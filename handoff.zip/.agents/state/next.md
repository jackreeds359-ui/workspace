# Next

## Actions in priority order

1. Get the first project task from the owner. There is no product code and no backlog.
2. Owner action: connect Unicorn Studio MCP in Hoplite Settings, Project, MCP. Add `https://agentmcp-qbght5huyq-uc.a.run.app/mcp`, run Analyze connection, save OAuth, Connect, approve in the browser, keep Allow agents enabled. Afterwards an agent verifies that the tools are discovered.
3. When a shadcn-compatible React project is created here, merge the `@react-bits` registry key into its `components.json` as described in `.agents/skills/reactbits/SKILL.md`.
4. Re-arm the recurring five-minute wake when it expires on 2026-11-13 12:00 UTC, if work is still active.
5. Owner decision on the default branch. GitHub made `hoplite/kyrene-3f44dbf5` the default because it was the first branch pushed to the empty repository. For a conventional layout, create `main` from commit `497363a` and make it the default in GitHub Settings, Branches. Do both steps together: if `main` exists while the thread branch is still the default, the updater skips its push and reports `skipped: upstream is the remote default branch`. Without a `main` there is no base branch for pull requests.

## Do not redo

- Skill installation. All thirteen folders are present. Reinstall only to update.
- The updater. Repair it in place. Never add a second checkpoint script.
- `AGENTS.md`. Edit it, do not replace it.

## Warnings

- `npx skills add ... -y` wrote the skills into about fifty agent-specific folders at the repository root, plus `data/`, `agent/` and `skills/`. Only `.agents/skills/` and `skills-lock.json` were kept. After any future install, check `git status` and remove the extra folders before committing. Read `npx skills add --help` for an agent-targeting option first.
- Never read or print the credential files under `.git/`.
- Upstream `designloop` files are unmodified third-party content. Change only `.agents/skills/designloop/SKILL.md`.
- A run that changes nothing reports `commit: unchanged` and writes no log line. That is expected.

## Checkpoint inspection 2026-11-12T23:57:06.761807+00:00

Scheduled continuation check: no new project task was supplied. Preserve the bootstrap and wait for the owner; do not begin unrelated implementation.
