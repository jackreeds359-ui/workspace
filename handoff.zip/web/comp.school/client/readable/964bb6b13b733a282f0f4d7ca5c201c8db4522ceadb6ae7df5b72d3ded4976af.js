function Ld(u, s) {
  for (var a = 0; a < s.length; a++) {
    const d = s[a];
    if (typeof d != "string" && !Array.isArray(d)) {
      for (const p in d)
        if (p !== "default" && !(p in u)) {
          const y = Object.getOwnPropertyDescriptor(d, p);
          y &&
            Object.defineProperty(
              u,
              p,
              y.get ? y : { enumerable: !0, get: () => d[p] },
            );
        }
    }
  }
  return Object.freeze(
    Object.defineProperty(u, Symbol.toStringTag, { value: "Module" }),
  );
}
function qu(u) {
  return u && u.__esModule && Object.prototype.hasOwnProperty.call(u, "default")
    ? u.default
    : u;
}
var Wu = { exports: {} },
  Rr = {},
  Vu = { exports: {} },
  q = {};
/**
 * @license React
 * react.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var tc;
function Td() {
  if (tc) return q;
  tc = 1;
  var u = Symbol.for("react.element"),
    s = Symbol.for("react.portal"),
    a = Symbol.for("react.fragment"),
    d = Symbol.for("react.strict_mode"),
    p = Symbol.for("react.profiler"),
    y = Symbol.for("react.provider"),
    S = Symbol.for("react.context"),
    E = Symbol.for("react.forward_ref"),
    k = Symbol.for("react.suspense"),
    x = Symbol.for("react.memo"),
    _ = Symbol.for("react.lazy"),
    z = Symbol.iterator;
  function F(m) {
    return m === null || typeof m != "object"
      ? null
      : ((m = (z && m[z]) || m["@@iterator"]),
        typeof m == "function" ? m : null);
  }
  var V = {
      isMounted: function () {
        return !1;
      },
      enqueueForceUpdate: function () {},
      enqueueReplaceState: function () {},
      enqueueSetState: function () {},
    },
    Y = Object.assign,
    H = {};
  function O(m, R, J) {
    ((this.props = m),
      (this.context = R),
      (this.refs = H),
      (this.updater = J || V));
  }
  ((O.prototype.isReactComponent = {}),
    (O.prototype.setState = function (m, R) {
      if (typeof m != "object" && typeof m != "function" && m != null)
        throw Error(
          "setState(...): takes an object of state variables to update or a function which returns an object of state variables.",
        );
      this.updater.enqueueSetState(this, m, R, "setState");
    }),
    (O.prototype.forceUpdate = function (m) {
      this.updater.enqueueForceUpdate(this, m, "forceUpdate");
    }));
  function W() {}
  W.prototype = O.prototype;
  function A(m, R, J) {
    ((this.props = m),
      (this.context = R),
      (this.refs = H),
      (this.updater = J || V));
  }
  var Z = (A.prototype = new W());
  ((Z.constructor = A), Y(Z, O.prototype), (Z.isPureReactComponent = !0));
  var ue = Array.isArray,
    he = Object.prototype.hasOwnProperty,
    ke = { current: null },
    Ee = { key: !0, ref: !0, __self: !0, __source: !0 };
  function Te(m, R, J) {
    var b,
      te = {},
      ne = null,
      ie = null;
    if (R != null)
      for (b in (R.ref !== void 0 && (ie = R.ref),
      R.key !== void 0 && (ne = "" + R.key),
      R))
        he.call(R, b) && !Ee.hasOwnProperty(b) && (te[b] = R[b]);
    var le = arguments.length - 2;
    if (le === 1) te.children = J;
    else if (1 < le) {
      for (var fe = Array(le), Xe = 0; Xe < le; Xe++)
        fe[Xe] = arguments[Xe + 2];
      te.children = fe;
    }
    if (m && m.defaultProps)
      for (b in ((le = m.defaultProps), le))
        te[b] === void 0 && (te[b] = le[b]);
    return {
      $$typeof: u,
      type: m,
      key: ne,
      ref: ie,
      props: te,
      _owner: ke.current,
    };
  }
  function Ce(m, R) {
    return {
      $$typeof: u,
      type: m.type,
      key: R,
      ref: m.ref,
      props: m.props,
      _owner: m._owner,
    };
  }
  function De(m) {
    return typeof m == "object" && m !== null && m.$$typeof === u;
  }
  function vt(m) {
    var R = { "=": "=0", ":": "=2" };
    return (
      "$" +
      m.replace(/[=:]/g, function (J) {
        return R[J];
      })
    );
  }
  var yt = /\/+/g;
  function Ye(m, R) {
    return typeof m == "object" && m !== null && m.key != null
      ? vt("" + m.key)
      : R.toString(36);
  }
  function ot(m, R, J, b, te) {
    var ne = typeof m;
    (ne === "undefined" || ne === "boolean") && (m = null);
    var ie = !1;
    if (m === null) ie = !0;
    else
      switch (ne) {
        case "string":
        case "number":
          ie = !0;
          break;
        case "object":
          switch (m.$$typeof) {
            case u:
            case s:
              ie = !0;
          }
      }
    if (ie)
      return (
        (ie = m),
        (te = te(ie)),
        (m = b === "" ? "." + Ye(ie, 0) : b),
        ue(te)
          ? ((J = ""),
            m != null && (J = m.replace(yt, "$&/") + "/"),
            ot(te, R, J, "", function (Xe) {
              return Xe;
            }))
          : te != null &&
            (De(te) &&
              (te = Ce(
                te,
                J +
                  (!te.key || (ie && ie.key === te.key)
                    ? ""
                    : ("" + te.key).replace(yt, "$&/") + "/") +
                  m,
              )),
            R.push(te)),
        1
      );
    if (((ie = 0), (b = b === "" ? "." : b + ":"), ue(m)))
      for (var le = 0; le < m.length; le++) {
        ne = m[le];
        var fe = b + Ye(ne, le);
        ie += ot(ne, R, J, fe, te);
      }
    else if (((fe = F(m)), typeof fe == "function"))
      for (m = fe.call(m), le = 0; !(ne = m.next()).done;)
        ((ne = ne.value),
          (fe = b + Ye(ne, le++)),
          (ie += ot(ne, R, J, fe, te)));
    else if (ne === "object")
      throw (
        (R = String(m)),
        Error(
          "Objects are not valid as a React child (found: " +
            (R === "[object Object]"
              ? "object with keys {" + Object.keys(m).join(", ") + "}"
              : R) +
            "). If you meant to render a collection of children, use an array instead.",
        )
      );
    return ie;
  }
  function gt(m, R, J) {
    if (m == null) return m;
    var b = [],
      te = 0;
    return (
      ot(m, b, "", "", function (ne) {
        return R.call(J, ne, te++);
      }),
      b
    );
  }
  function Ae(m) {
    if (m._status === -1) {
      var R = m._result;
      ((R = R()),
        R.then(
          function (J) {
            (m._status === 0 || m._status === -1) &&
              ((m._status = 1), (m._result = J));
          },
          function (J) {
            (m._status === 0 || m._status === -1) &&
              ((m._status = 2), (m._result = J));
          },
        ),
        m._status === -1 && ((m._status = 0), (m._result = R)));
    }
    if (m._status === 1) return m._result.default;
    throw m._result;
  }
  var ye = { current: null },
    D = { transition: null },
    X = {
      ReactCurrentDispatcher: ye,
      ReactCurrentBatchConfig: D,
      ReactCurrentOwner: ke,
    };
  function j() {
    throw Error("act(...) is not supported in production builds of React.");
  }
  return (
    (q.Children = {
      map: gt,
      forEach: function (m, R, J) {
        gt(
          m,
          function () {
            R.apply(this, arguments);
          },
          J,
        );
      },
      count: function (m) {
        var R = 0;
        return (
          gt(m, function () {
            R++;
          }),
          R
        );
      },
      toArray: function (m) {
        return (
          gt(m, function (R) {
            return R;
          }) || []
        );
      },
      only: function (m) {
        if (!De(m))
          throw Error(
            "React.Children.only expected to receive a single React element child.",
          );
        return m;
      },
    }),
    (q.Component = O),
    (q.Fragment = a),
    (q.Profiler = p),
    (q.PureComponent = A),
    (q.StrictMode = d),
    (q.Suspense = k),
    (q.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = X),
    (q.act = j),
    (q.cloneElement = function (m, R, J) {
      if (m == null)
        throw Error(
          "React.cloneElement(...): The argument must be a React element, but you passed " +
            m +
            ".",
        );
      var b = Y({}, m.props),
        te = m.key,
        ne = m.ref,
        ie = m._owner;
      if (R != null) {
        if (
          (R.ref !== void 0 && ((ne = R.ref), (ie = ke.current)),
          R.key !== void 0 && (te = "" + R.key),
          m.type && m.type.defaultProps)
        )
          var le = m.type.defaultProps;
        for (fe in R)
          he.call(R, fe) &&
            !Ee.hasOwnProperty(fe) &&
            (b[fe] = R[fe] === void 0 && le !== void 0 ? le[fe] : R[fe]);
      }
      var fe = arguments.length - 2;
      if (fe === 1) b.children = J;
      else if (1 < fe) {
        le = Array(fe);
        for (var Xe = 0; Xe < fe; Xe++) le[Xe] = arguments[Xe + 2];
        b.children = le;
      }
      return {
        $$typeof: u,
        type: m.type,
        key: te,
        ref: ne,
        props: b,
        _owner: ie,
      };
    }),
    (q.createContext = function (m) {
      return (
        (m = {
          $$typeof: S,
          _currentValue: m,
          _currentValue2: m,
          _threadCount: 0,
          Provider: null,
          Consumer: null,
          _defaultValue: null,
          _globalName: null,
        }),
        (m.Provider = { $$typeof: y, _context: m }),
        (m.Consumer = m)
      );
    }),
    (q.createElement = Te),
    (q.createFactory = function (m) {
      var R = Te.bind(null, m);
      return ((R.type = m), R);
    }),
    (q.createRef = function () {
      return { current: null };
    }),
    (q.forwardRef = function (m) {
      return { $$typeof: E, render: m };
    }),
    (q.isValidElement = De),
    (q.lazy = function (m) {
      return { $$typeof: _, _payload: { _status: -1, _result: m }, _init: Ae };
    }),
    (q.memo = function (m, R) {
      return { $$typeof: x, type: m, compare: R === void 0 ? null : R };
    }),
    (q.startTransition = function (m) {
      var R = D.transition;
      D.transition = {};
      try {
        m();
      } finally {
        D.transition = R;
      }
    }),
    (q.unstable_act = j),
    (q.useCallback = function (m, R) {
      return ye.current.useCallback(m, R);
    }),
    (q.useContext = function (m) {
      return ye.current.useContext(m);
    }),
    (q.useDebugValue = function () {}),
    (q.useDeferredValue = function (m) {
      return ye.current.useDeferredValue(m);
    }),
    (q.useEffect = function (m, R) {
      return ye.current.useEffect(m, R);
    }),
    (q.useId = function () {
      return ye.current.useId();
    }),
    (q.useImperativeHandle = function (m, R, J) {
      return ye.current.useImperativeHandle(m, R, J);
    }),
    (q.useInsertionEffect = function (m, R) {
      return ye.current.useInsertionEffect(m, R);
    }),
    (q.useLayoutEffect = function (m, R) {
      return ye.current.useLayoutEffect(m, R);
    }),
    (q.useMemo = function (m, R) {
      return ye.current.useMemo(m, R);
    }),
    (q.useReducer = function (m, R, J) {
      return ye.current.useReducer(m, R, J);
    }),
    (q.useRef = function (m) {
      return ye.current.useRef(m);
    }),
    (q.useState = function (m) {
      return ye.current.useState(m);
    }),
    (q.useSyncExternalStore = function (m, R, J) {
      return ye.current.useSyncExternalStore(m, R, J);
    }),
    (q.useTransition = function () {
      return ye.current.useTransition();
    }),
    (q.version = "18.3.1"),
    q
  );
}
var nc;
function bu() {
  return (nc || ((nc = 1), (Vu.exports = Td())), Vu.exports);
}
/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var rc;
function zd() {
  if (rc) return Rr;
  rc = 1;
  var u = bu(),
    s = Symbol.for("react.element"),
    a = Symbol.for("react.fragment"),
    d = Object.prototype.hasOwnProperty,
    p = u.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,
    y = { key: !0, ref: !0, __self: !0, __source: !0 };
  function S(E, k, x) {
    var _,
      z = {},
      F = null,
      V = null;
    (x !== void 0 && (F = "" + x),
      k.key !== void 0 && (F = "" + k.key),
      k.ref !== void 0 && (V = k.ref));
    for (_ in k) d.call(k, _) && !y.hasOwnProperty(_) && (z[_] = k[_]);
    if (E && E.defaultProps)
      for (_ in ((k = E.defaultProps), k)) z[_] === void 0 && (z[_] = k[_]);
    return {
      $$typeof: s,
      type: E,
      key: F,
      ref: V,
      props: z,
      _owner: p.current,
    };
  }
  return ((Rr.Fragment = a), (Rr.jsx = S), (Rr.jsxs = S), Rr);
}
var lc;
function Od() {
  return (lc || ((lc = 1), (Wu.exports = zd())), Wu.exports);
}
var ih = Od(),
  C = bu();
const Dd = qu(C),
  ah = Ld({ __proto__: null, default: Dd }, [C]);
var Hl = {},
  Qu = { exports: {} },
  Ke = {},
  Ku = { exports: {} },
  Yu = {};
/**
 * @license React
 * scheduler.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var oc;
function Md() {
  return (
    oc ||
      ((oc = 1),
      (function (u) {
        function s(D, X) {
          var j = D.length;
          D.push(X);
          e: for (; 0 < j;) {
            var m = (j - 1) >>> 1,
              R = D[m];
            if (0 < p(R, X)) ((D[m] = X), (D[j] = R), (j = m));
            else break e;
          }
        }
        function a(D) {
          return D.length === 0 ? null : D[0];
        }
        function d(D) {
          if (D.length === 0) return null;
          var X = D[0],
            j = D.pop();
          if (j !== X) {
            D[0] = j;
            e: for (var m = 0, R = D.length, J = R >>> 1; m < J;) {
              var b = 2 * (m + 1) - 1,
                te = D[b],
                ne = b + 1,
                ie = D[ne];
              if (0 > p(te, j))
                ne < R && 0 > p(ie, te)
                  ? ((D[m] = ie), (D[ne] = j), (m = ne))
                  : ((D[m] = te), (D[b] = j), (m = b));
              else if (ne < R && 0 > p(ie, j))
                ((D[m] = ie), (D[ne] = j), (m = ne));
              else break e;
            }
          }
          return X;
        }
        function p(D, X) {
          var j = D.sortIndex - X.sortIndex;
          return j !== 0 ? j : D.id - X.id;
        }
        if (
          typeof performance == "object" &&
          typeof performance.now == "function"
        ) {
          var y = performance;
          u.unstable_now = function () {
            return y.now();
          };
        } else {
          var S = Date,
            E = S.now();
          u.unstable_now = function () {
            return S.now() - E;
          };
        }
        var k = [],
          x = [],
          _ = 1,
          z = null,
          F = 3,
          V = !1,
          Y = !1,
          H = !1,
          O = typeof setTimeout == "function" ? setTimeout : null,
          W = typeof clearTimeout == "function" ? clearTimeout : null,
          A = typeof setImmediate < "u" ? setImmediate : null;
        typeof navigator < "u" &&
          navigator.scheduling !== void 0 &&
          navigator.scheduling.isInputPending !== void 0 &&
          navigator.scheduling.isInputPending.bind(navigator.scheduling);
        function Z(D) {
          for (var X = a(x); X !== null;) {
            if (X.callback === null) d(x);
            else if (X.startTime <= D)
              (d(x), (X.sortIndex = X.expirationTime), s(k, X));
            else break;
            X = a(x);
          }
        }
        function ue(D) {
          if (((H = !1), Z(D), !Y))
            if (a(k) !== null) ((Y = !0), Ae(he));
            else {
              var X = a(x);
              X !== null && ye(ue, X.startTime - D);
            }
        }
        function he(D, X) {
          ((Y = !1), H && ((H = !1), W(Te), (Te = -1)), (V = !0));
          var j = F;
          try {
            for (
              Z(X), z = a(k);
              z !== null && (!(z.expirationTime > X) || (D && !vt()));
            ) {
              var m = z.callback;
              if (typeof m == "function") {
                ((z.callback = null), (F = z.priorityLevel));
                var R = m(z.expirationTime <= X);
                ((X = u.unstable_now()),
                  typeof R == "function"
                    ? (z.callback = R)
                    : z === a(k) && d(k),
                  Z(X));
              } else d(k);
              z = a(k);
            }
            if (z !== null) var J = !0;
            else {
              var b = a(x);
              (b !== null && ye(ue, b.startTime - X), (J = !1));
            }
            return J;
          } finally {
            ((z = null), (F = j), (V = !1));
          }
        }
        var ke = !1,
          Ee = null,
          Te = -1,
          Ce = 5,
          De = -1;
        function vt() {
          return !(u.unstable_now() - De < Ce);
        }
        function yt() {
          if (Ee !== null) {
            var D = u.unstable_now();
            De = D;
            var X = !0;
            try {
              X = Ee(!0, D);
            } finally {
              X ? Ye() : ((ke = !1), (Ee = null));
            }
          } else ke = !1;
        }
        var Ye;
        if (typeof A == "function")
          Ye = function () {
            A(yt);
          };
        else if (typeof MessageChannel < "u") {
          var ot = new MessageChannel(),
            gt = ot.port2;
          ((ot.port1.onmessage = yt),
            (Ye = function () {
              gt.postMessage(null);
            }));
        } else
          Ye = function () {
            O(yt, 0);
          };
        function Ae(D) {
          ((Ee = D), ke || ((ke = !0), Ye()));
        }
        function ye(D, X) {
          Te = O(function () {
            D(u.unstable_now());
          }, X);
        }
        ((u.unstable_IdlePriority = 5),
          (u.unstable_ImmediatePriority = 1),
          (u.unstable_LowPriority = 4),
          (u.unstable_NormalPriority = 3),
          (u.unstable_Profiling = null),
          (u.unstable_UserBlockingPriority = 2),
          (u.unstable_cancelCallback = function (D) {
            D.callback = null;
          }),
          (u.unstable_continueExecution = function () {
            Y || V || ((Y = !0), Ae(he));
          }),
          (u.unstable_forceFrameRate = function (D) {
            0 > D || 125 < D
              ? console.error(
                  "forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported",
                )
              : (Ce = 0 < D ? Math.floor(1e3 / D) : 5);
          }),
          (u.unstable_getCurrentPriorityLevel = function () {
            return F;
          }),
          (u.unstable_getFirstCallbackNode = function () {
            return a(k);
          }),
          (u.unstable_next = function (D) {
            switch (F) {
              case 1:
              case 2:
              case 3:
                var X = 3;
                break;
              default:
                X = F;
            }
            var j = F;
            F = X;
            try {
              return D();
            } finally {
              F = j;
            }
          }),
          (u.unstable_pauseExecution = function () {}),
          (u.unstable_requestPaint = function () {}),
          (u.unstable_runWithPriority = function (D, X) {
            switch (D) {
              case 1:
              case 2:
              case 3:
              case 4:
              case 5:
                break;
              default:
                D = 3;
            }
            var j = F;
            F = D;
            try {
              return X();
            } finally {
              F = j;
            }
          }),
          (u.unstable_scheduleCallback = function (D, X, j) {
            var m = u.unstable_now();
            switch (
              (typeof j == "object" && j !== null
                ? ((j = j.delay),
                  (j = typeof j == "number" && 0 < j ? m + j : m))
                : (j = m),
              D)
            ) {
              case 1:
                var R = -1;
                break;
              case 2:
                R = 250;
                break;
              case 5:
                R = 1073741823;
                break;
              case 4:
                R = 1e4;
                break;
              default:
                R = 5e3;
            }
            return (
              (R = j + R),
              (D = {
                id: _++,
                callback: X,
                priorityLevel: D,
                startTime: j,
                expirationTime: R,
                sortIndex: -1,
              }),
              j > m
                ? ((D.sortIndex = j),
                  s(x, D),
                  a(k) === null &&
                    D === a(x) &&
                    (H ? (W(Te), (Te = -1)) : (H = !0), ye(ue, j - m)))
                : ((D.sortIndex = R), s(k, D), Y || V || ((Y = !0), Ae(he))),
              D
            );
          }),
          (u.unstable_shouldYield = vt),
          (u.unstable_wrapCallback = function (D) {
            var X = F;
            return function () {
              var j = F;
              F = X;
              try {
                return D.apply(this, arguments);
              } finally {
                F = j;
              }
            };
          }));
      })(Yu)),
    Yu
  );
}
var uc;
function Fd() {
  return (uc || ((uc = 1), (Ku.exports = Md())), Ku.exports);
}
/**
 * @license React
 * react-dom.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var ic;
function Id() {
  if (ic) return Ke;
  ic = 1;
  var u = bu(),
    s = Fd();
  function a(e) {
    for (
      var t = "https://reactjs.org/docs/error-decoder.html?invariant=" + e,
        n = 1;
      n < arguments.length;
      n++
    )
      t += "&args[]=" + encodeURIComponent(arguments[n]);
    return (
      "Minified React error #" +
      e +
      "; visit " +
      t +
      " for the full message or use the non-minified dev environment for full errors and additional helpful warnings."
    );
  }
  var d = new Set(),
    p = {};
  function y(e, t) {
    (S(e, t), S(e + "Capture", t));
  }
  function S(e, t) {
    for (p[e] = t, e = 0; e < t.length; e++) d.add(t[e]);
  }
  var E = !(
      typeof window > "u" ||
      typeof window.document > "u" ||
      typeof window.document.createElement > "u"
    ),
    k = Object.prototype.hasOwnProperty,
    x =
      /^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/,
    _ = {},
    z = {};
  function F(e) {
    return k.call(z, e)
      ? !0
      : k.call(_, e)
        ? !1
        : x.test(e)
          ? (z[e] = !0)
          : ((_[e] = !0), !1);
  }
  function V(e, t, n, r) {
    if (n !== null && n.type === 0) return !1;
    switch (typeof t) {
      case "function":
      case "symbol":
        return !0;
      case "boolean":
        return r
          ? !1
          : n !== null
            ? !n.acceptsBooleans
            : ((e = e.toLowerCase().slice(0, 5)),
              e !== "data-" && e !== "aria-");
      default:
        return !1;
    }
  }
  function Y(e, t, n, r) {
    if (t === null || typeof t > "u" || V(e, t, n, r)) return !0;
    if (r) return !1;
    if (n !== null)
      switch (n.type) {
        case 3:
          return !t;
        case 4:
          return t === !1;
        case 5:
          return isNaN(t);
        case 6:
          return isNaN(t) || 1 > t;
      }
    return !1;
  }
  function H(e, t, n, r, l, o, i) {
    ((this.acceptsBooleans = t === 2 || t === 3 || t === 4),
      (this.attributeName = r),
      (this.attributeNamespace = l),
      (this.mustUseProperty = n),
      (this.propertyName = e),
      (this.type = t),
      (this.sanitizeURL = o),
      (this.removeEmptyString = i));
  }
  var O = {};
  ("children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style"
    .split(" ")
    .forEach(function (e) {
      O[e] = new H(e, 0, !1, e, null, !1, !1);
    }),
    [
      ["acceptCharset", "accept-charset"],
      ["className", "class"],
      ["htmlFor", "for"],
      ["httpEquiv", "http-equiv"],
    ].forEach(function (e) {
      var t = e[0];
      O[t] = new H(t, 1, !1, e[1], null, !1, !1);
    }),
    ["contentEditable", "draggable", "spellCheck", "value"].forEach(
      function (e) {
        O[e] = new H(e, 2, !1, e.toLowerCase(), null, !1, !1);
      },
    ),
    [
      "autoReverse",
      "externalResourcesRequired",
      "focusable",
      "preserveAlpha",
    ].forEach(function (e) {
      O[e] = new H(e, 2, !1, e, null, !1, !1);
    }),
    "allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope"
      .split(" ")
      .forEach(function (e) {
        O[e] = new H(e, 3, !1, e.toLowerCase(), null, !1, !1);
      }),
    ["checked", "multiple", "muted", "selected"].forEach(function (e) {
      O[e] = new H(e, 3, !0, e, null, !1, !1);
    }),
    ["capture", "download"].forEach(function (e) {
      O[e] = new H(e, 4, !1, e, null, !1, !1);
    }),
    ["cols", "rows", "size", "span"].forEach(function (e) {
      O[e] = new H(e, 6, !1, e, null, !1, !1);
    }),
    ["rowSpan", "start"].forEach(function (e) {
      O[e] = new H(e, 5, !1, e.toLowerCase(), null, !1, !1);
    }));
  var W = /[\-:]([a-z])/g;
  function A(e) {
    return e[1].toUpperCase();
  }
  ("accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height"
    .split(" ")
    .forEach(function (e) {
      var t = e.replace(W, A);
      O[t] = new H(t, 1, !1, e, null, !1, !1);
    }),
    "xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type"
      .split(" ")
      .forEach(function (e) {
        var t = e.replace(W, A);
        O[t] = new H(t, 1, !1, e, "http://www.w3.org/1999/xlink", !1, !1);
      }),
    ["xml:base", "xml:lang", "xml:space"].forEach(function (e) {
      var t = e.replace(W, A);
      O[t] = new H(t, 1, !1, e, "http://www.w3.org/XML/1998/namespace", !1, !1);
    }),
    ["tabIndex", "crossOrigin"].forEach(function (e) {
      O[e] = new H(e, 1, !1, e.toLowerCase(), null, !1, !1);
    }),
    (O.xlinkHref = new H(
      "xlinkHref",
      1,
      !1,
      "xlink:href",
      "http://www.w3.org/1999/xlink",
      !0,
      !1,
    )),
    ["src", "href", "action", "formAction"].forEach(function (e) {
      O[e] = new H(e, 1, !1, e.toLowerCase(), null, !0, !0);
    }));
  function Z(e, t, n, r) {
    var l = O.hasOwnProperty(t) ? O[t] : null;
    (l !== null
      ? l.type !== 0
      : r ||
        !(2 < t.length) ||
        (t[0] !== "o" && t[0] !== "O") ||
        (t[1] !== "n" && t[1] !== "N")) &&
      (Y(t, n, l, r) && (n = null),
      r || l === null
        ? F(t) &&
          (n === null ? e.removeAttribute(t) : e.setAttribute(t, "" + n))
        : l.mustUseProperty
          ? (e[l.propertyName] = n === null ? (l.type === 3 ? !1 : "") : n)
          : ((t = l.attributeName),
            (r = l.attributeNamespace),
            n === null
              ? e.removeAttribute(t)
              : ((l = l.type),
                (n = l === 3 || (l === 4 && n === !0) ? "" : "" + n),
                r ? e.setAttributeNS(r, t, n) : e.setAttribute(t, n))));
  }
  var ue = u.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED,
    he = Symbol.for("react.element"),
    ke = Symbol.for("react.portal"),
    Ee = Symbol.for("react.fragment"),
    Te = Symbol.for("react.strict_mode"),
    Ce = Symbol.for("react.profiler"),
    De = Symbol.for("react.provider"),
    vt = Symbol.for("react.context"),
    yt = Symbol.for("react.forward_ref"),
    Ye = Symbol.for("react.suspense"),
    ot = Symbol.for("react.suspense_list"),
    gt = Symbol.for("react.memo"),
    Ae = Symbol.for("react.lazy"),
    ye = Symbol.for("react.offscreen"),
    D = Symbol.iterator;
  function X(e) {
    return e === null || typeof e != "object"
      ? null
      : ((e = (D && e[D]) || e["@@iterator"]),
        typeof e == "function" ? e : null);
  }
  var j = Object.assign,
    m;
  function R(e) {
    if (m === void 0)
      try {
        throw Error();
      } catch (n) {
        var t = n.stack.trim().match(/\n( *(at )?)/);
        m = (t && t[1]) || "";
      }
    return (
      `
` +
      m +
      e
    );
  }
  var J = !1;
  function b(e, t) {
    if (!e || J) return "";
    J = !0;
    var n = Error.prepareStackTrace;
    Error.prepareStackTrace = void 0;
    try {
      if (t)
        if (
          ((t = function () {
            throw Error();
          }),
          Object.defineProperty(t.prototype, "props", {
            set: function () {
              throw Error();
            },
          }),
          typeof Reflect == "object" && Reflect.construct)
        ) {
          try {
            Reflect.construct(t, []);
          } catch (w) {
            var r = w;
          }
          Reflect.construct(e, [], t);
        } else {
          try {
            t.call();
          } catch (w) {
            r = w;
          }
          e.call(t.prototype);
        }
      else {
        try {
          throw Error();
        } catch (w) {
          r = w;
        }
        e();
      }
    } catch (w) {
      if (w && r && typeof w.stack == "string") {
        for (
          var l = w.stack.split(`
`),
            o = r.stack.split(`
`),
            i = l.length - 1,
            c = o.length - 1;
          1 <= i && 0 <= c && l[i] !== o[c];
        )
          c--;
        for (; 1 <= i && 0 <= c; i--, c--)
          if (l[i] !== o[c]) {
            if (i !== 1 || c !== 1)
              do
                if ((i--, c--, 0 > c || l[i] !== o[c])) {
                  var f =
                    `
` + l[i].replace(" at new ", " at ");
                  return (
                    e.displayName &&
                      f.includes("<anonymous>") &&
                      (f = f.replace("<anonymous>", e.displayName)),
                    f
                  );
                }
              while (1 <= i && 0 <= c);
            break;
          }
      }
    } finally {
      ((J = !1), (Error.prepareStackTrace = n));
    }
    return (e = e ? e.displayName || e.name : "") ? R(e) : "";
  }
  function te(e) {
    switch (e.tag) {
      case 5:
        return R(e.type);
      case 16:
        return R("Lazy");
      case 13:
        return R("Suspense");
      case 19:
        return R("SuspenseList");
      case 0:
      case 2:
      case 15:
        return ((e = b(e.type, !1)), e);
      case 11:
        return ((e = b(e.type.render, !1)), e);
      case 1:
        return ((e = b(e.type, !0)), e);
      default:
        return "";
    }
  }
  function ne(e) {
    if (e == null) return null;
    if (typeof e == "function") return e.displayName || e.name || null;
    if (typeof e == "string") return e;
    switch (e) {
      case Ee:
        return "Fragment";
      case ke:
        return "Portal";
      case Ce:
        return "Profiler";
      case Te:
        return "StrictMode";
      case Ye:
        return "Suspense";
      case ot:
        return "SuspenseList";
    }
    if (typeof e == "object")
      switch (e.$$typeof) {
        case vt:
          return (e.displayName || "Context") + ".Consumer";
        case De:
          return (e._context.displayName || "Context") + ".Provider";
        case yt:
          var t = e.render;
          return (
            (e = e.displayName),
            e ||
              ((e = t.displayName || t.name || ""),
              (e = e !== "" ? "ForwardRef(" + e + ")" : "ForwardRef")),
            e
          );
        case gt:
          return (
            (t = e.displayName || null),
            t !== null ? t : ne(e.type) || "Memo"
          );
        case Ae:
          ((t = e._payload), (e = e._init));
          try {
            return ne(e(t));
          } catch {}
      }
    return null;
  }
  function ie(e) {
    var t = e.type;
    switch (e.tag) {
      case 24:
        return "Cache";
      case 9:
        return (t.displayName || "Context") + ".Consumer";
      case 10:
        return (t._context.displayName || "Context") + ".Provider";
      case 18:
        return "DehydratedFragment";
      case 11:
        return (
          (e = t.render),
          (e = e.displayName || e.name || ""),
          t.displayName || (e !== "" ? "ForwardRef(" + e + ")" : "ForwardRef")
        );
      case 7:
        return "Fragment";
      case 5:
        return t;
      case 4:
        return "Portal";
      case 3:
        return "Root";
      case 6:
        return "Text";
      case 16:
        return ne(t);
      case 8:
        return t === Te ? "StrictMode" : "Mode";
      case 22:
        return "Offscreen";
      case 12:
        return "Profiler";
      case 21:
        return "Scope";
      case 13:
        return "Suspense";
      case 19:
        return "SuspenseList";
      case 25:
        return "TracingMarker";
      case 1:
      case 0:
      case 17:
      case 2:
      case 14:
      case 15:
        if (typeof t == "function") return t.displayName || t.name || null;
        if (typeof t == "string") return t;
    }
    return null;
  }
  function le(e) {
    switch (typeof e) {
      case "boolean":
      case "number":
      case "string":
      case "undefined":
        return e;
      case "object":
        return e;
      default:
        return "";
    }
  }
  function fe(e) {
    var t = e.type;
    return (
      (e = e.nodeName) &&
      e.toLowerCase() === "input" &&
      (t === "checkbox" || t === "radio")
    );
  }
  function Xe(e) {
    var t = fe(e) ? "checked" : "value",
      n = Object.getOwnPropertyDescriptor(e.constructor.prototype, t),
      r = "" + e[t];
    if (
      !e.hasOwnProperty(t) &&
      typeof n < "u" &&
      typeof n.get == "function" &&
      typeof n.set == "function"
    ) {
      var l = n.get,
        o = n.set;
      return (
        Object.defineProperty(e, t, {
          configurable: !0,
          get: function () {
            return l.call(this);
          },
          set: function (i) {
            ((r = "" + i), o.call(this, i));
          },
        }),
        Object.defineProperty(e, t, { enumerable: n.enumerable }),
        {
          getValue: function () {
            return r;
          },
          setValue: function (i) {
            r = "" + i;
          },
          stopTracking: function () {
            ((e._valueTracker = null), delete e[t]);
          },
        }
      );
    }
  }
  function Or(e) {
    e._valueTracker || (e._valueTracker = Xe(e));
  }
  function ii(e) {
    if (!e) return !1;
    var t = e._valueTracker;
    if (!t) return !0;
    var n = t.getValue(),
      r = "";
    return (
      e && (r = fe(e) ? (e.checked ? "true" : "false") : e.value),
      (e = r),
      e !== n ? (t.setValue(e), !0) : !1
    );
  }
  function Dr(e) {
    if (
      ((e = e || (typeof document < "u" ? document : void 0)), typeof e > "u")
    )
      return null;
    try {
      return e.activeElement || e.body;
    } catch {
      return e.body;
    }
  }
  function Gl(e, t) {
    var n = t.checked;
    return j({}, t, {
      defaultChecked: void 0,
      defaultValue: void 0,
      value: void 0,
      checked: n ?? e._wrapperState.initialChecked,
    });
  }
  function ai(e, t) {
    var n = t.defaultValue == null ? "" : t.defaultValue,
      r = t.checked != null ? t.checked : t.defaultChecked;
    ((n = le(t.value != null ? t.value : n)),
      (e._wrapperState = {
        initialChecked: r,
        initialValue: n,
        controlled:
          t.type === "checkbox" || t.type === "radio"
            ? t.checked != null
            : t.value != null,
      }));
  }
  function si(e, t) {
    ((t = t.checked), t != null && Z(e, "checked", t, !1));
  }
  function Jl(e, t) {
    si(e, t);
    var n = le(t.value),
      r = t.type;
    if (n != null)
      r === "number"
        ? ((n === 0 && e.value === "") || e.value != n) && (e.value = "" + n)
        : e.value !== "" + n && (e.value = "" + n);
    else if (r === "submit" || r === "reset") {
      e.removeAttribute("value");
      return;
    }
    (t.hasOwnProperty("value")
      ? Zl(e, t.type, n)
      : t.hasOwnProperty("defaultValue") && Zl(e, t.type, le(t.defaultValue)),
      t.checked == null &&
        t.defaultChecked != null &&
        (e.defaultChecked = !!t.defaultChecked));
  }
  function ci(e, t, n) {
    if (t.hasOwnProperty("value") || t.hasOwnProperty("defaultValue")) {
      var r = t.type;
      if (!(
        (r !== "submit" && r !== "reset") ||
        (t.value !== void 0 && t.value !== null)
      ))
        return;
      ((t = "" + e._wrapperState.initialValue),
        n || t === e.value || (e.value = t),
        (e.defaultValue = t));
    }
    ((n = e.name),
      n !== "" && (e.name = ""),
      (e.defaultChecked = !!e._wrapperState.initialChecked),
      n !== "" && (e.name = n));
  }
  function Zl(e, t, n) {
    (t !== "number" || Dr(e.ownerDocument) !== e) &&
      (n == null
        ? (e.defaultValue = "" + e._wrapperState.initialValue)
        : e.defaultValue !== "" + n && (e.defaultValue = "" + n));
  }
  var Hn = Array.isArray;
  function hn(e, t, n, r) {
    if (((e = e.options), t)) {
      t = {};
      for (var l = 0; l < n.length; l++) t["$" + n[l]] = !0;
      for (n = 0; n < e.length; n++)
        ((l = t.hasOwnProperty("$" + e[n].value)),
          e[n].selected !== l && (e[n].selected = l),
          l && r && (e[n].defaultSelected = !0));
    } else {
      for (n = "" + le(n), t = null, l = 0; l < e.length; l++) {
        if (e[l].value === n) {
          ((e[l].selected = !0), r && (e[l].defaultSelected = !0));
          return;
        }
        t !== null || e[l].disabled || (t = e[l]);
      }
      t !== null && (t.selected = !0);
    }
  }
  function ql(e, t) {
    if (t.dangerouslySetInnerHTML != null) throw Error(a(91));
    return j({}, t, {
      value: void 0,
      defaultValue: void 0,
      children: "" + e._wrapperState.initialValue,
    });
  }
  function fi(e, t) {
    var n = t.value;
    if (n == null) {
      if (((n = t.children), (t = t.defaultValue), n != null)) {
        if (t != null) throw Error(a(92));
        if (Hn(n)) {
          if (1 < n.length) throw Error(a(93));
          n = n[0];
        }
        t = n;
      }
      (t == null && (t = ""), (n = t));
    }
    e._wrapperState = { initialValue: le(n) };
  }
  function di(e, t) {
    var n = le(t.value),
      r = le(t.defaultValue);
    (n != null &&
      ((n = "" + n),
      n !== e.value && (e.value = n),
      t.defaultValue == null && e.defaultValue !== n && (e.defaultValue = n)),
      r != null && (e.defaultValue = "" + r));
  }
  function pi(e) {
    var t = e.textContent;
    t === e._wrapperState.initialValue &&
      t !== "" &&
      t !== null &&
      (e.value = t);
  }
  function hi(e) {
    switch (e) {
      case "svg":
        return "http://www.w3.org/2000/svg";
      case "math":
        return "http://www.w3.org/1998/Math/MathML";
      default:
        return "http://www.w3.org/1999/xhtml";
    }
  }
  function bl(e, t) {
    return e == null || e === "http://www.w3.org/1999/xhtml"
      ? hi(t)
      : e === "http://www.w3.org/2000/svg" && t === "foreignObject"
        ? "http://www.w3.org/1999/xhtml"
        : e;
  }
  var Mr,
    mi = (function (e) {
      return typeof MSApp < "u" && MSApp.execUnsafeLocalFunction
        ? function (t, n, r, l) {
            MSApp.execUnsafeLocalFunction(function () {
              return e(t, n, r, l);
            });
          }
        : e;
    })(function (e, t) {
      if (e.namespaceURI !== "http://www.w3.org/2000/svg" || "innerHTML" in e)
        e.innerHTML = t;
      else {
        for (
          Mr = Mr || document.createElement("div"),
            Mr.innerHTML = "<svg>" + t.valueOf().toString() + "</svg>",
            t = Mr.firstChild;
          e.firstChild;
        )
          e.removeChild(e.firstChild);
        for (; t.firstChild;) e.appendChild(t.firstChild);
      }
    });
  function Wn(e, t) {
    if (t) {
      var n = e.firstChild;
      if (n && n === e.lastChild && n.nodeType === 3) {
        n.nodeValue = t;
        return;
      }
    }
    e.textContent = t;
  }
  var Vn = {
      animationIterationCount: !0,
      aspectRatio: !0,
      borderImageOutset: !0,
      borderImageSlice: !0,
      borderImageWidth: !0,
      boxFlex: !0,
      boxFlexGroup: !0,
      boxOrdinalGroup: !0,
      columnCount: !0,
      columns: !0,
      flex: !0,
      flexGrow: !0,
      flexPositive: !0,
      flexShrink: !0,
      flexNegative: !0,
      flexOrder: !0,
      gridArea: !0,
      gridRow: !0,
      gridRowEnd: !0,
      gridRowSpan: !0,
      gridRowStart: !0,
      gridColumn: !0,
      gridColumnEnd: !0,
      gridColumnSpan: !0,
      gridColumnStart: !0,
      fontWeight: !0,
      lineClamp: !0,
      lineHeight: !0,
      opacity: !0,
      order: !0,
      orphans: !0,
      tabSize: !0,
      widows: !0,
      zIndex: !0,
      zoom: !0,
      fillOpacity: !0,
      floodOpacity: !0,
      stopOpacity: !0,
      strokeDasharray: !0,
      strokeDashoffset: !0,
      strokeMiterlimit: !0,
      strokeOpacity: !0,
      strokeWidth: !0,
    },
    Oc = ["Webkit", "ms", "Moz", "O"];
  Object.keys(Vn).forEach(function (e) {
    Oc.forEach(function (t) {
      ((t = t + e.charAt(0).toUpperCase() + e.substring(1)), (Vn[t] = Vn[e]));
    });
  });
  function vi(e, t, n) {
    return t == null || typeof t == "boolean" || t === ""
      ? ""
      : n || typeof t != "number" || t === 0 || (Vn.hasOwnProperty(e) && Vn[e])
        ? ("" + t).trim()
        : t + "px";
  }
  function yi(e, t) {
    e = e.style;
    for (var n in t)
      if (t.hasOwnProperty(n)) {
        var r = n.indexOf("--") === 0,
          l = vi(n, t[n], r);
        (n === "float" && (n = "cssFloat"),
          r ? e.setProperty(n, l) : (e[n] = l));
      }
  }
  var Dc = j(
    { menuitem: !0 },
    {
      area: !0,
      base: !0,
      br: !0,
      col: !0,
      embed: !0,
      hr: !0,
      img: !0,
      input: !0,
      keygen: !0,
      link: !0,
      meta: !0,
      param: !0,
      source: !0,
      track: !0,
      wbr: !0,
    },
  );
  function eo(e, t) {
    if (t) {
      if (Dc[e] && (t.children != null || t.dangerouslySetInnerHTML != null))
        throw Error(a(137, e));
      if (t.dangerouslySetInnerHTML != null) {
        if (t.children != null) throw Error(a(60));
        if (
          typeof t.dangerouslySetInnerHTML != "object" ||
          !("__html" in t.dangerouslySetInnerHTML)
        )
          throw Error(a(61));
      }
      if (t.style != null && typeof t.style != "object") throw Error(a(62));
    }
  }
  function to(e, t) {
    if (e.indexOf("-") === -1) return typeof t.is == "string";
    switch (e) {
      case "annotation-xml":
      case "color-profile":
      case "font-face":
      case "font-face-src":
      case "font-face-uri":
      case "font-face-format":
      case "font-face-name":
      case "missing-glyph":
        return !1;
      default:
        return !0;
    }
  }
  var no = null;
  function ro(e) {
    return (
      (e = e.target || e.srcElement || window),
      e.correspondingUseElement && (e = e.correspondingUseElement),
      e.nodeType === 3 ? e.parentNode : e
    );
  }
  var lo = null,
    mn = null,
    vn = null;
  function gi(e) {
    if ((e = dr(e))) {
      if (typeof lo != "function") throw Error(a(280));
      var t = e.stateNode;
      t && ((t = rl(t)), lo(e.stateNode, e.type, t));
    }
  }
  function wi(e) {
    mn ? (vn ? vn.push(e) : (vn = [e])) : (mn = e);
  }
  function Si() {
    if (mn) {
      var e = mn,
        t = vn;
      if (((vn = mn = null), gi(e), t)) for (e = 0; e < t.length; e++) gi(t[e]);
    }
  }
  function ki(e, t) {
    return e(t);
  }
  function Ei() {}
  var oo = !1;
  function Ci(e, t, n) {
    if (oo) return e(t, n);
    oo = !0;
    try {
      return ki(e, t, n);
    } finally {
      ((oo = !1), (mn !== null || vn !== null) && (Ei(), Si()));
    }
  }
  function Qn(e, t) {
    var n = e.stateNode;
    if (n === null) return null;
    var r = rl(n);
    if (r === null) return null;
    n = r[t];
    e: switch (t) {
      case "onClick":
      case "onClickCapture":
      case "onDoubleClick":
      case "onDoubleClickCapture":
      case "onMouseDown":
      case "onMouseDownCapture":
      case "onMouseMove":
      case "onMouseMoveCapture":
      case "onMouseUp":
      case "onMouseUpCapture":
      case "onMouseEnter":
        ((r = !r.disabled) ||
          ((e = e.type),
          (r = !(
            e === "button" ||
            e === "input" ||
            e === "select" ||
            e === "textarea"
          ))),
          (e = !r));
        break e;
      default:
        e = !1;
    }
    if (e) return null;
    if (n && typeof n != "function") throw Error(a(231, t, typeof n));
    return n;
  }
  var uo = !1;
  if (E)
    try {
      var Kn = {};
      (Object.defineProperty(Kn, "passive", {
        get: function () {
          uo = !0;
        },
      }),
        window.addEventListener("test", Kn, Kn),
        window.removeEventListener("test", Kn, Kn));
    } catch {
      uo = !1;
    }
  function Mc(e, t, n, r, l, o, i, c, f) {
    var w = Array.prototype.slice.call(arguments, 3);
    try {
      t.apply(n, w);
    } catch (N) {
      this.onError(N);
    }
  }
  var Yn = !1,
    Fr = null,
    Ir = !1,
    io = null,
    Fc = {
      onError: function (e) {
        ((Yn = !0), (Fr = e));
      },
    };
  function Ic(e, t, n, r, l, o, i, c, f) {
    ((Yn = !1), (Fr = null), Mc.apply(Fc, arguments));
  }
  function jc(e, t, n, r, l, o, i, c, f) {
    if ((Ic.apply(this, arguments), Yn)) {
      if (Yn) {
        var w = Fr;
        ((Yn = !1), (Fr = null));
      } else throw Error(a(198));
      Ir || ((Ir = !0), (io = w));
    }
  }
  function en(e) {
    var t = e,
      n = e;
    if (e.alternate) for (; t.return;) t = t.return;
    else {
      e = t;
      do ((t = e), (t.flags & 4098) !== 0 && (n = t.return), (e = t.return));
      while (e);
    }
    return t.tag === 3 ? n : null;
  }
  function xi(e) {
    if (e.tag === 13) {
      var t = e.memoizedState;
      if (
        (t === null && ((e = e.alternate), e !== null && (t = e.memoizedState)),
        t !== null)
      )
        return t.dehydrated;
    }
    return null;
  }
  function _i(e) {
    if (en(e) !== e) throw Error(a(188));
  }
  function $c(e) {
    var t = e.alternate;
    if (!t) {
      if (((t = en(e)), t === null)) throw Error(a(188));
      return t !== e ? null : e;
    }
    for (var n = e, r = t; ;) {
      var l = n.return;
      if (l === null) break;
      var o = l.alternate;
      if (o === null) {
        if (((r = l.return), r !== null)) {
          n = r;
          continue;
        }
        break;
      }
      if (l.child === o.child) {
        for (o = l.child; o;) {
          if (o === n) return (_i(l), e);
          if (o === r) return (_i(l), t);
          o = o.sibling;
        }
        throw Error(a(188));
      }
      if (n.return !== r.return) ((n = l), (r = o));
      else {
        for (var i = !1, c = l.child; c;) {
          if (c === n) {
            ((i = !0), (n = l), (r = o));
            break;
          }
          if (c === r) {
            ((i = !0), (r = l), (n = o));
            break;
          }
          c = c.sibling;
        }
        if (!i) {
          for (c = o.child; c;) {
            if (c === n) {
              ((i = !0), (n = o), (r = l));
              break;
            }
            if (c === r) {
              ((i = !0), (r = o), (n = l));
              break;
            }
            c = c.sibling;
          }
          if (!i) throw Error(a(189));
        }
      }
      if (n.alternate !== r) throw Error(a(190));
    }
    if (n.tag !== 3) throw Error(a(188));
    return n.stateNode.current === n ? e : t;
  }
  function Pi(e) {
    return ((e = $c(e)), e !== null ? Ri(e) : null);
  }
  function Ri(e) {
    if (e.tag === 5 || e.tag === 6) return e;
    for (e = e.child; e !== null;) {
      var t = Ri(e);
      if (t !== null) return t;
      e = e.sibling;
    }
    return null;
  }
  var Ni = s.unstable_scheduleCallback,
    Li = s.unstable_cancelCallback,
    Uc = s.unstable_shouldYield,
    Ac = s.unstable_requestPaint,
    we = s.unstable_now,
    Bc = s.unstable_getCurrentPriorityLevel,
    ao = s.unstable_ImmediatePriority,
    Ti = s.unstable_UserBlockingPriority,
    jr = s.unstable_NormalPriority,
    Hc = s.unstable_LowPriority,
    zi = s.unstable_IdlePriority,
    $r = null,
    wt = null;
  function Wc(e) {
    if (wt && typeof wt.onCommitFiberRoot == "function")
      try {
        wt.onCommitFiberRoot($r, e, void 0, (e.current.flags & 128) === 128);
      } catch {}
  }
  var ut = Math.clz32 ? Math.clz32 : Kc,
    Vc = Math.log,
    Qc = Math.LN2;
  function Kc(e) {
    return ((e >>>= 0), e === 0 ? 32 : (31 - ((Vc(e) / Qc) | 0)) | 0);
  }
  var Ur = 64,
    Ar = 4194304;
  function Xn(e) {
    switch (e & -e) {
      case 1:
        return 1;
      case 2:
        return 2;
      case 4:
        return 4;
      case 8:
        return 8;
      case 16:
        return 16;
      case 32:
        return 32;
      case 64:
      case 128:
      case 256:
      case 512:
      case 1024:
      case 2048:
      case 4096:
      case 8192:
      case 16384:
      case 32768:
      case 65536:
      case 131072:
      case 262144:
      case 524288:
      case 1048576:
      case 2097152:
        return e & 4194240;
      case 4194304:
      case 8388608:
      case 16777216:
      case 33554432:
      case 67108864:
        return e & 130023424;
      case 134217728:
        return 134217728;
      case 268435456:
        return 268435456;
      case 536870912:
        return 536870912;
      case 1073741824:
        return 1073741824;
      default:
        return e;
    }
  }
  function Br(e, t) {
    var n = e.pendingLanes;
    if (n === 0) return 0;
    var r = 0,
      l = e.suspendedLanes,
      o = e.pingedLanes,
      i = n & 268435455;
    if (i !== 0) {
      var c = i & ~l;
      c !== 0 ? (r = Xn(c)) : ((o &= i), o !== 0 && (r = Xn(o)));
    } else ((i = n & ~l), i !== 0 ? (r = Xn(i)) : o !== 0 && (r = Xn(o)));
    if (r === 0) return 0;
    if (
      t !== 0 &&
      t !== r &&
      (t & l) === 0 &&
      ((l = r & -r), (o = t & -t), l >= o || (l === 16 && (o & 4194240) !== 0))
    )
      return t;
    if (((r & 4) !== 0 && (r |= n & 16), (t = e.entangledLanes), t !== 0))
      for (e = e.entanglements, t &= r; 0 < t;)
        ((n = 31 - ut(t)), (l = 1 << n), (r |= e[n]), (t &= ~l));
    return r;
  }
  function Yc(e, t) {
    switch (e) {
      case 1:
      case 2:
      case 4:
        return t + 250;
      case 8:
      case 16:
      case 32:
      case 64:
      case 128:
      case 256:
      case 512:
      case 1024:
      case 2048:
      case 4096:
      case 8192:
      case 16384:
      case 32768:
      case 65536:
      case 131072:
      case 262144:
      case 524288:
      case 1048576:
      case 2097152:
        return t + 5e3;
      case 4194304:
      case 8388608:
      case 16777216:
      case 33554432:
      case 67108864:
        return -1;
      case 134217728:
      case 268435456:
      case 536870912:
      case 1073741824:
        return -1;
      default:
        return -1;
    }
  }
  function Xc(e, t) {
    for (
      var n = e.suspendedLanes,
        r = e.pingedLanes,
        l = e.expirationTimes,
        o = e.pendingLanes;
      0 < o;
    ) {
      var i = 31 - ut(o),
        c = 1 << i,
        f = l[i];
      (f === -1
        ? ((c & n) === 0 || (c & r) !== 0) && (l[i] = Yc(c, t))
        : f <= t && (e.expiredLanes |= c),
        (o &= ~c));
    }
  }
  function so(e) {
    return (
      (e = e.pendingLanes & -1073741825),
      e !== 0 ? e : e & 1073741824 ? 1073741824 : 0
    );
  }
  function Oi() {
    var e = Ur;
    return ((Ur <<= 1), (Ur & 4194240) === 0 && (Ur = 64), e);
  }
  function co(e) {
    for (var t = [], n = 0; 31 > n; n++) t.push(e);
    return t;
  }
  function Gn(e, t, n) {
    ((e.pendingLanes |= t),
      t !== 536870912 && ((e.suspendedLanes = 0), (e.pingedLanes = 0)),
      (e = e.eventTimes),
      (t = 31 - ut(t)),
      (e[t] = n));
  }
  function Gc(e, t) {
    var n = e.pendingLanes & ~t;
    ((e.pendingLanes = t),
      (e.suspendedLanes = 0),
      (e.pingedLanes = 0),
      (e.expiredLanes &= t),
      (e.mutableReadLanes &= t),
      (e.entangledLanes &= t),
      (t = e.entanglements));
    var r = e.eventTimes;
    for (e = e.expirationTimes; 0 < n;) {
      var l = 31 - ut(n),
        o = 1 << l;
      ((t[l] = 0), (r[l] = -1), (e[l] = -1), (n &= ~o));
    }
  }
  function fo(e, t) {
    var n = (e.entangledLanes |= t);
    for (e = e.entanglements; n;) {
      var r = 31 - ut(n),
        l = 1 << r;
      ((l & t) | (e[r] & t) && (e[r] |= t), (n &= ~l));
    }
  }
  var oe = 0;
  function Di(e) {
    return (
      (e &= -e),
      1 < e ? (4 < e ? ((e & 268435455) !== 0 ? 16 : 536870912) : 4) : 1
    );
  }
  var Mi,
    po,
    Fi,
    Ii,
    ji,
    ho = !1,
    Hr = [],
    Mt = null,
    Ft = null,
    It = null,
    Jn = new Map(),
    Zn = new Map(),
    jt = [],
    Jc =
      "mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(
        " ",
      );
  function $i(e, t) {
    switch (e) {
      case "focusin":
      case "focusout":
        Mt = null;
        break;
      case "dragenter":
      case "dragleave":
        Ft = null;
        break;
      case "mouseover":
      case "mouseout":
        It = null;
        break;
      case "pointerover":
      case "pointerout":
        Jn.delete(t.pointerId);
        break;
      case "gotpointercapture":
      case "lostpointercapture":
        Zn.delete(t.pointerId);
    }
  }
  function qn(e, t, n, r, l, o) {
    return e === null || e.nativeEvent !== o
      ? ((e = {
          blockedOn: t,
          domEventName: n,
          eventSystemFlags: r,
          nativeEvent: o,
          targetContainers: [l],
        }),
        t !== null && ((t = dr(t)), t !== null && po(t)),
        e)
      : ((e.eventSystemFlags |= r),
        (t = e.targetContainers),
        l !== null && t.indexOf(l) === -1 && t.push(l),
        e);
  }
  function Zc(e, t, n, r, l) {
    switch (t) {
      case "focusin":
        return ((Mt = qn(Mt, e, t, n, r, l)), !0);
      case "dragenter":
        return ((Ft = qn(Ft, e, t, n, r, l)), !0);
      case "mouseover":
        return ((It = qn(It, e, t, n, r, l)), !0);
      case "pointerover":
        var o = l.pointerId;
        return (Jn.set(o, qn(Jn.get(o) || null, e, t, n, r, l)), !0);
      case "gotpointercapture":
        return (
          (o = l.pointerId),
          Zn.set(o, qn(Zn.get(o) || null, e, t, n, r, l)),
          !0
        );
    }
    return !1;
  }
  function Ui(e) {
    var t = tn(e.target);
    if (t !== null) {
      var n = en(t);
      if (n !== null) {
        if (((t = n.tag), t === 13)) {
          if (((t = xi(n)), t !== null)) {
            ((e.blockedOn = t),
              ji(e.priority, function () {
                Fi(n);
              }));
            return;
          }
        } else if (t === 3 && n.stateNode.current.memoizedState.isDehydrated) {
          e.blockedOn = n.tag === 3 ? n.stateNode.containerInfo : null;
          return;
        }
      }
    }
    e.blockedOn = null;
  }
  function Wr(e) {
    if (e.blockedOn !== null) return !1;
    for (var t = e.targetContainers; 0 < t.length;) {
      var n = vo(e.domEventName, e.eventSystemFlags, t[0], e.nativeEvent);
      if (n === null) {
        n = e.nativeEvent;
        var r = new n.constructor(n.type, n);
        ((no = r), n.target.dispatchEvent(r), (no = null));
      } else return ((t = dr(n)), t !== null && po(t), (e.blockedOn = n), !1);
      t.shift();
    }
    return !0;
  }
  function Ai(e, t, n) {
    Wr(e) && n.delete(t);
  }
  function qc() {
    ((ho = !1),
      Mt !== null && Wr(Mt) && (Mt = null),
      Ft !== null && Wr(Ft) && (Ft = null),
      It !== null && Wr(It) && (It = null),
      Jn.forEach(Ai),
      Zn.forEach(Ai));
  }
  function bn(e, t) {
    e.blockedOn === t &&
      ((e.blockedOn = null),
      ho ||
        ((ho = !0),
        s.unstable_scheduleCallback(s.unstable_NormalPriority, qc)));
  }
  function er(e) {
    function t(l) {
      return bn(l, e);
    }
    if (0 < Hr.length) {
      bn(Hr[0], e);
      for (var n = 1; n < Hr.length; n++) {
        var r = Hr[n];
        r.blockedOn === e && (r.blockedOn = null);
      }
    }
    for (
      Mt !== null && bn(Mt, e),
        Ft !== null && bn(Ft, e),
        It !== null && bn(It, e),
        Jn.forEach(t),
        Zn.forEach(t),
        n = 0;
      n < jt.length;
      n++
    )
      ((r = jt[n]), r.blockedOn === e && (r.blockedOn = null));
    for (; 0 < jt.length && ((n = jt[0]), n.blockedOn === null);)
      (Ui(n), n.blockedOn === null && jt.shift());
  }
  var yn = ue.ReactCurrentBatchConfig,
    Vr = !0;
  function bc(e, t, n, r) {
    var l = oe,
      o = yn.transition;
    yn.transition = null;
    try {
      ((oe = 1), mo(e, t, n, r));
    } finally {
      ((oe = l), (yn.transition = o));
    }
  }
  function ef(e, t, n, r) {
    var l = oe,
      o = yn.transition;
    yn.transition = null;
    try {
      ((oe = 4), mo(e, t, n, r));
    } finally {
      ((oe = l), (yn.transition = o));
    }
  }
  function mo(e, t, n, r) {
    if (Vr) {
      var l = vo(e, t, n, r);
      if (l === null) (Do(e, t, r, Qr, n), $i(e, r));
      else if (Zc(l, e, t, n, r)) r.stopPropagation();
      else if (($i(e, r), t & 4 && -1 < Jc.indexOf(e))) {
        for (; l !== null;) {
          var o = dr(l);
          if (
            (o !== null && Mi(o),
            (o = vo(e, t, n, r)),
            o === null && Do(e, t, r, Qr, n),
            o === l)
          )
            break;
          l = o;
        }
        l !== null && r.stopPropagation();
      } else Do(e, t, r, null, n);
    }
  }
  var Qr = null;
  function vo(e, t, n, r) {
    if (((Qr = null), (e = ro(r)), (e = tn(e)), e !== null))
      if (((t = en(e)), t === null)) e = null;
      else if (((n = t.tag), n === 13)) {
        if (((e = xi(t)), e !== null)) return e;
        e = null;
      } else if (n === 3) {
        if (t.stateNode.current.memoizedState.isDehydrated)
          return t.tag === 3 ? t.stateNode.containerInfo : null;
        e = null;
      } else t !== e && (e = null);
    return ((Qr = e), null);
  }
  function Bi(e) {
    switch (e) {
      case "cancel":
      case "click":
      case "close":
      case "contextmenu":
      case "copy":
      case "cut":
      case "auxclick":
      case "dblclick":
      case "dragend":
      case "dragstart":
      case "drop":
      case "focusin":
      case "focusout":
      case "input":
      case "invalid":
      case "keydown":
      case "keypress":
      case "keyup":
      case "mousedown":
      case "mouseup":
      case "paste":
      case "pause":
      case "play":
      case "pointercancel":
      case "pointerdown":
      case "pointerup":
      case "ratechange":
      case "reset":
      case "resize":
      case "seeked":
      case "submit":
      case "touchcancel":
      case "touchend":
      case "touchstart":
      case "volumechange":
      case "change":
      case "selectionchange":
      case "textInput":
      case "compositionstart":
      case "compositionend":
      case "compositionupdate":
      case "beforeblur":
      case "afterblur":
      case "beforeinput":
      case "blur":
      case "fullscreenchange":
      case "focus":
      case "hashchange":
      case "popstate":
      case "select":
      case "selectstart":
        return 1;
      case "drag":
      case "dragenter":
      case "dragexit":
      case "dragleave":
      case "dragover":
      case "mousemove":
      case "mouseout":
      case "mouseover":
      case "pointermove":
      case "pointerout":
      case "pointerover":
      case "scroll":
      case "toggle":
      case "touchmove":
      case "wheel":
      case "mouseenter":
      case "mouseleave":
      case "pointerenter":
      case "pointerleave":
        return 4;
      case "message":
        switch (Bc()) {
          case ao:
            return 1;
          case Ti:
            return 4;
          case jr:
          case Hc:
            return 16;
          case zi:
            return 536870912;
          default:
            return 16;
        }
      default:
        return 16;
    }
  }
  var $t = null,
    yo = null,
    Kr = null;
  function Hi() {
    if (Kr) return Kr;
    var e,
      t = yo,
      n = t.length,
      r,
      l = "value" in $t ? $t.value : $t.textContent,
      o = l.length;
    for (e = 0; e < n && t[e] === l[e]; e++);
    var i = n - e;
    for (r = 1; r <= i && t[n - r] === l[o - r]; r++);
    return (Kr = l.slice(e, 1 < r ? 1 - r : void 0));
  }
  function Yr(e) {
    var t = e.keyCode;
    return (
      "charCode" in e
        ? ((e = e.charCode), e === 0 && t === 13 && (e = 13))
        : (e = t),
      e === 10 && (e = 13),
      32 <= e || e === 13 ? e : 0
    );
  }
  function Xr() {
    return !0;
  }
  function Wi() {
    return !1;
  }
  function Ge(e) {
    function t(n, r, l, o, i) {
      ((this._reactName = n),
        (this._targetInst = l),
        (this.type = r),
        (this.nativeEvent = o),
        (this.target = i),
        (this.currentTarget = null));
      for (var c in e)
        e.hasOwnProperty(c) && ((n = e[c]), (this[c] = n ? n(o) : o[c]));
      return (
        (this.isDefaultPrevented = (
          o.defaultPrevented != null ? o.defaultPrevented : o.returnValue === !1
        )
          ? Xr
          : Wi),
        (this.isPropagationStopped = Wi),
        this
      );
    }
    return (
      j(t.prototype, {
        preventDefault: function () {
          this.defaultPrevented = !0;
          var n = this.nativeEvent;
          n &&
            (n.preventDefault
              ? n.preventDefault()
              : typeof n.returnValue != "unknown" && (n.returnValue = !1),
            (this.isDefaultPrevented = Xr));
        },
        stopPropagation: function () {
          var n = this.nativeEvent;
          n &&
            (n.stopPropagation
              ? n.stopPropagation()
              : typeof n.cancelBubble != "unknown" && (n.cancelBubble = !0),
            (this.isPropagationStopped = Xr));
        },
        persist: function () {},
        isPersistent: Xr,
      }),
      t
    );
  }
  var gn = {
      eventPhase: 0,
      bubbles: 0,
      cancelable: 0,
      timeStamp: function (e) {
        return e.timeStamp || Date.now();
      },
      defaultPrevented: 0,
      isTrusted: 0,
    },
    go = Ge(gn),
    tr = j({}, gn, { view: 0, detail: 0 }),
    tf = Ge(tr),
    wo,
    So,
    nr,
    Gr = j({}, tr, {
      screenX: 0,
      screenY: 0,
      clientX: 0,
      clientY: 0,
      pageX: 0,
      pageY: 0,
      ctrlKey: 0,
      shiftKey: 0,
      altKey: 0,
      metaKey: 0,
      getModifierState: Eo,
      button: 0,
      buttons: 0,
      relatedTarget: function (e) {
        return e.relatedTarget === void 0
          ? e.fromElement === e.srcElement
            ? e.toElement
            : e.fromElement
          : e.relatedTarget;
      },
      movementX: function (e) {
        return "movementX" in e
          ? e.movementX
          : (e !== nr &&
              (nr && e.type === "mousemove"
                ? ((wo = e.screenX - nr.screenX), (So = e.screenY - nr.screenY))
                : (So = wo = 0),
              (nr = e)),
            wo);
      },
      movementY: function (e) {
        return "movementY" in e ? e.movementY : So;
      },
    }),
    Vi = Ge(Gr),
    nf = j({}, Gr, { dataTransfer: 0 }),
    rf = Ge(nf),
    lf = j({}, tr, { relatedTarget: 0 }),
    ko = Ge(lf),
    of = j({}, gn, { animationName: 0, elapsedTime: 0, pseudoElement: 0 }),
    uf = Ge(of),
    af = j({}, gn, {
      clipboardData: function (e) {
        return "clipboardData" in e ? e.clipboardData : window.clipboardData;
      },
    }),
    sf = Ge(af),
    cf = j({}, gn, { data: 0 }),
    Qi = Ge(cf),
    ff = {
      Esc: "Escape",
      Spacebar: " ",
      Left: "ArrowLeft",
      Up: "ArrowUp",
      Right: "ArrowRight",
      Down: "ArrowDown",
      Del: "Delete",
      Win: "OS",
      Menu: "ContextMenu",
      Apps: "ContextMenu",
      Scroll: "ScrollLock",
      MozPrintableKey: "Unidentified",
    },
    df = {
      8: "Backspace",
      9: "Tab",
      12: "Clear",
      13: "Enter",
      16: "Shift",
      17: "Control",
      18: "Alt",
      19: "Pause",
      20: "CapsLock",
      27: "Escape",
      32: " ",
      33: "PageUp",
      34: "PageDown",
      35: "End",
      36: "Home",
      37: "ArrowLeft",
      38: "ArrowUp",
      39: "ArrowRight",
      40: "ArrowDown",
      45: "Insert",
      46: "Delete",
      112: "F1",
      113: "F2",
      114: "F3",
      115: "F4",
      116: "F5",
      117: "F6",
      118: "F7",
      119: "F8",
      120: "F9",
      121: "F10",
      122: "F11",
      123: "F12",
      144: "NumLock",
      145: "ScrollLock",
      224: "Meta",
    },
    pf = {
      Alt: "altKey",
      Control: "ctrlKey",
      Meta: "metaKey",
      Shift: "shiftKey",
    };
  function hf(e) {
    var t = this.nativeEvent;
    return t.getModifierState
      ? t.getModifierState(e)
      : (e = pf[e])
        ? !!t[e]
        : !1;
  }
  function Eo() {
    return hf;
  }
  var mf = j({}, tr, {
      key: function (e) {
        if (e.key) {
          var t = ff[e.key] || e.key;
          if (t !== "Unidentified") return t;
        }
        return e.type === "keypress"
          ? ((e = Yr(e)), e === 13 ? "Enter" : String.fromCharCode(e))
          : e.type === "keydown" || e.type === "keyup"
            ? df[e.keyCode] || "Unidentified"
            : "";
      },
      code: 0,
      location: 0,
      ctrlKey: 0,
      shiftKey: 0,
      altKey: 0,
      metaKey: 0,
      repeat: 0,
      locale: 0,
      getModifierState: Eo,
      charCode: function (e) {
        return e.type === "keypress" ? Yr(e) : 0;
      },
      keyCode: function (e) {
        return e.type === "keydown" || e.type === "keyup" ? e.keyCode : 0;
      },
      which: function (e) {
        return e.type === "keypress"
          ? Yr(e)
          : e.type === "keydown" || e.type === "keyup"
            ? e.keyCode
            : 0;
      },
    }),
    vf = Ge(mf),
    yf = j({}, Gr, {
      pointerId: 0,
      width: 0,
      height: 0,
      pressure: 0,
      tangentialPressure: 0,
      tiltX: 0,
      tiltY: 0,
      twist: 0,
      pointerType: 0,
      isPrimary: 0,
    }),
    Ki = Ge(yf),
    gf = j({}, tr, {
      touches: 0,
      targetTouches: 0,
      changedTouches: 0,
      altKey: 0,
      metaKey: 0,
      ctrlKey: 0,
      shiftKey: 0,
      getModifierState: Eo,
    }),
    wf = Ge(gf),
    Sf = j({}, gn, { propertyName: 0, elapsedTime: 0, pseudoElement: 0 }),
    kf = Ge(Sf),
    Ef = j({}, Gr, {
      deltaX: function (e) {
        return "deltaX" in e
          ? e.deltaX
          : "wheelDeltaX" in e
            ? -e.wheelDeltaX
            : 0;
      },
      deltaY: function (e) {
        return "deltaY" in e
          ? e.deltaY
          : "wheelDeltaY" in e
            ? -e.wheelDeltaY
            : "wheelDelta" in e
              ? -e.wheelDelta
              : 0;
      },
      deltaZ: 0,
      deltaMode: 0,
    }),
    Cf = Ge(Ef),
    xf = [9, 13, 27, 32],
    Co = E && "CompositionEvent" in window,
    rr = null;
  E && "documentMode" in document && (rr = document.documentMode);
  var _f = E && "TextEvent" in window && !rr,
    Yi = E && (!Co || (rr && 8 < rr && 11 >= rr)),
    Xi = " ",
    Gi = !1;
  function Ji(e, t) {
    switch (e) {
      case "keyup":
        return xf.indexOf(t.keyCode) !== -1;
      case "keydown":
        return t.keyCode !== 229;
      case "keypress":
      case "mousedown":
      case "focusout":
        return !0;
      default:
        return !1;
    }
  }
  function Zi(e) {
    return (
      (e = e.detail),
      typeof e == "object" && "data" in e ? e.data : null
    );
  }
  var wn = !1;
  function Pf(e, t) {
    switch (e) {
      case "compositionend":
        return Zi(t);
      case "keypress":
        return t.which !== 32 ? null : ((Gi = !0), Xi);
      case "textInput":
        return ((e = t.data), e === Xi && Gi ? null : e);
      default:
        return null;
    }
  }
  function Rf(e, t) {
    if (wn)
      return e === "compositionend" || (!Co && Ji(e, t))
        ? ((e = Hi()), (Kr = yo = $t = null), (wn = !1), e)
        : null;
    switch (e) {
      case "paste":
        return null;
      case "keypress":
        if (!(t.ctrlKey || t.altKey || t.metaKey) || (t.ctrlKey && t.altKey)) {
          if (t.char && 1 < t.char.length) return t.char;
          if (t.which) return String.fromCharCode(t.which);
        }
        return null;
      case "compositionend":
        return Yi && t.locale !== "ko" ? null : t.data;
      default:
        return null;
    }
  }
  var Nf = {
    color: !0,
    date: !0,
    datetime: !0,
    "datetime-local": !0,
    email: !0,
    month: !0,
    number: !0,
    password: !0,
    range: !0,
    search: !0,
    tel: !0,
    text: !0,
    time: !0,
    url: !0,
    week: !0,
  };
  function qi(e) {
    var t = e && e.nodeName && e.nodeName.toLowerCase();
    return t === "input" ? !!Nf[e.type] : t === "textarea";
  }
  function bi(e, t, n, r) {
    (wi(r),
      (t = el(t, "onChange")),
      0 < t.length &&
        ((n = new go("onChange", "change", null, n, r)),
        e.push({ event: n, listeners: t })));
  }
  var lr = null,
    or = null;
  function Lf(e) {
    ya(e, 0);
  }
  function Jr(e) {
    var t = xn(e);
    if (ii(t)) return e;
  }
  function Tf(e, t) {
    if (e === "change") return t;
  }
  var ea = !1;
  if (E) {
    var xo;
    if (E) {
      var _o = "oninput" in document;
      if (!_o) {
        var ta = document.createElement("div");
        (ta.setAttribute("oninput", "return;"),
          (_o = typeof ta.oninput == "function"));
      }
      xo = _o;
    } else xo = !1;
    ea = xo && (!document.documentMode || 9 < document.documentMode);
  }
  function na() {
    lr && (lr.detachEvent("onpropertychange", ra), (or = lr = null));
  }
  function ra(e) {
    if (e.propertyName === "value" && Jr(or)) {
      var t = [];
      (bi(t, or, e, ro(e)), Ci(Lf, t));
    }
  }
  function zf(e, t, n) {
    e === "focusin"
      ? (na(), (lr = t), (or = n), lr.attachEvent("onpropertychange", ra))
      : e === "focusout" && na();
  }
  function Of(e) {
    if (e === "selectionchange" || e === "keyup" || e === "keydown")
      return Jr(or);
  }
  function Df(e, t) {
    if (e === "click") return Jr(t);
  }
  function Mf(e, t) {
    if (e === "input" || e === "change") return Jr(t);
  }
  function Ff(e, t) {
    return (e === t && (e !== 0 || 1 / e === 1 / t)) || (e !== e && t !== t);
  }
  var it = typeof Object.is == "function" ? Object.is : Ff;
  function ur(e, t) {
    if (it(e, t)) return !0;
    if (
      typeof e != "object" ||
      e === null ||
      typeof t != "object" ||
      t === null
    )
      return !1;
    var n = Object.keys(e),
      r = Object.keys(t);
    if (n.length !== r.length) return !1;
    for (r = 0; r < n.length; r++) {
      var l = n[r];
      if (!k.call(t, l) || !it(e[l], t[l])) return !1;
    }
    return !0;
  }
  function la(e) {
    for (; e && e.firstChild;) e = e.firstChild;
    return e;
  }
  function oa(e, t) {
    var n = la(e);
    e = 0;
    for (var r; n;) {
      if (n.nodeType === 3) {
        if (((r = e + n.textContent.length), e <= t && r >= t))
          return { node: n, offset: t - e };
        e = r;
      }
      e: {
        for (; n;) {
          if (n.nextSibling) {
            n = n.nextSibling;
            break e;
          }
          n = n.parentNode;
        }
        n = void 0;
      }
      n = la(n);
    }
  }
  function ua(e, t) {
    return e && t
      ? e === t
        ? !0
        : e && e.nodeType === 3
          ? !1
          : t && t.nodeType === 3
            ? ua(e, t.parentNode)
            : "contains" in e
              ? e.contains(t)
              : e.compareDocumentPosition
                ? !!(e.compareDocumentPosition(t) & 16)
                : !1
      : !1;
  }
  function ia() {
    for (var e = window, t = Dr(); t instanceof e.HTMLIFrameElement;) {
      try {
        var n = typeof t.contentWindow.location.href == "string";
      } catch {
        n = !1;
      }
      if (n) e = t.contentWindow;
      else break;
      t = Dr(e.document);
    }
    return t;
  }
  function Po(e) {
    var t = e && e.nodeName && e.nodeName.toLowerCase();
    return (
      t &&
      ((t === "input" &&
        (e.type === "text" ||
          e.type === "search" ||
          e.type === "tel" ||
          e.type === "url" ||
          e.type === "password")) ||
        t === "textarea" ||
        e.contentEditable === "true")
    );
  }
  function If(e) {
    var t = ia(),
      n = e.focusedElem,
      r = e.selectionRange;
    if (
      t !== n &&
      n &&
      n.ownerDocument &&
      ua(n.ownerDocument.documentElement, n)
    ) {
      if (r !== null && Po(n)) {
        if (
          ((t = r.start),
          (e = r.end),
          e === void 0 && (e = t),
          "selectionStart" in n)
        )
          ((n.selectionStart = t),
            (n.selectionEnd = Math.min(e, n.value.length)));
        else if (
          ((e = ((t = n.ownerDocument || document) && t.defaultView) || window),
          e.getSelection)
        ) {
          e = e.getSelection();
          var l = n.textContent.length,
            o = Math.min(r.start, l);
          ((r = r.end === void 0 ? o : Math.min(r.end, l)),
            !e.extend && o > r && ((l = r), (r = o), (o = l)),
            (l = oa(n, o)));
          var i = oa(n, r);
          l &&
            i &&
            (e.rangeCount !== 1 ||
              e.anchorNode !== l.node ||
              e.anchorOffset !== l.offset ||
              e.focusNode !== i.node ||
              e.focusOffset !== i.offset) &&
            ((t = t.createRange()),
            t.setStart(l.node, l.offset),
            e.removeAllRanges(),
            o > r
              ? (e.addRange(t), e.extend(i.node, i.offset))
              : (t.setEnd(i.node, i.offset), e.addRange(t)));
        }
      }
      for (t = [], e = n; (e = e.parentNode);)
        e.nodeType === 1 &&
          t.push({ element: e, left: e.scrollLeft, top: e.scrollTop });
      for (typeof n.focus == "function" && n.focus(), n = 0; n < t.length; n++)
        ((e = t[n]),
          (e.element.scrollLeft = e.left),
          (e.element.scrollTop = e.top));
    }
  }
  var jf = E && "documentMode" in document && 11 >= document.documentMode,
    Sn = null,
    Ro = null,
    ir = null,
    No = !1;
  function aa(e, t, n) {
    var r =
      n.window === n ? n.document : n.nodeType === 9 ? n : n.ownerDocument;
    No ||
      Sn == null ||
      Sn !== Dr(r) ||
      ((r = Sn),
      "selectionStart" in r && Po(r)
        ? (r = { start: r.selectionStart, end: r.selectionEnd })
        : ((r = (
            (r.ownerDocument && r.ownerDocument.defaultView) ||
            window
          ).getSelection()),
          (r = {
            anchorNode: r.anchorNode,
            anchorOffset: r.anchorOffset,
            focusNode: r.focusNode,
            focusOffset: r.focusOffset,
          })),
      (ir && ur(ir, r)) ||
        ((ir = r),
        (r = el(Ro, "onSelect")),
        0 < r.length &&
          ((t = new go("onSelect", "select", null, t, n)),
          e.push({ event: t, listeners: r }),
          (t.target = Sn))));
  }
  function Zr(e, t) {
    var n = {};
    return (
      (n[e.toLowerCase()] = t.toLowerCase()),
      (n["Webkit" + e] = "webkit" + t),
      (n["Moz" + e] = "moz" + t),
      n
    );
  }
  var kn = {
      animationend: Zr("Animation", "AnimationEnd"),
      animationiteration: Zr("Animation", "AnimationIteration"),
      animationstart: Zr("Animation", "AnimationStart"),
      transitionend: Zr("Transition", "TransitionEnd"),
    },
    Lo = {},
    sa = {};
  E &&
    ((sa = document.createElement("div").style),
    "AnimationEvent" in window ||
      (delete kn.animationend.animation,
      delete kn.animationiteration.animation,
      delete kn.animationstart.animation),
    "TransitionEvent" in window || delete kn.transitionend.transition);
  function qr(e) {
    if (Lo[e]) return Lo[e];
    if (!kn[e]) return e;
    var t = kn[e],
      n;
    for (n in t) if (t.hasOwnProperty(n) && n in sa) return (Lo[e] = t[n]);
    return e;
  }
  var ca = qr("animationend"),
    fa = qr("animationiteration"),
    da = qr("animationstart"),
    pa = qr("transitionend"),
    ha = new Map(),
    ma =
      "abort auxClick cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(
        " ",
      );
  function Ut(e, t) {
    (ha.set(e, t), y(t, [e]));
  }
  for (var To = 0; To < ma.length; To++) {
    var zo = ma[To],
      $f = zo.toLowerCase(),
      Uf = zo[0].toUpperCase() + zo.slice(1);
    Ut($f, "on" + Uf);
  }
  (Ut(ca, "onAnimationEnd"),
    Ut(fa, "onAnimationIteration"),
    Ut(da, "onAnimationStart"),
    Ut("dblclick", "onDoubleClick"),
    Ut("focusin", "onFocus"),
    Ut("focusout", "onBlur"),
    Ut(pa, "onTransitionEnd"),
    S("onMouseEnter", ["mouseout", "mouseover"]),
    S("onMouseLeave", ["mouseout", "mouseover"]),
    S("onPointerEnter", ["pointerout", "pointerover"]),
    S("onPointerLeave", ["pointerout", "pointerover"]),
    y(
      "onChange",
      "change click focusin focusout input keydown keyup selectionchange".split(
        " ",
      ),
    ),
    y(
      "onSelect",
      "focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(
        " ",
      ),
    ),
    y("onBeforeInput", ["compositionend", "keypress", "textInput", "paste"]),
    y(
      "onCompositionEnd",
      "compositionend focusout keydown keypress keyup mousedown".split(" "),
    ),
    y(
      "onCompositionStart",
      "compositionstart focusout keydown keypress keyup mousedown".split(" "),
    ),
    y(
      "onCompositionUpdate",
      "compositionupdate focusout keydown keypress keyup mousedown".split(" "),
    ));
  var ar =
      "abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(
        " ",
      ),
    Af = new Set(
      "cancel close invalid load scroll toggle".split(" ").concat(ar),
    );
  function va(e, t, n) {
    var r = e.type || "unknown-event";
    ((e.currentTarget = n), jc(r, t, void 0, e), (e.currentTarget = null));
  }
  function ya(e, t) {
    t = (t & 4) !== 0;
    for (var n = 0; n < e.length; n++) {
      var r = e[n],
        l = r.event;
      r = r.listeners;
      e: {
        var o = void 0;
        if (t)
          for (var i = r.length - 1; 0 <= i; i--) {
            var c = r[i],
              f = c.instance,
              w = c.currentTarget;
            if (((c = c.listener), f !== o && l.isPropagationStopped()))
              break e;
            (va(l, c, w), (o = f));
          }
        else
          for (i = 0; i < r.length; i++) {
            if (
              ((c = r[i]),
              (f = c.instance),
              (w = c.currentTarget),
              (c = c.listener),
              f !== o && l.isPropagationStopped())
            )
              break e;
            (va(l, c, w), (o = f));
          }
      }
    }
    if (Ir) throw ((e = io), (Ir = !1), (io = null), e);
  }
  function se(e, t) {
    var n = t[Uo];
    n === void 0 && (n = t[Uo] = new Set());
    var r = e + "__bubble";
    n.has(r) || (ga(t, e, 2, !1), n.add(r));
  }
  function Oo(e, t, n) {
    var r = 0;
    (t && (r |= 4), ga(n, e, r, t));
  }
  var br = "_reactListening" + Math.random().toString(36).slice(2);
  function sr(e) {
    if (!e[br]) {
      ((e[br] = !0),
        d.forEach(function (n) {
          n !== "selectionchange" && (Af.has(n) || Oo(n, !1, e), Oo(n, !0, e));
        }));
      var t = e.nodeType === 9 ? e : e.ownerDocument;
      t === null || t[br] || ((t[br] = !0), Oo("selectionchange", !1, t));
    }
  }
  function ga(e, t, n, r) {
    switch (Bi(t)) {
      case 1:
        var l = bc;
        break;
      case 4:
        l = ef;
        break;
      default:
        l = mo;
    }
    ((n = l.bind(null, t, n, e)),
      (l = void 0),
      !uo ||
        (t !== "touchstart" && t !== "touchmove" && t !== "wheel") ||
        (l = !0),
      r
        ? l !== void 0
          ? e.addEventListener(t, n, { capture: !0, passive: l })
          : e.addEventListener(t, n, !0)
        : l !== void 0
          ? e.addEventListener(t, n, { passive: l })
          : e.addEventListener(t, n, !1));
  }
  function Do(e, t, n, r, l) {
    var o = r;
    if ((t & 1) === 0 && (t & 2) === 0 && r !== null)
      e: for (;;) {
        if (r === null) return;
        var i = r.tag;
        if (i === 3 || i === 4) {
          var c = r.stateNode.containerInfo;
          if (c === l || (c.nodeType === 8 && c.parentNode === l)) break;
          if (i === 4)
            for (i = r.return; i !== null;) {
              var f = i.tag;
              if (
                (f === 3 || f === 4) &&
                ((f = i.stateNode.containerInfo),
                f === l || (f.nodeType === 8 && f.parentNode === l))
              )
                return;
              i = i.return;
            }
          for (; c !== null;) {
            if (((i = tn(c)), i === null)) return;
            if (((f = i.tag), f === 5 || f === 6)) {
              r = o = i;
              continue e;
            }
            c = c.parentNode;
          }
        }
        r = r.return;
      }
    Ci(function () {
      var w = o,
        N = ro(n),
        L = [];
      e: {
        var P = ha.get(e);
        if (P !== void 0) {
          var M = go,
            $ = e;
          switch (e) {
            case "keypress":
              if (Yr(n) === 0) break e;
            case "keydown":
            case "keyup":
              M = vf;
              break;
            case "focusin":
              (($ = "focus"), (M = ko));
              break;
            case "focusout":
              (($ = "blur"), (M = ko));
              break;
            case "beforeblur":
            case "afterblur":
              M = ko;
              break;
            case "click":
              if (n.button === 2) break e;
            case "auxclick":
            case "dblclick":
            case "mousedown":
            case "mousemove":
            case "mouseup":
            case "mouseout":
            case "mouseover":
            case "contextmenu":
              M = Vi;
              break;
            case "drag":
            case "dragend":
            case "dragenter":
            case "dragexit":
            case "dragleave":
            case "dragover":
            case "dragstart":
            case "drop":
              M = rf;
              break;
            case "touchcancel":
            case "touchend":
            case "touchmove":
            case "touchstart":
              M = wf;
              break;
            case ca:
            case fa:
            case da:
              M = uf;
              break;
            case pa:
              M = kf;
              break;
            case "scroll":
              M = tf;
              break;
            case "wheel":
              M = Cf;
              break;
            case "copy":
            case "cut":
            case "paste":
              M = sf;
              break;
            case "gotpointercapture":
            case "lostpointercapture":
            case "pointercancel":
            case "pointerdown":
            case "pointermove":
            case "pointerout":
            case "pointerover":
            case "pointerup":
              M = Ki;
          }
          var U = (t & 4) !== 0,
            Se = !U && e === "scroll",
            v = U ? (P !== null ? P + "Capture" : null) : P;
          U = [];
          for (var h = w, g; h !== null;) {
            g = h;
            var T = g.stateNode;
            if (
              (g.tag === 5 &&
                T !== null &&
                ((g = T),
                v !== null &&
                  ((T = Qn(h, v)), T != null && U.push(cr(h, T, g)))),
              Se)
            )
              break;
            h = h.return;
          }
          0 < U.length &&
            ((P = new M(P, $, null, n, N)), L.push({ event: P, listeners: U }));
        }
      }
      if ((t & 7) === 0) {
        e: {
          if (
            ((P = e === "mouseover" || e === "pointerover"),
            (M = e === "mouseout" || e === "pointerout"),
            P &&
              n !== no &&
              ($ = n.relatedTarget || n.fromElement) &&
              (tn($) || $[xt]))
          )
            break e;
          if (
            (M || P) &&
            ((P =
              N.window === N
                ? N
                : (P = N.ownerDocument)
                  ? P.defaultView || P.parentWindow
                  : window),
            M
              ? (($ = n.relatedTarget || n.toElement),
                (M = w),
                ($ = $ ? tn($) : null),
                $ !== null &&
                  ((Se = en($)), $ !== Se || ($.tag !== 5 && $.tag !== 6)) &&
                  ($ = null))
              : ((M = null), ($ = w)),
            M !== $)
          ) {
            if (
              ((U = Vi),
              (T = "onMouseLeave"),
              (v = "onMouseEnter"),
              (h = "mouse"),
              (e === "pointerout" || e === "pointerover") &&
                ((U = Ki),
                (T = "onPointerLeave"),
                (v = "onPointerEnter"),
                (h = "pointer")),
              (Se = M == null ? P : xn(M)),
              (g = $ == null ? P : xn($)),
              (P = new U(T, h + "leave", M, n, N)),
              (P.target = Se),
              (P.relatedTarget = g),
              (T = null),
              tn(N) === w &&
                ((U = new U(v, h + "enter", $, n, N)),
                (U.target = g),
                (U.relatedTarget = Se),
                (T = U)),
              (Se = T),
              M && $)
            )
              t: {
                for (U = M, v = $, h = 0, g = U; g; g = En(g)) h++;
                for (g = 0, T = v; T; T = En(T)) g++;
                for (; 0 < h - g;) ((U = En(U)), h--);
                for (; 0 < g - h;) ((v = En(v)), g--);
                for (; h--;) {
                  if (U === v || (v !== null && U === v.alternate)) break t;
                  ((U = En(U)), (v = En(v)));
                }
                U = null;
              }
            else U = null;
            (M !== null && wa(L, P, M, U, !1),
              $ !== null && Se !== null && wa(L, Se, $, U, !0));
          }
        }
        e: {
          if (
            ((P = w ? xn(w) : window),
            (M = P.nodeName && P.nodeName.toLowerCase()),
            M === "select" || (M === "input" && P.type === "file"))
          )
            var B = Tf;
          else if (qi(P))
            if (ea) B = Mf;
            else {
              B = Of;
              var Q = zf;
            }
          else
            (M = P.nodeName) &&
              M.toLowerCase() === "input" &&
              (P.type === "checkbox" || P.type === "radio") &&
              (B = Df);
          if (B && (B = B(e, w))) {
            bi(L, B, n, N);
            break e;
          }
          (Q && Q(e, P, w),
            e === "focusout" &&
              (Q = P._wrapperState) &&
              Q.controlled &&
              P.type === "number" &&
              Zl(P, "number", P.value));
        }
        switch (((Q = w ? xn(w) : window), e)) {
          case "focusin":
            (qi(Q) || Q.contentEditable === "true") &&
              ((Sn = Q), (Ro = w), (ir = null));
            break;
          case "focusout":
            ir = Ro = Sn = null;
            break;
          case "mousedown":
            No = !0;
            break;
          case "contextmenu":
          case "mouseup":
          case "dragend":
            ((No = !1), aa(L, n, N));
            break;
          case "selectionchange":
            if (jf) break;
          case "keydown":
          case "keyup":
            aa(L, n, N);
        }
        var K;
        if (Co)
          e: {
            switch (e) {
              case "compositionstart":
                var G = "onCompositionStart";
                break e;
              case "compositionend":
                G = "onCompositionEnd";
                break e;
              case "compositionupdate":
                G = "onCompositionUpdate";
                break e;
            }
            G = void 0;
          }
        else
          wn
            ? Ji(e, n) && (G = "onCompositionEnd")
            : e === "keydown" &&
              n.keyCode === 229 &&
              (G = "onCompositionStart");
        (G &&
          (Yi &&
            n.locale !== "ko" &&
            (wn || G !== "onCompositionStart"
              ? G === "onCompositionEnd" && wn && (K = Hi())
              : (($t = N),
                (yo = "value" in $t ? $t.value : $t.textContent),
                (wn = !0))),
          (Q = el(w, G)),
          0 < Q.length &&
            ((G = new Qi(G, e, null, n, N)),
            L.push({ event: G, listeners: Q }),
            K ? (G.data = K) : ((K = Zi(n)), K !== null && (G.data = K)))),
          (K = _f ? Pf(e, n) : Rf(e, n)) &&
            ((w = el(w, "onBeforeInput")),
            0 < w.length &&
              ((N = new Qi("onBeforeInput", "beforeinput", null, n, N)),
              L.push({ event: N, listeners: w }),
              (N.data = K))));
      }
      ya(L, t);
    });
  }
  function cr(e, t, n) {
    return { instance: e, listener: t, currentTarget: n };
  }
  function el(e, t) {
    for (var n = t + "Capture", r = []; e !== null;) {
      var l = e,
        o = l.stateNode;
      (l.tag === 5 &&
        o !== null &&
        ((l = o),
        (o = Qn(e, n)),
        o != null && r.unshift(cr(e, o, l)),
        (o = Qn(e, t)),
        o != null && r.push(cr(e, o, l))),
        (e = e.return));
    }
    return r;
  }
  function En(e) {
    if (e === null) return null;
    do e = e.return;
    while (e && e.tag !== 5);
    return e || null;
  }
  function wa(e, t, n, r, l) {
    for (var o = t._reactName, i = []; n !== null && n !== r;) {
      var c = n,
        f = c.alternate,
        w = c.stateNode;
      if (f !== null && f === r) break;
      (c.tag === 5 &&
        w !== null &&
        ((c = w),
        l
          ? ((f = Qn(n, o)), f != null && i.unshift(cr(n, f, c)))
          : l || ((f = Qn(n, o)), f != null && i.push(cr(n, f, c)))),
        (n = n.return));
    }
    i.length !== 0 && e.push({ event: t, listeners: i });
  }
  var Bf = /\r\n?/g,
    Hf = /\u0000|\uFFFD/g;
  function Sa(e) {
    return (typeof e == "string" ? e : "" + e)
      .replace(
        Bf,
        `
`,
      )
      .replace(Hf, "");
  }
  function tl(e, t, n) {
    if (((t = Sa(t)), Sa(e) !== t && n)) throw Error(a(425));
  }
  function nl() {}
  var Mo = null,
    Fo = null;
  function Io(e, t) {
    return (
      e === "textarea" ||
      e === "noscript" ||
      typeof t.children == "string" ||
      typeof t.children == "number" ||
      (typeof t.dangerouslySetInnerHTML == "object" &&
        t.dangerouslySetInnerHTML !== null &&
        t.dangerouslySetInnerHTML.__html != null)
    );
  }
  var jo = typeof setTimeout == "function" ? setTimeout : void 0,
    Wf = typeof clearTimeout == "function" ? clearTimeout : void 0,
    ka = typeof Promise == "function" ? Promise : void 0,
    Vf =
      typeof queueMicrotask == "function"
        ? queueMicrotask
        : typeof ka < "u"
          ? function (e) {
              return ka.resolve(null).then(e).catch(Qf);
            }
          : jo;
  function Qf(e) {
    setTimeout(function () {
      throw e;
    });
  }
  function $o(e, t) {
    var n = t,
      r = 0;
    do {
      var l = n.nextSibling;
      if ((e.removeChild(n), l && l.nodeType === 8))
        if (((n = l.data), n === "/$")) {
          if (r === 0) {
            (e.removeChild(l), er(t));
            return;
          }
          r--;
        } else (n !== "$" && n !== "$?" && n !== "$!") || r++;
      n = l;
    } while (n);
    er(t);
  }
  function At(e) {
    for (; e != null; e = e.nextSibling) {
      var t = e.nodeType;
      if (t === 1 || t === 3) break;
      if (t === 8) {
        if (((t = e.data), t === "$" || t === "$!" || t === "$?")) break;
        if (t === "/$") return null;
      }
    }
    return e;
  }
  function Ea(e) {
    e = e.previousSibling;
    for (var t = 0; e;) {
      if (e.nodeType === 8) {
        var n = e.data;
        if (n === "$" || n === "$!" || n === "$?") {
          if (t === 0) return e;
          t--;
        } else n === "/$" && t++;
      }
      e = e.previousSibling;
    }
    return null;
  }
  var Cn = Math.random().toString(36).slice(2),
    St = "__reactFiber$" + Cn,
    fr = "__reactProps$" + Cn,
    xt = "__reactContainer$" + Cn,
    Uo = "__reactEvents$" + Cn,
    Kf = "__reactListeners$" + Cn,
    Yf = "__reactHandles$" + Cn;
  function tn(e) {
    var t = e[St];
    if (t) return t;
    for (var n = e.parentNode; n;) {
      if ((t = n[xt] || n[St])) {
        if (
          ((n = t.alternate),
          t.child !== null || (n !== null && n.child !== null))
        )
          for (e = Ea(e); e !== null;) {
            if ((n = e[St])) return n;
            e = Ea(e);
          }
        return t;
      }
      ((e = n), (n = e.parentNode));
    }
    return null;
  }
  function dr(e) {
    return (
      (e = e[St] || e[xt]),
      !e || (e.tag !== 5 && e.tag !== 6 && e.tag !== 13 && e.tag !== 3)
        ? null
        : e
    );
  }
  function xn(e) {
    if (e.tag === 5 || e.tag === 6) return e.stateNode;
    throw Error(a(33));
  }
  function rl(e) {
    return e[fr] || null;
  }
  var Ao = [],
    _n = -1;
  function Bt(e) {
    return { current: e };
  }
  function ce(e) {
    0 > _n || ((e.current = Ao[_n]), (Ao[_n] = null), _n--);
  }
  function ae(e, t) {
    (_n++, (Ao[_n] = e.current), (e.current = t));
  }
  var Ht = {},
    Me = Bt(Ht),
    Be = Bt(!1),
    nn = Ht;
  function Pn(e, t) {
    var n = e.type.contextTypes;
    if (!n) return Ht;
    var r = e.stateNode;
    if (r && r.__reactInternalMemoizedUnmaskedChildContext === t)
      return r.__reactInternalMemoizedMaskedChildContext;
    var l = {},
      o;
    for (o in n) l[o] = t[o];
    return (
      r &&
        ((e = e.stateNode),
        (e.__reactInternalMemoizedUnmaskedChildContext = t),
        (e.__reactInternalMemoizedMaskedChildContext = l)),
      l
    );
  }
  function He(e) {
    return ((e = e.childContextTypes), e != null);
  }
  function ll() {
    (ce(Be), ce(Me));
  }
  function Ca(e, t, n) {
    if (Me.current !== Ht) throw Error(a(168));
    (ae(Me, t), ae(Be, n));
  }
  function xa(e, t, n) {
    var r = e.stateNode;
    if (((t = t.childContextTypes), typeof r.getChildContext != "function"))
      return n;
    r = r.getChildContext();
    for (var l in r) if (!(l in t)) throw Error(a(108, ie(e) || "Unknown", l));
    return j({}, n, r);
  }
  function ol(e) {
    return (
      (e =
        ((e = e.stateNode) && e.__reactInternalMemoizedMergedChildContext) ||
        Ht),
      (nn = Me.current),
      ae(Me, e),
      ae(Be, Be.current),
      !0
    );
  }
  function _a(e, t, n) {
    var r = e.stateNode;
    if (!r) throw Error(a(169));
    (n
      ? ((e = xa(e, t, nn)),
        (r.__reactInternalMemoizedMergedChildContext = e),
        ce(Be),
        ce(Me),
        ae(Me, e))
      : ce(Be),
      ae(Be, n));
  }
  var _t = null,
    ul = !1,
    Bo = !1;
  function Pa(e) {
    _t === null ? (_t = [e]) : _t.push(e);
  }
  function Xf(e) {
    ((ul = !0), Pa(e));
  }
  function Wt() {
    if (!Bo && _t !== null) {
      Bo = !0;
      var e = 0,
        t = oe;
      try {
        var n = _t;
        for (oe = 1; e < n.length; e++) {
          var r = n[e];
          do r = r(!0);
          while (r !== null);
        }
        ((_t = null), (ul = !1));
      } catch (l) {
        throw (_t !== null && (_t = _t.slice(e + 1)), Ni(ao, Wt), l);
      } finally {
        ((oe = t), (Bo = !1));
      }
    }
    return null;
  }
  var Rn = [],
    Nn = 0,
    il = null,
    al = 0,
    be = [],
    et = 0,
    rn = null,
    Pt = 1,
    Rt = "";
  function ln(e, t) {
    ((Rn[Nn++] = al), (Rn[Nn++] = il), (il = e), (al = t));
  }
  function Ra(e, t, n) {
    ((be[et++] = Pt), (be[et++] = Rt), (be[et++] = rn), (rn = e));
    var r = Pt;
    e = Rt;
    var l = 32 - ut(r) - 1;
    ((r &= ~(1 << l)), (n += 1));
    var o = 32 - ut(t) + l;
    if (30 < o) {
      var i = l - (l % 5);
      ((o = (r & ((1 << i) - 1)).toString(32)),
        (r >>= i),
        (l -= i),
        (Pt = (1 << (32 - ut(t) + l)) | (n << l) | r),
        (Rt = o + e));
    } else ((Pt = (1 << o) | (n << l) | r), (Rt = e));
  }
  function Ho(e) {
    e.return !== null && (ln(e, 1), Ra(e, 1, 0));
  }
  function Wo(e) {
    for (; e === il;)
      ((il = Rn[--Nn]), (Rn[Nn] = null), (al = Rn[--Nn]), (Rn[Nn] = null));
    for (; e === rn;)
      ((rn = be[--et]),
        (be[et] = null),
        (Rt = be[--et]),
        (be[et] = null),
        (Pt = be[--et]),
        (be[et] = null));
  }
  var Je = null,
    Ze = null,
    de = !1,
    at = null;
  function Na(e, t) {
    var n = lt(5, null, null, 0);
    ((n.elementType = "DELETED"),
      (n.stateNode = t),
      (n.return = e),
      (t = e.deletions),
      t === null ? ((e.deletions = [n]), (e.flags |= 16)) : t.push(n));
  }
  function La(e, t) {
    switch (e.tag) {
      case 5:
        var n = e.type;
        return (
          (t =
            t.nodeType !== 1 || n.toLowerCase() !== t.nodeName.toLowerCase()
              ? null
              : t),
          t !== null
            ? ((e.stateNode = t), (Je = e), (Ze = At(t.firstChild)), !0)
            : !1
        );
      case 6:
        return (
          (t = e.pendingProps === "" || t.nodeType !== 3 ? null : t),
          t !== null ? ((e.stateNode = t), (Je = e), (Ze = null), !0) : !1
        );
      case 13:
        return (
          (t = t.nodeType !== 8 ? null : t),
          t !== null
            ? ((n = rn !== null ? { id: Pt, overflow: Rt } : null),
              (e.memoizedState = {
                dehydrated: t,
                treeContext: n,
                retryLane: 1073741824,
              }),
              (n = lt(18, null, null, 0)),
              (n.stateNode = t),
              (n.return = e),
              (e.child = n),
              (Je = e),
              (Ze = null),
              !0)
            : !1
        );
      default:
        return !1;
    }
  }
  function Vo(e) {
    return (e.mode & 1) !== 0 && (e.flags & 128) === 0;
  }
  function Qo(e) {
    if (de) {
      var t = Ze;
      if (t) {
        var n = t;
        if (!La(e, t)) {
          if (Vo(e)) throw Error(a(418));
          t = At(n.nextSibling);
          var r = Je;
          t && La(e, t)
            ? Na(r, n)
            : ((e.flags = (e.flags & -4097) | 2), (de = !1), (Je = e));
        }
      } else {
        if (Vo(e)) throw Error(a(418));
        ((e.flags = (e.flags & -4097) | 2), (de = !1), (Je = e));
      }
    }
  }
  function Ta(e) {
    for (
      e = e.return;
      e !== null && e.tag !== 5 && e.tag !== 3 && e.tag !== 13;
    )
      e = e.return;
    Je = e;
  }
  function sl(e) {
    if (e !== Je) return !1;
    if (!de) return (Ta(e), (de = !0), !1);
    var t;
    if (
      ((t = e.tag !== 3) &&
        !(t = e.tag !== 5) &&
        ((t = e.type),
        (t = t !== "head" && t !== "body" && !Io(e.type, e.memoizedProps))),
      t && (t = Ze))
    ) {
      if (Vo(e)) throw (za(), Error(a(418)));
      for (; t;) (Na(e, t), (t = At(t.nextSibling)));
    }
    if ((Ta(e), e.tag === 13)) {
      if (((e = e.memoizedState), (e = e !== null ? e.dehydrated : null), !e))
        throw Error(a(317));
      e: {
        for (e = e.nextSibling, t = 0; e;) {
          if (e.nodeType === 8) {
            var n = e.data;
            if (n === "/$") {
              if (t === 0) {
                Ze = At(e.nextSibling);
                break e;
              }
              t--;
            } else (n !== "$" && n !== "$!" && n !== "$?") || t++;
          }
          e = e.nextSibling;
        }
        Ze = null;
      }
    } else Ze = Je ? At(e.stateNode.nextSibling) : null;
    return !0;
  }
  function za() {
    for (var e = Ze; e;) e = At(e.nextSibling);
  }
  function Ln() {
    ((Ze = Je = null), (de = !1));
  }
  function Ko(e) {
    at === null ? (at = [e]) : at.push(e);
  }
  var Gf = ue.ReactCurrentBatchConfig;
  function pr(e, t, n) {
    if (
      ((e = n.ref),
      e !== null && typeof e != "function" && typeof e != "object")
    ) {
      if (n._owner) {
        if (((n = n._owner), n)) {
          if (n.tag !== 1) throw Error(a(309));
          var r = n.stateNode;
        }
        if (!r) throw Error(a(147, e));
        var l = r,
          o = "" + e;
        return t !== null &&
          t.ref !== null &&
          typeof t.ref == "function" &&
          t.ref._stringRef === o
          ? t.ref
          : ((t = function (i) {
              var c = l.refs;
              i === null ? delete c[o] : (c[o] = i);
            }),
            (t._stringRef = o),
            t);
      }
      if (typeof e != "string") throw Error(a(284));
      if (!n._owner) throw Error(a(290, e));
    }
    return e;
  }
  function cl(e, t) {
    throw (
      (e = Object.prototype.toString.call(t)),
      Error(
        a(
          31,
          e === "[object Object]"
            ? "object with keys {" + Object.keys(t).join(", ") + "}"
            : e,
        ),
      )
    );
  }
  function Oa(e) {
    var t = e._init;
    return t(e._payload);
  }
  function Da(e) {
    function t(v, h) {
      if (e) {
        var g = v.deletions;
        g === null ? ((v.deletions = [h]), (v.flags |= 16)) : g.push(h);
      }
    }
    function n(v, h) {
      if (!e) return null;
      for (; h !== null;) (t(v, h), (h = h.sibling));
      return null;
    }
    function r(v, h) {
      for (v = new Map(); h !== null;)
        (h.key !== null ? v.set(h.key, h) : v.set(h.index, h), (h = h.sibling));
      return v;
    }
    function l(v, h) {
      return ((v = Zt(v, h)), (v.index = 0), (v.sibling = null), v);
    }
    function o(v, h, g) {
      return (
        (v.index = g),
        e
          ? ((g = v.alternate),
            g !== null
              ? ((g = g.index), g < h ? ((v.flags |= 2), h) : g)
              : ((v.flags |= 2), h))
          : ((v.flags |= 1048576), h)
      );
    }
    function i(v) {
      return (e && v.alternate === null && (v.flags |= 2), v);
    }
    function c(v, h, g, T) {
      return h === null || h.tag !== 6
        ? ((h = ju(g, v.mode, T)), (h.return = v), h)
        : ((h = l(h, g)), (h.return = v), h);
    }
    function f(v, h, g, T) {
      var B = g.type;
      return B === Ee
        ? N(v, h, g.props.children, T, g.key)
        : h !== null &&
            (h.elementType === B ||
              (typeof B == "object" &&
                B !== null &&
                B.$$typeof === Ae &&
                Oa(B) === h.type))
          ? ((T = l(h, g.props)), (T.ref = pr(v, h, g)), (T.return = v), T)
          : ((T = Ml(g.type, g.key, g.props, null, v.mode, T)),
            (T.ref = pr(v, h, g)),
            (T.return = v),
            T);
    }
    function w(v, h, g, T) {
      return h === null ||
        h.tag !== 4 ||
        h.stateNode.containerInfo !== g.containerInfo ||
        h.stateNode.implementation !== g.implementation
        ? ((h = $u(g, v.mode, T)), (h.return = v), h)
        : ((h = l(h, g.children || [])), (h.return = v), h);
    }
    function N(v, h, g, T, B) {
      return h === null || h.tag !== 7
        ? ((h = pn(g, v.mode, T, B)), (h.return = v), h)
        : ((h = l(h, g)), (h.return = v), h);
    }
    function L(v, h, g) {
      if ((typeof h == "string" && h !== "") || typeof h == "number")
        return ((h = ju("" + h, v.mode, g)), (h.return = v), h);
      if (typeof h == "object" && h !== null) {
        switch (h.$$typeof) {
          case he:
            return (
              (g = Ml(h.type, h.key, h.props, null, v.mode, g)),
              (g.ref = pr(v, null, h)),
              (g.return = v),
              g
            );
          case ke:
            return ((h = $u(h, v.mode, g)), (h.return = v), h);
          case Ae:
            var T = h._init;
            return L(v, T(h._payload), g);
        }
        if (Hn(h) || X(h))
          return ((h = pn(h, v.mode, g, null)), (h.return = v), h);
        cl(v, h);
      }
      return null;
    }
    function P(v, h, g, T) {
      var B = h !== null ? h.key : null;
      if ((typeof g == "string" && g !== "") || typeof g == "number")
        return B !== null ? null : c(v, h, "" + g, T);
      if (typeof g == "object" && g !== null) {
        switch (g.$$typeof) {
          case he:
            return g.key === B ? f(v, h, g, T) : null;
          case ke:
            return g.key === B ? w(v, h, g, T) : null;
          case Ae:
            return ((B = g._init), P(v, h, B(g._payload), T));
        }
        if (Hn(g) || X(g)) return B !== null ? null : N(v, h, g, T, null);
        cl(v, g);
      }
      return null;
    }
    function M(v, h, g, T, B) {
      if ((typeof T == "string" && T !== "") || typeof T == "number")
        return ((v = v.get(g) || null), c(h, v, "" + T, B));
      if (typeof T == "object" && T !== null) {
        switch (T.$$typeof) {
          case he:
            return (
              (v = v.get(T.key === null ? g : T.key) || null),
              f(h, v, T, B)
            );
          case ke:
            return (
              (v = v.get(T.key === null ? g : T.key) || null),
              w(h, v, T, B)
            );
          case Ae:
            var Q = T._init;
            return M(v, h, g, Q(T._payload), B);
        }
        if (Hn(T) || X(T)) return ((v = v.get(g) || null), N(h, v, T, B, null));
        cl(h, T);
      }
      return null;
    }
    function $(v, h, g, T) {
      for (
        var B = null, Q = null, K = h, G = (h = 0), Le = null;
        K !== null && G < g.length;
        G++
      ) {
        K.index > G ? ((Le = K), (K = null)) : (Le = K.sibling);
        var re = P(v, K, g[G], T);
        if (re === null) {
          K === null && (K = Le);
          break;
        }
        (e && K && re.alternate === null && t(v, K),
          (h = o(re, h, G)),
          Q === null ? (B = re) : (Q.sibling = re),
          (Q = re),
          (K = Le));
      }
      if (G === g.length) return (n(v, K), de && ln(v, G), B);
      if (K === null) {
        for (; G < g.length; G++)
          ((K = L(v, g[G], T)),
            K !== null &&
              ((h = o(K, h, G)),
              Q === null ? (B = K) : (Q.sibling = K),
              (Q = K)));
        return (de && ln(v, G), B);
      }
      for (K = r(v, K); G < g.length; G++)
        ((Le = M(K, v, G, g[G], T)),
          Le !== null &&
            (e &&
              Le.alternate !== null &&
              K.delete(Le.key === null ? G : Le.key),
            (h = o(Le, h, G)),
            Q === null ? (B = Le) : (Q.sibling = Le),
            (Q = Le)));
      return (
        e &&
          K.forEach(function (qt) {
            return t(v, qt);
          }),
        de && ln(v, G),
        B
      );
    }
    function U(v, h, g, T) {
      var B = X(g);
      if (typeof B != "function") throw Error(a(150));
      if (((g = B.call(g)), g == null)) throw Error(a(151));
      for (
        var Q = (B = null), K = h, G = (h = 0), Le = null, re = g.next();
        K !== null && !re.done;
        G++, re = g.next()
      ) {
        K.index > G ? ((Le = K), (K = null)) : (Le = K.sibling);
        var qt = P(v, K, re.value, T);
        if (qt === null) {
          K === null && (K = Le);
          break;
        }
        (e && K && qt.alternate === null && t(v, K),
          (h = o(qt, h, G)),
          Q === null ? (B = qt) : (Q.sibling = qt),
          (Q = qt),
          (K = Le));
      }
      if (re.done) return (n(v, K), de && ln(v, G), B);
      if (K === null) {
        for (; !re.done; G++, re = g.next())
          ((re = L(v, re.value, T)),
            re !== null &&
              ((h = o(re, h, G)),
              Q === null ? (B = re) : (Q.sibling = re),
              (Q = re)));
        return (de && ln(v, G), B);
      }
      for (K = r(v, K); !re.done; G++, re = g.next())
        ((re = M(K, v, G, re.value, T)),
          re !== null &&
            (e &&
              re.alternate !== null &&
              K.delete(re.key === null ? G : re.key),
            (h = o(re, h, G)),
            Q === null ? (B = re) : (Q.sibling = re),
            (Q = re)));
      return (
        e &&
          K.forEach(function (Nd) {
            return t(v, Nd);
          }),
        de && ln(v, G),
        B
      );
    }
    function Se(v, h, g, T) {
      if (
        (typeof g == "object" &&
          g !== null &&
          g.type === Ee &&
          g.key === null &&
          (g = g.props.children),
        typeof g == "object" && g !== null)
      ) {
        switch (g.$$typeof) {
          case he:
            e: {
              for (var B = g.key, Q = h; Q !== null;) {
                if (Q.key === B) {
                  if (((B = g.type), B === Ee)) {
                    if (Q.tag === 7) {
                      (n(v, Q.sibling),
                        (h = l(Q, g.props.children)),
                        (h.return = v),
                        (v = h));
                      break e;
                    }
                  } else if (
                    Q.elementType === B ||
                    (typeof B == "object" &&
                      B !== null &&
                      B.$$typeof === Ae &&
                      Oa(B) === Q.type)
                  ) {
                    (n(v, Q.sibling),
                      (h = l(Q, g.props)),
                      (h.ref = pr(v, Q, g)),
                      (h.return = v),
                      (v = h));
                    break e;
                  }
                  n(v, Q);
                  break;
                } else t(v, Q);
                Q = Q.sibling;
              }
              g.type === Ee
                ? ((h = pn(g.props.children, v.mode, T, g.key)),
                  (h.return = v),
                  (v = h))
                : ((T = Ml(g.type, g.key, g.props, null, v.mode, T)),
                  (T.ref = pr(v, h, g)),
                  (T.return = v),
                  (v = T));
            }
            return i(v);
          case ke:
            e: {
              for (Q = g.key; h !== null;) {
                if (h.key === Q)
                  if (
                    h.tag === 4 &&
                    h.stateNode.containerInfo === g.containerInfo &&
                    h.stateNode.implementation === g.implementation
                  ) {
                    (n(v, h.sibling),
                      (h = l(h, g.children || [])),
                      (h.return = v),
                      (v = h));
                    break e;
                  } else {
                    n(v, h);
                    break;
                  }
                else t(v, h);
                h = h.sibling;
              }
              ((h = $u(g, v.mode, T)), (h.return = v), (v = h));
            }
            return i(v);
          case Ae:
            return ((Q = g._init), Se(v, h, Q(g._payload), T));
        }
        if (Hn(g)) return $(v, h, g, T);
        if (X(g)) return U(v, h, g, T);
        cl(v, g);
      }
      return (typeof g == "string" && g !== "") || typeof g == "number"
        ? ((g = "" + g),
          h !== null && h.tag === 6
            ? (n(v, h.sibling), (h = l(h, g)), (h.return = v), (v = h))
            : (n(v, h), (h = ju(g, v.mode, T)), (h.return = v), (v = h)),
          i(v))
        : n(v, h);
    }
    return Se;
  }
  var Tn = Da(!0),
    Ma = Da(!1),
    fl = Bt(null),
    dl = null,
    zn = null,
    Yo = null;
  function Xo() {
    Yo = zn = dl = null;
  }
  function Go(e) {
    var t = fl.current;
    (ce(fl), (e._currentValue = t));
  }
  function Jo(e, t, n) {
    for (; e !== null;) {
      var r = e.alternate;
      if (
        ((e.childLanes & t) !== t
          ? ((e.childLanes |= t), r !== null && (r.childLanes |= t))
          : r !== null && (r.childLanes & t) !== t && (r.childLanes |= t),
        e === n)
      )
        break;
      e = e.return;
    }
  }
  function On(e, t) {
    ((dl = e),
      (Yo = zn = null),
      (e = e.dependencies),
      e !== null &&
        e.firstContext !== null &&
        ((e.lanes & t) !== 0 && (We = !0), (e.firstContext = null)));
  }
  function tt(e) {
    var t = e._currentValue;
    if (Yo !== e)
      if (((e = { context: e, memoizedValue: t, next: null }), zn === null)) {
        if (dl === null) throw Error(a(308));
        ((zn = e), (dl.dependencies = { lanes: 0, firstContext: e }));
      } else zn = zn.next = e;
    return t;
  }
  var on = null;
  function Zo(e) {
    on === null ? (on = [e]) : on.push(e);
  }
  function Fa(e, t, n, r) {
    var l = t.interleaved;
    return (
      l === null ? ((n.next = n), Zo(t)) : ((n.next = l.next), (l.next = n)),
      (t.interleaved = n),
      Nt(e, r)
    );
  }
  function Nt(e, t) {
    e.lanes |= t;
    var n = e.alternate;
    for (n !== null && (n.lanes |= t), n = e, e = e.return; e !== null;)
      ((e.childLanes |= t),
        (n = e.alternate),
        n !== null && (n.childLanes |= t),
        (n = e),
        (e = e.return));
    return n.tag === 3 ? n.stateNode : null;
  }
  var Vt = !1;
  function qo(e) {
    e.updateQueue = {
      baseState: e.memoizedState,
      firstBaseUpdate: null,
      lastBaseUpdate: null,
      shared: { pending: null, interleaved: null, lanes: 0 },
      effects: null,
    };
  }
  function Ia(e, t) {
    ((e = e.updateQueue),
      t.updateQueue === e &&
        (t.updateQueue = {
          baseState: e.baseState,
          firstBaseUpdate: e.firstBaseUpdate,
          lastBaseUpdate: e.lastBaseUpdate,
          shared: e.shared,
          effects: e.effects,
        }));
  }
  function Lt(e, t) {
    return {
      eventTime: e,
      lane: t,
      tag: 0,
      payload: null,
      callback: null,
      next: null,
    };
  }
  function Qt(e, t, n) {
    var r = e.updateQueue;
    if (r === null) return null;
    if (((r = r.shared), (ee & 2) !== 0)) {
      var l = r.pending;
      return (
        l === null ? (t.next = t) : ((t.next = l.next), (l.next = t)),
        (r.pending = t),
        Nt(e, n)
      );
    }
    return (
      (l = r.interleaved),
      l === null ? ((t.next = t), Zo(r)) : ((t.next = l.next), (l.next = t)),
      (r.interleaved = t),
      Nt(e, n)
    );
  }
  function pl(e, t, n) {
    if (
      ((t = t.updateQueue), t !== null && ((t = t.shared), (n & 4194240) !== 0))
    ) {
      var r = t.lanes;
      ((r &= e.pendingLanes), (n |= r), (t.lanes = n), fo(e, n));
    }
  }
  function ja(e, t) {
    var n = e.updateQueue,
      r = e.alternate;
    if (r !== null && ((r = r.updateQueue), n === r)) {
      var l = null,
        o = null;
      if (((n = n.firstBaseUpdate), n !== null)) {
        do {
          var i = {
            eventTime: n.eventTime,
            lane: n.lane,
            tag: n.tag,
            payload: n.payload,
            callback: n.callback,
            next: null,
          };
          (o === null ? (l = o = i) : (o = o.next = i), (n = n.next));
        } while (n !== null);
        o === null ? (l = o = t) : (o = o.next = t);
      } else l = o = t;
      ((n = {
        baseState: r.baseState,
        firstBaseUpdate: l,
        lastBaseUpdate: o,
        shared: r.shared,
        effects: r.effects,
      }),
        (e.updateQueue = n));
      return;
    }
    ((e = n.lastBaseUpdate),
      e === null ? (n.firstBaseUpdate = t) : (e.next = t),
      (n.lastBaseUpdate = t));
  }
  function hl(e, t, n, r) {
    var l = e.updateQueue;
    Vt = !1;
    var o = l.firstBaseUpdate,
      i = l.lastBaseUpdate,
      c = l.shared.pending;
    if (c !== null) {
      l.shared.pending = null;
      var f = c,
        w = f.next;
      ((f.next = null), i === null ? (o = w) : (i.next = w), (i = f));
      var N = e.alternate;
      N !== null &&
        ((N = N.updateQueue),
        (c = N.lastBaseUpdate),
        c !== i &&
          (c === null ? (N.firstBaseUpdate = w) : (c.next = w),
          (N.lastBaseUpdate = f)));
    }
    if (o !== null) {
      var L = l.baseState;
      ((i = 0), (N = w = f = null), (c = o));
      do {
        var P = c.lane,
          M = c.eventTime;
        if ((r & P) === P) {
          N !== null &&
            (N = N.next =
              {
                eventTime: M,
                lane: 0,
                tag: c.tag,
                payload: c.payload,
                callback: c.callback,
                next: null,
              });
          e: {
            var $ = e,
              U = c;
            switch (((P = t), (M = n), U.tag)) {
              case 1:
                if ((($ = U.payload), typeof $ == "function")) {
                  L = $.call(M, L, P);
                  break e;
                }
                L = $;
                break e;
              case 3:
                $.flags = ($.flags & -65537) | 128;
              case 0:
                if (
                  (($ = U.payload),
                  (P = typeof $ == "function" ? $.call(M, L, P) : $),
                  P == null)
                )
                  break e;
                L = j({}, L, P);
                break e;
              case 2:
                Vt = !0;
            }
          }
          c.callback !== null &&
            c.lane !== 0 &&
            ((e.flags |= 64),
            (P = l.effects),
            P === null ? (l.effects = [c]) : P.push(c));
        } else
          ((M = {
            eventTime: M,
            lane: P,
            tag: c.tag,
            payload: c.payload,
            callback: c.callback,
            next: null,
          }),
            N === null ? ((w = N = M), (f = L)) : (N = N.next = M),
            (i |= P));
        if (((c = c.next), c === null)) {
          if (((c = l.shared.pending), c === null)) break;
          ((P = c),
            (c = P.next),
            (P.next = null),
            (l.lastBaseUpdate = P),
            (l.shared.pending = null));
        }
      } while (!0);
      if (
        (N === null && (f = L),
        (l.baseState = f),
        (l.firstBaseUpdate = w),
        (l.lastBaseUpdate = N),
        (t = l.shared.interleaved),
        t !== null)
      ) {
        l = t;
        do ((i |= l.lane), (l = l.next));
        while (l !== t);
      } else o === null && (l.shared.lanes = 0);
      ((sn |= i), (e.lanes = i), (e.memoizedState = L));
    }
  }
  function $a(e, t, n) {
    if (((e = t.effects), (t.effects = null), e !== null))
      for (t = 0; t < e.length; t++) {
        var r = e[t],
          l = r.callback;
        if (l !== null) {
          if (((r.callback = null), (r = n), typeof l != "function"))
            throw Error(a(191, l));
          l.call(r);
        }
      }
  }
  var hr = {},
    kt = Bt(hr),
    mr = Bt(hr),
    vr = Bt(hr);
  function un(e) {
    if (e === hr) throw Error(a(174));
    return e;
  }
  function bo(e, t) {
    switch ((ae(vr, t), ae(mr, e), ae(kt, hr), (e = t.nodeType), e)) {
      case 9:
      case 11:
        t = (t = t.documentElement) ? t.namespaceURI : bl(null, "");
        break;
      default:
        ((e = e === 8 ? t.parentNode : t),
          (t = e.namespaceURI || null),
          (e = e.tagName),
          (t = bl(t, e)));
    }
    (ce(kt), ae(kt, t));
  }
  function Dn() {
    (ce(kt), ce(mr), ce(vr));
  }
  function Ua(e) {
    un(vr.current);
    var t = un(kt.current),
      n = bl(t, e.type);
    t !== n && (ae(mr, e), ae(kt, n));
  }
  function eu(e) {
    mr.current === e && (ce(kt), ce(mr));
  }
  var me = Bt(0);
  function ml(e) {
    for (var t = e; t !== null;) {
      if (t.tag === 13) {
        var n = t.memoizedState;
        if (
          n !== null &&
          ((n = n.dehydrated), n === null || n.data === "$?" || n.data === "$!")
        )
          return t;
      } else if (t.tag === 19 && t.memoizedProps.revealOrder !== void 0) {
        if ((t.flags & 128) !== 0) return t;
      } else if (t.child !== null) {
        ((t.child.return = t), (t = t.child));
        continue;
      }
      if (t === e) break;
      for (; t.sibling === null;) {
        if (t.return === null || t.return === e) return null;
        t = t.return;
      }
      ((t.sibling.return = t.return), (t = t.sibling));
    }
    return null;
  }
  var tu = [];
  function nu() {
    for (var e = 0; e < tu.length; e++)
      tu[e]._workInProgressVersionPrimary = null;
    tu.length = 0;
  }
  var vl = ue.ReactCurrentDispatcher,
    ru = ue.ReactCurrentBatchConfig,
    an = 0,
    ve = null,
    _e = null,
    Re = null,
    yl = !1,
    yr = !1,
    gr = 0,
    Jf = 0;
  function Fe() {
    throw Error(a(321));
  }
  function lu(e, t) {
    if (t === null) return !1;
    for (var n = 0; n < t.length && n < e.length; n++)
      if (!it(e[n], t[n])) return !1;
    return !0;
  }
  function ou(e, t, n, r, l, o) {
    if (
      ((an = o),
      (ve = t),
      (t.memoizedState = null),
      (t.updateQueue = null),
      (t.lanes = 0),
      (vl.current = e === null || e.memoizedState === null ? ed : td),
      (e = n(r, l)),
      yr)
    ) {
      o = 0;
      do {
        if (((yr = !1), (gr = 0), 25 <= o)) throw Error(a(301));
        ((o += 1),
          (Re = _e = null),
          (t.updateQueue = null),
          (vl.current = nd),
          (e = n(r, l)));
      } while (yr);
    }
    if (
      ((vl.current = Sl),
      (t = _e !== null && _e.next !== null),
      (an = 0),
      (Re = _e = ve = null),
      (yl = !1),
      t)
    )
      throw Error(a(300));
    return e;
  }
  function uu() {
    var e = gr !== 0;
    return ((gr = 0), e);
  }
  function Et() {
    var e = {
      memoizedState: null,
      baseState: null,
      baseQueue: null,
      queue: null,
      next: null,
    };
    return (Re === null ? (ve.memoizedState = Re = e) : (Re = Re.next = e), Re);
  }
  function nt() {
    if (_e === null) {
      var e = ve.alternate;
      e = e !== null ? e.memoizedState : null;
    } else e = _e.next;
    var t = Re === null ? ve.memoizedState : Re.next;
    if (t !== null) ((Re = t), (_e = e));
    else {
      if (e === null) throw Error(a(310));
      ((_e = e),
        (e = {
          memoizedState: _e.memoizedState,
          baseState: _e.baseState,
          baseQueue: _e.baseQueue,
          queue: _e.queue,
          next: null,
        }),
        Re === null ? (ve.memoizedState = Re = e) : (Re = Re.next = e));
    }
    return Re;
  }
  function wr(e, t) {
    return typeof t == "function" ? t(e) : t;
  }
  function iu(e) {
    var t = nt(),
      n = t.queue;
    if (n === null) throw Error(a(311));
    n.lastRenderedReducer = e;
    var r = _e,
      l = r.baseQueue,
      o = n.pending;
    if (o !== null) {
      if (l !== null) {
        var i = l.next;
        ((l.next = o.next), (o.next = i));
      }
      ((r.baseQueue = l = o), (n.pending = null));
    }
    if (l !== null) {
      ((o = l.next), (r = r.baseState));
      var c = (i = null),
        f = null,
        w = o;
      do {
        var N = w.lane;
        if ((an & N) === N)
          (f !== null &&
            (f = f.next =
              {
                lane: 0,
                action: w.action,
                hasEagerState: w.hasEagerState,
                eagerState: w.eagerState,
                next: null,
              }),
            (r = w.hasEagerState ? w.eagerState : e(r, w.action)));
        else {
          var L = {
            lane: N,
            action: w.action,
            hasEagerState: w.hasEagerState,
            eagerState: w.eagerState,
            next: null,
          };
          (f === null ? ((c = f = L), (i = r)) : (f = f.next = L),
            (ve.lanes |= N),
            (sn |= N));
        }
        w = w.next;
      } while (w !== null && w !== o);
      (f === null ? (i = r) : (f.next = c),
        it(r, t.memoizedState) || (We = !0),
        (t.memoizedState = r),
        (t.baseState = i),
        (t.baseQueue = f),
        (n.lastRenderedState = r));
    }
    if (((e = n.interleaved), e !== null)) {
      l = e;
      do ((o = l.lane), (ve.lanes |= o), (sn |= o), (l = l.next));
      while (l !== e);
    } else l === null && (n.lanes = 0);
    return [t.memoizedState, n.dispatch];
  }
  function au(e) {
    var t = nt(),
      n = t.queue;
    if (n === null) throw Error(a(311));
    n.lastRenderedReducer = e;
    var r = n.dispatch,
      l = n.pending,
      o = t.memoizedState;
    if (l !== null) {
      n.pending = null;
      var i = (l = l.next);
      do ((o = e(o, i.action)), (i = i.next));
      while (i !== l);
      (it(o, t.memoizedState) || (We = !0),
        (t.memoizedState = o),
        t.baseQueue === null && (t.baseState = o),
        (n.lastRenderedState = o));
    }
    return [o, r];
  }
  function Aa() {}
  function Ba(e, t) {
    var n = ve,
      r = nt(),
      l = t(),
      o = !it(r.memoizedState, l);
    if (
      (o && ((r.memoizedState = l), (We = !0)),
      (r = r.queue),
      su(Va.bind(null, n, r, e), [e]),
      r.getSnapshot !== t || o || (Re !== null && Re.memoizedState.tag & 1))
    ) {
      if (
        ((n.flags |= 2048),
        Sr(9, Wa.bind(null, n, r, l, t), void 0, null),
        Ne === null)
      )
        throw Error(a(349));
      (an & 30) !== 0 || Ha(n, t, l);
    }
    return l;
  }
  function Ha(e, t, n) {
    ((e.flags |= 16384),
      (e = { getSnapshot: t, value: n }),
      (t = ve.updateQueue),
      t === null
        ? ((t = { lastEffect: null, stores: null }),
          (ve.updateQueue = t),
          (t.stores = [e]))
        : ((n = t.stores), n === null ? (t.stores = [e]) : n.push(e)));
  }
  function Wa(e, t, n, r) {
    ((t.value = n), (t.getSnapshot = r), Qa(t) && Ka(e));
  }
  function Va(e, t, n) {
    return n(function () {
      Qa(t) && Ka(e);
    });
  }
  function Qa(e) {
    var t = e.getSnapshot;
    e = e.value;
    try {
      var n = t();
      return !it(e, n);
    } catch {
      return !0;
    }
  }
  function Ka(e) {
    var t = Nt(e, 1);
    t !== null && dt(t, e, 1, -1);
  }
  function Ya(e) {
    var t = Et();
    return (
      typeof e == "function" && (e = e()),
      (t.memoizedState = t.baseState = e),
      (e = {
        pending: null,
        interleaved: null,
        lanes: 0,
        dispatch: null,
        lastRenderedReducer: wr,
        lastRenderedState: e,
      }),
      (t.queue = e),
      (e = e.dispatch = bf.bind(null, ve, e)),
      [t.memoizedState, e]
    );
  }
  function Sr(e, t, n, r) {
    return (
      (e = { tag: e, create: t, destroy: n, deps: r, next: null }),
      (t = ve.updateQueue),
      t === null
        ? ((t = { lastEffect: null, stores: null }),
          (ve.updateQueue = t),
          (t.lastEffect = e.next = e))
        : ((n = t.lastEffect),
          n === null
            ? (t.lastEffect = e.next = e)
            : ((r = n.next), (n.next = e), (e.next = r), (t.lastEffect = e))),
      e
    );
  }
  function Xa() {
    return nt().memoizedState;
  }
  function gl(e, t, n, r) {
    var l = Et();
    ((ve.flags |= e),
      (l.memoizedState = Sr(1 | t, n, void 0, r === void 0 ? null : r)));
  }
  function wl(e, t, n, r) {
    var l = nt();
    r = r === void 0 ? null : r;
    var o = void 0;
    if (_e !== null) {
      var i = _e.memoizedState;
      if (((o = i.destroy), r !== null && lu(r, i.deps))) {
        l.memoizedState = Sr(t, n, o, r);
        return;
      }
    }
    ((ve.flags |= e), (l.memoizedState = Sr(1 | t, n, o, r)));
  }
  function Ga(e, t) {
    return gl(8390656, 8, e, t);
  }
  function su(e, t) {
    return wl(2048, 8, e, t);
  }
  function Ja(e, t) {
    return wl(4, 2, e, t);
  }
  function Za(e, t) {
    return wl(4, 4, e, t);
  }
  function qa(e, t) {
    if (typeof t == "function")
      return (
        (e = e()),
        t(e),
        function () {
          t(null);
        }
      );
    if (t != null)
      return (
        (e = e()),
        (t.current = e),
        function () {
          t.current = null;
        }
      );
  }
  function ba(e, t, n) {
    return (
      (n = n != null ? n.concat([e]) : null),
      wl(4, 4, qa.bind(null, t, e), n)
    );
  }
  function cu() {}
  function es(e, t) {
    var n = nt();
    t = t === void 0 ? null : t;
    var r = n.memoizedState;
    return r !== null && t !== null && lu(t, r[1])
      ? r[0]
      : ((n.memoizedState = [e, t]), e);
  }
  function ts(e, t) {
    var n = nt();
    t = t === void 0 ? null : t;
    var r = n.memoizedState;
    return r !== null && t !== null && lu(t, r[1])
      ? r[0]
      : ((e = e()), (n.memoizedState = [e, t]), e);
  }
  function ns(e, t, n) {
    return (an & 21) === 0
      ? (e.baseState && ((e.baseState = !1), (We = !0)), (e.memoizedState = n))
      : (it(n, t) ||
          ((n = Oi()), (ve.lanes |= n), (sn |= n), (e.baseState = !0)),
        t);
  }
  function Zf(e, t) {
    var n = oe;
    ((oe = n !== 0 && 4 > n ? n : 4), e(!0));
    var r = ru.transition;
    ru.transition = {};
    try {
      (e(!1), t());
    } finally {
      ((oe = n), (ru.transition = r));
    }
  }
  function rs() {
    return nt().memoizedState;
  }
  function qf(e, t, n) {
    var r = Gt(e);
    if (
      ((n = {
        lane: r,
        action: n,
        hasEagerState: !1,
        eagerState: null,
        next: null,
      }),
      ls(e))
    )
      os(t, n);
    else if (((n = Fa(e, t, n, r)), n !== null)) {
      var l = Ue();
      (dt(n, e, r, l), us(n, t, r));
    }
  }
  function bf(e, t, n) {
    var r = Gt(e),
      l = {
        lane: r,
        action: n,
        hasEagerState: !1,
        eagerState: null,
        next: null,
      };
    if (ls(e)) os(t, l);
    else {
      var o = e.alternate;
      if (
        e.lanes === 0 &&
        (o === null || o.lanes === 0) &&
        ((o = t.lastRenderedReducer), o !== null)
      )
        try {
          var i = t.lastRenderedState,
            c = o(i, n);
          if (((l.hasEagerState = !0), (l.eagerState = c), it(c, i))) {
            var f = t.interleaved;
            (f === null
              ? ((l.next = l), Zo(t))
              : ((l.next = f.next), (f.next = l)),
              (t.interleaved = l));
            return;
          }
        } catch {
        } finally {
        }
      ((n = Fa(e, t, l, r)),
        n !== null && ((l = Ue()), dt(n, e, r, l), us(n, t, r)));
    }
  }
  function ls(e) {
    var t = e.alternate;
    return e === ve || (t !== null && t === ve);
  }
  function os(e, t) {
    yr = yl = !0;
    var n = e.pending;
    (n === null ? (t.next = t) : ((t.next = n.next), (n.next = t)),
      (e.pending = t));
  }
  function us(e, t, n) {
    if ((n & 4194240) !== 0) {
      var r = t.lanes;
      ((r &= e.pendingLanes), (n |= r), (t.lanes = n), fo(e, n));
    }
  }
  var Sl = {
      readContext: tt,
      useCallback: Fe,
      useContext: Fe,
      useEffect: Fe,
      useImperativeHandle: Fe,
      useInsertionEffect: Fe,
      useLayoutEffect: Fe,
      useMemo: Fe,
      useReducer: Fe,
      useRef: Fe,
      useState: Fe,
      useDebugValue: Fe,
      useDeferredValue: Fe,
      useTransition: Fe,
      useMutableSource: Fe,
      useSyncExternalStore: Fe,
      useId: Fe,
      unstable_isNewReconciler: !1,
    },
    ed = {
      readContext: tt,
      useCallback: function (e, t) {
        return ((Et().memoizedState = [e, t === void 0 ? null : t]), e);
      },
      useContext: tt,
      useEffect: Ga,
      useImperativeHandle: function (e, t, n) {
        return (
          (n = n != null ? n.concat([e]) : null),
          gl(4194308, 4, qa.bind(null, t, e), n)
        );
      },
      useLayoutEffect: function (e, t) {
        return gl(4194308, 4, e, t);
      },
      useInsertionEffect: function (e, t) {
        return gl(4, 2, e, t);
      },
      useMemo: function (e, t) {
        var n = Et();
        return (
          (t = t === void 0 ? null : t),
          (e = e()),
          (n.memoizedState = [e, t]),
          e
        );
      },
      useReducer: function (e, t, n) {
        var r = Et();
        return (
          (t = n !== void 0 ? n(t) : t),
          (r.memoizedState = r.baseState = t),
          (e = {
            pending: null,
            interleaved: null,
            lanes: 0,
            dispatch: null,
            lastRenderedReducer: e,
            lastRenderedState: t,
          }),
          (r.queue = e),
          (e = e.dispatch = qf.bind(null, ve, e)),
          [r.memoizedState, e]
        );
      },
      useRef: function (e) {
        var t = Et();
        return ((e = { current: e }), (t.memoizedState = e));
      },
      useState: Ya,
      useDebugValue: cu,
      useDeferredValue: function (e) {
        return (Et().memoizedState = e);
      },
      useTransition: function () {
        var e = Ya(!1),
          t = e[0];
        return ((e = Zf.bind(null, e[1])), (Et().memoizedState = e), [t, e]);
      },
      useMutableSource: function () {},
      useSyncExternalStore: function (e, t, n) {
        var r = ve,
          l = Et();
        if (de) {
          if (n === void 0) throw Error(a(407));
          n = n();
        } else {
          if (((n = t()), Ne === null)) throw Error(a(349));
          (an & 30) !== 0 || Ha(r, t, n);
        }
        l.memoizedState = n;
        var o = { value: n, getSnapshot: t };
        return (
          (l.queue = o),
          Ga(Va.bind(null, r, o, e), [e]),
          (r.flags |= 2048),
          Sr(9, Wa.bind(null, r, o, n, t), void 0, null),
          n
        );
      },
      useId: function () {
        var e = Et(),
          t = Ne.identifierPrefix;
        if (de) {
          var n = Rt,
            r = Pt;
          ((n = (r & ~(1 << (32 - ut(r) - 1))).toString(32) + n),
            (t = ":" + t + "R" + n),
            (n = gr++),
            0 < n && (t += "H" + n.toString(32)),
            (t += ":"));
        } else ((n = Jf++), (t = ":" + t + "r" + n.toString(32) + ":"));
        return (e.memoizedState = t);
      },
      unstable_isNewReconciler: !1,
    },
    td = {
      readContext: tt,
      useCallback: es,
      useContext: tt,
      useEffect: su,
      useImperativeHandle: ba,
      useInsertionEffect: Ja,
      useLayoutEffect: Za,
      useMemo: ts,
      useReducer: iu,
      useRef: Xa,
      useState: function () {
        return iu(wr);
      },
      useDebugValue: cu,
      useDeferredValue: function (e) {
        var t = nt();
        return ns(t, _e.memoizedState, e);
      },
      useTransition: function () {
        var e = iu(wr)[0],
          t = nt().memoizedState;
        return [e, t];
      },
      useMutableSource: Aa,
      useSyncExternalStore: Ba,
      useId: rs,
      unstable_isNewReconciler: !1,
    },
    nd = {
      readContext: tt,
      useCallback: es,
      useContext: tt,
      useEffect: su,
      useImperativeHandle: ba,
      useInsertionEffect: Ja,
      useLayoutEffect: Za,
      useMemo: ts,
      useReducer: au,
      useRef: Xa,
      useState: function () {
        return au(wr);
      },
      useDebugValue: cu,
      useDeferredValue: function (e) {
        var t = nt();
        return _e === null ? (t.memoizedState = e) : ns(t, _e.memoizedState, e);
      },
      useTransition: function () {
        var e = au(wr)[0],
          t = nt().memoizedState;
        return [e, t];
      },
      useMutableSource: Aa,
      useSyncExternalStore: Ba,
      useId: rs,
      unstable_isNewReconciler: !1,
    };
  function st(e, t) {
    if (e && e.defaultProps) {
      ((t = j({}, t)), (e = e.defaultProps));
      for (var n in e) t[n] === void 0 && (t[n] = e[n]);
      return t;
    }
    return t;
  }
  function fu(e, t, n, r) {
    ((t = e.memoizedState),
      (n = n(r, t)),
      (n = n == null ? t : j({}, t, n)),
      (e.memoizedState = n),
      e.lanes === 0 && (e.updateQueue.baseState = n));
  }
  var kl = {
    isMounted: function (e) {
      return (e = e._reactInternals) ? en(e) === e : !1;
    },
    enqueueSetState: function (e, t, n) {
      e = e._reactInternals;
      var r = Ue(),
        l = Gt(e),
        o = Lt(r, l);
      ((o.payload = t),
        n != null && (o.callback = n),
        (t = Qt(e, o, l)),
        t !== null && (dt(t, e, l, r), pl(t, e, l)));
    },
    enqueueReplaceState: function (e, t, n) {
      e = e._reactInternals;
      var r = Ue(),
        l = Gt(e),
        o = Lt(r, l);
      ((o.tag = 1),
        (o.payload = t),
        n != null && (o.callback = n),
        (t = Qt(e, o, l)),
        t !== null && (dt(t, e, l, r), pl(t, e, l)));
    },
    enqueueForceUpdate: function (e, t) {
      e = e._reactInternals;
      var n = Ue(),
        r = Gt(e),
        l = Lt(n, r);
      ((l.tag = 2),
        t != null && (l.callback = t),
        (t = Qt(e, l, r)),
        t !== null && (dt(t, e, r, n), pl(t, e, r)));
    },
  };
  function is(e, t, n, r, l, o, i) {
    return (
      (e = e.stateNode),
      typeof e.shouldComponentUpdate == "function"
        ? e.shouldComponentUpdate(r, o, i)
        : t.prototype && t.prototype.isPureReactComponent
          ? !ur(n, r) || !ur(l, o)
          : !0
    );
  }
  function as(e, t, n) {
    var r = !1,
      l = Ht,
      o = t.contextType;
    return (
      typeof o == "object" && o !== null
        ? (o = tt(o))
        : ((l = He(t) ? nn : Me.current),
          (r = t.contextTypes),
          (o = (r = r != null) ? Pn(e, l) : Ht)),
      (t = new t(n, o)),
      (e.memoizedState =
        t.state !== null && t.state !== void 0 ? t.state : null),
      (t.updater = kl),
      (e.stateNode = t),
      (t._reactInternals = e),
      r &&
        ((e = e.stateNode),
        (e.__reactInternalMemoizedUnmaskedChildContext = l),
        (e.__reactInternalMemoizedMaskedChildContext = o)),
      t
    );
  }
  function ss(e, t, n, r) {
    ((e = t.state),
      typeof t.componentWillReceiveProps == "function" &&
        t.componentWillReceiveProps(n, r),
      typeof t.UNSAFE_componentWillReceiveProps == "function" &&
        t.UNSAFE_componentWillReceiveProps(n, r),
      t.state !== e && kl.enqueueReplaceState(t, t.state, null));
  }
  function du(e, t, n, r) {
    var l = e.stateNode;
    ((l.props = n), (l.state = e.memoizedState), (l.refs = {}), qo(e));
    var o = t.contextType;
    (typeof o == "object" && o !== null
      ? (l.context = tt(o))
      : ((o = He(t) ? nn : Me.current), (l.context = Pn(e, o))),
      (l.state = e.memoizedState),
      (o = t.getDerivedStateFromProps),
      typeof o == "function" && (fu(e, t, o, n), (l.state = e.memoizedState)),
      typeof t.getDerivedStateFromProps == "function" ||
        typeof l.getSnapshotBeforeUpdate == "function" ||
        (typeof l.UNSAFE_componentWillMount != "function" &&
          typeof l.componentWillMount != "function") ||
        ((t = l.state),
        typeof l.componentWillMount == "function" && l.componentWillMount(),
        typeof l.UNSAFE_componentWillMount == "function" &&
          l.UNSAFE_componentWillMount(),
        t !== l.state && kl.enqueueReplaceState(l, l.state, null),
        hl(e, n, l, r),
        (l.state = e.memoizedState)),
      typeof l.componentDidMount == "function" && (e.flags |= 4194308));
  }
  function Mn(e, t) {
    try {
      var n = "",
        r = t;
      do ((n += te(r)), (r = r.return));
      while (r);
      var l = n;
    } catch (o) {
      l =
        `
Error generating stack: ` +
        o.message +
        `
` +
        o.stack;
    }
    return { value: e, source: t, stack: l, digest: null };
  }
  function pu(e, t, n) {
    return { value: e, source: null, stack: n ?? null, digest: t ?? null };
  }
  function hu(e, t) {
    try {
      console.error(t.value);
    } catch (n) {
      setTimeout(function () {
        throw n;
      });
    }
  }
  var rd = typeof WeakMap == "function" ? WeakMap : Map;
  function cs(e, t, n) {
    ((n = Lt(-1, n)), (n.tag = 3), (n.payload = { element: null }));
    var r = t.value;
    return (
      (n.callback = function () {
        (Nl || ((Nl = !0), (Lu = r)), hu(e, t));
      }),
      n
    );
  }
  function fs(e, t, n) {
    ((n = Lt(-1, n)), (n.tag = 3));
    var r = e.type.getDerivedStateFromError;
    if (typeof r == "function") {
      var l = t.value;
      ((n.payload = function () {
        return r(l);
      }),
        (n.callback = function () {
          hu(e, t);
        }));
    }
    var o = e.stateNode;
    return (
      o !== null &&
        typeof o.componentDidCatch == "function" &&
        (n.callback = function () {
          (hu(e, t),
            typeof r != "function" &&
              (Yt === null ? (Yt = new Set([this])) : Yt.add(this)));
          var i = t.stack;
          this.componentDidCatch(t.value, {
            componentStack: i !== null ? i : "",
          });
        }),
      n
    );
  }
  function ds(e, t, n) {
    var r = e.pingCache;
    if (r === null) {
      r = e.pingCache = new rd();
      var l = new Set();
      r.set(t, l);
    } else ((l = r.get(t)), l === void 0 && ((l = new Set()), r.set(t, l)));
    l.has(n) || (l.add(n), (e = yd.bind(null, e, t, n)), t.then(e, e));
  }
  function ps(e) {
    do {
      var t;
      if (
        ((t = e.tag === 13) &&
          ((t = e.memoizedState),
          (t = t !== null ? t.dehydrated !== null : !0)),
        t)
      )
        return e;
      e = e.return;
    } while (e !== null);
    return null;
  }
  function hs(e, t, n, r, l) {
    return (e.mode & 1) === 0
      ? (e === t
          ? (e.flags |= 65536)
          : ((e.flags |= 128),
            (n.flags |= 131072),
            (n.flags &= -52805),
            n.tag === 1 &&
              (n.alternate === null
                ? (n.tag = 17)
                : ((t = Lt(-1, 1)), (t.tag = 2), Qt(n, t, 1))),
            (n.lanes |= 1)),
        e)
      : ((e.flags |= 65536), (e.lanes = l), e);
  }
  var ld = ue.ReactCurrentOwner,
    We = !1;
  function $e(e, t, n, r) {
    t.child = e === null ? Ma(t, null, n, r) : Tn(t, e.child, n, r);
  }
  function ms(e, t, n, r, l) {
    n = n.render;
    var o = t.ref;
    return (
      On(t, l),
      (r = ou(e, t, n, r, o, l)),
      (n = uu()),
      e !== null && !We
        ? ((t.updateQueue = e.updateQueue),
          (t.flags &= -2053),
          (e.lanes &= ~l),
          Tt(e, t, l))
        : (de && n && Ho(t), (t.flags |= 1), $e(e, t, r, l), t.child)
    );
  }
  function vs(e, t, n, r, l) {
    if (e === null) {
      var o = n.type;
      return typeof o == "function" &&
        !Iu(o) &&
        o.defaultProps === void 0 &&
        n.compare === null &&
        n.defaultProps === void 0
        ? ((t.tag = 15), (t.type = o), ys(e, t, o, r, l))
        : ((e = Ml(n.type, null, r, t, t.mode, l)),
          (e.ref = t.ref),
          (e.return = t),
          (t.child = e));
    }
    if (((o = e.child), (e.lanes & l) === 0)) {
      var i = o.memoizedProps;
      if (
        ((n = n.compare), (n = n !== null ? n : ur), n(i, r) && e.ref === t.ref)
      )
        return Tt(e, t, l);
    }
    return (
      (t.flags |= 1),
      (e = Zt(o, r)),
      (e.ref = t.ref),
      (e.return = t),
      (t.child = e)
    );
  }
  function ys(e, t, n, r, l) {
    if (e !== null) {
      var o = e.memoizedProps;
      if (ur(o, r) && e.ref === t.ref)
        if (((We = !1), (t.pendingProps = r = o), (e.lanes & l) !== 0))
          (e.flags & 131072) !== 0 && (We = !0);
        else return ((t.lanes = e.lanes), Tt(e, t, l));
    }
    return mu(e, t, n, r, l);
  }
  function gs(e, t, n) {
    var r = t.pendingProps,
      l = r.children,
      o = e !== null ? e.memoizedState : null;
    if (r.mode === "hidden")
      if ((t.mode & 1) === 0)
        ((t.memoizedState = {
          baseLanes: 0,
          cachePool: null,
          transitions: null,
        }),
          ae(In, qe),
          (qe |= n));
      else {
        if ((n & 1073741824) === 0)
          return (
            (e = o !== null ? o.baseLanes | n : n),
            (t.lanes = t.childLanes = 1073741824),
            (t.memoizedState = {
              baseLanes: e,
              cachePool: null,
              transitions: null,
            }),
            (t.updateQueue = null),
            ae(In, qe),
            (qe |= e),
            null
          );
        ((t.memoizedState = {
          baseLanes: 0,
          cachePool: null,
          transitions: null,
        }),
          (r = o !== null ? o.baseLanes : n),
          ae(In, qe),
          (qe |= r));
      }
    else
      (o !== null ? ((r = o.baseLanes | n), (t.memoizedState = null)) : (r = n),
        ae(In, qe),
        (qe |= r));
    return ($e(e, t, l, n), t.child);
  }
  function ws(e, t) {
    var n = t.ref;
    ((e === null && n !== null) || (e !== null && e.ref !== n)) &&
      ((t.flags |= 512), (t.flags |= 2097152));
  }
  function mu(e, t, n, r, l) {
    var o = He(n) ? nn : Me.current;
    return (
      (o = Pn(t, o)),
      On(t, l),
      (n = ou(e, t, n, r, o, l)),
      (r = uu()),
      e !== null && !We
        ? ((t.updateQueue = e.updateQueue),
          (t.flags &= -2053),
          (e.lanes &= ~l),
          Tt(e, t, l))
        : (de && r && Ho(t), (t.flags |= 1), $e(e, t, n, l), t.child)
    );
  }
  function Ss(e, t, n, r, l) {
    if (He(n)) {
      var o = !0;
      ol(t);
    } else o = !1;
    if ((On(t, l), t.stateNode === null))
      (Cl(e, t), as(t, n, r), du(t, n, r, l), (r = !0));
    else if (e === null) {
      var i = t.stateNode,
        c = t.memoizedProps;
      i.props = c;
      var f = i.context,
        w = n.contextType;
      typeof w == "object" && w !== null
        ? (w = tt(w))
        : ((w = He(n) ? nn : Me.current), (w = Pn(t, w)));
      var N = n.getDerivedStateFromProps,
        L =
          typeof N == "function" ||
          typeof i.getSnapshotBeforeUpdate == "function";
      (L ||
        (typeof i.UNSAFE_componentWillReceiveProps != "function" &&
          typeof i.componentWillReceiveProps != "function") ||
        ((c !== r || f !== w) && ss(t, i, r, w)),
        (Vt = !1));
      var P = t.memoizedState;
      ((i.state = P),
        hl(t, r, i, l),
        (f = t.memoizedState),
        c !== r || P !== f || Be.current || Vt
          ? (typeof N == "function" && (fu(t, n, N, r), (f = t.memoizedState)),
            (c = Vt || is(t, n, c, r, P, f, w))
              ? (L ||
                  (typeof i.UNSAFE_componentWillMount != "function" &&
                    typeof i.componentWillMount != "function") ||
                  (typeof i.componentWillMount == "function" &&
                    i.componentWillMount(),
                  typeof i.UNSAFE_componentWillMount == "function" &&
                    i.UNSAFE_componentWillMount()),
                typeof i.componentDidMount == "function" &&
                  (t.flags |= 4194308))
              : (typeof i.componentDidMount == "function" &&
                  (t.flags |= 4194308),
                (t.memoizedProps = r),
                (t.memoizedState = f)),
            (i.props = r),
            (i.state = f),
            (i.context = w),
            (r = c))
          : (typeof i.componentDidMount == "function" && (t.flags |= 4194308),
            (r = !1)));
    } else {
      ((i = t.stateNode),
        Ia(e, t),
        (c = t.memoizedProps),
        (w = t.type === t.elementType ? c : st(t.type, c)),
        (i.props = w),
        (L = t.pendingProps),
        (P = i.context),
        (f = n.contextType),
        typeof f == "object" && f !== null
          ? (f = tt(f))
          : ((f = He(n) ? nn : Me.current), (f = Pn(t, f))));
      var M = n.getDerivedStateFromProps;
      ((N =
        typeof M == "function" ||
        typeof i.getSnapshotBeforeUpdate == "function") ||
        (typeof i.UNSAFE_componentWillReceiveProps != "function" &&
          typeof i.componentWillReceiveProps != "function") ||
        ((c !== L || P !== f) && ss(t, i, r, f)),
        (Vt = !1),
        (P = t.memoizedState),
        (i.state = P),
        hl(t, r, i, l));
      var $ = t.memoizedState;
      c !== L || P !== $ || Be.current || Vt
        ? (typeof M == "function" && (fu(t, n, M, r), ($ = t.memoizedState)),
          (w = Vt || is(t, n, w, r, P, $, f) || !1)
            ? (N ||
                (typeof i.UNSAFE_componentWillUpdate != "function" &&
                  typeof i.componentWillUpdate != "function") ||
                (typeof i.componentWillUpdate == "function" &&
                  i.componentWillUpdate(r, $, f),
                typeof i.UNSAFE_componentWillUpdate == "function" &&
                  i.UNSAFE_componentWillUpdate(r, $, f)),
              typeof i.componentDidUpdate == "function" && (t.flags |= 4),
              typeof i.getSnapshotBeforeUpdate == "function" &&
                (t.flags |= 1024))
            : (typeof i.componentDidUpdate != "function" ||
                (c === e.memoizedProps && P === e.memoizedState) ||
                (t.flags |= 4),
              typeof i.getSnapshotBeforeUpdate != "function" ||
                (c === e.memoizedProps && P === e.memoizedState) ||
                (t.flags |= 1024),
              (t.memoizedProps = r),
              (t.memoizedState = $)),
          (i.props = r),
          (i.state = $),
          (i.context = f),
          (r = w))
        : (typeof i.componentDidUpdate != "function" ||
            (c === e.memoizedProps && P === e.memoizedState) ||
            (t.flags |= 4),
          typeof i.getSnapshotBeforeUpdate != "function" ||
            (c === e.memoizedProps && P === e.memoizedState) ||
            (t.flags |= 1024),
          (r = !1));
    }
    return vu(e, t, n, r, o, l);
  }
  function vu(e, t, n, r, l, o) {
    ws(e, t);
    var i = (t.flags & 128) !== 0;
    if (!r && !i) return (l && _a(t, n, !1), Tt(e, t, o));
    ((r = t.stateNode), (ld.current = t));
    var c =
      i && typeof n.getDerivedStateFromError != "function" ? null : r.render();
    return (
      (t.flags |= 1),
      e !== null && i
        ? ((t.child = Tn(t, e.child, null, o)), (t.child = Tn(t, null, c, o)))
        : $e(e, t, c, o),
      (t.memoizedState = r.state),
      l && _a(t, n, !0),
      t.child
    );
  }
  function ks(e) {
    var t = e.stateNode;
    (t.pendingContext
      ? Ca(e, t.pendingContext, t.pendingContext !== t.context)
      : t.context && Ca(e, t.context, !1),
      bo(e, t.containerInfo));
  }
  function Es(e, t, n, r, l) {
    return (Ln(), Ko(l), (t.flags |= 256), $e(e, t, n, r), t.child);
  }
  var yu = { dehydrated: null, treeContext: null, retryLane: 0 };
  function gu(e) {
    return { baseLanes: e, cachePool: null, transitions: null };
  }
  function Cs(e, t, n) {
    var r = t.pendingProps,
      l = me.current,
      o = !1,
      i = (t.flags & 128) !== 0,
      c;
    if (
      ((c = i) ||
        (c = e !== null && e.memoizedState === null ? !1 : (l & 2) !== 0),
      c
        ? ((o = !0), (t.flags &= -129))
        : (e === null || e.memoizedState !== null) && (l |= 1),
      ae(me, l & 1),
      e === null)
    )
      return (
        Qo(t),
        (e = t.memoizedState),
        e !== null && ((e = e.dehydrated), e !== null)
          ? ((t.mode & 1) === 0
              ? (t.lanes = 1)
              : e.data === "$!"
                ? (t.lanes = 8)
                : (t.lanes = 1073741824),
            null)
          : ((i = r.children),
            (e = r.fallback),
            o
              ? ((r = t.mode),
                (o = t.child),
                (i = { mode: "hidden", children: i }),
                (r & 1) === 0 && o !== null
                  ? ((o.childLanes = 0), (o.pendingProps = i))
                  : (o = Fl(i, r, 0, null)),
                (e = pn(e, r, n, null)),
                (o.return = t),
                (e.return = t),
                (o.sibling = e),
                (t.child = o),
                (t.child.memoizedState = gu(n)),
                (t.memoizedState = yu),
                e)
              : wu(t, i))
      );
    if (((l = e.memoizedState), l !== null && ((c = l.dehydrated), c !== null)))
      return od(e, t, i, r, c, l, n);
    if (o) {
      ((o = r.fallback), (i = t.mode), (l = e.child), (c = l.sibling));
      var f = { mode: "hidden", children: r.children };
      return (
        (i & 1) === 0 && t.child !== l
          ? ((r = t.child),
            (r.childLanes = 0),
            (r.pendingProps = f),
            (t.deletions = null))
          : ((r = Zt(l, f)), (r.subtreeFlags = l.subtreeFlags & 14680064)),
        c !== null ? (o = Zt(c, o)) : ((o = pn(o, i, n, null)), (o.flags |= 2)),
        (o.return = t),
        (r.return = t),
        (r.sibling = o),
        (t.child = r),
        (r = o),
        (o = t.child),
        (i = e.child.memoizedState),
        (i =
          i === null
            ? gu(n)
            : {
                baseLanes: i.baseLanes | n,
                cachePool: null,
                transitions: i.transitions,
              }),
        (o.memoizedState = i),
        (o.childLanes = e.childLanes & ~n),
        (t.memoizedState = yu),
        r
      );
    }
    return (
      (o = e.child),
      (e = o.sibling),
      (r = Zt(o, { mode: "visible", children: r.children })),
      (t.mode & 1) === 0 && (r.lanes = n),
      (r.return = t),
      (r.sibling = null),
      e !== null &&
        ((n = t.deletions),
        n === null ? ((t.deletions = [e]), (t.flags |= 16)) : n.push(e)),
      (t.child = r),
      (t.memoizedState = null),
      r
    );
  }
  function wu(e, t) {
    return (
      (t = Fl({ mode: "visible", children: t }, e.mode, 0, null)),
      (t.return = e),
      (e.child = t)
    );
  }
  function El(e, t, n, r) {
    return (
      r !== null && Ko(r),
      Tn(t, e.child, null, n),
      (e = wu(t, t.pendingProps.children)),
      (e.flags |= 2),
      (t.memoizedState = null),
      e
    );
  }
  function od(e, t, n, r, l, o, i) {
    if (n)
      return t.flags & 256
        ? ((t.flags &= -257), (r = pu(Error(a(422)))), El(e, t, i, r))
        : t.memoizedState !== null
          ? ((t.child = e.child), (t.flags |= 128), null)
          : ((o = r.fallback),
            (l = t.mode),
            (r = Fl({ mode: "visible", children: r.children }, l, 0, null)),
            (o = pn(o, l, i, null)),
            (o.flags |= 2),
            (r.return = t),
            (o.return = t),
            (r.sibling = o),
            (t.child = r),
            (t.mode & 1) !== 0 && Tn(t, e.child, null, i),
            (t.child.memoizedState = gu(i)),
            (t.memoizedState = yu),
            o);
    if ((t.mode & 1) === 0) return El(e, t, i, null);
    if (l.data === "$!") {
      if (((r = l.nextSibling && l.nextSibling.dataset), r)) var c = r.dgst;
      return (
        (r = c),
        (o = Error(a(419))),
        (r = pu(o, r, void 0)),
        El(e, t, i, r)
      );
    }
    if (((c = (i & e.childLanes) !== 0), We || c)) {
      if (((r = Ne), r !== null)) {
        switch (i & -i) {
          case 4:
            l = 2;
            break;
          case 16:
            l = 8;
            break;
          case 64:
          case 128:
          case 256:
          case 512:
          case 1024:
          case 2048:
          case 4096:
          case 8192:
          case 16384:
          case 32768:
          case 65536:
          case 131072:
          case 262144:
          case 524288:
          case 1048576:
          case 2097152:
          case 4194304:
          case 8388608:
          case 16777216:
          case 33554432:
          case 67108864:
            l = 32;
            break;
          case 536870912:
            l = 268435456;
            break;
          default:
            l = 0;
        }
        ((l = (l & (r.suspendedLanes | i)) !== 0 ? 0 : l),
          l !== 0 &&
            l !== o.retryLane &&
            ((o.retryLane = l), Nt(e, l), dt(r, e, l, -1)));
      }
      return (Fu(), (r = pu(Error(a(421)))), El(e, t, i, r));
    }
    return l.data === "$?"
      ? ((t.flags |= 128),
        (t.child = e.child),
        (t = gd.bind(null, e)),
        (l._reactRetry = t),
        null)
      : ((e = o.treeContext),
        (Ze = At(l.nextSibling)),
        (Je = t),
        (de = !0),
        (at = null),
        e !== null &&
          ((be[et++] = Pt),
          (be[et++] = Rt),
          (be[et++] = rn),
          (Pt = e.id),
          (Rt = e.overflow),
          (rn = t)),
        (t = wu(t, r.children)),
        (t.flags |= 4096),
        t);
  }
  function xs(e, t, n) {
    e.lanes |= t;
    var r = e.alternate;
    (r !== null && (r.lanes |= t), Jo(e.return, t, n));
  }
  function Su(e, t, n, r, l) {
    var o = e.memoizedState;
    o === null
      ? (e.memoizedState = {
          isBackwards: t,
          rendering: null,
          renderingStartTime: 0,
          last: r,
          tail: n,
          tailMode: l,
        })
      : ((o.isBackwards = t),
        (o.rendering = null),
        (o.renderingStartTime = 0),
        (o.last = r),
        (o.tail = n),
        (o.tailMode = l));
  }
  function _s(e, t, n) {
    var r = t.pendingProps,
      l = r.revealOrder,
      o = r.tail;
    if (($e(e, t, r.children, n), (r = me.current), (r & 2) !== 0))
      ((r = (r & 1) | 2), (t.flags |= 128));
    else {
      if (e !== null && (e.flags & 128) !== 0)
        e: for (e = t.child; e !== null;) {
          if (e.tag === 13) e.memoizedState !== null && xs(e, n, t);
          else if (e.tag === 19) xs(e, n, t);
          else if (e.child !== null) {
            ((e.child.return = e), (e = e.child));
            continue;
          }
          if (e === t) break e;
          for (; e.sibling === null;) {
            if (e.return === null || e.return === t) break e;
            e = e.return;
          }
          ((e.sibling.return = e.return), (e = e.sibling));
        }
      r &= 1;
    }
    if ((ae(me, r), (t.mode & 1) === 0)) t.memoizedState = null;
    else
      switch (l) {
        case "forwards":
          for (n = t.child, l = null; n !== null;)
            ((e = n.alternate),
              e !== null && ml(e) === null && (l = n),
              (n = n.sibling));
          ((n = l),
            n === null
              ? ((l = t.child), (t.child = null))
              : ((l = n.sibling), (n.sibling = null)),
            Su(t, !1, l, n, o));
          break;
        case "backwards":
          for (n = null, l = t.child, t.child = null; l !== null;) {
            if (((e = l.alternate), e !== null && ml(e) === null)) {
              t.child = l;
              break;
            }
            ((e = l.sibling), (l.sibling = n), (n = l), (l = e));
          }
          Su(t, !0, n, null, o);
          break;
        case "together":
          Su(t, !1, null, null, void 0);
          break;
        default:
          t.memoizedState = null;
      }
    return t.child;
  }
  function Cl(e, t) {
    (t.mode & 1) === 0 &&
      e !== null &&
      ((e.alternate = null), (t.alternate = null), (t.flags |= 2));
  }
  function Tt(e, t, n) {
    if (
      (e !== null && (t.dependencies = e.dependencies),
      (sn |= t.lanes),
      (n & t.childLanes) === 0)
    )
      return null;
    if (e !== null && t.child !== e.child) throw Error(a(153));
    if (t.child !== null) {
      for (
        e = t.child, n = Zt(e, e.pendingProps), t.child = n, n.return = t;
        e.sibling !== null;
      )
        ((e = e.sibling),
          (n = n.sibling = Zt(e, e.pendingProps)),
          (n.return = t));
      n.sibling = null;
    }
    return t.child;
  }
  function ud(e, t, n) {
    switch (t.tag) {
      case 3:
        (ks(t), Ln());
        break;
      case 5:
        Ua(t);
        break;
      case 1:
        He(t.type) && ol(t);
        break;
      case 4:
        bo(t, t.stateNode.containerInfo);
        break;
      case 10:
        var r = t.type._context,
          l = t.memoizedProps.value;
        (ae(fl, r._currentValue), (r._currentValue = l));
        break;
      case 13:
        if (((r = t.memoizedState), r !== null))
          return r.dehydrated !== null
            ? (ae(me, me.current & 1), (t.flags |= 128), null)
            : (n & t.child.childLanes) !== 0
              ? Cs(e, t, n)
              : (ae(me, me.current & 1),
                (e = Tt(e, t, n)),
                e !== null ? e.sibling : null);
        ae(me, me.current & 1);
        break;
      case 19:
        if (((r = (n & t.childLanes) !== 0), (e.flags & 128) !== 0)) {
          if (r) return _s(e, t, n);
          t.flags |= 128;
        }
        if (
          ((l = t.memoizedState),
          l !== null &&
            ((l.rendering = null), (l.tail = null), (l.lastEffect = null)),
          ae(me, me.current),
          r)
        )
          break;
        return null;
      case 22:
      case 23:
        return ((t.lanes = 0), gs(e, t, n));
    }
    return Tt(e, t, n);
  }
  var Ps, ku, Rs, Ns;
  ((Ps = function (e, t) {
    for (var n = t.child; n !== null;) {
      if (n.tag === 5 || n.tag === 6) e.appendChild(n.stateNode);
      else if (n.tag !== 4 && n.child !== null) {
        ((n.child.return = n), (n = n.child));
        continue;
      }
      if (n === t) break;
      for (; n.sibling === null;) {
        if (n.return === null || n.return === t) return;
        n = n.return;
      }
      ((n.sibling.return = n.return), (n = n.sibling));
    }
  }),
    (ku = function () {}),
    (Rs = function (e, t, n, r) {
      var l = e.memoizedProps;
      if (l !== r) {
        ((e = t.stateNode), un(kt.current));
        var o = null;
        switch (n) {
          case "input":
            ((l = Gl(e, l)), (r = Gl(e, r)), (o = []));
            break;
          case "select":
            ((l = j({}, l, { value: void 0 })),
              (r = j({}, r, { value: void 0 })),
              (o = []));
            break;
          case "textarea":
            ((l = ql(e, l)), (r = ql(e, r)), (o = []));
            break;
          default:
            typeof l.onClick != "function" &&
              typeof r.onClick == "function" &&
              (e.onclick = nl);
        }
        eo(n, r);
        var i;
        n = null;
        for (w in l)
          if (!r.hasOwnProperty(w) && l.hasOwnProperty(w) && l[w] != null)
            if (w === "style") {
              var c = l[w];
              for (i in c) c.hasOwnProperty(i) && (n || (n = {}), (n[i] = ""));
            } else
              w !== "dangerouslySetInnerHTML" &&
                w !== "children" &&
                w !== "suppressContentEditableWarning" &&
                w !== "suppressHydrationWarning" &&
                w !== "autoFocus" &&
                (p.hasOwnProperty(w)
                  ? o || (o = [])
                  : (o = o || []).push(w, null));
        for (w in r) {
          var f = r[w];
          if (
            ((c = l?.[w]),
            r.hasOwnProperty(w) && f !== c && (f != null || c != null))
          )
            if (w === "style")
              if (c) {
                for (i in c)
                  !c.hasOwnProperty(i) ||
                    (f && f.hasOwnProperty(i)) ||
                    (n || (n = {}), (n[i] = ""));
                for (i in f)
                  f.hasOwnProperty(i) &&
                    c[i] !== f[i] &&
                    (n || (n = {}), (n[i] = f[i]));
              } else (n || (o || (o = []), o.push(w, n)), (n = f));
            else
              w === "dangerouslySetInnerHTML"
                ? ((f = f ? f.__html : void 0),
                  (c = c ? c.__html : void 0),
                  f != null && c !== f && (o = o || []).push(w, f))
                : w === "children"
                  ? (typeof f != "string" && typeof f != "number") ||
                    (o = o || []).push(w, "" + f)
                  : w !== "suppressContentEditableWarning" &&
                    w !== "suppressHydrationWarning" &&
                    (p.hasOwnProperty(w)
                      ? (f != null && w === "onScroll" && se("scroll", e),
                        o || c === f || (o = []))
                      : (o = o || []).push(w, f));
        }
        n && (o = o || []).push("style", n);
        var w = o;
        (t.updateQueue = w) && (t.flags |= 4);
      }
    }),
    (Ns = function (e, t, n, r) {
      n !== r && (t.flags |= 4);
    }));
  function kr(e, t) {
    if (!de)
      switch (e.tailMode) {
        case "hidden":
          t = e.tail;
          for (var n = null; t !== null;)
            (t.alternate !== null && (n = t), (t = t.sibling));
          n === null ? (e.tail = null) : (n.sibling = null);
          break;
        case "collapsed":
          n = e.tail;
          for (var r = null; n !== null;)
            (n.alternate !== null && (r = n), (n = n.sibling));
          r === null
            ? t || e.tail === null
              ? (e.tail = null)
              : (e.tail.sibling = null)
            : (r.sibling = null);
      }
  }
  function Ie(e) {
    var t = e.alternate !== null && e.alternate.child === e.child,
      n = 0,
      r = 0;
    if (t)
      for (var l = e.child; l !== null;)
        ((n |= l.lanes | l.childLanes),
          (r |= l.subtreeFlags & 14680064),
          (r |= l.flags & 14680064),
          (l.return = e),
          (l = l.sibling));
    else
      for (l = e.child; l !== null;)
        ((n |= l.lanes | l.childLanes),
          (r |= l.subtreeFlags),
          (r |= l.flags),
          (l.return = e),
          (l = l.sibling));
    return ((e.subtreeFlags |= r), (e.childLanes = n), t);
  }
  function id(e, t, n) {
    var r = t.pendingProps;
    switch ((Wo(t), t.tag)) {
      case 2:
      case 16:
      case 15:
      case 0:
      case 11:
      case 7:
      case 8:
      case 12:
      case 9:
      case 14:
        return (Ie(t), null);
      case 1:
        return (He(t.type) && ll(), Ie(t), null);
      case 3:
        return (
          (r = t.stateNode),
          Dn(),
          ce(Be),
          ce(Me),
          nu(),
          r.pendingContext &&
            ((r.context = r.pendingContext), (r.pendingContext = null)),
          (e === null || e.child === null) &&
            (sl(t)
              ? (t.flags |= 4)
              : e === null ||
                (e.memoizedState.isDehydrated && (t.flags & 256) === 0) ||
                ((t.flags |= 1024), at !== null && (Ou(at), (at = null)))),
          ku(e, t),
          Ie(t),
          null
        );
      case 5:
        eu(t);
        var l = un(vr.current);
        if (((n = t.type), e !== null && t.stateNode != null))
          (Rs(e, t, n, r, l),
            e.ref !== t.ref && ((t.flags |= 512), (t.flags |= 2097152)));
        else {
          if (!r) {
            if (t.stateNode === null) throw Error(a(166));
            return (Ie(t), null);
          }
          if (((e = un(kt.current)), sl(t))) {
            ((r = t.stateNode), (n = t.type));
            var o = t.memoizedProps;
            switch (((r[St] = t), (r[fr] = o), (e = (t.mode & 1) !== 0), n)) {
              case "dialog":
                (se("cancel", r), se("close", r));
                break;
              case "iframe":
              case "object":
              case "embed":
                se("load", r);
                break;
              case "video":
              case "audio":
                for (l = 0; l < ar.length; l++) se(ar[l], r);
                break;
              case "source":
                se("error", r);
                break;
              case "img":
              case "image":
              case "link":
                (se("error", r), se("load", r));
                break;
              case "details":
                se("toggle", r);
                break;
              case "input":
                (ai(r, o), se("invalid", r));
                break;
              case "select":
                ((r._wrapperState = { wasMultiple: !!o.multiple }),
                  se("invalid", r));
                break;
              case "textarea":
                (fi(r, o), se("invalid", r));
            }
            (eo(n, o), (l = null));
            for (var i in o)
              if (o.hasOwnProperty(i)) {
                var c = o[i];
                i === "children"
                  ? typeof c == "string"
                    ? r.textContent !== c &&
                      (o.suppressHydrationWarning !== !0 &&
                        tl(r.textContent, c, e),
                      (l = ["children", c]))
                    : typeof c == "number" &&
                      r.textContent !== "" + c &&
                      (o.suppressHydrationWarning !== !0 &&
                        tl(r.textContent, c, e),
                      (l = ["children", "" + c]))
                  : p.hasOwnProperty(i) &&
                    c != null &&
                    i === "onScroll" &&
                    se("scroll", r);
              }
            switch (n) {
              case "input":
                (Or(r), ci(r, o, !0));
                break;
              case "textarea":
                (Or(r), pi(r));
                break;
              case "select":
              case "option":
                break;
              default:
                typeof o.onClick == "function" && (r.onclick = nl);
            }
            ((r = l), (t.updateQueue = r), r !== null && (t.flags |= 4));
          } else {
            ((i = l.nodeType === 9 ? l : l.ownerDocument),
              e === "http://www.w3.org/1999/xhtml" && (e = hi(n)),
              e === "http://www.w3.org/1999/xhtml"
                ? n === "script"
                  ? ((e = i.createElement("div")),
                    (e.innerHTML = "<script><\/script>"),
                    (e = e.removeChild(e.firstChild)))
                  : typeof r.is == "string"
                    ? (e = i.createElement(n, { is: r.is }))
                    : ((e = i.createElement(n)),
                      n === "select" &&
                        ((i = e),
                        r.multiple
                          ? (i.multiple = !0)
                          : r.size && (i.size = r.size)))
                : (e = i.createElementNS(e, n)),
              (e[St] = t),
              (e[fr] = r),
              Ps(e, t, !1, !1),
              (t.stateNode = e));
            e: {
              switch (((i = to(n, r)), n)) {
                case "dialog":
                  (se("cancel", e), se("close", e), (l = r));
                  break;
                case "iframe":
                case "object":
                case "embed":
                  (se("load", e), (l = r));
                  break;
                case "video":
                case "audio":
                  for (l = 0; l < ar.length; l++) se(ar[l], e);
                  l = r;
                  break;
                case "source":
                  (se("error", e), (l = r));
                  break;
                case "img":
                case "image":
                case "link":
                  (se("error", e), se("load", e), (l = r));
                  break;
                case "details":
                  (se("toggle", e), (l = r));
                  break;
                case "input":
                  (ai(e, r), (l = Gl(e, r)), se("invalid", e));
                  break;
                case "option":
                  l = r;
                  break;
                case "select":
                  ((e._wrapperState = { wasMultiple: !!r.multiple }),
                    (l = j({}, r, { value: void 0 })),
                    se("invalid", e));
                  break;
                case "textarea":
                  (fi(e, r), (l = ql(e, r)), se("invalid", e));
                  break;
                default:
                  l = r;
              }
              (eo(n, l), (c = l));
              for (o in c)
                if (c.hasOwnProperty(o)) {
                  var f = c[o];
                  o === "style"
                    ? yi(e, f)
                    : o === "dangerouslySetInnerHTML"
                      ? ((f = f ? f.__html : void 0), f != null && mi(e, f))
                      : o === "children"
                        ? typeof f == "string"
                          ? (n !== "textarea" || f !== "") && Wn(e, f)
                          : typeof f == "number" && Wn(e, "" + f)
                        : o !== "suppressContentEditableWarning" &&
                          o !== "suppressHydrationWarning" &&
                          o !== "autoFocus" &&
                          (p.hasOwnProperty(o)
                            ? f != null && o === "onScroll" && se("scroll", e)
                            : f != null && Z(e, o, f, i));
                }
              switch (n) {
                case "input":
                  (Or(e), ci(e, r, !1));
                  break;
                case "textarea":
                  (Or(e), pi(e));
                  break;
                case "option":
                  r.value != null && e.setAttribute("value", "" + le(r.value));
                  break;
                case "select":
                  ((e.multiple = !!r.multiple),
                    (o = r.value),
                    o != null
                      ? hn(e, !!r.multiple, o, !1)
                      : r.defaultValue != null &&
                        hn(e, !!r.multiple, r.defaultValue, !0));
                  break;
                default:
                  typeof l.onClick == "function" && (e.onclick = nl);
              }
              switch (n) {
                case "button":
                case "input":
                case "select":
                case "textarea":
                  r = !!r.autoFocus;
                  break e;
                case "img":
                  r = !0;
                  break e;
                default:
                  r = !1;
              }
            }
            r && (t.flags |= 4);
          }
          t.ref !== null && ((t.flags |= 512), (t.flags |= 2097152));
        }
        return (Ie(t), null);
      case 6:
        if (e && t.stateNode != null) Ns(e, t, e.memoizedProps, r);
        else {
          if (typeof r != "string" && t.stateNode === null) throw Error(a(166));
          if (((n = un(vr.current)), un(kt.current), sl(t))) {
            if (
              ((r = t.stateNode),
              (n = t.memoizedProps),
              (r[St] = t),
              (o = r.nodeValue !== n) && ((e = Je), e !== null))
            )
              switch (e.tag) {
                case 3:
                  tl(r.nodeValue, n, (e.mode & 1) !== 0);
                  break;
                case 5:
                  e.memoizedProps.suppressHydrationWarning !== !0 &&
                    tl(r.nodeValue, n, (e.mode & 1) !== 0);
              }
            o && (t.flags |= 4);
          } else
            ((r = (n.nodeType === 9 ? n : n.ownerDocument).createTextNode(r)),
              (r[St] = t),
              (t.stateNode = r));
        }
        return (Ie(t), null);
      case 13:
        if (
          (ce(me),
          (r = t.memoizedState),
          e === null ||
            (e.memoizedState !== null && e.memoizedState.dehydrated !== null))
        ) {
          if (de && Ze !== null && (t.mode & 1) !== 0 && (t.flags & 128) === 0)
            (za(), Ln(), (t.flags |= 98560), (o = !1));
          else if (((o = sl(t)), r !== null && r.dehydrated !== null)) {
            if (e === null) {
              if (!o) throw Error(a(318));
              if (
                ((o = t.memoizedState),
                (o = o !== null ? o.dehydrated : null),
                !o)
              )
                throw Error(a(317));
              o[St] = t;
            } else
              (Ln(),
                (t.flags & 128) === 0 && (t.memoizedState = null),
                (t.flags |= 4));
            (Ie(t), (o = !1));
          } else (at !== null && (Ou(at), (at = null)), (o = !0));
          if (!o) return t.flags & 65536 ? t : null;
        }
        return (t.flags & 128) !== 0
          ? ((t.lanes = n), t)
          : ((r = r !== null),
            r !== (e !== null && e.memoizedState !== null) &&
              r &&
              ((t.child.flags |= 8192),
              (t.mode & 1) !== 0 &&
                (e === null || (me.current & 1) !== 0
                  ? Pe === 0 && (Pe = 3)
                  : Fu())),
            t.updateQueue !== null && (t.flags |= 4),
            Ie(t),
            null);
      case 4:
        return (
          Dn(),
          ku(e, t),
          e === null && sr(t.stateNode.containerInfo),
          Ie(t),
          null
        );
      case 10:
        return (Go(t.type._context), Ie(t), null);
      case 17:
        return (He(t.type) && ll(), Ie(t), null);
      case 19:
        if ((ce(me), (o = t.memoizedState), o === null)) return (Ie(t), null);
        if (((r = (t.flags & 128) !== 0), (i = o.rendering), i === null))
          if (r) kr(o, !1);
          else {
            if (Pe !== 0 || (e !== null && (e.flags & 128) !== 0))
              for (e = t.child; e !== null;) {
                if (((i = ml(e)), i !== null)) {
                  for (
                    t.flags |= 128,
                      kr(o, !1),
                      r = i.updateQueue,
                      r !== null && ((t.updateQueue = r), (t.flags |= 4)),
                      t.subtreeFlags = 0,
                      r = n,
                      n = t.child;
                    n !== null;
                  )
                    ((o = n),
                      (e = r),
                      (o.flags &= 14680066),
                      (i = o.alternate),
                      i === null
                        ? ((o.childLanes = 0),
                          (o.lanes = e),
                          (o.child = null),
                          (o.subtreeFlags = 0),
                          (o.memoizedProps = null),
                          (o.memoizedState = null),
                          (o.updateQueue = null),
                          (o.dependencies = null),
                          (o.stateNode = null))
                        : ((o.childLanes = i.childLanes),
                          (o.lanes = i.lanes),
                          (o.child = i.child),
                          (o.subtreeFlags = 0),
                          (o.deletions = null),
                          (o.memoizedProps = i.memoizedProps),
                          (o.memoizedState = i.memoizedState),
                          (o.updateQueue = i.updateQueue),
                          (o.type = i.type),
                          (e = i.dependencies),
                          (o.dependencies =
                            e === null
                              ? null
                              : {
                                  lanes: e.lanes,
                                  firstContext: e.firstContext,
                                })),
                      (n = n.sibling));
                  return (ae(me, (me.current & 1) | 2), t.child);
                }
                e = e.sibling;
              }
            o.tail !== null &&
              we() > jn &&
              ((t.flags |= 128), (r = !0), kr(o, !1), (t.lanes = 4194304));
          }
        else {
          if (!r)
            if (((e = ml(i)), e !== null)) {
              if (
                ((t.flags |= 128),
                (r = !0),
                (n = e.updateQueue),
                n !== null && ((t.updateQueue = n), (t.flags |= 4)),
                kr(o, !0),
                o.tail === null &&
                  o.tailMode === "hidden" &&
                  !i.alternate &&
                  !de)
              )
                return (Ie(t), null);
            } else
              2 * we() - o.renderingStartTime > jn &&
                n !== 1073741824 &&
                ((t.flags |= 128), (r = !0), kr(o, !1), (t.lanes = 4194304));
          o.isBackwards
            ? ((i.sibling = t.child), (t.child = i))
            : ((n = o.last),
              n !== null ? (n.sibling = i) : (t.child = i),
              (o.last = i));
        }
        return o.tail !== null
          ? ((t = o.tail),
            (o.rendering = t),
            (o.tail = t.sibling),
            (o.renderingStartTime = we()),
            (t.sibling = null),
            (n = me.current),
            ae(me, r ? (n & 1) | 2 : n & 1),
            t)
          : (Ie(t), null);
      case 22:
      case 23:
        return (
          Mu(),
          (r = t.memoizedState !== null),
          e !== null && (e.memoizedState !== null) !== r && (t.flags |= 8192),
          r && (t.mode & 1) !== 0
            ? (qe & 1073741824) !== 0 &&
              (Ie(t), t.subtreeFlags & 6 && (t.flags |= 8192))
            : Ie(t),
          null
        );
      case 24:
        return null;
      case 25:
        return null;
    }
    throw Error(a(156, t.tag));
  }
  function ad(e, t) {
    switch ((Wo(t), t.tag)) {
      case 1:
        return (
          He(t.type) && ll(),
          (e = t.flags),
          e & 65536 ? ((t.flags = (e & -65537) | 128), t) : null
        );
      case 3:
        return (
          Dn(),
          ce(Be),
          ce(Me),
          nu(),
          (e = t.flags),
          (e & 65536) !== 0 && (e & 128) === 0
            ? ((t.flags = (e & -65537) | 128), t)
            : null
        );
      case 5:
        return (eu(t), null);
      case 13:
        if (
          (ce(me), (e = t.memoizedState), e !== null && e.dehydrated !== null)
        ) {
          if (t.alternate === null) throw Error(a(340));
          Ln();
        }
        return (
          (e = t.flags),
          e & 65536 ? ((t.flags = (e & -65537) | 128), t) : null
        );
      case 19:
        return (ce(me), null);
      case 4:
        return (Dn(), null);
      case 10:
        return (Go(t.type._context), null);
      case 22:
      case 23:
        return (Mu(), null);
      case 24:
        return null;
      default:
        return null;
    }
  }
  var xl = !1,
    je = !1,
    sd = typeof WeakSet == "function" ? WeakSet : Set,
    I = null;
  function Fn(e, t) {
    var n = e.ref;
    if (n !== null)
      if (typeof n == "function")
        try {
          n(null);
        } catch (r) {
          ge(e, t, r);
        }
      else n.current = null;
  }
  function Eu(e, t, n) {
    try {
      n();
    } catch (r) {
      ge(e, t, r);
    }
  }
  var Ls = !1;
  function cd(e, t) {
    if (((Mo = Vr), (e = ia()), Po(e))) {
      if ("selectionStart" in e)
        var n = { start: e.selectionStart, end: e.selectionEnd };
      else
        e: {
          n = ((n = e.ownerDocument) && n.defaultView) || window;
          var r = n.getSelection && n.getSelection();
          if (r && r.rangeCount !== 0) {
            n = r.anchorNode;
            var l = r.anchorOffset,
              o = r.focusNode;
            r = r.focusOffset;
            try {
              (n.nodeType, o.nodeType);
            } catch {
              n = null;
              break e;
            }
            var i = 0,
              c = -1,
              f = -1,
              w = 0,
              N = 0,
              L = e,
              P = null;
            t: for (;;) {
              for (
                var M;
                L !== n || (l !== 0 && L.nodeType !== 3) || (c = i + l),
                  L !== o || (r !== 0 && L.nodeType !== 3) || (f = i + r),
                  L.nodeType === 3 && (i += L.nodeValue.length),
                  (M = L.firstChild) !== null;
              )
                ((P = L), (L = M));
              for (;;) {
                if (L === e) break t;
                if (
                  (P === n && ++w === l && (c = i),
                  P === o && ++N === r && (f = i),
                  (M = L.nextSibling) !== null)
                )
                  break;
                ((L = P), (P = L.parentNode));
              }
              L = M;
            }
            n = c === -1 || f === -1 ? null : { start: c, end: f };
          } else n = null;
        }
      n = n || { start: 0, end: 0 };
    } else n = null;
    for (
      Fo = { focusedElem: e, selectionRange: n }, Vr = !1, I = t;
      I !== null;
    )
      if (((t = I), (e = t.child), (t.subtreeFlags & 1028) !== 0 && e !== null))
        ((e.return = t), (I = e));
      else
        for (; I !== null;) {
          t = I;
          try {
            var $ = t.alternate;
            if ((t.flags & 1024) !== 0)
              switch (t.tag) {
                case 0:
                case 11:
                case 15:
                  break;
                case 1:
                  if ($ !== null) {
                    var U = $.memoizedProps,
                      Se = $.memoizedState,
                      v = t.stateNode,
                      h = v.getSnapshotBeforeUpdate(
                        t.elementType === t.type ? U : st(t.type, U),
                        Se,
                      );
                    v.__reactInternalSnapshotBeforeUpdate = h;
                  }
                  break;
                case 3:
                  var g = t.stateNode.containerInfo;
                  g.nodeType === 1
                    ? (g.textContent = "")
                    : g.nodeType === 9 &&
                      g.documentElement &&
                      g.removeChild(g.documentElement);
                  break;
                case 5:
                case 6:
                case 4:
                case 17:
                  break;
                default:
                  throw Error(a(163));
              }
          } catch (T) {
            ge(t, t.return, T);
          }
          if (((e = t.sibling), e !== null)) {
            ((e.return = t.return), (I = e));
            break;
          }
          I = t.return;
        }
    return (($ = Ls), (Ls = !1), $);
  }
  function Er(e, t, n) {
    var r = t.updateQueue;
    if (((r = r !== null ? r.lastEffect : null), r !== null)) {
      var l = (r = r.next);
      do {
        if ((l.tag & e) === e) {
          var o = l.destroy;
          ((l.destroy = void 0), o !== void 0 && Eu(t, n, o));
        }
        l = l.next;
      } while (l !== r);
    }
  }
  function _l(e, t) {
    if (
      ((t = t.updateQueue), (t = t !== null ? t.lastEffect : null), t !== null)
    ) {
      var n = (t = t.next);
      do {
        if ((n.tag & e) === e) {
          var r = n.create;
          n.destroy = r();
        }
        n = n.next;
      } while (n !== t);
    }
  }
  function Cu(e) {
    var t = e.ref;
    if (t !== null) {
      var n = e.stateNode;
      switch (e.tag) {
        case 5:
          e = n;
          break;
        default:
          e = n;
      }
      typeof t == "function" ? t(e) : (t.current = e);
    }
  }
  function Ts(e) {
    var t = e.alternate;
    (t !== null && ((e.alternate = null), Ts(t)),
      (e.child = null),
      (e.deletions = null),
      (e.sibling = null),
      e.tag === 5 &&
        ((t = e.stateNode),
        t !== null &&
          (delete t[St],
          delete t[fr],
          delete t[Uo],
          delete t[Kf],
          delete t[Yf])),
      (e.stateNode = null),
      (e.return = null),
      (e.dependencies = null),
      (e.memoizedProps = null),
      (e.memoizedState = null),
      (e.pendingProps = null),
      (e.stateNode = null),
      (e.updateQueue = null));
  }
  function zs(e) {
    return e.tag === 5 || e.tag === 3 || e.tag === 4;
  }
  function Os(e) {
    e: for (;;) {
      for (; e.sibling === null;) {
        if (e.return === null || zs(e.return)) return null;
        e = e.return;
      }
      for (
        e.sibling.return = e.return, e = e.sibling;
        e.tag !== 5 && e.tag !== 6 && e.tag !== 18;
      ) {
        if (e.flags & 2 || e.child === null || e.tag === 4) continue e;
        ((e.child.return = e), (e = e.child));
      }
      if (!(e.flags & 2)) return e.stateNode;
    }
  }
  function xu(e, t, n) {
    var r = e.tag;
    if (r === 5 || r === 6)
      ((e = e.stateNode),
        t
          ? n.nodeType === 8
            ? n.parentNode.insertBefore(e, t)
            : n.insertBefore(e, t)
          : (n.nodeType === 8
              ? ((t = n.parentNode), t.insertBefore(e, n))
              : ((t = n), t.appendChild(e)),
            (n = n._reactRootContainer),
            n != null || t.onclick !== null || (t.onclick = nl)));
    else if (r !== 4 && ((e = e.child), e !== null))
      for (xu(e, t, n), e = e.sibling; e !== null;)
        (xu(e, t, n), (e = e.sibling));
  }
  function _u(e, t, n) {
    var r = e.tag;
    if (r === 5 || r === 6)
      ((e = e.stateNode), t ? n.insertBefore(e, t) : n.appendChild(e));
    else if (r !== 4 && ((e = e.child), e !== null))
      for (_u(e, t, n), e = e.sibling; e !== null;)
        (_u(e, t, n), (e = e.sibling));
  }
  var ze = null,
    ct = !1;
  function Kt(e, t, n) {
    for (n = n.child; n !== null;) (Ds(e, t, n), (n = n.sibling));
  }
  function Ds(e, t, n) {
    if (wt && typeof wt.onCommitFiberUnmount == "function")
      try {
        wt.onCommitFiberUnmount($r, n);
      } catch {}
    switch (n.tag) {
      case 5:
        je || Fn(n, t);
      case 6:
        var r = ze,
          l = ct;
        ((ze = null),
          Kt(e, t, n),
          (ze = r),
          (ct = l),
          ze !== null &&
            (ct
              ? ((e = ze),
                (n = n.stateNode),
                e.nodeType === 8
                  ? e.parentNode.removeChild(n)
                  : e.removeChild(n))
              : ze.removeChild(n.stateNode)));
        break;
      case 18:
        ze !== null &&
          (ct
            ? ((e = ze),
              (n = n.stateNode),
              e.nodeType === 8
                ? $o(e.parentNode, n)
                : e.nodeType === 1 && $o(e, n),
              er(e))
            : $o(ze, n.stateNode));
        break;
      case 4:
        ((r = ze),
          (l = ct),
          (ze = n.stateNode.containerInfo),
          (ct = !0),
          Kt(e, t, n),
          (ze = r),
          (ct = l));
        break;
      case 0:
      case 11:
      case 14:
      case 15:
        if (
          !je &&
          ((r = n.updateQueue), r !== null && ((r = r.lastEffect), r !== null))
        ) {
          l = r = r.next;
          do {
            var o = l,
              i = o.destroy;
            ((o = o.tag),
              i !== void 0 && ((o & 2) !== 0 || (o & 4) !== 0) && Eu(n, t, i),
              (l = l.next));
          } while (l !== r);
        }
        Kt(e, t, n);
        break;
      case 1:
        if (
          !je &&
          (Fn(n, t),
          (r = n.stateNode),
          typeof r.componentWillUnmount == "function")
        )
          try {
            ((r.props = n.memoizedProps),
              (r.state = n.memoizedState),
              r.componentWillUnmount());
          } catch (c) {
            ge(n, t, c);
          }
        Kt(e, t, n);
        break;
      case 21:
        Kt(e, t, n);
        break;
      case 22:
        n.mode & 1
          ? ((je = (r = je) || n.memoizedState !== null), Kt(e, t, n), (je = r))
          : Kt(e, t, n);
        break;
      default:
        Kt(e, t, n);
    }
  }
  function Ms(e) {
    var t = e.updateQueue;
    if (t !== null) {
      e.updateQueue = null;
      var n = e.stateNode;
      (n === null && (n = e.stateNode = new sd()),
        t.forEach(function (r) {
          var l = wd.bind(null, e, r);
          n.has(r) || (n.add(r), r.then(l, l));
        }));
    }
  }
  function ft(e, t) {
    var n = t.deletions;
    if (n !== null)
      for (var r = 0; r < n.length; r++) {
        var l = n[r];
        try {
          var o = e,
            i = t,
            c = i;
          e: for (; c !== null;) {
            switch (c.tag) {
              case 5:
                ((ze = c.stateNode), (ct = !1));
                break e;
              case 3:
                ((ze = c.stateNode.containerInfo), (ct = !0));
                break e;
              case 4:
                ((ze = c.stateNode.containerInfo), (ct = !0));
                break e;
            }
            c = c.return;
          }
          if (ze === null) throw Error(a(160));
          (Ds(o, i, l), (ze = null), (ct = !1));
          var f = l.alternate;
          (f !== null && (f.return = null), (l.return = null));
        } catch (w) {
          ge(l, t, w);
        }
      }
    if (t.subtreeFlags & 12854)
      for (t = t.child; t !== null;) (Fs(t, e), (t = t.sibling));
  }
  function Fs(e, t) {
    var n = e.alternate,
      r = e.flags;
    switch (e.tag) {
      case 0:
      case 11:
      case 14:
      case 15:
        if ((ft(t, e), Ct(e), r & 4)) {
          try {
            (Er(3, e, e.return), _l(3, e));
          } catch (U) {
            ge(e, e.return, U);
          }
          try {
            Er(5, e, e.return);
          } catch (U) {
            ge(e, e.return, U);
          }
        }
        break;
      case 1:
        (ft(t, e), Ct(e), r & 512 && n !== null && Fn(n, n.return));
        break;
      case 5:
        if (
          (ft(t, e),
          Ct(e),
          r & 512 && n !== null && Fn(n, n.return),
          e.flags & 32)
        ) {
          var l = e.stateNode;
          try {
            Wn(l, "");
          } catch (U) {
            ge(e, e.return, U);
          }
        }
        if (r & 4 && ((l = e.stateNode), l != null)) {
          var o = e.memoizedProps,
            i = n !== null ? n.memoizedProps : o,
            c = e.type,
            f = e.updateQueue;
          if (((e.updateQueue = null), f !== null))
            try {
              (c === "input" &&
                o.type === "radio" &&
                o.name != null &&
                si(l, o),
                to(c, i));
              var w = to(c, o);
              for (i = 0; i < f.length; i += 2) {
                var N = f[i],
                  L = f[i + 1];
                N === "style"
                  ? yi(l, L)
                  : N === "dangerouslySetInnerHTML"
                    ? mi(l, L)
                    : N === "children"
                      ? Wn(l, L)
                      : Z(l, N, L, w);
              }
              switch (c) {
                case "input":
                  Jl(l, o);
                  break;
                case "textarea":
                  di(l, o);
                  break;
                case "select":
                  var P = l._wrapperState.wasMultiple;
                  l._wrapperState.wasMultiple = !!o.multiple;
                  var M = o.value;
                  M != null
                    ? hn(l, !!o.multiple, M, !1)
                    : P !== !!o.multiple &&
                      (o.defaultValue != null
                        ? hn(l, !!o.multiple, o.defaultValue, !0)
                        : hn(l, !!o.multiple, o.multiple ? [] : "", !1));
              }
              l[fr] = o;
            } catch (U) {
              ge(e, e.return, U);
            }
        }
        break;
      case 6:
        if ((ft(t, e), Ct(e), r & 4)) {
          if (e.stateNode === null) throw Error(a(162));
          ((l = e.stateNode), (o = e.memoizedProps));
          try {
            l.nodeValue = o;
          } catch (U) {
            ge(e, e.return, U);
          }
        }
        break;
      case 3:
        if (
          (ft(t, e), Ct(e), r & 4 && n !== null && n.memoizedState.isDehydrated)
        )
          try {
            er(t.containerInfo);
          } catch (U) {
            ge(e, e.return, U);
          }
        break;
      case 4:
        (ft(t, e), Ct(e));
        break;
      case 13:
        (ft(t, e),
          Ct(e),
          (l = e.child),
          l.flags & 8192 &&
            ((o = l.memoizedState !== null),
            (l.stateNode.isHidden = o),
            !o ||
              (l.alternate !== null && l.alternate.memoizedState !== null) ||
              (Nu = we())),
          r & 4 && Ms(e));
        break;
      case 22:
        if (
          ((N = n !== null && n.memoizedState !== null),
          e.mode & 1 ? ((je = (w = je) || N), ft(t, e), (je = w)) : ft(t, e),
          Ct(e),
          r & 8192)
        ) {
          if (
            ((w = e.memoizedState !== null),
            (e.stateNode.isHidden = w) && !N && (e.mode & 1) !== 0)
          )
            for (I = e, N = e.child; N !== null;) {
              for (L = I = N; I !== null;) {
                switch (((P = I), (M = P.child), P.tag)) {
                  case 0:
                  case 11:
                  case 14:
                  case 15:
                    Er(4, P, P.return);
                    break;
                  case 1:
                    Fn(P, P.return);
                    var $ = P.stateNode;
                    if (typeof $.componentWillUnmount == "function") {
                      ((r = P), (n = P.return));
                      try {
                        ((t = r),
                          ($.props = t.memoizedProps),
                          ($.state = t.memoizedState),
                          $.componentWillUnmount());
                      } catch (U) {
                        ge(r, n, U);
                      }
                    }
                    break;
                  case 5:
                    Fn(P, P.return);
                    break;
                  case 22:
                    if (P.memoizedState !== null) {
                      $s(L);
                      continue;
                    }
                }
                M !== null ? ((M.return = P), (I = M)) : $s(L);
              }
              N = N.sibling;
            }
          e: for (N = null, L = e; ;) {
            if (L.tag === 5) {
              if (N === null) {
                N = L;
                try {
                  ((l = L.stateNode),
                    w
                      ? ((o = l.style),
                        typeof o.setProperty == "function"
                          ? o.setProperty("display", "none", "important")
                          : (o.display = "none"))
                      : ((c = L.stateNode),
                        (f = L.memoizedProps.style),
                        (i =
                          f != null && f.hasOwnProperty("display")
                            ? f.display
                            : null),
                        (c.style.display = vi("display", i))));
                } catch (U) {
                  ge(e, e.return, U);
                }
              }
            } else if (L.tag === 6) {
              if (N === null)
                try {
                  L.stateNode.nodeValue = w ? "" : L.memoizedProps;
                } catch (U) {
                  ge(e, e.return, U);
                }
            } else if (
              ((L.tag !== 22 && L.tag !== 23) ||
                L.memoizedState === null ||
                L === e) &&
              L.child !== null
            ) {
              ((L.child.return = L), (L = L.child));
              continue;
            }
            if (L === e) break e;
            for (; L.sibling === null;) {
              if (L.return === null || L.return === e) break e;
              (N === L && (N = null), (L = L.return));
            }
            (N === L && (N = null),
              (L.sibling.return = L.return),
              (L = L.sibling));
          }
        }
        break;
      case 19:
        (ft(t, e), Ct(e), r & 4 && Ms(e));
        break;
      case 21:
        break;
      default:
        (ft(t, e), Ct(e));
    }
  }
  function Ct(e) {
    var t = e.flags;
    if (t & 2) {
      try {
        e: {
          for (var n = e.return; n !== null;) {
            if (zs(n)) {
              var r = n;
              break e;
            }
            n = n.return;
          }
          throw Error(a(160));
        }
        switch (r.tag) {
          case 5:
            var l = r.stateNode;
            r.flags & 32 && (Wn(l, ""), (r.flags &= -33));
            var o = Os(e);
            _u(e, o, l);
            break;
          case 3:
          case 4:
            var i = r.stateNode.containerInfo,
              c = Os(e);
            xu(e, c, i);
            break;
          default:
            throw Error(a(161));
        }
      } catch (f) {
        ge(e, e.return, f);
      }
      e.flags &= -3;
    }
    t & 4096 && (e.flags &= -4097);
  }
  function fd(e, t, n) {
    ((I = e), Is(e));
  }
  function Is(e, t, n) {
    for (var r = (e.mode & 1) !== 0; I !== null;) {
      var l = I,
        o = l.child;
      if (l.tag === 22 && r) {
        var i = l.memoizedState !== null || xl;
        if (!i) {
          var c = l.alternate,
            f = (c !== null && c.memoizedState !== null) || je;
          c = xl;
          var w = je;
          if (((xl = i), (je = f) && !w))
            for (I = l; I !== null;)
              ((i = I),
                (f = i.child),
                i.tag === 22 && i.memoizedState !== null
                  ? Us(l)
                  : f !== null
                    ? ((f.return = i), (I = f))
                    : Us(l));
          for (; o !== null;) ((I = o), Is(o), (o = o.sibling));
          ((I = l), (xl = c), (je = w));
        }
        js(e);
      } else
        (l.subtreeFlags & 8772) !== 0 && o !== null
          ? ((o.return = l), (I = o))
          : js(e);
    }
  }
  function js(e) {
    for (; I !== null;) {
      var t = I;
      if ((t.flags & 8772) !== 0) {
        var n = t.alternate;
        try {
          if ((t.flags & 8772) !== 0)
            switch (t.tag) {
              case 0:
              case 11:
              case 15:
                je || _l(5, t);
                break;
              case 1:
                var r = t.stateNode;
                if (t.flags & 4 && !je)
                  if (n === null) r.componentDidMount();
                  else {
                    var l =
                      t.elementType === t.type
                        ? n.memoizedProps
                        : st(t.type, n.memoizedProps);
                    r.componentDidUpdate(
                      l,
                      n.memoizedState,
                      r.__reactInternalSnapshotBeforeUpdate,
                    );
                  }
                var o = t.updateQueue;
                o !== null && $a(t, o, r);
                break;
              case 3:
                var i = t.updateQueue;
                if (i !== null) {
                  if (((n = null), t.child !== null))
                    switch (t.child.tag) {
                      case 5:
                        n = t.child.stateNode;
                        break;
                      case 1:
                        n = t.child.stateNode;
                    }
                  $a(t, i, n);
                }
                break;
              case 5:
                var c = t.stateNode;
                if (n === null && t.flags & 4) {
                  n = c;
                  var f = t.memoizedProps;
                  switch (t.type) {
                    case "button":
                    case "input":
                    case "select":
                    case "textarea":
                      f.autoFocus && n.focus();
                      break;
                    case "img":
                      f.src && (n.src = f.src);
                  }
                }
                break;
              case 6:
                break;
              case 4:
                break;
              case 12:
                break;
              case 13:
                if (t.memoizedState === null) {
                  var w = t.alternate;
                  if (w !== null) {
                    var N = w.memoizedState;
                    if (N !== null) {
                      var L = N.dehydrated;
                      L !== null && er(L);
                    }
                  }
                }
                break;
              case 19:
              case 17:
              case 21:
              case 22:
              case 23:
              case 25:
                break;
              default:
                throw Error(a(163));
            }
          je || (t.flags & 512 && Cu(t));
        } catch (P) {
          ge(t, t.return, P);
        }
      }
      if (t === e) {
        I = null;
        break;
      }
      if (((n = t.sibling), n !== null)) {
        ((n.return = t.return), (I = n));
        break;
      }
      I = t.return;
    }
  }
  function $s(e) {
    for (; I !== null;) {
      var t = I;
      if (t === e) {
        I = null;
        break;
      }
      var n = t.sibling;
      if (n !== null) {
        ((n.return = t.return), (I = n));
        break;
      }
      I = t.return;
    }
  }
  function Us(e) {
    for (; I !== null;) {
      var t = I;
      try {
        switch (t.tag) {
          case 0:
          case 11:
          case 15:
            var n = t.return;
            try {
              _l(4, t);
            } catch (f) {
              ge(t, n, f);
            }
            break;
          case 1:
            var r = t.stateNode;
            if (typeof r.componentDidMount == "function") {
              var l = t.return;
              try {
                r.componentDidMount();
              } catch (f) {
                ge(t, l, f);
              }
            }
            var o = t.return;
            try {
              Cu(t);
            } catch (f) {
              ge(t, o, f);
            }
            break;
          case 5:
            var i = t.return;
            try {
              Cu(t);
            } catch (f) {
              ge(t, i, f);
            }
        }
      } catch (f) {
        ge(t, t.return, f);
      }
      if (t === e) {
        I = null;
        break;
      }
      var c = t.sibling;
      if (c !== null) {
        ((c.return = t.return), (I = c));
        break;
      }
      I = t.return;
    }
  }
  var dd = Math.ceil,
    Pl = ue.ReactCurrentDispatcher,
    Pu = ue.ReactCurrentOwner,
    rt = ue.ReactCurrentBatchConfig,
    ee = 0,
    Ne = null,
    xe = null,
    Oe = 0,
    qe = 0,
    In = Bt(0),
    Pe = 0,
    Cr = null,
    sn = 0,
    Rl = 0,
    Ru = 0,
    xr = null,
    Ve = null,
    Nu = 0,
    jn = 1 / 0,
    zt = null,
    Nl = !1,
    Lu = null,
    Yt = null,
    Ll = !1,
    Xt = null,
    Tl = 0,
    _r = 0,
    Tu = null,
    zl = -1,
    Ol = 0;
  function Ue() {
    return (ee & 6) !== 0 ? we() : zl !== -1 ? zl : (zl = we());
  }
  function Gt(e) {
    return (e.mode & 1) === 0
      ? 1
      : (ee & 2) !== 0 && Oe !== 0
        ? Oe & -Oe
        : Gf.transition !== null
          ? (Ol === 0 && (Ol = Oi()), Ol)
          : ((e = oe),
            e !== 0 ||
              ((e = window.event), (e = e === void 0 ? 16 : Bi(e.type))),
            e);
  }
  function dt(e, t, n, r) {
    if (50 < _r) throw ((_r = 0), (Tu = null), Error(a(185)));
    (Gn(e, n, r),
      ((ee & 2) === 0 || e !== Ne) &&
        (e === Ne && ((ee & 2) === 0 && (Rl |= n), Pe === 4 && Jt(e, Oe)),
        Qe(e, r),
        n === 1 &&
          ee === 0 &&
          (t.mode & 1) === 0 &&
          ((jn = we() + 500), ul && Wt())));
  }
  function Qe(e, t) {
    var n = e.callbackNode;
    Xc(e, t);
    var r = Br(e, e === Ne ? Oe : 0);
    if (r === 0)
      (n !== null && Li(n), (e.callbackNode = null), (e.callbackPriority = 0));
    else if (((t = r & -r), e.callbackPriority !== t)) {
      if ((n != null && Li(n), t === 1))
        (e.tag === 0 ? Xf(Bs.bind(null, e)) : Pa(Bs.bind(null, e)),
          Vf(function () {
            (ee & 6) === 0 && Wt();
          }),
          (n = null));
      else {
        switch (Di(r)) {
          case 1:
            n = ao;
            break;
          case 4:
            n = Ti;
            break;
          case 16:
            n = jr;
            break;
          case 536870912:
            n = zi;
            break;
          default:
            n = jr;
        }
        n = Gs(n, As.bind(null, e));
      }
      ((e.callbackPriority = t), (e.callbackNode = n));
    }
  }
  function As(e, t) {
    if (((zl = -1), (Ol = 0), (ee & 6) !== 0)) throw Error(a(327));
    var n = e.callbackNode;
    if ($n() && e.callbackNode !== n) return null;
    var r = Br(e, e === Ne ? Oe : 0);
    if (r === 0) return null;
    if ((r & 30) !== 0 || (r & e.expiredLanes) !== 0 || t) t = Dl(e, r);
    else {
      t = r;
      var l = ee;
      ee |= 2;
      var o = Ws();
      (Ne !== e || Oe !== t) && ((zt = null), (jn = we() + 500), fn(e, t));
      do
        try {
          md();
          break;
        } catch (c) {
          Hs(e, c);
        }
      while (!0);
      (Xo(),
        (Pl.current = o),
        (ee = l),
        xe !== null ? (t = 0) : ((Ne = null), (Oe = 0), (t = Pe)));
    }
    if (t !== 0) {
      if (
        (t === 2 && ((l = so(e)), l !== 0 && ((r = l), (t = zu(e, l)))),
        t === 1)
      )
        throw ((n = Cr), fn(e, 0), Jt(e, r), Qe(e, we()), n);
      if (t === 6) Jt(e, r);
      else {
        if (
          ((l = e.current.alternate),
          (r & 30) === 0 &&
            !pd(l) &&
            ((t = Dl(e, r)),
            t === 2 && ((o = so(e)), o !== 0 && ((r = o), (t = zu(e, o)))),
            t === 1))
        )
          throw ((n = Cr), fn(e, 0), Jt(e, r), Qe(e, we()), n);
        switch (((e.finishedWork = l), (e.finishedLanes = r), t)) {
          case 0:
          case 1:
            throw Error(a(345));
          case 2:
            dn(e, Ve, zt);
            break;
          case 3:
            if (
              (Jt(e, r),
              (r & 130023424) === r && ((t = Nu + 500 - we()), 10 < t))
            ) {
              if (Br(e, 0) !== 0) break;
              if (((l = e.suspendedLanes), (l & r) !== r)) {
                (Ue(), (e.pingedLanes |= e.suspendedLanes & l));
                break;
              }
              e.timeoutHandle = jo(dn.bind(null, e, Ve, zt), t);
              break;
            }
            dn(e, Ve, zt);
            break;
          case 4:
            if ((Jt(e, r), (r & 4194240) === r)) break;
            for (t = e.eventTimes, l = -1; 0 < r;) {
              var i = 31 - ut(r);
              ((o = 1 << i), (i = t[i]), i > l && (l = i), (r &= ~o));
            }
            if (
              ((r = l),
              (r = we() - r),
              (r =
                (120 > r
                  ? 120
                  : 480 > r
                    ? 480
                    : 1080 > r
                      ? 1080
                      : 1920 > r
                        ? 1920
                        : 3e3 > r
                          ? 3e3
                          : 4320 > r
                            ? 4320
                            : 1960 * dd(r / 1960)) - r),
              10 < r)
            ) {
              e.timeoutHandle = jo(dn.bind(null, e, Ve, zt), r);
              break;
            }
            dn(e, Ve, zt);
            break;
          case 5:
            dn(e, Ve, zt);
            break;
          default:
            throw Error(a(329));
        }
      }
    }
    return (Qe(e, we()), e.callbackNode === n ? As.bind(null, e) : null);
  }
  function zu(e, t) {
    var n = xr;
    return (
      e.current.memoizedState.isDehydrated && (fn(e, t).flags |= 256),
      (e = Dl(e, t)),
      e !== 2 && ((t = Ve), (Ve = n), t !== null && Ou(t)),
      e
    );
  }
  function Ou(e) {
    Ve === null ? (Ve = e) : Ve.push.apply(Ve, e);
  }
  function pd(e) {
    for (var t = e; ;) {
      if (t.flags & 16384) {
        var n = t.updateQueue;
        if (n !== null && ((n = n.stores), n !== null))
          for (var r = 0; r < n.length; r++) {
            var l = n[r],
              o = l.getSnapshot;
            l = l.value;
            try {
              if (!it(o(), l)) return !1;
            } catch {
              return !1;
            }
          }
      }
      if (((n = t.child), t.subtreeFlags & 16384 && n !== null))
        ((n.return = t), (t = n));
      else {
        if (t === e) break;
        for (; t.sibling === null;) {
          if (t.return === null || t.return === e) return !0;
          t = t.return;
        }
        ((t.sibling.return = t.return), (t = t.sibling));
      }
    }
    return !0;
  }
  function Jt(e, t) {
    for (
      t &= ~Ru,
        t &= ~Rl,
        e.suspendedLanes |= t,
        e.pingedLanes &= ~t,
        e = e.expirationTimes;
      0 < t;
    ) {
      var n = 31 - ut(t),
        r = 1 << n;
      ((e[n] = -1), (t &= ~r));
    }
  }
  function Bs(e) {
    if ((ee & 6) !== 0) throw Error(a(327));
    $n();
    var t = Br(e, 0);
    if ((t & 1) === 0) return (Qe(e, we()), null);
    var n = Dl(e, t);
    if (e.tag !== 0 && n === 2) {
      var r = so(e);
      r !== 0 && ((t = r), (n = zu(e, r)));
    }
    if (n === 1) throw ((n = Cr), fn(e, 0), Jt(e, t), Qe(e, we()), n);
    if (n === 6) throw Error(a(345));
    return (
      (e.finishedWork = e.current.alternate),
      (e.finishedLanes = t),
      dn(e, Ve, zt),
      Qe(e, we()),
      null
    );
  }
  function Du(e, t) {
    var n = ee;
    ee |= 1;
    try {
      return e(t);
    } finally {
      ((ee = n), ee === 0 && ((jn = we() + 500), ul && Wt()));
    }
  }
  function cn(e) {
    Xt !== null && Xt.tag === 0 && (ee & 6) === 0 && $n();
    var t = ee;
    ee |= 1;
    var n = rt.transition,
      r = oe;
    try {
      if (((rt.transition = null), (oe = 1), e)) return e();
    } finally {
      ((oe = r), (rt.transition = n), (ee = t), (ee & 6) === 0 && Wt());
    }
  }
  function Mu() {
    ((qe = In.current), ce(In));
  }
  function fn(e, t) {
    ((e.finishedWork = null), (e.finishedLanes = 0));
    var n = e.timeoutHandle;
    if ((n !== -1 && ((e.timeoutHandle = -1), Wf(n)), xe !== null))
      for (n = xe.return; n !== null;) {
        var r = n;
        switch ((Wo(r), r.tag)) {
          case 1:
            ((r = r.type.childContextTypes), r != null && ll());
            break;
          case 3:
            (Dn(), ce(Be), ce(Me), nu());
            break;
          case 5:
            eu(r);
            break;
          case 4:
            Dn();
            break;
          case 13:
            ce(me);
            break;
          case 19:
            ce(me);
            break;
          case 10:
            Go(r.type._context);
            break;
          case 22:
          case 23:
            Mu();
        }
        n = n.return;
      }
    if (
      ((Ne = e),
      (xe = e = Zt(e.current, null)),
      (Oe = qe = t),
      (Pe = 0),
      (Cr = null),
      (Ru = Rl = sn = 0),
      (Ve = xr = null),
      on !== null)
    ) {
      for (t = 0; t < on.length; t++)
        if (((n = on[t]), (r = n.interleaved), r !== null)) {
          n.interleaved = null;
          var l = r.next,
            o = n.pending;
          if (o !== null) {
            var i = o.next;
            ((o.next = l), (r.next = i));
          }
          n.pending = r;
        }
      on = null;
    }
    return e;
  }
  function Hs(e, t) {
    do {
      var n = xe;
      try {
        if ((Xo(), (vl.current = Sl), yl)) {
          for (var r = ve.memoizedState; r !== null;) {
            var l = r.queue;
            (l !== null && (l.pending = null), (r = r.next));
          }
          yl = !1;
        }
        if (
          ((an = 0),
          (Re = _e = ve = null),
          (yr = !1),
          (gr = 0),
          (Pu.current = null),
          n === null || n.return === null)
        ) {
          ((Pe = 1), (Cr = t), (xe = null));
          break;
        }
        e: {
          var o = e,
            i = n.return,
            c = n,
            f = t;
          if (
            ((t = Oe),
            (c.flags |= 32768),
            f !== null && typeof f == "object" && typeof f.then == "function")
          ) {
            var w = f,
              N = c,
              L = N.tag;
            if ((N.mode & 1) === 0 && (L === 0 || L === 11 || L === 15)) {
              var P = N.alternate;
              P
                ? ((N.updateQueue = P.updateQueue),
                  (N.memoizedState = P.memoizedState),
                  (N.lanes = P.lanes))
                : ((N.updateQueue = null), (N.memoizedState = null));
            }
            var M = ps(i);
            if (M !== null) {
              ((M.flags &= -257),
                hs(M, i, c, o, t),
                M.mode & 1 && ds(o, w, t),
                (t = M),
                (f = w));
              var $ = t.updateQueue;
              if ($ === null) {
                var U = new Set();
                (U.add(f), (t.updateQueue = U));
              } else $.add(f);
              break e;
            } else {
              if ((t & 1) === 0) {
                (ds(o, w, t), Fu());
                break e;
              }
              f = Error(a(426));
            }
          } else if (de && c.mode & 1) {
            var Se = ps(i);
            if (Se !== null) {
              ((Se.flags & 65536) === 0 && (Se.flags |= 256),
                hs(Se, i, c, o, t),
                Ko(Mn(f, c)));
              break e;
            }
          }
          ((o = f = Mn(f, c)),
            Pe !== 4 && (Pe = 2),
            xr === null ? (xr = [o]) : xr.push(o),
            (o = i));
          do {
            switch (o.tag) {
              case 3:
                ((o.flags |= 65536), (t &= -t), (o.lanes |= t));
                var v = cs(o, f, t);
                ja(o, v);
                break e;
              case 1:
                c = f;
                var h = o.type,
                  g = o.stateNode;
                if (
                  (o.flags & 128) === 0 &&
                  (typeof h.getDerivedStateFromError == "function" ||
                    (g !== null &&
                      typeof g.componentDidCatch == "function" &&
                      (Yt === null || !Yt.has(g))))
                ) {
                  ((o.flags |= 65536), (t &= -t), (o.lanes |= t));
                  var T = fs(o, c, t);
                  ja(o, T);
                  break e;
                }
            }
            o = o.return;
          } while (o !== null);
        }
        Qs(n);
      } catch (B) {
        ((t = B), xe === n && n !== null && (xe = n = n.return));
        continue;
      }
      break;
    } while (!0);
  }
  function Ws() {
    var e = Pl.current;
    return ((Pl.current = Sl), e === null ? Sl : e);
  }
  function Fu() {
    ((Pe === 0 || Pe === 3 || Pe === 2) && (Pe = 4),
      Ne === null ||
        ((sn & 268435455) === 0 && (Rl & 268435455) === 0) ||
        Jt(Ne, Oe));
  }
  function Dl(e, t) {
    var n = ee;
    ee |= 2;
    var r = Ws();
    (Ne !== e || Oe !== t) && ((zt = null), fn(e, t));
    do
      try {
        hd();
        break;
      } catch (l) {
        Hs(e, l);
      }
    while (!0);
    if ((Xo(), (ee = n), (Pl.current = r), xe !== null)) throw Error(a(261));
    return ((Ne = null), (Oe = 0), Pe);
  }
  function hd() {
    for (; xe !== null;) Vs(xe);
  }
  function md() {
    for (; xe !== null && !Uc();) Vs(xe);
  }
  function Vs(e) {
    var t = Xs(e.alternate, e, qe);
    ((e.memoizedProps = e.pendingProps),
      t === null ? Qs(e) : (xe = t),
      (Pu.current = null));
  }
  function Qs(e) {
    var t = e;
    do {
      var n = t.alternate;
      if (((e = t.return), (t.flags & 32768) === 0)) {
        if (((n = id(n, t, qe)), n !== null)) {
          xe = n;
          return;
        }
      } else {
        if (((n = ad(n, t)), n !== null)) {
          ((n.flags &= 32767), (xe = n));
          return;
        }
        if (e !== null)
          ((e.flags |= 32768), (e.subtreeFlags = 0), (e.deletions = null));
        else {
          ((Pe = 6), (xe = null));
          return;
        }
      }
      if (((t = t.sibling), t !== null)) {
        xe = t;
        return;
      }
      xe = t = e;
    } while (t !== null);
    Pe === 0 && (Pe = 5);
  }
  function dn(e, t, n) {
    var r = oe,
      l = rt.transition;
    try {
      ((rt.transition = null), (oe = 1), vd(e, t, n, r));
    } finally {
      ((rt.transition = l), (oe = r));
    }
    return null;
  }
  function vd(e, t, n, r) {
    do $n();
    while (Xt !== null);
    if ((ee & 6) !== 0) throw Error(a(327));
    n = e.finishedWork;
    var l = e.finishedLanes;
    if (n === null) return null;
    if (((e.finishedWork = null), (e.finishedLanes = 0), n === e.current))
      throw Error(a(177));
    ((e.callbackNode = null), (e.callbackPriority = 0));
    var o = n.lanes | n.childLanes;
    if (
      (Gc(e, o),
      e === Ne && ((xe = Ne = null), (Oe = 0)),
      ((n.subtreeFlags & 2064) === 0 && (n.flags & 2064) === 0) ||
        Ll ||
        ((Ll = !0),
        Gs(jr, function () {
          return ($n(), null);
        })),
      (o = (n.flags & 15990) !== 0),
      (n.subtreeFlags & 15990) !== 0 || o)
    ) {
      ((o = rt.transition), (rt.transition = null));
      var i = oe;
      oe = 1;
      var c = ee;
      ((ee |= 4),
        (Pu.current = null),
        cd(e, n),
        Fs(n, e),
        If(Fo),
        (Vr = !!Mo),
        (Fo = Mo = null),
        (e.current = n),
        fd(n),
        Ac(),
        (ee = c),
        (oe = i),
        (rt.transition = o));
    } else e.current = n;
    if (
      (Ll && ((Ll = !1), (Xt = e), (Tl = l)),
      (o = e.pendingLanes),
      o === 0 && (Yt = null),
      Wc(n.stateNode),
      Qe(e, we()),
      t !== null)
    )
      for (r = e.onRecoverableError, n = 0; n < t.length; n++)
        ((l = t[n]), r(l.value, { componentStack: l.stack, digest: l.digest }));
    if (Nl) throw ((Nl = !1), (e = Lu), (Lu = null), e);
    return (
      (Tl & 1) !== 0 && e.tag !== 0 && $n(),
      (o = e.pendingLanes),
      (o & 1) !== 0 ? (e === Tu ? _r++ : ((_r = 0), (Tu = e))) : (_r = 0),
      Wt(),
      null
    );
  }
  function $n() {
    if (Xt !== null) {
      var e = Di(Tl),
        t = rt.transition,
        n = oe;
      try {
        if (((rt.transition = null), (oe = 16 > e ? 16 : e), Xt === null))
          var r = !1;
        else {
          if (((e = Xt), (Xt = null), (Tl = 0), (ee & 6) !== 0))
            throw Error(a(331));
          var l = ee;
          for (ee |= 4, I = e.current; I !== null;) {
            var o = I,
              i = o.child;
            if ((I.flags & 16) !== 0) {
              var c = o.deletions;
              if (c !== null) {
                for (var f = 0; f < c.length; f++) {
                  var w = c[f];
                  for (I = w; I !== null;) {
                    var N = I;
                    switch (N.tag) {
                      case 0:
                      case 11:
                      case 15:
                        Er(8, N, o);
                    }
                    var L = N.child;
                    if (L !== null) ((L.return = N), (I = L));
                    else
                      for (; I !== null;) {
                        N = I;
                        var P = N.sibling,
                          M = N.return;
                        if ((Ts(N), N === w)) {
                          I = null;
                          break;
                        }
                        if (P !== null) {
                          ((P.return = M), (I = P));
                          break;
                        }
                        I = M;
                      }
                  }
                }
                var $ = o.alternate;
                if ($ !== null) {
                  var U = $.child;
                  if (U !== null) {
                    $.child = null;
                    do {
                      var Se = U.sibling;
                      ((U.sibling = null), (U = Se));
                    } while (U !== null);
                  }
                }
                I = o;
              }
            }
            if ((o.subtreeFlags & 2064) !== 0 && i !== null)
              ((i.return = o), (I = i));
            else
              e: for (; I !== null;) {
                if (((o = I), (o.flags & 2048) !== 0))
                  switch (o.tag) {
                    case 0:
                    case 11:
                    case 15:
                      Er(9, o, o.return);
                  }
                var v = o.sibling;
                if (v !== null) {
                  ((v.return = o.return), (I = v));
                  break e;
                }
                I = o.return;
              }
          }
          var h = e.current;
          for (I = h; I !== null;) {
            i = I;
            var g = i.child;
            if ((i.subtreeFlags & 2064) !== 0 && g !== null)
              ((g.return = i), (I = g));
            else
              e: for (i = h; I !== null;) {
                if (((c = I), (c.flags & 2048) !== 0))
                  try {
                    switch (c.tag) {
                      case 0:
                      case 11:
                      case 15:
                        _l(9, c);
                    }
                  } catch (B) {
                    ge(c, c.return, B);
                  }
                if (c === i) {
                  I = null;
                  break e;
                }
                var T = c.sibling;
                if (T !== null) {
                  ((T.return = c.return), (I = T));
                  break e;
                }
                I = c.return;
              }
          }
          if (
            ((ee = l),
            Wt(),
            wt && typeof wt.onPostCommitFiberRoot == "function")
          )
            try {
              wt.onPostCommitFiberRoot($r, e);
            } catch {}
          r = !0;
        }
        return r;
      } finally {
        ((oe = n), (rt.transition = t));
      }
    }
    return !1;
  }
  function Ks(e, t, n) {
    ((t = Mn(n, t)),
      (t = cs(e, t, 1)),
      (e = Qt(e, t, 1)),
      (t = Ue()),
      e !== null && (Gn(e, 1, t), Qe(e, t)));
  }
  function ge(e, t, n) {
    if (e.tag === 3) Ks(e, e, n);
    else
      for (; t !== null;) {
        if (t.tag === 3) {
          Ks(t, e, n);
          break;
        } else if (t.tag === 1) {
          var r = t.stateNode;
          if (
            typeof t.type.getDerivedStateFromError == "function" ||
            (typeof r.componentDidCatch == "function" &&
              (Yt === null || !Yt.has(r)))
          ) {
            ((e = Mn(n, e)),
              (e = fs(t, e, 1)),
              (t = Qt(t, e, 1)),
              (e = Ue()),
              t !== null && (Gn(t, 1, e), Qe(t, e)));
            break;
          }
        }
        t = t.return;
      }
  }
  function yd(e, t, n) {
    var r = e.pingCache;
    (r !== null && r.delete(t),
      (t = Ue()),
      (e.pingedLanes |= e.suspendedLanes & n),
      Ne === e &&
        (Oe & n) === n &&
        (Pe === 4 || (Pe === 3 && (Oe & 130023424) === Oe && 500 > we() - Nu)
          ? fn(e, 0)
          : (Ru |= n)),
      Qe(e, t));
  }
  function Ys(e, t) {
    t === 0 &&
      ((e.mode & 1) === 0
        ? (t = 1)
        : ((t = Ar), (Ar <<= 1), (Ar & 130023424) === 0 && (Ar = 4194304)));
    var n = Ue();
    ((e = Nt(e, t)), e !== null && (Gn(e, t, n), Qe(e, n)));
  }
  function gd(e) {
    var t = e.memoizedState,
      n = 0;
    (t !== null && (n = t.retryLane), Ys(e, n));
  }
  function wd(e, t) {
    var n = 0;
    switch (e.tag) {
      case 13:
        var r = e.stateNode,
          l = e.memoizedState;
        l !== null && (n = l.retryLane);
        break;
      case 19:
        r = e.stateNode;
        break;
      default:
        throw Error(a(314));
    }
    (r !== null && r.delete(t), Ys(e, n));
  }
  var Xs;
  Xs = function (e, t, n) {
    if (e !== null)
      if (e.memoizedProps !== t.pendingProps || Be.current) We = !0;
      else {
        if ((e.lanes & n) === 0 && (t.flags & 128) === 0)
          return ((We = !1), ud(e, t, n));
        We = (e.flags & 131072) !== 0;
      }
    else ((We = !1), de && (t.flags & 1048576) !== 0 && Ra(t, al, t.index));
    switch (((t.lanes = 0), t.tag)) {
      case 2:
        var r = t.type;
        (Cl(e, t), (e = t.pendingProps));
        var l = Pn(t, Me.current);
        (On(t, n), (l = ou(null, t, r, e, l, n)));
        var o = uu();
        return (
          (t.flags |= 1),
          typeof l == "object" &&
          l !== null &&
          typeof l.render == "function" &&
          l.$$typeof === void 0
            ? ((t.tag = 1),
              (t.memoizedState = null),
              (t.updateQueue = null),
              He(r) ? ((o = !0), ol(t)) : (o = !1),
              (t.memoizedState =
                l.state !== null && l.state !== void 0 ? l.state : null),
              qo(t),
              (l.updater = kl),
              (t.stateNode = l),
              (l._reactInternals = t),
              du(t, r, e, n),
              (t = vu(null, t, r, !0, o, n)))
            : ((t.tag = 0), de && o && Ho(t), $e(null, t, l, n), (t = t.child)),
          t
        );
      case 16:
        r = t.elementType;
        e: {
          switch (
            (Cl(e, t),
            (e = t.pendingProps),
            (l = r._init),
            (r = l(r._payload)),
            (t.type = r),
            (l = t.tag = kd(r)),
            (e = st(r, e)),
            l)
          ) {
            case 0:
              t = mu(null, t, r, e, n);
              break e;
            case 1:
              t = Ss(null, t, r, e, n);
              break e;
            case 11:
              t = ms(null, t, r, e, n);
              break e;
            case 14:
              t = vs(null, t, r, st(r.type, e), n);
              break e;
          }
          throw Error(a(306, r, ""));
        }
        return t;
      case 0:
        return (
          (r = t.type),
          (l = t.pendingProps),
          (l = t.elementType === r ? l : st(r, l)),
          mu(e, t, r, l, n)
        );
      case 1:
        return (
          (r = t.type),
          (l = t.pendingProps),
          (l = t.elementType === r ? l : st(r, l)),
          Ss(e, t, r, l, n)
        );
      case 3:
        e: {
          if ((ks(t), e === null)) throw Error(a(387));
          ((r = t.pendingProps),
            (o = t.memoizedState),
            (l = o.element),
            Ia(e, t),
            hl(t, r, null, n));
          var i = t.memoizedState;
          if (((r = i.element), o.isDehydrated))
            if (
              ((o = {
                element: r,
                isDehydrated: !1,
                cache: i.cache,
                pendingSuspenseBoundaries: i.pendingSuspenseBoundaries,
                transitions: i.transitions,
              }),
              (t.updateQueue.baseState = o),
              (t.memoizedState = o),
              t.flags & 256)
            ) {
              ((l = Mn(Error(a(423)), t)), (t = Es(e, t, r, n, l)));
              break e;
            } else if (r !== l) {
              ((l = Mn(Error(a(424)), t)), (t = Es(e, t, r, n, l)));
              break e;
            } else
              for (
                Ze = At(t.stateNode.containerInfo.firstChild),
                  Je = t,
                  de = !0,
                  at = null,
                  n = Ma(t, null, r, n),
                  t.child = n;
                n;
              )
                ((n.flags = (n.flags & -3) | 4096), (n = n.sibling));
          else {
            if ((Ln(), r === l)) {
              t = Tt(e, t, n);
              break e;
            }
            $e(e, t, r, n);
          }
          t = t.child;
        }
        return t;
      case 5:
        return (
          Ua(t),
          e === null && Qo(t),
          (r = t.type),
          (l = t.pendingProps),
          (o = e !== null ? e.memoizedProps : null),
          (i = l.children),
          Io(r, l) ? (i = null) : o !== null && Io(r, o) && (t.flags |= 32),
          ws(e, t),
          $e(e, t, i, n),
          t.child
        );
      case 6:
        return (e === null && Qo(t), null);
      case 13:
        return Cs(e, t, n);
      case 4:
        return (
          bo(t, t.stateNode.containerInfo),
          (r = t.pendingProps),
          e === null ? (t.child = Tn(t, null, r, n)) : $e(e, t, r, n),
          t.child
        );
      case 11:
        return (
          (r = t.type),
          (l = t.pendingProps),
          (l = t.elementType === r ? l : st(r, l)),
          ms(e, t, r, l, n)
        );
      case 7:
        return ($e(e, t, t.pendingProps, n), t.child);
      case 8:
        return ($e(e, t, t.pendingProps.children, n), t.child);
      case 12:
        return ($e(e, t, t.pendingProps.children, n), t.child);
      case 10:
        e: {
          if (
            ((r = t.type._context),
            (l = t.pendingProps),
            (o = t.memoizedProps),
            (i = l.value),
            ae(fl, r._currentValue),
            (r._currentValue = i),
            o !== null)
          )
            if (it(o.value, i)) {
              if (o.children === l.children && !Be.current) {
                t = Tt(e, t, n);
                break e;
              }
            } else
              for (o = t.child, o !== null && (o.return = t); o !== null;) {
                var c = o.dependencies;
                if (c !== null) {
                  i = o.child;
                  for (var f = c.firstContext; f !== null;) {
                    if (f.context === r) {
                      if (o.tag === 1) {
                        ((f = Lt(-1, n & -n)), (f.tag = 2));
                        var w = o.updateQueue;
                        if (w !== null) {
                          w = w.shared;
                          var N = w.pending;
                          (N === null
                            ? (f.next = f)
                            : ((f.next = N.next), (N.next = f)),
                            (w.pending = f));
                        }
                      }
                      ((o.lanes |= n),
                        (f = o.alternate),
                        f !== null && (f.lanes |= n),
                        Jo(o.return, n, t),
                        (c.lanes |= n));
                      break;
                    }
                    f = f.next;
                  }
                } else if (o.tag === 10) i = o.type === t.type ? null : o.child;
                else if (o.tag === 18) {
                  if (((i = o.return), i === null)) throw Error(a(341));
                  ((i.lanes |= n),
                    (c = i.alternate),
                    c !== null && (c.lanes |= n),
                    Jo(i, n, t),
                    (i = o.sibling));
                } else i = o.child;
                if (i !== null) i.return = o;
                else
                  for (i = o; i !== null;) {
                    if (i === t) {
                      i = null;
                      break;
                    }
                    if (((o = i.sibling), o !== null)) {
                      ((o.return = i.return), (i = o));
                      break;
                    }
                    i = i.return;
                  }
                o = i;
              }
          ($e(e, t, l.children, n), (t = t.child));
        }
        return t;
      case 9:
        return (
          (l = t.type),
          (r = t.pendingProps.children),
          On(t, n),
          (l = tt(l)),
          (r = r(l)),
          (t.flags |= 1),
          $e(e, t, r, n),
          t.child
        );
      case 14:
        return (
          (r = t.type),
          (l = st(r, t.pendingProps)),
          (l = st(r.type, l)),
          vs(e, t, r, l, n)
        );
      case 15:
        return ys(e, t, t.type, t.pendingProps, n);
      case 17:
        return (
          (r = t.type),
          (l = t.pendingProps),
          (l = t.elementType === r ? l : st(r, l)),
          Cl(e, t),
          (t.tag = 1),
          He(r) ? ((e = !0), ol(t)) : (e = !1),
          On(t, n),
          as(t, r, l),
          du(t, r, l, n),
          vu(null, t, r, !0, e, n)
        );
      case 19:
        return _s(e, t, n);
      case 22:
        return gs(e, t, n);
    }
    throw Error(a(156, t.tag));
  };
  function Gs(e, t) {
    return Ni(e, t);
  }
  function Sd(e, t, n, r) {
    ((this.tag = e),
      (this.key = n),
      (this.sibling =
        this.child =
        this.return =
        this.stateNode =
        this.type =
        this.elementType =
          null),
      (this.index = 0),
      (this.ref = null),
      (this.pendingProps = t),
      (this.dependencies =
        this.memoizedState =
        this.updateQueue =
        this.memoizedProps =
          null),
      (this.mode = r),
      (this.subtreeFlags = this.flags = 0),
      (this.deletions = null),
      (this.childLanes = this.lanes = 0),
      (this.alternate = null));
  }
  function lt(e, t, n, r) {
    return new Sd(e, t, n, r);
  }
  function Iu(e) {
    return ((e = e.prototype), !(!e || !e.isReactComponent));
  }
  function kd(e) {
    if (typeof e == "function") return Iu(e) ? 1 : 0;
    if (e != null) {
      if (((e = e.$$typeof), e === yt)) return 11;
      if (e === gt) return 14;
    }
    return 2;
  }
  function Zt(e, t) {
    var n = e.alternate;
    return (
      n === null
        ? ((n = lt(e.tag, t, e.key, e.mode)),
          (n.elementType = e.elementType),
          (n.type = e.type),
          (n.stateNode = e.stateNode),
          (n.alternate = e),
          (e.alternate = n))
        : ((n.pendingProps = t),
          (n.type = e.type),
          (n.flags = 0),
          (n.subtreeFlags = 0),
          (n.deletions = null)),
      (n.flags = e.flags & 14680064),
      (n.childLanes = e.childLanes),
      (n.lanes = e.lanes),
      (n.child = e.child),
      (n.memoizedProps = e.memoizedProps),
      (n.memoizedState = e.memoizedState),
      (n.updateQueue = e.updateQueue),
      (t = e.dependencies),
      (n.dependencies =
        t === null ? null : { lanes: t.lanes, firstContext: t.firstContext }),
      (n.sibling = e.sibling),
      (n.index = e.index),
      (n.ref = e.ref),
      n
    );
  }
  function Ml(e, t, n, r, l, o) {
    var i = 2;
    if (((r = e), typeof e == "function")) Iu(e) && (i = 1);
    else if (typeof e == "string") i = 5;
    else
      e: switch (e) {
        case Ee:
          return pn(n.children, l, o, t);
        case Te:
          ((i = 8), (l |= 8));
          break;
        case Ce:
          return (
            (e = lt(12, n, t, l | 2)),
            (e.elementType = Ce),
            (e.lanes = o),
            e
          );
        case Ye:
          return (
            (e = lt(13, n, t, l)),
            (e.elementType = Ye),
            (e.lanes = o),
            e
          );
        case ot:
          return (
            (e = lt(19, n, t, l)),
            (e.elementType = ot),
            (e.lanes = o),
            e
          );
        case ye:
          return Fl(n, l, o, t);
        default:
          if (typeof e == "object" && e !== null)
            switch (e.$$typeof) {
              case De:
                i = 10;
                break e;
              case vt:
                i = 9;
                break e;
              case yt:
                i = 11;
                break e;
              case gt:
                i = 14;
                break e;
              case Ae:
                ((i = 16), (r = null));
                break e;
            }
          throw Error(a(130, e == null ? e : typeof e, ""));
      }
    return (
      (t = lt(i, n, t, l)),
      (t.elementType = e),
      (t.type = r),
      (t.lanes = o),
      t
    );
  }
  function pn(e, t, n, r) {
    return ((e = lt(7, e, r, t)), (e.lanes = n), e);
  }
  function Fl(e, t, n, r) {
    return (
      (e = lt(22, e, r, t)),
      (e.elementType = ye),
      (e.lanes = n),
      (e.stateNode = { isHidden: !1 }),
      e
    );
  }
  function ju(e, t, n) {
    return ((e = lt(6, e, null, t)), (e.lanes = n), e);
  }
  function $u(e, t, n) {
    return (
      (t = lt(4, e.children !== null ? e.children : [], e.key, t)),
      (t.lanes = n),
      (t.stateNode = {
        containerInfo: e.containerInfo,
        pendingChildren: null,
        implementation: e.implementation,
      }),
      t
    );
  }
  function Ed(e, t, n, r, l) {
    ((this.tag = t),
      (this.containerInfo = e),
      (this.finishedWork =
        this.pingCache =
        this.current =
        this.pendingChildren =
          null),
      (this.timeoutHandle = -1),
      (this.callbackNode = this.pendingContext = this.context = null),
      (this.callbackPriority = 0),
      (this.eventTimes = co(0)),
      (this.expirationTimes = co(-1)),
      (this.entangledLanes =
        this.finishedLanes =
        this.mutableReadLanes =
        this.expiredLanes =
        this.pingedLanes =
        this.suspendedLanes =
        this.pendingLanes =
          0),
      (this.entanglements = co(0)),
      (this.identifierPrefix = r),
      (this.onRecoverableError = l),
      (this.mutableSourceEagerHydrationData = null));
  }
  function Uu(e, t, n, r, l, o, i, c, f) {
    return (
      (e = new Ed(e, t, n, c, f)),
      t === 1 ? ((t = 1), o === !0 && (t |= 8)) : (t = 0),
      (o = lt(3, null, null, t)),
      (e.current = o),
      (o.stateNode = e),
      (o.memoizedState = {
        element: r,
        isDehydrated: n,
        cache: null,
        transitions: null,
        pendingSuspenseBoundaries: null,
      }),
      qo(o),
      e
    );
  }
  function Cd(e, t, n) {
    var r =
      3 < arguments.length && arguments[3] !== void 0 ? arguments[3] : null;
    return {
      $$typeof: ke,
      key: r == null ? null : "" + r,
      children: e,
      containerInfo: t,
      implementation: n,
    };
  }
  function Js(e) {
    if (!e) return Ht;
    e = e._reactInternals;
    e: {
      if (en(e) !== e || e.tag !== 1) throw Error(a(170));
      var t = e;
      do {
        switch (t.tag) {
          case 3:
            t = t.stateNode.context;
            break e;
          case 1:
            if (He(t.type)) {
              t = t.stateNode.__reactInternalMemoizedMergedChildContext;
              break e;
            }
        }
        t = t.return;
      } while (t !== null);
      throw Error(a(171));
    }
    if (e.tag === 1) {
      var n = e.type;
      if (He(n)) return xa(e, n, t);
    }
    return t;
  }
  function Zs(e, t, n, r, l, o, i, c, f) {
    return (
      (e = Uu(n, r, !0, e, l, o, i, c, f)),
      (e.context = Js(null)),
      (n = e.current),
      (r = Ue()),
      (l = Gt(n)),
      (o = Lt(r, l)),
      (o.callback = t ?? null),
      Qt(n, o, l),
      (e.current.lanes = l),
      Gn(e, l, r),
      Qe(e, r),
      e
    );
  }
  function Il(e, t, n, r) {
    var l = t.current,
      o = Ue(),
      i = Gt(l);
    return (
      (n = Js(n)),
      t.context === null ? (t.context = n) : (t.pendingContext = n),
      (t = Lt(o, i)),
      (t.payload = { element: e }),
      (r = r === void 0 ? null : r),
      r !== null && (t.callback = r),
      (e = Qt(l, t, i)),
      e !== null && (dt(e, l, i, o), pl(e, l, i)),
      i
    );
  }
  function jl(e) {
    if (((e = e.current), !e.child)) return null;
    switch (e.child.tag) {
      case 5:
        return e.child.stateNode;
      default:
        return e.child.stateNode;
    }
  }
  function qs(e, t) {
    if (((e = e.memoizedState), e !== null && e.dehydrated !== null)) {
      var n = e.retryLane;
      e.retryLane = n !== 0 && n < t ? n : t;
    }
  }
  function Au(e, t) {
    (qs(e, t), (e = e.alternate) && qs(e, t));
  }
  function xd() {
    return null;
  }
  var bs =
    typeof reportError == "function"
      ? reportError
      : function (e) {
          console.error(e);
        };
  function Bu(e) {
    this._internalRoot = e;
  }
  (($l.prototype.render = Bu.prototype.render =
    function (e) {
      var t = this._internalRoot;
      if (t === null) throw Error(a(409));
      Il(e, t, null, null);
    }),
    ($l.prototype.unmount = Bu.prototype.unmount =
      function () {
        var e = this._internalRoot;
        if (e !== null) {
          this._internalRoot = null;
          var t = e.containerInfo;
          (cn(function () {
            Il(null, e, null, null);
          }),
            (t[xt] = null));
        }
      }));
  function $l(e) {
    this._internalRoot = e;
  }
  $l.prototype.unstable_scheduleHydration = function (e) {
    if (e) {
      var t = Ii();
      e = { blockedOn: null, target: e, priority: t };
      for (var n = 0; n < jt.length && t !== 0 && t < jt[n].priority; n++);
      (jt.splice(n, 0, e), n === 0 && Ui(e));
    }
  };
  function Hu(e) {
    return !(!e || (e.nodeType !== 1 && e.nodeType !== 9 && e.nodeType !== 11));
  }
  function Ul(e) {
    return !(
      !e ||
      (e.nodeType !== 1 &&
        e.nodeType !== 9 &&
        e.nodeType !== 11 &&
        (e.nodeType !== 8 || e.nodeValue !== " react-mount-point-unstable "))
    );
  }
  function ec() {}
  function _d(e, t, n, r, l) {
    if (l) {
      if (typeof r == "function") {
        var o = r;
        r = function () {
          var w = jl(i);
          o.call(w);
        };
      }
      var i = Zs(t, r, e, 0, null, !1, !1, "", ec);
      return (
        (e._reactRootContainer = i),
        (e[xt] = i.current),
        sr(e.nodeType === 8 ? e.parentNode : e),
        cn(),
        i
      );
    }
    for (; (l = e.lastChild);) e.removeChild(l);
    if (typeof r == "function") {
      var c = r;
      r = function () {
        var w = jl(f);
        c.call(w);
      };
    }
    var f = Uu(e, 0, !1, null, null, !1, !1, "", ec);
    return (
      (e._reactRootContainer = f),
      (e[xt] = f.current),
      sr(e.nodeType === 8 ? e.parentNode : e),
      cn(function () {
        Il(t, f, n, r);
      }),
      f
    );
  }
  function Al(e, t, n, r, l) {
    var o = n._reactRootContainer;
    if (o) {
      var i = o;
      if (typeof l == "function") {
        var c = l;
        l = function () {
          var f = jl(i);
          c.call(f);
        };
      }
      Il(t, i, e, l);
    } else i = _d(n, t, e, l, r);
    return jl(i);
  }
  ((Mi = function (e) {
    switch (e.tag) {
      case 3:
        var t = e.stateNode;
        if (t.current.memoizedState.isDehydrated) {
          var n = Xn(t.pendingLanes);
          n !== 0 &&
            (fo(t, n | 1),
            Qe(t, we()),
            (ee & 6) === 0 && ((jn = we() + 500), Wt()));
        }
        break;
      case 13:
        (cn(function () {
          var r = Nt(e, 1);
          if (r !== null) {
            var l = Ue();
            dt(r, e, 1, l);
          }
        }),
          Au(e, 1));
    }
  }),
    (po = function (e) {
      if (e.tag === 13) {
        var t = Nt(e, 134217728);
        if (t !== null) {
          var n = Ue();
          dt(t, e, 134217728, n);
        }
        Au(e, 134217728);
      }
    }),
    (Fi = function (e) {
      if (e.tag === 13) {
        var t = Gt(e),
          n = Nt(e, t);
        if (n !== null) {
          var r = Ue();
          dt(n, e, t, r);
        }
        Au(e, t);
      }
    }),
    (Ii = function () {
      return oe;
    }),
    (ji = function (e, t) {
      var n = oe;
      try {
        return ((oe = e), t());
      } finally {
        oe = n;
      }
    }),
    (lo = function (e, t, n) {
      switch (t) {
        case "input":
          if ((Jl(e, n), (t = n.name), n.type === "radio" && t != null)) {
            for (n = e; n.parentNode;) n = n.parentNode;
            for (
              n = n.querySelectorAll(
                "input[name=" + JSON.stringify("" + t) + '][type="radio"]',
              ),
                t = 0;
              t < n.length;
              t++
            ) {
              var r = n[t];
              if (r !== e && r.form === e.form) {
                var l = rl(r);
                if (!l) throw Error(a(90));
                (ii(r), Jl(r, l));
              }
            }
          }
          break;
        case "textarea":
          di(e, n);
          break;
        case "select":
          ((t = n.value), t != null && hn(e, !!n.multiple, t, !1));
      }
    }),
    (ki = Du),
    (Ei = cn));
  var Pd = { usingClientEntryPoint: !1, Events: [dr, xn, rl, wi, Si, Du] },
    Pr = {
      findFiberByHostInstance: tn,
      bundleType: 0,
      version: "18.3.1",
      rendererPackageName: "react-dom",
    },
    Rd = {
      bundleType: Pr.bundleType,
      version: Pr.version,
      rendererPackageName: Pr.rendererPackageName,
      rendererConfig: Pr.rendererConfig,
      overrideHookState: null,
      overrideHookStateDeletePath: null,
      overrideHookStateRenamePath: null,
      overrideProps: null,
      overridePropsDeletePath: null,
      overridePropsRenamePath: null,
      setErrorHandler: null,
      setSuspenseHandler: null,
      scheduleUpdate: null,
      currentDispatcherRef: ue.ReactCurrentDispatcher,
      findHostInstanceByFiber: function (e) {
        return ((e = Pi(e)), e === null ? null : e.stateNode);
      },
      findFiberByHostInstance: Pr.findFiberByHostInstance || xd,
      findHostInstancesForRefresh: null,
      scheduleRefresh: null,
      scheduleRoot: null,
      setRefreshHandler: null,
      getCurrentFiber: null,
      reconcilerVersion: "18.3.1-next-f1338f8080-20240426",
    };
  if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u") {
    var Bl = __REACT_DEVTOOLS_GLOBAL_HOOK__;
    if (!Bl.isDisabled && Bl.supportsFiber)
      try {
        (($r = Bl.inject(Rd)), (wt = Bl));
      } catch {}
  }
  return (
    (Ke.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = Pd),
    (Ke.createPortal = function (e, t) {
      var n =
        2 < arguments.length && arguments[2] !== void 0 ? arguments[2] : null;
      if (!Hu(t)) throw Error(a(200));
      return Cd(e, t, null, n);
    }),
    (Ke.createRoot = function (e, t) {
      if (!Hu(e)) throw Error(a(299));
      var n = !1,
        r = "",
        l = bs;
      return (
        t != null &&
          (t.unstable_strictMode === !0 && (n = !0),
          t.identifierPrefix !== void 0 && (r = t.identifierPrefix),
          t.onRecoverableError !== void 0 && (l = t.onRecoverableError)),
        (t = Uu(e, 1, !1, null, null, n, !1, r, l)),
        (e[xt] = t.current),
        sr(e.nodeType === 8 ? e.parentNode : e),
        new Bu(t)
      );
    }),
    (Ke.findDOMNode = function (e) {
      if (e == null) return null;
      if (e.nodeType === 1) return e;
      var t = e._reactInternals;
      if (t === void 0)
        throw typeof e.render == "function"
          ? Error(a(188))
          : ((e = Object.keys(e).join(",")), Error(a(268, e)));
      return ((e = Pi(t)), (e = e === null ? null : e.stateNode), e);
    }),
    (Ke.flushSync = function (e) {
      return cn(e);
    }),
    (Ke.hydrate = function (e, t, n) {
      if (!Ul(t)) throw Error(a(200));
      return Al(null, e, t, !0, n);
    }),
    (Ke.hydrateRoot = function (e, t, n) {
      if (!Hu(e)) throw Error(a(405));
      var r = (n != null && n.hydratedSources) || null,
        l = !1,
        o = "",
        i = bs;
      if (
        (n != null &&
          (n.unstable_strictMode === !0 && (l = !0),
          n.identifierPrefix !== void 0 && (o = n.identifierPrefix),
          n.onRecoverableError !== void 0 && (i = n.onRecoverableError)),
        (t = Zs(t, null, e, 1, n ?? null, l, !1, o, i)),
        (e[xt] = t.current),
        sr(e),
        r)
      )
        for (e = 0; e < r.length; e++)
          ((n = r[e]),
            (l = n._getVersion),
            (l = l(n._source)),
            t.mutableSourceEagerHydrationData == null
              ? (t.mutableSourceEagerHydrationData = [n, l])
              : t.mutableSourceEagerHydrationData.push(n, l));
      return new $l(t);
    }),
    (Ke.render = function (e, t, n) {
      if (!Ul(t)) throw Error(a(200));
      return Al(null, e, t, !1, n);
    }),
    (Ke.unmountComponentAtNode = function (e) {
      if (!Ul(e)) throw Error(a(40));
      return e._reactRootContainer
        ? (cn(function () {
            Al(null, null, e, !1, function () {
              ((e._reactRootContainer = null), (e[xt] = null));
            });
          }),
          !0)
        : !1;
    }),
    (Ke.unstable_batchedUpdates = Du),
    (Ke.unstable_renderSubtreeIntoContainer = function (e, t, n, r) {
      if (!Ul(n)) throw Error(a(200));
      if (e == null || e._reactInternals === void 0) throw Error(a(38));
      return Al(e, t, n, !1, r);
    }),
    (Ke.version = "18.3.1-next-f1338f8080-20240426"),
    Ke
  );
}
var ac;
function mc() {
  if (ac) return Qu.exports;
  ac = 1;
  function u() {
    if (!(
      typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > "u" ||
      typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != "function"
    ))
      try {
        __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(u);
      } catch (s) {
        console.error(s);
      }
  }
  return (u(), (Qu.exports = Id()), Qu.exports);
}
var sc;
function jd() {
  if (sc) return Hl;
  sc = 1;
  var u = mc();
  return ((Hl.createRoot = u.createRoot), (Hl.hydrateRoot = u.hydrateRoot), Hl);
}
var $d = jd();
const sh = qu($d);
/**
 * react-router v7.9.5
 *
 * Copyright (c) Remix Software Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.md file in the root directory of this source tree.
 *
 * @license MIT
 */ var cc = "popstate";
function Ud(u = {}) {
  function s(d, p) {
    let { pathname: y, search: S, hash: E } = d.location;
    return Ju(
      "",
      { pathname: y, search: S, hash: E },
      (p.state && p.state.usr) || null,
      (p.state && p.state.key) || "default",
    );
  }
  function a(d, p) {
    return typeof p == "string" ? p : Lr(p);
  }
  return Bd(s, a, null, u);
}
function pe(u, s) {
  if (u === !1 || u === null || typeof u > "u") throw new Error(s);
}
function pt(u, s) {
  if (!u) {
    typeof console < "u" && console.warn(s);
    try {
      throw new Error(s);
    } catch {}
  }
}
function Ad() {
  return Math.random().toString(36).substring(2, 10);
}
function fc(u, s) {
  return { usr: u.state, key: u.key, idx: s };
}
function Ju(u, s, a = null, d) {
  return {
    pathname: typeof u == "string" ? u : u.pathname,
    search: "",
    hash: "",
    ...(typeof s == "string" ? Un(s) : s),
    state: a,
    key: (s && s.key) || d || Ad(),
  };
}
function Lr({ pathname: u = "/", search: s = "", hash: a = "" }) {
  return (
    s && s !== "?" && (u += s.charAt(0) === "?" ? s : "?" + s),
    a && a !== "#" && (u += a.charAt(0) === "#" ? a : "#" + a),
    u
  );
}
function Un(u) {
  let s = {};
  if (u) {
    let a = u.indexOf("#");
    a >= 0 && ((s.hash = u.substring(a)), (u = u.substring(0, a)));
    let d = u.indexOf("?");
    (d >= 0 && ((s.search = u.substring(d)), (u = u.substring(0, d))),
      u && (s.pathname = u));
  }
  return s;
}
function Bd(u, s, a, d = {}) {
  let { window: p = document.defaultView, v5Compat: y = !1 } = d,
    S = p.history,
    E = "POP",
    k = null,
    x = _();
  x == null && ((x = 0), S.replaceState({ ...S.state, idx: x }, ""));
  function _() {
    return (S.state || { idx: null }).idx;
  }
  function z() {
    E = "POP";
    let O = _(),
      W = O == null ? null : O - x;
    ((x = O), k && k({ action: E, location: H.location, delta: W }));
  }
  function F(O, W) {
    E = "PUSH";
    let A = Ju(H.location, O, W);
    x = _() + 1;
    let Z = fc(A, x),
      ue = H.createHref(A);
    try {
      S.pushState(Z, "", ue);
    } catch (he) {
      if (he instanceof DOMException && he.name === "DataCloneError") throw he;
      p.location.assign(ue);
    }
    y && k && k({ action: E, location: H.location, delta: 1 });
  }
  function V(O, W) {
    E = "REPLACE";
    let A = Ju(H.location, O, W);
    x = _();
    let Z = fc(A, x),
      ue = H.createHref(A);
    (S.replaceState(Z, "", ue),
      y && k && k({ action: E, location: H.location, delta: 0 }));
  }
  function Y(O) {
    return Hd(O);
  }
  let H = {
    get action() {
      return E;
    },
    get location() {
      return u(p, S);
    },
    listen(O) {
      if (k) throw new Error("A history only accepts one active listener");
      return (
        p.addEventListener(cc, z),
        (k = O),
        () => {
          (p.removeEventListener(cc, z), (k = null));
        }
      );
    },
    createHref(O) {
      return s(p, O);
    },
    createURL: Y,
    encodeLocation(O) {
      let W = Y(O);
      return { pathname: W.pathname, search: W.search, hash: W.hash };
    },
    push: F,
    replace: V,
    go(O) {
      return S.go(O);
    },
  };
  return H;
}
function Hd(u, s = !1) {
  let a = "http://localhost";
  (typeof window < "u" &&
    (a =
      window.location.origin !== "null"
        ? window.location.origin
        : window.location.href),
    pe(a, "No window.location.(origin|href) available to create URL"));
  let d = typeof u == "string" ? u : Lr(u);
  return (
    (d = d.replace(/ $/, "%20")),
    !s && d.startsWith("//") && (d = a + d),
    new URL(d, a)
  );
}
function vc(u, s, a = "/") {
  return Wd(u, s, a, !1);
}
function Wd(u, s, a, d) {
  let p = typeof s == "string" ? Un(s) : s,
    y = Dt(p.pathname || "/", a);
  if (y == null) return null;
  let S = yc(u);
  Vd(S);
  let E = null;
  for (let k = 0; E == null && k < S.length; ++k) {
    let x = tp(y);
    E = bd(S[k], x, d);
  }
  return E;
}
function yc(u, s = [], a = [], d = "", p = !1) {
  let y = (S, E, k = p, x) => {
    let _ = {
      relativePath: x === void 0 ? S.path || "" : x,
      caseSensitive: S.caseSensitive === !0,
      childrenIndex: E,
      route: S,
    };
    if (_.relativePath.startsWith("/")) {
      if (!_.relativePath.startsWith(d) && k) return;
      (pe(
        _.relativePath.startsWith(d),
        `Absolute route path "${_.relativePath}" nested under path "${d}" is not valid. An absolute child route path must start with the combined path of all its parent routes.`,
      ),
        (_.relativePath = _.relativePath.slice(d.length)));
    }
    let z = Ot([d, _.relativePath]),
      F = a.concat(_);
    (S.children &&
      S.children.length > 0 &&
      (pe(
        S.index !== !0,
        `Index routes must not have child routes. Please remove all child routes from route path "${z}".`,
      ),
      yc(S.children, s, F, z, k)),
      !(S.path == null && !S.index) &&
        s.push({ path: z, score: Zd(z, S.index), routesMeta: F }));
  };
  return (
    u.forEach((S, E) => {
      if (S.path === "" || !S.path?.includes("?")) y(S, E);
      else for (let k of gc(S.path)) y(S, E, !0, k);
    }),
    s
  );
}
function gc(u) {
  let s = u.split("/");
  if (s.length === 0) return [];
  let [a, ...d] = s,
    p = a.endsWith("?"),
    y = a.replace(/\?$/, "");
  if (d.length === 0) return p ? [y, ""] : [y];
  let S = gc(d.join("/")),
    E = [];
  return (
    E.push(...S.map((k) => (k === "" ? y : [y, k].join("/")))),
    p && E.push(...S),
    E.map((k) => (u.startsWith("/") && k === "" ? "/" : k))
  );
}
function Vd(u) {
  u.sort((s, a) =>
    s.score !== a.score
      ? a.score - s.score
      : qd(
          s.routesMeta.map((d) => d.childrenIndex),
          a.routesMeta.map((d) => d.childrenIndex),
        ),
  );
}
var Qd = /^:[\w-]+$/,
  Kd = 3,
  Yd = 2,
  Xd = 1,
  Gd = 10,
  Jd = -2,
  dc = (u) => u === "*";
function Zd(u, s) {
  let a = u.split("/"),
    d = a.length;
  return (
    a.some(dc) && (d += Jd),
    s && (d += Yd),
    a
      .filter((p) => !dc(p))
      .reduce((p, y) => p + (Qd.test(y) ? Kd : y === "" ? Xd : Gd), d)
  );
}
function qd(u, s) {
  return u.length === s.length && u.slice(0, -1).every((d, p) => d === s[p])
    ? u[u.length - 1] - s[s.length - 1]
    : 0;
}
function bd(u, s, a = !1) {
  let { routesMeta: d } = u,
    p = {},
    y = "/",
    S = [];
  for (let E = 0; E < d.length; ++E) {
    let k = d[E],
      x = E === d.length - 1,
      _ = y === "/" ? s : s.slice(y.length) || "/",
      z = Kl(
        { path: k.relativePath, caseSensitive: k.caseSensitive, end: x },
        _,
      ),
      F = k.route;
    if (
      (!z &&
        x &&
        a &&
        !d[d.length - 1].route.index &&
        (z = Kl(
          { path: k.relativePath, caseSensitive: k.caseSensitive, end: !1 },
          _,
        )),
      !z)
    )
      return null;
    (Object.assign(p, z.params),
      S.push({
        params: p,
        pathname: Ot([y, z.pathname]),
        pathnameBase: op(Ot([y, z.pathnameBase])),
        route: F,
      }),
      z.pathnameBase !== "/" && (y = Ot([y, z.pathnameBase])));
  }
  return S;
}
function Kl(u, s) {
  typeof u == "string" && (u = { path: u, caseSensitive: !1, end: !0 });
  let [a, d] = ep(u.path, u.caseSensitive, u.end),
    p = s.match(a);
  if (!p) return null;
  let y = p[0],
    S = y.replace(/(.)\/+$/, "$1"),
    E = p.slice(1);
  return {
    params: d.reduce((x, { paramName: _, isOptional: z }, F) => {
      if (_ === "*") {
        let Y = E[F] || "";
        S = y.slice(0, y.length - Y.length).replace(/(.)\/+$/, "$1");
      }
      const V = E[F];
      return (
        z && !V ? (x[_] = void 0) : (x[_] = (V || "").replace(/%2F/g, "/")),
        x
      );
    }, {}),
    pathname: y,
    pathnameBase: S,
    pattern: u,
  };
}
function ep(u, s = !1, a = !0) {
  pt(
    u === "*" || !u.endsWith("*") || u.endsWith("/*"),
    `Route path "${u}" will be treated as if it were "${u.replace(/\*$/, "/*")}" because the \`*\` character must always follow a \`/\` in the pattern. To get rid of this warning, please change the route path to "${u.replace(/\*$/, "/*")}".`,
  );
  let d = [],
    p =
      "^" +
      u
        .replace(/\/*\*?$/, "")
        .replace(/^\/*/, "/")
        .replace(/[\\.*+^${}|()[\]]/g, "\\$&")
        .replace(
          /\/:([\w-]+)(\?)?/g,
          (S, E, k) => (
            d.push({ paramName: E, isOptional: k != null }),
            k ? "/?([^\\/]+)?" : "/([^\\/]+)"
          ),
        )
        .replace(/\/([\w-]+)\?(\/|$)/g, "(/$1)?$2");
  return (
    u.endsWith("*")
      ? (d.push({ paramName: "*" }),
        (p += u === "*" || u === "/*" ? "(.*)$" : "(?:\\/(.+)|\\/*)$"))
      : a
        ? (p += "\\/*$")
        : u !== "" && u !== "/" && (p += "(?:(?=\\/|$))"),
    [new RegExp(p, s ? void 0 : "i"), d]
  );
}
function tp(u) {
  try {
    return u
      .split("/")
      .map((s) => decodeURIComponent(s).replace(/\//g, "%2F"))
      .join("/");
  } catch (s) {
    return (
      pt(
        !1,
        `The URL path "${u}" could not be decoded because it is a malformed URL segment. This is probably due to a bad percent encoding (${s}).`,
      ),
      u
    );
  }
}
function Dt(u, s) {
  if (s === "/") return u;
  if (!u.toLowerCase().startsWith(s.toLowerCase())) return null;
  let a = s.endsWith("/") ? s.length - 1 : s.length,
    d = u.charAt(a);
  return d && d !== "/" ? null : u.slice(a) || "/";
}
function np(u, s = "/") {
  let {
    pathname: a,
    search: d = "",
    hash: p = "",
  } = typeof u == "string" ? Un(u) : u;
  return {
    pathname: a ? (a.startsWith("/") ? a : rp(a, s)) : s,
    search: up(d),
    hash: ip(p),
  };
}
function rp(u, s) {
  let a = s.replace(/\/+$/, "").split("/");
  return (
    u.split("/").forEach((p) => {
      p === ".." ? a.length > 1 && a.pop() : p !== "." && a.push(p);
    }),
    a.length > 1 ? a.join("/") : "/"
  );
}
function Xu(u, s, a, d) {
  return `Cannot include a '${u}' character in a manually specified \`to.${s}\` field [${JSON.stringify(d)}].  Please separate it out to the \`to.${a}\` field. Alternatively you may provide the full path as a string in <Link to="..."> and the router will parse it for you.`;
}
function lp(u) {
  return u.filter(
    (s, a) => a === 0 || (s.route.path && s.route.path.length > 0),
  );
}
function ei(u) {
  let s = lp(u);
  return s.map((a, d) => (d === s.length - 1 ? a.pathname : a.pathnameBase));
}
function ti(u, s, a, d = !1) {
  let p;
  typeof u == "string"
    ? (p = Un(u))
    : ((p = { ...u }),
      pe(
        !p.pathname || !p.pathname.includes("?"),
        Xu("?", "pathname", "search", p),
      ),
      pe(
        !p.pathname || !p.pathname.includes("#"),
        Xu("#", "pathname", "hash", p),
      ),
      pe(!p.search || !p.search.includes("#"), Xu("#", "search", "hash", p)));
  let y = u === "" || p.pathname === "",
    S = y ? "/" : p.pathname,
    E;
  if (S == null) E = a;
  else {
    let z = s.length - 1;
    if (!d && S.startsWith("..")) {
      let F = S.split("/");
      for (; F[0] === "..";) (F.shift(), (z -= 1));
      p.pathname = F.join("/");
    }
    E = z >= 0 ? s[z] : "/";
  }
  let k = np(p, E),
    x = S && S !== "/" && S.endsWith("/"),
    _ = (y || S === ".") && a.endsWith("/");
  return (!k.pathname.endsWith("/") && (x || _) && (k.pathname += "/"), k);
}
var Ot = (u) => u.join("/").replace(/\/\/+/g, "/"),
  op = (u) => u.replace(/\/+$/, "").replace(/^\/*/, "/"),
  up = (u) => (!u || u === "?" ? "" : u.startsWith("?") ? u : "?" + u),
  ip = (u) => (!u || u === "#" ? "" : u.startsWith("#") ? u : "#" + u);
function ap(u) {
  return (
    u != null &&
    typeof u.status == "number" &&
    typeof u.statusText == "string" &&
    typeof u.internal == "boolean" &&
    "data" in u
  );
}
Object.getOwnPropertyNames(Object.prototype).sort().join("\0");
var wc = ["POST", "PUT", "PATCH", "DELETE"];
new Set(wc);
var sp = ["GET", ...wc];
new Set(sp);
var An = C.createContext(null);
An.displayName = "DataRouter";
var Yl = C.createContext(null);
Yl.displayName = "DataRouterState";
C.createContext(!1);
var Sc = C.createContext({ isTransitioning: !1 });
Sc.displayName = "ViewTransition";
var cp = C.createContext(new Map());
cp.displayName = "Fetchers";
var fp = C.createContext(null);
fp.displayName = "Await";
var ht = C.createContext(null);
ht.displayName = "Navigation";
var Tr = C.createContext(null);
Tr.displayName = "Location";
var mt = C.createContext({ outlet: null, matches: [], isDataRoute: !1 });
mt.displayName = "Route";
var ni = C.createContext(null);
ni.displayName = "RouteError";
function dp(u, { relative: s } = {}) {
  pe(
    Bn(),
    "useHref() may be used only in the context of a <Router> component.",
  );
  let { basename: a, navigator: d } = C.useContext(ht),
    { hash: p, pathname: y, search: S } = zr(u, { relative: s }),
    E = y;
  return (
    a !== "/" && (E = y === "/" ? a : Ot([a, y])),
    d.createHref({ pathname: E, search: S, hash: p })
  );
}
function Bn() {
  return C.useContext(Tr) != null;
}
function bt() {
  return (
    pe(
      Bn(),
      "useLocation() may be used only in the context of a <Router> component.",
    ),
    C.useContext(Tr).location
  );
}
var kc =
  "You should call navigate() in a React.useEffect(), not when your component is first rendered.";
function Ec(u) {
  C.useContext(ht).static || C.useLayoutEffect(u);
}
function Cc() {
  let { isDataRoute: u } = C.useContext(mt);
  return u ? _p() : pp();
}
function pp() {
  pe(
    Bn(),
    "useNavigate() may be used only in the context of a <Router> component.",
  );
  let u = C.useContext(An),
    { basename: s, navigator: a } = C.useContext(ht),
    { matches: d } = C.useContext(mt),
    { pathname: p } = bt(),
    y = JSON.stringify(ei(d)),
    S = C.useRef(!1);
  return (
    Ec(() => {
      S.current = !0;
    }),
    C.useCallback(
      (k, x = {}) => {
        if ((pt(S.current, kc), !S.current)) return;
        if (typeof k == "number") {
          a.go(k);
          return;
        }
        let _ = ti(k, JSON.parse(y), p, x.relative === "path");
        (u == null &&
          s !== "/" &&
          (_.pathname = _.pathname === "/" ? s : Ot([s, _.pathname])),
          (x.replace ? a.replace : a.push)(_, x.state, x));
      },
      [s, a, y, p, u],
    )
  );
}
C.createContext(null);
function ch() {
  let { matches: u } = C.useContext(mt),
    s = u[u.length - 1];
  return s ? s.params : {};
}
function zr(u, { relative: s } = {}) {
  let { matches: a } = C.useContext(mt),
    { pathname: d } = bt(),
    p = JSON.stringify(ei(a));
  return C.useMemo(() => ti(u, JSON.parse(p), d, s === "path"), [u, p, d, s]);
}
function hp(u, s) {
  return xc(u, s);
}
function xc(u, s, a, d, p) {
  pe(
    Bn(),
    "useRoutes() may be used only in the context of a <Router> component.",
  );
  let { navigator: y } = C.useContext(ht),
    { matches: S } = C.useContext(mt),
    E = S[S.length - 1],
    k = E ? E.params : {},
    x = E ? E.pathname : "/",
    _ = E ? E.pathnameBase : "/",
    z = E && E.route;
  {
    let A = (z && z.path) || "";
    _c(
      x,
      !z || A.endsWith("*") || A.endsWith("*?"),
      `You rendered descendant <Routes> (or called \`useRoutes()\`) at "${x}" (under <Route path="${A}">) but the parent route path has no trailing "*". This means if you navigate deeper, the parent won't match anymore and therefore the child routes will never render.

Please change the parent <Route path="${A}"> to <Route path="${A === "/" ? "*" : `${A}/*`}">.`,
    );
  }
  let F = bt(),
    V;
  if (s) {
    let A = typeof s == "string" ? Un(s) : s;
    (pe(
      _ === "/" || A.pathname?.startsWith(_),
      `When overriding the location using \`<Routes location>\` or \`useRoutes(routes, location)\`, the location pathname must begin with the portion of the URL pathname that was matched by all parent routes. The current pathname base is "${_}" but pathname "${A.pathname}" was given in the \`location\` prop.`,
    ),
      (V = A));
  } else V = F;
  let Y = V.pathname || "/",
    H = Y;
  if (_ !== "/") {
    let A = _.replace(/^\//, "").split("/");
    H = "/" + Y.replace(/^\//, "").split("/").slice(A.length).join("/");
  }
  let O = vc(u, { pathname: H });
  (pt(
    z || O != null,
    `No routes matched location "${V.pathname}${V.search}${V.hash}" `,
  ),
    pt(
      O == null ||
        O[O.length - 1].route.element !== void 0 ||
        O[O.length - 1].route.Component !== void 0 ||
        O[O.length - 1].route.lazy !== void 0,
      `Matched leaf route at location "${V.pathname}${V.search}${V.hash}" does not have an element or Component. This means it will render an <Outlet /> with a null value by default resulting in an "empty" page.`,
    ));
  let W = wp(
    O &&
      O.map((A) =>
        Object.assign({}, A, {
          params: Object.assign({}, k, A.params),
          pathname: Ot([
            _,
            y.encodeLocation
              ? y.encodeLocation(
                  A.pathname.replace(/\?/g, "%3F").replace(/#/g, "%23"),
                ).pathname
              : A.pathname,
          ]),
          pathnameBase:
            A.pathnameBase === "/"
              ? _
              : Ot([
                  _,
                  y.encodeLocation
                    ? y.encodeLocation(
                        A.pathnameBase
                          .replace(/\?/g, "%3F")
                          .replace(/#/g, "%23"),
                      ).pathname
                    : A.pathnameBase,
                ]),
        }),
      ),
    S,
    a,
    d,
    p,
  );
  return s && W
    ? C.createElement(
        Tr.Provider,
        {
          value: {
            location: {
              pathname: "/",
              search: "",
              hash: "",
              state: null,
              key: "default",
              ...V,
            },
            navigationType: "POP",
          },
        },
        W,
      )
    : W;
}
function mp() {
  let u = xp(),
    s = ap(u)
      ? `${u.status} ${u.statusText}`
      : u instanceof Error
        ? u.message
        : JSON.stringify(u),
    a = u instanceof Error ? u.stack : null,
    d = "rgba(200,200,200, 0.5)",
    p = { padding: "0.5rem", backgroundColor: d },
    y = { padding: "2px 4px", backgroundColor: d },
    S = null;
  return (
    console.error("Error handled by React Router default ErrorBoundary:", u),
    (S = C.createElement(
      C.Fragment,
      null,
      C.createElement("p", null, "💿 Hey developer 👋"),
      C.createElement(
        "p",
        null,
        "You can provide a way better UX than this when your app throws errors by providing your own ",
        C.createElement("code", { style: y }, "ErrorBoundary"),
        " or",
        " ",
        C.createElement("code", { style: y }, "errorElement"),
        " prop on your route.",
      ),
    )),
    C.createElement(
      C.Fragment,
      null,
      C.createElement("h2", null, "Unexpected Application Error!"),
      C.createElement("h3", { style: { fontStyle: "italic" } }, s),
      a ? C.createElement("pre", { style: p }, a) : null,
      S,
    )
  );
}
var vp = C.createElement(mp, null),
  yp = class extends C.Component {
    constructor(u) {
      (super(u),
        (this.state = {
          location: u.location,
          revalidation: u.revalidation,
          error: u.error,
        }));
    }
    static getDerivedStateFromError(u) {
      return { error: u };
    }
    static getDerivedStateFromProps(u, s) {
      return s.location !== u.location ||
        (s.revalidation !== "idle" && u.revalidation === "idle")
        ? { error: u.error, location: u.location, revalidation: u.revalidation }
        : {
            error: u.error !== void 0 ? u.error : s.error,
            location: s.location,
            revalidation: u.revalidation || s.revalidation,
          };
    }
    componentDidCatch(u, s) {
      this.props.unstable_onError
        ? this.props.unstable_onError(u, s)
        : console.error(
            "React Router caught the following error during render",
            u,
          );
    }
    render() {
      return this.state.error !== void 0
        ? C.createElement(
            mt.Provider,
            { value: this.props.routeContext },
            C.createElement(ni.Provider, {
              value: this.state.error,
              children: this.props.component,
            }),
          )
        : this.props.children;
    }
  };
function gp({ routeContext: u, match: s, children: a }) {
  let d = C.useContext(An);
  return (
    d &&
      d.static &&
      d.staticContext &&
      (s.route.errorElement || s.route.ErrorBoundary) &&
      (d.staticContext._deepestRenderedBoundaryId = s.route.id),
    C.createElement(mt.Provider, { value: u }, a)
  );
}
function wp(u, s = [], a = null, d = null, p = null) {
  if (u == null) {
    if (!a) return null;
    if (a.errors) u = a.matches;
    else if (s.length === 0 && !a.initialized && a.matches.length > 0)
      u = a.matches;
    else return null;
  }
  let y = u,
    S = a?.errors;
  if (S != null) {
    let x = y.findIndex((_) => _.route.id && S?.[_.route.id] !== void 0);
    (pe(
      x >= 0,
      `Could not find a matching route for errors on route IDs: ${Object.keys(S).join(",")}`,
    ),
      (y = y.slice(0, Math.min(y.length, x + 1))));
  }
  let E = !1,
    k = -1;
  if (a)
    for (let x = 0; x < y.length; x++) {
      let _ = y[x];
      if (
        ((_.route.HydrateFallback || _.route.hydrateFallbackElement) && (k = x),
        _.route.id)
      ) {
        let { loaderData: z, errors: F } = a,
          V =
            _.route.loader &&
            !z.hasOwnProperty(_.route.id) &&
            (!F || F[_.route.id] === void 0);
        if (_.route.lazy || V) {
          ((E = !0), k >= 0 ? (y = y.slice(0, k + 1)) : (y = [y[0]]));
          break;
        }
      }
    }
  return y.reduceRight((x, _, z) => {
    let F,
      V = !1,
      Y = null,
      H = null;
    a &&
      ((F = S && _.route.id ? S[_.route.id] : void 0),
      (Y = _.route.errorElement || vp),
      E &&
        (k < 0 && z === 0
          ? (_c(
              "route-fallback",
              !1,
              "No `HydrateFallback` element provided to render during initial hydration",
            ),
            (V = !0),
            (H = null))
          : k === z &&
            ((V = !0), (H = _.route.hydrateFallbackElement || null))));
    let O = s.concat(y.slice(0, z + 1)),
      W = () => {
        let A;
        return (
          F
            ? (A = Y)
            : V
              ? (A = H)
              : _.route.Component
                ? (A = C.createElement(_.route.Component, null))
                : _.route.element
                  ? (A = _.route.element)
                  : (A = x),
          C.createElement(gp, {
            match: _,
            routeContext: { outlet: x, matches: O, isDataRoute: a != null },
            children: A,
          })
        );
      };
    return a && (_.route.ErrorBoundary || _.route.errorElement || z === 0)
      ? C.createElement(yp, {
          location: a.location,
          revalidation: a.revalidation,
          component: Y,
          error: F,
          children: W(),
          routeContext: { outlet: null, matches: O, isDataRoute: !0 },
          unstable_onError: d,
        })
      : W();
  }, null);
}
function ri(u) {
  return `${u} must be used within a data router.  See https://reactrouter.com/en/main/routers/picking-a-router.`;
}
function Sp(u) {
  let s = C.useContext(An);
  return (pe(s, ri(u)), s);
}
function kp(u) {
  let s = C.useContext(Yl);
  return (pe(s, ri(u)), s);
}
function Ep(u) {
  let s = C.useContext(mt);
  return (pe(s, ri(u)), s);
}
function li(u) {
  let s = Ep(u),
    a = s.matches[s.matches.length - 1];
  return (
    pe(
      a.route.id,
      `${u} can only be used on routes that contain a unique "id"`,
    ),
    a.route.id
  );
}
function Cp() {
  return li("useRouteId");
}
function xp() {
  let u = C.useContext(ni),
    s = kp("useRouteError"),
    a = li("useRouteError");
  return u !== void 0 ? u : s.errors?.[a];
}
function _p() {
  let { router: u } = Sp("useNavigate"),
    s = li("useNavigate"),
    a = C.useRef(!1);
  return (
    Ec(() => {
      a.current = !0;
    }),
    C.useCallback(
      async (p, y = {}) => {
        (pt(a.current, kc),
          a.current &&
            (typeof p == "number"
              ? u.navigate(p)
              : await u.navigate(p, { fromRouteId: s, ...y })));
      },
      [u, s],
    )
  );
}
var pc = {};
function _c(u, s, a) {
  !s && !pc[u] && ((pc[u] = !0), pt(!1, a));
}
C.memo(Pp);
function Pp({ routes: u, future: s, state: a, unstable_onError: d }) {
  return xc(u, void 0, a, d, s);
}
function fh({ to: u, replace: s, state: a, relative: d }) {
  pe(
    Bn(),
    "<Navigate> may be used only in the context of a <Router> component.",
  );
  let { static: p } = C.useContext(ht);
  pt(
    !p,
    "<Navigate> must not be used on the initial render in a <StaticRouter>. This is a no-op, but you should modify your code so the <Navigate> is only ever rendered in response to some user interaction or state change.",
  );
  let { matches: y } = C.useContext(mt),
    { pathname: S } = bt(),
    E = Cc(),
    k = ti(u, ei(y), S, d === "path"),
    x = JSON.stringify(k);
  return (
    C.useEffect(() => {
      E(JSON.parse(x), { replace: s, state: a, relative: d });
    }, [E, x, d, s, a]),
    null
  );
}
function Rp(u) {
  pe(
    !1,
    "A <Route> is only ever to be used as the child of <Routes> element, never rendered directly. Please wrap your <Route> in a <Routes>.",
  );
}
function Np({
  basename: u = "/",
  children: s = null,
  location: a,
  navigationType: d = "POP",
  navigator: p,
  static: y = !1,
}) {
  pe(
    !Bn(),
    "You cannot render a <Router> inside another <Router>. You should never have more than one in your app.",
  );
  let S = u.replace(/^\/*/, "/"),
    E = C.useMemo(
      () => ({ basename: S, navigator: p, static: y, future: {} }),
      [S, p, y],
    );
  typeof a == "string" && (a = Un(a));
  let {
      pathname: k = "/",
      search: x = "",
      hash: _ = "",
      state: z = null,
      key: F = "default",
    } = a,
    V = C.useMemo(() => {
      let Y = Dt(k, S);
      return Y == null
        ? null
        : {
            location: { pathname: Y, search: x, hash: _, state: z, key: F },
            navigationType: d,
          };
    }, [S, k, x, _, z, F, d]);
  return (
    pt(
      V != null,
      `<Router basename="${S}"> is not able to match the URL "${k}${x}${_}" because it does not start with the basename, so the <Router> won't render anything.`,
    ),
    V == null
      ? null
      : C.createElement(
          ht.Provider,
          { value: E },
          C.createElement(Tr.Provider, { children: s, value: V }),
        )
  );
}
function dh({ children: u, location: s }) {
  return hp(Zu(u), s);
}
function Zu(u, s = []) {
  let a = [];
  return (
    C.Children.forEach(u, (d, p) => {
      if (!C.isValidElement(d)) return;
      let y = [...s, p];
      if (d.type === C.Fragment) {
        a.push.apply(a, Zu(d.props.children, y));
        return;
      }
      (pe(
        d.type === Rp,
        `[${typeof d.type == "string" ? d.type : d.type.name}] is not a <Route> component. All component children of <Routes> must be a <Route> or <React.Fragment>`,
      ),
        pe(
          !d.props.index || !d.props.children,
          "An index route cannot have child routes.",
        ));
      let S = {
        id: d.props.id || y.join("-"),
        caseSensitive: d.props.caseSensitive,
        element: d.props.element,
        Component: d.props.Component,
        index: d.props.index,
        path: d.props.path,
        middleware: d.props.middleware,
        loader: d.props.loader,
        action: d.props.action,
        hydrateFallbackElement: d.props.hydrateFallbackElement,
        HydrateFallback: d.props.HydrateFallback,
        errorElement: d.props.errorElement,
        ErrorBoundary: d.props.ErrorBoundary,
        hasErrorBoundary:
          d.props.hasErrorBoundary === !0 ||
          d.props.ErrorBoundary != null ||
          d.props.errorElement != null,
        shouldRevalidate: d.props.shouldRevalidate,
        handle: d.props.handle,
        lazy: d.props.lazy,
      };
      (d.props.children && (S.children = Zu(d.props.children, y)), a.push(S));
    }),
    a
  );
}
var Vl = "get",
  Ql = "application/x-www-form-urlencoded";
function Xl(u) {
  return u != null && typeof u.tagName == "string";
}
function Lp(u) {
  return Xl(u) && u.tagName.toLowerCase() === "button";
}
function Tp(u) {
  return Xl(u) && u.tagName.toLowerCase() === "form";
}
function zp(u) {
  return Xl(u) && u.tagName.toLowerCase() === "input";
}
function Op(u) {
  return !!(u.metaKey || u.altKey || u.ctrlKey || u.shiftKey);
}
function Dp(u, s) {
  return u.button === 0 && (!s || s === "_self") && !Op(u);
}
var Wl = null;
function Mp() {
  if (Wl === null)
    try {
      (new FormData(document.createElement("form"), 0), (Wl = !1));
    } catch {
      Wl = !0;
    }
  return Wl;
}
var Fp = new Set([
  "application/x-www-form-urlencoded",
  "multipart/form-data",
  "text/plain",
]);
function Gu(u) {
  return u != null && !Fp.has(u)
    ? (pt(
        !1,
        `"${u}" is not a valid \`encType\` for \`<Form>\`/\`<fetcher.Form>\` and will default to "${Ql}"`,
      ),
      null)
    : u;
}
function Ip(u, s) {
  let a, d, p, y, S;
  if (Tp(u)) {
    let E = u.getAttribute("action");
    ((d = E ? Dt(E, s) : null),
      (a = u.getAttribute("method") || Vl),
      (p = Gu(u.getAttribute("enctype")) || Ql),
      (y = new FormData(u)));
  } else if (Lp(u) || (zp(u) && (u.type === "submit" || u.type === "image"))) {
    let E = u.form;
    if (E == null)
      throw new Error(
        'Cannot submit a <button> or <input type="submit"> without a <form>',
      );
    let k = u.getAttribute("formaction") || E.getAttribute("action");
    if (
      ((d = k ? Dt(k, s) : null),
      (a = u.getAttribute("formmethod") || E.getAttribute("method") || Vl),
      (p =
        Gu(u.getAttribute("formenctype")) ||
        Gu(E.getAttribute("enctype")) ||
        Ql),
      (y = new FormData(E, u)),
      !Mp())
    ) {
      let { name: x, type: _, value: z } = u;
      if (_ === "image") {
        let F = x ? `${x}.` : "";
        (y.append(`${F}x`, "0"), y.append(`${F}y`, "0"));
      } else x && y.append(x, z);
    }
  } else {
    if (Xl(u))
      throw new Error(
        'Cannot submit element that is not <form>, <button>, or <input type="submit|image">',
      );
    ((a = Vl), (d = null), (p = Ql), (S = u));
  }
  return (
    y && p === "text/plain" && ((S = y), (y = void 0)),
    { action: d, method: a.toLowerCase(), encType: p, formData: y, body: S }
  );
}
Object.getOwnPropertyNames(Object.prototype).sort().join("\0");
function oi(u, s) {
  if (u === !1 || u === null || typeof u > "u") throw new Error(s);
}
function jp(u, s, a) {
  let d =
    typeof u == "string"
      ? new URL(
          u,
          typeof window > "u"
            ? "server://singlefetch/"
            : window.location.origin,
        )
      : u;
  return (
    d.pathname === "/"
      ? (d.pathname = `_root.${a}`)
      : s && Dt(d.pathname, s) === "/"
        ? (d.pathname = `${s.replace(/\/$/, "")}/_root.${a}`)
        : (d.pathname = `${d.pathname.replace(/\/$/, "")}.${a}`),
    d
  );
}
async function $p(u, s) {
  if (u.id in s) return s[u.id];
  try {
    let a = await import(u.module);
    return ((s[u.id] = a), a);
  } catch (a) {
    return (
      console.error(
        `Error loading route module \`${u.module}\`, reloading page...`,
      ),
      console.error(a),
      window.__reactRouterContext && window.__reactRouterContext.isSpaMode,
      window.location.reload(),
      new Promise(() => {})
    );
  }
}
function Up(u) {
  return u == null
    ? !1
    : u.href == null
      ? u.rel === "preload" &&
        typeof u.imageSrcSet == "string" &&
        typeof u.imageSizes == "string"
      : typeof u.rel == "string" && typeof u.href == "string";
}
async function Ap(u, s, a) {
  let d = await Promise.all(
    u.map(async (p) => {
      let y = s.routes[p.route.id];
      if (y) {
        let S = await $p(y, a);
        return S.links ? S.links() : [];
      }
      return [];
    }),
  );
  return Vp(
    d
      .flat(1)
      .filter(Up)
      .filter((p) => p.rel === "stylesheet" || p.rel === "preload")
      .map((p) =>
        p.rel === "stylesheet"
          ? { ...p, rel: "prefetch", as: "style" }
          : { ...p, rel: "prefetch" },
      ),
  );
}
function hc(u, s, a, d, p, y) {
  let S = (k, x) => (a[x] ? k.route.id !== a[x].route.id : !0),
    E = (k, x) =>
      a[x].pathname !== k.pathname ||
      (a[x].route.path?.endsWith("*") && a[x].params["*"] !== k.params["*"]);
  return y === "assets"
    ? s.filter((k, x) => S(k, x) || E(k, x))
    : y === "data"
      ? s.filter((k, x) => {
          let _ = d.routes[k.route.id];
          if (!_ || !_.hasLoader) return !1;
          if (S(k, x) || E(k, x)) return !0;
          if (k.route.shouldRevalidate) {
            let z = k.route.shouldRevalidate({
              currentUrl: new URL(
                p.pathname + p.search + p.hash,
                window.origin,
              ),
              currentParams: a[0]?.params || {},
              nextUrl: new URL(u, window.origin),
              nextParams: k.params,
              defaultShouldRevalidate: !0,
            });
            if (typeof z == "boolean") return z;
          }
          return !0;
        })
      : [];
}
function Bp(u, s, { includeHydrateFallback: a } = {}) {
  return Hp(
    u
      .map((d) => {
        let p = s.routes[d.route.id];
        if (!p) return [];
        let y = [p.module];
        return (
          p.clientActionModule && (y = y.concat(p.clientActionModule)),
          p.clientLoaderModule && (y = y.concat(p.clientLoaderModule)),
          a &&
            p.hydrateFallbackModule &&
            (y = y.concat(p.hydrateFallbackModule)),
          p.imports && (y = y.concat(p.imports)),
          y
        );
      })
      .flat(1),
  );
}
function Hp(u) {
  return [...new Set(u)];
}
function Wp(u) {
  let s = {},
    a = Object.keys(u).sort();
  for (let d of a) s[d] = u[d];
  return s;
}
function Vp(u, s) {
  let a = new Set();
  return (
    new Set(s),
    u.reduce((d, p) => {
      let y = JSON.stringify(Wp(p));
      return (a.has(y) || (a.add(y), d.push({ key: y, link: p })), d);
    }, [])
  );
}
function Pc() {
  let u = C.useContext(An);
  return (
    oi(
      u,
      "You must render this element inside a <DataRouterContext.Provider> element",
    ),
    u
  );
}
function Qp() {
  let u = C.useContext(Yl);
  return (
    oi(
      u,
      "You must render this element inside a <DataRouterStateContext.Provider> element",
    ),
    u
  );
}
var ui = C.createContext(void 0);
ui.displayName = "FrameworkContext";
function Rc() {
  let u = C.useContext(ui);
  return (
    oi(u, "You must render this element inside a <HydratedRouter> element"),
    u
  );
}
function Kp(u, s) {
  let a = C.useContext(ui),
    [d, p] = C.useState(!1),
    [y, S] = C.useState(!1),
    {
      onFocus: E,
      onBlur: k,
      onMouseEnter: x,
      onMouseLeave: _,
      onTouchStart: z,
    } = s,
    F = C.useRef(null);
  (C.useEffect(() => {
    if ((u === "render" && S(!0), u === "viewport")) {
      let H = (W) => {
          W.forEach((A) => {
            S(A.isIntersecting);
          });
        },
        O = new IntersectionObserver(H, { threshold: 0.5 });
      return (
        F.current && O.observe(F.current),
        () => {
          O.disconnect();
        }
      );
    }
  }, [u]),
    C.useEffect(() => {
      if (d) {
        let H = setTimeout(() => {
          S(!0);
        }, 100);
        return () => {
          clearTimeout(H);
        };
      }
    }, [d]));
  let V = () => {
      p(!0);
    },
    Y = () => {
      (p(!1), S(!1));
    };
  return a
    ? u !== "intent"
      ? [y, F, {}]
      : [
          y,
          F,
          {
            onFocus: Nr(E, V),
            onBlur: Nr(k, Y),
            onMouseEnter: Nr(x, V),
            onMouseLeave: Nr(_, Y),
            onTouchStart: Nr(z, V),
          },
        ]
    : [!1, F, {}];
}
function Nr(u, s) {
  return (a) => {
    (u && u(a), a.defaultPrevented || s(a));
  };
}
function Yp({ page: u, ...s }) {
  let { router: a } = Pc(),
    d = C.useMemo(() => vc(a.routes, u, a.basename), [a.routes, u, a.basename]);
  return d ? C.createElement(Gp, { page: u, matches: d, ...s }) : null;
}
function Xp(u) {
  let { manifest: s, routeModules: a } = Rc(),
    [d, p] = C.useState([]);
  return (
    C.useEffect(() => {
      let y = !1;
      return (
        Ap(u, s, a).then((S) => {
          y || p(S);
        }),
        () => {
          y = !0;
        }
      );
    }, [u, s, a]),
    d
  );
}
function Gp({ page: u, matches: s, ...a }) {
  let d = bt(),
    { manifest: p, routeModules: y } = Rc(),
    { basename: S } = Pc(),
    { loaderData: E, matches: k } = Qp(),
    x = C.useMemo(() => hc(u, s, k, p, d, "data"), [u, s, k, p, d]),
    _ = C.useMemo(() => hc(u, s, k, p, d, "assets"), [u, s, k, p, d]),
    z = C.useMemo(() => {
      if (u === d.pathname + d.search + d.hash) return [];
      let Y = new Set(),
        H = !1;
      if (
        (s.forEach((W) => {
          let A = p.routes[W.route.id];
          !A ||
            !A.hasLoader ||
            ((!x.some((Z) => Z.route.id === W.route.id) &&
              W.route.id in E &&
              y[W.route.id]?.shouldRevalidate) ||
            A.hasClientLoader
              ? (H = !0)
              : Y.add(W.route.id));
        }),
        Y.size === 0)
      )
        return [];
      let O = jp(u, S, "data");
      return (
        H &&
          Y.size > 0 &&
          O.searchParams.set(
            "_routes",
            s
              .filter((W) => Y.has(W.route.id))
              .map((W) => W.route.id)
              .join(","),
          ),
        [O.pathname + O.search]
      );
    }, [S, E, d, p, x, s, u, y]),
    F = C.useMemo(() => Bp(_, p), [_, p]),
    V = Xp(_);
  return C.createElement(
    C.Fragment,
    null,
    z.map((Y) =>
      C.createElement("link", {
        key: Y,
        rel: "prefetch",
        as: "fetch",
        href: Y,
        ...a,
      }),
    ),
    F.map((Y) =>
      C.createElement("link", { key: Y, rel: "modulepreload", href: Y, ...a }),
    ),
    V.map(({ key: Y, link: H }) =>
      C.createElement("link", { key: Y, nonce: a.nonce, ...H }),
    ),
  );
}
function Jp(...u) {
  return (s) => {
    u.forEach((a) => {
      typeof a == "function" ? a(s) : a != null && (a.current = s);
    });
  };
}
var Nc =
  typeof window < "u" &&
  typeof window.document < "u" &&
  typeof window.document.createElement < "u";
try {
  Nc && (window.__reactRouterVersion = "7.9.5");
} catch {}
function ph({ basename: u, children: s, window: a }) {
  let d = C.useRef();
  d.current == null && (d.current = Ud({ window: a, v5Compat: !0 }));
  let p = d.current,
    [y, S] = C.useState({ action: p.action, location: p.location }),
    E = C.useCallback(
      (k) => {
        C.startTransition(() => S(k));
      },
      [S],
    );
  return (
    C.useLayoutEffect(() => p.listen(E), [p, E]),
    C.createElement(Np, {
      basename: u,
      children: s,
      location: y.location,
      navigationType: y.action,
      navigator: p,
    })
  );
}
var Lc = /^(?:[a-z][a-z0-9+.-]*:|\/\/)/i,
  Tc = C.forwardRef(function (
    {
      onClick: s,
      discover: a = "render",
      prefetch: d = "none",
      relative: p,
      reloadDocument: y,
      replace: S,
      state: E,
      target: k,
      to: x,
      preventScrollReset: _,
      viewTransition: z,
      ...F
    },
    V,
  ) {
    let { basename: Y } = C.useContext(ht),
      H = typeof x == "string" && Lc.test(x),
      O,
      W = !1;
    if (typeof x == "string" && H && ((O = x), Nc))
      try {
        let Ce = new URL(window.location.href),
          De = x.startsWith("//") ? new URL(Ce.protocol + x) : new URL(x),
          vt = Dt(De.pathname, Y);
        De.origin === Ce.origin && vt != null
          ? (x = vt + De.search + De.hash)
          : (W = !0);
      } catch {
        pt(
          !1,
          `<Link to="${x}"> contains an invalid URL which will probably break when clicked - please update to a valid URL path.`,
        );
      }
    let A = dp(x, { relative: p }),
      [Z, ue, he] = Kp(d, F),
      ke = eh(x, {
        replace: S,
        state: E,
        target: k,
        preventScrollReset: _,
        relative: p,
        viewTransition: z,
      });
    function Ee(Ce) {
      (s && s(Ce), Ce.defaultPrevented || ke(Ce));
    }
    let Te = C.createElement("a", {
      ...F,
      ...he,
      href: O || A,
      onClick: W || y ? s : Ee,
      ref: Jp(V, ue),
      target: k,
      "data-discover": !H && a === "render" ? "true" : void 0,
    });
    return Z && !H
      ? C.createElement(C.Fragment, null, Te, C.createElement(Yp, { page: A }))
      : Te;
  });
Tc.displayName = "Link";
var Zp = C.forwardRef(function (
  {
    "aria-current": s = "page",
    caseSensitive: a = !1,
    className: d = "",
    end: p = !1,
    style: y,
    to: S,
    viewTransition: E,
    children: k,
    ...x
  },
  _,
) {
  let z = zr(S, { relative: x.relative }),
    F = bt(),
    V = C.useContext(Yl),
    { navigator: Y, basename: H } = C.useContext(ht),
    O = V != null && oh(z) && E === !0,
    W = Y.encodeLocation ? Y.encodeLocation(z).pathname : z.pathname,
    A = F.pathname,
    Z =
      V && V.navigation && V.navigation.location
        ? V.navigation.location.pathname
        : null;
  (a ||
    ((A = A.toLowerCase()),
    (Z = Z ? Z.toLowerCase() : null),
    (W = W.toLowerCase())),
    Z && H && (Z = Dt(Z, H) || Z));
  const ue = W !== "/" && W.endsWith("/") ? W.length - 1 : W.length;
  let he = A === W || (!p && A.startsWith(W) && A.charAt(ue) === "/"),
    ke =
      Z != null &&
      (Z === W || (!p && Z.startsWith(W) && Z.charAt(W.length) === "/")),
    Ee = { isActive: he, isPending: ke, isTransitioning: O },
    Te = he ? s : void 0,
    Ce;
  typeof d == "function"
    ? (Ce = d(Ee))
    : (Ce = [
        d,
        he ? "active" : null,
        ke ? "pending" : null,
        O ? "transitioning" : null,
      ]
        .filter(Boolean)
        .join(" "));
  let De = typeof y == "function" ? y(Ee) : y;
  return C.createElement(
    Tc,
    {
      ...x,
      "aria-current": Te,
      className: Ce,
      ref: _,
      style: De,
      to: S,
      viewTransition: E,
    },
    typeof k == "function" ? k(Ee) : k,
  );
});
Zp.displayName = "NavLink";
var qp = C.forwardRef(
  (
    {
      discover: u = "render",
      fetcherKey: s,
      navigate: a,
      reloadDocument: d,
      replace: p,
      state: y,
      method: S = Vl,
      action: E,
      onSubmit: k,
      relative: x,
      preventScrollReset: _,
      viewTransition: z,
      ...F
    },
    V,
  ) => {
    let Y = rh(),
      H = lh(E, { relative: x }),
      O = S.toLowerCase() === "get" ? "get" : "post",
      W = typeof E == "string" && Lc.test(E),
      A = (Z) => {
        if ((k && k(Z), Z.defaultPrevented)) return;
        Z.preventDefault();
        let ue = Z.nativeEvent.submitter,
          he = ue?.getAttribute("formmethod") || S;
        Y(ue || Z.currentTarget, {
          fetcherKey: s,
          method: he,
          navigate: a,
          replace: p,
          state: y,
          relative: x,
          preventScrollReset: _,
          viewTransition: z,
        });
      };
    return C.createElement("form", {
      ref: V,
      method: O,
      action: H,
      onSubmit: d ? k : A,
      ...F,
      "data-discover": !W && u === "render" ? "true" : void 0,
    });
  },
);
qp.displayName = "Form";
function bp(u) {
  return `${u} must be used within a data router.  See https://reactrouter.com/en/main/routers/picking-a-router.`;
}
function zc(u) {
  let s = C.useContext(An);
  return (pe(s, bp(u)), s);
}
function eh(
  u,
  {
    target: s,
    replace: a,
    state: d,
    preventScrollReset: p,
    relative: y,
    viewTransition: S,
  } = {},
) {
  let E = Cc(),
    k = bt(),
    x = zr(u, { relative: y });
  return C.useCallback(
    (_) => {
      if (Dp(_, s)) {
        _.preventDefault();
        let z = a !== void 0 ? a : Lr(k) === Lr(x);
        E(u, {
          replace: z,
          state: d,
          preventScrollReset: p,
          relative: y,
          viewTransition: S,
        });
      }
    },
    [k, E, x, a, d, s, u, p, y, S],
  );
}
var th = 0,
  nh = () => `__${String(++th)}__`;
function rh() {
  let { router: u } = zc("useSubmit"),
    { basename: s } = C.useContext(ht),
    a = Cp();
  return C.useCallback(
    async (d, p = {}) => {
      let { action: y, method: S, encType: E, formData: k, body: x } = Ip(d, s);
      if (p.navigate === !1) {
        let _ = p.fetcherKey || nh();
        await u.fetch(_, a, p.action || y, {
          preventScrollReset: p.preventScrollReset,
          formData: k,
          body: x,
          formMethod: p.method || S,
          formEncType: p.encType || E,
          flushSync: p.flushSync,
        });
      } else
        await u.navigate(p.action || y, {
          preventScrollReset: p.preventScrollReset,
          formData: k,
          body: x,
          formMethod: p.method || S,
          formEncType: p.encType || E,
          replace: p.replace,
          state: p.state,
          fromRouteId: a,
          flushSync: p.flushSync,
          viewTransition: p.viewTransition,
        });
    },
    [u, s, a],
  );
}
function lh(u, { relative: s } = {}) {
  let { basename: a } = C.useContext(ht),
    d = C.useContext(mt);
  pe(d, "useFormAction must be used inside a RouteContext");
  let [p] = d.matches.slice(-1),
    y = { ...zr(u || ".", { relative: s }) },
    S = bt();
  if (u == null) {
    y.search = S.search;
    let E = new URLSearchParams(y.search),
      k = E.getAll("index");
    if (k.some((_) => _ === "")) {
      (E.delete("index"),
        k.filter((z) => z).forEach((z) => E.append("index", z)));
      let _ = E.toString();
      y.search = _ ? `?${_}` : "";
    }
  }
  return (
    (!u || u === ".") &&
      p.route.index &&
      (y.search = y.search ? y.search.replace(/^\?/, "?index&") : "?index"),
    a !== "/" && (y.pathname = y.pathname === "/" ? a : Ot([a, y.pathname])),
    Lr(y)
  );
}
function oh(u, { relative: s } = {}) {
  let a = C.useContext(Sc);
  pe(
    a != null,
    "`useViewTransitionState` must be used within `react-router-dom`'s `RouterProvider`.  Did you accidentally import `RouterProvider` from `react-router`?",
  );
  let { basename: d } = zc("useViewTransitionState"),
    p = zr(u, { relative: s });
  if (!a.isTransitioning) return !1;
  let y = Dt(a.currentLocation.pathname, d) || a.currentLocation.pathname,
    S = Dt(a.nextLocation.pathname, d) || a.nextLocation.pathname;
  return Kl(p.pathname, S) != null || Kl(p.pathname, y) != null;
}
var uh = mc();
const hh = qu(uh);
export {
  ph as B,
  Tc as L,
  fh as N,
  ah as R,
  uh as a,
  hh as b,
  Dd as c,
  bt as d,
  ch as e,
  dh as f,
  qu as g,
  Rp as h,
  sh as i,
  ih as j,
  C as r,
  Cc as u,
};
