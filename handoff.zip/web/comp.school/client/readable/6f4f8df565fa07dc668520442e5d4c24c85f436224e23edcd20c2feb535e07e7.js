function Pt(e) {
  if (e instanceof Blob) return jt(e);
  throw new Error("Unsupported file content type. Expected a `Blob`");
}
function jt(e) {
  return e.arrayBuffer().then(function (r) {
    return new Uint8Array(r);
  });
}
var dr = {},
  $t = function (e, r, t, n, o) {
    var a = new Worker(
      dr[r] ||
        (dr[r] = URL.createObjectURL(
          new Blob(
            [
              e +
                ';addEventListener("error",function(e){e=e.error;postMessage({$e$:[e.message,e.code,e.stack]})})',
            ],
            { type: "text/javascript" },
          ),
        )),
    );
    return (
      (a.onmessage = function (l) {
        var s = l.data,
          i = s.$e$;
        if (i) {
          var f = new Error(i[0]);
          ((f.code = i[1]), (f.stack = i[2]), o(f, null));
        } else o(null, s);
      }),
      a.postMessage(t, n),
      a
    );
  },
  R = Uint8Array,
  U = Uint16Array,
  Ne = Int32Array,
  ze = new R([
    0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5,
    5, 5, 5, 0, 0, 0, 0,
  ]),
  Ve = new R([
    0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10,
    11, 11, 12, 12, 13, 13, 0, 0,
  ]),
  We = new R([
    16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15,
  ]),
  qr = function (e, r) {
    for (var t = new U(31), n = 0; n < 31; ++n) t[n] = r += 1 << e[n - 1];
    for (var o = new Ne(t[30]), n = 1; n < 30; ++n)
      for (var a = t[n]; a < t[n + 1]; ++a) o[a] = ((a - t[n]) << 5) | n;
    return { b: t, r: o };
  },
  Yr = qr(ze, 2),
  Rt = Yr.b,
  je = Yr.r;
((Rt[28] = 258), (je[258] = 28));
var Lt = qr(Ve, 0),
  Ge = Lt.r,
  $e = new U(32768);
for (var O = 0; O < 32768; ++O) {
  var q = ((O & 43690) >> 1) | ((O & 21845) << 1);
  ((q = ((q & 52428) >> 2) | ((q & 13107) << 2)),
    (q = ((q & 61680) >> 4) | ((q & 3855) << 4)),
    ($e[O] = (((q & 65280) >> 8) | ((q & 255) << 8)) >> 1));
}
var le = function (e, r, t) {
    for (var n = e.length, o = 0, a = new U(r); o < n; ++o)
      e[o] && ++a[e[o] - 1];
    var l = new U(r);
    for (o = 1; o < r; ++o) l[o] = (l[o - 1] + a[o - 1]) << 1;
    var s;
    if (t) {
      s = new U(1 << r);
      var i = 15 - r;
      for (o = 0; o < n; ++o)
        if (e[o])
          for (
            var f = (o << 4) | e[o],
              u = r - e[o],
              d = l[e[o] - 1]++ << u,
              c = d | ((1 << u) - 1);
            d <= c;
            ++d
          )
            s[$e[d] >> i] = f;
    } else
      for (s = new U(n), o = 0; o < n; ++o)
        e[o] && (s[o] = $e[l[e[o] - 1]++] >> (15 - e[o]));
    return s;
  },
  J = new R(288);
for (var O = 0; O < 144; ++O) J[O] = 8;
for (var O = 144; O < 256; ++O) J[O] = 9;
for (var O = 256; O < 280; ++O) J[O] = 7;
for (var O = 280; O < 288; ++O) J[O] = 8;
var xe = new R(32);
for (var O = 0; O < 32; ++O) xe[O] = 5;
var Jr = le(J, 9, 0),
  Zr = le(xe, 5, 0),
  rr = function (e) {
    return ((e + 7) / 8) | 0;
  },
  tr = function (e, r, t) {
    return (
      (r == null || r < 0) && (r = 0),
      (t == null || t > e.length) && (t = e.length),
      new R(e.subarray(r, t))
    );
  },
  Mt = [
    "unexpected EOF",
    "invalid block type",
    "invalid length/literal",
    "invalid distance",
    "stream finished",
    "no stream handler",
    ,
    "no callback",
    "invalid UTF-8 data",
    "extra field too long",
    "date not in range 1980-2099",
    "filename too long",
    "stream finishing",
    "invalid zip data",
  ],
  se = function (e, r, t) {
    var n = new Error(r || Mt[e]);
    if (
      ((n.code = e),
      Error.captureStackTrace && Error.captureStackTrace(n, se),
      !t)
    )
      throw n;
    return n;
  },
  H = function (e, r, t) {
    t <<= r & 7;
    var n = (r / 8) | 0;
    ((e[n] |= t), (e[n + 1] |= t >> 8));
  },
  oe = function (e, r, t) {
    t <<= r & 7;
    var n = (r / 8) | 0;
    ((e[n] |= t), (e[n + 1] |= t >> 8), (e[n + 2] |= t >> 16));
  },
  De = function (e, r) {
    for (var t = [], n = 0; n < e.length; ++n)
      e[n] && t.push({ s: n, f: e[n] });
    var o = t.length,
      a = t.slice();
    if (!o) return { t: or, l: 0 };
    if (o == 1) {
      var l = new R(t[0].s + 1);
      return ((l[t[0].s] = 1), { t: l, l: 1 });
    }
    (t.sort(function (w, I) {
      return w.f - I.f;
    }),
      t.push({ s: -1, f: 25001 }));
    var s = t[0],
      i = t[1],
      f = 0,
      u = 1,
      d = 2;
    for (t[0] = { s: -1, f: s.f + i.f, l: s, r: i }; u != o - 1;)
      ((s = t[t[f].f < t[d].f ? f++ : d++]),
        (i = t[f != u && t[f].f < t[d].f ? f++ : d++]),
        (t[u++] = { s: -1, f: s.f + i.f, l: s, r: i }));
    for (var c = a[0].s, n = 1; n < o; ++n) a[n].s > c && (c = a[n].s);
    var v = new U(c + 1),
      b = Re(t[u - 1], v, 0);
    if (b > r) {
      var n = 0,
        g = 0,
        m = b - r,
        C = 1 << m;
      for (
        a.sort(function (I, x) {
          return v[x.s] - v[I.s] || I.f - x.f;
        });
        n < o;
        ++n
      ) {
        var F = a[n].s;
        if (v[F] > r) ((g += C - (1 << (b - v[F]))), (v[F] = r));
        else break;
      }
      for (g >>= m; g > 0;) {
        var S = a[n].s;
        v[S] < r ? (g -= 1 << (r - v[S]++ - 1)) : ++n;
      }
      for (; n >= 0 && g; --n) {
        var h = a[n].s;
        v[h] == r && (--v[h], ++g);
      }
      b = r;
    }
    return { t: new R(v), l: b };
  },
  Re = function (e, r, t) {
    return e.s == -1
      ? Math.max(Re(e.l, r, t + 1), Re(e.r, r, t + 1))
      : (r[e.s] = t);
  },
  Ke = function (e) {
    for (var r = e.length; r && !e[--r];);
    for (
      var t = new U(++r),
        n = 0,
        o = e[0],
        a = 1,
        l = function (i) {
          t[n++] = i;
        },
        s = 1;
      s <= r;
      ++s
    )
      if (e[s] == o && s != r) ++a;
      else {
        if (!o && a > 2) {
          for (; a > 138; a -= 138) l(32754);
          a > 2 &&
            (l(a > 10 ? ((a - 11) << 5) | 28690 : ((a - 3) << 5) | 12305),
            (a = 0));
        } else if (a > 3) {
          for (l(o), --a; a > 6; a -= 6) l(8304);
          a > 2 && (l(((a - 3) << 5) | 8208), (a = 0));
        }
        for (; a--;) l(o);
        ((a = 1), (o = e[s]));
      }
    return { c: t.subarray(0, n), n: r };
  },
  ae = function (e, r) {
    for (var t = 0, n = 0; n < r.length; ++n) t += e[n] * r[n];
    return t;
  },
  nr = function (e, r, t) {
    var n = t.length,
      o = rr(r + 2);
    ((e[o] = n & 255),
      (e[o + 1] = n >> 8),
      (e[o + 2] = e[o] ^ 255),
      (e[o + 3] = e[o + 1] ^ 255));
    for (var a = 0; a < n; ++a) e[o + a + 4] = t[a];
    return (o + 4 + n) * 8;
  },
  qe = function (e, r, t, n, o, a, l, s, i, f, u) {
    (H(r, u++, t), ++o[256]);
    for (
      var d = De(o, 15),
        c = d.t,
        v = d.l,
        b = De(a, 15),
        g = b.t,
        m = b.l,
        C = Ke(c),
        F = C.c,
        S = C.n,
        h = Ke(g),
        w = h.c,
        I = h.n,
        x = new U(19),
        y = 0;
      y < F.length;
      ++y
    )
      ++x[F[y] & 31];
    for (var y = 0; y < w.length; ++y) ++x[w[y] & 31];
    for (
      var p = De(x, 7), A = p.t, D = p.l, k = 19;
      k > 4 && !A[We[k - 1]];
      --k
    );
    var M = (f + 5) << 3,
      E = ae(o, J) + ae(a, xe) + l,
      B =
        ae(o, c) +
        ae(a, g) +
        l +
        14 +
        3 * k +
        ae(x, A) +
        2 * x[16] +
        3 * x[17] +
        7 * x[18];
    if (i >= 0 && M <= E && M <= B) return nr(r, u, e.subarray(i, i + f));
    var P, T, L, _;
    if ((H(r, u, 1 + (B < E)), (u += 2), B < E)) {
      ((P = le(c, v, 0)), (T = c), (L = le(g, m, 0)), (_ = g));
      var ce = le(A, D, 0);
      (H(r, u, S - 257), H(r, u + 5, I - 1), H(r, u + 10, k - 4), (u += 14));
      for (var y = 0; y < k; ++y) H(r, u + 3 * y, A[We[y]]);
      u += 3 * k;
      for (var z = [F, w], Z = 0; Z < 2; ++Z)
        for (var K = z[Z], y = 0; y < K.length; ++y) {
          var V = K[y] & 31;
          (H(r, u, ce[V]),
            (u += A[V]),
            V > 15 && (H(r, u, (K[y] >> 5) & 127), (u += K[y] >> 12)));
        }
    } else ((P = Jr), (T = J), (L = Zr), (_ = xe));
    for (var y = 0; y < s; ++y) {
      var j = n[y];
      if (j > 255) {
        var V = (j >> 18) & 31;
        (oe(r, u, P[V + 257]),
          (u += T[V + 257]),
          V > 7 && (H(r, u, (j >> 23) & 31), (u += ze[V])));
        var X = j & 31;
        (oe(r, u, L[X]),
          (u += _[X]),
          X > 3 && (oe(r, u, (j >> 5) & 8191), (u += Ve[X])));
      } else (oe(r, u, P[j]), (u += T[j]));
    }
    return (oe(r, u, P[256]), u + T[256]);
  },
  Qr = new Ne([
    65540, 131080, 131088, 131104, 262176, 1048704, 1048832, 2114560, 2117632,
  ]),
  or = new R(0),
  et = function (e, r, t, n, o, a) {
    var l = a.z || e.length,
      s = new R(n + l + 5 * (1 + Math.ceil(l / 7e3)) + o),
      i = s.subarray(n, s.length - o),
      f = a.l,
      u = (a.r || 0) & 7;
    if (r) {
      u && (i[0] = a.r >> 3);
      for (
        var d = Qr[r - 1],
          c = d >> 13,
          v = d & 8191,
          b = (1 << t) - 1,
          g = a.p || new U(32768),
          m = a.h || new U(b + 1),
          C = Math.ceil(t / 3),
          F = 2 * C,
          S = function (ee) {
            return (e[ee] ^ (e[ee + 1] << C) ^ (e[ee + 2] << F)) & b;
          },
          h = new Ne(25e3),
          w = new U(288),
          I = new U(32),
          x = 0,
          y = 0,
          p = a.i || 0,
          A = 0,
          D = a.w || 0,
          k = 0;
        p + 2 < l;
        ++p
      ) {
        var M = S(p),
          E = p & 32767,
          B = m[M];
        if (((g[E] = B), (m[M] = E), D <= p)) {
          var P = l - p;
          if ((x > 7e3 || A > 24576) && (P > 423 || !f)) {
            ((u = qe(e, i, 0, h, w, I, y, A, k, p - k, u)),
              (A = x = y = 0),
              (k = p));
            for (var T = 0; T < 286; ++T) w[T] = 0;
            for (var T = 0; T < 30; ++T) I[T] = 0;
          }
          var L = 2,
            _ = 0,
            ce = v,
            z = (E - B) & 32767;
          if (P > 2 && M == S(p - z))
            for (
              var Z = Math.min(c, P) - 1,
                K = Math.min(32767, p),
                V = Math.min(258, P);
              z <= K && --ce && E != B;
            ) {
              if (e[p + L] == e[p + L - z]) {
                for (var j = 0; j < V && e[p + j] == e[p + j - z]; ++j);
                if (j > L) {
                  if (((L = j), (_ = z), j > Z)) break;
                  for (var X = Math.min(z, j - 2), de = 0, T = 0; T < X; ++T) {
                    var Q = (p - z + T) & 32767,
                      _e = g[Q],
                      me = (Q - _e) & 32767;
                    me > de && ((de = me), (B = Q));
                  }
                }
              }
              ((E = B), (B = g[E]), (z += (E - B) & 32767));
            }
          if (_) {
            h[A++] = 268435456 | (je[L] << 18) | Ge[_];
            var ve = je[L] & 31,
              ge = Ge[_] & 31;
            ((y += ze[ve] + Ve[ge]), ++w[257 + ve], ++I[ge], (D = p + L), ++x);
          } else ((h[A++] = e[p]), ++w[e[p]]);
        }
      }
      for (p = Math.max(p, D); p < l; ++p) ((h[A++] = e[p]), ++w[e[p]]);
      ((u = qe(e, i, f, h, w, I, y, A, k, p - k, u)),
        f ||
          ((a.r = (u & 7) | (i[(u / 8) | 0] << 3)),
          (u -= 7),
          (a.h = m),
          (a.p = g),
          (a.i = p),
          (a.w = D)));
    } else {
      for (var p = a.w || 0; p < l + f; p += 65535) {
        var te = p + 65535;
        (te >= l && ((i[(u / 8) | 0] = f), (te = l)),
          (u = nr(i, u + 1, e.subarray(p, te))));
      }
      a.i = l;
    }
    return tr(s, 0, n + rr(u) + o);
  },
  Ut = (function () {
    for (var e = new Int32Array(256), r = 0; r < 256; ++r) {
      for (var t = r, n = 9; --n;) t = (t & 1 && -306674912) ^ (t >>> 1);
      e[r] = t;
    }
    return e;
  })(),
  Nt = function () {
    var e = -1;
    return {
      p: function (r) {
        for (var t = e, n = 0; n < r.length; ++n)
          t = Ut[(t & 255) ^ r[n]] ^ (t >>> 8);
        e = t;
      },
      d: function () {
        return ~e;
      },
    };
  },
  rt = function (e, r, t, n, o) {
    if (!o && ((o = { l: 1 }), r.dictionary)) {
      var a = r.dictionary.subarray(-32768),
        l = new R(a.length + e.length);
      (l.set(a), l.set(e, a.length), (e = l), (o.w = a.length));
    }
    return et(
      e,
      r.level == null ? 6 : r.level,
      r.mem == null
        ? o.l
          ? Math.ceil(Math.max(8, Math.min(13, Math.log(e.length))) * 1.5)
          : 20
        : 12 + r.mem,
      t,
      n,
      o,
    );
  },
  ar = function (e, r) {
    var t = {};
    for (var n in e) t[n] = e[n];
    for (var n in r) t[n] = r[n];
    return t;
  },
  mr = function (e, r, t) {
    for (
      var n = e(),
        o = e.toString(),
        a = o
          .slice(o.indexOf("[") + 1, o.lastIndexOf("]"))
          .replace(/\s+/g, "")
          .split(","),
        l = 0;
      l < n.length;
      ++l
    ) {
      var s = n[l],
        i = a[l];
      if (typeof s == "function") {
        r += ";" + i + "=";
        var f = s.toString();
        if (s.prototype)
          if (f.indexOf("[native code]") != -1) {
            var u = f.indexOf(" ", 8) + 1;
            r += f.slice(u, f.indexOf("(", u));
          } else {
            r += f;
            for (var d in s.prototype)
              r +=
                ";" + i + ".prototype." + d + "=" + s.prototype[d].toString();
          }
        else r += f;
      } else t[i] = s;
    }
    return r;
  },
  Ae = [],
  zt = function (e) {
    var r = [];
    for (var t in e)
      e[t].buffer && r.push((e[t] = new e[t].constructor(e[t])).buffer);
    return r;
  },
  Vt = function (e, r, t, n) {
    if (!Ae[t]) {
      for (var o = "", a = {}, l = e.length - 1, s = 0; s < l; ++s)
        o = mr(e[s], o, a);
      Ae[t] = { c: mr(e[l], o, a), e: a };
    }
    var i = ar({}, Ae[t].e);
    return $t(
      Ae[t].c +
        ";onmessage=function(e){for(var k in e.data)self[k]=e.data[k];onmessage=" +
        r.toString() +
        "}",
      t,
      i,
      zt(i),
      n,
    );
  },
  Xt = function () {
    return [
      R,
      U,
      Ne,
      ze,
      Ve,
      We,
      je,
      Ge,
      Jr,
      J,
      Zr,
      xe,
      $e,
      Qr,
      or,
      le,
      H,
      oe,
      De,
      Re,
      Ke,
      ae,
      nr,
      qe,
      rr,
      tr,
      et,
      rt,
      ir,
      tt,
    ];
  },
  tt = function (e) {
    return postMessage(e, [e.buffer]);
  },
  _t = function (e, r, t, n, o, a) {
    var l = Vt(t, n, o, function (s, i) {
      (l.terminate(), a(s, i));
    });
    return (
      l.postMessage([e, r], r.consume ? [e.buffer] : []),
      function () {
        l.terminate();
      }
    );
  },
  $ = function (e, r, t) {
    for (; t; ++r) ((e[r] = t), (t >>>= 8));
  };
function Ht(e, r, t) {
  return (
    t || ((t = r), (r = {})),
    typeof t != "function" && se(7),
    _t(
      e,
      r,
      [Xt],
      function (n) {
        return tt(ir(n.data[0], n.data[1]));
      },
      0,
      t,
    )
  );
}
function ir(e, r) {
  return rt(e, r || {}, 0, 0);
}
var nt = function (e, r, t, n) {
    for (var o in e) {
      var a = e[o],
        l = r + o,
        s = n;
      (Array.isArray(a) && ((s = ar(n, a[1])), (a = a[0])),
        a instanceof R
          ? (t[l] = [a, s])
          : ((t[(l += "/")] = [new R(0), s]), nt(a, l, t, n)));
    }
  },
  vr = typeof TextEncoder < "u" && new TextEncoder(),
  Wt = typeof TextDecoder < "u" && new TextDecoder(),
  Gt = 0;
try {
  (Wt.decode(or, { stream: !0 }), (Gt = 1));
} catch {}
function Ye(e, r) {
  var t;
  if (vr) return vr.encode(e);
  for (
    var n = e.length,
      o = new R(e.length + (e.length >> 1)),
      a = 0,
      l = function (f) {
        o[a++] = f;
      },
      t = 0;
    t < n;
    ++t
  ) {
    if (a + 5 > o.length) {
      var s = new R(a + 8 + ((n - t) << 1));
      (s.set(o), (o = s));
    }
    var i = e.charCodeAt(t);
    i < 128 || r
      ? l(i)
      : i < 2048
        ? (l(192 | (i >> 6)), l(128 | (i & 63)))
        : i > 55295 && i < 57344
          ? ((i = (65536 + (i & 1047552)) | (e.charCodeAt(++t) & 1023)),
            l(240 | (i >> 18)),
            l(128 | ((i >> 12) & 63)),
            l(128 | ((i >> 6) & 63)),
            l(128 | (i & 63)))
          : (l(224 | (i >> 12)), l(128 | ((i >> 6) & 63)), l(128 | (i & 63)));
  }
  return tr(o, 0, a);
}
var Je = function (e) {
    var r = 0;
    if (e)
      for (var t in e) {
        var n = e[t].length;
        (n > 65535 && se(9), (r += n + 4));
      }
    return r;
  },
  gr = function (e, r, t, n, o, a, l, s) {
    var i = n.length,
      f = t.extra,
      u = s && s.length,
      d = Je(f);
    ($(e, r, l != null ? 33639248 : 67324752),
      (r += 4),
      l != null && ((e[r++] = 20), (e[r++] = t.os)),
      (e[r] = 20),
      (r += 2),
      (e[r++] = (t.flag << 1) | (a < 0 && 8)),
      (e[r++] = o && 8),
      (e[r++] = t.compression & 255),
      (e[r++] = t.compression >> 8));
    var c = new Date(t.mtime == null ? Date.now() : t.mtime),
      v = c.getFullYear() - 1980;
    if (
      ((v < 0 || v > 119) && se(10),
      $(
        e,
        r,
        (v << 25) |
          ((c.getMonth() + 1) << 21) |
          (c.getDate() << 16) |
          (c.getHours() << 11) |
          (c.getMinutes() << 5) |
          (c.getSeconds() >> 1),
      ),
      (r += 4),
      a != -1 &&
        ($(e, r, t.crc), $(e, r + 4, a < 0 ? -a - 2 : a), $(e, r + 8, t.size)),
      $(e, r + 12, i),
      $(e, r + 14, d),
      (r += 16),
      l != null &&
        ($(e, r, u), $(e, r + 6, t.attrs), $(e, r + 10, l), (r += 14)),
      e.set(n, r),
      (r += i),
      d)
    )
      for (var b in f) {
        var g = f[b],
          m = g.length;
        ($(e, r, +b), $(e, r + 2, m), e.set(g, r + 4), (r += 4 + m));
      }
    return (u && (e.set(s, r), (r += u)), r);
  },
  Kt = function (e, r, t, n, o) {
    ($(e, r, 101010256),
      $(e, r + 8, t),
      $(e, r + 10, t),
      $(e, r + 12, n),
      $(e, r + 16, o));
  };
function qt(e, r, t) {
  (t || ((t = r), (r = {})), typeof t != "function" && se(7));
  var n = {};
  nt(e, "", n, r);
  var o = Object.keys(n),
    a = o.length,
    l = 0,
    s = 0,
    i = a,
    f = new Array(a),
    u = [],
    d = function () {
      for (var m = 0; m < u.length; ++m) u[m]();
    },
    c = function (m, C) {
      hr(function () {
        t(m, C);
      });
    };
  hr(function () {
    c = t;
  });
  var v = function () {
    var m = new R(s + 22),
      C = l,
      F = s - l;
    s = 0;
    for (var S = 0; S < i; ++S) {
      var h = f[S];
      try {
        var w = h.c.length;
        gr(m, s, h, h.f, h.u, w);
        var I = 30 + h.f.length + Je(h.extra),
          x = s + I;
        (m.set(h.c, x),
          gr(m, l, h, h.f, h.u, w, s, h.m),
          (l += 16 + I + (h.m ? h.m.length : 0)),
          (s = x + w));
      } catch (y) {
        return c(y, null);
      }
    }
    (Kt(m, l, f.length, F, C), c(null, m));
  };
  a || v();
  for (
    var b = function (m) {
        var C = o[m],
          F = n[C],
          S = F[0],
          h = F[1],
          w = Nt(),
          I = S.length;
        w.p(S);
        var x = Ye(C),
          y = x.length,
          p = h.comment,
          A = p && Ye(p),
          D = A && A.length,
          k = Je(h.extra),
          M = h.level == 0 ? 0 : 8,
          E = function (B, P) {
            if (B) (d(), c(B, null));
            else {
              var T = P.length;
              ((f[m] = ar(h, {
                size: I,
                crc: w.d(),
                c: P,
                f: x,
                m: A,
                u: y != C.length || (A && p.length != D),
                compression: M,
              })),
                (l += 30 + y + k + T),
                (s += 76 + 2 * (y + k) + (D || 0) + T),
                --a || v());
            }
          };
        if ((y > 65535 && E(se(11, 0, 1), null), !M)) E(null, S);
        else if (I < 16e4)
          try {
            E(null, ir(S, h));
          } catch (B) {
            E(B, null);
          }
        else u.push(Ht(S, h, E));
      },
      g = 0;
    g < i;
    ++g
  )
    b(g);
  return d;
}
var hr =
  typeof queueMicrotask == "function"
    ? queueMicrotask
    : typeof setTimeout == "function"
      ? setTimeout
      : function (e) {
          e();
        };
function Yt(e) {
  return Jt(e).then(function (r) {
    return r.buffer;
  });
}
function Jt(e) {
  return new Promise(function (r, t) {
    qt(e, function (n, o) {
      n ? t(n) : r(o);
    });
  });
}
function Zt(e, r) {
  var t = {};
  return Promise.all(
    Object.keys(e).map(function (n) {
      if (e[n] instanceof Uint8Array) t[n] = e[n];
      else if (typeof e[n] == "string") t[n] = Qt(e[n]);
      else
        return r(e[n]).then(function (o) {
          t[n] = o;
        });
    }),
  ).then(function () {
    return t;
  });
}
function Qt(e) {
  return Ye(e);
}
function en(e, r) {
  var t = (typeof Symbol < "u" && e[Symbol.iterator]) || e["@@iterator"];
  if (t) return (t = t.call(e)).next.bind(t);
  if (Array.isArray(e) || (t = rn(e)) || r) {
    t && (e = t);
    var n = 0;
    return function () {
      return n >= e.length ? { done: !0 } : { done: !1, value: e[n++] };
    };
  }
  throw new TypeError(`Invalid attempt to iterate non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
}
function rn(e, r) {
  if (e) {
    if (typeof e == "string") return pr(e, r);
    var t = {}.toString.call(e).slice(8, -1);
    return (
      t === "Object" && e.constructor && (t = e.constructor.name),
      t === "Map" || t === "Set"
        ? Array.from(e)
        : t === "Arguments" ||
            /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t)
          ? pr(e, r)
          : void 0
    );
  }
}
function pr(e, r) {
  (r == null || r > e.length) && (r = e.length);
  for (var t = 0, n = Array(r); t < r; t++) n[t] = e[t];
  return n;
}
function W(e, r, t, n) {
  for (var o = "", a = en(r), l; !(l = a()).done;) {
    var s = l.value,
      i = s.files && s.files.transform && s.files.transform[e];
    if (i && i.insert) {
      var f = i.insert(t, n);
      f && (o += f);
    }
  }
  return o;
}
function tn(e, r) {
  var t = (typeof Symbol < "u" && e[Symbol.iterator]) || e["@@iterator"];
  if (t) return (t = t.call(e)).next.bind(t);
  if (Array.isArray(e) || (t = nn(e)) || r) {
    t && (e = t);
    var n = 0;
    return function () {
      return n >= e.length ? { done: !0 } : { done: !1, value: e[n++] };
    };
  }
  throw new TypeError(`Invalid attempt to iterate non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
}
function nn(e, r) {
  if (e) {
    if (typeof e == "string") return yr(e, r);
    var t = {}.toString.call(e).slice(8, -1);
    return (
      t === "Object" && e.constructor && (t = e.constructor.name),
      t === "Map" || t === "Set"
        ? Array.from(e)
        : t === "Arguments" ||
            /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t)
          ? yr(e, r)
          : void 0
    );
  }
}
function yr(e, r) {
  (r == null || r > e.length) && (r = e.length);
  for (var t = 0, n = Array(r); t < r; t++) n[t] = e[t];
  return n;
}
function G(e, r, t, n, o) {
  for (var a = tn(t), l; !(l = a()).done;) {
    var s = l.value,
      i = s.files && s.files.transform && s.files.transform[r];
    i && i.transform && (e = i.transform(e, n, o));
  }
  return e;
}
function ot(e, r) {
  var t = r.isAttributeValue;
  return (
    (e = be(e, "&", "&amp;")),
    (e = be(e, ">", "&gt;")),
    (e = be(e, "<", "&lt;")),
    t && ((e = be(e, "'", "&apos;")), (e = be(e, '"', "&quot;"))),
    e
  );
}
function be(e, r, t) {
  return e.replaceAll ? e.replaceAll(r, t) : e.replace(new RegExp(r, "g"), t);
}
var on =
    /((?:[\0-\x08\x0B\f\x0E-\x1F\uFFFD\uFFFE\uFFFF]|[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?:[^\uD800-\uDBFF]|^)[\uDC00-\uDFFF]))/g,
  an = new RegExp(
    "([\\x7F-\\x84]|[\\x86-\\x9F]|[\\uFDD0-\\uFDEF]|(?:\\uD83F[\\uDFFE\\uDFFF])|(?:\\uD87F[\\uDFFE\\uDFFF])|(?:\\uD8BF[\\uDFFE\\uDFFF])|(?:\\uD8FF[\\uDFFE\\uDFFF])|(?:\\uD93F[\\uDFFE\\uDFFF])|(?:\\uD97F[\\uDFFE\\uDFFF])|(?:\\uD9BF[\\uDFFE\\uDFFF])|(?:\\uD9FF[\\uDFFE\\uDFFF])|(?:\\uDA3F[\\uDFFE\\uDFFF])|(?:\\uDA7F[\\uDFFE\\uDFFF])|(?:\\uDABF[\\uDFFE\\uDFFF])|(?:\\uDAFF[\\uDFFE\\uDFFF])|(?:\\uDB3F[\\uDFFE\\uDFFF])|(?:\\uDB7F[\\uDFFE\\uDFFF])|(?:\\uDBBF[\\uDFFE\\uDFFF])|(?:\\uDBFF[\\uDFFE\\uDFFF])(?:[\\0-\\t\\x0B\\f\\x0E-\\u2027\\u202A-\\uD7FF\\uE000-\\uFFFF]|[\\uD800-\\uDBFF][\\uDC00-\\uDFFF]|[\\uD800-\\uDBFF](?![\\uDC00-\\uDFFF])|(?:[^\\uD800-\\uDBFF]|^)[\\uDC00-\\uDFFF]))",
    "g",
  );
function lr(e) {
  return ((e = e.replace(on, "")), (e = e.replace(an, "")), e);
}
function N(e) {
  if (typeof e != "string") throw new TypeError("Argument must be a string");
  return ((e = lr(e)), ot(e, { isAttributeValue: !0 }));
}
function ln(e) {
  if (typeof e != "string") throw new TypeError("Argument must be a string");
  return (
    (e = lr(e)),
    e.replace(/[^a-zA-Z_0-9-.:]/g, "").replace(/^[^a-zA-Z_]+/, "")
  );
}
function sn(e) {
  return Object.keys(e)
    .map(function (r) {
      return "".concat(ln(r), '="').concat(N(String(e[r])), '"');
    })
    .reduce(function (r, t) {
      return r + " " + t;
    }, "");
}
function Le(e, r) {
  return "<" + e + (r ? sn(r) : "") + ">";
}
function Ze(e) {
  return "</" + e + ">";
}
function Me(e, r) {
  return Le(e, r).slice(0, -1) + "/>";
}
function fn(e, r) {
  var t = (typeof Symbol < "u" && e[Symbol.iterator]) || e["@@iterator"];
  if (t) return (t = t.call(e)).next.bind(t);
  if (Array.isArray(e) || (t = un(e)) || r) {
    t && (e = t);
    var n = 0;
    return function () {
      return n >= e.length ? { done: !0 } : { done: !1, value: e[n++] };
    };
  }
  throw new TypeError(`Invalid attempt to iterate non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
}
function un(e, r) {
  if (e) {
    if (typeof e == "string") return br(e, r);
    var t = {}.toString.call(e).slice(8, -1);
    return (
      t === "Object" && e.constructor && (t = e.constructor.name),
      t === "Map" || t === "Set"
        ? Array.from(e)
        : t === "Arguments" ||
            /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t)
          ? br(e, r)
          : void 0
    );
  }
}
function br(e, r) {
  (r == null || r > e.length) && (r = e.length);
  for (var t = 0, n = Array(r); t < r; t++) n[t] = e[t];
  return n;
}
function at(e, r, t, n, o, a, l, s) {
  for (var i = fn(s), f; !(f = i()).done;) {
    var u = f.value,
      d = u.files && u.files.transform && u.files.transform[e];
    d &&
      d.transformElementAttributes &&
      (t = d.transformElementAttributes(r, t || cn, o, l, a));
  }
  return n ? Le(r, t) + n + Ze(r) : Me(r, t);
}
var cn = {};
function dn(e) {
  var r = e.sheetIdsAndNames,
    t = e.features,
    n = e.sheetsOptions,
    o = function (s, i, f, u) {
      return at("xl/workbook.xml", s, i, f, u, mn, n, t);
    },
    a =
      '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:mx="http://schemas.microsoft.com/office/mac/excel/2008/main" xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006" xmlns:mv="urn:schemas-microsoft-com:mac:vml" xmlns:x14="http://schemas.microsoft.com/office/spreadsheetml/2009/9/main" xmlns:x14ac="http://schemas.microsoft.com/office/spreadsheetml/2009/9/ac" xmlns:xm="http://schemas.microsoft.com/office/excel/2006/main">' +
      o("workbookPr") +
      o("bookViews", null, o("workbookView", null, null, 0)) +
      o(
        "sheets",
        null,
        r
          .map(function (l, s) {
            var i = l.sheetId,
              f = l.sheetName;
            return o(
              "sheet",
              { "r:id": "rId".concat(i), sheetId: i, name: f },
              null,
              s,
            );
          })
          .join(""),
      ) +
      o("definedNames") +
      o("calcPr") +
      W("xl/workbook.xml", t, n) +
      "</workbook>";
  return ((a = G(a, "xl/workbook.xml", t, n)), a);
}
var mn = {};
function vn(e) {
  var r = e.sheetIds,
    t = e.features,
    n = e.sheetsOptions,
    o =
      '<?xml version="1.0" ?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' +
      r
        .map(function (a) {
          return '<Relationship Id="rId'
            .concat(
              a,
              '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet',
            )
            .concat(a, '.xml"/>');
        })
        .join("") +
      '<Relationship Id="rId'.concat(
        r.length + 1,
        '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/sharedStrings" Target="sharedStrings.xml"/>',
      ) +
      '<Relationship Id="rId'.concat(
        r.length + 2,
        '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>',
      ) +
      W("xl/_rels/workbook.xml.rels", t, n) +
      "</Relationships>";
  return ((o = G(o, "xl/_rels/workbook.xml.rels", t, n)), o);
}
function gn(e) {
  var r = e.features,
    t = e.sheetsOptions,
    n =
      '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId-workbook-1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>' +
      W("_rels/.rels", r, t) +
      "</Relationships>";
  return ((n = G(n, "_rels/.rels", r, t)), n);
}
function hn(e) {
  var r = e.sheetIds,
    t = e.features,
    n = e.sheetsOptions,
    o =
      '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default ContentType="application/xml" Extension="xml"/><Default ContentType="application/vnd.openxmlformats-package.relationships+xml" Extension="rels"/><Override ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml" PartName="/xl/workbook.xml"/><Override ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml" PartName="/xl/sharedStrings.xml"/><Override ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml" PartName="/xl/styles.xml"/>' +
      r
        .map(function (a) {
          return '<Override ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml" PartName="/xl/worksheets/sheet'.concat(
            a,
            '.xml"/>',
          );
        })
        .join("") +
      r
        .map(function (a) {
          return it(a);
        })
        .join("") +
      W("[Content_Types].xml", t, n) +
      "</Types>";
  return ((o = G(o, "[Content_Types].xml", t, n)), o);
}
function it(e) {
  return '<Override ContentType="application/vnd.openxmlformats-officedocument.drawing+xml" PartName="/xl/drawings/drawing'.concat(
    e,
    '.xml"/>',
  );
}
function pn(e) {
  var r = e.sheetIndex,
    t = e.sheetId,
    n = e.sheetOptions,
    o = e.features,
    a =
      lt +
      W("xl/drawings/drawing{id}.xml", o, n, { sheetIndex: r, sheetId: t }) +
      st;
  return (
    (a = G(a, "xl/drawings/drawing{id}.xml", o, n, {
      sheetIndex: r,
      sheetId: t,
    })),
    a
  );
}
var lt =
    '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><xdr:wsDr xmlns:xdr="http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">',
  st = "</xdr:wsDr>";
function yn(e) {
  var r = e.sheetIndex,
    t = e.sheetId,
    n = e.sheetOptions,
    o = e.features,
    a =
      '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' +
      W("xl/drawings/_rels/drawing{id}.xml.rels", o, n, {
        sheetIndex: r,
        sheetId: t,
      }) +
      "</Relationships>";
  return (
    (a = G(a, "xl/drawings/_rels/drawing{id}.xml.rels", o, n, {
      sheetIndex: r,
      sheetId: t,
    })),
    a
  );
}
function bn(e, r, t) {
  if (!wn(r)) return "";
  var n = r.showGridLines,
    o = r.rightToLeft,
    a = r.zoomScale,
    l = { tabSelected: t === 0 ? 1 : 0, workbookViewId: 0 };
  (n === !1 && (l.showGridLines = !1),
    o && (l.rightToLeft = 1),
    typeof a == "number" && (l.zoomScale = Math.round(a * 100)));
  var s = e("sheetView", l, null, 0);
  return e("sheetViews", null, s);
}
function wn(e) {
  var r = e.showGridLines,
    t = e.rightToLeft,
    n = e.zoomScale;
  return r === !1 || t || typeof n == "number";
}
function xn(e, r, t) {
  if (!r) return "";
  var n = r.width;
  if (!n) return "";
  var o = t + 1,
    a = { min: o, max: o, width: n, customWidth: 1 };
  return e("col", a, null, t);
}
function Sn(e, r) {
  if (r) {
    var t = r
      .map(function (n, o) {
        return xn(e, n, o);
      })
      .join("");
    if (t) return e("cols", null, t);
  }
  return "";
}
function we(e) {
  if (typeof e != "string") throw new TypeError("Argument must be a string");
  return ((e = lr(e)), ot(e, { isAttributeValue: !1 }));
}
function fe(e, r) {
  return "".concat(ft(r)).concat(e + 1);
}
var wr = 26;
function ft(e) {
  if (typeof e != "number") return "";
  var r = Math.floor(e / wr),
    t = String.fromCharCode(97 + (e % wr)).toUpperCase();
  return r === 0 ? t : ft(r - 1) + t;
}
var Cn = 70 * 365 + 19,
  In = 3600 * 1e3,
  Fn = 24 * In;
function An(e) {
  return e.getTime() / Fn + Cn;
}
function Tn(e, r) {
  return Bn(e) || Dn(e, r) || En(e, r) || On();
}
function On() {
  throw new TypeError(`Invalid attempt to destructure non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
}
function En(e, r) {
  if (e) {
    if (typeof e == "string") return xr(e, r);
    var t = {}.toString.call(e).slice(8, -1);
    return (
      t === "Object" && e.constructor && (t = e.constructor.name),
      t === "Map" || t === "Set"
        ? Array.from(e)
        : t === "Arguments" ||
            /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t)
          ? xr(e, r)
          : void 0
    );
  }
}
function xr(e, r) {
  (r == null || r > e.length) && (r = e.length);
  for (var t = 0, n = Array(r); t < r; t++) n[t] = e[t];
  return n;
}
function Dn(e, r) {
  var t =
    e == null
      ? null
      : (typeof Symbol < "u" && e[Symbol.iterator]) || e["@@iterator"];
  if (t != null) {
    var n,
      o,
      a,
      l,
      s = [],
      i = !0,
      f = !1;
    try {
      if (((a = (t = t.call(e)).next), r !== 0))
        for (
          ;
          !(i = (n = a.call(t)).done) && (s.push(n.value), s.length !== r);
          i = !0
        );
    } catch (u) {
      ((f = !0), (o = u));
    } finally {
      try {
        if (!i && t.return != null && ((l = t.return()), Object(l) !== l))
          return;
      } finally {
        if (f) throw o;
      }
    }
    return s;
  }
}
function Bn(e) {
  if (Array.isArray(e)) return e;
}
function kn(e, r, t, n) {
  var o = r.value,
    a = r.type,
    l = r.cellStyleId,
    s = r.findOrCreateSharedString;
  if (o === null && l === void 0) return "";
  var i = { r: fe(n, t) };
  if ((l !== void 0 && (i.s = String(l)), o === null))
    return e("c", i, null, t);
  if (a === Date && l === void 0)
    throw new Error(
      "No `format` was specified for a `Date` value in a cell in row "
        .concat(n + 1, " column ")
        .concat(
          t + 1,
          ". Either specify a `format` for this cell or specify a default global one by passing `dateFormat` option to `writeXlsxFile()` function",
        ),
    );
  var f = jn(a, o, s),
    u = Pn(a);
  u && (i.t = u);
  var d = Rn(a),
    c = Tn(d, 2),
    v = c[0],
    b = c[1],
    g = v + f + b;
  return e("c", i, g, t);
}
function Pn(e) {
  switch (e) {
    case String:
      return "s";
    case Number:
      return;
    case Date:
      return;
    case Boolean:
      return "b";
    case "Formula":
      return;
    default:
      throw new Error("Unknown type: ".concat((e && e.name) || e));
  }
}
function jn(e, r, t) {
  switch (e) {
    case String:
      if (typeof r != "string")
        throw new Error(
          "Invalid cell value: ".concat(r, ". Expected a string"),
        );
      return t(r);
    case Number:
      if (typeof r != "number")
        throw new Error(
          "Invalid cell value: ".concat(r, ". Expected a number"),
        );
      return String(r);
    case Date:
      if (!(r instanceof Date))
        throw new Error("Invalid cell value: ".concat(r, ". Expected a Date"));
      return String(An(r));
    case Boolean:
      if (typeof r != "boolean")
        throw new Error(
          "Invalid cell value: ".concat(r, ". Expected a boolean"),
        );
      return r ? "1" : "0";
    case "Formula":
      if (typeof r != "string")
        throw new Error(
          "Invalid cell value: ".concat(r, ". Expected a string"),
        );
      return we(r);
    default:
      throw new Error("Unknown type: ".concat((e && e.name) || e));
  }
}
var $n = /</g;
function Rn(e) {
  var r = Ln(e),
    t = r.replace($n, "</");
  return [r, t];
}
function Ln(e) {
  switch (e) {
    case "Formula":
      return "<f>";
    default:
      return "<v>";
  }
}
function Qe(e) {
  var r = e.align,
    t = e.alignVertical,
    n = e.textRotation,
    o = e.indent,
    a = e.wrap;
  return !!(r || t || typeof n == "number" || o || a);
}
function sr(e) {
  var r = e.borderColor,
    t = e.borderStyle,
    n = e.leftBorderColor,
    o = e.leftBorderStyle,
    a = e.rightBorderColor,
    l = e.rightBorderStyle,
    s = e.topBorderColor,
    i = e.topBorderStyle,
    f = e.bottomBorderColor,
    u = e.bottomBorderStyle;
  return !!(r || t || n || o || a || l || s || i || f || u);
}
function Xe(e) {
  var r = e.backgroundColor,
    t = e.fillPatternStyle,
    n = e.fillPatternColor;
  return !!(r || (t && n));
}
function fr(e) {
  var r = e.fontFamily,
    t = e.fontSize,
    n = e.fontWeight,
    o = e.fontStyle,
    a = e.textDecoration,
    l = e.textColor;
  return !!(
    r ||
    typeof t == "number" ||
    n ||
    o ||
    (a && Object.keys(a).length > 0) ||
    l
  );
}
function ut(e, r) {
  var t = e.align,
    n = e.alignVertical,
    o = e.textRotation,
    a = e.indent,
    l = e.wrap,
    s = e.fontFamily,
    i = e.fontSize,
    f = e.fontWeight,
    u = e.fontStyle,
    d = e.textDecoration,
    c = e.textColor,
    v = e.backgroundColor,
    b = e.fillPatternStyle,
    g = e.fillPatternColor,
    m = e.borderColor,
    C = e.borderStyle,
    F = e.leftBorderColor,
    S = e.leftBorderStyle,
    h = e.rightBorderColor,
    w = e.rightBorderStyle,
    I = e.topBorderColor,
    x = e.topBorderStyle,
    y = e.bottomBorderColor,
    p = e.bottomBorderStyle;
  if (
    Qe({ align: t, alignVertical: n, textRotation: o, indent: a, wrap: l }) ||
    fr({
      fontFamily: s,
      fontSize: i,
      fontWeight: f,
      fontStyle: u,
      textDecoration: d,
      textColor: c,
    }) ||
    Xe({ backgroundColor: v, fillPatternStyle: b, fillPatternColor: g }) ||
    sr({
      borderColor: m,
      borderStyle: C,
      leftBorderColor: F,
      leftBorderStyle: S,
      rightBorderColor: h,
      rightBorderStyle: w,
      topBorderColor: I,
      topBorderStyle: x,
      bottomBorderColor: y,
      bottomBorderStyle: p,
    })
  )
    return Mn({
      align: t,
      alignVertical: n,
      textRotation: o,
      indent: a,
      wrap: l,
      fontFamily: s,
      fontSize: i,
      fontWeight: f,
      fontStyle: u,
      textDecoration: d,
      textColor: c,
      backgroundColor: v,
      fillPatternStyle: b,
      fillPatternColor: g,
      borderColor: m,
      borderStyle: C,
      leftBorderColor: F,
      leftBorderStyle: S,
      rightBorderColor: h,
      rightBorderStyle: w,
      topBorderColor: I,
      topBorderStyle: x,
      bottomBorderColor: y,
      bottomBorderStyle: p,
    });
}
function Mn(e) {
  var r = {};
  for (var t in e) e[t] !== void 0 && (r[t] = e[t]);
  return r;
}
var Un = {}.constructor;
function Be(e) {
  return e != null && e.constructor === Un;
}
function ct(e) {
  return Be(e);
}
function ue(e) {
  "@babel/helpers - typeof";
  return (
    (ue =
      typeof Symbol == "function" && typeof Symbol.iterator == "symbol"
        ? function (r) {
            return typeof r;
          }
        : function (r) {
            return r &&
              typeof Symbol == "function" &&
              r.constructor === Symbol &&
              r !== Symbol.prototype
              ? "symbol"
              : typeof r;
          }),
    ue(e)
  );
}
function Sr(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    (r &&
      (n = n.filter(function (o) {
        return Object.getOwnPropertyDescriptor(e, o).enumerable;
      })),
      t.push.apply(t, n));
  }
  return t;
}
function Nn(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = arguments[r] != null ? arguments[r] : {};
    r % 2
      ? Sr(Object(t), !0).forEach(function (n) {
          zn(e, n, t[n]);
        })
      : Object.getOwnPropertyDescriptors
        ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t))
        : Sr(Object(t)).forEach(function (n) {
            Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(t, n));
          });
  }
  return e;
}
function zn(e, r, t) {
  return (
    (r = Vn(r)) in e
      ? Object.defineProperty(e, r, {
          value: t,
          enumerable: !0,
          configurable: !0,
          writable: !0,
        })
      : (e[r] = t),
    e
  );
}
function Vn(e) {
  var r = Xn(e, "string");
  return ue(r) == "symbol" ? r : r + "";
}
function Xn(e, r) {
  if (ue(e) != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var n = t.call(e, r);
    if (ue(n) != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
function _n(e, r) {
  var t = (typeof Symbol < "u" && e[Symbol.iterator]) || e["@@iterator"];
  if (t) return (t = t.call(e)).next.bind(t);
  if (Array.isArray(e) || (t = Hn(e)) || r) {
    t && (e = t);
    var n = 0;
    return function () {
      return n >= e.length ? { done: !0 } : { done: !1, value: e[n++] };
    };
  }
  throw new TypeError(`Invalid attempt to iterate non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
}
function Hn(e, r) {
  if (e) {
    if (typeof e == "string") return Cr(e, r);
    var t = {}.toString.call(e).slice(8, -1);
    return (
      t === "Object" && e.constructor && (t = e.constructor.name),
      t === "Map" || t === "Set"
        ? Array.from(e)
        : t === "Arguments" ||
            /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t)
          ? Cr(e, r)
          : void 0
    );
  }
}
function Cr(e, r) {
  (r == null || r > e.length) && (r = e.length);
  for (var t = 0, n = Array(r); t < r; t++) n[t] = e[t];
  return n;
}
function Wn(e, r, t, n) {
  for (var o, a = _n(r), l; !(l = a()).done;) {
    var s = l.value;
    ct(s) && s.height && (o === void 0 || o < s.height) && (o = s.height);
  }
  var i = t,
    f = r
      .map(function (d, c) {
        return Gn(e, d, c, i, n);
      })
      .join(""),
    u = { r: t + 1 };
  return (o && ((u.ht = o), (u.customHeight = 1)), e("row", u, f, t));
}
function Gn(e, r, t, n, o) {
  var a = o.findOrCreateCellStyle,
    l = o.findOrCreateSharedString,
    s = o.hasDefaultFont,
    i = o.dateFormat;
  if (r == null) return "";
  var f = ct(r) ? r : { value: r },
    u = ut(f),
    d = f.type,
    c = f.value,
    v = f.format;
  if (
    (Kn(c)
      ? (c = null)
      : d === void 0 &&
        ((d = qn(c)), d === void 0 && ((d = String), (c = String(c)))),
    v)
  ) {
    if (d !== Date && d !== Number && d !== String && d !== "Formula")
      throw new Error(
        '`format` "'
          .concat(v, '" was specified on a cell of type `')
          .concat(
            d,
            '`. `format` could only be specified on a cell of type `Date`, `Number`, `String` or `"Formula"`.',
          ),
      );
    if (d === String && v !== "@")
      throw new Error(
        '`format` "'.concat(
          v,
          '" was specified on a cell of type `String`. The only supported `format` for a cell of type `String` is "@".',
        ),
      );
  } else d === Date && (v = i);
  var b = !!v,
    g = !!u,
    m;
  return (
    (s || b || g) && (m = a(Nn({ format: v }, u))),
    kn(
      e,
      { value: c, type: d, cellStyleId: m, findOrCreateSharedString: l },
      t,
      n,
    )
  );
}
function Kn(e) {
  return e == null || e === "";
}
function qn(e) {
  switch (ue(e)) {
    case "string":
      return String;
    case "number":
      return Number;
    case "boolean":
      return Boolean;
    default:
      if (e instanceof Date) return Date;
  }
}
function Yn(e, r, t) {
  var n = r
    .map(function (o, a) {
      return Wn(e, o, a, t);
    })
    .join("");
  return e("sheetData", null, n);
}
function Jn(e, r) {
  for (
    var t = [],
      n = function () {
        e = e.slice();
        for (var c = 0; c < e.length;) ((e[c] = e[c].slice()), c++);
        return (
          (n = function () {
            return e;
          }),
          e
        );
      },
      o = 0;
    o < e.length;
  ) {
    for (var a = e[o], l = 0; l < a.length;) {
      var s = a[l];
      if (s) {
        var i = s.rowSpan,
          f = i === void 0 ? 1 : i,
          u = typeof s.span == "number" ? s.span : s.columnSpan;
        (typeof u != "number" && (u = 1),
          (u > 1 || f > 1) &&
            (Zn(e, o, l, u, f, n),
            t.push([
              [o, l],
              [o + (f ? f - 1 : 0), l + (u ? u - 1 : 0)],
            ])));
      }
      l++;
    }
    o++;
  }
  return { sheetData: e, mergedCells: t };
}
function Zn(e, r, t, n, o, a, l) {
  var s = ut(e[r][t]);
  s && (e = a());
  for (var i = r; i <= r + (o - 1);) {
    for (var f = t; f <= t + (n - 1);) {
      var u = e[i][f];
      if (i > r || f > t) {
        if (u != null)
          throw new Error(
            "[write-excel-file] When using `columnSpan` or `rowSpan` parameters, all hidden overlapped cells should be represented by `null`s or `undefined`s. Cell at row "
              .concat(r + 1, " and column ")
              .concat(t + 1, " is configured with `columnSpan` ")
              .concat(n, " and `rowSpan` ")
              .concat(o, ". Cell at row ")
              .concat(i + 1, " and column ")
              .concat(f + 1, " is neither `null` nor `undefined`: ")
              .concat(JSON.stringify(u)),
          );
        s && (e[i][f] = s);
      }
      f++;
    }
    i++;
  }
}
function Qn(e, r) {
  return no(e) || to(e, r) || ro(e, r) || eo();
}
function eo() {
  throw new TypeError(`Invalid attempt to destructure non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
}
function ro(e, r) {
  if (e) {
    if (typeof e == "string") return Ir(e, r);
    var t = {}.toString.call(e).slice(8, -1);
    return (
      t === "Object" && e.constructor && (t = e.constructor.name),
      t === "Map" || t === "Set"
        ? Array.from(e)
        : t === "Arguments" ||
            /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t)
          ? Ir(e, r)
          : void 0
    );
  }
}
function Ir(e, r) {
  (r == null || r > e.length) && (r = e.length);
  for (var t = 0, n = Array(r); t < r; t++) n[t] = e[t];
  return n;
}
function to(e, r) {
  var t =
    e == null
      ? null
      : (typeof Symbol < "u" && e[Symbol.iterator]) || e["@@iterator"];
  if (t != null) {
    var n,
      o,
      a,
      l,
      s = [],
      i = !0,
      f = !1;
    try {
      if (((a = (t = t.call(e)).next), r !== 0))
        for (
          ;
          !(i = (n = a.call(t)).done) && (s.push(n.value), s.length !== r);
          i = !0
        );
    } catch (u) {
      ((f = !0), (o = u));
    } finally {
      try {
        if (!i && t.return != null && ((l = t.return()), Object(l) !== l))
          return;
      } finally {
        if (f) throw o;
      }
    }
    return s;
  }
}
function no(e) {
  if (Array.isArray(e)) return e;
}
function oo(e, r) {
  if (r.length === 0) return "";
  var t = r
    .map(function (n, o) {
      var a = Qn(n, 2),
        l = a[0],
        s = a[1],
        i = fe(l[0], l[1]) + ":" + fe(s[0], s[1]);
      return e("mergeCell", { ref: i }, null, o);
    })
    .join("");
  return e("mergeCells", { count: r.length }, t);
}
function ao(e, r) {
  var t = r.orientation;
  if (t) {
    var n = 0.7,
      o = 0.7,
      a = 0.75,
      l = 0.75,
      s = 0.3,
      i = 0.3;
    return e("pageMargins", {
      left: n,
      right: o,
      top: a,
      bottom: l,
      header: s,
      footer: i,
    });
  }
  return "";
}
function io(e, r) {
  var t = r.orientation;
  if (t) {
    var n = 9;
    return e("pageSetup", { paperSize: n, orientation: N(t) });
  }
  return "";
}
function dt(e) {
  return e("drawing", { "r:id": "rId-drawing-1" });
}
function lo(e, r) {
  var t = e.sheetData,
    n = e.sheetOptions,
    o = e.sheetIndex,
    a = e.sheetId,
    l = e.hasDefaultFont,
    s = e.findOrCreateCellStyle,
    i = e.findOrCreateSharedString,
    f = n.columns,
    u = n.dateFormat,
    d = n.orientation,
    c = n.showGridLines,
    v = n.rightToLeft,
    b = n.zoomScale,
    g = Jn(t),
    m = g.sheetData,
    C = g.mergedCells,
    F = { sheetIndex: o, sheetId: a },
    S = function (I, x, y, p) {
      return at("xl/worksheets/sheet{id}.xml", I, x, y, p, F, n, r);
    },
    h =
      '<?xml version="1.0" ?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006" xmlns:mv="urn:schemas-microsoft-com:mac:vml" xmlns:mx="http://schemas.microsoft.com/office/mac/excel/2008/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:x14="http://schemas.microsoft.com/office/spreadsheetml/2009/9/main" xmlns:x14ac="http://schemas.microsoft.com/office/spreadsheetml/2009/9/ac" xmlns:xm="http://schemas.microsoft.com/office/excel/2006/main">' +
      bn(S, { showGridLines: c, rightToLeft: v, zoomScale: b }, o) +
      Sn(S, f) +
      Yn(S, m, {
        findOrCreateCellStyle: s,
        findOrCreateSharedString: i,
        hasDefaultFont: l,
        dateFormat: u,
      }) +
      oo(S, C) +
      ao(S, { orientation: d }) +
      io(S, { orientation: d }) +
      dt(S) +
      W("xl/worksheets/sheet{id}.xml", r, n, { sheetIndex: o, sheetId: a }) +
      "</worksheet>";
  return (
    (h = G(h, "xl/worksheets/sheet{id}.xml", r, n, {
      sheetIndex: o,
      sheetId: a,
    })),
    h
  );
}
function so(e) {
  var r = e.sheetIndex,
    t = e.sheetId,
    n = e.sheetOptions,
    o = e.features,
    a =
      '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' +
      mt(t) +
      W("xl/worksheets/_rels/sheet{id}.xml.rels", o, n, {
        sheetIndex: r,
        sheetId: t,
      }) +
      "</Relationships>";
  return (
    (a = G(a, "xl/worksheets/_rels/sheet{id}.xml.rels", o, n, {
      sheetIndex: r,
      sheetId: t,
    })),
    a
  );
}
function mt(e) {
  return '<Relationship Id="rId-drawing-1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/drawing" Target="../drawings/drawing'.concat(
    e,
    '.xml"/>',
  );
}
function fo(e, r) {
  var t = (typeof Symbol < "u" && e[Symbol.iterator]) || e["@@iterator"];
  if (t) return (t = t.call(e)).next.bind(t);
  if (Array.isArray(e) || (t = uo(e)) || r) {
    t && (e = t);
    var n = 0;
    return function () {
      return n >= e.length ? { done: !0 } : { done: !1, value: e[n++] };
    };
  }
  throw new TypeError(`Invalid attempt to iterate non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
}
function uo(e, r) {
  if (e) {
    if (typeof e == "string") return Fr(e, r);
    var t = {}.toString.call(e).slice(8, -1);
    return (
      t === "Object" && e.constructor && (t = e.constructor.name),
      t === "Map" || t === "Set"
        ? Array.from(e)
        : t === "Arguments" ||
            /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t)
          ? Fr(e, r)
          : void 0
    );
  }
}
function Fr(e, r) {
  (r == null || r > e.length) && (r = e.length);
  for (var t = 0, n = Array(r); t < r; t++) n[t] = e[t];
  return n;
}
function co(e) {
  var r = '<?xml version="1.0"?>';
  r +=
    '<sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">';
  for (var t = fo(e), n; !(n = t()).done;) {
    var o = n.value,
      a = o.trim().length === o.length ? "" : ' xml:space="preserve"';
    ((r += "<si><t".concat(a, ">")), (r += we(o)), (r += "</t></si>"));
  }
  return ((r += "</sst>"), r);
}
function Ue(e) {
  if (e[0] !== "#")
    throw new Error('Color "'.concat(e, '" must start with a "#"'));
  return "FF".concat(e.slice(1).toUpperCase());
}
function vt(e) {
  var r = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {},
    t = r.conditionalFormatting,
    n = e.backgroundColor,
    o = e.fillPatternStyle,
    a = e.fillPatternColor,
    l = !o || o === "solid";
  if (!Xe(e)) return '<fill><patternFill patternType="none"/></fill>';
  var s = "<fill>";
  return (
    (s += '<patternFill patternType="'.concat(l ? "solid" : o, '">')),
    (s += '<fgColor rgb="'.concat(N(Ue(l ? n : a)), '"/>')),
    (s += "<bgColor ".concat(
      l && !t ? 'indexed="64"' : 'rgb="' + N(Ue(n)) + '"',
      "/>",
    )),
    (s += "</patternFill>"),
    (s += "</fill>"),
    s
  );
}
function gt(e) {
  var r = e.borderColor,
    t = e.borderStyle,
    n = e.leftBorderColor,
    o = e.leftBorderStyle,
    a = e.rightBorderColor,
    l = e.rightBorderStyle,
    s = e.topBorderColor,
    i = e.topBorderStyle,
    f = e.bottomBorderColor,
    u = e.bottomBorderStyle,
    d = { style: o || t, color: n || r },
    c = { style: l || t, color: a || r },
    v = { style: i || t, color: s || r },
    b = { style: u || t, color: f || r },
    g = "<border>";
  return (
    (g += Te("left", d)),
    (g += Te("right", c)),
    (g += Te("top", v)),
    (g += Te("bottom", b)),
    (g += "<diagonal/>"),
    (g += "</border>"),
    g
  );
}
function Te(e, r) {
  var t = r.style,
    n = r.color;
  n && !t && (t = "thin");
  var o = !!n;
  return (
    "<".concat(e) +
    (t ? ' style="'.concat(N(t), '"') : "") +
    (o ? ">" : "/>") +
    (n ? '<color rgb="'.concat(N(Ue(n)), '"/>') : "") +
    (o ? "</".concat(e, ">") : "")
  );
}
function ht(e) {
  var r = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
  r.isDefaultGenericFont;
  var t = e.fontFamily,
    n = e.fontSize,
    o = e.fontWeight,
    a = e.fontStyle,
    l = e.textDecoration,
    s = e.textColor,
    i = "<font>";
  return (
    t && (i += '<name val="'.concat(N(t), '"/>')),
    typeof n == "number" && (i += '<sz val="'.concat(n, '"/>')),
    (i += '<family val="2"/>'),
    t || typeof n == "number" || (i += '<scheme val="minor"/>'),
    o === "bold" && (i += "<b/>"),
    a === "italic" && (i += "<i/>"),
    l &&
      (l.strikethrough && (i += "<strike/>"),
      l.underline
        ? (i += "<u/>")
        : l.doubleUnderline && (i += '<u val="double"/>')),
    s
      ? (i += '<color rgb="'.concat(N(Ue(s)), '"/>'))
      : (i += '<color theme="1"/>'),
    (i += "</font>"),
    i
  );
}
function mo(e) {
  var r = e.align,
    t = e.alignVertical,
    n = e.textRotation,
    o = e.indent,
    a = e.wrap;
  return (
    "<alignment" +
    (r ? ' horizontal="'.concat(N(r), '"') : "") +
    (t ? ' vertical="'.concat(N(t), '"') : "") +
    (n ? ' textRotation="'.concat(go(vo(n)), '"') : "") +
    (o ? ' indent="'.concat(N(String(o)), '"') : "") +
    (a ? ' wrapText="1"' : "") +
    "/>"
  );
}
function vo(e) {
  if (!(e >= -90 && e <= 90))
    throw new Error(
      "Unsupported text rotation angle: ".concat(
        e,
        ". Values from -90 to 90 are supported.",
      ),
    );
  return e;
}
function go(e) {
  return e < 0 ? 90 - e : e;
}
function Se(e) {
  "@babel/helpers - typeof";
  return (
    (Se =
      typeof Symbol == "function" && typeof Symbol.iterator == "symbol"
        ? function (r) {
            return typeof r;
          }
        : function (r) {
            return r &&
              typeof Symbol == "function" &&
              r.constructor === Symbol &&
              r !== Symbol.prototype
              ? "symbol"
              : typeof r;
          }),
    Se(e)
  );
}
function Ar(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    (r &&
      (n = n.filter(function (o) {
        return Object.getOwnPropertyDescriptor(e, o).enumerable;
      })),
      t.push.apply(t, n));
  }
  return t;
}
function Tr(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = arguments[r] != null ? arguments[r] : {};
    r % 2
      ? Ar(Object(t), !0).forEach(function (n) {
          ho(e, n, t[n]);
        })
      : Object.getOwnPropertyDescriptors
        ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t))
        : Ar(Object(t)).forEach(function (n) {
            Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(t, n));
          });
  }
  return e;
}
function ho(e, r, t) {
  return (
    (r = po(r)) in e
      ? Object.defineProperty(e, r, {
          value: t,
          enumerable: !0,
          configurable: !0,
          writable: !0,
        })
      : (e[r] = t),
    e
  );
}
function po(e) {
  var r = yo(e, "string");
  return Se(r) == "symbol" ? r : r + "";
}
function yo(e, r) {
  if (Se(e) != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var n = t.call(e, r);
    if (Se(n) != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
var pt = 100;
function bo(e) {
  var r = [],
    t = {},
    n = [],
    o = {},
    a = [],
    l = {},
    s = [],
    i = {},
    f = [],
    u = {},
    d = a.length;
  ((l[Y(e)] = d), a.push(e || {}));
  var c = {};
  ((i[Y(c)] = s.length), s.push(c));
  var v = {};
  ((u[Y(v)] = f.length), f.push(v));
  var b = { gray125: !0 };
  s.push(b);
  function g(m) {
    var C = m.format,
      F = m.align,
      S = m.alignVertical,
      h = m.textRotation,
      w = m.indent,
      I = m.wrap,
      x = m.fontFamily,
      y = m.fontSize,
      p = m.fontWeight,
      A = m.fontStyle,
      D = m.textDecoration,
      k = m.textColor,
      M = m.backgroundColor,
      E = m.fillPatternStyle,
      B = m.fillPatternColor,
      P = m.borderColor,
      T = m.borderStyle,
      L = m.leftBorderColor,
      _ = m.leftBorderStyle,
      ce = m.rightBorderColor,
      z = m.rightBorderStyle,
      Z = m.topBorderColor,
      K = m.topBorderStyle,
      V = m.bottomBorderColor,
      j = m.bottomBorderStyle,
      X = {
        fontFamily: x,
        fontSize: y,
        fontWeight: p,
        fontStyle: A,
        textDecoration: D,
        textColor: k,
      },
      de = { backgroundColor: M, fillPatternStyle: E, fillPatternColor: B },
      Q = {
        borderColor: P,
        borderStyle: T,
        leftBorderColor: L,
        leftBorderStyle: _,
        rightBorderColor: ce,
        rightBorderStyle: z,
        topBorderColor: Z,
        topBorderStyle: K,
        bottomBorderColor: V,
        bottomBorderStyle: j,
      },
      _e = { align: F, alignVertical: S, textRotation: h, indent: w, wrap: I },
      me = Y(C),
      ve = Y(X),
      ge = Y(de),
      te = Y(Q),
      ee = Y(m),
      kt = function () {
        var he;
        C &&
          ((he = t[me]),
          he === void 0 && ((he = pt + r.length), (t[me] = he), r.push(C)));
        var ne;
        fr(X)
          ? ((ne = l[ve]),
            ne === void 0 &&
              ((ne = a.length),
              (l[ve] = ne),
              a.push(
                Tr(
                  Tr({}, X),
                  {},
                  {
                    fontSize: X.fontSize || (e && e.fontSize),
                    fontFamily: X.fontFamily || (e && e.fontFamily),
                  },
                ),
              )))
          : e && (ne = d);
        var pe;
        Xe(de) &&
          ((pe = i[ge]),
          pe === void 0 &&
            ((pe = s.length),
            (i[ge] = pe),
            s.push({
              backgroundColor: M,
              fillPatternStyle: E,
              fillPatternColor: B,
            })));
        var ye;
        sr(Q) &&
          ((ye = u[te]),
          ye === void 0 && ((ye = f.length), (u[te] = ye), f.push(Q)));
        var cr = n.length;
        return (
          (o[ee] = cr),
          n.push({
            formatId: he,
            fontId: ne,
            fillId: pe,
            borderId: ye,
            alignment: _e,
          }),
          cr
        );
      };
    return o[ee] !== void 0 ? o[ee] : kt();
  }
  return (
    g({}),
    {
      getCellStyles: function () {
        return { formats: r, styles: n, fonts: a, fills: s, borders: f };
      },
      findOrCreateCellStyle: g,
    }
  );
}
function Y(e) {
  return JSON.stringify(e);
}
function Oe(e, r) {
  var t = (typeof Symbol < "u" && e[Symbol.iterator]) || e["@@iterator"];
  if (t) return (t = t.call(e)).next.bind(t);
  if (Array.isArray(e) || (t = wo(e)) || r) {
    t && (e = t);
    var n = 0;
    return function () {
      return n >= e.length ? { done: !0 } : { done: !1, value: e[n++] };
    };
  }
  throw new TypeError(`Invalid attempt to iterate non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
}
function wo(e, r) {
  if (e) {
    if (typeof e == "string") return Or(e, r);
    var t = {}.toString.call(e).slice(8, -1);
    return (
      t === "Object" && e.constructor && (t = e.constructor.name),
      t === "Map" || t === "Set"
        ? Array.from(e)
        : t === "Arguments" ||
            /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t)
          ? Or(e, r)
          : void 0
    );
  }
}
function Or(e, r) {
  (r == null || r > e.length) && (r = e.length);
  for (var t = 0, n = Array(r); t < r; t++) n[t] = e[t];
  return n;
}
function xo(e, r, t) {
  var n = e.formats,
    o = e.styles,
    a = e.fonts,
    l = e.fills,
    s = e.borders,
    i = '<?xml version="1.0" ?>';
  if (
    ((i +=
      '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'),
    n.length > 0)
  ) {
    i += '<numFmts count="'.concat(n.length, '">');
    for (var f = 0; f < n.length; f++)
      i += '<numFmt numFmtId="'
        .concat(pt + f, '" formatCode="')
        .concat(N(n[f]), '"/>');
    i += "</numFmts>";
  }
  i += '<fonts count="'.concat(a.length, '">');
  for (var u = Oe(a), d; !(d = u()).done;) {
    var c = d.value;
    i += ht(c);
  }
  ((i += "</fonts>"), (i += '<fills count="'.concat(l.length, '">')));
  for (var v = Oe(l), b; !(b = v()).done;) {
    var g = b.value;
    g.gray125
      ? ((i += "<fill>"),
        (i += '<patternFill patternType="gray125"/>'),
        (i += "</fill>"))
      : (i += vt(g));
  }
  ((i += "</fills>"), (i += '<borders count="'.concat(s.length, '">')));
  for (var m = Oe(s), C; !(C = m()).done;) {
    var F = C.value;
    i += gt(F);
  }
  ((i += "</borders>"), (i += '<cellXfs count="'.concat(o.length, '">')));
  for (var S = Oe(o), h; !(h = S()).done;) {
    var w = h.value,
      I = w.fontId,
      x = w.fillId,
      y = w.borderId,
      p = w.alignment,
      A = w.formatId;
    i +=
      "<xf " +
      [
        A === void 0
          ? void 0
          : 'numFmtId="'.concat(A, '" applyNumberFormat="1"'),
        I === void 0 ? void 0 : 'fontId="'.concat(I, '" applyFont="1"'),
        x === void 0 ? void 0 : 'fillId="'.concat(x, '" applyFill="1"'),
        y === void 0 ? void 0 : 'borderId="'.concat(y, '" applyBorder="1"'),
        Qe(p) ? 'applyAlignment="1"' : void 0,
      ]
        .filter(function (D) {
          return D;
        })
        .join(" ") +
      ">" +
      (Qe(p) ? mo(p) : "") +
      "</xf>";
  }
  return (
    (i += "</cellXfs>"),
    (i += W("xl/styles.xml", t, r)),
    (i += "</styleSheet>"),
    (i = G(i, "xl/styles.xml", t, r)),
    i
  );
}
function yt(e) {
  for (
    var r = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {},
      t = r.tagName,
      n = r.stopAfterFirstMatch,
      o = new RegExp(bt(t), n ? void 0 : "g"),
      a = [],
      l;
    (l = o.exec(e)) !== null;
  ) {
    for (
      var s = l[0],
        i = t || l[1],
        f = {},
        u = new RegExp('\\s+([^\\s=>]+)(?:="([^\\s=>]+)")', "g"),
        d = void 0;
      (d = u.exec(s)) !== null;
    )
      f[d[1]] = d[2];
    var c = {
      tagName: i,
      openingTagStartIndex: l.index,
      openingTagEndIndex: l.index + s.length - 1,
      openingTagAttributes: f,
      selfClosingTag: !1,
      closingTagStartIndex: void 0,
      closingTagEndIndex: void 0,
    };
    if (s[s.length - 2] === "/") c.selfClosingTag = !0;
    else {
      var v = So(e, c.openingTagEndIndex + 1, i);
      if (!v)
        throw new Error(
          "Invalid XML: opening tag was found but closing tag was not: </".concat(
            i,
            ">",
          ),
        );
      ((c.closingTagStartIndex = v[0]), (c.closingTagEndIndex = v[1]));
    }
    if ((a.push(c), n)) break;
    c.selfClosingTag
      ? (o.lastIndex = c.openingTagEndIndex + 1)
      : (o.lastIndex = c.closingTagEndIndex + 1);
  }
  return a;
}
function So(e, r, t) {
  var n = new RegExp("<(/)?" + t + "(?:\\s+[^>]+|/)?>", "g");
  n.lastIndex = r;
  for (var o = 0, a; (a = n.exec(e)) !== null;) {
    var l = a[0],
      s = a[1];
    if (s)
      if (o > 0) o--;
      else return [a.index, a.index + l.length - 1];
    else o++;
  }
}
function bt(e) {
  return "<" + (e || "([^\\s/>]+)") + "(?:\\s+[^>]+|/)?>";
}
function re(e, r) {
  var t = yt(e, { tagName: r, stopAfterFirstMatch: !0 });
  return t[0];
}
function wt(e, r, t) {
  return t
    ? r.selfClosingTag
      ? e.slice(0, r.openingTagEndIndex - 1) +
        ">" +
        t +
        "</" +
        r.tagName +
        ">" +
        e.slice(r.openingTagEndIndex + 1)
      : e.slice(0, r.openingTagEndIndex + 1) +
        t +
        e.slice(r.closingTagStartIndex)
    : r.selfClosingTag
      ? e
      : e.slice(0, r.openingTagEndIndex) +
        "/>" +
        e.slice(r.closingTagEndIndex + 1);
}
function ke(e, r, t) {
  return r.selfClosingTag
    ? wt(e, r, t)
    : e.slice(0, r.closingTagStartIndex) + t + e.slice(r.closingTagStartIndex);
}
function xt(e, r) {
  return r.selfClosingTag
    ? ""
    : e.substring(r.openingTagEndIndex + 1, r.closingTagStartIndex);
}
function St(e, r) {
  var t = r.openingTagEndIndex + 1;
  ((e.openingTagStartIndex += t),
    (e.openingTagEndIndex += t),
    e.selfClosingTag ||
      ((e.closingTagStartIndex += t), (e.closingTagEndIndex += t)));
}
function Co(e, r) {
  var t = (typeof Symbol < "u" && e[Symbol.iterator]) || e["@@iterator"];
  if (t) return (t = t.call(e)).next.bind(t);
  if (Array.isArray(e) || (t = Io(e)) || r) {
    t && (e = t);
    var n = 0;
    return function () {
      return n >= e.length ? { done: !0 } : { done: !1, value: e[n++] };
    };
  }
  throw new TypeError(`Invalid attempt to iterate non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
}
function Io(e, r) {
  if (e) {
    if (typeof e == "string") return Er(e, r);
    var t = {}.toString.call(e).slice(8, -1);
    return (
      t === "Object" && e.constructor && (t = e.constructor.name),
      t === "Map" || t === "Set"
        ? Array.from(e)
        : t === "Arguments" ||
            /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t)
          ? Er(e, r)
          : void 0
    );
  }
}
function Er(e, r) {
  (r == null || r > e.length) && (r = e.length);
  for (var t = 0, n = Array(r); t < r; t++) n[t] = e[t];
  return n;
}
function Dr(e, r) {
  for (var t = yt(xt(e, r)), n = Co(t), o; !(o = n()).done;) {
    var a = o.value;
    St(a, r);
  }
  return t;
}
function Ct(e, r, t) {
  return r.selfClosingTag
    ? wt(e, r, t)
    : e.slice(0, r.openingTagEndIndex + 1) +
        t +
        e.slice(r.openingTagEndIndex + 1);
}
function Br(e, r) {
  var t = (typeof Symbol < "u" && e[Symbol.iterator]) || e["@@iterator"];
  if (t) return (t = t.call(e)).next.bind(t);
  if (Array.isArray(e) || (t = Fo(e)) || r) {
    t && (e = t);
    var n = 0;
    return function () {
      return n >= e.length ? { done: !0 } : { done: !1, value: e[n++] };
    };
  }
  throw new TypeError(`Invalid attempt to iterate non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
}
function Fo(e, r) {
  if (e) {
    if (typeof e == "string") return kr(e, r);
    var t = {}.toString.call(e).slice(8, -1);
    return (
      t === "Object" && e.constructor && (t = e.constructor.name),
      t === "Map" || t === "Set"
        ? Array.from(e)
        : t === "Arguments" ||
            /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t)
          ? kr(e, r)
          : void 0
    );
  }
}
function kr(e, r) {
  (r == null || r > e.length) && (r = e.length);
  for (var t = 0, n = Array(r); t < r; t++) n[t] = e[t];
  return n;
}
function It(e, r, t) {
  for (
    var n = arguments.length, o = new Array(n > 3 ? n - 3 : 0), a = 3;
    a < n;
    a++
  )
    o[a - 3] = arguments[a];
  if (o.length === 0)
    throw new Error("At least one parent element tag name is required");
  o = o.slice().reverse();
  for (
    var l,
      s = function () {
        var h = f.value;
        if (
          (l
            ? (l = Dr(e, l).find(function (w) {
                return w.tagName === h;
              }))
            : (l = re(e, h)),
          !l)
        )
          throw new Error("Element not found: <".concat(h, ">"));
      },
      i = Br(o),
      f;
    !(f = i()).done;
  )
    s();
  var u = r.match(Ao);
  if (!u) throw new Error("Couldn't extract tag name from markup: ".concat(r));
  var d = u[1];
  if (!t || t.length < 2) return ke(e, l, r);
  var c = Dr(e, l);
  if (c.length === 0) return ke(e, l, r);
  var v = t.indexOf(d);
  if (v < 0) return ke(e, l, r);
  for (
    var b = t.slice(0, v).reverse(),
      g = function () {
        var h = F.value,
          w = c.find(function (I) {
            return I.tagName === h;
          });
        if (w)
          return {
            v:
              e.slice(
                0,
                w.selfClosingTag
                  ? w.openingTagEndIndex + 1
                  : w.closingTagEndIndex + 1,
              ) +
              r +
              e.slice(
                w.selfClosingTag
                  ? w.openingTagEndIndex + 1
                  : w.closingTagEndIndex + 1,
              ),
          };
      },
      m,
      C = Br(b),
      F;
    !(F = C()).done;
  )
    if (((m = g()), m)) return m.v;
  return Ct(e, l, r);
}
var Ao = new RegExp(bt());
const To = {
  "xl/workbook.xml": [
    [
      "workbook",
      [
        "workbookPr",
        "bookViews",
        "sheets",
        "pivotCaches",
        "definedNames",
        "calcPr",
      ],
    ],
  ],
  "xl/styles.xml": [
    [
      "styleSheet",
      [
        "numFmts",
        "fonts",
        "fills",
        "borders",
        "cellStyleXfs",
        "cellXfs",
        "cellStyles",
        "dxfs",
        "tableStyles",
      ],
    ],
  ],
  "xl/worksheets/sheet{id}.xml": [
    [
      "worksheet",
      [
        "sheetPr",
        "dimension",
        "sheetViews",
        "sheetFormatPr",
        "cols",
        "sheetData",
        "sheetCalcPr",
        "sheetProtection",
        "protectedRanges",
        "scenarios",
        "autoFilter",
        "sortState",
        "dataConsolidate",
        "customSheetViews",
        "mergeCells",
        "phoneticPr",
        "conditionalFormatting",
        "dataValidations",
        "hyperlinks",
        "printOptions",
        "pageMargins",
        "pageSetup",
        "headerFooter",
        "rowBreaks",
        "colBreaks",
        "drawing",
        "legacyDrawing",
        "picture",
        "oleObjects",
        "controls",
        "tableParts",
        "extLst",
      ],
    ],
  ],
};
function Ft(e) {
  var r = To[e];
  if (r) {
    for (
      var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), o = 1;
      o < t;
      o++
    )
      n[o - 1] = arguments[o];
    if (n.length === 0)
      throw new Error("At least one parent element tag name is required");
    for (
      var a = function () {
          var u = i[s],
            d = r.find(function (c) {
              return Array.isArray(c) ? c[0] === u : c === u;
            });
          if (!d) return { v: void 0 };
          if (Array.isArray(d)) r = d[1];
          else return { v: void 0 };
        },
        l,
        s = 0,
        i = n;
      s < i.length;
      s++
    )
      if (((l = a()), l)) return l.v;
    if (r)
      return r.map(function (f) {
        return Array.isArray(f) ? f[0] : f;
      });
  }
}
function Pe(e, r) {
  var t = (typeof Symbol < "u" && e[Symbol.iterator]) || e["@@iterator"];
  if (t) return (t = t.call(e)).next.bind(t);
  if (Array.isArray(e) || (t = Oo(e)) || r) {
    t && (e = t);
    var n = 0;
    return function () {
      return n >= e.length ? { done: !0 } : { done: !1, value: e[n++] };
    };
  }
  throw new TypeError(`Invalid attempt to iterate non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
}
function Oo(e, r) {
  if (e) {
    if (typeof e == "string") return Pr(e, r);
    var t = {}.toString.call(e).slice(8, -1);
    return (
      t === "Object" && e.constructor && (t = e.constructor.name),
      t === "Map" || t === "Set"
        ? Array.from(e)
        : t === "Arguments" ||
            /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t)
          ? Pr(e, r)
          : void 0
    );
  }
}
function Pr(e, r) {
  (r == null || r > e.length) && (r = e.length);
  for (var t = 0, n = Array(r); t < r; t++) n[t] = e[t];
  return n;
}
const Eo = {
  files: {
    transform: {
      "xl/worksheets/sheet{id}.xml": {
        transform: function (r, t, n) {
          (n.sheetIndex, n.sheetId);
          var o = t.conditionalFormatting;
          if (o) {
            var a = Do(o);
            return It(
              r,
              a,
              Ft("xl/worksheets/sheet{id}.xml", "worksheet"),
              "worksheet",
            );
          }
          return r;
        },
      },
      "xl/styles.xml": {
        insert: function (r) {
          var t = r.map(function (n) {
            return n.conditionalFormatting;
          });
          if (t.some(Boolean)) return Bo(t);
        },
      },
    },
  },
};
function Do(e) {
  for (var r = "", t = 0, n = Pe(e), o; !(o = n()).done;) {
    var a = o.value,
      l = a.cellRange,
      s = l.from,
      i = l.to,
      f = a.condition,
      u = f.formula,
      d = f.operator,
      c = f.value,
      v = f.value2,
      b = fe(s.row - 1, s.column - 1) + ":" + fe(i.row - 1, i.column - 1);
    r += '<conditionalFormatting sqref="'.concat(b, '">');
    var g = t + 1,
      m = a._globalIndex;
    if (u)
      ((r += '<cfRule type="expression" dxfId="'
        .concat(m, '" priority="')
        .concat(g, '">')),
        (r += "<formula>".concat(we(u), "</formula>")),
        (r += "</cfRule>"));
    else if (d)
      ((r += '<cfRule type="cellIs" operator="'
        .concat($r(d), '" dxfId="')
        .concat(m, '" priority="')
        .concat(g, '">')),
        (r += "<formula>".concat(we(jr(c)), "</formula>")),
        $r(d) === "between" &&
          (r += "<formula>".concat(we(jr(v)), "</formula>")),
        (r += "</cfRule>"));
    else
      throw new Error(
        `Invalid conditional formatting rule:
`.concat(JSON.stringify(a, null, 2)),
      );
    ((r += "</conditionalFormatting>"), t++);
  }
  return r;
}
function jr(e) {
  return typeof e == "string" ? '"' + e + '"' : String(e);
}
function $r(e) {
  switch (e) {
    case "<":
      return "lessThan";
    case ">":
      return "greaterThan";
    case "<=":
      return "lessThanOrEqual";
    case ">=":
      return "greaterThanOrEqual";
    case "=":
      return "equal";
    case "!=":
      return "notEqual";
    case "...":
      return "between";
    default:
      throw new Error("Unknown conditional formatting operator: ".concat(e));
  }
}
function Bo(e) {
  for (var r = 0, t = Pe(e), n; !(n = t()).done;) {
    var o = n.value;
    o && (r += o.length);
  }
  var a = "";
  a += '<dxfs count="'.concat(r, '">');
  for (var l = Pe(e), s; !(s = l()).done;) {
    var i = s.value;
    if (i)
      for (var f = Pe(i), u; !(u = f()).done;) {
        var d = u.value,
          c = d.style,
          v = c.fontFamily,
          b = c.fontSize,
          g = c.fontWeight,
          m = c.fontStyle,
          C = c.textDecoration,
          F = c.textColor,
          S = c.backgroundColor,
          h = c.fillPatternStyle,
          w = c.fillPatternColor,
          I = c.borderColor,
          x = c.borderStyle,
          y = c.leftBorderColor,
          p = c.leftBorderStyle,
          A = c.rightBorderColor,
          D = c.rightBorderStyle,
          k = c.topBorderColor,
          M = c.topBorderStyle,
          E = c.bottomBorderColor,
          B = c.bottomBorderStyle;
        a += "<dxf>";
        var P = {
          fontFamily: v,
          fontSize: b,
          fontWeight: g,
          fontStyle: m,
          textDecoration: C,
          textColor: F,
        };
        if (fr(P)) {
          if (v)
            throw new Error(
              "Conditional formatting can't be used to override font family",
            );
          if (typeof b == "number")
            throw new Error(
              "Conditional formatting can't be used to override font size",
            );
          a += ht(P);
        }
        var T = {
          backgroundColor: S,
          fillPatternStyle: h,
          fillPatternColor: w,
        };
        Xe(T) && (a += vt(T, { conditionalFormatting: !0 }));
        var L = {
          borderColor: I,
          borderStyle: x,
          leftBorderColor: y,
          leftBorderStyle: p,
          rightBorderColor: A,
          rightBorderStyle: D,
          topBorderColor: k,
          topBorderStyle: M,
          bottomBorderColor: E,
          bottomBorderStyle: B,
        };
        (sr(L) && (a += gt(L)), (a += "</dxf>"));
      }
  }
  return ((a += "</dxfs>"), a);
}
function At(e) {
  if (!e) throw new Error("`contentType` is required");
  var r = e.toLowerCase().replace(/.*\//, "");
  if (!r) throw new Error("Unsupported `contentType`: " + e);
  return r;
}
function Ce(e) {
  "@babel/helpers - typeof";
  return (
    (Ce =
      typeof Symbol == "function" && typeof Symbol.iterator == "symbol"
        ? function (r) {
            return typeof r;
          }
        : function (r) {
            return r &&
              typeof Symbol == "function" &&
              r.constructor === Symbol &&
              r !== Symbol.prototype
              ? "symbol"
              : typeof r;
          }),
    Ce(e)
  );
}
function ur(e, r) {
  var t = (typeof Symbol < "u" && e[Symbol.iterator]) || e["@@iterator"];
  if (t) return (t = t.call(e)).next.bind(t);
  if (Array.isArray(e) || (t = Tt(e)) || r) {
    t && (e = t);
    var n = 0;
    return function () {
      return n >= e.length ? { done: !0 } : { done: !1, value: e[n++] };
    };
  }
  throw new TypeError(`Invalid attempt to iterate non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
}
function Rr(e) {
  return jo(e) || Po(e) || Tt(e) || ko();
}
function ko() {
  throw new TypeError(`Invalid attempt to spread non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
}
function Tt(e, r) {
  if (e) {
    if (typeof e == "string") return er(e, r);
    var t = {}.toString.call(e).slice(8, -1);
    return (
      t === "Object" && e.constructor && (t = e.constructor.name),
      t === "Map" || t === "Set"
        ? Array.from(e)
        : t === "Arguments" ||
            /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t)
          ? er(e, r)
          : void 0
    );
  }
}
function Po(e) {
  if (
    (typeof Symbol < "u" && e[Symbol.iterator] != null) ||
    e["@@iterator"] != null
  )
    return Array.from(e);
}
function jo(e) {
  if (Array.isArray(e)) return er(e);
}
function er(e, r) {
  (r == null || r > e.length) && (r = e.length);
  for (var t = 0, n = Array(r); t < r; t++) n[t] = e[t];
  return n;
}
function Lr(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    (r &&
      (n = n.filter(function (o) {
        return Object.getOwnPropertyDescriptor(e, o).enumerable;
      })),
      t.push.apply(t, n));
  }
  return t;
}
function Ee(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = arguments[r] != null ? arguments[r] : {};
    r % 2
      ? Lr(Object(t), !0).forEach(function (n) {
          Ot(e, n, t[n]);
        })
      : Object.getOwnPropertyDescriptors
        ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t))
        : Lr(Object(t)).forEach(function (n) {
            Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(t, n));
          });
  }
  return e;
}
function Ot(e, r, t) {
  return (
    (r = $o(r)) in e
      ? Object.defineProperty(e, r, {
          value: t,
          enumerable: !0,
          configurable: !0,
          writable: !0,
        })
      : (e[r] = t),
    e
  );
}
function $o(e) {
  var r = Ro(e, "string");
  return Ce(r) == "symbol" ? r : r + "";
}
function Ro(e, r) {
  if (Ce(e) != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var n = t.call(e, r);
    if (Ce(n) != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
const Lo = {
  files: {
    transform: {
      "[Content_Types].xml": {
        insert: function (r) {
          var t = r.map(function (n) {
            return n.images;
          });
          if (t.some(Boolean)) return Mo(t);
        },
      },
      "xl/drawings/drawing{id}.xml": {
        insert: function (r, t) {
          (t.sheetIndex, t.sheetId);
          var n = r.images;
          if (n) return No({ images: n });
        },
      },
      "xl/drawings/_rels/drawing{id}.xml.rels": {
        insert: function (r, t) {
          var n = t.sheetIndex;
          t.sheetId;
          var o = r.images;
          if (o) return zo({ images: o, sheetIndex: n });
        },
      },
    },
    write: {
      files: function (r, t) {
        t.read;
        var n = r.map(function (o) {
          return o.images;
        });
        if (n.some(Boolean))
          return n
            .map(function (o, a) {
              return o
                ? o.reduce(function (l, s, i) {
                    return Ee(
                      Ee({}, l),
                      {},
                      Ot(
                        {},
                        "xl/media/".concat(
                          Et(s, { sheetIndex: a, imageIndex: i }),
                        ),
                        s.content,
                      ),
                    );
                  }, {})
                : {};
            })
            .reduce(function (o, a) {
              return Ee(Ee({}, o), a);
            }, {});
      },
    },
  },
};
function Mo(e) {
  for (
    var r = e.reduce(function (i, f) {
        return [].concat(Rr(i), Rr(f || []));
      }, []),
      t = "",
      n = ur(Uo(r)),
      o;
    !(o = n()).done;
  ) {
    var a = o.value,
      l = a.fileExtension,
      s = a.contentType;
    t += '<Default Extension="'.concat(l, '" ContentType="').concat(s, '"/>');
  }
  return t;
}
function Uo(e) {
  for (
    var r = [],
      t = function (s) {
        var i = At(s.contentType),
          f = r.find(function (u) {
            return u.fileExtension === i;
          });
        f || r.push({ fileExtension: i, contentType: s.contentType });
      },
      n = ur(e),
      o;
    !(o = n()).done;
  ) {
    var a = o.value;
    t(a);
  }
  return r;
}
function Et(e, r) {
  var t = r.sheetIndex,
    n = r.imageIndex,
    o = t + 1,
    a = n + 1;
  return "sheet".concat(o, "-image").concat(a, ".").concat(At(e.contentType));
}
function No(e) {
  for (
    var r = e.images,
      t = "",
      n = 0,
      o = function () {
        var i = l.value,
          f = n + 1,
          u = function (c) {
            return Xo(c, i.dpi);
          };
        ((t += "<xdr:oneCellAnchor>"),
          (t += "<xdr:from>"),
          (t += "<xdr:col>".concat(i.anchor.column - 1, "</xdr:col>")),
          (t += "<xdr:colOff>".concat(
            typeof i.offsetX == "number" ? u(i.offsetX) : 0,
            "</xdr:colOff>",
          )),
          (t += "<xdr:row>".concat(i.anchor.row - 1, "</xdr:row>")),
          (t += "<xdr:rowOff>".concat(
            typeof i.offsetY == "number" ? u(i.offsetY) : 0,
            "</xdr:rowOff>",
          )),
          (t += "</xdr:from>"),
          (t += '<xdr:ext cx="'
            .concat(u(i.width), '" cy="')
            .concat(u(i.height), '"/>')),
          (t += "<xdr:pic>"),
          (t += "<xdr:nvPicPr>"),
          (t += '<xdr:cNvPr id="'
            .concat(f, '" name="')
            .concat(i.title ? N(i.title) : "Picture " + f, '" descr="')
            .concat(i.description ? N(i.description) : "", '"/>')),
          (t += "<xdr:cNvPicPr>"),
          (t += '<a:picLocks noChangeAspect="1"/>'),
          (t += "</xdr:cNvPicPr>"),
          (t += "</xdr:nvPicPr>"),
          (t += "<xdr:blipFill>"),
          (t +=
            '<a:blip xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" r:embed="rId-image-'.concat(
              f,
              '" cstate="print"/>',
            )),
          (t += "<a:stretch>"),
          (t += "<a:fillRect/>"),
          (t += "</a:stretch>"),
          (t += "</xdr:blipFill>"),
          (t += "<xdr:spPr>"),
          (t += '<a:prstGeom prst="rect">'),
          (t += "<a:avLst/>"),
          (t += "</a:prstGeom>"),
          (t += "</xdr:spPr>"),
          (t += "</xdr:pic>"),
          (t += "<xdr:clientData/>"),
          (t += "</xdr:oneCellAnchor>"),
          n++);
      },
      a = ur(r),
      l;
    !(l = a()).done;
  )
    o();
  return t;
}
function zo(e) {
  var r = e.images,
    t = e.sheetIndex;
  return r
    .map(function (n, o) {
      var a = o + 1;
      return '<Relationship Id="rId-image-'
        .concat(
          a,
          '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="../media/',
        )
        .concat(Et(n, { sheetIndex: t, imageIndex: o }), '"/>');
    })
    .join("");
}
var Mr = 96,
  Vo = 96;
function Xo(e, r) {
  var t = Mr;
  return Math.round(e * 9525 * (Mr / t) * (Vo / r));
}
function _o(e, r, t) {
  return r.selfClosingTag
    ? e.slice(0, r.openingTagStartIndex) + t + e.slice(r.openingTagEndIndex + 1)
    : e.slice(0, r.openingTagStartIndex) +
        t +
        e.slice(r.closingTagEndIndex + 1);
}
function Ho(e, r, t) {
  var n = re(xt(e, t), r);
  if (n) return (St(n, t), n);
}
const Wo = {
  files: {
    transform: {
      "xl/worksheets/sheet{id}.xml": {
        transform: function (r, t, n) {
          var o = n.sheetIndex,
            a = n.sheetId;
          if (Ur(t)) {
            var l = t.stickyRowsCount,
              s = t.stickyColumnsCount,
              i = {
                ySplit: l || 0,
                xSplit: s || 0,
                topLeftCell: fe(l || 0, s || 0),
                activePane: "bottomRight",
                state: "frozen",
              },
              f = re(r, "sheetView");
            if (f) {
              var u = Ho(r, "pane", f),
                d = Me("pane", i);
              u ? (r = _o(r, u, d)) : (r = ke(r, f, d));
            } else {
              var c = re(r, "sheetViews");
              if (c)
                throw new Error(
                  "xl/worksheets/sheet".concat(
                    a,
                    ".xml: <sheetViews/> element exists but it doesn't contain any <sheetView/> elements",
                  ),
                );
              var v = { tabSelected: o === 0 ? 1 : 0, workbookViewId: 0 },
                b =
                  Le("sheetViews") +
                  Le("sheetView", v) +
                  Me("pane", i) +
                  Ze("sheetView") +
                  Ze("sheetViews"),
                g = re(r, "worksheet");
              r = Ct(r, g, b);
            }
          }
          return r;
        },
      },
      "xl/workbook.xml": {
        transform: function (r, t) {
          if (t.some(Ur)) {
            var n = re(r, "workbookView");
            if (!n) {
              var o = re(r, "bookViews");
              if (o)
                throw new Error(
                  "xl/workbook.xml: <bookViews/> element exists but it doesn't contain any <workbookView/> elements",
                );
              return It(
                r,
                "<bookViews><workbookView/></bookViews>",
                Ft("xl/workbook.xml", "workbook"),
                "workbook",
              );
            }
          }
          return r;
        },
      },
    },
  },
};
function Ur(e) {
  return !!e.stickyRowsCount || !!e.stickyColumnsCount;
}
function Go(e) {
  var r = [];
  return (
    r.push(Eo),
    r.push(Lo),
    r.push(Wo),
    e && (e.forEach(qo), (r = r.concat(e))),
    r
  );
}
var Ko = [
  "[Content_Types].xml",
  "_rels/.rels",
  "xl/styles.xml",
  "xl/workbook.xml",
  "xl/_rels/workbook.xml.rels",
  "xl/worksheets/sheet{id}.xml",
  "xl/worksheets/_rels/sheet{id}.xml.rels",
  "xl/drawings/drawing{id}.xml",
  "xl/drawings/_rels/drawing{id}.xml.rels",
];
function qo(e) {
  if (e.files && e.files.transform)
    for (var r = 0, t = Object.keys(e.files.transform); r < t.length; r++) {
      var n = t[r];
      if (Ko.indexOf(n) < 0)
        throw new Error("Unknown file to transform: ".concat(n));
    }
}
function Yo(e, r) {
  var t = (typeof Symbol < "u" && e[Symbol.iterator]) || e["@@iterator"];
  if (t) return (t = t.call(e)).next.bind(t);
  if (Array.isArray(e) || (t = Jo(e)) || r) {
    t && (e = t);
    var n = 0;
    return function () {
      return n >= e.length ? { done: !0 } : { done: !1, value: e[n++] };
    };
  }
  throw new TypeError(`Invalid attempt to iterate non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
}
function Jo(e, r) {
  if (e) {
    if (typeof e == "string") return Nr(e, r);
    var t = {}.toString.call(e).slice(8, -1);
    return (
      t === "Object" && e.constructor && (t = e.constructor.name),
      t === "Map" || t === "Set"
        ? Array.from(e)
        : t === "Arguments" ||
            /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t)
          ? Nr(e, r)
          : void 0
    );
  }
}
function Nr(e, r) {
  (r == null || r > e.length) && (r = e.length);
  for (var t = 0, n = Array(r); t < r; t++) n[t] = e[t];
  return n;
}
function zr(e) {
  if (!Array.isArray(e))
    throw new TypeError("Expected sheet data to be an array of rows");
  for (var r = Yo(e), t; !(t = r()).done;) {
    var n = t.value;
    if (Array.isArray(n)) return;
    throw new Error("Expected each sheet data row to be an array");
  }
}
function Zo() {
  var e = [],
    r = {};
  return {
    getSharedStrings: function () {
      return e;
    },
    findOrCreateSharedString: function (n) {
      var o = r[n];
      return (o === void 0 && ((o = e.length), (r[n] = o), e.push(n)), o);
    },
  };
}
var Qo = /[\[\]\/\\:*?]+/;
function ea(e) {
  if (!e) throw new Error("Sheet name can't be empty");
  if (e.length > 31)
    throw new Error(
      'Sheet name "'.concat(e, `" can't be longer than 31 characters`),
    );
  if (Qo.test(e))
    throw new Error(
      'Sheet name "'.concat(e, '" contains illegal characters: []/\\:*?'),
    );
}
function ra(e, r) {
  var t = (typeof Symbol < "u" && e[Symbol.iterator]) || e["@@iterator"];
  if (t) return (t = t.call(e)).next.bind(t);
  if (Array.isArray(e) || (t = ta(e)) || r) {
    t && (e = t);
    var n = 0;
    return function () {
      return n >= e.length ? { done: !0 } : { done: !1, value: e[n++] };
    };
  }
  throw new TypeError(`Invalid attempt to iterate non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
}
function ta(e, r) {
  if (e) {
    if (typeof e == "string") return Vr(e, r);
    var t = {}.toString.call(e).slice(8, -1);
    return (
      t === "Object" && e.constructor && (t = e.constructor.name),
      t === "Map" || t === "Set"
        ? Array.from(e)
        : t === "Arguments" ||
            /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t)
          ? Vr(e, r)
          : void 0
    );
  }
}
function Vr(e, r) {
  (r == null || r > e.length) && (r = e.length);
  for (var t = 0, n = Array(r); t < r; t++) n[t] = e[t];
  return n;
}
function na(e, r, t) {
  for (
    var n = Zo(),
      o = n.getSharedStrings,
      a = n.findOrCreateSharedString,
      l = oa(t),
      s = bo(l),
      i = s.getCellStyles,
      f = s.findOrCreateCellStyle,
      u = r.map(function (m) {
        return m.sheet;
      }),
      d = ra(u),
      c;
    !(c = d()).done;
  ) {
    var v = c.value;
    ea(v);
  }
  for (var b = [], g = 0; g < u.length;)
    (b.push({
      sheetData: e[g],
      sheetOptions: r[g],
      sheetIndex: g,
      sheetId: Xr(g),
      hasDefaultFont: !!l,
      findOrCreateCellStyle: f,
      findOrCreateSharedString: a,
    }),
      g++);
  return {
    sheets: u.map(function (m, C) {
      var F = C;
      return { sheetId: Xr(F), sheetName: m, sheetXmlParameters: b[F] };
    }),
    getSharedStrings: o,
    getCellStyles: i,
  };
}
function Xr(e) {
  return String(e + 1);
}
function oa(e) {
  var r = e.fontFamily,
    t = e.fontSize;
  if (r || typeof t == "number") return { fontFamily: r, fontSize: t };
}
function aa(e, r) {
  var t;
  return (
    r.some(function (n) {
      return n.header;
    }) &&
      (t = r.map(function (n) {
        var o = n.header;
        return o || null;
      })),
    (t ? [t] : []).concat(
      e.map(function (n, o) {
        return r.map(function (a) {
          var l = a.cell;
          return l(n, o);
        });
      }),
    )
  );
}
function Ie(e) {
  "@babel/helpers - typeof";
  return (
    (Ie =
      typeof Symbol == "function" && typeof Symbol.iterator == "symbol"
        ? function (r) {
            return typeof r;
          }
        : function (r) {
            return r &&
              typeof Symbol == "function" &&
              r.constructor === Symbol &&
              r !== Symbol.prototype
              ? "symbol"
              : typeof r;
          }),
    Ie(e)
  );
}
function _r(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    (r &&
      (n = n.filter(function (o) {
        return Object.getOwnPropertyDescriptor(e, o).enumerable;
      })),
      t.push.apply(t, n));
  }
  return t;
}
function Hr(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = arguments[r] != null ? arguments[r] : {};
    r % 2
      ? _r(Object(t), !0).forEach(function (n) {
          ia(e, n, t[n]);
        })
      : Object.getOwnPropertyDescriptors
        ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t))
        : _r(Object(t)).forEach(function (n) {
            Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(t, n));
          });
  }
  return e;
}
function ia(e, r, t) {
  return (
    (r = la(r)) in e
      ? Object.defineProperty(e, r, {
          value: t,
          enumerable: !0,
          configurable: !0,
          writable: !0,
        })
      : (e[r] = t),
    e
  );
}
function la(e) {
  var r = sa(e, "string");
  return Ie(r) == "symbol" ? r : r + "";
}
function sa(e, r) {
  if (Ie(e) != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var n = t.call(e, r);
    if (Ie(n) != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
function fa(e, r) {
  var t = (typeof Symbol < "u" && e[Symbol.iterator]) || e["@@iterator"];
  if (t) return (t = t.call(e)).next.bind(t);
  if (Array.isArray(e) || (t = ua(e)) || r) {
    t && (e = t);
    var n = 0;
    return function () {
      return n >= e.length ? { done: !0 } : { done: !1, value: e[n++] };
    };
  }
  throw new TypeError(`Invalid attempt to iterate non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
}
function ua(e, r) {
  if (e) {
    if (typeof e == "string") return Wr(e, r);
    var t = {}.toString.call(e).slice(8, -1);
    return (
      t === "Object" && e.constructor && (t = e.constructor.name),
      t === "Map" || t === "Set"
        ? Array.from(e)
        : t === "Arguments" ||
            /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t)
          ? Wr(e, r)
          : void 0
    );
  }
}
function Wr(e, r) {
  (r == null || r > e.length) && (r = e.length);
  for (var t = 0, n = Array(r); t < r; t++) n[t] = e[t];
  return n;
}
function ca(e, r, t) {
  for (var n = t.read, o = {}, a = fa(e), l; !(l = a()).done;) {
    var s = l.value;
    if (s.files && s.files.write && s.files.write.files) {
      var i = s.files.write.files(r, { read: n });
      i && (o = Hr(Hr({}, o), i));
    }
  }
  return o;
}
function Fe(e) {
  "@babel/helpers - typeof";
  return (
    (Fe =
      typeof Symbol == "function" && typeof Symbol.iterator == "symbol"
        ? function (r) {
            return typeof r;
          }
        : function (r) {
            return r &&
              typeof Symbol == "function" &&
              r.constructor === Symbol &&
              r !== Symbol.prototype
              ? "symbol"
              : typeof r;
          }),
    Fe(e)
  );
}
var da = ["data"];
function Gr(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    (r &&
      (n = n.filter(function (o) {
        return Object.getOwnPropertyDescriptor(e, o).enumerable;
      })),
      t.push.apply(t, n));
  }
  return t;
}
function ie(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = arguments[r] != null ? arguments[r] : {};
    r % 2
      ? Gr(Object(t), !0).forEach(function (n) {
          ma(e, n, t[n]);
        })
      : Object.getOwnPropertyDescriptors
        ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t))
        : Gr(Object(t)).forEach(function (n) {
            Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(t, n));
          });
  }
  return e;
}
function ma(e, r, t) {
  return (
    (r = va(r)) in e
      ? Object.defineProperty(e, r, {
          value: t,
          enumerable: !0,
          configurable: !0,
          writable: !0,
        })
      : (e[r] = t),
    e
  );
}
function va(e) {
  var r = ga(e, "string");
  return Fe(r) == "symbol" ? r : r + "";
}
function ga(e, r) {
  if (Fe(e) != "object" || !e) return e;
  var t = e[Symbol.toPrimitive];
  if (t !== void 0) {
    var n = t.call(e, r);
    if (Fe(n) != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(e);
}
function ha(e, r) {
  if (e == null) return {};
  var t,
    n,
    o = pa(e, r);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    for (n = 0; n < a.length; n++)
      ((t = a[n]),
        r.indexOf(t) === -1 &&
          {}.propertyIsEnumerable.call(e, t) &&
          (o[t] = e[t]));
  }
  return o;
}
function pa(e, r) {
  if (e == null) return {};
  var t = {};
  for (var n in e)
    if ({}.hasOwnProperty.call(e, n)) {
      if (r.indexOf(n) !== -1) continue;
      t[n] = e[n];
    }
  return t;
}
function Dt(e, r) {
  var t = (typeof Symbol < "u" && e[Symbol.iterator]) || e["@@iterator"];
  if (t) return (t = t.call(e)).next.bind(t);
  if (Array.isArray(e) || (t = ya(e)) || r) {
    t && (e = t);
    var n = 0;
    return function () {
      return n >= e.length ? { done: !0 } : { done: !1, value: e[n++] };
    };
  }
  throw new TypeError(`Invalid attempt to iterate non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
}
function ya(e, r) {
  if (e) {
    if (typeof e == "string") return Kr(e, r);
    var t = {}.toString.call(e).slice(8, -1);
    return (
      t === "Object" && e.constructor && (t = e.constructor.name),
      t === "Map" || t === "Set"
        ? Array.from(e)
        : t === "Arguments" ||
            /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t)
          ? Kr(e, r)
          : void 0
    );
  }
}
function Kr(e, r) {
  (r == null || r > e.length) && (r = e.length);
  for (var t = 0, n = Array(r); t < r; t++) n[t] = e[t];
  return n;
}
function ba(e, r, t) {
  var n = Bt(e, r, t),
    o = n.sheets,
    a = n.options,
    l = o.map(function (x) {
      return x.data;
    }),
    s = o.map(function (x) {
      return x.options;
    });
  ((s = Ia(s)), (s = Fa(s)));
  var i = Go(a.features),
    f = {},
    u = function (y) {
      return f[y];
    },
    d = function (y) {
      for (var p = 0, A = Object.keys(y); p < A.length; p++) {
        var D = A[p];
        (Sa(D), Ca(D, y[D]), (f[D] = y[D]));
      }
    },
    c = na(l, s, a),
    v = c.sheets,
    b = c.getSharedStrings,
    g = c.getCellStyles;
  ((f["[Content_Types].xml"] = hn({
    sheetIds: v.map(function (x) {
      return x.sheetId;
    }),
    features: i,
    sheetsOptions: s,
  })),
    (f["_rels/.rels"] = gn({ features: i, sheetsOptions: s })),
    (f["xl/_rels/workbook.xml.rels"] = vn({
      sheetIds: v.map(function (x) {
        return x.sheetId;
      }),
      features: i,
      sheetsOptions: s,
    })),
    (f["xl/workbook.xml"] = dn({
      sheetIdsAndNames: v.map(function (x) {
        var y = x.sheetId,
          p = x.sheetName;
        return { sheetId: y, sheetName: p };
      }),
      features: i,
      sheetsOptions: s,
    })));
  for (var m = 0, C = Dt(v), F; !(F = C()).done;) {
    var S = F.value,
      h = S.sheetId,
      w = S.sheetXmlParameters,
      I = s[m];
    ((f["xl/worksheets/sheet".concat(h, ".xml")] = lo(w, i)),
      (f["xl/worksheets/_rels/sheet".concat(h, ".xml.rels")] = so({
        sheetIndex: m,
        sheetId: h,
        sheetOptions: I,
        features: i,
      })),
      (f["xl/drawings/drawing".concat(h, ".xml")] = pn({
        sheetIndex: m,
        sheetId: h,
        sheetOptions: I,
        features: i,
      })),
      (f["xl/drawings/_rels/drawing".concat(h, ".xml.rels")] = yn({
        sheetIndex: m,
        sheetId: h,
        sheetOptions: I,
        features: i,
      })),
      m++);
  }
  return (
    d(ca(i, s, { read: u })),
    (f["xl/styles.xml"] = xo(g(), s, i)),
    (f["xl/sharedStrings.xml"] = co(b())),
    wa(f, v),
    f
  );
}
function wa(e, r) {
  for (var t = Dt(r), n; !(n = t()).done;) {
    var o = n.value.sheetId;
    if (e["xl/drawings/drawing".concat(o, ".xml")] === lt + st) {
      if (
        (delete e["xl/drawings/drawing".concat(o, ".xml")],
        delete e["xl/drawings/_rels/drawing".concat(o, ".xml.rels")],
        !He(e, "xl/worksheets/sheet".concat(o, ".xml"), dt(Me)))
      )
        throw new Error(xa);
      (He(e, "xl/worksheets/_rels/sheet".concat(o, ".xml.rels"), mt(o)),
        He(e, "[Content_Types].xml", it(o)));
    }
  }
}
var xa = "Couldn't remove unused drawings";
function He(e, r, t) {
  if (!e[r]) throw new Error("File not found: ".concat(r));
  if (e[r].indexOf(t) < 0)
    throw new Error('Substring "'.concat(t, '" not found in "').concat(r, '"'));
  var n = e[r],
    o = n.replace(t, "");
  return ((e[r] = o), n !== o);
}
function Sa(e) {
  if (e[0] === "/")
    throw new Error("File path must not start with a slash (/)");
}
function Ca(e, r) {
  if (!r) throw new Error("File `content` not specified: ".concat(e));
}
function Bt(e, r, t) {
  if (Array.isArray(e))
    if (e.length === 0 || Array.isArray(e[0])) {
      if (
        (zr(e), Array.isArray(e[0]) && e.length > 0 && Array.isArray(e[0][0]))
      )
        throw new Error(
          "In order to write multiple sheets, pass an array of sheet objects",
        );
      return { sheets: [{ data: e, options: r || {} }], options: t || {} };
    } else if (Be(e[0])) {
      if (Be(r) && Array.isArray(r.schema))
        throw new Error(
          "`schema` parameter was removed, use `columns` parameter instead",
        );
      return Be(r) && Array.isArray(r.columns)
        ? Bt(aa(e, r.columns), r, t)
        : {
            sheets: e.map(function (n) {
              var o = n.data,
                a = ha(n, da);
              if (!o)
                throw new Error("`data` property is required for each sheet");
              return (zr(o), { data: o, options: a || {} });
            }),
            options: r || {},
          };
    } else
      throw new Error(
        "Invalid first argument: must be either sheet data — an array of arrays — or an array of sheet objects",
      );
  else throw new Error("Invalid first argument: must be an array");
}
function Ia(e) {
  return e.map(function (r, t) {
    return ie(ie({}, r), {}, { sheet: r.sheet || "Sheet".concat(t + 1) });
  });
}
function Fa(e) {
  var r = 0;
  return e.map(function (t) {
    return ie(
      ie({}, t),
      {},
      {
        conditionalFormatting:
          t.conditionalFormatting &&
          t.conditionalFormatting.map(function (n) {
            return ie(ie({}, n), {}, { _globalIndex: r++ });
          }),
      },
    );
  });
}
function Da(e, r, t) {
  return {
    toBlob: function () {
      return Oa(e, r, t, Pt);
    },
  };
}
function Aa(e, r, t, n, o, a) {
  var l = ba(e, r, t);
  return Zt(l, n).then(function (s) {
    var i = o(s);
    return i.then(function (f) {
      return Ta(f);
    });
  });
}
function Ta(e) {
  return new Blob([e], {
    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  });
}
function Oa(e, r, t, n) {
  return Aa(e, r, t, n, Yt);
}
export { Da as default, aa as getSheetData };
