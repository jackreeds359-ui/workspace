import { j as e, r as f } from "./react-vendor-BK1G6oO1.js";
import {
  ch as Ie,
  b6 as H,
  bm as ie,
  bW as Qe,
  bZ as Ce,
  P as ae,
  ad as He,
  ci as Ge,
  R as Ke,
} from "./index-DjyiOHey.js";
import { aq as Ye, aT as Ue } from "./GameNotebook-b0Qw2wzd.js";
import { u as qe } from "./keyword-flashcards-Ha6Msavb.js";
import "./ui-components-DeMDYLzO.js";
const i = {
    night: "#0a0f1f",
    deep: "#111a30",
    wall: "#1a2644",
    panel: "#24345a",
    edge: "#34497a",
    dim: "#4d6699",
    mute: "#7d93c0",
    soft: "#b4c3e0",
    paper: "#e3e9f5",
    white: "#ffffff",
  },
  N = { main: "#2fd6c3", dark: "#12877a", pale: "#c8f5ee" },
  w = { main: "#ffc04d", dark: "#b9770e", pale: "#ffeccc" },
  P = { main: "#a98bff", dark: "#5b3fc4", pale: "#e6dcff" },
  q = { main: "#4ade80", dark: "#166534" },
  k = { main: "#fb6f84", dark: "#9f1239", pale: "#ffe0e5" },
  m = {
    frog: "#6cc96a",
    frogDark: "#2f7d3a",
    hedgehog: "#a8774f",
    hedgehogDark: "#5b3a22",
    badger: "#9aa3b2",
    badgerDark: "#2b2f38",
    owl: "#c9925a",
    owlDark: "#7a4e25",
    fox: "#f08a3c",
    foxDark: "#a34d14",
    rabbit: "#d9d4e6",
    rabbitDark: "#8f86a8",
    cream: "#fff4dc",
    nose: "#f4a3b4",
  };
[
  ...Object.values(i),
  ...Object.values(N),
  ...Object.values(w),
  ...Object.values(P),
  ...Object.values(q),
  ...Object.values(k),
  ...Object.values(m),
];
const z = "ui-sans-serif, system-ui, sans-serif",
  _ = "ui-monospace, SFMono-Regular, Menlo, monospace";
function W({ x: t, y: r, scale: s = 1, children: a }) {
  return e.jsx("g", {
    transform: `translate(${t} ${r}) scale(${s})`,
    children: a,
  });
}
function D({ mood: t, eyeY: r = 50, eyeGap: s = 14, cx: a = 50 }) {
  const o = r + 16;
  return e.jsxs("g", {
    children: [
      e.jsx("circle", { cx: a - s, cy: r, r: 4, fill: i.night }),
      e.jsx("circle", { cx: a + s, cy: r, r: 4, fill: i.night }),
      e.jsx("circle", { cx: a - s + 1.4, cy: r - 1.4, r: 1.3, fill: i.white }),
      e.jsx("circle", { cx: a + s + 1.4, cy: r - 1.4, r: 1.3, fill: i.white }),
      t === "worried"
        ? e.jsxs(e.Fragment, {
            children: [
              e.jsx("path", {
                d: `M${a - s - 6} ${r - 10} l9 3M${a + s + 6} ${r - 10} l-9 3`,
                stroke: i.night,
                strokeWidth: 2.2,
                strokeLinecap: "round",
              }),
              e.jsx("path", {
                d: `M${a - 7} ${o + 3} q7 -6 14 0`,
                fill: "none",
                stroke: i.night,
                strokeWidth: 2.4,
                strokeLinecap: "round",
              }),
            ],
          })
        : t === "happy"
          ? e.jsx("path", {
              d: `M${a - 8} ${o - 2} q8 9 16 0`,
              fill: "none",
              stroke: i.night,
              strokeWidth: 2.4,
              strokeLinecap: "round",
            })
          : e.jsx("path", {
              d: `M${a - 6} ${o} q6 3 12 0`,
              fill: "none",
              stroke: i.night,
              strokeWidth: 2.2,
              strokeLinecap: "round",
            }),
    ],
  });
}
function F({ tone: t }) {
  return e.jsxs("g", {
    children: [
      e.jsx("path", { d: "M14 100 q2 -24 36 -26 q34 2 36 26z", fill: i.edge }),
      e.jsx("path", {
        d: "M40 76 l10 12 l10 -12",
        fill: "none",
        stroke: t,
        strokeWidth: 3,
        strokeLinecap: "round",
      }),
      e.jsx("rect", {
        x: 44,
        y: 88,
        width: 12,
        height: 9,
        rx: 2,
        fill: i.paper,
      }),
    ],
  });
}
function E({ creature: t, mood: r = "calm" }) {
  switch (t) {
    case "frog":
      return e.jsxs("g", {
        "data-creature": "frog",
        children: [
          e.jsx(F, { tone: m.frog }),
          e.jsx("ellipse", { cx: 50, cy: 54, rx: 32, ry: 24, fill: m.frog }),
          e.jsx("circle", { cx: 34, cy: 34, r: 11, fill: m.frog }),
          e.jsx("circle", { cx: 66, cy: 34, r: 11, fill: m.frog }),
          e.jsx("circle", { cx: 34, cy: 34, r: 7, fill: m.cream }),
          e.jsx("circle", { cx: 66, cy: 34, r: 7, fill: m.cream }),
          e.jsx("ellipse", {
            cx: 50,
            cy: 62,
            rx: 20,
            ry: 8,
            fill: m.frogDark,
            opacity: 0.35,
          }),
          e.jsx(D, { mood: r, eyeY: 35, eyeGap: 16 }),
        ],
      });
    case "hedgehog":
      return e.jsxs("g", {
        "data-creature": "hedgehog",
        children: [
          e.jsx(F, { tone: m.hedgehog }),
          e.jsx("path", {
            d: "M14 62 L10 48 L20 44 L16 30 L28 30 L28 16 L40 22 L46 8 L54 20 L64 10 L68 24 L80 18 L78 32 L90 34 L84 46 L92 54 L84 62z",
            fill: m.hedgehogDark,
          }),
          e.jsx("ellipse", { cx: 50, cy: 52, rx: 26, ry: 24, fill: m.cream }),
          e.jsx("circle", { cx: 50, cy: 60, r: 4, fill: i.night }),
          e.jsx(D, { mood: r, eyeY: 46, eyeGap: 11 }),
        ],
      });
    case "badger":
      return e.jsxs("g", {
        "data-creature": "badger",
        children: [
          e.jsx(F, { tone: m.badger }),
          e.jsx("circle", { cx: 28, cy: 26, r: 8, fill: m.badgerDark }),
          e.jsx("circle", { cx: 72, cy: 26, r: 8, fill: m.badgerDark }),
          e.jsx("ellipse", { cx: 50, cy: 50, rx: 28, ry: 27, fill: m.badger }),
          e.jsx("path", {
            d: "M30 34 q6 -10 12 0 l2 26 q-8 4 -14 -4z",
            fill: m.badgerDark,
          }),
          e.jsx("path", {
            d: "M70 34 q-6 -10 -12 0 l-2 26 q8 4 14 -4z",
            fill: m.badgerDark,
          }),
          e.jsx("path", { d: "M44 24 q6 -4 12 0 l-2 36 h-8z", fill: i.white }),
          e.jsx("ellipse", { cx: 50, cy: 64, rx: 5, ry: 4, fill: i.night }),
          e.jsx(D, { mood: r, eyeY: 46, eyeGap: 13 }),
        ],
      });
    case "owl":
      return e.jsxs("g", {
        "data-creature": "owl",
        children: [
          e.jsx(F, { tone: m.owl }),
          e.jsx("path", {
            d: "M22 30 L26 12 L38 26z M78 30 L74 12 L62 26z",
            fill: m.owlDark,
          }),
          e.jsx("ellipse", { cx: 50, cy: 50, rx: 30, ry: 28, fill: m.owl }),
          e.jsx("circle", { cx: 37, cy: 46, r: 11, fill: m.cream }),
          e.jsx("circle", { cx: 63, cy: 46, r: 11, fill: m.cream }),
          e.jsx("path", { d: "M45 58 L55 58 L50 66z", fill: w.dark }),
          e.jsx(D, { mood: r, eyeY: 46, eyeGap: 13 }),
        ],
      });
    case "fox":
      return e.jsxs("g", {
        "data-creature": "fox",
        children: [
          e.jsx(F, { tone: m.fox }),
          e.jsx("path", {
            d: "M22 40 L24 10 L44 28z M78 40 L76 10 L56 28z",
            fill: m.fox,
          }),
          e.jsx("path", {
            d: "M27 32 L28 18 L38 28z M73 32 L72 18 L62 28z",
            fill: m.foxDark,
          }),
          e.jsx("path", {
            d: "M20 40 Q50 18 80 40 Q78 70 50 78 Q22 70 20 40z",
            fill: m.fox,
          }),
          e.jsx("path", {
            d: "M28 54 Q38 70 50 76 Q62 70 72 54 Q60 62 50 60 Q40 62 28 54z",
            fill: m.cream,
          }),
          e.jsx("circle", { cx: 50, cy: 64, r: 4, fill: i.night }),
          e.jsx(D, { mood: r, eyeY: 46, eyeGap: 13 }),
        ],
      });
    case "rabbit":
      return e.jsxs("g", {
        "data-creature": "rabbit",
        children: [
          e.jsx(F, { tone: m.rabbit }),
          e.jsx("ellipse", { cx: 38, cy: 14, rx: 7, ry: 20, fill: m.rabbit }),
          e.jsx("ellipse", { cx: 62, cy: 14, rx: 7, ry: 20, fill: m.rabbit }),
          e.jsx("ellipse", { cx: 38, cy: 16, rx: 3, ry: 14, fill: m.nose }),
          e.jsx("ellipse", { cx: 62, cy: 16, rx: 3, ry: 14, fill: m.nose }),
          e.jsx("ellipse", { cx: 50, cy: 52, rx: 27, ry: 25, fill: m.rabbit }),
          e.jsx("ellipse", { cx: 50, cy: 62, rx: 4, ry: 3, fill: m.nose }),
          e.jsx("path", {
            d: "M34 62 h-12M34 66 h-11M66 62 h12M66 66 h11",
            stroke: m.rabbitDark,
            strokeWidth: 1.4,
            strokeLinecap: "round",
          }),
          e.jsx(D, { mood: r, eyeY: 48, eyeGap: 12 }),
        ],
      });
  }
}
function X({ x: t, y: r, w: s, h: a, children: o }) {
  return e.jsxs("g", {
    children: [
      e.jsx("rect", {
        x: t,
        y: r,
        width: s,
        height: a,
        rx: 5,
        fill: i.deep,
        stroke: i.mute,
        strokeWidth: 2.5,
      }),
      o,
    ],
  });
}
function ge({ prop: t }) {
  switch (t) {
    case "game-box":
      return e.jsxs("g", {
        "data-prop": "game-box",
        children: [
          e.jsx("rect", {
            x: 30,
            y: 8,
            width: 60,
            height: 84,
            rx: 4,
            fill: N.dark,
            stroke: i.paper,
            strokeWidth: 2,
          }),
          e.jsx("rect", {
            x: 36,
            y: 16,
            width: 48,
            height: 42,
            rx: 3,
            fill: i.wall,
          }),
          e.jsx("path", {
            d: "M40 48 q10 -16 22 -14 h10 l6 8 h-4 a4 4 0 0 1 -8 0 h-14 a4 4 0 0 1 -8 0z",
            fill: m.frog,
          }),
          e.jsx("path", {
            d: "M36 66 h48M36 74 h30",
            stroke: i.paper,
            strokeWidth: 3,
            strokeLinecap: "round",
          }),
        ],
      });
    case "quiz":
      return e.jsxs("g", {
        "data-prop": "quiz",
        children: [
          e.jsx(X, {
            x: 14,
            y: 10,
            w: 92,
            h: 62,
            children: e.jsx("text", {
              x: 60,
              y: 52,
              textAnchor: "middle",
              fontFamily: z,
              fontSize: 40,
              fontWeight: 800,
              fill: w.main,
              children: "?",
            }),
          }),
          e.jsx("path", {
            d: "M52 72 v12 M36 88 h48",
            stroke: i.mute,
            strokeWidth: 4,
            strokeLinecap: "round",
          }),
        ],
      });
    case "timetable":
      return e.jsxs("g", {
        "data-prop": "timetable",
        children: [
          e.jsx("rect", {
            x: 10,
            y: 10,
            width: 100,
            height: 78,
            rx: 4,
            fill: i.paper,
          }),
          e.jsx("rect", {
            x: 10,
            y: 10,
            width: 100,
            height: 14,
            rx: 4,
            fill: i.dim,
          }),
          [0, 1, 2, 3].map((r) =>
            [0, 1, 2].map((s) =>
              e.jsx(
                "rect",
                {
                  x: 16 + r * 24,
                  y: 30 + s * 18,
                  width: 18,
                  height: 12,
                  rx: 2,
                  fill:
                    (r + s) % 3 === 0
                      ? w.main
                      : (r + s) % 3 === 1
                        ? N.main
                        : P.main,
                  opacity: 0.8,
                },
                `${r}-${s}`,
              ),
            ),
          ),
        ],
      });
    case "barrier":
      return e.jsxs("g", {
        "data-prop": "barrier",
        children: [
          e.jsx("rect", {
            x: 14,
            y: 30,
            width: 22,
            height: 64,
            rx: 4,
            fill: i.mute,
          }),
          e.jsx("rect", {
            x: 84,
            y: 30,
            width: 22,
            height: 64,
            rx: 4,
            fill: i.mute,
          }),
          e.jsx("rect", {
            x: 36,
            y: 52,
            width: 22,
            height: 8,
            rx: 3,
            fill: k.main,
          }),
          e.jsx("rect", {
            x: 62,
            y: 52,
            width: 22,
            height: 8,
            rx: 3,
            fill: k.main,
          }),
          e.jsx("rect", {
            x: 18,
            y: 36,
            width: 14,
            height: 10,
            rx: 2,
            fill: N.main,
          }),
          e.jsx("path", { d: "M60 6 v16", stroke: i.soft, strokeWidth: 3 }),
          e.jsx("rect", {
            x: 44,
            y: 0,
            width: 32,
            height: 10,
            rx: 2,
            fill: i.wall,
            stroke: i.soft,
            strokeWidth: 1.5,
          }),
        ],
      });
    case "laptops":
      return e.jsxs("g", {
        "data-prop": "laptops",
        children: [
          [0, 1, 2].map((r) =>
            e.jsxs(
              "g",
              {
                transform: `translate(${r * 10} ${r * -14})`,
                children: [
                  e.jsx("rect", {
                    x: 14,
                    y: 60,
                    width: 70,
                    height: 30,
                    rx: 3,
                    fill: i.edge,
                    stroke: i.soft,
                    strokeWidth: 2,
                  }),
                  e.jsx("path", {
                    d: "M8 92 h82",
                    stroke: i.soft,
                    strokeWidth: 4,
                    strokeLinecap: "round",
                  }),
                ],
              },
              r,
            ),
          ),
          e.jsx("path", {
            d: "M40 58 l8 -8 l8 8",
            fill: "none",
            stroke: N.main,
            strokeWidth: 3,
            strokeLinecap: "round",
          }),
        ],
      });
    case "robot-arm":
      return e.jsxs("g", {
        "data-prop": "robot-arm",
        children: [
          e.jsx("rect", {
            x: 20,
            y: 80,
            width: 44,
            height: 14,
            rx: 3,
            fill: i.mute,
          }),
          e.jsx("path", {
            d: "M42 80 L52 46 L88 30",
            fill: "none",
            stroke: w.main,
            strokeWidth: 10,
            strokeLinecap: "round",
            strokeLinejoin: "round",
          }),
          e.jsx("circle", { cx: 52, cy: 46, r: 7, fill: i.paper }),
          e.jsx("circle", { cx: 42, cy: 80, r: 7, fill: i.paper }),
          e.jsx("path", {
            d: "M88 30 l14 -6 M88 30 l12 10",
            stroke: i.paper,
            strokeWidth: 5,
            strokeLinecap: "round",
          }),
        ],
      });
    case "bank":
      return e.jsxs("g", {
        "data-prop": "bank",
        children: [
          e.jsx("path", { d: "M10 34 L60 8 L110 34z", fill: i.soft }),
          [0, 1, 2, 3].map((r) =>
            e.jsx(
              "rect",
              { x: 20 + r * 24, y: 38, width: 10, height: 44, fill: i.paper },
              r,
            ),
          ),
          e.jsx("rect", { x: 10, y: 82, width: 100, height: 10, fill: i.soft }),
          e.jsx("circle", { cx: 60, cy: 24, r: 6, fill: w.main }),
        ],
      });
    case "console":
      return e.jsxs("g", {
        "data-prop": "console",
        children: [
          e.jsxs(X, {
            x: 14,
            y: 6,
            w: 92,
            h: 56,
            children: [
              e.jsx("rect", {
                x: 26,
                y: 44,
                width: 22,
                height: 6,
                fill: N.main,
              }),
              e.jsx("rect", {
                x: 60,
                y: 34,
                width: 22,
                height: 6,
                fill: N.main,
              }),
              e.jsx("circle", { cx: 40, cy: 36, r: 5, fill: m.rabbit }),
            ],
          }),
          e.jsx("path", {
            d: "M30 76 q-12 0 -12 10 q0 8 8 8 l10 -6 h48 l10 6 q8 0 8 -8 q0 -10 -12 -10z",
            fill: i.edge,
            stroke: i.soft,
            strokeWidth: 2,
          }),
          e.jsx("circle", { cx: 80, cy: 84, r: 3, fill: k.main }),
          e.jsx("circle", { cx: 88, cy: 80, r: 3, fill: q.main }),
        ],
      });
    case "weather":
      return e.jsxs("g", {
        "data-prop": "weather",
        children: [
          e.jsx("path", { d: "M60 30 V94", stroke: i.soft, strokeWidth: 4 }),
          e.jsx("path", {
            d: "M60 30 h-26 M60 30 h26 M60 30 v-20",
            stroke: i.soft,
            strokeWidth: 3,
          }),
          e.jsx("circle", { cx: 32, cy: 30, r: 7, fill: N.main }),
          e.jsx("circle", { cx: 88, cy: 30, r: 7, fill: N.main }),
          e.jsx("circle", { cx: 60, cy: 8, r: 7, fill: N.main }),
          e.jsx("rect", {
            x: 44,
            y: 58,
            width: 32,
            height: 22,
            rx: 3,
            fill: i.paper,
          }),
          e.jsx("text", {
            x: 60,
            y: 74,
            textAnchor: "middle",
            fontFamily: _,
            fontSize: 12,
            fontWeight: 700,
            fill: i.night,
            children: "18°",
          }),
        ],
      });
    case "club":
      return e.jsxs("g", {
        "data-prop": "club",
        children: [
          e.jsx("rect", {
            x: 6,
            y: 8,
            width: 108,
            height: 70,
            rx: 4,
            fill: i.paper,
            stroke: i.soft,
            strokeWidth: 3,
          }),
          ['print("Hi")', "x = 3", "if x > 2 then"].map((r, s) =>
            e.jsx(
              "text",
              {
                x: 14,
                y: 28 + s * 16,
                fontFamily: _,
                fontSize: 11,
                fill: i.night,
                children: r,
              },
              r,
            ),
          ),
          e.jsx("path", {
            d: "M30 78 L22 96 M90 78 L98 96",
            stroke: i.soft,
            strokeWidth: 4,
            strokeLinecap: "round",
          }),
        ],
      });
    case "washer":
      return e.jsxs("g", {
        "data-prop": "washer",
        children: [
          e.jsx("rect", {
            x: 22,
            y: 6,
            width: 76,
            height: 88,
            rx: 6,
            fill: i.paper,
          }),
          e.jsx("rect", {
            x: 22,
            y: 6,
            width: 76,
            height: 16,
            rx: 6,
            fill: i.soft,
          }),
          e.jsx("circle", { cx: 84, cy: 14, r: 4, fill: q.main }),
          e.jsx("circle", {
            cx: 60,
            cy: 56,
            r: 26,
            fill: i.edge,
            stroke: i.mute,
            strokeWidth: 5,
          }),
          e.jsx("path", {
            d: "M46 60 q14 -12 28 0",
            fill: "none",
            stroke: N.pale,
            strokeWidth: 4,
            strokeLinecap: "round",
          }),
        ],
      });
    case "devices":
      return e.jsxs("g", {
        "data-prop": "devices",
        children: [
          e.jsx(X, { x: 6, y: 18, w: 74, h: 50 }),
          e.jsx("path", {
            d: "M0 74 h86",
            stroke: i.soft,
            strokeWidth: 5,
            strokeLinecap: "round",
          }),
          e.jsx("rect", {
            x: 86,
            y: 30,
            width: 28,
            height: 56,
            rx: 6,
            fill: i.deep,
            stroke: i.mute,
            strokeWidth: 3,
          }),
          e.jsx("rect", {
            x: 20,
            y: 32,
            width: 46,
            height: 6,
            rx: 2,
            fill: w.main,
          }),
          e.jsx("rect", {
            x: 92,
            y: 42,
            width: 16,
            height: 5,
            rx: 2,
            fill: w.main,
          }),
        ],
      });
    case "booking":
      return e.jsxs("g", {
        "data-prop": "booking",
        children: [
          e.jsx("rect", {
            x: 14,
            y: 14,
            width: 92,
            height: 78,
            rx: 5,
            fill: i.paper,
          }),
          e.jsx("rect", {
            x: 14,
            y: 14,
            width: 92,
            height: 18,
            rx: 5,
            fill: P.main,
          }),
          e.jsx("path", {
            d: "M34 6 v14 M86 6 v14",
            stroke: i.soft,
            strokeWidth: 4,
            strokeLinecap: "round",
          }),
          [0, 1, 2].map((r) =>
            [0, 1, 2, 3].map((s) =>
              e.jsx(
                "path",
                {
                  d: `M${26 + s * 20} ${48 + r * 16} l4 4 l8 -8`,
                  fill: "none",
                  stroke: (r + s) % 2 ? q.dark : i.mute,
                  strokeWidth: 2.5,
                  strokeLinecap: "round",
                },
                `${r}-${s}`,
              ),
            ),
          ),
        ],
      });
    case "chip":
      return e.jsxs("g", {
        "data-prop": "chip",
        children: [
          e.jsx("rect", {
            x: 6,
            y: 28,
            width: 108,
            height: 52,
            rx: 4,
            fill: q.dark,
          }),
          e.jsx("circle", {
            cx: 42,
            cy: 54,
            r: 18,
            fill: i.wall,
            stroke: i.soft,
            strokeWidth: 3,
          }),
          e.jsx("path", {
            d: "M42 38 v32 M26 54 h32 M31 43 l22 22 M53 43 l-22 22",
            stroke: i.soft,
            strokeWidth: 2.5,
          }),
          e.jsx("rect", {
            x: 72,
            y: 40,
            width: 30,
            height: 28,
            rx: 2,
            fill: i.night,
          }),
          [0, 1, 2, 3, 4, 5].map((r) =>
            e.jsx(
              "rect",
              { x: 14 + r * 16, y: 80, width: 8, height: 8, fill: w.main },
              r,
            ),
          ),
        ],
      });
    case "watch":
      return e.jsxs("g", {
        "data-prop": "watch",
        children: [
          e.jsx("rect", {
            x: 42,
            y: 0,
            width: 36,
            height: 100,
            rx: 10,
            fill: i.edge,
          }),
          e.jsx("rect", {
            x: 30,
            y: 24,
            width: 60,
            height: 56,
            rx: 14,
            fill: i.deep,
            stroke: i.soft,
            strokeWidth: 3,
          }),
          e.jsx("path", {
            d: "M60 66 l-14 -14 a8 8 0 0 1 14 -10 a8 8 0 0 1 14 10z",
            fill: k.main,
          }),
        ],
      });
    case "tablet":
      return e.jsxs("g", {
        "data-prop": "tablet",
        children: [
          e.jsx("rect", {
            x: 14,
            y: 6,
            width: 92,
            height: 88,
            rx: 8,
            fill: i.deep,
            stroke: i.soft,
            strokeWidth: 3,
          }),
          e.jsx("rect", {
            x: 26,
            y: 22,
            width: 68,
            height: 12,
            rx: 3,
            fill: i.paper,
          }),
          [0, 1].map((r) =>
            e.jsx(
              "rect",
              {
                x: 26 + r * 36,
                y: 44,
                width: 32,
                height: 18,
                rx: 3,
                fill: r ? w.main : N.main,
              },
              r,
            ),
          ),
          [0, 1].map((r) =>
            e.jsx(
              "rect",
              {
                x: 26 + r * 36,
                y: 66,
                width: 32,
                height: 18,
                rx: 3,
                fill: r ? P.main : q.main,
              },
              r,
            ),
          ),
        ],
      });
  }
}
function A({ tone: t, children: r }) {
  return e.jsxs("g", {
    children: [
      e.jsx("circle", {
        cx: 40,
        cy: 40,
        r: 38,
        fill: t === "ok" ? q.dark : k.dark,
        stroke: t === "ok" ? q.main : k.main,
        strokeWidth: 4,
      }),
      r,
    ],
  });
}
function je({ mishap: t }) {
  switch (t) {
    case "ok":
      return e.jsx(A, {
        tone: "ok",
        children: e.jsx("path", {
          d: "M22 42 l12 12 l24 -26",
          fill: "none",
          stroke: i.white,
          strokeWidth: 8,
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }),
      });
    case "copied":
      return e.jsxs(A, {
        tone: "bad",
        children: [
          e.jsx("rect", {
            x: 18,
            y: 20,
            width: 26,
            height: 34,
            rx: 3,
            fill: i.paper,
          }),
          e.jsx("rect", {
            x: 36,
            y: 28,
            width: 26,
            height: 34,
            rx: 3,
            fill: k.pale,
            stroke: k.main,
            strokeWidth: 2,
            strokeDasharray: "4 3",
          }),
          e.jsx("text", {
            x: 49,
            y: 50,
            textAnchor: "middle",
            fontFamily: z,
            fontSize: 9,
            fontWeight: 800,
            fill: k.dark,
            children: "COPY",
          }),
        ],
      });
    case "no-translator":
      return e.jsxs(A, {
        tone: "bad",
        children: [
          e.jsx("rect", {
            x: 16,
            y: 22,
            width: 48,
            height: 36,
            rx: 4,
            fill: i.paper,
          }),
          e.jsx("rect", {
            x: 16,
            y: 22,
            width: 48,
            height: 9,
            rx: 4,
            fill: k.main,
          }),
          e.jsx("path", {
            d: "M33 38 l14 14 M47 38 l-14 14",
            stroke: k.dark,
            strokeWidth: 4,
            strokeLinecap: "round",
          }),
        ],
      });
    case "nothing-runs":
      return e.jsxs(A, {
        tone: "bad",
        children: [
          e.jsx("rect", {
            x: 16,
            y: 20,
            width: 48,
            height: 36,
            rx: 4,
            fill: i.night,
            stroke: i.mute,
            strokeWidth: 2,
          }),
          [0, 1, 2].map((r) =>
            e.jsx(
              "rect",
              {
                x: 22,
                y: 26 + r * 9,
                width: 30 - r * 6,
                height: 4,
                rx: 2,
                fill: k.main,
              },
              r,
            ),
          ),
          e.jsx("path", {
            d: "M34 62 h12",
            stroke: i.mute,
            strokeWidth: 4,
            strokeLinecap: "round",
          }),
        ],
      });
    case "queue":
      return e.jsxs(A, {
        tone: "bad",
        children: [
          [0, 1, 2, 3, 4].map((r) =>
            e.jsxs(
              "g",
              {
                children: [
                  e.jsx("circle", {
                    cx: 16 + r * 12,
                    cy: 36,
                    r: 5,
                    fill: i.paper,
                  }),
                  e.jsx("rect", {
                    x: 11 + r * 12,
                    y: 43,
                    width: 10,
                    height: 14,
                    rx: 4,
                    fill: i.paper,
                  }),
                ],
              },
              r,
            ),
          ),
          e.jsx("path", {
            d: "M14 66 h52",
            stroke: k.pale,
            strokeWidth: 3,
            strokeDasharray: "4 4",
          }),
        ],
      });
    case "stale":
      return e.jsxs(A, {
        tone: "bad",
        children: [
          e.jsx("rect", {
            x: 20,
            y: 18,
            width: 40,
            height: 44,
            rx: 4,
            fill: i.paper,
          }),
          e.jsx("rect", {
            x: 20,
            y: 18,
            width: 40,
            height: 11,
            rx: 4,
            fill: k.main,
          }),
          e.jsx("path", {
            d: "M48 46 h-18 m6 -6 l-6 6 l6 6",
            fill: "none",
            stroke: k.dark,
            strokeWidth: 4,
            strokeLinecap: "round",
            strokeLinejoin: "round",
          }),
        ],
      });
    case "stutter":
      return e.jsx(A, {
        tone: "bad",
        children: e.jsx("path", {
          d: "M12 46 l10 -14 l8 20 l10 -26 l8 30 l10 -18 l10 8",
          fill: "none",
          stroke: k.pale,
          strokeWidth: 5,
          strokeLinecap: "round",
          strokeLinejoin: "round",
        }),
      });
    case "extra":
      return e.jsxs(A, {
        tone: "bad",
        children: [
          e.jsx("rect", {
            x: 14,
            y: 30,
            width: 52,
            height: 32,
            rx: 4,
            fill: w.dark,
          }),
          e.jsx("path", { d: "M14 40 h52", stroke: w.main, strokeWidth: 3 }),
          e.jsx("path", {
            d: "M20 22 l40 46",
            stroke: k.pale,
            strokeWidth: 5,
            strokeLinecap: "round",
          }),
        ],
      });
    case "no-exe":
      return e.jsxs(A, {
        tone: "bad",
        children: [
          e.jsx("rect", {
            x: 20,
            y: 22,
            width: 40,
            height: 36,
            rx: 4,
            fill: "none",
            stroke: k.pale,
            strokeWidth: 3,
            strokeDasharray: "5 4",
          }),
          e.jsx("text", {
            x: 40,
            y: 45,
            textAnchor: "middle",
            fontFamily: _,
            fontSize: 11,
            fontWeight: 800,
            fill: k.pale,
            children: ".exe?",
          }),
        ],
      });
    case "rewrite":
      return e.jsxs(A, {
        tone: "bad",
        children: [
          e.jsx("rect", {
            x: 14,
            y: 22,
            width: 24,
            height: 34,
            rx: 3,
            fill: i.paper,
          }),
          e.jsx("rect", {
            x: 42,
            y: 22,
            width: 24,
            height: 34,
            rx: 3,
            fill: i.paper,
          }),
          e.jsx("path", {
            d: "M46 30 l16 18 M62 30 l-16 18",
            stroke: k.main,
            strokeWidth: 4,
            strokeLinecap: "round",
          }),
        ],
      });
    case "too-big":
      return e.jsxs(A, {
        tone: "bad",
        children: [
          e.jsx("rect", {
            x: 26,
            y: 34,
            width: 28,
            height: 28,
            rx: 3,
            fill: q.dark,
            stroke: i.paper,
            strokeWidth: 2,
          }),
          e.jsx("rect", {
            x: 14,
            y: 14,
            width: 52,
            height: 30,
            rx: 3,
            fill: i.paper,
            opacity: 0.9,
          }),
          e.jsx("text", {
            x: 40,
            y: 34,
            textAnchor: "middle",
            fontFamily: _,
            fontSize: 11,
            fontWeight: 800,
            fill: k.dark,
            children: "> 2 KB",
          }),
        ],
      });
    case "slow-team":
      return e.jsxs(A, {
        tone: "bad",
        children: [
          e.jsx("path", {
            d: "M26 16 h28 M26 64 h28 M30 16 q0 18 10 24 q-10 6 -10 24 M50 16 q0 18 -10 24 q10 6 10 24",
            fill: "none",
            stroke: i.paper,
            strokeWidth: 4,
            strokeLinecap: "round",
          }),
          e.jsx("path", { d: "M34 58 h12 l-6 -8z", fill: w.main }),
        ],
      });
  }
}
function Ve({ w: t, h: r, floor: s, window: a }) {
  return e.jsxs("g", {
    children: [
      e.jsx("rect", { width: t, height: r, fill: i.wall }),
      a
        ? e.jsxs("g", {
            children: [
              e.jsx("rect", {
                x: t * 0.06,
                y: r * 0.08,
                width: t * 0.22,
                height: r * 0.3,
                rx: 6,
                fill: i.night,
                stroke: i.edge,
                strokeWidth: 4,
              }),
              e.jsx("circle", {
                cx: t * 0.12,
                cy: r * 0.15,
                r: 2,
                fill: i.paper,
              }),
              e.jsx("circle", {
                cx: t * 0.2,
                cy: r * 0.24,
                r: 1.6,
                fill: i.paper,
              }),
              e.jsx("circle", {
                cx: t * 0.24,
                cy: r * 0.13,
                r: 6,
                fill: w.pale,
              }),
            ],
          })
        : null,
      e.jsx("rect", { y: s, width: t, height: r - s, fill: i.deep }),
      e.jsx("path", { d: `M0 ${s} H${t}`, stroke: i.edge, strokeWidth: 4 }),
    ],
  });
}
function ye({ x: t, y: r, name: s }) {
  const a = s.length * 11 + 24;
  return e.jsxs("g", {
    children: [
      e.jsx("rect", {
        x: t - a / 2,
        y: r,
        width: a,
        height: 26,
        rx: 13,
        fill: i.night,
        stroke: i.mute,
        strokeWidth: 1.5,
      }),
      e.jsx("text", {
        x: t,
        y: r + 18,
        textAnchor: "middle",
        fontFamily: z,
        fontSize: 15,
        fontWeight: 700,
        fill: i.paper,
        children: s,
      }),
    ],
  });
}
function ze({
  developer: t,
  prop: r,
  mishap: s,
  layout: a = "wide",
  label: o,
}) {
  const n = s === void 0 ? "calm" : s === "ok" ? "happy" : "worried",
    l = a === "wide",
    c = l ? 640 : 360,
    p = l ? 300 : 420;
  return e.jsxs("svg", {
    viewBox: `0 0 ${c} ${p}`,
    width: "100%",
    role: "img",
    "aria-label": o,
    className: "tl-scene",
    "data-layout": a,
    "data-prop": r,
    "data-mishap": s ?? "none",
    preserveAspectRatio: "xMidYMid meet",
    children: [
      e.jsx(Ve, { w: c, h: p, floor: l ? 236 : 330, window: l }),
      l
        ? e.jsxs(e.Fragment, {
            children: [
              e.jsx(W, {
                x: 40,
                y: 96,
                scale: 1.6,
                children: e.jsx(E, { creature: t.creature, mood: n }),
              }),
              e.jsx(ye, { x: 120, y: 262, name: t.name }),
              e.jsx(W, {
                x: 250,
                y: 70,
                scale: 1.65,
                children: e.jsx(ge, { prop: r }),
              }),
              s
                ? e.jsx(W, {
                    x: 472,
                    y: 70,
                    scale: 1.65,
                    children: e.jsx(je, { mishap: s }),
                  })
                : null,
            ],
          })
        : e.jsxs(e.Fragment, {
            children: [
              e.jsx(W, {
                x: s ? 30 : 90,
                y: 40,
                scale: 1.5,
                children: e.jsx(ge, { prop: r }),
              }),
              s
                ? e.jsx(W, {
                    x: 216,
                    y: 56,
                    scale: 1.5,
                    children: e.jsx(je, { mishap: s }),
                  })
                : null,
              e.jsx(W, {
                x: 100,
                y: 184,
                scale: 1.6,
                children: e.jsx(E, { creature: t.creature, mood: n }),
              }),
              e.jsx(ye, { x: 180, y: 360, name: t.name }),
            ],
          }),
    ],
  });
}
function O({ kind: t }) {
  return t === "compiler"
    ? e.jsxs("g", {
        "data-machine": "compiler",
        children: [
          e.jsx("path", { d: "M40 4 h80 l-12 26 h-56z", fill: N.pale }),
          [0, 1, 2].map((r) =>
            e.jsx(
              "path",
              {
                d: `M58 ${10 + r * 6} h44`,
                stroke: N.dark,
                strokeWidth: 2.5,
                strokeLinecap: "round",
              },
              r,
            ),
          ),
          e.jsx("rect", {
            x: 20,
            y: 30,
            width: 120,
            height: 62,
            rx: 10,
            fill: N.dark,
          }),
          e.jsx("rect", {
            x: 32,
            y: 42,
            width: 96,
            height: 20,
            rx: 4,
            fill: i.night,
          }),
          e.jsx("path", {
            d: "M40 52 h80",
            stroke: N.main,
            strokeWidth: 3,
            strokeDasharray: "10 6",
          }),
          e.jsx("rect", {
            x: 56,
            y: 92,
            width: 48,
            height: 22,
            rx: 3,
            fill: N.main,
          }),
          e.jsx("text", {
            x: 80,
            y: 108,
            textAnchor: "middle",
            fontFamily: _,
            fontSize: 12,
            fontWeight: 800,
            fill: i.night,
            children: ".exe",
          }),
        ],
      })
    : e.jsxs("g", {
        "data-machine": "interpreter",
        children: [
          e.jsx("rect", {
            x: 30,
            y: 22,
            width: 100,
            height: 72,
            rx: 18,
            fill: w.dark,
          }),
          e.jsx("path", { d: "M80 22 v-12", stroke: w.main, strokeWidth: 4 }),
          e.jsx("circle", { cx: 80, cy: 8, r: 6, fill: w.main }),
          e.jsx("rect", {
            x: 42,
            y: 36,
            width: 76,
            height: 18,
            rx: 9,
            fill: i.night,
          }),
          e.jsx("rect", {
            x: 52,
            y: 42,
            width: 34,
            height: 6,
            rx: 3,
            fill: w.main,
          }),
          e.jsx("circle", { cx: 60, cy: 72, r: 7, fill: w.pale }),
          e.jsx("circle", { cx: 100, cy: 72, r: 7, fill: w.pale }),
          e.jsx("circle", { cx: 60, cy: 72, r: 3, fill: i.night }),
          e.jsx("circle", { cx: 100, cy: 72, r: 3, fill: i.night }),
          e.jsx("rect", {
            x: 50,
            y: 94,
            width: 60,
            height: 18,
            rx: 4,
            fill: i.edge,
          }),
        ],
      });
}
function Ze() {
  return e.jsxs("g", {
    "data-chip": !0,
    children: [
      e.jsx("rect", {
        x: 44,
        y: 24,
        width: 72,
        height: 72,
        rx: 8,
        fill: P.dark,
      }),
      e.jsx("rect", {
        x: 60,
        y: 40,
        width: 40,
        height: 40,
        rx: 4,
        fill: P.pale,
      }),
      e.jsx("path", {
        d: "M58 24 v-10 M80 24 v-10 M102 24 v-10 M58 96 v10 M80 96 v10 M102 96 v10 M44 46 h-10 M44 74 h-10 M116 46 h10 M116 74 h10",
        stroke: P.main,
        strokeWidth: 4,
        strokeLinecap: "round",
      }),
      e.jsx("text", {
        x: 80,
        y: 66,
        textAnchor: "middle",
        fontFamily: _,
        fontSize: 12,
        fontWeight: 800,
        fill: P.dark,
        children: "CPU",
      }),
    ],
  });
}
function be({ layout: t }) {
  const r = t === "wide",
    s = r ? 1600 : 900,
    a = r ? 900 : 1600,
    o = r ? 650 : 1180;
  return e.jsxs("svg", {
    viewBox: `0 0 ${s} ${a}`,
    className: `game-landing-art ${r ? "game-landing-landscape" : "game-landing-portrait"}`,
    preserveAspectRatio: "xMidYMid slice",
    "aria-hidden": "true",
    "data-tl-landing": t,
    children: [
      e.jsx("rect", { width: s, height: a, fill: i.wall }),
      [...Array(12).keys()].map((n) =>
        e.jsx(
          "rect",
          {
            x: (n * 137) % s,
            y: (n * 83) % (o - 120),
            width: r ? 90 : 70,
            height: 4,
            rx: 2,
            fill: i.panel,
          },
          n,
        ),
      ),
      e.jsx("rect", { y: o, width: s, height: a - o, fill: i.deep }),
      e.jsx("path", { d: `M0 ${o} H${s}`, stroke: i.edge, strokeWidth: 8 }),
      e.jsx("text", {
        x: s / 2,
        y: r ? 150 : 260,
        textAnchor: "middle",
        fontFamily: z,
        fontSize: r ? 112 : 84,
        fontWeight: 800,
        fill: i.paper,
        children: "Translator Lab",
      }),
      e.jsx("text", {
        x: s / 2,
        y: r ? 214 : 340,
        textAnchor: "middle",
        fontFamily: _,
        fontSize: 34,
        fill: i.soft,
        children: "source code → machine code",
      }),
      r
        ? e.jsxs(e.Fragment, {
            children: [
              e.jsx(W, {
                x: 140,
                y: 300,
                scale: 2.6,
                children: e.jsx(O, { kind: "compiler" }),
              }),
              e.jsx(W, {
                x: 1040,
                y: 300,
                scale: 2.6,
                children: e.jsx(O, { kind: "interpreter" }),
              }),
              e.jsx(W, {
                x: 560,
                y: 400,
                scale: 2.2,
                children: e.jsx(E, { creature: "owl", mood: "happy" }),
              }),
              e.jsx(W, {
                x: 820,
                y: 400,
                scale: 2.2,
                children: e.jsx(E, { creature: "frog", mood: "happy" }),
              }),
              e.jsx("text", {
                x: 348,
                y: 290,
                textAnchor: "middle",
                fontFamily: z,
                fontSize: 40,
                fontWeight: 800,
                fill: N.main,
                children: "Compiler",
              }),
              e.jsx("text", {
                x: 1248,
                y: 290,
                textAnchor: "middle",
                fontFamily: z,
                fontSize: 40,
                fontWeight: 800,
                fill: w.main,
                children: "Interpreter",
              }),
            ],
          })
        : e.jsxs(e.Fragment, {
            children: [
              e.jsx(W, {
                x: 40,
                y: 460,
                scale: 2.4,
                children: e.jsx(O, { kind: "compiler" }),
              }),
              e.jsx(W, {
                x: 476,
                y: 460,
                scale: 2.4,
                children: e.jsx(O, { kind: "interpreter" }),
              }),
              e.jsx("text", {
                x: 232,
                y: 440,
                textAnchor: "middle",
                fontFamily: z,
                fontSize: 44,
                fontWeight: 800,
                fill: N.main,
                children: "Compiler",
              }),
              e.jsx("text", {
                x: 668,
                y: 440,
                textAnchor: "middle",
                fontFamily: z,
                fontSize: 44,
                fontWeight: 800,
                fill: w.main,
                children: "Interpreter",
              }),
              e.jsx(W, {
                x: 170,
                y: 860,
                scale: 2.4,
                children: e.jsx(E, { creature: "owl", mood: "happy" }),
              }),
              e.jsx(W, {
                x: 490,
                y: 860,
                scale: 2.4,
                children: e.jsx(E, { creature: "frog", mood: "happy" }),
              }),
            ],
          }),
    ],
  });
}
const ke =
    "J27702_Computational_thinking_algorithms_and_programming_June_2022 (3).json",
  we =
    "J27702_Computational_thinking_algorithms_and_programming_June_2023 (1).json",
  B =
    "J27702_Computational_thinking_algorithms_and_programming_June_2024 (3).json",
  Xe =
    "J27702_Computational_thinking_algorithms_and_programming_June_2026.json",
  ee =
    "J27702_Computational_thinking_algorithms_and_programming_Practice_2023 (2).json",
  ve = "paper-2-specimen.json",
  et = {
    "j24-7b-exe": {
      id: "j24-7b-exe",
      source: "June 2024 Q7b",
      file: B,
      questionId: "7(b)",
      credit: "A compiler produces an executable file.",
      rejected:
        "“It translates all the code in one go.” That says how it translates, not a benefit.",
      schemeWords: ["executable", "Descriptions of how a compiler translates"],
    },
    "j24-7b-no-translator": {
      id: "j24-7b-no-translator",
      source: "June 2024 Q7b",
      file: B,
      questionId: "7(b)",
      credit: "End users do not need a translator to run the executable.",
      rejected:
        "“It translates all the code in one go.” That says how it translates, not a benefit.",
      schemeWords: [
        "do not need a translator",
        "Descriptions of how a compiler translates",
      ],
    },
    "j24-7b-once": {
      id: "j24-7b-once",
      source: "June 2024 Q7b",
      file: B,
      questionId: "7(b)",
      credit:
        "It can be run again and again without translating it again: it only translates once.",
      rejected: "“It is faster.” Faster on its own is too vague.",
      schemeWords: ["without re-translating", "Faster / quicker"],
    },
    "j24-7b-source": {
      id: "j24-7b-source",
      source: "June 2024 Q7b",
      file: B,
      questionId: "7(b)",
      credit: "End users get no source code, so they cannot copy or change it.",
      rejected:
        "“No access to the source code”, unless it says the end user has none.",
      schemeWords: [
        "no access to source code",
        "unless clearly talking about the end user",
      ],
    },
    "j24-7a-low": {
      id: "j24-7a-low",
      source: "June 2024 Q7a",
      file: B,
      questionId: "7(a)",
      credit:
        "Low-level code gives direct control of the hardware and can be optimised to use less memory.",
      rejected:
        "“It is more efficient.” More efficient on its own is too vague.",
      schemeWords: [
        "Direct control of hardware",
        "optimised",
        "More efficient",
      ],
    },
    "j24-7a-machine-code": {
      id: "j24-7a-machine-code",
      source: "June 2024 Q7a",
      file: B,
      questionId: "7(a)",
      credit:
        "Machine code does not need to be translated: the processor runs it as it is.",
      schemeWords: ["does not need to be translated"],
    },
    "spec-5b-errors": {
      id: "spec-5b-errors",
      source: "Specimen Q5b",
      file: ve,
      questionId: "5(b)",
      credit:
        "An interpreter stops when it finds an error; a compiler reports all the errors at the end.",
      schemeWords: [
        "stops when it finds an error",
        "reports errors at the end",
      ],
    },
    "spec-5a-machine-code": {
      id: "spec-5a-machine-code",
      source: "Specimen Q5a",
      file: ve,
      questionId: "5(a)",
      credit:
        "The processor can only run machine code, so other code must be translated into machine code.",
      schemeWords: ["machine code"],
    },
    "j22-4b-debug": {
      id: "j22-4b-debug",
      source: "June 2022 Q4b",
      file: ke,
      questionId: "4(b)(ii)",
      credit:
        "An interpreter stops when an error is found, so it helps when debugging. Compiled code will not run until there are no errors.",
      schemeWords: ["stops when an error is found", "no errors", "debugging"],
    },
    "j22-4b-exe": {
      id: "j22-4b-exe",
      source: "June 2022 Q4b",
      file: ke,
      questionId: "4(b)(ii)",
      credit:
        "The executable file a compiler produces can be run without the compiler.",
      schemeWords: ["executable", "without the compiler"],
    },
    "p23-5b-every-run": {
      id: "p23-5b-every-run",
      source: "2023 Practice Q5b",
      file: ee,
      questionId: "5(b)",
      credit: "Interpreter: the program is translated every time it is run.",
      schemeWords: ["translated every time it is run", "Interpreter"],
    },
    "p23-5b-exe": {
      id: "p23-5b-exe",
      source: "2023 Practice Q5b",
      file: ee,
      questionId: "5(b)",
      credit:
        "Compiler: produces an executable file. Both: translate high-level code to low-level instructions.",
      schemeWords: ["Produces an executable file", "Both"],
    },
    "p23-5a-high": {
      id: "p23-5a-high",
      source: "2023 Practice Q5a",
      file: ee,
      questionId: "5(a)",
      credit:
        "High-level code uses English-like keywords, so it is easier and quicker to write and read.",
      schemeWords: ["closer to English", "quicker"],
    },
    "j23-1a-portable": {
      id: "j23-1a-portable",
      source: "June 2023 Q1a",
      file: we,
      questionId: "1(a)",
      credit:
        "High-level code is portable: the same code can be used on computers with different hardware.",
      schemeWords: ["different hardware = High-level"],
    },
    "j23-1a-memory": {
      id: "j23-1a-memory",
      source: "June 2023 Q1a",
      file: we,
      questionId: "1(a)",
      credit: "Low-level code lets the programmer manipulate memory directly.",
      schemeWords: ["manipulate memory = Low-level"],
    },
    "j26-2b-translated": {
      id: "j26-2b-translated",
      source: "June 2026 Q2b",
      file: Xe,
      questionId: "2(b)(i)",
      credit: "High-level code is translated into machine code before it runs.",
      rejected: "“It must be translated”, without saying into machine code.",
      schemeWords: ["'Must be translated' is not enough", "machine code"],
    },
  },
  ne = { name: "Moss", creature: "frog" },
  Pe = { name: "Pip", creature: "hedgehog" },
  Ee = { name: "Bramble", creature: "badger" },
  _e = { name: "Fern", creature: "fox" },
  oe = { name: "Juniper", creature: "owl" },
  le = { name: "Rowan", creature: "rabbit" },
  ce = { name: "Ash", creature: "badger" },
  de = { name: "Basil", creature: "rabbit" },
  he = { name: "Wren", creature: "owl" },
  G = { name: "Clover", creature: "fox" },
  De = { name: "Hazel", creature: "hedgehog" },
  pe = { name: "Sorrel", creature: "frog" },
  tt = [
    {
      id: "quiz-time",
      developer: Pe,
      title: "Quiz time",
      lines: [
        'print("Quiz time")',
        "score = 0",
        "if score == 0 then",
        '  print("Good luck)',
        "endif",
        "print(score",
      ],
      errors: [4, 6],
      fixes: { 4: 'missing closing "', 6: "missing )" },
    },
    {
      id: "rocket",
      developer: le,
      title: "Rocket check",
      lines: [
        'print("Rocket check")',
        "fuel = 80",
        'print("Fuel " + str(fuel))',
        "if fuel > 50 then",
        '  print("Go for launch"',
        "endif",
        'pirnt("Lift off")',
      ],
      errors: [5, 7],
      fixes: { 5: "missing )", 7: "print is misspelt" },
    },
    {
      id: "basket",
      developer: ne,
      title: "Shop basket",
      lines: [
        "price = 4",
        "qty = 3",
        'print("Basket")',
        "total = price * qty",
        'print("Total " + str(total)',
        'print("Thank you)',
      ],
      errors: [5, 6],
      fixes: { 5: "missing )", 6: 'missing closing "' },
    },
    {
      id: "forecast",
      developer: he,
      title: "Forecast",
      lines: [
        "temp = 22",
        'print("Forecast")',
        "if temp > 20 then",
        '  print("Sunny")',
        "endif",
        'prnit("Bye")',
        'print("Rain at 5"',
      ],
      errors: [6, 7],
      fixes: { 6: "print is misspelt", 7: "missing )" },
    },
    {
      id: "pet",
      developer: De,
      title: "Pet feeder",
      lines: [
        'name = "Biscuit"',
        'pritn("Pet " + name)',
        "food = 3",
        'print("Meals " + str(food))',
        "food = food -",
        "print(food)",
      ],
      errors: [2, 5],
      fixes: { 2: "print is misspelt", 5: "nothing after -" },
    },
    {
      id: "level-up",
      developer: G,
      title: "Level up",
      lines: [
        "xp = 90",
        'print("XP " + str(xp))',
        "xp = xp + 20",
        "if xp >= 100",
        '  print("Level up!)',
        "endif",
        'print("Next level"',
      ],
      errors: [4, 5, 7],
      fixes: { 4: "missing then", 5: 'missing closing "', 7: "missing )" },
    },
  ];
function Fe(t) {
  return Math.min(...t.errors);
}
function rt(t) {
  const r = Fe(t),
    s = new Map(),
    a = [];
  let o = !1;
  for (let n = 0; n < r - 1; n += 1) {
    const l = t.lines[n].trim();
    if (l === "endif") {
      ((o = !1), a.push({ line: n + 1 }));
      continue;
    }
    if (o) continue;
    a.push({ line: n + 1 });
    const c = /^if (\w+) (==|>|>=|<) (\d+) then$/.exec(l);
    if (c) {
      const j = Number(s.get(c[1])),
        d = Number(c[3]);
      o = !(c[2] === "=="
        ? j === d
        : c[2] === ">"
          ? j > d
          : c[2] === ">="
            ? j >= d
            : j < d);
      continue;
    }
    const p = /^(\w+) = (.+)$/.exec(l);
    if (p) {
      s.set(p[1], Ne(p[2], s));
      continue;
    }
    const u = /^print\((.+)\)$/.exec(l);
    u && (a[a.length - 1] = { line: n + 1, output: String(Ne(u[1], s)) });
  }
  return a;
}
function Ne(t, r) {
  const s = /^"([^"]*)"$/.exec(t);
  if (s) return s[1];
  if (/^\d+$/.test(t)) return Number(t);
  if (r.has(t)) return r.get(t);
  const a = /^"([^"]*)" \+ (?:str\((\w+)\)|(\w+))$/.exec(t);
  if (a) return `${a[1]}${String(r.get(a[2] ?? a[3]))}`;
  const o = /^(\w+) ([+*-]) (\w+)$/.exec(t);
  if (o) {
    const n = Number(r.get(o[1]) ?? o[1]),
      l = Number(r.get(o[3]) ?? o[3]);
    return o[2] === "+" ? n + l : o[2] === "*" ? n * l : n - l;
  }
  throw new Error(`Translator Lab cannot evaluate ${t}`);
}
const st = [
    {
      id: "racing-game",
      developer: ne,
      prop: "game-box",
      story:
        "Moss has finished Turbo Toads, a racing game to sell online. Buyers should be able to play straight away, and nobody should be able to copy the code.",
      right: "compiler",
      outcomes: {
        compiler: {
          title: "Sold, and safe",
          text: "Moss sells the executable file. It runs on buyers’ computers with no translator installed, and they never see the source code.",
          mishap: "ok",
          mark: "j24-7b-source",
        },
        interpreter: {
          title: "Copied in a week",
          text: "Every buyer gets the source code and has to install an interpreter before the game will run. A rival copies the track code and sells a clone.",
          mishap: "copied",
          mark: "j24-7b-source",
        },
      },
    },
    {
      id: "half-quiz",
      developer: Pe,
      prop: "quiz",
      story:
        "Pip is halfway through writing a quiz program. The second half is unfinished and full of mistakes, but Pip wants to try the first questions now.",
      right: "interpreter",
      outcomes: {
        interpreter: {
          title: "First questions work",
          text: "The interpreter runs the first questions line by line, then stops at the first error and shows its line. Pip fixes it and carries on.",
          mishap: "ok",
          mark: "j22-4b-debug",
        },
        compiler: {
          title: "Nothing runs",
          text: "The compiler lists every error in the unfinished half and makes no executable. Pip can’t try a single question until the whole program is fixed.",
          mishap: "nothing-runs",
          mark: "j22-4b-debug",
        },
      },
    },
    {
      id: "cover-timetable",
      developer: Ee,
      prop: "timetable",
      story:
        "Bramble, the school technician, edits the cover timetable program every morning, then runs it once before registration.",
      right: "interpreter",
      outcomes: {
        interpreter: {
          title: "Today’s rooms, every day",
          text: "Bramble saves the edit and runs it. The interpreter translates the code every time it runs, so this morning’s changes are always in.",
          mishap: "ok",
          mark: "p23-5b-every-run",
        },
        compiler: {
          title: "Yesterday’s timetable",
          text: "Every edit needs compiling again before it counts. One rushed morning Bramble runs yesterday’s executable, and every cover lesson is in the wrong room.",
          mishap: "stale",
          mark: "p23-5b-every-run",
        },
      },
    },
    {
      id: "ticket-barrier",
      developer: _e,
      prop: "barrier",
      story:
        "Fern writes the program for the ticket barriers at a busy station. It runs every time someone taps a card: 50,000 times a day.",
      right: "compiler",
      outcomes: {
        compiler: {
          title: "Gates open first time",
          text: "Fern compiles it once. The barriers run the executable on every tap without translating it again, and the gates keep up.",
          mishap: "ok",
          mark: "j24-7b-once",
        },
        interpreter: {
          title: "Queue to the platform",
          text: "The interpreter translates the program again on every tap, 50,000 times a day. The gates lag and the queue backs up onto the platform.",
          mishap: "queue",
          mark: "j24-7b-once",
        },
      },
    },
    {
      id: "drawing-app",
      developer: oe,
      prop: "laptops",
      story:
        "Juniper is sending a drawing app to 300 schools. Their computers have no translator installed, and the schools won’t install one.",
      right: "compiler",
      outcomes: {
        compiler: {
          title: "Runs in 300 schools",
          text: "Juniper sends the executable file. It runs on every school computer without a compiler or an interpreter.",
          mishap: "ok",
          mark: "j24-7b-no-translator",
        },
        interpreter: {
          title: "Won’t open anywhere",
          text: "The app arrives as source code. With no interpreter on the school computers, it won’t run in any of the 300 schools.",
          mishap: "no-translator",
          mark: "j24-7b-no-translator",
        },
      },
    },
    {
      id: "robot-arm",
      developer: le,
      prop: "robot-arm",
      story:
        "Rowan is programming a robot arm and wants to test the first three moves while the rest of the program is still unfinished.",
      right: "interpreter",
      outcomes: {
        interpreter: {
          title: "Three moves, then a stop",
          text: "The interpreter runs the first moves one line at a time, then stops at the unfinished part and shows the line.",
          mishap: "ok",
          mark: "spec-5b-errors",
        },
        compiler: {
          title: "The arm never moves",
          text: "The compiler reports the errors in the unfinished lines at the end and makes no executable. The arm doesn’t move once.",
          mishap: "nothing-runs",
          mark: "spec-5b-errors",
        },
      },
    },
    {
      id: "fraud-check",
      developer: ce,
      prop: "bank",
      story:
        "Ash’s team wrote a fraud check for 2,000 bank branch computers. How it spots fraud must stay secret, or criminals will work round it.",
      right: "compiler",
      outcomes: {
        compiler: {
          title: "The method stays secret",
          text: "Each branch gets the executable file only. Staff can run it, but nobody at a branch can read or change the code.",
          mishap: "ok",
          mark: "j24-7b-source",
        },
        interpreter: {
          title: "The secret leaks",
          text: "To run it, every branch needs the source code. A copy leaks, criminals read the checks, and the fraud gets through.",
          mishap: "copied",
          mark: "j24-7b-source",
        },
      },
    },
    {
      id: "console-game",
      developer: de,
      prop: "console",
      story:
        "Basil’s studio is releasing a fast platform game on a games console. Players will run it thousands of times.",
      right: "compiler",
      outcomes: {
        compiler: {
          title: "Smooth every time",
          text: "The console runs the compiled executable. It was translated once, so no play ever waits for translating.",
          mishap: "ok",
          mark: "j24-7b-once",
        },
        interpreter: {
          title: "The levels stutter",
          text: "The interpreter translates the code again on every play, as it runs. It runs slower than a compiled version, and the jumps stutter.",
          mishap: "stutter",
          mark: "j24-7b-once",
        },
      },
    },
    {
      id: "weather-tweaks",
      developer: he,
      prop: "weather",
      story:
        "Wren is trying out ideas for a weather station program: change a line, run it, check the reading, change another. Some lines have mistakes.",
      right: "interpreter",
      outcomes: {
        interpreter: {
          title: "Straight to the problem",
          text: "The interpreter runs the changed code line by line. When a line is wrong it stops right there and shows which line, so Wren fixes it fast.",
          mishap: "ok",
          mark: "j22-4b-debug",
        },
        compiler: {
          title: "No reading at all",
          text: "One mistake anywhere and the compiler makes no executable, so nothing runs. Wren gets no reading until every error is fixed.",
          mishap: "nothing-runs",
          mark: "j22-4b-debug",
        },
      },
    },
    {
      id: "coding-club",
      developer: G,
      prop: "club",
      story:
        "Clover’s coding club writes its first program together on the board, adding one line at a time and running it after each one.",
      right: "interpreter",
      outcomes: {
        interpreter: {
          title: "Each line, as it lands",
          text: "The interpreter runs the lines as they are added. When one is wrong it stops on that line, so the club knows where to look.",
          mishap: "ok",
          mark: "spec-5b-errors",
        },
        compiler: {
          title: "Stuck on the last line",
          text: "The newest line has a mistake, so the compiler makes no executable and none of the working lines run either.",
          mishap: "nothing-runs",
          mark: "spec-5b-errors",
        },
      },
    },
  ],
  te = [
    { id: "executable", label: "Executable file" },
    { id: "source", label: "Source code" },
    { id: "interpreter", label: "Interpreter" },
    { id: "compiler", label: "Compiler" },
  ],
  it = [
    {
      id: "turbo-toads",
      developer: ne,
      prop: "game-box",
      product: "Turbo Toads",
      customer: "players at home",
      translator: "compiler",
    },
    {
      id: "pond-log",
      developer: De,
      prop: "weather",
      product: "the pond sensor log",
      customer: "a partner school",
      translator: "interpreter",
    },
    {
      id: "fraud-tool",
      developer: ce,
      prop: "bank",
      product: "the fraud check",
      customer: "the bank branches",
      translator: "compiler",
    },
    {
      id: "club-quiz",
      developer: G,
      prop: "club",
      product: "the club quiz",
      customer: "a friend’s coding club",
      translator: "interpreter",
    },
    {
      id: "platformer",
      developer: de,
      prop: "console",
      product: "the platform game",
      customer: "console players",
      translator: "compiler",
    },
    {
      id: "reminder",
      developer: pe,
      prop: "quiz",
      product: "the homework reminder",
      customer: "the Year 9 tutors",
      translator: "interpreter",
    },
  ];
function Me(t, r) {
  const s = (a) => r.includes(a);
  return t.translator === "compiler"
    ? s("executable")
      ? s("source")
        ? {
            right: !1,
            title: "The code got out",
            text: `The source code went in the box, so ${t.customer} can read, copy and change it. The executable was all they needed.`,
            mishap: "copied",
            mark: "j24-7b-source",
          }
        : s("compiler") || s("interpreter")
          ? {
              right: !1,
              title: "A translator nobody uses",
              text: "It runs, but the translator was wasted space: the executable runs without a compiler or an interpreter.",
              mishap: "extra",
              mark: "j22-4b-exe",
            }
          : {
              right: !0,
              title: "Runs, and the code stays home",
              text: `${re(t.customer)} run the executable with no translator installed, and they never see the source code.`,
              mishap: "ok",
              mark: "j24-7b-no-translator",
            }
      : {
          right: !1,
          title: "Nothing ready to run",
          text: `There’s no executable file in the box, so ${t.customer} have nothing ready to run.`,
          mishap: "nothing-runs",
          mark: "j24-7b-exe",
        }
    : s("executable")
      ? {
          right: !1,
          title: "An empty slot",
          text: "An interpreter never makes an executable file: only a compiler does. The slot in the box is empty.",
          mishap: "no-exe",
          mark: "p23-5b-exe",
        }
      : s("source")
        ? s("interpreter")
          ? s("compiler")
            ? {
                right: !1,
                title: "A translator nobody uses",
                text: "It runs, but the compiler was wasted space: the interpreter does the translating on their machine.",
                mishap: "extra",
                mark: "p23-5b-every-run",
              }
            : {
                right: !0,
                title: "Runs, with strings attached",
                text: `${re(t.customer)} can run it, but only with the interpreter installed, and they get the source code too. That’s the price of interpreting.`,
                mishap: "ok",
                mark: "p23-5b-every-run",
              }
          : {
              right: !1,
              title: "Won’t open",
              text: `${re(t.customer)} get the source code but no interpreter, so ${t.product} can’t be translated or run.`,
              mishap: "no-translator",
              mark: "p23-5b-every-run",
            }
        : {
            right: !1,
            title: "Nothing to run",
            text: `With no source code in the box, the interpreter has nothing to translate, so ${t.customer} can’t run ${t.product}.`,
            mishap: "nothing-runs",
            mark: "p23-5b-every-run",
          };
}
function re(t) {
  return t.charAt(0).toUpperCase() + t.slice(1);
}
const at = [
  {
    id: "late-books",
    developer: oe,
    program: "the library’s late-books report",
    runLabel: "Day",
    translator: "compiler",
    runs: 5,
  },
  {
    id: "register",
    developer: Ee,
    program: "the lunch club register",
    runLabel: "Day",
    translator: "interpreter",
    runs: 5,
  },
  {
    id: "sign-up",
    developer: G,
    program: "the club sign-up checker",
    runLabel: "Week",
    translator: "compiler",
    runs: 4,
    editBefore: 3,
  },
  {
    id: "weather-log",
    developer: he,
    program: "the weather log",
    runLabel: "Day",
    translator: "interpreter",
    runs: 6,
    editBefore: 4,
  },
  {
    id: "high-scores",
    developer: de,
    program: "the high-score table",
    runLabel: "Game",
    translator: "compiler",
    runs: 3,
    editBefore: 2,
  },
  {
    id: "menu",
    developer: pe,
    program: "the canteen menu printer",
    runLabel: "Day",
    translator: "interpreter",
    runs: 7,
  },
];
function Be(t) {
  return t.translator === "interpreter" ? t.runs : t.editBefore ? 2 : 1;
}
function Le(t, r) {
  return t.translator === "interpreter" ? !0 : r === 1 || r === t.editBefore;
}
function nt(t, r) {
  const s = Be(t),
    a = r === s;
  if (t.translator === "compiler") {
    const o = t.editBefore
      ? `Compiled once, then once more after the edit before ${t.runLabel.toLowerCase()} ${t.editBefore}. Every other run uses the same executable without translating again.`
      : `Compiled once before ${t.runLabel.toLowerCase()} 1. Every run after that uses the same executable without translating again.`;
    return {
      right: a,
      title: a
        ? `${s} translation${s === 1 ? "" : "s"}, ${t.runs} runs`
        : `It was ${s}, not ${r}`,
      text: o,
      mishap: a ? "ok" : "queue",
      mark: "j24-7b-once",
    };
  }
  return {
    right: a,
    title: a ? `${s} runs, ${s} translations` : `It was ${s}, not ${r}`,
    text: `An interpreter makes no executable to keep, so the code is translated again on every run: ${t.runs} runs, ${t.runs} translations${t.editBefore ? ", edit or no edit" : ""}.`,
    mishap: a ? "ok" : "queue",
    mark: "p23-5b-every-run",
  };
}
const Se = { high: "translate", assembly: "translate", machine: "none" },
  ot = [
    { id: "translate", label: "Needs translating" },
    { id: "none", label: "Runs as it is" },
  ],
  lt = [
    {
      id: "washer",
      developer: ce,
      prop: "washer",
      story:
        "Ash is writing the motor controller for a washing machine. Its chip has 2 KB of memory, and the code must switch the motor on and off directly.",
      right: "low",
      outcomes: {
        low: {
          title: "Spins on cue",
          text: "The low-level code controls the motor hardware directly, and it is small enough to fit the 2 KB chip.",
          mishap: "ok",
          mark: "j24-7a-low",
        },
        high: {
          title: "Doesn’t fit",
          text: "High-level code gives Ash no direct control of the motor hardware, and translated it is too big for the 2 KB chip.",
          mishap: "too-big",
          mark: "j24-7a-low",
        },
      },
      code: {
        high: ['motor = "on"'],
        assembly: ["LDA on", "STA motor"],
        machine: ["0001 1110", "0010 1111"],
      },
    },
    {
      id: "homework-app",
      developer: oe,
      prop: "devices",
      story:
        "Juniper’s homework app must run on phones and laptops, and they have different processors.",
      right: "high",
      outcomes: {
        high: {
          title: "One program, every device",
          text: "High-level code is portable: the same program is translated for the phone processor and for the laptop one.",
          mishap: "ok",
          mark: "j23-1a-portable",
        },
        low: {
          title: "Written twice",
          text: "Assembly is written for one type of processor. It runs on the laptops, but the phone version has to be written again from scratch.",
          mishap: "rewrite",
          mark: "j23-1a-portable",
        },
      },
      code: {
        high: ['print("Due Friday")'],
        assembly: ["LDA msg", "OUT"],
        machine: ["0001 0101", "1001 0000"],
      },
    },
    {
      id: "club-booking",
      developer: pe,
      prop: "booking",
      story:
        "Sorrel’s team of new programmers has three weeks to build a booking system for after-school clubs.",
      right: "high",
      outcomes: {
        high: {
          title: "Open for bookings",
          text: "High-level code uses English-like keywords such as if and print, so the team writes it quickly and can read each other’s code.",
          mishap: "ok",
          mark: "p23-5a-high",
        },
        low: {
          title: "Three weeks, no system",
          text: "Every assembly line is a single processor instruction. The team is still writing the login screen when the deadline passes.",
          mishap: "slow-team",
          mark: "p23-5a-high",
        },
      },
      code: {
        high: ["if spaces > 0 then"],
        assembly: ["LDA spaces", "BRZ full"],
        machine: ["0001 0110", "0111 1010"],
      },
    },
    {
      id: "graphics-driver",
      developer: _e,
      prop: "chip",
      story:
        "Fern is writing a driver for one graphics chip. It will only ever run on that chip, and every instruction has to be as fast as possible.",
      right: "low",
      outcomes: {
        low: {
          title: "Every frame on time",
          text: "Written for this one chip, the low-level code is optimised instruction by instruction and executes fast.",
          mishap: "ok",
          mark: "j24-7a-low",
        },
        high: {
          title: "Dropped frames",
          text: "In high-level code Fern can’t choose each processor instruction for this one chip, so the driver can’t be hand-optimised and frames drop.",
          mishap: "stutter",
          mark: "j24-7a-low",
        },
      },
      code: {
        high: ["x = x + 1"],
        assembly: ["LDA x", "ADD one", "STA x"],
        machine: ["0001 0011", "0011 0100", "0010 0011"],
      },
    },
    {
      id: "heart-sensor",
      developer: le,
      prop: "watch",
      story:
        "Rowan’s smartwatch reads the heart-rate sensor from one exact memory address, many times a second.",
      right: "low",
      outcomes: {
        low: {
          title: "Every beat counted",
          text: "Low-level code manipulates memory directly, so it reads the sensor’s address itself.",
          mishap: "ok",
          mark: "j23-1a-memory",
        },
        high: {
          title: "Missed beats",
          text: "High-level code doesn’t let Rowan manipulate that memory address directly, so the readings arrive late and beats are missed.",
          mishap: "stutter",
          mark: "j23-1a-memory",
        },
      },
      code: {
        high: ["bpm = sensor"],
        assembly: ["LDA 200", "STA bpm"],
        machine: ["0001 1100", "0010 0101"],
      },
    },
    {
      id: "web-quiz",
      developer: G,
      prop: "tablet",
      story:
        "Clover’s revision quiz must work on the school’s tablets, laptops and phones, whatever processor each one has.",
      right: "high",
      outcomes: {
        high: {
          title: "Works on all of them",
          text: "High-level code is portable, so the same quiz runs on tablets, laptops and phones, each with its own translator.",
          mishap: "ok",
          mark: "j23-1a-portable",
        },
        low: {
          title: "Tablets only",
          text: "Low-level code is specific to one type of processor. It runs on the tablets and nowhere else.",
          mishap: "rewrite",
          mark: "j23-1a-portable",
        },
      },
      code: {
        high: ["score = score + 1"],
        assembly: ["LDA score", "ADD one", "STA score"],
        machine: ["0001 0001", "0011 0010", "0010 0001"],
      },
    },
  ],
  ct = ["spec-5a-machine-code", "j24-7a-machine-code"],
  ue = { errors: 2, pick: 1, ship: 1, rerun: 1, levels: 2 };
function U(t, r) {
  return t[Math.min(t.length - 1, Math.floor(r() * t.length))];
}
function Oe(t, r) {
  const s = [...t];
  for (let a = s.length - 1; a > 0; a -= 1) {
    const o = Math.min(a, Math.floor(r() * (a + 1)));
    [s[a], s[o]] = [s[o], s[a]];
  }
  return s;
}
function We(t) {
  const [r, s] = Oe(st, t);
  return [
    { kind: "errors", program: U(tt, t) },
    { kind: "pick", scenario: r },
    { kind: "ship", job: U(it, t) },
    { kind: "rerun", job: U(at, t) },
    { kind: "pick", scenario: s },
    { kind: "levels", job: U(lt, t) },
  ];
}
function dt(t) {
  return t.reduce((r, s) => r + ue[s.kind], 0);
}
function ht(t, r) {
  const s = r ? t / r : 0;
  return s >= 1
    ? "Lead engineer"
    : s >= 0.75
      ? "Senior developer"
      : s >= 0.5
        ? "Developer"
        : s >= 0.25
          ? "Junior developer"
          : "Intern";
}
const $e = { compiler: "Compiler", interpreter: "Interpreter" },
  pt = { high: "High-level", low: "Low-level" },
  ut = 8;
function V(t) {
  const r = f.useRef(null);
  function s(l, c) {
    if (c.button !== 0 && c.pointerType === "mouse") return;
    const p = c.currentTarget;
    ((r.current = { id: l, x: c.clientX, y: c.clientY, el: p, moved: !1 }),
      p.setPointerCapture?.(c.pointerId));
  }
  function a(l) {
    const c = r.current;
    if (!c) return;
    const p = l.clientX - c.x,
      u = l.clientY - c.y;
    (!c.moved && Math.hypot(p, u) < ut) ||
      ((c.moved = !0),
      (c.el.style.translate = `${p}px ${u}px`),
      (c.el.dataset.dragging = "true"));
  }
  function o(l) {
    const c = r.current;
    if (
      ((r.current = null),
      !c ||
        ((c.el.style.translate = ""), delete c.el.dataset.dragging, !c.moved))
    )
      return;
    c.el.dataset.dropped = "true";
    const u = document
      .elementFromPoint?.(l.clientX, l.clientY)
      ?.closest("[data-tl-zone]")?.dataset.tlZone;
    u && t(c.id, u);
  }
  function n(l) {
    const c = l.currentTarget;
    c.dataset.dropped &&
      (delete c.dataset.dropped, l.preventDefault(), l.stopPropagation());
  }
  return (l) => ({
    onPointerDown: (c) => s(l, c),
    onPointerMove: a,
    onPointerUp: o,
    onPointerCancel: o,
    onClickCapture: n,
    "data-tl-drag": l,
  });
}
function J({ id: t }) {
  const r = et[t];
  return e.jsxs("aside", {
    className: "tl-markpoint",
    "data-tl-markpoint": t,
    children: [
      e.jsx("p", { className: "tl-markpoint-source", children: r.source }),
      e.jsxs("p", {
        className: "tl-markpoint-credit",
        children: [
          e.jsx(H, { "aria-hidden": "true", className: "tl-markpoint-icon" }),
          e.jsx("span", { children: r.credit }),
        ],
      }),
      r.rejected
        ? e.jsxs("p", {
            className: "tl-markpoint-rejected",
            children: [
              e.jsx(ie, {
                "aria-hidden": "true",
                className: "tl-markpoint-icon",
              }),
              e.jsx("span", { children: r.rejected }),
            ],
          })
        : null,
    ],
  });
}
function K({ isLast: t, onNext: r }) {
  const s = f.useRef(null);
  return (
    f.useEffect(() => s.current?.focus({ preventScroll: !0 }), []),
    e.jsxs("button", {
      ref: s,
      type: "button",
      className: "tl-button tl-primary",
      onClick: r,
      "data-tl-next": !0,
      children: [
        t ? "End the shift" : "Next job",
        e.jsx(Ie, { "aria-hidden": "true", className: "h-4 w-4" }),
      ],
    })
  );
}
function me({
  developer: t,
  prop: r,
  outcome: s,
  right: a,
  children: o,
  footer: n,
}) {
  const l = qe();
  return e.jsxs("section", {
    className: "tl-outcome",
    "data-story-card": "outcome",
    "data-tl-outcome": a ? "right" : "wrong",
    "aria-live": "polite",
    children: [
      e.jsx("div", {
        className: "tl-photo",
        children: e.jsx(ze, {
          developer: t,
          prop: r,
          mishap: s.mishap,
          layout: l ? "tall" : "wide",
          label: `${t.name}: ${s.title}`,
        }),
      }),
      e.jsxs("div", {
        className: "tl-outcome-body",
        children: [
          e.jsxs("h3", {
            className: `tl-outcome-title ${a ? "tl-good" : "tl-bad"}`,
            children: [
              e.jsx("span", {
                className: "sr-only",
                children: a ? "Right. " : "Wrong. ",
              }),
              s.title,
            ],
          }),
          e.jsx("p", { className: "tl-text", children: s.text }),
          o,
          e.jsx(J, { id: s.mark }),
          n,
        ],
      }),
    ],
  });
}
function xe({ developer: t, prop: r, children: s }) {
  const a = qe();
  return e.jsxs("section", {
    className: "tl-story",
    "data-story-card": "event",
    children: [
      e.jsx("div", {
        className: "tl-photo",
        children: e.jsx(ze, {
          developer: t,
          prop: r,
          layout: a ? "tall" : "wide",
          label: `${t.name} at work`,
        }),
      }),
      e.jsx("div", { className: "tl-story-body", children: s }),
    ],
  });
}
function mt({ developer: t }) {
  return e.jsxs("svg", {
    viewBox: "0 0 100 100",
    className: "tl-avatar",
    "aria-hidden": "true",
    children: [
      e.jsx("circle", { cx: 50, cy: 50, r: 50, className: "tl-avatar-ring" }),
      e.jsx(E, { creature: t.creature }),
    ],
  });
}
function fe({ developer: t, children: r }) {
  return e.jsxs("div", {
    className: "tl-brief",
    "data-story-card": "brief",
    children: [
      e.jsx(mt, { developer: t }),
      e.jsxs("div", {
        className: "min-w-0 space-y-1",
        children: [
          e.jsx("p", { className: "tl-brief-name", children: t.name }),
          e.jsx("div", { className: "tl-text", children: r }),
        ],
      }),
    ],
  });
}
function Te({ kind: t, label: r, onPick: s, disabled: a, state: o }) {
  return e.jsxs("button", {
    type: "button",
    className: `tl-machine tl-machine-${t}`,
    "data-tl-zone": t,
    "data-state": o,
    onClick: s,
    disabled: a,
    children: [
      e.jsx("svg", {
        viewBox: "0 0 160 120",
        width: "100%",
        "aria-hidden": "true",
        children: e.jsx(O, { kind: t }),
      }),
      e.jsx("span", { className: "tl-machine-label", children: r }),
    ],
  });
}
function se(t, r, s, a) {
  const [o, n] = f.useState(0),
    l = f.useRef(a),
    c = f.useRef(!1);
  return (
    (l.current = a),
    f.useEffect(() => {
      if (!s) {
        c.current = !1;
        return;
      }
      if (r <= 0 || o >= t) {
        o < t ? n(t) : c.current || ((c.current = !0), l.current());
        return;
      }
      const p = window.setTimeout(() => n((u) => u + 1), r);
      return () => window.clearTimeout(p);
    }, [s, o, t, r]),
    o
  );
}
function xt({
  program: t,
  marks: r,
  cursor: s,
  selectable: a,
  selected: o,
  onToggle: n,
}) {
  return e.jsx("ol", {
    className: "tl-code",
    "aria-label": `${t.title} source code`,
    "data-tl-code": !0,
    children: t.lines.map((l, c) => {
      const p = c + 1,
        u = r[p],
        j = e.jsxs(e.Fragment, {
          children: [
            e.jsx("span", {
              className: "tl-code-no",
              "aria-hidden": "true",
              children: p,
            }),
            e.jsx("code", { className: "tl-code-text", children: l }),
          ],
        });
      return e.jsx(
        "li",
        {
          "data-line": p,
          "data-mark": u,
          "data-cursor": s === p ? "true" : void 0,
          children: a
            ? e.jsx("button", {
                type: "button",
                className: "tl-code-line",
                "aria-pressed": o.has(p),
                "aria-label": `Line ${p}: ${l}`,
                onClick: () => n(p),
                children: j,
              })
            : e.jsx("div", { className: "tl-code-line", children: j }),
        },
        p,
      );
    }),
  });
}
function ft({ lines: t, status: r, tone: s }) {
  return e.jsxs("div", {
    className: "tl-console",
    "data-tl-console": !0,
    children: [
      e.jsx("p", { className: "tl-console-head", children: "Output" }),
      t.map((a, o) =>
        e.jsx("p", { className: "tl-console-line", children: a }, o),
      ),
      r
        ? e.jsx("p", {
            className: `tl-console-status ${s === "bad" ? "tl-bad" : "tl-mute"}`,
            children: r,
          })
        : null,
    ],
  });
}
function Ae({ right: t, children: r }) {
  return e.jsxs("p", {
    className: `tl-verdict ${t ? "tl-good" : "tl-bad"}`,
    "data-tl-verdict": t ? "right" : "wrong",
    children: [
      t
        ? e.jsx(H, { "aria-hidden": "true", className: "tl-verdict-icon" })
        : e.jsx(ie, { "aria-hidden": "true", className: "tl-verdict-icon" }),
      e.jsx("span", {
        className: "sr-only",
        children: t ? "Right. " : "Wrong. ",
      }),
      e.jsx("span", { children: r }),
    ],
  });
}
function gt({ program: t, onResolved: r, onNext: s, isLast: a, stepMs: o }) {
  const [n, l] = f.useState("stop"),
    [c, p] = f.useState(null),
    [u, j] = f.useState(new Set()),
    d = Fe(t),
    x = f.useMemo(() => rt(t), [t]),
    g = f.useMemo(() => new Set(t.errors), [t]),
    S = c === d,
    b = u.size === g.size && [...u].every((y) => g.has(y)),
    v = se(x.length + 1, o, n === "interpreting", () => l("interpreted")),
    M = se(3, o, n === "compiling", () => {
      (l("done"), r((S ? 1 : 0) + (b ? 1 : 0)));
    }),
    L = {},
    $ = n !== "stop" && n !== "interpreting",
    I = n === "interpreting" ? x.slice(0, v) : $ ? x : [];
  for (const y of I) L[y.line] = "ran";
  if (
    (($ || (n === "interpreting" && v > x.length)) && (L[d] = "stopped"),
    n === "done")
  )
    for (const y of t.errors) L[y] = y === d ? "stopped" : "error";
  if (n === "report") for (const y of u) L[y] = "picked";
  const C = n === "interpreting" ? (v < x.length ? x[v]?.line : d) : void 0,
    Z = I.flatMap((y) => (y.output === void 0 ? [] : [y.output])),
    h = $ || (n === "interpreting" && v > x.length);
  function R(y) {
    if (n === "stop") {
      (p(y), l("interpreting"));
      return;
    }
    n === "report" &&
      j((Q) => {
        const Y = new Set(Q);
        return (Y.has(y) ? Y.delete(y) : Y.add(y), Y);
      });
  }
  const T = e.jsx(xt, {
    program: t,
    marks: L,
    cursor: C,
    selectable: n === "stop" || n === "report",
    selected: n === "report" ? u : new Set(),
    onToggle: R,
  });
  return e.jsxs("div", {
    className: "tl-round",
    "data-tl-round": "errors",
    "data-tl-program": t.id,
    "data-tl-stage": n,
    children: [
      e.jsx(fe, {
        developer: t.developer,
        children: e.jsxs("p", {
          children: [
            t.developer.name,
            "’s program ",
            e.jsx("strong", { children: t.title }),
            " has errors in it. Run it through both translators.",
          ],
        }),
      }),
      e.jsxs("div", {
        className: "tl-split",
        children: [
          e.jsx("div", { className: "min-w-0 space-y-3", children: T }),
          e.jsxs("div", {
            className: "min-w-0 space-y-3",
            children: [
              e.jsxs("div", {
                className: "tl-lane tl-lane-interpreter",
                "data-tl-lane": "interpreter",
                children: [
                  e.jsxs("h3", {
                    className: "tl-lane-title",
                    children: [
                      e.jsx("span", {
                        className: "tl-dot tl-dot-interpreter",
                        "aria-hidden": "true",
                      }),
                      "Interpreter",
                    ],
                  }),
                  n === "stop"
                    ? e.jsx("p", {
                        className: "tl-prompt",
                        "data-tl-prompt": !0,
                        children:
                          "It runs one line at a time. Tap the line where it stops.",
                      })
                    : e.jsxs(e.Fragment, {
                        children: [
                          e.jsx(ft, {
                            lines: Z,
                            status: h
                              ? `Error on line ${d}: ${t.fixes[d]}. Stopped.`
                              : "Running…",
                            tone: h ? "bad" : "mute",
                          }),
                          $
                            ? e.jsx(Ae, {
                                right: S,
                                children: S
                                  ? `It stopped at the first error, line ${d}.`
                                  : `You tapped line ${c}. It stopped at the first error it reached, line ${d}.`,
                              })
                            : null,
                        ],
                      }),
                  n === "interpreted"
                    ? e.jsxs("button", {
                        type: "button",
                        className: "tl-button tl-primary",
                        onClick: () => l("report"),
                        children: [
                          "Now the compiler",
                          e.jsx(Ge, {
                            "aria-hidden": "true",
                            className: "h-4 w-4",
                          }),
                        ],
                      })
                    : null,
                ],
              }),
              n === "report" || n === "compiling" || n === "done"
                ? e.jsxs("div", {
                    className: "tl-lane tl-lane-compiler",
                    "data-tl-lane": "compiler",
                    children: [
                      e.jsxs("h3", {
                        className: "tl-lane-title",
                        children: [
                          e.jsx("span", {
                            className: "tl-dot tl-dot-compiler",
                            "aria-hidden": "true",
                          }),
                          "Compiler",
                        ],
                      }),
                      n === "report"
                        ? e.jsxs(e.Fragment, {
                            children: [
                              e.jsx("p", {
                                className: "tl-prompt",
                                "data-tl-prompt": !0,
                                children:
                                  "It translates the whole program first. Tap every line its error report will list.",
                              }),
                              e.jsxs("button", {
                                type: "button",
                                className: "tl-button tl-primary",
                                disabled: u.size === 0,
                                onClick: () => l("compiling"),
                                children: [
                                  e.jsx(ae, {
                                    "aria-hidden": "true",
                                    className: "h-4 w-4",
                                  }),
                                  "Compile",
                                ],
                              }),
                            ],
                          })
                        : n === "compiling"
                          ? e.jsx("div", {
                              className: "tl-progress",
                              "aria-label": "Compiling",
                              children: e.jsx("div", {
                                className: "tl-progress-fill",
                                style: { width: `${(M / 3) * 100}%` },
                              }),
                            })
                          : e.jsxs(e.Fragment, {
                              children: [
                                e.jsxs("div", {
                                  className: "tl-report",
                                  "data-tl-report": !0,
                                  children: [
                                    e.jsx("p", {
                                      className: "tl-console-head",
                                      children: "Error report",
                                    }),
                                    t.errors.map((y) =>
                                      e.jsxs(
                                        "p",
                                        {
                                          className: "tl-console-line tl-bad",
                                          children: [
                                            "Line ",
                                            y,
                                            ": ",
                                            t.fixes[y],
                                          ],
                                        },
                                        y,
                                      ),
                                    ),
                                    e.jsx("p", {
                                      className: "tl-console-status tl-mute",
                                      children:
                                        "No executable made. Nothing ran.",
                                    }),
                                  ],
                                }),
                                e.jsx(Ae, {
                                  right: b,
                                  children: b
                                    ? `It reported all ${g.size} errors at the end, and ran nothing.`
                                    : `It reported all ${g.size} errors: lines ${t.errors.join(", ")}. You tapped ${[...u].sort((y, Q) => y - Q).join(", ")}.`,
                                }),
                              ],
                            }),
                    ],
                  })
                : null,
            ],
          }),
        ],
      }),
      n === "done"
        ? e.jsx("section", {
            className: "tl-outcome tl-outcome-plain",
            "data-story-card": "outcome",
            "data-tl-outcome": S && b ? "right" : "wrong",
            children: e.jsxs("div", {
              className: "tl-outcome-body",
              children: [
                e.jsx("h3", {
                  className: `tl-outcome-title ${S && b ? "tl-good" : "tl-bad"}`,
                  children:
                    S && b
                      ? "Both translators called right"
                      : "Watch what each one did",
                }),
                e.jsxs("p", {
                  className: "tl-text",
                  children: [
                    "The interpreter ran lines before the error and stopped at line ",
                    d,
                    ". The compiler ran nothing and listed every error at the end.",
                  ],
                }),
                e.jsx(J, { id: "spec-5b-errors" }),
                e.jsx(J, { id: "j22-4b-debug" }),
                e.jsx(K, { isLast: a, onNext: s }),
              ],
            }),
          })
        : null,
    ],
  });
}
function jt({ label: t, drag: r, onTap: s, selected: a }) {
  return e.jsxs("button", {
    type: "button",
    className: "tl-card tl-script",
    "aria-pressed": a,
    onClick: s,
    ...r,
    children: [
      e.jsxs("span", {
        className: "tl-script-lines",
        "aria-hidden": "true",
        children: [e.jsx("span", {}), e.jsx("span", {}), e.jsx("span", {})],
      }),
      t,
    ],
  });
}
function yt({ scenario: t, onResolved: r, onNext: s, isLast: a }) {
  const [o, n] = f.useState(null),
    [l, c] = f.useState(!1),
    p = V((j, d) => u(d));
  function u(j) {
    o || (n(j), r(j === t.right ? 1 : 0));
  }
  if (o) {
    const j = t.outcomes[o];
    return e.jsx("div", {
      className: "tl-round",
      "data-tl-round": "pick",
      "data-tl-scenario": t.id,
      "data-tl-choice": o,
      children: e.jsx(me, {
        developer: t.developer,
        prop: t.prop,
        outcome: j,
        right: o === t.right,
        footer: e.jsx(K, { isLast: a, onNext: s }),
        children: e.jsxs("p", {
          className: "tl-chosen",
          children: [
            t.developer.name,
            " used ",
            o === "compiler" ? "a compiler" : "an interpreter",
            ".",
          ],
        }),
      }),
    });
  }
  return e.jsxs("div", {
    className: "tl-round",
    "data-tl-round": "pick",
    "data-tl-scenario": t.id,
    children: [
      e.jsxs(xe, {
        developer: t.developer,
        prop: t.prop,
        children: [
          e.jsx("p", { className: "tl-text", children: t.story }),
          e.jsxs("p", {
            className: "tl-prompt",
            "data-tl-prompt": !0,
            children: [
              "Drag the code onto the translator ",
              t.developer.name,
              " should use.",
            ],
          }),
        ],
      }),
      e.jsxs("div", {
        className: "tl-dropline",
        children: [
          e.jsx(jt, {
            label: `${t.developer.name}’s code`,
            drag: p("script"),
            selected: l,
            onTap: () => c((j) => !j),
          }),
          e.jsxs("div", {
            className: "tl-machines",
            role: "group",
            "aria-label": "Translators",
            children: [
              e.jsx(Te, {
                kind: "compiler",
                label: $e.compiler,
                onPick: () => u("compiler"),
              }),
              e.jsx(Te, {
                kind: "interpreter",
                label: $e.interpreter,
                onPick: () => u("interpreter"),
              }),
            ],
          }),
        ],
      }),
    ],
  });
}
function bt({ job: t, onResolved: r, onNext: s, isLast: a }) {
  const [o, n] = f.useState([]),
    [l, c] = f.useState(!1),
    p = V((d, x) => {
      (x === "box" && n((g) => (g.includes(d) ? g : [...g, d])),
        x === "shelf" && n((g) => g.filter((S) => S !== d)));
    });
  function u(d) {
    n((x) => (x.includes(d) ? x.filter((g) => g !== d) : [...x, d]));
  }
  const j = t.translator === "compiler" ? "a compiler" : "an interpreter";
  if (l) {
    const d = Me(t, o);
    return e.jsx("div", {
      className: "tl-round",
      "data-tl-round": "ship",
      "data-tl-ship": t.id,
      children: e.jsx(me, {
        developer: t.developer,
        prop: t.prop,
        outcome: d,
        right: d.right,
        footer: e.jsx(K, { isLast: a, onNext: s }),
        children: e.jsx("ul", {
          className: "tl-packed",
          "aria-label": "In the box",
          children: te
            .filter(({ id: x }) => o.includes(x))
            .map(({ id: x, label: g }) =>
              e.jsx(
                "li",
                { className: "tl-chip", "data-item": x, children: g },
                x,
              ),
            ),
        }),
      }),
    });
  }
  return e.jsxs("div", {
    className: "tl-round",
    "data-tl-round": "ship",
    "data-tl-ship": t.id,
    children: [
      e.jsxs(xe, {
        developer: t.developer,
        prop: t.prop,
        children: [
          e.jsxs("p", {
            className: "tl-text",
            children: [
              t.developer.name,
              " translated ",
              t.product,
              " with ",
              e.jsx("strong", { children: j }),
              ". It’s going to ",
              t.customer,
              ".",
            ],
          }),
          e.jsx("p", {
            className: "tl-prompt",
            "data-tl-prompt": !0,
            children: "Pack only what their computers need to run it.",
          }),
        ],
      }),
      e.jsxs("div", {
        className: "tl-ship",
        children: [
          e.jsx("div", {
            className: "tl-shelf",
            "data-tl-zone": "shelf",
            "aria-label": "Shelf",
            children: te.map(({ id: d, label: x }) => {
              const g = o.includes(d);
              return e.jsxs(
                "button",
                {
                  type: "button",
                  className: "tl-card tl-chip",
                  "aria-pressed": g,
                  "data-item": d,
                  onClick: () => u(d),
                  ...p(d),
                  children: [
                    g
                      ? e.jsx(H, {
                          "aria-hidden": "true",
                          className: "h-4 w-4",
                        })
                      : e.jsx(Ce, {
                          "aria-hidden": "true",
                          className: "h-4 w-4",
                        }),
                    x,
                  ],
                },
                d,
              );
            }),
          }),
          e.jsxs("div", {
            className: "tl-box",
            "data-tl-zone": "box",
            "data-tl-box": !0,
            children: [
              e.jsx("p", { className: "tl-box-label", children: "The box" }),
              o.length
                ? e.jsx("ul", {
                    className: "tl-packed",
                    children: te
                      .filter(({ id: d }) => o.includes(d))
                      .map(({ id: d, label: x }) =>
                        e.jsx(
                          "li",
                          { className: "tl-chip", "data-item": d, children: x },
                          d,
                        ),
                      ),
                  })
                : e.jsx("p", { className: "tl-mute", children: "Empty" }),
              e.jsxs("button", {
                type: "button",
                className: "tl-button tl-primary",
                disabled: o.length === 0,
                onClick: () => {
                  (c(!0), r(Me(t, o).right ? 1 : 0));
                },
                children: [
                  e.jsx(He, { "aria-hidden": "true", className: "h-4 w-4" }),
                  "Ship it",
                ],
              }),
            ],
          }),
        ],
      }),
    ],
  });
}
function kt({ job: t, onResolved: r, onNext: s, isLast: a, stepMs: o }) {
  const [n, l] = f.useState(1),
    [c, p] = f.useState(!1),
    [u, j] = f.useState(!1),
    d = se(t.runs, o, c, () => {
      (p(!1), j(!0), r(n === Be(t) ? 1 : 0));
    }),
    x = t.runs + 2,
    g = u ? t.runs : d,
    S = Array.from({ length: g }, (M, L) => Le(t, L + 1)).filter(
      Boolean,
    ).length,
    b = u ? nt(t, n) : null,
    v = t.translator === "compiler" ? "a compiler" : "an interpreter";
  return e.jsxs("div", {
    className: "tl-round",
    "data-tl-round": "rerun",
    "data-tl-rerun": t.id,
    children: [
      e.jsx(fe, {
        developer: t.developer,
        children: e.jsxs("p", {
          children: [
            t.developer.name,
            " translates ",
            t.program,
            " with ",
            e.jsx("strong", { children: v }),
            ", then runs it ",
            t.runs,
            " times",
            t.editBefore
              ? `. The source code is edited before ${t.runLabel.toLowerCase()} ${t.editBefore}`
              : "",
            ".",
          ],
        }),
      }),
      e.jsx("ol", {
        className: "tl-timeline",
        "aria-label": "Runs",
        "data-tl-timeline": !0,
        children: Array.from({ length: t.runs }, (M, L) => {
          const $ = L + 1,
            I = $ <= g,
            C = I && Le(t, $);
          return e.jsxs(
            "li",
            {
              className: "tl-run",
              "data-reached": I ? "true" : void 0,
              "data-translates": C ? "true" : void 0,
              children: [
                t.editBefore === $
                  ? e.jsx("span", { className: "tl-edit", children: "Edited" })
                  : null,
                e.jsxs("span", {
                  className: "tl-run-label",
                  children: [t.runLabel, " ", $],
                }),
                e.jsxs("span", {
                  className: "tl-run-steps",
                  children: [
                    e.jsx("span", {
                      className: `tl-step ${C ? "tl-step-on" : ""}`,
                      children: C ? "Translate" : I ? "—" : "",
                    }),
                    e.jsx("span", {
                      className: `tl-step ${I ? "tl-step-run" : ""}`,
                      children: I ? "Run" : "",
                    }),
                  ],
                }),
              ],
            },
            $,
          );
        }),
      }),
      u
        ? null
        : e.jsxs("div", {
            className: "tl-counter",
            children: [
              e.jsx("p", {
                className: "tl-prompt",
                id: `count-${t.id}`,
                "data-tl-prompt": !0,
                children: "How many times is the code translated?",
              }),
              e.jsxs("div", {
                className: "tl-stepper",
                children: [
                  e.jsx("button", {
                    type: "button",
                    className: "tl-button tl-icon",
                    "aria-label": "Fewer",
                    disabled: c || n <= 0,
                    onClick: () => l((M) => Math.max(0, M - 1)),
                    children: e.jsx(Qe, {
                      "aria-hidden": "true",
                      className: "h-5 w-5",
                    }),
                  }),
                  e.jsx("output", {
                    className: "tl-count",
                    "aria-labelledby": `count-${t.id}`,
                    "data-tl-guess": !0,
                    children: c ? S : n,
                  }),
                  e.jsx("button", {
                    type: "button",
                    className: "tl-button tl-icon",
                    "aria-label": "More",
                    disabled: c || n >= x,
                    onClick: () => l((M) => Math.min(x, M + 1)),
                    children: e.jsx(Ce, {
                      "aria-hidden": "true",
                      className: "h-5 w-5",
                    }),
                  }),
                ],
              }),
              e.jsxs("button", {
                type: "button",
                className: "tl-button tl-primary",
                disabled: c,
                onClick: () => p(!0),
                children: [
                  e.jsx(ae, { "aria-hidden": "true", className: "h-4 w-4" }),
                  "Run all ",
                  t.runs,
                ],
              }),
            ],
          }),
      b
        ? e.jsx("section", {
            className: "tl-outcome tl-outcome-plain",
            "data-story-card": "outcome",
            "data-tl-outcome": b.right ? "right" : "wrong",
            children: e.jsxs("div", {
              className: "tl-outcome-body",
              children: [
                e.jsx("h3", {
                  className: `tl-outcome-title ${b.right ? "tl-good" : "tl-bad"}`,
                  children: b.title,
                }),
                e.jsx("p", { className: "tl-text", children: b.text }),
                e.jsx(J, { id: b.mark }),
                e.jsx(K, { isLast: a, onNext: s }),
              ],
            }),
          })
        : null,
    ],
  });
}
const Re = {
  high: "High-level",
  assembly: "Assembly",
  machine: "Machine code",
};
function wt({ job: t, onResolved: r, onNext: s, isLast: a, random: o }) {
  const [n, l] = f.useState(null),
    [c, p] = f.useState(!1),
    [u, j] = f.useState({}),
    [d, x] = f.useState(null),
    [g, S] = f.useState(!1),
    b = f.useMemo(() => Oe(["high", "assembly", "machine"], o), [o]),
    v = V((h, R) => L(R)),
    M = V((h, R) => $(h, R));
  function L(h) {
    n || l(h);
  }
  function $(h, R) {
    g || (j((T) => ({ ...T, [h]: R })), x(null));
  }
  const I = b.every((h) => u[h]),
    C = b.every((h) => u[h] === Se[h]);
  if (!n)
    return e.jsxs("div", {
      className: "tl-round",
      "data-tl-round": "levels",
      "data-tl-level-job": t.id,
      children: [
        e.jsxs(xe, {
          developer: t.developer,
          prop: t.prop,
          children: [
            e.jsx("p", { className: "tl-text", children: t.story }),
            e.jsxs("p", {
              className: "tl-prompt",
              "data-tl-prompt": !0,
              children: [
                "Drag the job onto the kind of language ",
                t.developer.name,
                " should write it in.",
              ],
            }),
          ],
        }),
        e.jsxs("div", {
          className: "tl-dropline",
          children: [
            e.jsxs("button", {
              type: "button",
              className: "tl-card tl-script",
              ...v("job"),
              children: [
                e.jsxs("span", {
                  className: "tl-script-lines",
                  "aria-hidden": "true",
                  children: [
                    e.jsx("span", {}),
                    e.jsx("span", {}),
                    e.jsx("span", {}),
                  ],
                }),
                t.developer.name,
                "’s job",
              ],
            }),
            e.jsx("div", {
              className: "tl-machines",
              role: "group",
              "aria-label": "Kind of language",
              children: ["high", "low"].map((h) =>
                e.jsxs(
                  "button",
                  {
                    type: "button",
                    className: `tl-level tl-level-${h}`,
                    "data-tl-zone": h,
                    onClick: () => L(h),
                    children: [
                      e.jsx("code", {
                        className: "tl-level-sample",
                        "aria-hidden": "true",
                        children:
                          h === "high"
                            ? t.code.high[0]
                            : t.code.assembly.join(" / "),
                      }),
                      e.jsx("span", {
                        className: "tl-machine-label",
                        children: pt[h],
                      }),
                    ],
                  },
                  h,
                ),
              ),
            }),
          ],
        }),
      ],
    });
  const Z = t.outcomes[n];
  return c
    ? e.jsxs("div", {
        className: "tl-round",
        "data-tl-round": "levels-sort",
        "data-tl-level-job": t.id,
        children: [
          e.jsx(fe, {
            developer: t.developer,
            children: e.jsx("p", {
              children:
                "The same instruction, written three ways. The processor can only run machine code.",
            }),
          }),
          e.jsx("p", {
            className: "tl-prompt",
            "data-tl-prompt": !0,
            children:
              "Drag each one: does it need translating before the processor can run it?",
          }),
          e.jsx("div", {
            className: "tl-forms",
            "aria-label": "Code to sort",
            children: b
              .filter((h) => !u[h])
              .map((h) =>
                e.jsxs(
                  "button",
                  {
                    type: "button",
                    className: "tl-card tl-form",
                    "aria-pressed": d === h,
                    "data-form": h,
                    onClick: () => x((R) => (R === h ? null : h)),
                    ...M(h),
                    children: [
                      e.jsx("span", {
                        className: "tl-form-label",
                        children: Re[h],
                      }),
                      e.jsx("code", {
                        className: "tl-form-code",
                        children: t.code[h].join(`
`),
                      }),
                    ],
                  },
                  h,
                ),
              ),
          }),
          e.jsx("div", {
            className: "tl-lanes",
            children: ot.map((h) => {
              const R = b.filter((T) => u[T] === h.id);
              return e.jsxs(
                "div",
                {
                  className: `tl-sortlane tl-sortlane-${h.id}`,
                  "data-tl-zone": h.id,
                  "data-lane": h.id,
                  children: [
                    e.jsxs("button", {
                      type: "button",
                      className: "tl-sortlane-head",
                      disabled: !d || g,
                      onClick: () => d && $(d, h.id),
                      children: [
                        e.jsx("svg", {
                          viewBox: "0 0 160 120",
                          className: "tl-sortlane-art",
                          "aria-hidden": "true",
                          children:
                            h.id === "translate"
                              ? e.jsx(O, { kind: "compiler" })
                              : e.jsx(Ze, {}),
                        }),
                        h.label,
                      ],
                    }),
                    R.map((T) => {
                      const y = Se[T] === h.id;
                      return e.jsxs(
                        "button",
                        {
                          type: "button",
                          className: "tl-card tl-form tl-form-placed",
                          "data-form": T,
                          "data-result": g ? (y ? "right" : "wrong") : void 0,
                          disabled: g,
                          onClick: () => j((Q) => ({ ...Q, [T]: void 0 })),
                          children: [
                            e.jsxs("span", {
                              className: "tl-form-label",
                              children: [
                                g
                                  ? y
                                    ? e.jsx(H, {
                                        "aria-label": "Right",
                                        className: "tl-form-icon",
                                      })
                                    : e.jsx(ie, {
                                        "aria-label": "Wrong",
                                        className: "tl-form-icon",
                                      })
                                  : null,
                                Re[T],
                              ],
                            }),
                            e.jsx("code", {
                              className: "tl-form-code",
                              children: t.code[T].join(`
`),
                            }),
                          ],
                        },
                        T,
                      );
                    }),
                  ],
                },
                h.id,
              );
            }),
          }),
          g
            ? e.jsx("section", {
                className: "tl-outcome tl-outcome-plain",
                "data-story-card": "outcome",
                "data-tl-outcome": C ? "right" : "wrong",
                children: e.jsxs("div", {
                  className: "tl-outcome-body",
                  children: [
                    e.jsx("h3", {
                      className: `tl-outcome-title ${C ? "tl-good" : "tl-bad"}`,
                      children: C
                        ? "All three reach the processor"
                        : "Not all three reach the processor",
                    }),
                    e.jsx("p", {
                      className: "tl-text",
                      children:
                        "High-level code always needs translating into machine code, by a compiler or an interpreter. Assembly is low-level but still needs translating. Machine code needs none: the processor runs it as it is.",
                    }),
                    ct.map((h) => e.jsx(J, { id: h }, h)),
                    e.jsx(J, { id: "j26-2b-translated" }),
                    e.jsx(K, { isLast: a, onNext: s }),
                  ],
                }),
              })
            : e.jsxs("button", {
                type: "button",
                className: "tl-button tl-primary",
                disabled: !I,
                onClick: () => {
                  (S(!0), r((n === t.right ? 1 : 0) + (C ? 1 : 0)));
                },
                children: [
                  e.jsx(H, { "aria-hidden": "true", className: "h-4 w-4" }),
                  "Translate",
                ],
              }),
        ],
      })
    : e.jsx("div", {
        className: "tl-round",
        "data-tl-round": "levels",
        "data-tl-level-job": t.id,
        "data-tl-choice": n,
        children: e.jsx(me, {
          developer: t.developer,
          prop: t.prop,
          outcome: Z,
          right: n === t.right,
          footer: e.jsxs("button", {
            type: "button",
            className: "tl-button tl-primary",
            onClick: () => p(!0),
            children: [
              "Now translate it",
              e.jsx(Ie, { "aria-hidden": "true", className: "h-4 w-4" }),
            ],
          }),
          children: e.jsxs("p", {
            className: "tl-chosen",
            children: [
              t.developer.name,
              " wrote it in ",
              n === "high" ? "a high-level" : "a low-level",
              " language.",
            ],
          }),
        }),
      });
}
const vt = 420;
function Nt() {
  return typeof window > "u" || typeof window.matchMedia != "function"
    ? !0
    : window.matchMedia("(prefers-reduced-motion: reduce)").matches ||
        document.documentElement.dataset.reduceMotion === "true";
}
function Mt({ onStart: t }) {
  return e.jsxs("div", {
    className: "game-landing tl-landing",
    style: { "--landing-glow": "#2fd6c3" },
    "data-game-landing": !0,
    children: [
      e.jsx(be, { layout: "tall" }),
      e.jsx(be, { layout: "wide" }),
      e.jsxs("button", {
        type: "button",
        className: "game-landing-start tl-button tl-primary",
        onClick: t,
        children: [
          e.jsx(ae, { "aria-hidden": "true", className: "h-4 w-4" }),
          "Open the lab",
        ],
      }),
    ],
  });
}
function Je({ jobs: t, index: r, earned: s }) {
  return e.jsx("ol", {
    className: "tl-dots",
    "aria-label": `Job ${r + 1} of ${t.length}`,
    "data-tl-dots": !0,
    children: t.map((a, o) => {
      const n = s[o],
        l =
          n === void 0
            ? o === r
              ? "next"
              : "pending"
            : n === ue[a.kind]
              ? "right"
              : n > 0
                ? "part"
                : "wrong";
      return e.jsx(
        "li",
        { className: "tl-dot-job", "data-state": l, "aria-hidden": "true" },
        o,
      );
    }),
  });
}
function Lt({ job: t, random: r, ...s }) {
  switch (t.kind) {
    case "errors":
      return e.jsx(gt, { program: t.program, ...s });
    case "pick":
      return e.jsx(yt, { scenario: t.scenario, ...s });
    case "ship":
      return e.jsx(bt, { job: t.job, ...s });
    case "rerun":
      return e.jsx(kt, { job: t.job, ...s });
    case "levels":
      return e.jsx(wt, { job: t.job, random: r, ...s });
  }
}
function St({ marks: t, total: r, jobs: s, earned: a, onRestart: o }) {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsxs("section", {
        className: "tl-summary",
        "data-story-card": "summary",
        "data-game-finished": t * 4 >= r * 3 ? "good" : "poor",
        "aria-live": "polite",
        children: [
          e.jsx("h3", {
            className: "tl-summary-rank",
            "data-tl-rank": !0,
            children: ht(t, r),
          }),
          e.jsxs("p", {
            className: "tl-summary-marks",
            "data-tl-marks": !0,
            children: [
              t,
              " / ",
              r,
              " ",
              e.jsx("span", {
                className: "tl-summary-unit",
                children: "marks",
              }),
            ],
          }),
          e.jsx(Je, { jobs: s, index: s.length, earned: a }),
          e.jsxs("button", {
            type: "button",
            className: "tl-button tl-secondary",
            onClick: o,
            children: [
              e.jsx(Ke, { "aria-hidden": "true", className: "h-4 w-4" }),
              "New shift",
            ],
          }),
        ],
      }),
      e.jsx(Ue, { game: "translator-lab" }),
    ],
  });
}
function It({ random: t = Math.random, stepMs: r }) {
  const [s, a] = f.useState(() => We(t)),
    [o, n] = f.useState("intro"),
    [l, c] = f.useState(0),
    [p, u] = f.useState([]),
    [j] = f.useState(() => r ?? (Nt() ? 0 : vt)),
    d = dt(s),
    x = p.reduce((v, M) => v + (M ?? 0), 0);
  Ye(
    p.filter((v) => v !== void 0).length,
    s.length,
    s.filter((v, M) => p[M] === ue[v.kind]).length,
  );
  function g() {
    (a(We(t)), c(0), u([]), n("playing"));
  }
  function S() {
    l + 1 >= s.length ? n("over") : c((v) => v + 1);
  }
  const b = s[l];
  return e.jsx("div", {
    className: "translator-lab",
    "data-translator-lab": !0,
    "data-tl-phase": o,
    children:
      o === "intro"
        ? e.jsx(Mt, { onStart: () => n("playing") })
        : o === "over" || !b
          ? e.jsx(St, { marks: x, total: d, jobs: s, earned: p, onRestart: g })
          : e.jsxs("div", {
              className: "tl-play",
              children: [
                e.jsxs("div", {
                  className: "tl-hud",
                  children: [
                    e.jsxs("p", {
                      className: "tl-hud-marks",
                      children: [
                        e.jsx("span", {
                          className: "tl-hud-label",
                          children: "Marks",
                        }),
                        e.jsx("span", {
                          className: "tl-hud-value",
                          "data-tl-score": !0,
                          children: x,
                        }),
                      ],
                    }),
                    e.jsx(Je, { jobs: s, index: l, earned: p }),
                  ],
                }),
                e.jsx(
                  Lt,
                  {
                    job: b,
                    random: t,
                    stepMs: j,
                    isLast: l + 1 >= s.length,
                    onNext: S,
                    onResolved: (v) =>
                      u((M) => {
                        const L = [...M];
                        return ((L[l] = v), L);
                      }),
                  },
                  `${l}-${b.kind}`,
                ),
              ],
            }),
  });
}
export { It as default };
