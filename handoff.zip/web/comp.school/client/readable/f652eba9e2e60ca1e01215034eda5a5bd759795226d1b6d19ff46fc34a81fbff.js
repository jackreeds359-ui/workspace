import { j as r, r as j } from "./react-vendor-BK1G6oO1.js";
import { P as Le, ce as fe, R as Ce } from "./index-DjyiOHey.js";
import { aq as ze, aT as De } from "./GameNotebook-b0Qw2wzd.js";
import { T as Fe } from "./action-styles-DWMwPIR0.js";
import "./ui-components-DeMDYLzO.js";
function N(e) {
  return Array.isArray(e)
    ? `[${e.map(N).join(", ")}]`
    : typeof e == "boolean"
      ? e
        ? "True"
        : "False"
      : typeof e == "number"
        ? Number.isInteger(e)
          ? String(e)
          : String(Number(e.toFixed(6)))
        : e;
}
const Ue = [
  "==",
  "!=",
  "<=",
  ">=",
  "//",
  "<",
  ">",
  "+",
  "-",
  "*",
  "/",
  "%",
  "^",
  "(",
  ")",
  "[",
  "]",
  ",",
  ".",
  ":",
  "=",
];
function We(e) {
  const t = [];
  let s = 0;
  for (; s < e.length;) {
    const n = e[s];
    if (n === " " || n === "	") s += 1;
    else if (/[0-9]/.test(n)) {
      const i = /^[0-9]+(\.[0-9]+)?/.exec(e.slice(s));
      (t.push({ t: "num", v: Number(i[0]) }), (s += i[0].length));
    } else if (n === '"' || n === "'") {
      const i = e.indexOf(n, s + 1);
      if (i < 0) throw new Error(`Unclosed string in: ${e}`);
      (t.push({ t: "str", v: e.slice(s + 1, i) }), (s = i + 1));
    } else if (/[A-Za-z_]/.test(n)) {
      const i = /^[A-Za-z_][A-Za-z0-9_]*/.exec(e.slice(s));
      (t.push({ t: "id", v: i[0] }), (s += i[0].length));
    } else {
      const i = Ue.find((o) => e.startsWith(o, s));
      if (!i) throw new Error(`Unexpected "${n}" in: ${e}`);
      (t.push({ t: "op", v: i }), (s += i.length));
    }
  }
  return t;
}
class k {
  i = 0;
  tokens;
  constructor(t) {
    this.tokens = t;
  }
  static parse(t) {
    const s = new k(We(t)),
      n = s.or();
    if (s.i < s.tokens.length) throw new Error(`Unexpected tokens in: ${t}`);
    return n;
  }
  peek() {
    return this.tokens[this.i];
  }
  isOp(t) {
    const s = this.peek();
    return s?.t === "op" && s.v === t;
  }
  isWord(...t) {
    const s = this.peek();
    return s?.t === "id" && t.includes(s.v) ? s.v : null;
  }
  expectOp(t) {
    if (!this.isOp(t)) throw new Error(`Expected "${t}"`);
    this.i += 1;
  }
  or() {
    let t = this.and();
    for (; this.isWord("OR", "or");)
      ((this.i += 1), (t = { k: "bin", op: "or", a: t, b: this.and() }));
    return t;
  }
  and() {
    let t = this.not();
    for (; this.isWord("AND", "and");)
      ((this.i += 1), (t = { k: "bin", op: "and", a: t, b: this.not() }));
    return t;
  }
  not() {
    return this.isWord("NOT", "not")
      ? ((this.i += 1), { k: "not", a: this.not() })
      : this.compare();
  }
  compare() {
    const t = this.add(),
      s = this.peek();
    return s?.t === "op" && ["==", "!=", "<", ">", "<=", ">="].includes(s.v)
      ? ((this.i += 1), { k: "bin", op: s.v, a: t, b: this.add() })
      : t;
  }
  add() {
    let t = this.mul();
    for (;;) {
      const s = this.peek();
      if (s?.t === "op" && (s.v === "+" || s.v === "-"))
        ((this.i += 1), (t = { k: "bin", op: s.v, a: t, b: this.mul() }));
      else return t;
    }
  }
  mul() {
    let t = this.unary();
    for (;;) {
      const s = this.peek(),
        n = this.isWord("MOD", "DIV");
      if (s?.t === "op" && ["*", "/", "%", "//"].includes(s.v))
        ((this.i += 1),
          (t = {
            k: "bin",
            op: s.v === "%" ? "MOD" : s.v === "//" ? "DIV" : s.v,
            a: t,
            b: this.unary(),
          }));
      else if (n)
        ((this.i += 1), (t = { k: "bin", op: n, a: t, b: this.unary() }));
      else return t;
    }
  }
  unary() {
    return this.isOp("-")
      ? ((this.i += 1), { k: "neg", a: this.unary() })
      : this.postfix();
  }
  args() {
    this.expectOp("(");
    const t = [];
    if (!this.isOp(")"))
      for (t.push(this.or()); this.isOp(",");)
        ((this.i += 1), t.push(this.or()));
    return (this.expectOp(")"), t);
  }
  postfix() {
    let t = this.primary();
    for (;;)
      if (this.isOp("[")) {
        this.i += 1;
        const s = this.or();
        (this.expectOp("]"), (t = { k: "index", target: t, index: s }));
      } else if (this.isOp(".")) {
        this.i += 1;
        const s = this.peek();
        if (s?.t !== "id") throw new Error('Expected a name after "."');
        ((this.i += 1),
          (t = {
            k: "attr",
            target: t,
            name: s.v,
            args: this.isOp("(") ? this.args() : null,
          }));
      } else return t;
  }
  primary() {
    const t = this.peek();
    if (!t) throw new Error("Unexpected end of expression");
    if (((this.i += 1), t.t === "num" || t.t === "str"))
      return { k: "lit", v: t.v };
    if (t.t === "id")
      return t.v === "true" || t.v === "True"
        ? { k: "lit", v: !0 }
        : t.v === "false" || t.v === "False"
          ? { k: "lit", v: !1 }
          : this.isOp("(")
            ? { k: "call", name: t.v, args: this.args() }
            : { k: "var", name: t.v };
    if (t.v === "(") {
      const s = this.or();
      return (this.expectOp(")"), s);
    }
    throw new Error(`Unexpected "${t.v}"`);
  }
}
const Ge = /^(?:int\(|float\(|str\()?\s*(?:input|random)\(/;
function pe(e, t) {
  const s = /^print\((.*)\)$/.exec(e);
  if (s) {
    const i = s[1].trim() ? me(s[1]).map((o) => k.parse(o)) : [];
    return { s: "print", line: t, args: i };
  }
  const n = /^([A-Za-z_][A-Za-z0-9_]*)\s*=(?!=)\s*(.+)$/.exec(e);
  if (n) {
    const [, i, o] = n;
    return Ge.test(o)
      ? { s: "given", line: t, name: i }
      : { s: "assign", line: t, name: i, expr: k.parse(o) };
  }
  throw new Error(`Line ${t} is not a statement: ${e}`);
}
function me(e) {
  const t = [];
  let s = 0,
    n = null,
    i = 0;
  for (let o = 0; o < e.length; o += 1) {
    const l = e[o];
    n
      ? l === n && (n = null)
      : l === '"' || l === "'"
        ? (n = l)
        : l === "(" || l === "["
          ? (s += 1)
          : l === ")" || l === "]"
            ? (s -= 1)
            : l === "," && s === 0 && (t.push(e.slice(i, o)), (i = o + 1));
  }
  return (t.push(e.slice(i)), t.map((o) => o.trim()));
}
function qe(e) {
  return e
    .split(
      `
`,
    )
    .map((t, s) => ({
      n: s + 1,
      indent: t.length - t.trimStart().length,
      code: t.trim(),
    }));
}
function Be(e) {
  let t = 0;
  function s(i) {
    const o = [];
    for (; t < e.length && !i.test(e[t].code);) {
      const { n: l, code: p } = e[t];
      t += 1;
      let c;
      if ((c = /^if (.+) then$/.exec(p))) {
        const d = [];
        let h = k.parse(c[1]);
        for (;;) {
          const x = s(/^(elseif .+ then|else|endif)$/);
          d.push({ cond: h, body: x });
          const a = e[t++].code;
          if (a === "endif") break;
          const m = /^elseif (.+) then$/.exec(a);
          h = m ? k.parse(m[1]) : null;
        }
        o.push({ s: "if", branches: d });
      } else if ((c = /^while (.+)$/.exec(p))) {
        const d = k.parse(c[1]),
          h = s(/^endwhile$/);
        ((t += 1), o.push({ s: "while", cond: d, body: h }));
      } else if (p === "do") {
        const d = s(/^until /),
          h = k.parse(e[t++].code.replace(/^until /, ""));
        o.push({ s: "doUntil", body: d, cond: h });
      } else if ((c = /^for ([A-Za-z_]\w*) = (.+) to (.+)$/.exec(p))) {
        const d = s(/^next /),
          h = e[t++].n;
        o.push({
          s: "forTo",
          line: l,
          name: c[1],
          from: k.parse(c[2]),
          to: k.parse(c[3]),
          body: d,
          nextLine: h,
        });
      } else o.push(pe(p, l));
    }
    return o;
  }
  const n = s(/^$a/);
  if (t < e.length)
    throw new Error(`Unexpected "${e[t].code}" on line ${e[t].n}`);
  return n;
}
function Je(e) {
  let t = 0;
  function s(i) {
    const o = [];
    for (; t < e.length && e[t].indent === i;) {
      const { n: l, code: p } = e[t];
      t += 1;
      let c;
      if ((c = /^if (.+):$/.exec(p))) {
        const d = [];
        for (d.push({ cond: k.parse(c[1]), body: s(e[t].indent) }); ;) {
          const h = e[t];
          if (!h || h.indent !== i) break;
          const x = /^elif (.+):$/.exec(h.code);
          if (x)
            ((t += 1), d.push({ cond: k.parse(x[1]), body: s(e[t].indent) }));
          else if (h.code === "else:") {
            ((t += 1), d.push({ cond: null, body: s(e[t].indent) }));
            break;
          } else break;
        }
        o.push({ s: "if", branches: d });
      } else if ((c = /^while (.+):$/.exec(p)))
        o.push({ s: "while", cond: k.parse(c[1]), body: s(e[t].indent) });
      else if ((c = /^for ([A-Za-z_]\w*) in range\((.+)\):$/.exec(p))) {
        const d = me(c[2]).map((a) => k.parse(a)),
          [h, x] = d.length === 1 ? [{ k: "lit", v: 0 }, d[0]] : [d[0], d[1]];
        o.push({
          s: "forRange",
          line: l,
          name: c[1],
          from: h,
          to: x,
          body: s(e[t].indent),
        });
      } else
        (c = /^for ([A-Za-z_]\w*) in (.+):$/.exec(p))
          ? o.push({
              s: "forEach",
              line: l,
              name: c[1],
              over: k.parse(c[2]),
              body: s(e[t].indent),
            })
          : o.push(pe(p, l));
    }
    return o;
  }
  const n = s(0);
  if (t < e.length) throw new Error(`Unexpected indent on line ${e[t].n}`);
  return n;
}
const He = 400;
function u(e) {
  if (typeof e != "number") throw new Error(`Expected a number, got ${N(e)}`);
  return e;
}
function E(e) {
  if (typeof e != "string") throw new Error(`Expected a string, got ${N(e)}`);
  return e;
}
function O(e) {
  if (typeof e != "boolean")
    throw new Error(`Expected a condition, got ${N(e)}`);
  return e;
}
function ie(e, t) {
  return N(e) === N(t) && typeof e == typeof t;
}
function Qe(e, t, s) {
  if (e === "==") return ie(t, s);
  if (e === "!=") return !ie(t, s);
  const n = typeof t == "string" ? t : u(t),
    i = typeof s == "string" ? s : u(s);
  if (typeof n != typeof i)
    throw new Error("Cannot compare a string with a number");
  return e === "<" ? n < i : e === ">" ? n > i : e === "<=" ? n <= i : n >= i;
}
function g(e, t) {
  switch (e.k) {
    case "lit":
      return e.v;
    case "var": {
      const s = t.get(e.name);
      if (s === void 0) throw new Error(`${e.name} is used before it is set`);
      return s;
    }
    case "not":
      return !O(g(e.a, t));
    case "neg":
      return -u(g(e.a, t));
    case "bin": {
      if (e.op === "and") return O(g(e.a, t)) && O(g(e.b, t));
      if (e.op === "or") return O(g(e.a, t)) || O(g(e.b, t));
      const s = g(e.a, t),
        n = g(e.b, t);
      if (["==", "!=", "<", ">", "<=", ">="].includes(e.op))
        return Qe(e.op, s, n);
      if (e.op === "+")
        return typeof s == "string" && typeof n == "string"
          ? s + n
          : u(s) + u(n);
      if (e.op === "-") return u(s) - u(n);
      if (e.op === "*") return u(s) * u(n);
      if (e.op === "/") return u(s) / u(n);
      if (e.op === "MOD") return u(s) - Math.floor(u(s) / u(n)) * u(n);
      if (e.op === "DIV") return Math.floor(u(s) / u(n));
      throw new Error(`Unknown operator ${e.op}`);
    }
    case "call": {
      const s = e.args.map((n) => g(n, t));
      if (e.name === "str") return N(s[0]);
      if (e.name === "int") return Math.trunc(Number(s[0]));
      if (e.name === "len") {
        const n = s[0];
        return Array.isArray(n) ? n.length : E(n).length;
      }
      throw new Error(`Unknown function ${e.name}`);
    }
    case "index": {
      const s = g(e.target, t),
        n = u(g(e.index, t)),
        i = Array.isArray(s) ? s[n] : E(s)[n];
      if (i === void 0) throw new Error(`Index ${n} is out of range`);
      return i;
    }
    case "attr": {
      const s = g(e.target, t),
        n = (e.args ?? []).map((i) => g(i, t));
      if (e.name === "length") return Array.isArray(s) ? s.length : E(s).length;
      if (e.name === "upper") return E(s).toUpperCase();
      if (e.name === "lower") return E(s).toLowerCase();
      if (e.name === "substring") return E(s).substr(u(n[0]), u(n[1]));
      if (e.name === "left") return E(s).slice(0, u(n[0]));
      if (e.name === "right") return E(s).slice(-u(n[0]));
      throw new Error(`Unknown method ${e.name}`);
    }
  }
}
function Ve(e, t) {
  const s = qe(e);
  return t === "ocr" ? Be(s) : Je(s);
}
function Ze(e, t, s = {}) {
  const n = Ve(e, t),
    i = new Map();
  for (const [x, a] of Object.entries(s.arrays ?? {})) i.set(x, [...a]);
  const o = [...(s.inputs ?? [])],
    l = [];
  function p(x) {
    if ((l.push(x), l.length > He))
      throw new Error("The program does not stop");
  }
  function c(x, a, m, v = !1) {
    (i.set(a, m),
      p({
        line: x,
        changes: { [a]: m },
        output: null,
        ...(v ? { given: v } : {}),
      }));
  }
  function d(x) {
    for (const a of x)
      switch (a.s) {
        case "assign":
          c(a.line, a.name, g(a.expr, i));
          break;
        case "given": {
          const m = o.shift();
          if (m === void 0)
            throw new Error(`No input for ${a.name} on line ${a.line}`);
          c(a.line, a.name, m, !0);
          break;
        }
        case "print":
          p({
            line: a.line,
            changes: {},
            output: a.args.map((m) => N(g(m, i))).join(" "),
          });
          break;
        case "if": {
          const m = a.branches.find((v) => v.cond === null || O(g(v.cond, i)));
          m && d(m.body);
          break;
        }
        case "while":
          for (; O(g(a.cond, i));) d(a.body);
          break;
        case "doUntil":
          do d(a.body);
          while (!O(g(a.cond, i)));
          break;
        case "forTo": {
          const m = u(g(a.to, i));
          for (c(a.line, a.name, u(g(a.from, i))); u(i.get(a.name)) <= m;)
            (d(a.body), c(a.nextLine, a.name, u(i.get(a.name)) + 1));
          break;
        }
        case "forRange": {
          const m = u(g(a.from, i)),
            v = u(g(a.to, i));
          for (let T = m; T < v; T += 1) (c(a.line, a.name, T), d(a.body));
          break;
        }
        case "forEach": {
          const m = g(a.over, i),
            v = Array.isArray(m) ? m : [...E(m)];
          for (const T of v) (c(a.line, a.name, T), d(a.body));
          break;
        }
      }
  }
  d(n);
  const h = [];
  for (const x of l)
    for (const a of Object.keys(x.changes)) h.includes(a) || h.push(a);
  return { rows: l, columns: h };
}
const Y = [
    { id: "for", name: "FOR loop" },
    { id: "while", name: "WHILE loop" },
    { id: "selection", name: "Selection" },
    { id: "strings", name: "Strings and arrays" },
  ],
  Ye = {
    tickets: { name: "Ticket machine" },
    scores: { name: "Score counter" },
    door: { name: "Staff door" },
    prizes: { name: "Prize desk" },
    lockers: { name: "Locker keypad" },
  },
  K = 3,
  R = (e, t) => e[Math.floor(t() * e.length)],
  y = (e, t, s) => e + Math.floor(s() * (t - e + 1)),
  C = {
    series: "June 2025",
    question: "Q6(d)(i)",
    markPoints:
      "count set to 0; count changes in order and no other changes; x goes 0, 1, 2 (then 3); one output only",
  },
  Ke = {
    series: "June 2023",
    question: "Q1(d)",
    markPoints:
      "start set and output; each loop updates start on the right line; Finished output; no extra output",
  },
  oe = {
    series: "Practice 2023",
    question: "Q7(b)",
    markPoints:
      "c changes on line 05 each time round; the loop stops once c is not < 100; the code is output once",
  },
  ae = {
    series: "June 2024",
    question: "Q9(b)",
    markPoints:
      "inputs on lines 01 and 02; score set only on the branch that runs; score doubled on line 11; output with no comma",
  },
  Xe = {
    series: "June 2026",
    question: "Q4(a)",
    markPoints:
      "year stored once; building set only when a condition is true; the output once and nothing else",
  },
  et = {
    series: "June 2022",
    question: "Q2(d)(ii)",
    markPoints:
      'staffID joined on line 03; one "x" added on line 05 each time round; "ID " output once with one space',
  },
  ce = {
    series: "June 2024",
    question: "Q6(a), Q9(b)",
    markPoints:
      "string methods .length, .upper and .left give the exact output; values change only on their own line",
  },
  tt = [
    {
      id: "ticket-total",
      stage: "for",
      machine: "tickets",
      style: "ocr",
      cite: C,
      deal: (e) => {
        const t = [y(2, 15, e), y(2, 15, e), y(2, 15, e)];
        return {
          source: [
            "total = 0",
            "for m = 0 to 2",
            "  total = total + tickets[m]",
            "next m",
            "print(total)",
          ].join(`
`),
          arrays: { tickets: t },
          brief: `The array tickets holds ${t.join(", ")}.`,
        };
      },
    },
    {
      id: "token-prices",
      stage: "for",
      machine: "tickets",
      style: "ocr",
      cite: C,
      deal: (e) => ({
        source: [
          `price = ${y(2, 6, e)}`,
          "for n = 1 to 3",
          "  print(n * price)",
          "next n",
          'print("End")',
        ].join(`
`),
        brief: "It prints the cost of 1, 2 and 3 tokens.",
      }),
    },
    {
      id: "double-score",
      stage: "for",
      machine: "scores",
      style: "python",
      cite: C,
      deal: (e) => ({
        source: [
          `score = ${y(3, 12, e)}`,
          "for i in range(3):",
          "    score = score * 2",
          "print(score)",
        ].join(`
`),
        brief: "A bonus doubles the score three times.",
      }),
    },
    {
      id: "bonus-steps",
      stage: "for",
      machine: "scores",
      style: "ocr",
      cite: C,
      deal: (e) => {
        const t = y(2, 5, e),
          s = y(1, 3, e);
        return {
          source: [
            "score = 0",
            `for level = ${s} to ${s + 2}`,
            `  score = score + level * ${t}`,
            "next level",
            "print(score)",
          ].join(`
`),
          brief: `Each level adds the level number times ${t}.`,
        };
      },
    },
    {
      id: "race-gap",
      stage: "while",
      machine: "scores",
      style: "ocr",
      cite: oe,
      deal: (e) => {
        const t = y(1, 3, e),
          s = y(9, 14, e);
        return {
          source: [
            `x = ${t}`,
            `y = ${s}`,
            "while x < y",
            "  x = x + 3",
            "  y = y - 2",
            "endwhile",
            "print(x)",
            "print(y)",
          ].join(`
`),
          brief: "Two racers close the gap until x catches y.",
        };
      },
    },
    {
      id: "countdown",
      stage: "while",
      machine: "tickets",
      style: "ocr",
      cite: Ke,
      deal: (e) => ({
        source: [
          `count = ${y(2, 4, e)}`,
          "do",
          "  print(count)",
          "  count = count - 1",
          "until count == 0",
          'print("Go")',
        ].join(`
`),
        brief: "The machine counts down before a game starts.",
      }),
    },
    {
      id: "jackpot",
      stage: "while",
      machine: "scores",
      style: "python",
      cite: oe,
      deal: (e) => {
        const t = y(5, 30, e),
          s = R([2, 3], e);
        return {
          source: [
            `points = ${t}`,
            "while points < 100:",
            `    points = points * ${s}`,
            "print(points)",
          ].join(`
`),
          brief: "The jackpot grows until it is 100 or more.",
        };
      },
    },
    {
      id: "digit-total",
      stage: "while",
      machine: "lockers",
      style: "ocr",
      cite: {
        series: "Practice 2023",
        question:
          "Q7(b), with MOD as in June 2024 Q2 and DIV as in Practice 2023 Q1",
        markPoints:
          "each variable changes on its own line; the loop stops when code reaches 0; one output",
      },
      deal: (e) => ({
        source: [
          `code = ${y(102, 989, e)}`,
          "total = 0",
          "while code > 0",
          "  total = total + code MOD 10",
          "  code = code DIV 10",
          "endwhile",
          "print(total)",
        ].join(`
`),
        brief: "The keypad adds up the digits of a locker code.",
      }),
    },
    {
      id: "penalty-kick",
      stage: "selection",
      machine: "scores",
      style: "ocr",
      cite: ae,
      deal: (e) => {
        const t = R([32.5, 38.2, 44.6, 51.3, 57.9, 63.4, 71.8], e),
          s = y(1, 3, e);
        return {
          source: [
            'speed = input("Enter speed")',
            'level = input("Enter level")',
            "if speed >= 60.0 then",
            "  score = 3",
            "elseif speed >= 40.0 then",
            "  score = 2",
            "else",
            "  score = 1",
            "endif",
            "if level != 1 then",
            "  score = score * 2",
            "endif",
            'print("The score is", score)',
          ].join(`
`),
          inputs: [t, s],
          brief: `A player on level ${s} kicks the ball at ${t} mph.`,
        };
      },
    },
    {
      id: "ticket-band",
      stage: "selection",
      machine: "tickets",
      style: "ocr",
      cite: Xe,
      deal: (e) => {
        const t = y(12, 18, e);
        return {
          source: [
            'age = int(input("Enter age"))',
            "if age >= 12 then",
            '  band = "B"',
            '  print("band" + band)',
            "endif",
            "if age >= 16 then",
            '  band = "C"',
            '  print("band" + band)',
            "endif",
          ].join(`
`),
          inputs: [t],
          brief: `${t} is entered.`,
        };
      },
    },
    {
      id: "prize-desk",
      stage: "selection",
      machine: "prizes",
      style: "python",
      cite: ae,
      deal: (e) => {
        const t = R([30, 45, 50, 65, 80], e),
          s = R(["Y", "N"], e);
        return {
          source: [
            'tickets = int(input("Tickets: "))',
            'member = input("Member? ")',
            "if tickets >= 50:",
            '    if member == "Y":',
            '        prize = "Robot"',
            "    else:",
            '        prize = "Yo-yo"',
            "    tickets = tickets - 50",
            "else:",
            '    prize = "Sticker"',
            "print(prize, tickets)",
          ].join(`
`),
          inputs: [t, s],
          brief: `${t} and ${s} are entered.`,
        };
      },
    },
    {
      id: "staff-id",
      stage: "strings",
      machine: "door",
      style: "ocr",
      cite: et,
      deal: (e) => {
        const t = R(["Jo", "Kai", "Ola", "Rio", "Ash", "Bo"], e),
          s = y(2024, 2027, e);
        return {
          source: [
            'name = input("Enter name")',
            'year = input("Enter year")',
            "user = name + str(year)",
            "while user.length < 8",
            '  user = user + "x"',
            "endwhile",
            'print("ID " + user)',
          ].join(`
`),
          inputs: [t, s],
          brief: `The door makes a staff ID when ${t} and ${s} are entered.`,
        };
      },
    },
    {
      id: "pin-total",
      stage: "strings",
      machine: "lockers",
      style: "ocr",
      cite: ce,
      deal: (e) => {
        const t = Array.from({ length: 3 }, () => String(y(0, 9, e))).join("");
        return {
          source: [
            'pin = input("Enter PIN")',
            "total = 0",
            "for i = 0 to pin.length - 1",
            "  total = total + int(pin.substring(i, 1))",
            "next i",
            "print(total)",
          ].join(`
`),
          inputs: [t],
          brief: `The PIN "${t}" is entered as a string.`,
        };
      },
    },
    {
      id: "high-score",
      stage: "strings",
      machine: "scores",
      style: "python",
      cite: C,
      deal: (e) => {
        const t = nt(
          [y(10, 29, e), y(30, 49, e), y(50, 69, e), y(70, 99, e)],
          e,
        );
        return {
          source: [
            "best = scores[0]",
            "for i in range(1, 4):",
            "    if scores[i] > best:",
            "        best = scores[i]",
            "print(best)",
          ].join(`
`),
          arrays: { scores: t },
          brief: `The array scores holds ${t.join(", ")}.`,
        };
      },
    },
    {
      id: "capitals",
      stage: "strings",
      machine: "door",
      style: "python",
      cite: ce,
      deal: (e) => {
        const s = [...R(["moon", "star", "bolt", "frog", "kite", "wave"], e)]
          .map((n) => (e() < 0.5 ? n.toUpperCase() : n))
          .join("");
        return {
          source: [
            'password = input("Password: ")',
            "caps = 0",
            "for letter in password:",
            "    if letter == letter.upper():",
            "        caps = caps + 1",
            "print(caps)",
          ].join(`
`),
          inputs: [s],
          brief: `The door counts the capitals in "${s}".`,
        };
      },
    },
  ];
function nt(e, t) {
  const s = [...e];
  for (let n = s.length - 1; n > 0; n -= 1) {
    const i = Math.floor(t() * (n + 1));
    [s[n], s[i]] = [s[i], s[n]];
  }
  return s;
}
function st(e, t) {
  const s = e.deal(t),
    n = Ze(s.source, e.style, { inputs: s.inputs, arrays: s.arrays });
  return {
    ...s,
    id: e.id,
    stage: e.stage,
    machine: e.machine,
    style: e.style,
    cite: e.cite,
    trace: n,
  };
}
function rt(e = Math.random) {
  return Y.map(({ id: t }) =>
    st(
      R(
        tt.filter((s) => s.stage === t),
        e,
      ),
      e,
    ),
  );
}
function le(e) {
  const t = e.trim();
  return (/^(["'])(.*)\1$/.exec(t)?.[2] ?? t).trim().toLowerCase();
}
function Q(e, t) {
  const s = le(e),
    n = le(N(t));
  if (s === n) return !0;
  const i = /^-?\d+(\.\d+)?$/;
  return i.test(s) && i.test(n) && Number(s) === Number(n);
}
function it(e, t) {
  const s = {};
  for (const n of e.slice(0, t)) Object.assign(s, n.changes);
  return s;
}
function ot(e, t, s) {
  const n = t.rows[s];
  if (!n) return [{ kind: "ended" }];
  const i = [];
  (Number(e.line.trim()) !== n.line || !/^\d+$/.test(e.line.trim())) &&
    i.push({ kind: "line", expected: n.line });
  const o = it(t.rows, s);
  for (const l of t.columns) {
    const p = e.cells[l] ?? "";
    l in n.changes
      ? p.trim()
        ? Q(p, n.changes[l]) || i.push({ kind: "value", name: l })
        : i.push({ kind: "missing", name: l })
      : p.trim() &&
        !(l in o && Q(p, o[l])) &&
        i.push({ kind: "early", name: l });
  }
  return (
    n.output === null
      ? e.output.trim() && i.push({ kind: "extra-output" })
      : Q(e.output, n.output) || i.push({ kind: "output" }),
    i
  );
}
function at(e, t) {
  return t < e.rows.length ? [{ kind: "not-ended" }] : [];
}
const A = (e) => String(e).padStart(2, "0");
function ct(e, t, s) {
  const n = t.rows[s];
  switch (e.kind) {
    case "line":
      return `This row happens on line ${A(e.expected)}.`;
    case "missing":
      return `${e.name} changes on line ${A(n.line)}, so its new value goes in this row.`;
    case "value":
      return `${e.name} becomes ${N(n.changes[e.name])} on line ${A(n.line)}.`;
    case "early":
      return `${e.name} does not change on line ${A(n.line)}. Fill a variable in only on the line that assigns it.`;
    case "extra-output":
      return `Line ${A(n.line)} outputs nothing, so the output box stays blank.`;
    case "output":
      return `Line ${A(n.line)} outputs ${n.output}.`;
    case "not-ended":
      return `The program has not finished: line ${A(n.line)} runs next.`;
    case "ended":
      return "The program has already finished. An extra row would lose the mark.";
  }
}
function V(e) {
  let t = 0;
  for (; e.rows[t]?.given;) t += 1;
  return t;
}
function lt(e, t, s) {
  if (s === 0) return "Out of lives";
  const n = t ? e / t : 0;
  return n === 1
    ? "Full marks"
    : n >= 0.8
      ? "Sharp tracer"
      : n >= 0.5
        ? "Getting there"
        : "Keep tracing";
}
const S = "#060b1a",
  F = "#0c1530",
  xe = "#16224a",
  ge = "#243366",
  be = "#3a4c86",
  de = "#8f9cc8",
  X = "#cdd5f0",
  Z = "#ffffff",
  q = "#2dd4bf",
  ue = "#0f766e",
  dt = "#99f6e4",
  B = "#f472b6",
  ut = "#9d174d",
  L = "#fbbf24",
  he = "#92400e",
  ye = "#34d399",
  je = "#fb7185",
  ht = "#b9a4f6",
  G = "#6f55c9",
  $e = {
    tickets: { glow: L, deep: he },
    scores: { glow: q, deep: ue },
    door: { glow: B, deep: ut },
    prizes: { glow: L, deep: he },
    lockers: { glow: q, deep: ue },
  };
function ft({ machine: e, w: t, h: s }) {
  const { glow: n } = $e[e],
    i = { fontFamily: "ui-monospace, monospace", fontWeight: 700 };
  switch (e) {
    case "tickets":
      return r.jsx("text", {
        x: t / 2,
        y: s * 0.62,
        textAnchor: "middle",
        fill: n,
        fontSize: s * 0.36,
        style: i,
        children: "x3",
      });
    case "scores":
      return r.jsx("text", {
        x: t / 2,
        y: s * 0.64,
        textAnchor: "middle",
        fill: n,
        fontSize: s * 0.42,
        style: i,
        children: "0042",
      });
    case "door":
      return r.jsx("text", {
        x: t / 2,
        y: s * 0.7,
        textAnchor: "middle",
        fill: n,
        fontSize: s * 0.5,
        style: i,
        children: "****",
      });
    case "prizes":
      return r.jsxs("g", {
        children: [
          r.jsx("circle", { cx: t * 0.28, cy: s * 0.55, r: s * 0.2, fill: B }),
          r.jsx("rect", {
            x: t * 0.45,
            y: s * 0.32,
            width: s * 0.4,
            height: s * 0.42,
            rx: 4,
            fill: q,
          }),
          r.jsx("path", {
            d: `M${t * 0.72} ${s * 0.75} l${s * 0.2} ${-s * 0.45} l${s * 0.2} ${s * 0.45} z`,
            fill: L,
          }),
        ],
      });
    case "lockers":
      return r.jsx("text", {
        x: t / 2,
        y: s * 0.64,
        textAnchor: "middle",
        fill: n,
        fontSize: s * 0.42,
        style: i,
        children: "4 0 7",
      });
  }
}
function pt({ state: e, cx: t, cy: s, r: n }) {
  if (e === "idle") return null;
  const i = e === "cleared" ? ye : je;
  return r.jsxs("g", {
    "data-machine-mark": e,
    children: [
      r.jsx("circle", {
        cx: t,
        cy: s,
        r: n,
        fill: S,
        stroke: i,
        strokeWidth: n * 0.16,
      }),
      e === "cleared"
        ? r.jsx("path", {
            d: `M${t - n * 0.45} ${s} l${n * 0.3} ${n * 0.32} l${n * 0.6} ${-n * 0.62}`,
            fill: "none",
            stroke: i,
            strokeWidth: n * 0.2,
            strokeLinecap: "round",
            strokeLinejoin: "round",
          })
        : r.jsx("path", {
            d: `M${t - n * 0.38} ${s - n * 0.38} l${n * 0.76} ${n * 0.76} M${t + n * 0.38} ${s - n * 0.38} l${-n * 0.76} ${n * 0.76}`,
            stroke: i,
            strokeWidth: n * 0.2,
            strokeLinecap: "round",
          }),
    ],
  });
}
function P({ machine: e, state: t = "idle", x: s, y: n, w: i }) {
  const o = i * 1.7,
    { glow: l, deep: p } = $e[e],
    c = { x: i * 0.14, y: o * 0.18, w: i * 0.72, h: o * 0.24 },
    d = t === "jammed" ? je : t === "cleared" ? ye : l;
  return r.jsxs("g", {
    transform: `translate(${s} ${n})`,
    "data-cabinet": e,
    "data-cabinet-state": t,
    children: [
      r.jsx("ellipse", {
        cx: i / 2,
        cy: o + i * 0.04,
        rx: i * 0.62,
        ry: i * 0.08,
        fill: S,
        opacity: 0.7,
      }),
      r.jsx("path", {
        d: `M0 ${o * 0.08} Q0 0 ${i * 0.08} 0 H${i * 0.92} Q${i} 0 ${i} ${o * 0.08} V${o} H0 Z`,
        fill: ge,
      }),
      r.jsx("rect", {
        x: i * 0.06,
        y: o * 0.03,
        width: i * 0.88,
        height: o * 0.09,
        rx: i * 0.04,
        fill: p,
      }),
      r.jsx("rect", {
        x: i * 0.1,
        y: o * 0.055,
        width: i * 0.8,
        height: o * 0.04,
        rx: i * 0.02,
        fill: d,
        opacity: 0.85,
      }),
      r.jsx("rect", {
        x: c.x - 6,
        y: c.y - 6,
        width: c.w + 12,
        height: c.h + 12,
        rx: 10,
        fill: F,
      }),
      r.jsxs("svg", {
        x: c.x,
        y: c.y,
        width: c.w,
        height: c.h,
        viewBox: `0 0 ${c.w} ${c.h}`,
        children: [
          r.jsx("rect", { width: c.w, height: c.h, rx: 6, fill: S }),
          r.jsx(ft, { machine: e, w: c.w, h: c.h }),
        ],
      }),
      r.jsx("rect", {
        x: i * 0.08,
        y: o * 0.5,
        width: i * 0.84,
        height: o * 0.12,
        rx: 8,
        fill: be,
      }),
      e === "door" || e === "lockers"
        ? Array.from({ length: 6 }, (h, x) =>
            r.jsx(
              "rect",
              {
                x: i * 0.2 + (x % 3) * i * 0.22,
                y: o * 0.515 + Math.floor(x / 3) * o * 0.05,
                width: i * 0.16,
                height: o * 0.035,
                rx: 4,
                fill: X,
              },
              x,
            ),
          )
        : r.jsxs(r.Fragment, {
            children: [
              r.jsx("circle", {
                cx: i * 0.3,
                cy: o * 0.56,
                r: i * 0.07,
                fill: B,
              }),
              r.jsx("circle", {
                cx: i * 0.5,
                cy: o * 0.56,
                r: i * 0.07,
                fill: q,
              }),
              r.jsx("circle", {
                cx: i * 0.7,
                cy: o * 0.56,
                r: i * 0.07,
                fill: L,
              }),
            ],
          }),
      r.jsx("rect", {
        x: i * 0.3,
        y: o * 0.7,
        width: i * 0.4,
        height: o * 0.05,
        rx: 4,
        fill: F,
      }),
      e === "tickets"
        ? r.jsx("path", {
            d: `M${i * 0.36} ${o * 0.74} h${i * 0.28} v${o * 0.12} l${-i * 0.05} ${o * 0.02} l${-i * 0.05} ${-o * 0.02} l${-i * 0.08} ${o * 0.02} l${-i * 0.1} ${-o * 0.02} z`,
            fill: L,
          })
        : null,
      r.jsx("rect", {
        x: i * 0.1,
        y: o * 0.9,
        width: i * 0.8,
        height: o * 0.04,
        rx: 4,
        fill: xe,
      }),
      r.jsx(pt, { state: t, cx: i * 0.84, cy: o * 0.16, r: i * 0.13 }),
    ],
  });
}
function ke({ x: e, y: t, size: s }) {
  const n = s;
  return r.jsxs("g", {
    transform: `translate(${e} ${t})`,
    "data-creature": !0,
    children: [
      r.jsx("ellipse", {
        cx: 0,
        cy: n * 0.98,
        rx: n * 0.55,
        ry: n * 0.08,
        fill: S,
        opacity: 0.6,
      }),
      r.jsx("path", {
        d: `M${-n * 0.32} ${-n * 0.42} l${-n * 0.1} ${-n * 0.32} l${n * 0.26} ${n * 0.18} z`,
        fill: G,
      }),
      r.jsx("path", {
        d: `M${n * 0.32} ${-n * 0.42} l${n * 0.1} ${-n * 0.32} l${-n * 0.26} ${n * 0.18} z`,
        fill: G,
      }),
      r.jsx("ellipse", {
        cx: 0,
        cy: n * 0.2,
        rx: n * 0.52,
        ry: n * 0.72,
        fill: ht,
      }),
      r.jsx("ellipse", {
        cx: 0,
        cy: n * 0.42,
        rx: n * 0.32,
        ry: n * 0.4,
        fill: X,
        opacity: 0.55,
      }),
      r.jsx("circle", { cx: -n * 0.18, cy: -n * 0.12, r: n * 0.11, fill: Z }),
      r.jsx("circle", { cx: n * 0.18, cy: -n * 0.12, r: n * 0.11, fill: Z }),
      r.jsx("circle", { cx: -n * 0.16, cy: -n * 0.1, r: n * 0.055, fill: S }),
      r.jsx("circle", { cx: n * 0.2, cy: -n * 0.1, r: n * 0.055, fill: S }),
      r.jsx("path", {
        d: `M${-n * 0.08} ${n * 0.06} q${n * 0.08} ${n * 0.07} ${n * 0.16} 0`,
        stroke: S,
        strokeWidth: n * 0.03,
        fill: "none",
        strokeLinecap: "round",
      }),
      r.jsxs("g", {
        transform: `translate(${n * 0.12} ${n * 0.28}) rotate(-8)`,
        children: [
          r.jsx("rect", {
            x: 0,
            y: 0,
            width: n * 0.5,
            height: n * 0.62,
            rx: n * 0.04,
            fill: be,
          }),
          r.jsx("rect", {
            x: n * 0.04,
            y: n * 0.06,
            width: n * 0.42,
            height: n * 0.52,
            fill: Z,
          }),
          Array.from({ length: 5 }, (i, o) =>
            r.jsx(
              "path",
              {
                d: `M${n * 0.06} ${n * (0.15 + o * 0.09)} h${n * 0.38}`,
                stroke: de,
                strokeWidth: n * 0.012,
              },
              o,
            ),
          ),
          r.jsx("path", {
            d: `M${n * 0.16} ${n * 0.08} v${n * 0.48} M${n * 0.3} ${n * 0.08} v${n * 0.48}`,
            stroke: de,
            strokeWidth: n * 0.012,
          }),
          r.jsx("rect", {
            x: n * 0.17,
            y: -n * 0.03,
            width: n * 0.16,
            height: n * 0.07,
            rx: n * 0.02,
            fill: L,
          }),
        ],
      }),
      r.jsx("ellipse", {
        cx: -n * 0.24,
        cy: n * 0.9,
        rx: n * 0.14,
        ry: n * 0.08,
        fill: G,
      }),
      r.jsx("ellipse", {
        cx: n * 0.24,
        cy: n * 0.9,
        rx: n * 0.14,
        ry: n * 0.08,
        fill: G,
      }),
    ],
  });
}
function we({ w: e, h: t, children: s }) {
  return r.jsxs(r.Fragment, {
    children: [
      r.jsx("defs", {
        children: r.jsxs("linearGradient", {
          id: "lbl-wall",
          x1: "0",
          y1: "0",
          x2: "0",
          y2: "1",
          children: [
            r.jsx("stop", { offset: "0", stopColor: S }),
            r.jsx("stop", { offset: "1", stopColor: xe }),
          ],
        }),
      }),
      r.jsx("rect", { width: e, height: t, fill: "url(#lbl-wall)" }),
      r.jsx("rect", { y: t * 0.72, width: e, height: t * 0.28, fill: F }),
      Array.from({ length: 12 }, (n, i) =>
        r.jsx(
          "path",
          {
            d: `M${(e / 11) * i} ${t * 0.72} L${(e / 11) * i * 1.4 - e * 0.2} ${t}`,
            stroke: ge,
            strokeWidth: 2,
          },
          i,
        ),
      ),
      Array.from({ length: 40 }, (n, i) =>
        r.jsx(
          "circle",
          {
            cx: (i * 397) % e,
            cy: ((i * 131) % (t * 0.4)) + 8,
            r: i % 3 === 0 ? 2.2 : 1.4,
            fill: X,
            opacity: 0.35,
          },
          i,
        ),
      ),
      s,
    ],
  });
}
function ve({ x: e, y: t, size: s }) {
  return r.jsxs("g", {
    "data-arcade-sign": !0,
    children: [
      r.jsx("rect", {
        x: e - s * 4.4,
        y: t - s * 1.05,
        width: s * 8.8,
        height: s * 1.5,
        rx: s * 0.3,
        fill: F,
        stroke: B,
        strokeWidth: s * 0.08,
      }),
      r.jsx("text", {
        x: e,
        y: t,
        textAnchor: "middle",
        fill: dt,
        fontSize: s,
        fontWeight: 800,
        style: {
          fontFamily: "ui-monospace, monospace",
          letterSpacing: "0.08em",
        },
        children: "LINE BY LINE",
      }),
    ],
  });
}
function mt() {
  return r.jsx("svg", {
    className: "game-landing-art game-landing-landscape",
    viewBox: "0 0 1600 900",
    preserveAspectRatio: "xMidYMid slice",
    width: "100%",
    "aria-hidden": "true",
    children: r.jsxs(we, {
      w: 1600,
      h: 900,
      children: [
        r.jsx(ve, { x: 1600 / 2, y: 170, size: 78 }),
        r.jsx(P, { machine: "tickets", x: 170, y: 300, w: 230 }),
        r.jsx(P, { machine: "scores", x: 460, y: 270, w: 250 }),
        r.jsx(P, { machine: "door", x: 950, y: 290, w: 230 }),
        r.jsx(P, { machine: "lockers", x: 1230, y: 310, w: 220 }),
        r.jsx(ke, { x: 820, y: 560, size: 130 }),
      ],
    }),
  });
}
function xt() {
  return r.jsx("svg", {
    className: "game-landing-art game-landing-portrait",
    viewBox: "0 0 900 1600",
    preserveAspectRatio: "xMidYMid slice",
    width: "100%",
    "aria-hidden": "true",
    children: r.jsxs(we, {
      w: 900,
      h: 1600,
      children: [
        r.jsx(ve, { x: 900 / 2, y: 260, size: 80 }),
        r.jsx(P, { machine: "scores", x: 90, y: 460, w: 300 }),
        r.jsx(P, { machine: "door", x: 510, y: 480, w: 290 }),
        r.jsx(ke, { x: 450, y: 1080, size: 170 }),
      ],
    }),
  });
}
function gt() {
  return r.jsxs(r.Fragment, { children: [r.jsx(xt, {}), r.jsx(mt, {})] });
}
function Ne({ machine: e, state: t }) {
  return r.jsxs("svg", {
    viewBox: "0 0 200 220",
    width: "100%",
    className: "lbl-machine-art",
    role: "img",
    "aria-label": t === "idle" ? void 0 : t === "cleared" ? "Traced" : "Jammed",
    "aria-hidden": t === "idle" ? !0 : void 0,
    "data-machine-art": e,
    "data-machine-state": t,
    children: [
      r.jsx("rect", { width: 200, height: 220, rx: 16, fill: F }),
      r.jsx("rect", { y: 170, width: 200, height: 50, fill: S }),
      r.jsx(P, { machine: e, state: t, x: 50, y: 14, w: 100 }),
    ],
  });
}
const D = `inline-flex min-h-11 items-center justify-center gap-2 rounded-lg px-5 py-2.5 text-sm font-bold transition disabled:cursor-not-allowed disabled:opacity-40 focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-300 ${Fe}`,
  bt =
    "inline-flex min-h-11 items-center justify-center gap-2 rounded-lg border border-[#3a4c86] px-5 py-2.5 text-sm font-bold text-[#cdd5f0] transition hover:bg-[#16224a] focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-300",
  z = () => ({ line: "", cells: {}, output: "" });
function It({ random: e } = {}) {
  const [t, s] = j.useState(0),
    n = j.useMemo(() => rt(e), [t, e]),
    [i, o] = j.useState("landing"),
    [l, p] = j.useState(0),
    [c, d] = j.useState(() => V(n[0].trace)),
    [h, x] = j.useState(K),
    [a, m] = j.useState(0),
    [v, T] = j.useState(0),
    [w, U] = j.useState(null),
    [I, W] = j.useState(!1),
    [M, _] = j.useState(z),
    [Ee, ee] = j.useState(() => new Set()),
    te = j.useRef(null),
    J = j.useRef(null),
    ne = j.useRef(null),
    $ = n[l],
    se = i === "finished" && h > 0 ? n.length : l + (I ? 1 : 0);
  (ze(se, n.length, n.length - Ee.size),
    j.useEffect(() => {
      i === "playing" && te.current?.focus();
    }, [i, l]));
  function Ae(f) {
    (p(f), d(V(n[f].trace)), U(null), W(!1), _(z()));
  }
  function Se() {
    (s((f) => f + 1),
      x(K),
      m(0),
      T(0),
      ee(new Set()),
      o("playing"),
      p(0),
      U(null),
      W(!1),
      _(z()));
  }
  j.useEffect(() => {
    d(V(n[0].trace));
  }, [n]);
  function re(f) {
    return (
      T((b) => b + 1),
      f.length
        ? (x((b) => b - 1),
          ee((b) => (b.has(l) ? b : new Set(b).add(l))),
          U({ index: c, mistakes: f }),
          requestAnimationFrame(() => ne.current?.focus({ preventScroll: !1 })),
          !1)
        : (m((b) => b + 1), !0)
    );
  }
  function Te(f) {
    (f.preventDefault(),
      !(w || I) &&
        re(ot(M, $.trace, c)) &&
        (d((b) => b + 1),
        _(z()),
        requestAnimationFrame(() => J.current?.focus({ preventScroll: !0 }))));
  }
  function Ie() {
    w || I || (re(at($.trace, c)) && W(!0));
  }
  function Me() {
    if (!w) return;
    const f = w.mistakes.some((b) => b.kind === "ended");
    if ((U(null), _(z()), h <= 0)) {
      o("finished");
      return;
    }
    f
      ? W(!0)
      : (d((b) => b + 1),
        requestAnimationFrame(() => J.current?.focus({ preventScroll: !0 })));
  }
  function Oe() {
    l + 1 >= n.length ? o("finished") : Ae(l + 1);
  }
  if (i === "landing")
    return r.jsx("div", {
      className: "line-by-line",
      "data-line-by-line": !0,
      children: r.jsxs("div", {
        className: "game-landing",
        style: { "--landing-glow": "rgba(244, 114, 182, 0.5)" },
        "data-game-landing": !0,
        "data-lbl-card": "landing",
        children: [
          r.jsx(gt, {}),
          r.jsx("h2", {
            className: "sr-only",
            children: "The arcade after dark",
          }),
          r.jsxs("button", {
            type: "button",
            className: `game-landing-start ${D}`,
            onClick: () => o("playing"),
            children: [
              r.jsx(Le, { "aria-hidden": "true", className: "h-5 w-5" }),
              "Start tracing",
            ],
          }),
        ],
      }),
    });
  if (i === "finished")
    return r.jsx("div", {
      className: "line-by-line",
      "data-line-by-line": !0,
      children: r.jsxs(r.Fragment, {
        children: [
          r.jsx(vt, {
            right: a,
            marked: v,
            lives: h,
            reached: se,
            total: n.length,
            onAgain: Se,
          }),
          r.jsx(De, { game: "line-by-line" }),
        ],
      }),
    });
  const _e = Ye[$.machine],
    H = $.trace.rows.slice(0, w ? w.index + 1 : c),
    Re = w ? "jammed" : I ? "cleared" : "idle",
    Pe = H[H.length - 1]?.line;
  return r.jsx("div", {
    className: "line-by-line",
    "data-line-by-line": !0,
    children: r.jsxs("div", {
      className: "lbl-play space-y-4",
      "data-lbl-card": "round",
      "data-lbl-round": $.id,
      "data-lbl-stage": $.stage,
      children: [
        r.jsxs("div", {
          className: "flex items-center justify-between gap-3",
          children: [
            r.jsx(yt, { index: l, total: n.length, traced: I }),
            r.jsx(jt, { lives: h }),
          ],
        }),
        r.jsxs("div", {
          className: "lbl-layout",
          children: [
            r.jsxs("section", {
              className: "lbl-program space-y-3",
              "aria-labelledby": "lbl-heading",
              children: [
                r.jsxs("div", {
                  className: "flex items-center gap-3",
                  children: [
                    r.jsx("div", {
                      className: "w-16 shrink-0 sm:w-20",
                      children: r.jsx(Ne, { machine: $.machine, state: Re }),
                    }),
                    r.jsxs("div", {
                      className: "min-w-0",
                      children: [
                        r.jsx("h2", {
                          ref: te,
                          id: "lbl-heading",
                          tabIndex: -1,
                          className: "lbl-title focus:outline-none",
                          children: _e.name,
                        }),
                        r.jsx("p", {
                          className: "lbl-brief",
                          children: $.brief,
                        }),
                      ],
                    }),
                  ],
                }),
                $.arrays ? r.jsx(kt, { arrays: $.arrays }) : null,
                r.jsx($t, { source: $.source, style: $.style, lastLine: Pe }),
              ],
            }),
            r.jsxs("section", {
              className: "lbl-table-wrap space-y-3",
              "aria-label": "Trace table",
              children: [
                r.jsxs("form", {
                  onSubmit: Te,
                  className: "space-y-3",
                  children: [
                    r.jsxs("table", {
                      className: "lbl-table",
                      "data-lbl-table": !0,
                      children: [
                        r.jsx("thead", {
                          children: r.jsxs("tr", {
                            children: [
                              r.jsx("th", { scope: "col", children: "Line" }),
                              $.trace.columns.map((f) =>
                                r.jsx("th", { scope: "col", children: f }, f),
                              ),
                              r.jsx("th", { scope: "col", children: "Output" }),
                            ],
                          }),
                        }),
                        r.jsxs("tbody", {
                          children: [
                            H.map((f, b) =>
                              r.jsx(
                                wt,
                                {
                                  row: f,
                                  columns: $.trace.columns,
                                  tone:
                                    w && b === w.index
                                      ? "fix"
                                      : f.given
                                        ? "given"
                                        : "done",
                                },
                                b,
                              ),
                            ),
                            !w && !I
                              ? r.jsxs("tr", {
                                  "data-lbl-entry": !0,
                                  children: [
                                    r.jsx("td", {
                                      children: r.jsx("input", {
                                        ref: J,
                                        className: "lbl-input",
                                        inputMode: "numeric",
                                        autoComplete: "off",
                                        "aria-label": "Line number",
                                        value: M.line,
                                        onChange: (f) =>
                                          _({ ...M, line: f.target.value }),
                                      }),
                                    }),
                                    $.trace.columns.map((f) =>
                                      r.jsx(
                                        "td",
                                        {
                                          children: r.jsx("input", {
                                            className: "lbl-input",
                                            autoComplete: "off",
                                            autoCapitalize: "off",
                                            spellCheck: !1,
                                            "aria-label": f,
                                            value: M.cells[f] ?? "",
                                            onChange: (b) =>
                                              _({
                                                ...M,
                                                cells: {
                                                  ...M.cells,
                                                  [f]: b.target.value,
                                                },
                                              }),
                                          }),
                                        },
                                        f,
                                      ),
                                    ),
                                    r.jsx("td", {
                                      children: r.jsx("input", {
                                        className: "lbl-input",
                                        autoComplete: "off",
                                        autoCapitalize: "off",
                                        spellCheck: !1,
                                        "aria-label": "Output",
                                        value: M.output,
                                        onChange: (f) =>
                                          _({ ...M, output: f.target.value }),
                                      }),
                                    }),
                                  ],
                                })
                              : null,
                          ],
                        }),
                      ],
                    }),
                    !w && !I
                      ? r.jsxs("div", {
                          className: "grid grid-cols-2 gap-2",
                          children: [
                            r.jsx("button", {
                              type: "submit",
                              className: D,
                              "data-lbl-add": !0,
                              children: "Add row",
                            }),
                            r.jsx("button", {
                              type: "button",
                              className: bt,
                              onClick: Ie,
                              "data-lbl-end": !0,
                              children: "Program ends",
                            }),
                          ],
                        })
                      : null,
                  ],
                }),
                w
                  ? r.jsxs("div", {
                      className: "lbl-verdict space-y-3",
                      role: "status",
                      "data-lbl-card": "mistake",
                      children: [
                        r.jsxs("p", {
                          className: "lbl-verdict-title text-[#fb7185]",
                          children: [
                            r.jsx(fe, {
                              "aria-hidden": "true",
                              className: "h-5 w-5",
                            }),
                            h > 0 ? "Life lost" : "Out of lives",
                          ],
                        }),
                        r.jsx("p", {
                          className: "text-[#cdd5f0]",
                          children: ct(w.mistakes[0], $.trace, w.index),
                        }),
                        r.jsx("button", {
                          ref: ne,
                          type: "button",
                          className: `w-full ${D}`,
                          onClick: Me,
                          children: h > 0 ? "Continue" : "See score",
                        }),
                      ],
                    })
                  : null,
                I
                  ? r.jsxs("div", {
                      className: "lbl-verdict space-y-3",
                      role: "status",
                      "data-lbl-card": "traced",
                      children: [
                        r.jsx("p", {
                          className: "lbl-verdict-title text-[#34d399]",
                          children: "Program traced",
                        }),
                        r.jsx("button", {
                          type: "button",
                          className: `w-full ${D}`,
                          onClick: Oe,
                          autoFocus: !0,
                          children:
                            l + 1 >= n.length ? "See score" : "Next program",
                        }),
                      ],
                    })
                  : null,
              ],
            }),
          ],
        }),
      ],
    }),
  });
}
function yt({ index: e, total: t, traced: s }) {
  return r.jsxs("div", {
    className: "flex items-center gap-2",
    "data-lbl-progress": !0,
    children: [
      r.jsx("span", {
        className: "sr-only",
        children: `Program ${e + 1} of ${t}: ${Y[e].name}`,
      }),
      Y.slice(0, t).map((n, i) => {
        const o =
          i < e || (i === e && s) ? "done" : i === e ? "active" : "pending";
        return r.jsx(
          "span",
          { "aria-hidden": "true", className: "lbl-dot", "data-lbl-dot": o },
          n.id,
        );
      }),
    ],
  });
}
function jt({ lives: e }) {
  return r.jsxs("div", {
    className: "flex items-center gap-1",
    "data-lbl-lives": e,
    children: [
      r.jsx("span", {
        className: "sr-only",
        children: `${e} ${e === 1 ? "life" : "lives"} left`,
      }),
      Array.from({ length: K }, (t, s) =>
        r.jsx(
          fe,
          {
            "aria-hidden": "true",
            className: `h-6 w-6 ${s < e ? "fill-[#fb7185] text-[#fb7185]" : "text-[#3a4c86]"}`,
          },
          s,
        ),
      ),
    ],
  });
}
function $t({ source: e, style: t, lastLine: s }) {
  return r.jsx("pre", {
    className: "lbl-listing",
    "data-lbl-listing": t,
    "aria-label": "Program",
    children: e
      .split(
        `
`,
      )
      .map((n, i) =>
        r.jsxs(
          "span",
          {
            className: "lbl-code-line",
            "data-lbl-last": s === i + 1 ? "true" : void 0,
            children: [
              r.jsx("span", {
                className: "lbl-line-number",
                children: A(i + 1),
              }),
              r.jsx("code", { children: n }),
            ],
          },
          i,
        ),
      ),
  });
}
function kt({ arrays: e }) {
  return r.jsx("div", {
    className: "space-y-2",
    children: Object.entries(e).map(([t, s]) =>
      r.jsxs(
        "table",
        {
          className: "lbl-array",
          "data-lbl-array": t,
          children: [
            r.jsx("caption", { children: t }),
            r.jsxs("tbody", {
              children: [
                r.jsxs("tr", {
                  children: [
                    r.jsx("th", { scope: "row", children: "Index" }),
                    s.map((n, i) => r.jsx("td", { children: i }, i)),
                  ],
                }),
                r.jsxs("tr", {
                  children: [
                    r.jsx("th", { scope: "row", children: "Data" }),
                    s.map((n, i) => r.jsx("td", { children: String(n) }, i)),
                  ],
                }),
              ],
            }),
          ],
        },
        t,
      ),
    ),
  });
}
function wt({ row: e, columns: t, tone: s }) {
  return r.jsxs("tr", {
    "data-lbl-row": s,
    children: [
      r.jsx("td", { children: A(e.line) }),
      t.map((n) =>
        r.jsx("td", { children: n in e.changes ? N(e.changes[n]) : "" }, n),
      ),
      r.jsx("td", { children: e.output ?? "" }),
    ],
  });
}
function vt({
  right: e,
  marked: t,
  lives: s,
  reached: n,
  total: i,
  onAgain: o,
}) {
  return r.jsxs("div", {
    className: "lbl-summary space-y-5 text-center",
    "aria-live": "polite",
    "data-game-finished": !0,
    "data-lbl-card": "summary",
    children: [
      r.jsx("div", {
        className: "mx-auto w-28",
        children: r.jsx(Ne, {
          machine: "scores",
          state: s > 0 ? "cleared" : "jammed",
        }),
      }),
      r.jsx("h2", {
        className: "lbl-rank",
        "data-lbl-rank": !0,
        children: lt(e, t, s),
      }),
      r.jsxs("p", { className: "lbl-score", children: [e, "/", t] }),
      r.jsxs("p", {
        className: "text-[#cdd5f0]",
        children: [n, " of ", i, " programs traced."],
      }),
      r.jsxs("button", {
        type: "button",
        className: D,
        onClick: o,
        children: [
          r.jsx(Ce, { "aria-hidden": "true", className: "h-4 w-4" }),
          "New programs",
        ],
      }),
    ],
  });
}
export { It as default };
