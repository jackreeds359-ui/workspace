import {
  r as i,
  R as Se,
  j as v,
  a as Zt,
  b as qt,
} from "./react-vendor-BK1G6oO1.js";
function Te(e, t) {
  if (typeof e == "function") return e(t);
  e != null && (e.current = t);
}
function Ee(...e) {
  return (t) => {
    let r = !1;
    const n = e.map((o) => {
      const a = Te(o, t);
      return (!r && typeof a == "function" && (r = !0), a);
    });
    if (r)
      return () => {
        for (let o = 0; o < n.length; o++) {
          const a = n[o];
          typeof a == "function" ? a() : Te(e[o], null);
        }
      };
  };
}
function T(...e) {
  return i.useCallback(Ee(...e), e);
}
var Qt = Symbol.for("react.lazy"),
  re = Se[" use ".trim().toString()];
function Jt(e) {
  return typeof e == "object" && e !== null && "then" in e;
}
function He(e) {
  return (
    e != null &&
    typeof e == "object" &&
    "$$typeof" in e &&
    e.$$typeof === Qt &&
    "_payload" in e &&
    Jt(e._payload)
  );
}
function Ve(e) {
  const t = er(e),
    r = i.forwardRef((n, o) => {
      let { children: a, ...c } = n;
      He(a) && typeof re == "function" && (a = re(a._payload));
      const s = i.Children.toArray(a),
        u = s.find(rr);
      if (u) {
        const l = u.props.children,
          d = s.map((f) =>
            f === u
              ? i.Children.count(l) > 1
                ? i.Children.only(null)
                : i.isValidElement(l)
                  ? l.props.children
                  : null
              : f,
          );
        return v.jsx(t, {
          ...c,
          ref: o,
          children: i.isValidElement(l) ? i.cloneElement(l, void 0, d) : null,
        });
      }
      return v.jsx(t, { ...c, ref: o, children: a });
    });
  return ((r.displayName = `${e}.Slot`), r);
}
var wo = Ve("Slot");
function er(e) {
  const t = i.forwardRef((r, n) => {
    let { children: o, ...a } = r;
    if (
      (He(o) && typeof re == "function" && (o = re(o._payload)),
      i.isValidElement(o))
    ) {
      const c = or(o),
        s = nr(a, o.props);
      return (
        o.type !== i.Fragment && (s.ref = n ? Ee(n, c) : c),
        i.cloneElement(o, s)
      );
    }
    return i.Children.count(o) > 1 ? i.Children.only(null) : null;
  });
  return ((t.displayName = `${e}.SlotClone`), t);
}
var tr = Symbol("radix.slottable");
function rr(e) {
  return (
    i.isValidElement(e) &&
    typeof e.type == "function" &&
    "__radixId" in e.type &&
    e.type.__radixId === tr
  );
}
function nr(e, t) {
  const r = { ...t };
  for (const n in t) {
    const o = e[n],
      a = t[n];
    /^on[A-Z]/.test(n)
      ? o && a
        ? (r[n] = (...s) => {
            const u = a(...s);
            return (o(...s), u);
          })
        : o && (r[n] = o)
      : n === "style"
        ? (r[n] = { ...o, ...a })
        : n === "className" && (r[n] = [o, a].filter(Boolean).join(" "));
  }
  return { ...e, ...r };
}
function or(e) {
  let t = Object.getOwnPropertyDescriptor(e.props, "ref")?.get,
    r = t && "isReactWarning" in t && t.isReactWarning;
  return r
    ? e.ref
    : ((t = Object.getOwnPropertyDescriptor(e, "ref")?.get),
      (r = t && "isReactWarning" in t && t.isReactWarning),
      r ? e.props.ref : e.props.ref || e.ref);
}
var ar = [
    "a",
    "button",
    "div",
    "form",
    "h2",
    "h3",
    "img",
    "input",
    "label",
    "li",
    "nav",
    "ol",
    "p",
    "select",
    "span",
    "svg",
    "ul",
  ],
  ir = ar.reduce((e, t) => {
    const r = Ve(`Primitive.${t}`),
      n = i.forwardRef((o, a) => {
        const { asChild: c, ...s } = o,
          u = c ? r : t;
        return (
          typeof window < "u" && (window[Symbol.for("radix-ui")] = !0),
          v.jsx(u, { ...s, ref: a })
        );
      });
    return ((n.displayName = `Primitive.${t}`), { ...e, [t]: n });
  }, {}),
  sr = "Label",
  ze = i.forwardRef((e, t) =>
    v.jsx(ir.label, {
      ...e,
      ref: t,
      onMouseDown: (r) => {
        r.target.closest("button, input, select, textarea") ||
          (e.onMouseDown?.(r),
          !r.defaultPrevented && r.detail > 1 && r.preventDefault());
      },
    }),
  );
ze.displayName = sr;
var Co = ze;
function cr(e, t) {
  const r = i.createContext(t),
    n = (a) => {
      const { children: c, ...s } = a,
        u = i.useMemo(() => s, Object.values(s));
      return v.jsx(r.Provider, { value: u, children: c });
    };
  n.displayName = e + "Provider";
  function o(a) {
    const c = i.useContext(r);
    if (c) return c;
    if (t !== void 0) return t;
    throw new Error(`\`${a}\` must be used within \`${e}\``);
  }
  return [n, o];
}
function we(e, t = []) {
  let r = [];
  function n(a, c) {
    const s = i.createContext(c),
      u = r.length;
    r = [...r, c];
    const l = (f) => {
      const { scope: p, children: m, ...y } = f,
        h = p?.[e]?.[u] || s,
        g = i.useMemo(() => y, Object.values(y));
      return v.jsx(h.Provider, { value: g, children: m });
    };
    l.displayName = a + "Provider";
    function d(f, p) {
      const m = p?.[e]?.[u] || s,
        y = i.useContext(m);
      if (y) return y;
      if (c !== void 0) return c;
      throw new Error(`\`${f}\` must be used within \`${a}\``);
    }
    return [l, d];
  }
  const o = () => {
    const a = r.map((c) => i.createContext(c));
    return function (s) {
      const u = s?.[e] || a;
      return i.useMemo(() => ({ [`__scope${e}`]: { ...s, [e]: u } }), [s, u]);
    };
  };
  return ((o.scopeName = e), [n, lr(o, ...t)]);
}
function lr(...e) {
  const t = e[0];
  if (e.length === 1) return t;
  const r = () => {
    const n = e.map((o) => ({ useScope: o(), scopeName: o.scopeName }));
    return function (a) {
      const c = n.reduce((s, { useScope: u, scopeName: l }) => {
        const f = u(a)[`__scope${l}`];
        return { ...s, ...f };
      }, {});
      return i.useMemo(() => ({ [`__scope${t.scopeName}`]: c }), [c]);
    };
  };
  return ((r.scopeName = t.scopeName), r);
}
function A(e, t, { checkForDefaultPrevented: r = !0 } = {}) {
  return function (o) {
    if ((e?.(o), r === !1 || !o.defaultPrevented)) return t?.(o);
  };
}
var X = globalThis?.document ? i.useLayoutEffect : () => {},
  ur = Se[" useId ".trim().toString()] || (() => {}),
  dr = 0;
function ue(e) {
  const [t, r] = i.useState(ur());
  return (
    X(() => {
      r((n) => n ?? String(dr++));
    }, [e]),
    e || (t ? `radix-${t}` : "")
  );
}
var fr = Se[" useInsertionEffect ".trim().toString()] || X;
function vr({ prop: e, defaultProp: t, onChange: r = () => {}, caller: n }) {
  const [o, a, c] = pr({ defaultProp: t, onChange: r }),
    s = e !== void 0,
    u = s ? e : o;
  {
    const d = i.useRef(e !== void 0);
    i.useEffect(() => {
      const f = d.current;
      (f !== s &&
        console.warn(
          `${n} is changing from ${f ? "controlled" : "uncontrolled"} to ${s ? "controlled" : "uncontrolled"}. Components should not switch from controlled to uncontrolled (or vice versa). Decide between using a controlled or uncontrolled value for the lifetime of the component.`,
        ),
        (d.current = s));
    }, [s, n]);
  }
  const l = i.useCallback(
    (d) => {
      if (s) {
        const f = hr(d) ? d(e) : d;
        f !== e && c.current?.(f);
      } else a(d);
    },
    [s, e, a, c],
  );
  return [u, l];
}
function pr({ defaultProp: e, onChange: t }) {
  const [r, n] = i.useState(e),
    o = i.useRef(r),
    a = i.useRef(t);
  return (
    fr(() => {
      a.current = t;
    }, [t]),
    i.useEffect(() => {
      o.current !== r && (a.current?.(r), (o.current = r));
    }, [r, o]),
    [r, n, a]
  );
}
function hr(e) {
  return typeof e == "function";
}
function Ye(e) {
  const t = mr(e),
    r = i.forwardRef((n, o) => {
      const { children: a, ...c } = n,
        s = i.Children.toArray(a),
        u = s.find(br);
      if (u) {
        const l = u.props.children,
          d = s.map((f) =>
            f === u
              ? i.Children.count(l) > 1
                ? i.Children.only(null)
                : i.isValidElement(l)
                  ? l.props.children
                  : null
              : f,
          );
        return v.jsx(t, {
          ...c,
          ref: o,
          children: i.isValidElement(l) ? i.cloneElement(l, void 0, d) : null,
        });
      }
      return v.jsx(t, { ...c, ref: o, children: a });
    });
  return ((r.displayName = `${e}.Slot`), r);
}
function mr(e) {
  const t = i.forwardRef((r, n) => {
    const { children: o, ...a } = r;
    if (i.isValidElement(o)) {
      const c = Sr(o),
        s = yr(a, o.props);
      return (
        o.type !== i.Fragment && (s.ref = n ? Ee(n, c) : c),
        i.cloneElement(o, s)
      );
    }
    return i.Children.count(o) > 1 ? i.Children.only(null) : null;
  });
  return ((t.displayName = `${e}.SlotClone`), t);
}
var Xe = Symbol("radix.slottable");
function gr(e) {
  const t = ({ children: r }) => v.jsx(v.Fragment, { children: r });
  return ((t.displayName = `${e}.Slottable`), (t.__radixId = Xe), t);
}
function br(e) {
  return (
    i.isValidElement(e) &&
    typeof e.type == "function" &&
    "__radixId" in e.type &&
    e.type.__radixId === Xe
  );
}
function yr(e, t) {
  const r = { ...t };
  for (const n in t) {
    const o = e[n],
      a = t[n];
    /^on[A-Z]/.test(n)
      ? o && a
        ? (r[n] = (...s) => {
            const u = a(...s);
            return (o(...s), u);
          })
        : o && (r[n] = o)
      : n === "style"
        ? (r[n] = { ...o, ...a })
        : n === "className" && (r[n] = [o, a].filter(Boolean).join(" "));
  }
  return { ...e, ...r };
}
function Sr(e) {
  let t = Object.getOwnPropertyDescriptor(e.props, "ref")?.get,
    r = t && "isReactWarning" in t && t.isReactWarning;
  return r
    ? e.ref
    : ((t = Object.getOwnPropertyDescriptor(e, "ref")?.get),
      (r = t && "isReactWarning" in t && t.isReactWarning),
      r ? e.props.ref : e.props.ref || e.ref);
}
var Er = [
    "a",
    "button",
    "div",
    "form",
    "h2",
    "h3",
    "img",
    "input",
    "label",
    "li",
    "nav",
    "ol",
    "p",
    "select",
    "span",
    "svg",
    "ul",
  ],
  O = Er.reduce((e, t) => {
    const r = Ye(`Primitive.${t}`),
      n = i.forwardRef((o, a) => {
        const { asChild: c, ...s } = o,
          u = c ? r : t;
        return (
          typeof window < "u" && (window[Symbol.for("radix-ui")] = !0),
          v.jsx(u, { ...s, ref: a })
        );
      });
    return ((n.displayName = `Primitive.${t}`), { ...e, [t]: n });
  }, {});
function wr(e, t) {
  e && Zt.flushSync(() => e.dispatchEvent(t));
}
function _(e) {
  const t = i.useRef(e);
  return (
    i.useEffect(() => {
      t.current = e;
    }),
    i.useMemo(
      () =>
        (...r) =>
          t.current?.(...r),
      [],
    )
  );
}
function Cr(e, t = globalThis?.document) {
  const r = _(e);
  i.useEffect(() => {
    const n = (o) => {
      o.key === "Escape" && r(o);
    };
    return (
      t.addEventListener("keydown", n, { capture: !0 }),
      () => t.removeEventListener("keydown", n, { capture: !0 })
    );
  }, [r, t]);
}
var Pr = "DismissableLayer",
  be = "dismissableLayer.update",
  Rr = "dismissableLayer.pointerDownOutside",
  Ar = "dismissableLayer.focusOutside",
  Ne,
  Ke = i.createContext({
    layers: new Set(),
    layersWithOutsidePointerEventsDisabled: new Set(),
    branches: new Set(),
  }),
  Ge = i.forwardRef((e, t) => {
    const {
        disableOutsidePointerEvents: r = !1,
        onEscapeKeyDown: n,
        onPointerDownOutside: o,
        onFocusOutside: a,
        onInteractOutside: c,
        onDismiss: s,
        ...u
      } = e,
      l = i.useContext(Ke),
      [d, f] = i.useState(null),
      p = d?.ownerDocument ?? globalThis?.document,
      [, m] = i.useState({}),
      y = T(t, (S) => f(S)),
      h = Array.from(l.layers),
      [g] = [...l.layersWithOutsidePointerEventsDisabled].slice(-1),
      b = h.indexOf(g),
      E = d ? h.indexOf(d) : -1,
      C = l.layersWithOutsidePointerEventsDisabled.size > 0,
      w = E >= b,
      P = Tr((S) => {
        const N = S.target,
          R = [...l.branches].some((D) => D.contains(N));
        !w || R || (o?.(S), c?.(S), S.defaultPrevented || s?.());
      }, p),
      x = Nr((S) => {
        const N = S.target;
        [...l.branches].some((D) => D.contains(N)) ||
          (a?.(S), c?.(S), S.defaultPrevented || s?.());
      }, p);
    return (
      Cr((S) => {
        E === l.layers.size - 1 &&
          (n?.(S), !S.defaultPrevented && s && (S.preventDefault(), s()));
      }, p),
      i.useEffect(() => {
        if (d)
          return (
            r &&
              (l.layersWithOutsidePointerEventsDisabled.size === 0 &&
                ((Ne = p.body.style.pointerEvents),
                (p.body.style.pointerEvents = "none")),
              l.layersWithOutsidePointerEventsDisabled.add(d)),
            l.layers.add(d),
            Oe(),
            () => {
              r &&
                l.layersWithOutsidePointerEventsDisabled.size === 1 &&
                (p.body.style.pointerEvents = Ne);
            }
          );
      }, [d, p, r, l]),
      i.useEffect(
        () => () => {
          d &&
            (l.layers.delete(d),
            l.layersWithOutsidePointerEventsDisabled.delete(d),
            Oe());
        },
        [d, l],
      ),
      i.useEffect(() => {
        const S = () => m({});
        return (
          document.addEventListener(be, S),
          () => document.removeEventListener(be, S)
        );
      }, []),
      v.jsx(O.div, {
        ...u,
        ref: y,
        style: {
          pointerEvents: C ? (w ? "auto" : "none") : void 0,
          ...e.style,
        },
        onFocusCapture: A(e.onFocusCapture, x.onFocusCapture),
        onBlurCapture: A(e.onBlurCapture, x.onBlurCapture),
        onPointerDownCapture: A(e.onPointerDownCapture, P.onPointerDownCapture),
      })
    );
  });
Ge.displayName = Pr;
var xr = "DismissableLayerBranch",
  Dr = i.forwardRef((e, t) => {
    const r = i.useContext(Ke),
      n = i.useRef(null),
      o = T(t, n);
    return (
      i.useEffect(() => {
        const a = n.current;
        if (a)
          return (
            r.branches.add(a),
            () => {
              r.branches.delete(a);
            }
          );
      }, [r.branches]),
      v.jsx(O.div, { ...e, ref: o })
    );
  });
Dr.displayName = xr;
function Tr(e, t = globalThis?.document) {
  const r = _(e),
    n = i.useRef(!1),
    o = i.useRef(() => {});
  return (
    i.useEffect(() => {
      const a = (s) => {
          if (s.target && !n.current) {
            let u = function () {
              Ze(Rr, r, l, { discrete: !0 });
            };
            const l = { originalEvent: s };
            s.pointerType === "touch"
              ? (t.removeEventListener("click", o.current),
                (o.current = u),
                t.addEventListener("click", o.current, { once: !0 }))
              : u();
          } else t.removeEventListener("click", o.current);
          n.current = !1;
        },
        c = window.setTimeout(() => {
          t.addEventListener("pointerdown", a);
        }, 0);
      return () => {
        (window.clearTimeout(c),
          t.removeEventListener("pointerdown", a),
          t.removeEventListener("click", o.current));
      };
    }, [t, r]),
    { onPointerDownCapture: () => (n.current = !0) }
  );
}
function Nr(e, t = globalThis?.document) {
  const r = _(e),
    n = i.useRef(!1);
  return (
    i.useEffect(() => {
      const o = (a) => {
        a.target &&
          !n.current &&
          Ze(Ar, r, { originalEvent: a }, { discrete: !1 });
      };
      return (
        t.addEventListener("focusin", o),
        () => t.removeEventListener("focusin", o)
      );
    }, [t, r]),
    {
      onFocusCapture: () => (n.current = !0),
      onBlurCapture: () => (n.current = !1),
    }
  );
}
function Oe() {
  const e = new CustomEvent(be);
  document.dispatchEvent(e);
}
function Ze(e, t, r, { discrete: n }) {
  const o = r.originalEvent.target,
    a = new CustomEvent(e, { bubbles: !1, cancelable: !0, detail: r });
  (t && o.addEventListener(e, t, { once: !0 }),
    n ? wr(o, a) : o.dispatchEvent(a));
}
var de = "focusScope.autoFocusOnMount",
  fe = "focusScope.autoFocusOnUnmount",
  _e = { bubbles: !1, cancelable: !0 },
  Or = "FocusScope",
  qe = i.forwardRef((e, t) => {
    const {
        loop: r = !1,
        trapped: n = !1,
        onMountAutoFocus: o,
        onUnmountAutoFocus: a,
        ...c
      } = e,
      [s, u] = i.useState(null),
      l = _(o),
      d = _(a),
      f = i.useRef(null),
      p = T(t, (h) => u(h)),
      m = i.useRef({
        paused: !1,
        pause() {
          this.paused = !0;
        },
        resume() {
          this.paused = !1;
        },
      }).current;
    (i.useEffect(() => {
      if (n) {
        let h = function (C) {
            if (m.paused || !s) return;
            const w = C.target;
            s.contains(w) ? (f.current = w) : W(f.current, { select: !0 });
          },
          g = function (C) {
            if (m.paused || !s) return;
            const w = C.relatedTarget;
            w !== null && (s.contains(w) || W(f.current, { select: !0 }));
          },
          b = function (C) {
            if (document.activeElement === document.body)
              for (const P of C) P.removedNodes.length > 0 && W(s);
          };
        (document.addEventListener("focusin", h),
          document.addEventListener("focusout", g));
        const E = new MutationObserver(b);
        return (
          s && E.observe(s, { childList: !0, subtree: !0 }),
          () => {
            (document.removeEventListener("focusin", h),
              document.removeEventListener("focusout", g),
              E.disconnect());
          }
        );
      }
    }, [n, s, m.paused]),
      i.useEffect(() => {
        if (s) {
          Ie.add(m);
          const h = document.activeElement;
          if (!s.contains(h)) {
            const b = new CustomEvent(de, _e);
            (s.addEventListener(de, l),
              s.dispatchEvent(b),
              b.defaultPrevented ||
                (_r(Fr(Qe(s)), { select: !0 }),
                document.activeElement === h && W(s)));
          }
          return () => {
            (s.removeEventListener(de, l),
              setTimeout(() => {
                const b = new CustomEvent(fe, _e);
                (s.addEventListener(fe, d),
                  s.dispatchEvent(b),
                  b.defaultPrevented || W(h ?? document.body, { select: !0 }),
                  s.removeEventListener(fe, d),
                  Ie.remove(m));
              }, 0));
          };
        }
      }, [s, l, d, m]));
    const y = i.useCallback(
      (h) => {
        if ((!r && !n) || m.paused) return;
        const g = h.key === "Tab" && !h.altKey && !h.ctrlKey && !h.metaKey,
          b = document.activeElement;
        if (g && b) {
          const E = h.currentTarget,
            [C, w] = Lr(E);
          C && w
            ? !h.shiftKey && b === w
              ? (h.preventDefault(), r && W(C, { select: !0 }))
              : h.shiftKey &&
                b === C &&
                (h.preventDefault(), r && W(w, { select: !0 }))
            : b === E && h.preventDefault();
        }
      },
      [r, n, m.paused],
    );
    return v.jsx(O.div, { tabIndex: -1, ...c, ref: p, onKeyDown: y });
  });
qe.displayName = Or;
function _r(e, { select: t = !1 } = {}) {
  const r = document.activeElement;
  for (const n of e)
    if ((W(n, { select: t }), document.activeElement !== r)) return;
}
function Lr(e) {
  const t = Qe(e),
    r = Le(t, e),
    n = Le(t.reverse(), e);
  return [r, n];
}
function Qe(e) {
  const t = [],
    r = document.createTreeWalker(e, NodeFilter.SHOW_ELEMENT, {
      acceptNode: (n) => {
        const o = n.tagName === "INPUT" && n.type === "hidden";
        return n.disabled || n.hidden || o
          ? NodeFilter.FILTER_SKIP
          : n.tabIndex >= 0
            ? NodeFilter.FILTER_ACCEPT
            : NodeFilter.FILTER_SKIP;
      },
    });
  for (; r.nextNode();) t.push(r.currentNode);
  return t;
}
function Le(e, t) {
  for (const r of e) if (!Ir(r, { upTo: t })) return r;
}
function Ir(e, { upTo: t }) {
  if (getComputedStyle(e).visibility === "hidden") return !0;
  for (; e;) {
    if (t !== void 0 && e === t) return !1;
    if (getComputedStyle(e).display === "none") return !0;
    e = e.parentElement;
  }
  return !1;
}
function Mr(e) {
  return e instanceof HTMLInputElement && "select" in e;
}
function W(e, { select: t = !1 } = {}) {
  if (e && e.focus) {
    const r = document.activeElement;
    (e.focus({ preventScroll: !0 }), e !== r && Mr(e) && t && e.select());
  }
}
var Ie = jr();
function jr() {
  let e = [];
  return {
    add(t) {
      const r = e[0];
      (t !== r && r?.pause(), (e = Me(e, t)), e.unshift(t));
    },
    remove(t) {
      ((e = Me(e, t)), e[0]?.resume());
    },
  };
}
function Me(e, t) {
  const r = [...e],
    n = r.indexOf(t);
  return (n !== -1 && r.splice(n, 1), r);
}
function Fr(e) {
  return e.filter((t) => t.tagName !== "A");
}
var Wr = "Portal",
  Je = i.forwardRef((e, t) => {
    const { container: r, ...n } = e,
      [o, a] = i.useState(!1);
    X(() => a(!0), []);
    const c = r || (o && globalThis?.document?.body);
    return c ? qt.createPortal(v.jsx(O.div, { ...n, ref: t }), c) : null;
  });
Je.displayName = Wr;
function kr(e, t) {
  return i.useReducer((r, n) => t[r][n] ?? r, e);
}
var k = (e) => {
  const { present: t, children: r } = e,
    n = $r(t),
    o =
      typeof r == "function" ? r({ present: n.isPresent }) : i.Children.only(r),
    a = T(n.ref, Br(o));
  return typeof r == "function" || n.isPresent
    ? i.cloneElement(o, { ref: a })
    : null;
};
k.displayName = "Presence";
function $r(e) {
  const [t, r] = i.useState(),
    n = i.useRef(null),
    o = i.useRef(e),
    a = i.useRef("none"),
    c = e ? "mounted" : "unmounted",
    [s, u] = kr(c, {
      mounted: { UNMOUNT: "unmounted", ANIMATION_OUT: "unmountSuspended" },
      unmountSuspended: { MOUNT: "mounted", ANIMATION_END: "unmounted" },
      unmounted: { MOUNT: "mounted" },
    });
  return (
    i.useEffect(() => {
      const l = G(n.current);
      a.current = s === "mounted" ? l : "none";
    }, [s]),
    X(() => {
      const l = n.current,
        d = o.current;
      if (d !== e) {
        const p = a.current,
          m = G(l);
        (e
          ? u("MOUNT")
          : m === "none" || l?.display === "none"
            ? u("UNMOUNT")
            : u(d && p !== m ? "ANIMATION_OUT" : "UNMOUNT"),
          (o.current = e));
      }
    }, [e, u]),
    X(() => {
      if (t) {
        let l;
        const d = t.ownerDocument.defaultView ?? window,
          f = (m) => {
            const h = G(n.current).includes(CSS.escape(m.animationName));
            if (m.target === t && h && (u("ANIMATION_END"), !o.current)) {
              const g = t.style.animationFillMode;
              ((t.style.animationFillMode = "forwards"),
                (l = d.setTimeout(() => {
                  t.style.animationFillMode === "forwards" &&
                    (t.style.animationFillMode = g);
                })));
            }
          },
          p = (m) => {
            m.target === t && (a.current = G(n.current));
          };
        return (
          t.addEventListener("animationstart", p),
          t.addEventListener("animationcancel", f),
          t.addEventListener("animationend", f),
          () => {
            (d.clearTimeout(l),
              t.removeEventListener("animationstart", p),
              t.removeEventListener("animationcancel", f),
              t.removeEventListener("animationend", f));
          }
        );
      } else u("ANIMATION_END");
    }, [t, u]),
    {
      isPresent: ["mounted", "unmountSuspended"].includes(s),
      ref: i.useCallback((l) => {
        ((n.current = l ? getComputedStyle(l) : null), r(l));
      }, []),
    }
  );
}
function G(e) {
  return e?.animationName || "none";
}
function Br(e) {
  let t = Object.getOwnPropertyDescriptor(e.props, "ref")?.get,
    r = t && "isReactWarning" in t && t.isReactWarning;
  return r
    ? e.ref
    : ((t = Object.getOwnPropertyDescriptor(e, "ref")?.get),
      (r = t && "isReactWarning" in t && t.isReactWarning),
      r ? e.props.ref : e.props.ref || e.ref);
}
var ve = 0;
function Ur() {
  i.useEffect(() => {
    const e = document.querySelectorAll("[data-radix-focus-guard]");
    return (
      document.body.insertAdjacentElement("afterbegin", e[0] ?? je()),
      document.body.insertAdjacentElement("beforeend", e[1] ?? je()),
      ve++,
      () => {
        (ve === 1 &&
          document
            .querySelectorAll("[data-radix-focus-guard]")
            .forEach((t) => t.remove()),
          ve--);
      }
    );
  }, []);
}
function je() {
  const e = document.createElement("span");
  return (
    e.setAttribute("data-radix-focus-guard", ""),
    (e.tabIndex = 0),
    (e.style.outline = "none"),
    (e.style.opacity = "0"),
    (e.style.position = "fixed"),
    (e.style.pointerEvents = "none"),
    e
  );
}
var M = function () {
  return (
    (M =
      Object.assign ||
      function (t) {
        for (var r, n = 1, o = arguments.length; n < o; n++) {
          r = arguments[n];
          for (var a in r)
            Object.prototype.hasOwnProperty.call(r, a) && (t[a] = r[a]);
        }
        return t;
      }),
    M.apply(this, arguments)
  );
};
function et(e, t) {
  var r = {};
  for (var n in e)
    Object.prototype.hasOwnProperty.call(e, n) &&
      t.indexOf(n) < 0 &&
      (r[n] = e[n]);
  if (e != null && typeof Object.getOwnPropertySymbols == "function")
    for (var o = 0, n = Object.getOwnPropertySymbols(e); o < n.length; o++)
      t.indexOf(n[o]) < 0 &&
        Object.prototype.propertyIsEnumerable.call(e, n[o]) &&
        (r[n[o]] = e[n[o]]);
  return r;
}
function Hr(e, t, r) {
  if (r || arguments.length === 2)
    for (var n = 0, o = t.length, a; n < o; n++)
      (a || !(n in t)) &&
        (a || (a = Array.prototype.slice.call(t, 0, n)), (a[n] = t[n]));
  return e.concat(a || Array.prototype.slice.call(t));
}
var ee = "right-scroll-bar-position",
  te = "width-before-scroll-bar",
  Vr = "with-scroll-bars-hidden",
  zr = "--removed-body-scroll-bar-size";
function pe(e, t) {
  return (typeof e == "function" ? e(t) : e && (e.current = t), e);
}
function Yr(e, t) {
  var r = i.useState(function () {
    return {
      value: e,
      callback: t,
      facade: {
        get current() {
          return r.value;
        },
        set current(n) {
          var o = r.value;
          o !== n && ((r.value = n), r.callback(n, o));
        },
      },
    };
  })[0];
  return ((r.callback = t), r.facade);
}
var Xr = typeof window < "u" ? i.useLayoutEffect : i.useEffect,
  Fe = new WeakMap();
function Kr(e, t) {
  var r = Yr(null, function (n) {
    return e.forEach(function (o) {
      return pe(o, n);
    });
  });
  return (
    Xr(
      function () {
        var n = Fe.get(r);
        if (n) {
          var o = new Set(n),
            a = new Set(e),
            c = r.current;
          (o.forEach(function (s) {
            a.has(s) || pe(s, null);
          }),
            a.forEach(function (s) {
              o.has(s) || pe(s, c);
            }));
        }
        Fe.set(r, e);
      },
      [e],
    ),
    r
  );
}
function Gr(e) {
  return e;
}
function Zr(e, t) {
  t === void 0 && (t = Gr);
  var r = [],
    n = !1,
    o = {
      read: function () {
        if (n)
          throw new Error(
            "Sidecar: could not `read` from an `assigned` medium. `read` could be used only with `useMedium`.",
          );
        return r.length ? r[r.length - 1] : e;
      },
      useMedium: function (a) {
        var c = t(a, n);
        return (
          r.push(c),
          function () {
            r = r.filter(function (s) {
              return s !== c;
            });
          }
        );
      },
      assignSyncMedium: function (a) {
        for (n = !0; r.length;) {
          var c = r;
          ((r = []), c.forEach(a));
        }
        r = {
          push: function (s) {
            return a(s);
          },
          filter: function () {
            return r;
          },
        };
      },
      assignMedium: function (a) {
        n = !0;
        var c = [];
        if (r.length) {
          var s = r;
          ((r = []), s.forEach(a), (c = r));
        }
        var u = function () {
            var d = c;
            ((c = []), d.forEach(a));
          },
          l = function () {
            return Promise.resolve().then(u);
          };
        (l(),
          (r = {
            push: function (d) {
              (c.push(d), l());
            },
            filter: function (d) {
              return ((c = c.filter(d)), r);
            },
          }));
      },
    };
  return o;
}
function qr(e) {
  e === void 0 && (e = {});
  var t = Zr(null);
  return ((t.options = M({ async: !0, ssr: !1 }, e)), t);
}
var tt = function (e) {
  var t = e.sideCar,
    r = et(e, ["sideCar"]);
  if (!t)
    throw new Error(
      "Sidecar: please provide `sideCar` property to import the right car",
    );
  var n = t.read();
  if (!n) throw new Error("Sidecar medium not found");
  return i.createElement(n, M({}, r));
};
tt.isSideCarExport = !0;
function Qr(e, t) {
  return (e.useMedium(t), tt);
}
var rt = qr(),
  he = function () {},
  ie = i.forwardRef(function (e, t) {
    var r = i.useRef(null),
      n = i.useState({
        onScrollCapture: he,
        onWheelCapture: he,
        onTouchMoveCapture: he,
      }),
      o = n[0],
      a = n[1],
      c = e.forwardProps,
      s = e.children,
      u = e.className,
      l = e.removeScrollBar,
      d = e.enabled,
      f = e.shards,
      p = e.sideCar,
      m = e.noRelative,
      y = e.noIsolation,
      h = e.inert,
      g = e.allowPinchZoom,
      b = e.as,
      E = b === void 0 ? "div" : b,
      C = e.gapMode,
      w = et(e, [
        "forwardProps",
        "children",
        "className",
        "removeScrollBar",
        "enabled",
        "shards",
        "sideCar",
        "noRelative",
        "noIsolation",
        "inert",
        "allowPinchZoom",
        "as",
        "gapMode",
      ]),
      P = p,
      x = Kr([r, t]),
      S = M(M({}, w), o);
    return i.createElement(
      i.Fragment,
      null,
      d &&
        i.createElement(P, {
          sideCar: rt,
          removeScrollBar: l,
          shards: f,
          noRelative: m,
          noIsolation: y,
          inert: h,
          setCallbacks: a,
          allowPinchZoom: !!g,
          lockRef: r,
          gapMode: C,
        }),
      c
        ? i.cloneElement(i.Children.only(s), M(M({}, S), { ref: x }))
        : i.createElement(E, M({}, S, { className: u, ref: x }), s),
    );
  });
ie.defaultProps = { enabled: !0, removeScrollBar: !0, inert: !1 };
ie.classNames = { fullWidth: te, zeroRight: ee };
var Jr = function () {
  if (typeof __webpack_nonce__ < "u") return __webpack_nonce__;
};
function en() {
  if (!document) return null;
  var e = document.createElement("style");
  e.type = "text/css";
  var t = Jr();
  return (t && e.setAttribute("nonce", t), e);
}
function tn(e, t) {
  e.styleSheet
    ? (e.styleSheet.cssText = t)
    : e.appendChild(document.createTextNode(t));
}
function rn(e) {
  var t = document.head || document.getElementsByTagName("head")[0];
  t.appendChild(e);
}
var nn = function () {
    var e = 0,
      t = null;
    return {
      add: function (r) {
        (e == 0 && (t = en()) && (tn(t, r), rn(t)), e++);
      },
      remove: function () {
        (e--,
          !e && t && (t.parentNode && t.parentNode.removeChild(t), (t = null)));
      },
    };
  },
  on = function () {
    var e = nn();
    return function (t, r) {
      i.useEffect(
        function () {
          return (
            e.add(t),
            function () {
              e.remove();
            }
          );
        },
        [t && r],
      );
    };
  },
  nt = function () {
    var e = on(),
      t = function (r) {
        var n = r.styles,
          o = r.dynamic;
        return (e(n, o), null);
      };
    return t;
  },
  an = { left: 0, top: 0, right: 0, gap: 0 },
  me = function (e) {
    return parseInt(e || "", 10) || 0;
  },
  sn = function (e) {
    var t = window.getComputedStyle(document.body),
      r = t[e === "padding" ? "paddingLeft" : "marginLeft"],
      n = t[e === "padding" ? "paddingTop" : "marginTop"],
      o = t[e === "padding" ? "paddingRight" : "marginRight"];
    return [me(r), me(n), me(o)];
  },
  cn = function (e) {
    if ((e === void 0 && (e = "margin"), typeof window > "u")) return an;
    var t = sn(e),
      r = document.documentElement.clientWidth,
      n = window.innerWidth;
    return {
      left: t[0],
      top: t[1],
      right: t[2],
      gap: Math.max(0, n - r + t[2] - t[0]),
    };
  },
  ln = nt(),
  z = "data-scroll-locked",
  un = function (e, t, r, n) {
    var o = e.left,
      a = e.top,
      c = e.right,
      s = e.gap;
    return (
      r === void 0 && (r = "margin"),
      `
  .`
        .concat(
          Vr,
          ` {
   overflow: hidden `,
        )
        .concat(
          n,
          `;
   padding-right: `,
        )
        .concat(s, "px ")
        .concat(
          n,
          `;
  }
  body[`,
        )
        .concat(
          z,
          `] {
    overflow: hidden `,
        )
        .concat(
          n,
          `;
    overscroll-behavior: contain;
    `,
        )
        .concat(
          [
            t && "position: relative ".concat(n, ";"),
            r === "margin" &&
              `
    padding-left: `
                .concat(
                  o,
                  `px;
    padding-top: `,
                )
                .concat(
                  a,
                  `px;
    padding-right: `,
                )
                .concat(
                  c,
                  `px;
    margin-left:0;
    margin-top:0;
    margin-right: `,
                )
                .concat(s, "px ")
                .concat(
                  n,
                  `;
    `,
                ),
            r === "padding" &&
              "padding-right: ".concat(s, "px ").concat(n, ";"),
          ]
            .filter(Boolean)
            .join(""),
          `
  }
  
  .`,
        )
        .concat(
          ee,
          ` {
    right: `,
        )
        .concat(s, "px ")
        .concat(
          n,
          `;
  }
  
  .`,
        )
        .concat(
          te,
          ` {
    margin-right: `,
        )
        .concat(s, "px ")
        .concat(
          n,
          `;
  }
  
  .`,
        )
        .concat(ee, " .")
        .concat(
          ee,
          ` {
    right: 0 `,
        )
        .concat(
          n,
          `;
  }
  
  .`,
        )
        .concat(te, " .")
        .concat(
          te,
          ` {
    margin-right: 0 `,
        )
        .concat(
          n,
          `;
  }
  
  body[`,
        )
        .concat(
          z,
          `] {
    `,
        )
        .concat(zr, ": ")
        .concat(
          s,
          `px;
  }
`,
        )
    );
  },
  We = function () {
    var e = parseInt(document.body.getAttribute(z) || "0", 10);
    return isFinite(e) ? e : 0;
  },
  dn = function () {
    i.useEffect(function () {
      return (
        document.body.setAttribute(z, (We() + 1).toString()),
        function () {
          var e = We() - 1;
          e <= 0
            ? document.body.removeAttribute(z)
            : document.body.setAttribute(z, e.toString());
        }
      );
    }, []);
  },
  fn = function (e) {
    var t = e.noRelative,
      r = e.noImportant,
      n = e.gapMode,
      o = n === void 0 ? "margin" : n;
    dn();
    var a = i.useMemo(
      function () {
        return cn(o);
      },
      [o],
    );
    return i.createElement(ln, { styles: un(a, !t, o, r ? "" : "!important") });
  },
  ye = !1;
if (typeof window < "u")
  try {
    var Z = Object.defineProperty({}, "passive", {
      get: function () {
        return ((ye = !0), !0);
      },
    });
    (window.addEventListener("test", Z, Z),
      window.removeEventListener("test", Z, Z));
  } catch {
    ye = !1;
  }
var U = ye ? { passive: !1 } : !1,
  vn = function (e) {
    return e.tagName === "TEXTAREA";
  },
  ot = function (e, t) {
    if (!(e instanceof Element)) return !1;
    var r = window.getComputedStyle(e);
    return (
      r[t] !== "hidden" &&
      !(r.overflowY === r.overflowX && !vn(e) && r[t] === "visible")
    );
  },
  pn = function (e) {
    return ot(e, "overflowY");
  },
  hn = function (e) {
    return ot(e, "overflowX");
  },
  ke = function (e, t) {
    var r = t.ownerDocument,
      n = t;
    do {
      typeof ShadowRoot < "u" && n instanceof ShadowRoot && (n = n.host);
      var o = at(e, n);
      if (o) {
        var a = it(e, n),
          c = a[1],
          s = a[2];
        if (c > s) return !0;
      }
      n = n.parentNode;
    } while (n && n !== r.body);
    return !1;
  },
  mn = function (e) {
    var t = e.scrollTop,
      r = e.scrollHeight,
      n = e.clientHeight;
    return [t, r, n];
  },
  gn = function (e) {
    var t = e.scrollLeft,
      r = e.scrollWidth,
      n = e.clientWidth;
    return [t, r, n];
  },
  at = function (e, t) {
    return e === "v" ? pn(t) : hn(t);
  },
  it = function (e, t) {
    return e === "v" ? mn(t) : gn(t);
  },
  bn = function (e, t) {
    return e === "h" && t === "rtl" ? -1 : 1;
  },
  yn = function (e, t, r, n, o) {
    var a = bn(e, window.getComputedStyle(t).direction),
      c = a * n,
      s = r.target,
      u = t.contains(s),
      l = !1,
      d = c > 0,
      f = 0,
      p = 0;
    do {
      if (!s) break;
      var m = it(e, s),
        y = m[0],
        h = m[1],
        g = m[2],
        b = h - g - a * y;
      (y || b) && at(e, s) && ((f += b), (p += y));
      var E = s.parentNode;
      s = E && E.nodeType === Node.DOCUMENT_FRAGMENT_NODE ? E.host : E;
    } while ((!u && s !== document.body) || (u && (t.contains(s) || t === s)));
    return (((d && Math.abs(f) < 1) || (!d && Math.abs(p) < 1)) && (l = !0), l);
  },
  q = function (e) {
    return "changedTouches" in e
      ? [e.changedTouches[0].clientX, e.changedTouches[0].clientY]
      : [0, 0];
  },
  $e = function (e) {
    return [e.deltaX, e.deltaY];
  },
  Be = function (e) {
    return e && "current" in e ? e.current : e;
  },
  Sn = function (e, t) {
    return e[0] === t[0] && e[1] === t[1];
  },
  En = function (e) {
    return `
  .block-interactivity-`
      .concat(
        e,
        ` {pointer-events: none;}
  .allow-interactivity-`,
      )
      .concat(
        e,
        ` {pointer-events: all;}
`,
      );
  },
  wn = 0,
  H = [];
function Cn(e) {
  var t = i.useRef([]),
    r = i.useRef([0, 0]),
    n = i.useRef(),
    o = i.useState(wn++)[0],
    a = i.useState(nt)[0],
    c = i.useRef(e);
  (i.useEffect(
    function () {
      c.current = e;
    },
    [e],
  ),
    i.useEffect(
      function () {
        if (e.inert) {
          document.body.classList.add("block-interactivity-".concat(o));
          var h = Hr([e.lockRef.current], (e.shards || []).map(Be), !0).filter(
            Boolean,
          );
          return (
            h.forEach(function (g) {
              return g.classList.add("allow-interactivity-".concat(o));
            }),
            function () {
              (document.body.classList.remove("block-interactivity-".concat(o)),
                h.forEach(function (g) {
                  return g.classList.remove("allow-interactivity-".concat(o));
                }));
            }
          );
        }
      },
      [e.inert, e.lockRef.current, e.shards],
    ));
  var s = i.useCallback(function (h, g) {
      if (
        ("touches" in h && h.touches.length === 2) ||
        (h.type === "wheel" && h.ctrlKey)
      )
        return !c.current.allowPinchZoom;
      var b = q(h),
        E = r.current,
        C = "deltaX" in h ? h.deltaX : E[0] - b[0],
        w = "deltaY" in h ? h.deltaY : E[1] - b[1],
        P,
        x = h.target,
        S = Math.abs(C) > Math.abs(w) ? "h" : "v";
      if ("touches" in h && S === "h" && x.type === "range") return !1;
      var N = ke(S, x);
      if (!N) return !0;
      if ((N ? (P = S) : ((P = S === "v" ? "h" : "v"), (N = ke(S, x))), !N))
        return !1;
      if (
        (!n.current && "changedTouches" in h && (C || w) && (n.current = P), !P)
      )
        return !0;
      var R = n.current || P;
      return yn(R, g, h, R === "h" ? C : w);
    }, []),
    u = i.useCallback(function (h) {
      var g = h;
      if (!(!H.length || H[H.length - 1] !== a)) {
        var b = "deltaY" in g ? $e(g) : q(g),
          E = t.current.filter(function (P) {
            return (
              P.name === g.type &&
              (P.target === g.target || g.target === P.shadowParent) &&
              Sn(P.delta, b)
            );
          })[0];
        if (E && E.should) {
          g.cancelable && g.preventDefault();
          return;
        }
        if (!E) {
          var C = (c.current.shards || [])
              .map(Be)
              .filter(Boolean)
              .filter(function (P) {
                return P.contains(g.target);
              }),
            w = C.length > 0 ? s(g, C[0]) : !c.current.noIsolation;
          w && g.cancelable && g.preventDefault();
        }
      }
    }, []),
    l = i.useCallback(function (h, g, b, E) {
      var C = { name: h, delta: g, target: b, should: E, shadowParent: Pn(b) };
      (t.current.push(C),
        setTimeout(function () {
          t.current = t.current.filter(function (w) {
            return w !== C;
          });
        }, 1));
    }, []),
    d = i.useCallback(function (h) {
      ((r.current = q(h)), (n.current = void 0));
    }, []),
    f = i.useCallback(function (h) {
      l(h.type, $e(h), h.target, s(h, e.lockRef.current));
    }, []),
    p = i.useCallback(function (h) {
      l(h.type, q(h), h.target, s(h, e.lockRef.current));
    }, []);
  i.useEffect(function () {
    return (
      H.push(a),
      e.setCallbacks({
        onScrollCapture: f,
        onWheelCapture: f,
        onTouchMoveCapture: p,
      }),
      document.addEventListener("wheel", u, U),
      document.addEventListener("touchmove", u, U),
      document.addEventListener("touchstart", d, U),
      function () {
        ((H = H.filter(function (h) {
          return h !== a;
        })),
          document.removeEventListener("wheel", u, U),
          document.removeEventListener("touchmove", u, U),
          document.removeEventListener("touchstart", d, U));
      }
    );
  }, []);
  var m = e.removeScrollBar,
    y = e.inert;
  return i.createElement(
    i.Fragment,
    null,
    y ? i.createElement(a, { styles: En(o) }) : null,
    m
      ? i.createElement(fn, { noRelative: e.noRelative, gapMode: e.gapMode })
      : null,
  );
}
function Pn(e) {
  for (var t = null; e !== null;)
    (e instanceof ShadowRoot && ((t = e.host), (e = e.host)),
      (e = e.parentNode));
  return t;
}
const Rn = Qr(rt, Cn);
var st = i.forwardRef(function (e, t) {
  return i.createElement(ie, M({}, e, { ref: t, sideCar: Rn }));
});
st.classNames = ie.classNames;
var An = function (e) {
    if (typeof document > "u") return null;
    var t = Array.isArray(e) ? e[0] : e;
    return t.ownerDocument.body;
  },
  V = new WeakMap(),
  Q = new WeakMap(),
  J = {},
  ge = 0,
  ct = function (e) {
    return e && (e.host || ct(e.parentNode));
  },
  xn = function (e, t) {
    return t
      .map(function (r) {
        if (e.contains(r)) return r;
        var n = ct(r);
        return n && e.contains(n)
          ? n
          : (console.error(
              "aria-hidden",
              r,
              "in not contained inside",
              e,
              ". Doing nothing",
            ),
            null);
      })
      .filter(function (r) {
        return !!r;
      });
  },
  Dn = function (e, t, r, n) {
    var o = xn(t, Array.isArray(e) ? e : [e]);
    J[r] || (J[r] = new WeakMap());
    var a = J[r],
      c = [],
      s = new Set(),
      u = new Set(o),
      l = function (f) {
        !f || s.has(f) || (s.add(f), l(f.parentNode));
      };
    o.forEach(l);
    var d = function (f) {
      !f ||
        u.has(f) ||
        Array.prototype.forEach.call(f.children, function (p) {
          if (s.has(p)) d(p);
          else
            try {
              var m = p.getAttribute(n),
                y = m !== null && m !== "false",
                h = (V.get(p) || 0) + 1,
                g = (a.get(p) || 0) + 1;
              (V.set(p, h),
                a.set(p, g),
                c.push(p),
                h === 1 && y && Q.set(p, !0),
                g === 1 && p.setAttribute(r, "true"),
                y || p.setAttribute(n, "true"));
            } catch (b) {
              console.error("aria-hidden: cannot operate on ", p, b);
            }
        });
    };
    return (
      d(t),
      s.clear(),
      ge++,
      function () {
        (c.forEach(function (f) {
          var p = V.get(f) - 1,
            m = a.get(f) - 1;
          (V.set(f, p),
            a.set(f, m),
            p || (Q.has(f) || f.removeAttribute(n), Q.delete(f)),
            m || f.removeAttribute(r));
        }),
          ge--,
          ge ||
            ((V = new WeakMap()),
            (V = new WeakMap()),
            (Q = new WeakMap()),
            (J = {})));
      }
    );
  },
  Tn = function (e, t, r) {
    r === void 0 && (r = "data-aria-hidden");
    var n = Array.from(Array.isArray(e) ? e : [e]),
      o = An(e);
    return o
      ? (n.push.apply(n, Array.from(o.querySelectorAll("[aria-live], script"))),
        Dn(n, o, r, "aria-hidden"))
      : function () {
          return null;
        };
  },
  se = "Dialog",
  [lt, ut] = we(se),
  [Nn, I] = lt(se),
  dt = (e) => {
    const {
        __scopeDialog: t,
        children: r,
        open: n,
        defaultOpen: o,
        onOpenChange: a,
        modal: c = !0,
      } = e,
      s = i.useRef(null),
      u = i.useRef(null),
      [l, d] = vr({ prop: n, defaultProp: o ?? !1, onChange: a, caller: se });
    return v.jsx(Nn, {
      scope: t,
      triggerRef: s,
      contentRef: u,
      contentId: ue(),
      titleId: ue(),
      descriptionId: ue(),
      open: l,
      onOpenChange: d,
      onOpenToggle: i.useCallback(() => d((f) => !f), [d]),
      modal: c,
      children: r,
    });
  };
dt.displayName = se;
var ft = "DialogTrigger",
  vt = i.forwardRef((e, t) => {
    const { __scopeDialog: r, ...n } = e,
      o = I(ft, r),
      a = T(t, o.triggerRef);
    return v.jsx(O.button, {
      type: "button",
      "aria-haspopup": "dialog",
      "aria-expanded": o.open,
      "aria-controls": o.contentId,
      "data-state": Re(o.open),
      ...n,
      ref: a,
      onClick: A(e.onClick, o.onOpenToggle),
    });
  });
vt.displayName = ft;
var Ce = "DialogPortal",
  [On, pt] = lt(Ce, { forceMount: void 0 }),
  ht = (e) => {
    const { __scopeDialog: t, forceMount: r, children: n, container: o } = e,
      a = I(Ce, t);
    return v.jsx(On, {
      scope: t,
      forceMount: r,
      children: i.Children.map(n, (c) =>
        v.jsx(k, {
          present: r || a.open,
          children: v.jsx(Je, { asChild: !0, container: o, children: c }),
        }),
      ),
    });
  };
ht.displayName = Ce;
var ne = "DialogOverlay",
  mt = i.forwardRef((e, t) => {
    const r = pt(ne, e.__scopeDialog),
      { forceMount: n = r.forceMount, ...o } = e,
      a = I(ne, e.__scopeDialog);
    return a.modal
      ? v.jsx(k, {
          present: n || a.open,
          children: v.jsx(Ln, { ...o, ref: t }),
        })
      : null;
  });
mt.displayName = ne;
var _n = Ye("DialogOverlay.RemoveScroll"),
  Ln = i.forwardRef((e, t) => {
    const { __scopeDialog: r, ...n } = e,
      o = I(ne, r);
    return v.jsx(st, {
      as: _n,
      allowPinchZoom: !0,
      shards: [o.contentRef],
      children: v.jsx(O.div, {
        "data-state": Re(o.open),
        ...n,
        ref: t,
        style: { pointerEvents: "auto", ...n.style },
      }),
    });
  }),
  $ = "DialogContent",
  gt = i.forwardRef((e, t) => {
    const r = pt($, e.__scopeDialog),
      { forceMount: n = r.forceMount, ...o } = e,
      a = I($, e.__scopeDialog);
    return v.jsx(k, {
      present: n || a.open,
      children: a.modal
        ? v.jsx(In, { ...o, ref: t })
        : v.jsx(Mn, { ...o, ref: t }),
    });
  });
gt.displayName = $;
var In = i.forwardRef((e, t) => {
    const r = I($, e.__scopeDialog),
      n = i.useRef(null),
      o = T(t, r.contentRef, n);
    return (
      i.useEffect(() => {
        const a = n.current;
        if (a) return Tn(a);
      }, []),
      v.jsx(bt, {
        ...e,
        ref: o,
        trapFocus: r.open,
        disableOutsidePointerEvents: !0,
        onCloseAutoFocus: A(e.onCloseAutoFocus, (a) => {
          (a.preventDefault(), r.triggerRef.current?.focus());
        }),
        onPointerDownOutside: A(e.onPointerDownOutside, (a) => {
          const c = a.detail.originalEvent,
            s = c.button === 0 && c.ctrlKey === !0;
          (c.button === 2 || s) && a.preventDefault();
        }),
        onFocusOutside: A(e.onFocusOutside, (a) => a.preventDefault()),
      })
    );
  }),
  Mn = i.forwardRef((e, t) => {
    const r = I($, e.__scopeDialog),
      n = i.useRef(!1),
      o = i.useRef(!1);
    return v.jsx(bt, {
      ...e,
      ref: t,
      trapFocus: !1,
      disableOutsidePointerEvents: !1,
      onCloseAutoFocus: (a) => {
        (e.onCloseAutoFocus?.(a),
          a.defaultPrevented ||
            (n.current || r.triggerRef.current?.focus(), a.preventDefault()),
          (n.current = !1),
          (o.current = !1));
      },
      onInteractOutside: (a) => {
        (e.onInteractOutside?.(a),
          a.defaultPrevented ||
            ((n.current = !0),
            a.detail.originalEvent.type === "pointerdown" && (o.current = !0)));
        const c = a.target;
        (r.triggerRef.current?.contains(c) && a.preventDefault(),
          a.detail.originalEvent.type === "focusin" &&
            o.current &&
            a.preventDefault());
      },
    });
  }),
  bt = i.forwardRef((e, t) => {
    const {
        __scopeDialog: r,
        trapFocus: n,
        onOpenAutoFocus: o,
        onCloseAutoFocus: a,
        ...c
      } = e,
      s = I($, r),
      u = i.useRef(null),
      l = T(t, u);
    return (
      Ur(),
      v.jsxs(v.Fragment, {
        children: [
          v.jsx(qe, {
            asChild: !0,
            loop: !0,
            trapped: n,
            onMountAutoFocus: o,
            onUnmountAutoFocus: a,
            children: v.jsx(Ge, {
              role: "dialog",
              id: s.contentId,
              "aria-describedby": s.descriptionId,
              "aria-labelledby": s.titleId,
              "data-state": Re(s.open),
              ...c,
              ref: l,
              onDismiss: () => s.onOpenChange(!1),
            }),
          }),
          v.jsxs(v.Fragment, {
            children: [
              v.jsx(Fn, { titleId: s.titleId }),
              v.jsx(kn, { contentRef: u, descriptionId: s.descriptionId }),
            ],
          }),
        ],
      })
    );
  }),
  Pe = "DialogTitle",
  yt = i.forwardRef((e, t) => {
    const { __scopeDialog: r, ...n } = e,
      o = I(Pe, r);
    return v.jsx(O.h2, { id: o.titleId, ...n, ref: t });
  });
yt.displayName = Pe;
var St = "DialogDescription",
  Et = i.forwardRef((e, t) => {
    const { __scopeDialog: r, ...n } = e,
      o = I(St, r);
    return v.jsx(O.p, { id: o.descriptionId, ...n, ref: t });
  });
Et.displayName = St;
var wt = "DialogClose",
  Ct = i.forwardRef((e, t) => {
    const { __scopeDialog: r, ...n } = e,
      o = I(wt, r);
    return v.jsx(O.button, {
      type: "button",
      ...n,
      ref: t,
      onClick: A(e.onClick, () => o.onOpenChange(!1)),
    });
  });
Ct.displayName = wt;
function Re(e) {
  return e ? "open" : "closed";
}
var Pt = "DialogTitleWarning",
  [jn, Rt] = cr(Pt, { contentName: $, titleName: Pe, docsSlug: "dialog" }),
  Fn = ({ titleId: e }) => {
    const t = Rt(Pt),
      r = `\`${t.contentName}\` requires a \`${t.titleName}\` for the component to be accessible for screen reader users.

If you want to hide the \`${t.titleName}\`, you can wrap it with our VisuallyHidden component.

For more information, see https://radix-ui.com/primitives/docs/components/${t.docsSlug}`;
    return (
      i.useEffect(() => {
        e && (document.getElementById(e) || console.error(r));
      }, [r, e]),
      null
    );
  },
  Wn = "DialogDescriptionWarning",
  kn = ({ contentRef: e, descriptionId: t }) => {
    const n = `Warning: Missing \`Description\` or \`aria-describedby={undefined}\` for {${Rt(Wn).contentName}}.`;
    return (
      i.useEffect(() => {
        const o = e.current?.getAttribute("aria-describedby");
        t && o && (document.getElementById(t) || console.warn(n));
      }, [n, e, t]),
      null
    );
  },
  $n = dt,
  Bn = vt,
  Un = ht,
  Hn = mt,
  Vn = gt,
  zn = yt,
  Yn = Et,
  At = Ct,
  xt = "AlertDialog",
  [Xn] = we(xt, [ut]),
  F = ut(),
  Dt = (e) => {
    const { __scopeAlertDialog: t, ...r } = e,
      n = F(t);
    return v.jsx($n, { ...n, ...r, modal: !0 });
  };
Dt.displayName = xt;
var Kn = "AlertDialogTrigger",
  Gn = i.forwardRef((e, t) => {
    const { __scopeAlertDialog: r, ...n } = e,
      o = F(r);
    return v.jsx(Bn, { ...o, ...n, ref: t });
  });
Gn.displayName = Kn;
var Zn = "AlertDialogPortal",
  Tt = (e) => {
    const { __scopeAlertDialog: t, ...r } = e,
      n = F(t);
    return v.jsx(Un, { ...n, ...r });
  };
Tt.displayName = Zn;
var qn = "AlertDialogOverlay",
  Nt = i.forwardRef((e, t) => {
    const { __scopeAlertDialog: r, ...n } = e,
      o = F(r);
    return v.jsx(Hn, { ...o, ...n, ref: t });
  });
Nt.displayName = qn;
var Y = "AlertDialogContent",
  [Qn, Jn] = Xn(Y),
  eo = gr("AlertDialogContent"),
  Ot = i.forwardRef((e, t) => {
    const { __scopeAlertDialog: r, children: n, ...o } = e,
      a = F(r),
      c = i.useRef(null),
      s = T(t, c),
      u = i.useRef(null);
    return v.jsx(jn, {
      contentName: Y,
      titleName: _t,
      docsSlug: "alert-dialog",
      children: v.jsx(Qn, {
        scope: r,
        cancelRef: u,
        children: v.jsxs(Vn, {
          role: "alertdialog",
          ...a,
          ...o,
          ref: s,
          onOpenAutoFocus: A(o.onOpenAutoFocus, (l) => {
            (l.preventDefault(), u.current?.focus({ preventScroll: !0 }));
          }),
          onPointerDownOutside: (l) => l.preventDefault(),
          onInteractOutside: (l) => l.preventDefault(),
          children: [v.jsx(eo, { children: n }), v.jsx(ro, { contentRef: c })],
        }),
      }),
    });
  });
Ot.displayName = Y;
var _t = "AlertDialogTitle",
  Lt = i.forwardRef((e, t) => {
    const { __scopeAlertDialog: r, ...n } = e,
      o = F(r);
    return v.jsx(zn, { ...o, ...n, ref: t });
  });
Lt.displayName = _t;
var It = "AlertDialogDescription",
  Mt = i.forwardRef((e, t) => {
    const { __scopeAlertDialog: r, ...n } = e,
      o = F(r);
    return v.jsx(Yn, { ...o, ...n, ref: t });
  });
Mt.displayName = It;
var to = "AlertDialogAction",
  jt = i.forwardRef((e, t) => {
    const { __scopeAlertDialog: r, ...n } = e,
      o = F(r);
    return v.jsx(At, { ...o, ...n, ref: t });
  });
jt.displayName = to;
var Ft = "AlertDialogCancel",
  Wt = i.forwardRef((e, t) => {
    const { __scopeAlertDialog: r, ...n } = e,
      { cancelRef: o } = Jn(Ft, r),
      a = F(r),
      c = T(t, o);
    return v.jsx(At, { ...a, ...n, ref: c });
  });
Wt.displayName = Ft;
var ro = ({ contentRef: e }) => {
    const t = `\`${Y}\` requires a description for the component to be accessible for screen reader users.

You can add a description to the \`${Y}\` by passing a \`${It}\` component as a child, which also benefits sighted users by adding visible context to the dialog.

Alternatively, you can use your own component as a description by assigning it an \`id\` and passing the same value to the \`aria-describedby\` prop in \`${Y}\`. If the description is confusing or duplicative for sighted users, you can use the \`@radix-ui/react-visually-hidden\` primitive as a wrapper around your description component.

For more information, see https://radix-ui.com/primitives/docs/components/alert-dialog`;
    return (
      i.useEffect(() => {
        document.getElementById(e.current?.getAttribute("aria-describedby")) ||
          console.warn(t);
      }, [t, e]),
      null
    );
  },
  Po = Dt,
  Ro = Tt,
  Ao = Nt,
  xo = Ot,
  Do = jt,
  To = Wt,
  No = Lt,
  Oo = Mt,
  no = i.createContext(void 0);
function oo(e) {
  const t = i.useContext(no);
  return e || t || "ltr";
}
function ao(e, [t, r]) {
  return Math.min(r, Math.max(t, e));
}
function io(e, t) {
  return i.useReducer((r, n) => t[r][n] ?? r, e);
}
var Ae = "ScrollArea",
  [kt] = we(Ae),
  [so, L] = kt(Ae),
  $t = i.forwardRef((e, t) => {
    const {
        __scopeScrollArea: r,
        type: n = "hover",
        dir: o,
        scrollHideDelay: a = 600,
        ...c
      } = e,
      [s, u] = i.useState(null),
      [l, d] = i.useState(null),
      [f, p] = i.useState(null),
      [m, y] = i.useState(null),
      [h, g] = i.useState(null),
      [b, E] = i.useState(0),
      [C, w] = i.useState(0),
      [P, x] = i.useState(!1),
      [S, N] = i.useState(!1),
      R = T(t, (B) => u(B)),
      D = oo(o);
    return v.jsx(so, {
      scope: r,
      type: n,
      dir: D,
      scrollHideDelay: a,
      scrollArea: s,
      viewport: l,
      onViewportChange: d,
      content: f,
      onContentChange: p,
      scrollbarX: m,
      onScrollbarXChange: y,
      scrollbarXEnabled: P,
      onScrollbarXEnabledChange: x,
      scrollbarY: h,
      onScrollbarYChange: g,
      scrollbarYEnabled: S,
      onScrollbarYEnabledChange: N,
      onCornerWidthChange: E,
      onCornerHeightChange: w,
      children: v.jsx(O.div, {
        dir: D,
        ...c,
        ref: R,
        style: {
          position: "relative",
          "--radix-scroll-area-corner-width": b + "px",
          "--radix-scroll-area-corner-height": C + "px",
          ...e.style,
        },
      }),
    });
  });
$t.displayName = Ae;
var Bt = "ScrollAreaViewport",
  Ut = i.forwardRef((e, t) => {
    const { __scopeScrollArea: r, children: n, nonce: o, ...a } = e,
      c = L(Bt, r),
      s = i.useRef(null),
      u = T(t, s, c.onViewportChange);
    return v.jsxs(v.Fragment, {
      children: [
        v.jsx("style", {
          dangerouslySetInnerHTML: {
            __html:
              "[data-radix-scroll-area-viewport]{scrollbar-width:none;-ms-overflow-style:none;-webkit-overflow-scrolling:touch;}[data-radix-scroll-area-viewport]::-webkit-scrollbar{display:none}",
          },
          nonce: o,
        }),
        v.jsx(O.div, {
          "data-radix-scroll-area-viewport": "",
          ...a,
          ref: u,
          style: {
            overflowX: c.scrollbarXEnabled ? "scroll" : "hidden",
            overflowY: c.scrollbarYEnabled ? "scroll" : "hidden",
            ...e.style,
          },
          children: v.jsx("div", {
            ref: c.onContentChange,
            style: { minWidth: "100%", display: "table" },
            children: n,
          }),
        }),
      ],
    });
  });
Ut.displayName = Bt;
var j = "ScrollAreaScrollbar",
  co = i.forwardRef((e, t) => {
    const { forceMount: r, ...n } = e,
      o = L(j, e.__scopeScrollArea),
      { onScrollbarXEnabledChange: a, onScrollbarYEnabledChange: c } = o,
      s = e.orientation === "horizontal";
    return (
      i.useEffect(
        () => (
          s ? a(!0) : c(!0),
          () => {
            s ? a(!1) : c(!1);
          }
        ),
        [s, a, c],
      ),
      o.type === "hover"
        ? v.jsx(lo, { ...n, ref: t, forceMount: r })
        : o.type === "scroll"
          ? v.jsx(uo, { ...n, ref: t, forceMount: r })
          : o.type === "auto"
            ? v.jsx(Ht, { ...n, ref: t, forceMount: r })
            : o.type === "always"
              ? v.jsx(xe, { ...n, ref: t })
              : null
    );
  });
co.displayName = j;
var lo = i.forwardRef((e, t) => {
    const { forceMount: r, ...n } = e,
      o = L(j, e.__scopeScrollArea),
      [a, c] = i.useState(!1);
    return (
      i.useEffect(() => {
        const s = o.scrollArea;
        let u = 0;
        if (s) {
          const l = () => {
              (window.clearTimeout(u), c(!0));
            },
            d = () => {
              u = window.setTimeout(() => c(!1), o.scrollHideDelay);
            };
          return (
            s.addEventListener("pointerenter", l),
            s.addEventListener("pointerleave", d),
            () => {
              (window.clearTimeout(u),
                s.removeEventListener("pointerenter", l),
                s.removeEventListener("pointerleave", d));
            }
          );
        }
      }, [o.scrollArea, o.scrollHideDelay]),
      v.jsx(k, {
        present: r || a,
        children: v.jsx(Ht, {
          "data-state": a ? "visible" : "hidden",
          ...n,
          ref: t,
        }),
      })
    );
  }),
  uo = i.forwardRef((e, t) => {
    const { forceMount: r, ...n } = e,
      o = L(j, e.__scopeScrollArea),
      a = e.orientation === "horizontal",
      c = le(() => u("SCROLL_END"), 100),
      [s, u] = io("hidden", {
        hidden: { SCROLL: "scrolling" },
        scrolling: { SCROLL_END: "idle", POINTER_ENTER: "interacting" },
        interacting: { SCROLL: "interacting", POINTER_LEAVE: "idle" },
        idle: {
          HIDE: "hidden",
          SCROLL: "scrolling",
          POINTER_ENTER: "interacting",
        },
      });
    return (
      i.useEffect(() => {
        if (s === "idle") {
          const l = window.setTimeout(() => u("HIDE"), o.scrollHideDelay);
          return () => window.clearTimeout(l);
        }
      }, [s, o.scrollHideDelay, u]),
      i.useEffect(() => {
        const l = o.viewport,
          d = a ? "scrollLeft" : "scrollTop";
        if (l) {
          let f = l[d];
          const p = () => {
            const m = l[d];
            (f !== m && (u("SCROLL"), c()), (f = m));
          };
          return (
            l.addEventListener("scroll", p),
            () => l.removeEventListener("scroll", p)
          );
        }
      }, [o.viewport, a, u, c]),
      v.jsx(k, {
        present: r || s !== "hidden",
        children: v.jsx(xe, {
          "data-state": s === "hidden" ? "hidden" : "visible",
          ...n,
          ref: t,
          onPointerEnter: A(e.onPointerEnter, () => u("POINTER_ENTER")),
          onPointerLeave: A(e.onPointerLeave, () => u("POINTER_LEAVE")),
        }),
      })
    );
  }),
  Ht = i.forwardRef((e, t) => {
    const r = L(j, e.__scopeScrollArea),
      { forceMount: n, ...o } = e,
      [a, c] = i.useState(!1),
      s = e.orientation === "horizontal",
      u = le(() => {
        if (r.viewport) {
          const l = r.viewport.offsetWidth < r.viewport.scrollWidth,
            d = r.viewport.offsetHeight < r.viewport.scrollHeight;
          c(s ? l : d);
        }
      }, 10);
    return (
      K(r.viewport, u),
      K(r.content, u),
      v.jsx(k, {
        present: n || a,
        children: v.jsx(xe, {
          "data-state": a ? "visible" : "hidden",
          ...o,
          ref: t,
        }),
      })
    );
  }),
  xe = i.forwardRef((e, t) => {
    const { orientation: r = "vertical", ...n } = e,
      o = L(j, e.__scopeScrollArea),
      a = i.useRef(null),
      c = i.useRef(0),
      [s, u] = i.useState({
        content: 0,
        viewport: 0,
        scrollbar: { size: 0, paddingStart: 0, paddingEnd: 0 },
      }),
      l = Xt(s.viewport, s.content),
      d = {
        ...n,
        sizes: s,
        onSizesChange: u,
        hasThumb: l > 0 && l < 1,
        onThumbChange: (p) => (a.current = p),
        onThumbPointerUp: () => (c.current = 0),
        onThumbPointerDown: (p) => (c.current = p),
      };
    function f(p, m) {
      return bo(p, c.current, s, m);
    }
    return r === "horizontal"
      ? v.jsx(fo, {
          ...d,
          ref: t,
          onThumbPositionChange: () => {
            if (o.viewport && a.current) {
              const p = o.viewport.scrollLeft,
                m = Ue(p, s, o.dir);
              a.current.style.transform = `translate3d(${m}px, 0, 0)`;
            }
          },
          onWheelScroll: (p) => {
            o.viewport && (o.viewport.scrollLeft = p);
          },
          onDragScroll: (p) => {
            o.viewport && (o.viewport.scrollLeft = f(p, o.dir));
          },
        })
      : r === "vertical"
        ? v.jsx(vo, {
            ...d,
            ref: t,
            onThumbPositionChange: () => {
              if (o.viewport && a.current) {
                const p = o.viewport.scrollTop,
                  m = Ue(p, s);
                a.current.style.transform = `translate3d(0, ${m}px, 0)`;
              }
            },
            onWheelScroll: (p) => {
              o.viewport && (o.viewport.scrollTop = p);
            },
            onDragScroll: (p) => {
              o.viewport && (o.viewport.scrollTop = f(p));
            },
          })
        : null;
  }),
  fo = i.forwardRef((e, t) => {
    const { sizes: r, onSizesChange: n, ...o } = e,
      a = L(j, e.__scopeScrollArea),
      [c, s] = i.useState(),
      u = i.useRef(null),
      l = T(t, u, a.onScrollbarXChange);
    return (
      i.useEffect(() => {
        u.current && s(getComputedStyle(u.current));
      }, [u]),
      v.jsx(zt, {
        "data-orientation": "horizontal",
        ...o,
        ref: l,
        sizes: r,
        style: {
          bottom: 0,
          left: a.dir === "rtl" ? "var(--radix-scroll-area-corner-width)" : 0,
          right: a.dir === "ltr" ? "var(--radix-scroll-area-corner-width)" : 0,
          "--radix-scroll-area-thumb-width": ce(r) + "px",
          ...e.style,
        },
        onThumbPointerDown: (d) => e.onThumbPointerDown(d.x),
        onDragScroll: (d) => e.onDragScroll(d.x),
        onWheelScroll: (d, f) => {
          if (a.viewport) {
            const p = a.viewport.scrollLeft + d.deltaX;
            (e.onWheelScroll(p), Gt(p, f) && d.preventDefault());
          }
        },
        onResize: () => {
          u.current &&
            a.viewport &&
            c &&
            n({
              content: a.viewport.scrollWidth,
              viewport: a.viewport.offsetWidth,
              scrollbar: {
                size: u.current.clientWidth,
                paddingStart: ae(c.paddingLeft),
                paddingEnd: ae(c.paddingRight),
              },
            });
        },
      })
    );
  }),
  vo = i.forwardRef((e, t) => {
    const { sizes: r, onSizesChange: n, ...o } = e,
      a = L(j, e.__scopeScrollArea),
      [c, s] = i.useState(),
      u = i.useRef(null),
      l = T(t, u, a.onScrollbarYChange);
    return (
      i.useEffect(() => {
        u.current && s(getComputedStyle(u.current));
      }, [u]),
      v.jsx(zt, {
        "data-orientation": "vertical",
        ...o,
        ref: l,
        sizes: r,
        style: {
          top: 0,
          right: a.dir === "ltr" ? 0 : void 0,
          left: a.dir === "rtl" ? 0 : void 0,
          bottom: "var(--radix-scroll-area-corner-height)",
          "--radix-scroll-area-thumb-height": ce(r) + "px",
          ...e.style,
        },
        onThumbPointerDown: (d) => e.onThumbPointerDown(d.y),
        onDragScroll: (d) => e.onDragScroll(d.y),
        onWheelScroll: (d, f) => {
          if (a.viewport) {
            const p = a.viewport.scrollTop + d.deltaY;
            (e.onWheelScroll(p), Gt(p, f) && d.preventDefault());
          }
        },
        onResize: () => {
          u.current &&
            a.viewport &&
            c &&
            n({
              content: a.viewport.scrollHeight,
              viewport: a.viewport.offsetHeight,
              scrollbar: {
                size: u.current.clientHeight,
                paddingStart: ae(c.paddingTop),
                paddingEnd: ae(c.paddingBottom),
              },
            });
        },
      })
    );
  }),
  [po, Vt] = kt(j),
  zt = i.forwardRef((e, t) => {
    const {
        __scopeScrollArea: r,
        sizes: n,
        hasThumb: o,
        onThumbChange: a,
        onThumbPointerUp: c,
        onThumbPointerDown: s,
        onThumbPositionChange: u,
        onDragScroll: l,
        onWheelScroll: d,
        onResize: f,
        ...p
      } = e,
      m = L(j, r),
      [y, h] = i.useState(null),
      g = T(t, (R) => h(R)),
      b = i.useRef(null),
      E = i.useRef(""),
      C = m.viewport,
      w = n.content - n.viewport,
      P = _(d),
      x = _(u),
      S = le(f, 10);
    function N(R) {
      if (b.current) {
        const D = R.clientX - b.current.left,
          B = R.clientY - b.current.top;
        l({ x: D, y: B });
      }
    }
    return (
      i.useEffect(() => {
        const R = (D) => {
          const B = D.target;
          y?.contains(B) && P(D, w);
        };
        return (
          document.addEventListener("wheel", R, { passive: !1 }),
          () => document.removeEventListener("wheel", R, { passive: !1 })
        );
      }, [C, y, w, P]),
      i.useEffect(x, [n, x]),
      K(y, S),
      K(m.content, S),
      v.jsx(po, {
        scope: r,
        scrollbar: y,
        hasThumb: o,
        onThumbChange: _(a),
        onThumbPointerUp: _(c),
        onThumbPositionChange: x,
        onThumbPointerDown: _(s),
        children: v.jsx(O.div, {
          ...p,
          ref: g,
          style: { position: "absolute", ...p.style },
          onPointerDown: A(e.onPointerDown, (R) => {
            R.button === 0 &&
              (R.target.setPointerCapture(R.pointerId),
              (b.current = y.getBoundingClientRect()),
              (E.current = document.body.style.webkitUserSelect),
              (document.body.style.webkitUserSelect = "none"),
              m.viewport && (m.viewport.style.scrollBehavior = "auto"),
              N(R));
          }),
          onPointerMove: A(e.onPointerMove, N),
          onPointerUp: A(e.onPointerUp, (R) => {
            const D = R.target;
            (D.hasPointerCapture(R.pointerId) &&
              D.releasePointerCapture(R.pointerId),
              (document.body.style.webkitUserSelect = E.current),
              m.viewport && (m.viewport.style.scrollBehavior = ""),
              (b.current = null));
          }),
        }),
      })
    );
  }),
  oe = "ScrollAreaThumb",
  ho = i.forwardRef((e, t) => {
    const { forceMount: r, ...n } = e,
      o = Vt(oe, e.__scopeScrollArea);
    return v.jsx(k, {
      present: r || o.hasThumb,
      children: v.jsx(mo, { ref: t, ...n }),
    });
  }),
  mo = i.forwardRef((e, t) => {
    const { __scopeScrollArea: r, style: n, ...o } = e,
      a = L(oe, r),
      c = Vt(oe, r),
      { onThumbPositionChange: s } = c,
      u = T(t, (f) => c.onThumbChange(f)),
      l = i.useRef(void 0),
      d = le(() => {
        l.current && (l.current(), (l.current = void 0));
      }, 100);
    return (
      i.useEffect(() => {
        const f = a.viewport;
        if (f) {
          const p = () => {
            if ((d(), !l.current)) {
              const m = yo(f, s);
              ((l.current = m), s());
            }
          };
          return (
            s(),
            f.addEventListener("scroll", p),
            () => f.removeEventListener("scroll", p)
          );
        }
      }, [a.viewport, d, s]),
      v.jsx(O.div, {
        "data-state": c.hasThumb ? "visible" : "hidden",
        ...o,
        ref: u,
        style: {
          width: "var(--radix-scroll-area-thumb-width)",
          height: "var(--radix-scroll-area-thumb-height)",
          ...n,
        },
        onPointerDownCapture: A(e.onPointerDownCapture, (f) => {
          const m = f.target.getBoundingClientRect(),
            y = f.clientX - m.left,
            h = f.clientY - m.top;
          c.onThumbPointerDown({ x: y, y: h });
        }),
        onPointerUp: A(e.onPointerUp, c.onThumbPointerUp),
      })
    );
  });
ho.displayName = oe;
var De = "ScrollAreaCorner",
  Yt = i.forwardRef((e, t) => {
    const r = L(De, e.__scopeScrollArea),
      n = !!(r.scrollbarX && r.scrollbarY);
    return r.type !== "scroll" && n ? v.jsx(go, { ...e, ref: t }) : null;
  });
Yt.displayName = De;
var go = i.forwardRef((e, t) => {
  const { __scopeScrollArea: r, ...n } = e,
    o = L(De, r),
    [a, c] = i.useState(0),
    [s, u] = i.useState(0),
    l = !!(a && s);
  return (
    K(o.scrollbarX, () => {
      const d = o.scrollbarX?.offsetHeight || 0;
      (o.onCornerHeightChange(d), u(d));
    }),
    K(o.scrollbarY, () => {
      const d = o.scrollbarY?.offsetWidth || 0;
      (o.onCornerWidthChange(d), c(d));
    }),
    l
      ? v.jsx(O.div, {
          ...n,
          ref: t,
          style: {
            width: a,
            height: s,
            position: "absolute",
            right: o.dir === "ltr" ? 0 : void 0,
            left: o.dir === "rtl" ? 0 : void 0,
            bottom: 0,
            ...e.style,
          },
        })
      : null
  );
});
function ae(e) {
  return e ? parseInt(e, 10) : 0;
}
function Xt(e, t) {
  const r = e / t;
  return isNaN(r) ? 0 : r;
}
function ce(e) {
  const t = Xt(e.viewport, e.content),
    r = e.scrollbar.paddingStart + e.scrollbar.paddingEnd,
    n = (e.scrollbar.size - r) * t;
  return Math.max(n, 18);
}
function bo(e, t, r, n = "ltr") {
  const o = ce(r),
    a = o / 2,
    c = t || a,
    s = o - c,
    u = r.scrollbar.paddingStart + c,
    l = r.scrollbar.size - r.scrollbar.paddingEnd - s,
    d = r.content - r.viewport,
    f = n === "ltr" ? [0, d] : [d * -1, 0];
  return Kt([u, l], f)(e);
}
function Ue(e, t, r = "ltr") {
  const n = ce(t),
    o = t.scrollbar.paddingStart + t.scrollbar.paddingEnd,
    a = t.scrollbar.size - o,
    c = t.content - t.viewport,
    s = a - n,
    u = r === "ltr" ? [0, c] : [c * -1, 0],
    l = ao(e, u);
  return Kt([0, c], [0, s])(l);
}
function Kt(e, t) {
  return (r) => {
    if (e[0] === e[1] || t[0] === t[1]) return t[0];
    const n = (t[1] - t[0]) / (e[1] - e[0]);
    return t[0] + n * (r - e[0]);
  };
}
function Gt(e, t) {
  return e > 0 && e < t;
}
var yo = (e, t = () => {}) => {
  let r = { left: e.scrollLeft, top: e.scrollTop },
    n = 0;
  return (
    (function o() {
      const a = { left: e.scrollLeft, top: e.scrollTop },
        c = r.left !== a.left,
        s = r.top !== a.top;
      ((c || s) && t(), (r = a), (n = window.requestAnimationFrame(o)));
    })(),
    () => window.cancelAnimationFrame(n)
  );
};
function le(e, t) {
  const r = _(e),
    n = i.useRef(0);
  return (
    i.useEffect(() => () => window.clearTimeout(n.current), []),
    i.useCallback(() => {
      (window.clearTimeout(n.current), (n.current = window.setTimeout(r, t)));
    }, [r, t])
  );
}
function K(e, t) {
  const r = _(t);
  X(() => {
    let n = 0;
    if (e) {
      const o = new ResizeObserver(() => {
        (cancelAnimationFrame(n), (n = window.requestAnimationFrame(r)));
      });
      return (
        o.observe(e),
        () => {
          (window.cancelAnimationFrame(n), o.unobserve(e));
        }
      );
    }
  }, [e, r]);
}
var _o = $t,
  Lo = Ut,
  Io = Yt;
export {
  Do as A,
  To as C,
  Oo as D,
  Ao as O,
  Ro as P,
  Co as R,
  wo as S,
  No as T,
  Lo as V,
  Po as a,
  xo as b,
  _o as c,
  Io as d,
  co as e,
  ho as f,
  $n as g,
  Un as h,
  Hn as i,
  Vn as j,
  zn as k,
  Yn as l,
};
