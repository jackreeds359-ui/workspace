const a = {
    pink: "#ff4d8d",
    orange: "#ff9f1c",
    green: "#2ec4b6",
    blue: "#3a86ff",
    purple: "#8338ec",
    red: "#ef233c",
    lime: "#6aa81e",
    teal: "#118ab2",
  },
  d = [
    ["Code", "Price"],
    ["BAS", "£5"],
    ["STD", "£9"],
    ["PRE", "£15"],
  ];
function p(e, s, i = {}) {
  return {
    tab: "Data",
    cols: ["E", "F", "G"],
    start: 1,
    hdRow: 1,
    data: [
      ["Name", "Plan", "Monthly cost"],
      ["Aisha", e, s],
    ],
    hl: i,
  };
}
function n(e = {}) {
  return {
    tab: "Analysis",
    cols: ["E", "F"],
    start: 12,
    hdRow: 12,
    data: d,
    hl: e,
  };
}
const t = (e, s, i, b, m = {}) => ({ sheets: [p(e, s, i), n(b)], ...m }),
  o = "=VLOOKUP(F2, Analysis!$E$13:$F$15, 2, FALSE)",
  l = {
    E13: "range",
    E14: "range",
    E15: "range",
    F13: "range",
    F14: "range",
    F15: "range",
  },
  h = {
    E13: "hit",
    E14: "hit",
    E15: "hit",
    F13: "ret",
    F14: "ret",
    F15: "ret",
  },
  c = [
    ["#ffe1ee", "lookup value"],
    ["#c9f7ee", "match found"],
    ["#e6dcff", "value returned"],
  ],
  { pink: f, orange: r, green: u, purple: F } = a,
  g = {
    id: "vlookup",
    logo: "VLOOKUP",
    title: "The VLOOKUP Challenge",
    badge: "BTEC DIT · Component 2 · Task 2a / 2b",
    lead: "VLOOKUP lets one sheet <b>look something up</b> in a table on another sheet. Tap a colour to zoom in on that part, or press <b>Watch it work</b>.",
    formula: [
      { t: "=VLOOKUP(" },
      { t: "F2", a: 0 },
      { t: ", ", sep: !0 },
      { t: "Analysis!$E$13:$F$15", a: 1 },
      { t: ", ", sep: !0 },
      { t: "2", a: 2 },
      { t: ", ", sep: !0 },
      { t: "FALSE", a: 3 },
      { t: ")" },
    ],
    args: [
      {
        k: "F2",
        c: a.pink,
        tint: "#ffe1ee",
        lab: "What to look for",
        title: "1. The lookup value",
        txt: "The thing we already know. F2 on the Data sheet holds Aisha's plan code, <b>STD</b>. VLOOKUP takes this and goes looking for it.",
        vis: t("STD", "?", { F2: "look" }, {}),
      },
      {
        k: "Analysis!$E$13:$F$15",
        c: a.orange,
        tint: "#fff0d6",
        lab: "Where to look",
        title: "2. The table",
        txt: "The block of cells to search: the <b>Analysis</b> sheet, from <b>E13</b> to <b>F15</b>. The <b>!</b> separates the sheet name from the cells. The <b>$</b> signs lock the table so it stays put when you fill down.",
        vis: t("STD", "?", {}, l),
      },
      {
        k: "2",
        c: a.green,
        tint: "#d6f7f3",
        lab: "Which column to bring back",
        title: "3. The column number",
        txt: "Which column of the table to bring back. Count from the <b>left edge of the table</b>, not from column A: E is column 1, F is column 2. VLOOKUP finds the row for you.",
        vis: {
          sheets: [n(h)],
          legend: [
            ["#c9f7ee", "column 1 (searched)"],
            ["#e6dcff", "column 2 (brought back)"],
          ],
        },
      },
      {
        k: "FALSE",
        c: a.purple,
        tint: "#ece3ff",
        lab: "Exact match only",
        title: "4. Exact match",
        txt: "Only accept a perfect match. If the code is not in the table you get <b>#N/A</b> instead of a guess. Leave this off and Excel quietly uses TRUE, so always type <b>FALSE</b>.",
        vis: t(
          "GLD",
          "#N/A",
          { F2: "look", G2: "bad" },
          { E13: "scan", E14: "scan", E15: "scan" },
          {
            note: "GLD is not in the table, so FALSE gives #N/A rather than a wrong price.",
          },
        ),
      },
    ],
    plain: [
      '"Look up the value in ',
      { a: 0, t: "cell F2" },
      ", in the table on the ",
      { a: 1, t: "Analysis sheet between E13 and F15" },
      ", and give me whatever is in the ",
      { a: 2, t: "2nd column" },
      " of that table on the matching row. ",
      { a: 3, t: "Must be an exact match." },
      '"',
    ],
    play: [
      {
        a: 0,
        cap: "Step 1: read the value in F2. It says STD.",
        vis: t("STD", "?", { F2: "look" }, {}),
      },
      {
        a: 1,
        cap: "Step 2: jump to the table on the Analysis sheet.",
        vis: t("STD", "?", { F2: "look" }, l),
      },
      {
        a: 1,
        cap: "Step 3: scan down the first column. E13 is BAS. Not STD...",
        vis: t("STD", "?", { F2: "look" }, { E13: "scan" }),
      },
      {
        a: 3,
        cap: "...E14 is STD. Exact match found!",
        vis: t("STD", "?", { F2: "look" }, { E13: "scan", E14: "hit" }),
      },
      {
        a: 2,
        cap: "Step 4: move across the same row to column 2.",
        vis: t("STD", "?", { F2: "look" }, { E14: "hit", F14: "ret" }),
      },
      {
        a: -1,
        cap: "Step 5: bring it back. G2 shows £9.",
        vis: t(
          "STD",
          "£9",
          { F2: "look", G2: "ret" },
          { E14: "hit", F14: "ret" },
          { legend: c },
        ),
      },
    ],
    sections: [
      { id: "meet", name: "Meet VLOOKUP", c: a.pink },
      { id: "read", name: "Read the Sheet", c: a.orange },
      { id: "eng", name: "Plain English Translator", c: a.green },
      { id: "typo", name: "Fix These Typos", c: a.red },
      { id: "dollar", name: "Dollar Sign Detectives", c: a.blue },
      { id: "bug", name: "Bug Hunt", c: a.purple },
    ],
    questions: [
      {
        sec: "meet",
        type: "match",
        prompt: "Match each part of the formula to what it does.",
        visual: () => ({ fx: o }),
        pairs: [
          ["F2", "What we are looking for (the lookup value)"],
          ["Analysis!$E$13:$F$15", "Where to look (the table)"],
          ["2", "Which column of the table to bring back"],
          ["FALSE", "Only accept an exact match"],
        ],
        explain:
          "The four arguments are always in this order: <b>what</b>, <b>where</b>, <b>which column</b>, <b>exact or not</b>.",
      },
      {
        sec: "meet",
        type: "mcq",
        prompt: "VLOOKUP searches for F2 in which column of the table?",
        visual: (e) => ({
          sheets: [n(e ? { E13: "hit", E14: "hit", E15: "hit" } : l)],
        }),
        opts: [
          "The first (leftmost) column, E",
          "The last column, F",
          "Whichever column the number 2 points to",
          "Every column, until it finds a match",
        ],
        ans: 0,
        explain:
          "VLOOKUP only ever searches <b>down the first column</b> of the table (V for Vertical). The column number only decides what comes <b>back</b>.",
      },
      {
        sec: "read",
        type: "mcq",
        prompt: `G2 contains <code>${o}</code>. What will G2 show?`,
        visual: (e) =>
          t(
            "STD",
            e ? "£9" : o,
            e ? { F2: "look", G2: "ret" } : { F2: "look" },
            e ? { E14: "hit", F14: "ret" } : {},
            e ? { legend: c } : {},
          ),
        opts: ["£5", "£9", "£15", "STD"],
        ans: 1,
        explain:
          "F2 is <b>STD</b>. VLOOKUP finds STD in row 14 of column E, moves across to column <b>2</b> (F) and returns <b>£9</b>.",
      },
      {
        sec: "read",
        type: "mcq",
        prompt:
          "Same sheets, but now the formula is <code>=VLOOKUP(F2, Analysis!$E$13:$F$15, 1, FALSE)</code>. What does it return?",
        visual: (e) => t("PRE", "?", { F2: "look" }, e ? { E15: "ret" } : {}),
        opts: ["£15", "PRE", "1", "#N/A"],
        ans: 1,
        explain:
          "Column <b>1</b> is the first column of the table, the one it searched in. So it just gives back the code it found: <b>PRE</b>. Not very useful!",
      },
      {
        sec: "read",
        type: "mcq",
        prompt: "Aisha changes plan to <b>GLD</b>. What will G2 show now?",
        visual: (e) =>
          t(
            "GLD",
            e ? "#N/A" : o,
            e ? { F2: "look", G2: "bad" } : { F2: "look" },
            e ? { E13: "scan", E14: "scan", E15: "scan" } : {},
          ),
        opts: ["£0", "£15 (the nearest one)", "#N/A", "#REF!"],
        ans: 2,
        explain:
          "With <b>FALSE</b>, if the exact value is not in the first column you get <b>#N/A</b> (Not Available). GLD is not in the table.",
      },
      {
        sec: "read",
        type: "mcq",
        prompt:
          "What happens with <code>=VLOOKUP(F2, Analysis!$E$13:$F$15, 3, FALSE)</code>?",
        visual: () => t("BAS", "?", { F2: "look" }, {}),
        opts: [
          "It returns £5",
          "It returns #REF! because the table only has 2 columns",
          "It returns #N/A",
          "It looks in column G instead",
        ],
        ans: 1,
        explain:
          "The table E13:F15 is only <b>2 columns wide</b>. Asking for column 3 goes off the edge of the table, so Excel shows <b>#REF!</b>.",
      },
      {
        sec: "eng",
        type: "mcq",
        prompt: "Translate this formula into plain English:",
        visual: () => ({ fx: "=VLOOKUP(B4, Prices!$A$2:$C$20, 3, FALSE)" }),
        opts: [
          "Look up the value in B4 in the table on the Prices sheet from A2 to C20, and give me whatever is in the 3rd column of that table on the matching row. Must be an exact match.",
          "Look up the value in B4 in column C of the Prices sheet between rows 2 and 20, and give me whatever is on row 3 of that table. Must be an exact match.",
          "Add up B4 and every value in the table on the Prices sheet from A2 to C20, then give me whatever total ends up in the 3rd column. Must be an exact match.",
          "Look up the value in B4 in the table on the Prices sheet from A2 to C20, and give me whatever is in column 3. The closest match is fine.",
        ],
        ans: 0,
        explain:
          "The number is a <b>column of the table</b> (not a row), and <b>FALSE</b> means exact match only.",
      },
      {
        sec: "eng",
        type: "mcq",
        prompt:
          'Which formula matches this sentence?<br><i>"Look up the value in A7, in the table on the Stock sheet between H2 and J40, give me whatever is in the 2nd column on the matching row. Must be an exact match."</i>',
        opts: [
          "=VLOOKUP(A7, Stock!$H$2:$J$40, 2, TRUE)",
          "=VLOOKUP(Stock!$H$2:$J$40, A7, 2, FALSE)",
          "=VLOOKUP(A7, Stock!$H$2:$J$40, 2, FALSE)",
          "=VLOOKUP(A7, Stock!$J$2:$J$40, 2, FALSE)",
        ],
        ans: 2,
        mono: !0,
        explain:
          "Order matters: <b>lookup value</b> first, then the <b>table</b>, then the <b>column</b>, then <b>FALSE</b> for exact.",
      },
      {
        sec: "eng",
        type: "build",
        prompt:
          "Build the formula from the English. Tap a chip to drop it in the next empty box. Tap a box to empty it.",
        english:
          '"Look up the value in D3, in the table on the Lookup sheet between H2 and I6, and give me whatever is in the 2nd column of that table on the matching row. Must be an exact match."',
        fn: "VLOOKUP",
        answer: ["D3", "Lookup!$H$2:$I$6", "2", "FALSE"],
        chips: [
          "D3",
          "Lookup!$H$2:$I$6",
          "2",
          "FALSE",
          "TRUE",
          "H2",
          "1",
          "Lookup!$H$2",
        ],
        explain: "<code>=VLOOKUP(D3, Lookup!$H$2:$I$6, 2, FALSE)</code>",
      },
      {
        sec: "eng",
        type: "order",
        prompt:
          "Put the steps VLOOKUP takes in the right order. Tap them 1 to 5.",
        visual: () => ({ fx: o }),
        items: [
          "Read the value in F2",
          "Jump to the first column of the table (E13:E15)",
          "Scan down until it finds an exact match",
          "Move across the same row to column 2",
          "Return the value it lands on",
        ],
        explain:
          "Read, jump, scan down, move across, return. Think of your finger going <b>down</b> then <b>across</b>.",
      },
      {
        sec: "typo",
        type: "typo",
        prompt: "This shows #NAME?. Fix it.",
        broken: "=VLOKUP(F2, Analysis!$E$13:$F$15, 2, FALSE)",
        fixed: "=VLOOKUP(F2,Analysis!$E$13:$F$15,2,FALSE)",
        shown: o,
        hint: "Check the spelling of the function name.",
        explain:
          "<b>VLOKUP</b> should be <b>VLOOKUP</b> (two Os). A misspelt function gives <b>#NAME?</b>",
      },
      {
        sec: "typo",
        type: "typo",
        prompt: "This gives the wrong result. Fix it.",
        broken: "=VLOOKUP(F2 Analysis!$E$13:$F$15, 2, FALSE)",
        fixed: "=VLOOKUP(F2,Analysis!$E$13:$F$15,2,FALSE)",
        shown: o,
        hint: "Count the commas. There should be 3 of them separating 4 arguments.",
        explain:
          "A comma was missing after <b>F2</b>. Four arguments need <b>three</b> commas.",
      },
      {
        sec: "typo",
        type: "typo",
        prompt: "The range is broken. Fix it.",
        broken: "=VLOOKUP(F2, Analysis!$E$13;$F$15, 2, FALSE)",
        fixed: "=VLOOKUP(F2,Analysis!$E$13:$F$15,2,FALSE)",
        shown: o,
        hint: "A range from one cell to another uses a colon, not a semicolon.",
        explain:
          'Ranges use a <b>colon</b>: <code>$E$13:$F$15</code> means "E13 to F15".',
      },
      {
        sec: "typo",
        type: "typo",
        prompt: "Excel cannot find the other sheet. Fix it.",
        broken: "=VLOOKUP(F2, Analysis$E$13:$F$15, 2, FALSE)",
        fixed: "=VLOOKUP(F2,Analysis!$E$13:$F$15,2,FALSE)",
        shown: o,
        hint: "Sheet names need a special symbol between them and the cell reference.",
        explain:
          "A sheet name is always followed by an <b>exclamation mark</b>: <code>Analysis!</code>",
      },
      {
        sec: "typo",
        type: "typo",
        prompt: "Two typos in this one! Fix both.",
        broken: "=VLOOKUP(F2, Analysis!$E$13:$F$15, 2, FLASE",
        fixed: "=VLOOKUP(F2,Analysis!$E$13:$F$15,2,FALSE)",
        shown: o,
        hint: "Look at the last word, then look at the very end of the formula.",
        explain:
          "<b>FLASE</b> should be <b>FALSE</b>, and every opening bracket needs a <b>closing bracket</b>.",
      },
      {
        sec: "typo",
        type: "typo",
        prompt: "This runs, but always returns #N/A. Fix it.",
        broken: '=VLOOKUP("F2", Analysis!$E$13:$F$15, 2, FALSE)',
        fixed: "=VLOOKUP(F2,Analysis!$E$13:$F$15,2,FALSE)",
        shown: o,
        hint: "Quote marks turn a cell reference into plain text.",
        explain:
          '<code>"F2"</code> searches for the <b>text</b> F2, not the value inside cell F2. Remove the quotes.',
      },
      {
        sec: "dollar",
        type: "mcq",
        prompt:
          "Someone typed the formula <b>without</b> dollar signs in G2, then filled it down to G3. What went wrong in G3?",
        visual: (e) => ({
          sheets: [
            {
              tab: "Data",
              cols: ["F", "G"],
              start: 1,
              hdRow: 1,
              data: [
                ["Plan", "Monthly cost"],
                ["STD", "=VLOOKUP(F2, Analysis!E13:F15, 2, FALSE)"],
                ["BAS", "=VLOOKUP(F3, Analysis!E14:F16, 2, FALSE)"],
              ],
              hl: e ? { G3: "bad" } : { G2: "look", G3: "range" },
            },
          ],
        }),
        opts: [
          "Nothing, filling down always keeps the formula exactly the same, so G3 is fine",
          "The table range slid down to E14:F16, so it no longer includes the BAS row (row 13)",
          "F3 should still say F2, because the lookup value must never move when copied",
          "The column number changed to 3, so it now looks off the edge of the table",
        ],
        ans: 1,
        explain:
          "BAS is not in E14:E16, so G3 returns <b>#N/A</b>. Without $, every reference moves when you fill down. The <b>table</b> must stay put, so lock it: <code>Analysis!$E$13:$F$15</code>. F2 changing to F3 is exactly what we want.",
      },
      {
        sec: "dollar",
        type: "mcq",
        prompt: "What does the reference <code>$E$13</code> mean?",
        opts: [
          "Cell E13, formatted as currency with a £ sign",
          "Cell E13, locked so it does not change when copied",
          "Cell E13 on a different sheet in the same workbook",
          "The total of column E from row 1 down to row 13",
        ],
        ans: 1,
        explain:
          "The $ locks the <b>column</b> ($E) and the <b>row</b> ($13). Nothing to do with money! Tip: press <b>F4</b> to add them.",
      },
      {
        sec: "bug",
        type: "match",
        prompt: "Match each problem to its most likely cause.",
        pairs: [
          ["#N/A", "The lookup value is not in the first column of the table"],
          ["#REF!", "The column number is bigger than the table is wide"],
          ["#NAME?", "The function name is spelt wrong"],
          [
            "Wrong answer, no error",
            "TRUE was used on unsorted data instead of FALSE",
          ],
        ],
        explain:
          "Learning what each error means turns debugging from guessing into detective work.",
      },
      {
        sec: "bug",
        type: "mcq",
        prompt:
          "Why should your BTEC dataset lookups nearly always end in <code>FALSE</code>?",
        opts: [
          "FALSE makes the formula calculate faster on large datasets with many rows",
          'Codes, names and IDs must match exactly, so a "close enough" answer would be wrong',
          "TRUE only works with text, and most of the dataset is numbers and prices",
          "FALSE hides any errors so the dashboard always looks clean and finished",
        ],
        ans: 1,
        explain:
          "<b>TRUE</b> (approximate) is only for sorted number bands like grade boundaries. For codes and categories you want <b>FALSE</b>.",
      },
      {
        sec: "bug",
        type: "mcq",
        prompt:
          "Someone leaves off the last argument: <code>=VLOOKUP(F2, Analysis!$E$13:$F$15, 2)</code>. What does Excel do?",
        opts: [
          "Uses TRUE (approximate match) by default, which can give a wrong answer with no error",
          "Uses FALSE (exact match) by default, so it works exactly the same as before",
          "Refuses to accept it, because VLOOKUP always needs all four arguments",
          "Shows #N/A every time, because the match type argument is missing",
        ],
        ans: 0,
        explain:
          "The 4th argument is optional and <b>defaults to TRUE</b>. On unsorted codes that can quietly return the wrong row with no error showing. Always type <b>FALSE</b> yourself.",
      },
      {
        sec: "bug",
        type: "mcq",
        prompt:
          "Which of these is a sensible use of <code>TRUE</code> (approximate match)?",
        visual: (e) => ({
          sheets: [
            {
              tab: "Grades",
              cols: ["A", "B"],
              start: 1,
              hdRow: 1,
              data: [
                ["Min mark", "Grade"],
                ["0", "U"],
                ["40", "Pass"],
                ["60", "Merit"],
                ["80", "Distinction"],
              ],
              hl: e ? { A4: "hit", B4: "ret" } : {},
            },
          ],
        }),
        opts: [
          "Finding the grade for a mark, using a sorted table of grade boundaries",
          "Finding the price for a plan code such as STD or PRE",
          "Finding a student's form group from their student ID",
          "Finding a product's name from its barcode number",
        ],
        ans: 0,
        explain:
          "With <b>TRUE</b> and the first column sorted smallest to largest, a mark of 67 falls back to the largest boundary not above it: <b>60, Merit</b>. Codes, IDs and barcodes need an exact match, so <b>FALSE</b>.",
      },
      {
        sec: "bug",
        type: "mcq",
        prompt:
          'F2 contains <b>"STD "</b> (with a space at the end). What happens?',
        visual: () =>
          t("STD␣", "#N/A", { F2: "look", G2: "bad" }, { E14: "range" }),
        opts: [
          "It still finds STD, because Excel ignores spaces at the end",
          '#N/A, because "STD " is not an exact match for "STD"',
          "#REF!, because the space pushes it outside the table range",
          "It returns £9 but shows a small green warning triangle",
        ],
        ans: 1,
        explain:
          "An extra space counts as a character. This is why <b>cleaning your data</b> (e.g. with TRIM) matters in Task 2.",
      },
    ],
    teach: {
      meet: {
        title: "Your finger goes down, then across",
        blocks: [
          {
            p: "Picture VLOOKUP as your finger on the table. It goes <b>down</b> the first column until it finds the value, then <b>across</b> that row to the column you asked for.",
          },
          {
            visual: t(
              "STD",
              o,
              { F2: "look" },
              { E13: "scan", E14: "hit", F14: "ret" },
              {
                legend: [
                  ["#ffe1ee", "1. what to look for"],
                  ["#fff0c2", "2. scan down column E"],
                  ["#c9f7ee", "3. match found"],
                  ["#e6dcff", "4. move across, bring back"],
                ],
              },
            ),
          },
          {
            tip: "The table must start with the column you are searching. VLOOKUP cannot look to the <b>left</b> of it.",
          },
        ],
      },
      read: {
        title: "Count columns from the edge of the table",
        blocks: [
          {
            p: "The column number counts from the <b>left edge of the table</b>, not from column A of the sheet. In <code>$E$13:$F$15</code>, E is column 1 and F is column 2.",
          },
          {
            visual: {
              sheets: [n(h)],
              legend: [
                ["#c9f7ee", "column 1 (E), searched"],
                ["#e6dcff", "column 2 (F), brought back"],
              ],
            },
          },
          { p: "Two errors to know for this round:" },
          {
            table: {
              rows: [
                ["#N/A", "The value was not found in column 1."],
                ["#REF!", "The column number is wider than the table."],
              ],
            },
          },
          {
            tip: "The header row (Code, Price) is left out of the range on purpose. Start the table on the first row of real data.",
          },
        ],
      },
      eng: {
        title: "The sentence frame",
        blocks: [
          {
            p: "Every VLOOKUP can be read aloud with the same sentence. Learn the frame and you can translate any formula, in either direction.",
          },
          {
            c: u,
            frame: [
              "Look up the value in ",
              { text: "cell", c: f },
              ", in the table on the ",
              { text: "sheet name", c: r },
              " sheet between ",
              { text: "first cell", c: r },
              " and ",
              { text: "last cell", c: r },
              ", and give me whatever is in the ",
              { text: "Nth", c: u },
              " column of that table on the matching row. ",
              { text: "Must be an exact match.", c: F },
            ],
          },
          { visual: { fx: "=VLOOKUP(B4, Prices!$A$2:$C$20, 3, FALSE)" } },
          {
            p: '"Look up the value in <b>B4</b>, in the table on the <b>Prices</b> sheet between <b>A2</b> and <b>C20</b>, and give me whatever is in the <b>3rd</b> column of that table on the matching row. <b>Must be an exact match.</b>"',
          },
          {
            tip: "The number is always a <b>column</b>, never a row. VLOOKUP finds the row for you.",
          },
        ],
      },
      typo: {
        title: "The syntax checklist",
        blocks: [
          {
            p: "When a formula breaks, check these in order. Most typos are one of these six.",
          },
          {
            table: {
              rows: [
                [
                  "VLOOKUP",
                  "Spelt right? A misspelt function shows <b>#NAME?</b>",
                ],
                [", , ,", "Exactly <b>3 commas</b> separating 4 arguments."],
                [
                  "E13:F15",
                  "A <b>colon</b> between the first and last cell of a range.",
                ],
                ["Analysis!", "An <b>exclamation mark</b> after a sheet name."],
                ["( )", "Every opening bracket has a closing one."],
                [
                  'F2 not "F2"',
                  "No quote marks around cell references. Quotes turn it into text.",
                ],
              ],
            },
          },
          {
            tip: "Excel colours each cell reference in a formula and draws a matching box on the sheet. If the box is not where you expect, the reference is wrong.",
          },
        ],
      },
      dollar: {
        title: "Lock the table, not the lookup value",
        blocks: [
          {
            p: "When you fill a formula down, Excel moves every reference down a row, unless it has <b>$</b> signs. For VLOOKUP you want one part to move and one part to stay still.",
          },
          {
            visual: {
              sheets: [
                {
                  tab: "Data",
                  cols: ["F", "G"],
                  start: 1,
                  hdRow: 1,
                  data: [
                    ["Plan", "Monthly cost"],
                    ["STD", "=VLOOKUP(F2, Analysis!$E$13:$F$15, 2, FALSE)"],
                    ["BAS", "=VLOOKUP(F3, Analysis!$E$13:$F$15, 2, FALSE)"],
                    ["PRE", "=VLOOKUP(F4, Analysis!$E$13:$F$15, 2, FALSE)"],
                  ],
                  hl: { F2: "look", F3: "look", F4: "look" },
                },
              ],
            },
          },
          {
            table: {
              rows: [
                [
                  "F2",
                  "<b>Should move</b> (F2, F3, F4...) so each row looks up its own plan. No $.",
                ],
                [
                  "$E$13:$F$15",
                  "<b>Must stay still</b> so every row searches the whole table. Locked with $.",
                ],
              ],
            },
          },
          {
            tip: "Click inside the range in the formula bar and press <b>F4</b> to add the $ signs. On some laptops it is <b>Fn + F4</b>.",
          },
        ],
      },
      bug: {
        title: "Reading error messages",
        blocks: [
          {
            p: "An error message is a clue, not a dead end. Match the clue to the cause.",
          },
          {
            table: {
              head: ["You see", "Most likely cause", "Fix"],
              rows: [
                [
                  "#N/A",
                  "Value not in column 1: a typo, an extra space, or a number stored as text.",
                  "Check spelling, use <code>TRIM</code>, check data types.",
                ],
                [
                  "#REF!",
                  "Column number wider than the table.",
                  "Count the columns of the range again.",
                ],
                [
                  "#NAME?",
                  "Function or sheet name misspelt.",
                  "Check spelling and the ! after sheet names.",
                ],
                [
                  "Wrong answer",
                  "TRUE used, or the 4th argument left off (it defaults to TRUE).",
                  "Type FALSE.",
                ],
              ],
            },
          },
          {
            p: '<b>TRUE vs FALSE.</b> FALSE means exact match only: use it for codes, names and IDs. TRUE means "closest match without going over" and only works if column 1 is sorted smallest to largest, e.g. grade boundaries.',
          },
          {
            tip: '<b>Dashboard tip:</b> <code>=IFERROR(VLOOKUP(F2, Analysis!$E$13:$F$15, 2, FALSE), "Not found")</code> shows a friendly message instead of #N/A. Only add it once the formula works, or it will hide real mistakes.',
          },
        ],
      },
    },
    cheat: {
      title: "VLOOKUP checklist for Task 2 (open me)",
      rows: [
        [
          "1",
          "Lookup value first, then table, then column number, then FALSE.",
        ],
        ["2", "The table starts with the column you are searching."],
        ["3", "Leave the header row out of the table range."],
        ["4", "Count the column number from the left edge of the table."],
        ["5", "Lock the table with $ (F4) before filling down."],
        ["6", "Always type FALSE. Leaving it off means TRUE."],
        [
          "7",
          "#N/A? Check spelling, spaces (TRIM) and numbers stored as text.",
        ],
        [
          "8",
          "Read it back with the sentence frame to check it says what you mean.",
        ],
      ],
    },
    ratings: [
      "VLOOKUP Legend",
      "Lookup Pro",
      "Getting There",
      "Keep Practising",
    ],
    footer: o,
  };
export { a as COLORS, g as VLOOKUP_GAME };
