import { j as e, r as C } from "./react-vendor-BK1G6oO1.js";
import { I as rs } from "./immersive-picker-PA4Q0OWd.js";
import { u as Mt } from "./keyword-flashcards-Ha6Msavb.js";
import { p as Wt, c as is } from "./helpers-DmEFZcxj.js";
import { s as ns, t as as } from "./ui-components-DeMDYLzO.js";
const Ue = {
  police: "Log 0417: van on Mill Road",
  hospital: "Scan booked: ward 6, 3pm",
  civil: "Passport 5521: approved",
  threadline: "Order 88213: two jumpers",
  law: "Draft contract, version 3",
  vidora: "Unreleased video: launch",
};
function Ge(t) {
  const s = "#%&*@$?!";
  return Array.from(t)
    .map((r, i) => {
      if (r === " ") return i % 3 === 0 ? "x" : " ";
      const a = r.charCodeAt(0);
      return /[a-z]/i.test(r)
        ? String.fromCharCode(97 + ((a * 7 + i * 11) % 26))
        : /\d/.test(r)
          ? String((a * 3 + i) % 10)
          : s[(a + i) % s.length];
    })
    .join("");
}
function os(t, s) {
  switch (s) {
    case "model":
      return `the computers inside ${t.hub}`;
    case "storage":
      return `where ${t.records.toLowerCase()} are kept`;
    case "bandwidth":
      return `${t.hub}’s line out to the internet`;
    case "area":
      return `inside the ${t.area.noun}`;
    case "wifi":
      return `the Wi-Fi at ${t.sites[1]}`;
  }
}
function vt(t) {
  return t === "threadline" || t === "law";
}
const ls = 800,
  cs = 480,
  h = "#1f2a44",
  hs = "Fredoka, ui-rounded, system-ui, sans-serif",
  c = { stroke: h, strokeWidth: 2, strokeLinejoin: "round" },
  _e = { ...c, strokeLinecap: "round", fill: "none" },
  n = {
    sky: "#e8f4ff",
    grass: "#d6f5e3",
    grassDot: "#b9ebcf",
    road: "#f3ead6",
    paper: "#fff8ec",
    white: "#ffffff",
    blue: "#9fc3e6",
    cable: "#4a7bd0",
    peach: "#ffb38a",
    lilac: "#c9b8ff",
    mint: "#7dd8b5",
    mintDeep: "#2f9e76",
    mintWash: "#e3f8ee",
    yellow: "#ffd166",
    pink: "#ff9fbf",
    amber: "#f2a541",
    amberWash: "#fff1dc",
    grey: "#cfd6e4",
    greyDeep: "#9aa6c4",
    navy: "#2d3a5c",
    blueprint: "#eaf2ff",
    blueprintLine: "#cfe0fb",
  },
  y = { light: "#f6cfa8", mid: "#d9a07a", dark: "#8d5a3b" },
  E = { dark: "#3b2a20", fair: "#f2c14e", red: "#c4562b", grey: "#b8b8c4" };
function Lt(t) {
  const s = t / 800;
  return {
    hq: [400 * s, 236],
    riverside: [130 * s, 360],
    elmbridge: [150 * s, 140],
    castle: [660 * s, 134],
    millbrook: [668 * s, 356],
  };
}
function O(t, s, r = 0.5) {
  return [t[0] + (s[0] - t[0]) * r, t[1] + (s[1] - t[1]) * r];
}
function v({
  x: t,
  y: s,
  children: r,
  size: i = 14,
  weight: a = 600,
  anchor: o = "start",
  fill: l = h,
}) {
  return e.jsx("text", {
    x: t,
    y: s,
    textAnchor: o,
    fontSize: i,
    fontWeight: a,
    fontFamily: hs,
    fill: l,
    children: r,
  });
}
function ds({
  x: t,
  y: s,
  w: r,
  h: i,
  fill: a = n.white,
  r: o = 14,
  strokeWidth: l = 2,
  dashed: d = !1,
  children: x,
}) {
  return e.jsxs("g", {
    children: [
      e.jsx("rect", {
        x: t,
        y: s,
        width: r,
        height: i,
        rx: o,
        fill: a,
        ...c,
        strokeWidth: l,
        strokeDasharray: d ? "6 5" : void 0,
      }),
      x,
    ],
  });
}
function N({ x: t, y: s, s: r = 1, fill: i = n.mintDeep }) {
  return e.jsxs("g", {
    transform: `translate(${t} ${s}) scale(${r})`,
    children: [
      e.jsx("circle", { r: "10", fill: i }),
      e.jsx("path", {
        d: "M-4.5 0.5 L-1.2 3.8 L5 -3.5",
        fill: "none",
        stroke: "#fff",
        strokeWidth: "2.6",
        strokeLinecap: "round",
        strokeLinejoin: "round",
      }),
    ],
  });
}
function Z({ x: t, y: s, s: r = 1 }) {
  return e.jsxs("g", {
    transform: `translate(${t} ${s}) scale(${r})`,
    children: [
      e.jsx("circle", { r: "10", fill: n.amber }),
      e.jsx("rect", {
        x: "-4.5",
        y: "-4.5",
        width: "3",
        height: "9",
        rx: "1.2",
        fill: "#fff",
      }),
      e.jsx("rect", {
        x: "1.5",
        y: "-4.5",
        width: "3",
        height: "9",
        rx: "1.2",
        fill: "#fff",
      }),
    ],
  });
}
function Nt({ x: t, y: s, r = 22 }) {
  return e.jsxs("g", {
    transform: `translate(${t} ${s})`,
    children: [
      Array.from({ length: 8 }, (i, a) =>
        e.jsx(
          "path",
          {
            d: `M0 ${-r - 6} V${-r - 13}`,
            stroke: "#f2b84b",
            strokeWidth: "3",
            strokeLinecap: "round",
            transform: `rotate(${a * 45})`,
          },
          a,
        ),
      ),
      e.jsx("circle", { r, fill: n.yellow, ...c }),
    ],
  });
}
function re({ x: t, y: s, s: r = 1, fill: i = "#fff" }) {
  return e.jsx("path", {
    transform: `translate(${t} ${s}) scale(${r})`,
    d: "M-34 10 Q-38 -6 -22 -8 Q-18 -24 0 -22 Q16 -30 24 -12 Q40 -12 36 10Z",
    fill: i,
    ...c,
  });
}
function D({ x: t, y: s, s: r = 1 }) {
  return e.jsxs("g", {
    transform: `translate(${t} ${s}) scale(${r})`,
    children: [
      e.jsx("rect", {
        x: "-3",
        y: "-14",
        width: "6",
        height: "14",
        fill: "#b07a50",
        ...c,
        strokeWidth: 1.5,
      }),
      e.jsx("circle", {
        cy: "-24",
        r: "14",
        fill: "#8fdcae",
        ...c,
        strokeWidth: 1.5,
      }),
    ],
  });
}
function Pe({ n: t = 40, w: s = ls, h: r = cs, y0: i = 0 }) {
  return e.jsx("g", {
    children: Array.from({ length: t }, (a, o) =>
      e.jsx(
        "circle",
        {
          cx: (o * 137) % s,
          cy: i + ((o * 71) % r),
          r: "2.6",
          fill: n.grassDot,
        },
        o,
      ),
    ),
  });
}
function Oe({
  x: t,
  y: s,
  w: r,
  h: i,
  wall: a = n.paper,
  roof: o = n.blue,
  lit: l = !0,
  cols: d = 3,
  rows: x = 2,
  label: f,
}) {
  const p = (r - 16) / d - 6,
    k = Math.max(6, (i - 22) / x - 8),
    j = Math.min(15, i * 0.45);
  return e.jsxs("g", {
    children: [
      e.jsx("rect", {
        x: t - 4,
        y: s - 8,
        width: r + 8,
        height: "12",
        rx: "3",
        fill: o,
        ...c,
      }),
      e.jsx("rect", { x: t, y: s, width: r, height: i, fill: a, ...c }),
      Array.from({ length: x }, (u, m) =>
        Array.from({ length: d }, (g, b) =>
          e.jsx(
            "rect",
            {
              x: t + 11 + b * (p + 6),
              y: s + 9 + m * (k + 8),
              width: p,
              height: k,
              rx: "2",
              fill: l ? n.yellow : n.grey,
              stroke: h,
              strokeWidth: "1.5",
            },
            `${m}-${b}`,
          ),
        ),
      ),
      e.jsx("rect", {
        x: t + r / 2 - 7,
        y: s + i - j,
        width: "14",
        height: j,
        fill: l ? n.peach : n.greyDeep,
        stroke: h,
        strokeWidth: "1.5",
      }),
      f ? e.jsx(w, { x: t + r / 2, y: s + i + 18, text: f }) : null,
    ],
  });
}
function w({
  x: t,
  y: s,
  text: r,
  size: i = 12,
  fill: a = n.white,
  muted: o = !1,
}) {
  const l = r.length * i * 0.56 + 16;
  return e.jsxs("g", {
    opacity: o ? 0.6 : 1,
    children: [
      e.jsx("rect", {
        x: t - l / 2,
        y: s - i * 0.95,
        width: l,
        height: i * 1.6,
        rx: i * 0.8,
        fill: a,
        stroke: h,
        strokeWidth: "1.5",
      }),
      e.jsx(v, {
        x: t,
        y: s + i * 0.3,
        size: i,
        anchor: "middle",
        children: r,
      }),
    ],
  });
}
function Q({ x: t, y: s, colour: r = n.blue, screen: i = "#fff", s: a = 1 }) {
  return e.jsxs("g", {
    transform: `translate(${t} ${s}) scale(${a})`,
    children: [
      e.jsx("rect", {
        x: "-24",
        y: "-30",
        width: "48",
        height: "34",
        rx: "5",
        fill: r,
        ...c,
      }),
      e.jsx("rect", {
        x: "-19",
        y: "-25",
        width: "38",
        height: "24",
        rx: "3",
        fill: i,
      }),
      e.jsx("path", { d: "M-7 4v6h14v-6", fill: n.greyDeep, ...c }),
      e.jsx("rect", {
        x: "-14",
        y: "10",
        width: "28",
        height: "4",
        rx: "2",
        fill: n.greyDeep,
        ...c,
        strokeWidth: 1.5,
      }),
    ],
  });
}
function z({ x: t, y: s, s: r = 1, rotate: i = 0, screen: a = "#dff3ff" }) {
  return e.jsxs("g", {
    transform: `translate(${t} ${s}) rotate(${i}) scale(${r})`,
    children: [
      e.jsx("rect", {
        x: "-13",
        y: "-18",
        width: "26",
        height: "36",
        rx: "4",
        fill: n.navy,
        ...c,
      }),
      e.jsx("rect", {
        x: "-10",
        y: "-14",
        width: "20",
        height: "27",
        rx: "2",
        fill: a,
      }),
    ],
  });
}
function At({ x: t, y: s, s: r = 1 }) {
  return e.jsxs("g", {
    transform: `translate(${t} ${s}) scale(${r})`,
    children: [
      e.jsx("rect", {
        x: "-14",
        y: "-24",
        width: "28",
        height: "12",
        rx: "2",
        fill: "#fff",
        ...c,
      }),
      e.jsx("rect", {
        x: "-22",
        y: "-13",
        width: "44",
        height: "24",
        rx: "6",
        fill: n.mint,
        ...c,
      }),
      e.jsx("rect", {
        x: "-12",
        y: "8",
        width: "24",
        height: "9",
        rx: "2",
        fill: "#fff",
        ...c,
      }),
    ],
  });
}
function Qe({ x: t, y: s, s: r = 1, lights: i = !0 }) {
  return e.jsxs("g", {
    transform: `translate(${t} ${s}) scale(${r})`,
    children: [
      e.jsx("rect", {
        x: "-34",
        y: "-12",
        width: "68",
        height: "24",
        rx: "5",
        fill: n.lilac,
        ...c,
      }),
      [-24, -14, -4, 6, 16, 26].map((a) =>
        e.jsxs(
          "g",
          {
            children: [
              e.jsx("rect", {
                x: a - 3,
                y: "-3",
                width: "7",
                height: "7",
                rx: "1",
                fill: h,
              }),
              e.jsx("circle", {
                cx: a + 0.5,
                cy: "-7",
                r: "1.6",
                fill: i ? n.mintDeep : n.greyDeep,
              }),
            ],
          },
          a,
        ),
      ),
    ],
  });
}
function Te({ x: t, y: s, s: r = 1 }) {
  return e.jsxs("g", {
    transform: `translate(${t} ${s}) scale(${r})`,
    children: [
      e.jsx("path", {
        d: "M-20 -10 L-26 -30 M20 -10 L26 -30",
        ..._e,
        strokeWidth: 2.5,
      }),
      e.jsx("circle", { cx: "-26", cy: "-31", r: "3", fill: h }),
      e.jsx("circle", { cx: "26", cy: "-31", r: "3", fill: h }),
      e.jsx("rect", {
        x: "-32",
        y: "-12",
        width: "64",
        height: "26",
        rx: "8",
        fill: n.peach,
        ...c,
      }),
      e.jsx("path", {
        d: "M-14 1 H14 M8 -5 L14 1 L8 7 M-8 -5 L-14 1 L-8 7",
        ..._e,
        strokeWidth: 2.2,
      }),
    ],
  });
}
function F({ x: t, y: s, s: r = 1, waves: i = !0 }) {
  return e.jsxs("g", {
    transform: `translate(${t} ${s}) scale(${r})`,
    children: [
      e.jsx("path", {
        d: "M-22 0 Q-22 -14 0 -14 Q22 -14 22 0Z",
        fill: n.white,
        ...c,
      }),
      e.jsx("rect", {
        x: "-24",
        y: "-2",
        width: "48",
        height: "6",
        rx: "3",
        fill: n.blue,
        ...c,
      }),
      e.jsx("circle", { cx: "0", cy: "-7", r: "2.4", fill: n.mintDeep }),
      i
        ? e.jsx("path", {
            d: "M-16 16 Q0 30 16 16 M-10 23 Q0 31 10 23",
            fill: "none",
            stroke: n.cable,
            strokeWidth: "2.6",
            strokeLinecap: "round",
          })
        : null,
    ],
  });
}
function Ht({ x: t, y: s, s: r = 1 }) {
  return e.jsxs("g", {
    transform: `translate(${t} ${s}) scale(${r})`,
    children: [
      e.jsx("rect", {
        x: "-26",
        y: "-14",
        width: "52",
        height: "24",
        rx: "3",
        fill: n.mint,
        ...c,
      }),
      e.jsx("rect", {
        x: "-20",
        y: "10",
        width: "34",
        height: "6",
        fill: n.yellow,
        ...c,
        strokeWidth: 1.5,
      }),
      e.jsx("rect", {
        x: "14",
        y: "-9",
        width: "9",
        height: "12",
        rx: "1",
        fill: n.white,
        ...c,
        strokeWidth: 1.5,
      }),
      e.jsx("rect", {
        x: "-18",
        y: "-8",
        width: "12",
        height: "10",
        rx: "1",
        fill: n.navy,
      }),
      e.jsx("rect", {
        x: "-2",
        y: "-8",
        width: "10",
        height: "4",
        rx: "1",
        fill: n.navy,
        opacity: 0.6,
      }),
    ],
  });
}
function Ke({ x: t, y: s, s: r = 1 }) {
  return e.jsxs("g", {
    transform: `translate(${t} ${s}) scale(${r})`,
    children: [
      e.jsx("ellipse", {
        rx: "20",
        ry: "13",
        fill: "none",
        stroke: n.cable,
        strokeWidth: "5",
      }),
      e.jsx("ellipse", {
        rx: "12",
        ry: "7",
        fill: "none",
        stroke: n.cable,
        strokeWidth: "5",
      }),
      e.jsx("path", {
        d: "M18 6 Q30 12 28 22",
        fill: "none",
        stroke: n.cable,
        strokeWidth: "5",
        strokeLinecap: "round",
      }),
      e.jsx("rect", {
        x: "23",
        y: "20",
        width: "10",
        height: "9",
        rx: "1.5",
        fill: n.white,
        ...c,
        strokeWidth: 1.5,
      }),
    ],
  });
}
function S({ x: t, y: s, s: r = 1, colour: i = n.blue }) {
  return e.jsxs("g", {
    transform: `translate(${t} ${s}) scale(${r})`,
    children: [
      e.jsx("rect", {
        x: "-18",
        y: "-32",
        width: "36",
        height: "64",
        rx: "5",
        fill: i,
        ...c,
      }),
      [-22, -8, 6].map((a) =>
        e.jsxs(
          "g",
          {
            children: [
              e.jsx("rect", {
                x: "-12",
                y: a,
                width: "24",
                height: "9",
                rx: "2",
                fill: n.white,
                ...c,
                strokeWidth: 1.5,
              }),
              e.jsx("circle", {
                cx: "7",
                cy: a + 4.5,
                r: "1.8",
                fill: n.mintDeep,
              }),
            ],
          },
          a,
        ),
      ),
    ],
  });
}
function Ye({ x: t, y: s, s: r = 1 }) {
  return e.jsxs("g", {
    transform: `translate(${t} ${s}) scale(${r})`,
    children: [
      e.jsx(re, { x: 0, y: 0, s: 1.1, fill: n.blueprint }),
      e.jsx("rect", {
        x: "-9",
        y: "-12",
        width: "18",
        height: "6",
        rx: "2",
        fill: n.blue,
        ...c,
        strokeWidth: 1.4,
      }),
      e.jsx("rect", {
        x: "-9",
        y: "-4",
        width: "18",
        height: "6",
        rx: "2",
        fill: n.blue,
        ...c,
        strokeWidth: 1.4,
      }),
    ],
  });
}
function G({ from: t, to: s, n: r = 5, fill: i = n.cable, r: a = 3.4 }) {
  return e.jsx("g", {
    children: Array.from({ length: r }, (o, l) => {
      const d = (l + 0.5) / r;
      return e.jsx(
        "circle",
        {
          cx: t[0] + (s[0] - t[0]) * d,
          cy: t[1] + (s[1] - t[1]) * d,
          r: a,
          fill: i,
          stroke: "#fff",
          strokeWidth: "1.2",
        },
        l,
      );
    }),
  });
}
function be({ from: t, to: s, state: r = "live", width: i = 5 }) {
  const a = `M${t[0]} ${t[1]} L${s[0]} ${s[1]}`;
  if (r === "cut") {
    const o = (t[0] + s[0]) / 2,
      l = (t[1] + s[1]) / 2,
      d = (s[0] - t[0]) * 0.06,
      x = (s[1] - t[1]) * 0.06;
    return e.jsxs("g", {
      children: [
        e.jsx("path", {
          d: `M${t[0]} ${t[1]} L${o - d} ${l - x}`,
          stroke: n.greyDeep,
          strokeWidth: i,
          strokeLinecap: "round",
        }),
        e.jsx("path", {
          d: `M${o + d} ${l + x} L${s[0]} ${s[1]}`,
          stroke: n.greyDeep,
          strokeWidth: i,
          strokeLinecap: "round",
        }),
      ],
    });
  }
  return e.jsxs("g", {
    children: [
      r === "glow"
        ? e.jsx("path", {
            d: a,
            stroke: n.mint,
            strokeWidth: i + 9,
            strokeLinecap: "round",
            opacity: 0.7,
          })
        : null,
      e.jsx("path", {
        d: a,
        stroke: r === "off" ? n.greyDeep : n.cable,
        strokeWidth: i,
        strokeLinecap: "round",
        strokeDasharray: r === "off" ? "3 9" : void 0,
      }),
    ],
  });
}
const xs = {
  officer: { top: n.navy, legs: "#25304d" },
  "call-handler": { top: n.blue, legs: "#4b5a7a", ear: "headset" },
  nurse: { top: "#8ad3dc", legs: "#8ad3dc" },
  doctor: { top: "#ffffff", legs: "#4b5a7a" },
  porter: { top: "#76c2b0", legs: "#76c2b0" },
  caseworker: { top: "#c4b3ee", legs: "#4b5a7a" },
  picker: { top: "#a9b3cc", legs: "#4b5a7a" },
  designer: { top: "#ffadc4", legs: "#4b5a7a" },
  lawyer: { top: "#3d4663", legs: "#3d4663" },
  producer: { top: "#aa9cf2", legs: "#4b5a7a", ear: "headset" },
  presenter: { top: "#b8e2f8", legs: "#4b5a7a" },
  creator: { top: "#ffd3bd", legs: "#4b5a7a", ear: "headphones" },
  engineer: { top: n.mint, legs: "#4b5a7a" },
  public: { top: "#ffc9a8", legs: "#4b5a7a" },
};
function He({ colour: t }) {
  return e.jsxs("g", {
    children: [
      e.jsx("path", {
        d: "M-6 -78 L0 -62 L6 -78",
        fill: "none",
        stroke: t,
        strokeWidth: 1.8,
      }),
      e.jsx("rect", {
        x: "-5",
        y: "-62",
        width: "10",
        height: "13",
        rx: "2",
        fill: "#fff",
        stroke: h,
        strokeWidth: 1.3,
      }),
    ],
  });
}
function Se({ fill: t = "#fff" }) {
  return e.jsx("path", {
    d: "M-7 -79 L0 -66 L7 -79Z",
    fill: t,
    stroke: h,
    strokeWidth: 1.3,
    strokeLinejoin: "round",
  });
}
function fs({ outfit: t }) {
  switch (t) {
    case "officer":
      return e.jsxs("g", {
        children: [
          e.jsx("path", {
            d: "M-17 -42 L-18 -70 Q-10 -76 -4 -77 L-4 -42Z M17 -42 L18 -70 Q10 -76 4 -77 L4 -42Z",
            fill: "#d8ef5b",
            stroke: h,
            strokeWidth: 1.4,
          }),
          e.jsx("path", {
            d: "M-18 -52 H-4 M4 -52 H18",
            stroke: "#e6e9f2",
            strokeWidth: 3,
          }),
        ],
      });
    case "call-handler":
      return e.jsx(He, { colour: n.cable });
    case "nurse":
      return e.jsxs("g", {
        children: [
          e.jsx("path", {
            d: "M-7 -79 L0 -68 L7 -79",
            fill: "none",
            stroke: "#fff",
            strokeWidth: 2.2,
            strokeLinejoin: "round",
          }),
          e.jsx("circle", {
            cx: "-9",
            cy: "-64",
            r: "3",
            fill: "#fff",
            stroke: h,
            strokeWidth: 1.2,
          }),
          e.jsx("path", {
            d: "M5 -58 H13 V-50 H5Z",
            fill: "none",
            stroke: h,
            strokeWidth: 1.1,
          }),
        ],
      });
    case "doctor":
      return e.jsxs("g", {
        children: [
          e.jsx("path", {
            d: "M-7 -79 L0 -62 L7 -79Z",
            fill: "#8ad3dc",
            stroke: h,
            strokeWidth: 1.3,
            strokeLinejoin: "round",
          }),
          e.jsx("path", {
            d: "M-7 -79 L-2 -56 M7 -79 L2 -56 M0 -60 V-40",
            fill: "none",
            stroke: h,
            strokeWidth: 1.3,
          }),
          e.jsx("path", {
            d: "M-9 -79 Q-12 -62 -4 -58 Q4 -62 9 -79",
            fill: "none",
            stroke: n.navy,
            strokeWidth: 2,
          }),
          e.jsx("circle", {
            cx: "-4",
            cy: "-56",
            r: "2.8",
            fill: n.grey,
            stroke: h,
            strokeWidth: 1.2,
          }),
        ],
      });
    case "porter":
      return e.jsxs("g", {
        children: [
          e.jsx("path", {
            d: "M-7 -79 L0 -68 L7 -79",
            fill: "none",
            stroke: "#fff",
            strokeWidth: 2.2,
            strokeLinejoin: "round",
          }),
          e.jsx(He, { colour: n.mintDeep }),
        ],
      });
    case "caseworker":
      return e.jsxs("g", {
        children: [e.jsx(Se, {}), e.jsx(He, { colour: "#8f7bd6" })],
      });
    case "picker":
      return e.jsxs("g", {
        children: [
          e.jsx("path", {
            d: "M-17 -42 L-18 -70 Q-10 -76 -4 -77 L-4 -42Z M17 -42 L18 -70 Q10 -76 4 -77 L4 -42Z",
            fill: "#ffc48a",
            stroke: h,
            strokeWidth: 1.4,
          }),
          e.jsx("path", {
            d: "M-18 -50 H-4 M4 -50 H18 M-18 -60 H-4 M4 -60 H18",
            stroke: "#fff",
            strokeWidth: 2.6,
          }),
        ],
      });
    case "designer":
      return e.jsxs("g", {
        children: [
          e.jsx(Se, {}),
          e.jsx("path", {
            d: "M-9 -79 Q-13 -62 -10 -46 M9 -79 Q13 -62 10 -50",
            fill: "none",
            stroke: h,
            strokeWidth: 5.4,
            strokeLinecap: "round",
          }),
          e.jsx("path", {
            d: "M-9 -79 Q-13 -62 -10 -46 M9 -79 Q13 -62 10 -50",
            fill: "none",
            stroke: n.yellow,
            strokeWidth: 3.2,
            strokeLinecap: "round",
          }),
        ],
      });
    case "lawyer":
      return e.jsxs("g", {
        children: [
          e.jsx(Se, {}),
          e.jsx("path", {
            d: "M0 -75 L-2.6 -70 L0 -60 L2.6 -70Z",
            fill: "#e6c784",
            stroke: h,
            strokeWidth: 1,
            strokeLinejoin: "round",
          }),
          e.jsx("path", {
            d: "M-7 -79 L-3 -54 M7 -79 L3 -54",
            fill: "none",
            stroke: "#6b7594",
            strokeWidth: 1.4,
          }),
        ],
      });
    case "producer":
      return e.jsx(He, { colour: "#7d6be0" });
    case "presenter":
      return e.jsxs("g", {
        children: [
          e.jsx(Se, {}),
          e.jsx("path", {
            d: "M-7 -79 L-3 -54 M7 -79 L3 -54",
            fill: "none",
            stroke: h,
            strokeWidth: 1.3,
          }),
          e.jsx("circle", { cx: "-7", cy: "-64", r: "2", fill: h }),
        ],
      });
    case "creator":
      return e.jsxs("g", {
        children: [
          e.jsx("path", {
            d: "M-13 -80 Q0 -70 13 -80",
            fill: "none",
            stroke: h,
            strokeWidth: 1.6,
          }),
          e.jsx("path", {
            d: "M-3 -75 V-65 M3 -75 V-65",
            stroke: "#fff",
            strokeWidth: 1.8,
            strokeLinecap: "round",
          }),
          e.jsx("path", {
            d: "M-10 -54 H10 L8 -45 H-8Z",
            fill: "none",
            stroke: h,
            strokeWidth: 1.3,
            strokeLinejoin: "round",
          }),
        ],
      });
    case "engineer":
      return e.jsxs("g", {
        children: [
          e.jsx("path", {
            d: "M-6 -78 L0 -60 L6 -78",
            fill: "none",
            stroke: n.navy,
            strokeWidth: 1.6,
          }),
          e.jsx("rect", {
            x: "-5",
            y: "-60",
            width: "10",
            height: "13",
            rx: "2",
            fill: "#fff",
            stroke: h,
            strokeWidth: 1.3,
          }),
        ],
      });
    case "public":
      return e.jsx("path", {
        d: "M-8 -79 Q0 -73 8 -79",
        fill: "none",
        stroke: h,
        strokeWidth: 1.4,
      });
  }
}
function js({ ear: t }) {
  switch (t) {
    case "headset":
      return e.jsxs("g", {
        children: [
          e.jsx("path", {
            d: "M-14 -98 Q-15 -116 0 -116 Q15 -116 14 -98",
            fill: "none",
            stroke: n.navy,
            strokeWidth: 2.4,
          }),
          e.jsx("rect", {
            x: "-17",
            y: "-101",
            width: "6",
            height: "10",
            rx: "2",
            fill: n.navy,
          }),
          e.jsx("path", {
            d: "M-14 -92 Q-12 -84 -4 -86",
            fill: "none",
            stroke: n.navy,
            strokeWidth: 1.8,
            strokeLinecap: "round",
          }),
          e.jsx("circle", { cx: "-4", cy: "-86", r: "1.8", fill: n.navy }),
        ],
      });
    case "headphones":
      return e.jsxs("g", {
        children: [
          e.jsx("path", {
            d: "M-15 -97 Q-16 -118 0 -118 Q16 -118 15 -97",
            fill: "none",
            stroke: n.navy,
            strokeWidth: 3.4,
          }),
          e.jsx("rect", {
            x: "-19",
            y: "-104",
            width: "8",
            height: "14",
            rx: "3",
            fill: n.lilac,
            stroke: h,
            strokeWidth: 1.4,
          }),
          e.jsx("rect", {
            x: "11",
            y: "-104",
            width: "8",
            height: "14",
            rx: "3",
            fill: n.lilac,
            stroke: h,
            strokeWidth: 1.4,
          }),
        ],
      });
    case "earpiece":
      return e.jsxs("g", {
        children: [
          e.jsx("circle", {
            cx: "-13",
            cy: "-95",
            r: "2.6",
            fill: n.navy,
            stroke: h,
            strokeWidth: 1,
          }),
          e.jsx("path", {
            d: "M-13 -93 q-3 4 0 6 q3 2 0 6 q-2 3 -4 6",
            fill: "none",
            stroke: h,
            strokeWidth: 1.2,
          }),
        ],
      });
    case "earbuds":
      return e.jsxs("g", {
        children: [
          e.jsx("circle", {
            cx: "-13",
            cy: "-94",
            r: "2.6",
            fill: "#fff",
            stroke: h,
            strokeWidth: 1.2,
          }),
          e.jsx("circle", {
            cx: "13",
            cy: "-94",
            r: "2.6",
            fill: "#fff",
            stroke: h,
            strokeWidth: 1.2,
          }),
        ],
      });
  }
}
function $({
  x: t,
  y: s,
  s: r = 1,
  outfit: i = "public",
  skin: a = y.light,
  hair: o = E.dark,
  long: l = !1,
  mood: d = "happy",
  ear: x,
  holding: f,
}) {
  const p = xs[i],
    k = x === "none" ? void 0 : (x ?? p.ear),
    j = i === "doctor";
  return e.jsxs("g", {
    transform: `translate(${t} ${s}) scale(${r})`,
    "data-person": i,
    children: [
      e.jsx("ellipse", {
        cx: "0",
        cy: "1",
        rx: "22",
        ry: "3.5",
        fill: h,
        opacity: 0.12,
      }),
      e.jsx("rect", {
        x: "-12",
        y: "-42",
        width: "10",
        height: "42",
        rx: "3",
        fill: p.legs,
        ...c,
        strokeWidth: 1.6,
      }),
      e.jsx("rect", {
        x: "2",
        y: "-42",
        width: "10",
        height: "42",
        rx: "3",
        fill: p.legs,
        ...c,
        strokeWidth: 1.6,
      }),
      e.jsx("path", {
        d: "M-14 0 h13 v-5 h-11Z M1 0 h13 l-2 -5 h-11Z",
        fill: h,
      }),
      l
        ? e.jsx("path", {
            d: "M-14 -96 Q-18 -70 -10 -66 H10 Q18 -70 14 -96Z",
            fill: o,
            ...c,
            strokeWidth: 1.6,
          })
        : null,
      e.jsx("path", {
        d: "M-20 -38 Q-22 -78 0 -80 Q22 -78 20 -38Z",
        fill: p.top,
        ...c,
        strokeWidth: 1.8,
      }),
      e.jsx(fs, { outfit: i }),
      j
        ? e.jsx("path", {
            d: "M-19 -72 Q-28 -56 -24 -40 M19 -72 Q26 -60 18 -50",
            fill: "none",
            stroke: h,
            strokeWidth: 12,
            strokeLinecap: "round",
          })
        : null,
      e.jsx("path", {
        d: "M-19 -72 Q-28 -56 -24 -40",
        fill: "none",
        stroke: p.top,
        strokeWidth: 9,
        strokeLinecap: "round",
      }),
      e.jsx("circle", {
        cx: "-24",
        cy: "-39",
        r: "4.5",
        fill: a,
        stroke: h,
        strokeWidth: 1.4,
      }),
      e.jsx("path", {
        d: "M19 -72 Q26 -60 18 -50",
        fill: "none",
        stroke: p.top,
        strokeWidth: 9,
        strokeLinecap: "round",
      }),
      e.jsx("circle", {
        cx: "16",
        cy: "-49",
        r: "4.5",
        fill: a,
        stroke: h,
        strokeWidth: 1.4,
      }),
      f ? e.jsx("g", { transform: "translate(16 -52)", children: f }) : null,
      e.jsx("rect", { x: "-4", y: "-86", width: "8", height: "8", fill: a }),
      e.jsx("circle", {
        cx: "0",
        cy: "-96",
        r: "13",
        fill: a,
        ...c,
        strokeWidth: 1.8,
      }),
      i === "officer"
        ? e.jsxs("g", {
            children: [
              e.jsx("path", {
                d: "M-14 -101 Q-14 -114 0 -114 Q14 -114 14 -101Z",
                fill: n.navy,
                ...c,
                strokeWidth: 1.6,
              }),
              e.jsx("rect", {
                x: "-15",
                y: "-104",
                width: "30",
                height: "5",
                fill: "#fff",
                stroke: h,
                strokeWidth: 1.2,
              }),
              e.jsx("path", {
                d: "M-15 -100 H19",
                stroke: h,
                strokeWidth: 2.4,
                strokeLinecap: "round",
              }),
            ],
          })
        : e.jsx("path", {
            d: "M-13 -98 Q-15 -112 0 -111 Q15 -112 13 -98 Q8 -105 0 -104 Q-8 -105 -13 -98Z",
            fill: o,
            ...c,
            strokeWidth: 1.6,
          }),
      k ? e.jsx(js, { ear: k }) : null,
      e.jsx("circle", { cx: "-4.5", cy: "-95", r: "1.7", fill: h }),
      e.jsx("circle", { cx: "4.5", cy: "-95", r: "1.7", fill: h }),
      d === "happy"
        ? e.jsx("path", {
            d: "M-4 -90 Q0 -86.5 4 -90",
            fill: "none",
            stroke: h,
            strokeWidth: 1.5,
            strokeLinecap: "round",
          })
        : d === "thinking"
          ? e.jsxs("g", {
              children: [
                e.jsx("path", {
                  d: "M-3 -89 H3",
                  stroke: h,
                  strokeWidth: 1.5,
                  strokeLinecap: "round",
                }),
                e.jsx("path", {
                  d: "M2 -100 Q5 -102 8 -100",
                  fill: "none",
                  stroke: h,
                  strokeWidth: 1.3,
                  strokeLinecap: "round",
                }),
              ],
            })
          : e.jsx("path", {
              d: "M-3.5 -89.5 H3.5",
              stroke: h,
              strokeWidth: 1.5,
              strokeLinecap: "round",
            }),
    ],
  });
}
function Y({ kind: t }) {
  switch (t) {
    case "location":
      return e.jsxs("g", {
        children: [
          e.jsx("path", {
            d: "M0 -30 C-9 -30 -11 -22 -8 -17 L0 -6 L8 -17 C11 -22 9 -30 0 -30Z",
            fill: n.pink,
            ...c,
            strokeWidth: 1.6,
          }),
          e.jsx("circle", {
            cx: "0",
            cy: "-23",
            r: "3",
            fill: "#fff",
            stroke: h,
            strokeWidth: 1.2,
          }),
        ],
      });
    case "scan":
      return e.jsxs("g", {
        children: [
          e.jsx("rect", {
            x: "-11",
            y: "-32",
            width: "22",
            height: "24",
            rx: "3",
            fill: "#5d6c8f",
            ...c,
            strokeWidth: 1.6,
          }),
          e.jsx("ellipse", {
            cx: "-4",
            cy: "-20",
            rx: "3.6",
            ry: "6.5",
            fill: "#d3f2ec",
          }),
          e.jsx("ellipse", {
            cx: "4",
            cy: "-20",
            rx: "3.6",
            ry: "6.5",
            fill: "#d3f2ec",
          }),
          e.jsx("path", { d: "M0 -29 V-12", stroke: "#fff", strokeWidth: 1.4 }),
        ],
      });
    case "passport":
      return e.jsxs("g", {
        children: [
          e.jsx("rect", {
            x: "-9",
            y: "-33",
            width: "18",
            height: "25",
            rx: "2.5",
            fill: "#9f8be0",
            ...c,
            strokeWidth: 1.6,
          }),
          e.jsx("circle", {
            cx: "0",
            cy: "-24",
            r: "4.2",
            fill: "none",
            stroke: n.yellow,
            strokeWidth: 1.6,
          }),
          e.jsx("path", {
            d: "M-5 -14 H5",
            stroke: n.yellow,
            strokeWidth: 1.6,
            strokeLinecap: "round",
          }),
        ],
      });
    case "order":
      return e.jsxs("g", {
        children: [
          e.jsx("path", {
            d: "M-12 -24 L0 -30 L12 -24 V-10 L0 -5 L-12 -10Z",
            fill: "#e8c39a",
            ...c,
            strokeWidth: 1.6,
          }),
          e.jsx("path", {
            d: "M-12 -24 L0 -18 L12 -24 M0 -18 V-5",
            fill: "none",
            stroke: h,
            strokeWidth: 1.3,
          }),
          e.jsx("path", {
            d: "M-6 -27 L6 -21",
            stroke: n.pink,
            strokeWidth: 2.6,
          }),
          e.jsx("path", {
            d: "M3 -15 L9 -18 V-13 L3 -10Z",
            fill: "#fff",
            stroke: h,
            strokeWidth: 1,
            strokeLinejoin: "round",
          }),
        ],
      });
    case "contract":
      return e.jsxs("g", {
        children: [
          e.jsx("path", {
            d: "M-10 -34 H6 L10 -30 V-6 H-10Z",
            fill: "#fff",
            ...c,
            strokeWidth: 1.6,
          }),
          e.jsx("path", {
            d: "M-6 -28 H5 M-6 -24 H5 M-6 -20 H2",
            stroke: n.greyDeep,
            strokeWidth: 1.4,
            strokeLinecap: "round",
          }),
          e.jsx("path", {
            d: "M-7 -12 q2 -4 4 0 q2 4 4 -1",
            fill: "none",
            stroke: n.cable,
            strokeWidth: 1.4,
            strokeLinecap: "round",
          }),
          e.jsx("path", {
            d: "M6 -10 l-2 7 l3 -2 l2 3 l1 -7",
            fill: n.pink,
            stroke: h,
            strokeWidth: 1,
            strokeLinejoin: "round",
          }),
          e.jsx("circle", {
            cx: "7",
            cy: "-11",
            r: "4.4",
            fill: "#e6c784",
            stroke: h,
            strokeWidth: 1.3,
          }),
        ],
      });
    case "video":
      return e.jsxs("g", {
        children: [
          e.jsx("rect", {
            x: "-13",
            y: "-31",
            width: "26",
            height: "22",
            rx: "3",
            fill: n.navy,
            ...c,
            strokeWidth: 1.6,
          }),
          [-9, -3, 3, 9].map((s) =>
            e.jsxs(
              "g",
              {
                children: [
                  e.jsx("rect", {
                    x: s - 1.5,
                    y: "-29",
                    width: "3",
                    height: "2.4",
                    rx: "0.6",
                    fill: "#fff",
                  }),
                  e.jsx("rect", {
                    x: s - 1.5,
                    y: "-13.4",
                    width: "3",
                    height: "2.4",
                    rx: "0.6",
                    fill: "#fff",
                  }),
                ],
              },
              s,
            ),
          ),
          e.jsx("rect", {
            x: "-10",
            y: "-25",
            width: "20",
            height: "10",
            rx: "1.5",
            fill: "#b8e2f8",
          }),
          e.jsx("path", { d: "M-3 -23.5 L4 -20 L-3 -16.5Z", fill: h }),
        ],
      });
  }
}
function Me({ x: t, y: s, s: r = 1, sealed: i = !1, kind: a }) {
  return e.jsxs("g", {
    transform: `translate(${t} ${s}) scale(${r})`,
    "data-packet": a ?? "plain",
    children: [
      e.jsx("rect", {
        x: "-22",
        y: "-15",
        width: "44",
        height: "30",
        rx: "4",
        fill: n.paper,
        ...c,
      }),
      e.jsx("path", { d: "M-22 -13 L0 3 L22 -13", fill: "none", ...c }),
      a ? e.jsx(Y, { kind: a }) : null,
      i
        ? e.jsxs("g", {
            transform: "translate(16 8)",
            children: [
              e.jsx("rect", {
                x: "-7",
                y: "-4",
                width: "14",
                height: "11",
                rx: "2",
                fill: n.yellow,
                stroke: h,
                strokeWidth: 1.4,
              }),
              e.jsx("path", {
                d: "M-4 -4 V-7 Q0 -12 4 -7 V-4",
                fill: "none",
                stroke: h,
                strokeWidth: 1.4,
              }),
            ],
          })
        : null,
    ],
  });
}
function me({ x: t, y: s, s: r = 1, open: i = !1 }) {
  return e.jsxs("g", {
    transform: `translate(${t} ${s}) scale(${r})`,
    children: [
      e.jsx("path", {
        d: i
          ? "M-8 -4 V-13 Q-8 -22 0 -22 Q8 -22 8 -15"
          : "M-8 -4 V-13 Q-8 -22 0 -22 Q8 -22 8 -13 V-4",
        fill: "none",
        stroke: h,
        strokeWidth: 3,
        strokeLinecap: "round",
      }),
      e.jsx("rect", {
        x: "-12",
        y: "-5",
        width: "24",
        height: "19",
        rx: "4",
        fill: i ? n.grey : n.yellow,
        ...c,
      }),
      e.jsx("circle", { cx: "0", cy: "4", r: "2.6", fill: h }),
    ],
  });
}
function ps({ x: t, y: s, w: r, value: i, fill: a = n.mint, h: o = 14 }) {
  return e.jsxs("g", {
    children: [
      e.jsx("rect", {
        x: t,
        y: s,
        width: r,
        height: o,
        rx: o / 2,
        fill: "#fff",
        ...c,
        strokeWidth: 1.6,
      }),
      e.jsx("rect", {
        x: t + 2,
        y: s + 2,
        width: Math.max(0, (r - 4) * i),
        height: o - 4,
        rx: (o - 4) / 2,
        fill: a,
      }),
    ],
  });
}
const us = 24;
function Xe(t) {
  const s = t + 0.1,
    r = {
      "--nb-flow-shift": `${-2 * s}px`,
      animationDuration: `${(2 * s) / us}s`,
    };
  return { className: "nb-flow", strokeDasharray: `0.1 ${t}`, style: r };
}
const te = { x: 0, y: 50, w: 800, h: 302 },
  Je = { w: 800, h: 302 },
  St = te.h / te.w;
function ge(t, s, r) {
  const i = r * St;
  return { x: t - r / 2, y: s - i / 2, w: r, h: i };
}
function ks(t) {
  return t !== void 0 && t !== "topology";
}
const ms = {
    model: ge(330, 205, 110),
    storage: ge(266, 204, 140),
    bandwidth: ge(530, 199, 260),
    area: ge(50, 231, 100),
    wifi: ge(585, 73, 110),
  },
  ys = 240,
  gs = 850,
  bs = 750;
function ws(t) {
  return t < 0.5 ? 4 * t * t * t : 1 - (-2 * t + 2) ** 3 / 2;
}
function $s(t, s, r) {
  const i = Math.exp(Math.log(t.w) + (Math.log(s.w) - Math.log(t.w)) * r),
    a = i * St,
    o = t.x + t.w / 2 + (s.x + s.w / 2 - (t.x + t.w / 2)) * r,
    l = t.y + t.h / 2 + (s.y + s.h / 2 - (t.y + t.h / 2)) * r;
  return { x: o - i / 2, y: l - a / 2, w: i, h: a };
}
function Ms(t, s) {
  const r = Math.log(te.w / s.w);
  return r <= 0 ? 0 : Math.min(1, Math.max(0, Math.log(te.w / t.w) / r));
}
function Ct(t, s) {
  const r = Math.min(1, Math.max(0, (Ms(t, s) - 0.45) / 0.45));
  return Number((r * r * (3 - 2 * r)).toFixed(3));
}
function Dt(t) {
  return [t.x, t.y, t.w, t.h]
    .map((s) => (Math.round(s * 100) / 100 + 0).toFixed(2))
    .join(" ");
}
function ct(t, s) {
  return (
    Math.abs(t.x - s.x) < 0.01 &&
    Math.abs(t.y - s.y) < 0.01 &&
    Math.abs(t.w - s.w) < 0.01
  );
}
function Ws(t, s) {
  return t && s ? t : te;
}
function vs({ target: t, leaving: s, onLeft: r }) {
  const i = C.useRef(null);
  i.current === null && (i.current = Wt());
  const a = C.useRef(Ws(t, i.current)),
    o = C.useRef(null),
    l = C.useRef(null),
    d = C.useRef(r);
  C.useLayoutEffect(() => {
    d.current = r;
  });
  const x = C.useCallback(
      (p) => {
        ((a.current = p),
          o.current?.setAttribute("viewBox", Dt(p)),
          l.current?.setAttribute("opacity", String(t ? Ct(p, t) : 0)));
      },
      [t],
    ),
    f = C.useCallback(
      (p, k, j, u) => {
        const m = a.current;
        if (i.current || typeof window.requestAnimationFrame != "function")
          return (x(p), u?.(), () => {});
        let g = 0,
          b = null;
        const P = (I) => {
          b ??= I;
          const V = Math.min(1, Math.max(0, (I - b - j) / k));
          (x(V < 1 ? $s(m, p, ws(V)) : p),
            V < 1 ? (g = window.requestAnimationFrame(P)) : u?.());
        };
        return (
          (g = window.requestAnimationFrame(P)),
          () => window.cancelAnimationFrame(g)
        );
      },
      [x],
    );
  return (
    C.useEffect(() => {
      if (s) return;
      const p = t ?? te;
      if (!ct(a.current, p)) return f(p, gs, ct(a.current, te) ? ys : 0);
    }, [t, s, f]),
    C.useEffect(() => {
      if (s) return f(te, bs, 0, () => d.current?.());
    }, [s, f]),
    { svgRef: o, detailRef: l, view: a.current }
  );
}
const _ = Je.w,
  B = Je.h,
  M = 232;
function Pt({ d: t, live: s = !0, w: r = 9 }) {
  return s
    ? e.jsxs("g", {
        children: [
          e.jsx("path", {
            d: t,
            fill: "none",
            stroke: h,
            strokeWidth: r + 4,
            strokeLinecap: "round",
            strokeLinejoin: "round",
          }),
          e.jsx("path", {
            d: t,
            fill: "none",
            stroke: n.cable,
            strokeWidth: r,
            strokeLinecap: "round",
            strokeLinejoin: "round",
          }),
          e.jsx("path", {
            d: t,
            fill: "none",
            stroke: "#fff",
            strokeWidth: r * 0.5,
            strokeLinecap: "round",
            ...Xe(22),
          }),
        ],
      })
    : e.jsx("path", {
        d: t,
        fill: "none",
        stroke: n.greyDeep,
        strokeWidth: 3,
        strokeLinecap: "round",
        strokeDasharray: "4 10",
      });
}
function We({ x: t = 0, w: s = _, floor: r = M, wall: i = n.paper, band: a }) {
  return e.jsxs("g", {
    children: [
      e.jsx("rect", { x: t, y: 0, width: s, height: r, fill: i }),
      a ? e.jsx("rect", { x: t, y: 0, width: s, height: "12", fill: a }) : null,
      e.jsx("rect", { x: t, y: r, width: s, height: B - r, fill: n.road }),
      Array.from({ length: Math.ceil(s / 90) }, (o, l) =>
        e.jsx(
          "path",
          {
            d: `M${t + 40 + l * 90} ${r} L${t + 10 + l * 90} ${B}`,
            stroke: "#e6d9bd",
            strokeWidth: "2",
          },
          l,
        ),
      ),
      e.jsx("path", {
        d: `M${t} ${r} H${t + s}`,
        stroke: h,
        strokeWidth: "2.5",
      }),
    ],
  });
}
function je({ x: t, w: s = 120, top: r = 190 }) {
  return e.jsxs("g", {
    children: [
      e.jsx("rect", {
        x: t - s / 2 + 8,
        y: r,
        width: "8",
        height: M - r,
        fill: "#c9a77d",
        ...c,
        strokeWidth: 1.6,
      }),
      e.jsx("rect", {
        x: t + s / 2 - 16,
        y: r,
        width: "8",
        height: M - r,
        fill: "#c9a77d",
        ...c,
        strokeWidth: 1.6,
      }),
      e.jsx("rect", {
        x: t - s / 2,
        y: r - 8,
        width: s,
        height: "10",
        rx: "3",
        fill: "#e2c39b",
        ...c,
      }),
    ],
  });
}
function Qt({ x: t, y: s, s: r = 1 }) {
  return e.jsxs("g", {
    transform: `translate(${t} ${s}) scale(${r})`,
    children: [
      e.jsx("path", { d: "M-20 -30 H20 L22 -4 H-22Z", fill: n.navy, ...c }),
      e.jsx("rect", {
        x: "-16",
        y: "-26",
        width: "32",
        height: "18",
        rx: "2",
        fill: "#dff3ff",
      }),
      e.jsx("rect", {
        x: "-28",
        y: "-5",
        width: "56",
        height: "6",
        rx: "2",
        fill: n.grey,
        ...c,
        strokeWidth: 1.6,
      }),
    ],
  });
}
function Ls({ x: t, y: s }) {
  return e.jsxs("g", {
    children: [
      e.jsx("path", {
        d: `M${t} ${s - 58} L${t - 22} ${s} M${t} ${s - 58} L${t + 22} ${s} M${t} ${s - 58} V${s}`,
        stroke: h,
        strokeWidth: "3",
        strokeLinecap: "round",
      }),
      e.jsx("rect", {
        x: t - 26,
        y: s - 86,
        width: "44",
        height: "30",
        rx: "6",
        fill: n.navy,
        ...c,
      }),
      e.jsx("rect", {
        x: t + 16,
        y: s - 80,
        width: "16",
        height: "18",
        rx: "3",
        fill: n.grey,
        ...c,
        strokeWidth: 1.6,
      }),
      e.jsx("circle", { cx: t - 14, cy: s - 78, r: "3", fill: n.pink }),
    ],
  });
}
function Ns({ x: t, y: s, w: r = 150 }) {
  return e.jsxs("g", {
    children: [
      e.jsx("rect", {
        x: t - r / 2,
        y: s - 80,
        width: r,
        height: "80",
        rx: "6",
        fill: n.navy,
        ...c,
      }),
      e.jsx("rect", {
        x: t - r / 2 + 8,
        y: s - 72,
        width: r - 16,
        height: "64",
        rx: "3",
        fill: "#dff3ff",
      }),
      e.jsx("path", {
        d: `M${t - r / 2 + 22} ${s - 26} l24 -18 l20 12 l30 -24`,
        fill: "none",
        stroke: n.cable,
        strokeWidth: "3",
        strokeLinecap: "round",
      }),
    ],
  });
}
function ht({ x: t }) {
  return e.jsxs("g", {
    children: [
      e.jsx("path", {
        d: `M${t} ${M - 34} Q${t - 30} ${M - 80} ${t - 8} ${M - 96} M${t} ${M - 34} Q${t + 28} ${M - 76} ${t + 12} ${M - 104} M${t} ${M - 34} V${M - 110}`,
        stroke: n.mintDeep,
        strokeWidth: "5",
        strokeLinecap: "round",
        fill: "none",
      }),
      e.jsx("path", {
        d: `M${t - 18} ${M - 36} H${t + 18} L${t + 13} ${M} H${t - 13}Z`,
        fill: n.peach,
        ...c,
      }),
    ],
  });
}
function As({ x: t, y: s, s: r = 1 }) {
  return e.jsxs("g", {
    transform: `translate(${t} ${s}) scale(${r})`,
    fill: "none",
    stroke: n.cable,
    strokeWidth: "3",
    strokeLinecap: "round",
    children: [
      e.jsx("path", { d: "M-14 -6 Q0 -18 14 -6" }),
      e.jsx("path", { d: "M-8 0 Q0 -7 8 0" }),
      e.jsx("circle", {
        cx: "0",
        cy: "5",
        r: "2.4",
        fill: n.cable,
        stroke: "none",
      }),
    ],
  });
}
function Tt({ x: t, y: s, radii: r }) {
  return e.jsx("g", {
    fill: "none",
    stroke: n.cable,
    strokeWidth: "2.5",
    strokeDasharray: "2 9",
    strokeLinecap: "round",
    children: r.map((i, a) =>
      e.jsx("circle", { cx: t, cy: s, r: i, opacity: 0.7 - a * 0.12 }, i),
    ),
  });
}
function et({ x: t, y: s, w: r, h: i }) {
  return e.jsx("rect", {
    x: t,
    y: s,
    width: r,
    height: i,
    rx: "8",
    fill: "none",
    stroke: n.greyDeep,
    strokeWidth: "2.5",
    strokeDasharray: "6 7",
  });
}
const he = [110, 235, 565, 690],
  q = [400, 184];
function Hs({ org: t, side: s }) {
  return e.jsxs("g", {
    children: [
      e.jsx(We, { band: t.theme.accent }),
      e.jsx(w, { x: _ / 2, y: 34, text: t.hub, size: 15 }),
      s === "a"
        ? he.map((r) =>
            e.jsxs(
              "g",
              {
                children: [
                  e.jsx("path", {
                    d: `M${q[0]} ${q[1] - 20} L${r} 166`,
                    stroke: n.cable,
                    strokeWidth: "3",
                    strokeDasharray: "7 6",
                  }),
                  e.jsx(A, {
                    x: (q[0] * 3 + r * 2) / 5,
                    y: (q[1] - 20) * 0.6 + 166 * 0.4 - 4,
                    s: 0.8,
                  }),
                ],
              },
              r,
            ),
          )
        : null,
      s === "b"
        ? he
            .slice(1)
            .map((r, i) =>
              e.jsx(
                "path",
                {
                  d: `M${he[i]} 150 Q${(he[i] + r) / 2} ${i === 1 ? 70 : 110} ${r} 150`,
                  fill: "none",
                  stroke: n.cable,
                  strokeWidth: "3",
                  strokeDasharray: "7 6",
                },
                r,
              ),
            )
        : null,
      he.map((r) =>
        e.jsxs(
          "g",
          {
            children: [
              e.jsx(je, { x: r }),
              e.jsx(Q, { x: r, y: 168, s: 0.95 }),
              s === "b" ? e.jsx(A, { x: r, y: 120, s: 1.1 }) : null,
            ],
          },
          r,
        ),
      ),
      s === "a"
        ? e.jsxs("g", {
            children: [
              e.jsx(S, { x: q[0], y: q[1], s: 1.5, colour: n.lilac }),
              e.jsx(A, { x: q[0], y: 116, s: 1.2 }),
              e.jsx(w, { x: q[0], y: 262, text: "File server", size: 14 }),
            ],
          })
        : s === void 0
          ? e.jsx(et, { x: q[0] - 30, y: q[1] - 50, w: 60, h: 98 })
          : null,
      s === "a"
        ? he.map((r) => e.jsx(w, { x: r, y: 262, text: "Client", size: 13 }, r))
        : null,
    ],
  });
}
function A({ x: t, y: s, s: r = 1 }) {
  return e.jsxs("g", {
    transform: `translate(${t} ${s}) scale(${r})`,
    children: [
      e.jsx("path", {
        d: "M-14 -10 H-4 L0 -6 H14 V10 H-14Z",
        fill: n.yellow,
        ...c,
        strokeWidth: 1.6,
      }),
      e.jsx("path", { d: "M-14 -3 H14", stroke: h, strokeWidth: 1.4 }),
    ],
  });
}
const Ss = [120, 210, 300];
function Cs({ lit: t }) {
  return e.jsxs("g", {
    opacity: t ? 1 : 0.4,
    children: [
      e.jsx(re, { x: 680, y: 128, s: 3.3, fill: n.blueprint }),
      e.jsx("rect", {
        x: 612,
        y: 112,
        width: 136,
        height: 112,
        rx: "6",
        fill: n.white,
        ...c,
      }),
      [630, 664, 698].map((s) =>
        e.jsxs(
          "g",
          {
            children: [
              e.jsx("rect", {
                x: s,
                y: 124,
                width: "26",
                height: "88",
                rx: "3",
                fill: t ? n.blue : n.grey,
                ...c,
                strokeWidth: 1.6,
              }),
              [136, 156, 176, 196].map((r) =>
                e.jsx(
                  "circle",
                  {
                    cx: s + 18,
                    cy: r,
                    r: "2.4",
                    fill: t ? n.mintDeep : n.greyDeep,
                  },
                  r,
                ),
              ),
            ],
          },
          s,
        ),
      ),
      t ? e.jsx(A, { x: 680, y: 98, s: 1.1 }) : null,
      e.jsx(w, { x: 680, y: 262, text: "Cloud provider", size: 14 }),
    ],
  });
}
function Ds({ org: t, side: s }) {
  return e.jsxs("g", {
    children: [
      e.jsx("rect", { width: _, height: B, fill: n.sky }),
      e.jsx("rect", {
        x: 490,
        y: 244,
        width: _ - 490,
        height: B - 244,
        fill: n.grass,
      }),
      e.jsx(We, { w: 470, floor: 244, band: t.theme.accent }),
      e.jsx("rect", { x: 462, y: 0, width: 24, height: B, fill: n.grey, ...c }),
      e.jsx(Cs, { lit: s === "b" }),
      s === "b"
        ? e.jsx(Pt, { d: "M420 150 H474 C 540 150, 560 168, 612 168", w: 8 })
        : null,
      s === "b" ? e.jsx(Ps, {}) : null,
      Ss.map((r) =>
        s === "a"
          ? e.jsxs(
              "g",
              {
                children: [
                  e.jsx(S, { x: r, y: 196, s: 1.45 }),
                  e.jsx(A, { x: r, y: 132, s: 1.05 }),
                ],
              },
              r,
            )
          : e.jsx(et, { x: r - 27, y: 150, w: 54, h: 92 }, r),
      ),
      e.jsx(w, { x: 210, y: 34, text: t.records, size: 15 }),
      e.jsx(w, { x: 210, y: 276, text: t.hub, size: 14 }),
    ],
  });
}
function Ps() {
  return e.jsxs("g", {
    transform: "translate(412 150) scale(0.8)",
    children: [
      e.jsx("rect", {
        x: "-30",
        y: "-12",
        width: "60",
        height: "26",
        rx: "8",
        fill: n.peach,
        ...c,
      }),
      e.jsx("path", {
        d: "M-14 1 H14 M8 -5 L14 1 L8 7 M-8 -5 L-14 1 L-8 7",
        fill: "none",
        stroke: h,
        strokeWidth: 2.2,
        strokeLinecap: "round",
      }),
    ],
  });
}
const dt = [n.mint, n.yellow, n.pink, n.lilac],
  pe = 200,
  Be = 700,
  de = 156,
  Re = 52;
function Qs({ y: t, offset: s }) {
  return e.jsx("g", {
    children: Array.from({ length: Math.ceil((Be - pe) / Re) + 2 }, (r, i) =>
      e.jsx(
        "rect",
        {
          x: pe - Re + i * Re + s,
          y: t - 8,
          width: "28",
          height: "16",
          rx: "5",
          fill: dt[(i + s) % dt.length],
          stroke: h,
          strokeWidth: "1.6",
        },
        i,
      ),
    ),
  });
}
function Ts({ org: t, side: s }) {
  const r = C.useId(),
    i = s === "b",
    a = s === void 0 ? 50 : i ? 104 : 34,
    o = s === void 0 ? [] : i ? [-32, 0, 32] : [0];
  return e.jsxs("g", {
    children: [
      e.jsx("rect", { width: _, height: B, fill: n.sky }),
      e.jsx(We, { w: 170 }),
      e.jsx("rect", { x: 160, y: 0, width: 20, height: B, fill: n.grey, ...c }),
      [60, 120].map((l) =>
        [92, 162, 232].map((d) =>
          e.jsx(Q, { x: l, y: d - 14, s: 0.62 }, `${l}-${d}`),
        ),
      ),
      e.jsx(w, { x: 85, y: 278, text: t.hub, size: 14 }),
      e.jsx(re, { x: 760, y: de + 4, s: 2.8 }),
      e.jsx("defs", {
        children: e.jsx("clipPath", {
          id: r,
          children: e.jsx("rect", {
            x: pe,
            y: de - a / 2,
            width: Be - pe,
            height: a,
            rx: a / 2,
          }),
        }),
      }),
      e.jsx("rect", {
        x: pe,
        y: de - a / 2,
        width: Be - pe,
        height: a,
        rx: a / 2,
        fill: s === void 0 ? "none" : n.white,
        stroke: s === void 0 ? n.greyDeep : h,
        strokeWidth: s === void 0 ? 3 : 2.5,
        strokeDasharray: s === void 0 ? "6 8" : void 0,
      }),
      e.jsx("g", {
        clipPath: `url(#${r})`,
        children: e.jsx("g", {
          className: "nb-stream",
          children: o.map((l, d) =>
            e.jsx(Qs, { y: de + l, offset: d * 17 }, l),
          ),
        }),
      }),
      s === "a"
        ? [
            [214, 112],
            [244, 100],
            [226, 202],
            [256, 214],
          ].map(([l, d]) =>
            e.jsx(
              "rect",
              {
                x: l,
                y: d,
                width: "28",
                height: "16",
                rx: "5",
                fill: n.grey,
                stroke: h,
                strokeWidth: "1.6",
              },
              `${l}-${d}`,
            ),
          )
        : null,
      e.jsx("rect", {
        x: 174,
        y: de - 14,
        width: "34",
        height: "28",
        rx: "7",
        fill: n.peach,
        ...c,
      }),
      e.jsx(v, {
        x: 754,
        y: de + 12,
        size: 18,
        weight: 700,
        anchor: "middle",
        children: "Internet",
      }),
    ],
  });
}
function Es({ x: t }) {
  return e.jsxs("g", {
    children: [
      e.jsx("rect", {
        x: t - 30,
        y: 100,
        width: "60",
        height: M - 100,
        rx: "4",
        fill: n.blue,
        ...c,
      }),
      e.jsx("rect", {
        x: t - 12,
        y: 118,
        width: "24",
        height: "16",
        rx: "3",
        fill: n.white,
        ...c,
        strokeWidth: 1.6,
      }),
      e.jsx("circle", { cx: t + 20, cy: 170, r: "3.2", fill: h }),
    ],
  });
}
function Is({ x: t }) {
  return e.jsxs("g", {
    children: [
      e.jsx("rect", {
        x: t - 70,
        y: 70,
        width: "8",
        height: M - 70,
        fill: n.greyDeep,
        ...c,
        strokeWidth: 1.6,
      }),
      e.jsx("rect", {
        x: t + 62,
        y: 70,
        width: "8",
        height: M - 70,
        fill: n.greyDeep,
        ...c,
        strokeWidth: 1.6,
      }),
      [100, 150, 200].map((s, r) =>
        e.jsxs(
          "g",
          {
            children: [
              e.jsx("rect", {
                x: t - 70,
                y: s,
                width: "140",
                height: "7",
                fill: n.grey,
                ...c,
                strokeWidth: 1.6,
              }),
              [-56, -18, 22].map((i, a) =>
                e.jsx(
                  "rect",
                  {
                    x: t + i,
                    y: s - 26 + ((a + r) % 2) * 6,
                    width: "32",
                    height: 26 - ((a + r) % 2) * 6,
                    rx: "2",
                    fill: (a + r) % 3 === 0 ? n.yellow : n.peach,
                    ...c,
                    strokeWidth: 1.5,
                  },
                  i,
                ),
              ),
            ],
          },
          s,
        ),
      ),
    ],
  });
}
function Vs(t) {
  switch (t) {
    case "police":
      return {
        wap: [420, 24],
        scenery: e.jsxs("g", {
          children: [
            [580, 660, 740].map((s) => e.jsx(Es, { x: s }, s)),
            e.jsx(je, { x: 480, w: 90, top: 196 }),
          ],
        }),
        front: e.jsx("rect", {
          x: 150,
          y: 176,
          width: 260,
          height: M - 176,
          rx: "4",
          fill: "#c9b8ff",
          ...c,
        }),
        devices: [
          { kind: "pc", x: 210, y: 176 },
          { kind: "pc", x: 340, y: 176 },
          { kind: "printer", x: 480, y: 188 },
        ],
      };
    case "hospital":
      return {
        wap: [380, 24],
        scenery: e.jsxs("g", {
          children: [
            e.jsx("rect", {
              x: 470,
              y: 194,
              width: 300,
              height: "16",
              rx: "6",
              fill: n.white,
              ...c,
            }),
            e.jsx("path", {
              d: "M520 210 V232 M720 210 V232",
              stroke: h,
              strokeWidth: "5",
            }),
            e.jsx("circle", {
              cx: 610,
              cy: 150,
              r: "74",
              fill: n.white,
              ...c,
              strokeWidth: 2.5,
            }),
            e.jsx("circle", { cx: 610, cy: 150, r: "38", fill: n.sky, ...c }),
            e.jsx("rect", {
              x: 470,
              y: 190,
              width: 110,
              height: "12",
              rx: "5",
              fill: n.mintWash,
              ...c,
              strokeWidth: 1.6,
            }),
            e.jsx(je, { x: 200, w: 220 }),
          ],
        }),
        devices: [
          { kind: "pc", x: 150, y: 182 },
          { kind: "pc", x: 255, y: 182 },
          { kind: "fixed", x: 610, y: 224 },
        ],
      };
    case "civil":
      return {
        wap: [400, 24],
        scenery: e.jsxs("g", {
          children: [
            [140, 300, 460, 620].map((s) => e.jsx(je, { x: s, w: 130 }, s)),
            e.jsx(ht, { x: 750 }),
          ],
        }),
        devices: [140, 300, 460, 620].map((s) => ({
          kind: "pc",
          x: s,
          y: 182,
        })),
      };
    case "threadline":
      return {
        wap: [420, 24],
        scenery: e.jsxs("g", {
          children: [
            [130, 360, 590].map((s) => e.jsx(Is, { x: s }, s)),
            e.jsx("rect", {
              x: 700,
              y: 196,
              width: 80,
              height: "22",
              rx: "4",
              fill: n.peach,
              ...c,
            }),
            e.jsx("circle", { cx: 712, cy: 224, r: "7", fill: h }),
            e.jsx("circle", { cx: 768, cy: 224, r: "7", fill: h }),
            e.jsx("path", {
              d: "M700 196 L690 160",
              stroke: h,
              strokeWidth: "4",
              strokeLinecap: "round",
            }),
          ],
        }),
        devices: [
          { kind: "tablet", x: 245, y: 216 },
          { kind: "tablet", x: 475, y: 216 },
          { kind: "tablet", x: 740, y: 196 },
        ],
      };
    case "law":
      return {
        wap: [620, 24],
        scenery: e.jsxs("g", {
          children: [e.jsx(Ns, { x: 400, y: 140 }), e.jsx(ht, { x: 740 })],
        }),
        front: e.jsxs("g", {
          children: [
            e.jsx("rect", {
              x: 236,
              y: 198,
              width: "10",
              height: M - 198,
              fill: "#c9a77d",
              ...c,
              strokeWidth: 1.6,
            }),
            e.jsx("rect", {
              x: 554,
              y: 198,
              width: "10",
              height: M - 198,
              fill: "#c9a77d",
              ...c,
              strokeWidth: 1.6,
            }),
            e.jsx("rect", {
              x: 220,
              y: 188,
              width: 360,
              height: "12",
              rx: "4",
              fill: "#e2c39b",
              ...c,
            }),
          ],
        }),
        devices: [
          { kind: "screen", x: 400, y: 140 },
          { kind: "laptop", x: 290, y: 190 },
          { kind: "laptop", x: 510, y: 190 },
        ],
      };
    case "vidora":
      return {
        wap: [200, 24],
        scenery: e.jsxs("g", {
          children: [
            e.jsx("path", {
              d: "M300 64 H790",
              stroke: h,
              strokeWidth: "6",
              strokeLinecap: "round",
            }),
            [400, 560, 720].map((s) =>
              e.jsxs(
                "g",
                {
                  children: [
                    e.jsx("path", {
                      d: `M${s - 10} 74 L${s - 70} 200 H${s + 70} L${s + 10} 74Z`,
                      fill: n.yellow,
                      opacity: 0.22,
                    }),
                    e.jsx("rect", {
                      x: s - 12,
                      y: 62,
                      width: "24",
                      height: "16",
                      rx: "4",
                      fill: n.navy,
                      ...c,
                      strokeWidth: 1.6,
                    }),
                  ],
                },
                s,
              ),
            ),
            e.jsx("rect", {
              x: 300,
              y: 200,
              width: 500,
              height: M - 200,
              fill: n.lilac,
              ...c,
            }),
            e.jsx(je, { x: 560, w: 150, top: 170 }),
          ],
        }),
        devices: [
          { kind: "camera", x: 160, y: 232 },
          { kind: "laptop", x: 560, y: 162 },
          { kind: "camera", x: 730, y: 200 },
        ],
      };
  }
}
function Os({ d: t }) {
  switch (t.kind) {
    case "pc":
      return e.jsx(Q, { x: t.x, y: t.y - 14, s: 0.9 });
    case "laptop":
      return e.jsx(Qt, { x: t.x, y: t.y });
    case "tablet":
      return e.jsxs("g", {
        children: [
          e.jsx("path", {
            d: `M${t.x} ${t.y} V${t.y - 26}`,
            stroke: h,
            strokeWidth: "4",
          }),
          e.jsx(z, { x: t.x, y: t.y - 44, s: 0.95 }),
        ],
      });
    case "printer":
      return e.jsx(At, { x: t.x, y: t.y - 17 });
    case "camera":
      return e.jsx(Ls, { x: t.x, y: t.y });
    case "screen":
    case "fixed":
      return null;
  }
}
const Rs = {
  pc: 56,
  laptop: 46,
  tablet: 80,
  printer: 52,
  camera: 104,
  screen: 92,
  fixed: 150,
};
function _s({ org: t, side: s }) {
  const r = Vs(t.id),
    [i, a] = r.wap;
  return e.jsxs("g", {
    children: [
      e.jsx(We, {
        wall: t.id === "hospital" ? "#f1eee8" : n.paper,
        band: t.theme.accent,
      }),
      e.jsx("path", { d: `M0 6 H${_}`, stroke: n.grey, strokeWidth: "10" }),
      r.scenery,
      s === "a"
        ? e.jsxs("g", {
            children: [
              r.devices.map((o, l) =>
                e.jsx(
                  Pt,
                  { d: `M40 132 V${284 - l * 9} H${o.x} V${o.y}`, w: 5 },
                  `${o.x}-${o.y}`,
                ),
              ),
              e.jsx("g", {
                transform: "translate(40 120) rotate(90)",
                children: e.jsx(Qe, { x: 0, y: 0, s: 0.6 }),
              }),
            ],
          })
        : null,
      s === "b"
        ? e.jsx(Tt, { x: i, y: a + 10, radii: [70, 140, 210, 290] })
        : null,
      r.front,
      r.devices.map((o) => e.jsx(Os, { d: o }, `${o.x}-${o.y}`)),
      s === "b"
        ? r.devices.map((o) =>
            e.jsx(As, { x: o.x, y: o.y - Rs[o.kind] - 12 }, `${o.x}-${o.y}`),
          )
        : null,
      s === "b" ? e.jsx(F, { x: i, y: a, s: 1.3, waves: !1 }) : null,
      s === void 0 ? e.jsx(et, { x: i - 34, y: 6, w: 68, h: 34 }) : null,
      e.jsx(w, {
        x: 18 + (t.area.label.length * 15 * 0.56 + 16) / 2,
        y: 36,
        text: t.area.label,
        size: 15,
      }),
    ],
  });
}
function xt({ x: t, y: s, w: r, text: i, lock: a }) {
  return e.jsxs("g", {
    children: [
      e.jsx("rect", {
        x: t,
        y: s,
        width: r,
        height: "42",
        rx: "14",
        fill: n.white,
        ...c,
      }),
      e.jsx("path", {
        d: `M${t + r / 2 - 10} ${s + 41} l10 14 l10 -14`,
        fill: n.white,
        ...c,
      }),
      e.jsx("rect", {
        x: t + r / 2 - 9,
        y: s + 38,
        width: "18",
        height: "5",
        fill: n.white,
      }),
      a === "key"
        ? e.jsxs("g", {
            transform: `translate(${t + 22} ${s + 21})`,
            children: [
              e.jsx("circle", {
                cx: "-4",
                cy: "0",
                r: "6",
                fill: n.yellow,
                stroke: h,
                strokeWidth: "1.8",
              }),
              e.jsx("path", {
                d: "M2 0 H14 M10 0 V5 M14 0 V4",
                stroke: h,
                strokeWidth: "2.2",
                strokeLinecap: "round",
              }),
            ],
          })
        : e.jsx(me, { x: t + 22, y: s + 21, s: 0.75, open: a === "open" }),
      e.jsx(v, {
        x: t + 44,
        y: s + 27,
        size: 15,
        weight: 600,
        fill: a === "shut" ? n.greyDeep : h,
        children: i,
      }),
    ],
  });
}
function Bs({ org: t, side: s }) {
  const r = Ue[t.id],
    i = s === "a" ? Ge(r) : r,
    a = r.length * 8.6 + 60;
  return e.jsxs("g", {
    children: [
      e.jsx("rect", { width: _, height: B, fill: n.sky }),
      e.jsx("rect", {
        x: 480,
        y: M,
        width: _ - 480,
        height: B - M,
        fill: n.road,
      }),
      e.jsx("path", { d: `M480 ${M} H${_}`, stroke: h, strokeWidth: "2.5" }),
      e.jsx(D, { x: 770, y: M, s: 1.3 }),
      e.jsx(We, { w: 480, band: t.theme.accent }),
      e.jsx(Tt, { x: 240, y: 34, radii: [90, 170, 250, 330] }),
      e.jsx("rect", { x: 470, y: 0, width: 22, height: B, fill: n.grey, ...c }),
      e.jsx(je, { x: 200, w: 130 }),
      e.jsx(Qt, { x: 200, y: 182 }),
      e.jsx($, { x: 110, y: 262, s: 0.92, outfit: t.theme.people[0] }),
      e.jsx($, {
        x: 640,
        y: 262,
        s: 0.92,
        outfit: "public",
        hair: E.fair,
        mood: "neutral",
        holding: e.jsx(z, { x: 0, y: 0, s: 0.55 }),
      }),
      e.jsx(F, { x: 240, y: 24, s: 1.3, waves: !1 }),
      e.jsx(w, { x: 330, y: 278, text: t.sites[1], size: 14 }),
      s
        ? e.jsxs("g", {
            children: [
              e.jsx(xt, {
                x: Math.max(14, 200 - a / 2),
                y: 82,
                w: a,
                text: r,
                lock: "key",
              }),
              e.jsx(xt, {
                x: Math.min(_ - 14 - a, 640 - a / 2),
                y: 56,
                w: a,
                text: i,
                lock: s === "a" ? "shut" : "open",
              }),
            ],
          })
        : null,
    ],
  });
}
function Zs({ org: t, build: s, decision: r }) {
  const i = C.useId(),
    a = s[r];
  let o;
  switch (r) {
    case "model":
      o = e.jsx(Hs, { org: t, side: a });
      break;
    case "storage":
      o = e.jsx(Ds, { org: t, side: a });
      break;
    case "bandwidth":
      o = e.jsx(Ts, { org: t, side: a });
      break;
    case "area":
      o = e.jsx(_s, { org: t, side: a });
      break;
    case "wifi":
      o = e.jsx(Bs, { org: t, side: a });
      break;
  }
  return e.jsxs("g", {
    children: [
      e.jsx("defs", {
        children: e.jsx("clipPath", {
          id: i,
          children: e.jsx("rect", { width: _, height: B }),
        }),
      }),
      e.jsx("g", { clipPath: `url(#${i})`, children: o }),
    ],
  });
}
const R = "#dcefff",
  Et = "#e4e8f0";
function K({ x: t, y: s, w: r, h: i, cols: a, rows: o, lit: l, fill: d }) {
  if (a < 1 || o < 1 || r <= 0 || i <= 0) return null;
  const x = Math.max(3, Math.min(6, r / a / 4)),
    f = (r - x * (a - 1)) / a,
    p = (i - x * (o - 1)) / o;
  return e.jsx("g", {
    children: Array.from({ length: o }, (k, j) =>
      Array.from({ length: a }, (u, m) =>
        e.jsx(
          "rect",
          {
            x: t + m * (f + x),
            y: s + j * (p + x),
            width: f,
            height: p,
            rx: "2",
            fill: l ? (d ?? n.yellow) : n.grey,
            stroke: h,
            strokeWidth: "1.4",
          },
          `${j}-${m}`,
        ),
      ),
    ),
  });
}
function ie({ cx: t, bottom: s, h: r, lit: i, fill: a }) {
  return e.jsx("rect", {
    x: t - 7,
    y: s - r,
    width: "14",
    height: r,
    fill: i ? (a ?? n.peach) : n.greyDeep,
    stroke: h,
    strokeWidth: "1.5",
  });
}
function le({ x: t, y: s, w: r, fill: i }) {
  return e.jsx("rect", {
    x: t - 4,
    y: s - 8,
    width: r + 8,
    height: "12",
    rx: "3",
    fill: i,
    ...c,
  });
}
function Ee(t, s) {
  return {
    cols: Math.max(t >= 36 ? 2 : 1, Math.min(6, Math.round(t / 30))),
    rows: Math.max(1, Math.min(4, Math.round(s / 34))),
  };
}
function Fs({ x: t, y: s, w: r, h: i, roof: a, lit: o }) {
  const l = Math.min(15, i * 0.4),
    d = r >= 56,
    x = Math.max(7, Math.min(12, i * 0.17)),
    f = s + (d ? x + 9 : 7),
    p = s + i - l - 4 - f,
    { cols: k, rows: j } = Ee(r, p);
  return e.jsxs("g", {
    children: [
      e.jsx("rect", {
        x: t + r / 2 - 5,
        y: s - 22,
        width: "10",
        height: "10",
        rx: "3",
        fill: o ? n.cable : n.greyDeep,
        ...c,
      }),
      e.jsx("rect", {
        x: t + r / 2 - 8,
        y: s - 13,
        width: "16",
        height: "5",
        rx: "1",
        fill: h,
      }),
      e.jsx(le, { x: t, y: s, w: r, fill: a }),
      e.jsx("rect", { x: t, y: s, width: r, height: i, fill: n.paper, ...c }),
      d
        ? e.jsxs("g", {
            children: [
              e.jsx("rect", {
                x: t + r / 2 - r * 0.32,
                y: s + 6,
                width: r * 0.64,
                height: x,
                rx: "2",
                fill: n.navy,
                stroke: h,
                strokeWidth: "1.4",
              }),
              e.jsx(v, {
                x: t + r / 2,
                y: s + 6 + x * 0.78,
                size: x * 0.78,
                weight: 700,
                anchor: "middle",
                fill: "#fff",
                children: "POLICE",
              }),
            ],
          })
        : null,
      p >= 8
        ? e.jsx(K, {
            x: t + 9,
            y: f,
            w: r - 18,
            h: p,
            cols: k,
            rows: j,
            lit: o,
          })
        : e.jsxs("g", {
            children: [
              e.jsx(K, {
                x: t + 6,
                y: s + i - l,
                w: r / 2 - 16,
                h: l - 4,
                cols: 1,
                rows: 1,
                lit: o,
              }),
              e.jsx(K, {
                x: t + r / 2 + 10,
                y: s + i - l,
                w: r / 2 - 16,
                h: l - 4,
                cols: 1,
                rows: 1,
                lit: o,
              }),
            ],
          }),
      e.jsx(ie, { cx: t + r / 2, bottom: s + i, h: l, lit: o, fill: n.blue }),
    ],
  });
}
function It({ cx: t, cy: s, r, colour: i }) {
  return e.jsxs("g", {
    children: [
      e.jsx("rect", {
        x: t - r,
        y: s - r,
        width: r * 2,
        height: r * 2,
        rx: r * 0.35,
        fill: "#fff",
        stroke: h,
        strokeWidth: "1.5",
      }),
      e.jsx("path", {
        d: `M${t} ${s - r * 0.62} V${s + r * 0.62} M${t - r * 0.62} ${s} H${t + r * 0.62}`,
        stroke: i,
        strokeWidth: Math.max(2, r * 0.45),
        strokeLinecap: "round",
      }),
    ],
  });
}
const tt = "#3aa892";
function zs({ x: t, y: s, w: r, h: i, roof: a, trim: o, lit: l }) {
  const d = r * 0.32,
    x = r - d,
    f = Math.min(15, i * 0.32),
    { cols: p, rows: k } = Ee(x, i - f);
  return e.jsxs("g", {
    children: [
      e.jsx(le, { x: t, y: s, w: r, fill: a }),
      e.jsx("rect", { x: t, y: s, width: r, height: i, fill: "#fbfefd", ...c }),
      e.jsx(K, {
        x: t + 8,
        y: s + 8,
        w: x - 12,
        h: i - f - 16,
        cols: p,
        rows: k,
        lit: l,
        fill: l ? n.yellow : void 0,
      }),
      e.jsx(ie, { cx: t + x / 2, bottom: s + i, h: f, lit: l, fill: o }),
      e.jsx("rect", {
        x: t + x,
        y: s + i * 0.5,
        width: d,
        height: i * 0.5,
        fill: l ? "#eef8f5" : n.grey,
        stroke: h,
        strokeWidth: "1.5",
      }),
      e.jsx("rect", {
        x: t + x - 3,
        y: s + i * 0.5 - 5,
        width: d + 7,
        height: "6",
        rx: "2",
        fill: a,
        stroke: h,
        strokeWidth: "1.5",
      }),
      e.jsx("path", {
        d: `M${t + x + d * 0.2} ${s + i - 2} H${t + x + d * 0.8}`,
        stroke: n.yellow,
        strokeWidth: "2.4",
        strokeDasharray: "4 3",
      }),
      e.jsx(It, {
        cx: t + x + d / 2,
        cy: s + i * 0.26,
        r: Math.max(5, Math.min(11, r * 0.06)),
        colour: l ? tt : n.greyDeep,
      }),
    ],
  });
}
function qs({ x: t, y: s, w: r, h: i, roof: a, trim: o, lit: l }) {
  const d = Math.min(15, i * 0.4),
    x = Math.max(4.5, Math.min(12, i * 0.15, r * 0.1)),
    f = t + x * 2 + 10,
    p = Math.max(1, Math.min(3, Math.round((i - d) / 40))),
    k = Math.max(2, Math.min(5, Math.round((t + r - f) / 28)));
  return e.jsxs("g", {
    children: [
      e.jsx(le, { x: t, y: s, w: r, fill: a }),
      e.jsx("rect", { x: t, y: s, width: r, height: i, fill: "#fbfefd", ...c }),
      e.jsx(It, {
        cx: t + x + 5,
        cy: s + x + 6,
        r: x,
        colour: l ? tt : n.greyDeep,
      }),
      e.jsx(K, {
        x: f,
        y: s + 7,
        w: t + r - f - 7,
        h: Math.max(6, i - d - 15),
        cols: k,
        rows: p,
        lit: l,
      }),
      e.jsx("rect", {
        x: t + r / 2 - 12,
        y: s + i - d - 4,
        width: "24",
        height: "5",
        rx: "2",
        fill: o,
        stroke: h,
        strokeWidth: "1.3",
      }),
      e.jsx(ie, { cx: t + r / 2, bottom: s + i, h: d, lit: l, fill: o }),
    ],
  });
}
function Us({ x: t, y: s, w: r, h: i, roof: a, trim: o, lit: l }) {
  const d = Math.max(3, Math.min(8, Math.round(r / 16))),
    x = Math.max(4, i * 0.07),
    f = s + 6,
    p = s + i - x * 2,
    k = Math.max(3, (r - 12) / d / 2.6),
    j = Array.from({ length: d }, (u, m) => t + 6 + ((r - 12) / (d - 1)) * m);
  return e.jsxs("g", {
    children: [
      e.jsx("path", {
        d: `M${t - 6} ${s + 2} L${t + r / 2} ${s - Math.max(10, i * 0.3)} L${t + r + 6} ${s + 2}Z`,
        fill: a,
        ...c,
      }),
      e.jsx("circle", {
        cx: t + r / 2,
        cy: s - Math.max(10, i * 0.3) * 0.42,
        r: Math.max(2.4, i * 0.05),
        fill: l ? n.yellow : n.grey,
        stroke: h,
        strokeWidth: "1.3",
      }),
      e.jsx("rect", {
        x: t - 4,
        y: s,
        width: r + 8,
        height: "7",
        fill: o,
        ...c,
        strokeWidth: 1.6,
      }),
      e.jsx("rect", {
        x: t,
        y: f,
        width: r,
        height: p - f,
        fill: n.paper,
        ...c,
      }),
      j
        .slice(0, -1)
        .map((u, m) =>
          e.jsx(
            "rect",
            {
              x: u + k / 2 + 2,
              y: f + (p - f) * 0.18,
              width: Math.max(2, j[m + 1] - u - k - 4),
              height: (p - f) * 0.5,
              rx: "1.5",
              fill: l ? n.yellow : n.grey,
              stroke: h,
              strokeWidth: "1.2",
            },
            u,
          ),
        ),
      j.map((u) =>
        e.jsx(
          "rect",
          {
            x: u - k / 2,
            y: f,
            width: k,
            height: p - f,
            fill: "#fff",
            stroke: h,
            strokeWidth: "1.4",
          },
          `c${u}`,
        ),
      ),
      e.jsx("rect", {
        x: t - 4,
        y: p,
        width: r + 8,
        height: x,
        fill: o,
        stroke: h,
        strokeWidth: "1.5",
      }),
      e.jsx("rect", {
        x: t - 9,
        y: p + x,
        width: r + 18,
        height: x,
        fill: o,
        stroke: h,
        strokeWidth: "1.5",
      }),
    ],
  });
}
function Gs({ x: t, y: s, w: r, h: i, roof: a, trim: o, lit: l }) {
  const d = Math.min(15, i * 0.4),
    { cols: x, rows: f } = Ee(r, i - d),
    p = t + r - 6;
  return e.jsxs("g", {
    children: [
      e.jsx("path", {
        d: `M${p} ${s - 8} V${s - 26}`,
        stroke: h,
        strokeWidth: "1.6",
      }),
      e.jsx("path", {
        d: `M${p} ${s - 26} L${p + 12} ${s - 22} L${p} ${s - 18}Z`,
        fill: a,
        stroke: h,
        strokeWidth: "1.3",
        strokeLinejoin: "round",
      }),
      e.jsx(le, { x: t, y: s, w: r, fill: a }),
      e.jsx("rect", { x: t, y: s, width: r, height: i, fill: n.paper, ...c }),
      e.jsx(K, {
        x: t + 8,
        y: s + 8,
        w: r - 16,
        h: i - d - 14,
        cols: x,
        rows: f,
        lit: l,
      }),
      e.jsx("rect", {
        x: t + r / 2 - 13,
        y: s + i - d - 5,
        width: "26",
        height: "5",
        fill: o,
        stroke: h,
        strokeWidth: "1.3",
      }),
      e.jsx("rect", {
        x: t + r / 2 - 12,
        y: s + i - d,
        width: "3.5",
        height: d,
        fill: "#fff",
        stroke: h,
        strokeWidth: "1.1",
      }),
      e.jsx("rect", {
        x: t + r / 2 + 8.5,
        y: s + i - d,
        width: "3.5",
        height: d,
        fill: "#fff",
        stroke: h,
        strokeWidth: "1.1",
      }),
      e.jsx(ie, { cx: t + r / 2, bottom: s + i, h: d, lit: l, fill: o }),
    ],
  });
}
function Vt({ cx: t, cy: s, s: r }) {
  return e.jsx("path", {
    transform: `translate(${t} ${s}) scale(${r})`,
    d: "M0 -6 Q0 -9 2.5 -9 Q5 -9 5 -6.5 Q5 -4.5 0 -2 L-9 4 H9 L0 -2",
    fill: "none",
    stroke: h,
    strokeWidth: 1.6 / r,
    strokeLinecap: "round",
    strokeLinejoin: "round",
  });
}
function Ks({ x: t, y: s, w: r, h: i, roof: a, trim: o, lit: l }) {
  const d = Math.max(2, Math.round(i / 16)),
    x = Math.max(3, Math.round(r / 16)),
    f = Math.min(14, i * 0.26);
  return e.jsxs("g", {
    children: [
      e.jsx("rect", {
        x: t - 2,
        y: s - 5,
        width: r + 4,
        height: "7",
        rx: "2",
        fill: a,
        ...c,
      }),
      e.jsx("rect", {
        x: t,
        y: s,
        width: r,
        height: i,
        rx: "3",
        fill: l ? R : Et,
        ...c,
      }),
      Array.from({ length: d - 1 }, (p, k) =>
        e.jsx(
          "path",
          {
            d: `M${t} ${s + ((i - f) / d) * (k + 1)} H${t + r}`,
            stroke: h,
            strokeWidth: "1.2",
          },
          `f${k}`,
        ),
      ),
      Array.from({ length: x - 1 }, (p, k) =>
        e.jsx(
          "path",
          {
            d: `M${t + (r / x) * (k + 1)} ${s} V${s + i - f}`,
            stroke: "#a9c6e6",
            strokeWidth: "1.2",
          },
          `m${k}`,
        ),
      ),
      e.jsx("path", {
        d: `M${t + r * 0.18} ${s + i * 0.7} L${t + r * 0.42} ${s + 4} M${t + r * 0.3} ${s + i * 0.7} L${t + r * 0.54} ${s + 4}`,
        stroke: "#fff",
        strokeWidth: "3",
        opacity: 0.8,
      }),
      e.jsx("rect", {
        x: t,
        y: s + i - f,
        width: r,
        height: f,
        fill: o,
        ...c,
        strokeWidth: 1.5,
      }),
      e.jsx("rect", {
        x: t + r / 2 - 9,
        y: s + i - f + 2,
        width: "18",
        height: f - 2,
        fill: l ? n.yellow : n.grey,
        stroke: h,
        strokeWidth: "1.3",
      }),
      r >= 50
        ? e.jsxs("g", {
            children: [
              e.jsx("rect", {
                x: t + r - 26,
                y: s - 20,
                width: "22",
                height: "14",
                rx: "4",
                fill: "#fff",
                stroke: h,
                strokeWidth: "1.4",
              }),
              e.jsx(Vt, { cx: t + r - 15, cy: s - 12, s: 0.8 }),
            ],
          })
        : null,
    ],
  });
}
function Ys({ x: t, y: s, w: r, h: i, roof: a, trim: o, lit: l }) {
  const d = r >= 70 ? 3 : 2,
    x = Math.min(22, (r - 16) / d - 6),
    f = i * 0.52,
    p = d * x + (d - 1) * 6,
    k = t + (r - p) / 2 + 4;
  return e.jsxs("g", {
    children: [
      e.jsx("path", {
        d: `M${t - 4} ${s + 4} L${t + r * 0.5} ${s - 7} L${t + r + 4} ${s + 4}Z`,
        fill: a,
        ...c,
      }),
      e.jsx("rect", {
        x: t,
        y: s + 2,
        width: r,
        height: i - 2,
        fill: "#f7f1ee",
        ...c,
      }),
      Array.from({ length: Math.floor(r / 7) }, (j, u) =>
        e.jsx(
          "path",
          {
            d: `M${t + 4 + u * 7} ${s + 6} V${s + i - f - 4}`,
            stroke: o,
            strokeWidth: "1.4",
          },
          u,
        ),
      ),
      e.jsx("rect", {
        x: t + 6,
        y: s + 6,
        width: Math.min(18, r * 0.2),
        height: "6",
        rx: "1.5",
        fill: l ? n.yellow : n.grey,
        stroke: h,
        strokeWidth: "1.2",
      }),
      Array.from({ length: d }, (j, u) => {
        const m = k + u * (x + 6);
        return e.jsxs(
          "g",
          {
            children: [
              e.jsx("rect", {
                x: m,
                y: s + i - f,
                width: x,
                height: f,
                fill: l ? "#fff3c4" : n.grey,
                stroke: h,
                strokeWidth: "1.4",
              }),
              Array.from({ length: 3 }, (g, b) =>
                e.jsx(
                  "path",
                  {
                    d: `M${m} ${s + i - f + 4 + b * 4} H${m + x}`,
                    stroke: h,
                    strokeWidth: "1",
                    opacity: 0.55,
                  },
                  b,
                ),
              ),
              e.jsx("rect", {
                x: m - 2,
                y: s + i - f - 4,
                width: x + 4,
                height: "4",
                rx: "1",
                fill: a,
                stroke: h,
                strokeWidth: "1.1",
              }),
            ],
          },
          u,
        );
      }),
    ],
  });
}
function Xs({ x: t, y: s, w: r, h: i, roof: a, trim: o, lit: l }) {
  const d = Math.max(2, Math.min(5, Math.round(r / 22))),
    x = r / d,
    f = Math.max(8, i * 0.24),
    p = Math.min(15, i * 0.4),
    k = Array.from(
      { length: d },
      (j, u) => `L${t + u * x} ${s - f} L${t + (u + 1) * x} ${s}`,
    ).join(" ");
  return e.jsxs("g", {
    children: [
      e.jsx("path", { d: `M${t} ${s} ${k} Z`, fill: a, ...c }),
      Array.from({ length: d }, (j, u) =>
        e.jsx(
          "path",
          {
            d: `M${t + u * x + 2} ${s - 2} L${t + u * x + 2} ${s - f + 4}`,
            stroke: l ? R : n.grey,
            strokeWidth: "3",
          },
          u,
        ),
      ),
      e.jsx("rect", { x: t, y: s, width: r, height: i, fill: "#fff6f1", ...c }),
      e.jsx("rect", {
        x: t + 7,
        y: s + 7,
        width: r * 0.62 - 7,
        height: i - 14,
        rx: "2",
        fill: l ? R : n.grey,
        stroke: h,
        strokeWidth: "1.4",
      }),
      e.jsx("path", {
        d: `M${t + 7 + (r * 0.62 - 7) / 2} ${s + 7} V${s + i - 7}`,
        stroke: h,
        strokeWidth: "1.2",
      }),
      e.jsx(ie, { cx: t + r * 0.8, bottom: s + i, h: p, lit: l, fill: o }),
    ],
  });
}
function Js({ x: t, y: s, w: r, h: i, roof: a, trim: o, lit: l }) {
  const d = Math.min(15, i * 0.38),
    { cols: x, rows: f } = Ee(r, i - d);
  return e.jsxs("g", {
    children: [
      e.jsx(le, { x: t, y: s, w: r, fill: a }),
      e.jsx("rect", { x: t, y: s, width: r, height: i, fill: "#fffaf2", ...c }),
      e.jsx("rect", { x: t, y: s + 4, width: r, height: "4", fill: o }),
      e.jsx(K, {
        x: t + 8,
        y: s + 12,
        w: r - 16,
        h: i - d - 18,
        cols: x,
        rows: f,
        lit: l,
        fill: n.yellow,
      }),
      e.jsx("rect", {
        x: t + r / 2 - 14,
        y: s + i - d - 5,
        width: "28",
        height: "5",
        rx: "2",
        fill: a,
        stroke: h,
        strokeWidth: "1.3",
      }),
      e.jsx(ie, { cx: t + r / 2, bottom: s + i, h: d, lit: l, fill: R }),
    ],
  });
}
function er({ x: t, y: s, w: r, h: i, roof: a, trim: o, lit: l }) {
  const d = i * 0.36,
    x = Math.max(18, r * 0.46),
    f = t + (r - x) / 2,
    p = s - i * 0.7,
    k = s + i - d - p,
    j = Math.max(4, Math.round(k / 9)),
    u = Math.max(2, Math.round(x / 12)),
    m = Math.min(14, d * 0.7);
  return e.jsxs("g", {
    children: [
      e.jsx("path", {
        d: `M${f + x / 2} ${p - 14} V${p - 4}`,
        stroke: h,
        strokeWidth: "1.8",
        strokeLinecap: "round",
      }),
      e.jsx("path", {
        d: `M${f + 4} ${p} L${f + x / 2} ${p - 8} L${f + x - 4} ${p}Z`,
        fill: a,
        stroke: h,
        strokeWidth: "1.5",
        strokeLinejoin: "round",
      }),
      e.jsx("rect", {
        x: f - 2,
        y: p - 2,
        width: x + 4,
        height: "6",
        rx: "2",
        fill: a,
        ...c,
        strokeWidth: 1.6,
      }),
      e.jsx("rect", {
        x: f,
        y: p + 4,
        width: x,
        height: k - 4,
        fill: l ? R : Et,
        ...c,
      }),
      Array.from({ length: j - 1 }, (g, b) =>
        e.jsx(
          "path",
          {
            d: `M${f} ${p + 4 + ((k - 4) / j) * (b + 1)} H${f + x}`,
            stroke: "#a9c6e6",
            strokeWidth: "1.2",
          },
          `f${b}`,
        ),
      ),
      Array.from({ length: u - 1 }, (g, b) =>
        e.jsx(
          "path",
          {
            d: `M${f + (x / u) * (b + 1)} ${p + 4} V${s + i - d}`,
            stroke: h,
            strokeWidth: "1",
            opacity: 0.7,
          },
          `c${b}`,
        ),
      ),
      e.jsx("path", {
        d: `M${f + x * 0.2} ${p + k * 0.5} L${f + x * 0.55} ${p + 10}`,
        stroke: "#fff",
        strokeWidth: "3",
        opacity: 0.8,
      }),
      e.jsx("rect", {
        x: t,
        y: s + i - d,
        width: r,
        height: d,
        fill: "#fffaf2",
        ...c,
      }),
      e.jsx("rect", {
        x: t,
        y: s + i - d,
        width: r,
        height: "4",
        fill: o,
        stroke: h,
        strokeWidth: "1.2",
      }),
      e.jsx(K, {
        x: t + 6,
        y: s + i - d + 8,
        w: r * 0.5 - 22,
        h: d - 14,
        cols: Math.max(1, Math.round(r / 60)),
        rows: 1,
        lit: l,
      }),
      e.jsx(K, {
        x: t + r * 0.5 + 16,
        y: s + i - d + 8,
        w: r * 0.5 - 22,
        h: d - 14,
        cols: Math.max(1, Math.round(r / 60)),
        rows: 1,
        lit: l,
      }),
      e.jsx(ie, { cx: t + r / 2, bottom: s + i, h: m, lit: l, fill: a }),
    ],
  });
}
function tr({ x: t, y: s, w: r, h: i, roof: a, trim: o, lit: l }) {
  const d = Math.max(2, Math.round(i / 20)),
    x = Math.min(14, i * 0.26),
    f = Math.max(5, Math.min(11, i * 0.15)),
    p = (i - x - 10) / d - 5;
  return e.jsxs("g", {
    children: [
      e.jsx("rect", {
        x: t,
        y: s - 4,
        width: r,
        height: i + 4,
        rx: Math.min(14, r * 0.12),
        fill: "#fbfaff",
        ...c,
      }),
      e.jsx("rect", {
        x: t,
        y: s - 4,
        width: r,
        height: "9",
        rx: "4",
        fill: a,
        ...c,
        strokeWidth: 1.6,
      }),
      Array.from({ length: d }, (k, j) =>
        e.jsx(
          "rect",
          {
            x: t + 6,
            y: s + 9 + j * (p + 5),
            width: r - 12,
            height: p,
            rx: p / 2,
            fill: l ? o : n.grey,
            stroke: h,
            strokeWidth: "1.3",
          },
          j,
        ),
      ),
      e.jsxs("g", {
        transform: `translate(${t + r - f - 6} ${s - f - 2})`,
        children: [
          e.jsx("circle", { r: f, fill: a, stroke: h, strokeWidth: "1.4" }),
          e.jsx("path", {
            d: `M${-f * 0.3} ${-f * 0.42} L${f * 0.48} 0 L${-f * 0.3} ${f * 0.42}Z`,
            fill: "#fff",
          }),
        ],
      }),
      e.jsx("rect", {
        x: t + r / 2 - 10,
        y: s + i - x,
        width: "20",
        height: x,
        rx: "2",
        fill: l ? n.yellow : n.grey,
        stroke: h,
        strokeWidth: "1.4",
      }),
    ],
  });
}
function sr({ x: t, y: s, w: r, h: i, roof: a, trim: o, lit: l }) {
  const d = Math.max(2, Math.min(5, Math.round(r / 22))),
    x = Math.min(16, (r - 8) / d - 4),
    f = Math.max(2, Math.round(r / 14));
  return e.jsxs("g", {
    children: [
      Array.from({ length: d }, (p, k) => {
        const j = t + 6 + k * ((r - 12 - x) / Math.max(1, d - 1));
        return e.jsxs(
          "g",
          {
            children: [
              e.jsx("rect", {
                x: j,
                y: s - 15,
                width: x,
                height: "10",
                rx: "2",
                fill: "#fff",
                stroke: h,
                strokeWidth: "1.3",
              }),
              e.jsx("circle", {
                cx: j + x / 2,
                cy: s - 10,
                r: Math.min(3.5, x / 3.2),
                fill: o,
                stroke: h,
                strokeWidth: "1",
              }),
            ],
          },
          k,
        );
      }),
      e.jsx(le, { x: t, y: s, w: r, fill: a }),
      e.jsx("rect", { x: t, y: s, width: r, height: i, fill: "#eef0f7", ...c }),
      Array.from({ length: f }, (p, k) => {
        const j = t + 6 + k * ((r - 18) / Math.max(1, f - 1));
        return e.jsx(
          "g",
          {
            children: Array.from(
              { length: Math.max(2, Math.round((i - 18) / 7)) },
              (u, m) =>
                e.jsx(
                  "path",
                  {
                    d: `M${j} ${s + 8 + m * 6} h6`,
                    stroke: n.greyDeep,
                    strokeWidth: "1.6",
                    strokeLinecap: "round",
                  },
                  m,
                ),
            ),
          },
          k,
        );
      }),
      e.jsx("rect", {
        x: t + 4,
        y: s + i - 9,
        width: r - 22,
        height: "5",
        rx: "2.5",
        fill: "#fff",
        stroke: h,
        strokeWidth: "1.1",
      }),
      Array.from({ length: Math.max(2, Math.round((r - 26) / 8)) }, (p, k) =>
        e.jsx(
          "circle",
          {
            cx: t + 8 + k * 8,
            cy: s + i - 6.5,
            r: "1.4",
            fill: l ? n.mintDeep : n.greyDeep,
          },
          k,
        ),
      ),
      e.jsx("rect", {
        x: t + r - 15,
        y: s + i - Math.min(14, i * 0.4),
        width: "10",
        height: Math.min(14, i * 0.4),
        fill: l ? n.lilac : n.greyDeep,
        stroke: h,
        strokeWidth: "1.3",
      }),
    ],
  });
}
function rr({ x: t, y: s, w: r, h: i, roof: a, trim: o, lit: l }) {
  const d = Math.min(15, i * 0.4),
    x = Math.max(8, Math.min(13, i * 0.24)),
    f = Math.max(22, Math.min(46, r * 0.4));
  return e.jsxs("g", {
    children: [
      e.jsxs("g", {
        transform: `translate(${t + r * 0.22} ${s - 9})`,
        children: [
          e.jsx("path", { d: "M0 0 L3 -9", stroke: h, strokeWidth: "1.6" }),
          e.jsx("ellipse", {
            cx: "3",
            cy: "-12",
            rx: "9",
            ry: "5",
            transform: "rotate(-25 3 -12)",
            fill: o,
            stroke: h,
            strokeWidth: "1.4",
          }),
          e.jsx("circle", { cx: "5", cy: "-14", r: "1.4", fill: h }),
        ],
      }),
      e.jsx(le, { x: t, y: s, w: r, fill: a }),
      e.jsx("rect", { x: t, y: s, width: r, height: i, fill: "#fbfaff", ...c }),
      e.jsx("rect", {
        x: t + r - f - 6,
        y: s + 6,
        width: f,
        height: x,
        rx: x / 2,
        fill: l ? a : n.grey,
        stroke: h,
        strokeWidth: "1.4",
      }),
      r >= 44
        ? e.jsx(v, {
            x: t + r - 6 - f / 2,
            y: s + 6 + x * 0.76,
            size: x * 0.72,
            weight: 700,
            anchor: "middle",
            fill: "#fff",
            children: "LIVE",
          })
        : null,
      e.jsx("rect", {
        x: t + 7,
        y: s + 6,
        width: Math.max(10, r - f - 20),
        height: Math.max(6, i - d - 12),
        rx: "2",
        fill: l ? n.yellow : n.grey,
        stroke: h,
        strokeWidth: "1.4",
      }),
      e.jsx(ie, { cx: t + r * 0.7, bottom: s + i, h: d, lit: l, fill: o }),
    ],
  });
}
const ir = {
  station: Fs,
  hospital: zs,
  clinic: qs,
  government: Us,
  "civic-office": Gs,
  "glass-hq": Ks,
  warehouse: Ys,
  studio: Xs,
  office: Js,
  tower: er,
  "tech-hq": tr,
  "data-centre": sr,
  "live-studio": rr,
};
function H({
  kind: t,
  theme: s,
  x: r,
  y: i,
  w: a,
  h: o,
  lit: l = !0,
  label: d,
}) {
  const x = ir[t];
  return e.jsxs("g", {
    "data-building": t,
    children: [
      e.jsx(x, {
        x: r,
        y: i,
        w: a,
        h: o,
        roof: l ? s.accent : n.greyDeep,
        trim: l ? s.secondary : n.grey,
        lit: l,
      }),
      d ? e.jsx(w, { x: r + a / 2, y: i + o + 18, text: d }) : null,
    ],
  });
}
function xe({ xs: t }) {
  return e.jsx("g", {
    children: t.map((s) =>
      e.jsxs(
        "g",
        {
          children: [
            e.jsx("circle", { cx: s, cy: "10", r: "5", fill: h }),
            e.jsx("circle", { cx: s, cy: "10", r: "1.8", fill: n.grey }),
          ],
        },
        s,
      ),
    ),
  });
}
function ve({ kind: t, theme: s, x: r, y: i, s: a = 1 }) {
  let o;
  switch (t) {
    case "police-car":
      o = e.jsxs("g", {
        children: [
          e.jsx("path", {
            d: "M-14 -14 L-8 -22 H8 L14 -14Z",
            fill: R,
            ...c,
            strokeWidth: 1.6,
          }),
          e.jsx("rect", {
            x: "-4",
            y: "-27",
            width: "8",
            height: "5",
            rx: "1.5",
            fill: n.cable,
            stroke: h,
            strokeWidth: "1.3",
          }),
          e.jsx("rect", {
            x: "-22",
            y: "-14",
            width: "44",
            height: "22",
            rx: "6",
            fill: "#fff",
            ...c,
          }),
          e.jsx("rect", {
            x: "-22",
            y: "-3",
            width: "44",
            height: "6",
            fill: s.accent,
            stroke: h,
            strokeWidth: "1",
          }),
          e.jsx(xe, { xs: [-12, 12] }),
        ],
      });
      break;
    case "ambulance":
      o = e.jsxs("g", {
        children: [
          e.jsx("rect", {
            x: "-26",
            y: "-24",
            width: "40",
            height: "32",
            rx: "4",
            fill: "#fff",
            ...c,
          }),
          e.jsx("path", {
            d: "M14 -14 H22 L28 -4 V8 H14Z",
            fill: "#fff",
            ...c,
          }),
          e.jsx("path", {
            d: "M16 -11 H21 L25 -4 H16Z",
            fill: R,
            stroke: h,
            strokeWidth: "1.2",
          }),
          e.jsx("rect", {
            x: "-26",
            y: "-2",
            width: "54",
            height: "5",
            fill: s.accent,
            stroke: h,
            strokeWidth: "1",
          }),
          e.jsx("path", {
            d: "M-6 -19 V-9 M-11 -14 H-1",
            stroke: tt,
            strokeWidth: "3.2",
            strokeLinecap: "round",
          }),
          e.jsx(xe, { xs: [-15, 16] }),
        ],
      });
      break;
    case "car":
      o = e.jsxs("g", {
        children: [
          e.jsx("path", {
            d: "M-16 -12 L-9 -22 H9 L16 -12Z",
            fill: R,
            ...c,
            strokeWidth: 1.6,
          }),
          e.jsx("rect", {
            x: "-22",
            y: "-13",
            width: "44",
            height: "21",
            rx: "7",
            fill: s.accent,
            ...c,
          }),
          e.jsx("circle", {
            cx: "18",
            cy: "-6",
            r: "2",
            fill: n.yellow,
            stroke: h,
            strokeWidth: "1",
          }),
          e.jsx(xe, { xs: [-12, 12] }),
        ],
      });
      break;
    case "lorry":
      o = e.jsxs("g", {
        children: [
          e.jsx("rect", {
            x: "-40",
            y: "-30",
            width: "54",
            height: "38",
            rx: "3",
            fill: s.accent,
            ...c,
          }),
          e.jsx("rect", {
            x: "-34",
            y: "-24",
            width: "20",
            height: "13",
            rx: "3",
            fill: "#fff",
            stroke: h,
            strokeWidth: "1.3",
          }),
          e.jsx(Vt, { cx: -24, cy: -17, s: 0.7 }),
          e.jsx("path", {
            d: "M16 -20 H26 L34 -8 V8 H16Z",
            fill: s.secondary,
            ...c,
          }),
          e.jsx("path", {
            d: "M19 -17 H25 L30 -9 H19Z",
            fill: R,
            stroke: h,
            strokeWidth: "1.2",
          }),
          e.jsx(xe, { xs: [-28, -12, 24] }),
        ],
      });
      break;
    case "taxi":
      o = e.jsxs("g", {
        children: [
          e.jsx("rect", {
            x: "-6",
            y: "-29",
            width: "12",
            height: "6",
            rx: "2",
            fill: n.yellow,
            stroke: h,
            strokeWidth: "1.2",
          }),
          e.jsx("path", {
            d: "M-20 -6 Q-20 -24 -4 -24 H8 Q20 -24 20 -6Z",
            fill: "#4e5875",
            ...c,
          }),
          e.jsx("path", {
            d: "M-14 -8 Q-14 -19 -4 -19 V-8Z M2 -8 V-19 H8 Q14 -19 14 -8Z",
            fill: R,
            stroke: h,
            strokeWidth: "1.2",
          }),
          e.jsx("rect", {
            x: "-24",
            y: "-8",
            width: "48",
            height: "16",
            rx: "6",
            fill: "#4e5875",
            ...c,
          }),
          e.jsx("path", {
            d: "M-24 -1 H24",
            stroke: s.accent,
            strokeWidth: "2",
          }),
          e.jsx(xe, { xs: [-13, 13] }),
        ],
      });
      break;
    case "broadcast-van":
      o = e.jsxs("g", {
        children: [
          e.jsx("path", {
            d: "M-14 -24 L-12 -30",
            stroke: h,
            strokeWidth: "1.6",
          }),
          e.jsx("ellipse", {
            cx: "-11",
            cy: "-33",
            rx: "9",
            ry: "4.5",
            transform: "rotate(-20 -11 -33)",
            fill: s.secondary,
            stroke: h,
            strokeWidth: "1.4",
          }),
          e.jsx("rect", {
            x: "-28",
            y: "-24",
            width: "42",
            height: "32",
            rx: "4",
            fill: s.accent,
            ...c,
          }),
          e.jsx("path", {
            d: "M14 -14 H22 L28 -4 V8 H14Z",
            fill: s.accent,
            ...c,
          }),
          e.jsx("path", {
            d: "M16 -11 H21 L25 -4 H16Z",
            fill: R,
            stroke: h,
            strokeWidth: "1.2",
          }),
          e.jsxs("g", {
            transform: "translate(-7 -8)",
            children: [
              e.jsx("circle", {
                r: "7",
                fill: "#fff",
                stroke: h,
                strokeWidth: "1.3",
              }),
              e.jsx("path", { d: "M-2 -3.5 L3.5 0 L-2 3.5Z", fill: h }),
            ],
          }),
          e.jsx(xe, { xs: [-16, 16] }),
        ],
      });
      break;
  }
  return e.jsxs("g", {
    transform: `translate(${r} ${i}) scale(${a})`,
    "data-vehicle": t,
    children: [
      e.jsx("ellipse", {
        cx: "0",
        cy: "15",
        rx: "30",
        ry: "3",
        fill: h,
        opacity: 0.1,
      }),
      o,
    ],
  });
}
const fe = [330, 205],
  ee = [
    [120, 112],
    [540, 112],
    [120, 286],
    [540, 286],
  ],
  nr = [
    [0, 1],
    [1, 3],
    [3, 2],
    [2, 0],
  ],
  X = [712, 200],
  ne = [40, 240],
  ft = "M388 200 H652";
function J({ x: t, y: s, w: r, h: i }) {
  return e.jsx("rect", {
    className: "nb-focus",
    x: t,
    y: s,
    width: r,
    height: i,
    rx: "18",
    fill: n.mint,
    fillOpacity: 0.22,
    stroke: n.mintDeep,
    strokeWidth: "2.5",
    strokeDasharray: "8 6",
  });
}
function ar(t, s) {
  switch (t) {
    case "topology":
      return e.jsx(J, { x: 62, y: 72, w: 540, h: 262 });
    case "model":
      return s.model === "b"
        ? e.jsx("g", {
            children: ee.map((r) =>
              e.jsx(J, { x: r[0] - 64, y: r[1] - 48, w: 46, h: 42 }, r.join()),
            ),
          })
        : e.jsx(J, { x: 248, y: 150, w: 44, h: 106 });
    case "storage":
      return s.storage === "b"
        ? e.jsx(J, { x: 640, y: 252, w: 146, h: 98 })
        : e.jsx(J, { x: 208, y: 150, w: 44, h: 106 });
    case "bandwidth":
      return e.jsx(J, { x: 380, y: 160, w: 406, h: 80 });
    case "area":
      return e.jsx(J, { x: 10, y: 196, w: 156, h: 140 });
    case "wifi":
      return e.jsx("g", {
        children: ee.map((r) =>
          e.jsx(J, { x: r[0] + 16, y: r[1] - 62, w: 52, h: 56 }, r.join()),
        ),
      });
  }
}
function Ot({
  org: t,
  build: s,
  decision: r,
  className: i,
  leaving: a = !1,
  onLeft: o,
}) {
  const l = s.bandwidth === "b",
    d = ks(r) ? r : void 0,
    x = d ? ms[d] : void 0,
    {
      svgRef: f,
      detailRef: p,
      view: k,
    } = vs({ target: x, leaving: a, onLeft: o });
  return e.jsxs("svg", {
    ref: f,
    viewBox: Dt(k),
    className: i,
    role: "img",
    "aria-label": d ? `Close up on ${os(t, d)}. ${jt(t, s)}` : jt(t, s),
    "data-build-scene": !0,
    "data-org-scene": t.id,
    "data-zoom": r ?? "map",
    children: [
      e.jsx("rect", {
        x: "0",
        y: "50",
        width: "800",
        height: "302",
        fill: n.blueprint,
      }),
      Array.from({ length: 27 }, (j, u) =>
        e.jsx(
          "path",
          {
            d: `M${10 + u * 30} 50 V352`,
            stroke: n.blueprintLine,
            strokeWidth: "1.3",
          },
          `v${u}`,
        ),
      ),
      Array.from({ length: 10 }, (j, u) =>
        e.jsx(
          "path",
          {
            d: `M0 ${70 + u * 30} H800`,
            stroke: n.blueprintLine,
            strokeWidth: "1.3",
          },
          `h${u}`,
        ),
      ),
      e.jsx("rect", {
        x: "626",
        y: "50",
        width: "174",
        height: "302",
        fill: n.sky,
        opacity: 0.85,
      }),
      e.jsx("path", {
        d: "M626 50 V352",
        stroke: n.cable,
        strokeWidth: "1.6",
        strokeDasharray: "5 6",
      }),
      r ? ar(r, s) : null,
      e.jsx("path", {
        d: ft,
        fill: "none",
        stroke: s.bandwidth ? n.cable : n.greyDeep,
        strokeWidth: s.bandwidth ? (l ? 18 : 7) : 3,
        strokeLinecap: "round",
        strokeDasharray: s.bandwidth ? void 0 : "4 8",
      }),
      s.bandwidth
        ? e.jsx("path", {
            d: ft,
            fill: "none",
            stroke: "#fff",
            strokeWidth: l ? 8 : 4,
            strokeLinecap: "round",
            ...Xe(17),
          })
        : null,
      e.jsx(re, { x: X[0], y: X[1], s: 2.1 }),
      e.jsx(v, {
        x: X[0],
        y: X[1] + 6,
        size: 13,
        weight: 700,
        anchor: "middle",
        children: "Internet",
      }),
      ee.map((j) =>
        e.jsx(
          be,
          {
            from: fe,
            to: j,
            state: s.topology ? "live" : "off",
            width: s.topology ? 5 : 3,
          },
          j.join(),
        ),
      ),
      s.topology === "b"
        ? nr.map(([j, u]) => e.jsx(be, { from: ee[j], to: ee[u] }, `${j}-${u}`))
        : null,
      s.topology
        ? ee.map((j) =>
            e.jsx(G, { from: fe, to: j, n: 3, fill: n.mint }, j.join()),
          )
        : null,
      s.area === "a" ? e.jsx(be, { from: ee[2], to: ne, width: 4 }) : null,
      e.jsx(H, {
        kind: t.theme.area,
        theme: t.theme,
        x: ne[0] - 22,
        y: ne[1] - 14,
        w: 44,
        h: 28,
      }),
      e.jsx(w, { x: ne[0] + 6, y: ne[1] + 30, text: t.area.label, size: 10 }),
      s.area === "b" ? e.jsx(F, { x: ne[0], y: ne[1] - 34, s: 0.55 }) : null,
      e.jsx(H, {
        kind: t.theme.hub,
        theme: t.theme,
        x: fe[0] - 48,
        y: fe[1] - 28,
        w: 96,
        h: 56,
      }),
      e.jsx(w, { x: fe[0], y: fe[1] + 46, text: t.hub, size: 12 }),
      ee.map((j, u) =>
        e.jsxs(
          "g",
          {
            children: [
              e.jsx(H, {
                kind: t.theme.sites[u],
                theme: t.theme,
                x: j[0] - 30,
                y: j[1] - 19,
                w: 60,
                h: 38,
              }),
              e.jsx(w, { x: j[0], y: j[1] + 36, text: t.sites[u], size: 11 }),
              s.model === "b"
                ? e.jsx(A, { x: j[0] - 41, y: j[1] - 27, s: 0.95 })
                : null,
              s.wifi
                ? e.jsxs("g", {
                    children: [
                      e.jsx(F, { x: j[0] + 40, y: j[1] - 40, s: 0.55 }),
                      e.jsx(me, {
                        x: j[0] + 54,
                        y: j[1] - 22,
                        s: 0.55,
                        open: s.wifi === "b",
                      }),
                    ],
                  })
                : null,
            ],
          },
          j.join(),
        ),
      ),
      s.model === "a"
        ? e.jsxs("g", {
            children: [
              e.jsx(S, { x: 270, y: 208, s: 0.66, colour: n.lilac }),
              e.jsx(A, { x: 270, y: 172, s: 0.75 }),
            ],
          })
        : null,
      s.storage === "a" ? e.jsx(S, { x: 230, y: 208, s: 0.66 }) : null,
      s.storage === "b"
        ? e.jsxs("g", {
            children: [
              e.jsx("path", {
                d: `M${X[0]} ${X[1] + 36} V270`,
                stroke: n.cable,
                strokeWidth: "3",
                strokeDasharray: "5 5",
              }),
              e.jsx(Ye, { x: X[0], y: 292, s: 1.5 }),
              e.jsx(w, { x: X[0], y: 334, text: "Records", size: 11 }),
            ],
          })
        : null,
      d && x
        ? e.jsx("g", {
            ref: p,
            opacity: Ct(k, x),
            transform: `translate(${x.x} ${x.y}) scale(${x.w / Je.w})`,
            "data-closeup": d,
            "data-side": s[d] ?? "none",
            children: e.jsx(Zs, { org: t, build: s, decision: d }),
          })
        : null,
    ],
  });
}
function jt(t, s) {
  const r = [
    s.topology
      ? s.topology === "a"
        ? "star links to"
        : "mesh links between"
      : null,
    s.model
      ? s.model === "a"
        ? "a file server"
        : "files on each computer"
      : null,
    s.storage
      ? s.storage === "a"
        ? "on-site servers"
        : "cloud storage"
      : null,
    s.bandwidth
      ? s.bandwidth === "a"
        ? "a low-bandwidth internet connection"
        : "a high-bandwidth internet connection"
      : null,
    s.area
      ? s.area === "a"
        ? `a wired ${t.area.noun}`
        : `a wireless ${t.area.noun}`
      : null,
    s.wifi ? (s.wifi === "a" ? "encrypted Wi-Fi" : "open Wi-Fi") : null,
  ].filter(Boolean);
  return `Map of ${t.hub} and the ${t.sitesNoun}${r.length ? `: ${r.join(", ")}` : ""}`;
}
function or({ x: t, y: s, mesh: r }) {
  const i = [
      [t - 18, s - 14],
      [t + 18, s - 14],
      [t - 18, s + 14],
      [t + 18, s + 14],
    ],
    a = [
      [0, 1],
      [1, 3],
      [3, 2],
      [2, 0],
    ];
  return e.jsxs("g", {
    children: [
      i.map((o) =>
        e.jsx(
          "path",
          {
            d: `M${t} ${s} L${o[0]} ${o[1]}`,
            stroke: n.cable,
            strokeWidth: "3",
          },
          o.join(),
        ),
      ),
      r
        ? a.map(([o, l]) =>
            e.jsx(
              "path",
              {
                d: `M${i[o][0]} ${i[o][1]} L${i[l][0]} ${i[l][1]}`,
                stroke: n.cable,
                strokeWidth: "3",
              },
              `${o}${l}`,
            ),
          )
        : null,
      e.jsx("rect", {
        x: t - 7,
        y: s - 6,
        width: "14",
        height: "12",
        rx: "3",
        fill: n.yellow,
        stroke: h,
        strokeWidth: "1.6",
      }),
      i.map((o) =>
        e.jsx(
          "circle",
          {
            cx: o[0],
            cy: o[1],
            r: "5.5",
            fill: n.blue,
            stroke: h,
            strokeWidth: "1.6",
          },
          `n${o.join()}`,
        ),
      ),
    ],
  });
}
function Rt({ id: t, side: s }) {
  let a;
  switch (t) {
    case "topology":
      a = e.jsx(or, { x: 34, y: 37, mesh: s === "b" });
      break;
    case "model":
      a =
        s === "a"
          ? e.jsxs("g", {
              children: [
                e.jsx(S, { x: 34, y: 41, s: 0.55, colour: n.lilac }),
                e.jsx(A, { x: 34, y: 15, s: 0.6 }),
              ],
            })
          : e.jsxs("g", {
              children: [
                e.jsx(A, { x: 21, y: 29, s: 0.6 }),
                e.jsx(A, { x: 47, y: 29, s: 0.6 }),
                e.jsx(A, { x: 34, y: 49, s: 0.6 }),
              ],
            });
      break;
    case "storage":
      a =
        s === "a"
          ? e.jsx(S, { x: 34, y: 37, s: 0.6 })
          : e.jsx(Ye, { x: 34, y: 41, s: 0.78 });
      break;
    case "bandwidth":
      a = e.jsxs("g", {
        children: [
          e.jsx("path", {
            d: "M10 37 H58",
            stroke: n.cable,
            strokeWidth: s === "b" ? 16 : 6,
            strokeLinecap: "round",
          }),
          e.jsx(G, {
            from: [16, 37],
            to: [52, 37],
            n: s === "b" ? 4 : 2,
            fill: "#fff",
            r: s === "b" ? 3.6 : 2.4,
          }),
        ],
      });
      break;
    case "area":
      a =
        s === "a"
          ? e.jsx(Ke, { x: 30, y: 37, s: 0.85 })
          : e.jsx(F, { x: 34, y: 31, s: 0.8 });
      break;
    case "wifi":
      a = e.jsx(me, { x: 34, y: 41, s: 1.15, open: s === "b" });
      break;
  }
  return e.jsxs("svg", {
    viewBox: "0 0 68 74",
    "aria-hidden": "true",
    className: "nb-option-art",
    children: [
      e.jsx("rect", {
        x: "0.75",
        y: "0.75",
        width: "66.5",
        height: "72.5",
        rx: "12",
        fill: n.blueprint,
        stroke: n.blueprintLine,
        strokeWidth: "1.5",
      }),
      a,
    ],
  });
}
const pt = {
    viewBox: { x: 0, y: 70, w: 800, h: 280 },
    room: { x: 40, y: 84, w: 720, h: 250 },
    title: [56, 108],
    closet: { x: 560, y: 122, w: 190, h: 184 },
    floor: { x: 40, y: 306, w: 720, h: 28 },
    desks: [
      { x: 150, floor: 306 },
      { x: 290, floor: 306 },
      { x: 430, floor: 306 },
    ],
    cable: ({ x: t, floor: s }, r) =>
      `M${t + 28} ${s - 44} V${s - 14 + r * 4} H${578 - r * 4} V201`,
    switchAt: [612, 197],
    routerAt: [693, 262],
    routerLine: "M760 257 H730",
    wapAt: [370, 104],
    nicTag: "M178 230 L196 184",
    nicAt: [200, 150],
    people: { staff: [72, 306], engineer: [522, 306] },
    ticks: {
      nic: [224, 126],
      switch: [652, 178],
      router: [722, 232],
      wap: [404, 92],
      cable: [540, 291],
    },
    slots: {
      nic: { x: 166, y: 116, w: 68, h: 68 },
      switch: { x: 570, y: 176, w: 84, h: 42 },
      wap: { x: 330, y: 88, w: 80, h: 40 },
      router: { x: 656, y: 232, w: 74, h: 50 },
      cable: { x: 420, y: 274, w: 130, h: 34 },
    },
  },
  ji = {
    viewBox: { x: 0, y: 0, w: 400, h: 480 },
    room: { x: 16, y: 16, w: 368, h: 448 },
    title: [30, 44],
    closet: { x: 214, y: 52, w: 154, h: 156 },
    floor: { x: 16, y: 300, w: 368, h: 164 },
    desks: [
      { x: 90, floor: 300 },
      { x: 266, floor: 300 },
      { x: 90, floor: 420 },
    ],
    cable: ({ x: t, floor: s }, r) =>
      `M${t + 28} ${s - 44} V${s - 14 + r * 4} H${352 + r * 4} V104 H333`,
    switchAt: [291, 100],
    routerAt: [300, 172],
    routerLine: "M384 167 H337",
    wapAt: [110, 74],
    nicTag: "M118 224 L136 180",
    nicAt: [140, 146],
    people: { staff: [190, 300], engineer: [300, 420] },
    ticks: {
      nic: [164, 122],
      switch: [331, 81],
      router: [329, 142],
      wap: [144, 62],
      cable: [270, 413],
    },
    slots: {
      nic: { x: 106, y: 112, w: 68, h: 68 },
      switch: { x: 249, y: 79, w: 84, h: 42 },
      wap: { x: 70, y: 58, w: 80, h: 40 },
      router: { x: 263, y: 142, w: 74, h: 50 },
      cable: { x: 150, y: 396, w: 130, h: 34 },
    },
  },
  lr = {
    accent: "#8fb6e8",
    secondary: "#d6e6fa",
    wash: "#eaf2ff",
    hub: "station",
    sites: ["station", "station", "station", "station"],
    area: "station",
    people: ["officer", "call-handler", "officer"],
    packet: "location",
    vehicle: "police-car",
    sender: "phone",
    bluetooth: { person: "officer", accessory: "earpiece", device: "radio" },
    places: "police stations",
  },
  cr = {
    accent: "#7fd3c3",
    secondary: "#d3f2ec",
    wash: "#e3f8f3",
    hub: "hospital",
    sites: ["clinic", "clinic", "clinic", "clinic"],
    area: "clinic",
    people: ["nurse", "doctor", "porter"],
    packet: "scan",
    vehicle: "ambulance",
    sender: "pc",
    bluetooth: { person: "nurse", accessory: "headset", device: "phone" },
    places: "a hospital and clinics",
  },
  hr = {
    accent: "#c4b3ee",
    secondary: "#ebe4fc",
    wash: "#f3eefd",
    hub: "government",
    sites: ["civic-office", "civic-office", "civic-office", "civic-office"],
    area: "civic-office",
    people: ["caseworker", "caseworker", "public"],
    packet: "passport",
    vehicle: "car",
    sender: "laptop",
    bluetooth: { person: "caseworker", accessory: "mouse", device: "laptop" },
    places: "a government building and regional offices",
  },
  dr = {
    accent: "#ffadc4",
    secondary: "#ffd3bd",
    wash: "#ffeef3",
    hub: "glass-hq",
    sites: ["warehouse", "studio", "warehouse", "office"],
    area: "warehouse",
    people: ["picker", "designer", "picker"],
    packet: "order",
    vehicle: "lorry",
    sender: "phone",
    bluetooth: {
      person: "picker",
      accessory: "scanner",
      device: "label-printer",
    },
    places: "a glass head office, warehouses and a studio",
  },
  xr = {
    accent: "#e6c784",
    secondary: "#f6e7c8",
    wash: "#fff5e3",
    hub: "tower",
    sites: ["office", "office", "office", "office"],
    area: "office",
    people: ["lawyer", "lawyer", "public"],
    packet: "contract",
    vehicle: "taxi",
    sender: "laptop",
    bluetooth: { person: "lawyer", accessory: "earbuds", device: "phone" },
    places: "a City tower and regional offices",
  },
  fr = {
    accent: "#aa9cf2",
    secondary: "#b8e2f8",
    wash: "#efebff",
    hub: "tech-hq",
    sites: ["data-centre", "data-centre", "live-studio", "data-centre"],
    area: "live-studio",
    people: ["producer", "presenter", "creator"],
    packet: "video",
    vehicle: "broadcast-van",
    sender: "laptop",
    bluetooth: {
      person: "presenter",
      accessory: "headphones",
      device: "laptop",
    },
    places: "a tech head office, data centres and a live studio",
  },
  _t = {
    id: "police",
    name: "Northgate Police Service",
    sector: "Public sector",
    story: "The line that cannot drop",
    scale: 1,
    hub: "HQ",
    hubLong: "HQ and 999 control room",
    siteNoun: "station",
    sitesNoun: "stations",
    siteCount: 12,
    sites: ["Elmbridge", "Castle Hill", "Riverside", "Millbrook"],
    distance: "14 miles",
    area: {
      title: "Riverside custody suite",
      label: "Custody",
      noun: "custody suite",
    },
    placeSite: "Riverside station",
    records: "Police records",
    theme: lr,
    trace: {
      packet: "a 999 caller’s location",
      packets: "caller locations",
      sender: "The caller’s phone",
      domain: "dispatch.northgate.police.uk",
      devices: ["Records PC", "Printer", "Response desk", "WAP"],
      bluetooth:
        "The response officer’s earpiece connects to her radio with no cable and no WAP. Which connection is it?",
      mail: {
        send: "The control room emails the incident report to the duty inspector. Which protocol sends it?",
        read: "The inspector reads email on her desk PC and her phone. Her mailbox uses",
        imap: {
          from: "Duty inspector",
          message:
            "Read the report on my phone at 3am, then on my PC in the morning.",
        },
        pop: {
          from: "Duty inspector",
          message: "The report was on my desk PC, but not on my phone at 3am.",
        },
      },
      newKit: "New in-car tablets",
      app: "the dispatch app",
      http: {
        from: "Information security officer",
        message:
          "An audit found caller locations crossing the network as readable text.",
      },
      https: {
        from: "Information security officer",
        message:
          "An audit checked the dispatch link: every caller location was encrypted.",
      },
    },
  },
  jr = {
    id: "hospital",
    name: "St Elm University Hospital",
    sector: "Public sector",
    story: "Major incident",
    scale: 2,
    hub: "St Elm",
    hubLong: "St Elm main hospital",
    siteNoun: "clinic",
    sitesNoun: "clinics",
    siteCount: 4,
    sites: ["Eastgate", "Hillside", "Westway", "Southfield"],
    distance: "9 miles",
    area: {
      title: "Westway scanner room",
      label: "Scanners",
      noun: "basement scanner room",
    },
    placeSite: "Westway clinic",
    records: "Patient records",
    theme: cr,
    trace: {
      packet: "a scan result",
      packets: "scan results",
      sender: "The scanning centre’s computer",
      domain: "results.stelmhospital.org.uk",
      devices: ["Booking PC", "Printer", "Consultant’s PC", "WAP"],
      bluetooth:
        "A nurse’s wireless headset connects to her phone with no cable and no WAP. Which connection is it?",
      mail: {
        send: "The scan team emails the report to the on-call consultant. Which protocol sends it?",
        read: "The consultant reads email on her desk PC and her phone. Her mailbox uses",
        imap: {
          from: "On-call consultant",
          message: "Read the report on my phone at 3am and made the call.",
        },
        pop: {
          from: "On-call consultant",
          message: "The report was on my desk PC, but not on my phone at 3am.",
        },
      },
      newKit: "New scanners",
      app: "the results app",
      http: {
        from: "Data protection officer",
        message:
          "An audit found scan results crossing the network as readable text.",
      },
      https: {
        from: "Data protection officer",
        message:
          "An audit checked the results link: every scan result was encrypted.",
      },
    },
  },
  pr = {
    id: "civil",
    name: "Digital Identity Office",
    sector: "Public sector",
    story: "Civil Service: Passport season",
    scale: 5,
    hub: "Whitehall",
    hubLong: "Whitehall office",
    siteNoun: "office",
    sitesNoun: "offices and data centres",
    siteCount: 6,
    sites: ["Leeds", "Newport", "Glasgow", "Belfast"],
    distance: "200 miles",
    area: {
      title: "Glasgow caseworker floor",
      label: "Casework",
      noun: "caseworker floor",
    },
    placeSite: "Glasgow office",
    records: "Passport records",
    theme: hr,
    trace: {
      packet: "a passport application",
      packets: "passport applications",
      sender: "A citizen’s laptop",
      domain: "apply.digitalidentityoffice.org.uk",
      devices: ["Printer", "Scanner", "Caseworker’s PC", "WAP"],
      bluetooth:
        "A caseworker’s wireless mouse connects to his laptop with no cable and no WAP. Which connection is it?",
      mail: {
        send: "The system emails the application to the senior caseworker. Which protocol sends it?",
        read: "The senior caseworker reads email on his desk PC and his phone. His mailbox uses",
        imap: {
          from: "Senior caseworker",
          message: "Approved it from my phone on the train in.",
        },
        pop: {
          from: "Senior caseworker",
          message:
            "The email was on my desk PC, but not on my phone, so it waited a day.",
        },
      },
      newKit: "New laptops",
      app: "the application website",
      http: {
        from: "Security team",
        message:
          "An audit found passport applications crossing the network as readable text.",
      },
      https: {
        from: "Security team",
        message:
          "An audit checked the website: every passport application was encrypted.",
      },
    },
  },
  ur = {
    id: "threadline",
    name: "Threadline",
    sector: "Private sector",
    story: "Black Friday week",
    scale: 3,
    hub: "HQ",
    hubLong: "Threadline HQ",
    siteNoun: "site",
    sitesNoun: "sites",
    siteCount: 4,
    sites: ["Returns", "Studio", "Warehouse", "Call centre"],
    distance: "40 miles",
    area: {
      title: "Warehouse far aisles",
      label: "Aisles",
      noun: "far aisles",
    },
    placeSite: "Warehouse office",
    records: "Orders and stock",
    theme: dr,
    trace: {
      packet: "a Black Friday week order",
      packets: "orders",
      sender: "A customer’s phone",
      domain: "shop.threadline.co.uk",
      devices: ["Label printer", "Stock PC", "Picking desk", "WAP"],
      bluetooth:
        "A picker’s handheld scanner connects to the label printer on her belt with no cable and no WAP. Which connection is it?",
      mail: {
        send: "The shop emails the order summary to the warehouse manager. Which protocol sends it?",
        read: "The warehouse manager reads email on his desk PC and his phone. His mailbox uses",
        imap: {
          from: "Warehouse manager",
          message: "Saw the order summary on my phone on the warehouse floor.",
        },
        pop: {
          from: "Warehouse manager",
          message:
            "The summary was on my desk PC, not on my phone on the floor.",
        },
      },
      newKit: "New handheld scanners",
      app: "the checkout app",
      http: {
        from: "Security team",
        message:
          "An audit found orders, with addresses, crossing the network as readable text.",
      },
      https: {
        from: "Security team",
        message: "An audit checked the shop: every order was encrypted.",
      },
    },
  },
  kr = {
    id: "law",
    name: "Harcourt and Vale LLP",
    sector: "Private sector",
    story: "The merger",
    scale: 1.5,
    hub: "London",
    hubLong: "London tower",
    siteNoun: "office",
    sitesNoun: "offices",
    siteCount: 4,
    sites: ["Bristol", "Edinburgh", "Manchester", "Leeds"],
    distance: "200 miles",
    area: {
      title: "Manchester meeting floor",
      label: "Meetings",
      noun: "meeting floor",
    },
    placeSite: "Manchester office",
    records: "Case files",
    theme: xr,
    trace: {
      packet: "a signed contract",
      packets: "signed contracts",
      sender: "A client’s laptop",
      domain: "sign.harcourtvale.co.uk",
      devices: ["Printer", "Scanner", "Partner’s PC", "WAP"],
      bluetooth:
        "A partner’s wireless earbuds connect to her phone with no cable and no WAP. Which connection is it?",
      mail: {
        send: "The signing system emails the contract to the partner. Which protocol sends it?",
        read: "The partner reads email on her desk PC and her phone. Her mailbox uses",
        imap: {
          from: "Partner",
          message: "Saw the signed contract on my phone in the taxi.",
        },
        pop: {
          from: "Partner",
          message:
            "The contract was on my desk PC, but not on my phone in the taxi.",
        },
      },
      newKit: "New phones",
      app: "the signing app",
      http: {
        from: "Compliance officer",
        message:
          "An audit found signed contracts crossing the network as readable text.",
      },
      https: {
        from: "Compliance officer",
        message:
          "An audit checked the signing link: every contract was encrypted.",
      },
    },
  },
  mr = {
    id: "vidora",
    name: "Vidora",
    sector: "Private sector",
    story: "World Cup final",
    scale: 10,
    hub: "London",
    hubLong: "Vidora HQ, London",
    siteNoun: "site",
    sitesNoun: "data centres and studio",
    siteCount: 4,
    sites: ["Dublin", "Frankfurt", "Studio", "Amsterdam"],
    distance: "300 miles",
    area: { title: "Studio live stage", label: "Stage", noun: "live stage" },
    placeSite: "Studio control room",
    records: "Creators’ videos",
    theme: fr,
    trace: {
      packet: "a creator’s video",
      packets: "creators’ uploads",
      sender: "A creator’s laptop",
      domain: "upload.vidora-video.co.uk",
      devices: ["Editing PC", "Printer", "Video server", "WAP"],
      bluetooth:
        "A presenter’s wireless headphones connect to the studio laptop with no cable and no WAP. Which connection is it?",
      mail: {
        send: "The upload system emails a receipt to the creator. Which protocol sends it?",
        read: "The creator reads email on a laptop and a phone. Their mailbox uses",
        imap: {
          from: "Creator",
          message: "Saw the receipt on my phone straight away.",
        },
        pop: {
          from: "Creator",
          message:
            "The receipt went to my laptop only, so I uploaded the video twice.",
        },
      },
      newKit: "New cameras",
      app: "the upload app",
      http: {
        from: "Trust and safety team",
        message:
          "An audit found creators’ uploads crossing the network as readable data.",
      },
      https: {
        from: "Trust and safety team",
        message:
          "An audit checked the upload link: every upload was encrypted.",
      },
    },
  },
  Bt = [_t, jr, pr, ur, kr, mr],
  pi = Bt.map((t) => t.id);
function Ze(t) {
  return Bt.find((s) => s.id === t) ?? _t;
}
function st(t) {
  const s = t.siteNoun;
  return {
    topology: {
      title: `Linking the ${t.sitesNoun}`,
      a: ["One link from each", `${s} to ${t.hub}`],
      b: ["Sites link to", "each other too"],
    },
    model: {
      title: "Where files are kept",
      a: ["One file server", `at ${t.hub}`],
      b: [`Each ${s} keeps`, "its own files"],
    },
    storage: {
      title: t.records,
      a: ["Servers in the", `${t.hub} building`],
      b: ["Kept by a provider,", "over the internet"],
    },
    bandwidth: {
      title: `${t.hub}’s internet connection`,
      a: ["100 Mbps, shared by", `every device at ${t.hub}`],
      b: ["1 Gbps: ten times", "the data per second"],
    },
    area: {
      title: t.area.title,
      a: ["Ethernet cable", "to every desk"],
      b: ["One WAP covers", `the ${t.area.noun}`],
    },
    wifi: {
      title: `${s.charAt(0).toUpperCase()}${s.slice(1)} Wi-Fi`,
      a: ["Unreadable", "without the key"],
      b: ["Anyone in range", "can read it"],
    },
  };
}
function yr({ id: t, className: s }) {
  const r = Ze(t).theme;
  return e.jsxs("svg", {
    viewBox: "-2 -2 74 74",
    "aria-hidden": "true",
    className: s,
    "data-org-icon": t,
    children: [
      e.jsx("rect", {
        width: "70",
        height: "70",
        rx: "14",
        fill: r.wash,
        ...c,
      }),
      t === "police"
        ? e.jsx(H, { kind: "station", theme: r, x: 14, y: 32, w: 42, h: 28 })
        : null,
      t === "hospital"
        ? e.jsx(H, { kind: "hospital", theme: r, x: 10, y: 26, w: 50, h: 34 })
        : null,
      t === "civil"
        ? e.jsx(H, { kind: "government", theme: r, x: 12, y: 30, w: 46, h: 30 })
        : null,
      t === "threadline"
        ? e.jsxs("g", {
            children: [
              e.jsx("path", {
                d: "M18 28 H52 L56 60 H14Z",
                fill: r.accent,
                ...c,
              }),
              e.jsx("path", {
                d: "M27 30 V22 Q35 12 43 22 V30",
                fill: "none",
                ...c,
              }),
              e.jsx("path", {
                d: "M35 36 Q35 33 37.5 33 Q40 33 40 35.5 Q40 37.5 35 40 L26 46 H44 L35 40",
                fill: "none",
                stroke: h,
                strokeWidth: 1.8,
                strokeLinecap: "round",
                strokeLinejoin: "round",
              }),
            ],
          })
        : null,
      t === "law"
        ? e.jsx(H, { kind: "tower", theme: r, x: 14, y: 34, w: 42, h: 26 })
        : null,
      t === "vidora"
        ? e.jsxs("g", {
            children: [
              e.jsx("rect", {
                x: "11",
                y: "16",
                width: "48",
                height: "34",
                rx: "5",
                fill: r.accent,
                ...c,
              }),
              e.jsx("path", {
                d: "M30 25 L42 33 L30 41Z",
                fill: "#fff",
                stroke: h,
                strokeWidth: 1.6,
                strokeLinejoin: "round",
              }),
              e.jsx("path", { d: "M28 50 v6 M42 50 v6 M22 58 H48", ..._e }),
            ],
          })
        : null,
    ],
  });
}
const Zt = {
  police: { skin: y.dark, hair: E.dark, long: !1 },
  hospital: { skin: y.light, hair: E.red, long: !0 },
  civil: { skin: y.mid, hair: E.grey, long: !1 },
  threadline: { skin: y.mid, hair: E.dark, long: !0 },
  law: { skin: y.light, hair: E.fair, long: !1 },
  vidora: { skin: y.dark, hair: E.dark, long: !0 },
};
function gr({ org: t, className: s }) {
  const { theme: r } = t,
    i = Zt[t.id];
  return e.jsxs("svg", {
    viewBox: "0 0 320 210",
    "aria-hidden": "true",
    className: s,
    "data-org-scene-card": t.id,
    children: [
      e.jsx("rect", { width: "320", height: "210", fill: n.sky }),
      e.jsx("circle", {
        cx: "282",
        cy: "34",
        r: "16",
        fill: n.yellow,
        ...c,
        strokeWidth: 1.5,
      }),
      e.jsx("path", {
        d: "M226 74 q4 -10 14 -6 q6 -8 14 0 q8 0 6 6Z",
        fill: "#fff",
        stroke: h,
        strokeWidth: 1.4,
      }),
      e.jsx("rect", { y: "140", width: "320", height: "70", fill: n.grass }),
      e.jsx(Pe, { n: 18, w: 320, h: 70, y0: 140 }),
      e.jsx("path", { d: "M0 178 H320", stroke: n.road, strokeWidth: "22" }),
      e.jsx(H, { kind: r.hub, theme: r, x: 36, y: 40, w: 176, h: 104 }),
      e.jsx(D, { x: 20, y: 150, s: 0.9 }),
      e.jsx(D, { x: 230, y: 148, s: 0.8 }),
      e.jsx(ve, { kind: r.vehicle, theme: r, x: 74, y: 176, s: 1.1 }),
      e.jsx($, { x: 160, y: 192, s: 0.5, outfit: r.people[0], skin: y.mid }),
      e.jsx($, {
        x: 268,
        y: 204,
        s: 0.95,
        outfit: "engineer",
        skin: i.skin,
        hair: i.hair,
        long: i.long,
        holding: e.jsx(z, { x: 0, y: 0, s: 0.6, screen: r.wash }),
      }),
    ],
  });
}
const br = { w: 240, h: 474 };
function wr({ org: t, className: s }) {
  const { theme: r } = t,
    i = Zt[t.id],
    { w: a, h: o } = br;
  return e.jsxs("svg", {
    viewBox: `0 0 ${a} ${o}`,
    "aria-hidden": "true",
    className: s,
    "data-org-scene-card": t.id,
    "data-variant": "portrait",
    children: [
      e.jsx("rect", { width: a, height: o, fill: n.sky }),
      e.jsx("circle", {
        cx: "196",
        cy: "74",
        r: "15",
        fill: n.yellow,
        ...c,
        strokeWidth: 1.5,
      }),
      e.jsx("path", {
        d: "M38 92 q4 -10 14 -6 q6 -8 14 0 q8 0 6 6Z",
        fill: "#fff",
        stroke: h,
        strokeWidth: 1.4,
      }),
      e.jsx("rect", { y: "214", width: a, height: o - 214, fill: n.grass }),
      e.jsx(Pe, { n: 30, w: a, h: o - 214, y0: 214 }),
      e.jsx("path", { d: `M0 256 H${a}`, stroke: n.road, strokeWidth: "22" }),
      e.jsx(H, { kind: r.hub, theme: r, x: 20, y: 104, w: 200, h: 118 }),
      e.jsx(D, { x: 12, y: 232, s: 0.8 }),
      e.jsx(D, { x: 228, y: 230, s: 0.75 }),
      e.jsx(ve, { kind: r.vehicle, theme: r, x: 56, y: 254, s: 1.05 }),
      e.jsx($, { x: 128, y: 276, s: 0.55, outfit: r.people[0], skin: y.mid }),
      e.jsx($, {
        x: 186,
        y: 318,
        s: 1.15,
        outfit: "engineer",
        skin: i.skin,
        hair: i.hair,
        long: i.long,
        holding: e.jsx(z, { x: 0, y: 0, s: 0.6, screen: r.wash }),
      }),
    ],
  });
}
function ui({ org: t }) {
  const s = [250, 200],
    r = [
      [92, 112],
      [420, 120],
      [86, 330],
      [420, 330],
    ];
  return e.jsxs("svg", {
    viewBox: "0 50 510 430",
    role: "img",
    "aria-label": `${t.hubLong} and its ${t.sitesNoun}, ${t.distance} apart, drawn as ${t.theme.places}`,
    className: "nb-art",
    "data-org-scene": t.id,
    children: [
      e.jsx("rect", {
        x: "0",
        y: "50",
        width: "510",
        height: "430",
        fill: n.grass,
      }),
      e.jsx(Pe, { n: 50, w: 510, h: 430, y0: 50 }),
      e.jsx("path", {
        d: "M0 268 Q140 240 250 268 T510 250",
        fill: "none",
        stroke: n.road,
        strokeWidth: "22",
      }),
      e.jsx("path", {
        d: "M248 50 Q230 160 250 268 T262 480",
        fill: "none",
        stroke: n.road,
        strokeWidth: "18",
      }),
      e.jsx(D, { x: 160, y: 160 }),
      e.jsx(D, { x: 350, y: 200, s: 0.9 }),
      e.jsx(D, { x: 36, y: 230, s: 0.8 }),
      e.jsx(D, { x: 470, y: 210, s: 0.8 }),
      e.jsx(D, { x: 482, y: 300, s: 0.8 }),
      e.jsx("path", {
        d: `M${s[0] - 30} ${s[1] + 44} L${r[2][0] + 30} ${r[2][1] - 26}`,
        stroke: h,
        strokeWidth: "2",
        strokeDasharray: "6 6",
      }),
      e.jsx(w, { x: 110, y: 262, text: t.distance, size: 12, fill: n.yellow }),
      e.jsx(H, {
        kind: t.theme.hub,
        theme: t.theme,
        x: s[0] - 55,
        y: s[1] - 34,
        w: 110,
        h: 70,
      }),
      e.jsx(w, { x: s[0], y: s[1] + 56, text: t.hubLong, size: 12 }),
      r.map((i, a) =>
        e.jsxs(
          "g",
          {
            children: [
              e.jsx(H, {
                kind: t.theme.sites[a],
                theme: t.theme,
                x: i[0] - 32,
                y: i[1] - 26,
                w: 64,
                h: 42,
              }),
              e.jsx(w, { x: i[0], y: i[1] + 36, text: t.sites[a], size: 11.5 }),
            ],
          },
          i.join(),
        ),
      ),
      e.jsx(ve, { kind: t.theme.vehicle, theme: t.theme, x: 330, y: 414 }),
      e.jsx($, {
        x: 100,
        y: 462,
        s: 0.62,
        outfit: t.theme.people[0],
        skin: y.mid,
        holding: e.jsx(z, { x: 0, y: 0, s: 0.6 }),
      }),
    ],
  });
}
function ki({ kind: t, org: s }) {
  const r = s.theme.accent;
  return e.jsx("svg", {
    viewBox: "0 0 100 70",
    "aria-hidden": "true",
    className: "nb-lanwan-art",
    children:
      t === "lan"
        ? e.jsxs("g", {
            children: [
              e.jsx(Oe, {
                x: 26,
                y: 16,
                w: 46,
                h: 34,
                cols: 2,
                rows: 1,
                roof: r,
              }),
              e.jsx("path", {
                d: "M24 62 H74",
                stroke: n.cable,
                strokeWidth: "4",
                strokeLinecap: "round",
              }),
            ],
          })
        : e.jsxs("g", {
            children: [
              e.jsx(Oe, {
                x: 10,
                y: 16,
                w: 30,
                h: 24,
                cols: 1,
                rows: 1,
                roof: r,
              }),
              e.jsx(Oe, {
                x: 60,
                y: 16,
                w: 30,
                h: 24,
                cols: 1,
                rows: 1,
                roof: r,
              }),
              e.jsx("path", {
                d: "M25 54 Q50 72 75 54",
                fill: "none",
                stroke: n.cable,
                strokeWidth: "4",
                strokeLinecap: "round",
              }),
              e.jsx("circle", {
                cx: "50",
                cy: "63",
                r: "7",
                fill: n.yellow,
                ...c,
                strokeWidth: 1.5,
              }),
            ],
          }),
  });
}
function mi({ org: t, placed: s, layout: r = pt }) {
  const i = (g) => s.includes(g),
    {
      viewBox: a,
      room: o,
      closet: l,
      floor: d,
      switchAt: x,
      routerAt: f,
      wapAt: p,
      nicAt: k,
      ticks: j,
    } = r,
    u = [n.blue, n.peach, n.lilac],
    m = (g) => {
      const b = r.slots[g];
      return i(g)
        ? null
        : e.jsx("rect", {
            x: b.x,
            y: b.y,
            width: b.w,
            height: b.h,
            rx: "10",
            fill: "#fff",
            fillOpacity: 0.6,
            stroke: n.cable,
            strokeWidth: "2",
            strokeDasharray: "6 5",
          });
    };
  return e.jsxs("svg", {
    viewBox: `${a.x} ${a.y} ${a.w} ${a.h}`,
    role: "img",
    "aria-label": `${t.placeSite}, cut away: ${s.length} of 5 pieces of hardware placed`,
    className: "nb-art",
    "data-place-layout": r === pt ? "wide" : "tall",
    children: [
      e.jsx("rect", { x: a.x, y: a.y, width: a.w, height: a.h, fill: n.sky }),
      e.jsx("rect", {
        x: o.x,
        y: o.y,
        width: o.w,
        height: o.h,
        rx: "6",
        fill: n.paper,
        ...c,
      }),
      e.jsx("rect", {
        x: o.x + 1,
        y: o.y + 1,
        width: o.w - 2,
        height: "10",
        rx: "5",
        fill: t.theme.accent,
      }),
      e.jsx("rect", {
        x: d.x,
        y: d.y,
        width: d.w,
        height: d.h,
        fill: "#e9d6b8",
        ...c,
      }),
      e.jsx("text", {
        x: r.title[0],
        y: r.title[1],
        fontSize: 15,
        fontWeight: 700,
        fontFamily: "Fredoka, ui-rounded, system-ui, sans-serif",
        fill: h,
        children: t.placeSite,
      }),
      e.jsx("rect", {
        x: l.x,
        y: l.y,
        width: l.w,
        height: l.h,
        fill: "#f4ecdf",
        ...c,
      }),
      i("cable")
        ? r.desks.map((g, b) =>
            e.jsx(
              "path",
              {
                d: r.cable(g, b),
                fill: "none",
                stroke: n.cable,
                strokeWidth: "3.5",
                strokeLinejoin: "round",
              },
              `${g.x} ${g.floor}`,
            ),
          )
        : null,
      r.desks.map(({ x: g, floor: b }, P) => {
        const I = u[P % u.length];
        return e.jsxs(
          "g",
          {
            children: [
              e.jsx("rect", {
                x: g - 50,
                y: b - 40,
                width: "100",
                height: "10",
                rx: "2",
                fill: "#d9a07a",
                ...c,
              }),
              e.jsx("path", {
                d: `M${g - 42} ${b - 30} v30 M${g + 42} ${b - 30} v30`,
                stroke: h,
                strokeWidth: "3",
              }),
              e.jsx(Q, { x: g - 12, y: b - 62, colour: I }),
              e.jsx("rect", {
                x: g + 18,
                y: b - 84,
                width: "20",
                height: "42",
                rx: "3",
                fill: I,
                ...c,
              }),
              e.jsx("circle", {
                cx: g + 28,
                cy: b - 74,
                r: "2.4",
                fill: n.mintDeep,
              }),
            ],
          },
          `${g} ${b}`,
        );
      }),
      e.jsx($, {
        x: r.people.staff[0],
        y: r.people.staff[1],
        s: 0.6,
        outfit: t.theme.people[0],
        skin: y.mid,
        hair: E.red,
      }),
      e.jsx($, {
        x: r.people.engineer[0],
        y: r.people.engineer[1],
        s: 0.6,
        outfit: "engineer",
        skin: y.light,
      }),
      e.jsx("path", {
        d: r.nicTag,
        stroke: h,
        strokeWidth: "1.5",
        strokeDasharray: "4 4",
      }),
      i("nic")
        ? e.jsxs("g", {
            children: [
              e.jsx("circle", {
                cx: k[0],
                cy: k[1],
                r: "30",
                fill: "#fff",
                ...c,
              }),
              e.jsx(Ht, { x: k[0], y: k[1], s: 0.72 }),
              e.jsx(N, { x: j.nic[0], y: j.nic[1], s: 0.8 }),
            ],
          })
        : m("nic"),
      i("switch")
        ? e.jsxs("g", {
            children: [
              e.jsx(Qe, { x: x[0], y: x[1], s: 1.1 }),
              e.jsx(N, { x: j.switch[0], y: j.switch[1], s: 0.8 }),
            ],
          })
        : m("switch"),
      e.jsx("path", {
        d: r.routerLine,
        stroke: i("router") ? n.cable : n.greyDeep,
        strokeWidth: "5",
        strokeLinecap: "round",
      }),
      i("router")
        ? e.jsxs("g", {
            children: [
              e.jsx(Te, { x: f[0], y: f[1], s: 0.9 }),
              e.jsx(N, { x: j.router[0], y: j.router[1], s: 0.8 }),
            ],
          })
        : m("router"),
      i("wap")
        ? e.jsxs("g", {
            children: [
              e.jsx(F, { x: p[0], y: p[1], s: 1.05 }),
              e.jsx(N, { x: j.wap[0], y: j.wap[1], s: 0.8 }),
            ],
          })
        : m("wap"),
      i("cable")
        ? e.jsx(N, { x: j.cable[0], y: j.cable[1], s: 0.8 })
        : m("cable"),
    ],
  });
}
function yi({ id: t }) {
  return e.jsxs("svg", {
    viewBox: "-40 -34 80 68",
    "aria-hidden": "true",
    className: "nb-tray-art",
    children: [
      t === "nic" ? e.jsx(Ht, { x: 0, y: 0 }) : null,
      t === "switch" ? e.jsx(Qe, { x: 0, y: 0 }) : null,
      t === "wap" ? e.jsx(F, { x: 0, y: 0, waves: !1 }) : null,
      t === "router" ? e.jsx(Te, { x: 0, y: 8, s: 0.9 }) : null,
      t === "cable" ? e.jsx(Ke, { x: -6, y: -4, s: 0.9 }) : null,
    ],
  });
}
const L = ["topology", "model", "storage", "bandwidth", "area", "wifi"],
  ae = {
    topology: {
      id: "topology",
      a: {
        name: "Star",
        cost: 20,
        upside:
          "Less cable, so cheaper; the central switch controls the traffic",
        downside:
          "The centre is a single point of failure; a broken link cuts a site off",
      },
      b: {
        name: "Mesh",
        cost: 60,
        upside: "No central device; if a link breaks, data takes another route",
        downside: "Far more cable, so it costs more to install",
      },
      bullets: ["star-mesh"],
      bank: ["1.3.1 Q1(b)(ii)", "1.3.1 Q2(ii)"],
    },
    model: {
      id: "model",
      a: {
        name: "Client-server",
        cost: 24,
        upside: "The server stores, backs up and controls access to every file",
        downside: "Costs more, and the server needs managing",
      },
      b: {
        name: "Peer-to-peer",
        cost: 8,
        upside: "Cheap and simple to set up",
        downside: "Files are spread across computers, with no central backup",
      },
      bullets: ["client-server", "hosting"],
      bank: ["1.3.1 Q3(i)", "1.3.1 Q3(ii)"],
    },
    storage: {
      id: "storage",
      a: {
        name: "On-site",
        cost: 30,
        upside: "Stays under your control, and opens without the internet",
        downside: "You buy, back up and look after the servers yourself",
      },
      b: {
        name: "Cloud",
        cost: 12,
        upside:
          "Remote access from anywhere online; the provider handles backup",
        downside:
          "Needs a constant internet connection; a third party controls security",
      },
      bullets: ["cloud", "hosting"],
      bank: ["1.3.1 Q8(b)", "1.3.1 Q8(c)"],
    },
    bandwidth: {
      id: "bandwidth",
      a: {
        name: "Low bandwidth",
        cost: 12,
        upside: "Cheaper, and enough when only a few devices are online",
        downside:
          "Bandwidth is shared: the more devices online, the less data per second each one gets",
      },
      b: {
        name: "High bandwidth",
        cost: 36,
        upside:
          "More data can be transferred per second, so it copes with many devices at once",
        downside: "Costs three times as much",
      },
      bullets: ["performance"],
      bank: ["1.3.1 Q4(a)(i)"],
    },
    area: {
      id: "area",
      a: {
        name: "Wired",
        cost: 14,
        upside: "Fast and reliable, and not slowed by walls",
        downside: "Each device is fixed to where its cable runs",
      },
      b: {
        name: "Wireless",
        cost: 6,
        upside: "Devices can move anywhere in range, with no new cables",
        downside: "Walls, distance and interference slow it down",
      },
      bullets: ["wired-wireless", "connection-modes"],
      bank: ["1.3.2 Q2(b)(i)", "1.3.2 Q3(b)(iii)"],
    },
    wifi: {
      id: "wifi",
      a: {
        name: "Encrypted",
        cost: 6,
        upside: "Intercepted data cannot be understood without the key",
        downside: "Every device needs the key to join",
      },
      b: {
        name: "Open",
        cost: 0,
        upside: "Nothing to set up",
        downside: "Anyone in range can read what is sent",
      },
      bullets: ["encryption"],
      bank: ["1.3.2 Q4(b)"],
    },
  },
  we = 160,
  $r = {
    topology: "b",
    model: "a",
    storage: "b",
    bandwidth: "b",
    area: "a",
    wifi: "a",
  };
function ke(t, s) {
  return ae[t][s];
}
function ut(t) {
  return L.reduce((s, r) => {
    const i = t[r];
    return i ? s + ke(r, i).cost : s;
  }, 0);
}
function Ft(t, s, r = t[L[s]]) {
  const i = L[s],
    a = ut({ ...t, [i]: void 0 });
  return { spent: a, bite: r ? ut(Mr(t, s, r)) - a : 0 };
}
function kt(t) {
  return Math.min(ae[t].a.cost, ae[t].b.cost);
}
function rt(t, s, r) {
  let i = 0;
  return (
    L.forEach((a, o) => {
      if (o < s) {
        const l = t[a];
        i += l ? ke(a, l).cost : kt(a);
      } else o === s ? (i += ke(a, r).cost) : (i += kt(a));
    }),
    i <= we
  );
}
function Mr(t, s, r) {
  const i = { ...t, [L[s]]: r };
  return (
    L.forEach((a, o) => {
      const l = i[a];
      o > s && l && !rt(i, o, l) && delete i[a];
    }),
    i
  );
}
function gi(t) {
  return L.every((s) => t[s] !== void 0);
}
function Fe(t, s) {
  const r = t * s;
  if (r >= 1e3) {
    const i = r / 1e3;
    return `£${Number.isInteger(i) ? i : i.toFixed(1)}m`;
  }
  return `£${Math.round(r)}k`;
}
const bi = [
    {
      id: "nic",
      name: "NIC",
      slot: "Inside the desk computer",
      task: "A NIC lets a computer connect to the network. Each one has its own MAC address.",
      title: "NIC: network interface card",
      lines: [
        "Every device that joins a network has one: a computer, a printer, a phone.",
        "It connects the device to the network, through a port for a cable or an aerial for wireless.",
        "Each NIC is given its own MAC address when it is made: 12 hexadecimal digits in pairs.",
      ],
    },
    {
      id: "switch",
      name: "Switch",
      slot: "Shelf in the comms cupboard",
      task: "A switch connects the devices in the LAN and sends data to the right device using its MAC address.",
      title: "Switch",
      lines: [
        "Connects the devices in a LAN: the cable from every desk plugs into one of its ports.",
        "It reads the destination MAC address of each packet and sends it out of the matching port only, not to every device.",
      ],
    },
    {
      id: "wap",
      name: "WAP",
      slot: "Ceiling above the desks",
      task: "A wireless access point lets wireless devices join the LAN.",
      title: "WAP: wireless access point",
      lines: [
        "Lets wireless devices such as laptops, tablets and phones join the LAN, using Wi-Fi.",
        "It sends and receives the data as radio waves, and is cabled to the switch.",
        "Walls, distance and interference weaken the signal.",
      ],
    },
    {
      id: "router",
      name: "Router",
      slot: "Where the outside line comes in",
      task: "A router receives packets and forwards them between networks using IP addresses, linking this LAN to the WAN and the internet.",
      title: "Router",
      lines: [
        "Where the LAN meets the outside world: it links this LAN to the WAN and the internet.",
        "It receives packets and forwards them between networks using IP addresses.",
        "The internet is a network of networks joined by routers, all following TCP/IP: the rules for sending packets across networks.",
      ],
    },
    {
      id: "cable",
      name: "Cable",
      slot: "From the desks to the comms cupboard",
      task: "The transmission media: Ethernet cable carries the data between each computer and the switch.",
      title: "Cable: the transmission media",
      lines: [
        "Carries the data between each computer and the switch.",
        "Ethernet cable has copper wires inside, and a plug at each end that clicks into a port.",
        "Fibre optic cable carries data as pulses of light, further and faster than copper.",
      ],
    },
  ],
  Wr = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
  vr = 5,
  mt = ["Mon", "Tue", "Wed", "Thu", "Fri"];
function Lr(t) {
  return mt[Math.min(t, mt.length - 1)];
}
const Le = {
  cut: {
    category: "topology",
    decision: "topology",
    outcomes: { a: "vulnerable", b: "protected" },
    lesson:
      "Mesh: if one link breaks, data takes another route. In a star, a site whose link breaks is cut off.",
    fix: "Mesh: a second route to every site",
    bullets: ["star-mesh"],
    bank: ["1.3.1 Q1(b)(ii)", "1.3.1 Q2(ii)"],
  },
  peak: {
    category: "performance",
    decision: "bandwidth",
    outcomes: { a: "vulnerable", b: "protected" },
    lesson:
      "More devices share the same bandwidth, so each one gets less. More bandwidth means more data per second.",
    fix: "More bandwidth on the internet connection",
    bullets: ["performance"],
    bank: ["1.3.1 Q4(a)(i)", "1.3.2 Q1(a)(ii)"],
  },
  files: {
    category: "model",
    decision: "model",
    outcomes: { a: "protected", b: "vulnerable" },
    lesson:
      "A file server stores files, backs them up and provides them to clients that request them. In peer-to-peer, files are spread across computers with no central backup.",
    fix: "Client-server: one file server that stores and backs up every file",
    bullets: ["client-server", "hosting"],
    bank: ["1.3.1 Q3(i)", "1.3.1 Q3(ii)"],
  },
  server: {
    category: "model",
    decision: "model",
    outcomes: { a: "vulnerable", b: "protected" },
    lesson:
      "In client-server, the clients rely on the server: if it fails, nobody can reach the shared files until it is fixed. In peer-to-peer, each computer keeps its own files, so there is no single server to fail.",
    fix: "Peer-to-peer: no single server that everyone relies on",
    bullets: ["client-server"],
    bank: ["1.3.1 Q3(i)", "1.3.1 Q3(ii)"],
  },
  offline: {
    category: "cloud",
    decision: "storage",
    outcomes: { a: "protected", b: "vulnerable" },
    lesson:
      "The cloud needs a constant internet connection. On-site servers still work when the internet is down.",
    fix: "On-site servers",
    bullets: ["cloud"],
    bank: ["1.3.1 Q1(c)", "1.3.1 Q8(c)"],
  },
  remote: {
    category: "cloud",
    decision: "storage",
    outcomes: { a: "vulnerable", b: "protected" },
    lesson:
      "The cloud gives remote access from anywhere with an internet connection, and the provider handles the backup.",
    fix: "Cloud: open from anywhere online",
    bullets: ["cloud"],
    bank: ["1.3.1 Q8(b)", "1.3.1 Q6(i)"],
  },
  walls: {
    category: "connection",
    decision: "area",
    outcomes: { a: "protected", b: "vulnerable" },
    lesson:
      "Wireless is slowed by walls, distance and interference. A wired connection is faster and more reliable.",
    fix: "Wired: Ethernet cable to every desk",
    bullets: ["wired-wireless"],
    bank: ["1.3.2 Q2(b)(i)", "1.3.2 Q3(b)(iii)"],
  },
  move: {
    category: "connection",
    decision: "area",
    outcomes: { a: "vulnerable", b: "protected" },
    lesson:
      "Wireless devices can move anywhere in range, with no new cables. A wired device is fixed to where its cable runs.",
    fix: "Wireless: devices work anywhere in range",
    bullets: ["wired-wireless", "connection-modes"],
    bank: ["1.3.2 Q2(b)(i)", "1.3.2 Q3(b)(iii)"],
  },
  snoop: {
    category: "connection",
    decision: "wifi",
    outcomes: { a: "protected", b: "vulnerable" },
    lesson:
      "Encryption scrambles data so that, if it is intercepted, it cannot be understood without the key.",
    fix: "Encrypted Wi-Fi",
    bullets: ["encryption"],
    bank: ["1.3.2 Q4(b)"],
  },
};
function Nr(t, s) {
  const r = Le[t];
  return r.outcomes[s[r.decision]];
}
function wi(t) {
  return Le[t].outcomes.a === "protected" ? "a" : "b";
}
const zt = [
    {
      id: "dns",
      label: "DNS",
      kind: "inspect",
      bullets: ["dns", "hosting"],
      bank: ["1.3.1 Q1(d)(iii)"],
    },
    {
      id: "ip",
      label: "IP",
      kind: "inspect",
      bullets: ["ip"],
      bank: ["1.3.2 Q2(a)(i)", "1.3.1 Q1(d)(ii)"],
    },
    {
      id: "https",
      label: "HTTPS",
      kind: "choice",
      bullets: ["http-https", "encryption", "protocol-rules", "hosting"],
      bank: ["1.3.2 Q3(a)(i)", "1.3.2 Q5(a)"],
    },
    {
      id: "build",
      label: "Route",
      kind: "auto",
      bullets: ["star-mesh", "lan-wan"],
      bank: ["1.3.1 Q1(b)(ii)"],
    },
    {
      id: "switch",
      label: "Switch",
      kind: "inspect",
      bullets: ["mac", "hardware"],
      bank: ["1.3.2 Q2(a)(ii)", "1.3.1 Q2(iii)"],
    },
    {
      id: "bluetooth",
      label: "Bluetooth",
      kind: "inspect",
      bullets: ["connection-modes", "wired-wireless"],
      bank: ["1.3.2 Q2(b)(ii)"],
    },
    {
      id: "mail",
      label: "Email",
      kind: "choice",
      bullets: ["email-protocols", "ftp", "protocol-rules"],
      bank: ["1.3.2 Q3(a)(i)", "1.3.2 Q4(c)"],
    },
    {
      id: "standards",
      label: "Standards",
      kind: "inspect",
      bullets: ["standards"],
      bank: ["1.3.2 Q4(a)"],
    },
    {
      id: "layers",
      label: "Layers",
      kind: "inspect",
      bullets: ["layers"],
      bank: ["1.3.2 Q3(a)(ii)", "1.3.2 Q5(b)(ii)"],
    },
    {
      id: "hardware",
      label: "Hardware",
      kind: "inspect",
      bullets: ["hardware", "internet", "tcpip", "mac", "lan-wan"],
      bank: ["1.3.1 Q2(iii)", "1.3.1 Q4(c)", "1.3.1 Q1(d)(i)"],
    },
    {
      id: "lan-wan",
      label: "Sites",
      kind: "inspect",
      bullets: ["lan-wan"],
      bank: ["1.3.1 Q1(a)", "1.3.1 Q8(a)"],
    },
  ],
  $i = [
    {
      id: "dns",
      label: "DNS",
      feedback:
        "DNS is made up of many name servers. The first did not know this name, so it asked another, which sent back the IP address.",
    },
    {
      id: "switch",
      label: "Switch",
      feedback:
        "A switch sends data to devices inside a LAN using MAC addresses. It does not look up names.",
    },
    {
      id: "wap",
      label: "WAP",
      feedback:
        "A WAP lets wireless devices join a LAN. It does not look up names.",
    },
  ],
  Mi = [
    {
      id: "bluetooth",
      label: "Bluetooth",
      feedback:
        "Bluetooth links two devices directly over a short range, with no WAP and no cable.",
    },
    {
      id: "wifi",
      label: "Wi-Fi",
      feedback:
        "Wi-Fi joins devices to a LAN through a WAP. Two devices close together can pair directly with Bluetooth.",
    },
    {
      id: "ethernet",
      label: "Ethernet",
      feedback:
        "Ethernet is a wired connection. Here there is no cable: Bluetooth pairs the two devices directly.",
    },
  ],
  Wi = [
    {
      id: "smtp",
      label: "SMTP",
      feedback:
        "SMTP sends email from the sender to the mail server, and on between mail servers.",
    },
    {
      id: "ftp",
      label: "FTP",
      feedback:
        "FTP transfers files between a client and a server. Sending email is SMTP’s job.",
    },
    {
      id: "pop",
      label: "POP",
      feedback:
        "POP fetches email from the mail server; it does not send it. Sending is SMTP’s job.",
    },
    {
      id: "imap",
      label: "IMAP",
      feedback:
        "IMAP fetches email from the mail server; it does not send it. Sending is SMTP’s job.",
    },
  ],
  vi = [
    {
      id: "standards",
      label: "Every maker follows the same standards",
      feedback:
        "A standard is a set of rules that lets hardware and software from different manufacturers work together.",
    },
    {
      id: "mac",
      label: "They share one MAC address",
      feedback:
        "Every device is given its own MAC address. It is shared standards that let different makers’ kit work together.",
    },
    {
      id: "router",
      label: "The router was replaced",
      feedback:
        "A new router would not make kit from different makers compatible. Shared standards do.",
    },
  ],
  Li = [
    {
      id: "one",
      label: "Only the app’s own layer",
      feedback:
        "Network protocols are split into layers. Each layer is self-contained, so one can be changed without changing the others.",
    },
    {
      id: "all",
      label: "Every layer",
      feedback:
        "Layers are independent: changing one does not mean changing the others.",
    },
  ],
  Ni = [
    { id: "ipv4", label: "IPv4" },
    { id: "ipv6", label: "IPv6" },
    { id: "invalid", label: "Not valid" },
  ],
  Ai = [
    {
      address: "203.0.113.24",
      kind: "ipv4",
      why: "Four numbers from 0 to 255, separated by full stops: IPv4.",
    },
    {
      address: "2001:db8:4f:0:0:0:0:24",
      kind: "ipv6",
      why: "Eight groups of hexadecimal, separated by colons: IPv6.",
    },
    {
      address: "192.168.1.256",
      kind: "invalid",
      why: "256 is more than 255, so this is not a valid IPv4 address.",
    },
    {
      address: "56.1.2.66.1",
      kind: "invalid",
      why: "Five numbers: an IPv4 address has exactly four.",
    },
  ],
  Hi = [
    {
      id: "http",
      label: "HTTP",
      feedback:
        "HTTP is the protocol (set of rules) for requesting and sending web pages between a client and a web server.",
    },
    {
      id: "https",
      label: "HTTPS",
      feedback:
        "HTTPS is HTTP with encryption: the data is scrambled between the client and the web server.",
    },
  ],
  Si = [
    {
      id: "imap",
      label: "IMAP",
      feedback:
        "IMAP keeps email on the mail server, so every device sees the same inbox.",
    },
    {
      id: "pop",
      label: "POP",
      feedback:
        "POP downloads email to one device and removes it from the server.",
    },
  ],
  Ar = "3C:52:82:1A:9F:04",
  Ci = ["7A:11:C0:5E:22:9B", "B4:2E:99:07:6C:11", Ar, "E8:6F:38:A2:14:D0"],
  Di =
    "The switch reads the destination MAC address and sends the packet out of the matching port only. A MAC address is assigned to each device: 12 hexadecimal digits in pairs, separated by colons.";
function Pi(t, s = Math.random) {
  const r = yt(t, s);
  return yt(L, s)
    .slice(0, vr)
    .map((i) => {
      const a = r.find((o) => Le[o.kind].decision === i);
      if (!a) throw new Error(`No ${i} incident`);
      return a;
    });
}
function yt(t, s = Math.random) {
  const r = [...t];
  for (let i = r.length - 1; i > 0; i -= 1) {
    const a = Math.floor(s() * (i + 1));
    [r[i], r[a]] = [r[a], r[i]];
  }
  return r;
}
[...L.flatMap((t) => ae[t].bullets)];
function it(t) {
  return t === "protected" ? "good" : "friction";
}
function Hr() {
  return e.jsxs("svg", {
    viewBox: "-14 -16 28 30",
    "aria-hidden": "true",
    className: "nb-logo",
    children: [
      e.jsx("path", {
        d: "M0 -8 L-10 8 M0 -8 L10 8 M-10 8 H10",
        stroke: "#4a7bd0",
        strokeWidth: "3",
        strokeLinecap: "round",
      }),
      e.jsx("circle", {
        cx: "0",
        cy: "-8",
        r: "5",
        fill: "#7dd8b5",
        stroke: "#1f2a44",
        strokeWidth: "1.6",
      }),
      e.jsx("circle", {
        cx: "-10",
        cy: "8",
        r: "5",
        fill: "#ffb38a",
        stroke: "#1f2a44",
        strokeWidth: "1.6",
      }),
      e.jsx("circle", {
        cx: "10",
        cy: "8",
        r: "5",
        fill: "#c9b8ff",
        stroke: "#1f2a44",
        strokeWidth: "1.6",
      }),
    ],
  });
}
function Qi({ title: t, right: s }) {
  return e.jsxs("div", {
    className: "nb-topbar",
    children: [
      e.jsxs("div", {
        className: "nb-brand",
        children: [e.jsx(Hr, {}), e.jsx("span", { children: t })],
      }),
      s ? e.jsx("div", { className: "nb-topbar-right", children: s }) : null,
    ],
  });
}
function Ti({ org: t }) {
  return e.jsxs("span", {
    className: "nb-org-chip",
    style: { background: t.theme.secondary },
    "data-org-chip": t.id,
    children: [
      e.jsx(yr, { id: t.id, className: "nb-org-chip-icon" }),
      e.jsx("span", { children: t.name }),
    ],
  });
}
function Ei({ total: t, spent: s, bite: r = 0, format: i }) {
  const a = t - s;
  return e.jsxs("span", {
    className: "nb-budget",
    "data-budget-left": a,
    "data-budget-bite": r,
    children: [
      e.jsxs("span", {
        className: "nb-budget-text",
        children: [
          i(a),
          " left of ",
          i(t),
          r > 0
            ? e.jsxs("span", {
                className: "sr-only",
                children: [", this choice costs ", i(r)],
              })
            : null,
        ],
      }),
      e.jsx(nt, { total: t, left: a, bite: r }),
    ],
  });
}
function nt({
  total: t,
  left: s,
  bite: r = 0,
  biteOnly: i = !1,
  className: a = "",
}) {
  const o = (l) => `${t > 0 ? Math.max(0, Math.min(1, l / t)) * 100 : 0}%`;
  return e.jsxs("span", {
    className: `nb-budget-bar ${a}`,
    "aria-hidden": "true",
    children: [
      i
        ? null
        : e.jsx("span", {
            className: "nb-budget-keep",
            style: { width: o(s - r) },
          }),
      r > 0
        ? e.jsx("span", {
            className: "nb-budget-take",
            style: { width: o(Math.min(r, s)) },
          })
        : null,
    ],
  });
}
function qt({ className: t = "" }) {
  return e.jsxs("svg", {
    viewBox: "-10 -10 20 20",
    "aria-hidden": "true",
    className: `nb-mark ${t}`,
    children: [
      e.jsx("circle", { r: "10", fill: "#2f9e76" }),
      e.jsx("path", {
        d: "M-4.5 0.5 L-1.2 3.8 L5 -3.5",
        fill: "none",
        stroke: "#fff",
        strokeWidth: "2.6",
        strokeLinecap: "round",
        strokeLinejoin: "round",
      }),
    ],
  });
}
function Ut({ className: t = "" }) {
  return e.jsxs("svg", {
    viewBox: "-10 -10 20 20",
    "aria-hidden": "true",
    className: `nb-mark ${t}`,
    children: [
      e.jsx("circle", { r: "10", fill: "#f2a541" }),
      e.jsx("rect", {
        x: "-4.5",
        y: "-4.5",
        width: "3",
        height: "9",
        rx: "1.2",
        fill: "#fff",
      }),
      e.jsx("rect", {
        x: "1.5",
        y: "-4.5",
        width: "3",
        height: "9",
        rx: "1.2",
        fill: "#fff",
      }),
    ],
  });
}
function at({ tone: t, label: s }) {
  return e.jsxs("span", {
    className: "nb-mark-wrap",
    "data-tone": t,
    children: [
      t === "good" ? e.jsx(qt, {}) : e.jsx(Ut, {}),
      e.jsx("span", {
        className: "sr-only",
        children: s ?? (t === "good" ? "Went well" : "Caused friction"),
      }),
    ],
  });
}
function Sr({ outcome: t }) {
  const s = t === "protected" ? "Protected" : "Not protected";
  return e.jsx(at, { tone: it(t), label: s });
}
function Ii({ count: t, outcomes: s, current: r, time: i }) {
  const a = Array.from({ length: t }, (o, l) => l);
  return e.jsxs("div", {
    className: "nb-week-strip",
    children: [
      e.jsx("span", { className: "nb-clock", children: i }),
      e.jsx("ol", {
        className: "nb-days",
        "aria-label": "The week",
        children: Wr.map((o) => {
          const l = a.filter((x) => Lr(x) === o),
            d = r !== null && l.includes(r);
          return e.jsxs(
            "li",
            {
              className: "nb-day",
              "data-state": l.length ? (d ? "now" : "busy") : "quiet",
              "aria-current": d ? "step" : void 0,
              children: [
                e.jsx("span", {
                  className: "nb-pins",
                  "aria-hidden": "true",
                  children: l.length
                    ? l.map((x) => {
                        const f = s[x],
                          p = f ? it(f) : x === r ? "now" : "later";
                        return e.jsx(
                          "span",
                          { className: "nb-pin", "data-state": p },
                          x,
                        );
                      })
                    : e.jsx("span", {
                        className: "nb-pin",
                        "data-state": "quiet",
                      }),
                }),
                e.jsx("span", { children: o }),
              ],
            },
            o,
          );
        }),
      }),
    ],
  });
}
function Vi({ current: t, tones: s, onSelect: r }) {
  return e.jsx("nav", {
    "aria-label": "Trace stops",
    children: e.jsx("ol", {
      className: "nb-trace-bar",
      children: zt.map((i, a) => {
        const o = s[a] !== void 0,
          l = i.kind === "choice" ? void 0 : s[a],
          d = a === t ? "now" : o ? (l ?? "chosen") : "later";
        return e.jsx(
          "li",
          {
            className: "nb-stop",
            "data-state": d,
            children: e.jsxs("button", {
              type: "button",
              className: "nb-stop-button",
              "aria-current": a === t ? "step" : void 0,
              "data-go-stop": i.id,
              onClick: () => r(a),
              children: [
                e.jsx("span", {
                  className: "nb-stop-dot",
                  "aria-hidden": "true",
                  children:
                    a !== t && l
                      ? l === "friction"
                        ? e.jsx(Ut, {})
                        : e.jsx(qt, {})
                      : null,
                }),
                e.jsx("span", {
                  className: "nb-stop-label",
                  children: i.label,
                }),
              ],
            }),
          },
          i.id,
        );
      }),
    }),
  });
}
function Oi({ ids: t, ready: s = !1, onPick: r }) {
  return Mt()
    ? e.jsx("div", {
        className: "nb-pick-phone",
        "data-network-build-stage": "pick",
        children: e.jsx(rs, {
          label: "Choose an organisation",
          primaryClass: "nb-button nb-primary",
          picks: t.map((a) => {
            const o = Ze(a);
            return {
              id: a,
              name: o.name,
              line: o.story,
              art: e.jsx(wr, { org: o }),
              data: { "data-org": o.id },
            };
          }),
          onPick: (a) => r(a),
        }),
      })
    : e.jsxs("div", {
        className: "nb-page nb-pick",
        "data-network-build-stage": "pick",
        children: [
          e.jsx("div", {
            className: "nb-pick-head",
            children: e.jsx("h2", {
              className: "nb-title",
              children: "Choose an organisation",
            }),
          }),
          s
            ? e.jsx("ul", {
                className: "nb-ready",
                "aria-label": "Ready-built network",
                children: L.map((a) =>
                  e.jsx("li", { children: ke(a, $r[a]).name }, a),
                ),
              })
            : null,
          e.jsx("div", {
            className: "nb-orgs",
            children: t
              .map(Ze)
              .map((a, o) =>
                e.jsxs(
                  "button",
                  {
                    type: "button",
                    className: "nb-org-card",
                    onClick: () => r(t[o]),
                    "data-org": a.id,
                    children: [
                      e.jsx("span", {
                        className: "nb-org-stage",
                        children: e.jsx(gr, {
                          org: a,
                          className: "nb-org-scene",
                        }),
                      }),
                      e.jsxs("span", {
                        className: "nb-org-text",
                        children: [
                          e.jsx("span", {
                            className: "nb-org-name",
                            children: a.name,
                          }),
                          e.jsx("span", {
                            className: "nb-org-story",
                            children: a.story,
                          }),
                        ],
                      }),
                    ],
                  },
                  a.id,
                ),
              ),
          }),
        ],
      });
}
function Ri({ org: t, build: s, step: r, onPick: i, onBack: a, onNext: o }) {
  const l = L[r],
    d = ae[l],
    x = st(t)[l],
    f = s[l],
    [p, k] = C.useState(null);
  function j(m) {
    if (!p) {
      if (Wt()) {
        m === "next" ? o() : a();
        return;
      }
      k(m);
    }
  }
  return Mt()
    ? e.jsx(Pr, { org: t, build: s, step: r, onPick: i, onBack: a, onNext: o })
    : e.jsxs("div", {
        className: "nb-page nb-build-page",
        "data-network-build-stage": "decide",
        "data-decision": l,
        children: [
          e.jsx(Ot, {
            org: t,
            build: s,
            decision: l,
            className: "nb-art nb-map",
            leaving: p !== null,
            onLeft: p === "back" ? a : o,
          }),
          e.jsxs("div", {
            className: "nb-decision",
            children: [
              e.jsxs("div", {
                className: "nb-decision-head",
                children: [
                  e.jsx("ol", {
                    className: "nb-dots",
                    "aria-label": `Decision ${r + 1} of ${L.length}`,
                    children: L.map((m, g) =>
                      e.jsx(
                        "li",
                        {
                          "data-state":
                            g < r ? "done" : g === r ? "now" : "later",
                        },
                        m,
                      ),
                    ),
                  }),
                  e.jsxs("span", {
                    className: "nb-count",
                    "aria-hidden": "true",
                    children: [r + 1, " of ", L.length],
                  }),
                  e.jsx("h2", { className: "nb-title", children: x.title }),
                  e.jsxs("div", {
                    className: "nb-nav",
                    children: [
                      e.jsx("button", {
                        type: "button",
                        className: "nb-button",
                        onClick: () => j("back"),
                        children: "Back",
                      }),
                      e.jsx("button", {
                        type: "button",
                        className: "nb-button nb-primary",
                        onClick: () => j("next"),
                        disabled: !f,
                        children: "Next",
                      }),
                    ],
                  }),
                ],
              }),
              e.jsx("div", {
                className: "nb-options",
                role: "group",
                "aria-label": x.title,
                children: ["a", "b"].map((m) => {
                  const g = d[m],
                    b = rt(s, r, m),
                    P = Ft(s, r, m),
                    I =
                      g.cost === 0
                        ? "Free"
                        : l === "storage" && m === "b"
                          ? `${Fe(g.cost, t.scale)} a year`
                          : Fe(g.cost, t.scale);
                  return e.jsxs(
                    "button",
                    {
                      type: "button",
                      className: "nb-option",
                      "aria-pressed": f === m,
                      disabled: !b,
                      "data-option": m,
                      onClick: () => {
                        p || i(m);
                      },
                      children: [
                        e.jsx(Rt, { id: l, side: m }),
                        e.jsxs("span", {
                          className: "nb-option-text",
                          children: [
                            e.jsx("span", {
                              className: "nb-option-name",
                              children: g.name,
                            }),
                            e.jsxs("span", {
                              className: "nb-option-price",
                              children: [
                                e.jsx("span", {
                                  className: "nb-option-cost",
                                  children: I,
                                }),
                                e.jsx(nt, {
                                  total: we - P.spent,
                                  left: we - P.spent,
                                  bite: P.bite,
                                  biteOnly: !0,
                                  className: "nb-option-budget",
                                }),
                              ],
                            }),
                            e.jsxs("span", {
                              className: "nb-option-lines",
                              children: [x[m][0], " ", x[m][1]],
                            }),
                          ],
                        }),
                      ],
                    },
                    m,
                  );
                }),
              }),
              f
                ? e.jsxs("ul", {
                    className: "nb-tradeoff",
                    "aria-live": "polite",
                    "data-tradeoff": l,
                    children: [
                      e.jsxs("li", {
                        "data-tone": "good",
                        children: [
                          e.jsx("span", {
                            "aria-hidden": "true",
                            children: "+",
                          }),
                          e.jsx("span", {
                            className: "sr-only",
                            children: "Advantage: ",
                          }),
                          d[f].upside,
                        ],
                      }),
                      e.jsxs("li", {
                        "data-tone": "friction",
                        children: [
                          e.jsx("span", {
                            "aria-hidden": "true",
                            children: "−",
                          }),
                          e.jsx("span", {
                            className: "sr-only",
                            children: "Disadvantage: ",
                          }),
                          d[f].downside,
                        ],
                      }),
                    ],
                  })
                : null,
            ],
          }),
        ],
      });
}
function Cr(t, s, r) {
  const i = L[s],
    a = ae[i][r];
  if (a.cost === 0) return "Free";
  const o = Fe(a.cost, t.scale);
  return i === "storage" && r === "b" ? `${o} a year` : o;
}
const Ce = ["a", "b"],
  Dr = 48;
function Pr({ org: t, build: s, step: r, onPick: i, onBack: a, onNext: o }) {
  const l = L[r],
    d = ae[l],
    x = st(t)[l],
    f = s[l],
    [p, k] = C.useState(f === "b" ? 1 : 0),
    j = C.useRef(null),
    u = Ce[p],
    m = d[u],
    g = rt(s, r, u),
    b = Ft(s, r, u),
    P = f === u;
  function I(V) {
    k((T) => (T + V + Ce.length) % Ce.length);
  }
  return e.jsxs("div", {
    className: "nb-page nb-build-page nb-pager",
    "data-network-build-stage": "decide",
    "data-decision": l,
    children: [
      e.jsxs("div", {
        className: "nb-pager-head",
        children: [
          e.jsx("ol", {
            className: "nb-dots",
            "aria-label": `Decision ${r + 1} of ${L.length}`,
            children: L.map((V, T) =>
              e.jsx(
                "li",
                { "data-state": T < r ? "done" : T === r ? "now" : "later" },
                V,
              ),
            ),
          }),
          e.jsxs("span", {
            className: "nb-count",
            "aria-hidden": "true",
            children: [r + 1, " of ", L.length],
          }),
          e.jsx("h2", { className: "nb-title", children: x.title }),
        ],
      }),
      e.jsxs("section", {
        className: "nb-pager-card",
        "aria-label": x.title,
        "data-story-card": "option",
        "data-option": u,
        "data-chosen": P || void 0,
        onTouchStart: (V) => {
          const T = V.touches[0];
          j.current = T ? { x: T.clientX, y: T.clientY } : null;
        },
        onTouchEnd: (V) => {
          const T = j.current,
            Ie = V.changedTouches[0];
          if (((j.current = null), !T || !Ie)) return;
          const Ve = Ie.clientX - T.x;
          Math.abs(Ve) > Dr &&
            Math.abs(Ve) > Math.abs(Ie.clientY - T.y) &&
            I(Ve < 0 ? 1 : -1);
        },
        children: [
          e.jsx(
            "span",
            {
              className: "nb-pager-art",
              children: e.jsx(Rt, { id: l, side: u }),
            },
            u,
          ),
          e.jsxs("span", {
            className: "nb-pager-text",
            children: [
              e.jsx("span", { className: "nb-option-name", children: m.name }),
              e.jsxs("span", {
                className: "nb-option-price",
                children: [
                  e.jsx("span", {
                    className: "nb-option-cost",
                    children: Cr(t, r, u),
                  }),
                  e.jsx(nt, {
                    total: we - b.spent,
                    left: we - b.spent,
                    bite: b.bite,
                    biteOnly: !0,
                    className: "nb-option-budget",
                  }),
                ],
              }),
              e.jsxs("span", {
                className: "nb-option-lines",
                children: [x[u][0], " ", x[u][1]],
              }),
            ],
          }),
          e.jsxs("div", {
            className: "nb-pager-nav",
            children: [
              e.jsx("button", {
                type: "button",
                className: "nb-pager-arrow",
                "aria-label": "Previous option",
                onClick: () => I(-1),
                children: e.jsx(ns, { "aria-hidden": "true" }),
              }),
              e.jsx("button", {
                type: "button",
                className: "nb-button nb-pager-choose",
                "aria-pressed": P,
                disabled: !g,
                "data-option": u,
                onClick: () => i(u),
                children: P ? "Chosen" : g ? "Choose" : "Over budget",
              }),
              e.jsx("button", {
                type: "button",
                className: "nb-pager-arrow",
                "aria-label": "Next option",
                onClick: () => I(1),
                children: e.jsx(as, { "aria-hidden": "true" }),
              }),
            ],
          }),
          e.jsxs("p", {
            className: "nb-pager-count",
            "aria-live": "polite",
            children: ["Option ", p + 1, " of ", Ce.length],
          }),
        ],
      }),
      P
        ? e.jsxs("ul", {
            className: "nb-tradeoff",
            "aria-live": "polite",
            "data-tradeoff": l,
            children: [
              e.jsxs("li", {
                "data-tone": "good",
                children: [
                  e.jsx("span", { "aria-hidden": "true", children: "+" }),
                  e.jsx("span", {
                    className: "sr-only",
                    children: "Advantage: ",
                  }),
                  m.upside,
                ],
              }),
              e.jsxs("li", {
                "data-tone": "friction",
                children: [
                  e.jsx("span", { "aria-hidden": "true", children: "−" }),
                  e.jsx("span", {
                    className: "sr-only",
                    children: "Disadvantage: ",
                  }),
                  m.downside,
                ],
              }),
            ],
          })
        : null,
      e.jsxs("div", {
        className: "nb-nav nb-pager-steps",
        children: [
          e.jsx("button", {
            type: "button",
            className: "nb-button",
            onClick: a,
            children: "Back",
          }),
          e.jsx("button", {
            type: "button",
            className: "nb-button nb-primary",
            onClick: o,
            disabled: !f,
            children: "Next",
          }),
        ],
      }),
    ],
  });
}
function _i({ org: t, build: s, onBack: r, onConfirm: i }) {
  const a = st(t);
  return e.jsxs("div", {
    className: "nb-page nb-build-page",
    "data-network-build-stage": "review",
    children: [
      e.jsx(Ot, { org: t, build: s, className: "nb-art nb-map" }),
      e.jsxs("div", {
        className: "nb-decision",
        children: [
          e.jsxs("div", {
            className: "nb-decision-head",
            children: [
              e.jsx("h2", { className: "nb-title", children: "Your network" }),
              e.jsxs("div", {
                className: "nb-nav",
                children: [
                  e.jsx("button", {
                    type: "button",
                    className: "nb-button",
                    onClick: r,
                    children: "Back",
                  }),
                  e.jsx("button", {
                    type: "button",
                    className: "nb-button nb-primary",
                    onClick: i,
                    children: "Confirm build",
                  }),
                ],
              }),
            ],
          }),
          e.jsx("ul", {
            className: "nb-ready nb-review-picks",
            children: L.map((o) => {
              const l = s[o];
              return l
                ? e.jsxs(
                    "li",
                    {
                      children: [
                        e.jsxs("span", {
                          className: "sr-only",
                          children: [a[o].title, ": "],
                        }),
                        ke(o, l).name,
                      ],
                    },
                    o,
                  )
                : null;
            }),
          }),
        ],
      }),
    ],
  });
}
function Qr({ org: t }) {
  return e.jsxs("svg", {
    viewBox: "508 82 244 168",
    "aria-hidden": "true",
    className: "nb-art",
    "data-org-scene": t.id,
    children: [
      e.jsx("rect", {
        x: "508",
        y: "82",
        width: "244",
        height: "168",
        rx: "10",
        fill: n.mintWash,
      }),
      e.jsx(H, {
        kind: t.theme.hub,
        theme: t.theme,
        x: 680,
        y: 148,
        w: 56,
        h: 56,
      }),
      e.jsx("rect", {
        x: "508",
        y: "200",
        width: "244",
        height: "50",
        fill: "#bfead6",
      }),
      e.jsx("rect", {
        x: "588",
        y: "110",
        width: "84",
        height: "58",
        rx: "6",
        fill: n.blueprint,
        stroke: h,
        strokeWidth: 1.6,
      }),
      e.jsx("path", {
        d: "M600 152 L620 128 L642 146 L660 122",
        fill: "none",
        stroke: n.cable,
        strokeWidth: "3",
        strokeLinecap: "round",
        strokeLinejoin: "round",
      }),
      [
        [600, 152],
        [620, 128],
        [642, 146],
        [660, 122],
      ].map(([s, r]) =>
        e.jsx(
          "circle",
          {
            cx: s,
            cy: r,
            r: "4.5",
            fill: n.mint,
            stroke: h,
            strokeWidth: "1.4",
          },
          s,
        ),
      ),
      e.jsx($, {
        x: 562,
        y: 246,
        s: 0.92,
        outfit: "engineer",
        skin: y.dark,
        hair: E.dark,
        long: !0,
        holding: e.jsx(Ke, { x: 4, y: 4, s: 0.45 }),
      }),
    ],
  });
}
function Bi(t, s) {
  const r = [],
    i = s.https?.pick;
  i &&
    r.push({
      id: "https",
      title: `${is(t.trace.packet)}, sent with ${i.toUpperCase()}`,
      when: "The next month",
      tone: i === "https" ? "good" : "friction",
      beat: i === "https" ? t.trace.https : t.trace.http,
      fix:
        i === "https"
          ? void 0
          : "HTTPS: encrypts the data between the client and the web server",
      bank: ["1.3.2 Q3(a)(i)", "1.3.2 Q4(b)"],
    });
  const a = s.mail?.pick;
  return (
    a &&
      r.push({
        id: "mailbox",
        title: `A mailbox on ${a.toUpperCase()}`,
        when: "That night",
        tone: a === "imap" ? "good" : "friction",
        beat: a === "imap" ? t.trace.mail.imap : t.trace.mail.pop,
        fix:
          a === "imap"
            ? void 0
            : "IMAP: email stays on the server, so every device sees it",
        bank: ["1.3.2 Q3(a)(i)", "1.3.2 Q4(c)"],
      }),
    r
  );
}
function Zi({ build: t, week: s, trace: r }) {
  const i = s.map((o) => {
      const l = Le[o.kind],
        d = Nr(o.kind, t);
      return {
        id: o.kind,
        label: o.title,
        choice: ke(l.decision, t[l.decision]).name,
        mark: { tone: it(d), outcome: d },
        bank: l.bank,
      };
    }),
    a = zt.flatMap((o) => {
      const l = r[o.id];
      return l
        ? [
            {
              id: o.id,
              label: o.label,
              choice: l.choice,
              mark: { tone: l.tone },
              bank: o.bank,
            },
          ]
        : [];
    });
  return { week: i, trace: a };
}
const Tr =
    "https://nationalcareers.service.gov.uk/job-profiles/network-engineer",
  W = 300,
  U = 250,
  Er = { x: 336, y: 22, w: 168, h: 126 };
function oe({ org: t }) {
  return e.jsxs("g", {
    children: [
      e.jsx("rect", { width: "520", height: W, fill: n.paper }),
      e.jsx("rect", { width: "520", height: "10", fill: t.theme.accent }),
      e.jsx("rect", { y: W, width: "520", height: 390 - W, fill: n.road }),
      [60, 170, 280, 390, 500].map((s) =>
        e.jsx(
          "path",
          {
            d: `M${s} ${W} L${s - 30} 390`,
            stroke: "#e6d9bd",
            strokeWidth: "2",
          },
          s,
        ),
      ),
      e.jsx("path", { d: `M0 ${W} H520`, stroke: h, strokeWidth: "2.5" }),
    ],
  });
}
function Gt({ evening: t = !1 }) {
  return e.jsxs("g", {
    children: [
      e.jsx("rect", { width: "520", height: W, fill: t ? "#f4efff" : n.sky }),
      e.jsx("rect", { y: W, width: "520", height: 390 - W, fill: n.grass }),
      e.jsx("path", { d: `M0 ${W} H520`, stroke: h, strokeWidth: "2" }),
    ],
  });
}
function Ir({ viewBox: t, children: s }) {
  const { x: r, y: i, w: a, h: o } = Er;
  return e.jsxs("g", {
    "data-consequence-inset": "",
    children: [
      e.jsx("rect", {
        x: r - 6,
        y: i - 6,
        width: a + 12,
        height: o + 12,
        rx: "10",
        fill: n.navy,
        ...c,
      }),
      e.jsx("svg", {
        x: r,
        y: i,
        width: a,
        height: o,
        viewBox: t,
        preserveAspectRatio: "xMidYMid slice",
        children: s,
      }),
    ],
  });
}
function Kt({ x: t, w: s = 130 }) {
  return e.jsxs("g", {
    children: [
      e.jsx("rect", {
        x: t - s / 2,
        y: U,
        width: s,
        height: "10",
        rx: "2",
        fill: "#d9a07a",
        ...c,
      }),
      e.jsx("path", {
        d: `M${t - s / 2 + 10} ${U + 10} V${W} M${t + s / 2 - 10} ${U + 10} V${W}`,
        stroke: h,
        strokeWidth: "3",
      }),
    ],
  });
}
function Yt({ x: t, state: s, org: r, s: i = 1 }) {
  const a =
    s === "ok"
      ? n.mintWash
      : s === "off" || s === "cracked"
        ? n.greyDeep
        : "#fff";
  return e.jsxs("g", {
    transform: `translate(${t} ${U}) scale(${i})`,
    "data-screen": s,
    children: [
      e.jsx("path", {
        d: "M-8 0 V-8 H8 V0Z",
        fill: n.greyDeep,
        ...c,
        strokeWidth: 1.5,
      }),
      e.jsx("rect", {
        x: "-38",
        y: "-58",
        width: "76",
        height: "52",
        rx: "6",
        fill: s === "cracked" ? n.grey : n.navy,
        ...c,
      }),
      e.jsx("rect", {
        x: "-33",
        y: "-53",
        width: "66",
        height: "42",
        rx: "3",
        fill: a,
      }),
      s === "ok"
        ? e.jsxs("g", {
            children: [
              e.jsx("g", {
                transform: "translate(-8 -16)",
                children: e.jsx(Y, { kind: r.theme.packet }),
              }),
              e.jsx(N, { x: 20, y: -40, s: 0.55 }),
            ],
          })
        : null,
      s === "cracked"
        ? e.jsx("path", {
            d: "M-20 -50 l10 12 -7 7 12 9 -4 10",
            fill: "none",
            stroke: "#fff",
            strokeWidth: "2.2",
            strokeLinecap: "round",
            strokeLinejoin: "round",
          })
        : null,
      s === "off"
        ? e.jsx("g", {
            stroke: "#fff",
            strokeWidth: "2.4",
            strokeLinecap: "round",
            children: e.jsx("path", { d: "M-8 -40 l16 16 M8 -40 l-16 16" }),
          })
        : null,
      s === "loading" ? e.jsx(Xt, { x: 0, y: -32, r: 11 }) : null,
      s === "cloud-down"
        ? e.jsxs("g", {
            children: [
              e.jsx(re, { x: 0, y: -32, s: 0.5, fill: n.grey }),
              e.jsx("path", {
                d: "M10 -28 l8 8 M18 -28 l-8 8",
                stroke: h,
                strokeWidth: "2.2",
                strokeLinecap: "round",
              }),
            ],
          })
        : null,
    ],
  });
}
function Xt({ x: t, y: s, r }) {
  return e.jsxs("g", {
    transform: `translate(${t} ${s})`,
    children: [
      e.jsx("circle", { r, fill: "none", stroke: n.grey, strokeWidth: "4" }),
      e.jsx("path", {
        d: `M0 ${-r} A${r} ${r} 0 0 1 ${r} 0`,
        fill: "none",
        stroke: n.amber,
        strokeWidth: "4",
        strokeLinecap: "round",
      }),
    ],
  });
}
function ot() {
  return e.jsxs("g", {
    transform: "translate(-6 -34) rotate(-20)",
    children: [
      e.jsx("rect", {
        x: "-4",
        y: "-14",
        width: "8",
        height: "28",
        rx: "4",
        fill: h,
        stroke: "#fff",
        strokeWidth: 1.2,
      }),
      e.jsx("rect", {
        x: "-6",
        y: "-16",
        width: "12",
        height: "7",
        rx: "3",
        fill: h,
        stroke: "#fff",
        strokeWidth: 1.2,
      }),
      e.jsx("rect", {
        x: "-6",
        y: "9",
        width: "12",
        height: "7",
        rx: "3",
        fill: h,
        stroke: "#fff",
        strokeWidth: 1.2,
      }),
    ],
  });
}
function Jt() {
  return e.jsxs("g", {
    transform: "translate(-2 -6)",
    children: [
      e.jsx("rect", {
        x: "-9",
        y: "-13",
        width: "18",
        height: "24",
        rx: "2",
        fill: "#d9a07a",
        ...c,
        strokeWidth: 1.4,
      }),
      e.jsx("rect", {
        x: "-6",
        y: "-9",
        width: "12",
        height: "17",
        fill: "#fff",
      }),
      e.jsx("path", {
        d: "M-4 -5 H4 M-4 -1 H4 M-4 3 H2",
        stroke: n.greyDeep,
        strokeWidth: "1.3",
      }),
    ],
  });
}
function ze({ x: t, n: s, base: r = U }) {
  return e.jsx("g", {
    "data-paper-stack": s,
    children: Array.from({ length: s }, (i, a) =>
      e.jsx(
        "rect",
        {
          x: t - 18 + (a % 2) * 3,
          y: r - 6 - a * 5,
          width: "36",
          height: "6",
          rx: "1",
          fill: "#fff",
          stroke: h,
          strokeWidth: 1.2,
        },
        a,
      ),
    ),
  });
}
function Ne({ x: t, y: s, s: r = 1 }) {
  return e.jsxs("g", {
    transform: `translate(${t} ${s}) scale(${r})`,
    "data-clock": "",
    children: [
      e.jsx("circle", { r: "18", fill: "#fff", ...c, strokeWidth: 2.2 }),
      e.jsx("path", {
        d: "M0 -11 V0 L8 5",
        fill: "none",
        stroke: h,
        strokeWidth: "2.4",
        strokeLinecap: "round",
      }),
      e.jsx("path", {
        d: "M0 -18 A18 18 0 0 1 17 -6",
        fill: "none",
        stroke: n.amber,
        strokeWidth: "4",
      }),
    ],
  });
}
function Vr({ x: t, y: s, value: r }) {
  return e.jsx("g", {
    transform: `translate(${t} ${s})`,
    children: [0, 1, 2, 3].map((i) =>
      e.jsx(
        "rect",
        {
          x: i * 7,
          y: -6 - i * 5,
          width: "5",
          height: 6 + i * 5,
          rx: "1",
          fill: i < r ? (r >= 4 ? n.mintDeep : n.amber) : "#fff",
          stroke: h,
          strokeWidth: 1,
        },
        i,
      ),
    ),
  });
}
function $e({
  x: t,
  org: s,
  state: r,
  person: i,
  skin: a,
  mood: o,
  holding: l,
  s: d = 0.9,
  children: x,
}) {
  return e.jsxs("g", {
    children: [
      e.jsx($, {
        x: t + 30,
        y: W,
        s: d,
        outfit: i,
        skin: a,
        mood: o,
        holding: l,
      }),
      e.jsx(Kt, { x: t, w: 130 }),
      r ? e.jsx(Yt, { x: t - 28, state: r, org: s, s: 0.85 }) : null,
      x,
    ],
  });
}
function Ae({ good: t, x: s, y: r }) {
  return t
    ? e.jsx(N, { x: s, y: r, s: 1.2 })
    : e.jsx(Z, { x: s, y: r, s: 1.2 });
}
function se(t) {
  return t.theme.people[0];
}
function ye(t) {
  return t.theme.people[1];
}
function gt({ org: t, cutOff: s }) {
  return e.jsxs("g", {
    children: [
      e.jsx(oe, { org: t }),
      [130, 300].map((r, i) =>
        e.jsx(
          $e,
          {
            x: r,
            org: t,
            state: s ? "off" : "ok",
            person: i ? ye(t) : se(t),
            skin: i ? y.light : y.mid,
            mood: s ? "thinking" : "happy",
            holding: s ? e.jsx(ot, {}) : void 0,
            children: s
              ? e.jsx(ze, { x: r - 88, n: 10 - i * 3, base: W })
              : null,
          },
          r,
        ),
      ),
      s ? e.jsx(Ne, { x: 200, y: 80 }) : null,
      e.jsx(Ae, { good: !s, x: 420, y: 200 }),
    ],
  });
}
function Or({ org: t, wide: s }) {
  return e.jsxs("g", {
    children: [
      e.jsx(oe, { org: t }),
      e.jsxs("g", {
        "data-wall-screen": "",
        children: [
          e.jsx("rect", {
            x: "28",
            y: "34",
            width: "270",
            height: "150",
            rx: "10",
            fill: n.navy,
            ...c,
          }),
          e.jsx("rect", {
            x: "38",
            y: "44",
            width: "250",
            height: "118",
            rx: "6",
            fill: s ? n.mintWash : "#fff",
          }),
          s
            ? e.jsxs("g", {
                children: [
                  [0, 1, 2].map((r) =>
                    [0, 1, 2, 3].map((i) =>
                      e.jsx(
                        "rect",
                        {
                          x: 52 + i * 58,
                          y: 54 + r * 34,
                          width: "48",
                          height: "26",
                          rx: "4",
                          fill: i % 2 ? n.blue : t.theme.secondary,
                          stroke: h,
                          strokeWidth: 1,
                        },
                        `${r}${i}`,
                      ),
                    ),
                  ),
                  e.jsx("g", {
                    transform: "translate(250 150)",
                    children: e.jsx(Y, { kind: t.theme.packet }),
                  }),
                ],
              })
            : e.jsx(Xt, { x: 163, y: 98, r: 22 }),
          e.jsx("rect", {
            x: "48",
            y: "168",
            width: "230",
            height: "10",
            rx: "5",
            fill: "#fff",
            stroke: h,
            strokeWidth: 1.2,
          }),
          e.jsx("rect", {
            x: "50",
            y: "170",
            width: s ? 226 : 66,
            height: "6",
            rx: "3",
            fill: s ? n.mint : n.amber,
          }),
        ],
      }),
      [80, 200, 320, 440].map((r, i) =>
        e.jsx(
          "g",
          {
            children: e.jsx($, {
              x: r,
              y: W + 40,
              s: 0.8,
              outfit: i % 2 ? ye(t) : se(t),
              skin: [y.light, y.dark, y.mid, y.light][i],
              mood: s ? "happy" : "thinking",
            }),
          },
          r,
        ),
      ),
      s ? null : e.jsx(Ne, { x: 318, y: 190, s: 0.9 }),
      e.jsx(Ae, { good: s, x: 460, y: 190 }),
    ],
  });
}
function Rr({ org: t, server: s }) {
  return s
    ? e.jsxs("g", {
        children: [
          e.jsx(oe, { org: t }),
          e.jsx("rect", {
            x: "24",
            y: "110",
            width: "110",
            height: W - 110,
            rx: "4",
            fill: "#e9dcc6",
            ...c,
          }),
          e.jsx(S, { x: 79, y: 250, s: 1.3, colour: n.lilac }),
          e.jsx("g", {
            transform: "translate(64 150)",
            children: e.jsx(A, { x: 0, y: 0, s: 1.1 }),
          }),
          e.jsx("g", {
            transform: "translate(96 150)",
            children: e.jsx(A, { x: 0, y: 0, s: 1.1 }),
          }),
          e.jsx("path", {
            d: "M74 150 H86",
            stroke: n.mintDeep,
            strokeWidth: "2.5",
            strokeLinecap: "round",
          }),
          e.jsx($, {
            x: 250,
            y: W,
            s: 1,
            outfit: se(t),
            skin: y.mid,
            mood: "happy",
            holding: e.jsx("g", {
              transform: "translate(6 -4)",
              children: e.jsx(Y, { kind: t.theme.packet }),
            }),
          }),
          e.jsx(N, { x: 290, y: 150, s: 1.2 }),
        ],
      })
    : vt(t.id)
      ? e.jsx(_r, { org: t })
      : e.jsxs("g", {
          children: [
            e.jsx(oe, { org: t }),
            e.jsx($, {
              x: 300,
              y: W,
              s: 1,
              outfit: se(t),
              skin: y.mid,
              mood: "thinking",
            }),
            e.jsx(Kt, { x: 150, w: 170 }),
            e.jsx(Yt, { x: 150, state: "cracked", org: t, s: 1.15 }),
            e.jsxs("g", {
              transform: "translate(150 140)",
              "data-lost-file": "",
              children: [
                e.jsx("path", {
                  d: "M-26 -16 H-6 L0 -10 H26 V18 H-26Z",
                  fill: "#fff",
                  stroke: n.greyDeep,
                  strokeWidth: "2",
                  strokeDasharray: "5 4",
                }),
                e.jsx(v, {
                  x: 0,
                  y: 9,
                  size: 16,
                  weight: 700,
                  anchor: "middle",
                  fill: n.greyDeep,
                  children: "?",
                }),
              ],
            }),
            e.jsx(Ne, { x: 420, y: 210 }),
            e.jsx(Z, { x: 60, y: 70, s: 1.2 }),
          ],
        });
}
function bt({ org: t, x: s, y: r, label: i, old: a }) {
  return e.jsxs("g", {
    transform: `translate(${s} ${r})`,
    "data-file-version": i,
    children: [
      e.jsx("path", {
        d: "M-22 -30 H12 L22 -20 V30 H-22Z",
        fill: a ? n.amberWash : "#fff",
        ...c,
      }),
      e.jsx("path", { d: "M12 -30 V-20 H22", fill: "none", ...c }),
      e.jsx("g", {
        transform: "translate(0 6)",
        children: e.jsx(Y, { kind: t.theme.packet }),
      }),
      e.jsx(v, {
        x: 0,
        y: 24,
        size: 12,
        weight: 700,
        anchor: "middle",
        fill: a ? n.amber : n.mintDeep,
        children: i,
      }),
    ],
  });
}
function _r({ org: t }) {
  return e.jsxs("g", {
    children: [
      e.jsx(oe, { org: t }),
      e.jsx($e, {
        x: 110,
        org: t,
        person: ye(t),
        skin: y.light,
        mood: "thinking",
        children: e.jsx(bt, { org: t, x: 92, y: U - 34, label: "v3", old: !1 }),
      }),
      e.jsx($e, {
        x: 300,
        org: t,
        person: se(t),
        skin: y.dark,
        mood: "thinking",
        children: e.jsx(bt, {
          org: t,
          x: 282,
          y: U - 34,
          label: "v1",
          old: !0,
        }),
      }),
      e.jsx("path", {
        d: "M306 196 Q370 176 428 228",
        fill: "none",
        stroke: n.amber,
        strokeWidth: "3",
        strokeDasharray: "6 6",
      }),
      e.jsx("path", {
        d: "M416 224 l13 5 -2 -13",
        fill: "none",
        stroke: n.amber,
        strokeWidth: "3",
        strokeLinecap: "round",
        strokeLinejoin: "round",
      }),
      e.jsxs("g", {
        transform: "translate(462 246)",
        children: [
          e.jsx("rect", {
            x: "-26",
            y: "-16",
            width: "52",
            height: "34",
            rx: "4",
            fill: "#fff",
            ...c,
          }),
          e.jsx("path", { d: "M-26 -16 L0 4 L26 -16", fill: "none", ...c }),
        ],
      }),
      e.jsx(Z, { x: 60, y: 70, s: 1.2 }),
    ],
  });
}
function Br({ org: t, cloud: s }) {
  return e.jsxs("g", {
    children: [
      e.jsx(oe, { org: t }),
      s
        ? null
        : e.jsxs("g", {
            children: [
              e.jsx("rect", {
                x: "20",
                y: "130",
                width: "70",
                height: W - 130,
                rx: "4",
                fill: "#e9dcc6",
                ...c,
              }),
              e.jsx(S, { x: 55, y: 270, s: 1, colour: n.blue }),
            ],
          }),
      [170, 320].map((r, i) =>
        e.jsx(
          $e,
          {
            x: r,
            org: t,
            state: s ? "cloud-down" : "ok",
            person: i ? ye(t) : se(t),
            skin: i ? y.light : y.dark,
            mood: s ? "thinking" : "happy",
            holding: s && i === 0 ? e.jsx(ot, {}) : void 0,
          },
          r,
        ),
      ),
      s ? e.jsx(Ne, { x: 230, y: 80 }) : null,
      e.jsx(Ae, { good: !s, x: 430, y: 200 }),
    ],
  });
}
function Zr({ org: t, cloud: s }) {
  return e.jsxs("g", {
    children: [
      e.jsx(Gt, {}),
      e.jsx(D, { x: 60, y: W, s: 1.1 }),
      e.jsx(ve, {
        kind: t.theme.vehicle,
        theme: t.theme,
        x: 330,
        y: W - 15,
        s: 1.6,
      }),
      e.jsx($, {
        x: 190,
        y: W + 30,
        s: 1.05,
        outfit: se(t),
        skin: y.dark,
        mood: s ? "happy" : "thinking",
        holding: s
          ? e.jsx(z, { x: 0, y: -6, s: 0.8, screen: n.mintWash })
          : e.jsx(ot, {}),
      }),
      s
        ? e.jsxs("g", {
            children: [
              e.jsx("g", {
                transform: "translate(206 170)",
                children: e.jsx(Y, { kind: t.theme.packet }),
              }),
              e.jsx(N, { x: 240, y: 140, s: 1.2 }),
            ],
          })
        : e.jsxs("g", {
            children: [
              e.jsx(Ne, { x: 250, y: 150 }),
              e.jsx(Z, { x: 290, y: 120, s: 1.1 }),
            ],
          }),
    ],
  });
}
function wt({ org: t, wired: s, move: r = !1 }) {
  const i = [80, 250, 420];
  return e.jsxs("g", {
    children: [
      e.jsx(oe, { org: t }),
      r
        ? null
        : [168, 338].map((a) =>
            e.jsx(
              "rect",
              {
                x: a - 10,
                y: "150",
                width: "20",
                height: W - 150,
                fill: "#c9b8a4",
                ...c,
              },
              a,
            ),
          ),
      i.map((a, o) => {
        const l = r ? !s || o === 0 : s || o === 0;
        return e.jsx(
          $e,
          {
            x: a,
            org: t,
            state: s ? (l ? "ok" : "off") : void 0,
            person: o === 1 ? ye(t) : se(t),
            skin: [y.light, y.mid, y.dark][o],
            mood: l ? "happy" : "thinking",
            holding: l ? void 0 : e.jsx(Jt, {}),
            s: 0.8,
            children: s
              ? l
                ? e.jsx("path", {
                    d: `M${a - 28} ${U} V${W - 8} H${a + 64}`,
                    fill: "none",
                    stroke: n.cable,
                    strokeWidth: "3",
                  })
                : e.jsx(ze, { x: a - 50, n: 4 })
              : e.jsxs("g", {
                  children: [
                    e.jsx(z, {
                      x: a - 34,
                      y: U - 16,
                      s: 0.9,
                      rotate: -8,
                      screen: l ? n.mintWash : n.grey,
                    }),
                    e.jsx(Vr, { x: a - 14, y: U - 6, value: l ? 4 : 1 }),
                    l ? null : e.jsx(ze, { x: a - 50, n: 4 }),
                  ],
                }),
          },
          a,
        );
      }),
      e.jsx(Ae, { good: r ? !s : s, x: 60, y: 70 }),
    ],
  });
}
function Fr({ org: t, encrypted: s }) {
  const r = Ue[t.id],
    i = s ? Ge(r) : r,
    a = Math.max(260, r.length * 9.6 + 70),
    o = 260 - a / 2;
  return e.jsxs("g", {
    children: [
      e.jsx(Gt, { evening: !0 }),
      e.jsxs("g", {
        transform: "translate(130 300)",
        children: [
          e.jsx("rect", {
            x: "-110",
            y: "-56",
            width: "220",
            height: "56",
            rx: "16",
            fill: n.grey,
            ...c,
          }),
          e.jsx("path", {
            d: "M-80 -56 L-56 -100 H60 L84 -56",
            fill: "#dff3ff",
            ...c,
          }),
          e.jsx("circle", { cx: "-62", cy: "0", r: "16", fill: h }),
          e.jsx("circle", { cx: "62", cy: "0", r: "16", fill: h }),
        ],
      }),
      e.jsxs("g", {
        "data-laptop": "",
        children: [
          e.jsx("rect", {
            x: o,
            y: "160",
            width: a,
            height: "96",
            rx: "10",
            fill: n.navy,
            ...c,
          }),
          e.jsx("rect", {
            x: o + 8,
            y: "168",
            width: a - 16,
            height: "80",
            rx: "6",
            fill: s ? n.mintWash : n.amberWash,
          }),
          e.jsx(v, {
            x: 260,
            y: 214,
            size: 15,
            weight: 700,
            anchor: "middle",
            fill: s ? n.mintDeep : h,
            children: i,
          }),
          e.jsx("path", {
            d: `M${o - 14} 256 H${o + a + 14} L${o + a} 270 H${o}Z`,
            fill: n.grey,
            ...c,
          }),
          e.jsx(me, { x: o + a - 4, y: 166, s: 1.1, open: !s }),
        ],
      }),
      s
        ? null
        : e.jsx($, {
            x: 430,
            y: W + 40,
            s: 0.8,
            outfit: ye(t),
            skin: y.mid,
            mood: "thinking",
            holding: e.jsx(Jt, {}),
          }),
      e.jsx(Ae, { good: s, x: o, y: 150 }),
    ],
  });
}
function zr({ org: t, kind: s, side: r }) {
  switch (s) {
    case "cut":
      return e.jsx(gt, { org: t, cutOff: r === "a" });
    case "peak":
      return e.jsx(Or, { org: t, wide: r === "b" });
    case "files":
      return e.jsx(Rr, { org: t, server: r === "a" });
    case "server":
      return e.jsx(gt, { org: t, cutOff: r === "a" });
    case "offline":
      return e.jsx(Br, { org: t, cloud: r === "b" });
    case "remote":
      return e.jsx(Zr, { org: t, cloud: r === "b" });
    case "walls":
      return e.jsx(wt, { org: t, wired: r === "a" });
    case "move":
      return e.jsx(wt, { org: t, wired: r === "a", move: !0 });
    case "snoop":
      return e.jsx(Fr, { org: t, encrypted: r === "a" });
  }
}
function qr({ org: t, kind: s, side: r, viewBox: i, network: a }) {
  return e.jsxs("g", {
    "data-consequence": `${s}-${r}`,
    children: [
      e.jsx(zr, { org: t, kind: s, side: r }),
      e.jsx(Ir, { viewBox: i, children: a }),
    ],
  });
}
function lt({
  org: t,
  w: s,
  mesh: r,
  cut: i = !1,
  reroute: a = !1,
  dark: o = [],
  digger: l,
}) {
  const d = Lt(s),
    x = [d.elmbridge, d.castle, d.riverside, d.millbrook],
    f = r
      ? [
          [2, 0],
          [0, 1],
          [1, 3],
          [3, 2],
        ]
      : [],
    p = O(d.hq, d.riverside, 0.6),
    k = (j) => (i && j === 2 ? "cut" : a && j === 0 ? "glow" : "live");
  return e.jsxs("g", {
    children: [
      e.jsx("rect", {
        x: "0",
        y: "50",
        width: s,
        height: "390",
        fill: n.grass,
      }),
      e.jsx(Pe, { n: Math.round(s / 14), w: s, h: 390, y0: 50 }),
      e.jsx("path", {
        d: `M0 300 Q${s * 0.25} 270 ${s * 0.5} 300 T${s} 290`,
        fill: "none",
        stroke: n.road,
        strokeWidth: "20",
      }),
      e.jsx(D, { x: s * 0.3, y: 200, s: 0.8 }),
      e.jsx(D, { x: s * 0.62, y: 230, s: 0.8 }),
      e.jsx(D, { x: s * 0.9, y: 240, s: 0.75 }),
      e.jsx(D, { x: s * 0.42, y: 420, s: 0.8 }),
      f.map(([j, u]) =>
        e.jsx(
          be,
          {
            from: x[j],
            to: x[u],
            state: a && j === 2 && u === 0 ? "glow" : "live",
          },
          `${j}-${u}`,
        ),
      ),
      x.map((j, u) => e.jsx(be, { from: d.hq, to: j, state: k(u) }, j.join())),
      x
        .filter((j, u) => !(i && u === 2))
        .map((j) =>
          e.jsx(
            "g",
            {
              className: "nb-flow-dots",
              children: e.jsx(G, {
                from: O(d.hq, j, 0.2),
                to: O(d.hq, j, 0.8),
                n: 3,
              }),
            },
            j.join(),
          ),
        ),
      f
        .filter(([j, u]) => !(a && j === 2 && u === 0))
        .map(([j, u]) =>
          e.jsx(
            "g",
            {
              className: "nb-flow-dots",
              children: e.jsx(G, {
                from: O(x[j], x[u], 0.25),
                to: O(x[j], x[u], 0.75),
                n: 2,
                fill: n.cable,
              }),
            },
            `f${j}-${u}`,
          ),
        ),
      a
        ? e.jsxs("g", {
            className: "nb-flow-dots",
            children: [
              e.jsx(G, {
                from: O(x[2], x[0], 0.2),
                to: O(x[2], x[0], 0.8),
                n: 4,
                fill: n.mintDeep,
                r: 4,
              }),
              e.jsx(G, {
                from: O(x[0], d.hq, 0.2),
                to: O(x[0], d.hq, 0.8),
                n: 4,
                fill: n.mintDeep,
                r: 4,
              }),
            ],
          })
        : null,
      l
        ? e.jsx("g", {
            transform: `translate(${l === "arriving" ? p[0] + 120 : p[0] + 52} ${p[1] + (l === "arriving" ? 30 : 10)}) scale(-0.75 0.75)`,
            children: e.jsx(Ur, {}),
          })
        : null,
      i
        ? e.jsx("ellipse", {
            cx: p[0],
            cy: p[1] + 2,
            rx: "14",
            ry: "7",
            fill: "#c9a77c",
            stroke: h,
            strokeWidth: "1.6",
          })
        : null,
      e.jsx(H, {
        kind: t.theme.hub,
        theme: t.theme,
        x: d.hq[0] - 60,
        y: d.hq[1] - 40,
        w: 120,
        h: 74,
      }),
      e.jsx(w, { x: d.hq[0], y: d.hq[1] + 54, text: t.hub, size: 12 }),
      x.map((j, u) => {
        const m = !o.includes(u);
        return e.jsxs(
          "g",
          {
            children: [
              m
                ? null
                : e.jsx("circle", {
                    cx: j[0],
                    cy: j[1] + 4,
                    r: "62",
                    fill: "#fff",
                    fillOpacity: 0.35,
                    stroke: n.greyDeep,
                    strokeWidth: "2",
                    strokeDasharray: "6 7",
                  }),
              e.jsx(H, {
                kind: t.theme.sites[u],
                theme: t.theme,
                x: j[0] - 38,
                y: j[1] - 26,
                w: 76,
                h: 46,
                lit: m,
              }),
              e.jsx(w, {
                x: j[0],
                y: j[1] + 38,
                text: t.sites[u],
                size: 11.5,
                muted: !m,
              }),
            ],
          },
          j.join(),
        );
      }),
    ],
  });
}
function Ur() {
  return e.jsxs("g", {
    children: [
      e.jsx("rect", {
        x: "-30",
        y: "-18",
        width: "46",
        height: "22",
        rx: "4",
        fill: n.yellow,
        ...c,
      }),
      e.jsx("rect", {
        x: "-22",
        y: "-36",
        width: "24",
        height: "20",
        rx: "3",
        fill: n.yellow,
        ...c,
      }),
      e.jsx("rect", {
        x: "-18",
        y: "-32",
        width: "14",
        height: "10",
        rx: "2",
        fill: "#dff3ff",
      }),
      e.jsx("path", {
        d: "M16 -12 L40 -34 L58 -14",
        fill: "none",
        stroke: h,
        strokeWidth: "7",
        strokeLinecap: "round",
        strokeLinejoin: "round",
      }),
      e.jsx("path", {
        d: "M16 -12 L40 -34 L58 -14",
        fill: "none",
        stroke: n.yellow,
        strokeWidth: "4",
        strokeLinecap: "round",
        strokeLinejoin: "round",
      }),
      e.jsx("path", { d: "M52 -16 h14 l-4 12 h-12Z", fill: n.yellow, ...c }),
      e.jsx("rect", {
        x: "-34",
        y: "4",
        width: "54",
        height: "12",
        rx: "6",
        fill: n.navy,
        ...c,
      }),
    ],
  });
}
function Fi({ org: t, build: s, narrow: r = !1 }) {
  const i = r ? 520 : 800,
    a = i / 800;
  return e.jsxs("svg", {
    viewBox: `0 50 ${i} 390`,
    role: "img",
    "aria-label": `${t.name} through the week, with traffic on every link between ${t.theme.places}`,
    className: "nb-art",
    "data-org-scene": t.id,
    children: [
      e.jsx(lt, { org: t, w: i, mesh: s.topology === "b", digger: "arriving" }),
      e.jsx(Nt, { x: i - 60, y: 92, r: 18 }),
      e.jsx(re, { x: 560 * a, y: 78, s: 0.8 }),
      e.jsx($, {
        x: 590 * a,
        y: 256,
        s: 0.5,
        outfit: t.theme.people[0],
        skin: y.dark,
        holding: e.jsx(z, { x: 0, y: 0, s: 0.55 }),
      }),
      e.jsx($, {
        x: 560 * a,
        y: 420,
        s: 0.5,
        outfit: t.theme.people[2],
        skin: y.light,
        hair: E.fair,
        long: !0,
      }),
      e.jsx($, {
        x: 46,
        y: 250,
        s: 0.48,
        outfit: t.theme.people[1],
        skin: y.mid,
      }),
      e.jsx(ve, {
        kind: t.theme.vehicle,
        theme: t.theme,
        x: 470 * a,
        y: 300,
        s: 0.9,
      }),
    ],
  });
}
function zi({ org: t, incident: s, build: r, revealed: i }) {
  const a = r[Le[s.kind].decision],
    o = `${s.title}. ${i ? s.result[a].headline : s.setup}`,
    l = e.jsx(Kr, { org: t, incident: s, side: a, revealed: i });
  return e.jsx("svg", {
    viewBox: i ? "0 0 520 390" : $t(s.kind),
    role: "img",
    "aria-label": o,
    className: "nb-art",
    "data-incident-scene": s.kind,
    "data-org-scene": t.id,
    children: i
      ? e.jsx(qr, {
          org: t,
          kind: s.kind,
          side: a,
          viewBox: $t(s.kind),
          network: l,
        })
      : l,
  });
}
function $t(t) {
  return t === "cut" ? "0 50 520 390" : "0 0 520 390";
}
function Gr(t) {
  const s = Number(t.split(":")[0]);
  return s >= 20 || s < 6;
}
function Kr({ org: t, incident: s, side: r, revealed: i }) {
  switch (s.kind) {
    case "cut":
      return e.jsx(lt, {
        org: t,
        w: 520,
        mesh: r === "b",
        cut: !0,
        digger: "cutting",
        reroute: i && r === "b",
        dark: i && r === "a" ? [2] : [],
      });
    case "peak":
      return e.jsx(Yr, {
        evening: Gr(s.time),
        wide: r === "b",
        revealed: i,
        hub: t.hub,
      });
    case "files":
      return e.jsx(Xr, { org: t, server: r === "a", revealed: i });
    case "server":
      return e.jsx(Jr, { org: t, server: r === "a", revealed: i });
    case "offline":
    case "remote":
      return e.jsx(ei, { org: t, cloud: r === "b", revealed: i, mode: s.kind });
    case "walls":
    case "move":
      return e.jsx(ti, {
        wired: r === "a",
        revealed: i,
        label: t.area.title,
        move: s.kind === "move",
      });
    case "snoop":
      return e.jsx(si, { org: t, encrypted: r === "a", revealed: i });
  }
}
function Yr({ evening: t, wide: s, revealed: r, hub: i }) {
  const o = [-150, -107, -64, -21, 22, 65, 108, 151].map((f) => 260 + f),
    l = s,
    d = s ? 24 : 8,
    x = s ? 4.5 : 1.8;
  return e.jsxs("g", {
    children: [
      e.jsx("rect", {
        width: "520",
        height: "390",
        fill: t ? "#f4efff" : n.sky,
      }),
      e.jsx("path", {
        d: "M0 330 H520 V390 H0Z",
        fill: t ? "#e6defc" : n.grass,
      }),
      t
        ? [
            [60, 50],
            [460, 60],
          ].map(([f, p]) =>
            e.jsx(
              "g",
              {
                transform: `translate(${f} ${p})`,
                children: Array.from({ length: 8 }, (k, j) =>
                  e.jsx(
                    "path",
                    {
                      d: "M0 -6 V-14",
                      stroke: j % 2 ? n.pink : n.yellow,
                      strokeWidth: "3",
                      strokeLinecap: "round",
                      transform: `rotate(${j * 45})`,
                    },
                    j,
                  ),
                ),
              },
              f,
            ),
          )
        : e.jsx(Nt, { x: 460, y: 54, r: 16 }),
      e.jsx(re, { x: 260, y: 58, s: 1.2 }),
      e.jsx("path", {
        d: "M260 76 V100",
        stroke: n.cable,
        strokeWidth: d,
        strokeLinecap: "round",
      }),
      e.jsx("path", {
        d: "M260 136 V200",
        stroke: n.cable,
        strokeWidth: d,
        strokeLinecap: "round",
      }),
      e.jsx("path", {
        d: "M260 136 V200",
        stroke: "#fff",
        strokeWidth: s ? 8 : 3,
        strokeLinecap: "round",
        ...Xe(14),
      }),
      e.jsx(Te, { x: 260, y: 118, s: 0.9 }),
      e.jsx(w, { x: 330, y: 124, text: i, size: 11 }),
      o.map((f) =>
        e.jsx(
          "path",
          {
            d: `M260 200 Q260 236 ${f} 262`,
            fill: "none",
            stroke: n.cable,
            strokeWidth: x,
            strokeLinecap: "round",
          },
          f,
        ),
      ),
      o.map((f, p) =>
        e.jsxs(
          "g",
          {
            children: [
              p % 3 === 0
                ? e.jsx(Q, { x: f, y: 300, s: 0.62 })
                : e.jsx(z, { x: f, y: 286, s: 0.78 }),
              r
                ? l
                  ? e.jsx(N, { x: f, y: 330, s: 0.62 })
                  : e.jsx(Z, { x: f, y: 330, s: 0.62 })
                : null,
            ],
          },
          `d${f}`,
        ),
      ),
      r
        ? e.jsxs("g", {
            children: [
              e.jsx("rect", {
                x: "140",
                y: "346",
                width: "240",
                height: "30",
                rx: "12",
                fill: l ? n.mintWash : n.amberWash,
                ...c,
                strokeWidth: 1.6,
              }),
              e.jsx(ps, {
                x: 152,
                y: 354,
                w: 216,
                h: 14,
                value: l ? 1 : 0.3,
                fill: l ? n.mint : n.amber,
              }),
            ],
          })
        : null,
    ],
  });
}
function Xr({ org: t, server: s, revealed: r }) {
  return e.jsxs("g", {
    children: [
      e.jsx("rect", { width: "520", height: "390", fill: n.paper }),
      e.jsx("rect", { y: "300", width: "520", height: "90", fill: "#f6e1c8" }),
      s
        ? e.jsxs("g", {
            children: [
              e.jsx(H, {
                kind: t.theme.hub,
                theme: t.theme,
                x: 40,
                y: 150,
                w: 150,
                h: 120,
              }),
              e.jsx(w, { x: 115, y: 292, text: t.hub, size: 12 }),
              e.jsx(S, { x: 300, y: 220, s: 1.4, colour: n.lilac }),
              e.jsx(A, { x: 300, y: 150, s: 1.4 }),
              e.jsx("path", {
                d: "M190 220 H272",
                stroke: n.cable,
                strokeWidth: "5",
                strokeLinecap: "round",
              }),
              r
                ? e.jsxs("g", {
                    children: [
                      e.jsx("circle", {
                        cx: "300",
                        cy: "200",
                        r: "76",
                        fill: n.mint,
                        opacity: 0.18,
                      }),
                      e.jsx(N, { x: 346, y: 142, s: 1.3 }),
                      e.jsx($, {
                        x: 430,
                        y: 330,
                        s: 0.8,
                        outfit: t.theme.people[1],
                        skin: y.mid,
                      }),
                    ],
                  })
                : e.jsx($, {
                    x: 430,
                    y: 330,
                    s: 0.8,
                    outfit: t.theme.people[1],
                    skin: y.mid,
                    mood: "thinking",
                  }),
            ],
          })
        : e.jsxs("g", {
            children: [
              e.jsx("rect", {
                x: "40",
                y: "250",
                width: "150",
                height: "10",
                rx: "2",
                fill: "#d9a07a",
                ...c,
              }),
              e.jsx("path", {
                d: "M50 260 V300 M180 260 V300",
                stroke: h,
                strokeWidth: "3",
              }),
              e.jsx(Q, { x: 100, y: 228, colour: n.mint }),
              e.jsx(A, { x: 100, y: 170, s: 1.2 }),
              e.jsx("rect", {
                x: "300",
                y: "250",
                width: "150",
                height: "10",
                rx: "2",
                fill: "#d9a07a",
                ...c,
              }),
              e.jsx("path", {
                d: "M310 260 V300 M440 260 V300",
                stroke: h,
                strokeWidth: "3",
              }),
              r && !vt(t.id)
                ? e.jsxs("g", {
                    children: [
                      e.jsx(Q, {
                        x: 360,
                        y: 228,
                        colour: n.grey,
                        screen: n.greyDeep,
                      }),
                      e.jsx("path", {
                        d: "M347 205 l9 8 -5 6 10 7",
                        fill: "none",
                        stroke: "#fff",
                        strokeWidth: "2",
                        strokeLinecap: "round",
                        strokeLinejoin: "round",
                      }),
                      e.jsxs("g", {
                        transform: "translate(375 150)",
                        children: [
                          e.jsx("path", {
                            d: "M-26 -16 H-6 L0 -10 H26 V18 H-26Z",
                            fill: "#fff",
                            stroke: n.greyDeep,
                            strokeWidth: "2",
                            strokeDasharray: "5 4",
                          }),
                          e.jsx(v, {
                            x: 0,
                            y: 9,
                            size: 16,
                            weight: 700,
                            anchor: "middle",
                            fill: n.greyDeep,
                            children: "?",
                          }),
                        ],
                      }),
                      e.jsx(Z, { x: 430, y: 120, s: 1.2 }),
                    ],
                  })
                : e.jsxs("g", {
                    children: [
                      e.jsx(Q, { x: 360, y: 228, colour: n.peach }),
                      e.jsx(A, { x: 360, y: 170, s: 1.2 }),
                      r ? e.jsx(Z, { x: 430, y: 120, s: 1.2 }) : null,
                    ],
                  }),
            ],
          }),
    ],
  });
}
function Jr({ org: t, server: s, revealed: r }) {
  const i = [120, 260, 400];
  return e.jsxs("g", {
    children: [
      e.jsx("rect", { width: "520", height: "390", fill: n.paper }),
      e.jsx("rect", { y: "300", width: "520", height: "90", fill: "#f6e1c8" }),
      s
        ? e.jsxs("g", {
            children: [
              e.jsx(S, {
                x: 260,
                y: 120,
                s: 1.3,
                colour: r ? n.grey : n.lilac,
              }),
              i.map((a) =>
                e.jsx(
                  "path",
                  {
                    d: `M260 150 Q${(260 + a) / 2} 190 ${a} 216`,
                    fill: "none",
                    stroke: n.cable,
                    strokeWidth: "3",
                    strokeDasharray: r ? "4 8" : void 0,
                  },
                  a,
                ),
              ),
              r ? e.jsx(Z, { x: 320, y: 80, s: 1.2 }) : null,
            ],
          })
        : null,
      i.map((a, o) =>
        e.jsxs(
          "g",
          {
            children: [
              e.jsx("rect", {
                x: a - 50,
                y: "260",
                width: "100",
                height: "10",
                rx: "2",
                fill: "#d9a07a",
                ...c,
              }),
              e.jsx("path", {
                d: `M${a - 42} 270 v30 M${a + 42} 270 v30`,
                stroke: h,
                strokeWidth: "3",
              }),
              e.jsx(Q, {
                x: a,
                y: 238,
                colour: [n.mint, n.peach, n.blue][o],
                screen: s && r ? n.grey : void 0,
              }),
              s ? null : e.jsx(A, { x: a, y: 180, s: 1 }),
              r && !s ? e.jsx(N, { x: a + 34, y: 200 }) : null,
            ],
          },
          a,
        ),
      ),
      e.jsx($, {
        x: 460,
        y: 350,
        s: 0.7,
        outfit: t.theme.people[1],
        skin: y.mid,
        mood: r && s ? "thinking" : "happy",
      }),
    ],
  });
}
function ei({ org: t, cloud: s, revealed: r, mode: i }) {
  const a = [130, 230],
    o = [400, 110],
    l = i === "offline",
    d = r && (i === "offline" ? !s : s),
    x = r && !d;
  return e.jsxs("g", {
    children: [
      e.jsx("rect", { width: "520", height: "390", fill: n.sky }),
      e.jsx("path", { d: "M0 300 H520 V390 H0Z", fill: n.grass }),
      e.jsx(H, {
        kind: t.theme.hub,
        theme: t.theme,
        x: a[0] - 70,
        y: a[1] - 50,
        w: 140,
        h: 100,
      }),
      e.jsx(w, { x: a[0], y: a[1] + 72, text: t.hub, size: 12 }),
      s ? null : e.jsx(S, { x: a[0] + 104, y: a[1] + 30, s: 0.9 }),
      e.jsx(re, { x: o[0], y: o[1], s: 2.2 }),
      e.jsx(v, {
        x: o[0],
        y: o[1] + 6,
        size: 13,
        weight: 700,
        anchor: "middle",
        children: "Internet",
      }),
      s ? e.jsx(Ye, { x: o[0] + 10, y: o[1] + 90, s: 1.4 }) : null,
      l
        ? e.jsxs("g", {
            children: [
              e.jsx("path", {
                d: `M${a[0] + 70} ${a[1] - 30} L${o[0] - 90} ${o[1] + 10}`,
                stroke: n.greyDeep,
                strokeWidth: "5",
                strokeDasharray: "4 10",
                strokeLinecap: "round",
              }),
              e.jsx("circle", {
                cx: (a[0] + 70 + o[0] - 90) / 2,
                cy: (a[1] - 30 + o[1] + 10) / 2,
                r: "12",
                fill: "#fff",
                stroke: n.greyDeep,
                strokeWidth: "2",
              }),
              e.jsx("path", {
                d: `M${(a[0] + 70 + o[0] - 90) / 2 - 5} ${(a[1] - 30 + o[1] + 10) / 2 - 5} l10 10 m0 -10 l-10 10`,
                stroke: n.greyDeep,
                strokeWidth: "2.4",
                strokeLinecap: "round",
              }),
            ],
          })
        : e.jsxs("g", {
            children: [
              e.jsx("path", {
                d: `M${a[0] + 70} ${a[1] - 30} L${o[0] - 90} ${o[1] + 10}`,
                stroke: n.cable,
                strokeWidth: "5",
                strokeLinecap: "round",
              }),
              e.jsx($, {
                x: 440,
                y: 350,
                s: 0.85,
                outfit: t.theme.people[0],
                skin: y.dark,
                holding: e.jsx(z, { x: 0, y: 0, s: 0.6 }),
                mood: x ? "thinking" : "happy",
              }),
              e.jsx("path", {
                d: s
                  ? `M420 270 Q410 220 ${o[0] + 20} ${o[1] + 120}`
                  : `M410 280 Q300 300 ${a[0] + 104} ${a[1] + 30}`,
                fill: "none",
                stroke: d ? n.mintDeep : n.greyDeep,
                strokeWidth: "3",
                strokeDasharray: "6 6",
              }),
            ],
          }),
      r
        ? d
          ? e.jsx(N, {
              x: s ? o[0] + 60 : a[0] + 130,
              y: s ? o[1] + 70 : a[1] - 10,
              s: 1.3,
            })
          : e.jsx(Z, {
              x: s ? o[0] + 60 : a[0] + 130,
              y: s ? o[1] + 70 : a[1] - 10,
              s: 1.3,
            })
        : null,
      l
        ? e.jsx($, {
            x: 300,
            y: 350,
            s: 0.8,
            outfit: t.theme.people[1],
            skin: y.light,
            mood: x ? "thinking" : "happy",
          })
        : null,
    ],
  });
}
function ti({ wired: t, revealed: s, label: r, move: i = !1 }) {
  const a = [110, 260, 410];
  return e.jsxs("g", {
    children: [
      e.jsx("rect", { width: "520", height: "390", fill: n.paper }),
      e.jsx("rect", { y: "320", width: "520", height: "70", fill: "#e9d6b8" }),
      e.jsx(v, { x: 20, y: 36, size: 15, weight: 700, children: r }),
      i
        ? null
        : [185, 335].map((o) =>
            e.jsx(
              "rect",
              {
                x: o - 9,
                y: "60",
                width: "18",
                height: "260",
                fill: "#c9b8a4",
                ...c,
              },
              o,
            ),
          ),
      t
        ? a
            .slice(0, i ? 1 : a.length)
            .map((o, l) =>
              e.jsx(
                "path",
                {
                  d: `M${o} 300 V${334 + l * 4} H20`,
                  fill: "none",
                  stroke: n.cable,
                  strokeWidth: "3.5",
                },
                o,
              ),
            )
        : e.jsxs("g", {
            children: [
              e.jsx(F, { x: 110, y: 70, s: 1.1 }),
              e.jsx("path", {
                d: "M60 110 Q110 150 160 110 M40 130 Q110 190 180 130",
                fill: "none",
                stroke: n.cable,
                strokeWidth: "3",
                strokeLinecap: "round",
                opacity: 0.7,
              }),
            ],
          }),
      a.map((o, l) => {
        const d = i ? !t || l === 0 : t || l === 0;
        return e.jsxs(
          "g",
          {
            children: [
              e.jsx("rect", {
                x: o - 50,
                y: "280",
                width: "100",
                height: "10",
                rx: "2",
                fill: "#d9a07a",
                ...c,
              }),
              e.jsx("path", {
                d: `M${o - 42} 290 v30 M${o + 42} 290 v30`,
                stroke: h,
                strokeWidth: "3",
              }),
              t
                ? e.jsx(Q, { x: o, y: 258, colour: n.blue })
                : e.jsx(z, { x: o, y: 252, s: 1.1, rotate: -8 }),
              s
                ? d
                  ? e.jsx(N, { x: o + 34, y: 220 })
                  : e.jsx(Z, { x: o + 34, y: 220 })
                : null,
            ],
          },
          o,
        );
      }),
    ],
  });
}
function si({ org: t, encrypted: s, revealed: r }) {
  const i = Ue[t.id],
    a = s ? Ge(i) : i,
    o = Math.max(190, i.length * 7.4 + 28),
    l = 506 - o;
  return e.jsxs("g", {
    children: [
      e.jsx("rect", { width: "520", height: "390", fill: n.sky }),
      e.jsx("path", { d: "M0 310 H520 V390 H0Z", fill: n.road }),
      e.jsx(H, {
        kind: t.theme.sites[1],
        theme: t.theme,
        x: 30,
        y: 110,
        w: 220,
        h: 200,
      }),
      e.jsx(F, { x: 210, y: 150, s: 1, waves: !1 }),
      [40, 80, 120].map((d) =>
        e.jsx(
          "path",
          {
            d: `M${210 + d * 0.6} ${150 - d * 0.8} Q${210 + d} 150 ${210 + d * 0.6} ${150 + d * 0.8}`,
            fill: "none",
            stroke: n.cable,
            strokeWidth: "3",
            opacity: 0.7,
          },
          d,
        ),
      ),
      e.jsxs("g", {
        transform: "translate(400 300)",
        children: [
          e.jsx("rect", {
            x: "-60",
            y: "-30",
            width: "120",
            height: "40",
            rx: "12",
            fill: n.lilac,
            ...c,
          }),
          e.jsx("path", {
            d: "M-40 -30 L-26 -56 H26 L40 -30",
            fill: "#dff3ff",
            ...c,
          }),
          e.jsx("circle", { cx: "-34", cy: "12", r: "10", fill: h }),
          e.jsx("circle", { cx: "34", cy: "12", r: "10", fill: h }),
        ],
      }),
      e.jsxs("g", {
        children: [
          e.jsx("rect", {
            x: l,
            y: "150",
            width: o,
            height: "44",
            rx: "10",
            fill: r ? (s ? n.mintWash : n.amberWash) : "#fff",
            ...c,
          }),
          e.jsx(v, {
            x: l + o / 2,
            y: 177,
            size: 13,
            weight: 700,
            anchor: "middle",
            fill: s ? n.mintDeep : h,
            children: a,
          }),
          e.jsx(me, { x: l + o - 20, y: 140, s: 1, open: !s }),
        ],
      }),
      r
        ? s
          ? e.jsx(N, { x: l, y: 140, s: 1.2 })
          : e.jsx(Z, { x: l, y: 140, s: 1.2 })
        : null,
    ],
  });
}
function es({ x: t, y: s, s: r = 1, packet: i }) {
  return e.jsxs("g", {
    transform: `translate(${t} ${s}) scale(${r})`,
    children: [
      e.jsx("rect", {
        x: "-24",
        y: "-44",
        width: "48",
        height: "88",
        rx: "9",
        fill: n.navy,
        ...c,
      }),
      e.jsx("rect", {
        x: "-19",
        y: "-36",
        width: "38",
        height: "68",
        rx: "4",
        fill: "#e3f8ee",
      }),
      e.jsx("g", {
        transform: "translate(0 16) scale(1.05)",
        children: e.jsx(Y, { kind: i }),
      }),
    ],
  });
}
function ri({ x: t, y: s, s: r = 1, packet: i }) {
  return e.jsxs("g", {
    transform: `translate(${t} ${s}) scale(${r})`,
    children: [
      e.jsx("path", { d: "M-34 -40 H34 L36 14 H-36Z", fill: n.navy, ...c }),
      e.jsx("rect", {
        x: "-29",
        y: "-35",
        width: "58",
        height: "44",
        rx: "3",
        fill: "#e3f8ee",
      }),
      e.jsx("g", {
        transform: "translate(0 6) scale(1.05)",
        children: e.jsx(Y, { kind: i }),
      }),
      e.jsx("path", { d: "M-46 14 H46 L40 24 H-40Z", fill: n.grey, ...c }),
    ],
  });
}
function ii({ x: t, y: s, s: r = 1, packet: i }) {
  return e.jsxs("g", {
    transform: `translate(${t} ${s}) scale(${r})`,
    children: [
      e.jsx("rect", {
        x: "-36",
        y: "-44",
        width: "72",
        height: "54",
        rx: "6",
        fill: n.blue,
        ...c,
      }),
      e.jsx("rect", {
        x: "-30",
        y: "-38",
        width: "60",
        height: "42",
        rx: "3",
        fill: "#e3f8ee",
      }),
      e.jsx("g", {
        transform: "translate(0 4) scale(1.05)",
        children: e.jsx(Y, { kind: i }),
      }),
      e.jsx("path", { d: "M-9 10 v10 h18 v-10", fill: n.greyDeep, ...c }),
      e.jsx("rect", {
        x: "-22",
        y: "20",
        width: "44",
        height: "6",
        rx: "3",
        fill: n.greyDeep,
        ...c,
        strokeWidth: 1.5,
      }),
    ],
  });
}
function ts({ kind: t, packet: s, x: r, y: i, s: a = 1 }) {
  const o =
    t === "phone"
      ? e.jsx(es, { x: r, y: i, s: a, packet: s })
      : t === "laptop"
        ? e.jsx(ri, { x: r, y: i + 8 * a, s: a * 0.82, packet: s })
        : e.jsx(ii, { x: r, y: i + 6 * a, s: a * 0.82, packet: s });
  return e.jsx("g", { "data-sender": t, children: o });
}
function ue({ d: t, dashed: s = !1 }) {
  return e.jsx("path", {
    d: t,
    fill: "none",
    stroke: h,
    strokeWidth: "2.4",
    strokeLinecap: "round",
    strokeDasharray: s ? "5 6" : void 0,
    markerEnd: "url(#nb-arrow)",
  });
}
function ss() {
  return e.jsx("defs", {
    children: e.jsx("marker", {
      id: "nb-arrow",
      viewBox: "0 0 10 10",
      refX: "7",
      refY: "5",
      markerWidth: "7",
      markerHeight: "7",
      orient: "auto-start-reverse",
      children: e.jsx("path", {
        d: "M1 1 L8 5 L1 9",
        fill: "none",
        stroke: h,
        strokeWidth: "2",
        strokeLinecap: "round",
        strokeLinejoin: "round",
      }),
    }),
  });
}
function ce({ label: t, children: s, viewBox: r = "0 0 440 300" }) {
  return e.jsx("svg", {
    viewBox: r,
    role: "img",
    "aria-label": t,
    className: "nb-art",
    children: s,
  });
}
function qi({ org: t, revealed: s }) {
  const r = t.trace.domain;
  return e.jsxs(ce, {
    label: s
      ? `${t.trace.sender} asks one name server, which asks another; the second sends back 203.0.113.24 for ${r}`
      : `${t.trace.sender} needs the IP address for ${r}`,
    children: [
      e.jsx(ss, {}),
      e.jsx("rect", { width: "440", height: "300", fill: n.sky }),
      e.jsx("rect", {
        x: "20",
        y: "16",
        width: "400",
        height: "36",
        rx: "18",
        fill: "#fff",
        ...c,
      }),
      e.jsx(v, { x: 40, y: 40, size: 14, weight: 600, children: r }),
      e.jsx(ts, {
        kind: t.theme.sender,
        packet: t.theme.packet,
        x: 64,
        y: 200,
      }),
      e.jsx(Me, { x: 64, y: 120, s: 0.7, kind: t.theme.packet }),
      e.jsx(ue, { d: "M96 172 Q150 140 194 162" }),
      e.jsx(S, { x: 230, y: 196, colour: n.lilac }),
      e.jsx(w, { x: 230, y: 248, text: "Name server", size: 11 }),
      e.jsx("rect", {
        x: "194",
        y: "104",
        width: "72",
        height: "30",
        rx: "10",
        fill: "#fff",
        ...c,
      }),
      e.jsx(v, {
        x: 230,
        y: 125,
        size: 14,
        weight: 700,
        anchor: "middle",
        children: "?",
      }),
      s
        ? e.jsxs("g", {
            children: [
              e.jsx(ue, { d: "M262 196 Q300 176 336 192" }),
              e.jsx(S, { x: 372, y: 196, colour: n.lilac }),
              e.jsx(w, { x: 372, y: 248, text: "Name server", size: 11 }),
              e.jsx("rect", {
                x: "316",
                y: "104",
                width: "112",
                height: "30",
                rx: "10",
                fill: n.mintWash,
                ...c,
              }),
              e.jsx(v, {
                x: 372,
                y: 125,
                size: 14,
                weight: 700,
                anchor: "middle",
                children: "203.0.113.24",
              }),
              e.jsx(ue, { d: "M372 270 Q240 300 92 254", dashed: !0 }),
            ],
          })
        : null,
    ],
  });
}
function Ui({ org: t, secure: s }) {
  return e.jsxs("svg", {
    viewBox: "0 70 350 110",
    "aria-hidden": "true",
    className: "nb-art",
    children: [
      e.jsx(ts, {
        kind: t.theme.sender,
        packet: t.theme.packet,
        x: 44,
        y: 120,
        s: 0.55,
      }),
      e.jsx(S, { x: 300, y: 122, s: 0.7, colour: n.lilac }),
      e.jsx("path", {
        d: "M70 122 H282",
        stroke: n.cable,
        strokeWidth: "4",
        strokeLinecap: "round",
      }),
      e.jsx("rect", {
        x: "96",
        y: "92",
        width: "150",
        height: "26",
        rx: "8",
        fill: s ? n.mintWash : "#fff",
        ...c,
        strokeWidth: 1.6,
      }),
      e.jsx(v, {
        x: 171,
        y: 110,
        size: 13.5,
        weight: 700,
        anchor: "middle",
        fill: s ? n.mintDeep : h,
        children: s ? "k9#Qe!7vX%2" : "Readable text",
      }),
      e.jsx(me, { x: 171, y: 160, s: 1, open: !s }),
    ],
  });
}
function Gi({ org: t, mesh: s }) {
  const r = Lt(800),
    i = s ? O(r.elmbridge, r.hq, 0.5) : O(r.hq, r.riverside, 0.3);
  return e.jsxs(ce, {
    viewBox: "0 50 800 390",
    label: s
      ? `The line to ${t.sites[2]} is under repair, so your mesh sends the packet via ${t.sites[0]}`
      : `The only line to ${t.sites[2]} is under repair, so the packet waits at ${t.hub}`,
    children: [
      e.jsx(lt, {
        org: t,
        w: 800,
        mesh: s,
        cut: !0,
        reroute: s,
        dark: s ? [] : [2],
      }),
      e.jsx(Me, {
        x: i[0],
        y: i[1] - 18,
        s: 0.9,
        sealed: !0,
        kind: t.theme.packet,
      }),
    ],
  });
}
function ni({ name: t, x: s, y: r, i }) {
  return /\bWAP\b/.test(t)
    ? e.jsx(F, { x: s, y: r - 18, s: 0.9, waves: !1 })
    : /printer/i.test(t)
      ? e.jsx(At, { x: s, y: r - 6 })
      : /scanner/i.test(t)
        ? e.jsx(ai, { x: s, y: r })
        : /server/i.test(t)
          ? e.jsx(S, { x: s, y: r - 14, s: 0.7, colour: n.lilac })
          : e.jsx(Q, {
              x: s,
              y: r,
              colour: [n.peach, n.blue, n.mint][i % 3],
              screen: i === 2 ? "#e3f8ee" : "#fff",
            });
}
function ai({ x: t, y: s }) {
  return e.jsxs("g", {
    transform: `translate(${t} ${s})`,
    children: [
      e.jsx("path", {
        d: "M-24 -16 L22 -24 L24 -20 L-22 -12Z",
        fill: n.white,
        ...c,
        strokeWidth: 1.6,
      }),
      e.jsx("rect", {
        x: "-26",
        y: "-12",
        width: "52",
        height: "20",
        rx: "5",
        fill: n.grey,
        ...c,
      }),
      e.jsx("rect", {
        x: "-18",
        y: "-6",
        width: "26",
        height: "4",
        rx: "2",
        fill: n.blue,
      }),
      e.jsx("circle", { cx: "16", cy: "-2", r: "2.4", fill: n.mintDeep }),
    ],
  });
}
function Ki({ org: t, picked: s }) {
  const r = t.trace.devices,
    i = [220, 110],
    a = [
      [60, 250],
      [170, 250],
      [280, 250],
      [390, 250],
    ];
  return e.jsxs(ce, {
    label: `A switch with four ports: ${r.map((o, l) => `port ${l + 1}, ${o}`).join("; ")}`,
    viewBox: "0 30 440 270",
    children: [
      e.jsx("rect", { y: "30", width: "440", height: "270", fill: n.paper }),
      e.jsx(Te, { x: 60, y: 86, s: 0.7 }),
      e.jsx("path", {
        d: `M86 88 H${i[0] - 70}`,
        stroke: n.cable,
        strokeWidth: "5",
        strokeLinecap: "round",
      }),
      e.jsx(Me, { x: 124, y: 60, s: 0.6, sealed: !0, kind: t.theme.packet }),
      a.map(([o, l], d) => {
        const x = s === d;
        return e.jsxs(
          "g",
          {
            children: [
              x
                ? e.jsx("path", {
                    d: `M${i[0] - 36 + d * 24} ${i[1] + 20} L${o} ${l - 46}`,
                    stroke: n.mint,
                    strokeWidth: 12,
                    strokeLinecap: "round",
                    opacity: 0.7,
                  })
                : null,
              e.jsx("path", {
                d: `M${i[0] - 36 + d * 24} ${i[1] + 20} L${o} ${l - 46}`,
                stroke: x ? n.cable : n.grey,
                strokeWidth: "4",
                strokeLinecap: "round",
              }),
              e.jsx(v, {
                x: i[0] - 36 + d * 24,
                y: i[1] + 42,
                size: 11,
                weight: 700,
                anchor: "middle",
                fill: "#5a6684",
                children: String(d + 1),
              }),
            ],
          },
          o,
        );
      }),
      e.jsx(Qe, { x: i[0], y: i[1], s: 1.9 }),
      a.map(([o, l], d) =>
        e.jsx(
          "g",
          {
            opacity: s === d ? 1 : 0.6,
            children: e.jsx(ni, { name: r[d], x: o, y: l - 6, i: d }),
          },
          `d${o}`,
        ),
      ),
      r.map((o, l) =>
        e.jsx(
          v,
          {
            x: a[l][0],
            y: 286,
            size: 11.5,
            weight: 600,
            anchor: "middle",
            fill: l === s ? h : "#5a6684",
            children: o,
          },
          o,
        ),
      ),
    ],
  });
}
function qe({ device: t }) {
  switch (t) {
    case "radio":
      return e.jsxs("g", {
        children: [
          e.jsx("path", {
            d: "M4 -16 V-26",
            stroke: h,
            strokeWidth: "2.4",
            strokeLinecap: "round",
          }),
          e.jsx("rect", {
            x: "-7",
            y: "-16",
            width: "16",
            height: "26",
            rx: "3",
            fill: n.navy,
            ...c,
            strokeWidth: 1.6,
          }),
          e.jsx("rect", {
            x: "-4",
            y: "-12",
            width: "10",
            height: "7",
            rx: "1.5",
            fill: "#e3f8ee",
          }),
        ],
      });
    case "phone":
      return e.jsxs("g", {
        children: [
          e.jsx("rect", {
            x: "-8",
            y: "-14",
            width: "16",
            height: "28",
            rx: "3",
            fill: n.navy,
            ...c,
            strokeWidth: 1.6,
          }),
          e.jsx("rect", {
            x: "-5.5",
            y: "-10.5",
            width: "11",
            height: "20",
            rx: "1.5",
            fill: "#dff3ff",
          }),
        ],
      });
    case "laptop":
      return e.jsxs("g", {
        children: [
          e.jsx("path", { d: "M-22 -30 H22 L24 -4 H-24Z", fill: n.navy, ...c }),
          e.jsx("rect", {
            x: "-18",
            y: "-26",
            width: "36",
            height: "18",
            rx: "2",
            fill: "#dff3ff",
          }),
          e.jsx("rect", {
            x: "-30",
            y: "-5",
            width: "60",
            height: "6",
            rx: "2",
            fill: n.grey,
            ...c,
            strokeWidth: 1.6,
          }),
        ],
      });
    case "label-printer":
      return e.jsxs("g", {
        children: [
          e.jsx("rect", {
            x: "-11",
            y: "-9",
            width: "22",
            height: "18",
            rx: "4",
            fill: n.white,
            ...c,
            strokeWidth: 1.6,
          }),
          e.jsx("rect", {
            x: "-6",
            y: "7",
            width: "12",
            height: "7",
            rx: "1",
            fill: n.yellow,
            stroke: h,
            strokeWidth: 1.2,
          }),
        ],
      });
  }
}
function oi({ look: t }) {
  return t.accessory === "mouse"
    ? e.jsx("ellipse", {
        cx: "2",
        cy: "2",
        rx: "6",
        ry: "8",
        fill: n.white,
        ...c,
        strokeWidth: 1.5,
      })
    : t.accessory === "scanner"
      ? e.jsxs("g", {
          children: [
            e.jsx("path", {
              d: "M-1 -10 V2",
              stroke: h,
              strokeWidth: "4",
              strokeLinecap: "round",
            }),
            e.jsx("rect", {
              x: "-6",
              y: "-30",
              width: "14",
              height: "20",
              rx: "3",
              fill: n.yellow,
              ...c,
              strokeWidth: 1.5,
            }),
            e.jsx("rect", {
              x: "-3",
              y: "-26",
              width: "8",
              height: "6",
              rx: "1",
              fill: "#dff3ff",
            }),
          ],
        })
      : t.device === "radio" || t.device === "phone"
        ? e.jsx(qe, { device: t.device })
        : null;
}
function Yi({ org: t, revealed: s }) {
  const r = t.theme.bluetooth,
    i =
      r.accessory === "mouse" || r.accessory === "scanner"
        ? "none"
        : r.accessory,
    a = i !== "none",
    o = 130,
    l = 270,
    d = 1.2,
    x = [o - 13 * d, l - 95 * d],
    f = [o + 16 * d, l - 48 * d],
    p = r.device === "laptop",
    k = [o + 22 * d, l - 38 * d],
    j = [o + 17 * d, l - 72 * d],
    u = a ? x : r.accessory === "scanner" ? j : f,
    m = p ? [252, 196] : r.device === "label-printer" ? k : f;
  return e.jsxs(ce, {
    label: `${t.trace.bluetooth.split(" with no cable")[0]}: two devices close together, linked with no cable and no access point`,
    children: [
      e.jsx("rect", { width: "440", height: "300", fill: n.sky }),
      e.jsx("path", { d: "M0 250 H440 V300 H0Z", fill: n.grass }),
      p
        ? e.jsxs("g", {
            children: [
              e.jsx("rect", {
                x: "200",
                y: "214",
                width: "110",
                height: "10",
                rx: "3",
                fill: "#e2c39b",
                ...c,
              }),
              e.jsx("path", {
                d: "M210 224 V270 M300 224 V270",
                stroke: h,
                strokeWidth: "3",
              }),
              e.jsx("g", {
                transform: "translate(255 214)",
                children: e.jsx(qe, { device: "laptop" }),
              }),
            ],
          })
        : null,
      e.jsx($, {
        x: o,
        y: l,
        s: d,
        outfit: r.person,
        skin: y.mid,
        hair: E.dark,
        long: !0,
        ear: i,
        holding: e.jsx(oi, { look: r }),
      }),
      r.device === "label-printer"
        ? e.jsx("g", {
            transform: `translate(${k[0]} ${k[1]})`,
            children: e.jsx(qe, { device: "label-printer" }),
          })
        : null,
      e.jsx("path", {
        d: `M${u[0]} ${u[1]} Q${Math.max(u[0], m[0]) + 50} ${Math.min(u[1], m[1]) - 30} ${m[0]} ${m[1]}`,
        fill: "none",
        stroke: s ? n.mintDeep : n.cable,
        strokeWidth: "3",
        strokeDasharray: "5 6",
      }),
      e.jsxs("g", {
        transform: "translate(360 110)",
        children: [
          e.jsx("circle", { r: "38", fill: s ? n.mintWash : "#fff", ...c }),
          e.jsx("path", {
            d: "M-8 -16 L10 4 L0 14 V-14 L10 -4 L-8 16",
            fill: "none",
            stroke: n.cable,
            strokeWidth: "4",
            strokeLinecap: "round",
            strokeLinejoin: "round",
          }),
        ],
      }),
      s ? e.jsx(N, { x: 390, y: 78 }) : null,
    ],
  });
}
function Xi({ org: t, stage: s }) {
  return e.jsxs(ce, {
    label:
      "An email goes from the sender to the mail server, then to a desk PC and a phone",
    children: [
      e.jsx(ss, {}),
      e.jsx("rect", { width: "440", height: "300", fill: n.paper }),
      e.jsx(Q, { x: 60, y: 170, colour: n.peach }),
      e.jsx(ue, { d: "M96 150 Q150 110 190 140" }),
      e.jsx(S, { x: 220, y: 160, colour: n.lilac }),
      e.jsx(w, { x: 220, y: 212, text: "Mail server", size: 11 }),
      e.jsx(Me, { x: 150, y: 110, s: 0.55, kind: t.theme.packet }),
      e.jsxs("g", {
        opacity: s === "send" ? 0.4 : 1,
        children: [
          e.jsx(ue, { d: "M250 140 Q300 100 340 118" }),
          e.jsx(ue, { d: "M250 180 Q300 220 340 214" }),
          e.jsx(Q, { x: 380, y: 130, colour: n.blue }),
          e.jsx(es, { x: 380, y: 234, s: 0.6, packet: t.theme.packet }),
        ],
      }),
    ],
  });
}
function Ji({ revealed: t }) {
  const s = [n.peach, n.lilac, n.mint];
  return e.jsxs(ce, {
    label: "Devices from three different makers joining one network",
    children: [
      e.jsx("rect", { width: "440", height: "300", fill: n.sky }),
      e.jsx(F, { x: 220, y: 70, s: 1.3 }),
      s.map((r, i) =>
        e.jsxs(
          "g",
          {
            transform: `translate(${100 + i * 120} 200)`,
            children: [
              e.jsx("rect", {
                x: "-26",
                y: "-36",
                width: "52",
                height: "72",
                rx: "8",
                fill: r,
                ...c,
              }),
              e.jsx("rect", {
                x: "-20",
                y: "-28",
                width: "40",
                height: "50",
                rx: "4",
                fill: "#fff",
              }),
              e.jsx(v, {
                x: 0,
                y: 4,
                size: 12,
                weight: 700,
                anchor: "middle",
                children: ["Maker A", "Maker B", "Maker C"][i],
              }),
              t ? e.jsx(N, { x: 26, y: -40, s: 0.9 }) : null,
            ],
          },
          r,
        ),
      ),
      t
        ? e.jsxs("g", {
            className: "nb-flow-dots",
            children: [
              e.jsx(G, {
                from: [220, 100],
                to: [100, 160],
                n: 3,
                fill: n.mintDeep,
              }),
              e.jsx(G, {
                from: [220, 100],
                to: [220, 160],
                n: 3,
                fill: n.mintDeep,
              }),
              e.jsx(G, {
                from: [220, 100],
                to: [340, 160],
                n: 3,
                fill: n.mintDeep,
              }),
            ],
          })
        : null,
    ],
  });
}
function De({ y: t, fill: s, updated: r, show: i }) {
  return e.jsxs("g", {
    children: [
      e.jsx("path", {
        d: `M60 ${t} V${t + 10} L200 ${t + 26} L340 ${t + 10} V${t}`,
        fill: s,
        ...c,
      }),
      e.jsx("path", {
        d: `M60 ${t} L200 ${t - 16} L340 ${t} L200 ${t + 16}Z`,
        fill: s,
        ...c,
      }),
      i
        ? r
          ? e.jsxs("g", {
              children: [
                e.jsx(N, { x: 364, y: t + 2 }),
                e.jsx(v, {
                  x: 380,
                  y: t + 7,
                  size: 13,
                  weight: 700,
                  children: "Updated",
                }),
              ],
            })
          : e.jsx(v, {
              x: 354,
              y: t + 7,
              size: 13,
              weight: 600,
              fill: "#5a6684",
              children: "No change",
            })
        : null,
    ],
  });
}
function en({ org: t, revealed: s }) {
  return e.jsxs(ce, {
    label: s
      ? "Four layers: only the top layer changed"
      : "Four layers, one on top of another",
    children: [
      e.jsx("rect", { width: "440", height: "300", fill: n.paper }),
      e.jsx("path", {
        d: "M200 60 V270",
        stroke: n.pink,
        strokeWidth: "3",
        strokeDasharray: "4 6",
      }),
      e.jsx(De, { y: 250, fill: n.grey, updated: !1, show: s }),
      e.jsx(De, { y: 190, fill: n.grey, updated: !1, show: s }),
      e.jsx(De, { y: 130, fill: n.grey, updated: !1, show: s }),
      e.jsx(De, { y: 70, fill: s ? n.mint : n.grey, updated: !0, show: s }),
      e.jsx(Me, { x: 200, y: 68, s: 0.55, kind: t.theme.packet }),
    ],
  });
}
function li({ good: t }) {
  return e.jsxs("svg", {
    viewBox: "0 0 120 120",
    "aria-hidden": "true",
    className: "nb-next-art",
    children: [
      e.jsx(ds, {
        x: 6,
        y: 6,
        w: 108,
        h: 108,
        fill: t ? n.mintWash : n.amberWash,
        r: 24,
      }),
      t
        ? e.jsx(N, { x: 60, y: 60, s: 3 })
        : e.jsxs("g", {
            transform: "translate(60 60) scale(3)",
            children: [
              e.jsx("circle", { r: "10", fill: n.amber }),
              e.jsx("rect", {
                x: "-4.5",
                y: "-4.5",
                width: "3",
                height: "9",
                rx: "1.2",
                fill: "#fff",
              }),
              e.jsx("rect", {
                x: "1.5",
                y: "-4.5",
                width: "3",
                height: "9",
                rx: "1.2",
                fill: "#fff",
              }),
            ],
          }),
    ],
  });
}
function tn({ pages: t, page: s, onBack: r, onNext: i }) {
  const a = t[s];
  return e.jsxs("div", {
    className: "nb-page",
    "data-network-build-stage": "next",
    "data-next-page": a.id,
    children: [
      e.jsxs("div", {
        className: "nb-next-head",
        children: [
          e.jsx("h2", {
            className: "nb-title",
            children: "What happened next",
          }),
          e.jsxs("span", {
            className: "nb-count",
            children: [s + 1, " of ", t.length],
          }),
        ],
      }),
      e.jsxs("div", {
        className: "nb-next-card",
        "data-tone": a.tone,
        children: [
          e.jsx(li, { good: a.tone === "good" }),
          e.jsxs("div", {
            className: "nb-next-body",
            children: [
              e.jsx("p", { className: "nb-when", children: a.when }),
              e.jsx("h3", { className: "nb-subtitle", children: a.title }),
              e.jsxs("figure", {
                className: "nb-message",
                "data-tone": a.tone,
                children: [
                  e.jsx("figcaption", { children: a.beat.from }),
                  e.jsx("blockquote", { children: a.beat.message }),
                ],
              }),
              a.fix
                ? e.jsxs("div", {
                    className: "nb-fix",
                    children: [
                      e.jsx("h4", { children: "What would have fixed it" }),
                      e.jsx("p", { children: a.fix }),
                    ],
                  })
                : null,
            ],
          }),
        ],
      }),
      e.jsx("ol", {
        className: "nb-next-strip",
        "aria-label": "Pages",
        children: t.map((o, l) =>
          e.jsxs(
            "li",
            {
              "data-tone": o.tone,
              "aria-current": l === s ? "step" : void 0,
              children: [
                e.jsx(at, { tone: o.tone }),
                e.jsx("span", { children: o.title }),
              ],
            },
            o.id,
          ),
        ),
      }),
      e.jsxs("div", {
        className: "nb-nav",
        children: [
          e.jsx("button", {
            type: "button",
            className: "nb-button",
            onClick: r,
            disabled: s === 0,
            children: "Back",
          }),
          e.jsx("button", {
            type: "button",
            className: "nb-button nb-primary",
            onClick: i,
            children: s === t.length - 1 ? "See the report" : "Next",
          }),
        ],
      }),
    ],
  });
}
function sn({ org: t, rows: s, onPlayAgain: r, onPickAnother: i }) {
  const a = [
    { id: "week", title: "The week", rows: s.week },
    { id: "trace", title: "Trace", rows: s.trace },
  ].filter((o) => o.rows.length > 0);
  return e.jsxs("div", {
    className: "nb-page nb-report",
    "data-network-build-stage": "report",
    children: [
      e.jsxs("div", {
        className: "nb-report-main",
        children: [
          e.jsxs("h2", {
            className: "nb-title",
            children: ["Your network at ", t.name],
          }),
          a.map((o) =>
            e.jsxs(
              "section",
              {
                "aria-label": o.title,
                className: "nb-report-group",
                children: [
                  e.jsx("h3", {
                    className: "nb-sector-title",
                    children: o.title,
                  }),
                  e.jsx("ul", {
                    className: "nb-report-rows",
                    children: o.rows.map((l) =>
                      e.jsxs(
                        "li",
                        {
                          className: "nb-report-row",
                          "data-tone": l.mark.tone,
                          "data-report-row": l.id,
                          children: [
                            l.mark.outcome
                              ? e.jsx(Sr, { outcome: l.mark.outcome })
                              : e.jsx(at, { tone: l.mark.tone }),
                            e.jsx("span", {
                              className: "nb-report-label",
                              children: l.label,
                            }),
                            e.jsx("span", {
                              className: "nb-report-choice",
                              children: l.choice,
                            }),
                          ],
                        },
                        l.id,
                      ),
                    ),
                  }),
                ],
              },
              o.id,
            ),
          ),
          e.jsxs("div", {
            className: "nb-nav nb-wrap",
            children: [
              e.jsx("button", {
                type: "button",
                className: "nb-button nb-primary",
                onClick: r,
                children: "Play again",
              }),
              e.jsx("button", {
                type: "button",
                className: "nb-button",
                onClick: i,
                children: "Another organisation",
              }),
            ],
          }),
        ],
      }),
      e.jsxs("aside", {
        className: "nb-career",
        "aria-labelledby": "nb-career-title",
        children: [
          e.jsx(Qr, { org: t }),
          e.jsx("h3", {
            id: "nb-career-title",
            className: "nb-subtitle",
            children: "Network engineer",
          }),
          e.jsxs("ul", {
            children: [
              e.jsx("li", { children: "Designs and builds networks" }),
              e.jsx("li", {
                children: "Chooses the topology, kit and connections",
              }),
              e.jsx("li", { children: "Finds and fixes faults" }),
            ],
          }),
          e.jsxs("p", {
            className: "nb-source",
            children: [
              "Source: National Careers Service.",
              " ",
              e.jsx("a", {
                href: Tr,
                target: "_blank",
                rel: "noreferrer",
                children: "Job profile",
              }),
            ],
          }),
        ],
      }),
    ],
  });
}
export {
  Ji as $,
  F as A,
  Ei as B,
  n as C,
  L as D,
  z as E,
  Te as F,
  h as G,
  w as H,
  zi as I,
  ji as J,
  Le as K,
  c as L,
  pt as M,
  Ht as N,
  Sr as O,
  Oi as P,
  bi as Q,
  $r as R,
  Qe as S,
  Qi as T,
  mi as U,
  yi as V,
  Ii as W,
  zt as X,
  Li as Y,
  en as Z,
  vi as _,
  Fi as a,
  Mi as a0,
  Yi as a1,
  $i as a2,
  qi as a3,
  Vi as a4,
  yt as a5,
  Gi as a6,
  at as a7,
  Hi as a8,
  Ui as a9,
  Ai as aa,
  Ni as ab,
  Ki as ac,
  Ci as ad,
  Di as ae,
  Wi as af,
  Xi as ag,
  Si as ah,
  ui as ai,
  ki as aj,
  Bi as ak,
  tn as al,
  pi as am,
  wi as b,
  Rt as c,
  Lr as d,
  vr as e,
  Ft as f,
  Ze as g,
  Fe as h,
  gi as i,
  we as j,
  ut as k,
  Ti as l,
  sn as m,
  Ri as n,
  ke as o,
  Nr as p,
  _i as q,
  Zi as r,
  Pi as s,
  it as t,
  v as u,
  Ar as v,
  Mr as w,
  Me as x,
  At as y,
  Q as z,
};
