import { r as c, j as e } from "./react-vendor-BK1G6oO1.js";
import {
  ae as Qe,
  b$ as Ve,
  c0 as Xe,
  c1 as Je,
  c2 as Ze,
  c3 as et,
  c4 as tt,
  c5 as Fe,
  c6 as st,
  R as Ue,
  a7 as Se,
  a8 as Ae,
  P as Ce,
  j as rt,
  ap as at,
  bs as nt,
} from "./index-DjyiOHey.js";
import { s as Ne } from "./revision-content-CLnFOyQ7.js";
import { T as se } from "./action-styles-DWMwPIR0.js";
import { aT as Oe, aq as lt } from "./GameNotebook-b0Qw2wzd.js";
const ue = { durationMs: 720, easing: "cubic-bezier(0.65, 0, 0.35, 1)" },
  re = () => Qe();
function it(t, s, r) {
  if (typeof t.animate != "function") return null;
  ((t.dataset.matchingMotion = r ? "float" : "make-room"),
    r && (t.style.zIndex = "20"));
  const a = t.animate(
      r
        ? [
            {
              transform: `translateY(${s}px)`,
              boxShadow: "0 12px 28px -8px rgb(15 118 110 / 0.45)",
            },
            {
              transform: "translateY(0)",
              boxShadow: "0 1px 2px 0 rgb(0 0 0 / 0.05)",
            },
          ]
        : [{ transform: `translateY(${s}px)` }, { transform: "translateY(0)" }],
      { duration: ue.durationMs, easing: ue.easing },
    ),
    n = () => {
      ((t.style.zIndex = ""), delete t.dataset.matchingMotion);
    };
  return ((a.onfinish = n), (a.oncancel = n), a);
}
const he = {
  pc: st,
  mar: Fe,
  mdr: tt,
  acc: et,
  cu: Ze,
  alu: Je,
  cache: Xe,
  ram: Ve,
};
function ot(t) {
  return t === "paper" ? "study" : "retrieval";
}
const Y = [
    {
      id: "pc",
      term: "Program Counter (PC)",
      short: "PC",
      job: "I hold the address of the next instruction to fetch.",
    },
    {
      id: "mar",
      term: "Memory Address Register (MAR)",
      short: "MAR",
      job: "I hold the address in RAM that is about to be read from or written to.",
    },
    {
      id: "mdr",
      term: "Memory Data Register (MDR)",
      short: "MDR",
      job: "I hold the data or instruction copied from RAM, or about to be written to it.",
    },
    {
      id: "acc",
      term: "Accumulator (ACC)",
      short: "ACC",
      job: "I hold the result of each calculation the ALU carries out.",
    },
    {
      id: "cu",
      term: "Control Unit (CU)",
      short: "CU",
      job: "I control the fetch-execute cycle, telling the other parts of the CPU what to do.",
    },
    {
      id: "alu",
      term: "Arithmetic Logic Unit (ALU)",
      short: "ALU",
      job: "I carry out arithmetic calculations and logical comparisons.",
    },
    {
      id: "cache",
      term: "Cache",
      short: "Cache",
      job: "I keep frequently used instructions and data close to the CPU, so they are quicker to fetch than from RAM.",
    },
  ],
  dt = ["fetch", "execute"],
  oe = { fetch: "Fetch", execute: "Execute" },
  R = [
    {
      id: "pc-address",
      stage: "fetch",
      text: "The PC holds the address of the next instruction in RAM.",
      hint: "The CPU has to know where the next instruction is before it can get it.",
    },
    {
      id: "mar-address",
      stage: "fetch",
      text: "The address in the PC is copied to the MAR.",
      hint: "This is about finding the instruction in RAM.",
    },
    {
      id: "mdr-instruction",
      stage: "fetch",
      text: "The instruction at the MAR's address is copied from RAM into the MDR.",
      hint: "The instruction has to come into the CPU before anything else can happen.",
    },
    {
      id: "pc-increment",
      stage: "fetch",
      text: "The PC is incremented to point to the next instruction.",
      hint: "This gets the PC ready for the next cycle as soon as the instruction has been found.",
    },
    {
      id: "cu-reads",
      stage: "execute",
      text: "The CU reads the instruction in the MDR and controls how it is carried out.",
      hint: "This is the stage where the instruction actually happens.",
    },
    {
      id: "mdr-data",
      stage: "execute",
      text: "The data the instruction needs is copied from RAM into the MDR.",
      hint: "This is data the instruction uses, not the instruction itself.",
    },
    {
      id: "cu-controls",
      stage: "execute",
      text: "The CU tells the ALU what to do.",
      hint: "This is about making the instruction happen once it is inside the CPU.",
    },
    {
      id: "acc-result",
      stage: "execute",
      text: "The ALU carries out the calculation and stores the result in the ACC.",
      hint: "A result only exists once the instruction has been carried out.",
    },
  ],
  de = [
    {
      id: "pc",
      term: "Program Counter (PC)",
      holds: "address",
      reason: "The address of the next instruction to fetch.",
    },
    {
      id: "mar",
      term: "Memory Address Register (MAR)",
      holds: "address",
      reason: "The address in RAM being read from or written to.",
    },
    {
      id: "mdr",
      term: "Memory Data Register (MDR)",
      holds: "data",
      reason:
        "The data or instruction copied from, or about to be written to, RAM.",
    },
    {
      id: "acc",
      term: "Accumulator (ACC)",
      holds: "data",
      reason: "The result of a calculation.",
    },
  ],
  ct = {
    pc: ["pc-address", "mar-address", "pc-increment"],
    mar: ["mar-address", "mdr-instruction", "mdr-data"],
    mdr: ["mdr-instruction", "cu-reads", "mdr-data"],
    acc: ["acc-result"],
    cu: ["cu-reads", "cu-controls"],
    alu: ["cu-controls", "acc-result"],
  },
  ut = 1400,
  ht = 260,
  Ee = [3, 4],
  ye = Ee.map((t, s) => {
    const r = Ee.slice(0, s).reduce((a, n) => a + n, 0);
    return Y.slice(r, r + t);
  });
function xt({ component: t }) {
  const s = he[t.id];
  return e.jsx(s, {
    "aria-hidden": "true",
    className: "h-6 w-6 shrink-0 text-slate-400 sm:h-9 sm:w-9",
    strokeWidth: 1.75,
  });
}
function ft({ mode: t }) {
  const s = Y,
    [r, a] = c.useState(0),
    [n, u] = c.useState(0),
    f = t === "study",
    i = ye[n] ?? ye[0],
    x = n === ye.length - 1,
    { left: m, right: h } = c.useMemo(
      () => (f ? { left: i, right: i } : { left: Ne(i), right: Ne(i) }),
      [i, f, r],
    ),
    [g, y] = c.useState([]),
    [b, $] = c.useState({ left: null, right: null }),
    [P, w] = c.useState(null),
    [o, p] = c.useState(0),
    k = f ? s.map(({ id: d }) => d) : g,
    D = !f && g.length === s.length,
    _ = !f && i.every(({ id: d }) => g.includes(d)),
    q = (d) => {
      const S = [
        ...g.filter((l) => d.some((j) => j.id === l)),
        ...d.map(({ id: l }) => l).filter((l) => !g.includes(l)),
      ];
      return new Map(S.map((l, j) => [l, j]));
    },
    K = q(m),
    B = q(h);
  (c.useEffect(() => {
    (y([]), u(0), $({ left: null, right: null }), w(null), p(0));
  }, [t, r]),
    c.useEffect(() => {
      if (!P) return;
      const d = window.setTimeout(() => w(null), ut);
      return () => window.clearTimeout(d);
    }, [P]));
  function O(d, v) {
    if (f || g.includes(v)) return;
    const S = { ...b, [d]: b[d] === v ? null : v };
    if (!S.left || !S.right) {
      $(S);
      return;
    }
    ($({ left: null, right: null }),
      p((l) => l + 1),
      S.left === S.right
        ? (y((l) => [...l, S.left]), w(null))
        : w({ left: S.left, right: S.right }));
  }
  const I = c.useRef(null),
    ae = c.useRef(new Set()),
    [V, ge] = c.useState([]),
    ne = `${t}:${r}:${n}:${k.join(",")}`,
    X = c.useRef(() => {});
  X.current = () => {
    const d = I.current;
    if (!d) return;
    const v = d.getBoundingClientRect(),
      S = (l, j) =>
        d
          .querySelector(`[data-fde-side="${l}"][data-fde-tile="${j}"]`)
          ?.getBoundingClientRect();
    ge(
      k.flatMap((l) => {
        const j = S("left", l),
          M = S("right", l);
        return !j || !M || j.right >= M.left
          ? []
          : [
              {
                id: l,
                x1: j.right - v.left,
                y1: j.top + j.height / 2 - v.top,
                x2: M.left - v.left,
                y2: M.top + M.height / 2 - v.top,
              },
            ];
      }),
    );
  };
  const J = c.useRef(new Map()),
    le = c.useRef([]),
    H = c.useRef(0);
  (c.useLayoutEffect(() => {
    const d = I.current;
    if (!d) return;
    const v = le.current;
    le.current = k;
    const S = [...d.querySelectorAll("[data-fde-tile]")],
      l = (C) => `${C.dataset.fdeSide}:${C.dataset.fdeTile}`,
      j = J.current,
      M = d.getBoundingClientRect().top;
    for (const C of S) C.getAnimations?.().forEach((z) => z.cancel());
    J.current = new Map(
      S.map((C) => [l(C), C.getBoundingClientRect().top - M]),
    );
    const A = k.filter((C) => !v.includes(C));
    if (f || !A.length || !v.every((C) => k.includes(C)) || re()) return;
    let L = !1;
    for (const C of S) {
      const z = j.get(l(C)),
        G = J.current.get(l(C));
      z === void 0 ||
        G === void 0 ||
        Math.abs(z - G) < 1 ||
        (it(C, z - G, A.includes(C.dataset.fdeTile ?? "")) && (L = !0));
    }
    if (!L || typeof requestAnimationFrame > "u") return;
    const N = performance.now() + ue.durationMs + 32;
    cancelAnimationFrame(H.current);
    const F = () => {
      (X.current(),
        (H.current = performance.now() < N ? requestAnimationFrame(F) : 0));
    };
    H.current = requestAnimationFrame(F);
  }, [ne]),
    c.useEffect(() => () => cancelAnimationFrame(H.current), []),
    c.useLayoutEffect(() => {
      const d = I.current;
      if (!d) return;
      const v = () => X.current();
      v();
      const S = typeof ResizeObserver > "u" ? null : new ResizeObserver(v);
      return (
        S?.observe(d),
        window.addEventListener("resize", v),
        () => {
          (S?.disconnect(), window.removeEventListener("resize", v));
        }
      );
    }, [ne]),
    c.useEffect(() => ae.current.clear(), [t, r, n]));
  function be(d) {
    ($({ left: null, right: null }), w(null), u(d));
  }
  const Z = (d, v) =>
    e.jsxs("button", {
      type: "button",
      onClick: () => be(d),
      className: `inline-flex items-center gap-2 rounded-lg px-4 py-2 text-sm font-semibold transition ${se}`,
      children: [
        d < n
          ? e.jsx(Se, { "aria-hidden": "true", className: "h-4 w-4" })
          : null,
        v,
        d > n
          ? e.jsx(Ae, { "aria-hidden": "true", className: "h-4 w-4" })
          : null,
      ],
    });
  function ee(d, v) {
    return k.includes(v)
      ? f
        ? "border-teal-500/50 bg-slate-900 text-slate-100"
        : "border-emerald-500/60 bg-emerald-950 text-emerald-100"
      : P && P[d] === v
        ? "border-rose-500/70 bg-rose-950 text-rose-100"
        : b[d] === v
          ? "border-teal-400 bg-teal-950 text-slate-50"
          : "border-slate-700 bg-slate-900 text-slate-100 hover:border-teal-500/60";
  }
  const ie = (d) =>
    k.includes(d) ? (f ? "bg-teal-500" : "bg-emerald-500") : "bg-teal-500";
  return e.jsxs("div", {
    className: "space-y-4",
    "data-fde-match": !0,
    "data-fde-mode": t,
    "data-fde-page": n + 1,
    children: [
      e.jsxs("div", {
        ref: I,
        className:
          "relative grid grid-cols-[minmax(0,0.8fr)_minmax(0,1.2fr)] gap-x-2 gap-y-2 sm:grid-cols-[minmax(0,1fr)_clamp(2rem,8vw,5rem)_minmax(0,1.4fr)] sm:gap-x-0",
        children: [
          e.jsx("div", {
            className: "contents",
            role: "group",
            "aria-label": "Components",
            children: m.map((d) =>
              e.jsxs(
                "button",
                {
                  type: "button",
                  "data-fde-side": "left",
                  "data-fde-tile": d.id,
                  style: { gridRow: (K.get(d.id) ?? 0) + 1 },
                  disabled: f || g.includes(d.id),
                  "aria-pressed": b.left === d.id,
                  onClick: () => O("left", d.id),
                  className: `relative col-start-1 flex min-w-0 items-center gap-3 rounded-xl border px-3 py-2 text-left text-sm font-semibold transition-colors duration-500 focus:outline-none focus-visible:ring-2 focus-visible:ring-teal-400 disabled:cursor-default sm:px-4 ${ee("left", d.id)}`,
                  children: [
                    e.jsx("span", { children: d.term }),
                    e.jsx("span", {
                      className: `absolute -right-1 top-1/2 hidden h-3 w-3 -translate-y-1/2 rounded-full border-2 border-slate-950 sm:block ${ie(d.id)}`,
                      "aria-hidden": "true",
                    }),
                  ],
                },
                d.id,
              ),
            ),
          }),
          e.jsx("div", {
            className: "contents",
            role: "group",
            "aria-label": "Jobs",
            children: h.map((d) =>
              e.jsxs(
                "button",
                {
                  type: "button",
                  "data-fde-side": "right",
                  "data-fde-tile": d.id,
                  style: { gridRow: (B.get(d.id) ?? 0) + 1 },
                  disabled: f || g.includes(d.id),
                  "aria-pressed": b.right === d.id,
                  onClick: () => O("right", d.id),
                  className: `relative col-start-2 flex flex-col items-start gap-1.5 rounded-xl border px-3 py-2 text-left text-sm leading-6 transition-colors duration-500 focus:outline-none focus-visible:ring-2 focus-visible:ring-teal-400 disabled:cursor-default sm:col-start-3 sm:flex-row sm:items-center sm:gap-3 sm:px-4 ${ee("right", d.id)}`,
                  children: [
                    e.jsx("span", {
                      className: `absolute -left-1 top-1/2 hidden h-3 w-3 -translate-y-1/2 rounded-full border-2 border-slate-950 sm:block ${ie(d.id)}`,
                      "aria-hidden": "true",
                    }),
                    e.jsx(xt, { component: d }),
                    e.jsx("span", { children: d.job }),
                  ],
                },
                d.id,
              ),
            ),
          }),
          e.jsx("svg", {
            className:
              "pointer-events-none absolute inset-0 hidden h-full w-full overflow-visible sm:block",
            "aria-hidden": "true",
            children: V.map((d) =>
              e.jsx(
                "line",
                {
                  ref: (v) => {
                    !v ||
                      ae.current.has(d.id) ||
                      (ae.current.add(d.id),
                      !(f || typeof v.animate != "function" || re()) &&
                        v.animate(
                          [{ strokeDashoffset: 1 }, { strokeDashoffset: 0 }],
                          { duration: ht, easing: "ease-out" },
                        ));
                  },
                  "data-fde-line": d.id,
                  pathLength: 1,
                  strokeDasharray: "1",
                  x1: d.x1,
                  y1: d.y1,
                  x2: d.x2,
                  y2: d.y2,
                  className: f ? "stroke-teal-500/70" : "stroke-emerald-500",
                  strokeWidth: "3",
                  strokeLinecap: "round",
                },
                d.id,
              ),
            ),
          }),
        ],
      }),
      f
        ? e.jsxs("div", {
            className: "flex flex-wrap items-center gap-3",
            children: [
              n > 0 ? Z(n - 1, "Back") : null,
              x ? null : Z(n + 1, "Next"),
            ],
          })
        : e.jsx("div", {
            className: "flex flex-wrap items-center gap-3",
            "aria-live": "polite",
            children: D
              ? e.jsxs(e.Fragment, {
                  children: [
                    e.jsxs("p", {
                      className: "text-sm font-semibold text-emerald-300",
                      children: [
                        "All ",
                        s.length,
                        " matched in ",
                        o,
                        " ",
                        o === 1 ? "try" : "tries",
                        ".",
                      ],
                    }),
                    e.jsxs("button", {
                      type: "button",
                      onClick: () => a((d) => d + 1),
                      className: `inline-flex items-center gap-2 rounded-lg px-4 py-2 text-sm font-semibold transition ${se}`,
                      children: [
                        e.jsx(Ue, {
                          "aria-hidden": "true",
                          className: "h-4 w-4",
                        }),
                        "Again",
                      ],
                    }),
                  ],
                })
              : P
                ? e.jsx("p", {
                    className: "text-sm text-rose-200",
                    children: "Not a pair. Try again.",
                  })
                : _ && !x
                  ? e.jsxs(e.Fragment, {
                      children: [
                        e.jsxs("p", {
                          className: "text-sm font-semibold text-emerald-300",
                          children: [g.length, " of ", s.length, " matched"],
                        }),
                        Z(n + 1, "Next"),
                      ],
                    })
                  : e.jsxs("p", {
                      className: "text-sm text-slate-400",
                      children: [g.length, " of ", s.length, " matched"],
                    }),
          }),
      D ? e.jsx(Oe, { game: "fde-quiz" }) : null,
    ],
  });
}
function ze({
  x: t,
  y: s,
  width: r,
  height: a,
  chips: n,
  lit: u = !1,
  replay: f = 0,
}) {
  const i = Math.max(4, r * 0.14),
    x = { x: t + i - 1, w: r - i + 1 },
    m = Math.max(5, a * 0.05),
    h = Math.max(2, a * 0.025),
    g = (a - m * 2 - h * (n - 1)) / n,
    y = x.w * 0.56,
    b = x.x + (x.w - y) / 2 + i * 0.15,
    $ = Math.round(a / Math.max(4, i * 0.9)),
    P = { y: s + a * 0.58, h: Math.max(4, a * 0.04) },
    w = a / $;
  return e.jsxs("g", {
    "data-fde-ram": !0,
    "data-fde-ram-lit": u || void 0,
    "aria-hidden": "true",
    children: [
      e.jsx("g", {
        className: "fill-amber-400/90",
        children: Array.from({ length: $ }, (o, p) => {
          const k = s + p * w + w * 0.18,
            D = k + w * 0.32;
          return D > P.y - 1 && D < P.y + P.h + 1
            ? null
            : e.jsx(
                "rect",
                { x: t, y: k, width: i, height: w * 0.64, rx: 0.8 },
                p,
              );
        }),
      }),
      e.jsx("rect", {
        x: x.x,
        y: s,
        width: x.w,
        height: a,
        rx: Math.min(6, r * 0.08),
        className: `fill-emerald-800 transition-colors duration-500 ${u ? "stroke-amber-300" : "stroke-emerald-600"}`,
        strokeWidth: u ? 2 : 1.5,
      }),
      u
        ? e.jsx(
            "rect",
            {
              x: x.x,
              y: s,
              width: x.w,
              height: a,
              rx: Math.min(6, r * 0.08),
              fill: "none",
              className: "fde-part-glow stroke-amber-300",
              strokeWidth: 2,
            },
            f,
          )
        : null,
      Array.from({ length: n }, (o, p) =>
        e.jsx(
          "rect",
          {
            x: b,
            y: s + m + p * (g + h),
            width: y,
            height: g,
            rx: 1.5,
            className: "fill-slate-800 stroke-slate-500",
            strokeWidth: 0.75,
          },
          p,
        ),
      ),
    ],
  });
}
const Q = { width: 640, height: 300 },
  W = {
    cu: { x: 24, y: 44, w: 140, h: 112, label: "CU", name: "Control Unit" },
    alu: {
      x: 24,
      y: 172,
      w: 140,
      h: 112,
      label: "ALU",
      name: "Arithmetic Logic Unit",
    },
    pc: { x: 180, y: 44, w: 212, h: 52, label: "PC", name: "Program Counter" },
    mar: {
      x: 180,
      y: 108,
      w: 212,
      h: 52,
      label: "MAR",
      name: "Memory Address Register",
    },
    mdr: {
      x: 180,
      y: 172,
      w: 212,
      h: 52,
      label: "MDR",
      name: "Memory Data Register",
    },
    acc: { x: 180, y: 236, w: 212, h: 52, label: "ACC", name: "Accumulator" },
  },
  me = ["pc", "mar", "mdr", "acc"],
  Be = { x: 498, y: 46, width: 76, height: 240 },
  Le = Be.x - 4,
  mt = 900,
  pt = Object.fromEntries(Y.map(({ id: t, job: s }) => [t, s])),
  qe = {
    pc: "Now the CPU can't tell where the next instruction is.",
    mar: "Now the CPU can't say which address in memory to use.",
    mdr: "Now the CPU can't hold anything it fetches from memory.",
    acc: "Now the CPU loses every result the ALU works out.",
    cu: "Now nothing tells the CPU's parts what to do. The cycle stops.",
    alu: "Now the CPU can't calculate or compare anything.",
  },
  He = 24,
  gt = Array.from({ length: 15 }, (t, s) => 40 + s * He),
  bt = Array.from({ length: 11 }, (t, s) => 32 + s * He),
  U = (t) => W[t].y + W[t].h / 2,
  ke = (t) => W[t].x + W[t].w,
  Me = (t, s) =>
    s
      ? `M ${ke(t) + 2} ${U(t)} L ${Le} ${U(t)}`
      : `M ${Le + 2} ${U(t)} L ${ke(t) + 4} ${U(t)}`;
function yt(t, s) {
  if ("part" in t && "address" in s) return Me(t.part, !0);
  if ("address" in t && "part" in s) return Me(s.part, !1);
  if ("part" in t && "part" in s) {
    const r = W[t.part],
      a = W[s.part];
    if (r.x === a.x) {
      const u = ke(t.part) + 2;
      return `M ${u} ${U(t.part)} C ${u + 34} ${U(t.part)}, ${u + 34} ${U(s.part)}, ${u + 2} ${U(s.part)}`;
    }
    if (a.y + a.h < r.y)
      return `M ${r.x - 2} ${U(t.part)} C ${a.x + a.w - 10} ${U(t.part)}, ${a.x + a.w - 14} ${a.y + a.h + 20}, ${a.x + a.w - 14} ${a.y + a.h + 4}`;
    if (r.y + r.h < a.y)
      return `M ${r.x + r.w / 2} ${r.y + r.h + 1} L ${a.x + a.w / 2} ${a.y - 3}`;
    const n = U(s.part);
    return `M ${r.x + r.w + 1} ${n} L ${a.x - 3} ${n}`;
  }
  return "";
}
function jt({ from: t, to: s, durationMs: r }) {
  const a = c.useRef(null),
    n = c.useRef(null),
    u = yt(t, s);
  c.useEffect(() => {
    const i = a.current,
      x = n.current;
    if (
      !i ||
      !x ||
      re() ||
      typeof i.getTotalLength != "function" ||
      typeof requestAnimationFrame > "u"
    )
      return;
    const m = i.getTotalLength(),
      h = performance.now();
    let g = 0;
    const y = (b) => {
      const $ = Math.min(1, (b - h) / r),
        P = i.getPointAtLength(m * $);
      (x.setAttribute("cx", String(P.x)),
        x.setAttribute("cy", String(P.y)),
        x.setAttribute("opacity", $ < 1 ? "1" : "0"),
        $ < 1 && (g = requestAnimationFrame(y)));
    };
    return ((g = requestAnimationFrame(y)), () => cancelAnimationFrame(g));
  }, [u, r]);
  const f = (i) => ("part" in i ? i.part : "ram");
  return e.jsxs("g", {
    "data-fde-flow": `${f(t)}>${f(s)}`,
    children: [
      e.jsx("path", {
        ref: a,
        d: u,
        fill: "none",
        className: "fde-draw stroke-amber-300",
        strokeWidth: 2.5,
        pathLength: 1,
        strokeDasharray: "1",
        markerEnd: "url(#fde-flow-head)",
      }),
      e.jsx("circle", {
        ref: n,
        r: 6,
        className: "fill-amber-200",
        opacity: 0,
      }),
    ],
  });
}
function wt({ id: t, pinned: s, removed: r, onToggle: a }) {
  const n = W[t],
    u = me.includes(t),
    f = u ? ((n.x + n.w / 2) / Q.width) * 100 : (n.x / Q.width) * 100,
    i = n.y + n.h / 2 < Q.height / 2,
    x = i
      ? `calc(${((n.y + n.h) / Q.height) * 100}% + 6px)`
      : `calc(${(n.y / Q.height) * 100}% - 6px)`;
  return e.jsxs("div", {
    role: "tooltip",
    "data-fde-tip": t,
    className: `absolute z-10 w-max max-w-[16rem] rounded-lg border px-3 py-2 text-xs leading-5 shadow-lg sm:text-sm ${s ? "pointer-events-auto" : "pointer-events-none"} ${r ? "border-rose-400/60 bg-rose-950 text-rose-50" : "border-emerald-700 bg-[#04140f] text-slate-100"} ${u ? "-translate-x-1/2" : ""} ${i ? "" : "-translate-y-full"}`,
    style: { left: `${f}%`, top: x },
    children: [
      e.jsx("p", {
        "data-fde-tip-name": !0,
        className: `text-[11px] font-semibold leading-4 ${r ? "text-rose-200/70" : "text-emerald-300/70"}`,
        children: n.name,
      }),
      e.jsx("p", { "data-fde-tip-text": !0, children: r ? qe[t] : pt[t] }),
      s
        ? e.jsx("div", {
            className: "mt-2 flex justify-end",
            children: e.jsx("button", {
              type: "button",
              onClick: a,
              "data-fde-remove": t,
              className: `rounded-md border px-2.5 py-1 text-xs font-semibold transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-teal-300 ${r ? "border-emerald-500/70 text-emerald-100 hover:bg-emerald-900/50" : "border-rose-400/70 text-rose-100 hover:bg-rose-900/50"}`,
              children: r ? "Put me back" : "Remove me",
            }),
          })
        : null,
    ],
  });
}
function vt(t, s) {
  if (s.length === 0) return t;
  const r = (n) => s.includes(n),
    a = Object.fromEntries(Object.entries(t.values).filter(([n]) => !r(n)));
  return {
    ...t,
    values: a,
    pointers: t.pointers.filter(({ from: n }) => !r(n)),
    copied: r("mdr") ? null : t.copied,
    lit: t.lit.filter((n) => !r(n)),
    flow:
      t.flow && [t.flow.from, t.flow.to].some((n) => "part" in n && r(n.part))
        ? null
        : t.flow,
  };
}
function Re({ scene: t, replay: s, explains: r = () => !0, packetMs: a = mt }) {
  const [n, u] = c.useState(null),
    [f, i] = c.useState(null),
    [x, m] = c.useState([]),
    h = c.useRef(null),
    g = f ?? n,
    y = g && r(g) ? g : null,
    b = vt(t, x),
    $ = b.flow !== null && [b.flow.from, b.flow.to].some((o) => "address" in o);
  c.useEffect(() => {
    if (!f) return;
    const o = (p) => {
      h.current?.contains(p.target) || i(null);
    };
    return (
      document.addEventListener("pointerdown", o),
      () => document.removeEventListener("pointerdown", o)
    );
  }, [f]);
  function P(o) {
    m((p) => (p.includes(o) ? p.filter((k) => k !== o) : [...p, o]));
  }
  const w = [
    ...me
      .filter((o) => b.values[o])
      .map((o) => `${W[o].name} holds ${b.values[o]}`),
    ...b.pointers.map(
      ({ from: o, address: p }) => `${W[o].label} points at address ${p}`,
    ),
  ].join(". ");
  return e.jsxs("div", {
    className: "relative",
    ref: h,
    children: [
      e.jsxs("svg", {
        viewBox: `0 0 ${Q.width} ${Q.height}`,
        className: "h-auto w-full select-none",
        role: "img",
        "aria-label": w ? `Computer: ${w}.` : "Computer: CPU and main memory.",
        "data-fde-computer": !0,
        "data-fde-executing": b.executing || void 0,
        children: [
          e.jsxs("defs", {
            children: [
              e.jsx("marker", {
                id: "fde-pointer-head",
                viewBox: "0 0 10 10",
                refX: "8",
                refY: "5",
                markerWidth: "5",
                markerHeight: "5",
                orient: "auto-start-reverse",
                children: e.jsx("path", {
                  d: "M0 0 L10 5 L0 10 z",
                  className: "fill-teal-400",
                }),
              }),
              e.jsx("marker", {
                id: "fde-flow-head",
                viewBox: "0 0 10 10",
                refX: "8",
                refY: "5",
                markerWidth: "4",
                markerHeight: "4",
                orient: "auto-start-reverse",
                children: e.jsx("path", {
                  d: "M0 0 L10 5 L0 10 z",
                  className: "fill-amber-300",
                }),
              }),
            ],
          }),
          e.jsxs("g", {
            "data-fde-chip-pins": !0,
            "aria-hidden": "true",
            className: "fill-emerald-700/70",
            children: [
              gt.map((o) =>
                e.jsxs(
                  "g",
                  {
                    children: [
                      e.jsx("rect", {
                        x: o - 3,
                        y: 0,
                        width: 6,
                        height: 8,
                        rx: 1,
                      }),
                      e.jsx("rect", {
                        x: o - 3,
                        y: 294,
                        width: 6,
                        height: 6,
                        rx: 1,
                      }),
                    ],
                  },
                  o,
                ),
              ),
              bt.map((o) =>
                e.jsxs(
                  "g",
                  {
                    children: [
                      e.jsx("rect", {
                        x: 0,
                        y: o - 3,
                        width: 8,
                        height: 6,
                        rx: 1,
                      }),
                      e.jsx("rect", {
                        x: 404,
                        y: o - 3,
                        width: 8,
                        height: 6,
                        rx: 1,
                      }),
                    ],
                  },
                  o,
                ),
              ),
            ],
          }),
          e.jsx("rect", {
            x: 8,
            y: 8,
            width: 396,
            height: 286,
            rx: 16,
            "data-fde-chip": !0,
            className: `fill-[#062018] transition-colors duration-500 ${b.executing ? "stroke-amber-300/70" : "stroke-emerald-700"}`,
            strokeWidth: 2,
          }),
          e.jsx("circle", {
            cx: 388,
            cy: 24,
            r: 4,
            className: "fill-emerald-700/80",
            "aria-hidden": "true",
          }),
          e.jsx("text", {
            x: 24,
            y: 32,
            className: "fill-emerald-300/80 text-[16px] font-semibold",
            children: "CPU",
          }),
          e.jsx(he.ram, {
            x: 486,
            y: 15,
            size: 22,
            strokeWidth: 1.75,
            className: "text-slate-400",
          }),
          e.jsx("text", {
            x: 514,
            y: 32,
            className: "fill-slate-400 text-[16px] font-semibold",
            children: "RAM",
          }),
          e.jsx(ze, { ...Be, chips: 8, lit: $, replay: s }),
          Object.keys(W).map((o) => {
            const p = W[o],
              k = b.lit.includes(o),
              D = me.includes(o) ? b.values[o] : void 0,
              _ = me.includes(o),
              q = b.pointers.some((I) => I.from === o),
              K = he[o],
              B = k ? "text-emerald-100" : "text-emerald-300/70",
              O = x.includes(o);
            return e.jsxs(
              "g",
              {
                "data-fde-part": o,
                "data-fde-lit": k || void 0,
                "data-fde-removed": O || void 0,
                className: `transition-opacity duration-300 ${O ? "opacity-30" : ""} ${r(o) ? "cursor-help" : ""}`,
                onPointerEnter: () => u(o),
                onPointerLeave: () => u((I) => (I === o ? null : I)),
                onClick: () => i((I) => (I === o ? null : o)),
                children: [
                  e.jsx("rect", {
                    x: p.x,
                    y: p.y,
                    width: p.w,
                    height: p.h,
                    rx: 10,
                    className: `transition-colors duration-500 ${k ? "fill-[#0d3a2c] stroke-amber-300" : "fill-[#0a2b21] stroke-emerald-800"}`,
                    strokeWidth: 2,
                    strokeDasharray: O ? "6 5" : void 0,
                  }),
                  k
                    ? e.jsx(
                        "rect",
                        {
                          x: p.x,
                          y: p.y,
                          width: p.w,
                          height: p.h,
                          rx: 10,
                          fill: "none",
                          className: "fde-part-glow stroke-amber-300",
                          strokeWidth: 2,
                        },
                        s,
                      )
                    : null,
                  _
                    ? e.jsxs(e.Fragment, {
                        children: [
                          e.jsx(K, {
                            x: p.x + 12,
                            y: p.y + 13,
                            size: 26,
                            strokeWidth: 1.75,
                            className: `transition-colors duration-500 ${B}`,
                          }),
                          e.jsx("text", {
                            x: p.x + 46,
                            y: p.y + 32,
                            className: "fill-slate-100 text-[17px] font-bold",
                            children: p.label,
                          }),
                          e.jsx(
                            "text",
                            {
                              x: p.x + p.w - 14,
                              y: p.y + 32,
                              textAnchor: "end",
                              className: `font-mono text-[16px] ${k ? "fde-value-in" : ""} ${q ? "fill-teal-200" : "fill-amber-100"}`,
                              children: D ?? "",
                            },
                            `${D}-${k ? s : 0}`,
                          ),
                        ],
                      })
                    : e.jsxs(e.Fragment, {
                        children: [
                          e.jsx(K, {
                            x: p.x + p.w / 2 - 18,
                            y: p.y + 22,
                            size: 36,
                            strokeWidth: 1.75,
                            className: `transition-colors duration-500 ${B}`,
                          }),
                          e.jsx("text", {
                            x: p.x + p.w / 2,
                            y: p.y + 88,
                            textAnchor: "middle",
                            className: "fill-slate-100 text-[22px] font-bold",
                            children: p.label,
                          }),
                        ],
                      }),
                ],
              },
              o,
            );
          }),
          (b.pointerArrows ? b.pointers : []).map(({ from: o, address: p }) =>
            e.jsx(
              "path",
              {
                "data-fde-pointer": o,
                d: Me(o, !0),
                fill: "none",
                className: "fde-draw stroke-teal-400",
                strokeWidth: 2,
                pathLength: 1,
                strokeDasharray: "1",
                markerEnd: "url(#fde-pointer-head)",
              },
              `${o}-${p}`,
            ),
          ),
          b.flow
            ? e.jsx(jt, { from: b.flow.from, to: b.flow.to, durationMs: a }, s)
            : null,
        ],
      }),
      y
        ? e.jsx(wt, {
            id: y,
            pinned: y === f,
            removed: x.includes(y),
            onToggle: () => P(y),
          })
        : null,
      e.jsx("p", {
        "aria-live": "polite",
        className: "sr-only",
        children: x.map((o) => `${W[o].label} removed. ${qe[o]}`).join(" "),
      }),
    ],
  });
}
const $e = [
    { address: 0, contents: "0110 0011" },
    { address: 1, contents: "0011 0101" },
    { address: 2, contents: "0100 0101" },
    { address: 3, contents: "0111 0000" },
    { address: 4, contents: "0001 1001" },
    { address: 5, contents: "0000 1010" },
  ],
  T = 1,
  ce = 5,
  Ge = "0010 0011",
  Pe = {
    values: {},
    pointers: [],
    copied: null,
    lit: [],
    flow: null,
    pointerArrows: !0,
    executing: !1,
  };
function te(t, s, r) {
  return {
    ...t,
    pointers: [
      ...t.pointers.filter((a) => a.from !== s),
      { from: s, address: r },
    ],
  };
}
const Nt = {
    "pc-address": { from: { part: "pc" }, to: { address: T } },
    "mar-address": { from: { part: "pc" }, to: { part: "mar" } },
    "mdr-instruction": { from: { address: T }, to: { part: "mdr" } },
    "pc-increment": { from: { part: "pc" }, to: { address: T + 1 } },
    "cu-reads": { from: { part: "mdr" }, to: { part: "cu" } },
    "mdr-data": { from: { address: ce }, to: { part: "mdr" } },
    "cu-controls": { from: { part: "cu" }, to: { part: "alu" } },
    "acc-result": { from: { part: "alu" }, to: { part: "acc" } },
  },
  kt = ({ from: t, to: s }) =>
    [t, s].flatMap((r) => ("part" in r ? [r.part] : []));
function Mt(t, s) {
  switch (s) {
    case "pc-address":
      return { ...te(t, "pc", T), values: { ...t.values, pc: String(T) } };
    case "mar-address":
      return { ...te(t, "mar", T), values: { ...t.values, mar: String(T) } };
    case "mdr-instruction":
      return { ...t, values: { ...t.values, mdr: $e[T]?.contents }, copied: T };
    case "pc-increment":
      return {
        ...te(t, "pc", T + 1),
        values: { ...t.values, pc: String(T + 1) },
      };
    case "mdr-data":
      return {
        ...te(t, "mar", ce),
        executing: !0,
        values: { ...t.values, mar: String(ce), mdr: $e[ce]?.contents },
        copied: ce,
      };
    case "acc-result":
      return { ...t, executing: !0, values: { ...t.values, acc: Ge } };
    case "cu-reads":
    case "cu-controls":
      return { ...t, executing: !0 };
    default:
      return t;
  }
}
function Ye(t, s) {
  const r = R.filter(({ id: n }) => t.includes(n)).reduce(
      (n, { id: u }) => Mt(n, u),
      Pe,
    ),
    a = s !== null && t.includes(s) ? (Nt[s] ?? null) : null;
  return { ...r, pointerArrows: !1, flow: a, lit: a ? kt(a) : [] };
}
function $t(t, s) {
  return de
    .filter(({ id: r }) => t.includes(r))
    .reduce((r, { id: a }) => {
      const n = a === s ? [a] : [];
      return a === "pc"
        ? {
            ...te(r, "pc", T + 1),
            values: { ...r.values, pc: String(T + 1) },
            lit: [...r.lit, ...n],
          }
        : a === "mar"
          ? {
              ...te(r, "mar", T),
              values: { ...r.values, mar: String(T) },
              lit: [...r.lit, ...n],
            }
          : a === "mdr"
            ? {
                ...r,
                values: { ...r.values, mdr: $e[T]?.contents },
                copied: T,
                lit: [...r.lit, ...n],
              }
            : { ...r, values: { ...r.values, acc: Ge }, lit: [...r.lit, ...n] };
    }, Pe);
}
function Ke(t) {
  const s = R.findIndex((r) => r.id === t);
  return s < 0
    ? Pe
    : Ye(
        R.slice(0, s + 1).map((r) => r.id),
        t,
      );
}
const St = 4200,
  At = 2600;
function Ct(t, s) {
  return { ...t, lit: t.lit.includes(s) ? t.lit : [...t.lit, s] };
}
function Rt({ onDone: t }) {
  const [s, r] = c.useState(0),
    [a, n] = c.useState(!1),
    [u, f] = c.useState(0),
    [i, x] = c.useState(0),
    [m] = c.useState(() => !re()),
    h = Y[s] ?? Y[0],
    g = h.id === "cache" ? [] : ct[h.id],
    y = R.find(({ id: w }) => w === g[u]) ?? null,
    b = he[h.id],
    $ = s === Y.length - 1;
  (c.useEffect(() => {
    (n(!1), f(0), x((w) => w + 1));
  }, [s]),
    c.useEffect(() => {
      if (!m || g.length === 0) return;
      const w = window.setTimeout(() => {
        (f((o) => (o + 1) % g.length), x((o) => o + 1));
      }, St);
      return () => window.clearTimeout(w);
    }, [m, g.length, i]));
  function P(w) {
    (f(w), x((o) => o + 1));
  }
  return e.jsxs("div", {
    className: "space-y-4",
    "data-fde-flashcards": !0,
    "data-fde-flashcard": h.id,
    children: [
      e.jsxs("button", {
        type: "button",
        onClick: () => n((w) => !w),
        "aria-pressed": a,
        "aria-label": a ? `${h.term}: ${h.job}` : `${h.term}. Flip`,
        "data-fde-flashcard-face": a ? "back" : "front",
        className:
          "flex min-h-[7.5rem] w-full items-center gap-4 rounded-2xl border border-teal-500/40 bg-slate-900 px-5 py-4 text-left transition-colors hover:border-teal-400 focus:outline-none focus-visible:ring-2 focus-visible:ring-teal-400",
        children: [
          e.jsx(b, {
            "aria-hidden": "true",
            className: "h-10 w-10 shrink-0 text-emerald-300/80",
            strokeWidth: 1.75,
          }),
          e.jsx(
            "span",
            {
              className: "fde-card-land min-w-0 flex-1",
              children: a
                ? e.jsxs(e.Fragment, {
                    children: [
                      e.jsx("span", {
                        className:
                          "block text-sm font-semibold text-teal-300/80",
                        children: h.short,
                      }),
                      e.jsx("span", {
                        className:
                          "block text-lg leading-7 text-slate-50 sm:text-xl",
                        children: h.job,
                      }),
                    ],
                  })
                : e.jsxs(e.Fragment, {
                    children: [
                      e.jsx("span", {
                        className: "block text-3xl font-bold text-slate-50",
                        children: h.short,
                      }),
                      e.jsx("span", {
                        className: "block text-base text-slate-300",
                        children: h.term.replace(` (${h.short})`, ""),
                      }),
                    ],
                  }),
            },
            a ? "back" : "front",
          ),
        ],
      }),
      g.length > 0
        ? e.jsxs("div", {
            className: "space-y-3",
            "data-fde-flashcard-steps": !0,
            children: [
              e.jsx(
                Re,
                { scene: Ct(Ke(g[u] ?? ""), h.id), replay: i, packetMs: At },
                h.id,
              ),
              y
                ? e.jsxs(
                    "p",
                    {
                      className:
                        "fde-card-land min-h-[3.5rem] text-base leading-7 text-slate-200",
                      "aria-live": "polite",
                      "data-fde-flashcard-step": y.id,
                      children: [
                        e.jsx("span", {
                          className:
                            "mr-2 rounded-md bg-slate-800 px-2 py-0.5 text-sm font-semibold text-amber-200",
                          children: oe[y.stage],
                        }),
                        y.text,
                      ],
                    },
                    `${h.id}-${y.id}`,
                  )
                : null,
              e.jsx("div", {
                role: "group",
                "aria-label": `${h.short} steps`,
                className: "-ml-3 flex gap-1",
                children: g.map((w, o) =>
                  e.jsx(
                    "button",
                    {
                      type: "button",
                      onClick: () => P(o),
                      "aria-label": `Step ${o + 1} of ${g.length}`,
                      "aria-current": o === u || void 0,
                      className:
                        "flex h-10 w-10 items-center justify-center rounded-lg focus:outline-none focus-visible:ring-2 focus-visible:ring-teal-400",
                      children: e.jsx("span", {
                        className: `h-2.5 w-2.5 rounded-full transition-colors ${o === u ? "bg-amber-300" : "bg-slate-600"}`,
                      }),
                    },
                    w,
                  ),
                ),
              }),
            ],
          })
        : e.jsx("div", {
            className:
              "flex justify-center rounded-2xl border border-slate-800 bg-slate-900/50 py-10",
            "data-fde-flashcard-glyph": !0,
            children: e.jsx(b, {
              "aria-hidden": "true",
              className: "h-24 w-24 text-emerald-300/70",
              strokeWidth: 1.5,
            }),
          }),
      e.jsxs("div", {
        className: "flex flex-wrap items-center gap-2",
        role: "group",
        "aria-label": "Cards",
        children: [
          e.jsx("button", {
            type: "button",
            onClick: () => r((w) => Math.max(0, w - 1)),
            disabled: s === 0,
            "aria-label": "Previous card",
            className:
              "inline-flex h-10 w-10 items-center justify-center rounded-lg border border-slate-700 text-slate-100 transition hover:border-teal-500/60 disabled:opacity-40",
            children: e.jsx(Se, {
              "aria-hidden": "true",
              className: "h-5 w-5",
            }),
          }),
          e.jsxs("span", {
            className: "text-sm text-slate-400",
            children: [s + 1, " of ", Y.length],
          }),
          $
            ? e.jsxs("button", {
                type: "button",
                onClick: t,
                "data-fde-flashcards-done": !0,
                className: `ml-auto inline-flex h-10 items-center gap-2 rounded-lg px-4 text-sm font-semibold transition ${se}`,
                children: [
                  e.jsx(Ce, { "aria-hidden": "true", className: "h-4 w-4" }),
                  "Quiz",
                ],
              })
            : e.jsx("button", {
                type: "button",
                onClick: () => r((w) => Math.min(Y.length - 1, w + 1)),
                "aria-label": "Next card",
                className:
                  "inline-flex h-10 w-10 items-center justify-center rounded-lg border border-slate-700 text-slate-100 transition hover:border-teal-500/60",
                children: e.jsx(Ae, {
                  "aria-hidden": "true",
                  className: "h-5 w-5",
                }),
              }),
        ],
      }),
    ],
  });
}
const De = ["#f472b6", "#facc15", "#34d399", "#fb923c", "#a78bfa", "#38bdf8"],
  Pt = [
    [18, 18],
    [78, 18],
    [18, 46],
    [78, 46],
  ],
  xe = [
    {
      id: "calculator",
      name: "Calculator",
      art: e.jsxs(e.Fragment, {
        children: [
          e.jsx("rect", {
            x: 30,
            y: 8,
            width: 36,
            height: 64,
            rx: 5,
            fill: "#334155",
          }),
          e.jsx("rect", {
            x: 30,
            y: 8,
            width: 36,
            height: 6,
            rx: 3,
            fill: "#475569",
          }),
          e.jsx("rect", {
            x: 35,
            y: 15,
            width: 26,
            height: 12,
            rx: 2,
            fill: "#a7f3d0",
          }),
          e.jsx("rect", {
            x: 49,
            y: 19,
            width: 9,
            height: 4,
            rx: 1,
            fill: "#065f46",
            opacity: 0.7,
          }),
          [0, 1, 2, 3].map((t) =>
            [0, 1, 2].map((s) =>
              e.jsx(
                "rect",
                {
                  x: 35 + s * 9,
                  y: 32 + t * 9,
                  width: 7,
                  height: 6,
                  rx: 1.5,
                  fill: t === 3 && s === 2 ? "#f59e0b" : "#64748b",
                },
                `${t}-${s}`,
              ),
            ),
          ),
        ],
      }),
    },
    {
      id: "washing-machine",
      name: "Washing machine",
      art: e.jsxs(e.Fragment, {
        children: [
          e.jsx("rect", {
            x: 20,
            y: 4,
            width: 56,
            height: 68,
            rx: 6,
            fill: "#e2e8f0",
          }),
          e.jsx("rect", {
            x: 20,
            y: 4,
            width: 56,
            height: 14,
            rx: 6,
            fill: "#cbd5e1",
          }),
          e.jsx("rect", {
            x: 26,
            y: 9,
            width: 16,
            height: 4,
            rx: 2,
            fill: "#0f172a",
          }),
          e.jsx("circle", { cx: 66, cy: 11, r: 3.5, fill: "#94a3b8" }),
          e.jsx("circle", { cx: 48, cy: 45, r: 19, fill: "#94a3b8" }),
          e.jsx("circle", { cx: 48, cy: 45, r: 14, fill: "#1e3a8a" }),
          e.jsx("path", {
            d: "M34 48c5-4 9 3 14-1s9 3 14-1v1a14 14 0 0 1-28 0z",
            fill: "#38bdf8",
            opacity: 0.85,
          }),
          e.jsx("path", {
            d: "M40 36a10 10 0 0 1 8-3",
            stroke: "#e0f2fe",
            strokeWidth: 2,
            strokeLinecap: "round",
            fill: "none",
            opacity: 0.7,
          }),
        ],
      }),
    },
    {
      id: "phone",
      name: "Phone",
      art: e.jsxs(e.Fragment, {
        children: [
          e.jsx("rect", {
            x: 32,
            y: 2,
            width: 32,
            height: 70,
            rx: 7,
            fill: "#0f172a",
          }),
          e.jsx("rect", {
            x: 35,
            y: 6,
            width: 26,
            height: 60,
            rx: 5,
            fill: "#1d4ed8",
          }),
          e.jsx("rect", {
            x: 44,
            y: 8,
            width: 8,
            height: 2.5,
            rx: 1.25,
            fill: "#0f172a",
          }),
          [0, 1, 2, 3].map((t) =>
            [0, 1, 2].map((s) =>
              e.jsx(
                "rect",
                {
                  x: 38 + s * 7.5,
                  y: 15 + t * 9,
                  width: 5.5,
                  height: 5.5,
                  rx: 1.5,
                  fill: De[(t * 3 + s) % De.length],
                },
                `${t}-${s}`,
              ),
            ),
          ),
          e.jsx("rect", {
            x: 42,
            y: 61,
            width: 12,
            height: 2,
            rx: 1,
            fill: "#bfdbfe",
          }),
        ],
      }),
    },
    {
      id: "laptop",
      name: "Laptop",
      art: e.jsxs(e.Fragment, {
        children: [
          e.jsx("rect", {
            x: 18,
            y: 20,
            width: 60,
            height: 42,
            rx: 4,
            fill: "#334155",
          }),
          e.jsx("rect", {
            x: 22,
            y: 24,
            width: 52,
            height: 34,
            rx: 2,
            fill: "#0c4a6e",
          }),
          e.jsx("rect", {
            x: 26,
            y: 29,
            width: 22,
            height: 3,
            rx: 1.5,
            fill: "#38bdf8",
          }),
          e.jsx("rect", {
            x: 26,
            y: 35,
            width: 34,
            height: 3,
            rx: 1.5,
            fill: "#7dd3fc",
            opacity: 0.7,
          }),
          e.jsx("rect", {
            x: 26,
            y: 41,
            width: 28,
            height: 3,
            rx: 1.5,
            fill: "#7dd3fc",
            opacity: 0.5,
          }),
          e.jsx("path", { d: "M8 66h80l-6-4H14z", fill: "#94a3b8" }),
          e.jsx("rect", {
            x: 8,
            y: 66,
            width: 80,
            height: 6,
            rx: 2,
            fill: "#cbd5e1",
          }),
          e.jsx("rect", {
            x: 40,
            y: 67,
            width: 16,
            height: 2,
            rx: 1,
            fill: "#94a3b8",
          }),
        ],
      }),
    },
    {
      id: "games-console",
      name: "Games console",
      art: e.jsxs(e.Fragment, {
        children: [
          e.jsx("path", {
            d: "M22 44h52a12 12 0 0 1 12 11l1 7a8 8 0 0 1-14 6l-6-6H29l-6 6a8 8 0 0 1-14-6l1-7a12 12 0 0 1 12-11z",
            fill: "#475569",
          }),
          e.jsx("path", {
            d: "M25 50v10M20 55h10",
            stroke: "#0f172a",
            strokeWidth: 4,
            strokeLinecap: "round",
          }),
          e.jsx("circle", { cx: 68, cy: 51, r: 2.6, fill: "#22c55e" }),
          e.jsx("circle", { cx: 74, cy: 56, r: 2.6, fill: "#ef4444" }),
          e.jsx("circle", { cx: 62, cy: 56, r: 2.6, fill: "#3b82f6" }),
          e.jsx("circle", { cx: 68, cy: 61, r: 2.6, fill: "#facc15" }),
          e.jsx("circle", { cx: 40, cy: 60, r: 3.5, fill: "#1e293b" }),
          e.jsx("circle", { cx: 56, cy: 60, r: 3.5, fill: "#1e293b" }),
        ],
      }),
    },
    {
      id: "smartwatch",
      name: "Smartwatch",
      art: e.jsxs(e.Fragment, {
        children: [
          e.jsx("rect", {
            x: 8,
            y: 60,
            width: 80,
            height: 10,
            rx: 5,
            fill: "#1f2937",
          }),
          e.jsx("rect", {
            x: 30,
            y: 44,
            width: 36,
            height: 28,
            rx: 9,
            fill: "#94a3b8",
          }),
          e.jsx("rect", {
            x: 33,
            y: 47,
            width: 30,
            height: 22,
            rx: 7,
            fill: "#020617",
          }),
          e.jsx("rect", {
            x: 66,
            y: 52,
            width: 3,
            height: 8,
            rx: 1.5,
            fill: "#cbd5e1",
          }),
          e.jsx("path", {
            d: "M40 60l4-4 4 3 6-7",
            stroke: "#34d399",
            strokeWidth: 2,
            strokeLinecap: "round",
            strokeLinejoin: "round",
            fill: "none",
          }),
        ],
      }),
    },
    {
      id: "drone",
      name: "Drone",
      airborne: !0,
      art: e.jsxs(e.Fragment, {
        children: [
          e.jsx("ellipse", {
            cx: 48,
            cy: 70,
            rx: 26,
            ry: 2.5,
            fill: "#000",
            opacity: 0.45,
          }),
          e.jsxs("g", {
            className: "fde-hover",
            children: [
              e.jsx("path", {
                d: "M40 30L18 20M56 30l22-10M40 38L18 46M56 38l22 8",
                stroke: "#64748b",
                strokeWidth: 4,
                strokeLinecap: "round",
              }),
              e.jsx("rect", {
                x: 36,
                y: 26,
                width: 24,
                height: 16,
                rx: 6,
                fill: "#e5e7eb",
              }),
              e.jsx("circle", { cx: 48, cy: 42, r: 4, fill: "#0f172a" }),
              e.jsx("circle", { cx: 42, cy: 30, r: 1.6, fill: "#ef4444" }),
              e.jsx("circle", { cx: 54, cy: 30, r: 1.6, fill: "#22c55e" }),
              Pt.map(([t, s]) =>
                e.jsxs(
                  "g",
                  {
                    children: [
                      e.jsx("ellipse", {
                        className: "fde-rotor",
                        cx: t,
                        cy: s,
                        rx: 13,
                        ry: 3,
                        fill: "#cbd5e1",
                        opacity: 0.55,
                      }),
                      e.jsx("circle", {
                        cx: t,
                        cy: s,
                        r: 2.5,
                        fill: "#475569",
                      }),
                    ],
                  },
                  `${t}-${s}`,
                ),
              ),
            ],
          }),
        ],
      }),
    },
    {
      id: "self-driving-car",
      name: "Self-driving car",
      art: e.jsxs(e.Fragment, {
        children: [
          e.jsx("path", {
            d: "M6 58v-8a6 6 0 0 1 4-6l12-3 10-11a8 8 0 0 1 6-3h20a8 8 0 0 1 6 3l11 11 9 2a6 6 0 0 1 5 6v9z",
            fill: "#f8fafc",
          }),
          e.jsx("path", {
            d: "M34 40l7-8h10v8zM55 32h4a5 5 0 0 1 4 2l6 6H55z",
            fill: "#1e293b",
          }),
          e.jsx("rect", {
            x: 6,
            y: 52,
            width: 84,
            height: 6,
            rx: 2,
            fill: "#cbd5e1",
          }),
          e.jsx("rect", {
            x: 42,
            y: 19,
            width: 12,
            height: 6,
            rx: 3,
            fill: "#334155",
          }),
          e.jsx("rect", {
            x: 45,
            y: 20,
            width: 6,
            height: 2,
            rx: 1,
            fill: "#2dd4bf",
          }),
          e.jsx("circle", { cx: 24, cy: 62, r: 9, fill: "#0f172a" }),
          e.jsx("circle", { cx: 24, cy: 62, r: 4, fill: "#94a3b8" }),
          e.jsx("circle", { cx: 72, cy: 62, r: 9, fill: "#0f172a" }),
          e.jsx("circle", { cx: 72, cy: 62, r: 4, fill: "#94a3b8" }),
          e.jsx("rect", {
            x: 84,
            y: 46,
            width: 5,
            height: 3,
            rx: 1.5,
            fill: "#fde68a",
          }),
        ],
      }),
    },
    {
      id: "humanoid-robot",
      name: "Humanoid robot",
      art: e.jsxs(e.Fragment, {
        children: [
          e.jsx("rect", {
            x: 38,
            y: 0,
            width: 20,
            height: 16,
            rx: 7,
            fill: "#f1f5f9",
          }),
          e.jsx("rect", {
            x: 40,
            y: 5,
            width: 16,
            height: 7,
            rx: 3.5,
            fill: "#0f172a",
          }),
          e.jsx("circle", { cx: 44.5, cy: 8.5, r: 1.6, fill: "#2dd4bf" }),
          e.jsx("circle", { cx: 51.5, cy: 8.5, r: 1.6, fill: "#2dd4bf" }),
          e.jsx("rect", { x: 45, y: 16, width: 6, height: 4, fill: "#94a3b8" }),
          e.jsx("path", {
            d: "M34 24l-8 18M62 24l8 18",
            stroke: "#cbd5e1",
            strokeWidth: 6,
            strokeLinecap: "round",
          }),
          e.jsx("path", {
            d: "M42 46l-2 22M54 46l2 22",
            stroke: "#cbd5e1",
            strokeWidth: 7,
            strokeLinecap: "round",
          }),
          e.jsx("rect", {
            x: 34,
            y: 20,
            width: 28,
            height: 26,
            rx: 8,
            fill: "#e2e8f0",
          }),
          e.jsx("rect", {
            x: 42,
            y: 26,
            width: 12,
            height: 8,
            rx: 3,
            fill: "#cbd5e1",
          }),
          e.jsx("rect", {
            x: 33,
            y: 67,
            width: 11,
            height: 5,
            rx: 2,
            fill: "#475569",
          }),
          e.jsx("rect", {
            x: 52,
            y: 67,
            width: 11,
            height: 5,
            rx: 2,
            fill: "#475569",
          }),
        ],
      }),
    },
    {
      id: "mars-rover",
      name: "Mars rover",
      art: e.jsxs(e.Fragment, {
        children: [
          e.jsx("rect", {
            x: 10,
            y: 30,
            width: 50,
            height: 6,
            rx: 2,
            fill: "#1e3a8a",
          }),
          e.jsx("path", {
            d: "M18 30v6M26 30v6M34 30v6M42 30v6M50 30v6",
            stroke: "#3b82f6",
            strokeWidth: 1,
          }),
          e.jsx("rect", {
            x: 20,
            y: 36,
            width: 52,
            height: 14,
            rx: 3,
            fill: "#e2e8f0",
          }),
          e.jsx("path", { d: "M66 36V18", stroke: "#94a3b8", strokeWidth: 3 }),
          e.jsx("rect", {
            x: 60,
            y: 10,
            width: 16,
            height: 9,
            rx: 2,
            fill: "#cbd5e1",
          }),
          e.jsx("circle", { cx: 70, cy: 14.5, r: 2.5, fill: "#0f172a" }),
          e.jsx("path", {
            d: "M24 50l-8 8M46 50v8M68 50l8 8",
            stroke: "#64748b",
            strokeWidth: 3,
          }),
          [16, 46, 76].map((t) =>
            e.jsxs(
              "g",
              {
                children: [
                  e.jsx("circle", { cx: t, cy: 64, r: 8, fill: "#1f2937" }),
                  e.jsx("circle", { cx: t, cy: 64, r: 3, fill: "#94a3b8" }),
                ],
              },
              t,
            ),
          ),
        ],
      }),
    },
  ],
  Tt = 150,
  Et = 120,
  Lt = 3,
  Ie = { width: 360, height: 210 },
  E = { x: 16, y: 20, w: 160, h: 170 },
  pe = { x: 270, y: 44, width: 46, height: 146 },
  je = pe.x - 3,
  we = 8,
  Dt = Array.from({ length: 10 }, (t, s) => E.x + 12 + s * 15),
  It = Array.from({ length: 11 }, (t, s) => E.y + 10 + s * 15),
  Wt = [
    { id: "cu", label: "CU", y: 40 },
    { id: "alu", label: "ALU", y: 104 },
  ],
  _t = [
    { id: "pc", label: "PC", y: 40 },
    { id: "mar", label: "MAR", y: 70 },
    { id: "mdr", label: "MDR", y: 100 },
    { id: "acc", label: "ACC", y: 130 },
  ];
function fe(t, s) {
  return ((Math.imul(t + s * 97, 2654435761) >>> 24) & 255)
    .toString(2)
    .padStart(8, "0");
}
function Ft() {
  const t = { d: `M 166 52 L ${je} 52`, to: [je, 52], lit: ["pc"], ram: !0 },
    s = { d: `M ${je} 112 L 168 112`, to: [168, 112], lit: ["mdr"], ram: !0 };
  return [
    t,
    {
      d: "M 166 54 C 192 56, 192 80, 168 82",
      to: [168, 82],
      lit: ["pc", "mar"],
    },
    s,
    t,
    { d: "M 98 106 C 92 100, 90 94, 84 90", to: [84, 90], lit: ["mdr", "cu"] },
    s,
    { d: "M 66 92 C 76 96, 76 100, 66 104", to: [66, 104], lit: ["cu", "alu"] },
    {
      d: "M 86 142 C 90 136, 94 136, 98 142",
      to: [98, 142],
      lit: ["alu", "acc"],
    },
  ];
}
function We(t) {
  const s = Math.floor(t / 8),
    r = t % 8,
    a = s % 6,
    n = (a + 4) % we,
    u = (a + 5) % 6,
    f = {
      pc: String(r >= 3 ? a + 1 : a),
      mar: String(r >= 5 ? n : r >= 1 ? a : (u + 4) % we),
      mdr: (r >= 5
        ? fe(s, n)
        : r >= 2
          ? fe(s, a)
          : fe(s - 1, (u + 4) % we)
      ).slice(0, 4),
      acc: fe(r >= 7 ? s : s - 1, 99).slice(0, 4),
    };
  return { step: r, values: f, steps: Ft() };
}
function Ut({ step: t }) {
  const s = c.useRef(null),
    r = c.useRef(null);
  c.useEffect(() => {
    const u = s.current,
      f = r.current;
    if (
      !u ||
      !f ||
      typeof u.getTotalLength != "function" ||
      typeof requestAnimationFrame > "u"
    )
      return;
    const i = u.getTotalLength(),
      x = performance.now();
    let m = 0;
    const h = (g) => {
      const y = Math.min(1, (g - x) / Et),
        b = 1 - (1 - y) * (1 - y),
        $ = u.getPointAtLength(i * b);
      (f.setAttribute("cx", String($.x)),
        f.setAttribute("cy", String($.y)),
        f.setAttribute("opacity", y < 1 ? "1" : "0"),
        y < 1 && (m = requestAnimationFrame(h)));
    };
    return ((m = requestAnimationFrame(h)), () => cancelAnimationFrame(m));
  }, []);
  const [a, n] = t.to;
  return e.jsxs("g", {
    "data-fde-spark": !0,
    children: [
      e.jsx("path", {
        ref: s,
        d: t.d,
        fill: "none",
        pathLength: 1,
        strokeDasharray: "1",
        className: "fde-spark-trail stroke-amber-300",
        strokeWidth: 2,
        strokeLinecap: "round",
      }),
      e.jsx("circle", {
        ref: r,
        r: 3.2,
        className: "fill-amber-100",
        opacity: 0,
      }),
      e.jsx("g", {
        transform: `translate(${a} ${n})`,
        children: e.jsx("g", {
          className: "fde-spark-burst stroke-amber-200",
          strokeWidth: 1.4,
          strokeLinecap: "round",
          children: [0, 60, 120, 180, 240, 300].map((u) =>
            e.jsx(
              "path",
              { d: "M 3 0 L 8 0", transform: `rotate(${u + 15})` },
              u,
            ),
          ),
        }),
      }),
    ],
  });
}
function Ot({ device: t }) {
  return e.jsx("svg", {
    viewBox: "0 0 96 72",
    className: "h-[63px] w-[84px]",
    "aria-hidden": "true",
    children: t.art,
  });
}
function zt({ onStart: t }) {
  const [s] = c.useState(() => !re()),
    [r, a] = c.useState(10);
  c.useEffect(() => {
    if (!s) return;
    const i = window.setInterval(() => a((x) => x + 1), Tt);
    return () => window.clearInterval(i);
  }, [s]);
  const n = We(r),
    u = new Set(n.steps[n.step]?.lit ?? []),
    f = Array.from({ length: s ? Lt : 1 }, (i, x) => r - x).filter(
      (i) => i >= 0,
    );
  return e.jsxs("div", {
    className:
      "mx-auto flex min-h-[75vh] max-w-xl flex-col justify-center space-y-8",
    "data-fde-landing": !0,
    "data-fde-landing-moving": s || void 0,
    children: [
      e.jsxs("svg", {
        viewBox: `0 0 ${Ie.width} ${Ie.height}`,
        className: "h-auto w-full select-none",
        role: "img",
        "aria-label": "A CPU running the fetch-execute cycle at full speed",
        "data-fde-landing-computer": !0,
        children: [
          e.jsxs("g", {
            className: "fill-emerald-700/70",
            "aria-hidden": "true",
            children: [
              Dt.map((i) =>
                e.jsxs(
                  "g",
                  {
                    children: [
                      e.jsx("rect", {
                        x: i - 2.5,
                        y: E.y - 7,
                        width: 5,
                        height: 7,
                        rx: 1,
                      }),
                      e.jsx("rect", {
                        x: i - 2.5,
                        y: E.y + E.h,
                        width: 5,
                        height: 7,
                        rx: 1,
                      }),
                    ],
                  },
                  i,
                ),
              ),
              It.map((i) =>
                e.jsx(
                  "rect",
                  { x: E.x - 7, y: i - 2.5, width: 7, height: 5, rx: 1 },
                  i,
                ),
              ),
            ],
          }),
          e.jsx("rect", {
            x: E.x,
            y: E.y,
            width: E.w,
            height: E.h,
            rx: 12,
            className: "fill-[#062018] stroke-emerald-600",
            strokeWidth: 2,
          }),
          e.jsx("rect", {
            x: E.x,
            y: E.y,
            width: E.w,
            height: E.h,
            rx: 12,
            fill: "none",
            className: "fde-landing-core stroke-emerald-300",
            strokeWidth: 2,
          }),
          e.jsx("text", {
            x: E.x + 12,
            y: E.y + 162,
            className: "fill-emerald-300/80 text-[11px] font-semibold",
            children: "CPU",
          }),
          Wt.map(({ id: i, label: x, y: m }) =>
            e.jsxs(
              "g",
              {
                "data-fde-landing-part": i,
                children: [
                  e.jsx("rect", {
                    x: 28,
                    y: m,
                    width: 58,
                    height: 52,
                    rx: 7,
                    className: `fill-[#0a2b21] transition-colors duration-150 ${u.has(i) ? "stroke-amber-300" : "stroke-emerald-800"}`,
                    strokeWidth: 1.5,
                  }),
                  e.jsx("text", {
                    x: 57,
                    y: m + 31,
                    textAnchor: "middle",
                    className: "fill-slate-100 text-[13px] font-bold",
                    children: x,
                  }),
                ],
              },
              i,
            ),
          ),
          _t.map(({ id: i, label: x, y: m }) =>
            e.jsxs(
              "g",
              {
                "data-fde-landing-part": i,
                children: [
                  e.jsx("rect", {
                    x: 98,
                    y: m,
                    width: 68,
                    height: 24,
                    rx: 5,
                    className: `fill-[#0a2b21] transition-colors duration-150 ${u.has(i) ? "stroke-amber-300" : "stroke-emerald-800"}`,
                    strokeWidth: 1.5,
                  }),
                  e.jsx("text", {
                    x: 104,
                    y: m + 16,
                    className: "fill-slate-100 text-[9px] font-bold",
                    children: x,
                  }),
                  e.jsx("text", {
                    x: 161,
                    y: m + 16,
                    textAnchor: "end",
                    className: `font-mono text-[8px] ${i === "pc" || i === "mar" ? "fill-teal-200" : "fill-amber-100"}`,
                    children: n.values[i],
                  }),
                ],
              },
              i,
            ),
          ),
          e.jsx("text", {
            x: pe.x + pe.width / 2,
            y: 37,
            textAnchor: "middle",
            className: "fill-slate-400 text-[11px] font-semibold",
            children: "RAM",
          }),
          e.jsx(ze, { ...pe, chips: 6, lit: n.steps[n.step]?.ram ?? !1 }),
          e.jsx("g", {
            "aria-hidden": "true",
            children: f.map((i) => {
              const x = We(i).steps[i % 8];
              return x ? e.jsx(Ut, { step: x }, i) : null;
            }),
          }),
        ],
      }),
      e.jsxs("div", {
        className: "relative overflow-hidden",
        "data-fde-conveyor": !0,
        children: [
          e.jsx("ul", {
            className: `flex w-max gap-4 pb-3 pr-4 ${s ? "fde-conveyor" : ""}`,
            "aria-label": "Run by a CPU",
            children: [...xe, ...xe].map((i, x) =>
              e.jsxs(
                "li",
                {
                  "aria-hidden": x >= xe.length || void 0,
                  "data-fde-device": x < xe.length ? i.id : void 0,
                  className: "flex w-28 justify-center",
                  children: [
                    e.jsx(Ot, { device: i }),
                    e.jsx("span", { className: "sr-only", children: i.name }),
                  ],
                },
                `${i.id}-${x}`,
              ),
            ),
          }),
          e.jsx("div", {
            className: `absolute inset-x-0 top-[63px] h-3 rounded-sm border-y border-slate-600 ${s ? "fde-belt" : "fde-belt-still"}`,
            "aria-hidden": "true",
          }),
          e.jsx("div", {
            className:
              "pointer-events-none absolute inset-y-0 left-0 w-10 bg-gradient-to-r from-[#020617] to-transparent",
            "aria-hidden": "true",
          }),
          e.jsx("div", {
            className:
              "pointer-events-none absolute inset-y-0 right-0 w-10 bg-gradient-to-l from-[#020617] to-transparent",
            "aria-hidden": "true",
          }),
        ],
      }),
      e.jsx("div", {
        className: "flex justify-center",
        children: e.jsxs("button", {
          type: "button",
          onClick: t,
          "data-fde-start": !0,
          className: `inline-flex items-center gap-2 rounded-lg px-6 py-2.5 text-base font-semibold transition ${se}`,
          children: [
            e.jsx(Ce, { "aria-hidden": "true", className: "h-4 w-4" }),
            "Start",
          ],
        }),
      }),
    ],
  });
}
const Bt = 2400,
  qt = 1200,
  _e = "text/plain";
function Ht({ mode: t }) {
  const s = t === "study",
    [r, a] = c.useState(0),
    n = c.useMemo(() => Ne(R), [r]),
    [u, f] = c.useState([]),
    [i, x] = c.useState(null),
    [m, h] = c.useState(null),
    [g, y] = c.useState({}),
    [b, $] = c.useState(0),
    [P, w] = c.useState(null),
    [o, p] = c.useState(0),
    [k, D] = c.useState(!1),
    [_, q] = c.useState(null),
    K = c.useRef(0),
    B = c.useRef(new Map()),
    O = c.useRef(null),
    I = s && o > 0 ? (R[o - 1] ?? null) : null,
    ae = s ? R.slice(0, o).map(({ id: l }) => l) : u,
    V = s ? (I?.id ?? null) : (P?.card ?? null),
    ge = _ ? Ke(_.card) : Ye(ae, V),
    ne = !s && u.length === R.length,
    X = n.filter(({ id: l }) => !u.includes(l));
  lt(
    s ? 0 : u.length,
    s ? 0 : R.length,
    s ? null : u.filter((l) => !g[l]).length,
  );
  function J() {
    (f([]), x(null), h(null), y({}), $(0), w(null), p(0), D(!1), q(null));
  }
  c.useEffect(J, [t]);
  const le = (l) => (j) => {
    j ? B.current.set(l, j) : B.current.delete(l);
  };
  (c.useLayoutEffect(() => {
    const l = O.current;
    if (((O.current = null), !l || re())) return;
    const j = u[u.length - 1];
    for (const [M, A] of B.current) {
      const L = l.get(M);
      if (!L || typeof A.animate != "function") continue;
      const N = A.getBoundingClientRect(),
        F = L.left - N.left,
        C = L.top - N.top;
      if (Math.abs(F) < 1 && Math.abs(C) < 1) continue;
      const z = M === j;
      z && (A.style.zIndex = "20");
      const G = A.animate(
          z
            ? [
                {
                  transform: `translate(${F}px, ${C}px)`,
                  boxShadow: "0 12px 28px -8px rgb(252 211 77 / 0.45)",
                },
                {
                  transform: "translate(0, 0)",
                  boxShadow: "0 0 0 0 rgb(0 0 0 / 0)",
                },
              ]
            : [
                { transform: `translate(${F}px, ${C}px)` },
                { transform: "translate(0, 0)" },
              ],
          { duration: ue.durationMs, easing: ue.easing },
        ),
        Te = () => {
          A.style.zIndex = "";
        };
      ((G.onfinish = Te), (G.oncancel = Te));
    }
  }, [u]),
    c.useEffect(() => {
      if (!m) return;
      const l = window.setTimeout(() => h(null), qt);
      return () => window.clearTimeout(l);
    }, [m]),
    c.useEffect(() => {
      if (!s || !k) return;
      if (o >= R.length) {
        D(!1);
        return;
      }
      const l = window.setTimeout(() => p((j) => j + 1), o === 0 ? 300 : Bt);
      return () => window.clearTimeout(l);
    }, [s, k, o]));
  function H(l, j) {
    const M = R.find(({ id: A }) => A === l);
    (x(null),
      !(!M || s || u.includes(M.id)) &&
        (M.stage === j
          ? ((O.current = new Map(
              [...B.current].map(([A, L]) => [A, L.getBoundingClientRect()]),
            )),
            f((A) => [...A, M.id]),
            w((A) => ({ card: M.id, key: (A?.key ?? 0) + 1 })),
            h(null))
          : (h({ card: M.id, stage: j, key: Date.now() }),
            y((A) => ({ ...A, [M.id]: (A[M.id] ?? 0) + 1 })),
            $((A) => A + 1))));
  }
  function be(l, j) {
    l.preventDefault();
    const M = l.dataTransfer.getData(_e);
    M && H(M, j);
  }
  function Z(l) {
    (D(!1), p((j) => Math.max(0, Math.min(R.length, j + l))));
  }
  const ee = m ? R.find(({ id: l }) => l === m.card) : null,
    ie = ee && (g[ee.id] ?? 0) >= 2 ? ee.hint : null,
    d = _ ? -_.key : s ? o : (P?.key ?? 0);
  function v(l, j = !1) {
    (_?.card === l && !j) || ((K.current += 1), q({ card: l, key: K.current }));
  }
  function S(l) {
    q((j) => (j?.card === l ? null : j));
  }
  return e.jsxs("div", {
    className: "space-y-4",
    "data-fde-buckets": !0,
    "data-fde-mode": t,
    children: [
      e.jsx(Re, { scene: ge, replay: d }),
      e.jsx("div", {
        className: "grid grid-cols-2 gap-3 sm:gap-4",
        role: "group",
        "aria-label": "Stages",
        children: dt.map((l) => {
          const j = R.filter((N) => N.stage === l),
            M = m?.stage === l,
            A = V ? R.find(({ id: N }) => N === V)?.stage === l : !1,
            L = !s && !!i;
          return e.jsxs(
            "section",
            {
              "data-fde-bucket": l,
              onDragOver: (N) => !s && N.preventDefault(),
              onDrop: (N) => be(N, l),
              className: `flex min-h-[10rem] flex-col gap-2 rounded-2xl border-2 p-2 transition-colors duration-300 sm:p-3 ${M ? "border-rose-400 bg-rose-950/50" : L ? "border-teal-400 bg-teal-950/40" : "border-slate-700 bg-slate-900/60"}`,
              children: [
                e.jsxs("button", {
                  type: "button",
                  disabled: !L,
                  onClick: () => i && H(i, l),
                  "aria-label": i ? `Put in ${oe[l]}` : oe[l],
                  className: `relative rounded-xl py-2 text-lg font-bold transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-teal-300 disabled:cursor-default sm:text-xl ${L ? "text-teal-100 hover:bg-teal-900/50" : "text-slate-100"}`,
                  children: [
                    A
                      ? e.jsx(
                          "span",
                          {
                            className:
                              "fde-bucket-pulse pointer-events-none absolute inset-0 rounded-xl",
                            "aria-hidden": "true",
                          },
                          d,
                        )
                      : null,
                    oe[l],
                  ],
                }),
                e.jsx("ol", {
                  "aria-label": oe[l],
                  className: "space-y-2",
                  "data-fde-stage-list": l,
                  children: j.map((N) => {
                    const F = R.indexOf(N) + 1;
                    if (!s && !u.includes(N.id))
                      return e.jsx(
                        "li",
                        {
                          "data-fde-blank": F,
                          children: e.jsx("button", {
                            type: "button",
                            tabIndex: L ? 0 : -1,
                            disabled: !L,
                            onClick: () => i && H(i, l),
                            "aria-label": `Step ${F}`,
                            className: `flex min-h-[2.75rem] w-full items-center rounded-lg border border-dashed px-2 text-xs font-semibold transition-colors duration-300 focus:outline-none focus-visible:ring-2 focus-visible:ring-teal-300 disabled:cursor-default sm:px-3 ${L ? "border-teal-500/60 text-teal-300/80 hover:bg-teal-900/40" : "border-slate-700 text-slate-600"}`,
                            children: F,
                          }),
                        },
                        `blank-${N.id}`,
                      );
                    const C = _?.card === N.id,
                      z = !_ && N.id === V,
                      G = !s || R.indexOf(N) < o;
                    return e.jsx(
                      "li",
                      {
                        ref: le(N.id),
                        "data-fde-placed": N.id,
                        className: "relative rounded-lg bg-slate-900",
                        children: e.jsx("button", {
                          type: "button",
                          "aria-pressed": C,
                          onMouseEnter: () => v(N.id),
                          onMouseLeave: () => S(N.id),
                          onFocus: () => v(N.id),
                          onBlur: () => S(N.id),
                          onClick: () => v(N.id, !0),
                          className: `w-full rounded-lg border px-2 py-2 text-left text-xs leading-5 transition-colors duration-300 focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-300 sm:px-3 sm:text-sm ${C ? "border-amber-300 bg-amber-300/15 text-amber-50" : z ? `${s ? "fde-card-land " : ""}border-amber-300/70 bg-amber-300/10 text-amber-50` : G ? (s ? "border-teal-500/40 bg-slate-900 text-slate-100 hover:border-amber-300/60" : "border-emerald-500/40 bg-emerald-950/60 text-emerald-50 hover:border-amber-300/60") : "border-slate-800 bg-slate-900/60 text-slate-500 hover:border-amber-300/60"}`,
                          children: e.jsxs("span", {
                            className: "flex gap-2",
                            children: [
                              e.jsx("span", {
                                className:
                                  "shrink-0 font-semibold tabular-nums opacity-60",
                                "aria-hidden": "true",
                                children: F,
                              }),
                              e.jsx("span", { children: N.text }),
                            ],
                          }),
                        }),
                      },
                      N.id,
                    );
                  }),
                }),
              ],
            },
            l,
          );
        }),
      }),
      !s && X.length > 0
        ? e.jsx("div", {
            className: "flex flex-wrap gap-2",
            role: "group",
            "aria-label": "What happens",
            children: X.map((l) =>
              e.jsx(
                "button",
                {
                  type: "button",
                  draggable: !0,
                  onDragStart: (j) => {
                    (j.dataTransfer.setData(_e, l.id),
                      (j.dataTransfer.effectAllowed = "move"),
                      x(l.id));
                  },
                  ref: le(l.id),
                  "data-fde-card": l.id,
                  "aria-pressed": i === l.id,
                  onClick: () => x(i === l.id ? null : l.id),
                  className: `cursor-grab rounded-lg border px-3 py-2 text-left text-sm transition-colors duration-300 focus:outline-none focus-visible:ring-2 focus-visible:ring-teal-400 active:cursor-grabbing ${i === l.id ? "border-teal-400 bg-teal-950 text-slate-50" : m?.card === l.id ? "fde-card-shake border-rose-500/70 bg-rose-950 text-rose-100" : "border-slate-700 bg-slate-900 text-slate-100 hover:border-teal-500/60"}`,
                  children: l.text,
                },
                l.id,
              ),
            ),
          })
        : null,
      e.jsxs("div", {
        "aria-live": "polite",
        className: "min-h-[1.5rem] space-y-1 text-sm",
        children: [
          m
            ? e.jsx("p", { className: "sr-only", children: "Not quite." })
            : null,
          ie
            ? e.jsx("p", {
                className: "text-amber-100",
                "data-fde-hint": !0,
                children: ie,
              })
            : null,
          ne
            ? e.jsxs("div", {
                className: "flex flex-wrap items-center gap-3",
                children: [
                  e.jsxs("p", {
                    className: "font-semibold text-emerald-300",
                    children: [
                      "All sorted with ",
                      b,
                      " ",
                      b === 1 ? "mistake" : "mistakes",
                      ".",
                    ],
                  }),
                  e.jsxs("button", {
                    type: "button",
                    onClick: () => {
                      (J(), a((l) => l + 1));
                    },
                    className: `inline-flex items-center gap-2 rounded-lg px-4 py-2 font-semibold transition ${se}`,
                    children: [
                      e.jsx(Ue, {
                        "aria-hidden": "true",
                        className: "h-4 w-4",
                      }),
                      "Again",
                    ],
                  }),
                ],
              })
            : null,
        ],
      }),
      ne ? e.jsx(Oe, { game: "fde-quiz" }) : null,
      s
        ? e.jsxs("div", {
            className: "flex flex-wrap items-center gap-2",
            role: "group",
            "aria-label": "Step through the cycle",
            children: [
              e.jsx("button", {
                type: "button",
                onClick: () => Z(-1),
                disabled: o === 0,
                "aria-label": "Back",
                className:
                  "inline-flex h-10 w-10 items-center justify-center rounded-lg border border-slate-700 text-slate-100 transition hover:border-teal-500/60 disabled:opacity-40",
                children: e.jsx(Se, {
                  "aria-hidden": "true",
                  className: "h-5 w-5",
                }),
              }),
              e.jsxs("button", {
                type: "button",
                onClick: () => {
                  (o >= R.length && p(0), D((l) => !l));
                },
                "aria-label": k ? "Pause" : "Play",
                className: `inline-flex h-10 items-center gap-2 rounded-lg px-4 text-sm font-semibold transition ${se}`,
                children: [
                  k
                    ? e.jsx(rt, { "aria-hidden": "true", className: "h-4 w-4" })
                    : e.jsx(Ce, {
                        "aria-hidden": "true",
                        className: "h-4 w-4",
                      }),
                  k ? "Pause" : "Play",
                ],
              }),
              e.jsx("button", {
                type: "button",
                onClick: () => Z(1),
                disabled: o >= R.length,
                "aria-label": "Next",
                className:
                  "inline-flex h-10 w-10 items-center justify-center rounded-lg border border-slate-700 text-slate-100 transition hover:border-teal-500/60 disabled:opacity-40",
                children: e.jsx(Ae, {
                  "aria-hidden": "true",
                  className: "h-5 w-5",
                }),
              }),
              e.jsxs("span", {
                className: "ml-1 text-sm text-slate-400",
                children: [o, " of ", R.length],
              }),
            ],
          })
        : null,
    ],
  });
}
function Gt({ id: t }) {
  const s = he[t];
  return e.jsx(s, {
    "aria-hidden": "true",
    className: "h-6 w-6 shrink-0 text-slate-400",
    strokeWidth: 1.75,
  });
}
const Yt = [
  { id: "address", title: "Address", Icon: Fe },
  { id: "data", title: "Data", Icon: at },
];
function Kt({ mode: t }) {
  const s = t === "study",
    [r, a] = c.useState({}),
    [n, u] = c.useState(null),
    [f, i] = c.useState(null);
  c.useEffect(() => {
    (a({}), u(null), i(null));
  }, [t]);
  function x(h, g) {
    const y = de.find((b) => b.id === h);
    !y ||
      s ||
      r[h] ||
      (y.holds === g
        ? (a((b) => ({ ...b, [h]: !0 })),
          i((b) => ({ id: h, key: (b?.key ?? 0) + 1 })),
          u(null))
        : u({ id: h, choice: g }));
  }
  const m = s ? de.map(({ id: h }) => h) : Object.keys(r);
  return e.jsxs("div", {
    className: "space-y-4",
    children: [
      e.jsx(Re, {
        scene: $t(m, s ? null : (f?.id ?? null)),
        replay: f?.key ?? 0,
        explains: (h) => s || m.includes(h) || !de.some((g) => g.id === h),
      }),
      e.jsx("ul", {
        className: "space-y-3",
        "data-fde-holds": !0,
        "data-fde-mode": t,
        children: de.map((h) => {
          const g = s || r[h.id];
          return e.jsxs(
            "li",
            {
              "data-fde-register": h.id,
              className: `rounded-xl border px-3 py-3 transition-colors duration-300 sm:px-4 ${g ? (s ? "border-teal-500/40 bg-slate-900" : "border-emerald-500/50 bg-emerald-950/60") : "border-slate-700 bg-slate-900"}`,
              children: [
                e.jsxs("div", {
                  className:
                    "flex flex-wrap items-center justify-between gap-3",
                  children: [
                    e.jsxs("span", {
                      className:
                        "flex items-center gap-3 font-semibold text-slate-50",
                      children: [e.jsx(Gt, { id: h.id }), h.term],
                    }),
                    e.jsx("div", {
                      role: "group",
                      "aria-label": `${h.term} stores`,
                      className: "inline-flex gap-2",
                      children: Yt.map((y) => {
                        const b = g && y.id === h.holds,
                          $ = n?.id === h.id && n.choice === y.id;
                        return e.jsxs(
                          "button",
                          {
                            type: "button",
                            disabled: !!g,
                            "aria-pressed": b,
                            onClick: () => x(h.id, y.id),
                            className: `inline-flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-sm font-semibold transition-colors duration-300 focus:outline-none focus-visible:ring-2 focus-visible:ring-teal-400 disabled:cursor-default ${b ? (s ? "border-teal-400 bg-teal-400 text-[#020617]" : "border-emerald-400 bg-emerald-400 text-[#020617]") : $ ? "fde-card-shake border-rose-500/70 bg-rose-950 text-rose-100" : g ? "border-slate-800 text-slate-500" : "border-slate-600 text-slate-200 hover:border-teal-500/60"}`,
                            children: [
                              e.jsx(y.Icon, {
                                "aria-hidden": "true",
                                className: "h-4 w-4 shrink-0",
                                strokeWidth: 1.75,
                              }),
                              y.title,
                            ],
                          },
                          y.id,
                        );
                      }),
                    }),
                  ],
                }),
                g
                  ? e.jsx("p", {
                      className: "fde-card-land mt-2 text-sm text-slate-300",
                      children: h.reason,
                    })
                  : null,
                n?.id === h.id
                  ? e.jsx("p", {
                      className: "sr-only",
                      "aria-live": "polite",
                      children: "Not quite.",
                    })
                  : null,
              ],
            },
            h.id,
          );
        }),
      }),
    ],
  });
}
const ve = [
    { id: "cards", title: "Flashcards", prompt: "" },
    {
      id: "jobs",
      title: "What do I do?",
      prompt: "Pick a part, then what it does.",
    },
    {
      id: "stages",
      title: "Fetch or execute?",
      prompt: "Put each card in the stage where it happens.",
    },
    {
      id: "holds",
      title: "Data or address?",
      prompt: "Does each register store data or an address?",
    },
  ],
  Qt = [
    { id: "retrieval", title: "Retrieval" },
    { id: "study", title: "Study" },
  ];
function Vt() {
  const t = nt(),
    [s, r] = c.useState(null),
    a = s ?? ot(t),
    [n, u] = c.useState("cards"),
    f = ve.find(({ id: m }) => m === n) ?? ve[0],
    [i, x] = c.useState(!1);
  return i
    ? e.jsxs("div", {
        className: "space-y-5",
        "data-fde-quiz": !0,
        "data-fde-mode": a,
        children: [
          e.jsxs("div", {
            className: "flex flex-wrap items-center justify-between gap-3",
            children: [
              e.jsx("div", {
                role: "tablist",
                "aria-label": "Rounds",
                className: "flex flex-wrap gap-2",
                children: ve.map((m) =>
                  e.jsx(
                    "button",
                    {
                      type: "button",
                      role: "tab",
                      id: `fde-tab-${m.id}`,
                      "aria-selected": m.id === n,
                      "aria-controls": "fde-round",
                      onClick: () => u(m.id),
                      className: `rounded-lg border px-3 py-2 text-sm font-semibold transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-teal-400 ${m.id === n ? "border-teal-400 bg-teal-950 text-slate-50" : "border-slate-700 bg-slate-900 text-slate-300 hover:border-teal-500/60"}`,
                      children: m.title,
                    },
                    m.id,
                  ),
                ),
              }),
              n === "cards"
                ? null
                : e.jsx("div", {
                    role: "radiogroup",
                    "aria-label": "Mode",
                    className:
                      "inline-flex rounded-lg border border-slate-700 bg-slate-900 p-1",
                    "data-fde-mode-toggle": !0,
                    children: Qt.map((m) =>
                      e.jsx(
                        "button",
                        {
                          type: "button",
                          role: "radio",
                          "aria-checked": m.id === a,
                          onClick: () => r(m.id),
                          className: `rounded-md px-3 py-1.5 text-sm font-semibold transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-teal-400 ${m.id === a ? "bg-teal-400 text-[#020617]" : "text-slate-300 hover:text-slate-50"}`,
                          children: m.title,
                        },
                        m.id,
                      ),
                    ),
                  }),
            ],
          }),
          e.jsxs("div", {
            id: "fde-round",
            role: "tabpanel",
            "aria-labelledby": `fde-tab-${f.id}`,
            className: "space-y-4",
            children: [
              a === "retrieval" && f.prompt
                ? e.jsx("p", {
                    className: "text-sm text-slate-300",
                    children: f.prompt,
                  })
                : null,
              n === "cards"
                ? e.jsx(Rt, { onDone: () => u("jobs") })
                : n === "stages"
                  ? e.jsx(Ht, { mode: a })
                  : n === "holds"
                    ? e.jsx(Kt, { mode: a })
                    : e.jsx(ft, { mode: a }),
            ],
          }),
        ],
      })
    : e.jsx(zt, { onStart: () => x(!0) });
}
const ss = Object.freeze(
  Object.defineProperty({ __proto__: null, default: Vt }, Symbol.toStringTag, {
    value: "Module",
  }),
);
export { Vt as F, ue as M, ss as a, it as f, re as m };
