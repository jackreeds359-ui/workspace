import {
  j as n,
  r as c,
  bP as Y,
  bQ as ae,
  bR as re,
  bS as le,
  bT as ie,
  e as oe,
  aj as ce,
  ak as ue,
} from "./index-CHiQZc8e.js";
function de(e) {
  let t = 2166136261;
  for (let s = 0; s < e.length; s += 1)
    ((t ^= e.charCodeAt(s)), (t = Math.imul(t, 16777619)));
  return t >>> 0;
}
function fe(e) {
  let t = typeof e == "number" ? e >>> 0 : de(e);
  return () => {
    t = (t + 1831565813) >>> 0;
    let s = t;
    return (
      (s = Math.imul(s ^ (s >>> 15), s | 1)),
      (s ^= s + Math.imul(s ^ (s >>> 7), s | 61)),
      ((s ^ (s >>> 14)) >>> 0) / 4294967296
    );
  };
}
function E(e, t, s) {
  return t + e() * (s - t);
}
const k = 200,
  B = 240;
function he(e, t, s, a) {
  const r = Math.floor(E(e, 5, 11)),
    i = E(e, 0.06, 0.16),
    u = E(e, 0, Math.PI * 2),
    h = Math.floor(E(e, 5, 8)),
    f = [];
  for (let o = 0; o < h; o += 1) {
    const l = a * (0.35 + (o / h) * 0.65),
      d = u + o * (Math.PI / r);
    let g = "";
    for (let y = 0; y <= B; y += 1) {
      const w = (y / B) * Math.PI * 2,
        v = l * (1 + i * Math.sin(r * w + d)),
        M = t + v * Math.cos(w),
        N = s + v * Math.sin(w);
      g += `${y === 0 ? "M" : "L"}${M.toFixed(1)} ${N.toFixed(1)}`;
    }
    f.push(`${g}Z`);
  }
  return f;
}
function me(e) {
  const t = fe(`pattern:${e}`),
    a = t() < 0.5 ? k * 0.82 : k * 0.18,
    r = k * E(t, 0.12, 0.3);
  return he(t, a, r, k * E(t, 0.42, 0.55));
}
function xe({ seed: e, className: t }) {
  return n.jsx("svg", {
    className: t ?? "rc-pattern",
    viewBox: `0 0 ${k} ${k}`,
    preserveAspectRatio: "xMidYMid slice",
    "aria-hidden": "true",
    focusable: "false",
    children: n.jsx("g", {
      fill: "none",
      stroke: "currentColor",
      strokeWidth: "0.6",
      children: me(e).map((s, a) => n.jsx("path", { d: s }, a)),
    }),
  });
}
function pe({ kind: e }) {
  return n.jsx("svg", {
    className: "rc-suit",
    viewBox: "0 0 16 16",
    "aria-hidden": "true",
    focusable: "false",
    children:
      e === "chip"
        ? n.jsxs("g", {
            fill: "none",
            stroke: "currentColor",
            strokeWidth: "1.5",
            strokeLinecap: "round",
            children: [
              n.jsx("rect", {
                x: "4",
                y: "4",
                width: "8",
                height: "8",
                rx: "1.5",
                fill: "currentColor",
                fillOpacity: "0.25",
              }),
              n.jsx("path", {
                d: "M6 1.5v2.5M10 1.5v2.5M6 12v2.5M10 12v2.5M1.5 6h2.5M1.5 10h2.5M12 6h2.5M12 10h2.5",
              }),
            ],
          })
        : e === "brace"
          ? n.jsxs("g", {
              fill: "none",
              stroke: "currentColor",
              strokeWidth: "1.6",
              strokeLinecap: "round",
              strokeLinejoin: "round",
              children: [
                n.jsx("path", {
                  d: "M6 2.5C4 2.5 4.5 4 4.5 6S3.5 8 2.5 8c1 0 2 0 2 2s-.5 3.5 1.5 3.5",
                }),
                n.jsx("path", {
                  d: "M10 2.5c2 0 1.5 1.5 1.5 3.5s1 2 2 2c-1 0-2 0-2 2s.5 3.5-1.5 3.5",
                }),
              ],
            })
          : n.jsx("path", {
              d: "M8 1.5 9.6 6.4 14.5 8 9.6 9.6 8 14.5 6.4 9.6 1.5 8 6.4 6.4Z",
              fill: "currentColor",
            }),
  });
}
function ge({ seed: e, rank: t, suit: s }) {
  const a = n.jsxs(n.Fragment, {
    children: [
      t == null ? null : n.jsx("span", { className: "rc-rank", children: t }),
      n.jsx(pe, { kind: s }),
    ],
  });
  return n.jsxs("span", {
    className: "rc-face",
    "aria-hidden": "true",
    children: [
      n.jsx(xe, { seed: e }),
      n.jsx("span", { className: "rc-frame" }),
      n.jsx("span", {
        className: "rc-corner",
        "data-corner": "top",
        children: a,
      }),
      n.jsx("span", {
        className: "rc-corner",
        "data-corner": "bottom",
        children: a,
      }),
    ],
  });
}
function q() {
  const [e, t] = c.useState(0),
    s = c.useCallback(() => t((a) => a + 1), []);
  return { flip: e === 0 ? void 0 : e % 2 ? "a" : "b", turn: s };
}
function ye() {
  const [e, t] = c.useState(() => new Map()),
    s = c.useCallback(
      (r) => t((i) => new Map(i).set(r, (i.get(r) ?? 0) + 1)),
      [],
    );
  return {
    flipOf: c.useCallback(
      (r) => {
        const i = e.get(r) ?? 0;
        return i === 0 ? void 0 : i % 2 ? "a" : "b";
      },
      [e],
    ),
    turn: s,
  };
}
const G = ["again", "hard", "good", "easy"],
  $ = 6e4,
  D = 1440 * $,
  j = {
    learningSteps: [1, 10],
    relearningSteps: [10],
    graduatingInterval: 1,
    easyInterval: 4,
    startingEase: 2.5,
    minimumEase: 1.3,
    easyBonus: 1.3,
    hardInterval: 1.2,
    newInterval: 0,
    minimumInterval: 1,
    maximumInterval: 84,
    newCardsPerDay: 20,
    learnAheadMinutes: 20,
    nextDayStartsAt: 4,
  };
function I(e) {
  const t = new Date(e);
  return (
    t.setHours(j.nextDayStartsAt, 0, 0, 0),
    t.getTime() > e && t.setDate(t.getDate() - 1),
    t.getTime()
  );
}
function P(e) {
  const t = new Date(I(e));
  return (t.setDate(t.getDate() + 1), t.getTime());
}
function V(e) {
  const t = new Date(I(e));
  return `${t.getFullYear()}-${t.getMonth() + 1}-${t.getDate()}`;
}
function be(e, t) {
  return I(e) + t * D;
}
function we(e, t) {
  if (!t) return null;
  const [s, a, r] = t.split("-").map(Number);
  if (!s || !a || !r) return null;
  const i = new Date(s, a - 1, r, j.nextDayStartsAt).getTime(),
    u = Math.round((i - I(e)) / D) - 1;
  return u >= 0 ? u : null;
}
function z(e, t, s) {
  const a = we(t, s.examOn),
    r = Math.min(j.maximumInterval, a ?? Number.POSITIVE_INFINITY);
  return Math.max(j.minimumInterval, Math.min(r, Math.round(e)));
}
function S(e, t, s, a, r) {
  const i = z(t, s, r);
  return {
    type: "review",
    step: 0,
    due: be(s, i),
    interval: i,
    ease: a,
    reps: (e?.reps ?? 0) + 1,
    lapses: e?.lapses ?? 0,
  };
}
function C(e, t, s, a, r) {
  return {
    type: t,
    step: s,
    due: r + Math.round(a * $),
    interval: e?.interval ?? 0,
    ease: e?.ease ?? j.startingEase,
    reps: (e?.reps ?? 0) + 1,
    lapses: e?.lapses ?? 0,
  };
}
function H(e, t) {
  const s = e[t] ?? e[0] ?? 1;
  if (t !== 0) return s;
  const a = e[1];
  return a === void 0 ? Math.min(s * 1.5, s + D / $) : (s + a) / 2;
}
function ee(e, t, s, a = {}) {
  const r = j;
  if (!e || e.type === "learning") {
    const o = r.learningSteps,
      l = e?.step ?? 0,
      d = e?.ease ?? r.startingEase;
    switch (t) {
      case "again":
        return C(e, "learning", 0, o[0], s);
      case "hard":
        return C(e, "learning", l, H(o, l), s);
      case "good":
        return l + 1 < o.length
          ? C(e, "learning", l + 1, o[l + 1] ?? o[0], s)
          : S(e, r.graduatingInterval, s, d, a);
      case "easy":
        return S(e, r.easyInterval, s, d, a);
    }
  }
  if (e.type === "relearning") {
    const o = r.relearningSteps;
    switch (t) {
      case "again":
        return C(e, "relearning", 0, o[0], s);
      case "hard":
        return C(e, "relearning", e.step, H(o, e.step), s);
      case "good":
        return e.step + 1 < o.length
          ? C(e, "relearning", e.step + 1, o[e.step + 1] ?? o[0], s)
          : S(e, e.interval, s, e.ease, a);
      case "easy":
        return S(e, e.interval + 1, s, e.ease, a);
    }
  }
  const i = Math.max(0, Math.floor((I(s) - e.due) / D)),
    u = Math.max(e.interval + 1, e.interval * r.hardInterval),
    h = Math.max(u + 1, (e.interval + i / 2) * e.ease),
    f = Math.max(h + 1, (e.interval + i) * e.ease * r.easyBonus);
  switch (t) {
    case "again": {
      const o = {
        ...e,
        interval: z(e.interval * r.newInterval, s, a),
        ease: Math.max(r.minimumEase, e.ease - 0.2),
        lapses: e.lapses + 1,
      };
      return C(o, "relearning", 0, r.relearningSteps[0], s);
    }
    case "hard":
      return S(e, u, s, Math.max(r.minimumEase, e.ease - 0.15), a);
    case "good":
      return S(e, h, s, e.ease, a);
    case "easy":
      return S(e, f, s, e.ease + 0.15, a);
  }
}
function ve(e, t, s, a = {}) {
  const r = ee(e, t, s, a);
  return r.type === "review" ? F(r.interval) : te(r.due - s);
}
function te(e) {
  const t = e / $;
  if (t < 1) return "<1m";
  if (t < 60) return `${Math.round(t)}m`;
  const s = t / 60;
  return s < 24 ? `${T(s)}h` : F(e / D);
}
function F(e) {
  return e < 30
    ? `${Math.round(e)}d`
    : e < 365
      ? `${T(e / 30)}mo`
      : `${T(e / 365)}y`;
}
function T(e) {
  return (Math.round(e * 10) / 10).toString();
}
c.createContext(null);
c.createContext(null);
c.createContext(null);
c.createContext(null);
const je = c.createContext(null),
  Me = c.createContext(!1),
  L = "comp-school-fallback-access";
function Ne() {
  if (typeof window > "u") return null;
  const e = new URLSearchParams(window.location.hash.replace(/^#/, "")),
    t = e.get("fallback");
  if (t && Y(t)) {
    (window.sessionStorage.setItem(L, t), e.delete("fallback"));
    const a = e.toString();
    window.history.replaceState(
      {},
      "",
      `${window.location.pathname}${window.location.search}${a ? `#${a}` : ""}`,
    );
  }
  const s = t || window.sessionStorage.getItem(L);
  return Y(s) ? s : (window.sessionStorage.removeItem(L), null);
}
function se() {
  return !!Ne();
}
function Je() {
  return se();
}
function Se() {
  return c.useContext(Me);
}
function Ze() {
  const e = Se(),
    t = Ce();
  return e && !ae(t);
}
function Ce() {
  return c.useContext(je);
}
function Ee(e, t) {
  return (
    e
      .filter(
        (s) =>
          s.kind === "exam" &&
          /^\d{4}-\d{2}-\d{2}$/.test(s.date) &&
          s.date >= t,
      )
      .map((s) => s.date)
      .sort()[0] ?? null
  );
}
function ke() {
  const e = new Date(),
    t = (s) => String(s).padStart(2, "0");
  return `${e.getFullYear()}-${t(e.getMonth() + 1)}-${t(e.getDate())}`;
}
let J = null;
function De() {
  return se()
    ? Promise.resolve(null)
    : ((J ??= Promise.resolve()
        .then(re)
        .then((e) => Ee(e.keyDates ?? [], ke()))
        .catch(() => null)),
      J);
}
function Ie() {
  const [e, t] = c.useState(null);
  return (
    c.useEffect(() => {
      let s = !0;
      return (
        De().then((a) => {
          s && t(a);
        }),
        () => {
          s = !1;
        }
      );
    }, []),
    e
  );
}
const O = {
    key: "comp-school:flashcards:v1",
    storage: () => window.localStorage,
  },
  Ae = () => ({ cards: {}, newToday: {} });
function $e(e = O) {
  try {
    const t = JSON.parse(e.storage().getItem(e.key) ?? "null");
    if (t && typeof t == "object" && "cards" in t && "newToday" in t) return t;
  } catch {}
  return Ae();
}
function Le(e, t = O) {
  try {
    t.storage().setItem(t.key, JSON.stringify(e));
  } catch {}
}
function R(e, t, s) {
  const a = e.newToday[t.code];
  return a && a.day === V(s) ? a.count : 0;
}
function Te(e, t, s) {
  return { ...e.newToday, [t.code]: { day: V(s), count: R(e, t, s) + 1 } };
}
function Pe(e, t, s, a = j.newCardsPerDay) {
  const r = P(s);
  let i = 0,
    u = 0,
    h = 0;
  for (const o of t.cards) {
    const l = e.cards[o.id];
    l
      ? l.type !== "review"
        ? (u += l.due < r ? 1 : 0)
        : l.due < r && (h += 1)
      : (i += 1);
  }
  const f = Math.max(0, a - R(e, t, s));
  return { new: Math.min(i, f), learning: u, review: h };
}
function Fe(e, t, s, a = j.newCardsPerDay) {
  const r = P(s),
    i = s + j.learnAheadMinutes * 6e4,
    u = (l) =>
      l.sort((d, g) => (e.cards[d.id]?.due ?? 0) - (e.cards[g.id]?.due ?? 0)),
    h = u(t.cards.filter((l) => Re(e.cards[l.id]))),
    f = h.find((l) => (e.cards[l.id]?.due ?? 0) <= s);
  if (f) return f;
  const o = u(
    t.cards.filter(
      (l) => e.cards[l.id]?.type === "review" && (e.cards[l.id]?.due ?? 0) < r,
    ),
  );
  if (o[0]) return o[0];
  if (R(e, t, s) < a) {
    const l = t.cards.find((d) => !e.cards[d.id]);
    if (l) return l;
  }
  return h.find((l) => (e.cards[l.id]?.due ?? 0) <= i) ?? null;
}
function Oe(e, t) {
  let s = null;
  for (const a of t.cards) {
    const r = e.cards[a.id]?.due;
    r !== void 0 && (s === null || r < s) && (s = r);
  }
  return s;
}
function Re(e) {
  return e?.type === "learning" || e?.type === "relearning";
}
const Ke = { again: "Again", hard: "Hard", good: "Good", easy: "Easy" };
function Qe({
  deck: e,
  art: t,
  embedded: s = !1,
  onReveal: a,
  onGrade: r,
  overview: i,
  storeLocation: u = O,
  pattern: h = !0,
}) {
  const [f, o] = c.useState("mastery"),
    [l, d] = c.useState(() => $e(u)),
    [g, y] = c.useState(() => Date.now()),
    w = Ue(),
    v = u.newCardsPerDay ?? j.newCardsPerDay,
    M = Pe(l, e, g, v),
    N = c.useCallback(
      (m, b) => {
        (Le(m, u), d(m), y(b));
      },
      [u],
    );
  return n.jsxs("div", {
    className: "flashcards",
    "data-flashcards": e.code,
    "data-flashcards-mode": f,
    "data-flashcards-layout": f === "overview" && w ? "grid" : "single",
    "data-flashcards-embedded": s ? "" : void 0,
    "data-flashcards-overview": i ? "custom" : void 0,
    "data-flashcards-pattern": h ? void 0 : "off",
    children: [
      n.jsxs("header", {
        className: "flashcards-header",
        children: [
          n.jsx("p", {
            className:
              "min-w-0 flex-1 truncate text-sm font-semibold text-slate-200",
            children:
              e.label ?? (e.code === "all" ? e.title : `${e.code} ${e.title}`),
          }),
          f === "mastery" ? n.jsx(_e, { counts: M }) : null,
        ],
      }),
      n.jsxs("div", {
        className: "flashcards-tabs",
        role: "tablist",
        "aria-label": "Mode",
        children: [
          n.jsx(Q, {
            mode: "mastery",
            current: f,
            onSelect: o,
            label: "Mastery",
            Icon: le,
          }),
          n.jsx(Q, {
            mode: "overview",
            current: f,
            onSelect: o,
            label: "Overview",
            Icon: ie,
          }),
        ],
      }),
      n.jsx("div", {
        className: "flashcards-body",
        role: "tabpanel",
        id: "flashcards-panel",
        "aria-labelledby": `flashcards-tab-${f}`,
        children:
          f === "mastery"
            ? n.jsx(We, {
                art: t,
                deck: e,
                store: l,
                now: g,
                newCardsPerDay: v,
                onTick: y,
                onAnswer: N,
                onReveal: a,
                onGrade: r,
                eyebrows: !s,
              })
            : i ||
              (w
                ? n.jsx(Ye, { art: t, deck: e, onReveal: a, eyebrows: !s })
                : n.jsx(Be, { art: t, deck: e, onReveal: a, eyebrows: !s })),
      }),
    ],
  });
}
const Z = [
  { key: "new", label: "New", tone: "text-sky-400" },
  { key: "learning", label: "Learning", tone: "text-rose-400" },
  { key: "review", label: "To review", tone: "text-emerald-400" },
];
function _e({ counts: e }) {
  const [t, s] = c.useState(!1),
    a = c.useRef(null);
  return (
    c.useEffect(() => {
      if (!t) return;
      const r = (u) => {
          (u.preventDefault(), u.stopPropagation());
        },
        i = (u) => {
          if (u instanceof KeyboardEvent) {
            u.key === "Escape" && s(!1);
            return;
          }
          a.current?.contains(u.target) ||
            (window.addEventListener("click", r, { capture: !0, once: !0 }),
            window.setTimeout(
              () => window.removeEventListener("click", r, { capture: !0 }),
              600,
            ),
            s(!1));
        };
      return (
        document.addEventListener("pointerdown", i),
        document.addEventListener("keydown", i),
        () => {
          (document.removeEventListener("pointerdown", i),
            document.removeEventListener("keydown", i));
        }
      );
    }, [t]),
    n.jsxs("div", {
      ref: a,
      className: "flashcards-counts",
      children: [
        n.jsx("button", {
          type: "button",
          onClick: () => s((r) => !r),
          "aria-expanded": t,
          "aria-controls": "flashcards-counts-tip",
          className:
            "flashcards-counts-button flex shrink-0 gap-2.5 text-sm font-semibold tabular-nums",
          "data-flashcards-counts": !0,
          children: Z.map(({ key: r, label: i, tone: u }) =>
            n.jsxs(
              "span",
              {
                className: u,
                children: [
                  n.jsxs("span", { className: "sr-only", children: [i, " "] }),
                  e[r],
                ],
              },
              r,
            ),
          ),
        }),
        t
          ? n.jsx("div", {
              id: "flashcards-counts-tip",
              role: "tooltip",
              className: "flashcards-counts-tip",
              "data-flashcards-counts-tip": !0,
              children: Z.map(({ key: r, label: i, tone: u }) =>
                n.jsxs(
                  "p",
                  {
                    className:
                      "flex items-center justify-between gap-6 text-sm",
                    children: [
                      n.jsx("span", {
                        className: "text-slate-200",
                        children: i,
                      }),
                      n.jsx("span", {
                        className: `font-semibold tabular-nums ${u}`,
                        children: e[r],
                      }),
                    ],
                  },
                  r,
                ),
              ),
            })
          : null,
      ],
    })
  );
}
function Q({ mode: e, current: t, onSelect: s, label: a, Icon: r }) {
  const i = e === t;
  return n.jsxs("button", {
    type: "button",
    role: "tab",
    id: `flashcards-tab-${e}`,
    "aria-selected": i,
    "aria-controls": "flashcards-panel",
    onClick: () => s(e),
    className: `flex min-h-11 flex-1 items-center justify-center gap-2 rounded-lg text-sm font-semibold transition focus:outline-none focus-visible:ring-2 focus-visible:ring-teal-300 ${i ? "bg-teal-400/15 text-teal-200" : "text-slate-400 hover:text-slate-200"}`,
    "data-flashcards-tab": e,
    children: [n.jsx(r, { "aria-hidden": "true", className: "h-5 w-5" }), a],
  });
}
function We({
  art: e,
  deck: t,
  store: s,
  now: a,
  newCardsPerDay: r,
  onTick: i,
  onAnswer: u,
  onReveal: h,
  onGrade: f,
  eyebrows: o,
}) {
  const l = c.useMemo(() => Fe(s, t, a, r), [s, t, a, r]),
    [d, g] = c.useState(!1),
    { flip: y, turn: w } = q();
  c.useEffect(() => {
    d && w();
  }, [d, w]);
  const v = Ie(),
    M = c.useRef(Date.now()),
    N = l?.id ?? null;
  (c.useEffect(() => {
    M.current = Date.now();
  }, [N]),
    c.useEffect(() => {
      d && l && h?.(l);
    }, [d, l, h]),
    c.useEffect(() => {
      if (l) return;
      const x = window.setInterval(() => i(Date.now()), 15e3);
      return () => window.clearInterval(x);
    }, [l, i]));
  const m = c.useCallback(
    (x) => {
      if (!l) return;
      const p = Date.now(),
        A = s.cards[l.id];
      (u(
        {
          cards: { ...s.cards, [l.id]: ee(A, x, p, { examOn: v }) },
          newToday: A ? s.newToday : Te(s, t, p),
        },
        p,
      ),
        g(!1),
        f?.(l, x, p - M.current));
    },
    [l, t, s, u, f, v],
  );
  if (
    (c.useEffect(() => {
      const x = (p) => {
        if (
          !(!l || p.altKey || p.ctrlKey || p.metaKey) &&
          !(
            p.target instanceof HTMLElement &&
            p.target.closest("button, a, input, [data-session-sidebar]")
          )
        ) {
          if (!d && (p.key === " " || p.key === "Enter"))
            (p.preventDefault(), g(!0));
          else if (d) {
            const A = ["1", "2", "3", "4"].indexOf(p.key),
              U = p.key === " " || p.key === "Enter" ? "good" : G[A];
            U && (p.preventDefault(), m(U));
          }
        }
      };
      return (
        window.addEventListener("keydown", x),
        () => window.removeEventListener("keydown", x)
      );
    }, [l, d, m]),
    !l)
  ) {
    const x = Oe(s, t);
    return n.jsxs("div", {
      className:
        "flex flex-1 flex-col items-center justify-center gap-3 px-6 text-center",
      "data-flashcards-done": !0,
      children: [
        n.jsx("span", {
          className:
            "flex h-14 w-14 items-center justify-center rounded-full bg-teal-400/15 text-teal-300",
          children: n.jsx(oe, { "aria-hidden": "true", className: "h-7 w-7" }),
        }),
        n.jsx("h2", {
          className: "text-xl font-semibold text-slate-50",
          children: "Congratulations! You have finished this deck for now.",
        }),
        x !== null
          ? n.jsxs("p", {
              className: "text-sm text-slate-400",
              children: ["Next card in ", Ge(x, a)],
            })
          : null,
      ],
    });
  }
  const b = s.cards[l.id];
  return n.jsxs(n.Fragment, {
    children: [
      n.jsxs("button", {
        type: "button",
        className: "flashcards-stage rc-card",
        onClick: () => g(!0),
        "aria-label": d ? void 0 : "Show answer",
        disabled: d,
        "data-flashcard": l.id,
        "data-flip": y,
        children: [
          n.jsx(K, { card: l }),
          n.jsx(W, {
            art: e,
            card: l,
            side: d ? "answer" : "term",
            eyebrows: o,
          }),
        ],
      }),
      n.jsx("div", {
        className: "flashcards-actions",
        children: d
          ? n.jsx("div", {
              className: "grid grid-cols-4 gap-2",
              "data-flashcards-grades": !0,
              children: G.map((x) =>
                n.jsxs(
                  "button",
                  {
                    type: "button",
                    onClick: () => m(x),
                    className: `flashcards-grade flashcards-grade-${x}`,
                    "data-flashcards-grade": x,
                    children: [
                      n.jsx("span", {
                        className:
                          "text-xs font-medium tabular-nums opacity-80",
                        children: ve(b, x, a, { examOn: v }),
                      }),
                      n.jsx("span", {
                        className: "text-sm font-semibold",
                        children: Ke[x],
                      }),
                    ],
                  },
                  x,
                ),
              ),
            })
          : n.jsx("button", {
              type: "button",
              onClick: () => g(!0),
              className:
                "h-14 w-full rounded-xl bg-teal-400 text-base font-semibold text-slate-950 active:scale-[0.99] focus:outline-none focus-visible:ring-2 focus-visible:ring-teal-200",
              "data-flashcards-show": !0,
              children: "Show answer",
            }),
      }),
    ],
  });
}
const X = "(min-width: 1024px)";
function Ue() {
  const [e, t] = c.useState(() => window.matchMedia?.(X).matches ?? !0);
  return (
    c.useEffect(() => {
      const s = window.matchMedia?.(X);
      if (!s) return;
      const a = () => t(s.matches);
      return (
        s.addEventListener("change", a),
        () => s.removeEventListener("change", a)
      );
    }, []),
    e
  );
}
function Ye({ art: e, deck: t, onReveal: s, eyebrows: a }) {
  const [r, i] = c.useState(() => new Map()),
    { flipOf: u, turn: h } = ye(),
    f = (o) => {
      (s?.(o),
        h(o.id),
        i((l) => new Map(l).set(o.id, ne(o, l.get(o.id) ?? 0))));
    };
  return n.jsx("ul", {
    className: "flashcards-grid",
    "aria-label": `${t.cards.length} cards`,
    "data-flashcards-grid": !0,
    children: t.cards.map((o) => {
      const l = _(o)[r.get(o.id) ?? 0] ?? "term";
      return n.jsx(
        "li",
        {
          className: "flex",
          children: n.jsxs("button", {
            type: "button",
            className: "flashcards-tile rc-card",
            onClick: () => f(o),
            "aria-label": `${o.term}: ${l}`,
            "data-flashcard": o.id,
            "data-flip": u(o.id),
            children: [
              n.jsx(K, { card: o }),
              n.jsx(W, { art: e, card: o, side: l, eyebrows: a }),
            ],
          }),
        },
        o.id,
      );
    }),
  });
}
function Be({ art: e, deck: t, onReveal: s, eyebrows: a }) {
  const [r, i] = c.useState(0),
    [u, h] = c.useState(0),
    { flip: f, turn: o } = q(),
    l = c.useRef(null),
    d = t.cards[r] ?? t.cards[0],
    g = t.cards.length - 1,
    y = c.useCallback(
      (m) => {
        (i((b) => Math.min(g, Math.max(0, b + m))), h(0));
      },
      [g],
    );
  c.useEffect(() => {
    const m = (b) => {
      (b.target instanceof HTMLElement &&
        b.target.closest("[data-session-sidebar]")) ||
        (b.key === "ArrowLeft" ? y(-1) : b.key === "ArrowRight" && y(1));
    };
    return (
      window.addEventListener("keydown", m),
      () => window.removeEventListener("keydown", m)
    );
  }, [y]);
  const w = (m) => {
      l.current = m.clientX;
    },
    v = (m) => {
      const b = l.current;
      if (((l.current = null), b === null)) return;
      const x = m.clientX - b;
      Math.abs(x) > 60 ? y(x < 0 ? 1 : -1) : N();
    };
  if (!d) return n.jsx(n.Fragment, {});
  const M = _(d)[u] ?? "term";
  function N() {
    d && (s?.(d), h((m) => ne(d, m)), o());
  }
  return n.jsxs(n.Fragment, {
    children: [
      n.jsxs("button", {
        type: "button",
        className: "flashcards-stage rc-card",
        onPointerDown: w,
        onPointerUp: v,
        onPointerCancel: () => (l.current = null),
        onKeyDown: (m) => {
          (m.key === "Enter" || m.key === " ") && (m.preventDefault(), N());
        },
        "aria-label": `${d.term}: ${M}`,
        "data-flashcard": d.id,
        "data-flip": f,
        children: [
          n.jsx(K, { card: d }),
          n.jsx(W, { art: e, card: d, side: M, eyebrows: a }),
        ],
      }),
      n.jsxs("div", {
        className: "flashcards-actions flex items-center justify-between gap-3",
        children: [
          n.jsx("button", {
            type: "button",
            onClick: () => y(-1),
            disabled: r === 0,
            "aria-label": "Previous card",
            className: "flashcards-step",
            children: n.jsx(ce, {
              "aria-hidden": "true",
              className: "h-6 w-6",
            }),
          }),
          n.jsxs("p", {
            className: "text-sm font-semibold tabular-nums text-slate-300",
            "data-flashcards-position": !0,
            children: [r + 1, " / ", t.cards.length],
          }),
          n.jsx("button", {
            type: "button",
            onClick: () => y(1),
            disabled: r === g,
            "aria-label": "Next card",
            className: "flashcards-step",
            children: n.jsx(ue, {
              "aria-hidden": "true",
              className: "h-6 w-6",
            }),
          }),
        ],
      }),
    ],
  });
}
function K({ card: e }) {
  const t = e.deck.startsWith("1")
      ? "chip"
      : e.deck.startsWith("2")
        ? "brace"
        : "spark",
    s = e.deck.startsWith("btec-") ? e.deck.slice(5).toUpperCase() : e.deck;
  return n.jsx(ge, { seed: e.id, rank: s, suit: t });
}
function _(e) {
  return e.example ? ["term", "definition", "example"] : ["term", "definition"];
}
function ne(e, t) {
  return (t + 1) % _(e).length;
}
function W({ art: e, card: t, side: s, eyebrows: a = !0 }) {
  const r = a ? "flashcards-eyebrow" : "sr-only",
    i = e(t),
    u = s === "definition" || s === "answer",
    h = (s === "example" || s === "answer") && t.example;
  return n.jsxs("span", {
    className: "flashcards-card",
    "data-flashcard-side": s === "term" ? "front" : "back",
    "data-flashcard-face": s,
    children: [
      i
        ? n.jsx("img", {
            src: i,
            alt: "",
            "aria-hidden": "true",
            className: "flashcards-art",
            draggable: !1,
          })
        : null,
      n.jsx("span", { className: "flashcards-term", children: t.term }),
      s === "term"
        ? null
        : n.jsxs("span", {
            className: "flashcards-answer",
            "data-flashcard-answer": !0,
            children: [
              u
                ? n.jsxs("span", {
                    className: "flashcards-section",
                    "data-flashcard-section": "definition",
                    children: [
                      n.jsx("span", { className: r, children: "Definition" }),
                      n.jsx("span", {
                        className: "flashcards-definition",
                        children: t.definition,
                      }),
                    ],
                  })
                : null,
              h
                ? n.jsxs("span", {
                    className: "flashcards-section flashcards-example-section",
                    "data-flashcard-section": "example",
                    children: [
                      n.jsx("span", { className: r, children: "Example" }),
                      n.jsx("span", {
                        className: "flashcards-example",
                        children: t.example,
                      }),
                    ],
                  })
                : null,
            ],
          }),
    ],
  });
}
function Ge(e, t) {
  return e < P(t) ? te(Math.max(0, e - t)) : F(Math.round((e - I(t)) / D));
}
export { Qe as F, se as a, Ze as b, Je as i, Ne as r, Ce as u };
