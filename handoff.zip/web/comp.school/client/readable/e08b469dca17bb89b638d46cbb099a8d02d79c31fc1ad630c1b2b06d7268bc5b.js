var Ul = (e, t) => () => (
  t || (e((t = { exports: {} }).exports, t, t.exports), (e = null)),
  t.exports
);
function Mt(e) {
  "@babel/helpers - typeof";
  return (
    (Mt =
      typeof Symbol == "function" && typeof Symbol.iterator == "symbol"
        ? function (t) {
            return typeof t;
          }
        : function (t) {
            return t &&
              typeof Symbol == "function" &&
              t.constructor === Symbol &&
              t !== Symbol.prototype
              ? "symbol"
              : typeof t;
          }),
    Mt(e)
  );
}
function Gl(e, t) {
  if (Mt(e) != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (Mt(n) != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
function jl(e) {
  var t = Gl(e, "string");
  return Mt(t) == "symbol" ? t : t + "";
}
function p(e, t, r) {
  return (
    (t = jl(t)) in e
      ? Object.defineProperty(e, t, {
          value: r,
          enumerable: !0,
          configurable: !0,
          writable: !0,
        })
      : (e[t] = r),
    e
  );
}
var Ut = class {
    constructor(e) {
      (p(this, "rootKey", void 0), (this.rootKey = e));
    }
    get writtenAs() {}
  },
  qa = (e) =>
    e instanceof Ut ||
    (typeof e == "object" && e !== null && typeof e.prepForXml == "function"),
  Gt = (e) => (qa(e) ? e.rootKey : void 0),
  Vl = Object.seal({}),
  y = class extends Ut {
    constructor(e) {
      (super(e), p(this, "root", void 0), (this.root = new Array()));
    }
    prepForXml(e) {
      var t;
      e.stack.push(this);
      const r = this.root
        .flatMap((n) => {
          if (qa(n)) {
            const s = n.writtenAs;
            return s ? s.map((a) => a.prepForXml(e)) : n.prepForXml(e);
          }
          return n;
        })
        .filter((n) => n !== void 0);
      return (
        e.stack.pop(),
        {
          [this.rootKey]: r.length
            ? r.length === 1 &&
              !((t = r[0]) === null || t === void 0) &&
              t._attr
              ? r[0]
              : r
            : Vl,
        }
      );
    }
    addChildElement(e) {
      return (this.root.push(e), this);
    }
  },
  Ze = class extends y {
    constructor(e, t) {
      (super(e), p(this, "includeIfEmpty", void 0), (this.includeIfEmpty = t));
    }
    prepForXml(e) {
      const t = super.prepForXml(e);
      return this.includeIfEmpty ||
        (t &&
          (typeof t[this.rootKey] != "object" ||
            Object.keys(t[this.rootKey]).length))
        ? t
        : void 0;
    }
  };
function Rs(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    (t &&
      (n = n.filter(function (s) {
        return Object.getOwnPropertyDescriptor(e, s).enumerable;
      })),
      r.push.apply(r, n));
  }
  return r;
}
function f(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2
      ? Rs(Object(r), !0).forEach(function (n) {
          p(e, n, r[n]);
        })
      : Object.getOwnPropertyDescriptors
        ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
        : Rs(Object(r)).forEach(function (n) {
            Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
          });
  }
  return e;
}
var _ = class extends Ut {
    constructor(e) {
      (super("_attr"),
        p(this, "root", void 0),
        p(this, "xmlKeys", void 0),
        (this.root = e));
    }
    prepForXml(e) {
      const t = {};
      return (
        Object.entries(this.root).forEach(([r, n]) => {
          if (n !== void 0) {
            const s = (this.xmlKeys && this.xmlKeys[r]) || r;
            t[s] = n;
          }
        }),
        { _attr: t }
      );
    }
  },
  Sr = class extends Ut {
    constructor(e) {
      (super("_attr"), p(this, "root", void 0), (this.root = e));
    }
    prepForXml(e) {
      return {
        _attr: Object.values(this.root)
          .filter(({ value: t }) => t !== void 0)
          .reduce((t, { key: r, value: n }) => f(f({}, t), {}, { [r]: n }), {}),
      };
    }
  },
  pe = class extends _ {
    constructor(...e) {
      (super(...e),
        p(this, "xmlKeys", {
          val: "w:val",
          color: "w:color",
          fill: "w:fill",
          space: "w:space",
          sz: "w:sz",
          type: "w:type",
          rsidR: "w:rsidR",
          rsidRPr: "w:rsidRPr",
          rsidSect: "w:rsidSect",
          w: "w:w",
          h: "w:h",
          top: "w:top",
          right: "w:right",
          bottom: "w:bottom",
          left: "w:left",
          header: "w:header",
          footer: "w:footer",
          gutter: "w:gutter",
          linePitch: "w:linePitch",
          pos: "w:pos",
        }));
    }
  };
function Xl(e, t) {
  if (e == null) return {};
  var r = {};
  for (var n in e)
    if ({}.hasOwnProperty.call(e, n)) {
      if (t.includes(n)) continue;
      r[n] = e[n];
    }
  return r;
}
function jt(e, t) {
  if (e == null) return {};
  var r,
    n,
    s = Xl(e, t);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    for (n = 0; n < a.length; n++)
      ((r = a[n]),
        t.includes(r) || ({}.propertyIsEnumerable.call(e, r) && (s[r] = e[r])));
  }
  return s;
}
var Kl = ["elements"],
  zl = new Map([
    ["amp", "&"],
    ["lt", "<"],
    ["gt", ">"],
    ["quot", '"'],
    ["apos", "'"],
  ]),
  Yl = /&([^;]*);?/g,
  Ja = (e) =>
    e.indexOf("&") === -1
      ? e
      : e.replace(Yl, (t, r) => {
          if (!t.endsWith(";"))
            throw new Error(
              `Invalid XML: "&" that starts no entity, in "${e}"`,
            );
          const n = zl.get(r);
          if (n !== void 0) return n;
          const s = /^#x[0-9a-f]+$/i.test(r)
            ? parseInt(r.slice(2), 16)
            : /^#[0-9]+$/.test(r)
              ? parseInt(r.slice(1), 10)
              : NaN;
          if (!(s > 0 && s <= 1114111))
            throw new Error(`Invalid XML: unknown entity "${t}"`);
          return String.fromCodePoint(s);
        }),
  ir = (e) =>
    e === " " ||
    e ===
      `
` ||
    e === "	" ||
    e === "\r",
  ql = /([\w:-]+)\s*=\s*(?:"([^"]*)"|'([^']*)')/g,
  Jl = (e) =>
    Object.fromEntries([...e.matchAll(ql)].map(([, t, r, n]) => [t, r ?? n])),
  bt = (e, { keepWhitespaceText: t = !1 } = {}) => {
    const r = {},
      n = [];
    let s = e.charCodeAt(0) === 65279 ? 1 : 0;
    for (; s < e.length && ir(e[s]);) s++;
    const a = (d) => {
        var h;
        const w = n.length === 0 ? r : n[n.length - 1];
        ((h = w.elements) !== null && h !== void 0
          ? h
          : (w.elements = [])
        ).push(d);
      },
      o = (d) => {
        if (d.trim() === "") {
          d !== "" && t && a({ type: "text", text: d });
          return;
        }
        if (n.length === 0)
          throw new Error(
            `Invalid XML: text outside of the root element, "${d.trim()}"`,
          );
        a({ type: "text", text: Ja(d) });
      },
      i = (d, h, w) => {
        const m = e.indexOf(d, h);
        if (m === -1) throw new Error(`Invalid XML: ${w} that isn't closed`);
        return m;
      };
    for (; s < e.length;) {
      const d = e.indexOf("<", s);
      if ((o(e.slice(s, d === -1 ? e.length : d)), d === -1)) break;
      if (e.startsWith("<?", d)) {
        const h = i("?>", d + 2, "processing instruction"),
          w = e.slice(d + 2, h),
          m = w.search(/\s/),
          v = m === -1 ? w : w.slice(0, m),
          g = m === -1 ? "" : w.slice(m).trimStart();
        if (v.toLowerCase() === "xml") {
          const A = Jl(g);
          r.declaration = Object.keys(A).length > 0 ? { attributes: A } : {};
        } else a({ type: "instruction", name: v, instruction: g });
        s = h + 2;
      } else if (e.startsWith("<!--", d)) {
        const h = i("-->", d + 4, "comment"),
          w = e.slice(d + 4, h);
        (w !== "" && a({ type: "comment", comment: w }), (s = h + 3));
      } else if (e.startsWith("<![CDATA[", d)) {
        const h = i("]]>", d + 9, "CDATA section"),
          w = e.slice(d + 9, h);
        (w !== "" && a({ type: "cdata", cdata: w }), (s = h + 3));
      } else if (e.startsWith("<!DOCTYPE", d)) {
        let h = d + 9,
          w,
          m = !1;
        for (; h < e.length; h++) {
          const v = e[h];
          if (w !== void 0) w = v === w ? void 0 : w;
          else if (v === '"' || v === "'") w = v;
          else if (v === "[") m = !0;
          else if (v === "]") m = !1;
          else if (v === ">" && !m) break;
        }
        if (h === e.length)
          throw new Error("Invalid XML: DOCTYPE that isn't closed");
        (a({ type: "doctype", doctype: e.slice(d + 9, h).replace(/^ /, "") }),
          (s = h + 1));
      } else if (e.startsWith("</", d)) {
        const h = i(">", d + 2, "closing tag"),
          w = e.slice(d + 2, h).trimEnd(),
          m = n.pop();
        if (m?.name !== w) {
          var l;
          throw new Error(
            `Invalid XML: closing tag </${w}> doesn't match <${(l = m?.name) !== null && l !== void 0 ? l : ""}>`,
          );
        }
        s = h + 1;
      } else
        s = Zl(e, d + 1, (h, w) => {
          (a(h), w || n.push(h));
        });
    }
    if (n.length > 0)
      throw new Error(`Invalid XML: <${n[n.length - 1].name}> isn't closed`);
    const { elements: c } = r,
      u = jt(r, Kl);
    return c === void 0 ? u : f(f({}, u), {}, { elements: c });
  },
  Zl = (e, t, r) => {
    let n = t;
    for (; n < e.length && !ir(e[n]) && e[n] !== "/" && e[n] !== ">";) n++;
    const s = e.slice(t, n);
    if (s === "") throw new Error("Invalid XML: tag without a name");
    const a = [];
    let o = n;
    for (;;) {
      for (; o < e.length && ir(e[o]);) o++;
      if (o >= e.length)
        throw new Error(`Invalid XML: <${s}> that isn't closed`);
      if (e[o] === ">" || e.startsWith("/>", o)) {
        const h = e[o] === "/";
        return (
          r(
            f(
              { type: "element", name: s },
              a.length > 0 ? { attributes: Object.fromEntries(a) } : {},
            ),
            h,
          ),
          o + (h ? 2 : 1)
        );
      }
      const i = e.indexOf("=", o),
        l = e.slice(o, i === -1 ? e.length : i).trimEnd();
      if (i === -1 || l === "" || /[\s/>]/.test(l))
        throw new Error(`Invalid XML: attribute of <${s}> without a value`);
      let c = i + 1;
      for (; c < e.length && ir(e[c]);) c++;
      const u = e[c];
      if (u !== '"' && u !== "'")
        throw new Error(`Invalid XML: value of ${l} on <${s}> isn't quoted`);
      const d = e.indexOf(u, c + 1);
      if (d === -1)
        throw new Error(`Invalid XML: value of ${l} on <${s}> isn't closed`);
      (a.some(([h]) => h === l) || a.push([l, Ja(e.slice(c + 1, d))]),
        (o = d + 1));
    }
  },
  Za = new Map([
    ["&", "&amp;"],
    ['"', "&quot;"],
    ["'", "&apos;"],
    ["<", "&lt;"],
    [">", "&gt;"],
  ]),
  vr = (e) =>
    e.replace(/[&"'<>\x00-\x08\x0B\x0C\x0E-\x1F]/g, (t) => {
      var r;
      return (r = Za.get(t)) !== null && r !== void 0 ? r : "";
    }),
  Ql = (e) =>
    e.replace(/[&<>\x00-\x08\x0B\x0C\x0E-\x1F]/g, (t) => {
      var r;
      return (r = Za.get(t)) !== null && r !== void 0 ? r : "";
    }),
  Hr = (e) => (typeof e == "string" ? vr(e) : e),
  Qa = (e, t, r) => {
    const n = Object.keys(e)[0],
      s = n === void 0 ? void 0 : e[n],
      a = [],
      o = [],
      i = (l) => {
        for (const [c, u] of Object.entries(l))
          a.push(`${c}="${String(Hr(u))}"`);
      };
    if (typeof s == "object") {
      if (s !== null) {
        const { _attr: l, _cdata: c } = s;
        if (
          (l && i(l),
          c && o.push(`<![CDATA[${c.replace(/\]\]>/g, "]]]]><![CDATA[>")}]]>`),
          Array.isArray(s))
        ) {
          let u = !1;
          o.push("");
          for (const d of s)
            typeof d == "object"
              ? Object.keys(d)[0] === "_attr"
                ? i(d._attr)
                : o.push(Qa(d, t, r + 1))
              : (o.pop(), (u = !0), o.push(Hr(d)));
          u || o.push("");
        }
      }
    } else o.push(Hr(s));
    return {
      name: n,
      attributes: a,
      content: o,
      indents: r > 1 ? t.repeat(r - 1) : "",
    };
  },
  eo = (e, t, r) => {
    if (typeof e != "object") return String(e);
    const { name: n, attributes: s, content: a, indents: o } = e,
      { length: i } = a,
      l =
        o +
        (n ? `<${n}` : "") +
        (s.length > 0 ? ` ${s.join(" ")}` : "") +
        (i > 0 ? (n ? ">" : "") : "/>") +
        (t && i > 1
          ? `
`
          : "");
    return i === 0
      ? l +
          (t
            ? `
`
            : "")
      : l +
          a.map((c) => (c === void 0 ? "" : eo(c, t, !1))).join("") +
          (i > 1 ? o : "") +
          (n ? `</${n}>` : "") +
          (t && !r
            ? `
`
            : "");
  },
  $ = (e, { indent: t = "", declaration: r } = {}) => {
    const n = Array.isArray(e) ? e : [e],
      s = t ? 1 : 0,
      a = r?.standalone ? ` standalone="${vr(r.standalone)}"` : "";
    return (
      (r === void 0
        ? ""
        : `<?xml version="1.0" encoding="${vr(r.encoding || "UTF-8")}"${a}?>${
            t
              ? `
`
              : ""
          }`) + n.map((o, i) => eo(Qa(o, t, s), t, i === n.length - 1)).join("")
    );
  },
  to = (e) =>
    Object.entries(e ?? {})
      .flatMap(([t, r]) => (r == null ? [] : [` ${t}="${vr(String(r))}"`]))
      .join(""),
  ro = (e) => {
    switch (e.type) {
      case "element": {
        var t, r;
        const n = (t = e.elements) !== null && t !== void 0 ? t : [],
          s = `<${e.name}${to(e.attributes)}`;
        return n.length > 0 ||
          ((r = e.attributes) === null || r === void 0
            ? void 0
            : r["xml:space"]) === "preserve"
          ? `${s}>${n.map(ro).join("")}</${e.name}>`
          : `${s}/>`;
      }
      case "text":
        return Ql(String(e.text));
      case "cdata":
        return `<![CDATA[${String(e.cdata).replace(/\]\]>/g, "]]]]><![CDATA[>")}]]>`;
      case "comment":
        return `<!--${e.comment}-->`;
      case "doctype":
        return `<!DOCTYPE ${e.doctype}>`;
      case "instruction":
        return `<?${e.name}${e.instruction ? ` ${e.instruction}` : ""}?>`;
      default:
        return "";
    }
  },
  ec = (e) => {
    var t;
    return (
      (e.declaration ? `<?xml${to(e.declaration.attributes)}?>` : "") +
      ((t = e.elements) !== null && t !== void 0 ? t : []).map(ro).join("")
    );
  },
  Yn = (e) => {
    switch (e.type) {
      case void 0:
      case "element":
        const t = new rc(e.name, e.attributes),
          r = e.elements || [];
        for (const n of r) {
          const s = Yn(n);
          s !== void 0 && t.push(s);
        }
        return t;
      case "text":
        return e.text;
      default:
        return;
    }
  },
  tc = class extends _ {},
  rc = class extends y {
    static fromXmlString(e) {
      return Yn(bt(e));
    }
    constructor(e, t) {
      (super(e), t && this.root.push(new tc(t)));
    }
    push(e) {
      this.root.push(e);
    }
    get writtenAs() {
      return this.rootKey === void 0
        ? this.root.filter((e) => typeof e != "string")
        : void 0;
    }
    prepForXml(e) {
      const t = this.writtenAs;
      return t?.length === 1 ? t[0].prepForXml(e) : super.prepForXml(e);
    }
  },
  nc = class extends y {
    constructor(e) {
      (super(""), p(this, "_attr", void 0), (this._attr = e));
    }
    prepForXml(e) {
      return { _attr: this._attr };
    }
  },
  no = class extends y {
    constructor(e, t) {
      (super(e), t && (this.root = t.root));
    }
  },
  K = (e) => {
    if (!Number.isFinite(e))
      throw new Error(`Invalid value '${e}' specified. Must be an integer.`);
    return Math.floor(e);
  },
  Ar = (e) => {
    const t = K(e);
    if (t < 0)
      throw new Error(
        `Invalid value '${e}' specified. Must be a positive integer.`,
      );
    return t;
  },
  Ir = (e, t) => {
    const r = t * 2;
    if (e.length !== r || isNaN(+`0x${e}`))
      throw new Error(
        `Invalid hex value '${e}'. Expected ${r} digit hex value`,
      );
    return e;
  },
  Y0 = (e) => Ir(e, 4),
  sc = (e) => Ir(e, 2),
  Ps = (e) => Ir(e, 1),
  Cr = (e) => {
    const t = e.slice(-2),
      r = e.substring(0, e.length - 2);
    return `${Number(r)}${t}`;
  },
  ac = { in: 1440, cm: 1440 / 2.54, mm: 1440 / 25.4, pt: 20, pc: 240, pi: 240 },
  nt = (e) => {
    if (typeof e == "number") return e;
    const t = e.slice(-2),
      r = Number(e.substring(0, e.length - 2)),
      n = ac[t];
    if (n === void 0 || Number.isNaN(r))
      throw new Error(
        `Invalid universal measure '${e}'. Expected a number followed by mm, cm, in, pt, pc or pi.`,
      );
    return r * n;
  },
  so = (e) => {
    const t = Cr(e);
    if (parseFloat(t) < 0)
      throw new Error(
        `Invalid value '${t}' specified. Expected a positive number.`,
      );
    return t;
  },
  ao = (e) =>
    e === "auto" ? e : Ir(e.charAt(0) === "#" ? e.substring(1) : e, 3),
  Fe = (e) => (typeof e == "string" ? Cr(e) : K(e)),
  oc = (e) => (typeof e == "string" ? so(e) : Ar(e)),
  q0 = (e) => (typeof e == "string" ? Cr(e) : K(e)),
  ee = (e) => (typeof e == "string" ? so(e) : Ar(e)),
  ic = (e) => {
    const t = e.substring(0, e.length - 1);
    return `${Number(t)}%`;
  },
  oo = (e) =>
    typeof e == "number" ? K(e) : e.slice(-1) === "%" ? ic(e) : Cr(e),
  lc = Ar,
  cc = Ar,
  uc = (e) => e.toISOString(),
  N = class extends y {
    constructor(e, t = !0) {
      (super(e), t !== !0 && this.root.push(new pe({ val: t })));
    }
  },
  Br = class extends y {
    constructor(e, t) {
      (super(e), this.root.push(new pe({ val: oc(t) })));
    }
  },
  ue = class extends y {},
  $e = class extends y {
    constructor(e, t) {
      (super(e), this.root.push(new pe({ val: t })));
    }
  },
  Et = (e, t) =>
    new x({ name: e, attributes: { value: { key: "w:val", value: t } } }),
  Ot = class extends y {
    constructor(e, t) {
      (super(e), this.root.push(new pe({ val: t })));
    }
  },
  J0 = class extends y {
    constructor(e, t) {
      (super(e), this.root.push(new pe({ val: t })));
    }
  },
  lt = class extends y {
    constructor(e, t) {
      (super(e), this.root.push(t));
    }
  },
  x = class extends y {
    constructor({ name: e, attributes: t, children: r }) {
      (super(e), t && this.root.push(new Sr(t)), r && this.root.push(...r));
    }
  },
  de = {
    START: "start",
    CENTER: "center",
    END: "end",
    BOTH: "both",
    MEDIUM_KASHIDA: "mediumKashida",
    DISTRIBUTE: "distribute",
    NUM_TAB: "numTab",
    HIGH_KASHIDA: "highKashida",
    LOW_KASHIDA: "lowKashida",
    THAI_DISTRIBUTE: "thaiDistribute",
    LEFT: "left",
    RIGHT: "right",
    JUSTIFIED: "both",
  },
  io = (e) =>
    new x({ name: "w:jc", attributes: { val: { key: "w:val", value: e } } }),
  qn = {
    dark1: "dk1",
    light1: "lt1",
    dark2: "dk2",
    light2: "lt2",
    accent1: "accent1",
    accent2: "accent2",
    accent3: "accent3",
    accent4: "accent4",
    accent5: "accent5",
    accent6: "accent6",
    hyperlink: "hlink",
    followedHyperlink: "folHlink",
  },
  lo = {
    dark2: "44546A",
    light2: "E7E6E6",
    accent1: "4472C4",
    accent2: "ED7D31",
    accent3: "A5A5A5",
    accent4: "FFC000",
    accent5: "5B9BD5",
    accent6: "70AD47",
    hyperlink: "0563C1",
    followedHyperlink: "954F72",
  },
  co = {
    dark1: { value: "windowText", lastColor: "000000" },
    light1: { value: "window", lastColor: "FFFFFF" },
  },
  uo = (e, t) => {
    if (t === "auto")
      throw new Error(
        `Invalid theme color ${e} 'auto'. Expected 6 digit hex value`,
      );
    return ao(t);
  },
  Jn = (e = {}) =>
    Object.fromEntries(
      Object.keys(qn).map((t) => {
        const r = e[t],
          n = t === "dark1" || t === "light1" ? co[t].lastColor : lo[t];
        return [t, r === void 0 ? n : uo(t, r)];
      }),
    ),
  dc = (e, t) =>
    new x({
      name: "a:srgbClr",
      attributes: { value: { key: "val", value: uo(e, t) } },
    }),
  hc = (e, t) => {
    const r = t[e],
      n = e === "dark1" || e === "light1" ? co[e] : void 0;
    return new x({
      name: `a:${qn[e]}`,
      children: [
        r === void 0 && n
          ? new x({
              name: "a:sysClr",
              attributes: {
                value: { key: "val", value: n.value },
                lastColor: { key: "lastClr", value: n.lastColor },
              },
            })
          : dc(e, r ?? lo[e]),
      ],
    });
  },
  mc = (e, t = {}) =>
    new x({
      name: "a:clrScheme",
      attributes: { name: { key: "name", value: e } },
      children: Object.keys(qn).map((r) => hc(r, t)),
    }),
  Os = new Set([
    "dark1",
    "light1",
    "dark2",
    "light2",
    "accent1",
    "accent2",
    "accent3",
    "accent4",
    "accent5",
    "accent6",
    "hyperlink",
    "followedHyperlink",
  ]),
  pc = new Map([
    ["dk1", "dark1"],
    ["lt1", "light1"],
    ["dk2", "dark2"],
    ["lt2", "light2"],
    ["hlink", "hyperlink"],
    ["folHlink", "followedHyperlink"],
    ["text1", "dark1"],
    ["background1", "light1"],
    ["text2", "dark2"],
    ["background2", "light2"],
  ]),
  _s = (e, t) => {
    if (!(e >= 0 && e <= 100))
      throw new Error(`Invalid ${t} ${e}. Expected a number from 0 to 100`);
    return Math.round(255 * (1 - e / 100));
  },
  vc = ({ theme: e, lighter: t, darker: r }) => {
    if (!Os.has(e)) {
      const a = pc.get(e);
      throw new Error(
        `Invalid theme color "${e}". ${a ? `Did you mean "${a}"?` : `Expected one of ${[...Os].join(", ")}`}`,
      );
    }
    if (t !== void 0 && r !== void 0)
      throw new Error(
        "Invalid theme color. Expected lighter or darker, not both",
      );
    const n = t === void 0 ? void 0 : _s(t, "lighter"),
      s = r === void 0 ? void 0 : _s(r, "darker");
    return { tint: n === 255 ? void 0 : n, shade: s === 255 ? void 0 : s };
  },
  fc = (e) => {
    const [t, r, n] = [0, 2, 4].map(
        (l) => parseInt(e.slice(l, l + 2), 16) / 255,
      ),
      s = Math.max(t, r, n),
      a = Math.min(t, r, n),
      o = (s + a) / 2,
      i = s - a;
    return i === 0
      ? { hue: 0, saturation: 0, lightness: o }
      : {
          hue:
            (s === t
              ? ((r - n) / i + 6) % 6
              : s === r
                ? (n - t) / i + 2
                : (t - r) / i + 4) * 60,
          saturation: i / (1 - Math.abs(2 * o - 1)),
          lightness: o,
        };
  },
  wc = ({ hue: e, saturation: t, lightness: r }) => {
    const n = (1 - Math.abs(2 * r - 1)) * t,
      s = n * (1 - Math.abs(((e / 60) % 2) - 1)),
      [a, o, i] =
        e < 60
          ? [n, s, 0]
          : e < 120
            ? [s, n, 0]
            : e < 180
              ? [0, n, s]
              : e < 240
                ? [0, s, n]
                : e < 300
                  ? [s, 0, n]
                  : [n, 0, s],
      l = r - n / 2;
    return [a, o, i]
      .map((c) =>
        Math.floor((c + l) * 255 + 1e-9)
          .toString(16)
          .padStart(2, "0"),
      )
      .join("")
      .toUpperCase();
  },
  gc = (e, { tint: t, shade: r }) => {
    if (t === void 0 && r === void 0) return e;
    const n = fc(e),
      s =
        t === void 0
          ? (n.lightness * r) / 255
          : (n.lightness * t) / 255 + (1 - t / 255);
    return wc(f(f({}, n), {}, { lightness: s }));
  },
  Ls = (e) =>
    e === void 0 ? void 0 : e.toString(16).padStart(2, "0").toUpperCase(),
  yc = (e) =>
    typeof e == "string"
      ? { type: "hex", value: ao(e) }
      : { type: "theme", color: e, change: vc(e) },
  xc = (e, t) =>
    e.type === "hex"
      ? { color: e.value }
      : {
          color: gc(t[e.color.theme], e.change),
          theme: e.color.theme,
          tint: Ls(e.change.tint),
          shade: Ls(e.change.shade),
        },
  bc = Jn(),
  Zn = class extends Ut {
    constructor(e) {
      (super("_attr"),
        p(this, "attributes", void 0),
        (this.attributes = e.map((t) =>
          "keys" in t
            ? { keys: t.keys, color: t.color === void 0 ? void 0 : yc(t.color) }
            : t,
        )));
    }
    prepForXml(e) {
      var t, r;
      const n =
          (t =
            (r = e.file) === null ||
            r === void 0 ||
            (r = r.Theme) === null ||
            r === void 0
              ? void 0
              : r.Colors) !== null && t !== void 0
            ? t
            : bc,
        s = this.attributes.flatMap((a) => {
          if (!("keys" in a)) return [[a.key, a.value]];
          if (a.color === void 0) return [];
          const { keys: o } = a,
            i = xc(a.color, n);
          return [
            [o.color, i.color],
            [o.theme, i.theme],
            [o.tint, i.tint],
            [o.shade, i.shade],
          ];
        });
      return { _attr: Object.fromEntries(s.filter(([, a]) => a !== void 0)) };
    }
  },
  Tc = class extends y {
    constructor(e, t) {
      (super(e), this.root.push(new Zn(t)));
    }
  },
  Qn = (e, t) => new Tc(e, t),
  Vt = {
    color: "w:color",
    theme: "w:themeColor",
    tint: "w:themeTint",
    shade: "w:themeShade",
  },
  Q = (e, { color: t, size: r, space: n, style: s }) =>
    Qn(e, [
      { key: "w:val", value: s },
      { keys: Vt, color: t },
      { key: "w:sz", value: r === void 0 ? void 0 : lc(r) },
      { key: "w:space", value: n === void 0 ? void 0 : cc(n) },
    ]),
  es = {
    SINGLE: "single",
    DASH_DOT_STROKED: "dashDotStroked",
    DASHED: "dashed",
    DASH_SMALL_GAP: "dashSmallGap",
    DOT_DASH: "dotDash",
    DOT_DOT_DASH: "dotDotDash",
    DOTTED: "dotted",
    DOUBLE: "double",
    DOUBLE_WAVE: "doubleWave",
    INSET: "inset",
    NIL: "nil",
    NONE: "none",
    OUTSET: "outset",
    THICK: "thick",
    THICK_THIN_LARGE_GAP: "thickThinLargeGap",
    THICK_THIN_MEDIUM_GAP: "thickThinMediumGap",
    THICK_THIN_SMALL_GAP: "thickThinSmallGap",
    THIN_THICK_LARGE_GAP: "thinThickLargeGap",
    THIN_THICK_MEDIUM_GAP: "thinThickMediumGap",
    THIN_THICK_SMALL_GAP: "thinThickSmallGap",
    THIN_THICK_THIN_LARGE_GAP: "thinThickThinLargeGap",
    THIN_THICK_THIN_MEDIUM_GAP: "thinThickThinMediumGap",
    THIN_THICK_THIN_SMALL_GAP: "thinThickThinSmallGap",
    THREE_D_EMBOSS: "threeDEmboss",
    THREE_D_ENGRAVE: "threeDEngrave",
    TRIPLE: "triple",
    WAVE: "wave",
  },
  Ec = class extends Ze {
    constructor(e) {
      (super("w:pBdr"),
        e.top && this.root.push(Q("w:top", e.top)),
        e.left && this.root.push(Q("w:left", e.left)),
        e.bottom && this.root.push(Q("w:bottom", e.bottom)),
        e.right && this.root.push(Q("w:right", e.right)),
        e.between && this.root.push(Q("w:between", e.between)));
    }
  },
  Sc = class extends y {
    constructor() {
      super("w:pBdr");
      const e = Q("w:bottom", {
        color: "auto",
        space: 1,
        style: es.SINGLE,
        size: 6,
      });
      this.root.push(e);
    }
  },
  Ac = ({
    start: e,
    end: t,
    left: r,
    right: n,
    hanging: s,
    firstLine: a,
    firstLineChars: o,
  }) =>
    new x({
      name: "w:ind",
      attributes: {
        start: { key: "w:start", value: e === void 0 ? void 0 : Fe(e) },
        end: { key: "w:end", value: t === void 0 ? void 0 : Fe(t) },
        left: { key: "w:left", value: r === void 0 ? void 0 : Fe(r) },
        right: { key: "w:right", value: n === void 0 ? void 0 : Fe(n) },
        hanging: { key: "w:hanging", value: s === void 0 ? void 0 : ee(s) },
        firstLine: { key: "w:firstLine", value: a === void 0 ? void 0 : ee(a) },
        firstLineChars: {
          key: "w:firstLineChars",
          value: o === void 0 ? void 0 : K(o),
        },
      },
    }),
  ho = () => new x({ name: "w:br" }),
  Nr = { BEGIN: "begin", END: "end", SEPARATE: "separate" },
  ts = (e, t, r) =>
    new x({
      name: "w:fldChar",
      attributes: {
        type: { key: "w:fldCharType", value: e },
        dirty: { key: "w:dirty", value: t },
        locked: { key: "w:fldLock", value: r },
      },
    }),
  Ke = (e, t) => ts(Nr.BEGIN, e, t),
  mo = new WeakSet(),
  Ic = class extends x {
    constructor() {
      super({
        name: "w:fldChar",
        attributes: {
          type: { key: "w:fldCharType", value: Nr.BEGIN },
          dirty: { key: "w:dirty", value: !0 },
        },
      });
    }
    prepForXml(e) {
      const t = super.prepForXml(e);
      return (mo.add(t), t);
    }
  },
  rs = () => new Ic(),
  Cc = (e) => typeof e == "object" && e !== null && mo.has(e),
  Re = (e) => ts(Nr.SEPARATE, e),
  Se = (e) => ts(Nr.END, e),
  Z0 = {
    CENTER: "center",
    INSIDE: "inside",
    LEFT: "left",
    OUTSIDE: "outside",
    RIGHT: "right",
  },
  Q0 = {
    BOTTOM: "bottom",
    CENTER: "center",
    INSIDE: "inside",
    OUTSIDE: "outside",
    TOP: "top",
  },
  eg = {
    DECIMAL: "decimal",
    UPPER_ROMAN: "upperRoman",
    LOWER_ROMAN: "lowerRoman",
    UPPER_LETTER: "upperLetter",
    LOWER_LETTER: "lowerLetter",
    ORDINAL: "ordinal",
    CARDINAL_TEXT: "cardinalText",
    ORDINAL_TEXT: "ordinalText",
    HEX: "hex",
    CHICAGO: "chicago",
    IDEOGRAPH_DIGITAL: "ideographDigital",
    JAPANESE_COUNTING: "japaneseCounting",
    AIUEO: "aiueo",
    IROHA: "iroha",
    DECIMAL_FULL_WIDTH: "decimalFullWidth",
    DECIMAL_HALF_WIDTH: "decimalHalfWidth",
    JAPANESE_LEGAL: "japaneseLegal",
    JAPANESE_DIGITAL_TEN_THOUSAND: "japaneseDigitalTenThousand",
    DECIMAL_ENCLOSED_CIRCLE: "decimalEnclosedCircle",
    DECIMAL_FULL_WIDTH_2: "decimalFullWidth2",
    AIUEO_FULL_WIDTH: "aiueoFullWidth",
    IROHA_FULL_WIDTH: "irohaFullWidth",
    DECIMAL_ZERO: "decimalZero",
    BULLET: "bullet",
    GANADA: "ganada",
    CHOSUNG: "chosung",
    DECIMAL_ENCLOSED_FULL_STOP: "decimalEnclosedFullstop",
    DECIMAL_ENCLOSED_PAREN: "decimalEnclosedParen",
    DECIMAL_ENCLOSED_CIRCLE_CHINESE: "decimalEnclosedCircleChinese",
    IDEOGRAPH_ENCLOSED_CIRCLE: "ideographEnclosedCircle",
    IDEOGRAPH_TRADITIONAL: "ideographTraditional",
    IDEOGRAPH_ZODIAC: "ideographZodiac",
    IDEOGRAPH_ZODIAC_TRADITIONAL: "ideographZodiacTraditional",
    TAIWANESE_COUNTING: "taiwaneseCounting",
    IDEOGRAPH_LEGAL_TRADITIONAL: "ideographLegalTraditional",
    TAIWANESE_COUNTING_THOUSAND: "taiwaneseCountingThousand",
    TAIWANESE_DIGITAL: "taiwaneseDigital",
    CHINESE_COUNTING: "chineseCounting",
    CHINESE_LEGAL_SIMPLIFIED: "chineseLegalSimplified",
    CHINESE_COUNTING_TEN_THOUSAND: "chineseCountingThousand",
    KOREAN_DIGITAL: "koreanDigital",
    KOREAN_COUNTING: "koreanCounting",
    KOREAN_LEGAL: "koreanLegal",
    KOREAN_DIGITAL_2: "koreanDigital2",
    VIETNAMESE_COUNTING: "vietnameseCounting",
    RUSSIAN_LOWER: "russianLower",
    RUSSIAN_UPPER: "russianUpper",
    NONE: "none",
    NUMBER_IN_DASH: "numberInDash",
    HEBREW_1: "hebrew1",
    HEBREW_2: "hebrew2",
    ARABIC_ALPHA: "arabicAlpha",
    ARABIC_ABJAD: "arabicAbjad",
    HINDI_VOWELS: "hindiVowels",
    HINDI_CONSONANTS: "hindiConsonants",
    HINDI_NUMBERS: "hindiNumbers",
    HINDI_COUNTING: "hindiCounting",
    THAI_LETTERS: "thaiLetters",
    THAI_NUMBERS: "thaiNumbers",
    THAI_COUNTING: "thaiCounting",
    BAHT_TEXT: "bahtText",
    DOLLAR_TEXT: "dollarText",
    CUSTOM: "custom",
  },
  fe = { DEFAULT: "default", PRESERVE: "preserve" },
  we = class extends _ {
    constructor(...e) {
      (super(...e), p(this, "xmlKeys", { space: "xml:space" }));
    }
  },
  Nc = class extends y {
    constructor() {
      (super("w:instrText"),
        this.root.push(new we({ space: fe.PRESERVE })),
        this.root.push("PAGE"));
    }
  },
  kc = class extends y {
    constructor() {
      (super("w:instrText"),
        this.root.push(new we({ space: fe.PRESERVE })),
        this.root.push("NUMPAGES"));
    }
  },
  Rc = class extends y {
    constructor() {
      (super("w:instrText"),
        this.root.push(new we({ space: fe.PRESERVE })),
        this.root.push("SECTIONPAGES"));
    }
  },
  Pc = class extends y {
    constructor() {
      (super("w:instrText"),
        this.root.push(new we({ space: fe.PRESERVE })),
        this.root.push("SECTION"));
    }
  },
  kr = ({ fill: e, color: t, type: r }) =>
    Qn("w:shd", [
      {
        keys: {
          color: "w:fill",
          theme: "w:themeFill",
          tint: "w:themeFillTint",
          shade: "w:themeFillShade",
        },
        color: e,
      },
      { keys: Vt, color: t },
      { key: "w:val", value: r ?? Oc.CLEAR },
    ]),
  Oc = {
    CLEAR: "clear",
    DIAGONAL_CROSS: "diagCross",
    DIAGONAL_STRIPE: "diagStripe",
    HORIZONTAL_CROSS: "horzCross",
    HORIZONTAL_STRIPE: "horzStripe",
    NIL: "nil",
    PERCENT_5: "pct5",
    PERCENT_10: "pct10",
    PERCENT_12: "pct12",
    PERCENT_15: "pct15",
    PERCENT_20: "pct20",
    PERCENT_25: "pct25",
    PERCENT_30: "pct30",
    PERCENT_35: "pct35",
    PERCENT_37: "pct37",
    PERCENT_40: "pct40",
    PERCENT_45: "pct45",
    PERCENT_50: "pct50",
    PERCENT_55: "pct55",
    PERCENT_60: "pct60",
    PERCENT_62: "pct62",
    PERCENT_65: "pct65",
    PERCENT_70: "pct70",
    PERCENT_75: "pct75",
    PERCENT_80: "pct80",
    PERCENT_85: "pct85",
    PERCENT_87: "pct87",
    PERCENT_90: "pct90",
    PERCENT_95: "pct95",
    REVERSE_DIAGONAL_STRIPE: "reverseDiagStripe",
    SOLID: "solid",
    THIN_DIAGONAL_CROSS: "thinDiagCross",
    THIN_DIAGONAL_STRIPE: "thinDiagStripe",
    THIN_HORIZONTAL_CROSS: "thinHorzCross",
    THIN_REVERSE_DIAGONAL_STRIPE: "thinReverseDiagStripe",
    THIN_VERTICAL_STRIPE: "thinVertStripe",
    VERTICAL_STRIPE: "vertStripe",
  },
  ge = class extends _ {
    constructor(...e) {
      (super(...e),
        p(this, "xmlKeys", { id: "w:id", author: "w:author", date: "w:date" }));
    }
  },
  _c = class extends y {
    constructor(e) {
      (super("w:del"),
        this.root.push(new ge({ id: e.id, author: e.author, date: e.date })));
    }
  },
  Lc = class extends y {
    constructor(e) {
      (super("w:ins"),
        this.root.push(new ge({ id: e.id, author: e.author, date: e.date })));
    }
  },
  tg = {
    NONE: "none",
    ROUND: "round",
    SQUARE: "square",
    ANGLE: "angle",
    CURLY: "curly",
  },
  Dc = ({
    twoLinesInOne: e,
    brackets: t,
    horizontalInVertical: r,
    fitToLine: n,
    group: s,
  }) =>
    new x({
      name: "w:eastAsianLayout",
      attributes: {
        id: { key: "w:id", value: s === void 0 ? void 0 : K(s) },
        combine: { key: "w:combine", value: e },
        combineBrackets: { key: "w:combineBrackets", value: t },
        vert: { key: "w:vert", value: r },
        vertCompress: { key: "w:vertCompress", value: n },
      },
    }),
  po = { DOT: "dot" },
  vo = (e = po.DOT) =>
    new x({ name: "w:em", attributes: { val: { key: "w:val", value: e } } }),
  rg = () => vo(po.DOT),
  Mc = "57X6y3wQZNzYjJB2L_10pxbackgroundhimselfUTF-8DEMOGRAPHICSVqvt4KW9",
  Fc =
    (e, t = 21) =>
    (r = t) => {
      let n = "",
        s = r | 0;
      for (; s-- > 0;) n += e[(Math.random() * e.length) | 0];
      return n;
    },
  $c = (e = 21) => {
    let t = "",
      r = e | 0;
    for (; r-- > 0;) t += Mc[(Math.random() * 64) | 0];
    return t;
  },
  fo = (e) => {
    const t = new Int32Array(Math.ceil((e.length + 9) / 64) * 16);
    for (let r = 0; r < e.length; r++) t[r >> 2] |= e[r] << (24 - (r & 3) * 8);
    return (
      (t[e.length >> 2] |= 128 << (24 - (e.length & 3) * 8)),
      (t[t.length - 2] = Math.floor(e.length / 536870912)),
      (t[t.length - 1] = e.length * 8),
      t
    );
  },
  wo = (e) => {
    const t = new Uint8Array(e.length * 4);
    for (let r = 0; r < t.length; r++) t[r] = e[r >> 2] >>> (24 - (r & 3) * 8);
    return t;
  },
  Wr = (e, t) => (e << t) | (e >>> (32 - t)),
  Le = (e, t) => (e >>> t) | (e << (32 - t)),
  Hc = [1732584193, 4023233417, 2562383102, 271733878, 3285377520],
  Bc = Int32Array.of(1518500249, 1859775393, 2400959708, 3395469782),
  Wc = new Int32Array(80),
  Uc = (e) => {
    const t = fo(e),
      r = Wc;
    let [n, s, a, o, i] = Hc;
    for (let l = 0; l < t.length; l += 16) {
      r.set(t.subarray(l, l + 16));
      for (let m = 16; m < 80; m++)
        r[m] = Wr(r[m - 3] ^ r[m - 8] ^ r[m - 14] ^ r[m - 16], 1);
      let [c, u, d, h, w] = [n, s, a, o, i];
      for (let m = 0; m < 80; m++) {
        const v =
            m < 20
              ? (u & d) | (~u & h)
              : m >= 40 && m < 60
                ? (u & d) | (u & h) | (d & h)
                : u ^ d ^ h,
          g = (Wr(c, 5) + v + w + Bc[Math.floor(m / 20)] + r[m]) | 0;
        ((w = h), (h = d), (d = Wr(u, 30)), (u = c), (c = g));
      }
      [n, s, a, o, i] = [
        (n + c) | 0,
        (s + u) | 0,
        (a + d) | 0,
        (o + h) | 0,
        (i + w) | 0,
      ];
    }
    return wo([n, s, a, o, i]);
  },
  Gc = Int32Array.of(
    1116352408,
    1899447441,
    3049323471,
    3921009573,
    961987163,
    1508970993,
    2453635748,
    2870763221,
    3624381080,
    310598401,
    607225278,
    1426881987,
    1925078388,
    2162078206,
    2614888103,
    3248222580,
    3835390401,
    4022224774,
    264347078,
    604807628,
    770255983,
    1249150122,
    1555081692,
    1996064986,
    2554220882,
    2821834349,
    2952996808,
    3210313671,
    3336571891,
    3584528711,
    113926993,
    338241895,
    666307205,
    773529912,
    1294757372,
    1396182291,
    1695183700,
    1986661051,
    2177026350,
    2456956037,
    2730485921,
    2820302411,
    3259730800,
    3345764771,
    3516065817,
    3600352804,
    4094571909,
    275423344,
    430227734,
    506948616,
    659060556,
    883997877,
    958139571,
    1322822218,
    1537002063,
    1747873779,
    1955562222,
    2024104815,
    2227730452,
    2361852424,
    2428436474,
    2756734187,
    3204031479,
    3329325298,
  ),
  jc = [
    1779033703, 3144134277, 1013904242, 2773480762, 1359893119, 2600822924,
    528734635, 1541459225,
  ],
  Vc = new Int32Array(64),
  Ds = (e) => {
    const t = fo(e),
      r = Vc;
    let [n, s, a, o, i, l, c, u] = jc;
    for (let d = 0; d < t.length; d += 16) {
      r.set(t.subarray(d, d + 16));
      for (let R = 16; R < 64; R++) {
        const O = r[R - 15],
          E = r[R - 2];
        r[R] =
          r[R - 16] +
          (Le(O, 7) ^ Le(O, 18) ^ (O >>> 3)) +
          r[R - 7] +
          (Le(E, 17) ^ Le(E, 19) ^ (E >>> 10));
      }
      let [h, w, m, v, g, A, I, b] = [n, s, a, o, i, l, c, u];
      for (let R = 0; R < 64; R++) {
        const O =
            (b +
              (Le(g, 6) ^ Le(g, 11) ^ Le(g, 25)) +
              ((g & A) ^ (~g & I)) +
              Gc[R] +
              r[R]) |
            0,
          E =
            ((Le(h, 2) ^ Le(h, 13) ^ Le(h, 22)) +
              ((h & w) ^ (h & m) ^ (w & m))) |
            0;
        ((b = I),
          (I = A),
          (A = g),
          (g = (v + O) | 0),
          (v = m),
          (m = w),
          (w = h),
          (h = (O + E) | 0));
      }
      [n, s, a, o, i, l, c, u] = [
        (n + h) | 0,
        (s + w) | 0,
        (a + m) | 0,
        (o + v) | 0,
        (i + g) | 0,
        (l + A) | 0,
        (c + I) | 0,
        (u + b) | 0,
      ];
    }
    return wo([n, s, a, o, i, l, c, u]);
  },
  ng = (e) => Math.floor((e / 25.4) * 72 * 20),
  Ne = (e) => Math.floor(e * 72 * 20),
  Tt = (e = 0) => {
    let t = e;
    return () => ++t;
  },
  Xc = () => Tt(),
  Kc = () => Tt(1),
  zc = () => Tt(),
  Yc = zc(),
  qc = () => Tt(),
  go = qc(),
  Jc = Tt(),
  Zc = () => -Jc(),
  at = () => $c().toLowerCase(),
  yo = (e) =>
    Array.from(
      Uc(
        typeof e == "string"
          ? bo(e)
          : ArrayBuffer.isView(e)
            ? e
            : new Uint8Array(e),
      ),
      (t) => t.toString(16).padStart(2, "0"),
    ).join(""),
  St = (e) => Fc("1234567890abcdef", e)(),
  xo = () => `${St(8)}-${St(4)}-${St(4)}-${St(4)}-${St(12)}`,
  bo = (e) => new Uint8Array(new TextEncoder().encode(e)),
  Qc = ({ width: e, group: t }) =>
    new x({
      name: "w:fitText",
      attributes: {
        val: { key: "w:val", value: Math.round(nt(ee(e))) },
        id: { key: "w:id", value: t === void 0 ? Zc() : K(t) },
      },
    }),
  eu = class extends y {
    constructor(e) {
      (super("w:spacing"), this.root.push(new pe({ val: Fe(e) })));
    }
  },
  tu = class extends y {
    constructor(e) {
      (super("w:color"),
        this.root.push(
          new Zn([{ keys: f(f({}, Vt), {}, { color: "w:val" }), color: e }]),
        ));
    }
  },
  ru = class extends y {
    constructor(e) {
      (super("w:highlight"), this.root.push(new pe({ val: e })));
    }
  },
  nu = (e) =>
    new x({
      name: "w:lang",
      attributes: {
        value: { key: "w:val", value: e.value },
        eastAsia: { key: "w:eastAsia", value: e.eastAsia },
        bidirectional: { key: "w:bidi", value: e.bidirectional },
      },
    }),
  Ur = (e, t) => {
    if (typeof e == "string") {
      const n = e;
      return new x({
        name: "w:rFonts",
        attributes: {
          ascii: { key: "w:ascii", value: n },
          cs: { key: "w:cs", value: n },
          eastAsia: { key: "w:eastAsia", value: n },
          hAnsi: { key: "w:hAnsi", value: n },
          hint: { key: "w:hint", value: t },
        },
      });
    }
    if ("theme" in e) {
      const n = e.theme === "headings" ? "major" : "minor";
      return new x({
        name: "w:rFonts",
        attributes: {
          ascii: { key: "w:asciiTheme", value: `${n}HAnsi` },
          eastAsia: { key: "w:eastAsiaTheme", value: `${n}EastAsia` },
          hAnsi: { key: "w:hAnsiTheme", value: `${n}HAnsi` },
          cs: { key: "w:cstheme", value: `${n}Bidi` },
        },
      });
    }
    const r = e;
    return new x({
      name: "w:rFonts",
      attributes: {
        ascii: { key: "w:ascii", value: r.ascii },
        cs: { key: "w:cs", value: r.cs },
        eastAsia: { key: "w:eastAsia", value: r.eastAsia },
        hAnsi: { key: "w:hAnsi", value: r.hAnsi },
        hint: { key: "w:hint", value: r.hint },
      },
    });
  },
  To = (e) =>
    new x({
      name: "w:vertAlign",
      attributes: { val: { key: "w:val", value: e } },
    }),
  su = () => To("superscript"),
  au = () => To("subscript"),
  Eo = {
    SINGLE: "single",
    WORDS: "words",
    DOUBLE: "double",
    THICK: "thick",
    DOTTED: "dotted",
    DOTTEDHEAVY: "dottedHeavy",
    DASH: "dash",
    DASHEDHEAVY: "dashedHeavy",
    DASHLONG: "dashLong",
    DASHLONGHEAVY: "dashLongHeavy",
    DOTDASH: "dotDash",
    DASHDOTHEAVY: "dashDotHeavy",
    DOTDOTDASH: "dotDotDash",
    DASHDOTDOTHEAVY: "dashDotDotHeavy",
    WAVE: "wave",
    WAVYHEAVY: "wavyHeavy",
    WAVYDOUBLE: "wavyDouble",
    NONE: "none",
  },
  ou = (e = Eo.SINGLE, t) =>
    Qn("w:u", [
      { key: "w:val", value: e },
      { keys: Vt, color: t },
    ]),
  sg = {
    BLINK_BACKGROUND: "blinkBackground",
    LIGHTS: "lights",
    ANTS_BLACK: "antsBlack",
    ANTS_RED: "antsRed",
    SHIMMER: "shimmer",
    SPARKLE: "sparkle",
    NONE: "none",
  },
  ag = {
    BLACK: "black",
    BLUE: "blue",
    CYAN: "cyan",
    DARK_BLUE: "darkBlue",
    DARK_CYAN: "darkCyan",
    DARK_GRAY: "darkGray",
    DARK_GREEN: "darkGreen",
    DARK_MAGENTA: "darkMagenta",
    DARK_RED: "darkRed",
    DARK_YELLOW: "darkYellow",
    GREEN: "green",
    LIGHT_GRAY: "lightGray",
    MAGENTA: "magenta",
    NONE: "none",
    RED: "red",
    WHITE: "white",
    YELLOW: "yellow",
  },
  Qe = class extends Ze {
    constructor(e) {
      if ((super("w:rPr"), !e)) return;
      if (
        (e.style && this.push(new $e("w:rStyle", e.style)),
        e.font &&
          (typeof e.font == "string"
            ? this.push(Ur(e.font))
            : "name" in e.font
              ? this.push(Ur(e.font.name, e.font.hint))
              : this.push(Ur(e.font))),
        e.bold !== void 0 && this.push(new N("w:b", e.bold)),
        (e.boldComplexScript === void 0 && e.bold !== void 0) ||
          e.boldComplexScript)
      ) {
        var t;
        this.push(
          new N(
            "w:bCs",
            (t = e.boldComplexScript) !== null && t !== void 0 ? t : e.bold,
          ),
        );
      }
      if (
        (e.italics !== void 0 && this.push(new N("w:i", e.italics)),
        (e.italicsComplexScript === void 0 && e.italics !== void 0) ||
          e.italicsComplexScript)
      ) {
        var r;
        this.push(
          new N(
            "w:iCs",
            (r = e.italicsComplexScript) !== null && r !== void 0
              ? r
              : e.italics,
          ),
        );
      }
      (e.smallCaps !== void 0
        ? this.push(new N("w:smallCaps", e.smallCaps))
        : e.allCaps !== void 0 && this.push(new N("w:caps", e.allCaps)),
        e.strike !== void 0 && this.push(new N("w:strike", e.strike)),
        e.doubleStrike !== void 0 &&
          this.push(new N("w:dstrike", e.doubleStrike)),
        e.emboss !== void 0 && this.push(new N("w:emboss", e.emboss)),
        e.imprint !== void 0 && this.push(new N("w:imprint", e.imprint)),
        e.noProof !== void 0 && this.push(new N("w:noProof", e.noProof)),
        e.snapToGrid !== void 0 &&
          this.push(new N("w:snapToGrid", e.snapToGrid)),
        e.vanish !== void 0 && this.push(new N("w:vanish", e.vanish)),
        e.color && this.push(new tu(e.color)),
        e.characterSpacing && this.push(new eu(e.characterSpacing)),
        e.scale !== void 0 && this.push(new Ot("w:w", e.scale)),
        e.kern && this.push(new Br("w:kern", e.kern)),
        e.position && this.push(new $e("w:position", e.position)),
        e.size !== void 0 && this.push(new Br("w:sz", e.size)));
      const n =
        e.sizeComplexScript === void 0 || e.sizeComplexScript === !0
          ? e.size
          : e.sizeComplexScript;
      (n && this.push(new Br("w:szCs", n)),
        e.highlight && this.push(new ru(e.highlight)),
        e.underline && this.push(ou(e.underline.type, e.underline.color)),
        e.effect && this.push(new $e("w:effect", e.effect)),
        e.border && this.push(Q("w:bdr", e.border)),
        e.shading && this.push(kr(e.shading)),
        e.fitText && this.push(Qc(e.fitText)),
        e.subScript && this.push(au()),
        e.superScript && this.push(su()),
        e.rightToLeft !== void 0 && this.push(new N("w:rtl", e.rightToLeft)),
        e.emphasisMark && this.push(vo(e.emphasisMark.type)),
        e.language && this.push(nu(e.language)),
        e.eastAsianLayout && this.push(Dc(e.eastAsianLayout)),
        e.specVanish !== void 0 &&
          this.push(new N("w:specVanish", e.specVanish)),
        e.math !== void 0 && this.push(new N("w:oMath", e.math)),
        e.revision && this.push(new lu(e.revision)));
    }
    push(e) {
      this.root.push(e);
    }
  },
  iu = class extends Qe {
    constructor(e) {
      (super(e),
        e?.insertion && this.push(new Lc(e.insertion)),
        e?.deletion && this.push(new _c(e.deletion)));
    }
  },
  lu = class extends y {
    constructor(e) {
      (super("w:rPrChange"),
        this.root.push(new ge({ id: e.id, author: e.author, date: e.date })),
        this.addChildElement(new Qe(e)));
    }
  },
  Ft = class extends y {
    constructor(e) {
      if ((super("w:t"), typeof e == "string"))
        (this.root.push(new we({ space: fe.PRESERVE })), this.root.push(e));
      else {
        var t;
        (this.root.push(
          new we({
            space: (t = e.space) !== null && t !== void 0 ? t : fe.DEFAULT,
          }),
        ),
          this.root.push(e.text));
      }
    }
  },
  ut = {
    CURRENT: "CURRENT",
    TOTAL_PAGES: "TOTAL_PAGES",
    TOTAL_PAGES_IN_SECTION: "TOTAL_PAGES_IN_SECTION",
    CURRENT_SECTION: "SECTION",
  },
  cu = (e) => {
    switch (e) {
      case ut.CURRENT:
        return [Ke(), new Nc(), Re(), Se()];
      case ut.TOTAL_PAGES:
        return [Ke(), new kc(), Re(), Se()];
      case ut.TOTAL_PAGES_IN_SECTION:
        return [Ke(), new Rc(), Re(), Se()];
      case ut.CURRENT_SECTION:
        return [Ke(), new Pc(), Re(), Se()];
      default:
        return;
    }
  },
  te = class Sn extends y {
    constructor(t) {
      if (
        (super("w:r"),
        p(this, "properties", void 0),
        p(this, "following", []),
        (this.properties = new Qe(t)),
        this.root.push(this.properties),
        t.break)
      )
        for (let r = 0; r < t.break; r++) this.root.push(ho());
      if (t.children)
        for (const [r, n] of t.children.entries()) {
          if (Gt(n) === "w:r") {
            const s = t.children.slice(r + 1);
            this.following = [
              n,
              ...(s.length > 0
                ? [new Sn(f(f({}, t), {}, { break: void 0, children: s }))]
                : []),
            ];
            break;
          }
          if (typeof n == "string") {
            const s = cu(n);
            if (s) {
              const a = t.children.slice(r + 1),
                o = (c) =>
                  new Sn(f(f({}, t), {}, { break: void 0, children: c })),
                i = this.root.length === 1;
              i && this.root.push(s[0]);
              const l = i ? s.slice(1) : s;
              this.following = [
                ...l.map((c) => o([c])),
                ...(a.length > 0 ? [o(a)] : []),
              ];
              break;
            }
            this.root.push(new Ft(n));
            continue;
          }
          this.root.push(n);
        }
      else t.text !== void 0 && this.root.push(new Ft(t.text));
    }
    get writtenAs() {
      return this.following.length > 0
        ? [
            this,
            ...this.following.flatMap((t) => {
              var r;
              return (r = t.writtenAs) !== null && r !== void 0 ? r : t;
            }),
          ]
        : void 0;
    }
  },
  Ye = class extends te {
    constructor(e) {
      super(typeof e == "string" ? { text: e } : e);
    }
  },
  uu = class extends _ {
    constructor(...e) {
      (super(...e),
        p(this, "xmlKeys", { char: "w:char", symbolfont: "w:font" }));
    }
  },
  Ms = class extends y {
    constructor(e = "", t = "Wingdings") {
      (super("w:sym"), this.root.push(new uu({ char: e, symbolfont: t })));
    }
  },
  du = class extends te {
    constructor(e) {
      (super(typeof e == "string" ? {} : e),
        this.root.push(
          typeof e == "string" ? new Ms(e) : new Ms(e.char, e.symbolfont),
        ));
    }
  },
  hu = (e) => {
    const t = e.indexOf(";base64,"),
      r = t === -1 ? 0 : t + 8;
    return new Uint8Array(
      atob(e.substring(r))
        .split("")
        .map((n) => n.charCodeAt(0)),
    );
  },
  ns = (e) => (typeof e == "string" ? hu(e) : e),
  mu = [
    ["png", [137, 80, 78, 71, 13, 10, 26, 10]],
    ["jpg", [255, 216, 255]],
    ["gif", [71, 73, 70, 56, 55, 97]],
    ["gif", [71, 73, 70, 56, 57, 97]],
    ["bmp", [66, 77]],
  ],
  So = ({ type: e, data: t }, r) => {
    if (e !== void 0) return e;
    const n = ns(t),
      s = ArrayBuffer.isView(n)
        ? new Uint8Array(n.buffer, n.byteOffset, n.byteLength)
        : new Uint8Array(n),
      a = mu.find(([, o]) => o.every((i, l) => s[l] === i));
    if (a === void 0)
      throw new Error(
        `${r}: type isn't given, and data isn't a PNG, JPEG, GIF or BMP file to read it from. Give its type`,
      );
    return a[0];
  },
  pu = {
    CHARACTER: "character",
    COLUMN: "column",
    INSIDE_MARGIN: "insideMargin",
    LEFT_MARGIN: "leftMargin",
    MARGIN: "margin",
    OUTSIDE_MARGIN: "outsideMargin",
    PAGE: "page",
    RIGHT_MARGIN: "rightMargin",
  },
  vu = {
    BOTTOM_MARGIN: "bottomMargin",
    INSIDE_MARGIN: "insideMargin",
    LINE: "line",
    MARGIN: "margin",
    OUTSIDE_MARGIN: "outsideMargin",
    PAGE: "page",
    PARAGRAPH: "paragraph",
    TOP_MARGIN: "topMargin",
  },
  fu = () =>
    new x({
      name: "wp:simplePos",
      attributes: { x: { key: "x", value: 0 }, y: { key: "y", value: 0 } },
    }),
  Ao = (e) => new x({ name: "wp:align", children: [e] }),
  Io = (e) => new x({ name: "wp:posOffset", children: [e.toString()] }),
  wu = ({ relative: e, align: t, offset: r }) =>
    new x({
      name: "wp:positionH",
      attributes: {
        relativeFrom: { key: "relativeFrom", value: e ?? pu.PAGE },
      },
      children: [
        (() => {
          if (t) return Ao(t);
          if (r !== void 0) return Io(r);
          throw new Error(
            "There is no configuration provided for floating position (Align or offset)",
          );
        })(),
      ],
    }),
  gu = ({ relative: e, align: t, offset: r }) =>
    new x({
      name: "wp:positionV",
      attributes: {
        relativeFrom: { key: "relativeFrom", value: e ?? vu.PAGE },
      },
      children: [
        (() => {
          if (t) return Ao(t);
          if (r !== void 0) return Io(r);
          throw new Error(
            "There is no configuration provided for floating position (Align or offset)",
          );
        })(),
      ],
    }),
  og = (function (e) {
    return ((e.CENTER = "ctr"), (e.TOP = "t"), (e.BOTTOM = "b"), e);
  })({}),
  yu = (e = {}) => {
    var t, r, n, s;
    return new x({
      name: "wps:bodyPr",
      attributes: {
        lIns: {
          key: "lIns",
          value: (t = e.margins) === null || t === void 0 ? void 0 : t.left,
        },
        rIns: {
          key: "rIns",
          value: (r = e.margins) === null || r === void 0 ? void 0 : r.right,
        },
        tIns: {
          key: "tIns",
          value: (n = e.margins) === null || n === void 0 ? void 0 : n.top,
        },
        bIns: {
          key: "bIns",
          value: (s = e.margins) === null || s === void 0 ? void 0 : s.bottom,
        },
        anchor: { key: "anchor", value: e.verticalAnchor },
      },
      children: [...(e.noAutoFit ? [new N("a:noAutofit", e.noAutoFit)] : [])],
    });
  },
  xu = (e = { txBox: "1" }) =>
    new x({
      name: "wps:cNvSpPr",
      attributes: { txBox: { key: "txBox", value: e.txBox } },
    }),
  bu = (e) => new x({ name: "w:txbxContent", children: [...e] }),
  Tu = (e) => new x({ name: "wps:txbx", children: [bu(e)] }),
  Eu = class extends _ {
    constructor(...e) {
      (super(...e), p(this, "xmlKeys", { cx: "cx", cy: "cy" }));
    }
  },
  Co = class extends y {
    constructor(e, t) {
      (super("a:ext"),
        p(this, "attributes", void 0),
        (this.attributes = new Eu({ cx: e, cy: t })),
        this.root.push(this.attributes));
    }
  },
  Su = class extends _ {
    constructor(...e) {
      (super(...e), p(this, "xmlKeys", { x: "x", y: "y" }));
    }
  },
  No = class extends y {
    constructor(e, t) {
      (super("a:off"), this.root.push(new Su({ x: e ?? 0, y: t ?? 0 })));
    }
  },
  Au = class extends _ {
    constructor(...e) {
      (super(...e),
        p(this, "xmlKeys", {
          flipVertical: "flipV",
          flipHorizontal: "flipH",
          rotation: "rot",
        }));
    }
  },
  Iu = class extends y {
    constructor(e) {
      var t, r, n, s;
      (super("a:xfrm"),
        p(this, "extents", void 0),
        p(this, "offset", void 0),
        this.root.push(
          new Au({
            flipVertical:
              (t = e.flip) === null || t === void 0 ? void 0 : t.vertical,
            flipHorizontal:
              (r = e.flip) === null || r === void 0 ? void 0 : r.horizontal,
            rotation: e.rotation,
          }),
        ),
        (this.offset = new No(
          (n = e.offset) === null ||
            n === void 0 ||
            (n = n.emus) === null ||
            n === void 0
            ? void 0
            : n.x,
          (s = e.offset) === null ||
            s === void 0 ||
            (s = s.emus) === null ||
            s === void 0
            ? void 0
            : s.y,
        )),
        (this.extents = new Co(e.emus.x, e.emus.y)),
        this.root.push(this.offset),
        this.root.push(this.extents));
    }
  },
  ko = () => new x({ name: "a:noFill" }),
  Cu = (e) =>
    new x({
      name: "a:srgbClr",
      attributes: { value: { key: "val", value: e.value } },
    }),
  ig = {
    BG1: "bg1",
    TX1: "tx1",
    BG2: "bg2",
    TX2: "tx2",
    ACCENT1: "accent1",
    ACCENT2: "accent2",
    ACCENT3: "accent3",
    ACCENT4: "accent4",
    ACCENT5: "accent5",
    ACCENT6: "accent6",
    HLINK: "hlink",
    FOLHLINK: "folHlink",
    DK1: "dk1",
    LT1: "lt1",
    DK2: "dk2",
    LT2: "lt2",
    PHCLR: "phClr",
  },
  Nu = (e) =>
    new x({
      name: "a:schemeClr",
      attributes: { value: { key: "val", value: e.value } },
    }),
  An = (e) =>
    new x({
      name: "a:solidFill",
      children: [e.type === "rgb" ? Cu(e) : Nu(e)],
    }),
  ku = { ROUND: "rnd", SQUARE: "sq", FLAT: "flat" },
  Ru = {
    SINGLE: "sng",
    DOUBLE: "dbl",
    THICK_THIN: "thickThin",
    THIN_THICK: "thinThick",
    TRI: "tri",
  },
  Pu = { CENTER: "ctr", INSET: "in" },
  Ou = (e) =>
    new x({
      name: "a:ln",
      attributes: {
        width: { key: "w", value: e.width },
        cap: { key: "cap", value: e.cap === void 0 ? void 0 : ku[e.cap] },
        compoundLine: {
          key: "cmpd",
          value: e.compoundLine === void 0 ? void 0 : Ru[e.compoundLine],
        },
        align: {
          key: "algn",
          value: e.align === void 0 ? void 0 : Pu[e.align],
        },
      },
      children: [
        e.type === "noFill"
          ? ko()
          : e.solidFillType === "rgb"
            ? An({ type: "rgb", value: e.value })
            : An({ type: "scheme", value: e.value }),
      ],
    }),
  _u = class extends y {
    constructor() {
      super("a:avLst");
    }
  },
  Lu = class extends _ {
    constructor(...e) {
      (super(...e), p(this, "xmlKeys", { prst: "prst" }));
    }
  },
  Du = class extends y {
    constructor() {
      (super("a:prstGeom"),
        this.root.push(new Lu({ prst: "rect" })),
        this.root.push(new _u()));
    }
  },
  Mu = class extends _ {
    constructor(...e) {
      (super(...e), p(this, "xmlKeys", { bwMode: "bwMode" }));
    }
  },
  Ro = class extends y {
    constructor({ element: e, outline: t, solidFill: r, transform: n }) {
      (super(`${e}:spPr`),
        p(this, "form", void 0),
        this.root.push(new Mu({ bwMode: "auto" })),
        (this.form = new Iu(n)),
        this.root.push(this.form),
        this.root.push(new Du()),
        r ? this.root.push(An(r)) : t && this.root.push(ko()),
        t && this.root.push(Ou(t)));
    }
  },
  Fs = (e) =>
    new x({
      name: "wps:wsp",
      children: [
        xu(e.nonVisualProperties),
        new Ro({
          element: "wps",
          transform: e.transformation,
          outline: e.outline,
          solidFill: e.solidFill,
        }),
        Tu(e.children),
        yu(e.bodyProperties),
      ],
    }),
  Zt = class extends _ {
    constructor(...e) {
      (super(...e), p(this, "xmlKeys", { uri: "uri" }));
    }
  },
  Fu = (e) =>
    new x({
      name: "asvg:svgBlip",
      attributes: {
        asvg: {
          key: "xmlns:asvg",
          value: "http://schemas.microsoft.com/office/drawing/2016/SVG/main",
        },
        embed: { key: "r:embed", value: `rId{${e.fileName}}` },
      },
    }),
  $u = (e) =>
    new x({
      name: "a:ext",
      attributes: {
        uri: { key: "uri", value: "{96DAC541-7B7A-43D3-8B79-37D633B846F1}" },
      },
      children: [Fu(e)],
    }),
  Hu = (e) => new x({ name: "a:extLst", children: [$u(e)] }),
  Bu = (e) =>
    new x({
      name: "a:blip",
      attributes: {
        embed: {
          key: "r:embed",
          value: `rId{${e.type === "svg" ? e.fallback.fileName : e.fileName}}`,
        },
        cstate: { key: "cstate", value: "none" },
      },
      children: e.type === "svg" ? [Hu(e)] : [],
    }),
  Wu = class extends _ {
    constructor(...e) {
      (super(...e),
        p(this, "xmlKeys", { left: "l", top: "t", right: "r", bottom: "b" }));
    }
  },
  Qt = (e, t) => {
    if (e !== void 0) {
      if (!(e >= 0 && e <= 100))
        throw new Error(
          `Invalid crop ${t} ${e}. Expected a number from 0 to 100`,
        );
      return Math.round(e * 1e3);
    }
  },
  Uu = class extends y {
    constructor(e) {
      (super("a:srcRect"),
        e &&
          this.root.push(
            new Wu({
              left: Qt(e.left, "left"),
              top: Qt(e.top, "top"),
              right: Qt(e.right, "right"),
              bottom: Qt(e.bottom, "bottom"),
            }),
          ));
    }
  },
  Gu = class extends y {
    constructor() {
      super("a:fillRect");
    }
  },
  ju = class extends y {
    constructor() {
      (super("a:stretch"), this.root.push(new Gu()));
    }
  },
  Vu = class extends y {
    constructor(e, t) {
      (super("pic:blipFill"),
        this.root.push(Bu(e)),
        this.root.push(new Uu(t)),
        this.root.push(new ju()));
    }
  },
  Xu = class extends _ {
    constructor(...e) {
      (super(...e),
        p(this, "xmlKeys", {
          noChangeAspect: "noChangeAspect",
          noChangeArrowheads: "noChangeArrowheads",
        }));
    }
  },
  Ku = class extends y {
    constructor() {
      (super("a:picLocks"),
        this.root.push(new Xu({ noChangeAspect: 1, noChangeArrowheads: 1 })));
    }
  },
  zu = class extends y {
    constructor() {
      (super("pic:cNvPicPr"), this.root.push(new Ku()));
    }
  },
  Yu = class extends _ {
    constructor(...e) {
      (super(...e),
        p(this, "xmlKeys", { id: "id", name: "name", descr: "descr" }));
    }
  },
  qu = class extends y {
    constructor() {
      (super("pic:cNvPr"),
        this.root.push(new Yu({ id: 0, name: "", descr: "" })));
    }
    prepForXml(e) {
      for (let r = e.stack.length - 1; r >= 0; r--) {
        const n = e.stack[r];
        if (n instanceof Kt) {
          this.root.push(n.createDrawingClick(e, !1));
          break;
        }
      }
      const t = super.prepForXml(e);
      return (this.root.splice(1), t);
    }
  },
  Ju = class extends y {
    constructor() {
      (super("pic:nvPicPr"),
        this.root.push(new qu()),
        this.root.push(new zu()));
    }
  },
  Zu = class extends _ {
    constructor(...e) {
      (super(...e), p(this, "xmlKeys", { xmlns: "xmlns:pic" }));
    }
  },
  $s = class extends y {
    constructor({
      mediaData: e,
      transform: t,
      outline: r,
      solidFill: n,
      crop: s,
    }) {
      (super("pic:pic"),
        this.root.push(
          new Zu({
            xmlns: "http://schemas.openxmlformats.org/drawingml/2006/picture",
          }),
        ),
        this.root.push(new Ju()),
        this.root.push(new Vu(e, s)),
        this.root.push(
          new Ro({ element: "pic", transform: t, outline: r, solidFill: n }),
        ));
    }
  },
  Qu = (e) => {
    var t, r, n, s;
    return new x({
      name: "a:xfrm",
      attributes: {
        flipVertical: {
          key: "flipV",
          value: (t = e.flip) === null || t === void 0 ? void 0 : t.vertical,
        },
        flipHorizontal: {
          key: "flipH",
          value: (r = e.flip) === null || r === void 0 ? void 0 : r.horizontal,
        },
        rotation: { key: "rot", value: e.rotation },
      },
      children: [
        new No(
          (n = e.offset) === null ||
            n === void 0 ||
            (n = n.emus) === null ||
            n === void 0
            ? void 0
            : n.x,
          (s = e.offset) === null ||
            s === void 0 ||
            (s = s.emus) === null ||
            s === void 0
            ? void 0
            : s.y,
        ),
        new Co(e.emus.x, e.emus.y),
        new x({
          name: "a:chOff",
          attributes: { x: { key: "x", value: 0 }, y: { key: "y", value: 0 } },
        }),
        new x({
          name: "a:chExt",
          attributes: {
            x: { key: "cx", value: e.emus.x },
            y: { key: "cy", value: e.emus.y },
          },
        }),
      ],
    });
  },
  ed = () => new x({ name: "wpg:cNvGrpSpPr" }),
  td = (e) =>
    new x({
      name: "wpg:wgp",
      children: [
        ed(),
        new x({ name: "wpg:grpSpPr", children: [Qu(e.transformation)] }),
        ...e.children,
      ],
    }),
  rd = class extends y {
    constructor({
      mediaData: e,
      transform: t,
      outline: r,
      solidFill: n,
      crop: s,
    }) {
      if ((super("a:graphicData"), e.type === "graphic"))
        (this.root.push(new Zt({ uri: e.uri })), this.root.push(e.content));
      else if (e.type === "wps") {
        this.root.push(
          new Zt({
            uri: "http://schemas.microsoft.com/office/word/2010/wordprocessingShape",
          }),
        );
        const a = Fs(
          f(f({}, e.data), {}, { transformation: t, outline: r, solidFill: n }),
        );
        this.root.push(a);
      } else if (e.type === "wpg") {
        this.root.push(
          new Zt({
            uri: "http://schemas.microsoft.com/office/word/2010/wordprocessingGroup",
          }),
        );
        const a = td({
          children: e.children.map((o) =>
            o.type === "wps"
              ? Fs(
                  f(
                    f({}, o.data),
                    {},
                    {
                      transformation: o.transformation,
                      outline: o.outline,
                      solidFill: o.solidFill,
                    },
                  ),
                )
              : new $s({
                  mediaData: o,
                  transform: o.transformation,
                  outline: o.outline,
                  solidFill: o.solidFill,
                }),
          ),
          transformation: t,
        });
        this.root.push(a);
      } else {
        this.root.push(
          new Zt({
            uri: "http://schemas.openxmlformats.org/drawingml/2006/picture",
          }),
        );
        const a = new $s({
          mediaData: e,
          transform: t,
          outline: r,
          solidFill: n,
          crop: s,
        });
        this.root.push(a);
      }
    }
  },
  nd = class extends _ {
    constructor(...e) {
      (super(...e), p(this, "xmlKeys", { a: "xmlns:a" }));
    }
  },
  Po = class extends y {
    constructor({
      mediaData: e,
      transform: t,
      outline: r,
      solidFill: n,
      crop: s,
    }) {
      (super("a:graphic"),
        p(this, "data", void 0),
        this.root.push(
          new nd({
            a: "http://schemas.openxmlformats.org/drawingml/2006/main",
          }),
        ),
        (this.data = new rd({
          mediaData: e,
          transform: t,
          outline: r,
          solidFill: n,
          crop: s,
        })),
        this.root.push(this.data));
    }
  },
  At = { NONE: 0, SQUARE: 1, TIGHT: 2, TOP_AND_BOTTOM: 3, THROUGH: 4 },
  Oo = {
    BOTH_SIDES: "bothSides",
    LEFT: "left",
    RIGHT: "right",
    LARGEST: "largest",
  },
  Hs = () => new x({ name: "wp:wrapNone" }),
  sd = (e, t = { top: 0, bottom: 0, left: 0, right: 0 }) =>
    new x({
      name: "wp:wrapSquare",
      attributes: {
        wrapText: { key: "wrapText", value: e.side || Oo.BOTH_SIDES },
        distT: { key: "distT", value: t.top },
        distB: { key: "distB", value: t.bottom },
        distL: { key: "distL", value: t.left },
        distR: { key: "distR", value: t.right },
      },
    }),
  er = 21600,
  It = (e, { x: t, y: r }) =>
    new x({
      name: e,
      attributes: { x: { key: "x", value: t }, y: { key: "y", value: r } },
    }),
  ad = () =>
    new x({
      name: "wp:wrapPolygon",
      attributes: { edited: { key: "edited", value: !1 } },
      children: [
        It("wp:start", { x: 0, y: 0 }),
        It("wp:lineTo", { x: 0, y: er }),
        It("wp:lineTo", { x: er, y: er }),
        It("wp:lineTo", { x: er, y: 0 }),
        It("wp:lineTo", { x: 0, y: 0 }),
      ],
    }),
  _o = (e, t = {}, r) => {
    var n;
    return new x({
      name: e,
      attributes: {
        wrapText: {
          key: "wrapText",
          value: (n = r?.side) !== null && n !== void 0 ? n : Oo.BOTH_SIDES,
        },
        distL: { key: "distL", value: t.left },
        distR: { key: "distR", value: t.right },
      },
      children: [ad()],
    });
  },
  od = (e, t) => _o("wp:wrapTight", e, t),
  id = (e, t) => _o("wp:wrapThrough", e, t),
  ld = (e = { top: 0, bottom: 0 }) =>
    new x({
      name: "wp:wrapTopAndBottom",
      attributes: {
        distT: { key: "distT", value: e.top },
        distB: { key: "distB", value: e.bottom },
      },
    }),
  ss = { EXTERNAL: "External" },
  cd = (e, t, r, n) =>
    new x({
      name: "Relationship",
      attributes: {
        id: { key: "Id", value: e },
        type: { key: "Type", value: t },
        target: { key: "Target", value: r },
        targetMode: { key: "TargetMode", value: n },
      },
    }),
  Lo = (e, t) =>
    new x({
      name: "a:hlinkClick",
      attributes: f(
        f(
          {},
          t
            ? {
                xmlns: {
                  key: "xmlns:a",
                  value:
                    "http://schemas.openxmlformats.org/drawingml/2006/main",
                },
              }
            : {},
        ),
        {},
        { id: { key: "r:id", value: `rId${e}` } },
      ),
    }),
  ud = "{C183D7F6-B498-43B3-948B-1728B52AA6E4}",
  Do = (e) =>
    new x({
      name: "a:extLst",
      attributes: {
        namespace: {
          key: "xmlns:a",
          value: e
            ? "http://schemas.openxmlformats.org/drawingml/2006/main"
            : void 0,
        },
      },
      children: [
        new x({
          name: "a:ext",
          attributes: { uri: { key: "uri", value: ud } },
          children: [
            new x({
              name: "adec:decorative",
              attributes: {
                namespace: {
                  key: "xmlns:adec",
                  value:
                    "http://schemas.microsoft.com/office/drawing/2017/decorative",
                },
                value: { key: "val", value: 1 },
              },
            }),
          ],
        }),
      ],
    }),
  as = class {
    constructor(e) {
      (p(this, "link", void 0),
        p(this, "linkId", at()),
        p(this, "addedTo", new WeakSet()),
        (this.link = e));
    }
    createClick(e) {
      return Lo(this.linkId, e);
    }
    addRelationship(e) {
      const t = e.viewWrapper.Relationships;
      this.addedTo.has(t) ||
        (this.addedTo.add(t),
        t.addRelationship(
          this.linkId,
          "http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink",
          this.link,
          ss.EXTERNAL,
        ));
    }
  },
  lg = class extends y {
    constructor(
      e,
      { id: t, name: r, description: n, title: s, link: a, decorative: o },
    ) {
      (super(e),
        p(this, "link", void 0),
        (this.link = a === void 0 ? void 0 : new as(a)),
        this.root.push(
          new Sr({
            id: { key: "id", value: t },
            name: { key: "name", value: r },
            description: { key: "descr", value: n },
            title: { key: "title", value: s },
          }),
        ),
        this.link && this.root.push(this.link.createClick(!1)),
        o && this.root.push(Do(!1)));
    }
    prepForXml(e) {
      var t;
      return (
        (t = this.link) === null || t === void 0 || t.addRelationship(e),
        super.prepForXml(e)
      );
    }
  },
  Mo = class extends y {
    constructor(
      { name: e = "", description: t, title: r, id: n } = {},
      { link: s, decorative: a } = {},
    ) {
      (super("wp:docPr"),
        p(this, "link", void 0),
        p(this, "decorative", void 0));
      const o = {
        id: { key: "id", value: n ?? Yc() },
        name: { key: "name", value: e },
      };
      (t && (o.description = { key: "descr", value: t }),
        r && (o.title = { key: "title", value: r }),
        this.root.push(new Sr(o)),
        (this.link = s === void 0 ? void 0 : new as(s)),
        (this.decorative = a));
    }
    prepForXml(e) {
      if (this.link)
        (this.link.addRelationship(e),
          this.root.push(this.link.createClick(!0)));
      else
        for (let r = e.stack.length - 1; r >= 0; r--) {
          const n = e.stack[r];
          if (n instanceof Kt) {
            this.root.push(n.createDrawingClick(e, !0));
            break;
          }
        }
      this.decorative && this.root.push(Do(!0));
      const t = super.prepForXml(e);
      return (this.root.splice(1), t);
    }
  },
  Fo = ({ top: e, right: t, bottom: r, left: n }) =>
    new x({
      name: "wp:effectExtent",
      attributes: {
        top: { key: "t", value: e },
        right: { key: "r", value: t },
        bottom: { key: "b", value: r },
        left: { key: "l", value: n },
      },
    }),
  Gr = 2147483647,
  Bs = 9525,
  Ws = (e, t) => {
    if (t !== void 0 && t > Gr)
      throw new Error(
        `Invalid drawing ${e} ${t} EMUs (${Math.round(t / Bs)} pixels). Word won't open a drawing with a ${e} over ${Gr} EMUs (${Math.floor(Gr / Bs)} pixels). Sizes such as an ImageRun's transformation are in pixels, not EMUs`,
      );
    return t;
  },
  $o = ({ x: e, y: t }) =>
    new x({
      name: "wp:extent",
      attributes: {
        x: { key: "cx", value: Ws("width", e) },
        y: { key: "cy", value: Ws("height", t) },
      },
    }),
  dd = class extends _ {
    constructor(...e) {
      (super(...e),
        p(this, "xmlKeys", {
          xmlns: "xmlns:a",
          noChangeAspect: "noChangeAspect",
        }));
    }
  },
  hd = class extends y {
    constructor() {
      (super("a:graphicFrameLocks"),
        this.root.push(
          new dd({
            xmlns: "http://schemas.openxmlformats.org/drawingml/2006/main",
            noChangeAspect: 1,
          }),
        ));
    }
  },
  Ho = (e = !0) =>
    new x({ name: "wp:cNvGraphicFramePr", children: e ? [new hd()] : [] }),
  md = class extends _ {
    constructor(...e) {
      (super(...e),
        p(this, "xmlKeys", {
          distT: "distT",
          distB: "distB",
          distL: "distL",
          distR: "distR",
          allowOverlap: "allowOverlap",
          behindDoc: "behindDoc",
          layoutInCell: "layoutInCell",
          locked: "locked",
          relativeHeight: "relativeHeight",
          simplePos: "simplePos",
        }));
    }
  },
  pd = class extends y {
    constructor({ mediaData: e, transform: t, drawingOptions: r }) {
      var n;
      super("wp:anchor");
      const s = f(
        {
          allowOverlap: !0,
          behindDocument: !1,
          lockAnchor: !1,
          layoutInCell: !0,
          verticalPosition: {},
          horizontalPosition: {},
        },
        r.floating,
      );
      if (
        (this.root.push(
          new md({
            distT: (s.margins && s.margins.top) || 0,
            distB: (s.margins && s.margins.bottom) || 0,
            distL: (s.margins && s.margins.left) || 0,
            distR: (s.margins && s.margins.right) || 0,
            simplePos: "0",
            allowOverlap: s.allowOverlap === !0 ? "1" : "0",
            behindDoc: s.behindDocument === !0 ? "1" : "0",
            locked: s.lockAnchor === !0 ? "1" : "0",
            layoutInCell: s.layoutInCell === !0 ? "1" : "0",
            relativeHeight: s.zIndex ? s.zIndex : t.emus.y,
          }),
        ),
        this.root.push(fu()),
        this.root.push(wu(s.horizontalPosition)),
        this.root.push(gu(s.verticalPosition)),
        this.root.push($o({ x: t.emus.x, y: t.emus.y })),
        this.root.push(
          Fo(
            (n = r.effectExtent) !== null && n !== void 0
              ? n
              : { top: 0, right: 0, bottom: 0, left: 0 },
          ),
        ),
        r.floating !== void 0 && r.floating.wrap !== void 0)
      )
        switch (r.floating.wrap.type) {
          case At.SQUARE:
            this.root.push(sd(r.floating.wrap, r.floating.margins));
            break;
          case At.TIGHT:
            this.root.push(od(r.floating.margins, r.floating.wrap));
            break;
          case At.THROUGH:
            this.root.push(id(r.floating.margins, r.floating.wrap));
            break;
          case At.TOP_AND_BOTTOM:
            this.root.push(ld(r.floating.margins));
            break;
          case At.NONE:
          default:
            this.root.push(Hs());
        }
      else this.root.push(Hs());
      (this.root.push(
        new Mo(r.docProperties, { link: r.link, decorative: r.decorative }),
      ),
        this.root.push(Ho(e.type !== "graphic" || e.lockAspectRatio !== !1)),
        this.root.push(
          new Po({
            mediaData: e,
            transform: t,
            outline: r.outline,
            solidFill: r.solidFill,
            crop: r.crop,
          }),
        ));
    }
  },
  vd = ({
    mediaData: e,
    transform: t,
    docProperties: r,
    outline: n,
    solidFill: s,
    crop: a,
    effectExtent: o,
    link: i,
    decorative: l,
  }) => {
    var c, u, d, h;
    return new x({
      name: "wp:inline",
      attributes: {
        distanceTop: { key: "distT", value: 0 },
        distanceBottom: { key: "distB", value: 0 },
        distanceLeft: { key: "distL", value: 0 },
        distanceRight: { key: "distR", value: 0 },
      },
      children: [
        $o({ x: t.emus.x, y: t.emus.y }),
        Fo(
          o ??
            (n
              ? {
                  top: ((c = n.width) !== null && c !== void 0 ? c : 9525) * 2,
                  right:
                    ((u = n.width) !== null && u !== void 0 ? u : 9525) * 2,
                  bottom:
                    ((d = n.width) !== null && d !== void 0 ? d : 9525) * 2,
                  left: ((h = n.width) !== null && h !== void 0 ? h : 9525) * 2,
                }
              : { top: 0, right: 0, bottom: 0, left: 0 }),
        ),
        new Mo(r, { link: i, decorative: l }),
        Ho(e.type !== "graphic" || e.lockAspectRatio !== !1),
        new Po({
          mediaData: e,
          transform: t,
          outline: n,
          solidFill: s,
          crop: a,
        }),
      ],
    });
  },
  os = class extends y {
    constructor(e, t = {}) {
      (super("w:drawing"),
        t.floating
          ? this.root.push(
              new pd({
                mediaData: e,
                transform: e.transformation,
                drawingOptions: t,
              }),
            )
          : this.root.push(
              vd({
                mediaData: e,
                transform: e.transformation,
                docProperties: t.docProperties,
                outline: t.outline,
                solidFill: t.solidFill,
                crop: t.crop,
                effectExtent: t.effectExtent,
                link: t.link,
                decorative: t.decorative,
              }),
            ));
    }
  },
  Bo = (e, t) => ({
    data: ns(e.data),
    fileName: t,
    transformation: {
      pixels: {
        x: Math.round(e.transformation.width),
        y: Math.round(e.transformation.height),
      },
      emus: {
        x: Math.round(e.transformation.width * 9525),
        y: Math.round(e.transformation.height * 9525),
      },
      flip: e.transformation.flip,
      rotation: e.transformation.rotation
        ? e.transformation.rotation * 6e4
        : void 0,
    },
  }),
  Us = (e, t, r) => {
    const n = So(e, r);
    return f(
      { type: n },
      Bo(f(f({}, e), {}, { transformation: t }), `${yo(e.data)}.${n}`),
    );
  },
  fd = ({ id: e, author: t, date: r }, n) =>
    new x({
      name: "w:del",
      attributes: {
        id: { key: "w:id", value: e },
        author: { key: "w:author", value: t },
        date: { key: "w:date", value: r },
      },
      children: [n],
    }),
  cg = class extends y {
    constructor(e) {
      var t;
      const r =
          e.type === "svg"
            ? f(
                f({ type: e.type }, Bo(e, `${yo(e.data)}.svg`)),
                {},
                {
                  fallback: Us(
                    e.fallback,
                    e.transformation,
                    "ImageRun fallback",
                  ),
                },
              )
            : Us(e, e.transformation, "ImageRun"),
        n = new os(r, {
          floating: e.floating,
          docProperties: e.altText,
          outline: e.outline,
          solidFill: e.solidFill,
          crop: e.crop,
          link: e.link,
          decorative: e.decorative,
        }),
        s = new Qe(e.run),
        a = (t = e.insertion) !== null && t !== void 0 ? t : e.deletion,
        o = e.insertion ? "w:ins" : e.deletion ? "w:del" : "w:r";
      if ((super(o), p(this, "imageData", void 0), a)) {
        this.root.push(new ge({ id: a.id, author: a.author, date: a.date }));
        const i = new x({ name: "w:r", children: [s, n] });
        this.addChildElement(e.insertion && e.deletion ? fd(e.deletion, i) : i);
      } else (this.root.push(s), this.root.push(n));
      this.imageData = r;
    }
    prepForXml(e) {
      return (
        e.file.Media.addImage(this.imageData.fileName, this.imageData),
        this.imageData.type === "svg" &&
          e.file.Media.addImage(
            this.imageData.fallback.fileName,
            this.imageData.fallback,
          ),
        super.prepForXml(e)
      );
    }
  },
  Wo = (e) => {
    var t, r, n, s, a, o, i, l;
    return {
      offset: {
        pixels: {
          x: Math.round(
            (t = (r = e.offset) === null || r === void 0 ? void 0 : r.left) !==
              null && t !== void 0
              ? t
              : 0,
          ),
          y: Math.round(
            (n = (s = e.offset) === null || s === void 0 ? void 0 : s.top) !==
              null && n !== void 0
              ? n
              : 0,
          ),
        },
        emus: {
          x: Math.round(
            ((a = (o = e.offset) === null || o === void 0 ? void 0 : o.left) !==
              null && a !== void 0
              ? a
              : 0) * 9525,
          ),
          y: Math.round(
            ((i = (l = e.offset) === null || l === void 0 ? void 0 : l.top) !==
              null && i !== void 0
              ? i
              : 0) * 9525,
          ),
        },
      },
      pixels: { x: Math.round(e.width), y: Math.round(e.height) },
      emus: { x: Math.round(e.width * 9525), y: Math.round(e.height * 9525) },
      flip: e.flip,
      rotation: e.rotation ? e.rotation * 6e4 : void 0,
    };
  },
  ug = class extends te {
    constructor(e) {
      (super({}),
        p(this, "wpsShapeData", void 0),
        (this.wpsShapeData = {
          type: e.type,
          transformation: Wo(e.transformation),
          data: f({}, e),
        }));
      const t = new os(this.wpsShapeData, {
        floating: e.floating,
        docProperties: e.altText,
        outline: e.outline,
        solidFill: e.solidFill,
      });
      this.root.push(t);
    }
  },
  dg = class extends te {
    constructor(e) {
      (super({}),
        p(this, "wpgGroupData", void 0),
        p(this, "mediaDatas", void 0),
        (this.wpgGroupData = {
          type: e.type,
          transformation: Wo(e.transformation),
          children: e.children,
        }));
      const t = new os(this.wpgGroupData, {
        floating: e.floating,
        docProperties: e.altText,
      });
      ((this.mediaDatas = e.children
        .filter((r) => r.type !== "wps")
        .map((r) => r)),
        this.root.push(t));
    }
    prepForXml(e) {
      return (
        this.mediaDatas.forEach((t) => {
          (e.file.Media.addImage(t.fileName, t),
            t.type === "svg" &&
              e.file.Media.addImage(t.fallback.fileName, t.fallback));
        }),
        super.prepForXml(e)
      );
    }
  },
  wd = class extends y {
    constructor(e) {
      (super("w:instrText"),
        this.root.push(new we({ space: fe.PRESERVE })),
        this.root.push(`SEQ ${e}`));
    }
  },
  hg = class extends te {
    constructor(e) {
      (super({}),
        this.root.push(rs()),
        this.root.push(new wd(e)),
        this.root.push(Re()),
        this.root.push(Se()));
    }
  },
  gd = /^\s*(?:XE|TC|TA|RD|PRIVATE)\b/i,
  yd = class extends y {
    constructor(e) {
      (super("w:instrText"),
        this.root.push(new we({ space: fe.PRESERVE })),
        this.root.push(e));
    }
  },
  xd = class extends _ {
    constructor(...e) {
      (super(...e),
        p(this, "xmlKeys", { instr: "w:instr", fldLock: "w:fldLock" }));
    }
  },
  Uo = class extends y {
    constructor(e, t, r = {}) {
      const n = gd.test(e);
      if ((super(n ? "w:r" : "w:fldSimple"), n)) {
        (this.root.push(Ke(void 0, r.locked ? !0 : void 0)),
          this.root.push(new yd(e)),
          this.root.push(Se()));
        return;
      }
      (this.root.push(new xd({ instr: e, fldLock: r.locked ? !0 : void 0 })),
        t !== void 0 && this.root.push(new Ye(t)));
    }
  },
  mg = class extends Uo {
    constructor(e) {
      super(` MERGEFIELD ${e} `, `«${e}»`);
    }
  },
  bd = 32767,
  Td = 780,
  Ed = [
    [1e3, "M"],
    [900, "CM"],
    [500, "D"],
    [400, "CD"],
    [100, "C"],
    [90, "XC"],
    [50, "L"],
    [40, "XL"],
    [10, "X"],
    [9, "IX"],
    [5, "V"],
    [4, "IV"],
    [1, "I"],
  ],
  Sd = (e) =>
    e <= bd
      ? Ed.reduce(
          ({ rest: t, text: r }, [n, s]) => ({
            rest: t % n,
            text: r + s.repeat(Math.floor(t / n)),
          }),
          { rest: e, text: "" },
        ).text
      : void 0,
  Ad = (e) =>
    e === 0
      ? ""
      : e <= Td
        ? String.fromCharCode(65 + ((e - 1) % 26)).repeat(Math.ceil(e / 26))
        : void 0,
  Id = (e) => {
    var t;
    return `${e}${e % 100 >= 11 && e % 100 <= 13 ? "th" : (t = ["th", "st", "nd", "rd"][e % 10]) !== null && t !== void 0 ? t : "th"}`;
  },
  is = (e) => {
    const t = e.charAt(0) !== e.charAt(0).toUpperCase(),
      r = (n) => (s) => {
        var a;
        return t
          ? (a = n(s)) === null || a === void 0
            ? void 0
            : a.toLowerCase()
          : n(s);
      };
    switch (e.toLowerCase()) {
      case "arabic":
        return String;
      case "roman":
        return r(Sd);
      case "alphabetic":
        return r(Ad);
      case "ordinal":
        return (n) => (n > 0 ? Id(n) : void 0);
      case "arabicdash":
        return (n) => `- ${n} -`;
      default:
        return;
    }
  },
  Go = new Set(["mergeformat", "charformat", "mergeformatinet"]),
  jo = new Set(["upper", "lower", "firstcap", "caps"]),
  Cd = (e) => /^[#0,]*[#0][#0,]*$/.test(e),
  Nd = (e, t) => {
    const r = [...t].filter((a) => a === "0").length,
      n = r + [...t].filter((a) => a === "#").length,
      s = String(e).padStart(r, "0");
    if (!(s.length < n || (r === 0 && e === 0)))
      return t.includes(",") ? s.replace(/\B(?=(\d{3})+$)/g, ",") : s;
  },
  kd = (e, t) => {
    switch (t) {
      case "upper":
        return e.toUpperCase();
      case "lower":
        return e.toLowerCase();
      case "firstcap":
        return e.charAt(0).toUpperCase() + e.slice(1);
      default:
        return e;
    }
  },
  Rd = (e) => {
    var t;
    const r = new RegExp(
        "^\\s*(PAGEREF|NUMPAGES|SECTIONPAGES)\\b(.*)$",
        "is",
      ).exec(e),
      n =
        r?.[1].toUpperCase() === "PAGEREF"
          ? new RegExp('^\\s*("?)([^\\s"\\\\]+)\\1(.*)$', "s").exec(r[2])
          : void 0;
    if (!r || (r[1].toUpperCase() === "PAGEREF" && !n)) return;
    const s =
      (t = (n ? n[3] : r[2]).match(/"[^"]*"|\S+/g)) !== null && t !== void 0
        ? t
        : [];
    let a, o;
    const i = [];
    let l = !1,
      c = !0;
    for (let w = 0; w < s.length; w++) {
      const m = s[w],
        v = () => {
          var g;
          return (
            m.length > 2
              ? m.slice(2)
              : (g = s[++w]) !== null && g !== void 0
                ? g
                : ""
          ).replace(/^"(.*)"$/, "$1");
        };
      if (/^\\p$/i.test(m)) l = !0;
      else if (m.startsWith("\\#")) {
        var u;
        const g = v();
        (c && (c = o === void 0 && Cd(g)),
          ((u = o) !== null && u !== void 0) || (o = g));
      } else if (m.startsWith("\\*")) {
        const g = v(),
          A = g.toLowerCase();
        if (jo.has(A)) i.push(A);
        else if (g !== "" && !Go.has(A)) {
          var d;
          (c && (c = a === void 0 && is(g) !== void 0),
            ((d = a) !== null && d !== void 0) || (a = g));
        }
      }
    }
    const h = f(
      f(
        f(
          f({}, a === void 0 ? {} : { numberFormat: a }),
          o === void 0 ? {} : { picture: o },
        ),
        i.length === 0 ? {} : { capitals: i[0] },
      ),
      {},
      {
        written:
          c &&
          i.length <= 1 &&
          i[0] !== "caps" &&
          (a === void 0 || o === void 0),
      },
    );
    return f(
      n
        ? { type: "pageReference", bookmark: n[2], relative: l }
        : {
            type: "pageCount",
            scope: r[1].toUpperCase() === "NUMPAGES" ? "document" : "section",
          },
      h,
    );
  },
  Pd = (e) => new RegExp("^\\s*TOC\\b.*\\\\s\\b", "is").test(e),
  Vo = (
    e,
    { enclosing: t, within: r, inTextBox: n },
    { estimate: s, sectionPageCount: a, blank: o, relativeTo: i },
  ) => {
    const l = Rd(e);
    if (l === void 0) return;
    const { bookmarks: c, pageCount: u, bookmarkPageNumbers: d } = s,
      { numberFormat: h, picture: w, capitals: m, written: v } = l,
      g = h !== void 0 || w !== void 0,
      A = (R) =>
        R === void 0 ? void 0 : w === void 0 ? is(h ?? "arabic")(R) : Nd(R, w),
      I =
        l.type === "pageReference" && l.relative && r === "counted" && !n
          ? i?.(l.bookmark)
          : void 0;
    let b;
    return (
      v
        ? l.type === "pageCount"
          ? (b = A(l.scope === "document" ? u : a))
          : t.some(Pd)
            ? (b = void 0)
            : g
              ? (b = A(d?.get(l.bookmark)))
              : (b = l.relative ? I : c.get(l.bookmark))
        : (b = void 0),
      b === void 0 ? (o ? "" : void 0) : kd(b, m)
    );
  },
  Od = (e, t) =>
    e === "mc:Fallback" || t === "fallback"
      ? "fallback"
      : e === "w:del" || e === "w:moveFrom"
        ? "deleted"
        : t,
  $t = (e, t, r, n, s = "counted", a = !1) => {
    for (let c = 0; c < t.length; c++) {
      const u = t[c],
        d = e.nameOf(u);
      if (d === void 0) continue;
      const h = r[r.length - 1];
      if (d === "w:fldChar") {
        const w = e.attributeOf(u, "w:fldCharType");
        w === "begin"
          ? r.push({ begin: u, instruction: "", inResult: !1 })
          : w === "separate" && h
            ? (e.writeClean(h.begin, h.instruction),
              (h.inResult = !0),
              (h.result = n.resultOf(h.instruction, {
                within: s,
                enclosing: r.slice(0, -1).map((m) => m.instruction),
                inTextBox: a,
              })),
              h.result !== void 0 &&
                (t.splice(c + 1, 0, e.textElement(h.result)), c++))
            : w === "end" && r.pop();
      } else if (d === "w:instrText" && h && !h.inResult)
        h.instruction += e.textOf(u);
      else if (
        (d === "w:t" || d === "w:tab" || d === "w:br" || d === "w:cr") &&
        h?.result !== void 0
      )
        (t.splice(c, 1), c--);
      else if (d === "w:fldSimple") {
        const w = n.resultOf(String(e.attributeOf(u, "w:instr")), {
          within: s,
          enclosing: r.map((m) => m.instruction),
          inTextBox: a,
        });
        if (w === void 0) {
          var o;
          $t(
            e,
            (o = e.contentOf(u)) !== null && o !== void 0 ? o : [],
            [],
            n,
            s,
            a,
          );
        } else e.setSimpleFieldResult(u, w);
      } else {
        var i;
        if (d === "w:p") {
          var l;
          (l = n.beforeParagraph) === null || l === void 0 || l.call(n, u);
        }
        ($t(
          e,
          (i = e.contentOf(u)) !== null && i !== void 0 ? i : [],
          r,
          n,
          Od(d, s),
          a || d === "w:txbxContent",
        ),
          d === "w:p" && n.afterParagraph(u));
      }
    }
  },
  Xo = (e, t) =>
    t.flatMap((r) => {
      var n;
      const s = e.nameOf(r);
      return s === void 0
        ? []
        : s === "w:sectPr"
          ? [r]
          : Xo(e, (n = e.contentOf(r)) !== null && n !== void 0 ? n : []);
    }),
  _d = (e, t) => {
    var r;
    return ((r = e.contentOf(t)) !== null && r !== void 0 ? r : []).some(
      (n) => {
        var s;
        return (
          e.nameOf(n) === "w:pPr" &&
          ((s = e.contentOf(n)) !== null && s !== void 0 ? s : []).some(
            (a) => e.nameOf(a) === "w:sectPr",
          )
        );
      },
    );
  },
  Ld = (e, t, r) => {
    const n = Xo(e, [t])
      .reduce((s, a) => {
        var o, i;
        const l = (
          (o = e.contentOf(a)) !== null && o !== void 0 ? o : []
        ).flatMap((c) => {
          const u = e.nameOf(c);
          return u === "w:headerReference" || u === "w:footerReference"
            ? [
                [
                  `${u} ${String(e.attributeOf(c, "w:type"))}`,
                  String(e.attributeOf(c, "r:id")),
                ],
              ]
            : [];
        });
        return [
          ...s,
          new Map([
            ...((i = s[s.length - 1]) !== null && i !== void 0 ? i : []),
            ...l,
          ]),
        ];
      }, [])
      .reduce((s, a, o) => {
        for (const l of a.values()) {
          var i;
          s.set(l, [
            ...((i = s.get(l)) !== null && i !== void 0 ? i : []),
            r[o],
          ]);
        }
        return s;
      }, new Map());
    return new Map(
      [...n].flatMap(([s, [a, ...o]]) =>
        a !== void 0 && o.every((i) => i === a) ? [[s, a]] : [],
      ),
    );
  },
  Ko = (e, t, r, { blank: n }) => {
    const { sectionPageCounts: s = [], relativePositions: a } = r;
    let o = 0;
    const i = new Map(),
      l = (c) => {
        var u, d;
        const h = (u = i.get(c)) !== null && u !== void 0 ? u : 0;
        return (
          i.set(c, h + 1),
          a == null || (d = a.get(c)) === null || d === void 0 ? void 0 : d[h]
        );
      };
    return (
      $t(e, [t], [], {
        resultOf: (c, u) =>
          Vo(c, u, {
            estimate: r,
            sectionPageCount: s[o],
            blank: n,
            relativeTo: l,
          }),
        afterParagraph: (c) => {
          o += _d(e, c) ? 1 : 0;
        },
      }),
      Ld(e, t, s)
    );
  },
  zo = (e, t, r, { blank: n, sectionPageCount: s, notes: a = !1 }) => {
    const o = (i) => {
      const l = r.bookmarks.get(i);
      return l === void 0 ? void 0 : `on page ${l}`;
    };
    $t(e, [t], [], {
      resultOf: (i, l) =>
        Vo(
          i,
          l,
          f(
            { estimate: r, sectionPageCount: s, blank: n },
            a ? { relativeTo: o } : {},
          ),
        ),
      afterParagraph: () => {},
    });
  },
  Dd = (e, t, { beforeParagraph: r, resultOf: n }) =>
    $t(e, [t], [], {
      resultOf: (s, { within: a }) => n(s, a),
      beforeParagraph: r,
      afterParagraph: () => {},
    }),
  Yo = class extends y {
    constructor(e = {}) {
      (super("w:instrText"),
        p(this, "properties", void 0),
        (this.properties = e),
        this.root.push(new we({ space: fe.PRESERVE })));
      let t = "TOC";
      if (
        (this.properties.captionLabel &&
          (t = `${t} \\a "${this.properties.captionLabel}"`),
        this.properties.entriesFromBookmark &&
          (t = `${t} \\b "${this.properties.entriesFromBookmark}"`),
        this.properties.captionLabelIncludingNumbers &&
          (t = `${t} \\c "${this.properties.captionLabelIncludingNumbers}"`),
        this.properties.sequenceAndPageNumbersSeparator &&
          (t = `${t} \\d "${this.properties.sequenceAndPageNumbersSeparator}"`),
        this.properties.tcFieldIdentifier &&
          (t = `${t} \\f "${this.properties.tcFieldIdentifier}"`),
        this.properties.hyperlink && (t = `${t} \\h`),
        this.properties.tcFieldLevelRange &&
          (t = `${t} \\l "${this.properties.tcFieldLevelRange}"`),
        this.properties.pageNumbersEntryLevelsRange &&
          (t = `${t} \\n "${this.properties.pageNumbersEntryLevelsRange}"`),
        this.properties.headingStyleRange &&
          (t = `${t} \\o "${this.properties.headingStyleRange}"`),
        this.properties.entryAndPageNumberSeparator &&
          (t = `${t} \\p "${this.properties.entryAndPageNumberSeparator}"`),
        this.properties.seqFieldIdentifierForPrefix &&
          (t = `${t} \\s "${this.properties.seqFieldIdentifierForPrefix}"`),
        this.properties.stylesWithLevels &&
          this.properties.stylesWithLevels.length)
      ) {
        const r = this.properties.stylesWithLevels
          .map((n) => `${n.styleName},${n.level}`)
          .join(",");
        t = `${t} \\t "${r}"`;
      }
      (this.properties.useAppliedParagraphOutlineLevel && (t = `${t} \\u`),
        this.properties.preserveTabInEntries && (t = `${t} \\w`),
        this.properties.preserveNewLineInEntries && (t = `${t} \\x`),
        this.properties.hideTabAndPageNumbersInWebView && (t = `${t} \\z`),
        this.root.push(t));
    }
  },
  ls = class extends y {
    constructor() {
      super("w:sdtContent");
    }
  },
  qo = (e) => (e === void 0 ? rs() : Ke(e)),
  cs = new WeakMap(),
  Md = (e, t) => {
    cs.set(e, t);
  },
  Fd = class {
    constructor() {
      p(this, "ids", []);
    }
    get(e) {
      var t, r;
      return (
        ((r = (t = this.ids)[e]) !== null && r !== void 0) || (t[e] = go()),
        this.ids[e]
      );
    }
  },
  Be = (e) => (typeof e == "object" && e !== null ? Object.keys(e)[0] : void 0),
  We = (e) => {
    const t = Be(e),
      r = t === void 0 ? void 0 : e[t];
    return Array.isArray(r) ? r : r === void 0 ? [] : [r];
  },
  Pe = (e, t) => We(e).find((r) => Be(r) === t),
  Ae = (e, t) => {
    var r;
    return (r = Pe(e, "_attr")) === null ||
      r === void 0 ||
      (r = r._attr) === null ||
      r === void 0
      ? void 0
      : r[t];
  },
  us = (e, t) => {
    const r = Ae(e, t);
    return r === void 0 ? void 0 : Number(r);
  },
  $d = new Set([
    "w:tbl",
    "w:tr",
    "w:tc",
    "w:sdt",
    "w:sdtContent",
    "w:customXml",
  ]),
  Jo = (e) =>
    e.flatMap((t) => {
      const r = Be(t);
      return r === "w:p" || cs.has(t)
        ? [t]
        : r !== void 0 && $d.has(r)
          ? Jo(We(t))
          : [];
    }),
  Hd = new Set([
    "w:r",
    "w:hyperlink",
    "w:ins",
    "w:moveTo",
    "w:smartTag",
    "w:customXml",
    "w:sdt",
    "w:sdtContent",
    "w:fldSimple",
    "w:dir",
    "w:bdo",
  ]),
  Bd = (e) => {
    switch (Be(e)) {
      case "w:t":
        return We(e)
          .filter((t) => typeof t == "string")
          .join("");
      case "w:tab":
        return "	";
      case "w:br":
        return [void 0, "textWrapping"].includes(Ae(e, "w:type"))
          ? `
`
          : "";
      case "w:cr":
        return `
`;
      case "w:noBreakHyphen":
        return "-";
      default:
        return "";
    }
  },
  Wd = (e) => {
    const t = [],
      r = (n) => {
        const s = Be(n);
        if (s !== void 0 && Hd.has(s)) return We(n).map(r).join("");
        if (s === "w:fldChar") {
          const a = Ae(n, "w:fldCharType");
          return (
            a === "begin"
              ? t.push(!1)
              : a === "separate"
                ? (t[t.length - 1] = !0)
                : t.pop(),
            ""
          );
        }
        return t.every(Boolean) ? Bd(n) : "";
      };
    return We(e).map(r).join("");
  },
  Zo = (e) => {
    const t = Be(e);
    return t === "w:bookmarkStart"
      ? [{ start: !0, id: Ae(e, "w:id"), name: Ae(e, "w:name") }]
      : t === "w:bookmarkEnd"
        ? [{ start: !1, id: Ae(e, "w:id") }]
        : t === void 0 || t === "_attr"
          ? []
          : We(e).flatMap(Zo);
  },
  Ud = (e) => {
    const t = new Map();
    return e.map((r) => {
      const n = Zo(r),
        s = new Set([
          ...t.values(),
          ...n.flatMap((a) => (a.start ? [a.name] : [])),
        ]);
      for (const a of n) a.start ? t.set(a.id, a.name) : t.delete(a.id);
      return s;
    });
  },
  Gd = (e, t) => {
    const r = t ? Ud(e) : [];
    return e.map((n, s) => {
      var a;
      const o = Pe(n, "w:pPr");
      return {
        element: n,
        styleId: Ae(Pe(o, "w:pStyle"), "w:val"),
        outlineLevel: us(Pe(o, "w:outlineLvl"), "w:val"),
        text: Wd(n),
        bookmarks: (a = r[s]) !== null && a !== void 0 ? a : new Set(),
      };
    });
  },
  Qo = (e) => {
    var t;
    const r =
      (t = e.file) === null ||
      t === void 0 ||
      (t = t.Styles) === null ||
      t === void 0
        ? void 0
        : t.prepForXml(e);
    return new Map(
      We(r)
        .filter(
          (n) =>
            Be(n) === "w:style" &&
            ["paragraph", void 0].includes(Ae(n, "w:type")),
        )
        .map((n) => [
          Ae(n, "w:styleId"),
          {
            name: Ae(Pe(n, "w:name"), "w:val"),
            basedOn: Ae(Pe(n, "w:basedOn"), "w:val"),
            outlineLevel: us(Pe(Pe(n, "w:pPr"), "w:outlineLvl"), "w:val"),
          },
        ]),
    );
  },
  ei = (e) => {
    const t = /^\s*(\d+)\s*-\s*(\d+)\s*$/.exec(e);
    return t ? [Number(t[1]), Number(t[2])] : void 0;
  },
  In = (e, [t, r]) => e >= t && e <= r,
  ds = (e, t) => {
    var r, n;
    if (e === void 0) return;
    const s = /^heading ?([1-9])$/i.exec(
      (r = (n = t.get(e)) === null || n === void 0 ? void 0 : n.name) !==
        null && r !== void 0
        ? r
        : e,
    );
    return s ? Number(s[1]) : void 0;
  },
  ti = (e, t, r = 0) => {
    var n;
    if (e === void 0 || r > t.size) return;
    const s = t.get(e),
      a = ds(e, t);
    return (n = s?.outlineLevel) !== null && n !== void 0
      ? n
      : a === void 0
        ? ti(s?.basedOn, t, r + 1)
        : a - 1;
  },
  jd = (e) => {
    const t = Qo(e);
    return (r) => {
      const n = Pe(r, "w:pPr"),
        s = Ae(Pe(n, "w:pStyle"), "w:val"),
        a = ds(s, t),
        o = ri(
          { styleId: s, outlineLevel: us(Pe(n, "w:outlineLvl"), "w:val") },
          t,
        ),
        i = o === void 0 || o >= 9 ? void 0 : o + 1;
      return a !== void 0 && (i === void 0 || i === a)
        ? a
        : i === void 0
          ? void 0
          : "unclear";
    };
  },
  ri = (e, t) => {
    var r;
    return (r = e.outlineLevel) !== null && r !== void 0 ? r : ti(e.styleId, t);
  },
  Vd = (e, t, r) => {
    var n;
    const {
      entriesFromBookmark: s,
      headingStyleRange: a,
      stylesWithLevels: o = [],
      useAppliedParagraphOutlineLevel: i,
    } = e;
    if (t.text.trim() === "" || (s && !t.bookmarks.has(s))) return;
    const l = [
        t.styleId,
        t.styleId === void 0 || (n = r.get(t.styleId)) === null || n === void 0
          ? void 0
          : n.name,
      ]
        .filter((m) => m !== void 0)
        .map((m) => m.toLowerCase()),
      c = o.find((m) => l.includes(m.styleName.toLowerCase()));
    if (c) return c.level;
    const u =
        !!a ||
        o.length > 0 ||
        !!i ||
        !!e.tcFieldIdentifier ||
        !!e.tcFieldLevelRange ||
        !!e.captionLabel ||
        !!e.captionLabelIncludingNumbers,
      d = a ? ei(a) : u ? void 0 : [1, 9],
      h = ds(t.styleId, r);
    if (d && h !== void 0 && In(h, d)) return h;
    const w = i ? ri(t, r) : void 0;
    return w !== void 0 && In(w + 1, d ?? [1, 9]) ? w + 1 : void 0;
  },
  Xd = (e, t) => {
    const r = t.preserveTabInEntries ? e : e.replace(/\t/g, " ");
    return (
      t.preserveNewLineInEntries
        ? r.split(`
`)
        : [r.replace(/\n/g, " ")]
    ).map(
      (n, s) =>
        new Ye({
          break: s > 0 ? 1 : void 0,
          children: n
            .split("	")
            .flatMap((a, o) => [
              ...(o > 0 ? [new Pr()] : []),
              ...(a === "" ? [] : [a]),
            ]),
        }),
    );
  },
  Kd = ({ text: e, separator: t }) =>
    t === "tab"
      ? [new Ye(e), new Ye({ children: [new Pr()] })]
      : [new Ye(`${e} `)],
  zd = (e, t) => {
    const r = 240 * (e - 1) + t + 240;
    return r <= 1920 ? Math.ceil(r / 240) * 240 : Math.round(r);
  },
  Yd = (e, t) => {
    var r, n;
    return (r =
      (n = [...t].find(([, s]) => {
        var a;
        return (
          ((a = s.name) === null || a === void 0 ? void 0 : a.toLowerCase()) ===
          `toc ${e}`
        );
      })) === null || n === void 0
        ? void 0
        : n[0]) !== null && r !== void 0
      ? r
      : `TOC${e}`;
  },
  qd = (
    { properties: e, beginDirty: t, textWidth: r, tabLeader: n },
    s,
    a,
    o,
  ) => {
    var i;
    const l = e.pageNumbersEntryLevelsRange
        ? (i = ei(e.pageNumbersEntryLevelsRange)) !== null && i !== void 0
          ? i
          : [1, 9]
        : void 0,
      c = new ls();
    return (
      s.forEach((u, d) => {
        var h;
        const w = l === void 0 || !In(u.level, l),
          m = [
            ...(u.listNumber ? Kd(u.listNumber) : []),
            ...Xd(u.title, e),
            ...(w
              ? [
                  new Ye({
                    children: [e.entryAndPageNumberSeparator || new Pr()],
                  }),
                  new Fh(u.bookmark, { hyperlink: e.hyperlink }),
                ]
              : []),
          ];
        c.addChildElement(
          new me({
            style: Yd(u.level, a),
            tabStops: [
              ...(((h = u.listNumber) === null || h === void 0
                ? void 0
                : h.separator) === "tab"
                ? [{ type: "left", position: zd(u.level, u.listNumber.width) }]
                : []),
              { type: "right", position: r, leader: n },
            ],
            children: [
              ...(d === 0
                ? [new te({ children: [qo(t), new Yo(e), Re()] })]
                : []),
              ...(e.hyperlink
                ? [new ii({ anchor: u.bookmark, children: m })]
                : m),
            ],
          }),
        );
      }),
      c.addChildElement(new me({ children: [new te({ children: [Se()] })] })),
      c.prepForXml(o)
    );
  },
  Jd = (e, t, r, n) => {
    const s = We(e),
      a = s.findIndex((o) => Be(o) === "w:pPr") + 1;
    e["w:p"] = [
      ...s.slice(0, a),
      new ui(t, r).prepForXml(n),
      ...s.slice(a),
      new di(r).prepForXml(n),
    ];
  },
  Zd = (e, t, r, n) => {
    const s = Jo(We(e)),
      a = s.flatMap((u) => {
        const d = cs.get(u);
        return d ? [[u, d]] : [];
      });
    if (a.length === 0) return;
    const o = Qo(t),
      i = a.some(([, { properties: u }]) => !!u.entriesFromBookmark),
      l = Gd(
        s.filter((u) => Be(u) === "w:p"),
        i,
      )
        .map((u) => ({
          paragraph: u,
          levels: a.map(([, { properties: d }]) => Vd(d, u, o)),
        }))
        .filter(({ levels: u }) => u.some((d) => d !== void 0))
        .map((u, d) => f(f({}, u), {}, { id: r.get(d) }));
    for (const { paragraph: u, id: d } of l) Jd(u.element, `_Toc${d}`, d, t);
    const c = l.length > 0 ? n?.(e) : void 0;
    a.forEach(([u, d], h) => {
      const w = l.flatMap(({ paragraph: m, levels: v, id: g }) => {
        const A = v[h],
          I = c?.get(`_Toc${g}`);
        return A === void 0
          ? []
          : [
              f(
                { title: m.text, level: A, bookmark: `_Toc${g}` },
                I ? { listNumber: I } : {},
              ),
            ];
      });
      w.length !== 0 &&
        (u["w:sdt"] = We(u).map((m) =>
          Be(m) === "w:sdtContent" ? qd(d, w, o, t) : m,
        ));
    });
  },
  Qd = new RegExp("^\\p{L}[\\p{L}\\p{N}_]*$", "u"),
  eh = (e) => {
    var t, r;
    let n,
      s = !1,
      a,
      o = !1,
      i = !1;
    for (let d = 0; d < e.length; d++) {
      var l, c;
      const h = e[d],
        w = (l = e[d + 1]) !== null && l !== void 0 ? l : "";
      let m;
      if (d === 0 && !h.startsWith("\\")) m = { type: "bookmark" };
      else if (h === "\\c" || h === "\\n")
        m = { type: h === "\\c" ? "repeat" : "next" };
      else if ((h === "\\r" || h === "\\s") && /^\d+$/.test(w))
        (d++,
          (m =
            h === "\\r"
              ? { type: "reset", to: Number(w) }
              : { type: "heading", level: Number(w) }));
      else if (h === "\\h") s = !0;
      else if (h === "\\#" && d + 1 < e.length) (d++, (i = !0));
      else if (h === "\\*" && d + 1 < e.length) {
        const v = e[++d];
        if (jo.has(v.toLowerCase())) o = !0;
        else if (!Go.has(v.toLowerCase())) {
          if (a !== void 0) return;
          a = v;
        }
      } else return;
      if (m && n) return;
      n = (c = m) !== null && c !== void 0 ? c : n;
    }
    if (n?.type === "bookmark" && e.length > 1) return;
    const u = !i && !(o && a !== void 0 && a.toLowerCase() !== "arabic");
    return {
      step: (t = n) !== null && t !== void 0 ? t : { type: "next" },
      hidden: s && a === void 0,
      format: u ? ((r = a) !== null && r !== void 0 ? r : "ARABIC") : "",
    };
  },
  hs = (e) => {
    var t;
    const r = new RegExp("^\\s*SEQ\\b(.*)$", "is").exec(e);
    if (!r) return;
    const [n, ...s] =
      (t = r[1].match(/"[^"]*"|\S+/g)) !== null && t !== void 0 ? t : [];
    if (n === void 0) return {};
    const a = n.replace(/^"(.*)"$/, "$1");
    return Qd.test(a) ? { identifier: a, sequence: eh(s) } : { identifier: a };
  },
  th = (e) => hs(e) !== void 0,
  Cn = (e) =>
    typeof e != "object" || e === null
      ? []
      : Array.isArray(e)
        ? e.flatMap(Cn)
        : Object.entries(e).flatMap(([t, r]) => [
            ...(t === "w:instrText" && Array.isArray(r)
              ? r
              : t === "_attr"
                ? [r["w:instr"]]
                : []
            ).flatMap((n) => {
              const s = typeof n == "string" ? hs(n) : void 0;
              return s?.identifier === void 0
                ? []
                : [s.identifier.toLowerCase()];
            }),
            ...Cn(r),
          ]),
  rh = (e) => {
    var t;
    const r = (t = e.file) === null || t === void 0 ? void 0 : t.Comments;
    if (!r) return new Set();
    const n = { View: r, Relationships: r.Relationships };
    return new Set(
      Cn(r.prepForXml(f(f({}, e), {}, { viewWrapper: n, stack: [] }))),
    );
  },
  nh = (e) => {
    const t = jd(e),
      r = new Map(),
      n = new Map(),
      s = [];
    let a = -1,
      o = -1,
      i;
    const l = (c, u) => {
      var d;
      const h = Math.max(-1, ...s.slice(1, u + 1).filter((v) => v !== void 0)),
        w = ((d = n.get(c)) !== null && d !== void 0 ? d : []).filter(
          (v) => v.paragraph >= h,
        ),
        m = w.every(
          ({ step: v }) =>
            v?.type === "next" || (v?.type === "heading" && v.level === u),
        );
      return a > h || !m ? void 0 : w.length + 1;
    };
    return {
      startParagraph: (c) => {
        o++;
        const u = t(c);
        u === "unclear" ? (a = o) : u !== void 0 && (s[u] = o);
      },
      numberOf: (c, u) => {
        var d, h, w;
        const { identifier: m, sequence: v } = hs(c);
        if (m === void 0 || u === "fallback") return;
        ((d = i) !== null && d !== void 0) || (i = rh(e));
        const g = m.toLowerCase();
        if (v?.step.type === "bookmark" && u === "counted" && !i.has(g)) return;
        const A = r.has(g) ? r.get(g) : 0,
          I = i.has(g) || u === "deleted" ? void 0 : v?.step,
          b =
            I?.type === "reset"
              ? I.to
              : I?.type === "repeat"
                ? A
                : I?.type === "heading"
                  ? l(g, I.level)
                  : I?.type === "next" && A !== void 0
                    ? A + 1
                    : void 0;
        return (
          r.set(g, b),
          n.set(g, [
            ...((h = n.get(g)) !== null && h !== void 0 ? h : []),
            f({ paragraph: o }, b === void 0 ? {} : { step: I }),
          ]),
          b === void 0 || v === void 0
            ? void 0
            : v.hidden
              ? ""
              : (w = is(v.format)) === null || w === void 0
                ? void 0
                : w(b)
        );
      },
    };
  },
  jr = (e) => {
    const t =
      typeof e == "object" && e !== null && !Array.isArray(e)
        ? Object.keys(e)[0]
        : void 0;
    return t === "_attr" ? void 0 : t;
  },
  Gs = (e) => ({ "w:t": [{ _attr: { "xml:space": "preserve" } }, e] }),
  Rr = {
    nameOf: jr,
    contentOf: (e) => {
      const t = e[jr(e)];
      return Array.isArray(t) ? t : void 0;
    },
    attributeOf: (e, t) => {
      var r;
      const n = e[jr(e)],
        s = Array.isArray(n)
          ? n.find((a) => typeof a == "object" && a !== null && "_attr" in a)
          : n;
      return s == null || (r = s._attr) === null || r === void 0
        ? void 0
        : r[t];
    },
    textOf: (e) =>
      Rr.contentOf(e)
        .filter((t) => typeof t == "string")
        .join(""),
    textElement: Gs,
    writeClean: (e) => {
      if (Cc(e)) {
        const t = e["w:fldChar"]._attr;
        e["w:fldChar"] = {
          _attr: Object.fromEntries(
            Object.entries(t).filter(([r]) => r !== "w:dirty"),
          ),
        };
      }
    },
    setSimpleFieldResult: (e, t) => {
      const r = e["w:fldSimple"];
      e["w:fldSimple"] = [
        ...(Array.isArray(r) ? r : [r]).filter(
          (n) => typeof n == "object" && n !== null && "_attr" in n,
        ),
        { "w:r": [Gs(t)] },
      ];
    },
  },
  ni = new WeakMap(),
  sh = (e, t) => {
    const { startParagraph: r, numberOf: n } = nh(t);
    Dd(Rr, e, {
      beforeParagraph: (s) => r(s),
      resultOf: (s, a) => (th(s) ? n(s, a) : void 0),
    });
  },
  ah = (e, t, r) => {
    const n = r(e, t),
      s = Ko(Rr, e, n, { blank: !1 });
    t.file && ni.set(t.file, { estimate: n, partPageCounts: s });
  },
  Xt = (e, t, r) => {
    const n = t.file && ni.get(t.file);
    if (!e || !n) return;
    const s = r === void 0 ? void 0 : n.partPageCounts.get(`rId${r}`),
      a = "w:footnotes" in e || "w:endnotes" in e;
    zo(Rr, e, n.estimate, { blank: !1, sectionPageCount: s, notes: a });
  },
  oh = class extends _ {
    constructor(...e) {
      (super(...e), p(this, "xmlKeys", { xmlns: "xmlns" }));
    }
  },
  se = class si extends y {
    constructor() {
      (super("Relationships"),
        this.root.push(
          new oh({
            xmlns:
              "http://schemas.openxmlformats.org/package/2006/relationships",
          }),
        ));
    }
    addRelationship(t, r, n, s) {
      this.root.push(cd(`rId${t}`, r, n, s));
    }
    static copy(t) {
      const r = new si();
      return (r.root.push(...t.root.slice(1)), r);
    }
    get RelationshipCount() {
      return this.root.length - 1;
    }
  },
  ih = class extends _ {
    constructor(...e) {
      (super(...e),
        p(this, "xmlKeys", {
          id: "w:id",
          initials: "w:initials",
          author: "w:author",
          date: "w:date",
        }));
    }
  },
  ms = class extends _ {
    constructor(...e) {
      (super(...e), p(this, "xmlKeys", { id: "w:id" }));
    }
  },
  lh = class extends _ {
    constructor(...e) {
      (super(...e),
        p(this, "xmlKeys", {
          "xmlns:wpc": "xmlns:wpc",
          "xmlns:cx": "xmlns:cx",
          "xmlns:cx1": "xmlns:cx1",
          "xmlns:cx2": "xmlns:cx2",
          "xmlns:cx3": "xmlns:cx3",
          "xmlns:cx4": "xmlns:cx4",
          "xmlns:cx5": "xmlns:cx5",
          "xmlns:cx6": "xmlns:cx6",
          "xmlns:cx7": "xmlns:cx7",
          "xmlns:cx8": "xmlns:cx8",
          "xmlns:mc": "xmlns:mc",
          "xmlns:aink": "xmlns:aink",
          "xmlns:am3d": "xmlns:am3d",
          "xmlns:o": "xmlns:o",
          "xmlns:r": "xmlns:r",
          "xmlns:m": "xmlns:m",
          "xmlns:v": "xmlns:v",
          "xmlns:wp14": "xmlns:wp14",
          "xmlns:wp": "xmlns:wp",
          "xmlns:w10": "xmlns:w10",
          "xmlns:w": "xmlns:w",
          "xmlns:w14": "xmlns:w14",
          "xmlns:w15": "xmlns:w15",
          "xmlns:w16cex": "xmlns:w16cex",
          "xmlns:w16cid": "xmlns:w16cid",
          "xmlns:w16": "xmlns:w16",
          "xmlns:w16sdtdh": "xmlns:w16sdtdh",
          "xmlns:w16se": "xmlns:w16se",
          "xmlns:wpg": "xmlns:wpg",
          "xmlns:wpi": "xmlns:wpi",
          "xmlns:wne": "xmlns:wne",
          "xmlns:wps": "xmlns:wps",
          "mc:Ignorable": "mc:Ignorable",
        }));
    }
  },
  pg = class extends y {
    constructor(e) {
      (super("w:commentRangeStart"), this.root.push(new ms({ id: e })));
    }
  },
  vg = class extends y {
    constructor(e) {
      (super("w:commentRangeEnd"), this.root.push(new ms({ id: e })));
    }
  },
  fg = class extends y {
    constructor(e) {
      (super("w:commentReference"), this.root.push(new ms({ id: e })));
    }
  },
  js = class extends y {
    constructor(
      { id: e, initials: t, author: r, date: n = new Date(), children: s },
      a,
    ) {
      (super("w:comment"),
        p(this, "paraId", void 0),
        (this.paraId = a),
        this.root.push(
          new ih({ id: e, initials: t, author: r, date: n.toISOString() }),
        ));
      for (const o of s) this.root.push(o);
    }
    prepForXml(e) {
      const t = super.prepForXml(e);
      if (!t || !this.paraId) return t;
      const r = t["w:comment"];
      if (!Array.isArray(r)) return t;
      for (let n = r.length - 1; n >= 0; n--) {
        const s = r[n];
        if (s && typeof s == "object" && "w:p" in s) {
          const a = s["w:p"];
          Array.isArray(a) &&
            a.unshift({
              _attr: { "w14:paraId": this.paraId, "w14:textId": this.paraId },
            });
          break;
        }
      }
      return t;
    }
  },
  ch = (e) => (e + 1).toString(16).toUpperCase().padStart(8, "0"),
  uh = class extends y {
    constructor({ children: e }) {
      (super("w:comments"),
        p(this, "relationships", void 0),
        p(this, "threadData", void 0),
        p(this, "commentIdsData", void 0),
        p(this, "isEmpty", void 0),
        (this.isEmpty = e.length === 0),
        this.root.push(
          new lh({
            "xmlns:wpc":
              "http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas",
            "xmlns:cx":
              "http://schemas.microsoft.com/office/drawing/2014/chartex",
            "xmlns:cx1":
              "http://schemas.microsoft.com/office/drawing/2015/9/8/chartex",
            "xmlns:cx2":
              "http://schemas.microsoft.com/office/drawing/2015/10/21/chartex",
            "xmlns:cx3":
              "http://schemas.microsoft.com/office/drawing/2016/5/9/chartex",
            "xmlns:cx4":
              "http://schemas.microsoft.com/office/drawing/2016/5/10/chartex",
            "xmlns:cx5":
              "http://schemas.microsoft.com/office/drawing/2016/5/11/chartex",
            "xmlns:cx6":
              "http://schemas.microsoft.com/office/drawing/2016/5/12/chartex",
            "xmlns:cx7":
              "http://schemas.microsoft.com/office/drawing/2016/5/13/chartex",
            "xmlns:cx8":
              "http://schemas.microsoft.com/office/drawing/2016/5/14/chartex",
            "xmlns:mc":
              "http://schemas.openxmlformats.org/markup-compatibility/2006",
            "xmlns:aink":
              "http://schemas.microsoft.com/office/drawing/2016/ink",
            "xmlns:am3d":
              "http://schemas.microsoft.com/office/drawing/2017/model3d",
            "xmlns:o": "urn:schemas-microsoft-com:office:office",
            "xmlns:r":
              "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
            "xmlns:m":
              "http://schemas.openxmlformats.org/officeDocument/2006/math",
            "xmlns:v": "urn:schemas-microsoft-com:vml",
            "xmlns:wp14":
              "http://schemas.microsoft.com/office/word/2010/wordprocessingDrawing",
            "xmlns:wp":
              "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing",
            "xmlns:w10": "urn:schemas-microsoft-com:office:word",
            "xmlns:w":
              "http://schemas.openxmlformats.org/wordprocessingml/2006/main",
            "xmlns:w14": "http://schemas.microsoft.com/office/word/2010/wordml",
            "xmlns:w15": "http://schemas.microsoft.com/office/word/2012/wordml",
            "xmlns:w16cex":
              "http://schemas.microsoft.com/office/word/2018/wordml/cex",
            "xmlns:w16cid":
              "http://schemas.microsoft.com/office/word/2016/wordml/cid",
            "xmlns:w16": "http://schemas.microsoft.com/office/word/2018/wordml",
            "xmlns:w16sdtdh":
              "http://schemas.microsoft.com/office/word/2020/wordml/sdtdatahash",
            "xmlns:w16se":
              "http://schemas.microsoft.com/office/word/2015/wordml/symex",
            "xmlns:wpg":
              "http://schemas.microsoft.com/office/word/2010/wordprocessingGroup",
            "xmlns:wpi":
              "http://schemas.microsoft.com/office/word/2010/wordprocessingInk",
            "xmlns:wne": "http://schemas.microsoft.com/office/word/2006/wordml",
            "xmlns:wps":
              "http://schemas.microsoft.com/office/word/2010/wordprocessingShape",
            "mc:Ignorable": "w14 w15 wp14",
          }),
        ));
      const t = e.some((n) => n.parentId !== void 0),
        r = e.some((n) => n.durableId !== void 0);
      if (t || r) {
        const n = new Map(e.map((s) => [s.id, ch(s.id)]));
        for (const s of e) this.root.push(new js(s, n.get(s.id)));
        (t &&
          (this.threadData = e.map((s) => ({
            paraId: n.get(s.id),
            parentParaId: s.parentId !== void 0 ? n.get(s.parentId) : void 0,
            done: s.resolved,
          }))),
          r &&
            (this.commentIdsData = e.map((s) => {
              var a;
              return {
                paraId: n.get(s.id),
                durableId:
                  (a = s.durableId) !== null && a !== void 0 ? a : n.get(s.id),
              };
            })));
      } else for (const n of e) this.root.push(new js(n));
      this.relationships = new se();
    }
    get Relationships() {
      return this.relationships;
    }
    get ThreadData() {
      return this.threadData;
    }
    get CommentIdsData() {
      return this.commentIdsData;
    }
    get IsEmpty() {
      return this.isEmpty;
    }
    prepForXml(e) {
      const t = super.prepForXml(e);
      return (Xt(t, e), t);
    }
  },
  dh = class extends _ {
    constructor(...e) {
      (super(...e), p(this, "xmlKeys", { id: "w:id", editorGroup: "w:edGrp" }));
    }
  },
  hh = class extends _ {
    constructor(...e) {
      (super(...e), p(this, "xmlKeys", { id: "w:id" }));
    }
  },
  wg = class extends y {
    constructor(e) {
      (super("w:permStart"),
        this.root.push(new dh({ id: e, editorGroup: "everyone" })));
    }
  },
  gg = class extends y {
    constructor(e) {
      (super("w:permEnd"), this.root.push(new hh({ id: e })));
    }
  },
  mh = class extends _ {
    constructor(...e) {
      (super(...e),
        p(this, "xmlKeys", {
          "xmlns:wpc": "xmlns:wpc",
          "xmlns:mc": "xmlns:mc",
          "xmlns:w15": "xmlns:w15",
          "mc:Ignorable": "mc:Ignorable",
        }));
    }
  },
  ph = class extends _ {
    constructor(...e) {
      (super(...e),
        p(this, "xmlKeys", {
          paraId: "w15:paraId",
          paraIdParent: "w15:paraIdParent",
          done: "w15:done",
        }));
    }
  },
  vh = class extends y {
    constructor(e) {
      (super("w15:commentEx"),
        this.root.push(
          new ph({
            paraId: e.paraId,
            paraIdParent: e.parentParaId,
            done: e.done !== void 0 ? (e.done ? "1" : "0") : void 0,
          }),
        ));
    }
  },
  fh = class extends y {
    constructor(e) {
      (super("w15:commentsEx"),
        this.root.push(
          new mh({
            "xmlns:wpc":
              "http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas",
            "xmlns:mc":
              "http://schemas.openxmlformats.org/markup-compatibility/2006",
            "xmlns:w15": "http://schemas.microsoft.com/office/word/2012/wordml",
            "mc:Ignorable": "w15",
          }),
        ));
      for (const t of e) this.root.push(new vh(t));
    }
  },
  wh = class extends _ {
    constructor(...e) {
      (super(...e),
        p(this, "xmlKeys", {
          paraId: "w16cid:paraId",
          durableId: "w16cid:durableId",
        }));
    }
  },
  gh = class extends y {
    constructor(e) {
      (super("w16cid:commentId"),
        this.root.push(new wh({ paraId: e.paraId, durableId: e.durableId })));
    }
  },
  yh = class extends _ {
    constructor(...e) {
      (super(...e),
        p(this, "xmlKeys", {
          "xmlns:w16cid": "xmlns:w16cid",
          "xmlns:mc": "xmlns:mc",
          "mc:Ignorable": "mc:Ignorable",
        }));
    }
  },
  xh = class extends y {
    constructor(e) {
      (super("w16cid:commentsIds"),
        this.root.push(
          new yh({
            "xmlns:w16cid":
              "http://schemas.microsoft.com/office/word/2016/wordml/cid",
            "xmlns:mc":
              "http://schemas.openxmlformats.org/markup-compatibility/2006",
            "mc:Ignorable": "w16cid",
          }),
        ));
      for (const t of e) this.root.push(new gh(t));
    }
  },
  yg = class extends ue {
    constructor() {
      super("w:noBreakHyphen");
    }
  },
  xg = class extends ue {
    constructor() {
      super("w:softHyphen");
    }
  },
  bg = class extends ue {
    constructor() {
      super("w:dayShort");
    }
  },
  Tg = class extends ue {
    constructor() {
      super("w:monthShort");
    }
  },
  Eg = class extends ue {
    constructor() {
      super("w:yearShort");
    }
  },
  Sg = class extends ue {
    constructor() {
      super("w:dayLong");
    }
  },
  Ag = class extends ue {
    constructor() {
      super("w:monthLong");
    }
  },
  Ig = class extends ue {
    constructor() {
      super("w:yearLong");
    }
  },
  Cg = class extends ue {
    constructor() {
      super("w:annotationRef");
    }
  },
  Ng = class extends ue {
    constructor() {
      super("w:footnoteRef");
    }
  },
  bh = class extends ue {
    constructor() {
      super("w:endnoteRef");
    }
  },
  kg = class extends ue {
    constructor() {
      super("w:separator");
    }
  },
  Rg = class extends ue {
    constructor() {
      super("w:continuationSeparator");
    }
  },
  Pg = class extends ue {
    constructor() {
      super("w:pgNum");
    }
  },
  Og = class extends ue {
    constructor() {
      super("w:cr");
    }
  },
  Pr = class extends ue {
    constructor() {
      super("w:tab");
    }
  },
  _g = class extends ue {
    constructor() {
      super("w:lastRenderedPageBreak");
    }
  },
  Lg = { LEFT: "left", CENTER: "center", RIGHT: "right" },
  Dg = { MARGIN: "margin", INDENT: "indent" },
  Mg = {
    NONE: "none",
    DOT: "dot",
    HYPHEN: "hyphen",
    UNDERSCORE: "underscore",
    MIDDLE_DOT: "middleDot",
  },
  Th = class extends _ {
    constructor(...e) {
      (super(...e),
        p(this, "xmlKeys", {
          alignment: "w:alignment",
          relativeTo: "w:relativeTo",
          leader: "w:leader",
        }));
    }
  },
  Fg = class extends y {
    constructor(e) {
      (super("w:ptab"),
        this.root.push(
          new Th({
            alignment: e.alignment,
            relativeTo: e.relativeTo,
            leader: e.leader,
          }),
        ));
    }
  },
  ai = { COLUMN: "column", PAGE: "page" },
  oi = class extends y {
    constructor(e) {
      (super("w:br"), this.root.push(new pe({ type: e })));
    }
  },
  $g = class extends te {
    constructor() {
      (super({}), this.root.push(new oi(ai.PAGE)));
    }
  },
  Hg = class extends te {
    constructor() {
      (super({}), this.root.push(new oi(ai.COLUMN)));
    }
  },
  Eh = class extends y {
    constructor() {
      super("w:pageBreakBefore");
    }
  },
  xt = {
    AT_LEAST: "atLeast",
    EXACTLY: "exactly",
    EXACT: "exact",
    AUTO: "auto",
  },
  Sh = ({
    after: e,
    before: t,
    line: r,
    lineRule: n,
    beforeAutoSpacing: s,
    afterAutoSpacing: a,
  }) =>
    new x({
      name: "w:spacing",
      attributes: {
        after: { key: "w:after", value: e },
        before: { key: "w:before", value: t },
        line: { key: "w:line", value: r },
        lineRule: { key: "w:lineRule", value: n },
        beforeAutoSpacing: { key: "w:beforeAutospacing", value: s },
        afterAutoSpacing: { key: "w:afterAutospacing", value: a },
      },
    }),
  Bg = {
    HEADING_1: "Heading1",
    HEADING_2: "Heading2",
    HEADING_3: "Heading3",
    HEADING_4: "Heading4",
    HEADING_5: "Heading5",
    HEADING_6: "Heading6",
    TITLE: "Title",
  },
  Pt = (e) =>
    new x({
      name: "w:pStyle",
      attributes: { val: { key: "w:val", value: e } },
    }),
  Vs = {
    LEFT: "left",
    RIGHT: "right",
    CENTER: "center",
    BAR: "bar",
    CLEAR: "clear",
    DECIMAL: "decimal",
    END: "end",
    NUM: "num",
    START: "start",
  },
  Ah = {
    DOT: "dot",
    HYPHEN: "hyphen",
    MIDDLE_DOT: "middleDot",
    NONE: "none",
    UNDERSCORE: "underscore",
  },
  Wg = { MAX: 9026 },
  Ih = ({ type: e, position: t, leader: r }) =>
    new x({
      name: "w:tab",
      attributes: {
        val: { key: "w:val", value: e },
        pos: { key: "w:pos", value: Fe(t) },
        leader: { key: "w:leader", value: r },
      },
    }),
  Ch = (e) => new x({ name: "w:tabs", children: e.map((t) => Ih(t)) }),
  tr = class extends y {
    constructor(e, t) {
      (super("w:numPr"), this.root.push(new Nh(t)), this.root.push(new kh(e)));
    }
  },
  Nh = class extends y {
    constructor(e) {
      if ((super("w:ilvl"), e > 9))
        throw new Error(
          "Level cannot be greater than 9. Read more here: https://answers.microsoft.com/en-us/msoffice/forum/all/does-word-support-more-than-9-list-levels/d130fdcd-1781-446d-8c84-c6c79124e4d7",
        );
      this.root.push(new pe({ val: e }));
    }
  },
  kh = class extends y {
    constructor(e) {
      (super("w:numId"),
        this.root.push(new pe({ val: typeof e == "string" ? `{${e}}` : e })));
    }
  },
  Or = class extends y {
    constructor(...e) {
      (super(...e), p(this, "fileChild", Symbol()));
    }
  },
  Rh = class extends _ {
    constructor(...e) {
      (super(...e),
        p(this, "xmlKeys", {
          id: "r:id",
          history: "w:history",
          anchor: "w:anchor",
        }));
    }
  },
  Ug = { INTERNAL: "INTERNAL", EXTERNAL: "EXTERNAL" },
  Kt = class extends y {
    constructor(e, t, r, n) {
      (super("w:hyperlink"),
        p(this, "linkId", void 0),
        p(this, "drawingLink", void 0),
        (this.linkId = t),
        (this.drawingLink = r && n !== void 0 ? new as(n) : void 0));
      const s = new Rh({
        history: 1,
        anchor: r || void 0,
        id: !r || n !== void 0 ? `rId${this.linkId}` : void 0,
      });
      (this.root.push(s),
        e.forEach((a) => {
          this.root.push(a);
        }));
    }
    createDrawingClick(e, t) {
      return this.drawingLink
        ? (this.drawingLink.addRelationship(e), this.drawingLink.createClick(t))
        : Lo(this.linkId, t);
    }
  },
  ii = class extends Kt {
    constructor(e) {
      super(e.children, at(), e.anchor);
    }
  },
  Ph = class extends y {
    constructor(e) {
      (super("w:externalHyperlink"),
        p(this, "options", void 0),
        (this.options = e));
    }
  },
  Oh = class extends _ {
    constructor(...e) {
      (super(...e), p(this, "xmlKeys", { id: "w:id", name: "w:name" }));
    }
  },
  _h = class extends _ {
    constructor(...e) {
      (super(...e), p(this, "xmlKeys", { id: "w:id" }));
    }
  },
  li = class ci {
    constructor(t) {
      (p(this, "start", void 0),
        p(this, "children", void 0),
        p(this, "end", void 0));
      const r = go();
      ((this.start = new ui(t.id, r)),
        (this.children = t.children),
        (this.end = new di(r)));
    }
    get writtenAs() {
      return [
        this.start,
        ...this.children.flatMap((t) => (t instanceof ci ? t.writtenAs : [t])),
        this.end,
      ];
    }
  },
  ui = class extends y {
    constructor(e, t) {
      super("w:bookmarkStart");
      const r = new Oh({ name: e, id: t });
      this.root.push(r);
    }
  },
  di = class extends y {
    constructor(e) {
      super("w:bookmarkEnd");
      const t = new _h({ id: e });
      this.root.push(t);
    }
  },
  Gg = (function (e) {
    return (
      (e.NONE = "none"),
      (e.RELATIVE = "relative"),
      (e.NO_CONTEXT = "no_context"),
      (e.FULL_CONTEXT = "full_context"),
      e
    );
  })({}),
  Lh = {
    relative: "\\r",
    no_context: "\\n",
    full_context: "\\w",
    none: void 0,
  },
  jg = class extends Uo {
    constructor(e, t, r = {}) {
      const { hyperlink: n = !0, referenceFormat: s = "full_context" } = r,
        a = `${`REF ${e}`} ${[...(n ? ["\\h"] : []), ...[Lh[s]].filter((o) => !!o)].join(" ")}`;
      super(a, t);
    }
  },
  Dh = (e) =>
    new x({
      name: "w:outlineLvl",
      attributes: { val: { key: "w:val", value: e } },
    }),
  Mh = class extends y {
    constructor(e, t = {}) {
      (super("w:instrText"), this.root.push(new we({ space: fe.PRESERVE })));
      let r = `PAGEREF ${e}`;
      (t.hyperlink && (r = `${r} \\h`),
        t.useRelativePosition && (r = `${r} \\p`),
        this.root.push(r));
    }
  },
  Fh = class extends te {
    constructor(e, t = {}) {
      super({ children: [rs(), new Mh(e, t), Re(), Se()] });
    }
  },
  $h = 255,
  hi = (e) => {
    const t = e.indexOf("#"),
      r = e.length - t - 1;
    return t > 0 && r > 0 && r <= $h
      ? { target: e.slice(0, t), anchor: e.slice(t + 1) }
      : { target: e };
  },
  fr = (e, t, r) => (r === void 0 ? `${e}-${t}` : `${e}-restart ${r}`),
  Vg = {
    ANSI: "00",
    DEFAULT: "01",
    SYMBOL: "02",
    MAC: "4D",
    JIS: "80",
    HANGUL: "81",
    JOHAB: "82",
    GB_2312: "86",
    CHINESEBIG5: "88",
    GREEK: "A1",
    TURKISH: "A2",
    VIETNAMESE: "A3",
    HEBREW: "B1",
    ARABIC: "B2",
    BALTIC: "BA",
    RUSSIAN: "CC",
    THAI: "DE",
    EASTEUROPE: "EE",
    OEM: "FF",
  },
  rr = ({ id: e, fontKey: t, subsetted: r }, n) =>
    new x({
      name: n,
      attributes: f(
        { id: { key: "r:id", value: e } },
        t
          ? { fontKey: { key: "w:fontKey", value: `{${t.toUpperCase()}}` } }
          : {},
      ),
      children: [...(r ? [new N("w:subsetted", r)] : [])],
    }),
  Hh = ({
    name: e,
    altName: t,
    panose1: r,
    charset: n,
    family: s,
    notTrueType: a,
    pitch: o,
    sig: i,
    embedRegular: l,
    embedBold: c,
    embedItalic: u,
    embedBoldItalic: d,
  }) =>
    new x({
      name: "w:font",
      attributes: { name: { key: "w:name", value: e } },
      children: [
        ...(t ? [Et("w:altName", t)] : []),
        ...(r ? [Et("w:panose1", r)] : []),
        ...(n ? [Et("w:charset", n)] : []),
        Et("w:family", s),
        ...(a ? [new N("w:notTrueType", a)] : []),
        Et("w:pitch", o),
        ...(i
          ? [
              new x({
                name: "w:sig",
                attributes: {
                  usb0: { key: "w:usb0", value: i.usb0 },
                  usb1: { key: "w:usb1", value: i.usb1 },
                  usb2: { key: "w:usb2", value: i.usb2 },
                  usb3: { key: "w:usb3", value: i.usb3 },
                  csb0: { key: "w:csb0", value: i.csb0 },
                  csb1: { key: "w:csb1", value: i.csb1 },
                },
              }),
            ]
          : []),
        ...(l ? [rr(l, "w:embedRegular")] : []),
        ...(c ? [rr(c, "w:embedBold")] : []),
        ...(u ? [rr(u, "w:embedItalic")] : []),
        ...(d ? [rr(d, "w:embedBoldItalic")] : []),
      ],
    }),
  Bh = ({
    name: e,
    characterSet: t,
    embedRegular: r,
    embedBold: n,
    embedItalic: s,
    embedBoldItalic: a,
  }) =>
    Hh({
      name: e,
      sig: {
        usb0: "E0002AFF",
        usb1: "C000247B",
        usb2: "00000009",
        usb3: "00000000",
        csb0: "000001FF",
        csb1: "00000000",
      },
      charset: t,
      family: "auto",
      pitch: "variable",
      embedRegular: r,
      embedBold: n,
      embedItalic: s,
      embedBoldItalic: a,
    }),
  Wh = (e) =>
    new x({
      name: "w:fonts",
      attributes: {
        mc: {
          key: "xmlns:mc",
          value: "http://schemas.openxmlformats.org/markup-compatibility/2006",
        },
        r: {
          key: "xmlns:r",
          value:
            "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
        },
        w: {
          key: "xmlns:w",
          value: "http://schemas.openxmlformats.org/wordprocessingml/2006/main",
        },
        w14: {
          key: "xmlns:w14",
          value: "http://schemas.microsoft.com/office/word/2010/wordml",
        },
        w15: {
          key: "xmlns:w15",
          value: "http://schemas.microsoft.com/office/word/2012/wordml",
        },
        w16cex: {
          key: "xmlns:w16cex",
          value: "http://schemas.microsoft.com/office/word/2018/wordml/cex",
        },
        w16cid: {
          key: "xmlns:w16cid",
          value: "http://schemas.microsoft.com/office/word/2016/wordml/cid",
        },
        w16: {
          key: "xmlns:w16",
          value: "http://schemas.microsoft.com/office/word/2018/wordml",
        },
        w16sdtdh: {
          key: "xmlns:w16sdtdh",
          value:
            "http://schemas.microsoft.com/office/word/2020/wordml/sdtdatahash",
        },
        w16se: {
          key: "xmlns:w16se",
          value: "http://schemas.microsoft.com/office/word/2015/wordml/symex",
        },
        Ignorable: {
          key: "mc:Ignorable",
          value: "w14 w15 w16se w16cid w16 w16cex w16sdtdh",
        },
      },
      children: e.map(Bh),
    }),
  Uh = [
    { option: "data", element: "embedRegular", bold: !1, italic: !1 },
    { option: "bold", element: "embedBold", bold: !0, italic: !1 },
    { option: "italic", element: "embedItalic", bold: !1, italic: !0 },
    { option: "boldItalic", element: "embedBoldItalic", bold: !0, italic: !0 },
  ],
  mi = class {
    constructor(e) {
      (p(this, "options", void 0),
        p(this, "fontTable", void 0),
        p(this, "relationships", void 0),
        p(this, "fontOptionsWithKey", []),
        p(this, "files", []),
        (this.options = e));
      const t = e.map((r) =>
        Uh.flatMap(({ option: n, element: s, bold: a, italic: o }) => {
          const i = r[n];
          return i
            ? [
                {
                  element: s,
                  file: {
                    name: r.name,
                    data: i,
                    bold: a,
                    italic: o,
                    fontKey: xo(),
                  },
                },
              ]
            : [];
        }),
      );
      ((this.files = t.flatMap((r) => r.map(({ file: n }) => n))),
        (this.fontOptionsWithKey = e.map((r, n) =>
          f(f({}, r), {}, { fontKey: t[n][0].file.fontKey }),
        )),
        (this.fontTable = Wh(
          e.map((r, n) =>
            f(
              { name: r.name, characterSet: r.characterSet },
              Object.fromEntries(
                t[n].map(({ element: s, file: a }) => [
                  s,
                  { id: `rId${this.files.indexOf(a) + 1}`, fontKey: a.fontKey },
                ]),
              ),
            ),
          ),
        )),
        (this.relationships = new se()));
      for (let r = 0; r < this.files.length; r++)
        this.relationships.addRelationship(
          r + 1,
          "http://schemas.openxmlformats.org/officeDocument/2006/relationships/font",
          `fonts/font${r + 1}.odttf`,
        );
    }
    get View() {
      return this.fontTable;
    }
    get Relationships() {
      return this.relationships;
    }
  },
  Gh = () =>
    new x({
      name: "w:wordWrap",
      attributes: { val: { key: "w:val", value: 0 } },
    }),
  Xg = { NONE: "none", DROP: "drop", MARGIN: "margin" },
  Kg = { MARGIN: "margin", PAGE: "page", TEXT: "text" },
  zg = {
    AROUND: "around",
    AUTO: "auto",
    NONE: "none",
    NOT_BESIDE: "notBeside",
    THROUGH: "through",
    TIGHT: "tight",
  },
  jh = (e) => {
    var t, r;
    return new x({
      name: "w:framePr",
      attributes: {
        anchorLock: { key: "w:anchorLock", value: e.anchorLock },
        dropCap: { key: "w:dropCap", value: e.dropCap },
        width: { key: "w:w", value: e.width },
        height: { key: "w:h", value: e.height },
        x: { key: "w:x", value: e.position ? e.position.x : void 0 },
        y: { key: "w:y", value: e.position ? e.position.y : void 0 },
        anchorHorizontal: { key: "w:hAnchor", value: e.anchor.horizontal },
        anchorVertical: { key: "w:vAnchor", value: e.anchor.vertical },
        spaceHorizontal: {
          key: "w:hSpace",
          value: (t = e.space) === null || t === void 0 ? void 0 : t.horizontal,
        },
        spaceVertical: {
          key: "w:vSpace",
          value: (r = e.space) === null || r === void 0 ? void 0 : r.vertical,
        },
        rule: { key: "w:hRule", value: e.rule },
        alignmentX: {
          key: "w:xAlign",
          value: e.alignment ? e.alignment.x : void 0,
        },
        alignmentY: {
          key: "w:yAlign",
          value: e.alignment ? e.alignment.y : void 0,
        },
        lines: { key: "w:lines", value: e.lines },
        wrap: { key: "w:wrap", value: e.wrap },
      },
    });
  },
  Vr = new WeakMap(),
  Vh = Tt(),
  Xh = { left: "right", right: "left" },
  dt = class extends Ze {
    constructor(
      e,
      { implicitListParagraphStyle: t = !0, inListOrder: r = !0 } = {},
    ) {
      if (
        (super("w:pPr", e?.includeIfEmpty),
        p(this, "numbering", void 0),
        p(this, "numberProperties", void 0),
        !e)
      )
        return this;
      if (
        (e.heading && this.push(Pt(e.heading)),
        t &&
          (e.bullet && this.push(Pt("ListParagraph")),
          e.numbering &&
            !e.numbering.custom &&
            !e.style &&
            !e.heading &&
            this.push(Pt("ListParagraph"))),
        e.style && this.push(Pt(e.style)),
        e.keepNext !== void 0 && this.push(new N("w:keepNext", e.keepNext)),
        e.keepLines !== void 0 && this.push(new N("w:keepLines", e.keepLines)),
        e.pageBreakBefore && this.push(new Eh()),
        e.frame && this.push(jh(e.frame)),
        e.widowControl !== void 0 &&
          this.push(new N("w:widowControl", e.widowControl)),
        e.bullet && this.push(new tr(1, e.bullet.level)),
        e.numbering)
      ) {
        const { reference: s, instance: a, level: o, restart: i } = e.numbering,
          l = typeof s == "string" ? s : s.reference,
          c = new tr(fr(l, a ?? 0), o);
        ((this.numbering = {
          reference: l,
          level: o,
          instance: a,
          restartedListId: i && r && a === void 0 ? Vh() : void 0,
          definition: typeof s == "string" ? void 0 : s,
        }),
          (this.numberProperties = c),
          this.push(c));
      } else e.numbering === !1 && this.push(new tr(0, 0));
      (e.border && this.push(new Ec(e.border)),
        e.thematicBreak && this.push(new Sc()),
        e.shading && this.push(kr(e.shading)),
        e.wordWrap && this.push(Gh()),
        e.overflowPunctuation &&
          this.push(new N("w:overflowPunct", e.overflowPunctuation)));
      const n = [
        ...(e.rightTabStop !== void 0
          ? [{ type: Vs.RIGHT, position: e.rightTabStop }]
          : []),
        ...(e.tabStops ? e.tabStops : []),
        ...(e.leftTabStop !== void 0
          ? [{ type: Vs.LEFT, position: e.leftTabStop }]
          : []),
      ];
      (n.length > 0 && this.push(Ch(n)),
        e.bidirectional !== void 0 &&
          this.push(new N("w:bidi", e.bidirectional)),
        e.spacing && this.push(Sh(e.spacing)),
        e.indent && this.push(Ac(e.indent)),
        e.contextualSpacing !== void 0 &&
          this.push(new N("w:contextualSpacing", e.contextualSpacing)),
        e.alignment &&
          this.push(io((e.bidirectional && Xh[e.alignment]) || e.alignment)),
        e.outlineLevel !== void 0 && this.push(Dh(e.outlineLevel)),
        e.suppressLineNumbers !== void 0 &&
          this.push(new N("w:suppressLineNumbers", e.suppressLineNumbers)),
        e.autoSpaceEastAsianText !== void 0 &&
          this.push(new N("w:autoSpaceDN", e.autoSpaceEastAsianText)),
        e.run && this.push(new iu(e.run)),
        e.revision && this.push(new Xs(e.revision)));
    }
    push(e) {
      this.root.push(e);
    }
    addSectionProperties(e) {
      const t = this.root.findIndex((r) => r instanceof Xs);
      if (t === -1) {
        this.root.push(e);
        return;
      }
      this.root.splice(t, 0, e);
    }
    removeSectionProperties(e) {
      const t = this.root.indexOf(e);
      t !== -1 && this.root.splice(t, 1);
    }
    prepForXml(e) {
      var t;
      if (this.numbering) {
        var r, n;
        const {
            reference: o,
            level: i,
            instance: l = 0,
            definition: c,
          } = this.numbering,
          u =
            this.numbering.instance === void 0
              ? (r = this.numbering.restartedListId) !== null && r !== void 0
                ? r
                : (n = Vr.get(e)) === null || n === void 0
                  ? void 0
                  : n.get(o)
              : void 0;
        e.viewWrapper instanceof mi ||
          e.file.Numbering.createConcreteNumberingInstance(o, l, c, u);
        const d = new tr(fr(o, l, u), i);
        (this.root.splice(this.root.indexOf(this.numberProperties), 1, d),
          (this.numberProperties = d));
      }
      const s = super.prepForXml(e);
      if (
        ((t = this.numbering) === null || t === void 0
          ? void 0
          : t.restartedListId) !== void 0
      ) {
        var a;
        Vr.set(
          e,
          new Map([
            ...((a = Vr.get(e)) !== null && a !== void 0 ? a : []),
            [this.numbering.reference, this.numbering.restartedListId],
          ]),
        );
      }
      return s;
    }
  },
  Xs = class extends y {
    constructor(e) {
      (super("w:pPrChange"),
        this.root.push(new ge({ id: e.id, author: e.author, date: e.date })),
        this.root.push(
          new dt(f(f({}, e), {}, { includeIfEmpty: !0 }), { inListOrder: !1 }),
        ));
    }
  },
  me = class pi extends Or {
    constructor(t) {
      if (
        (super("w:p"),
        p(this, "options", void 0),
        p(this, "properties", void 0),
        p(this, "alignment", void 0),
        (this.options = typeof t == "string" ? { text: t } : t),
        typeof t == "string")
      )
        return (
          (this.alignment = {}),
          (this.properties = new dt({})),
          this.root.push(this.properties),
          this.root.push(new Ye(t)),
          this
        );
      if (
        ((this.alignment = {
          alignment: t.alignment,
          bidirectional: t.bidirectional,
        }),
        (this.properties = new dt(t)),
        this.root.push(this.properties),
        t.text && this.root.push(new Ye(t.text)),
        t.children)
      )
        for (const r of t.children) {
          if (r instanceof li) {
            this.root.push(...r.writtenAs);
            continue;
          }
          this.root.push(r);
        }
    }
    prepForXml(t) {
      for (const r of this.root)
        if (Gt(r) === "w:externalHyperlink") {
          const n = this.root.indexOf(r),
            { options: s } = r,
            { target: a, anchor: o } = hi(s.link),
            i = new Kt(s.children, at(), o, s.link);
          (t.viewWrapper.Relationships.addRelationship(
            i.linkId,
            "http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink",
            a,
            ss.EXTERNAL,
          ),
            (this.root[n] = i));
        }
      return super.prepForXml(t);
    }
    addSectionProperties(t) {
      this.properties.addSectionProperties(t);
    }
    removeSectionProperties(t) {
      this.properties.removeSectionProperties(t);
    }
    get Alignment() {
      return this.alignment;
    }
    with(t) {
      return new pi(f(f({}, this.options), t));
    }
    addRunToFront(t) {
      return (this.root.splice(1, 0, t), this);
    }
  },
  Yg = class extends y {
    constructor(e) {
      super("m:oMath");
      for (const t of e.children) this.root.push(t);
    }
  },
  Kh = class extends y {
    constructor(e) {
      (super("m:t"),
        /^[\s\u200B]|[\s\u200B]$/.test(e) &&
          this.root.push(new we({ space: fe.PRESERVE })),
        this.root.push(e));
    }
  },
  zh = ["text", "normalText", "script", "literal"],
  Xr = { plain: "p", bold: "b", italic: "i", boldItalic: "bi" },
  Kr = {
    roman: "roman",
    script: "script",
    fraktur: "fraktur",
    doubleStruck: "double-struck",
    sansSerif: "sans-serif",
    monospace: "monospace",
  },
  nr = (e, t) =>
    new x({ name: e, attributes: { value: { key: "m:val", value: t } } }),
  qg = class extends y {
    constructor(e) {
      var t;
      super("m:r");
      const r = typeof e == "string" ? { text: e } : e,
        { text: n, normalText: s, script: a, literal: o } = r,
        i =
          (t = jt(r, zh).style) !== null && t !== void 0
            ? t
            : a === void 0 || a === "roman"
              ? void 0
              : "plain";
      if (s && (i !== void 0 || a !== void 0))
        throw new Error(
          "MathRun: normalText can't be given with style or script, which are for math. Give one or the other",
        );
      if (i !== void 0 && !Object.keys(Xr).includes(i))
        throw new Error(
          `MathRun: style is "${i}", which isn't one of ${Object.keys(Xr).join(", ")}`,
        );
      if (a !== void 0 && !Object.keys(Kr).includes(a))
        throw new Error(
          `MathRun: script is "${a}", which isn't one of ${Object.keys(Kr).join(", ")}`,
        );
      const l = [
        ...(o ? [nr("m:lit", 1)] : []),
        ...(s ? [nr("m:nor", 1)] : []),
        ...(a === void 0 ? [] : [nr("m:scr", Kr[a])]),
        ...(i === void 0 ? [] : [nr("m:sty", Xr[i])]),
      ];
      (l.length > 0 && this.root.push(new x({ name: "m:rPr", children: l })),
        this.root.push(new Kh(n)));
    }
  },
  Yh = class extends y {
    constructor(e) {
      super("m:den");
      for (const t of e) this.root.push(t);
    }
  },
  qh = class extends y {
    constructor(e) {
      super("m:num");
      for (const t of e) this.root.push(t);
    }
  },
  zr = { stacked: "bar", skewed: "skw", linear: "lin", noBar: "noBar" },
  Jg = class extends y {
    constructor(e) {
      if ((super("m:f"), e.type !== void 0)) {
        if (!Object.keys(zr).includes(e.type))
          throw new Error(
            `MathFraction: type is "${e.type}", which isn't one of ${Object.keys(zr).join(", ")}`,
          );
        this.root.push(
          new x({
            name: "m:fPr",
            children: [
              new x({
                name: "m:type",
                attributes: { value: { key: "m:val", value: zr[e.type] } },
              }),
            ],
          }),
        );
      }
      (this.root.push(new qh(e.numerator)),
        this.root.push(new Yh(e.denominator)));
    }
  },
  Jh = ({ accent: e }) =>
    new x({
      name: "m:chr",
      attributes: { accent: { key: "m:val", value: e } },
    }),
  ye = ({ children: e }) => new x({ name: "m:e", children: e }),
  Zh = ({ value: e }) =>
    new x({
      name: "m:limLoc",
      attributes: { value: { key: "m:val", value: e || "undOvr" } },
    }),
  Qh = () =>
    new x({
      name: "m:subHide",
      attributes: { hide: { key: "m:val", value: 1 } },
    }),
  em = () =>
    new x({
      name: "m:supHide",
      attributes: { hide: { key: "m:val", value: 1 } },
    }),
  vi = ({
    accent: e,
    hasSuperScript: t,
    hasSubScript: r,
    limitLocationVal: n,
  }) =>
    new x({
      name: "m:naryPr",
      children: [
        ...(e ? [Jh({ accent: e })] : []),
        Zh({ value: n }),
        ...(r ? [] : [Qh()]),
        ...(t ? [] : [em()]),
      ],
    }),
  zt = ({ children: e }) => new x({ name: "m:sub", children: e }),
  Yr = { aboveBelow: "undOvr", side: "subSup" },
  fi = (e, t, r) => {
    if (t === void 0) return r;
    if (!Object.keys(Yr).includes(t))
      throw new Error(
        `${e}: limits is "${t}", which isn't one of ${Object.keys(Yr).join(", ")}`,
      );
    return Yr[t];
  },
  Yt = ({ children: e }) => new x({ name: "m:sup", children: e }),
  Zg = class extends y {
    constructor(e) {
      var t, r;
      (super("m:nary"),
        this.root.push(
          vi({
            accent: "∑",
            hasSuperScript: !!e.superScript,
            hasSubScript: !!e.subScript,
            limitLocationVal: fi("MathSum", e.limits, "undOvr"),
          }),
        ),
        this.root.push(
          zt({ children: (t = e.subScript) !== null && t !== void 0 ? t : [] }),
        ),
        this.root.push(
          Yt({
            children: (r = e.superScript) !== null && r !== void 0 ? r : [],
          }),
        ),
        this.root.push(ye({ children: e.children })));
    }
  },
  Qg = class extends y {
    constructor(e) {
      var t, r;
      (super("m:nary"),
        this.root.push(
          vi({
            accent: "",
            hasSuperScript: !!e.superScript,
            hasSubScript: !!e.subScript,
            limitLocationVal: fi("MathIntegral", e.limits, "subSup"),
          }),
        ),
        this.root.push(
          zt({ children: (t = e.subScript) !== null && t !== void 0 ? t : [] }),
        ),
        this.root.push(
          Yt({
            children: (r = e.superScript) !== null && r !== void 0 ? r : [],
          }),
        ),
        this.root.push(ye({ children: e.children })));
    }
  },
  wi = class extends y {
    constructor(e) {
      super("m:lim");
      for (const t of e) this.root.push(t);
    }
  },
  ey = class extends y {
    constructor(e) {
      (super("m:limUpp"),
        this.root.push(ye({ children: e.children })),
        this.root.push(new wi(e.limit)));
    }
  },
  ty = class extends y {
    constructor(e) {
      (super("m:limLow"),
        this.root.push(ye({ children: e.children })),
        this.root.push(new wi(e.limit)));
    }
  },
  tm = () => new x({ name: "m:sSupPr" }),
  ry = class extends y {
    constructor(e) {
      (super("m:sSup"),
        this.root.push(tm()),
        this.root.push(ye({ children: e.children })),
        this.root.push(Yt({ children: e.superScript })));
    }
  },
  rm = () => new x({ name: "m:sSubPr" }),
  ny = class extends y {
    constructor(e) {
      (super("m:sSub"),
        this.root.push(rm()),
        this.root.push(ye({ children: e.children })),
        this.root.push(zt({ children: e.subScript })));
    }
  },
  nm = () => new x({ name: "m:sSubSupPr" }),
  sy = class extends y {
    constructor(e) {
      (super("m:sSubSup"),
        this.root.push(nm()),
        this.root.push(ye({ children: e.children })),
        this.root.push(zt({ children: e.subScript })),
        this.root.push(Yt({ children: e.superScript })));
    }
  },
  sm = () => new x({ name: "m:sPrePr" }),
  ay = class extends x {
    constructor({ children: e, subScript: t, superScript: r }) {
      super({
        name: "m:sPre",
        children: [
          sm(),
          zt({ children: t }),
          Yt({ children: r }),
          ye({ children: e }),
        ],
      });
    }
  },
  am = class extends y {
    constructor(e) {
      if ((super("m:deg"), e)) for (const t of e) this.root.push(t);
    }
  },
  om = class extends _ {
    constructor(...e) {
      (super(...e), p(this, "xmlKeys", { hide: "m:val" }));
    }
  },
  im = class extends y {
    constructor() {
      (super("m:degHide"), this.root.push(new om({ hide: 1 })));
    }
  },
  lm = class extends y {
    constructor(e) {
      (super("m:radPr"), e || this.root.push(new im()));
    }
  },
  oy = class extends y {
    constructor(e) {
      (super("m:rad"),
        this.root.push(new lm(!!e.degree)),
        this.root.push(new am(e.degree)),
        this.root.push(ye({ children: e.children })));
    }
  },
  cm = class extends y {
    constructor(e) {
      super("m:fName");
      for (const t of e) this.root.push(t);
    }
  },
  um = class extends y {
    constructor() {
      super("m:funcPr");
    }
  },
  iy = class extends y {
    constructor(e) {
      (super("m:func"),
        this.root.push(new um()),
        this.root.push(new cm(e.name)),
        this.root.push(ye({ children: e.children })));
    }
  },
  dm = ({ character: e }) =>
    new x({
      name: "m:begChr",
      attributes: { character: { key: "m:val", value: e } },
    }),
  hm = ({ character: e }) =>
    new x({
      name: "m:endChr",
      attributes: { character: { key: "m:val", value: e } },
    }),
  _r = ({ characters: e }) =>
    new x({
      name: "m:dPr",
      children: e
        ? [
            dm({ character: e.beginningCharacter }),
            hm({ character: e.endingCharacter }),
          ]
        : [],
    }),
  ly = class extends y {
    constructor(e) {
      (super("m:d"),
        this.root.push(_r({})),
        this.root.push(ye({ children: e.children })));
    }
  },
  cy = class extends y {
    constructor(e) {
      (super("m:d"),
        this.root.push(
          _r({ characters: { beginningCharacter: "[", endingCharacter: "]" } }),
        ),
        this.root.push(ye({ children: e.children })));
    }
  },
  uy = class extends y {
    constructor(e) {
      (super("m:d"),
        this.root.push(
          _r({ characters: { beginningCharacter: "{", endingCharacter: "}" } }),
        ),
        this.root.push(ye({ children: e.children })));
    }
  },
  dy = class extends y {
    constructor(e) {
      (super("m:d"),
        this.root.push(
          _r({ characters: { beginningCharacter: "⟨", endingCharacter: "⟩" } }),
        ),
        this.root.push(ye({ children: e.children })));
    }
  },
  mm = { TOP: "top", CENTER: "center", BOTTOM: "bottom" },
  pm = f(f({}, mm), {}, { BOTH: "both" }),
  hy = pm,
  gi = (e) =>
    new x({
      name: "w:vAlign",
      attributes: { verticalAlign: { key: "w:val", value: e } },
    }),
  vm = ({ space: e, count: t, separate: r, equalWidth: n, children: s }) =>
    new x({
      name: "w:cols",
      attributes: {
        space: { key: "w:space", value: e === void 0 ? void 0 : ee(e) },
        count: { key: "w:num", value: t === void 0 ? void 0 : K(t) },
        separate: { key: "w:sep", value: r },
        equalWidth: { key: "w:equalWidth", value: n },
      },
      children: !n && s ? s : void 0,
    }),
  my = {
    DEFAULT: "default",
    LINES: "lines",
    LINES_AND_CHARS: "linesAndChars",
    SNAP_TO_CHARS: "snapToChars",
  },
  fm = ({ type: e, linePitch: t, charSpace: r }) =>
    new x({
      name: "w:docGrid",
      attributes: {
        type: { key: "w:type", value: e },
        linePitch: { key: "w:linePitch", value: K(t) },
        charSpace: { key: "w:charSpace", value: r ? K(r) : void 0 },
      },
    }),
  yt = { DEFAULT: "default", FIRST: "first", EVEN: "even" },
  Ks = { HEADER: "w:headerReference", FOOTER: "w:footerReference" },
  qr = (e, t) =>
    new x({
      name: e,
      attributes: {
        type: { key: "w:type", value: t.type || yt.DEFAULT },
        id: { key: "r:id", value: `rId${t.id}` },
      },
    }),
  py = {
    NEW_PAGE: "newPage",
    NEW_SECTION: "newSection",
    CONTINUOUS: "continuous",
  },
  wm = ({ countBy: e, start: t, restart: r, distance: n }) =>
    new x({
      name: "w:lnNumType",
      attributes: {
        countBy: { key: "w:countBy", value: e === void 0 ? void 0 : K(e) },
        start: { key: "w:start", value: t === void 0 ? void 0 : K(t) },
        restart: { key: "w:restart", value: r },
        distance: { key: "w:distance", value: n === void 0 ? void 0 : ee(n) },
      },
    }),
  vy = {
    PAGE_BOTTOM: "pageBottom",
    BENEATH_TEXT: "beneathText",
    SECTION_END: "sectEnd",
    DOCUMENT_END: "docEnd",
  },
  fy = { SECTION_END: "sectEnd", DOCUMENT_END: "docEnd" },
  wy = {
    CONTINUOUS: "continuous",
    EACH_SECTION: "eachSect",
    EACH_PAGE: "eachPage",
  },
  yi = ({ name: e, position: t, numberFormat: r, start: n, restart: s }) =>
    new x({
      name: e,
      children: [
        ...(t === void 0
          ? []
          : [
              new x({
                name: "w:pos",
                attributes: { val: { key: "w:val", value: t } },
              }),
            ]),
        ...(r
          ? [
              new x({
                name: "w:numFmt",
                attributes: {
                  val: { key: "w:val", value: r.type },
                  format: { key: "w:format", value: r.format },
                },
              }),
            ]
          : []),
        ...(n === void 0
          ? []
          : [
              new x({
                name: "w:numStart",
                attributes: { val: { key: "w:val", value: K(n) } },
              }),
            ]),
        ...(s === void 0
          ? []
          : [
              new x({
                name: "w:numRestart",
                attributes: { val: { key: "w:val", value: s } },
              }),
            ]),
      ],
    }),
  gm = (e) => yi(f({ name: "w:footnotePr" }, e)),
  ym = (e) => yi(f({ name: "w:endnotePr" }, e)),
  gy = {
    ALL_PAGES: "allPages",
    FIRST_PAGE: "firstPage",
    NOT_FIRST_PAGE: "notFirstPage",
  },
  yy = { PAGE: "page", TEXT: "text" },
  xy = { BACK: "back", FRONT: "front" },
  zs = class extends _ {
    constructor(...e) {
      (super(...e),
        p(this, "xmlKeys", {
          display: "w:display",
          offsetFrom: "w:offsetFrom",
          zOrder: "w:zOrder",
        }));
    }
  },
  xm = class extends Ze {
    constructor(e) {
      if ((super("w:pgBorders"), !e)) return this;
      (e.pageBorders
        ? this.root.push(
            new zs({
              display: e.pageBorders.display,
              offsetFrom: e.pageBorders.offsetFrom,
              zOrder: e.pageBorders.zOrder,
            }),
          )
        : this.root.push(new zs({})),
        e.pageBorderTop && this.root.push(Q("w:top", e.pageBorderTop)),
        e.pageBorderLeft && this.root.push(Q("w:left", e.pageBorderLeft)),
        e.pageBorderBottom && this.root.push(Q("w:bottom", e.pageBorderBottom)),
        e.pageBorderRight && this.root.push(Q("w:right", e.pageBorderRight)));
    }
  },
  bm = (e, t, r, n, s, a, o) =>
    new x({
      name: "w:pgMar",
      attributes: {
        top: { key: "w:top", value: Fe(e) },
        right: { key: "w:right", value: ee(t) },
        bottom: { key: "w:bottom", value: Fe(r) },
        left: { key: "w:left", value: ee(n) },
        header: { key: "w:header", value: ee(s) },
        footer: { key: "w:footer", value: ee(a) },
        gutter: { key: "w:gutter", value: ee(o) },
      },
    }),
  Tm = {
    HYPHEN: "hyphen",
    PERIOD: "period",
    COLON: "colon",
    EM_DASH: "emDash",
    EN_DASH: "endash",
  },
  Em = ({ start: e, formatType: t, separator: r, chapterHeadingLevel: n }) =>
    new x({
      name: "w:pgNumType",
      attributes: {
        start: { key: "w:start", value: e === void 0 ? void 0 : K(e) },
        formatType: { key: "w:fmt", value: t },
        separator: { key: "w:chapSep", value: r === Tm.EN_DASH ? "enDash" : r },
        chapterHeadingLevel: {
          key: "w:chapStyle",
          value: n === void 0 ? void 0 : K(n),
        },
      },
    }),
  wr = { PORTRAIT: "portrait", LANDSCAPE: "landscape" },
  Sm = ({ width: e, height: t, orientation: r, code: n }) => {
    const s = ee(e),
      a = ee(t);
    return new x({
      name: "w:pgSz",
      attributes: {
        width: { key: "w:w", value: r === wr.LANDSCAPE ? a : s },
        height: { key: "w:h", value: r === wr.LANDSCAPE ? s : a },
        orientation: { key: "w:orient", value: r },
        code: { key: "w:code", value: n },
      },
    });
  },
  by = {
    LEFT_TO_RIGHT_TOP_TO_BOTTOM: "lrTb",
    TOP_TO_BOTTOM_RIGHT_TO_LEFT: "tbRl",
  },
  Am = class extends _ {
    constructor(...e) {
      (super(...e), p(this, "xmlKeys", { val: "w:val" }));
    }
  },
  Im = class extends y {
    constructor(e) {
      (super("w:textDirection"), this.root.push(new Am({ val: e })));
    }
  },
  Ty = {
    NEXT_PAGE: "nextPage",
    NEXT_COLUMN: "nextColumn",
    CONTINUOUS: "continuous",
    EVEN_PAGE: "evenPage",
    ODD_PAGE: "oddPage",
  },
  Cm = (e) =>
    new x({ name: "w:type", attributes: { val: { key: "w:val", value: e } } }),
  De = {
    TOP: 1440,
    RIGHT: 1440,
    BOTTOM: 1440,
    LEFT: 1440,
    HEADER: 708,
    FOOTER: 708,
    GUTTER: 0,
  },
  lr = { WIDTH: 11906, HEIGHT: 16838, ORIENTATION: wr.PORTRAIT },
  Nn = class xi extends y {
    constructor({
      page: {
        size: {
          width: t = lr.WIDTH,
          height: r = lr.HEIGHT,
          orientation: n = lr.ORIENTATION,
          code: s,
        } = {},
        margin: {
          top: a = De.TOP,
          right: o = De.RIGHT,
          bottom: i = De.BOTTOM,
          left: l = De.LEFT,
          header: c = De.HEADER,
          footer: u = De.FOOTER,
          gutter: d = De.GUTTER,
        } = {},
        pageNumbers: h = {},
        borders: w,
        textDirection: m,
      } = {},
      grid: { linePitch: v = 360, charSpace: g, type: A } = {},
      headerWrapperGroup: I = {},
      footerWrapperGroup: b = {},
      lineNumbers: R,
      titlePage: O,
      verticalAlign: E,
      column: T,
      type: S,
      footnoteProperties: C,
      endnoteProperties: k,
      revision: L,
    } = {}) {
      (super("w:sectPr"),
        p(this, "availableTextWidth", void 0),
        (this.availableTextWidth = xi.calculateAvailableTextWidth({
          pageWidth: n === wr.LANDSCAPE ? r : t,
          left: l,
          right: o,
          gutter: d,
          column: T,
        })),
        this.addHeaderFooterGroup(Ks.HEADER, I),
        this.addHeaderFooterGroup(Ks.FOOTER, b),
        C && this.root.push(gm(C)),
        k && this.root.push(ym(k)),
        S && this.root.push(Cm(S)),
        this.root.push(Sm({ width: t, height: r, orientation: n, code: s })),
        this.root.push(bm(a, o, i, l, c, u, d)),
        w && this.root.push(new xm(w)),
        R && this.root.push(wm(R)),
        this.root.push(Em(h)),
        T && this.root.push(vm(T)),
        E && this.root.push(gi(E)),
        O !== void 0 && this.root.push(new N("w:titlePg", O)),
        m && this.root.push(new Im(m)),
        this.root.push(fm({ linePitch: v, charSpace: g, type: A })),
        L && this.root.push(new Nm(L)));
    }
    get AvailableTextWidth() {
      return this.availableTextWidth;
    }
    static calculateAvailableTextWidth({
      pageWidth: t,
      left: r,
      right: n,
      gutter: s,
      column: a,
    }) {
      var o, i;
      const l = nt(t) - nt(r) - nt(n) - nt(s),
        c = (o = a?.count) !== null && o !== void 0 ? o : 1;
      return c <= 1
        ? l
        : (l -
            nt((i = a?.space) !== null && i !== void 0 ? i : 720) * (c - 1)) /
            c;
    }
    addHeaderFooterGroup(t, r) {
      (r.default &&
        this.root.push(
          qr(t, { type: yt.DEFAULT, id: r.default.View.ReferenceId }),
        ),
        r.first &&
          this.root.push(
            qr(t, { type: yt.FIRST, id: r.first.View.ReferenceId }),
          ),
        r.even &&
          this.root.push(
            qr(t, { type: yt.EVEN, id: r.even.View.ReferenceId }),
          ));
    }
  },
  Nm = class extends y {
    constructor(e) {
      (super("w:sectPrChange"),
        this.root.push(new ge({ id: e.id, author: e.author, date: e.date })),
        this.root.push(new Nn(e)));
    }
  },
  bi = class extends y {
    constructor({ pageNumbers: e } = {}) {
      (super("w:body"),
        p(this, "sections", []),
        p(this, "sectionParagraphs", new Map()),
        p(this, "headingBookmarkIds", new Fd()),
        p(this, "pageNumbers", void 0),
        (this.pageNumbers = e));
    }
    getSectionPropertiesFor(e) {
      const t = e ? Math.max(this.root.indexOf(e), 0) : 0;
      for (let r = t; r < this.root.length; r++) {
        const n = this.root[r];
        if (n instanceof Nn) return n;
        const s = this.sectionParagraphs.get(n);
        if (s) return s;
      }
      return this.sections[this.sections.length - 1];
    }
    addSection(e) {
      const t = this.sections.pop(),
        r = this.lastParagraphOfSection();
      if (t && r) this.sectionParagraphs.set(r, t);
      else {
        const n = this.createSectionParagraph();
        (this.root.push(n), t && this.sectionParagraphs.set(n, t));
      }
      this.sections.push(new Nn(e));
    }
    prepForXml(e) {
      var t;
      this.sections.length === 1 &&
        (this.root.splice(0, 1), this.root.push(this.sections.pop()));
      for (const [s, a] of this.sectionParagraphs) s.addSectionProperties(a);
      let r;
      try {
        r = super.prepForXml(e);
      } finally {
        for (const [s, a] of this.sectionParagraphs)
          s.removeSectionProperties(a);
      }
      const n =
        (t = this.pageNumbers) === null || t === void 0
          ? void 0
          : t.listNumbers;
      return (
        Zd(r, e, this.headingBookmarkIds, n && ((s) => n(s, e))),
        this.pageNumbers && (sh(r, e), ah(r, e, this.pageNumbers)),
        r
      );
    }
    push(e) {
      const t = e instanceof me ? this.sectionParagraphs.get(e) : void 0;
      if (t) {
        const r = this.createSectionParagraph();
        (this.root.splice(this.root.indexOf(e) + 1, 0, r),
          this.sectionParagraphs.delete(e),
          this.sectionParagraphs.set(r, t));
      }
      this.root.push(e);
    }
    lastParagraphOfSection() {
      const e = this.root[this.root.length - 1];
      return e instanceof me &&
        e !== this.root[0] &&
        !this.sectionParagraphs.has(e) &&
        this.root.indexOf(e) === this.root.length - 1
        ? e
        : void 0;
    }
    createSectionParagraph() {
      return new me({});
    }
  },
  ze = { AUTO: "auto", DXA: "dxa", NIL: "nil", PERCENTAGE: "pct" },
  Ht = (e, { type: t = ze.AUTO, size: r }) => {
    let n = r;
    return (
      t === ze.PERCENTAGE && typeof r == "number" && (n = Math.round(r * 50)),
      new x({
        name: e,
        attributes: {
          type: { key: "w:type", value: t },
          size: { key: "w:w", value: oo(n) },
        },
      })
    );
  },
  cr = lr.WIDTH - De.LEFT - De.RIGHT - De.GUTTER,
  Ti = (e) => e.options.columnSpan || 1,
  ps = (e, t) => {
    if (!e) return;
    const { type: r = ze.AUTO, size: n } = e;
    if (r !== ze.PERCENTAGE && r !== ze.DXA) return;
    const s =
      typeof n == "number"
        ? r === ze.PERCENTAGE
          ? (n / 100) * t
          : n
        : n.endsWith("%")
          ? (Number(n.slice(0, -1)) / 100) * t
          : nt(n);
    return s > 0 ? s : void 0;
  },
  km = (e, t) => {
    var r;
    return (r = ps(e, t)) !== null && r !== void 0 ? r : t;
  },
  Rm = (e) =>
    Math.max(0, ...e.map((t) => t.cells.reduce((r, n) => r + Ti(n), 0))),
  Ys = ({ rows: e, width: t, availableWidth: r }) => {
    const n = Rm(e);
    if (n === 0) return [];
    const s = km(t, r),
      a = Array.from({ length: n }, () => {}),
      o = [];
    for (const u of e) {
      let d = 0;
      for (const h of u.cells) {
        const w = Ti(h),
          m = ps(h.options.width, s);
        if (m !== void 0)
          if (w === 1) {
            var i, l;
            ((l = a[(i = d)]) !== null && l !== void 0) || (a[i] = m);
          } else o.push({ start: d, span: w, width: m });
        d += w;
      }
    }
    for (const { start: u, span: d, width: h } of o) {
      const w = Array.from({ length: d }, (g, A) => u + A).filter((g) => g < n),
        m = w.filter((g) => a[g] === void 0),
        v =
          h -
          w.reduce((g, A) => {
            var I;
            return g + ((I = a[A]) !== null && I !== void 0 ? I : 0);
          }, 0);
      if (m.length > 0 && v > 0) for (const g of m) a[g] = v / m.length;
    }
    const c = a.flatMap((u, d) => (u === void 0 ? [d] : []));
    if (c.length > 0) {
      const u = s - a.reduce((h, w) => h + (w ?? 0), 0),
        d = u > 0 ? u / c.length : s / n;
      for (const h of c) a[h] = d;
    }
    return a.map((u) => Math.round(u));
  },
  Pm = (e) =>
    new x({
      name: "w:gridCol",
      attributes:
        e !== void 0 ? { width: { key: "w:w", value: ee(e) } } : void 0,
    }),
  ur = class extends y {
    constructor(e, t) {
      super("w:tblGrid");
      for (const r of e) this.root.push(Pm(r));
      t && this.root.push(new _m(t));
    }
  },
  Om = class extends _ {
    constructor(...e) {
      (super(...e), p(this, "xmlKeys", { id: "w:id" }));
    }
  },
  _m = class extends y {
    constructor(e) {
      (super("w:tblGridChange"),
        this.root.push(new Om({ id: e.id })),
        this.root.push(new ur(e.columnWidths)));
    }
  },
  Ey = class extends y {
    constructor(e) {
      (super("w:ins"),
        this.root.push(new ge({ id: e.id, author: e.author, date: e.date })),
        this.addChildElement(new Ye(e)));
    }
  },
  Lm = class extends y {
    constructor() {
      (super("w:delInstrText"),
        this.root.push(new we({ space: fe.PRESERVE })),
        this.root.push("PAGE"));
    }
  },
  Dm = class extends y {
    constructor() {
      (super("w:delInstrText"),
        this.root.push(new we({ space: fe.PRESERVE })),
        this.root.push("NUMPAGES"));
    }
  },
  Mm = class extends y {
    constructor() {
      (super("w:delInstrText"),
        this.root.push(new we({ space: fe.PRESERVE })),
        this.root.push("SECTIONPAGES"));
    }
  },
  qs = class extends y {
    constructor(e) {
      (super("w:delText"),
        this.root.push(new we({ space: fe.PRESERVE })),
        this.root.push(e));
    }
  },
  Fm = (e) => {
    switch (e) {
      case ut.CURRENT:
        return [Ke(), new Lm(), Re(), Se()];
      case ut.TOTAL_PAGES:
        return [Ke(), new Dm(), Re(), Se()];
      case ut.TOTAL_PAGES_IN_SECTION:
        return [Ke(), new Mm(), Re(), Se()];
      default:
        return;
    }
  },
  Sy = class extends y {
    constructor(e) {
      (super("w:del"),
        p(this, "deletedTextRunWrapper", void 0),
        this.root.push(new ge({ id: e.id, author: e.author, date: e.date })),
        (this.deletedTextRunWrapper = new $m(e)),
        this.addChildElement(this.deletedTextRunWrapper));
    }
  },
  $m = class kn extends y {
    constructor(t) {
      if (
        (super("w:r"),
        p(this, "following", []),
        this.root.push(new Qe(t)),
        t.children)
      )
        for (const [r, n] of t.children.entries()) {
          if (n instanceof te) {
            const s = t.children.slice(r + 1);
            this.following = [
              n,
              ...(s.length > 0
                ? [new kn(f(f({}, t), {}, { break: void 0, children: s }))]
                : []),
            ];
            break;
          }
          if (typeof n == "string") {
            const s = Fm(n);
            if (s) {
              const a = t.children.slice(r + 1),
                o = (c) =>
                  new kn(f(f({}, t), {}, { break: void 0, children: c })),
                i = this.root.length === 1;
              i && this.root.push(s[0]);
              const l = i ? s.slice(1) : s;
              this.following = [
                ...l.map((c) => o([c])),
                ...(a.length > 0 ? [o(a)] : []),
              ];
              break;
            }
            this.root.push(new qs(n));
            continue;
          }
          this.root.push(n);
        }
      else t.text && this.root.push(new qs(t.text));
      if (t.break)
        for (let r = 0; r < t.break; r++) this.root.splice(1, 0, ho());
    }
    get writtenAs() {
      return this.following.length > 0
        ? [
            this,
            ...this.following.flatMap((t) => {
              var r;
              return (r = t.writtenAs) !== null && r !== void 0 ? r : t;
            }),
          ]
        : void 0;
    }
  },
  Hm = class extends y {
    constructor(e) {
      (super("w:ins"),
        this.root.push(new ge({ id: e.id, author: e.author, date: e.date })));
    }
  },
  Bm = class extends y {
    constructor(e) {
      (super("w:del"),
        this.root.push(new ge({ id: e.id, author: e.author, date: e.date })));
    }
  },
  Wm = class extends y {
    constructor(e) {
      (super("w:cellIns"),
        this.root.push(new ge({ id: e.id, author: e.author, date: e.date })));
    }
  },
  Um = class extends y {
    constructor(e) {
      (super("w:cellDel"),
        this.root.push(new ge({ id: e.id, author: e.author, date: e.date })));
    }
  },
  Ay = { CONTINUE: "cont", RESTART: "rest" },
  Gm = class extends _ {
    constructor(...e) {
      (super(...e),
        p(this, "xmlKeys", {
          id: "w:id",
          author: "w:author",
          date: "w:date",
          verticalMerge: "w:vMerge",
          verticalMergeOriginal: "w:vMergeOrig",
        }));
    }
  },
  jm = class extends y {
    constructor(e) {
      (super("w:cellMerge"), this.root.push(new Gm(e)));
    }
  },
  Ei = ({ marginUnitType: e = ze.DXA, top: t, left: r, bottom: n, right: s }) =>
    [
      { name: "w:top", size: t },
      { name: "w:left", size: r },
      { name: "w:bottom", size: n },
      { name: "w:right", size: s },
    ]
      .filter((a) => a.size !== void 0)
      .map(({ name: a, size: o }) => Ht(a, { type: e, size: o })),
  Vm = (e) => {
    const t = Ei(e);
    if (t.length !== 0) return new x({ name: "w:tblCellMar", children: t });
  },
  Xm = (e) => {
    const t = Ei(e);
    if (t.length !== 0) return new x({ name: "w:tcMar", children: t });
  },
  Km = class extends Ze {
    constructor(e) {
      (super("w:tcBorders"),
        e.top && this.root.push(Q("w:top", e.top)),
        e.start && this.root.push(Q("w:start", e.start)),
        e.left && this.root.push(Q("w:left", e.left)),
        e.bottom && this.root.push(Q("w:bottom", e.bottom)),
        e.end && this.root.push(Q("w:end", e.end)),
        e.right && this.root.push(Q("w:right", e.right)),
        e.diagonalDown && this.root.push(Q("w:tl2br", e.diagonalDown)),
        e.diagonalUp && this.root.push(Q("w:tr2bl", e.diagonalUp)));
    }
  },
  zm = class extends _ {
    constructor(...e) {
      (super(...e), p(this, "xmlKeys", { val: "w:val" }));
    }
  },
  Ym = class extends y {
    constructor(e) {
      (super("w:gridSpan"), this.root.push(new zm({ val: K(e) })));
    }
  },
  Si = { CONTINUE: "continue", RESTART: "restart" },
  qm = class extends _ {
    constructor(...e) {
      (super(...e), p(this, "xmlKeys", { val: "w:val" }));
    }
  },
  Js = class extends y {
    constructor(e) {
      (super("w:vMerge"), this.root.push(new qm({ val: e })));
    }
  },
  Iy = {
    BOTTOM_TO_TOP_LEFT_TO_RIGHT: "btLr",
    LEFT_TO_RIGHT_TOP_TO_BOTTOM: "lrTb",
    TOP_TO_BOTTOM_RIGHT_TO_LEFT: "tbRl",
  },
  Jm = class extends _ {
    constructor(...e) {
      (super(...e), p(this, "xmlKeys", { val: "w:val" }));
    }
  },
  Zm = class extends y {
    constructor(e) {
      (super("w:textDirection"), this.root.push(new Jm({ val: e })));
    }
  },
  Ai = class extends Ze {
    constructor(e) {
      if (
        (super("w:tcPr", e.includeIfEmpty),
        p(this, "hasWidth", void 0),
        p(this, "hasColumnWidth", !1),
        (this.hasWidth = e.width !== void 0),
        e.width && this.root.push(Ht("w:tcW", e.width)),
        e.columnSpan && this.root.push(new Ym(e.columnSpan)),
        e.verticalMerge
          ? this.root.push(new Js(e.verticalMerge))
          : e.rowSpan && e.rowSpan > 1 && this.root.push(new Js(Si.RESTART)),
        e.borders && this.root.push(new Km(e.borders)),
        e.shading && this.root.push(kr(e.shading)),
        e.margins)
      ) {
        const t = Xm(e.margins);
        t && this.root.push(t);
      }
      (e.textDirection && this.root.push(new Zm(e.textDirection)),
        e.verticalAlign && this.root.push(gi(e.verticalAlign)),
        e.insertion && this.root.push(new Wm(e.insertion)),
        e.deletion && this.root.push(new Um(e.deletion)),
        e.cellMerge && this.root.push(new jm(e.cellMerge)),
        e.revision && this.root.push(new Qm(e.revision)));
    }
    setColumnWidth(e) {
      this.hasWidth ||
        (this.root.splice(
          0,
          this.hasColumnWidth ? 1 : 0,
          Ht("w:tcW", { size: e, type: ze.DXA }),
        ),
        (this.hasColumnWidth = !0));
    }
  },
  Qm = class extends y {
    constructor(e) {
      (super("w:tcPrChange"),
        this.root.push(new ge({ id: e.id, author: e.author, date: e.date })),
        this.root.push(new Ai(f(f({}, e), {}, { includeIfEmpty: !0 }))));
    }
  },
  Zs = class extends y {
    constructor(e) {
      (super("w:tc"),
        p(this, "options", void 0),
        p(this, "properties", void 0),
        (this.options = e),
        (this.properties = new Ai(e)),
        this.root.push(this.properties));
      for (const t of e.children) this.root.push(t);
    }
    setColumnWidth(e) {
      this.properties.setColumnWidth(e);
    }
    prepForXml(e) {
      return (
        Gt(this.root[this.root.length - 1]) !== "w:p" &&
          this.root.push(new me({})),
        super.prepForXml(e)
      );
    }
  },
  Rn = (e, t) => (t ? new N(e) : new $e(e, "off")),
  ft = { style: es.NONE, size: 0, color: "auto" },
  ep = { style: es.SINGLE, size: 4, color: "auto" },
  Ii = class extends Ze {
    constructor(e, { fillMissingSides: t = !0 } = {}) {
      super("w:tblBorders");
      const r = [
        ["w:top", e.top],
        ["w:left", e.left],
        ["w:bottom", e.bottom],
        ["w:right", e.right],
        ["w:insideH", e.insideHorizontal],
        ["w:insideV", e.insideVertical],
      ];
      for (const [n, s] of r) {
        const a = s ?? (t ? ep : void 0);
        a && this.root.push(Q(n, a));
      }
    }
  };
p(Ii, "NONE", {
  top: ft,
  bottom: ft,
  left: ft,
  right: ft,
  insideHorizontal: ft,
  insideVertical: ft,
});
var Cy = { MARGIN: "margin", PAGE: "page", TEXT: "text" },
  Jr = {
    CENTER: "center",
    INSIDE: "inside",
    LEFT: "left",
    OUTSIDE: "outside",
    RIGHT: "right",
  },
  tp = {
    CENTER: "center",
    INSIDE: "inside",
    BOTTOM: "bottom",
    OUTSIDE: "outside",
    INLINE: "inline",
    TOP: "top",
  },
  Ny = { NEVER: "never", OVERLAP: "overlap" },
  rp = ({
    horizontalAnchor: e,
    verticalAnchor: t,
    absoluteHorizontalPosition: r,
    relativeHorizontalPosition: n,
    absoluteVerticalPosition: s,
    relativeVerticalPosition: a,
    bottomFromText: o,
    topFromText: i,
    leftFromText: l,
    rightFromText: c,
  }) =>
    new x({
      name: "w:tblpPr",
      attributes: {
        leftFromText: {
          key: "w:leftFromText",
          value: l === void 0 ? void 0 : ee(l),
        },
        rightFromText: {
          key: "w:rightFromText",
          value: c === void 0 ? void 0 : ee(c),
        },
        topFromText: {
          key: "w:topFromText",
          value: i === void 0 ? void 0 : ee(i),
        },
        bottomFromText: {
          key: "w:bottomFromText",
          value: o === void 0 ? void 0 : ee(o),
        },
        absoluteHorizontalPosition: {
          key: "w:tblpX",
          value: r === void 0 ? void 0 : Fe(r),
        },
        absoluteVerticalPosition: {
          key: "w:tblpY",
          value: s === void 0 ? void 0 : Fe(s),
        },
        horizontalAnchor: { key: "w:horzAnchor", value: e },
        relativeHorizontalPosition: { key: "w:tblpXSpec", value: n },
        relativeVerticalPosition: { key: "w:tblpYSpec", value: a },
        verticalAnchor: { key: "w:vertAnchor", value: t },
      },
    }),
  ky = { AUTOFIT: "autofit", FIXED: "fixed" },
  np = (e) =>
    new x({
      name: "w:tblLayout",
      attributes: { type: { key: "w:type", value: e } },
    }),
  sp = { DXA: "dxa" },
  Ci = ({ type: e = sp.DXA, value: t }) =>
    new x({
      name: "w:tblCellSpacing",
      attributes: {
        type: { key: "w:type", value: e },
        value: { key: "w:w", value: oo(t) },
      },
    }),
  ap = ({
    firstRow: e,
    lastRow: t,
    firstColumn: r,
    lastColumn: n,
    noHBand: s,
    noVBand: a,
  }) =>
    new x({
      name: "w:tblLook",
      attributes: {
        firstRow: { key: "w:firstRow", value: e },
        lastRow: { key: "w:lastRow", value: t },
        firstColumn: { key: "w:firstColumn", value: r },
        lastColumn: { key: "w:lastColumn", value: n },
        noHBand: { key: "w:noHBand", value: s },
        noVBand: { key: "w:noVBand", value: a },
      },
    }),
  op = (e) =>
    new x({
      name: "w:tblOverlap",
      attributes: { val: { key: "w:val", value: e } },
    }),
  ip = { [Jr.LEFT]: de.LEFT, [Jr.CENTER]: de.CENTER, [Jr.RIGHT]: de.RIGHT },
  vs = class extends Ze {
    constructor(e) {
      var t, r, n;
      (super("w:tblPr", e.includeIfEmpty),
        e.style && this.root.push(new $e("w:tblStyle", e.style)));
      const s =
          ((t = e.float) === null || t === void 0
            ? void 0
            : t.relativeVerticalPosition) === tp.INLINE,
        a = s ? void 0 : e.float;
      (a && this.root.push(rp(a)),
        a?.overlap && this.root.push(op(a.overlap)),
        e.visuallyRightToLeft !== void 0 &&
          this.root.push(Rn("w:bidiVisual", e.visuallyRightToLeft)),
        e.width && this.root.push(Ht("w:tblW", e.width)));
      const o =
        (r = e.alignment) !== null && r !== void 0
          ? r
          : s &&
              !((n = e.float) === null || n === void 0) &&
              n.relativeHorizontalPosition
            ? ip[e.float.relativeHorizontalPosition]
            : void 0;
      if (
        (o && this.root.push(io(o)),
        e.cellSpacing && this.root.push(Ci(e.cellSpacing)),
        e.indent && this.root.push(Ht("w:tblInd", e.indent)),
        e.borders &&
          this.root.push(new Ii(e.borders, { fillMissingSides: !e.style })),
        e.shading && this.root.push(kr(e.shading)),
        e.layout && this.root.push(np(e.layout)),
        e.cellMargin)
      ) {
        const i = Vm(e.cellMargin);
        i && this.root.push(i);
      }
      (e.tableLook && this.root.push(ap(e.tableLook)),
        e.revision && this.root.push(new lp(e.revision)));
    }
  },
  lp = class extends y {
    constructor(e) {
      (super("w:tblPrChange"),
        this.root.push(new ge({ id: e.id, author: e.author, date: e.date })),
        this.root.push(new vs(f(f({}, e), {}, { includeIfEmpty: !0 }))));
    }
  },
  Ry = { AUTO: "auto", ATLEAST: "atLeast", EXACT: "exact" },
  cp = (e, t) =>
    new x({
      name: "w:trHeight",
      attributes: {
        value: { key: "w:val", value: ee(e) },
        rule: { key: "w:hRule", value: t },
      },
    }),
  Ni = class extends Ze {
    constructor(e) {
      (super("w:trPr", e.includeIfEmpty),
        e.cantSplit !== void 0 &&
          this.root.push(Rn("w:cantSplit", e.cantSplit)),
        e.tableHeader !== void 0 &&
          this.root.push(Rn("w:tblHeader", e.tableHeader)),
        e.height && this.root.push(cp(e.height.value, e.height.rule)),
        e.cellSpacing && this.root.push(Ci(e.cellSpacing)),
        e.insertion && this.root.push(new Hm(e.insertion)),
        e.deletion && this.root.push(new Bm(e.deletion)),
        e.revision && this.root.push(new up(e.revision)));
    }
  },
  up = class extends y {
    constructor(e) {
      (super("w:trPrChange"),
        this.root.push(new ge({ id: e.id, author: e.author, date: e.date })),
        this.root.push(new Ni(f(f({}, e), {}, { includeIfEmpty: !0 }))));
    }
  },
  gr = (e, t) => {
    const r = e[t];
    return Array.isArray(r) ? r : [];
  },
  _t = (e) => Object.keys(e)[0],
  dp = (e, t) => {
    const r = gr(e, "w:p"),
      n = r.find((i) => _t(i) === "w:pPr");
    if (!n) return { "w:p": [{ "w:pPr": [t] }, ...r] };
    const s = gr(n, "w:pPr");
    if (s.some((i) => _t(i) === "w:keepNext")) return e;
    const a = s.filter((i) => _t(i) === "w:pStyle").length,
      o = { "w:pPr": [...s.slice(0, a), t, ...s.slice(a)] };
    return { "w:p": r.map((i) => (i === n ? o : i)) };
  },
  hp = class extends y {
    constructor(e) {
      (super("w:tr"),
        p(this, "options", void 0),
        (this.options = e),
        this.root.push(new Ni(e)));
      for (const t of e.children) this.root.push(t);
    }
    prepForXml(e) {
      if (this.cells.length === 0) return;
      const t = super.prepForXml(e);
      if (!t || this.options.keepNext === void 0) return t;
      const r = new N("w:keepNext", this.options.keepNext).prepForXml(e);
      return {
        "w:tr": gr(t, "w:tr").map((n) =>
          _t(n) === "w:tc"
            ? {
                "w:tc": gr(n, "w:tc").map((s) =>
                  _t(s) === "w:p" ? dp(s, r) : s,
                ),
              }
            : n,
        ),
      };
    }
    get CellCount() {
      return this.options.children.length;
    }
    get cells() {
      return this.root.filter((e) => Gt(e) === "w:tc");
    }
    addCellToIndex(e, t) {
      this.root.splice(t + 1, 0, e);
    }
    addCellToColumnIndex(e, t) {
      const r = this.columnIndexToRootIndex(t, !0);
      this.addCellToIndex(e, r - 1);
    }
    rootIndexToColumnIndex(e) {
      if (e < 1 || e >= this.root.length)
        throw new Error(
          `cell 'rootIndex' should between 1 to ${this.root.length - 1}`,
        );
      let t = 0;
      for (let r = 1; r < e; r++) {
        const n = this.root[r];
        t += n.options.columnSpan || 1;
      }
      return t;
    }
    columnIndexToRootIndex(e, t = !1) {
      if (e < 0)
        throw new Error("cell 'columnIndex' should not less than zero");
      let r = 0,
        n = 1;
      for (; r <= e;) {
        if (n >= this.root.length) {
          if (t) return this.root.length;
          throw new Error(`cell 'columnIndex' should not great than ${r - 1}`);
        }
        const s = this.root[n];
        ((n += 1), (r += (s && s.options.columnSpan) || 1));
      }
      return n - 1;
    }
  },
  Py = class ki extends Or {
    constructor({
      rows: t,
      width: r,
      columnWidths: n,
      columnWidthsRevision: s,
      margins: a,
      indent: o,
      float: i,
      layout: l,
      style: c,
      borders: u,
      alignment: d,
      visuallyRightToLeft: h,
      tableLook: w,
      cellSpacing: m,
      revision: v,
    }) {
      (super("w:tbl"),
        p(this, "rows", void 0),
        p(this, "width", void 0),
        p(this, "columnWidths", void 0),
        p(this, "columnWidthsRevision", void 0),
        p(this, "resolvedColumnWidths", void 0),
        (this.rows = t),
        (this.width = r ?? { size: 100 }),
        (this.columnWidths = n),
        (this.columnWidthsRevision = s),
        t.forEach((g, A) => {
          if (A === t.length - 1) return;
          let I = 0;
          g.cells.forEach((b) => {
            if (b.options.rowSpan && b.options.rowSpan > 1) {
              const R = b.options.children[b.options.children.length - 1],
                O = new Zs({
                  rowSpan: b.options.rowSpan - 1,
                  columnSpan: b.options.columnSpan,
                  width: b.options.width,
                  borders: b.options.borders,
                  shading: b.options.shading,
                  margins: b.options.margins,
                  textDirection: b.options.textDirection,
                  verticalAlign: b.options.verticalAlign,
                  children: R instanceof me ? [new me(R.Alignment)] : [],
                  verticalMerge: Si.CONTINUE,
                });
              t[A + 1].addCellToColumnIndex(O, I);
            }
            I += b.options.columnSpan || 1;
          });
        }),
        this.setCellWidths(cr),
        (this.resolvedColumnWidths =
          n ?? Ys({ rows: t, width: this.width, availableWidth: cr })),
        this.root.push(
          new vs({
            borders: c ? u : (u ?? {}),
            width: this.width,
            indent: o,
            float: i,
            layout: l,
            style: c,
            alignment: d,
            cellMargin: a,
            visuallyRightToLeft: h,
            tableLook: w,
            cellSpacing: m,
            revision: v,
          }),
        ),
        this.root.push(new ur(this.resolvedColumnWidths, s)));
      for (const g of t) this.root.push(g);
    }
    get ColumnWidths() {
      return this.resolvedColumnWidths;
    }
    getCellWidth(t, r) {
      const { cells: n } = t,
        s = n.indexOf(r);
      if (s === -1) return;
      const a = n
          .slice(0, s)
          .reduce((i, l) => i + (l.options.columnSpan || 1), 0),
        o = this.resolvedColumnWidths.slice(a, a + (r.options.columnSpan || 1));
      return o.length === 0 ? void 0 : o.reduce((i, l) => i + l, 0);
    }
    prepForXml(t) {
      if (
        (this.setCellWidths(this.resolveAvailableWidth(t)),
        this.columnWidths === void 0)
      ) {
        this.resolvedColumnWidths = Ys({
          rows: this.rows,
          width: this.width,
          availableWidth: this.resolveAvailableWidth(t),
        });
        const r = this.root.findIndex((n) => n instanceof ur);
        this.root[r] = new ur(
          this.resolvedColumnWidths,
          this.columnWidthsRevision,
        );
      }
      return super.prepForXml(t);
    }
    setCellWidths(t) {
      var r;
      if (this.columnWidths === void 0) return;
      const n = this.columnWidths.reduce((o, i) => o + i, 0),
        s = (r = ps(this.width, t)) !== null && r !== void 0 ? r : 0,
        a = n > 0 && s > n ? s / n : 1;
      for (const o of this.rows) {
        let i = 0;
        for (const l of o.cells) {
          const c = l.options.columnSpan || 1,
            u = this.columnWidths.slice(i, i + c),
            d = Math.round(u.reduce((h, w) => h + w, 0) * a);
          (u.length === c && d > 0 && l.setColumnWidth(d), (i += c));
        }
      }
    }
    resolveAvailableWidth(t) {
      var r, n, s;
      const { stack: a } = t,
        o = a[a.length - 1],
        i = a[a.length - 2],
        l = a[a.length - 3];
      if (o instanceof Zs && i instanceof hp && l instanceof ki) {
        const h = l.getCellWidth(i, o);
        if (h !== void 0) return h;
      }
      const c = a.findIndex((h) => h instanceof bi),
        u =
          (r = t.file) === null ||
          r === void 0 ||
          (r = r.Document) === null ||
          r === void 0
            ? void 0
            : r.View.Body,
        d =
          c >= 0
            ? a[c].getSectionPropertiesFor(
                (n = a[c + 1]) !== null && n !== void 0 ? n : this,
              )
            : u?.getSectionPropertiesFor();
      return (s = d?.AvailableTextWidth) !== null && s !== void 0 ? s : cr;
    }
  },
  mp = class extends _ {
    constructor(...e) {
      (super(...e), p(this, "xmlKeys", { xmlns: "xmlns", vt: "xmlns:vt" }));
    }
  },
  pp = class extends y {
    constructor() {
      (super("Properties"),
        this.root.push(
          new mp({
            xmlns:
              "http://schemas.openxmlformats.org/officeDocument/2006/extended-properties",
            vt: "http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes",
          }),
        ));
    }
  },
  vp = class extends _ {
    constructor(...e) {
      (super(...e), p(this, "xmlKeys", { xmlns: "xmlns" }));
    }
  },
  Ge = (e, t) =>
    new x({
      name: "Default",
      attributes: {
        contentType: { key: "ContentType", value: e },
        extension: { key: "Extension", value: t },
      },
    }),
  ne = (e, t) =>
    new x({
      name: "Override",
      attributes: {
        contentType: { key: "ContentType", value: e },
        partName: { key: "PartName", value: t },
      },
    }),
  fp = class extends y {
    constructor({ macros: e = !1 } = {}) {
      (super("Types"),
        this.root.push(
          new vp({
            xmlns:
              "http://schemas.openxmlformats.org/package/2006/content-types",
          }),
        ),
        this.root.push(Ge("image/png", "png")),
        this.root.push(Ge("image/jpeg", "jpeg")),
        this.root.push(Ge("image/jpeg", "jpg")),
        this.root.push(Ge("image/bmp", "bmp")),
        this.root.push(Ge("image/gif", "gif")),
        this.root.push(Ge("image/svg+xml", "svg")),
        this.root.push(
          Ge(
            "application/vnd.openxmlformats-package.relationships+xml",
            "rels",
          ),
        ),
        this.root.push(Ge("application/xml", "xml")),
        this.root.push(
          Ge(
            "application/vnd.openxmlformats-officedocument.obfuscatedFont",
            "odttf",
          ),
        ),
        this.root.push(
          ne(
            e
              ? "application/vnd.ms-word.document.macroEnabled.main+xml"
              : "application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml",
            "/word/document.xml",
          ),
        ),
        this.root.push(
          ne(
            "application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml",
            "/word/styles.xml",
          ),
        ),
        this.root.push(
          ne(
            "application/vnd.openxmlformats-package.core-properties+xml",
            "/docProps/core.xml",
          ),
        ),
        this.root.push(
          ne(
            "application/vnd.openxmlformats-officedocument.custom-properties+xml",
            "/docProps/custom.xml",
          ),
        ),
        this.root.push(
          ne(
            "application/vnd.openxmlformats-officedocument.extended-properties+xml",
            "/docProps/app.xml",
          ),
        ),
        this.root.push(
          ne(
            "application/vnd.openxmlformats-officedocument.wordprocessingml.numbering+xml",
            "/word/numbering.xml",
          ),
        ),
        this.root.push(
          ne(
            "application/vnd.openxmlformats-officedocument.wordprocessingml.footnotes+xml",
            "/word/footnotes.xml",
          ),
        ),
        this.root.push(
          ne(
            "application/vnd.openxmlformats-officedocument.wordprocessingml.endnotes+xml",
            "/word/endnotes.xml",
          ),
        ),
        this.root.push(
          ne(
            "application/vnd.openxmlformats-officedocument.wordprocessingml.settings+xml",
            "/word/settings.xml",
          ),
        ),
        this.root.push(
          ne(
            "application/vnd.openxmlformats-officedocument.wordprocessingml.fontTable+xml",
            "/word/fontTable.xml",
          ),
        ),
        this.root.push(
          ne(
            "application/vnd.openxmlformats-officedocument.theme+xml",
            "/word/theme/theme1.xml",
          ),
        ),
        e &&
          this.root.push(
            ne("application/vnd.ms-office.vbaProject", "/word/vbaProject.bin"),
          ));
    }
    addComments() {
      this.root.push(
        ne(
          "application/vnd.openxmlformats-officedocument.wordprocessingml.comments+xml",
          "/word/comments.xml",
        ),
      );
    }
    addCommentsExtended() {
      this.root.push(
        ne(
          "application/vnd.openxmlformats-officedocument.wordprocessingml.commentsExtended+xml",
          "/word/commentsExtended.xml",
        ),
      );
    }
    addCommentsIds() {
      this.root.push(
        ne(
          "application/vnd.openxmlformats-officedocument.wordprocessingml.commentsIds+xml",
          "/word/commentsIds.xml",
        ),
      );
    }
    addFooter(e) {
      this.root.push(
        ne(
          "application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml",
          `/word/footer${e}.xml`,
        ),
      );
    }
    addOverride(e, t) {
      this.root.push(ne(e, t));
    }
    addHeader(e) {
      this.root.push(
        ne(
          "application/vnd.openxmlformats-officedocument.wordprocessingml.header+xml",
          `/word/header${e}.xml`,
        ),
      );
    }
  },
  Pn = {
    wpc: "http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas",
    mc: "http://schemas.openxmlformats.org/markup-compatibility/2006",
    o: "urn:schemas-microsoft-com:office:office",
    r: "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
    m: "http://schemas.openxmlformats.org/officeDocument/2006/math",
    v: "urn:schemas-microsoft-com:vml",
    wp14: "http://schemas.microsoft.com/office/word/2010/wordprocessingDrawing",
    wp: "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing",
    w10: "urn:schemas-microsoft-com:office:word",
    w: "http://schemas.openxmlformats.org/wordprocessingml/2006/main",
    w14: "http://schemas.microsoft.com/office/word/2010/wordml",
    w15: "http://schemas.microsoft.com/office/word/2012/wordml",
    wpg: "http://schemas.microsoft.com/office/word/2010/wordprocessingGroup",
    wpi: "http://schemas.microsoft.com/office/word/2010/wordprocessingInk",
    wne: "http://schemas.microsoft.com/office/word/2006/wordml",
    wps: "http://schemas.microsoft.com/office/word/2010/wordprocessingShape",
    cp: "http://schemas.openxmlformats.org/package/2006/metadata/core-properties",
    dc: "http://purl.org/dc/elements/1.1/",
    dcterms: "http://purl.org/dc/terms/",
    dcmitype: "http://purl.org/dc/dcmitype/",
    xsi: "http://www.w3.org/2001/XMLSchema-instance",
    cx: "http://schemas.microsoft.com/office/drawing/2014/chartex",
    cx1: "http://schemas.microsoft.com/office/drawing/2015/9/8/chartex",
    cx2: "http://schemas.microsoft.com/office/drawing/2015/10/21/chartex",
    cx3: "http://schemas.microsoft.com/office/drawing/2016/5/9/chartex",
    cx4: "http://schemas.microsoft.com/office/drawing/2016/5/10/chartex",
    cx5: "http://schemas.microsoft.com/office/drawing/2016/5/11/chartex",
    cx6: "http://schemas.microsoft.com/office/drawing/2016/5/12/chartex",
    cx7: "http://schemas.microsoft.com/office/drawing/2016/5/13/chartex",
    cx8: "http://schemas.microsoft.com/office/drawing/2016/5/14/chartex",
    aink: "http://schemas.microsoft.com/office/drawing/2016/ink",
    am3d: "http://schemas.microsoft.com/office/drawing/2017/model3d",
    w16cex: "http://schemas.microsoft.com/office/word/2018/wordml/cex",
    w16cid: "http://schemas.microsoft.com/office/word/2016/wordml/cid",
    w16: "http://schemas.microsoft.com/office/word/2018/wordml",
    w16sdtdh:
      "http://schemas.microsoft.com/office/word/2020/wordml/sdtdatahash",
    w16se: "http://schemas.microsoft.com/office/word/2015/wordml/symex",
  },
  Lr = class extends _ {
    constructor(e, t) {
      (super(f({ Ignorable: t }, Object.fromEntries(e.map((r) => [r, Pn[r]])))),
        p(
          this,
          "xmlKeys",
          f(
            { Ignorable: "mc:Ignorable" },
            Object.fromEntries(Object.keys(Pn).map((r) => [r, `xmlns:${r}`])),
          ),
        ));
    }
  },
  wp = class extends y {
    constructor(e) {
      (super("cp:coreProperties"),
        this.root.push(new Lr(["cp", "dc", "dcterms", "dcmitype", "xsi"])),
        e.title && this.root.push(new lt("dc:title", e.title)),
        e.subject && this.root.push(new lt("dc:subject", e.subject)),
        e.creator && this.root.push(new lt("dc:creator", e.creator)),
        e.keywords && this.root.push(new lt("cp:keywords", e.keywords)),
        e.description &&
          this.root.push(new lt("dc:description", e.description)),
        e.lastModifiedBy &&
          this.root.push(new lt("cp:lastModifiedBy", e.lastModifiedBy)),
        e.revision && this.root.push(new lt("cp:revision", String(e.revision))),
        this.root.push(new Qs("dcterms:created")),
        this.root.push(new Qs("dcterms:modified")));
    }
  },
  gp = class extends _ {
    constructor(...e) {
      (super(...e), p(this, "xmlKeys", { type: "xsi:type" }));
    }
  },
  Qs = class extends y {
    constructor(e) {
      (super(e),
        this.root.push(new gp({ type: "dcterms:W3CDTF" })),
        this.root.push(uc(new Date())));
    }
  },
  yp = class extends _ {
    constructor(...e) {
      (super(...e), p(this, "xmlKeys", { xmlns: "xmlns", vt: "xmlns:vt" }));
    }
  },
  xp = class extends _ {
    constructor(...e) {
      (super(...e),
        p(this, "xmlKeys", { formatId: "fmtid", pid: "pid", name: "name" }));
    }
  },
  bp = class extends y {
    constructor(e, t) {
      (super("property"),
        this.root.push(
          new xp({
            formatId: "{D5CDD505-2E9C-101B-9397-08002B2CF9AE}",
            pid: e.toString(),
            name: t.name,
          }),
        ),
        this.root.push(new Tp(t.value)));
    }
  },
  Tp = class extends y {
    constructor(e) {
      (super("vt:lpwstr"), this.root.push(e));
    }
  },
  Ep = class extends y {
    constructor(e) {
      (super("Properties"),
        p(this, "nextId", void 0),
        p(this, "properties", []),
        this.root.push(
          new yp({
            xmlns:
              "http://schemas.openxmlformats.org/officeDocument/2006/custom-properties",
            vt: "http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes",
          }),
        ),
        (this.nextId = 2));
      for (const t of e) this.addCustomProperty(t);
    }
    prepForXml(e) {
      return (
        this.root.splice(1, this.root.length - 1, ...this.properties),
        super.prepForXml(e)
      );
    }
    addCustomProperty(e) {
      this.properties.push(new bp(this.nextId++, e));
    }
  },
  Sp = class extends _ {
    constructor(...e) {
      (super(...e), p(this, "xmlKeys", { width: "w:w", space: "w:space" }));
    }
  },
  Oy = class extends y {
    constructor(e) {
      (super("w:col"),
        this.root.push(
          new Sp({
            width: ee(e.width),
            space: e.space === void 0 ? void 0 : ee(e.space),
          }),
        ));
    }
  },
  Ap = (e) =>
    new x({
      name: "ds:datastoreItem",
      attributes: {
        itemId: { key: "ds:itemID", value: e },
        namespace: {
          key: "xmlns:ds",
          value:
            "http://schemas.openxmlformats.org/officeDocument/2006/customXml",
        },
      },
      children: [
        new x({
          name: "ds:schemaRefs",
          children: [
            new x({
              name: "ds:schemaRef",
              attributes: {
                uri: {
                  key: "ds:uri",
                  value:
                    "http://schemas.openxmlformats.org/officeDocument/2006/bibliography",
                },
              },
            }),
          ],
        }),
      ],
    }),
  Ip = {
    new: "wne:eventDocNew",
    open: "wne:eventDocOpen",
    close: "wne:eventDocClose",
    sync: "wne:eventDocSync",
    xmlAfterInsert: "wne:eventDocXmlAfterInsert",
    xmlBeforeDelete: "wne:eventDocXmlBeforeDelete",
    contentControlAfterAdd: "wne:eventDocContentControlAfterInsert",
    contentControlBeforeDelete: "wne:eventDocContentControlBeforeDelete",
    contentControlOnExit: "wne:eventDocContentControlOnExit",
    contentControlOnEnter: "wne:eventDocContentControlOnEnter",
    contentControlBeforeStoreUpdate: "wne:eventDocStoreUpdate",
    contentControlBeforeContentUpdate:
      "wne:eventDocContentControlContentUpdate",
    buildingBlockInsert: "wne:eventDocBuildingBlockAfterInsert",
  },
  Cp = (e) =>
    new x({
      name: "wne:vbaSuppData",
      attributes: {
        namespace: {
          key: "xmlns:wne",
          value: "http://schemas.microsoft.com/office/word/2006/wordml",
        },
      },
      children: [
        new x({
          name: "wne:docEvents",
          children: Object.entries(Ip)
            .filter(([t]) => e.includes(t))
            .map(([, t]) => new x({ name: t })),
        }),
      ],
    }),
  _y = class extends _ {
    constructor(...e) {
      (super(...e),
        p(this, "xmlKeys", {
          color: "w:color",
          themeColor: "w:themeColor",
          themeShade: "w:themeShade",
          themeTint: "w:themeTint",
        }));
    }
  },
  Np = class extends y {
    constructor({ color: e, themeColor: t, themeShade: r, themeTint: n }) {
      if (
        (super("w:background"),
        typeof e == "object" && (t !== void 0 || r !== void 0 || n !== void 0))
      )
        throw new Error(
          "Invalid background. Expected a theme color in color, or themeColor, themeShade and themeTint, not both",
        );
      this.root.push(
        new Zn([
          { keys: Vt, color: e },
          { key: "w:themeColor", value: t },
          { key: "w:themeShade", value: r === void 0 ? void 0 : Ps(r) },
          { key: "w:themeTint", value: n === void 0 ? void 0 : Ps(n) },
        ]),
      );
    }
  },
  kp = class extends y {
    constructor(e) {
      (super("w:document"),
        p(this, "body", void 0),
        this.root.push(
          new Lr(
            [
              "wpc",
              "mc",
              "o",
              "r",
              "m",
              "v",
              "wp14",
              "wp",
              "w10",
              "w",
              "w14",
              "w15",
              "wpg",
              "wpi",
              "wne",
              "wps",
              "cx",
              "cx1",
              "cx2",
              "cx3",
              "cx4",
              "cx5",
              "cx6",
              "cx7",
              "cx8",
              "aink",
              "am3d",
              "w16cex",
              "w16cid",
              "w16",
              "w16sdtdh",
              "w16se",
            ],
            "w14 w15 wp14",
          ),
        ),
        (this.body = new bi({ pageNumbers: e.pageNumbers })),
        e.background && this.root.push(new Np(e.background)),
        this.root.push(this.body));
    }
    add(e) {
      return (this.body.push(e), this);
    }
    get Body() {
      return this.body;
    }
  },
  Rp = class {
    constructor(e) {
      (p(this, "document", void 0),
        p(this, "relationships", void 0),
        (this.document = new kp(e)),
        (this.relationships = new se()));
    }
    get View() {
      return this.document;
    }
    get Relationships() {
      return this.relationships;
    }
  },
  Pp = class extends _ {
    constructor(...e) {
      (super(...e),
        p(this, "xmlKeys", {
          wpc: "xmlns:wpc",
          mc: "xmlns:mc",
          o: "xmlns:o",
          r: "xmlns:r",
          m: "xmlns:m",
          v: "xmlns:v",
          wp14: "xmlns:wp14",
          wp: "xmlns:wp",
          w10: "xmlns:w10",
          w: "xmlns:w",
          w14: "xmlns:w14",
          w15: "xmlns:w15",
          wpg: "xmlns:wpg",
          wpi: "xmlns:wpi",
          wne: "xmlns:wne",
          wps: "xmlns:wps",
          Ignorable: "mc:Ignorable",
        }));
    }
  },
  Ri = class extends y {
    constructor(e, t) {
      (super("w:p"),
        p(this, "paragraph", void 0),
        p(this, "mark", void 0),
        (this.paragraph = e),
        (this.mark = t));
    }
    prepForXml(e) {
      const t = this.paragraph.prepForXml(e)["w:p"],
        r = Array.isArray(t) ? t : [],
        n = r.length > 0 && "w:pPr" in r[0] ? 1 : 0;
      return {
        "w:p": [...r.slice(0, n), this.mark.prepForXml(e), ...r.slice(n)],
      };
    }
  },
  Op = class extends _ {
    constructor(...e) {
      (super(...e), p(this, "xmlKeys", { type: "w:type", id: "w:id" }));
    }
  },
  Pi = class extends te {
    constructor() {
      (super({ style: "EndnoteReference" }), this.root.push(new bh()));
    }
  },
  ea = {
    SEPARATOR: "separator",
    CONTINUATION_SEPARATOR: "continuationSeparator",
  },
  Zr = class extends y {
    constructor(e) {
      (super("w:endnote"), this.root.push(new Op({ type: e.type, id: e.id })));
      for (const [t, r] of e.children.entries())
        this.root.push(t === 0 ? new Ri(r, new Pi()) : r);
    }
  },
  _p = class extends y {
    constructor() {
      super("w:continuationSeparator");
    }
  },
  Oi = class extends te {
    constructor() {
      (super({}), this.root.push(new _p()));
    }
  },
  Lp = class extends y {
    constructor() {
      super("w:separator");
    }
  },
  _i = class extends te {
    constructor() {
      (super({}), this.root.push(new Lp()));
    }
  },
  Li = class extends y {
    constructor() {
      (super("w:endnotes"),
        p(this, "ownNotes", new Map()),
        p(this, "highestId", 0),
        this.root.push(
          new Pp({
            wpc: "http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas",
            mc: "http://schemas.openxmlformats.org/markup-compatibility/2006",
            o: "urn:schemas-microsoft-com:office:office",
            r: "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
            m: "http://schemas.openxmlformats.org/officeDocument/2006/math",
            v: "urn:schemas-microsoft-com:vml",
            wp14: "http://schemas.microsoft.com/office/word/2010/wordprocessingDrawing",
            wp: "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing",
            w10: "urn:schemas-microsoft-com:office:word",
            w: "http://schemas.openxmlformats.org/wordprocessingml/2006/main",
            w14: "http://schemas.microsoft.com/office/word/2010/wordml",
            w15: "http://schemas.microsoft.com/office/word/2012/wordml",
            wpg: "http://schemas.microsoft.com/office/word/2010/wordprocessingGroup",
            wpi: "http://schemas.microsoft.com/office/word/2010/wordprocessingInk",
            wne: "http://schemas.microsoft.com/office/word/2006/wordml",
            wps: "http://schemas.microsoft.com/office/word/2010/wordprocessingShape",
            Ignorable: "w14 w15 wp14",
          }),
        ));
      const e = new Zr({
        id: -1,
        type: ea.SEPARATOR,
        children: [
          new me({
            spacing: { after: 0, line: 240, lineRule: xt.AUTO },
            children: [new _i()],
          }),
        ],
      });
      this.root.push(e);
      const t = new Zr({
        id: 0,
        type: ea.CONTINUATION_SEPARATOR,
        children: [
          new me({
            spacing: { after: 0, line: 240, lineRule: xt.AUTO },
            children: [new Oi()],
          }),
        ],
      });
      this.root.push(t);
    }
    createEndnote(e, t) {
      const r = new Zr({ id: e, children: t });
      (this.root.push(r),
        Number.isFinite(e) &&
          (this.highestId = Math.max(this.highestId, Math.floor(e))));
    }
    idOf(e, t, r) {
      if (r.viewWrapper !== r.file.Document) return;
      const n = this.ownNotes.get(e);
      if (n !== void 0) return n;
      const s = this.highestId + 1;
      return (this.createEndnote(s, t.children), this.ownNotes.set(e, s), s);
    }
    prepForXml(e) {
      const t = super.prepForXml(e);
      return (Xt(t, e), t);
    }
  },
  Dp = class {
    constructor() {
      (p(this, "endnotes", void 0),
        p(this, "relationships", void 0),
        (this.endnotes = new Li()),
        (this.relationships = new se()));
    }
    get View() {
      return this.endnotes;
    }
    get Relationships() {
      return this.relationships;
    }
  },
  Mp = class extends _ {
    constructor(...e) {
      (super(...e),
        p(this, "xmlKeys", {
          wpc: "xmlns:wpc",
          mc: "xmlns:mc",
          o: "xmlns:o",
          r: "xmlns:r",
          m: "xmlns:m",
          v: "xmlns:v",
          wp14: "xmlns:wp14",
          wp: "xmlns:wp",
          w10: "xmlns:w10",
          w: "xmlns:w",
          w14: "xmlns:w14",
          w15: "xmlns:w15",
          wpg: "xmlns:wpg",
          wpi: "xmlns:wpi",
          wne: "xmlns:wne",
          wps: "xmlns:wps",
          cp: "xmlns:cp",
          dc: "xmlns:dc",
          dcterms: "xmlns:dcterms",
          dcmitype: "xmlns:dcmitype",
          xsi: "xmlns:xsi",
          type: "xsi:type",
        }));
    }
  },
  Fp = class extends no {
    constructor(e, t) {
      (super("w:ftr", t),
        p(this, "refId", void 0),
        (this.refId = e),
        t ||
          this.root.push(
            new Mp({
              wpc: "http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas",
              mc: "http://schemas.openxmlformats.org/markup-compatibility/2006",
              o: "urn:schemas-microsoft-com:office:office",
              r: "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
              m: "http://schemas.openxmlformats.org/officeDocument/2006/math",
              v: "urn:schemas-microsoft-com:vml",
              wp14: "http://schemas.microsoft.com/office/word/2010/wordprocessingDrawing",
              wp: "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing",
              w10: "urn:schemas-microsoft-com:office:word",
              w: "http://schemas.openxmlformats.org/wordprocessingml/2006/main",
              w14: "http://schemas.microsoft.com/office/word/2010/wordml",
              w15: "http://schemas.microsoft.com/office/word/2012/wordml",
              wpg: "http://schemas.microsoft.com/office/word/2010/wordprocessingGroup",
              wpi: "http://schemas.microsoft.com/office/word/2010/wordprocessingInk",
              wne: "http://schemas.microsoft.com/office/word/2006/wordml",
              wps: "http://schemas.microsoft.com/office/word/2010/wordprocessingShape",
            }),
          ));
    }
    get ReferenceId() {
      return this.refId;
    }
    add(e) {
      this.root.push(e);
    }
    prepForXml(e) {
      const t = super.prepForXml(e);
      return (Xt(t, e, this.refId), t);
    }
  },
  $p = class {
    constructor(e, t, r) {
      (p(this, "media", void 0),
        p(this, "footer", void 0),
        p(this, "relationships", void 0),
        (this.media = e),
        (this.footer = new Fp(t, r)),
        (this.relationships = new se()));
    }
    add(e) {
      this.footer.add(e);
    }
    addChildElement(e) {
      this.footer.addChildElement(e);
    }
    get View() {
      return this.footer;
    }
    get Relationships() {
      return this.relationships;
    }
    get Media() {
      return this.media;
    }
  },
  Hp = class extends _ {
    constructor(...e) {
      (super(...e), p(this, "xmlKeys", { type: "w:type", id: "w:id" }));
    }
  },
  Bp = class extends y {
    constructor() {
      super("w:footnoteRef");
    }
  },
  Di = class extends te {
    constructor() {
      (super({ style: "FootnoteReference" }), this.root.push(new Bp()));
    }
  },
  ta = {
    SEPERATOR: "separator",
    CONTINUATION_SEPERATOR: "continuationSeparator",
  },
  Qr = class extends y {
    constructor(e) {
      (super("w:footnote"), this.root.push(new Hp({ type: e.type, id: e.id })));
      for (const [t, r] of e.children.entries())
        this.root.push(t === 0 ? new Ri(r, new Di()) : r);
    }
  },
  Wp = class extends _ {
    constructor(...e) {
      (super(...e),
        p(this, "xmlKeys", {
          wpc: "xmlns:wpc",
          mc: "xmlns:mc",
          o: "xmlns:o",
          r: "xmlns:r",
          m: "xmlns:m",
          v: "xmlns:v",
          wp14: "xmlns:wp14",
          wp: "xmlns:wp",
          w10: "xmlns:w10",
          w: "xmlns:w",
          w14: "xmlns:w14",
          w15: "xmlns:w15",
          wpg: "xmlns:wpg",
          wpi: "xmlns:wpi",
          wne: "xmlns:wne",
          wps: "xmlns:wps",
          Ignorable: "mc:Ignorable",
        }));
    }
  },
  Mi = class extends y {
    constructor() {
      (super("w:footnotes"),
        p(this, "ownNotes", new Map()),
        p(this, "highestId", 0),
        this.root.push(
          new Wp({
            wpc: "http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas",
            mc: "http://schemas.openxmlformats.org/markup-compatibility/2006",
            o: "urn:schemas-microsoft-com:office:office",
            r: "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
            m: "http://schemas.openxmlformats.org/officeDocument/2006/math",
            v: "urn:schemas-microsoft-com:vml",
            wp14: "http://schemas.microsoft.com/office/word/2010/wordprocessingDrawing",
            wp: "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing",
            w10: "urn:schemas-microsoft-com:office:word",
            w: "http://schemas.openxmlformats.org/wordprocessingml/2006/main",
            w14: "http://schemas.microsoft.com/office/word/2010/wordml",
            w15: "http://schemas.microsoft.com/office/word/2012/wordml",
            wpg: "http://schemas.microsoft.com/office/word/2010/wordprocessingGroup",
            wpi: "http://schemas.microsoft.com/office/word/2010/wordprocessingInk",
            wne: "http://schemas.microsoft.com/office/word/2006/wordml",
            wps: "http://schemas.microsoft.com/office/word/2010/wordprocessingShape",
            Ignorable: "w14 w15 wp14",
          }),
        ));
      const e = new Qr({
        id: -1,
        type: ta.SEPERATOR,
        children: [
          new me({
            spacing: { after: 0, line: 240, lineRule: xt.AUTO },
            children: [new _i()],
          }),
        ],
      });
      this.root.push(e);
      const t = new Qr({
        id: 0,
        type: ta.CONTINUATION_SEPERATOR,
        children: [
          new me({
            spacing: { after: 0, line: 240, lineRule: xt.AUTO },
            children: [new Oi()],
          }),
        ],
      });
      this.root.push(t);
    }
    createFootNote(e, t) {
      const r = new Qr({ id: e, children: t });
      (this.root.push(r),
        Number.isFinite(e) &&
          (this.highestId = Math.max(this.highestId, Math.floor(e))));
    }
    idOf(e, t, r) {
      if (r.viewWrapper !== r.file.Document) return;
      const n = this.ownNotes.get(e);
      if (n !== void 0) return n;
      const s = this.highestId + 1;
      return (this.createFootNote(s, t.children), this.ownNotes.set(e, s), s);
    }
    prepForXml(e) {
      const t = super.prepForXml(e);
      return (Xt(t, e), t);
    }
  },
  Up = class {
    constructor() {
      (p(this, "footnotess", void 0),
        p(this, "relationships", void 0),
        (this.footnotess = new Mi()),
        (this.relationships = new se()));
    }
    get View() {
      return this.footnotess;
    }
    get Relationships() {
      return this.relationships;
    }
  },
  Gp = class extends _ {
    constructor(...e) {
      (super(...e),
        p(this, "xmlKeys", {
          wpc: "xmlns:wpc",
          mc: "xmlns:mc",
          o: "xmlns:o",
          r: "xmlns:r",
          m: "xmlns:m",
          v: "xmlns:v",
          wp14: "xmlns:wp14",
          wp: "xmlns:wp",
          w10: "xmlns:w10",
          w: "xmlns:w",
          w14: "xmlns:w14",
          w15: "xmlns:w15",
          wpg: "xmlns:wpg",
          wpi: "xmlns:wpi",
          wne: "xmlns:wne",
          wps: "xmlns:wps",
          cp: "xmlns:cp",
          dc: "xmlns:dc",
          dcterms: "xmlns:dcterms",
          dcmitype: "xmlns:dcmitype",
          xsi: "xmlns:xsi",
          type: "xsi:type",
          cx: "xmlns:cx",
          cx1: "xmlns:cx1",
          cx2: "xmlns:cx2",
          cx3: "xmlns:cx3",
          cx4: "xmlns:cx4",
          cx5: "xmlns:cx5",
          cx6: "xmlns:cx6",
          cx7: "xmlns:cx7",
          cx8: "xmlns:cx8",
          w16cid: "xmlns:w16cid",
          w16se: "xmlns:w16se",
        }));
    }
  },
  jp = class extends no {
    constructor(e, t) {
      (super("w:hdr", t),
        p(this, "refId", void 0),
        (this.refId = e),
        t ||
          this.root.push(
            new Gp({
              wpc: "http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas",
              mc: "http://schemas.openxmlformats.org/markup-compatibility/2006",
              o: "urn:schemas-microsoft-com:office:office",
              r: "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
              m: "http://schemas.openxmlformats.org/officeDocument/2006/math",
              v: "urn:schemas-microsoft-com:vml",
              wp14: "http://schemas.microsoft.com/office/word/2010/wordprocessingDrawing",
              wp: "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing",
              w10: "urn:schemas-microsoft-com:office:word",
              w: "http://schemas.openxmlformats.org/wordprocessingml/2006/main",
              w14: "http://schemas.microsoft.com/office/word/2010/wordml",
              w15: "http://schemas.microsoft.com/office/word/2012/wordml",
              wpg: "http://schemas.microsoft.com/office/word/2010/wordprocessingGroup",
              wpi: "http://schemas.microsoft.com/office/word/2010/wordprocessingInk",
              wne: "http://schemas.microsoft.com/office/word/2006/wordml",
              wps: "http://schemas.microsoft.com/office/word/2010/wordprocessingShape",
              cx: "http://schemas.microsoft.com/office/drawing/2014/chartex",
              cx1: "http://schemas.microsoft.com/office/drawing/2015/9/8/chartex",
              cx2: "http://schemas.microsoft.com/office/drawing/2015/10/21/chartex",
              cx3: "http://schemas.microsoft.com/office/drawing/2016/5/9/chartex",
              cx4: "http://schemas.microsoft.com/office/drawing/2016/5/10/chartex",
              cx5: "http://schemas.microsoft.com/office/drawing/2016/5/11/chartex",
              cx6: "http://schemas.microsoft.com/office/drawing/2016/5/12/chartex",
              cx7: "http://schemas.microsoft.com/office/drawing/2016/5/13/chartex",
              cx8: "http://schemas.microsoft.com/office/drawing/2016/5/14/chartex",
              w16cid:
                "http://schemas.microsoft.com/office/word/2016/wordml/cid",
              w16se:
                "http://schemas.microsoft.com/office/word/2015/wordml/symex",
            }),
          ));
    }
    get ReferenceId() {
      return this.refId;
    }
    add(e) {
      this.root.push(e);
    }
    prepForXml(e) {
      const t = super.prepForXml(e);
      return (Xt(t, e, this.refId), t);
    }
  },
  Vp = class {
    constructor(e, t, r) {
      (p(this, "media", void 0),
        p(this, "header", void 0),
        p(this, "relationships", void 0),
        (this.media = e),
        (this.header = new jp(t, r)),
        (this.relationships = new se()));
    }
    add(e) {
      return (this.header.add(e), this);
    }
    addChildElement(e) {
      this.header.addChildElement(e);
    }
    get View() {
      return this.header;
    }
    get Relationships() {
      return this.relationships;
    }
    get Media() {
      return this.media;
    }
  },
  Xp = () => {
    const e = new Map();
    return (t) => {
      var r;
      const n = ((r = e.get(t)) !== null && r !== void 0 ? r : 0) + 1;
      return (e.set(t, n), `media/image${n}.${t}`);
    };
  },
  Fi = class {
    constructor(e = Xp()) {
      (p(this, "map", new Map()),
        p(this, "takePath", void 0),
        (this.takePath = e));
    }
    addImage(e, t) {
      if (this.map.has(e)) return;
      const r = this.takePath(t.type);
      this.map.set(
        e,
        f(f({}, t), {}, { fileName: r.slice(r.lastIndexOf("/") + 1) }),
      );
    }
    get Array() {
      return Array.from(this.map.values());
    }
    get Entries() {
      return Array.from(this.map.entries());
    }
  },
  je = {
    DECIMAL: "decimal",
    UPPER_ROMAN: "upperRoman",
    LOWER_ROMAN: "lowerRoman",
    UPPER_LETTER: "upperLetter",
    LOWER_LETTER: "lowerLetter",
    ORDINAL: "ordinal",
    CARDINAL_TEXT: "cardinalText",
    ORDINAL_TEXT: "ordinalText",
    HEX: "hex",
    CHICAGO: "chicago",
    IDEOGRAPH__DIGITAL: "ideographDigital",
    JAPANESE_COUNTING: "japaneseCounting",
    AIUEO: "aiueo",
    IROHA: "iroha",
    DECIMAL_FULL_WIDTH: "decimalFullWidth",
    DECIMAL_HALF_WIDTH: "decimalHalfWidth",
    JAPANESE_LEGAL: "japaneseLegal",
    JAPANESE_DIGITAL_TEN_THOUSAND: "japaneseDigitalTenThousand",
    DECIMAL_ENCLOSED_CIRCLE: "decimalEnclosedCircle",
    DECIMAL_FULL_WIDTH2: "decimalFullWidth2",
    AIUEO_FULL_WIDTH: "aiueoFullWidth",
    IROHA_FULL_WIDTH: "irohaFullWidth",
    DECIMAL_ZERO: "decimalZero",
    BULLET: "bullet",
    GANADA: "ganada",
    CHOSUNG: "chosung",
    DECIMAL_ENCLOSED_FULLSTOP: "decimalEnclosedFullstop",
    DECIMAL_ENCLOSED_PARENTHESES: "decimalEnclosedParen",
    DECIMAL_ENCLOSED_CIRCLE_CHINESE: "decimalEnclosedCircleChinese",
    IDEOGRAPH_ENCLOSED_CIRCLE: "ideographEnclosedCircle",
    IDEOGRAPH_TRADITIONAL: "ideographTraditional",
    IDEOGRAPH_ZODIAC: "ideographZodiac",
    IDEOGRAPH_ZODIAC_TRADITIONAL: "ideographZodiacTraditional",
    TAIWANESE_COUNTING: "taiwaneseCounting",
    IDEOGRAPH_LEGAL_TRADITIONAL: "ideographLegalTraditional",
    TAIWANESE_COUNTING_THOUSAND: "taiwaneseCountingThousand",
    TAIWANESE_DIGITAL: "taiwaneseDigital",
    CHINESE_COUNTING: "chineseCounting",
    CHINESE_LEGAL_SIMPLIFIED: "chineseLegalSimplified",
    CHINESE_COUNTING_THOUSAND: "chineseCountingThousand",
    KOREAN_DIGITAL: "koreanDigital",
    KOREAN_COUNTING: "koreanCounting",
    KOREAN_LEGAL: "koreanLegal",
    KOREAN_DIGITAL2: "koreanDigital2",
    VIETNAMESE_COUNTING: "vietnameseCounting",
    RUSSIAN_LOWER: "russianLower",
    RUSSIAN_UPPER: "russianUpper",
    NONE: "none",
    NUMBER_IN_DASH: "numberInDash",
    HEBREW1: "hebrew1",
    HEBREW2: "hebrew2",
    ARABIC_ALPHA: "arabicAlpha",
    ARABIC_ABJAD: "arabicAbjad",
    HINDI_VOWELS: "hindiVowels",
    HINDI_CONSONANTS: "hindiConsonants",
    HINDI_NUMBERS: "hindiNumbers",
    HINDI_COUNTING: "hindiCounting",
    THAI_LETTERS: "thaiLetters",
    THAI_NUMBERS: "thaiNumbers",
    THAI_COUNTING: "thaiCounting",
    BAHT_TEXT: "bahtText",
    DOLLAR_TEXT: "dollarText",
    CUSTOM: "custom",
  },
  Kp = class extends _ {
    constructor(...e) {
      (super(...e),
        p(this, "xmlKeys", { ilvl: "w:ilvl", tentative: "w:tentative" }));
    }
  },
  zp = class extends y {
    constructor(e) {
      (super("w:numFmt"), this.root.push(new pe({ val: e })));
    }
  },
  Yp = class extends y {
    constructor(e) {
      (super("w:lvlText"), this.root.push(new pe({ val: e })));
    }
  },
  qp = (e) => {
    switch (e) {
      case de.CENTER:
        return "center";
      case de.END:
      case de.RIGHT:
        return "right";
      default:
        return "left";
    }
  },
  Jp = class extends y {
    constructor(e) {
      (super("w:lvlJc"), this.root.push(new pe({ val: qp(e) })));
    }
  },
  Ly = { NOTHING: "nothing", SPACE: "space", TAB: "tab" },
  Zp = class extends y {
    constructor(e) {
      (super("w:suff"), this.root.push(new pe({ val: e })));
    }
  },
  Qp = class extends y {
    constructor() {
      super("w:isLgl");
    }
  },
  $i = class extends y {
    constructor({
      level: e,
      format: t,
      text: r,
      alignment: n = de.START,
      start: s = 1,
      style: a,
      suffix: o,
      isLegalNumberingStyle: i,
    }) {
      if (
        (super("w:lvl"),
        p(this, "paragraphProperties", void 0),
        p(this, "runProperties", void 0),
        this.root.push(new Ot("w:start", K(s))),
        t && this.root.push(new zp(t)),
        a?.style && this.root.push(Pt(a.style)),
        i && this.root.push(new Qp()),
        o && this.root.push(new Zp(o)),
        r && this.root.push(new Yp(r)),
        this.root.push(new Jp(n)),
        (this.paragraphProperties = new dt(a && a.paragraph, {
          implicitListParagraphStyle: !1,
          inListOrder: !1,
        })),
        (this.runProperties = new Qe(
          a?.run &&
            f(
              f({}, a.run),
              {},
              { highlight: void 0, math: void 0, revision: void 0 },
            ),
        )),
        this.root.push(this.paragraphProperties),
        this.root.push(this.runProperties),
        e > 9)
      )
        throw new Error(
          "Level cannot be greater than 9. Read more here: https://answers.microsoft.com/en-us/msoffice/forum/all/does-word-support-more-than-9-list-levels/d130fdcd-1781-446d-8c84-c6c79124e4d7",
        );
      this.root.push(new Kp({ ilvl: K(e), tentative: 1 }));
    }
  },
  ev = class extends $i {},
  Dy = class extends $i {},
  tv = class extends y {
    constructor(e) {
      (super("w:multiLevelType"), this.root.push(new pe({ val: e })));
    }
  },
  rv = class extends _ {
    constructor(...e) {
      (super(...e),
        p(this, "xmlKeys", {
          abstractNumId: "w:abstractNumId",
          restartNumberingAfterBreak: "w15:restartNumberingAfterBreak",
        }));
    }
  },
  en = class extends y {
    constructor(e, t) {
      (super("w:abstractNum"),
        p(this, "id", void 0),
        this.root.push(
          new rv({ abstractNumId: K(e), restartNumberingAfterBreak: 0 }),
        ),
        this.root.push(new tv("hybridMultilevel")),
        (this.id = e));
      for (const r of t) this.root.push(new ev(r));
    }
  },
  nv = class extends y {
    constructor(e) {
      (super("w:abstractNumId"), this.root.push(new pe({ val: e })));
    }
  },
  sv = class extends _ {
    constructor(...e) {
      (super(...e), p(this, "xmlKeys", { numId: "w:numId" }));
    }
  },
  ra = class extends y {
    constructor(e) {
      if (
        (super("w:num"),
        p(this, "numId", void 0),
        p(this, "reference", void 0),
        p(this, "instance", void 0),
        p(this, "restartedListId", void 0),
        (this.numId = e.numId),
        (this.reference = e.reference),
        (this.instance = e.instance),
        (this.restartedListId = e.restartedListId),
        this.root.push(new sv({ numId: K(e.numId) })),
        this.root.push(new nv(K(e.abstractNumId))),
        e.overrideLevels && e.overrideLevels.length)
      )
        for (const t of e.overrideLevels)
          this.root.push(new ov(t.num, t.start));
    }
  },
  av = class extends _ {
    constructor(...e) {
      (super(...e), p(this, "xmlKeys", { ilvl: "w:ilvl" }));
    }
  },
  ov = class extends y {
    constructor(e, t) {
      (super("w:lvlOverride"),
        this.root.push(new av({ ilvl: e })),
        t !== void 0 && this.root.push(new lv(t)));
    }
  },
  iv = class extends _ {
    constructor(...e) {
      (super(...e), p(this, "xmlKeys", { val: "w:val" }));
    }
  },
  lv = class extends y {
    constructor(e) {
      (super("w:startOverride"), this.root.push(new iv({ val: e })));
    }
  },
  Hi = class extends y {
    constructor(e) {
      (super("w:numbering"),
        p(this, "abstractNumberingMap", new Map()),
        p(this, "concreteNumberingMap", new Map()),
        p(this, "referenceConfigMap", new Map()),
        p(this, "abstractNumUniqueNumericId", Xc()),
        p(this, "concreteNumUniqueNumericId", Kc()),
        this.root.push(
          new Lr(
            [
              "wpc",
              "mc",
              "o",
              "r",
              "m",
              "v",
              "wp14",
              "wp",
              "w10",
              "w",
              "w14",
              "w15",
              "wpg",
              "wpi",
              "wne",
              "wps",
            ],
            "w14 w15 wp14",
          ),
        ));
      const t = new en(this.abstractNumUniqueNumericId(), [
        {
          level: 0,
          format: je.BULLET,
          text: "●",
          alignment: de.LEFT,
          style: {
            paragraph: { indent: { left: Ne(0.5), hanging: Ne(0.25) } },
          },
        },
        {
          level: 1,
          format: je.BULLET,
          text: "○",
          alignment: de.LEFT,
          style: { paragraph: { indent: { left: Ne(1), hanging: Ne(0.25) } } },
        },
        {
          level: 2,
          format: je.BULLET,
          text: "■",
          alignment: de.LEFT,
          style: { paragraph: { indent: { left: 2160, hanging: Ne(0.25) } } },
        },
        {
          level: 3,
          format: je.BULLET,
          text: "●",
          alignment: de.LEFT,
          style: { paragraph: { indent: { left: 2880, hanging: Ne(0.25) } } },
        },
        {
          level: 4,
          format: je.BULLET,
          text: "○",
          alignment: de.LEFT,
          style: { paragraph: { indent: { left: 3600, hanging: Ne(0.25) } } },
        },
        {
          level: 5,
          format: je.BULLET,
          text: "■",
          alignment: de.LEFT,
          style: { paragraph: { indent: { left: 4320, hanging: Ne(0.25) } } },
        },
        {
          level: 6,
          format: je.BULLET,
          text: "●",
          alignment: de.LEFT,
          style: { paragraph: { indent: { left: 5040, hanging: Ne(0.25) } } },
        },
        {
          level: 7,
          format: je.BULLET,
          text: "●",
          alignment: de.LEFT,
          style: { paragraph: { indent: { left: 5760, hanging: Ne(0.25) } } },
        },
        {
          level: 8,
          format: je.BULLET,
          text: "●",
          alignment: de.LEFT,
          style: { paragraph: { indent: { left: 6480, hanging: Ne(0.25) } } },
        },
      ]);
      (this.concreteNumberingMap.set(
        "default-bullet-numbering",
        new ra({
          numId: 1,
          abstractNumId: t.id,
          reference: "default-bullet-numbering",
          instance: 0,
          overrideLevels: [{ num: 0, start: 1 }],
        }),
      ),
        this.abstractNumberingMap.set("default-bullet-numbering", t));
      for (const r of e.config)
        (this.abstractNumberingMap.set(
          r.reference,
          new en(this.abstractNumUniqueNumericId(), r.levels),
        ),
          this.referenceConfigMap.set(r.reference, r.levels));
    }
    prepForXml(e) {
      return (
        this.root.splice(
          1,
          this.root.length - 1,
          ...this.abstractNumberingMap.values(),
          ...this.concreteNumberingMap.values(),
        ),
        super.prepForXml(e)
      );
    }
    createConcreteNumberingInstance(e, t, r, n) {
      var s;
      r &&
        !this.abstractNumberingMap.has(r.reference) &&
        (this.abstractNumberingMap.set(
          r.reference,
          new en(this.abstractNumUniqueNumericId(), r.levels),
        ),
        this.referenceConfigMap.set(r.reference, r.levels));
      const a = this.abstractNumberingMap.get(e);
      if (!a) return;
      const o = fr(e, t, n);
      if (this.concreteNumberingMap.has(o)) return;
      const i =
          (s = this.referenceConfigMap.get(e)) !== null && s !== void 0
            ? s
            : [{ level: 0 }],
        l = {
          numId: this.concreteNumUniqueNumericId(),
          abstractNumId: a.id,
          reference: e,
          instance: t,
          restartedListId: n,
          overrideLevels: i.map(({ level: c, start: u = 1 }) => ({
            num: c,
            start: K(u),
          })),
        };
      this.concreteNumberingMap.set(o, new ra(l));
    }
    get ConcreteNumbering() {
      return Array.from(this.concreteNumberingMap.values());
    }
    get ReferenceConfig() {
      return Array.from(this.referenceConfigMap.values());
    }
  },
  tn = /^[\w-]+$/,
  cv = new Set(["_rels", "fonts", "theme"]),
  uv = class {
    constructor(e) {
      if (
        (p(this, "options", void 0),
        p(this, "id", at()),
        p(this, "relationshipId", `rId${this.id}`),
        p(this, "addedTo", new WeakSet()),
        (this.options = e),
        !tn.test(e.folder) || cv.has(e.folder))
      )
        throw new Error(
          `Invalid package part folder "${e.folder}". Expected a folder name docx doesn't use, such as "charts"`,
        );
      if (!tn.test(e.name))
        throw new Error(
          `Invalid package part name "${e.name}". Expected letters, digits, "_" and "-", such as "chart"`,
        );
      if (!tn.test(e.extension))
        throw new Error(
          `Invalid package part extension "${e.extension}". Expected letters, digits, "_" and "-", such as "xml"`,
        );
    }
    addTo(e) {
      const t = e.file.PackageParts,
        r = t.add(this),
        n = e.viewWrapper.Relationships;
      this.addedTo.has(n) ||
        (this.addedTo.add(n),
        n.addRelationship(
          this.id,
          this.options.relationshipType,
          t.getTarget(n, r),
        ));
    }
  },
  Bi = class {
    constructor(e, t = new Set()) {
      (p(this, "contentTypes", void 0),
        p(this, "paths", new Map()),
        p(this, "taken", void 0),
        p(this, "folders", new WeakMap()),
        (this.contentTypes = e),
        (this.taken = new Set(t)));
    }
    add(e) {
      const t = this.paths.get(e);
      if (t !== void 0) return t;
      const { folder: r, name: n, extension: s, contentType: a } = e.options,
        o = this.takePath(r, n, s);
      return (
        this.paths.set(e, o),
        this.contentTypes.addOverride(a, `/word/${o}`),
        o
      );
    }
    takePath(e, t, r) {
      let n = 1;
      for (; this.taken.has(`${e}/${t}${n}.${r}`);) n++;
      const s = `${e}/${t}${n}.${r}`;
      return (this.taken.add(s), s);
    }
    get Array() {
      return [...this.paths].map(([e, t]) => ({ part: e, path: t }));
    }
    createRelationships(e) {
      const t = new se();
      return (this.folders.set(t, e.slice(0, e.indexOf("/"))), t);
    }
    getTarget(e, t) {
      const r = this.folders.get(e);
      return r === void 0
        ? t
        : t.startsWith(`${r}/`)
          ? t.slice(r.length + 1)
          : `../${t}`;
    }
  },
  dv = (e) =>
    new x({
      name: "w:compatSetting",
      attributes: {
        version: { key: "w:val", value: e },
        name: { key: "w:name", value: "compatibilityMode" },
        uri: {
          key: "w:uri",
          value: "http://schemas.microsoft.com/office/word",
        },
      },
    }),
  hv = class extends y {
    constructor(e) {
      (super("w:compat"),
        e.useSingleBorderforContiguousCells &&
          this.root.push(
            new N(
              "w:useSingleBorderforContiguousCells",
              e.useSingleBorderforContiguousCells,
            ),
          ),
        e.wordPerfectJustification &&
          this.root.push(
            new N("w:wpJustification", e.wordPerfectJustification),
          ),
        e.noTabStopForHangingIndent &&
          this.root.push(new N("w:noTabHangInd", e.noTabStopForHangingIndent)),
        e.noLeading && this.root.push(new N("w:noLeading", e.noLeading)),
        e.spaceForUnderline &&
          this.root.push(new N("w:spaceForUL", e.spaceForUnderline)),
        e.noColumnBalance &&
          this.root.push(new N("w:noColumnBalance", e.noColumnBalance)),
        e.balanceSingleByteDoubleByteWidth &&
          this.root.push(
            new N(
              "w:balanceSingleByteDoubleByteWidth",
              e.balanceSingleByteDoubleByteWidth,
            ),
          ),
        e.noExtraLineSpacing &&
          this.root.push(new N("w:noExtraLineSpacing", e.noExtraLineSpacing)),
        e.doNotLeaveBackslashAlone &&
          this.root.push(
            new N("w:doNotLeaveBackslashAlone", e.doNotLeaveBackslashAlone),
          ),
        e.underlineTrailingSpaces &&
          this.root.push(new N("w:ulTrailSpace", e.underlineTrailingSpaces)),
        e.doNotExpandShiftReturn &&
          this.root.push(
            new N("w:doNotExpandShiftReturn", e.doNotExpandShiftReturn),
          ),
        e.spacingInWholePoints &&
          this.root.push(
            new N("w:spacingInWholePoints", e.spacingInWholePoints),
          ),
        e.lineWrapLikeWord6 &&
          this.root.push(new N("w:lineWrapLikeWord6", e.lineWrapLikeWord6)),
        e.printBodyTextBeforeHeader &&
          this.root.push(
            new N("w:printBodyTextBeforeHeader", e.printBodyTextBeforeHeader),
          ),
        e.printColorsBlack &&
          this.root.push(new N("w:printColBlack", e.printColorsBlack)),
        e.spaceWidth && this.root.push(new N("w:wpSpaceWidth", e.spaceWidth)),
        e.showBreaksInFrames &&
          this.root.push(new N("w:showBreaksInFrames", e.showBreaksInFrames)),
        e.subFontBySize &&
          this.root.push(new N("w:subFontBySize", e.subFontBySize)),
        e.suppressBottomSpacing &&
          this.root.push(
            new N("w:suppressBottomSpacing", e.suppressBottomSpacing),
          ),
        e.suppressTopSpacing &&
          this.root.push(new N("w:suppressTopSpacing", e.suppressTopSpacing)),
        e.suppressSpacingAtTopOfPage &&
          this.root.push(
            new N("w:suppressSpacingAtTopOfPage", e.suppressSpacingAtTopOfPage),
          ),
        e.suppressTopSpacingWP &&
          this.root.push(
            new N("w:suppressTopSpacingWP", e.suppressTopSpacingWP),
          ),
        e.suppressSpBfAfterPgBrk &&
          this.root.push(
            new N("w:suppressSpBfAfterPgBrk", e.suppressSpBfAfterPgBrk),
          ),
        e.swapBordersFacingPages &&
          this.root.push(
            new N("w:swapBordersFacingPages", e.swapBordersFacingPages),
          ),
        e.convertMailMergeEsc &&
          this.root.push(new N("w:convMailMergeEsc", e.convertMailMergeEsc)),
        e.truncateFontHeightsLikeWP6 &&
          this.root.push(
            new N("w:truncateFontHeightsLikeWP6", e.truncateFontHeightsLikeWP6),
          ),
        e.macWordSmallCaps &&
          this.root.push(new N("w:mwSmallCaps", e.macWordSmallCaps)),
        e.usePrinterMetrics &&
          this.root.push(new N("w:usePrinterMetrics", e.usePrinterMetrics)),
        e.doNotSuppressParagraphBorders &&
          this.root.push(
            new N(
              "w:doNotSuppressParagraphBorders",
              e.doNotSuppressParagraphBorders,
            ),
          ),
        e.wrapTrailSpaces &&
          this.root.push(new N("w:wrapTrailSpaces", e.wrapTrailSpaces)),
        e.footnoteLayoutLikeWW8 &&
          this.root.push(
            new N("w:footnoteLayoutLikeWW8", e.footnoteLayoutLikeWW8),
          ),
        e.shapeLayoutLikeWW8 &&
          this.root.push(new N("w:shapeLayoutLikeWW8", e.shapeLayoutLikeWW8)),
        e.alignTablesRowByRow &&
          this.root.push(new N("w:alignTablesRowByRow", e.alignTablesRowByRow)),
        e.forgetLastTabAlignment &&
          this.root.push(
            new N("w:forgetLastTabAlignment", e.forgetLastTabAlignment),
          ),
        e.adjustLineHeightInTable &&
          this.root.push(
            new N("w:adjustLineHeightInTable", e.adjustLineHeightInTable),
          ),
        e.autoSpaceLikeWord95 &&
          this.root.push(new N("w:autoSpaceLikeWord95", e.autoSpaceLikeWord95)),
        e.noSpaceRaiseLower &&
          this.root.push(new N("w:noSpaceRaiseLower", e.noSpaceRaiseLower)),
        e.doNotUseHTMLParagraphAutoSpacing &&
          this.root.push(
            new N(
              "w:doNotUseHTMLParagraphAutoSpacing",
              e.doNotUseHTMLParagraphAutoSpacing,
            ),
          ),
        e.layoutRawTableWidth &&
          this.root.push(new N("w:layoutRawTableWidth", e.layoutRawTableWidth)),
        e.layoutTableRowsApart &&
          this.root.push(
            new N("w:layoutTableRowsApart", e.layoutTableRowsApart),
          ),
        e.useWord97LineBreakRules &&
          this.root.push(
            new N("w:useWord97LineBreakRules", e.useWord97LineBreakRules),
          ),
        e.doNotBreakWrappedTables &&
          this.root.push(
            new N("w:doNotBreakWrappedTables", e.doNotBreakWrappedTables),
          ),
        e.doNotSnapToGridInCell &&
          this.root.push(
            new N("w:doNotSnapToGridInCell", e.doNotSnapToGridInCell),
          ),
        e.selectFieldWithFirstOrLastCharacter &&
          this.root.push(
            new N(
              "w:selectFldWithFirstOrLastChar",
              e.selectFieldWithFirstOrLastCharacter,
            ),
          ),
        e.applyBreakingRules &&
          this.root.push(new N("w:applyBreakingRules", e.applyBreakingRules)),
        e.doNotWrapTextWithPunctuation &&
          this.root.push(
            new N("w:doNotWrapTextWithPunct", e.doNotWrapTextWithPunctuation),
          ),
        e.doNotUseEastAsianBreakRules &&
          this.root.push(
            new N(
              "w:doNotUseEastAsianBreakRules",
              e.doNotUseEastAsianBreakRules,
            ),
          ),
        e.useWord2002TableStyleRules &&
          this.root.push(
            new N("w:useWord2002TableStyleRules", e.useWord2002TableStyleRules),
          ),
        e.growAutofit && this.root.push(new N("w:growAutofit", e.growAutofit)),
        e.useFELayout && this.root.push(new N("w:useFELayout", e.useFELayout)),
        e.useNormalStyleForList &&
          this.root.push(
            new N("w:useNormalStyleForList", e.useNormalStyleForList),
          ),
        e.doNotUseIndentAsNumberingTabStop &&
          this.root.push(
            new N(
              "w:doNotUseIndentAsNumberingTabStop",
              e.doNotUseIndentAsNumberingTabStop,
            ),
          ),
        e.useAlternateEastAsianLineBreakRules &&
          this.root.push(
            new N(
              "w:useAltKinsokuLineBreakRules",
              e.useAlternateEastAsianLineBreakRules,
            ),
          ),
        e.allowSpaceOfSameStyleInTable &&
          this.root.push(
            new N(
              "w:allowSpaceOfSameStyleInTable",
              e.allowSpaceOfSameStyleInTable,
            ),
          ),
        e.doNotSuppressIndentation &&
          this.root.push(
            new N("w:doNotSuppressIndentation", e.doNotSuppressIndentation),
          ),
        e.doNotAutofitConstrainedTables &&
          this.root.push(
            new N(
              "w:doNotAutofitConstrainedTables",
              e.doNotAutofitConstrainedTables,
            ),
          ),
        e.autofitToFirstFixedWidthCell &&
          this.root.push(
            new N(
              "w:autofitToFirstFixedWidthCell",
              e.autofitToFirstFixedWidthCell,
            ),
          ),
        e.underlineTabInNumberingList &&
          this.root.push(
            new N("w:underlineTabInNumList", e.underlineTabInNumberingList),
          ),
        e.displayHangulFixedWidth &&
          this.root.push(
            new N("w:displayHangulFixedWidth", e.displayHangulFixedWidth),
          ),
        e.splitPgBreakAndParaMark &&
          this.root.push(
            new N("w:splitPgBreakAndParaMark", e.splitPgBreakAndParaMark),
          ),
        e.doNotVerticallyAlignCellWithSp &&
          this.root.push(
            new N(
              "w:doNotVertAlignCellWithSp",
              e.doNotVerticallyAlignCellWithSp,
            ),
          ),
        e.doNotBreakConstrainedForcedTable &&
          this.root.push(
            new N(
              "w:doNotBreakConstrainedForcedTable",
              e.doNotBreakConstrainedForcedTable,
            ),
          ),
        e.ignoreVerticalAlignmentInTextboxes &&
          this.root.push(
            new N(
              "w:doNotVertAlignInTxbx",
              e.ignoreVerticalAlignmentInTextboxes,
            ),
          ),
        e.useAnsiKerningPairs &&
          this.root.push(new N("w:useAnsiKerningPairs", e.useAnsiKerningPairs)),
        e.cachedColumnBalance &&
          this.root.push(new N("w:cachedColBalance", e.cachedColumnBalance)),
        e.version && this.root.push(dv(e.version)));
    }
  },
  na = 1e5,
  sa = 15,
  mv = [
    57840, 7439, 52380, 33984, 4364, 3600, 61902, 12606, 6258, 57657, 54287,
    34041, 10252, 43370, 20163,
  ],
  pv = [
    [44796, 19929, 39858, 10053, 20106, 40212, 10761],
    [31585, 63170, 64933, 60267, 50935, 40399, 11199],
    [17763, 35526, 1453, 2906, 5812, 11624, 23248],
    [885, 1770, 3540, 7080, 14160, 28320, 56640],
    [55369, 41139, 20807, 41614, 21821, 43642, 17621],
    [28485, 56970, 44341, 19019, 38038, 14605, 29210],
    [60195, 50791, 40175, 10751, 21502, 43004, 24537],
    [18387, 36774, 3949, 7898, 15796, 31592, 63184],
    [47201, 24803, 49606, 37805, 14203, 28406, 56812],
    [17824, 35648, 1697, 3394, 6788, 13576, 27152],
    [43601, 17539, 35078, 557, 1114, 2228, 4456],
    [30388, 60776, 51953, 34243, 7079, 14158, 28316],
    [14128, 28256, 56512, 43425, 17251, 34502, 7597],
    [13105, 26210, 52420, 35241, 883, 1766, 3532],
    [4129, 8258, 16516, 33032, 4657, 9314, 18628],
  ],
  aa = (e) => ((e >> 14) & 1) | ((e << 1) & 32767),
  vv = (e) => {
    const t = e
        .slice(0, sa)
        .split("")
        .map((s) => {
          const a = s.charCodeAt(0);
          return (a & 255) !== 0 ? a & 255 : (a >> 8) & 255;
        }),
      r = t.reduce(
        (s, a, o) =>
          pv[sa - t.length + o].reduce(
            (i, l, c) => ((a >> c) & 1 ? i ^ l : i),
            s,
          ),
        mv[t.length - 1],
      ),
      n =
        (aa(t.reduceRight((s, a) => aa(s) ^ a, 0)) ^ t.length ^ 52811) & 65535;
    return [n & 255, n >> 8, r & 255, r >> 8]
      .map((s) => s.toString(16).toUpperCase().padStart(2, "0"))
      .join("");
  },
  fv = (e, t, r) => {
    const n = [...vv(e)].flatMap((i) => [i.charCodeAt(0), 0]);
    let s = Ds(Uint8Array.from([...t, ...n]));
    const a = new Uint8Array(s.length + 4),
      o = new DataView(a.buffer);
    for (let i = 0; i < r; i++)
      (a.set(s), o.setUint32(s.length, i, !0), (s = Ds(a)));
    return Array.from(s);
  },
  wv = (e) => {
    var t;
    const r = new Uint8Array(e);
    return typeof ((t = globalThis.crypto) === null || t === void 0
      ? void 0
      : t.getRandomValues) == "function"
      ? (globalThis.crypto.getRandomValues(r), [...r])
      : [...r].map(() => Math.floor(Math.random() * 256));
  },
  My = {
    READ_ONLY: "readOnly",
    COMMENTS: "comments",
    TRACKED_CHANGES: "trackedChanges",
    FORMS: "forms",
  },
  oa = class extends _ {
    constructor(...e) {
      (super(...e),
        p(this, "xmlKeys", {
          edit: "w:edit",
          enforcement: "w:enforcement",
          cryptProviderType: "w:cryptProviderType",
          cryptAlgorithmClass: "w:cryptAlgorithmClass",
          cryptAlgorithmType: "w:cryptAlgorithmType",
          cryptAlgorithmSid: "w:cryptAlgorithmSid",
          cryptSpinCount: "w:cryptSpinCount",
          hash: "w:hash",
          salt: "w:salt",
        }));
    }
  },
  ia = (e) => btoa(String.fromCharCode(...e)),
  gv = class extends y {
    constructor({ type: e, password: t }) {
      if ((super("w:documentProtection"), t === void 0 || t === "")) {
        this.root.push(new oa({ edit: e, enforcement: !0 }));
        return;
      }
      const r = wv(16);
      this.root.push(
        new oa({
          edit: e,
          enforcement: !0,
          cryptProviderType: "rsaAES",
          cryptAlgorithmClass: "hash",
          cryptAlgorithmType: "typeAny",
          cryptAlgorithmSid: 12,
          cryptSpinCount: na,
          hash: ia(fv(t, r, na)),
          salt: ia(r),
        }),
      );
    }
  },
  yv = class extends _ {
    constructor(...e) {
      (super(...e),
        p(this, "xmlKeys", {
          wpc: "xmlns:wpc",
          mc: "xmlns:mc",
          o: "xmlns:o",
          r: "xmlns:r",
          m: "xmlns:m",
          v: "xmlns:v",
          wp14: "xmlns:wp14",
          wp: "xmlns:wp",
          w10: "xmlns:w10",
          w: "xmlns:w",
          w14: "xmlns:w14",
          w15: "xmlns:w15",
          wpg: "xmlns:wpg",
          wpi: "xmlns:wpi",
          wne: "xmlns:wne",
          wps: "xmlns:wps",
          Ignorable: "mc:Ignorable",
        }));
    }
  },
  xv = class extends y {
    constructor(e) {
      var t, r, n, s, a, o, i, l, c;
      (super("w:settings"),
        this.root.push(
          new yv({
            wpc: "http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas",
            mc: "http://schemas.openxmlformats.org/markup-compatibility/2006",
            o: "urn:schemas-microsoft-com:office:office",
            r: "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
            m: "http://schemas.openxmlformats.org/officeDocument/2006/math",
            v: "urn:schemas-microsoft-com:vml",
            wp14: "http://schemas.microsoft.com/office/word/2010/wordprocessingDrawing",
            wp: "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing",
            w10: "urn:schemas-microsoft-com:office:word",
            w: "http://schemas.openxmlformats.org/wordprocessingml/2006/main",
            w14: "http://schemas.microsoft.com/office/word/2010/wordml",
            w15: "http://schemas.microsoft.com/office/word/2012/wordml",
            wpg: "http://schemas.microsoft.com/office/word/2010/wordprocessingGroup",
            wpi: "http://schemas.microsoft.com/office/word/2010/wordprocessingInk",
            wne: "http://schemas.microsoft.com/office/word/2006/wordml",
            wps: "http://schemas.microsoft.com/office/word/2010/wordprocessingShape",
            Ignorable: "w14 w15 wp14",
          }),
        ),
        this.root.push(new N("w:displayBackgroundShape", !0)),
        e.embedFonts !== void 0 &&
          this.root.push(new N("w:embedTrueTypeFonts", e.embedFonts)),
        e.trackRevisions !== void 0 &&
          this.root.push(new N("w:trackRevisions", e.trackRevisions)),
        e.protection !== void 0 && this.root.push(new gv(e.protection)),
        this.root.push(
          new Ot(
            "w:defaultTabStop",
            (t = e.defaultTabStop) !== null && t !== void 0 ? t : 720,
          ),
        ),
        ((r = e.hyphenation) === null || r === void 0
          ? void 0
          : r.autoHyphenation) !== void 0 &&
          this.root.push(
            new N("w:autoHyphenation", e.hyphenation.autoHyphenation),
          ),
        ((n = e.hyphenation) === null || n === void 0
          ? void 0
          : n.consecutiveHyphenLimit) !== void 0 &&
          this.root.push(
            new Ot(
              "w:consecutiveHyphenLimit",
              e.hyphenation.consecutiveHyphenLimit,
            ),
          ),
        ((s = e.hyphenation) === null || s === void 0
          ? void 0
          : s.hyphenationZone) !== void 0 &&
          this.root.push(
            new Ot("w:hyphenationZone", e.hyphenation.hyphenationZone),
          ),
        ((a = e.hyphenation) === null || a === void 0
          ? void 0
          : a.doNotHyphenateCaps) !== void 0 &&
          this.root.push(
            new N("w:doNotHyphenateCaps", e.hyphenation.doNotHyphenateCaps),
          ),
        e.evenAndOddHeaders !== void 0 &&
          this.root.push(new N("w:evenAndOddHeaders", e.evenAndOddHeaders)),
        e.updateFields !== void 0 &&
          this.root.push(new N("w:updateFields", e.updateFields)),
        this.root.push(
          new hv(
            f(
              f({}, (o = e.compatibility) !== null && o !== void 0 ? o : {}),
              {},
              {
                version:
                  (i =
                    (l =
                      (c = e.compatibility) === null || c === void 0
                        ? void 0
                        : c.version) !== null && l !== void 0
                      ? l
                      : e.compatibilityModeVersion) !== null && i !== void 0
                    ? i
                    : 15,
              },
            ),
          ),
        ));
    }
  },
  Wi = class extends _ {
    constructor(...e) {
      (super(...e), p(this, "xmlKeys", { val: "w:val" }));
    }
  },
  bv = class extends y {
    constructor(e) {
      (super("w:name"), this.root.push(new Wi({ val: e })));
    }
  },
  Tv = class extends y {
    constructor(e) {
      (super("w:uiPriority"), this.root.push(new Wi({ val: K(e) })));
    }
  },
  Ev = class extends _ {
    constructor(...e) {
      (super(...e),
        p(this, "xmlKeys", {
          type: "w:type",
          styleId: "w:styleId",
          default: "w:default",
          customStyle: "w:customStyle",
        }));
    }
  },
  fs = class extends y {
    constructor(e, t) {
      (super("w:style"),
        this.root.push(new Ev(e)),
        t.name && this.root.push(new bv(t.name)),
        t.basedOn &&
          t.basedOn !== e.styleId &&
          this.root.push(new $e("w:basedOn", t.basedOn)),
        t.next && this.root.push(new $e("w:next", t.next)),
        t.link && this.root.push(new $e("w:link", t.link)),
        t.uiPriority !== void 0 && this.root.push(new Tv(t.uiPriority)),
        t.semiHidden !== void 0 &&
          this.root.push(new N("w:semiHidden", t.semiHidden)),
        t.unhideWhenUsed !== void 0 &&
          this.root.push(new N("w:unhideWhenUsed", t.unhideWhenUsed)),
        t.quickFormat !== void 0 &&
          this.root.push(new N("w:qFormat", t.quickFormat)));
    }
  },
  et = class extends fs {
    constructor(e) {
      (super({ type: "paragraph", styleId: e.id }, e),
        p(this, "paragraphProperties", void 0),
        p(this, "runProperties", void 0),
        (this.paragraphProperties = new dt(e.paragraph, {
          implicitListParagraphStyle: !1,
          inListOrder: !1,
        })),
        (this.runProperties = new Qe(e.run)),
        this.root.push(this.paragraphProperties),
        this.root.push(this.runProperties));
    }
  },
  ht = class extends fs {
    constructor(e) {
      (super(
        { type: "character", styleId: e.id },
        f({ uiPriority: 99, unhideWhenUsed: !0 }, e),
      ),
        p(this, "runProperties", void 0),
        (this.runProperties = new Qe(e.run)),
        this.root.push(this.runProperties));
    }
  },
  ot = class extends et {
    constructor(e) {
      super(f({ basedOn: "Normal", next: "Normal", quickFormat: !0 }, e));
    }
  },
  Sv = class extends ot {
    constructor(e) {
      super(f({ id: "Title", name: "Title" }, e));
    }
  },
  Av = class extends ot {
    constructor(e) {
      super(f({ id: "Heading1", name: "Heading 1" }, e));
    }
  },
  Iv = class extends ot {
    constructor(e) {
      super(f({ id: "Heading2", name: "Heading 2" }, e));
    }
  },
  Cv = class extends ot {
    constructor(e) {
      super(f({ id: "Heading3", name: "Heading 3" }, e));
    }
  },
  Nv = class extends ot {
    constructor(e) {
      super(f({ id: "Heading4", name: "Heading 4" }, e));
    }
  },
  kv = class extends ot {
    constructor(e) {
      super(f({ id: "Heading5", name: "Heading 5" }, e));
    }
  },
  Rv = class extends ot {
    constructor(e) {
      super(f({ id: "Heading6", name: "Heading 6" }, e));
    }
  },
  Pv = class extends ot {
    constructor(e) {
      super(f({ id: "Strong", name: "Strong" }, e));
    }
  },
  Ov = class extends et {
    constructor(e) {
      super(
        f(
          {
            id: "ListParagraph",
            name: "List Paragraph",
            basedOn: "Normal",
            quickFormat: !0,
          },
          e,
        ),
      );
    }
  },
  _v = class extends et {
    constructor(e) {
      super(
        f(
          {
            id: "Caption",
            name: "caption",
            basedOn: "Normal",
            next: "Normal",
            uiPriority: 35,
            semiHidden: !0,
            unhideWhenUsed: !0,
            quickFormat: !0,
            paragraph: { spacing: { after: 200 } },
            run: { italics: !0, color: { theme: "dark2" }, size: 18 },
          },
          e,
        ),
      );
    }
  },
  Lv = class extends et {
    constructor(e) {
      super(
        f(
          {
            id: "Bibliography",
            name: "Bibliography",
            basedOn: "Normal",
            next: "Normal",
            uiPriority: 37,
            unhideWhenUsed: !0,
          },
          e,
        ),
      );
    }
  },
  Ui = new WeakSet(),
  la = (e) => Ui.has(e),
  Ve = class extends et {
    constructor(e, t) {
      super({
        id: `TOC${e}`,
        name: `toc ${e}`,
        basedOn: "Normal",
        next: "Normal",
        uiPriority: 39,
        semiHidden: !0,
        unhideWhenUsed: !0,
        paragraph: f(
          { spacing: { after: 100 } },
          e > 1 ? { indent: { left: (e - 1) * t } } : {},
        ),
      });
    }
    prepForXml(e) {
      const t = super.prepForXml(e);
      return (Ui.add(t), t);
    }
  },
  Gi = class extends et {
    constructor(e) {
      super(
        f(
          {
            id: "FootnoteText",
            name: "footnote text",
            link: "FootnoteTextChar",
            basedOn: "Normal",
            uiPriority: 99,
            semiHidden: !0,
            unhideWhenUsed: !0,
            paragraph: { spacing: { after: 0, line: 240, lineRule: xt.AUTO } },
            run: { size: 20 },
          },
          e,
        ),
      );
    }
  },
  ji = class extends ht {
    constructor(e) {
      super(
        f(
          {
            id: "FootnoteReference",
            name: "footnote reference",
            basedOn: "DefaultParagraphFont",
            semiHidden: !0,
            run: { superScript: !0 },
          },
          e,
        ),
      );
    }
  },
  Vi = class extends ht {
    constructor(e) {
      super(
        f(
          {
            id: "FootnoteTextChar",
            name: "Footnote Text Char",
            basedOn: "DefaultParagraphFont",
            link: "FootnoteText",
            semiHidden: !0,
            run: { size: 20 },
          },
          e,
        ),
      );
    }
  },
  Xi = class extends et {
    constructor(e) {
      super(
        f(
          {
            id: "EndnoteText",
            name: "endnote text",
            link: "EndnoteTextChar",
            basedOn: "Normal",
            uiPriority: 99,
            semiHidden: !0,
            unhideWhenUsed: !0,
            paragraph: { spacing: { after: 0, line: 240, lineRule: xt.AUTO } },
            run: { size: 20 },
          },
          e,
        ),
      );
    }
  },
  Ki = class extends ht {
    constructor(e) {
      super(
        f(
          {
            id: "EndnoteReference",
            name: "endnote reference",
            basedOn: "DefaultParagraphFont",
            semiHidden: !0,
            run: { superScript: !0 },
          },
          e,
        ),
      );
    }
  },
  zi = class extends ht {
    constructor(e) {
      super(
        f(
          {
            id: "EndnoteTextChar",
            name: "Endnote Text Char",
            basedOn: "DefaultParagraphFont",
            link: "EndnoteText",
            semiHidden: !0,
            run: { size: 20 },
          },
          e,
        ),
      );
    }
  },
  Dv = class extends ht {
    constructor(e) {
      super(
        f(
          {
            id: "Hyperlink",
            name: "Hyperlink",
            basedOn: "DefaultParagraphFont",
            run: { color: "0563C1", underline: { type: Eo.SINGLE } },
          },
          e,
        ),
      );
    }
  },
  Mv = class extends ht {
    constructor(e) {
      super(
        f(
          {
            id: "LineNumber",
            name: "line number",
            basedOn: "DefaultParagraphFont",
            semiHidden: !0,
          },
          e,
        ),
      );
    }
  },
  Fv = class extends fs {
    constructor() {
      (super(
        { type: "table", styleId: "TableNormal", default: !0 },
        {
          name: "Normal Table",
          uiPriority: 99,
          semiHidden: !0,
          unhideWhenUsed: !0,
        },
      ),
        this.root.push(
          new vs({
            indent: { size: 0, type: ze.DXA },
            cellMargin: { top: 0, left: 108, bottom: 0, right: 108 },
          }),
        ));
    }
  },
  Lt = (e) => (typeof e == "object" ? Object.keys(e)[0] : void 0),
  ws = (e) => {
    var t;
    return (t = [e["w:style"]].flat().find((r) => r._attr)) === null ||
      t === void 0
      ? void 0
      : t._attr;
  },
  ca = (e) => {
    var t;
    return (t = ws(e)) === null || t === void 0 ? void 0 : t["w:styleId"];
  },
  ua = (e) => {
    var t;
    const r =
      (t = [e["w:style"]].flat().find((n) => Lt(n) === "w:name")) === null ||
      t === void 0 ||
      (t = t["w:name"]) === null ||
      t === void 0 ||
      (t = t._attr) === null ||
      t === void 0
        ? void 0
        : t["w:val"];
    return r === void 0 ? void 0 : String(r).toLowerCase();
  },
  On = (e) => {
    var t, r;
    return (
      Lt(e) === "w:style" &&
      ((t = (r = ws(e)) === null || r === void 0 ? void 0 : r["w:type"]) !==
        null && t !== void 0
        ? t
        : "paragraph") === "paragraph"
    );
  },
  $v = (e) => {
    const t = On(e) ? ws(e) : void 0;
    return (
      t?.["w:default"] !== void 0 &&
      !["0", "false", "off"].includes(String(t["w:default"]))
    );
  },
  Hv = (e) => ({
    "w:style": [e["w:style"]]
      .flat()
      .map((t) =>
        t._attr ? { _attr: f(f({}, t._attr), {}, { "w:default": "1" }) } : t,
      ),
  }),
  rn = class extends y {
    constructor(e) {
      if (
        (super("w:styles"),
        e.initialStyles && this.root.push(e.initialStyles),
        e.importedStyles)
      )
        for (const t of e.importedStyles) this.root.push(t);
      if (e.paragraphStyles)
        for (const t of e.paragraphStyles) this.root.push(new et(t));
      if (e.characterStyles)
        for (const t of e.characterStyles) this.root.push(new ht(t));
    }
    prepForXml(e) {
      const t = super.prepForXml(e),
        r = t["w:styles"];
      if (!Array.isArray(r)) return t;
      const n = (c) => r.filter((u) => Lt(u) === c),
        s = r.map((c) => (Lt(c) === "w:style" ? ca(c) : void 0)),
        a = r.filter(
          (c, u) =>
            !["_attr", "w:docDefaults", "w:latentStyles"].includes(Lt(c)) &&
            (s[u] === void 0 || s.lastIndexOf(s[u]) === u),
        ),
        o = new Set(a.filter((c) => On(c) && !la(c)).map(ua)),
        i = a.filter((c) => !la(c) || !o.has(ua(c))),
        l = i.some($v)
          ? i
          : i.map((c) => (On(c) && ca(c) === "Normal" ? Hv(c) : c));
      return {
        "w:styles": [
          ...n("_attr"),
          ...n("w:docDefaults").slice(-1),
          ...n("w:latentStyles").slice(-1),
          ...l,
        ],
      };
    }
  },
  Bv = class extends y {
    constructor(e) {
      (super("w:pPrDefault"),
        this.root.push(
          new dt(e, { implicitListParagraphStyle: !1, inListOrder: !1 }),
        ));
    }
  },
  Wv = class extends y {
    constructor(e) {
      (super("w:rPrDefault"), this.root.push(new Qe(e)));
    }
  },
  Uv = class extends y {
    constructor(e) {
      (super("w:docDefaults"),
        p(this, "runPropertiesDefaults", void 0),
        p(this, "paragraphPropertiesDefaults", void 0),
        (this.runPropertiesDefaults = new Wv(e.run)),
        (this.paragraphPropertiesDefaults = new Bv(e.paragraph)),
        this.root.push(this.runPropertiesDefaults),
        this.root.push(this.paragraphPropertiesDefaults));
    }
  },
  Gv = class {
    newInstance(e) {
      const t = bt(e);
      let r;
      for (const s of t.elements || []) s.name === "w:styles" && (r = s);
      if (r === void 0) throw new Error("can not find styles element");
      const n = r.elements || [];
      return {
        initialStyles: new nc(r.attributes),
        importedStyles: n.map((s) => Yn(s)),
      };
    }
  },
  jv = (e) => {
    var t;
    const r =
      (t = e.document) === null ||
      t === void 0 ||
      (t = t.run) === null ||
      t === void 0
        ? void 0
        : t.size;
    return r === void 0
      ? 200
      : Math.round(typeof r == "number" ? r * 10 : nt(r));
  },
  Vv = (e) => ({
    tableOfContents1: new Ve(1, e),
    tableOfContents2: new Ve(2, e),
    tableOfContents3: new Ve(3, e),
    tableOfContents4: new Ve(4, e),
    tableOfContents5: new Ve(5, e),
    tableOfContents6: new Ve(6, e),
    tableOfContents7: new Ve(7, e),
    tableOfContents8: new Ve(8, e),
    tableOfContents9: new Ve(9, e),
  }),
  gs = (e = {}) => {
    var t;
    return f(
      f(
        {
          normal: new et({ id: "Normal", name: "Normal", quickFormat: !0 }),
          normalTable: new Fv(),
          document: new Uv((t = e.document) !== null && t !== void 0 ? t : {}),
          title: new Sv(f({ run: { size: 56 } }, e.title)),
          heading1: new Av(
            f({ run: { color: "2E74B5", size: 32 } }, e.heading1),
          ),
          heading2: new Iv(
            f({ run: { color: "2E74B5", size: 26 } }, e.heading2),
          ),
          heading3: new Cv(
            f({ run: { color: "1F4D78", size: 24 } }, e.heading3),
          ),
          heading4: new Nv(
            f({ run: { color: "2E74B5", italics: !0 } }, e.heading4),
          ),
          heading5: new kv(f({ run: { color: "2E74B5" } }, e.heading5)),
          heading6: new Rv(f({ run: { color: "1F4D78" } }, e.heading6)),
          strong: new Pv(f({ run: { bold: !0 } }, e.strong)),
          listParagraph: new Ov(e.listParagraph || {}),
          caption: new _v(e.caption || {}),
          bibliography: new Lv(e.bibliography || {}),
        },
        Vv(jv(e)),
      ),
      {},
      {
        hyperlink: new Dv(e.hyperlink || {}),
        footnoteReference: new ji(e.footnoteReference || {}),
        footnoteText: new Gi(e.footnoteText || {}),
        footnoteTextChar: new Vi(e.footnoteTextChar || {}),
        endnoteReference: new Ki(e.endnoteReference || {}),
        endnoteText: new Xi(e.endnoteText || {}),
        endnoteTextChar: new zi(e.endnoteTextChar || {}),
        lineNumber: new Mv(e.lineNumber || {}),
      },
    );
  },
  da = class {
    newInstance(e = {}) {
      return {
        initialStyles: new Lr(["mc", "r", "w", "w14", "w15"], "w14 w15"),
        importedStyles: Object.values(gs(e)),
      };
    }
  },
  Yi = {
    headings: { latin: "Calibri Light", panose: "020F0302020204030204" },
    body: { latin: "Calibri", panose: "020F0502020204030204" },
  },
  Xv = [
    ["Jpan", "游ゴシック Light", "游明朝"],
    ["Hang", "맑은 고딕"],
    ["Hans", "等线 Light", "等线"],
    ["Hant", "新細明體"],
    ["Arab", "Times New Roman", "Arial"],
    ["Hebr", "Times New Roman", "Arial"],
    ["Thai", "Angsana New", "Cordia New"],
    ["Ethi", "Nyala"],
    ["Beng", "Vrinda"],
    ["Gujr", "Shruti"],
    ["Khmr", "MoolBoran", "DaunPenh"],
    ["Knda", "Tunga"],
    ["Guru", "Raavi"],
    ["Cans", "Euphemia"],
    ["Cher", "Plantagenet Cherokee"],
    ["Yiii", "Microsoft Yi Baiti"],
    ["Tibt", "Microsoft Himalaya"],
    ["Thaa", "MV Boli"],
    ["Deva", "Mangal"],
    ["Telu", "Gautami"],
    ["Taml", "Latha"],
    ["Syrc", "Estrangelo Edessa"],
    ["Orya", "Kalinga"],
    ["Mlym", "Kartika"],
    ["Laoo", "DokChampa"],
    ["Sinh", "Iskoola Pota"],
    ["Mong", "Mongolian Baiti"],
    ["Viet", "Times New Roman", "Arial"],
    ["Uigh", "Microsoft Uighur"],
    ["Geor", "Sylfaen"],
    ["Armn", "Arial"],
    ["Bugi", "Leelawadee UI"],
    ["Bopo", "Microsoft JhengHei"],
    ["Java", "Javanese Text"],
    ["Lisu", "Segoe UI"],
    ["Mymr", "Myanmar Text"],
    ["Nkoo", "Ebrima"],
    ["Olck", "Nirmala UI"],
    ["Osma", "Ebrima"],
    ["Phag", "Phagspa"],
    ["Syrn", "Estrangelo Edessa"],
    ["Syrj", "Estrangelo Edessa"],
    ["Syre", "Estrangelo Edessa"],
    ["Sora", "Nirmala UI"],
    ["Tale", "Microsoft Tai Le"],
    ["Talu", "Microsoft New Tai Lue"],
    ["Tfng", "Ebrima"],
  ],
  nn = (e, t, r) =>
    new x({
      name: e,
      attributes: {
        typeface: { key: "typeface", value: t },
        panose: { key: "panose", value: r },
      },
    }),
  Kv = (e, t) => {
    const r = t[e],
      n = typeof r == "string" ? r : r?.latin;
    return n ?? Yi[e].latin;
  },
  zv = (e, t = {}) => {
    const r = Xv.map(([s, a, o = a]) => {
        var i;
        return [
          s,
          (i = t[s]) !== null && i !== void 0 ? i : e === "headings" ? a : o,
        ];
      }),
      n = new Set(r.map(([s]) => s));
    return [...r, ...Object.entries(t).filter(([s]) => !n.has(s))];
  },
  ha = (e, t) => {
    const r = t[e],
      {
        eastAsia: n = "",
        complexScript: s = "",
        scripts: a,
      } = typeof r == "object" ? r : {},
      o = Kv(e, t),
      i = Yi[e];
    return new x({
      name: e === "headings" ? "a:majorFont" : "a:minorFont",
      children: [
        nn("a:latin", o, o === i.latin ? i.panose : void 0),
        nn("a:ea", n),
        nn("a:cs", s),
        ...zv(e, a).map(
          ([l, c]) =>
            new x({
              name: "a:font",
              attributes: {
                script: { key: "script", value: l },
                typeface: { key: "typeface", value: c },
              },
            }),
        ),
      ],
    });
  },
  Yv = (e, t = {}) =>
    new x({
      name: "a:fontScheme",
      attributes: { name: { key: "name", value: e } },
      children: [ha("headings", t), ha("body", t)],
    }),
  qi = (e = []) =>
    new x({
      name: "a:schemeClr",
      attributes: { value: { key: "val", value: "phClr" } },
      children: e.map(
        ([t, r]) =>
          new x({
            name: `a:${t}`,
            attributes: { value: { key: "val", value: r } },
          }),
      ),
    }),
  dr = (e) => new x({ name: "a:solidFill", children: [qi(e)] }),
  sn = (e) =>
    new x({
      name: "a:gradFill",
      attributes: { rotateWithShape: { key: "rotWithShape", value: !0 } },
      children: [
        new x({
          name: "a:gsLst",
          children: e.map(
            (t, r) =>
              new x({
                name: "a:gs",
                attributes: { position: { key: "pos", value: r * 5e4 } },
                children: [qi(t)],
              }),
          ),
        }),
        new x({
          name: "a:lin",
          attributes: {
            angle: { key: "ang", value: 54e5 },
            scaled: { key: "scaled", value: !1 },
          },
        }),
      ],
    }),
  an = (e) =>
    new x({
      name: "a:ln",
      attributes: {
        width: { key: "w", value: e },
        cap: { key: "cap", value: "flat" },
        compound: { key: "cmpd", value: "sng" },
        alignment: { key: "algn", value: "ctr" },
      },
      children: [
        dr(),
        new x({
          name: "a:prstDash",
          attributes: { value: { key: "val", value: "solid" } },
        }),
        new x({
          name: "a:miter",
          attributes: { limit: { key: "lim", value: 8e5 } },
        }),
      ],
    }),
  on = (e) =>
    new x({
      name: "a:effectStyle",
      children: [new x({ name: "a:effectLst", children: e })],
    }),
  qv = () =>
    new x({
      name: "a:outerShdw",
      attributes: {
        blurRadius: { key: "blurRad", value: 57150 },
        distance: { key: "dist", value: 19050 },
        direction: { key: "dir", value: 54e5 },
        alignment: { key: "algn", value: "ctr" },
        rotateWithShape: { key: "rotWithShape", value: !1 },
      },
      children: [
        new x({
          name: "a:srgbClr",
          attributes: { value: { key: "val", value: "000000" } },
          children: [
            new x({
              name: "a:alpha",
              attributes: { value: { key: "val", value: 63e3 } },
            }),
          ],
        }),
      ],
    }),
  Jv = () =>
    new x({
      name: "a:fmtScheme",
      attributes: { name: { key: "name", value: "Office" } },
      children: [
        new x({
          name: "a:fillStyleLst",
          children: [
            dr(),
            sn([
              [
                ["lumMod", 11e4],
                ["satMod", 105e3],
                ["tint", 67e3],
              ],
              [
                ["lumMod", 105e3],
                ["satMod", 103e3],
                ["tint", 73e3],
              ],
              [
                ["lumMod", 105e3],
                ["satMod", 109e3],
                ["tint", 81e3],
              ],
            ]),
            sn([
              [
                ["satMod", 103e3],
                ["lumMod", 102e3],
                ["tint", 94e3],
              ],
              [
                ["satMod", 11e4],
                ["lumMod", 1e5],
                ["shade", 1e5],
              ],
              [
                ["lumMod", 99e3],
                ["satMod", 12e4],
                ["shade", 78e3],
              ],
            ]),
          ],
        }),
        new x({
          name: "a:lnStyleLst",
          children: [an(6350), an(12700), an(19050)],
        }),
        new x({
          name: "a:effectStyleLst",
          children: [on([]), on([]), on([qv()])],
        }),
        new x({
          name: "a:bgFillStyleLst",
          children: [
            dr(),
            dr([
              ["tint", 95e3],
              ["satMod", 17e4],
            ]),
            sn([
              [
                ["tint", 93e3],
                ["satMod", 15e4],
                ["shade", 98e3],
                ["lumMod", 102e3],
              ],
              [
                ["tint", 98e3],
                ["satMod", 13e4],
                ["shade", 9e4],
                ["lumMod", 103e3],
              ],
              [
                ["shade", 63e3],
                ["satMod", 12e4],
              ],
            ]),
          ],
        }),
      ],
    }),
  Zv = class extends y {
    constructor({ name: e = "Office Theme", colors: t, fonts: r } = {}) {
      (super("a:theme"),
        p(this, "colors", void 0),
        (this.colors = Jn(t)),
        this.root.push(
          new Sr({
            namespace: {
              key: "xmlns:a",
              value: "http://schemas.openxmlformats.org/drawingml/2006/main",
            },
            name: { key: "name", value: e },
          }),
        ),
        this.root.push(
          new x({
            name: "a:themeElements",
            children: [mc(t ? e : "Office", t), Yv(r ? e : "Office", r), Jv()],
          }),
        ),
        this.root.push(new x({ name: "a:objectDefaults" })),
        this.root.push(new x({ name: "a:extraClrSchemeLst" })));
    }
    get Colors() {
      return this.colors;
    }
  },
  Oe = (e) => {
    const t = e.lastIndexOf("/");
    return `${e.slice(0, t + 1)}_rels/${e.slice(t + 1)}.rels`;
  },
  Ji = (e) => e.replace(/(^|\/)_rels\/([^/]*)\.rels$/, "$1$2"),
  Zi = (e) => e.slice(0, e.lastIndexOf("/") + 1),
  mt = (e, t) => {
    const r = t.replace(/\\/g, "/");
    return (r.startsWith("/") ? r : `${Zi(e)}${r}`)
      .split("/")
      .reduce(
        (n, s) =>
          s === "" || s === "." ? n : s === ".." ? n.slice(0, -1) : [...n, s],
        [],
      )
      .join("/");
  },
  ys = (e, t) => {
    const r = Zi(e).split("/").filter(Boolean),
      n = t.split("/"),
      s = r.findIndex((o, i) => i >= n.length - 1 || n[i] !== o),
      a = s === -1 ? r.length : s;
    return [...r.slice(a).map(() => ".."), ...n.slice(a)].join("/");
  },
  Qi = (e, t) => e.toLowerCase() === t.toLowerCase(),
  Z = Uint8Array,
  be = Uint16Array,
  xs = Int32Array,
  Dr = new Z([
    0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5,
    5, 5, 5, 0, 0, 0, 0,
  ]),
  Mr = new Z([
    0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10,
    11, 11, 12, 12, 13, 13, 0, 0,
  ]),
  _n = new Z([
    16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15,
  ]),
  el = function (e, t) {
    for (var r = new be(31), n = 0; n < 31; ++n) r[n] = t += 1 << e[n - 1];
    for (var s = new xs(r[30]), n = 1; n < 30; ++n)
      for (var a = r[n]; a < r[n + 1]; ++a) s[a] = ((a - r[n]) << 5) | n;
    return { b: r, r: s };
  },
  tl = el(Dr, 2),
  rl = tl.b,
  Ln = tl.r;
((rl[28] = 258), (Ln[258] = 28));
var nl = el(Mr, 0),
  Qv = nl.b,
  ma = nl.r,
  Dn = new be(32768);
for (var W = 0; W < 32768; ++W) {
  var rt = ((W & 43690) >> 1) | ((W & 21845) << 1);
  ((rt = ((rt & 52428) >> 2) | ((rt & 13107) << 2)),
    (rt = ((rt & 61680) >> 4) | ((rt & 3855) << 4)),
    (Dn[W] = (((rt & 65280) >> 8) | ((rt & 255) << 8)) >> 1));
}
var He = function (e, t, r) {
    for (var n = e.length, s = 0, a = new be(t); s < n; ++s)
      e[s] && ++a[e[s] - 1];
    var o = new be(t);
    for (s = 1; s < t; ++s) o[s] = (o[s - 1] + a[s - 1]) << 1;
    var i;
    if (r) {
      i = new be(1 << t);
      var l = 15 - t;
      for (s = 0; s < n; ++s)
        if (e[s])
          for (
            var c = (s << 4) | e[s],
              u = t - e[s],
              d = o[e[s] - 1]++ << u,
              h = d | ((1 << u) - 1);
            d <= h;
            ++d
          )
            i[Dn[d] >> l] = c;
    } else
      for (i = new be(n), s = 0; s < n; ++s)
        e[s] && (i[s] = Dn[o[e[s] - 1]++] >> (15 - e[s]));
    return i;
  },
  st = new Z(288);
for (var W = 0; W < 144; ++W) st[W] = 8;
for (var W = 144; W < 256; ++W) st[W] = 9;
for (var W = 256; W < 280; ++W) st[W] = 7;
for (var W = 280; W < 288; ++W) st[W] = 8;
var Bt = new Z(32);
for (var W = 0; W < 32; ++W) Bt[W] = 5;
var ef = He(st, 9, 0),
  tf = He(st, 9, 1),
  rf = He(Bt, 5, 0),
  nf = He(Bt, 5, 1),
  ln = function (e) {
    for (var t = e[0], r = 1; r < e.length; ++r) e[r] > t && (t = e[r]);
    return t;
  },
  ke = function (e, t, r) {
    var n = (t / 8) | 0;
    return ((e[n] | (e[n + 1] << 8)) >> (t & 7)) & r;
  },
  cn = function (e, t) {
    var r = (t / 8) | 0;
    return (e[r] | (e[r + 1] << 8) | (e[r + 2] << 16)) >> (t & 7);
  },
  bs = function (e) {
    return ((e + 7) / 8) | 0;
  },
  qt = function (e, t, r) {
    return (
      (t == null || t < 0) && (t = 0),
      (r == null || r > e.length) && (r = e.length),
      new Z(e.subarray(t, r))
    );
  },
  sf = [
    "unexpected EOF",
    "invalid block type",
    "invalid length/literal",
    "invalid distance",
    "stream finished",
    "no stream handler",
    ,
    "no callback",
    "invalid UTF-8 data",
    "extra field too long",
    "date not in range 1980-2099",
    "filename too long",
    "stream finishing",
    "invalid zip data",
  ],
  he = function (e, t, r) {
    var n = new Error(t || sf[e]);
    if (
      ((n.code = e),
      Error.captureStackTrace && Error.captureStackTrace(n, he),
      !r)
    )
      throw n;
    return n;
  },
  af = function (e, t, r, n) {
    var s = e.length,
      a = n ? n.length : 0;
    if (!s || (t.f && !t.l)) return r || new Z(0);
    var o = !r,
      i = o || t.i != 2,
      l = t.i;
    o && (r = new Z(s * 3));
    var c = function (q) {
        var B = r.length;
        if (q > B) {
          var xe = new Z(Math.max(B * 2, q));
          (xe.set(r), (r = xe));
        }
      },
      u = t.f || 0,
      d = t.p || 0,
      h = t.b || 0,
      w = t.l,
      m = t.d,
      v = t.m,
      g = t.n,
      A = s * 8;
    do {
      if (!w) {
        u = ke(e, d, 1);
        var I = ke(e, d + 1, 3);
        if (((d += 3), I))
          if (I == 1) ((w = tf), (m = nf), (v = 9), (g = 5));
          else if (I == 2) {
            var E = ke(e, d, 31) + 257,
              T = ke(e, d + 10, 15) + 4,
              S = E + ke(e, d + 5, 31) + 1;
            d += 14;
            for (var C = new Z(S), k = new Z(19), L = 0; L < T; ++L)
              k[_n[L]] = ke(e, d + L * 3, 7);
            d += T * 3;
            for (
              var D = ln(k), j = (1 << D) - 1, z = He(k, D, 1), L = 0;
              L < S;
            ) {
              var V = z[ke(e, d, j)];
              d += V & 15;
              var b = V >> 4;
              if (b < 16) C[L++] = b;
              else {
                var X = 0,
                  H = 0;
                for (
                  b == 16
                    ? ((H = 3 + ke(e, d, 3)), (d += 2), (X = C[L - 1]))
                    : b == 17
                      ? ((H = 3 + ke(e, d, 7)), (d += 3))
                      : b == 18 && ((H = 11 + ke(e, d, 127)), (d += 7));
                  H--;
                )
                  C[L++] = X;
              }
            }
            var re = C.subarray(0, E),
              J = C.subarray(E);
            ((v = ln(re)), (g = ln(J)), (w = He(re, v, 1)), (m = He(J, g, 1)));
          } else he(1);
        else {
          var b = bs(d) + 4,
            R = e[b - 4] | (e[b - 3] << 8),
            O = b + R;
          if (O > s) {
            l && he(0);
            break;
          }
          (i && c(h + R),
            r.set(e.subarray(b, O), h),
            (t.b = h += R),
            (t.p = d = O * 8),
            (t.f = u));
          continue;
        }
        if (d > A) {
          l && he(0);
          break;
        }
      }
      i && c(h + 131072);
      for (var tt = (1 << v) - 1, ve = (1 << g) - 1, Ie = d; ; Ie = d) {
        var X = w[cn(e, d) & tt],
          ae = X >> 4;
        if (((d += X & 15), d > A)) {
          l && he(0);
          break;
        }
        if ((X || he(2), ae < 256)) r[h++] = ae;
        else if (ae == 256) {
          ((Ie = d), (w = null));
          break;
        } else {
          var oe = ae - 254;
          if (ae > 264) {
            var L = ae - 257,
              U = Dr[L];
            ((oe = ke(e, d, (1 << U) - 1) + rl[L]), (d += U));
          }
          var P = m[cn(e, d) & ve],
            M = P >> 4;
          (P || he(3), (d += P & 15));
          var J = Qv[M];
          if (M > 3) {
            var U = Mr[M];
            ((J += cn(e, d) & ((1 << U) - 1)), (d += U));
          }
          if (d > A) {
            l && he(0);
            break;
          }
          i && c(h + 131072);
          var F = h + oe;
          if (h < J) {
            var G = a - J,
              Y = Math.min(J, F);
            for (G + h < 0 && he(3); h < Y; ++h) r[h] = n[G + h];
          }
          for (; h < F; ++h) r[h] = r[h - J];
        }
      }
      ((t.l = w),
        (t.p = Ie),
        (t.b = h),
        (t.f = u),
        w && ((u = 1), (t.m = v), (t.d = m), (t.n = g)));
    } while (!u);
    return h != r.length && o ? qt(r, 0, h) : r.subarray(0, h);
  },
  Xe = function (e, t, r) {
    r <<= t & 7;
    var n = (t / 8) | 0;
    ((e[n] |= r), (e[n + 1] |= r >> 8));
  },
  Ct = function (e, t, r) {
    r <<= t & 7;
    var n = (t / 8) | 0;
    ((e[n] |= r), (e[n + 1] |= r >> 8), (e[n + 2] |= r >> 16));
  },
  un = function (e, t) {
    for (var r = [], n = 0; n < e.length; ++n)
      e[n] && r.push({ s: n, f: e[n] });
    var s = r.length,
      a = r.slice();
    if (!s) return { t: al, l: 0 };
    if (s == 1) {
      var o = new Z(r[0].s + 1);
      return ((o[r[0].s] = 1), { t: o, l: 1 });
    }
    (r.sort(function (O, E) {
      return O.f - E.f;
    }),
      r.push({ s: -1, f: 25001 }));
    var i = r[0],
      l = r[1],
      c = 0,
      u = 1,
      d = 2;
    for (r[0] = { s: -1, f: i.f + l.f, l: i, r: l }; u != s - 1;)
      ((i = r[r[c].f < r[d].f ? c++ : d++]),
        (l = r[c != u && r[c].f < r[d].f ? c++ : d++]),
        (r[u++] = { s: -1, f: i.f + l.f, l: i, r: l }));
    for (var h = a[0].s, n = 1; n < s; ++n) a[n].s > h && (h = a[n].s);
    var w = new be(h + 1),
      m = Mn(r[u - 1], w, 0);
    if (m > t) {
      var n = 0,
        v = 0,
        g = m - t,
        A = 1 << g;
      for (
        a.sort(function (E, T) {
          return w[T.s] - w[E.s] || E.f - T.f;
        });
        n < s;
        ++n
      ) {
        var I = a[n].s;
        if (w[I] > t) ((v += A - (1 << (m - w[I]))), (w[I] = t));
        else break;
      }
      for (v >>= g; v > 0;) {
        var b = a[n].s;
        w[b] < t ? (v -= 1 << (t - w[b]++ - 1)) : ++n;
      }
      for (; n >= 0 && v; --n) {
        var R = a[n].s;
        w[R] == t && (--w[R], ++v);
      }
      m = t;
    }
    return { t: new Z(w), l: m };
  },
  Mn = function (e, t, r) {
    return e.s == -1
      ? Math.max(Mn(e.l, t, r + 1), Mn(e.r, t, r + 1))
      : (t[e.s] = r);
  },
  pa = function (e) {
    for (var t = e.length; t && !e[--t];);
    for (
      var r = new be(++t),
        n = 0,
        s = e[0],
        a = 1,
        o = function (l) {
          r[n++] = l;
        },
        i = 1;
      i <= t;
      ++i
    )
      if (e[i] == s && i != t) ++a;
      else {
        if (!s && a > 2) {
          for (; a > 138; a -= 138) o(32754);
          a > 2 &&
            (o(a > 10 ? ((a - 11) << 5) | 28690 : ((a - 3) << 5) | 12305),
            (a = 0));
        } else if (a > 3) {
          for (o(s), --a; a > 6; a -= 6) o(8304);
          a > 2 && (o(((a - 3) << 5) | 8208), (a = 0));
        }
        for (; a--;) o(s);
        ((a = 1), (s = e[i]));
      }
    return { c: r.subarray(0, n), n: t };
  },
  Nt = function (e, t) {
    for (var r = 0, n = 0; n < t.length; ++n) r += e[n] * t[n];
    return r;
  },
  sl = function (e, t, r) {
    var n = r.length,
      s = bs(t + 2);
    ((e[s] = n & 255),
      (e[s + 1] = n >> 8),
      (e[s + 2] = e[s] ^ 255),
      (e[s + 3] = e[s + 1] ^ 255));
    for (var a = 0; a < n; ++a) e[s + a + 4] = r[a];
    return (s + 4 + n) * 8;
  },
  va = function (e, t, r, n, s, a, o, i, l, c, u) {
    (Xe(t, u++, r), ++s[256]);
    for (
      var d = un(s, 15),
        h = d.t,
        w = d.l,
        m = un(a, 15),
        v = m.t,
        g = m.l,
        A = pa(h),
        I = A.c,
        b = A.n,
        R = pa(v),
        O = R.c,
        E = R.n,
        T = new be(19),
        S = 0;
      S < I.length;
      ++S
    )
      ++T[I[S] & 31];
    for (var S = 0; S < O.length; ++S) ++T[O[S] & 31];
    for (
      var C = un(T, 7), k = C.t, L = C.l, D = 19;
      D > 4 && !k[_n[D - 1]];
      --D
    );
    var j = (c + 5) << 3,
      z = Nt(s, st) + Nt(a, Bt) + o,
      V =
        Nt(s, h) +
        Nt(a, v) +
        o +
        14 +
        3 * D +
        Nt(T, k) +
        2 * T[16] +
        3 * T[17] +
        7 * T[18];
    if (l >= 0 && j <= z && j <= V) return sl(t, u, e.subarray(l, l + c));
    var X, H, re, J;
    if ((Xe(t, u, 1 + (V < z)), (u += 2), V < z)) {
      ((X = He(h, w, 0)), (H = h), (re = He(v, g, 0)), (J = v));
      var tt = He(k, L, 0);
      (Xe(t, u, b - 257), Xe(t, u + 5, E - 1), Xe(t, u + 10, D - 4), (u += 14));
      for (var S = 0; S < D; ++S) Xe(t, u + 3 * S, k[_n[S]]);
      u += 3 * D;
      for (var ve = [I, O], Ie = 0; Ie < 2; ++Ie)
        for (var ae = ve[Ie], S = 0; S < ae.length; ++S) {
          var oe = ae[S] & 31;
          (Xe(t, u, tt[oe]),
            (u += k[oe]),
            oe > 15 && (Xe(t, u, (ae[S] >> 5) & 127), (u += ae[S] >> 12)));
        }
    } else ((X = ef), (H = st), (re = rf), (J = Bt));
    for (var S = 0; S < i; ++S) {
      var U = n[S];
      if (U > 255) {
        var oe = (U >> 18) & 31;
        (Ct(t, u, X[oe + 257]),
          (u += H[oe + 257]),
          oe > 7 && (Xe(t, u, (U >> 23) & 31), (u += Dr[oe])));
        var P = U & 31;
        (Ct(t, u, re[P]),
          (u += J[P]),
          P > 3 && (Ct(t, u, (U >> 5) & 8191), (u += Mr[P])));
      } else (Ct(t, u, X[U]), (u += H[U]));
    }
    return (Ct(t, u, X[256]), u + H[256]);
  },
  of = new xs([
    65540, 131080, 131088, 131104, 262176, 1048704, 1048832, 2114560, 2117632,
  ]),
  al = new Z(0),
  lf = function (e, t, r, n, s, a) {
    var o = a.z || e.length,
      i = new Z(n + o + 5 * (1 + Math.ceil(o / 7e3)) + s),
      l = i.subarray(n, i.length - s),
      c = a.l,
      u = (a.r || 0) & 7;
    if (t) {
      u && (l[0] = a.r >> 3);
      for (
        var d = of[t - 1],
          h = d >> 13,
          w = d & 8191,
          m = (1 << r) - 1,
          v = a.p || new be(32768),
          g = a.h || new be(m + 1),
          A = Math.ceil(r / 3),
          I = 2 * A,
          b = function (xe) {
            return (e[xe] ^ (e[xe + 1] << A) ^ (e[xe + 2] << I)) & m;
          },
          R = new xs(25e3),
          O = new be(288),
          E = new be(32),
          T = 0,
          S = 0,
          C = a.i || 0,
          k = 0,
          L = a.w || 0,
          D = 0;
        C + 2 < o;
        ++C
      ) {
        var j = b(C),
          z = C & 32767,
          V = g[j];
        if (((v[z] = V), (g[j] = z), L <= C)) {
          var X = o - C;
          if ((T > 7e3 || k > 24576) && (X > 423 || !c)) {
            ((u = va(e, l, 0, R, O, E, S, k, D, C - D, u)),
              (k = T = S = 0),
              (D = C));
            for (var H = 0; H < 286; ++H) O[H] = 0;
            for (var H = 0; H < 30; ++H) E[H] = 0;
          }
          var re = 2,
            J = 0,
            tt = w,
            ve = (z - V) & 32767;
          if (X > 2 && j == b(C - ve))
            for (
              var Ie = Math.min(h, X) - 1,
                ae = Math.min(32767, C),
                oe = Math.min(258, X);
              ve <= ae && --tt && z != V;
            ) {
              if (e[C + re] == e[C + re - ve]) {
                for (var U = 0; U < oe && e[C + U] == e[C + U - ve]; ++U);
                if (U > re) {
                  if (((re = U), (J = ve), U > Ie)) break;
                  for (var P = Math.min(ve, U - 2), M = 0, H = 0; H < P; ++H) {
                    var F = (C - ve + H) & 32767,
                      G = (F - v[F]) & 32767;
                    G > M && ((M = G), (V = F));
                  }
                }
              }
              ((z = V), (V = v[z]), (ve += (z - V) & 32767));
            }
          if (J) {
            R[k++] = 268435456 | (Ln[re] << 18) | ma[J];
            var Y = Ln[re] & 31,
              q = ma[J] & 31;
            ((S += Dr[Y] + Mr[q]), ++O[257 + Y], ++E[q], (L = C + re), ++T);
          } else ((R[k++] = e[C]), ++O[e[C]]);
        }
      }
      for (C = Math.max(C, L); C < o; ++C) ((R[k++] = e[C]), ++O[e[C]]);
      ((u = va(e, l, c, R, O, E, S, k, D, C - D, u)),
        c ||
          ((a.r = (u & 7) | (l[(u / 8) | 0] << 3)),
          (u -= 7),
          (a.h = g),
          (a.p = v),
          (a.i = C),
          (a.w = L)));
    } else {
      for (var C = a.w || 0; C < o + c; C += 65535) {
        var B = C + 65535;
        (B >= o && ((l[(u / 8) | 0] = c), (B = o)),
          (u = sl(l, u + 1, e.subarray(C, B))));
      }
      a.i = o;
    }
    return qt(i, 0, n + bs(u) + s);
  },
  cf = (function () {
    for (var e = new Int32Array(256), t = 0; t < 256; ++t) {
      for (var r = t, n = 9; --n;) r = (r & 1 && -306674912) ^ (r >>> 1);
      e[t] = r;
    }
    return e;
  })(),
  uf = function () {
    var e = -1;
    return {
      p: function (t) {
        for (var r = e, n = 0; n < t.length; ++n)
          r = cf[(r & 255) ^ t[n]] ^ (r >>> 8);
        e = r;
      },
      d: function () {
        return ~e;
      },
    };
  },
  df = function (e, t, r, n, s) {
    if (!s && ((s = { l: 1 }), t.dictionary)) {
      var a = t.dictionary.subarray(-32768),
        o = new Z(a.length + e.length);
      (o.set(a), o.set(e, a.length), (e = o), (s.w = a.length));
    }
    return lf(
      e,
      t.level == null ? 6 : t.level,
      t.mem == null
        ? s.l
          ? Math.ceil(Math.max(8, Math.min(13, Math.log(e.length))) * 1.5)
          : 20
        : 12 + t.mem,
      r,
      n,
      s,
    );
  },
  ol = function (e, t) {
    var r = {};
    for (var n in e) r[n] = e[n];
    for (var n in t) r[n] = t[n];
    return r;
  },
  Me = function (e, t) {
    return e[t] | (e[t + 1] << 8);
  },
  Ee = function (e, t) {
    return (e[t] | (e[t + 1] << 8) | (e[t + 2] << 16) | (e[t + 3] << 24)) >>> 0;
  },
  dn = function (e, t) {
    return Ee(e, t) + Ee(e, t + 4) * 4294967296;
  },
  ie = function (e, t, r) {
    for (; r; ++t) ((e[t] = r), (r >>>= 8));
  };
function hf(e, t) {
  return df(e, t || {}, 0, 0);
}
function mf(e, t) {
  return af(e, { i: 2 }, t && t.out, t && t.dictionary);
}
var il = function (e, t, r, n) {
    for (var s in e) {
      var a = e[s],
        o = t + s,
        i = n;
      (Array.isArray(a) && ((i = ol(n, a[1])), (a = a[0])),
        ArrayBuffer.isView(a)
          ? (r[o] = [a, i])
          : ((r[(o += "/")] = [new Z(0), i]), il(a, o, r, n)));
    }
  },
  fa = typeof TextEncoder < "u" && new TextEncoder(),
  Fn = typeof TextDecoder < "u" && new TextDecoder();
try {
  Fn.decode(al, { stream: !0 });
} catch {}
var pf = function (e) {
  for (var t = "", r = 0; ;) {
    var n = e[r++],
      s = (n > 127) + (n > 223) + (n > 239);
    if (r + s > e.length) return { s: t, r: qt(e, r - 1) };
    s
      ? s == 3
        ? ((n =
            (((n & 15) << 18) |
              ((e[r++] & 63) << 12) |
              ((e[r++] & 63) << 6) |
              (e[r++] & 63)) -
            65536),
          (t += String.fromCharCode(55296 | (n >> 10), 56320 | (n & 1023))))
        : s & 1
          ? (t += String.fromCharCode(((n & 31) << 6) | (e[r++] & 63)))
          : (t += String.fromCharCode(
              ((n & 15) << 12) | ((e[r++] & 63) << 6) | (e[r++] & 63),
            ))
      : (t += String.fromCharCode(n));
  }
};
function wa(e, t) {
  var r;
  if (fa) return fa.encode(e);
  for (
    var n = e.length,
      s = new Z(e.length + (e.length >> 1)),
      a = 0,
      o = function (c) {
        s[a++] = c;
      },
      r = 0;
    r < n;
    ++r
  ) {
    if (a + 5 > s.length) {
      var i = new Z(a + 8 + ((n - r) << 1));
      (i.set(s), (s = i));
    }
    var l = e.charCodeAt(r);
    l < 128 || t
      ? o(l)
      : l < 2048
        ? (o(192 | (l >> 6)), o(128 | (l & 63)))
        : l > 55295 && l < 57344
          ? ((l = (65536 + (l & 1047552)) | (e.charCodeAt(++r) & 1023)),
            o(240 | (l >> 18)),
            o(128 | ((l >> 12) & 63)),
            o(128 | ((l >> 6) & 63)),
            o(128 | (l & 63)))
          : (o(224 | (l >> 12)), o(128 | ((l >> 6) & 63)), o(128 | (l & 63)));
  }
  return qt(s, 0, a);
}
function vf(e, t) {
  if (t) {
    for (var r = "", n = 0; n < e.length; n += 16384)
      r += String.fromCharCode.apply(null, e.subarray(n, n + 16384));
    return r;
  } else {
    if (Fn) return Fn.decode(e);
    var s = pf(e),
      a = s.s,
      r = s.r;
    return (r.length && he(8), a);
  }
}
var ff = function (e, t) {
    return t + 30 + Me(e, t + 26) + Me(e, t + 28);
  },
  wf = function (e, t, r) {
    var n = Me(e, t + 28),
      s = Me(e, t + 30),
      a = vf(e.subarray(t + 46, t + 46 + n), !(Me(e, t + 8) & 2048)),
      o = t + 46 + n,
      i = gf(e, o, s, r, Ee(e, t + 20), Ee(e, t + 24), Ee(e, t + 42)),
      l = i[0],
      c = i[1],
      u = i[2];
    return [Me(e, t + 10), l, c, a, o + s + Me(e, t + 32), u];
  },
  gf = function (e, t, r, n, s, a, o) {
    var i = s == 4294967295,
      l = a == 4294967295,
      c = o == 4294967295,
      u = t + r,
      d = i + l + c;
    if (n && d) {
      for (; t + 4 < u; t += 4 + Me(e, t + 2))
        if (Me(e, t) == 1)
          return [
            i ? dn(e, t + 4 + 8 * l) : s,
            l ? dn(e, t + 4) : a,
            c ? dn(e, t + 4 + 8 * (l + i)) : o,
            1,
          ];
      n < 2 && he(13);
    }
    return [s, a, o, 0];
  },
  $n = function (e) {
    var t = 0;
    if (e)
      for (var r in e) {
        var n = e[r].length;
        (n > 65535 && he(9), (t += n + 4));
      }
    return t;
  },
  ga = function (e, t, r, n, s, a, o, i) {
    var l = n.length,
      c = r.extra,
      u = i && i.length,
      d = $n(c);
    (ie(e, t, o != null ? 33639248 : 67324752),
      (t += 4),
      o != null && ((e[t++] = 20), (e[t++] = r.os)),
      (e[t] = 20),
      (t += 2),
      (e[t++] = (r.flag << 1) | (a < 0 && 8)),
      (e[t++] = s && 8),
      (e[t++] = r.compression & 255),
      (e[t++] = r.compression >> 8));
    var h = new Date(r.mtime == null ? Date.now() : r.mtime),
      w = h.getFullYear() - 1980;
    if (
      ((w < 0 || w > 119) && he(10),
      ie(
        e,
        t,
        (w << 25) |
          ((h.getMonth() + 1) << 21) |
          (h.getDate() << 16) |
          (h.getHours() << 11) |
          (h.getMinutes() << 5) |
          (h.getSeconds() >> 1),
      ),
      (t += 4),
      a != -1 &&
        (ie(e, t, r.crc),
        ie(e, t + 4, a < 0 ? -a - 2 : a),
        ie(e, t + 8, r.size)),
      ie(e, t + 12, l),
      ie(e, t + 14, d),
      (t += 16),
      o != null &&
        (ie(e, t, u), ie(e, t + 6, r.attrs), ie(e, t + 10, o), (t += 14)),
      e.set(n, t),
      (t += l),
      d)
    )
      for (var m in c) {
        var v = c[m],
          g = v.length;
        (ie(e, t, +m), ie(e, t + 2, g), e.set(v, t + 4), (t += 4 + g));
      }
    return (u && (e.set(i, t), (t += u)), t);
  },
  yf = function (e, t, r, n, s) {
    (ie(e, t, 101010256),
      ie(e, t + 8, r),
      ie(e, t + 10, r),
      ie(e, t + 12, n),
      ie(e, t + 16, s));
  };
function xf(e, t) {
  t || (t = {});
  var r = {},
    n = [];
  il(e, "", r, t);
  var s = 0,
    a = 0;
  for (var o in r) {
    var i = r[o],
      l = i[0],
      c = i[1],
      u = c.level == 0 ? 0 : 8,
      d = wa(o),
      h = d.length,
      w = c.comment,
      m = w && wa(w),
      v = m && m.length,
      g = $n(c.extra);
    h > 65535 && he(11);
    var A = u ? hf(l, c) : l,
      I = A.length,
      b = uf();
    (b.p(l),
      n.push(
        ol(c, {
          size: l.length,
          crc: b.d(),
          c: A,
          f: d,
          m,
          u: h != o.length || (m && w.length != v),
          o: s,
          compression: u,
        }),
      ),
      (s += 30 + h + g + I),
      (a += 76 + 2 * (h + g) + (v || 0) + I));
  }
  for (var R = new Z(a + 22), O = s, E = a - s, T = 0; T < n.length; ++T) {
    var d = n[T];
    ga(R, d.o, d, d.f, d.u, d.c.length);
    var S = 30 + d.f.length + $n(d.extra);
    (R.set(d.c, d.o + S),
      ga(R, s, d, d.f, d.u, d.c.length, d.o, d.m),
      (s += 16 + S + (d.m ? d.m.length : 0)));
  }
  return (yf(R, s, n.length, E, O), R);
}
function bf(e, t) {
  for (var r = {}, n = e.length - 22; Ee(e, n) != 101010256; --n)
    (!n || e.length - n > 65558) && he(13);
  var s = Me(e, n + 8);
  if (!s) return {};
  var a = Ee(e, n + 16),
    o = Ee(e, n - 20) == 117853008;
  if (o) {
    var i = Ee(e, n - 12);
    ((o = Ee(e, i) == 101075792),
      o && ((s = Ee(e, i + 32)), (a = Ee(e, i + 48))));
  }
  for (var l = t && t.filter, c = 0; c < s; ++c) {
    var u = wf(e, a, o),
      d = u[0],
      h = u[1],
      w = u[2],
      m = u[3],
      v = u[4],
      g = u[5],
      A = ff(e, g);
    ((a = v),
      (!l || l({ name: m, size: h, originalSize: w, compression: d })) &&
        (d
          ? d == 8
            ? (r[m] = mf(e.subarray(A, A + h), { out: new Z(w) }))
            : he(14, "unknown compression type " + d)
          : (r[m] = qt(e, A, A + h))));
  }
  return r;
}
var Tf = (e) =>
    typeof e == "string"
      ? bo(e)
      : ArrayBuffer.isView(e)
        ? new Uint8Array(e.buffer, e.byteOffset, e.byteLength)
        : new Uint8Array(e),
  yr = (e) => xf(Object.fromEntries([...e].map(([t, r]) => [t, Tf(r)]))),
  Ef = 1032,
  ya = (e) =>
    new Error(`Corrupted zip: ${e} isn't the size the zip file gives it`),
  xr = (e, t = () => !0) => {
    const r = new Map();
    let n = 0;
    const s = bf(e, {
        filter: ({ name: o, size: i, originalSize: l }) => {
          if (o.endsWith("/") || !t(o)) return !1;
          if (((n += i), n > e.length || l > i * Ef)) throw ya(o);
          return (r.set(o, l), !0);
        },
      }),
      a = Object.entries(s).find(([o, i]) => i.length !== r.get(o));
    if (a !== void 0) throw ya(a[0]);
    return new Map(Object.entries(s));
  },
  hn = (e) => {
    let t = "";
    for (let r = 0; r < e.length; r += 32768)
      t += String.fromCharCode(...e.subarray(r, r + 32768));
    return t;
  },
  hr = (e) => new Error(`${e} is not supported by this platform`),
  xa = {
    uint8array: (e) => e,
    arraybuffer: (e) =>
      e.buffer.slice(e.byteOffset, e.byteOffset + e.byteLength),
    array: (e) => Array.from(e),
    string: hn,
    binarystring: hn,
    base64: (e) => btoa(hn(e)),
    blob: (e, t) => {
      if (typeof Blob > "u") throw hr("blob");
      return new Blob([e], { type: t });
    },
    nodebuffer: (e) => {
      if (typeof Buffer > "u") throw hr("nodebuffer");
      return Buffer.from(e.buffer, e.byteOffset, e.byteLength);
    },
    text: () => {
      throw hr("text");
    },
  },
  Hn = (e, t, r) => {
    const n = Object.prototype.hasOwnProperty.call(xa, t.toLowerCase())
      ? xa[t.toLowerCase()]
      : void 0;
    if (n === void 0) throw hr(t);
    return n(e, r);
  },
  Sf = new Map([
    ["dk1", "dark1"],
    ["lt1", "light1"],
    ["dk2", "dark2"],
    ["lt2", "light2"],
    ["accent1", "accent1"],
    ["accent2", "accent2"],
    ["accent3", "accent3"],
    ["accent4", "accent4"],
    ["accent5", "accent5"],
    ["accent6", "accent6"],
    ["hlink", "hyperlink"],
    ["folHlink", "followedHyperlink"],
  ]),
  Af = new Map([
    ["dark1", "windowText"],
    ["light1", "window"],
  ]),
  If = new Set([
    "http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument",
    "http://purl.oclc.org/ooxml/officeDocument/relationships/officeDocument",
  ]),
  Cf = new Set([
    "http://schemas.openxmlformats.org/officeDocument/2006/relationships/theme",
    "http://purl.oclc.org/ooxml/officeDocument/relationships/theme",
  ]),
  qe = (e) => {
    var t, r;
    return (t =
      e == null || (r = e.name) === null || r === void 0
        ? void 0
        : r.slice(e.name.indexOf(":") + 1)) !== null && t !== void 0
      ? t
      : "";
  },
  pt = (e) => {
    var t, r;
    return (t =
      e == null || (r = e.elements) === null || r === void 0
        ? void 0
        : r.filter((n) => n.type === "element")) !== null && t !== void 0
      ? t
      : [];
  },
  _e = (e, t) => pt(e).find((r) => qe(r) === t),
  Je = (e, t) => {
    var r;
    const n =
      e == null || (r = e.attributes) === null || r === void 0 ? void 0 : r[t];
    return n === void 0 ? void 0 : String(n);
  },
  Nf = (e) => e[0] === 80 && e[1] === 75 && e[2] === 3 && e[3] === 4,
  Ts = (e) =>
    new TextDecoder(
      e[0] === 255 && e[1] === 254
        ? "utf-16le"
        : e[0] === 254 && e[1] === 255
          ? "utf-16be"
          : "utf-8",
    ).decode(e),
  ll = (e) =>
    Object.fromEntries(Object.entries(e).filter(([, t]) => t !== void 0)),
  cl = (e, t, r) => {
    const n = e.get(Oe(t)),
      s = Je(
        n &&
          pt(_e(bt(Ts(n)), "Relationships")).find((a) => {
            var o;
            return r.has((o = Je(a, "Type")) !== null && o !== void 0 ? o : "");
          }),
        "Target",
      );
    return s === void 0 ? void 0 : mt(t, s);
  },
  ul = (e, t) => cl(e, t, Cf),
  kf = (e) => {
    const t = xr(e, (a) => a.endsWith(".rels")),
      r = cl(t, "", If);
    if (r === void 0)
      throw new Error(
        "Invalid file: a zip file that isn't a Word, PowerPoint or Excel file or an Office theme (.thmx)",
      );
    const n = ul(t, r),
      s = n === void 0 ? void 0 : [...xr(e, (a) => Qi(a, n)).values()][0];
    if (s === void 0)
      throw new Error(
        `The file has no theme: its main part, ${r}, refers to none`,
      );
    return Ts(s);
  },
  Rf = (e, t, r) => {
    const [n] = pt(t),
      s =
        qe(n) === "srgbClr"
          ? Je(n, "val")
          : qe(n) === "sysClr" && (r || Je(n, "val") !== Af.get(e))
            ? Je(n, "lastClr")
            : void 0;
    return s !== void 0 && /^[0-9A-Fa-f]{6}$/.test(s)
      ? s.toUpperCase()
      : void 0;
  },
  Bn = (e, t = !1) =>
    Object.fromEntries(
      pt(e).flatMap((r) => {
        const n = Sf.get(qe(r)),
          s = n && Rf(n, r, t);
        return n && s ? [[n, s]] : [];
      }),
    ),
  Pf = (e) => {
    const [t] = pt(bt(e)),
      r = qe(t) === "theme" ? _e(_e(t, "themeElements"), "clrScheme") : void 0;
    return r ? Bn(r, !0) : {};
  },
  mn = (e) => Je(e, "typeface") || void 0,
  ba = (e) => {
    const t = pt(e)
      .filter((r) => qe(r) === "font")
      .flatMap((r) => {
        const n = Je(r, "script"),
          s = Je(r, "typeface");
        return n && s !== void 0 ? [[n, s]] : [];
      });
    return ll({
      latin: mn(_e(e, "latin")),
      eastAsia: mn(_e(e, "ea")),
      complexScript: mn(_e(e, "cs")),
      scripts: t.length > 0 ? Object.fromEntries(t) : void 0,
    });
  },
  Ta = (e) => ({
    headings: ba(_e(e, "majorFont")),
    body: ba(_e(e, "minorFont")),
  }),
  Of = (e) => {
    if (typeof e == "string") return e;
    const t = ArrayBuffer.isView(e)
      ? new Uint8Array(e.buffer, e.byteOffset, e.byteLength)
      : new Uint8Array(e);
    return Nf(t) ? kf(t) : Ts(t);
  },
  Fy = (e) => {
    const [t] = pt(bt(Of(e)));
    if (qe(t) === "clrScheme") return { colors: Bn(t) };
    if (qe(t) === "fontScheme") return { fonts: Ta(t) };
    if (qe(t) !== "theme") {
      var r;
      throw new Error(
        `Invalid theme: expected the XML of a theme, such as a document's word/theme/theme1.xml, but its root element is ${(r = t?.name) !== null && r !== void 0 ? r : "missing"}`,
      );
    }
    const n = _e(t, "themeElements"),
      s = _e(n, "clrScheme"),
      a = _e(n, "fontScheme");
    return ll({
      name: Je(t, "name") || void 0,
      colors: s && Bn(s),
      fonts: a && Ta(a),
    });
  },
  _f = [208, 207, 17, 224, 161, 177, 26, 225],
  $y = class {
    constructor(e) {
      var t, r, n, s, a, o, i, l, c, u, d, h, w, m;
      if (
        (p(this, "currentRelationshipId", 1),
        p(this, "documentWrapper", void 0),
        p(this, "headers", []),
        p(this, "footers", []),
        p(this, "coreProperties", void 0),
        p(this, "numbering", void 0),
        p(this, "media", void 0),
        p(this, "fileRelationships", void 0),
        p(this, "footnotesWrapper", void 0),
        p(this, "endnotesWrapper", void 0),
        p(this, "settings", void 0),
        p(this, "contentTypes", void 0),
        p(this, "customProperties", void 0),
        p(this, "appProperties", void 0),
        p(this, "styles", void 0),
        p(this, "comments", void 0),
        p(this, "commentsExtended", void 0),
        p(this, "commentsIds", void 0),
        p(this, "fontWrapper", void 0),
        p(this, "theme", void 0),
        p(this, "packageParts", void 0),
        p(this, "macros", void 0),
        p(this, "bibliography", void 0),
        e.macros !== void 0)
      ) {
        const { project: b, events: R = [] } = e.macros,
          O = b instanceof Uint8Array ? b : new Uint8Array(b);
        if (!_f.every((T, S) => O[S] === T))
          throw new Error(
            "macros.project isn't a VBA project. Use createMacros from docx/macros, or the word/vbaProject.bin in a .docm rather than the .docm itself",
          );
        const E = new se();
        (R.length > 0 &&
          E.addRelationship(
            1,
            "http://schemas.microsoft.com/office/2006/relationships/wordVbaData",
            "vbaData.xml",
          ),
          (this.macros = {
            project: O,
            events: R.length > 0 ? Cp(R) : void 0,
            relationships: E,
          }));
      }
      if (
        ((this.coreProperties = new wp(
          f(
            f({}, e),
            {},
            {
              creator:
                (t = e.creator) !== null && t !== void 0 ? t : "Un-named",
              revision: (r = e.revision) !== null && r !== void 0 ? r : 1,
              lastModifiedBy:
                (n = e.lastModifiedBy) !== null && n !== void 0
                  ? n
                  : "Un-named",
            },
          ),
        )),
        (this.numbering = new Hi(e.numbering ? e.numbering : { config: [] })),
        (this.comments = new uh(
          (s = e.comments) !== null && s !== void 0 ? s : { children: [] },
        )),
        this.comments.ThreadData &&
          (this.commentsExtended = new fh(this.comments.ThreadData)),
        this.comments.CommentIdsData &&
          (this.commentsIds = new xh(this.comments.CommentIdsData)),
        (this.fileRelationships = new se()),
        (this.customProperties = new Ep(
          (a = e.customProperties) !== null && a !== void 0 ? a : [],
        )),
        (this.appProperties = new pp()),
        (this.footnotesWrapper = new Up()),
        (this.endnotesWrapper = new Dp()),
        (this.contentTypes = new fp({ macros: this.macros !== void 0 })),
        ((o = this.macros) === null || o === void 0 ? void 0 : o.events) !==
          void 0 &&
          this.contentTypes.addOverride(
            "application/vnd.ms-word.vbaData+xml",
            "/word/vbaData.xml",
          ),
        e.bibliography !== void 0)
      ) {
        const b = new se();
        (b.addRelationship(
          1,
          "http://schemas.openxmlformats.org/officeDocument/2006/relationships/customXmlProps",
          "itemProps1.xml",
        ),
          (this.bibliography = {
            sources: e.bibliography.sources,
            properties: Ap(`{${xo().toUpperCase()}}`),
            relationships: b,
          }),
          this.contentTypes.addOverride(
            "application/vnd.openxmlformats-officedocument.customXmlProperties+xml",
            "/customXml/itemProps1.xml",
          ));
      }
      if (
        ((this.packageParts = new Bi(this.contentTypes)),
        (this.documentWrapper = new Rp({
          background: e.background,
          pageNumbers: e.pageNumbers,
        })),
        (this.settings = new xv({
          compatibilityModeVersion: e.compatabilityModeVersion,
          compatibility: e.compatibility,
          evenAndOddHeaders: !!e.evenAndOddHeaderAndFooters,
          trackRevisions:
            (i = e.features) === null || i === void 0
              ? void 0
              : i.trackRevisions,
          updateFields:
            (l = e.features) === null || l === void 0 ? void 0 : l.updateFields,
          embedFonts:
            !((c = e.fonts) === null || c === void 0) && c.length ? !0 : void 0,
          defaultTabStop: e.defaultTabStop,
          protection: e.protection,
          hyphenation: {
            autoHyphenation:
              (u = e.hyphenation) === null || u === void 0
                ? void 0
                : u.autoHyphenation,
            hyphenationZone:
              (d = e.hyphenation) === null || d === void 0
                ? void 0
                : d.hyphenationZone,
            consecutiveHyphenLimit:
              (h = e.hyphenation) === null || h === void 0
                ? void 0
                : h.consecutiveHyphenLimit,
            doNotHyphenateCaps:
              (w = e.hyphenation) === null || w === void 0
                ? void 0
                : w.doNotHyphenateCaps,
          },
        })),
        (this.media = new Fi((b) =>
          this.packageParts.takePath("media", "image", b),
        )),
        e.externalStyles !== void 0)
      ) {
        var v, g, A, I;
        const b =
            (v =
              (g = e.styles) === null || g === void 0 ? void 0 : g.default) !==
              null && v !== void 0
              ? v
              : {},
          R = Object.entries(gs(b)),
          O = ([T]) => b[T] !== void 0,
          E = new Gv().newInstance(e.externalStyles);
        this.styles = new rn(
          f(
            f({}, E),
            {},
            {
              paragraphStyles:
                (A = e.styles) === null || A === void 0
                  ? void 0
                  : A.paragraphStyles,
              characterStyles:
                (I = e.styles) === null || I === void 0
                  ? void 0
                  : I.characterStyles,
              importedStyles: [
                ...R.filter((T) => !O(T)).map(([, T]) => T),
                ...E.importedStyles,
                ...R.filter(O).map(([, T]) => T),
              ],
            },
          ),
        );
      } else if (e.styles) {
        const b = new da().newInstance(e.styles.default);
        this.styles = new rn(f(f({}, b), e.styles));
      } else {
        const b = new da();
        this.styles = new rn(b.newInstance());
      }
      this.addDefaultRelationships();
      for (const b of e.sections) this.addSection(b);
      if (e.footnotes)
        for (const b in e.footnotes)
          this.footnotesWrapper.View.createFootNote(
            parseFloat(b),
            e.footnotes[b].children,
          );
      if (e.endnotes)
        for (const b in e.endnotes)
          this.endnotesWrapper.View.createEndnote(
            parseFloat(b),
            e.endnotes[b].children,
          );
      ((this.fontWrapper = new mi(
        (m = e.fonts) !== null && m !== void 0 ? m : [],
      )),
        (this.theme = new Zv(e.theme)),
        this.documentWrapper.Relationships.addRelationship(
          this.currentRelationshipId++,
          "http://schemas.openxmlformats.org/officeDocument/2006/relationships/theme",
          "theme/theme1.xml",
        ),
        this.macros !== void 0 &&
          this.documentWrapper.Relationships.addRelationship(
            this.currentRelationshipId++,
            "http://schemas.microsoft.com/office/2006/relationships/vbaProject",
            "vbaProject.bin",
          ),
        this.bibliography !== void 0 &&
          this.documentWrapper.Relationships.addRelationship(
            this.currentRelationshipId++,
            "http://schemas.openxmlformats.org/officeDocument/2006/relationships/customXml",
            "../customXml/item1.xml",
          ));
    }
    addSection({
      headers: e = {},
      footers: t = {},
      children: r,
      properties: n,
    }) {
      this.documentWrapper.View.Body.addSection(
        f(
          f({}, n),
          {},
          {
            headerWrapperGroup: {
              default: e.default ? this.createHeader(e.default) : void 0,
              first: e.first ? this.createHeader(e.first) : void 0,
              even: e.even ? this.createHeader(e.even) : void 0,
            },
            footerWrapperGroup: {
              default: t.default ? this.createFooter(t.default) : void 0,
              first: t.first ? this.createFooter(t.first) : void 0,
              even: t.even ? this.createFooter(t.even) : void 0,
            },
          },
        ),
      );
      for (const s of r) this.documentWrapper.View.add(s);
    }
    createHeader(e) {
      const t = new Vp(this.media, this.currentRelationshipId++);
      for (const r of e.options.children) t.add(r);
      return (this.addHeaderToDocument(t), t);
    }
    createFooter(e) {
      const t = new $p(this.media, this.currentRelationshipId++);
      for (const r of e.options.children) t.add(r);
      return (this.addFooterToDocument(t), t);
    }
    addHeaderToDocument(e, t = yt.DEFAULT) {
      (this.headers.push({ header: e, type: t }),
        this.documentWrapper.Relationships.addRelationship(
          e.View.ReferenceId,
          "http://schemas.openxmlformats.org/officeDocument/2006/relationships/header",
          `header${this.headers.length}.xml`,
        ),
        this.contentTypes.addHeader(this.headers.length));
    }
    addFooterToDocument(e, t = yt.DEFAULT) {
      (this.footers.push({ footer: e, type: t }),
        this.documentWrapper.Relationships.addRelationship(
          e.View.ReferenceId,
          "http://schemas.openxmlformats.org/officeDocument/2006/relationships/footer",
          `footer${this.footers.length}.xml`,
        ),
        this.contentTypes.addFooter(this.footers.length));
    }
    addDefaultRelationships() {
      (this.fileRelationships.addRelationship(
        1,
        "http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument",
        "word/document.xml",
      ),
        this.fileRelationships.addRelationship(
          2,
          "http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties",
          "docProps/core.xml",
        ),
        this.fileRelationships.addRelationship(
          3,
          "http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties",
          "docProps/app.xml",
        ),
        this.fileRelationships.addRelationship(
          4,
          "http://schemas.openxmlformats.org/officeDocument/2006/relationships/custom-properties",
          "docProps/custom.xml",
        ),
        this.documentWrapper.Relationships.addRelationship(
          this.currentRelationshipId++,
          "http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles",
          "styles.xml",
        ),
        this.documentWrapper.Relationships.addRelationship(
          this.currentRelationshipId++,
          "http://schemas.openxmlformats.org/officeDocument/2006/relationships/numbering",
          "numbering.xml",
        ),
        this.documentWrapper.Relationships.addRelationship(
          this.currentRelationshipId++,
          "http://schemas.openxmlformats.org/officeDocument/2006/relationships/footnotes",
          "footnotes.xml",
        ),
        this.documentWrapper.Relationships.addRelationship(
          this.currentRelationshipId++,
          "http://schemas.openxmlformats.org/officeDocument/2006/relationships/endnotes",
          "endnotes.xml",
        ),
        this.documentWrapper.Relationships.addRelationship(
          this.currentRelationshipId++,
          "http://schemas.openxmlformats.org/officeDocument/2006/relationships/settings",
          "settings.xml",
        ),
        this.comments.IsEmpty ||
          (this.documentWrapper.Relationships.addRelationship(
            this.currentRelationshipId++,
            "http://schemas.openxmlformats.org/officeDocument/2006/relationships/comments",
            "comments.xml",
          ),
          this.contentTypes.addComments()),
        this.commentsExtended &&
          (this.documentWrapper.Relationships.addRelationship(
            this.currentRelationshipId++,
            "http://schemas.microsoft.com/office/2011/relationships/commentsExtended",
            "commentsExtended.xml",
          ),
          this.contentTypes.addCommentsExtended()),
        this.commentsIds &&
          (this.documentWrapper.Relationships.addRelationship(
            this.currentRelationshipId++,
            "http://schemas.microsoft.com/office/2016/09/relationships/commentsIds",
            "commentsIds.xml",
          ),
          this.contentTypes.addCommentsIds()));
    }
    get Document() {
      return this.documentWrapper;
    }
    get Styles() {
      return this.styles;
    }
    get CoreProperties() {
      return this.coreProperties;
    }
    get Numbering() {
      return this.numbering;
    }
    get Media() {
      return this.media;
    }
    get FileRelationships() {
      return this.fileRelationships;
    }
    get Headers() {
      return this.headers.map((e) => e.header);
    }
    get Footers() {
      return this.footers.map((e) => e.footer);
    }
    get ContentTypes() {
      return this.contentTypes;
    }
    get CustomProperties() {
      return this.customProperties;
    }
    get AppProperties() {
      return this.appProperties;
    }
    get FootNotes() {
      return this.footnotesWrapper;
    }
    get Endnotes() {
      return this.endnotesWrapper;
    }
    get Settings() {
      return this.settings;
    }
    get Comments() {
      return this.comments;
    }
    get CommentsExtended() {
      return this.commentsExtended;
    }
    get CommentsIds() {
      return this.commentsIds;
    }
    get FontTable() {
      return this.fontWrapper;
    }
    get Theme() {
      return this.theme;
    }
    get PackageParts() {
      return this.packageParts;
    }
    get Macros() {
      return this.macros;
    }
    get Bibliography() {
      return this.bibliography;
    }
  },
  dl = class extends y {
    constructor(e) {
      (super("w:sdtPr"), e && this.root.push(new $e("w:alias", e)));
    }
  },
  Lf = (e) =>
    new x({
      name: "w:docPartObj",
      children: [
        new $e("w:docPartGallery", e),
        new x({ name: "w:docPartUnique" }),
      ],
    }),
  Df = ["contentChildren", "cachedEntries", "beginDirty", "tabLeader"],
  Hy = class extends Or {
    constructor(e = "Table of Contents", t = {}) {
      let {
          contentChildren: r = [],
          cachedEntries: n = [],
          beginDirty: s,
          tabLeader: a = Ah.DOT,
        } = t,
        o = jt(t, Df);
      (super("w:sdt"), p(this, "fromHeadings", void 0));
      const i = new dl(e);
      (i.addChildElement(Lf("Table of Contents")), this.root.push(i));
      const l = new ls(),
        c = [new te({ children: [qo(s), new Yo(o), Re()] })],
        u = [new te({ children: [Se()] })];
      if (n !== void 0 && n.length > 0) {
        const { stylesWithLevels: d } = o,
          h = n.map((m, v) => {
            var g, A;
            const I = this.buildCachedContentParagraphChild(m, o),
              b =
                (g =
                  d == null ||
                  (A = d.find((O) => O.level === m.level)) === null ||
                  A === void 0
                    ? void 0
                    : A.styleName) !== null && g !== void 0
                  ? g
                  : `TOC${m.level}`,
              R = v === 0 ? [...c, I] : v === n.length - 1 ? [I, ...u] : [I];
            return new me({
              style: b,
              tabStops: this.getTabStopsForLevel(m.level, a),
              children: R,
            });
          });
        let w = h;
        n.length <= 1 && (w = [...h, new me({ children: u })]);
        for (const m of w) l.addChildElement(m);
      } else {
        const d = new me({ children: c });
        l.addChildElement(d);
        for (const w of r) l.addChildElement(w);
        const h = new me({ children: u });
        (l.addChildElement(h),
          r.length === 0 &&
            (this.fromHeadings = {
              properties: o,
              beginDirty: s,
              tabLeader: a,
            }));
      }
      this.root.push(l);
    }
    prepForXml(e) {
      const t = super.prepForXml(e);
      return (
        Md(
          t,
          this.fromHeadings &&
            f(f({}, this.fromHeadings), {}, { textWidth: this.textWidthIn(e) }),
        ),
        t
      );
    }
    textWidthIn(e) {
      var t, r;
      return (t =
        (r = e.file) === null ||
        r === void 0 ||
        (r = r.Document) === null ||
        r === void 0 ||
        (r = r.View.Body.getSectionPropertiesFor(this)) === null ||
        r === void 0
          ? void 0
          : r.AvailableTextWidth) !== null && t !== void 0
        ? t
        : cr;
    }
    getTabStopsForLevel(e, t, r = 9025) {
      return [
        { type: "clear", position: r + 1 - (e - 1) * 240 },
        { type: "right", position: r, leader: t },
      ];
    }
    buildCachedContentRun(e, t) {
      var r, n;
      return new te({
        style: t?.hyperlink && e.href !== void 0 ? "IndexLink" : void 0,
        children: [
          new Ft({ text: e.title }),
          new Pr(),
          new Ft({
            text:
              (r =
                (n = e.page) === null || n === void 0
                  ? void 0
                  : n.toString()) !== null && r !== void 0
                ? r
                : "",
          }),
        ],
      });
    }
    buildCachedContentParagraphChild(e, t) {
      const r = this.buildCachedContentRun(e, t);
      return t?.hyperlink && e.href !== void 0
        ? new ii({ anchor: e.href, children: [r] })
        : r;
    }
  },
  By = class {
    constructor(e, t) {
      (p(this, "styleName", void 0),
        p(this, "level", void 0),
        (this.styleName = e),
        (this.level = t));
    }
  },
  Wy = class {
    constructor(e = { children: [] }) {
      (p(this, "options", void 0), (this.options = e));
    }
  },
  Uy = class {
    constructor(e = { children: [] }) {
      (p(this, "options", void 0), (this.options = e));
    }
  },
  Mf = class extends _ {
    constructor(...e) {
      (super(...e), p(this, "xmlKeys", { id: "w:id" }));
    }
  },
  Ea = class extends y {
    constructor(e) {
      (super("w:footnoteReference"), this.root.push(new Mf({ id: e })));
    }
  },
  Gy = class extends te {
    constructor(e) {
      (super({ style: "FootnoteReference" }),
        p(this, "footnote", void 0),
        typeof e == "number" ? this.root.push(new Ea(e)) : (this.footnote = e));
    }
    prepForXml(e) {
      var t;
      if (this.footnote === void 0) return super.prepForXml(e);
      const r =
        (t = e.file) === null || t === void 0
          ? void 0
          : t.FootNotes.View.idOf(this, this.footnote, e);
      if (r !== void 0) {
        this.root.push(new Ea(r));
        try {
          return super.prepForXml(e);
        } finally {
          this.root.pop();
        }
      }
    }
  },
  Ff = class extends _ {
    constructor(...e) {
      (super(...e), p(this, "xmlKeys", { id: "w:id" }));
    }
  },
  Sa = class extends y {
    constructor(e) {
      (super("w:endnoteReference"), this.root.push(new Ff({ id: e })));
    }
  },
  jy = class extends te {
    constructor(e) {
      (super({ style: "EndnoteReference" }),
        p(this, "endnote", void 0),
        typeof e == "number" ? this.root.push(new Sa(e)) : (this.endnote = e));
    }
    prepForXml(e) {
      var t;
      if (this.endnote === void 0) return super.prepForXml(e);
      const r =
        (t = e.file) === null || t === void 0
          ? void 0
          : t.Endnotes.View.idOf(this, this.endnote, e);
      if (r !== void 0) {
        this.root.push(new Sa(r));
        try {
          return super.prepForXml(e);
        } finally {
          this.root.pop();
        }
      }
    }
  },
  Aa = class extends _ {
    constructor(...e) {
      (super(...e),
        p(this, "xmlKeys", { val: "w14:val", symbolfont: "w14:font" }));
    }
  },
  pn = class extends y {
    constructor(e, t, r) {
      (super(e),
        r
          ? this.root.push(new Aa({ val: sc(t), symbolfont: r }))
          : this.root.push(new Aa({ val: t })));
    }
  },
  $f = class extends y {
    constructor(e) {
      var t, r, n, s, a, o, i, l;
      (super("w14:checkbox"),
        p(this, "DEFAULT_UNCHECKED_SYMBOL", "2610"),
        p(this, "DEFAULT_CHECKED_SYMBOL", "2612"),
        p(this, "DEFAULT_FONT", "MS Gothic"));
      const c = e?.checked ? "1" : "0";
      let u, d;
      (this.root.push(new pn("w14:checked", c)),
        (u =
          !(e == null || (t = e.checkedState) === null || t === void 0) &&
          t.value
            ? e == null || (r = e.checkedState) === null || r === void 0
              ? void 0
              : r.value
            : this.DEFAULT_CHECKED_SYMBOL),
        (d =
          !(e == null || (n = e.checkedState) === null || n === void 0) &&
          n.font
            ? e == null || (s = e.checkedState) === null || s === void 0
              ? void 0
              : s.font
            : this.DEFAULT_FONT),
        this.root.push(new pn("w14:checkedState", u, d)),
        (u =
          !(e == null || (a = e.uncheckedState) === null || a === void 0) &&
          a.value
            ? e == null || (o = e.uncheckedState) === null || o === void 0
              ? void 0
              : o.value
            : this.DEFAULT_UNCHECKED_SYMBOL),
        (d =
          !(e == null || (i = e.uncheckedState) === null || i === void 0) &&
          i.font
            ? e == null || (l = e.uncheckedState) === null || l === void 0
              ? void 0
              : l.font
            : this.DEFAULT_FONT),
        this.root.push(new pn("w14:uncheckedState", u, d)));
    }
  },
  Vy = class extends y {
    constructor(e) {
      var t, r, n, s;
      (super("w:sdt"),
        p(this, "DEFAULT_UNCHECKED_SYMBOL", "2610"),
        p(this, "DEFAULT_CHECKED_SYMBOL", "2612"),
        p(this, "DEFAULT_FONT", "MS Gothic"));
      const a = new dl(e?.alias);
      (a.addChildElement(new $f(e)), this.root.push(a));
      const o = new ls(),
        i =
          e == null || (t = e.checkedState) === null || t === void 0
            ? void 0
            : t.font,
        l =
          e == null || (r = e.checkedState) === null || r === void 0
            ? void 0
            : r.value,
        c =
          e == null || (n = e.uncheckedState) === null || n === void 0
            ? void 0
            : n.font,
        u =
          e == null || (s = e.uncheckedState) === null || s === void 0
            ? void 0
            : s.value;
      let d, h;
      e?.checked
        ? ((d = i || this.DEFAULT_FONT), (h = l || this.DEFAULT_CHECKED_SYMBOL))
        : ((d = c || this.DEFAULT_FONT),
          (h = u || this.DEFAULT_UNCHECKED_SYMBOL));
      const w = new du({ char: h, symbolfont: d });
      (o.addChildElement(w), this.root.push(o));
    }
  },
  vn = (e) => (e === void 0 ? void 0 : e ? "t" : "f"),
  Hf = ({ children: e }) => new x({ name: "w:pict", children: e }),
  Bf = {
    flip: "flip",
    height: "height",
    left: "left",
    marginBottom: "margin-bottom",
    marginLeft: "margin-left",
    marginRight: "margin-right",
    marginTop: "margin-top",
    positionHorizontal: "mso-position-horizontal",
    positionHorizontalRelative: "mso-position-horizontal-relative",
    positionVertical: "mso-position-vertical",
    positionVerticalRelative: "mso-position-vertical-relative",
    wrapDistanceBottom: "mso-wrap-distance-bottom",
    wrapDistanceLeft: "mso-wrap-distance-left",
    wrapDistanceRight: "mso-wrap-distance-right",
    wrapDistanceTop: "mso-wrap-distance-top",
    wrapEdited: "mso-wrap-edited",
    wrapStyle: "mso-wrap-style",
    position: "position",
    rotation: "rotation",
    top: "top",
    visibility: "visibility",
    width: "width",
    zIndex: "z-index",
  },
  Wf = (e) =>
    e
      ? Object.entries(e)
          .filter(([, t]) => t !== void 0)
          .map(([t, r]) => `${Bf[t]}:${r}`)
          .join(";")
      : void 0,
  Uf = ({
    id: e,
    type: t,
    style: r,
    coordinateSize: n,
    adjustment: s,
    path: a,
    presetShapeType: o,
    allowInCell: i,
    alt: l,
    title: c,
    fillColor: u,
    filled: d,
    stroked: h,
    strokeColor: w,
    strokeWeight: m,
    children: v = [],
  }) =>
    new x({
      name: "v:shape",
      attributes: {
        id: { key: "id", value: e },
        type: { key: "type", value: t },
        style: { key: "style", value: Wf(r) },
        coordinateSize: { key: "coordsize", value: n },
        adjustment: { key: "adj", value: s },
        path: { key: "path", value: a },
        presetShapeType: { key: "o:spt", value: o },
        allowInCell: { key: "o:allowincell", value: vn(i) },
        alt: { key: "alt", value: l },
        title: { key: "title", value: c },
        fillColor: { key: "fillcolor", value: u },
        filled: { key: "filled", value: vn(d) },
        stroked: { key: "stroked", value: vn(h) },
        strokeColor: { key: "strokecolor", value: w },
        strokeWeight: { key: "strokeweight", value: m },
      },
      children: v,
    }),
  Gf = ({ shape: e }) => Hf({ children: [e] }),
  jf = ({ children: e = [] }) => new x({ name: "w:txbxContent", children: e }),
  Vf = ({ style: e, children: t, inset: r }) =>
    new x({
      name: "v:textbox",
      attributes: {
        style: { key: "style", value: e },
        inset: {
          key: "inset",
          value: r ? `${r.left}, ${r.top}, ${r.right}, ${r.bottom}` : void 0,
        },
      },
      children: [jf({ children: t })],
    }),
  Xf = "#_x0000_t202",
  Kf = "1in",
  zf = (e) =>
    e && (e.height === void 0 || e.height === "auto")
      ? f(f({}, e), {}, { height: Kf })
      : e,
  Yf = ({ id: e, children: t, type: r = Xf, style: n }) =>
    Uf({
      id: e,
      type: r,
      style: zf(n),
      children: [Vf({ style: "mso-fit-shape-to-text:t;", children: t })],
    }),
  qf = ["style", "children"],
  Xy = class extends Or {
    constructor(e) {
      let { style: t, children: r } = e,
        n = jt(e, qf);
      (super("w:p"),
        p(this, "run", void 0),
        this.root.push(new dt(n)),
        (this.run = new x({
          name: "w:r",
          children: [Gf({ shape: Yf({ children: r, id: at(), style: t }) })],
        })),
        this.root.push(this.run));
    }
    prepForXml(e) {
      return Gt(e.stack[e.stack.length - 1]) === "w:p"
        ? this.run.prepForXml(e)
        : super.prepForXml(e);
    }
  },
  kt = 0,
  fn = 32,
  Jf = 32,
  Zf = (e, t) => {
    const r = t.replace(/-/g, "");
    if (r.length !== Jf)
      throw new Error(`Error: Cannot extract GUID from font filename: ${t}`);
    const n = r
      .replace(/(..)/g, "$1 ")
      .trim()
      .split(" ")
      .map((o) => parseInt(o, 16));
    n.reverse();
    const s = e.slice(kt, fn).map((o, i) => o ^ n[i % n.length]),
      a = new Uint8Array(kt + s.length + Math.max(0, e.length - fn));
    return (
      a.set(e.slice(0, kt)),
      a.set(s, kt),
      a.set(e.slice(fn), kt + s.length),
      a
    );
  },
  vt = class {
    format(e, t = { stack: [] }) {
      const r = e.prepForXml(t);
      if (r) return r;
      throw Error("XMLComponent did not format correctly");
    }
  },
  hl = /\{([^{}]+)\}/g,
  ml = (e, t) =>
    t.size === 0
      ? e
      : e.replace(hl, (r, n) => {
          var s;
          return (s = t.get(n)) !== null && s !== void 0 ? s : r;
        }),
  Qf = (e) => new Set(Array.from(e.matchAll(hl), ([, t]) => t)),
  pl = class {
    replace(e, t, r) {
      return ml(e, new Map(t.map((n, s) => [n.key, (r + s).toString()])));
    }
    getMediaData(e, t) {
      const r = Qf(e);
      return t.Entries.filter(([n]) => r.has(n)).map(
        ([n, { fileName: s }]) => ({ key: n, fileName: s }),
      );
    }
  },
  ew = class {
    replace(e, t) {
      return ml(
        e,
        new Map(
          t.map(
            ({ reference: r, instance: n, restartedListId: s, numId: a }) => [
              fr(r, n, s),
              a.toString(),
            ],
          ),
        ),
      );
    }
  },
  tw = new vt(),
  wn = (e, t, r, n, s = !0) =>
    $(
      tw.format(t, {
        viewWrapper: { View: t, Relationships: n },
        file: e,
        stack: [],
      }),
      {
        indent: r,
        declaration: s
          ? { standalone: "yes", encoding: "UTF-8" }
          : { encoding: "UTF-8" },
      },
    ),
  rw = (e, t, r, n) => {
    const { content: s } = t.options;
    if (s instanceof Uint8Array) return [{ data: s, path: `word/${r}` }];
    if ("files" in s)
      return [
        {
          data: yr(
            s.files.map(({ path: c, content: u }) => [
              c,
              u instanceof Uint8Array ? u : wn(e, u, n, new se()),
            ]),
          ),
          path: `word/${r}`,
        },
      ];
    const a = e.PackageParts.createRelationships(r),
      o = wn(e, s, n, a),
      i = r.slice(0, r.lastIndexOf("/")),
      l = r.slice(r.lastIndexOf("/") + 1);
    return [
      { data: o, path: `word/${r}` },
      ...(a.RelationshipCount > 0
        ? [{ data: wn(e, a, n, a, !1), path: `word/${i}/_rels/${l}.rels` }]
        : []),
    ];
  },
  Es = (e, t, r = 0) => {
    const n = e.PackageParts.Array.slice(r);
    return n.length === 0
      ? []
      : [
          ...n.flatMap(({ part: s, path: a }) => rw(e, s, a, t)),
          ...Es(e, t, r + n.length),
        ];
  },
  nw = ["PackageParts"],
  sw = class {
    constructor() {
      (p(this, "formatter", void 0),
        p(this, "imageReplacer", void 0),
        p(this, "numberingReplacer", void 0),
        (this.formatter = new vt()),
        (this.imageReplacer = new pl()),
        (this.numberingReplacer = new ew()));
    }
    compile(e, t, r = []) {
      const n = this.xmlifyFile(e, t),
        { PackageParts: s } = n,
        a = jt(n, nw),
        o = Object.values(a).flatMap((i) => (Array.isArray(i) ? i : [i]));
      return new Map([
        ...o.map(({ path: i, data: l }) => [i, l]),
        ...s.map(({ path: i, data: l }) => [i, l]),
        ...r.map(({ path: i, data: l }) => [i, l]),
        ...(e.Macros === void 0
          ? []
          : [["word/vbaProject.bin", e.Macros.project]]),
        ...e.Media.Array.map((i) => [`word/media/${i.fileName}`, i.data]),
        ...e.FontTable.files.map(({ data: i, fontKey: l }, c) => [
          `word/fonts/font${c + 1}.odttf`,
          Zf(i, l),
        ]),
      ]);
    }
    xmlifyFile(e, t) {
      var r;
      const n = $(
          this.formatter.format(e.Document.View, {
            viewWrapper: e.Document,
            file: e,
            stack: [],
          }),
          { indent: t, declaration: { standalone: "yes", encoding: "UTF-8" } },
        ),
        s = $(
          this.formatter.format(e.Comments, {
            viewWrapper: {
              View: e.Comments,
              Relationships: e.Comments.Relationships,
            },
            file: e,
            stack: [],
          }),
          { indent: t, declaration: { standalone: "yes", encoding: "UTF-8" } },
        ),
        a = $(
          this.formatter.format(e.FootNotes.View, {
            viewWrapper: e.FootNotes,
            file: e,
            stack: [],
          }),
          { indent: t, declaration: { standalone: "yes", encoding: "UTF-8" } },
        ),
        o = $(
          this.formatter.format(e.Endnotes.View, {
            viewWrapper: e.Endnotes,
            file: e,
            stack: [],
          }),
          { indent: t, declaration: { encoding: "UTF-8" } },
        ),
        i = e.Document.Relationships.RelationshipCount + 1,
        l = e.Comments.Relationships.RelationshipCount + 1,
        c = e.FootNotes.Relationships.RelationshipCount + 1,
        u = e.Endnotes.Relationships.RelationshipCount + 1,
        d = this.imageReplacer.getMediaData(n, e.Media),
        h = this.imageReplacer.getMediaData(s, e.Media),
        w = this.imageReplacer.getMediaData(a, e.Media),
        m = this.imageReplacer.getMediaData(o, e.Media);
      return f(
        f(
          f(
            f(
              f(
                f(
                  {
                    Relationships: {
                      data: (() => {
                        const v = se.copy(e.Document.Relationships);
                        return (
                          d.forEach((g, A) => {
                            v.addRelationship(
                              i + A,
                              "http://schemas.openxmlformats.org/officeDocument/2006/relationships/image",
                              `media/${g.fileName}`,
                            );
                          }),
                          v.addRelationship(
                            v.RelationshipCount + 1,
                            "http://schemas.openxmlformats.org/officeDocument/2006/relationships/fontTable",
                            "fontTable.xml",
                          ),
                          $(
                            this.formatter.format(v, {
                              viewWrapper: e.Document,
                              file: e,
                              stack: [],
                            }),
                            { indent: t, declaration: { encoding: "UTF-8" } },
                          )
                        );
                      })(),
                      path: "word/_rels/document.xml.rels",
                    },
                    Document: {
                      data: (() => {
                        const v = this.imageReplacer.replace(n, d, i);
                        return this.numberingReplacer.replace(
                          v,
                          e.Numbering.ConcreteNumbering,
                        );
                      })(),
                      path: "word/document.xml",
                    },
                    Styles: {
                      data: (() => {
                        const v = $(
                          this.formatter.format(e.Styles, {
                            viewWrapper: e.Document,
                            file: e,
                            stack: [],
                          }),
                          {
                            indent: t,
                            declaration: {
                              standalone: "yes",
                              encoding: "UTF-8",
                            },
                          },
                        );
                        return this.numberingReplacer.replace(
                          v,
                          e.Numbering.ConcreteNumbering,
                        );
                      })(),
                      path: "word/styles.xml",
                    },
                    Properties: {
                      data: $(
                        this.formatter.format(e.CoreProperties, {
                          viewWrapper: e.Document,
                          file: e,
                          stack: [],
                        }),
                        {
                          indent: t,
                          declaration: { standalone: "yes", encoding: "UTF-8" },
                        },
                      ),
                      path: "docProps/core.xml",
                    },
                    FileRelationships: {
                      data: $(
                        this.formatter.format(e.FileRelationships, {
                          viewWrapper: e.Document,
                          file: e,
                          stack: [],
                        }),
                        { indent: t, declaration: { encoding: "UTF-8" } },
                      ),
                      path: "_rels/.rels",
                    },
                    HeaderRelationships: e.Headers.map((v, g) => {
                      const A = $(
                          this.formatter.format(v.View, {
                            viewWrapper: v,
                            file: e,
                            stack: [],
                          }),
                          { indent: t, declaration: { encoding: "UTF-8" } },
                        ),
                        I = this.imageReplacer.getMediaData(A, e.Media),
                        b = se.copy(v.Relationships);
                      return (
                        I.forEach((R, O) => {
                          b.addRelationship(
                            O,
                            "http://schemas.openxmlformats.org/officeDocument/2006/relationships/image",
                            `media/${R.fileName}`,
                          );
                        }),
                        {
                          data: $(
                            this.formatter.format(b, {
                              viewWrapper: v,
                              file: e,
                              stack: [],
                            }),
                            { indent: t, declaration: { encoding: "UTF-8" } },
                          ),
                          path: `word/_rels/header${g + 1}.xml.rels`,
                        }
                      );
                    }),
                    FooterRelationships: e.Footers.map((v, g) => {
                      const A = $(
                          this.formatter.format(v.View, {
                            viewWrapper: v,
                            file: e,
                            stack: [],
                          }),
                          { indent: t, declaration: { encoding: "UTF-8" } },
                        ),
                        I = this.imageReplacer.getMediaData(A, e.Media),
                        b = se.copy(v.Relationships);
                      return (
                        I.forEach((R, O) => {
                          b.addRelationship(
                            O,
                            "http://schemas.openxmlformats.org/officeDocument/2006/relationships/image",
                            `media/${R.fileName}`,
                          );
                        }),
                        {
                          data: $(
                            this.formatter.format(b, {
                              viewWrapper: v,
                              file: e,
                              stack: [],
                            }),
                            { indent: t, declaration: { encoding: "UTF-8" } },
                          ),
                          path: `word/_rels/footer${g + 1}.xml.rels`,
                        }
                      );
                    }),
                    Headers: e.Headers.map((v, g) => {
                      const A = $(
                          this.formatter.format(v.View, {
                            viewWrapper: v,
                            file: e,
                            stack: [],
                          }),
                          { indent: t, declaration: { encoding: "UTF-8" } },
                        ),
                        I = this.imageReplacer.getMediaData(A, e.Media),
                        b = this.imageReplacer.replace(A, I, 0);
                      return {
                        data: this.numberingReplacer.replace(
                          b,
                          e.Numbering.ConcreteNumbering,
                        ),
                        path: `word/header${g + 1}.xml`,
                      };
                    }),
                    Footers: e.Footers.map((v, g) => {
                      const A = $(
                          this.formatter.format(v.View, {
                            viewWrapper: v,
                            file: e,
                            stack: [],
                          }),
                          { indent: t, declaration: { encoding: "UTF-8" } },
                        ),
                        I = this.imageReplacer.getMediaData(A, e.Media),
                        b = this.imageReplacer.replace(A, I, 0);
                      return {
                        data: this.numberingReplacer.replace(
                          b,
                          e.Numbering.ConcreteNumbering,
                        ),
                        path: `word/footer${g + 1}.xml`,
                      };
                    }),
                    CustomProperties: {
                      data: $(
                        this.formatter.format(e.CustomProperties, {
                          viewWrapper: e.Document,
                          file: e,
                          stack: [],
                        }),
                        {
                          indent: t,
                          declaration: { standalone: "yes", encoding: "UTF-8" },
                        },
                      ),
                      path: "docProps/custom.xml",
                    },
                    AppProperties: {
                      data: $(
                        this.formatter.format(e.AppProperties, {
                          viewWrapper: e.Document,
                          file: e,
                          stack: [],
                        }),
                        {
                          indent: t,
                          declaration: { standalone: "yes", encoding: "UTF-8" },
                        },
                      ),
                      path: "docProps/app.xml",
                    },
                    FootNotes: {
                      data: (() => {
                        const v = this.imageReplacer.replace(a, w, c);
                        return this.numberingReplacer.replace(
                          v,
                          e.Numbering.ConcreteNumbering,
                        );
                      })(),
                      path: "word/footnotes.xml",
                    },
                    FootNotesRelationships: {
                      data: (() => {
                        const v = se.copy(e.FootNotes.Relationships);
                        return (
                          w.forEach((g, A) => {
                            v.addRelationship(
                              c + A,
                              "http://schemas.openxmlformats.org/officeDocument/2006/relationships/image",
                              `media/${g.fileName}`,
                            );
                          }),
                          $(
                            this.formatter.format(v, {
                              viewWrapper: e.FootNotes,
                              file: e,
                              stack: [],
                            }),
                            { indent: t, declaration: { encoding: "UTF-8" } },
                          )
                        );
                      })(),
                      path: "word/_rels/footnotes.xml.rels",
                    },
                    Endnotes: {
                      data: (() => {
                        const v = this.imageReplacer.replace(o, m, u);
                        return this.numberingReplacer.replace(
                          v,
                          e.Numbering.ConcreteNumbering,
                        );
                      })(),
                      path: "word/endnotes.xml",
                    },
                    EndnotesRelationships: {
                      data: (() => {
                        const v = se.copy(e.Endnotes.Relationships);
                        return (
                          m.forEach((g, A) => {
                            v.addRelationship(
                              u + A,
                              "http://schemas.openxmlformats.org/officeDocument/2006/relationships/image",
                              `media/${g.fileName}`,
                            );
                          }),
                          $(
                            this.formatter.format(v, {
                              viewWrapper: e.Endnotes,
                              file: e,
                              stack: [],
                            }),
                            { indent: t, declaration: { encoding: "UTF-8" } },
                          )
                        );
                      })(),
                      path: "word/_rels/endnotes.xml.rels",
                    },
                    Settings: {
                      data: $(
                        this.formatter.format(e.Settings, {
                          viewWrapper: e.Document,
                          file: e,
                          stack: [],
                        }),
                        {
                          indent: t,
                          declaration: { standalone: "yes", encoding: "UTF-8" },
                        },
                      ),
                      path: "word/settings.xml",
                    },
                  },
                  e.Comments.IsEmpty
                    ? {}
                    : {
                        Comments: {
                          data: (() => {
                            const v = this.imageReplacer.replace(s, h, l);
                            return this.numberingReplacer.replace(
                              v,
                              e.Numbering.ConcreteNumbering,
                            );
                          })(),
                          path: "word/comments.xml",
                        },
                        CommentsRelationships: {
                          data: (() => {
                            const v = se.copy(e.Comments.Relationships);
                            return (
                              h.forEach((g, A) => {
                                v.addRelationship(
                                  l + A,
                                  "http://schemas.openxmlformats.org/officeDocument/2006/relationships/image",
                                  `media/${g.fileName}`,
                                );
                              }),
                              $(
                                this.formatter.format(v, {
                                  viewWrapper: {
                                    View: e.Comments,
                                    Relationships: e.Comments.Relationships,
                                  },
                                  file: e,
                                  stack: [],
                                }),
                                {
                                  indent: t,
                                  declaration: { encoding: "UTF-8" },
                                },
                              )
                            );
                          })(),
                          path: "word/_rels/comments.xml.rels",
                        },
                      },
                ),
                e.CommentsExtended
                  ? {
                      CommentsExtended: {
                        data: $(
                          this.formatter.format(e.CommentsExtended, {
                            viewWrapper: {
                              View: e.CommentsExtended,
                              Relationships: e.Comments.Relationships,
                            },
                            file: e,
                            stack: [],
                          }),
                          {
                            indent: t,
                            declaration: {
                              standalone: "yes",
                              encoding: "UTF-8",
                            },
                          },
                        ),
                        path: "word/commentsExtended.xml",
                      },
                    }
                  : {},
              ),
              e.CommentsIds
                ? {
                    CommentsIds: {
                      data: $(
                        this.formatter.format(e.CommentsIds, {
                          viewWrapper: {
                            View: e.CommentsIds,
                            Relationships: e.Comments.Relationships,
                          },
                          file: e,
                          stack: [],
                        }),
                        {
                          indent: t,
                          declaration: { standalone: "yes", encoding: "UTF-8" },
                        },
                      ),
                      path: "word/commentsIds.xml",
                    },
                  }
                : {},
            ),
            {},
            {
              FontTable: {
                data: $(
                  this.formatter.format(e.FontTable.View, {
                    viewWrapper: e.Document,
                    file: e,
                    stack: [],
                  }),
                  {
                    indent: t,
                    declaration: { standalone: "yes", encoding: "UTF-8" },
                  },
                ),
                path: "word/fontTable.xml",
              },
              FontTableRelationships: {
                data: $(
                  this.formatter.format(e.FontTable.Relationships, {
                    viewWrapper: e.Document,
                    file: e,
                    stack: [],
                  }),
                  { indent: t, declaration: { encoding: "UTF-8" } },
                ),
                path: "word/_rels/fontTable.xml.rels",
              },
              Theme: {
                data: $(
                  this.formatter.format(e.Theme, {
                    viewWrapper: e.Document,
                    file: e,
                    stack: [],
                  }),
                  {
                    indent: t,
                    declaration: { standalone: "yes", encoding: "UTF-8" },
                  },
                ),
                path: "word/theme/theme1.xml",
              },
            },
            !((r = e.Macros) === null || r === void 0) && r.events
              ? {
                  MacroEvents: {
                    data: $(
                      this.formatter.format(e.Macros.events, {
                        viewWrapper: e.Document,
                        file: e,
                        stack: [],
                      }),
                      {
                        indent: t,
                        declaration: { standalone: "yes", encoding: "UTF-8" },
                      },
                    ),
                    path: "word/vbaData.xml",
                  },
                  MacroRelationships: {
                    data: $(
                      this.formatter.format(e.Macros.relationships, {
                        viewWrapper: e.Document,
                        file: e,
                        stack: [],
                      }),
                      { indent: t, declaration: { encoding: "UTF-8" } },
                    ),
                    path: "word/_rels/vbaProject.bin.rels",
                  },
                }
              : {},
          ),
          e.Bibliography
            ? {
                BibliographySources: {
                  data: $(
                    this.formatter.format(e.Bibliography.sources, {
                      viewWrapper: e.Document,
                      file: e,
                      stack: [],
                    }),
                    {
                      indent: t,
                      declaration: { standalone: "yes", encoding: "UTF-8" },
                    },
                  ),
                  path: "customXml/item1.xml",
                },
                BibliographySourcesProperties: {
                  data: $(
                    this.formatter.format(e.Bibliography.properties, {
                      viewWrapper: e.Document,
                      file: e,
                      stack: [],
                    }),
                    {
                      indent: t,
                      declaration: { standalone: "no", encoding: "UTF-8" },
                    },
                  ),
                  path: "customXml/itemProps1.xml",
                },
                BibliographySourcesRelationships: {
                  data: $(
                    this.formatter.format(e.Bibliography.relationships, {
                      viewWrapper: e.Document,
                      file: e,
                      stack: [],
                    }),
                    {
                      indent: t,
                      declaration: { standalone: "yes", encoding: "UTF-8" },
                    },
                  ),
                  path: "customXml/_rels/item1.xml.rels",
                },
              }
            : {},
        ),
        {},
        {
          PackageParts: Es(e, t),
          Numbering: {
            data: $(
              this.formatter.format(e.Numbering, {
                viewWrapper: e.Document,
                file: e,
                stack: [],
              }),
              {
                indent: t,
                declaration: { standalone: "yes", encoding: "UTF-8" },
              },
            ),
            path: "word/numbering.xml",
          },
          ContentTypes: {
            data: $(
              this.formatter.format(e.ContentTypes, {
                viewWrapper: e.Document,
                file: e,
                stack: [],
              }),
              { indent: t, declaration: { encoding: "UTF-8" } },
            ),
            path: "[Content_Types].xml",
          },
        },
      );
    }
  },
  Ia = Ul((e, t) => {
    var r = typeof Reflect == "object" ? Reflect : null,
      n =
        r && typeof r.apply == "function"
          ? r.apply
          : function (T, S, C) {
              return Function.prototype.apply.call(T, S, C);
            },
      s;
    r && typeof r.ownKeys == "function"
      ? (s = r.ownKeys)
      : Object.getOwnPropertySymbols
        ? (s = function (T) {
            return Object.getOwnPropertyNames(T).concat(
              Object.getOwnPropertySymbols(T),
            );
          })
        : (s = function (T) {
            return Object.getOwnPropertyNames(T);
          });
    function a(E) {
      console && console.warn && console.warn(E);
    }
    var o =
      Number.isNaN ||
      function (T) {
        return T !== T;
      };
    function i() {
      i.init.call(this);
    }
    ((t.exports = i),
      (t.exports.once = b),
      (i.EventEmitter = i),
      (i.prototype._events = void 0),
      (i.prototype._eventsCount = 0),
      (i.prototype._maxListeners = void 0));
    var l = 10;
    function c(E) {
      if (typeof E != "function")
        throw new TypeError(
          'The "listener" argument must be of type Function. Received type ' +
            typeof E,
        );
    }
    (Object.defineProperty(i, "defaultMaxListeners", {
      enumerable: !0,
      get: function () {
        return l;
      },
      set: function (E) {
        if (typeof E != "number" || E < 0 || o(E))
          throw new RangeError(
            'The value of "defaultMaxListeners" is out of range. It must be a non-negative number. Received ' +
              E +
              ".",
          );
        l = E;
      },
    }),
      (i.init = function () {
        ((this._events === void 0 ||
          this._events === Object.getPrototypeOf(this)._events) &&
          ((this._events = Object.create(null)), (this._eventsCount = 0)),
          (this._maxListeners = this._maxListeners || void 0));
      }),
      (i.prototype.setMaxListeners = function (T) {
        if (typeof T != "number" || T < 0 || o(T))
          throw new RangeError(
            'The value of "n" is out of range. It must be a non-negative number. Received ' +
              T +
              ".",
          );
        return ((this._maxListeners = T), this);
      }));
    function u(E) {
      return E._maxListeners === void 0
        ? i.defaultMaxListeners
        : E._maxListeners;
    }
    ((i.prototype.getMaxListeners = function () {
      return u(this);
    }),
      (i.prototype.emit = function (T) {
        for (var S = [], C = 1; C < arguments.length; C++) S.push(arguments[C]);
        var k = T === "error",
          L = this._events;
        if (L !== void 0) k = k && L.error === void 0;
        else if (!k) return !1;
        if (k) {
          var D;
          if ((S.length > 0 && (D = S[0]), D instanceof Error)) throw D;
          var j = new Error(
            "Unhandled error." + (D ? " (" + D.message + ")" : ""),
          );
          throw ((j.context = D), j);
        }
        var z = L[T];
        if (z === void 0) return !1;
        if (typeof z == "function") n(z, this, S);
        else
          for (var V = z.length, X = g(z, V), C = 0; C < V; ++C)
            n(X[C], this, S);
        return !0;
      }));
    function d(E, T, S, C) {
      var k, L, D;
      if (
        (c(S),
        (L = E._events),
        L === void 0
          ? ((L = E._events = Object.create(null)), (E._eventsCount = 0))
          : (L.newListener !== void 0 &&
              (E.emit("newListener", T, S.listener ? S.listener : S),
              (L = E._events)),
            (D = L[T])),
        D === void 0)
      )
        ((D = L[T] = S), ++E._eventsCount);
      else if (
        (typeof D == "function"
          ? (D = L[T] = C ? [S, D] : [D, S])
          : C
            ? D.unshift(S)
            : D.push(S),
        (k = u(E)),
        k > 0 && D.length > k && !D.warned)
      ) {
        D.warned = !0;
        var j = new Error(
          "Possible EventEmitter memory leak detected. " +
            D.length +
            " " +
            String(T) +
            " listeners added. Use emitter.setMaxListeners() to increase limit",
        );
        ((j.name = "MaxListenersExceededWarning"),
          (j.emitter = E),
          (j.type = T),
          (j.count = D.length),
          a(j));
      }
      return E;
    }
    ((i.prototype.addListener = function (T, S) {
      return d(this, T, S, !1);
    }),
      (i.prototype.on = i.prototype.addListener),
      (i.prototype.prependListener = function (T, S) {
        return d(this, T, S, !0);
      }));
    function h() {
      if (!this.fired)
        return (
          this.target.removeListener(this.type, this.wrapFn),
          (this.fired = !0),
          arguments.length === 0
            ? this.listener.call(this.target)
            : this.listener.apply(this.target, arguments)
        );
    }
    function w(E, T, S) {
      var C = { fired: !1, wrapFn: void 0, target: E, type: T, listener: S },
        k = h.bind(C);
      return ((k.listener = S), (C.wrapFn = k), k);
    }
    ((i.prototype.once = function (T, S) {
      return (c(S), this.on(T, w(this, T, S)), this);
    }),
      (i.prototype.prependOnceListener = function (T, S) {
        return (c(S), this.prependListener(T, w(this, T, S)), this);
      }),
      (i.prototype.removeListener = function (T, S) {
        var C, k, L, D, j;
        if ((c(S), (k = this._events), k === void 0)) return this;
        if (((C = k[T]), C === void 0)) return this;
        if (C === S || C.listener === S)
          --this._eventsCount === 0
            ? (this._events = Object.create(null))
            : (delete k[T],
              k.removeListener &&
                this.emit("removeListener", T, C.listener || S));
        else if (typeof C != "function") {
          for (L = -1, D = C.length - 1; D >= 0; D--)
            if (C[D] === S || C[D].listener === S) {
              ((j = C[D].listener), (L = D));
              break;
            }
          if (L < 0) return this;
          (L === 0 ? C.shift() : A(C, L),
            C.length === 1 && (k[T] = C[0]),
            k.removeListener !== void 0 &&
              this.emit("removeListener", T, j || S));
        }
        return this;
      }),
      (i.prototype.off = i.prototype.removeListener),
      (i.prototype.removeAllListeners = function (T) {
        var S,
          C = this._events,
          k;
        if (C === void 0) return this;
        if (C.removeListener === void 0)
          return (
            arguments.length === 0
              ? ((this._events = Object.create(null)), (this._eventsCount = 0))
              : C[T] !== void 0 &&
                (--this._eventsCount === 0
                  ? (this._events = Object.create(null))
                  : delete C[T]),
            this
          );
        if (arguments.length === 0) {
          var L = Object.keys(C),
            D;
          for (k = 0; k < L.length; ++k)
            ((D = L[k]), D !== "removeListener" && this.removeAllListeners(D));
          return (
            this.removeAllListeners("removeListener"),
            (this._events = Object.create(null)),
            (this._eventsCount = 0),
            this
          );
        }
        if (((S = C[T]), typeof S == "function")) this.removeListener(T, S);
        else if (S !== void 0)
          for (k = S.length - 1; k >= 0; k--) this.removeListener(T, S[k]);
        return this;
      }));
    function m(E, T, S) {
      var C = E._events;
      if (C === void 0) return [];
      var k = C[T];
      return k === void 0
        ? []
        : typeof k == "function"
          ? S
            ? [k.listener || k]
            : [k]
          : S
            ? I(k)
            : g(k, k.length);
    }
    ((i.prototype.listeners = function (T) {
      return m(this, T, !0);
    }),
      (i.prototype.rawListeners = function (T) {
        return m(this, T, !1);
      }),
      (i.listenerCount = function (E, T) {
        return typeof E.listenerCount == "function"
          ? E.listenerCount(T)
          : v.call(E, T);
      }),
      (i.prototype.listenerCount = v));
    function v(E) {
      var T = this._events;
      if (T !== void 0) {
        var S = T[E];
        if (typeof S == "function") return 1;
        if (S !== void 0) return S.length;
      }
      return 0;
    }
    i.prototype.eventNames = function () {
      return this._eventsCount > 0 ? s(this._events) : [];
    };
    function g(E, T) {
      for (var S = new Array(T), C = 0; C < T; ++C) S[C] = E[C];
      return S;
    }
    function A(E, T) {
      for (; T + 1 < E.length; T++) E[T] = E[T + 1];
      E.pop();
    }
    function I(E) {
      for (var T = new Array(E.length), S = 0; S < T.length; ++S)
        T[S] = E[S].listener || E[S];
      return T;
    }
    function b(E, T) {
      return new Promise(function (S, C) {
        function k(D) {
          (E.removeListener(T, L), C(D));
        }
        function L() {
          (typeof E.removeListener == "function" &&
            E.removeListener("error", k),
            S([].slice.call(arguments)));
        }
        (O(E, T, L, { once: !0 }), T !== "error" && R(E, k, { once: !0 }));
      });
    }
    function R(E, T, S) {
      typeof E.on == "function" && O(E, "error", T, S);
    }
    function O(E, T, S, C) {
      if (typeof E.on == "function") C.once ? E.once(T, S) : E.on(T, S);
      else if (typeof E.addEventListener == "function")
        E.addEventListener(T, function k(L) {
          (C.once && E.removeEventListener(T, k), S(L));
        });
      else
        throw new TypeError(
          'The "emitter" argument must be of type EventEmitter. Received type ' +
            typeof E,
        );
    }
  })();
/**
 * @license MIT
 * Adapted from stream-browserify 3.0.0's base Stream and pipe implementation (MIT).
 * Copyright Joyent, Inc. and other Node contributors.
 * Copyright (c) James Halliday
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to permit
 * persons to whom the Software is furnished to do so, subject to the
 * following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
 * NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
 * USE OR OTHER DEALINGS IN THE SOFTWARE.
 */ var aw = class extends Ia.EventEmitter {
  pipe(e, t) {
    const r = this,
      n = e,
      s = (d) => {
        n.writable && n.write(d) === !1 && r.pause && r.pause();
      };
    r.on("data", s);
    const a = () => {
      r.readable && r.resume && r.resume();
    };
    (n.on("drain", a),
      !n._isStdio &&
        (!t || t.end !== !1) &&
        (r.on("end", i), r.on("close", l)));
    let o = !1;
    function i() {
      o || ((o = !0), n.end());
    }
    function l() {
      o || ((o = !0), typeof n.destroy == "function" && n.destroy());
    }
    function c(d) {
      if ((u(), Ia.EventEmitter.listenerCount(this, "error") === 0)) throw d;
    }
    (r.on("error", c), n.on("error", c));
    function u() {
      (r.removeListener("data", s),
        n.removeListener("drain", a),
        r.removeListener("end", i),
        r.removeListener("close", l),
        r.removeListener("error", c),
        n.removeListener("error", c),
        r.removeListener("end", u),
        r.removeListener("close", u),
        n.removeListener("close", u));
    }
    return (
      r.on("end", u),
      r.on("close", u),
      n.on("close", u),
      n.emit("pipe", r),
      n
    );
  }
};
function Ca(e, t, r, n, s, a, o) {
  try {
    var i = e[a](o),
      l = i.value;
  } catch (c) {
    r(c);
    return;
  }
  i.done ? t(l) : Promise.resolve(l).then(n, s);
}
function it(e) {
  return function () {
    var t = this,
      r = arguments;
    return new Promise(function (n, s) {
      var a = e.apply(t, r);
      function o(l) {
        Ca(a, n, s, o, i, "next", l);
      }
      function i(l) {
        Ca(a, n, s, o, i, "throw", l);
      }
      o(void 0);
    });
  };
}
var ow = { NONE: "", WITH_2_BLANKS: "  ", WITH_4_BLANKS: "    ", WITH_TAB: "	" },
  Na = (e) => (e === !0 ? ow.WITH_2_BLANKS : e === !1 ? void 0 : e),
  ka = (e) =>
    e.Macros === void 0
      ? "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
      : "application/vnd.ms-word.document.macroEnabled.12",
  iw = class gt {
    static pack(t, r, n) {
      var s = this;
      return it(function* (a, o, i, l = []) {
        return Hn(yr(s.compiler.compile(a, Na(i), l)), o, ka(a));
      }).apply(this, arguments);
    }
    static toString(t, r, n = []) {
      return gt.pack(t, "string", r, n);
    }
    static toBuffer(t, r, n = []) {
      return gt.pack(t, "nodebuffer", r, n);
    }
    static toBase64String(t, r, n = []) {
      return gt.pack(t, "base64", r, n);
    }
    static toBlob(t, r, n = []) {
      return gt.pack(t, "blob", r, n);
    }
    static toArrayBuffer(t, r, n = []) {
      return gt.pack(t, "arraybuffer", r, n);
    }
    static toStream(t, r, n = []) {
      const s = new aw(),
        a = this.compiler.compile(t, Na(r), n);
      return (
        new Promise((o) => setTimeout(o))
          .then(() => Hn(yr(a), "nodebuffer", ka(t)))
          .then(
            (o) => {
              (s.emit("data", o), s.emit("end"));
            },
            (o) => s.emit("error", o),
          ),
        s
      );
    }
  };
p(iw, "compiler", new sw());
var vl = (e) => {
    var t;
    if (e.name !== "w:bookmarkStart" && e.name !== "w:bookmarkEnd") return;
    const r = Number(
      (t = e.attributes) === null || t === void 0 ? void 0 : t["w:id"],
    );
    return Number.isInteger(r) ? r : void 0;
  },
  fl = (e) => {
    var t;
    const r = vl(e);
    return [
      ...(r === void 0 ? [] : [r]),
      ...((t = e.elements) !== null && t !== void 0 ? t : []).flatMap(fl),
    ];
  },
  lw = (e) => {
    const t = new Set(e),
      r = new Map();
    let n = e.reduce((o, i) => Math.max(o, i), 0);
    const s = (o) => {
        const i = r.get(o);
        if (i !== void 0) return i;
        const l = t.has(o) ? n + 1 : o;
        return ((n = Math.max(n, l)), t.add(l), r.set(o, l), l);
      },
      a = (o) => {
        const i = vl(o);
        return f(
          f(
            f({}, o),
            i === void 0
              ? {}
              : {
                  attributes: f(
                    f({}, o.attributes),
                    {},
                    { "w:id": String(s(i)) },
                  ),
                },
          ),
          o.elements === void 0 ? {} : { elements: o.elements.map(a) },
        );
      };
    return (o) => o.map(a);
  },
  cw = new vt(),
  Fr = (e) => new TextDecoder("utf-8", { ignoreBOM: !0 }).decode(e),
  Ue = (e) => bt(e, { keepWhitespaceText: !0 }),
  wl = (e) => {
    var t;
    return (t = Ue($(cw.format(new Ft({ text: e })))).elements[0].elements) !==
      null && t !== void 0
      ? t
      : [];
  },
  gl = (e) => f(f({}, e), {}, { attributes: { "xml:space": "preserve" } }),
  ce = (e, t) => {
    var r, n;
    const s =
      (r = e.elements) === null || r === void 0
        ? void 0
        : r.find((a) => a.name === t);
    return s === void 0
      ? []
      : (((n = s.elements) !== null && n !== void 0) || (s.elements = []),
        s.elements);
  },
  yl = (e) => {
    if (!e?.start.trim() || !e?.end.trim())
      throw new Error(
        "Both start and end delimiters must be non-empty strings.",
      );
  },
  wt = (e, t, r) => {
    const n = ce(e, "Types");
    n.some((s) => {
      var a, o;
      return (
        s.type === "element" &&
        s.name === "Default" &&
        (s == null || (a = s.attributes) === null || a === void 0
          ? void 0
          : a.ContentType) === t &&
        (s == null || (o = s.attributes) === null || o === void 0
          ? void 0
          : o.Extension) === r
      );
    }) ||
      n.push({
        attributes: { ContentType: t, Extension: r },
        name: "Default",
        type: "element",
      });
  },
  uw = (e, t, r) => {
    const n = ce(e, "Types");
    n.some((s) => {
      var a;
      return (
        s.type === "element" &&
        s.name === "Override" &&
        ((a = s.attributes) === null || a === void 0 ? void 0 : a.PartName) ===
          r
      );
    }) ||
      n.push({
        attributes: { ContentType: t, PartName: r },
        name: "Override",
        type: "element",
      });
  },
  dw = (e, t) => {
    var r;
    const n =
      (r = e.elements) === null || r === void 0
        ? void 0
        : r.find((s) => s.name === "Types");
    n?.elements !== void 0 &&
      (n.elements = n.elements.filter((s) => {
        var a, o;
        return !(
          s.name === "Override" &&
          String(
            (a =
              (o = s.attributes) === null || o === void 0
                ? void 0
                : o.PartName) !== null && a !== void 0
              ? a
              : "",
          ).toLowerCase() === t.toLowerCase()
        );
      }));
  },
  hw = (e) => {
    const t = parseInt(e.substring(3), 10);
    return isNaN(t) ? 0 : t;
  },
  Ss = (e) =>
    ce(e, "Relationships")
      .map((t) => {
        var r, n;
        return hw(
          (r =
            (n = t.attributes) === null ||
            n === void 0 ||
            (n = n.Id) === null ||
            n === void 0
              ? void 0
              : n.toString()) !== null && r !== void 0
            ? r
            : "",
        );
      })
      .reduce((t, r) => Math.max(t, r), 0) + 1,
  Wn = (e, t, r, n, s) => {
    const a = ce(e, "Relationships");
    return (
      a.push({
        attributes: { Id: `rId${t}`, Type: r, Target: n, TargetMode: s },
        name: "Relationship",
        type: "element",
      }),
      a
    );
  },
  Wt = () => ({
    declaration: {
      attributes: { version: "1.0", encoding: "UTF-8", standalone: "yes" },
    },
    elements: [
      {
        type: "element",
        name: "Relationships",
        attributes: {
          xmlns: "http://schemas.openxmlformats.org/package/2006/relationships",
        },
        elements: [],
      },
    ],
  }),
  Ra =
    "http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties",
  mw = "application/vnd.openxmlformats-package.core-properties+xml",
  Pa = "_rels/.rels",
  Oa = "docProps/core.xml",
  Un = {
    cp: "http://schemas.openxmlformats.org/package/2006/metadata/core-properties",
    dc: "http://purl.org/dc/elements/1.1/",
  },
  pw = {
    title: { namespace: "dc", name: "title" },
    subject: { namespace: "dc", name: "subject" },
    creator: { namespace: "dc", name: "creator" },
    keywords: { namespace: "cp", name: "keywords" },
    description: { namespace: "dc", name: "description" },
    lastModifiedBy: { namespace: "cp", name: "lastModifiedBy" },
    revision: { namespace: "cp", name: "revision" },
  },
  _a = (e) => (e === "" ? [] : [{ type: "text", text: String(e) }]),
  La = (e) => {
    var t;
    return (t = e.name) === null || t === void 0
      ? void 0
      : t.slice(e.name.indexOf(":") + 1);
  },
  vw = (e, t) => {
    var r;
    const n =
      (r = Object.entries(f({}, e.attributes)).find(
        ([s, a]) => (s === "xmlns" || s.startsWith("xmlns:")) && a === Un[t],
      )) === null || r === void 0
        ? void 0
        : r[0];
    return n === void 0
      ? ((e.attributes = f(f({}, e.attributes), {}, { [`xmlns:${t}`]: Un[t] })),
        `${t}:`)
      : n === "xmlns"
        ? ""
        : `${n.slice(6)}:`;
  },
  fw = (e) => {
    const t =
      e[0] === 255 && e[1] === 254
        ? "utf-16le"
        : e[0] === 254 && e[1] === 255
          ? "utf-16be"
          : "utf-8";
    return new TextDecoder(t).decode(e);
  },
  ww = (e, t, r) => {
    var n;
    const s = t.get(r);
    if (s === void 0) return e.get(r);
    const a = Ue(fw(s));
    return (
      !((n = a.declaration) === null || n === void 0) &&
        n.attributes &&
        (a.declaration.attributes.encoding = "UTF-8"),
      t.delete(r),
      e.set(r, a),
      a
    );
  },
  gw = (e) => {
    var t, r;
    const n = (t = e.get(Pa)) !== null && t !== void 0 ? t : Wt(),
      s =
        (r = ce(n, "Relationships").find((a) => {
          var o;
          return (
            ((o = a.attributes) === null || o === void 0 ? void 0 : o.Type) ===
            Ra
          );
        })) === null ||
        r === void 0 ||
        (r = r.attributes) === null ||
        r === void 0
          ? void 0
          : r.Target;
    return typeof s == "string"
      ? mt("", s)
      : (Wn(n, Ss(n), Ra, Oa), e.set(Pa, n), Oa);
  },
  yw = (e, t, r, { addContentTypeOverride: n }) => {
    var s, a;
    const o = gw(e),
      i = ww(e, t, o),
      l = i ?? {
        declaration: {
          attributes: { version: "1.0", encoding: "UTF-8", standalone: "yes" },
        },
        elements: [
          {
            type: "element",
            name: "cp:coreProperties",
            attributes: { "xmlns:cp": Un.cp },
            elements: [],
          },
        ],
      };
    i === void 0 && (e.set(o, l), n(mw, `/${o}`));
    const c =
      (s = l.elements) === null || s === void 0
        ? void 0
        : s.find((u) => La(u) === "coreProperties");
    if (c === void 0)
      throw new Error(`Could not find the core properties in ${o}`);
    ((a = c.elements) !== null && a !== void 0) || (c.elements = []);
    for (const [u, { namespace: d, name: h }] of Object.entries(pw)) {
      const w = r[u];
      if (w === void 0) continue;
      const m = c.elements.find((v) => La(v) === h);
      m
        ? (m.elements = _a(w))
        : c.elements.push({
            type: "element",
            name: `${vw(c, d)}${h}`,
            elements: _a(w),
          });
    }
  },
  Gn = new Set(["wp:inline", "wp:anchor"]),
  As = new Set(["wp:docPr", "wps:cNvPr", "wpg:cNvPr"]),
  xw = new Set(["a:stCxn", "a:endCxn"]),
  br = (e, t) => {
    var r, n;
    if (!t.has((r = e.name) !== null && r !== void 0 ? r : "")) return;
    const s = Number(
      (n = e.attributes) === null || n === void 0 ? void 0 : n.id,
    );
    return Number.isInteger(s) ? s : void 0;
  },
  xl = (e) => {
    var t;
    const r = br(e, As);
    return [
      ...(r === void 0 ? [] : [r]),
      ...((t = e.elements) !== null && t !== void 0 ? t : []).flatMap(xl),
    ];
  },
  bw = (e) => {
    const t = (r) => {
      var n;
      const s = br(r, As);
      return [
        ...(s === void 0 ? [] : [s]),
        ...((n = r.elements) !== null && n !== void 0 ? n : []).flatMap((a) => {
          var o;
          return Gn.has((o = a.name) !== null && o !== void 0 ? o : "")
            ? []
            : t(a);
        }),
      ];
    };
    return t(e);
  },
  Tw = (e) => {
    const t = new Set(e);
    let r = e.reduce((o, i) => Math.max(o, i), 0);
    const n = (o) => {
        const i = t.has(o) ? r + 1 : o;
        return ((r = Math.max(r, i)), t.add(i), i);
      },
      s = (o) => {
        const i = new Map([...new Set(bw(o))].map((c) => [c, n(c)])),
          l = (c) => {
            var u, d;
            if (
              c !== o &&
              Gn.has((u = c.name) !== null && u !== void 0 ? u : "")
            )
              return s(c);
            const h = (d = br(c, As)) !== null && d !== void 0 ? d : br(c, xw),
              w = h === void 0 ? void 0 : i.get(h);
            return f(
              f(
                f({}, c),
                w === void 0
                  ? {}
                  : {
                      attributes: f(f({}, c.attributes), {}, { id: String(w) }),
                    },
              ),
              c.elements === void 0 ? {} : { elements: c.elements.map(l) },
            );
          };
        return l(o);
      },
      a = (o) => {
        var i;
        return Gn.has((i = o.name) !== null && i !== void 0 ? i : "")
          ? s(o)
          : f(
              f({}, o),
              o.elements === void 0 ? {} : { elements: o.elements.map(a) },
            );
      };
    return (o) => o.map(a);
  },
  le = {
    DOCUMENT: "file",
    PARAGRAPH: "paragraph",
    TABLE_ROWS: "tableRows",
    DRAWING: "drawing",
  },
  Ew = class {
    constructor() {
      p(this, "type", le.DRAWING);
    }
  },
  Sw = new Map([
    ["wp:inline", "wp:docPr"],
    ["wp:anchor", "wp:docPr"],
    ["wpg:graphicFrame", "wpg:cNvPr"],
    ["wpc:graphicFrame", "wpg:cNvPr"],
  ]),
  $r = (e) => {
    var t;
    return ((t = e.elements) !== null && t !== void 0 ? t : []).flatMap((r) => {
      var n;
      const s = r.name === void 0 ? void 0 : Sw.get(r.name),
        a =
          s === void 0 || (n = r.elements) === null || n === void 0
            ? void 0
            : n.find((o) => o.name === s);
      return [...(a ? [{ element: r, properties: a }] : []), ...$r(r)];
    });
  },
  bl = (e) => {
    var t, r;
    return [
      (t = e.attributes) === null || t === void 0 ? void 0 : t.descr,
      (r = e.attributes) === null || r === void 0 ? void 0 : r.title,
    ].flatMap((n) => (n === void 0 ? [] : [String(n)]));
  },
  Da = "[Content_Types].xml",
  Aw = (e) => {
    var t;
    if (!(
      !((t = e.elements) === null || t === void 0) &&
      t.some((n) => n.name === "Relationships")
    )) {
      var r;
      e.elements = [
        ...((r = e.elements) !== null && r !== void 0 ? r : []),
        ...Wt().elements,
      ];
    }
    return ce(e, "Relationships");
  },
  Iw = "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
  jn = (e) => {
    var t, r;
    return new Set([
      "r",
      ...Object.entries(
        (t = e.attributes) !== null && t !== void 0 ? t : {},
      ).flatMap(([n, s]) =>
        n.startsWith("xmlns:") && s === Iw ? [n.slice(6)] : [],
      ),
      ...((r = e.elements) !== null && r !== void 0 ? r : []).flatMap((n) => [
        ...jn(n),
      ]),
    ]);
  },
  Vn = (e, t) => {
    var r, n;
    return new Set([
      ...Object.entries(
        (r = e.attributes) !== null && r !== void 0 ? r : {},
      ).flatMap(([s, a]) =>
        s.includes(":") && t.has(s.slice(0, s.indexOf(":"))) ? [String(a)] : [],
      ),
      ...((n = e.elements) !== null && n !== void 0 ? n : []).flatMap((s) => [
        ...Vn(s, t),
      ]),
    ]);
  },
  Cw = (e, t) => {
    const r = (c) => e.has(c) || t.has(c),
      n = (c) => {
        if (r(c)) return c;
        const u = (() => {
          try {
            return decodeURI(c);
          } catch {
            return;
          }
        })();
        if (u !== void 0 && r(u)) return u;
        const d = c.toLowerCase();
        return [...e.keys(), ...t.keys()].find((h) => h.toLowerCase() === d);
      },
      s = (c, u) => {
        const d = e.get(Oe(c));
        return d === void 0
          ? void 0
          : ce(d, "Relationships").find((h) => {
              var w;
              return (
                h.name === "Relationship" &&
                ((w = h.attributes) === null || w === void 0
                  ? void 0
                  : w.Id) === u
              );
            });
      },
      a = (c, u) => {
        var d, h;
        const w =
          (d = u.attributes) === null || d === void 0 ? void 0 : d.Target;
        return ((h = u.attributes) === null || h === void 0
          ? void 0
          : h.TargetMode) === "External" || w === void 0
          ? void 0
          : n(mt(c, String(w)));
      },
      o = (c) =>
        [...e].some(
          ([u, d]) =>
            u.endsWith(".rels") &&
            ce(d, "Relationships").some((h) => a(Ji(u), h) === c),
        ),
      i = (c, u) => {
        if (u === void 0 || u === c || u === Da || u.endsWith(".rels") || o(u))
          return;
        const d = e.get(Oe(u));
        (e.delete(u), t.delete(u), e.delete(Oe(u)));
        const h = e.get(Da);
        h !== void 0 && dw(h, `/${u}`);
        for (const w of d === void 0 ? [] : ce(d, "Relationships"))
          i(u, a(u, w));
      };
    return {
      findRelationship: s,
      pathOf: a,
      removeIfUnreferenced: i,
      removeRelationships: (c, u) => {
        var d, h;
        const w =
            (d = e.get(Oe(c))) === null ||
            d === void 0 ||
            (d = d.elements) === null ||
            d === void 0
              ? void 0
              : d.find((v) => v.name === "Relationships"),
          m = ((h = w?.elements) !== null && h !== void 0 ? h : []).filter(
            (v) => {
              var g;
              return (
                v.name === "Relationship" &&
                u.has(
                  String(
                    (g = v.attributes) === null || g === void 0 ? void 0 : g.Id,
                  ),
                )
              );
            },
          );
        if (!(w === void 0 || m.length === 0)) {
          w.elements = w.elements.filter((v) => !m.includes(v));
          for (const v of m) i(c, a(c, v));
        }
      },
    };
  },
  Nw = (
    e,
    { findRelationship: t, pathOf: r, removeIfUnreferenced: n },
    s,
    a,
  ) => {
    const o = new vt();
    return {
      getRelatedPart: (i, l) => {
        const c = t(i.path, l),
          u = c === void 0 ? void 0 : r(i.path, c);
        return u === void 0 ? void 0 : { path: u, xml: e.get(u) };
      },
      replaceRelatedPart: (i, l, c) => {
        const u = `word/${s.PackageParts.add(c)}`,
          { relationshipType: d } = c.options,
          h = ys(i.path, u),
          w = l === void 0 ? void 0 : t(i.path, l);
        if (w === void 0) {
          var m;
          const g = Oe(i.path),
            A = (m = e.get(g)) !== null && m !== void 0 ? m : Wt();
          e.set(g, A);
          const I = l ?? `rId${Ss(A)}`;
          return (
            Aw(A).push({
              type: "element",
              name: "Relationship",
              attributes: { Id: I, Type: d, Target: h },
            }),
            I
          );
        }
        const v = r(i.path, w);
        return (
          (w.attributes = f(
            f(
              {},
              Object.fromEntries(
                Object.entries(w.attributes).filter(
                  ([g]) => g !== "TargetMode",
                ),
              ),
            ),
            {},
            { Type: d, Target: h },
          )),
          n(i.path, v),
          String(w.attributes.Id)
        );
      },
      format: (i) => Ue($(o.format(i, a))).elements[0],
    };
  },
  kw = (
    { parts: e, binaryParts: t, file: r, patches: n, delimiters: s },
    a,
  ) => {
    const o = n.map(([c, u]) => ({
        placeholder: `${s.start}${c}${s.end}`,
        patch: u,
      })),
      i = [...e]
        .filter(([c]) => c.startsWith("word/") && !c.endsWith(".rels"))
        .flatMap(([c, u]) =>
          $r(u).flatMap((d) => {
            const h = bl(d.properties),
              w = o.filter(({ placeholder: g }) =>
                h.some((A) => A.includes(g)),
              );
            if (w.length > 1) {
              var m, v;
              throw new Error(
                `The drawing "${(m = (v = d.properties.attributes) === null || v === void 0 ? void 0 : v.name) !== null && m !== void 0 ? m : ""}" in ${c} has the placeholders ${w.map(({ placeholder: g }) => g).join(" and ")} in its alt text. A drawing can only be patched once`,
              );
            }
            return w.map(({ placeholder: g, patch: A }) => ({
              drawing: f(
                f({ placeholder: g }, d),
                {},
                { part: { path: c, xml: u } },
              ),
              patch: A,
            }));
          }),
        ),
      l = Cw(e, t);
    for (const { drawing: c, patch: u } of i) {
      const d = Vn(c.element, jn(c.part.xml));
      u.patch(c, Nw(e, l, r, a(c.part.path)));
      const h = Vn(c.part.xml, jn(c.part.xml));
      l.removeRelationships(
        c.part.path,
        new Set([...d].filter((w) => !h.has(w))),
      );
    }
  },
  Rw = (e) =>
    typeof e == "object" &&
    e !== null &&
    "on" in e &&
    typeof e.on == "function",
  Pw = (e) =>
    typeof e == "object" &&
    e !== null &&
    "generateAsync" in e &&
    typeof e.generateAsync == "function",
  Ow = (e) =>
    ["[object Blob]", "[object File]"].includes(
      Object.prototype.toString.call(e),
    ),
  _w = (e) =>
    new Promise((t, r) => {
      const n = [];
      (e.on("data", (s) => {
        ArrayBuffer.isView(s)
          ? n.push(new Uint8Array(s.buffer, s.byteOffset, s.byteLength))
          : typeof s == "number"
            ? n.push(s)
            : r(
                new TypeError(
                  `A template stream must give bytes, but it gave a ${typeof s}. A stream with an encoding set gives text, so do not set one.`,
                ),
              );
      }),
        e.on("error", r),
        e.on("end", () => {
          const s = new Uint8Array(
            n.reduce((a, o) => a + (typeof o == "number" ? 1 : o.length), 0),
          );
          (n.reduce(
            (a, o) =>
              typeof o == "number"
                ? ((s[a] = o), a + 1)
                : (s.set(o, a), a + o.length),
            0,
          ),
            t(s));
        }));
    }),
  Lw = (function () {
    var e = it(function* (t) {
      return Pw(t)
        ? t.generateAsync({ type: "uint8array" })
        : Rw(t)
          ? _w(t)
          : Ow(t)
            ? new Uint8Array(yield t.arrayBuffer())
            : typeof t == "string"
              ? Uint8Array.from({ length: t.length }, (r, n) => t.charCodeAt(n))
              : Array.isArray(t)
                ? Uint8Array.from(t)
                : ArrayBuffer.isView(t)
                  ? new Uint8Array(t.buffer, t.byteOffset, t.byteLength)
                  : new Uint8Array(t);
    });
    return function (r) {
      return e.apply(this, arguments);
    };
  })(),
  Tl = (function () {
    var e = it(function* (t, r) {
      return xr(yield Lw(t), r);
    });
    return function (r, n) {
      return e.apply(this, arguments);
    };
  })(),
  Dw = new vt(),
  sr = "word/document.xml",
  Mw = {
    path: "word/footnotes.xml",
    rootName: "w:footnotes",
    noteName: "w:footnote",
    referenceName: "w:footnoteReference",
    contentType:
      "application/vnd.openxmlformats-officedocument.wordprocessingml.footnotes+xml",
    relationshipType:
      "http://schemas.openxmlformats.org/officeDocument/2006/relationships/footnotes",
    create: {
      part: () => new Mi(),
      mark: () => new Di(),
      styles: () => [new Gi({}), new Vi({}), new ji({})],
    },
  },
  Fw = {
    path: "word/endnotes.xml",
    rootName: "w:endnotes",
    noteName: "w:endnote",
    referenceName: "w:endnoteReference",
    contentType:
      "application/vnd.openxmlformats-officedocument.wordprocessingml.endnotes+xml",
    relationshipType:
      "http://schemas.openxmlformats.org/officeDocument/2006/relationships/endnotes",
    create: {
      part: () => new Li(),
      mark: () => new Pi(),
      styles: () => [new Xi({}), new zi({}), new Ki({})],
    },
  },
  ar = (e, t) => Ue($(Dw.format(e, t))).elements[0],
  El = (e, t) => {
    var r, n, s;
    const a = t.includes((r = e.name) !== null && r !== void 0 ? r : "")
      ? Number((n = e.attributes) === null || n === void 0 ? void 0 : n["w:id"])
      : NaN;
    return [
      ...(Number.isInteger(a) ? [a] : []),
      ...((s = e.elements) !== null && s !== void 0 ? s : []).flatMap((o) =>
        El(o, t),
      ),
    ];
  },
  $w = (e, t) => {
    var r, n;
    const s = (r = e.elements) !== null && r !== void 0 ? r : [],
      a =
        ((n = s[0]) === null || n === void 0 ? void 0 : n.name) === "w:pPr"
          ? 1
          : 0;
    return f(f({}, e), {}, { elements: [...s.slice(0, a), t, ...s.slice(a)] });
  },
  Ma = (
    e,
    t,
    r,
    {
      createContext: n,
      addContentTypeOverride: s,
      renumberBookmarks: a,
      renumberDrawings: o,
      renumberLists: i,
      useStyles: l,
    },
  ) => {
    const c = new Map(Object.entries(t).map(([I, b]) => [Number(I), b])),
      u = new Map();
    let d = [...c.keys()]
      .filter(Number.isFinite)
      .reduce((I, b) => Math.max(I, Math.floor(b)), 0);
    const h = new Map();
    let w;
    const m = (I) => {
        var b, R;
        const O =
          I.name === e.referenceName
            ? c.get(
                Number(
                  (b = I.attributes) === null || b === void 0
                    ? void 0
                    : b["w:id"],
                ),
              )
            : void 0;
        return O === void 0
          ? I.elements === void 0
            ? I
            : f(f({}, I), {}, { elements: I.elements.map(m) })
          : ((w =
              ((R = w) !== null && R !== void 0
                ? R
                : [...r.values()]
                    .flatMap((E) => El(E, [e.noteName, e.referenceName]))
                    .reduce((E, T) => Math.max(E, T), 0)) + 1),
            h.set(w, O),
            f(
              f({}, I),
              {},
              { attributes: f(f({}, I.attributes), {}, { "w:id": String(w) }) },
            ));
      },
      v = () => {
        var I;
        const b = ce(
            (I = r.get(Oe(sr))) !== null && I !== void 0 ? I : {},
            "Relationships",
          ).find((O) => {
            var E;
            return (
              ((E = O.attributes) === null || E === void 0
                ? void 0
                : E.Type) === e.relationshipType
            );
          }),
          R = b ? mt(sr, String(b.attributes.Target)) : e.path;
        return (
          r.has(R) ||
            (r.set(R, {
              declaration: {
                attributes: {
                  version: "1.0",
                  encoding: "UTF-8",
                  standalone: "yes",
                },
              },
              elements: [ar(e.create.part(), n(R))],
            }),
            s(e.contentType, `/${R}`)),
          b ||
            n(sr).viewWrapper.Relationships.addRelationship(
              at(),
              e.relationshipType,
              ys(sr, R),
            ),
          R
        );
      };
    return {
      renumber: (I) => I.map(m),
      write: () => {
        if (h.size === 0) return;
        const I = v(),
          b = n(I),
          R = new Map(
            [...new Set(h.values())].map((E) => {
              const T = ar(e.create.mark(), b);
              return [
                E,
                l(
                  i(
                    a(
                      E.children
                        .map((S) => ar(S, b))
                        .map((S, C) => (C === 0 ? $w(S, T) : S)),
                    ),
                  ),
                ),
              ];
            }),
          );
        ce(r.get(I), e.rootName).push(
          ...[...h].map(([E, T]) => ({
            type: "element",
            name: e.noteName,
            attributes: { "w:id": String(E) },
            elements: [...o(R.get(T))],
          })),
        );
        const O = r.get("word/styles.xml");
        if (O) {
          const E = ce(O, "w:styles"),
            T = new Set(
              E.map((S) => {
                var C;
                return (C = S.attributes) === null || C === void 0
                  ? void 0
                  : C["w:styleId"];
              }),
            );
          E.push(
            ...e.create
              .styles()
              .map((S) => ar(S, b))
              .filter((S) => {
                var C;
                return !T.has(
                  (C = S.attributes) === null || C === void 0
                    ? void 0
                    : C["w:styleId"],
                );
              }),
          );
        }
      },
      carry: (I, b) => {
        const R = u.get(I);
        return R !== void 0 ? R : (d++, c.set(d, b), u.set(I, d), d);
      },
    };
  },
  Hw = ({ footnotes: e = {}, endnotes: t = {} }, r, n) => {
    const s = { footnotes: Ma(Mw, e, r, n), endnotes: Ma(Fw, t, r, n) };
    return {
      carry: (a, o, i) => s[a].carry(o, i),
      renumber: (a) => Object.values(s).reduce((o, i) => i.renumber(o), a),
      write: () => {
        for (const a of Object.values(s)) a.write();
      },
    };
  },
  Bw = new vt(),
  or = "word/document.xml",
  Ww = "word/numbering.xml",
  Uw =
    "application/vnd.openxmlformats-officedocument.wordprocessingml.numbering+xml",
  Fa =
    "http://schemas.openxmlformats.org/officeDocument/2006/relationships/numbering",
  Gw = "default-bullet-numbering",
  jw = "1",
  Vw = (e, t) => Ue($(Bw.format(e, t))).elements[0],
  $a = (e) => e.reduce((t, r) => Math.max(t, r), 0),
  Xw = (e, t, { createContext: r, addContentTypeOverride: n }) => {
    const s = new Map();
    let a;
    const o = () => {
        var m;
        return ce(
          (m = t.get(Oe(or))) !== null && m !== void 0 ? m : {},
          "Relationships",
        ).find((v) => {
          var g;
          return (
            ((g = v.attributes) === null || g === void 0 ? void 0 : g.Type) ===
            Fa
          );
        });
      },
      i = (m = o()) => (m ? mt(or, String(m.attributes.Target)) : Ww),
      l = (m, v) => {
        var g;
        return ce(
          (g = t.get(i())) !== null && g !== void 0 ? g : {},
          "w:numbering",
        )
          .filter((A) => A.name === m)
          .map((A) => Number(A.attributes[v]));
      },
      c = (m) => {
        if (m === jw)
          return e.ConcreteNumbering.find(({ reference: g }) => g === Gw);
        if (!m.startsWith("{")) return;
        const v = e.ConcreteNumbering.find(
          ({ reference: g, instance: A }) => m === `{${g}-${A}}`,
        );
        if (!v) {
          const g = m.slice(1, -1).replace(/-\d+$/, "");
          throw new Error(
            `A paragraph in a patch uses the numbering "${g}", which isn't in the numbering option of patchDocument. Add it there with its levels, as in a Document`,
          );
        }
        return v;
      },
      u = (m) => {
        var v;
        const g = s.get(m.numId);
        return g !== void 0
          ? g
          : ((a =
              ((v = a) !== null && v !== void 0
                ? v
                : $a(l("w:num", "w:numId"))) + 1),
            s.set(m.numId, a),
            a);
      },
      d = (m) => {
        const v =
          m.name === "w:numId" ? c(String(m.attributes["w:val"])) : void 0;
        return v === void 0
          ? m.elements === void 0
            ? m
            : f(f({}, m), {}, { elements: m.elements.map(d) })
          : f(
              f({}, m),
              {},
              {
                attributes: f(
                  f({}, m.attributes),
                  {},
                  { "w:val": String(u(v)) },
                ),
              },
            );
      },
      h = (m) => {
        const v = o(),
          g = i(v);
        return (
          t.has(g) ||
            (t.set(g, {
              declaration: {
                attributes: {
                  version: "1.0",
                  encoding: "UTF-8",
                  standalone: "yes",
                },
              },
              elements: [f(f({}, m), {}, { elements: [] })],
            }),
            n(Uw, `/${g}`)),
          v ||
            r(or).viewWrapper.Relationships.addRelationship(
              at(),
              Fa,
              ys(or, g),
            ),
          g
        );
      };
    return {
      renumber: (m) => m.map(d),
      write: () => {
        var m, v;
        if (s.size === 0) return;
        const g = Vw(e, r(i())),
          A = (k) =>
            Number(
              k.elements.find((L) => L.name === "w:abstractNumId").attributes[
                "w:val"
              ],
            ),
          I = g.elements.filter(
            (k) => k.name === "w:num" && s.has(Number(k.attributes["w:numId"])),
          ),
          b = $a(l("w:abstractNum", "w:abstractNumId")),
          R = new Map([...new Set(I.map(A))].map((k, L) => [k, b + L + 1])),
          O = g.elements.flatMap((k) => {
            const L =
              k.name === "w:abstractNum"
                ? R.get(Number(k.attributes["w:abstractNumId"]))
                : void 0;
            return L === void 0
              ? []
              : [
                  f(
                    f({}, k),
                    {},
                    {
                      attributes: f(
                        f({}, k.attributes),
                        {},
                        { "w:abstractNumId": String(L) },
                      ),
                    },
                  ),
                ];
          }),
          E = h(g),
          T = t.get(E).elements.find((k) => k.name === "w:numbering");
        T.attributes = f(
          f(
            f(
              {},
              Object.fromEntries(
                Object.entries(g.attributes).filter(([k]) =>
                  k.startsWith("xmlns:"),
                ),
              ),
            ),
            T.attributes,
          ),
          {},
          {
            "mc:Ignorable": [
              ...new Set([
                ...String(
                  (m =
                    (v = T.attributes) === null || v === void 0
                      ? void 0
                      : v["mc:Ignorable"]) !== null && m !== void 0
                    ? m
                    : "",
                ).split(" "),
                ...String(g.attributes["mc:Ignorable"]).split(" "),
              ]),
            ]
              .filter((k) => k !== "")
              .join(" "),
          },
        );
        const S = ce(t.get(E), "w:numbering"),
          C = (k) => {
            const L = S.findIndex((D) => k.includes(D.name));
            return L === -1 ? S.length : L;
          };
        (S.splice(C(["w:num", "w:numIdMacAtCleanup"]), 0, ...O),
          S.splice(
            C(["w:numIdMacAtCleanup"]),
            0,
            ...I.map((k) =>
              f(
                f({}, k),
                {},
                {
                  attributes: f(
                    f({}, k.attributes),
                    {},
                    {
                      "w:numId": String(s.get(Number(k.attributes["w:numId"]))),
                    },
                  ),
                  elements: k.elements.map((L) =>
                    L.name === "w:abstractNumId"
                      ? f(
                          f({}, L),
                          {},
                          { attributes: { "w:val": String(R.get(A(k))) } },
                        )
                      : L,
                  ),
                },
              ),
            ),
          ));
      },
    };
  },
  Xn = {
    nameOf: (e) => (e.type === "element" ? e.name : void 0),
    contentOf: (e) => e.elements,
    attributeOf: (e, t) => {
      var r;
      return (r = e.attributes) === null || r === void 0 ? void 0 : r[t];
    },
    textOf: (e) => {
      var t;
      return ((t = e.elements) !== null && t !== void 0 ? t : [])
        .filter(({ type: r }) => r === "text")
        .map(({ text: r }) => String(r))
        .join("");
    },
    textElement: (e) => ({
      type: "element",
      name: "w:t",
      attributes: { "xml:space": "preserve" },
      elements: [{ type: "text", text: e }],
    }),
    writeClean: (e, t) => {
      var r;
      /^\s*(PAGEREF|TOC)\b/i.test(t) &&
        ((r = e.attributes) === null || r === void 0
          ? void 0
          : r["w:dirty"]) !== void 0 &&
        (e.attributes = Object.fromEntries(
          Object.entries(e.attributes).filter(([n]) => n !== "w:dirty"),
        ));
    },
    setSimpleFieldResult: (e, t) => {
      e.elements = [
        { type: "element", name: "w:r", elements: [Xn.textElement(t)] },
      ];
    },
  },
  gn = "word/document.xml",
  Kw =
    "http://schemas.openxmlformats.org/officeDocument/2006/relationships/aFChunk",
  zw = [80, 75, 3, 4],
  Yw = (function () {
    var e = it(function* (t) {
      if (zw.every((r, n) => t[n] === r))
        try {
          const r = new Map(),
            n = new Map();
          for (const [a, o] of xr(t))
            /\.(xml|rels)$/.test(a) ? r.set(a, Ue(Fr(o))) : n.set(a, o);
          const s = yield Sl(r, n);
          return f(
            { parts: r, binaryParts: n },
            s.size > 0 ? { importedDocuments: s } : {},
          );
        } catch {
          return;
        }
    });
    return function (r) {
      return e.apply(this, arguments);
    };
  })(),
  Sl = (function () {
    var e = it(function* (t, r) {
      const n = new Map();
      for (const [o, i] of t) {
        var s, a;
        if (o.endsWith(".rels"))
          for (const { attributes: l = {} } of (s =
            (a = mr(i)) === null || a === void 0 ? void 0 : a.elements) !==
            null && s !== void 0
            ? s
            : []) {
            const c = mt(Ji(o), String(l.Target)),
              u = r.get(c),
              d =
                l.Type === Kw && l.TargetMode !== "External" && u
                  ? yield Yw(u)
                  : void 0;
            d && n.set(c, d);
          }
      }
      return n;
    });
    return function (r, n) {
      return e.apply(this, arguments);
    };
  })(),
  mr = (e) => {
    var t;
    return e == null || (t = e.elements) === null || t === void 0
      ? void 0
      : t.find(({ type: r }) => r === "element");
  },
  qw = (function () {
    var e = it(function* (t, r, n = new Map()) {
      var s, a;
      const o = mr(t.get(gn));
      if (!o) return;
      const i = yield Sl(t, n),
        l = r(
          f(
            { parts: t, binaryParts: n },
            i.size > 0 ? { importedDocuments: i } : {},
          ),
        ),
        c = Ko(Xn, o, l, { blank: !0 }),
        u =
          (s =
            (a = mr(t.get(Oe(gn)))) === null || a === void 0
              ? void 0
              : a.elements) !== null && s !== void 0
            ? s
            : [];
      for (const { attributes: d = {} } of u) {
        const h = /\/(header|footer)$/.test(String(d.Type))
          ? mr(t.get(mt(gn, String(d.Target))))
          : void 0;
        h && zo(Xn, h, l, { blank: !0, sectionPageCount: c.get(String(d.Id)) });
      }
    });
    return function (r, n) {
      return e.apply(this, arguments);
    };
  })(),
  Jw = new Set([
    "w:hyperlink",
    "w:sdt",
    "w:sdtContent",
    "w:ins",
    "w:moveTo",
    "w:smartTag",
    "w:customXml",
    "w:fldSimple",
    "w:dir",
    "w:bdo",
  ]),
  Al = (e, t) => {
    var r;
    return ((r = e.elements) !== null && r !== void 0 ? r : []).flatMap(
      (n, s) => {
        var a;
        return n.name === "w:r"
          ? [{ element: n, path: [...t, s] }]
          : Jw.has((a = n.name) !== null && a !== void 0 ? a : "")
            ? Al(n, [...t, s])
            : [];
      },
    );
  },
  Tr = (e, t) => t.reduce((r, n) => r.elements[n], e),
  Jt = (e) => {
    if (e.element.name !== "w:p")
      throw new Error(`Invalid node type: ${e.element.name}`);
    if (!e.element.elements)
      return { text: "", runs: [], index: -1, pathToParagraph: [] };
    let t = 0;
    const r = Al(e.element, []).map(({ element: n, path: s }) => {
      const a = Zw(n, s, t);
      return ((t += a.text.length), a);
    });
    return {
      text: r.reduce((n, s) => n + s.text, ""),
      runs: r,
      index: e.index,
      pathToParagraph: Il(e),
    };
  },
  Zw = (e, t, r) => {
    if (!e.elements) return { text: "", parts: [], path: t, start: r, end: r };
    let n = r;
    const s = e.elements
      .map((a, o) => {
        var i, l;
        if (a.name !== "w:t" || !a.elements || a.elements.length === 0) return;
        const c =
            (i =
              (l = a.elements[0].text) === null || l === void 0
                ? void 0
                : l.toString()) !== null && i !== void 0
              ? i
              : "",
          u = n;
        return (
          (n += c.length),
          { text: c, index: o, start: u, end: u + c.length - 1 }
        );
      })
      .filter((a) => !!a)
      .map((a) => a);
    return {
      text: s.reduce((a, o) => a + o.text, ""),
      parts: s,
      path: t,
      start: r,
      end: s.length > 0 ? s[s.length - 1].end : r,
    };
  },
  Il = (e) => (e.parent ? [...Il(e.parent), e.index] : [e.index]),
  Qw = class extends Error {
    constructor(e) {
      (super(`Token ${e} not found`), (this.name = "TokenNotFoundError"));
    }
  },
  e0 = (e, t) => {
    const r = Jt({ element: e, index: 0, parent: void 0 }).runs.find(
      ({ parts: n }) => n.some(({ text: s }) => s.includes(t)),
    );
    if (!r) throw new Qw(t);
    return r.path;
  },
  t0 = (e, t) => {
    var r, n;
    let s = -1;
    const a =
      (r =
        (n = e.elements) === null || n === void 0
          ? void 0
          : n
              .map((o, i) => {
                if (s !== -1) return o;
                if (o.type === "element" && o.name === "w:t") {
                  var l, c;
                  const u = (
                      (l =
                        (c = o.elements) === null ||
                        c === void 0 ||
                        (c = c[0]) === null ||
                        c === void 0
                          ? void 0
                          : c.text) !== null && l !== void 0
                        ? l
                        : ""
                    ).split(t),
                    d = u.map((h) =>
                      f(f(f({}, o), gl(o)), {}, { elements: wl(h) }),
                    );
                  return (u.length > 1 && (s = i), d);
                } else return o;
              })
              .flat()) !== null && r !== void 0
        ? r
        : [];
    return {
      left: f(
        f({}, JSON.parse(JSON.stringify(e))),
        {},
        { elements: a.slice(0, s + 1) },
      ),
      right: f(
        f({}, JSON.parse(JSON.stringify(e))),
        {},
        { elements: a.slice(s + 1) },
      ),
    };
  },
  Rt = { START: 0, MIDDLE: 1, END: 2 },
  Cl = ({
    paragraphElement: e,
    renderedParagraph: t,
    originalText: r,
    replacementText: n,
    fromIndex: s = 0,
  }) => {
    const a = t.text.indexOf(r, s),
      o = a + r.length - 1;
    let i = Rt.START;
    for (const l of t.runs) {
      const c = Tr(e, l.path);
      for (const { text: u, index: d, start: h, end: w } of l.parts)
        switch (i) {
          case Rt.START:
            if (a >= h && a <= w) {
              const m = a - h,
                v = Math.min(o, w) - h;
              if (u.substring(m, v + 1) === "") continue;
              const g = u.substring(0, m) + n + u.substring(v + 1);
              (yn(c.elements[d], g), (i = Rt.MIDDLE));
              continue;
            }
            break;
          case Rt.MIDDLE:
            if (o <= w) {
              const m = u.substring(o - h + 1);
              yn(c.elements[d], m);
              const v = c.elements[d];
              ((c.elements[d] = gl(v)), (i = Rt.END));
            } else yn(c.elements[d], "");
        }
    }
    return e;
  },
  yn = (e, t) => ((e.elements = wl(t)), e),
  Ha = (e) => {
    var t, r;
    return (t =
      (r = e.element.elements) === null || r === void 0
        ? void 0
        : r.map((n, s) => ({ element: n, index: s, parent: e }))) !== null &&
      t !== void 0
      ? t
      : [];
  },
  Nl = (e) => {
    const t = [],
      r = [...Ha({ element: e, index: 0, parent: void 0 })];
    for (const n of r) {
      n.element.name === "w:p" && t.push(Jt(n));
      for (const s of Ha(n)) r.push(s);
    }
    return t;
  },
  Is = (e, t) => Nl(e).filter((r) => r.text.includes(t)),
  xn = "￿",
  r0 = ({
    json: e,
    patch: t,
    patchText: r,
    context: n,
    keepOriginalStyles: s = !0,
    recursive: a = !0,
    renumberIds: o = (i) => i,
  }) => {
    const i = Is(e, r);
    if (i.length === 0) return { element: e, didFindOccurrence: !1 };
    const l = [...i].reverse(),
      c = t.type === le.DOCUMENT ? m0(l) : l;
    let u;
    const d = () => {
      var w;
      return (
        (u = ((w = u) !== null && w !== void 0 ? w : Rl(e)) + 1),
        String(u)
      );
    };
    for (const w of c)
      switch (t.type) {
        case le.DOCUMENT: {
          var h;
          const m = p0(e, w.pathToParagraph),
            v = v0(w.pathToParagraph),
            g = Ba(t, n, o),
            A =
              m.name === "w:tc" &&
              v === m.elements.length - 1 &&
              ((h = g[g.length - 1]) === null || h === void 0
                ? void 0
                : h.name) !== "w:p"
                ? [{ type: "element", name: "w:p" }]
                : [];
          m.elements.splice(v, 1, ...g, ...A);
          break;
        }
        case le.PARAGRAPH:
        default: {
          const m = Pl(e, w.pathToParagraph);
          let v = w,
            g = 0;
          do
            ((g = n0({
              paragraphElement: m,
              renderedParagraph: v,
              patchText: r,
              fromIndex: g,
              children: Ba(t, n, o),
              keepOriginalStyles: s,
              newTrackedChangeId: d,
            })),
              (v = Jt({ element: m, index: w.index, parent: void 0 })));
          while (a && v.text.includes(r, g));
          break;
        }
      }
    return { element: e, didFindOccurrence: !0 };
  },
  Ba = (e, t, r) =>
    r(
      e.children
        .flatMap((n) => {
          var s;
          return (s = n.writtenAs) !== null && s !== void 0 ? s : n;
        })
        .flatMap((n) => {
          const s = n.prepForXml(t);
          return s ? [Ue($(s)).elements[0]] : [];
        }),
    ),
  n0 = ({
    paragraphElement: e,
    renderedParagraph: t,
    patchText: r,
    fromIndex: n,
    children: s,
    keepOriginalStyles: a,
    newTrackedChangeId: o,
  }) => {
    const i = t.text.indexOf(r, n);
    Cl({
      paragraphElement: e,
      renderedParagraph: t,
      originalText: r,
      replacementText: xn,
      fromIndex: n,
    });
    const l = e0(e, xn),
      c = l.slice(0, -1),
      u = Tr(e, c),
      d = l[l.length - 1],
      h = c
        .map((O, E) => Tr(e, c.slice(0, E + 1)))
        .filter((O) => O.name === "w:sdt"),
      w = [...h].reverse().find(s0),
      m = u.elements[d],
      { left: v, right: g } = t0(m, xn),
      A = m.elements.find((O) => O.type === "element" && O.name === "w:rPr"),
      I = w ? a0(w) : A,
      b = a && I ? s.map((O) => kl(O, I)) : s,
      R = A ? f(f({}, g), {}, { elements: [A, ...g.elements] }) : g;
    return (
      u.elements.splice(d, 1, v, ...b, R),
      h.forEach((O) => l0(O, b)),
      u0(e, c, o),
      i +
        Jt({
          element: { name: "w:p", elements: [...b] },
          index: 0,
          parent: void 0,
        }).text.length
    );
  },
  Cs = (e) => {
    var t;
    return (t = e.elements) === null || t === void 0
      ? void 0
      : t.find((r) => r.name === "w:sdtPr");
  },
  s0 = (e) => {
    var t;
    return !!(
      !(
        (t = Cs(e)) === null ||
        t === void 0 ||
        (t = t.elements) === null ||
        t === void 0
      ) && t.some((r) => r.name === "w:showingPlcHdr")
    );
  },
  a0 = (e) => {
    var t;
    return (t = Cs(e)) === null ||
      t === void 0 ||
      (t = t.elements) === null ||
      t === void 0
      ? void 0
      : t.find((r) => r.name === "w:rPr");
  },
  o0 = new Set(["w:rPr", "w:t", "w:tab", "w:br"]),
  i0 = (e) =>
    e.name === "w:bookmarkStart" ||
    e.name === "w:bookmarkEnd" ||
    (e.name === "w:r" && ct(e).every((t) => o0.has(t.name))),
  l0 = (e, t) => {
    const r = Cs(e);
    if (!r?.elements) return;
    const n = r.elements.some((s) => s.name === "w:text") && !t.every(i0);
    r.elements = r.elements.filter(
      (s) =>
        s.name !== "w:showingPlcHdr" &&
        s.name !== "w:dataBinding" &&
        !(n && s.name === "w:text"),
    );
  },
  Kn = new Set(["w:hyperlink", "w:fldSimple", "w:subDoc"]),
  c0 = new Map([
    ["w:ins", Kn],
    ["w:moveTo", Kn],
    ["w:hyperlink", new Set(["w:hyperlink"])],
  ]),
  u0 = (e, t, r) => {
    for (let s = t.length; s > 0; s--) {
      var n;
      const a = Tr(e, t.slice(0, s - 1)),
        o = t[s - 1],
        i = a.elements[o],
        l = c0.get(i.name),
        c = (g) => !!l?.has(g.name);
      if (!(!((n = i.elements) === null || n === void 0) && n.some(c)))
        continue;
      const { elements: u } = i,
        d = u.flatMap((g, A) => (A === 0 || c(g) || c(u[A - 1]) ? [A] : [])),
        h = d.map((g, A) => u.slice(g, d[A + 1])),
        w = l === Kn;
      let m = !0;
      const v = h.map((g) => {
        if (c(g[0])) return g[0];
        const A =
          w && !m ? f(f({}, i.attributes), {}, { "w:id": r() }) : i.attributes;
        return ((m = !1), f(f({}, i), {}, { attributes: A, elements: [...g] }));
      });
      a.elements.splice(o, 1, ...v);
    }
  },
  kl = (e, t) =>
    e.name === "w:r"
      ? d0(e, t)
      : e.elements
        ? f(f({}, e), {}, { elements: e.elements.map((r) => kl(r, t)) })
        : e,
  d0 = (e, t) => {
    const r = ct(e).find((o) => o.type === "element" && o.name === "w:rPr");
    if (!r) return f(f({}, e), {}, { elements: [t, ...ct(e)] });
    const n = new Set(ct(r).map((o) => o.name)),
      s = [...ct(t).filter((o) => !n.has(o.name)), ...ct(r)],
      a = f(f({}, r), {}, { elements: [...s].sort((o, i) => Wa(o) - Wa(i)) });
    return f(f({}, e), {}, { elements: ct(e).map((o) => (o === r ? a : o)) });
  },
  bn = [
    "w:rStyle",
    "w:rFonts",
    "w:b",
    "w:bCs",
    "w:i",
    "w:iCs",
    "w:caps",
    "w:smallCaps",
    "w:strike",
    "w:dstrike",
    "w:outline",
    "w:shadow",
    "w:emboss",
    "w:imprint",
    "w:noProof",
    "w:snapToGrid",
    "w:vanish",
    "w:webHidden",
    "w:color",
    "w:spacing",
    "w:w",
    "w:kern",
    "w:position",
    "w:sz",
    "w:szCs",
    "w:highlight",
    "w:u",
    "w:effect",
    "w:bdr",
    "w:shd",
    "w:fitText",
    "w:vertAlign",
    "w:rtl",
    "w:cs",
    "w:em",
    "w:lang",
    "w:eastAsianLayout",
    "w:specVanish",
    "w:oMath",
    "w14:glow",
    "w14:shadow",
    "w14:reflection",
    "w14:textOutline",
    "w14:textFill",
    "w14:scene3d",
    "w14:props3d",
    "w14:ligatures",
    "w14:numForm",
    "w14:numSpacing",
    "w14:stylisticSets",
    "w14:cntxtAlts",
  ],
  Wa = (e) => {
    var t;
    if (e.name === "w:rPrChange") return bn.length + 1;
    const r = bn.indexOf((t = e.name) !== null && t !== void 0 ? t : "");
    return r === -1 ? bn.length : r;
  },
  ct = (e) => {
    var t;
    return (t = e.elements) !== null && t !== void 0 ? t : [];
  },
  Rl = (e) => {
    var t, r;
    const n = Number(
      (t = e.attributes) === null || t === void 0 ? void 0 : t["w:id"],
    );
    return ((r = e.elements) !== null && r !== void 0 ? r : []).reduce(
      (s, a) => Math.max(s, Rl(a)),
      Number.isInteger(n) ? n : 0,
    );
  },
  h0 = (e, t) => e.length > t.length && t.every((r, n) => e[n] === r),
  m0 = (e) =>
    e.filter((t) => !e.some((r) => h0(t.pathToParagraph, r.pathToParagraph))),
  Pl = (e, t) => {
    let r = e;
    for (let n = 1; n < t.length; n++) {
      const s = t[n];
      r = r.elements[s];
    }
    return r;
  },
  p0 = (e, t) => Pl(e, t.slice(0, t.length - 1)),
  v0 = (e) => e[e.length - 1],
  f0 = new vt(),
  Tn = "word/styles.xml",
  w0 = new Set([
    "w:pStyle",
    "w:rStyle",
    "w:tblStyle",
    "w:basedOn",
    "w:next",
    "w:link",
  ]),
  Dt = (e) => {
    var t;
    return String(
      (t = e.attributes) === null || t === void 0 ? void 0 : t["w:styleId"],
    );
  },
  zn = (e) => {
    var t;
    const r =
      (t = e.elements) === null ||
      t === void 0 ||
      (t = t.find((n) => n.name === "w:name")) === null ||
      t === void 0 ||
      (t = t.attributes) === null ||
      t === void 0
        ? void 0
        : t["w:val"];
    return r === void 0 ? void 0 : String(r).toLowerCase();
  },
  pr = (e, t) => {
    var r;
    return e == null || (r = e.elements) === null || r === void 0
      ? void 0
      : r.find((n) => n.name === t);
  },
  Ua = (e) => {
    var t;
    const r = Number(
      (t = pr(e, "w:sz")) === null ||
        t === void 0 ||
        (t = t.attributes) === null ||
        t === void 0
        ? void 0
        : t["w:val"],
    );
    return Number.isNaN(r) ? void 0 : r;
  },
  g0 = (e) => {
    var t, r;
    const n = e.filter((o) => o.name === "w:style"),
      s =
        (t = n.find((o) => Dt(o) === "Normal")) !== null && t !== void 0
          ? t
          : n.find((o) => {
              var i;
              return (
                ((i = o.attributes) === null || i === void 0
                  ? void 0
                  : i["w:type"]) === "paragraph" && zn(o) === "normal"
              );
            }),
      a = e.find((o) => o.name === "w:docDefaults");
    return (r = Ua(pr(s, "w:rPr"))) !== null && r !== void 0
      ? r
      : Ua(pr(pr(a, "w:rPrDefault"), "w:rPr"));
  },
  y0 = (e, t) =>
    new Map(
      Object.values(gs({ document: { run: { size: t } } }))
        .map((r) => Ue($(f0.format(r, e))).elements[0])
        .filter((r) => r.name === "w:style")
        .map((r) => [Dt(r), r]),
    ),
  x0 = (e, t) => {
    var r;
    const n = ce((r = e.get(Tn)) !== null && r !== void 0 ? r : {}, "w:styles"),
      s = n.filter((m) => m.name === "w:style"),
      a = new Set(s.map(Dt));
    let o;
    const i = (m) => {
        var v;
        return (
          ((v = o) !== null && v !== void 0) || (o = y0(t(Tn), g0(n))),
          o.get(m)
        );
      },
      l = new Set(),
      c = new Map(),
      u = (m) => {
        const v = a.has(m) ? void 0 : i(m);
        if (v === void 0) return m;
        const g = s.find((A) => {
          var I, b;
          return (
            ((I = A.attributes) === null || I === void 0
              ? void 0
              : I["w:type"]) ===
              ((b = v.attributes) === null || b === void 0
                ? void 0
                : b["w:type"]) && zn(A) === zn(v)
          );
        });
        return g !== void 0 ? Dt(g) : (l.add(m), m);
      },
      d = (m) => (c.has(m) || c.set(m, u(m)), c.get(m)),
      h = (m) => {
        var v;
        return w0.has((v = m.name) !== null && v !== void 0 ? v : "")
          ? f(
              f({}, m),
              {},
              {
                attributes: f(
                  f({}, m.attributes),
                  {},
                  { "w:val": d(String(m.attributes["w:val"])) },
                ),
              },
            )
          : m.elements === void 0
            ? m
            : f(f({}, m), {}, { elements: m.elements.map(h) });
      };
    return {
      use: (m) => m.map(h),
      write: () => {
        const m = e.get(Tn);
        if (!m) return;
        const v = ce(m, "w:styles"),
          g = new Set(v.map(Dt));
        for (const A of l) g.has(A) || (g.add(A), v.push(h(i(A))));
      },
    };
  },
  b0 = { type: le.PARAGRAPH, children: [] },
  T0 = ({
    json: e,
    key: t,
    patch: r,
    delimiters: { start: n, end: s },
    patchPlaceholder: a,
    renumberDrawings: o,
  }) => {
    const i = `${n}${t}.`;
    for (const l of E0(e, i)) {
      const c = I0(l.elements, i, s),
        u = r.rows.flatMap((d, h) => {
          const w = {
              type: "element",
              name: "w:tbl",
              elements: [...(h === 0 ? l.elements.map(C0) : o(_l(l.elements)))],
            },
            m = new Map(
              Object.entries(d).flatMap(([v, g]) =>
                g === void 0 ? [] : [[v, g]],
              ),
            );
          for (const [v, g] of m) a(w, `${t}.${v}`, g);
          for (const v of c.filter((g) => !m.has(g))) a(w, `${t}.${v}`, b0);
          return w.elements;
        });
      (l.parent.elements.splice(
        l.parent.elements.indexOf(l.elements[0]),
        l.elements.length,
        ...u,
      ),
        l.table &&
          !Ol(l.table.element) &&
          l.table.parent.elements.splice(
            l.table.parent.elements.indexOf(l.table.element),
            1,
          ));
    }
  },
  E0 = (e, t) => {
    const r = Is(e, t).flatMap((s) => {
        const a = S0(e, s.pathToParagraph);
        return a ? [a] : [];
      }),
      n = r
        .filter((s) => !r.some((a) => A0(s.path, a.path)))
        .filter((s, a, o) => o.findIndex((i) => i.row === s.row) === a);
    return [...new Set(n.map((s) => s.parent))].flatMap((s) => {
      const a = s.elements.filter((l) => l.name === "w:tr"),
        o = n
          .filter((l) => l.parent === s)
          .map((l) => a.indexOf(l.row))
          .sort((l, c) => l - c),
        { table: i } = n.find((l) => l.parent === s);
      return o
        .reduce((l, c) => {
          const u = l[l.length - 1];
          return u?.[u.length - 1] === c - 1
            ? [...l.slice(0, -1), [...u, c]]
            : [...l, [c]];
        }, [])
        .map((l) => {
          const c = s.elements.indexOf(a[l[0]]),
            u = s.elements.indexOf(a[l[l.length - 1]]);
          return { parent: s, table: i, elements: s.elements.slice(c, u + 1) };
        });
    });
  },
  S0 = (e, t) => {
    let r = e,
      n,
      s;
    for (let a = 1; a < t.length; a++) {
      const o = r.elements[t[a]];
      (o.name === "w:tbl" && (s = { element: o, parent: r }),
        o.name === "w:tr" &&
          (n = { parent: r, table: s, row: o, path: t.slice(0, a + 1) }),
        (r = o));
    }
    return n;
  },
  A0 = (e, t) => e.length > t.length && t.every((r, n) => e[n] === r),
  Ol = (e) => {
    var t;
    return ((t = e.elements) !== null && t !== void 0 ? t : []).some(
      (r) =>
        r.name === "w:tr" ||
        (r.name !== "w:tblPr" && r.name !== "w:tblGrid" && Ol(r)),
    );
  },
  I0 = (e, t, r) => {
    const n = Is({ elements: [...e] }, t).flatMap(({ text: s }) =>
      s
        .split(t)
        .slice(1)
        .flatMap((a) => {
          const o = a.indexOf(r);
          return o > 0 ? [a.slice(0, o)] : [];
        }),
    );
    return [...new Set(n)];
  },
  C0 = (e) => JSON.parse(JSON.stringify(e)),
  N0 = ["w14:paraId", "w14:textId"],
  k0 = ["w:bookmarkStart", "w:bookmarkEnd"],
  _l = (e, t) =>
    e
      .filter((r) => {
        var n;
        return (
          !k0.includes((n = r.name) !== null && n !== void 0 ? n : "") &&
          !(t?.name === "w:sdtPr" && r.name === "w:id")
        );
      })
      .map((r) =>
        f(
          f(
            f({}, r),
            r.attributes === void 0
              ? {}
              : {
                  attributes: Object.fromEntries(
                    Object.entries(r.attributes).filter(
                      ([n]) => !N0.includes(n),
                    ),
                  ),
                },
          ),
          r.elements === void 0 ? {} : { elements: [..._l(r.elements, r)] },
        ),
      ),
  R0 = (e) => (e[0] === 255 && e[1] === 254) || (e[0] === 254 && e[1] === 255),
  P0 = (e) => {
    var t;
    const r = ul(e, "word/document.xml"),
      n =
        r === void 0 ||
        (t = [...e].find(([s]) => Qi(s, r))) === null ||
        t === void 0
          ? void 0
          : t[1];
    return n === void 0 || R0(n) ? void 0 : Jn(Pf(Fr(n)));
  },
  Er = (e, t, { start: r, end: n }, s) => {
    for (let a = e.indexOf(r, t); a !== -1; a = e.indexOf(r, a + 1)) {
      const o = e.indexOf(n, a + r.length);
      if (o === -1) return;
      const i = e.slice(a + r.length, o),
        l = i.trim();
      if (l !== i && s(l))
        return {
          index: a,
          placeholder: e.slice(a, o + n.length),
          trimmed: `${r}${l}${n}`,
        };
    }
  },
  O0 = (e, t, r) => {
    let n = e;
    for (
      let s = Er(n, 0, t, r);
      s !== void 0;
      s = Er(n, s.index + s.trimmed.length, t, r)
    )
      n = `${n.slice(0, s.index)}${s.trimmed}${n.slice(s.index + s.placeholder.length)}`;
    return n;
  },
  Ll = (e) => {
    var t;
    return ((t = e.elements) !== null && t !== void 0 ? t : []).flatMap((r) => [
      ...(r.name === "w:p" ? [r] : []),
      ...Ll(r),
    ]);
  },
  _0 = (e, t, r) => {
    const n = () => Jt({ element: e, index: 0, parent: void 0 });
    for (
      let s = n(), a = Er(s.text, 0, t, r);
      a !== void 0;
      s = n(), a = Er(s.text, a.index + a.trimmed.length, t, r)
    )
      Cl({
        paragraphElement: e,
        renderedParagraph: s,
        originalText: a.placeholder,
        replacementText: a.trimmed,
        fromIndex: a.index,
      });
  },
  L0 = (
    e,
    { delimiters: t, textKeys: r, tableRowsKeys: n, drawingKeys: s },
  ) => {
    const a = (l) => r.has(l) || n.some((c) => l.startsWith(`${c}.`));
    for (const l of Ll(e)) _0(l, t, a);
    const o = (l) => s.has(l);
    for (const { properties: l } of $r(e))
      for (const c of ["descr", "title"]) {
        var i;
        const u = (i = l.attributes) === null || i === void 0 ? void 0 : i[c];
        u !== void 0 && (l.attributes[c] = O0(String(u), t, o));
      }
  },
  Dl = (e) => {
    var t;
    return e.name === "v:shapetype" &&
      ((t = e.attributes) === null || t === void 0 ? void 0 : t.id) !== void 0
      ? String(e.attributes.id)
      : void 0;
  },
  Ml = (e) => {
    var t;
    const r = Dl(e);
    return [
      ...(r === void 0 ? [] : [r]),
      ...((t = e.elements) !== null && t !== void 0 ? t : []).flatMap(Ml),
    ];
  },
  D0 = (e) => {
    const t = new Set(Ml(e)),
      r = (n) => {
        const s = Dl(n);
        return s !== void 0
          ? t.has(s)
            ? []
            : (t.add(s), [n])
          : [
              n.elements === void 0
                ? n
                : f(f({}, n), {}, { elements: n.elements.flatMap(r) }),
            ];
      };
    return (n) => n.flatMap(r);
  },
  M0 =
    "http://schemas.openxmlformats.org/officeDocument/2006/relationships/image",
  F0 = {
    png: "image/png",
    jpg: "image/jpeg",
    gif: "image/gif",
    bmp: "image/bmp",
    svg: "image/svg+xml",
  },
  $0 = ["png", "jpg", "gif", "bmp"],
  Ga = 9525,
  ja = "{96DAC541-7B7A-43D3-8B79-37D633B846F1}",
  H0 = "{BEBA8EAE-BF5A-486C-A8C5-ECC9F3942E4B}",
  Te = (e, t) => {
    var r;
    return e == null || (r = e.elements) === null || r === void 0
      ? void 0
      : r.find((n) => n.name === t);
  },
  B0 = (e) => {
    const t = ns(e);
    return ArrayBuffer.isView(t)
      ? new Uint8Array(t.buffer, t.byteOffset, t.byteLength)
      : new Uint8Array(t);
  },
  Fl = (e, t) =>
    new uv({
      folder: "media",
      name: "image",
      extension: e,
      contentType: F0[e],
      relationshipType: M0,
      content: B0(t),
    }),
  Va = (e, t) => {
    const r = So(e, t);
    if (!$0.includes(r))
      throw new Error(
        `${t}: invalid type "${r}". Expected "png", "jpg", "gif", "bmp" or, with a fallback, "svg"`,
      );
    return Fl(r, e.data);
  },
  W0 = new Map([
    [
      "c:chart",
      "It is a chart, not a picture. Give a chart new data with ChartDataPatch from docx/charts",
    ],
    [
      "cx:chart",
      "It is a chart, not a picture. Give a chart new data with ChartDataPatch from docx/charts",
    ],
    [
      "wpg:wgp",
      "It is a group of drawings. Ungroup the picture in Word, and put the placeholder in its alt text",
    ],
    [
      "wpc:wpc",
      "It is a drawing canvas. Move the picture out of it in Word, and put the placeholder in its alt text",
    ],
    ["wps:wsp", "It is a shape, not a picture"],
  ]),
  U0 = (e, t) => {
    var r, n;
    const s = Te(Te(e, "a:graphic"), "a:graphicData"),
      a = Te(s, "pic:pic");
    if (a !== void 0) return a;
    const o =
      s == null ||
      (r = s.elements) === null ||
      r === void 0 ||
      (r = r.find((i) => i.type === "element")) === null ||
      r === void 0
        ? void 0
        : r.name;
    throw new Error(
      `Can't patch the picture ${t}. ${(n = W0.get(o ?? "")) !== null && n !== void 0 ? n : "It isn't a picture"}`,
    );
  },
  G0 = (e, t) => {
    var r, n;
    const s = (r = e.elements) !== null && r !== void 0 ? r : [],
      a = Te(e, "a:extLst"),
      o =
        t === void 0
          ? []
          : [
              {
                type: "element",
                name: "a:ext",
                attributes: { uri: ja },
                elements: [
                  {
                    type: "element",
                    name: "asvg:svgBlip",
                    attributes: {
                      "xmlns:asvg":
                        "http://schemas.microsoft.com/office/drawing/2016/SVG/main",
                      "r:embed": t,
                    },
                  },
                ],
              },
            ],
      i = [
        ...((n = a?.elements) !== null && n !== void 0 ? n : []).filter((c) => {
          var u;
          return (
            c.name === "a:ext" &&
            ![ja, H0].includes(
              String(
                (u = c.attributes) === null || u === void 0 ? void 0 : u.uri,
              ).toUpperCase(),
            )
          );
        }),
        ...o,
      ],
      l =
        i.length === 0
          ? []
          : [
              f(
                f({}, a),
                {},
                { type: "element", name: "a:extLst", elements: i },
              ),
            ];
    return [...s.filter((c) => c !== a), ...l];
  },
  Xa = (e, t, r) => {
    var n, s;
    const a = (l) => {
        var c;
        const u = (c = e.attributes) === null || c === void 0 ? void 0 : c[l];
        return u === void 0 ? void 0 : String(u).split(t).join("").trim();
      },
      o = (n = r?.description) !== null && n !== void 0 ? n : a("descr"),
      i = (s = r?.title) !== null && s !== void 0 ? s : a("title");
    e.attributes = Object.fromEntries(
      Object.entries(
        f(f({}, e.attributes), {}, { descr: o || void 0, title: i || void 0 }),
      ).filter(([, l]) => l !== void 0),
    );
  },
  Ka = (e, { width: t, height: r }) => {
    e !== void 0 &&
      (e.attributes = f(
        f({}, e.attributes),
        {},
        { cx: Math.round(t * Ga), cy: Math.round(r * Ga) },
      ));
  },
  Ky = class extends Ew {
    constructor(e) {
      if (
        (super(),
        p(this, "image", void 0),
        p(this, "svg", void 0),
        p(this, "transformation", void 0),
        p(this, "altText", void 0),
        e.type === "svg")
      ) {
        if (e.fallback === void 0)
          throw new Error(
            "ImagePatch: an SVG image needs a fallback, a PNG, JPEG, GIF or BMP image for applications that can't show SVG",
          );
        ((this.image = Va(e.fallback, "ImagePatch fallback")),
          (this.svg = Fl("svg", e.data)));
      } else this.image = Va(e, "ImagePatch");
      const { transformation: t } = e;
      if (t !== void 0) {
        for (const r of ["width", "height"]) {
          const n = t[r];
          if (!(typeof n == "number" && n > 0 && Number.isFinite(n)))
            throw new Error(
              `ImagePatch: invalid ${r} ${String(n)}. Expected a number of pixels greater than 0`,
            );
        }
        this.transformation = { width: t.width, height: t.height };
      }
      this.altText = e.altText && f({}, e.altText);
    }
    patch({ element: e, properties: t, placeholder: r, part: n }, s) {
      var a;
      const o = U0(e, r),
        i = Te(o, "pic:blipFill"),
        l = Te(i, "a:blip");
      if (i === void 0 || l === void 0)
        throw new Error(
          `Can't patch the picture ${r}. It has no image: it has no a:blip`,
        );
      const c = s.replaceRelatedPart(n, void 0, this.image),
        u = this.svg && s.replaceRelatedPart(n, void 0, this.svg);
      ((l.attributes = f(
        { "r:embed": c },
        Object.fromEntries(
          Object.entries(
            (a = l.attributes) !== null && a !== void 0 ? a : {},
          ).filter(([h]) => !/^[^:]+:(embed|link)$/.test(h)),
        ),
      )),
        (l.elements = [...G0(l, u)]),
        (i.elements = i.elements.filter((h) => h.name !== "a:srcRect")),
        this.transformation !== void 0 &&
          (Ka(Te(e, "wp:extent"), this.transformation),
          Ka(
            Te(Te(Te(o, "pic:spPr"), "a:xfrm"), "a:ext"),
            this.transformation,
          )),
        Xa(t, r, this.altText));
      const d = Te(Te(o, "pic:nvPicPr"), "pic:cNvPr");
      d !== void 0 && Xa(d, r, this.altText);
    }
  },
  $l = (e, t, { inTableRow: r }) => {
    if (t?.type === le.TABLE_ROWS && Array.isArray(t.rows)) {
      for (const n of t.rows) {
        if (typeof n != "object" || n === null)
          throw new Error(
            `Invalid patch "${e}". Expected each of its rows to be an object of patches, by the name of their field`,
          );
        for (const [s, a] of Object.entries(n))
          a !== void 0 && $l(`${e}.${s}`, a, { inTableRow: !0 });
      }
      return;
    }
    if (
      !(t?.type === le.DRAWING
        ? !r && typeof t.patch == "function"
        : t?.type !== le.TABLE_ROWS && Array.isArray(t?.children))
    )
      throw new Error(
        `Invalid patch "${e}". Expected { type: PatchType.PARAGRAPH or PatchType.DOCUMENT, children: [...] }, ${r ? "or { type: PatchType.TABLE_ROWS, rows: [...] }" : "{ type: PatchType.TABLE_ROWS, rows: [...] }, or a drawing patch such as ImagePatch, or ChartDataPatch from docx/charts"}`,
      );
  },
  za = new pl(),
  j0 = new Uint8Array([255, 254]),
  V0 = new Uint8Array([254, 255]),
  X0 = new Set([
    "w:document",
    "w:hdr",
    "w:ftr",
    "w:footnotes",
    "w:endnotes",
    "w:comments",
  ]),
  Ya = (e, t) => {
    if (e.length !== t.length) return !1;
    for (let r = 0; r < e.length; r++) if (e[r] !== t[r]) return !1;
    return !0;
  },
  zy = (function () {
    var e = it(function* ({
      outputType: t,
      data: r,
      patches: n,
      keepOriginalStyles: s,
      placeholderDelimiters: a = { start: "{{", end: "}}" },
      recursive: o = !0,
      trimPlaceholders: i = !1,
      footnotes: l,
      endnotes: c,
      numbering: u = { config: [] },
      pageNumbers: d,
      properties: h,
    }) {
      const w = yield Tl(r),
        m = new Map(),
        v = P0(w),
        g = [],
        A = new Bi(
          { addOverride: (P, M) => g.push({ contentType: P, partName: M }) },
          new Set(
            [...w.keys()]
              .filter((P) => P.startsWith("word/"))
              .map((P) => P.slice(5)),
          ),
        ),
        I = {
          Media: new Fi((P) => A.takePath("media", "image", P)),
          Numbering: new Hi(u),
          Theme: v && { Colors: v },
          FootNotes: { View: { idOf: (P, M, F) => tt("footnotes", P, M, F) } },
          Endnotes: { View: { idOf: (P, M, F) => tt("endnotes", P, M, F) } },
          PackageParts: A,
        },
        b = new Map(),
        R = [],
        O = [];
      let E = !1;
      const T = new Map();
      yl(a);
      const { start: S, end: C } = a;
      for (const [P, M] of Object.entries(n)) $l(P, M, { inTableRow: !1 });
      for (const [P, M] of w) {
        var k;
        const F = M.slice(0, 2);
        if (Ya(F, j0) || Ya(F, V0)) {
          T.set(P, M);
          continue;
        }
        if (!P.endsWith(".xml") && !P.endsWith(".rels")) {
          T.set(P, M);
          continue;
        }
        const G = Ue(Fr(M)),
          Y =
            (k = G.elements) === null || k === void 0
              ? void 0
              : k.find((q) => {
                  var B;
                  return X0.has((B = q.name) !== null && B !== void 0 ? B : "");
                });
        if (Y && Y.attributes) {
          for (const q of ["mc", "wp", "r", "w15", "m", "v", "o"])
            Y.attributes[`xmlns:${q}`] = Pn[q];
          Y.attributes["mc:Ignorable"] =
            `${Y.attributes["mc:Ignorable"] || ""} w15`.trim();
        }
        b.set(P, G);
      }
      const L = lw([...b.values()].flatMap(fl)),
        D = Tw([...b.values()].flatMap(xl)),
        j = new Map(),
        z = (P) => {
          const M = j.get(P);
          if (M) return M;
          const F = {
            Relationships: {
              addRelationship: (G, Y, q, B) => {
                O.push({ key: P, id: G, type: Y, target: q, targetMode: B });
              },
            },
          };
          return (j.set(P, F), F);
        },
        V = (P) => ({ file: I, viewWrapper: z(P), stack: [] }),
        X = (P, M) => {
          g.push({ contentType: P, partName: M });
        },
        H = x0(b, V),
        re = Xw(I.Numbering, b, {
          createContext: V,
          addContentTypeOverride: X,
        }),
        J = Hw({ footnotes: l, endnotes: c }, b, {
          createContext: V,
          addContentTypeOverride: X,
          renumberBookmarks: L,
          renumberDrawings: D,
          renumberLists: re.renumber,
          useStyles: H.use,
        }),
        tt = (P, M, F, G) =>
          G.viewWrapper === z("word/document.xml") ? J.carry(P, M, F) : void 0;
      if (i) {
        const P = (F) =>
            Object.entries(n).flatMap(([G, Y]) => (F(Y.type) ? [G] : [])),
          M = {
            delimiters: { start: S, end: C },
            textKeys: new Set(
              P((F) => F !== le.TABLE_ROWS && F !== le.DRAWING),
            ),
            tableRowsKeys: P((F) => F === le.TABLE_ROWS),
            drawingKeys: new Set(P((F) => F === le.DRAWING)),
          };
        for (const [F, G] of b)
          F.startsWith("word/") && !F.endsWith(".rels") && L0(G, M);
      }
      kw(
        {
          parts: b,
          binaryParts: T,
          file: I,
          patches: Object.entries(n).flatMap(([P, M]) =>
            M.type === le.DRAWING ? [[P, M]] : [],
          ),
          delimiters: { start: S, end: C },
        },
        V,
      );
      const ve = Object.entries(n).flatMap(([P, M]) =>
          M.type === le.DRAWING ? [] : [[P, M]],
        ),
        Ie = [
          ...ve.filter(([, P]) => P.type === le.TABLE_ROWS),
          ...ve.filter(([, P]) => P.type !== le.TABLE_ROWS),
        ];
      for (const [P, M] of [...b]) {
        if (!P.startsWith("word/") || P.endsWith(".xml.rels")) continue;
        const F = V(P);
        m.set(P, F);
        const G = D0(M),
          Y = (q, B, xe) => {
            if (xe.type === le.TABLE_ROWS) {
              T0({
                json: q,
                key: B,
                patch: xe,
                delimiters: { start: S, end: C },
                patchPlaceholder: Y,
                renumberDrawings: D,
              });
              return;
            }
            const Ns = [],
              { didFindOccurrence: Hl } = r0({
                json: q,
                patch: f(
                  f({}, xe),
                  {},
                  {
                    children: xe.children
                      .flatMap((Ce) => (Ce instanceof li ? Ce.writtenAs : [Ce]))
                      .map((Ce) => {
                        if (Ce instanceof Ph) {
                          const { target: Bl, anchor: Wl } = hi(
                              Ce.options.link,
                            ),
                            ks = new Kt(
                              Ce.options.children,
                              at(),
                              Wl,
                              Ce.options.link,
                            );
                          return (
                            Ns.push({
                              key: P,
                              id: ks.linkId,
                              type: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink",
                              target: Bl,
                              targetMode: ss.EXTERNAL,
                            }),
                            ks
                          );
                        } else return Ce;
                      }),
                  },
                ),
                patchText: `${S}${B}${C}`,
                context: F,
                keepOriginalStyles: s,
                recursive: o,
                renumberIds: (Ce) =>
                  H.use(re.renumber(J.renumber(L(D(G(Ce)))))),
              });
            Hl && O.push(...Ns);
          };
        for (const [q, B] of Ie) Y(M, q, B);
      }
      (J.write(), re.write(), H.write());
      for (const [P, M] of b) {
        if (!P.startsWith("word/") || P.endsWith(".xml.rels")) continue;
        const F = za.getMediaData(JSON.stringify(M), I.Media);
        F.length > 0 && ((E = !0), R.push({ key: P, mediaDatas: F }));
      }
      for (const { key: P, mediaDatas: M } of R) {
        var ae;
        const F = Oe(P),
          G = (ae = b.get(F)) !== null && ae !== void 0 ? ae : Wt();
        b.set(F, G);
        const Y = Ss(G),
          q = za.replace(JSON.stringify(b.get(P)), M, Y);
        b.set(P, JSON.parse(q));
        for (let B = 0; B < M.length; B++) {
          const { fileName: xe } = M[B];
          Wn(
            G,
            Y + B,
            "http://schemas.openxmlformats.org/officeDocument/2006/relationships/image",
            `media/${xe}`,
          );
        }
      }
      for (const { key: P, id: M, type: F, target: G, targetMode: Y } of O) {
        var oe;
        const q = Oe(P),
          B = (oe = b.get(q)) !== null && oe !== void 0 ? oe : Wt();
        (b.set(q, B), Wn(B, M, F, G, Y));
      }
      (d && (yield qw(b, d, T)),
        h && yw(b, T, h, { addContentTypeOverride: X }));
      const U = Es(I, void 0);
      if (E || g.length > 0) {
        const P = b.get("[Content_Types].xml");
        if (!P) throw new Error("Could not find content types file");
        E &&
          (wt(P, "image/png", "png"),
          wt(P, "image/jpeg", "jpeg"),
          wt(P, "image/jpeg", "jpg"),
          wt(P, "image/bmp", "bmp"),
          wt(P, "image/gif", "gif"),
          wt(P, "image/svg+xml", "svg"));
        for (const { contentType: M, partName: F } of g) uw(P, M, F);
      }
      return Hn(
        yr([
          ...[...b].map(([P, M]) => [P, ec(M)]),
          ...T,
          ...I.Media.Array.map(({ data: P, fileName: M }) => [
            `word/media/${M}`,
            P,
          ]),
          ...U.map(({ path: P, data: M }) => [P, M]),
        ]),
        t,
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      );
    });
    return function (r) {
      return e.apply(this, arguments);
    };
  })(),
  K0 = (e) =>
    e.startsWith("word/") &&
    /\.(xml|rels)$/.test(e) &&
    !e.endsWith(".xml.rels"),
  Yy = (function () {
    var e = it(function* ({
      data: t,
      placeholderDelimiters: r = { start: "{{", end: "}}" },
      trimPlaceholders: n = !1,
    }) {
      yl(r);
      const s = z0(r),
        a = yield Tl(t, K0),
        o = new Set();
      for (const [, i] of a) {
        const l = Ue(Fr(i));
        [
          ...Nl(l).map((c) => c.text),
          ...$r(l).flatMap(({ properties: c }) => bl(c)),
        ]
          .flatMap((c) => {
            var u;
            return (u = c.match(s)) !== null && u !== void 0 ? u : [];
          })
          .map((c) => (n ? c.trim() : c))
          .filter((c) => c !== "")
          .forEach((c) => o.add(c));
      }
      return Array.from(o);
    });
    return function (r) {
      return e.apply(this, arguments);
    };
  })(),
  En = (e) => e.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"),
  z0 = ({ start: e, end: t }) =>
    new RegExp(`(?<=${En(e)})(?:(?!${En(e)}).)+?(?=${En(t)})`, "gs");
export {
  en as AbstractNumbering,
  de as AlignmentType,
  Cg as AnnotationReference,
  pe as Attributes,
  Ut as BaseXmlComponent,
  bi as Body,
  li as Bookmark,
  di as BookmarkEnd,
  ui as BookmarkStart,
  Ec as Border,
  es as BorderStyle,
  x as BuilderElement,
  Og as CarriageReturn,
  jm as CellMerge,
  Gm as CellMergeAttributes,
  Vg as CharacterSet,
  Vy as CheckBox,
  pn as CheckBoxSymbolElement,
  $f as CheckBoxUtil,
  Oy as Column,
  Hg as ColumnBreak,
  js as Comment,
  vg as CommentRangeEnd,
  pg as CommentRangeStart,
  fg as CommentReference,
  uh as Comments,
  fh as CommentsExtended,
  xh as CommentsIds,
  Kt as ConcreteHyperlink,
  ra as ConcreteNumbering,
  Rg as ContinuationSeparator,
  Sg as DayLong,
  bg as DayShort,
  Um as DeletedTableCell,
  Bm as DeletedTableRow,
  Sy as DeletedTextRun,
  $y as Document,
  Pn as DocumentAttributeNamespaces,
  Lr as DocumentAttributes,
  Np as DocumentBackground,
  _y as DocumentBackgroundAttributes,
  Uv as DocumentDefaults,
  my as DocumentGridType,
  My as DocumentProtectionType,
  os as Drawing,
  Ew as DrawingPatch,
  Xg as DropCapType,
  Vl as EMPTY_OBJECT,
  gg as EditableRangeEnd,
  wg as EditableRangeStart,
  po as EmphasisMarkType,
  ue as EmptyElement,
  Sa as EndnoteIdReference,
  fy as EndnotePosition,
  bh as EndnoteReference,
  jy as EndnoteReferenceRun,
  Ff as EndnoteReferenceRunAttributes,
  Li as Endnotes,
  Ph as ExternalHyperlink,
  $y as File,
  Or as FileChild,
  Mf as FootNoteReferenceRunAttributes,
  Mi as FootNotes,
  Uy as Footer,
  $p as FooterWrapper,
  vy as FootnotePosition,
  Ea as FootnoteReference,
  Ng as FootnoteReferenceElement,
  Gy as FootnoteReferenceRun,
  Kg as FrameAnchorType,
  zg as FrameWrap,
  Ym as GridSpan,
  Wy as Header,
  yt as HeaderFooterReferenceType,
  Ks as HeaderFooterType,
  Vp as HeaderWrapper,
  Bg as HeadingLevel,
  Ry as HeightRule,
  ag as HighlightColor,
  Z0 as HorizontalPositionAlign,
  pu as HorizontalPositionRelativeFrom,
  Br as HpsMeasureElement,
  Ug as HyperlinkType,
  Ze as IgnoreIfEmptyXmlComponent,
  Ky as ImagePatch,
  cg as ImageRun,
  nc as ImportedRootElementAttributes,
  rc as ImportedXmlComponent,
  no as InitializableXmlComponent,
  Wm as InsertedTableCell,
  Hm as InsertedTableRow,
  Ey as InsertedTextRun,
  ii as InternalHyperlink,
  _g as LastRenderedPageBreak,
  Ah as LeaderType,
  ev as Level,
  $i as LevelBase,
  Dy as LevelForOverride,
  je as LevelFormat,
  ov as LevelOverride,
  Ly as LevelSuffix,
  py as LineNumberRestartFormat,
  xt as LineRuleType,
  Yg as Math,
  dy as MathAngledBrackets,
  uy as MathCurlyBrackets,
  am as MathDegree,
  Yh as MathDenominator,
  Jg as MathFraction,
  iy as MathFunction,
  cm as MathFunctionName,
  um as MathFunctionProperties,
  Qg as MathIntegral,
  wi as MathLimit,
  ty as MathLimitLower,
  ey as MathLimitUpper,
  qh as MathNumerator,
  ay as MathPreSubSuperScript,
  oy as MathRadical,
  lm as MathRadicalProperties,
  ly as MathRoundBrackets,
  qg as MathRun,
  cy as MathSquareBrackets,
  ny as MathSubScript,
  sy as MathSubSuperScript,
  Zg as MathSum,
  ry as MathSuperScript,
  Fi as Media,
  Ag as MonthLong,
  Tg as MonthShort,
  Sr as NextAttributeComponent,
  yg as NoBreakHyphen,
  lg as NonVisualDrawingProperties,
  wy as NoteNumberRestart,
  eg as NumberFormat,
  tr as NumberProperties,
  Ot as NumberValueElement,
  jg as NumberedItemReference,
  Gg as NumberedItemReferenceFormat,
  Hi as Numbering,
  N as OnOffElement,
  Ny as OverlapType,
  uv as PackagePart,
  iw as Packer,
  gy as PageBorderDisplay,
  yy as PageBorderOffsetFrom,
  xy as PageBorderZOrder,
  xm as PageBorders,
  $g as PageBreak,
  Eh as PageBreakBefore,
  ut as PageNumber,
  Pg as PageNumberElement,
  Tm as PageNumberSeparator,
  wr as PageOrientation,
  Fh as PageReference,
  Im as PageTextDirection,
  by as PageTextDirectionType,
  me as Paragraph,
  dt as ParagraphProperties,
  Xs as ParagraphPropertiesChange,
  Bv as ParagraphPropertiesDefaults,
  iu as ParagraphRunProperties,
  le as PatchType,
  Fg as PositionalTab,
  Lg as PositionalTabAlignment,
  Mg as PositionalTabLeader,
  Dg as PositionalTabRelativeTo,
  ow as PrettifyType,
  Jr as RelativeHorizontalPosition,
  tp as RelativeVerticalPosition,
  te as Run,
  Qe as RunProperties,
  lu as RunPropertiesChange,
  Wv as RunPropertiesDefaults,
  ig as SchemeColor,
  Nn as SectionProperties,
  Nm as SectionPropertiesChange,
  Ty as SectionType,
  kg as Separator,
  hg as SequentialIdentifier,
  Oc as ShadingType,
  Uo as SimpleField,
  mg as SimpleMailMergeField,
  xg as SoftHyphen,
  fe as SpaceType,
  lt as StringContainer,
  J0 as StringEnumValueElement,
  $e as StringValueElement,
  ht as StyleForCharacter,
  et as StyleForParagraph,
  By as StyleLevel,
  rn as Styles,
  du as SymbolRun,
  Zm as TDirection,
  Pr as Tab,
  Wg as TabStopPosition,
  Vs as TabStopType,
  Py as Table,
  Cy as TableAnchorType,
  Ii as TableBorders,
  Zs as TableCell,
  Km as TableCellBorders,
  ky as TableLayoutType,
  Hy as TableOfContents,
  vs as TableProperties,
  hp as TableRow,
  Ni as TableRowProperties,
  up as TableRowPropertiesChange,
  Iy as TextDirection,
  sg as TextEffect,
  Ye as TextRun,
  Oo as TextWrappingSide,
  At as TextWrappingType,
  Xy as Textbox,
  Sc as ThematicBreak,
  Zv as Theme,
  tg as TwoLinesInOneBrackets,
  Eo as UnderlineType,
  hy as VerticalAlign,
  pm as VerticalAlignSection,
  mm as VerticalAlignTable,
  og as VerticalAnchor,
  Js as VerticalMerge,
  Ay as VerticalMergeRevisionType,
  Si as VerticalMergeType,
  Q0 as VerticalPositionAlign,
  vu as VerticalPositionRelativeFrom,
  ze as WidthType,
  dg as WpgGroupRun,
  ug as WpsShapeRun,
  _ as XmlAttributeComponent,
  y as XmlComponent,
  Ig as YearLong,
  Eg as YearShort,
  Xc as abstractNumUniqueNumericIdGen,
  go as bookmarkUniqueNumericId,
  qc as bookmarkUniqueNumericIdGen,
  ch as commentIdToParaId,
  Kc as concreteNumUniqueNumericIdGen,
  Ne as convertInchesToTwip,
  ng as convertMillimetersToTwip,
  Yn as convertToXmlComponent,
  io as createAlignment,
  yu as createBodyProperties,
  Q as createBorderElement,
  vm as createColumns,
  fm as createDocumentGrid,
  rg as createDotEmphasisMark,
  Dc as createEastAsianLayout,
  vo as createEmphasisMark,
  ym as createEndnoteProperties,
  Qc as createFitText,
  gm as createFootnoteProperties,
  jh as createFrameProperties,
  qr as createHeaderFooterReference,
  wu as createHorizontalPosition,
  Ac as createIndent,
  wm as createLineNumberType,
  Jh as createMathAccentCharacter,
  ye as createMathBase,
  Zh as createMathLimitLocation,
  vi as createMathNAryProperties,
  sm as createMathPreSubSuperScriptProperties,
  zt as createMathSubScriptElement,
  rm as createMathSubScriptProperties,
  nm as createMathSubSuperScriptProperties,
  Yt as createMathSuperScriptElement,
  tm as createMathSuperScriptProperties,
  Dh as createOutlineLevel,
  bm as createPageMargin,
  Em as createPageNumberType,
  Sm as createPageSize,
  Pt as createParagraphStyle,
  Ur as createRunFonts,
  Cm as createSectionType,
  kr as createShading,
  fu as createSimplePos,
  Sh as createSpacing,
  Et as createStringElement,
  Ch as createTabStop,
  Ih as createTabStopItem,
  rp as createTableFloatProperties,
  np as createTableLayout,
  ap as createTableLook,
  cp as createTableRowHeight,
  Ht as createTableWidthElement,
  Wo as createTransformation,
  ou as createUnderline,
  gi as createVerticalAlign,
  gu as createVerticalPosition,
  Uf as createVmlShape,
  Hs as createWrapNone,
  sd as createWrapSquare,
  id as createWrapThrough,
  od as createWrapTight,
  ld as createWrapTopAndBottom,
  uc as dateTimeValue,
  K as decimalNumber,
  Yc as docPropertiesUniqueNumericId,
  zc as docPropertiesUniqueNumericIdGen,
  lc as eighthPointMeasureValue,
  Gt as elementOf,
  bo as encodeUtf8,
  ah as fillPageNumbers,
  Xt as fillPartPageNumbers,
  sh as fillSequenceNumbers,
  Zc as fitTextUniqueNumericId,
  yo as hashedId,
  ao as hexColorValue,
  oc as hpsMeasureValue,
  qa as isXmlComponent,
  Y0 as longHexNumber,
  oo as measurementOrPercentValue,
  Yy as patchDetector,
  zy as patchDocument,
  ic as percentageValue,
  cc as pointMeasureValue,
  so as positiveUniversalMeasureValue,
  Fy as readTheme,
  De as sectionMarginDefaults,
  lr as sectionPageSizeDefaults,
  sc as shortHexNumber,
  q0 as signedHpsMeasureValue,
  Fe as signedTwipsMeasureValue,
  ns as standardizeData,
  ee as twipsMeasureValue,
  Ps as uCharHexNumber,
  at as uniqueId,
  Tt as uniqueNumericIdCreator,
  xo as uniqueUuid,
  nt as universalMeasureToTwips,
  Cr as universalMeasureValue,
  Ar as unsignedDecimalNumber,
};
