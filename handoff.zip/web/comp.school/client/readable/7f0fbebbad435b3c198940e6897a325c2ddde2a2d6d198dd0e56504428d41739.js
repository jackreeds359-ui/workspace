import { j as e, r as O } from "./react-vendor-BK1G6oO1.js";
import {
  cr as ot,
  cs as b,
  ct as je,
  cu as nt,
  cv as jt,
  cw as ft,
  cq as pt,
  a6 as kt,
  cx as Ze,
  cp as yt,
  cb as ut,
  R as gt,
  bm as Ie,
  b6 as Oe,
  cy as Mt,
} from "./index-DjyiOHey.js";
import { u as wt } from "./NetworkTraceGame-Qz8SQ8Dr.js";
const Re = 360,
  at = 220,
  B = "#0f172a",
  ne = "#334155",
  Ce = "#5eead4";
function Lt({ career: t, className: r }) {
  const { look: s } = t;
  return e.jsxs("svg", {
    className: r,
    viewBox: `0 0 ${Re} ${at}`,
    role: "img",
    "aria-label": `${t.title} at work`,
    "data-career-scene": s.set,
    children: [
      e.jsx(vt, { set: s.set }),
      e.jsxs("g", {
        className: "career-figure",
        children: [
          e.jsx(Wt, { outfit: s.outfit, colour: s.outfitColour }),
          e.jsx("svg", {
            x: 152,
            y: 62,
            width: 96,
            height: 96,
            overflow: "visible",
            children: e.jsx(ot, {
              features: s.features,
              idSuffix: `career-${t.id}`,
            }),
          }),
          e.jsx($t, { outfit: s.outfit, colour: s.outfitColour }),
          e.jsx(bt, { prop: s.prop }),
        ],
      }),
    ],
  });
}
function mt({ career: t, className: r }) {
  return e.jsx("span", {
    className: r,
    "data-career-face": t.id,
    children: e.jsx(ot, {
      features: t.look.features,
      idSuffix: `career-face-${t.id}`,
    }),
  });
}
const Pe = "M136 222C136 178 158 150 200 150C242 150 264 178 264 222Z";
function Wt({ outfit: t, colour: r }) {
  return t === "hood-up"
    ? e.jsx("path", {
        d: "M150 162C142 110 160 66 200 66C240 66 258 110 250 162Z",
        fill: r,
        stroke: "#020617",
        strokeOpacity: "0.4",
        strokeWidth: "2",
      })
    : t === "hoodie"
      ? e.jsx("path", {
          d: "M162 156C160 140 176 132 200 132C224 132 240 140 238 156Z",
          fill: le(r),
        })
      : null;
}
function $t({ outfit: t, colour: r }) {
  const s = e.jsx("path", { d: Pe, fill: r });
  switch (t) {
    case "lab-coat":
      return e.jsxs("g", {
        children: [
          s,
          e.jsx("path", { d: "M184 150L200 196L216 150Z", fill: "#38bdf8" }),
          e.jsx("path", {
            d: "M184 150L200 196L192 222H186L176 160Z M216 150L200 196L208 222H214L224 160Z",
            fill: "#e2e8f0",
          }),
          e.jsx("path", {
            d: "M200 196V222",
            stroke: "#cbd5e1",
            strokeWidth: "2",
          }),
          e.jsx("rect", {
            x: "226",
            y: "186",
            width: "18",
            height: "12",
            rx: "2",
            fill: "#cbd5e1",
          }),
        ],
      });
    case "hood-up":
      return e.jsxs("g", {
        children: [
          s,
          e.jsx("path", {
            d: "M176 152C182 172 218 172 224 152",
            fill: "none",
            stroke: "#020617",
            strokeOpacity: "0.5",
            strokeWidth: "3",
          }),
          e.jsx("path", {
            d: "M190 164V188M210 164V188",
            stroke: "#e2e8f0",
            strokeWidth: "2.5",
            strokeLinecap: "round",
          }),
          e.jsx("rect", {
            x: "178",
            y: "198",
            width: "44",
            height: "20",
            rx: "6",
            fill: "#020617",
            fillOpacity: "0.25",
          }),
        ],
      });
    case "hoodie":
      return e.jsxs("g", {
        children: [
          s,
          e.jsx("path", {
            d: "M178 151C186 166 214 166 222 151",
            fill: "none",
            stroke: le(r),
            strokeWidth: "5",
          }),
          e.jsx("path", {
            d: "M192 162V186M208 162V186",
            stroke: "#f8fafc",
            strokeWidth: "2.5",
            strokeLinecap: "round",
          }),
          e.jsx("rect", {
            x: "176",
            y: "198",
            width: "48",
            height: "20",
            rx: "6",
            fill: le(r),
          }),
        ],
      });
    case "team-polo":
      return e.jsxs("g", {
        children: [
          s,
          e.jsx("path", { d: "M184 150L200 168L216 150Z", fill: "#f8fafc" }),
          e.jsx("path", {
            d: "M184 150L194 172L200 162Z M216 150L206 172L200 162Z",
            fill: le(r),
          }),
          e.jsx("path", {
            d: "M140 200H260",
            stroke: "#f8fafc",
            strokeWidth: "6",
          }),
          e.jsx("circle", { cx: "230", cy: "178", r: "6", fill: "#f8fafc" }),
        ],
      });
    case "blazer":
      return e.jsxs("g", {
        children: [
          s,
          e.jsx("path", { d: "M186 150L200 190L214 150Z", fill: "#f8fafc" }),
          e.jsx("path", { d: "M198 160L200 190L202 160Z", fill: "#7c3aed" }),
          e.jsx("path", {
            d: "M186 150L200 190L188 222H180L174 162Z M214 150L200 190L212 222H220L226 162Z",
            fill: le(r),
          }),
        ],
      });
    case "overalls":
      return e.jsxs("g", {
        children: [
          e.jsx("path", { d: Pe, fill: "#f8fafc" }),
          e.jsx("path", { d: "M170 180H230V222H170Z", fill: r }),
          e.jsx("path", {
            d: "M172 182L160 158M228 182L240 158",
            stroke: r,
            strokeWidth: "8",
            strokeLinecap: "round",
          }),
          e.jsx("circle", { cx: "174", cy: "186", r: "3", fill: "#fde047" }),
          e.jsx("circle", { cx: "226", cy: "186", r: "3", fill: "#fde047" }),
          e.jsx("rect", {
            x: "190",
            y: "194",
            width: "20",
            height: "14",
            rx: "2",
            fill: le(r),
          }),
        ],
      });
    case "jumper":
      return e.jsxs("g", {
        children: [
          s,
          e.jsx("path", {
            d: "M180 151C188 162 212 162 220 151",
            fill: "none",
            stroke: le(r),
            strokeWidth: "6",
          }),
          e.jsx("path", {
            d: "M140 190H260M138 202H262",
            stroke: "#f8fafc",
            strokeOpacity: "0.55",
            strokeWidth: "4",
            strokeDasharray: "8 6",
          }),
        ],
      });
    case "tee":
    default:
      return e.jsxs("g", {
        children: [
          s,
          e.jsx("path", {
            d: "M184 151C190 160 210 160 216 151",
            fill: "none",
            stroke: le(r),
            strokeWidth: "4",
          }),
        ],
      });
  }
}
function bt({ prop: t }) {
  switch (t) {
    case "headset":
      return e.jsxs("g", {
        children: [
          e.jsx("path", {
            d: "M160 120C156 68 244 68 240 120",
            fill: "none",
            stroke: B,
            strokeWidth: "6",
            strokeLinecap: "round",
          }),
          e.jsx("rect", {
            x: "152",
            y: "108",
            width: "14",
            height: "24",
            rx: "6",
            fill: B,
          }),
          e.jsx("rect", {
            x: "234",
            y: "108",
            width: "14",
            height: "24",
            rx: "6",
            fill: B,
          }),
          e.jsx("path", {
            d: "M160 130C162 146 176 150 186 148",
            fill: "none",
            stroke: B,
            strokeWidth: "3",
            strokeLinecap: "round",
          }),
          e.jsx("circle", { cx: "188", cy: "148", r: "4", fill: Ce }),
        ],
      });
    case "laptop":
      return e.jsxs("g", {
        children: [
          e.jsx("path", {
            d: "M150 222L160 176H240L250 222Z",
            fill: "#cbd5e1",
          }),
          e.jsx("path", {
            d: "M156 222L164 182H236L244 222Z",
            fill: "#94a3b8",
          }),
          e.jsx("circle", { cx: "200", cy: "200", r: "6", fill: "#f8fafc" }),
          e.jsx("rect", {
            x: "168",
            y: "190",
            width: "10",
            height: "8",
            rx: "2",
            fill: "#f472b6",
            transform: "rotate(-12 173 194)",
          }),
          e.jsx("rect", {
            x: "222",
            y: "204",
            width: "10",
            height: "10",
            rx: "5",
            fill: "#facc15",
          }),
        ],
      });
    case "magnifier":
      return e.jsxs("g", {
        children: [
          e.jsx("path", {
            d: "M250 196L268 222",
            stroke: "#78350f",
            strokeWidth: "8",
            strokeLinecap: "round",
          }),
          e.jsx("circle", {
            cx: "240",
            cy: "180",
            r: "20",
            fill: "#e0f2fe",
            fillOpacity: "0.35",
            stroke: "#cbd5e1",
            strokeWidth: "5",
          }),
          e.jsx("path", {
            d: "M230 172A12 12 0 0 1 242 166",
            stroke: "#f8fafc",
            strokeWidth: "3",
            fill: "none",
            strokeLinecap: "round",
          }),
        ],
      });
    case "tablet":
      return e.jsxs("g", {
        children: [
          e.jsx("rect", {
            x: "172",
            y: "172",
            width: "56",
            height: "44",
            rx: "5",
            fill: B,
          }),
          e.jsx("rect", {
            x: "177",
            y: "177",
            width: "46",
            height: "34",
            rx: "2",
            fill: "#1e293b",
          }),
          e.jsx("path", {
            d: "M182 204L192 194L200 199L214 184",
            stroke: Ce,
            strokeWidth: "2.5",
            fill: "none",
            strokeLinecap: "round",
          }),
        ],
      });
    case "controller":
      return e.jsxs("g", {
        children: [
          e.jsx("path", {
            d: "M168 186C168 176 178 172 188 174H212C222 172 232 176 232 186L236 206C238 216 226 220 220 212L212 202H188L180 212C174 220 162 216 164 206Z",
            fill: "#e2e8f0",
          }),
          e.jsx("path", {
            d: "M182 186V196M177 191H187",
            stroke: B,
            strokeWidth: "3",
            strokeLinecap: "round",
          }),
          e.jsx("circle", { cx: "216", cy: "187", r: "3", fill: "#ef4444" }),
          e.jsx("circle", { cx: "223", cy: "193", r: "3", fill: "#22c55e" }),
        ],
      });
    case "phone":
      return e.jsxs("g", {
        children: [
          e.jsx("rect", {
            x: "226",
            y: "160",
            width: "28",
            height: "50",
            rx: "5",
            fill: B,
            transform: "rotate(10 240 185)",
          }),
          e.jsx("rect", {
            x: "230",
            y: "166",
            width: "20",
            height: "36",
            rx: "2",
            fill: "#1e293b",
            transform: "rotate(10 240 185)",
          }),
          e.jsx("circle", {
            cx: "240",
            cy: "184",
            r: "6",
            fill: Ce,
            transform: "rotate(10 240 185)",
          }),
        ],
      });
    case "goggles":
      return e.jsxs("g", {
        children: [
          e.jsx("path", { d: "M160 98H240", stroke: B, strokeWidth: "5" }),
          e.jsx("circle", {
            cx: "186",
            cy: "98",
            r: "11",
            fill: "#bae6fd",
            fillOpacity: "0.85",
            stroke: B,
            strokeWidth: "4",
          }),
          e.jsx("circle", {
            cx: "214",
            cy: "98",
            r: "11",
            fill: "#bae6fd",
            fillOpacity: "0.85",
            stroke: B,
            strokeWidth: "4",
          }),
        ],
      });
    case "stylus":
      return e.jsxs("g", {
        children: [
          e.jsx("path", {
            d: "M236 206L258 162",
            stroke: "#f8fafc",
            strokeWidth: "6",
            strokeLinecap: "round",
          }),
          e.jsx("path", {
            d: "M258 162L262 154",
            stroke: B,
            strokeWidth: "6",
            strokeLinecap: "round",
          }),
          e.jsx("rect", {
            x: "164",
            y: "186",
            width: "22",
            height: "22",
            rx: "2",
            fill: "#fde047",
            transform: "rotate(-6 175 197)",
          }),
        ],
      });
    case "none":
    default:
      return null;
  }
}
function vt({ set: t }) {
  const [r, s, i] = Nt[t];
  return e.jsxs("g", {
    children: [
      e.jsx("defs", {
        children: e.jsxs("linearGradient", {
          id: `career-sky-${t}`,
          x1: "0",
          y1: "0",
          x2: "0",
          y2: "1",
          children: [
            e.jsx("stop", { offset: "0", stopColor: r }),
            e.jsx("stop", { offset: "1", stopColor: s }),
          ],
        }),
      }),
      e.jsx("rect", { width: Re, height: at, fill: `url(#career-sky-${t})` }),
      e.jsx("rect", { y: 196, width: Re, height: 24, fill: i }),
      Ht[t],
    ],
  });
}
const Nt = {
  "chip-lab": ["#1e1b4b", "#312e81", "#1e1b4b"],
  "data-pipes": ["#042f2e", "#134e4a", "#042f2e"],
  "server-room": ["#0c1222", "#1e293b", "#020617"],
  "hacker-den": ["#020617", "#052e16", "#020617"],
  "pit-wall": ["#1c1917", "#44403c", "#292524"],
  "evidence-board": ["#2e1065", "#3b0764", "#1e1b4b"],
  "neural-net": ["#3b0764", "#701a75", "#2e1065"],
  "game-studio": ["#172554", "#4c1d95", "#1e1b4b"],
  "bug-hunt": ["#0c4a6e", "#075985", "#082f49"],
  "circuit-bench": ["#052e16", "#14532d", "#422006"],
  "app-desk": ["#164e63", "#155e75", "#083344"],
  "design-wall": ["#4a044e", "#831843", "#3b0764"],
  dashboard: ["#172554", "#1e3a8a", "#0f172a"],
  "security-centre": ["#020617", "#0c4a6e", "#020617"],
};
function te({ x: t, y: r, w: s, h: i, children: l }) {
  return e.jsxs("g", {
    children: [
      e.jsx("rect", {
        x: t,
        y: r,
        width: s,
        height: i,
        rx: "5",
        fill: B,
        stroke: ne,
        strokeWidth: "2",
      }),
      e.jsx("rect", {
        x: t + s / 2 - 4,
        y: r + i,
        width: "8",
        height: "10",
        fill: ne,
      }),
      l,
    ],
  });
}
function _e({ x: t, y: r, rows: s }) {
  return e.jsx("g", {
    children: Array.from({ length: s }, (i, l) =>
      e.jsxs(
        "g",
        {
          children: [
            e.jsx("rect", {
              x: t,
              y: r + l * 22,
              width: "70",
              height: "16",
              rx: "2",
              fill: "#1e293b",
              stroke: ne,
            }),
            e.jsx("circle", {
              cx: t + 8,
              cy: r + l * 22 + 8,
              r: "2.5",
              fill: l % 3 === 1 ? "#f59e0b" : "#22c55e",
            }),
            e.jsx("circle", {
              cx: t + 16,
              cy: r + l * 22 + 8,
              r: "2.5",
              fill: "#22c55e",
            }),
            e.jsx("path", {
              d: `M${t + 28} ${r + l * 22 + 8}H${t + 62}`,
              stroke: ne,
              strokeWidth: "3",
            }),
          ],
        },
        l,
      ),
    ),
  });
}
const Ht = {
  "chip-lab": e.jsxs("g", {
    children: [
      e.jsx("rect", {
        x: "22",
        y: "40",
        width: "96",
        height: "96",
        rx: "8",
        fill: "#4338ca",
        stroke: "#a5b4fc",
        strokeWidth: "2",
      }),
      e.jsx("rect", {
        x: "44",
        y: "62",
        width: "52",
        height: "52",
        rx: "4",
        fill: "#312e81",
      }),
      [0, 1, 2, 3].map((t) =>
        e.jsx(
          "g",
          {
            stroke: "#a5b4fc",
            strokeWidth: "3",
            children: e.jsx("path", {
              d: `M${34 + t * 24} 40V28M${34 + t * 24} 136V148M22 ${52 + t * 24}H10M118 ${52 + t * 24}H130`,
            }),
          },
          t,
        ),
      ),
      e.jsx("path", {
        d: "M52 72H88M52 84H76M52 96H88M52 106H70",
        stroke: "#c7d2fe",
        strokeWidth: "3",
      }),
      e.jsx("rect", {
        x: "282",
        y: "58",
        width: "58",
        height: "80",
        rx: "4",
        fill: "#1e1b4b",
        stroke: "#6366f1",
        strokeWidth: "2",
      }),
      e.jsx("path", {
        d: "M292 72h38M292 86h24M292 100h38M292 114h30",
        stroke: "#818cf8",
        strokeWidth: "3",
      }),
    ],
  }),
  "data-pipes": e.jsxs("g", {
    children: [
      [0, 1, 2].map((t) =>
        e.jsxs(
          "g",
          {
            children: [
              e.jsx("ellipse", {
                cx: 46 + t * 2,
                cy: 60 + t * 44,
                rx: "30",
                ry: "9",
                fill: "#5eead4",
              }),
              e.jsx("path", {
                d: `M${16 + t * 2} ${60 + t * 44}v24a30 9 0 0 0 60 0v-24`,
                fill: "#14b8a6",
              }),
            ],
          },
          t,
        ),
      ),
      e.jsx("path", {
        d: "M80 72C140 72 120 120 160 120M80 116H120M80 160C120 160 120 120 160 120",
        stroke: "#99f6e4",
        strokeWidth: "4",
        fill: "none",
        strokeDasharray: "10 8",
      }),
      e.jsx("path", { d: "M262 62h80v100h-80z", fill: "#115e59" }),
      e.jsx("path", {
        d: "M272 80h60M272 98h40M272 116h56M272 134h32",
        stroke: "#ccfbf1",
        strokeWidth: "4",
      }),
    ],
  }),
  "server-room": e.jsxs("g", {
    children: [
      e.jsx("rect", {
        x: "18",
        y: "26",
        width: "86",
        height: "172",
        rx: "4",
        fill: "#0f172a",
        stroke: ne,
        strokeWidth: "2",
      }),
      e.jsx(_e, { x: 26, y: 36, rows: 7 }),
      e.jsx("rect", {
        x: "268",
        y: "26",
        width: "86",
        height: "172",
        rx: "4",
        fill: "#0f172a",
        stroke: ne,
        strokeWidth: "2",
      }),
      e.jsx(_e, { x: 276, y: 36, rows: 7 }),
      e.jsx("path", {
        d: "M104 60C140 60 130 30 180 30M268 80C240 80 250 30 220 30",
        stroke: "#38bdf8",
        strokeWidth: "3",
        fill: "none",
      }),
      e.jsx("path", {
        d: "M104 104C130 104 128 50 170 46",
        stroke: "#facc15",
        strokeWidth: "3",
        fill: "none",
      }),
    ],
  }),
  "hacker-den": e.jsxs("g", {
    children: [
      e.jsx(te, {
        x: 14,
        y: 40,
        w: 110,
        h: 74,
        children: e.jsx("path", {
          d: "M26 56h40M26 68h70M26 80h30M26 92h56",
          stroke: "#4ade80",
          strokeWidth: "3",
        }),
      }),
      e.jsxs(te, {
        x: 252,
        y: 34,
        w: 96,
        h: 70,
        children: [
          e.jsx("rect", {
            x: "286",
            y: "58",
            width: "28",
            height: "22",
            rx: "3",
            fill: "#4ade80",
          }),
          e.jsx("path", {
            d: "M292 58v-8a8 8 0 0 1 16 0v8",
            stroke: "#4ade80",
            strokeWidth: "4",
            fill: "none",
          }),
        ],
      }),
      e.jsx(te, {
        x: 260,
        y: 124,
        w: 80,
        h: 48,
        children: e.jsx("path", {
          d: "M270 138h50M270 150h30M270 162h44",
          stroke: "#22c55e",
          strokeWidth: "2.5",
        }),
      }),
      e.jsx("text", {
        x: "22",
        y: "150",
        fill: "#22c55e",
        fontFamily: "monospace",
        fontSize: "12",
        opacity: "0.6",
        children: "01001000 01101001",
      }),
    ],
  }),
  "pit-wall": e.jsxs("g", {
    children: [
      e.jsx("path", { d: "M14 168H130", stroke: "#78716c", strokeWidth: "3" }),
      e.jsx("path", {
        d: "M20 160C30 146 54 142 70 142H96L118 150L126 160Z",
        fill: "#dc2626",
      }),
      e.jsx("path", { d: "M56 142L66 128H84L88 142Z", fill: "#1c1917" }),
      e.jsx("rect", {
        x: "10",
        y: "150",
        width: "18",
        height: "6",
        fill: "#dc2626",
      }),
      e.jsx("circle", {
        cx: "40",
        cy: "164",
        r: "11",
        fill: "#1c1917",
        stroke: "#57534e",
        strokeWidth: "3",
      }),
      e.jsx("circle", {
        cx: "108",
        cy: "164",
        r: "11",
        fill: "#1c1917",
        stroke: "#57534e",
        strokeWidth: "3",
      }),
      e.jsx(te, {
        x: 258,
        y: 36,
        w: 90,
        h: 66,
        children: e.jsx("path", {
          d: "M266 88L282 70L294 80L310 52L324 66L340 48",
          stroke: "#f87171",
          strokeWidth: "3",
          fill: "none",
        }),
      }),
      e.jsx(te, {
        x: 258,
        y: 120,
        w: 90,
        h: 52,
        children: e.jsx("text", {
          x: "268",
          y: "152",
          fill: "#fde047",
          fontFamily: "monospace",
          fontSize: "16",
          children: "1:21.4",
        }),
      }),
    ],
  }),
  "evidence-board": e.jsxs("g", {
    children: [
      e.jsx("rect", {
        x: "14",
        y: "26",
        width: "120",
        height: "150",
        rx: "4",
        fill: "#78350f",
      }),
      e.jsx("rect", {
        x: "22",
        y: "36",
        width: "40",
        height: "30",
        fill: "#f8fafc",
      }),
      e.jsx("rect", {
        x: "84",
        y: "44",
        width: "40",
        height: "40",
        fill: "#fde68a",
      }),
      e.jsx("rect", {
        x: "30",
        y: "110",
        width: "36",
        height: "48",
        rx: "4",
        fill: "#0f172a",
      }),
      e.jsx("rect", {
        x: "84",
        y: "118",
        width: "40",
        height: "30",
        fill: "#f8fafc",
      }),
      e.jsx("path", {
        d: "M42 50L104 64L48 132L104 132",
        stroke: "#ef4444",
        strokeWidth: "2",
        fill: "none",
      }),
      [
        [42, 50],
        [104, 64],
        [48, 132],
        [104, 132],
      ].map(([t, r]) =>
        e.jsx("circle", { cx: t, cy: r, r: "4", fill: "#ef4444" }, `${t}-${r}`),
      ),
      e.jsx("path", {
        d: "M270 120h70v62h-70z",
        fill: "#e0f2fe",
        fillOpacity: "0.25",
        stroke: "#bae6fd",
        strokeWidth: "2",
      }),
      e.jsx("rect", {
        x: "290",
        y: "132",
        width: "30",
        height: "42",
        rx: "4",
        fill: "#0f172a",
      }),
      e.jsx("text", {
        x: "276",
        y: "114",
        fill: "#fde68a",
        fontFamily: "monospace",
        fontSize: "11",
        children: "EVIDENCE",
      }),
    ],
  }),
  "neural-net": e.jsxs("g", {
    children: [
      [
        [30, 50],
        [30, 100],
        [30, 150],
        [90, 70],
        [90, 130],
        [300, 60],
        [300, 120],
        [340, 90],
      ].map(([t, r], s, i) =>
        e.jsxs(
          "g",
          {
            children: [
              i
                .filter(([l]) => l === (t === 30 ? 90 : t === 300 ? 340 : -1))
                .map(([l, o]) =>
                  e.jsx(
                    "path",
                    {
                      d: `M${t} ${r}L${l} ${o}`,
                      stroke: "#f0abfc",
                      strokeOpacity: "0.5",
                      strokeWidth: "2",
                    },
                    `${l}-${o}`,
                  ),
                ),
              e.jsx("circle", {
                cx: t,
                cy: r,
                r: s % 3 === 0 ? 10 : 8,
                fill: "#e879f9",
              }),
            ],
          },
          `${t}-${r}`,
        ),
      ),
      e.jsx("rect", {
        x: "250",
        y: "150",
        width: "96",
        height: "34",
        rx: "12",
        fill: "#f8fafc",
      }),
      e.jsx("path", {
        d: "M262 162h60M262 172h40",
        stroke: "#a21caf",
        strokeWidth: "3",
      }),
    ],
  }),
  "game-studio": e.jsxs("g", {
    children: [
      e.jsxs(te, {
        x: 12,
        y: 34,
        w: 128,
        h: 92,
        children: [
          e.jsx("rect", {
            x: "18",
            y: "40",
            width: "116",
            height: "80",
            fill: "#38bdf8",
          }),
          e.jsx("rect", {
            x: "18",
            y: "104",
            width: "116",
            height: "16",
            fill: "#16a34a",
          }),
          e.jsx("rect", {
            x: "40",
            y: "84",
            width: "20",
            height: "20",
            fill: "#a16207",
          }),
          e.jsx("rect", {
            x: "96",
            y: "70",
            width: "28",
            height: "12",
            fill: "#a16207",
          }),
          e.jsx("circle", { cx: "72", cy: "94", r: "7", fill: "#f43f5e" }),
          e.jsx("circle", { cx: "110", cy: "58", r: "5", fill: "#facc15" }),
        ],
      }),
      e.jsx(te, {
        x: 262,
        y: 40,
        w: 86,
        h: 62,
        children: e.jsx("path", {
          d: "M272 54h30M280 66h44M280 78h26M272 90h40",
          stroke: "#c4b5fd",
          strokeWidth: "3",
        }),
      }),
      e.jsx("path", {
        d: "M284 150l10 -20 10 20z M314 150l10-20 10 20z",
        fill: "#facc15",
        opacity: "0.8",
      }),
    ],
  }),
  "bug-hunt": e.jsxs("g", {
    children: [
      [
        [28, 40],
        [80, 60],
        [40, 120],
        [96, 140],
      ].map(([t, r], s) =>
        e.jsxs(
          "g",
          {
            transform: `translate(${t} ${r})`,
            children: [
              e.jsx("ellipse", {
                cx: "0",
                cy: "0",
                rx: "10",
                ry: "13",
                fill: s % 2 ? "#22c55e" : "#f43f5e",
              }),
              e.jsx("path", {
                d: "M-10 -4h-7M10 -4h7M-10 6h-7M10 6h7M-4 -13l-4-6M4 -13l4-6",
                stroke: "#0f172a",
                strokeWidth: "2",
              }),
              s % 2
                ? e.jsx("path", {
                    d: "M-5 0l3 4 7-8",
                    stroke: "#f8fafc",
                    strokeWidth: "2.5",
                    fill: "none",
                  })
                : e.jsx("path", {
                    d: "M-4 -4l8 8M4 -4l-8 8",
                    stroke: "#f8fafc",
                    strokeWidth: "2.5",
                  }),
            ],
          },
          `${t}-${r}`,
        ),
      ),
      e.jsx("rect", {
        x: "264",
        y: "40",
        width: "34",
        height: "62",
        rx: "5",
        fill: B,
        stroke: "#7dd3fc",
        strokeWidth: "2",
      }),
      e.jsx("rect", {
        x: "306",
        y: "56",
        width: "34",
        height: "62",
        rx: "5",
        fill: B,
        stroke: "#7dd3fc",
        strokeWidth: "2",
      }),
      e.jsx("rect", {
        x: "282",
        y: "120",
        width: "40",
        height: "60",
        rx: "5",
        fill: B,
        stroke: "#7dd3fc",
        strokeWidth: "2",
      }),
      e.jsx("path", {
        d: "M292 140l6 6 14-14",
        stroke: "#22c55e",
        strokeWidth: "3",
        fill: "none",
      }),
    ],
  }),
  "circuit-bench": e.jsxs("g", {
    children: [
      e.jsx("rect", {
        x: "10",
        y: "60",
        width: "130",
        height: "100",
        rx: "6",
        fill: "#166534",
        stroke: "#86efac",
        strokeWidth: "2",
      }),
      e.jsx("path", {
        d: "M24 80h30v30h40M24 140h56v-30M100 80v60h26",
        stroke: "#fde047",
        strokeWidth: "3",
        fill: "none",
      }),
      e.jsx("path", { d: "M54 98h14a12 12 0 0 1 0 24h-14z", fill: "#f8fafc" }),
      e.jsx("path", {
        d: "M86 128c8 0 16 6 16 12-0 6-8 12-16 12 4-6 4-18 0-24z",
        fill: "#f8fafc",
        transform: "translate(0 -20)",
      }),
      e.jsx("circle", { cx: "126", cy: "140", r: "5", fill: "#ef4444" }),
      e.jsx("path", {
        d: "M270 196V140L300 110L330 130",
        stroke: "#94a3b8",
        strokeWidth: "10",
        strokeLinecap: "round",
        fill: "none",
      }),
      e.jsx("circle", { cx: "300", cy: "110", r: "8", fill: "#f59e0b" }),
      e.jsx("path", {
        d: "M330 130l10 -6M330 130l10 8",
        stroke: "#94a3b8",
        strokeWidth: "5",
        strokeLinecap: "round",
      }),
    ],
  }),
  "app-desk": e.jsxs("g", {
    children: [
      e.jsx("rect", {
        x: "22",
        y: "22",
        width: "70",
        height: "140",
        rx: "12",
        fill: B,
        stroke: "#67e8f9",
        strokeWidth: "2",
      }),
      e.jsx("rect", {
        x: "30",
        y: "38",
        width: "54",
        height: "22",
        rx: "4",
        fill: "#22d3ee",
      }),
      e.jsx("rect", {
        x: "30",
        y: "68",
        width: "24",
        height: "24",
        rx: "6",
        fill: "#f472b6",
      }),
      e.jsx("rect", {
        x: "60",
        y: "68",
        width: "24",
        height: "24",
        rx: "6",
        fill: "#facc15",
      }),
      e.jsx("rect", {
        x: "30",
        y: "100",
        width: "54",
        height: "10",
        rx: "3",
        fill: "#334155",
      }),
      e.jsx("rect", {
        x: "30",
        y: "116",
        width: "40",
        height: "10",
        rx: "3",
        fill: "#334155",
      }),
      e.jsx(te, {
        x: 248,
        y: 36,
        w: 100,
        h: 74,
        children: e.jsx("path", {
          d: "M258 50h20M266 62h50M266 74h34M274 86h40M258 98h22",
          stroke: "#a5f3fc",
          strokeWidth: "3",
        }),
      }),
      e.jsx("text", {
        x: "262",
        y: "150",
        fill: "#67e8f9",
        fontFamily: "monospace",
        fontSize: "14",
        children: "fun main()",
      }),
    ],
  }),
  "design-wall": e.jsxs("g", {
    children: [
      [
        [18, 30, "#fde047"],
        [64, 40, "#f9a8d4"],
        [24, 86, "#86efac"],
        [72, 96, "#93c5fd"],
        [30, 140, "#fdba74"],
      ].map(([t, r, s]) =>
        e.jsx(
          "rect",
          {
            x: t,
            y: r,
            width: "38",
            height: "38",
            rx: "2",
            fill: s,
            transform: `rotate(${Number(t) % 3 === 0 ? -4 : 4} ${t} ${r})`,
          },
          `${t}-${r}`,
        ),
      ),
      e.jsx("rect", {
        x: "262",
        y: "30",
        width: "80",
        height: "130",
        rx: "10",
        fill: "#f8fafc",
      }),
      e.jsx("rect", {
        x: "272",
        y: "44",
        width: "60",
        height: "30",
        rx: "4",
        fill: "#f9a8d4",
      }),
      e.jsx("rect", {
        x: "272",
        y: "82",
        width: "60",
        height: "10",
        rx: "3",
        fill: "#cbd5e1",
      }),
      e.jsx("rect", {
        x: "272",
        y: "98",
        width: "44",
        height: "10",
        rx: "3",
        fill: "#cbd5e1",
      }),
      e.jsx("rect", {
        x: "272",
        y: "126",
        width: "60",
        height: "20",
        rx: "10",
        fill: "#db2777",
      }),
    ],
  }),
  dashboard: e.jsxs("g", {
    children: [
      e.jsx("rect", {
        x: "12",
        y: "34",
        width: "132",
        height: "120",
        rx: "8",
        fill: "#0f172a",
        stroke: "#3b82f6",
        strokeWidth: "2",
      }),
      [40, 70, 52, 96, 80].map((t, r) =>
        e.jsx(
          "rect",
          {
            x: 26 + r * 22,
            y: 140 - t,
            width: "14",
            height: t,
            rx: "2",
            fill: r === 3 ? "#facc15" : "#60a5fa",
          },
          r,
        ),
      ),
      e.jsx("rect", {
        x: "258",
        y: "34",
        width: "90",
        height: "70",
        rx: "8",
        fill: "#0f172a",
        stroke: "#3b82f6",
        strokeWidth: "2",
      }),
      e.jsx("path", {
        d: "M268 90L284 72L300 80L318 52L338 60",
        stroke: "#4ade80",
        strokeWidth: "3",
        fill: "none",
      }),
      e.jsx("circle", { cx: "303", cy: "144", r: "26", fill: "#1e3a8a" }),
      e.jsx("path", {
        d: "M303 144V118A26 26 0 0 1 328 150Z",
        fill: "#facc15",
      }),
    ],
  }),
  "security-centre": e.jsxs("g", {
    children: [
      e.jsx("rect", {
        x: "10",
        y: "26",
        width: "340",
        height: "96",
        rx: "6",
        fill: "#082f49",
        stroke: "#0e7490",
        strokeWidth: "2",
      }),
      e.jsx("path", {
        d: "M40 70c10-14 30-20 44-10s20 4 30-4M150 60c16-10 36-6 50 4s30 8 44-2M260 78c12-8 30-10 44 0",
        stroke: "#155e75",
        strokeWidth: "14",
        strokeLinecap: "round",
        fill: "none",
      }),
      [
        [70, 62, "#ef4444"],
        [196, 70, "#f59e0b"],
        [292, 74, "#ef4444"],
        [130, 90, "#22c55e"],
      ].map(([t, r, s]) =>
        e.jsx("circle", { cx: t, cy: r, r: "5", fill: s }, `${t}-${r}`),
      ),
      e.jsx("path", {
        d: "M300 140l22 8v18c0 14-10 22-22 26-12-4-22-12-22-26v-18z",
        fill: "#0891b2",
        stroke: "#67e8f9",
        strokeWidth: "2",
      }),
      e.jsx("path", {
        d: "M291 168l7 7 13-14",
        stroke: "#f8fafc",
        strokeWidth: "3",
        fill: "none",
      }),
    ],
  }),
};
function le(t) {
  const r = Number.parseInt(t.slice(1), 16),
    s = (i) => Math.round(((r >> i) & 255) * 0.72);
  return `#${[16, 8, 0].map((i) => s(i).toString(16).padStart(2, "0")).join("")}`;
}
const Ct = "0 0 320 200",
  M = "#0f172a",
  fe = "#020617",
  R = "#1e293b",
  c = "#334155",
  n = "#475569",
  k = "#64748b",
  w = "#94a3b8",
  m = "#cbd5e1",
  q = "#e2e8f0",
  h = "#14b8a6",
  A = "#5eead4",
  ae = "#134e4a",
  G = "#0f766e",
  Be = "#8b5cf6",
  Fe = "#a78bfa",
  V = "#fbbf24",
  ge = "#b45309",
  Z = "#fb7185",
  re = "#e11d48",
  Vt = "monospace";
function he({ x: t, y: r, w: s, h: i, fill: l = R, stroke: o = n }) {
  return e.jsx("rect", {
    x: t,
    y: r,
    width: s,
    height: i,
    rx: "10",
    fill: l,
    stroke: o,
    strokeWidth: "3",
  });
}
function se({ x: t, y: r, w: s, h: i, children: l }) {
  return e.jsxs("g", {
    children: [
      e.jsx(he, { x: t, y: r, w: s, h: i }),
      e.jsx("path", {
        d: `M${t + 1.5} ${r + 24}H${t + s - 1.5}`,
        stroke: n,
        strokeWidth: "3",
      }),
      e.jsx("circle", { cx: t + 14, cy: r + 12, r: "4", fill: k }),
      e.jsx("circle", { cx: t + 27, cy: r + 12, r: "4", fill: k }),
      e.jsx("circle", { cx: t + 40, cy: r + 12, r: "4", fill: k }),
      l,
    ],
  });
}
function pe({ x: t, y: r, w: s, h: i, children: l }) {
  return e.jsxs("g", {
    children: [
      e.jsx("rect", {
        x: t,
        y: r,
        width: s,
        height: i,
        rx: "16",
        fill: R,
        stroke: n,
        strokeWidth: "4",
      }),
      e.jsx("rect", {
        x: t + s / 2 - 12,
        y: r + 8,
        width: "24",
        height: "5",
        rx: "2.5",
        fill: n,
      }),
      l,
    ],
  });
}
function J({ x: t, y: r, widths: s, gap: i = 14, colour: l = k, h: o = 6 }) {
  return e.jsx("g", {
    children: s.map((a, x) =>
      e.jsx(
        "rect",
        { x: t, y: r + x * i, width: a, height: o, rx: o / 2, fill: l },
        x,
      ),
    ),
  });
}
function Ve({ x: t, y: r, colour: s, open: i = !1, cracked: l = !1 }) {
  const o = i
    ? `M${t + 12} ${r}V${r - 20}C${t + 12} ${r - 44} ${t + 48} ${r - 44} ${t + 48} ${r - 26}V${r - 18}`
    : `M${t + 12} ${r}V${r - 16}C${t + 12} ${r - 40} ${t + 48} ${r - 40} ${t + 48} ${r - 16}V${r}`;
  return e.jsxs("g", {
    children: [
      e.jsx("path", {
        d: o,
        fill: "none",
        stroke: m,
        strokeWidth: "8",
        strokeLinecap: "round",
        transform: i ? `rotate(-18 ${t + 12} ${r})` : void 0,
      }),
      e.jsx("rect", {
        x: t,
        y: r,
        width: "60",
        height: "48",
        rx: "9",
        fill: s,
      }),
      e.jsx("circle", { cx: t + 30, cy: r + 20, r: "6", fill: M }),
      e.jsx("rect", {
        x: t + 27,
        y: r + 22,
        width: "6",
        height: "14",
        rx: "3",
        fill: M,
      }),
      l &&
        e.jsx("path", {
          d: `M${t + 44} ${r}L${t + 38} ${r + 14}L${t + 48} ${r + 22}L${t + 40} ${r + 34}L${t + 46} ${r + 48}`,
          fill: "none",
          stroke: M,
          strokeWidth: "4",
          strokeLinejoin: "round",
        }),
    ],
  });
}
function Ge({ x: t, y: r, colour: s, size: i = 1 }) {
  return e.jsxs("g", {
    transform: `translate(${t} ${r}) scale(${i})`,
    children: [
      e.jsx("path", {
        d: "M-12 -6L-24 -12M-13 4H-26M-12 13L-23 22M12 -6L24 -12M13 4H26M12 13L23 22",
        stroke: s,
        strokeWidth: "4",
        strokeLinecap: "round",
      }),
      e.jsx("path", {
        d: "M-5 -20L-11 -30M5 -20L11 -30",
        stroke: s,
        strokeWidth: "3",
        strokeLinecap: "round",
      }),
      e.jsx("circle", { cx: "0", cy: "-15", r: "8", fill: s }),
      e.jsx("ellipse", { cx: "0", cy: "5", rx: "14", ry: "18", fill: s }),
      e.jsx("path", { d: "M0 -10V22", stroke: M, strokeWidth: "3" }),
    ],
  });
}
function ye({ x: t, y: r, size: s = 1, colour: i = h, width: l = 6 }) {
  return e.jsx("path", {
    d: `M${t - 10 * s} ${r}L${t - 3 * s} ${r + 8 * s}L${t + 12 * s} ${r - 9 * s}`,
    fill: "none",
    stroke: i,
    strokeWidth: l,
    strokeLinecap: "round",
    strokeLinejoin: "round",
  });
}
function Ke({ x: t, y: r, size: s = 10, colour: i = Z, width: l = 6 }) {
  return e.jsx("path", {
    d: `M${t - s} ${r - s}L${t + s} ${r + s}M${t + s} ${r - s}L${t - s} ${r + s}`,
    stroke: i,
    strokeWidth: l,
    strokeLinecap: "round",
  });
}
function Ae({ x: t, y: r, r: s = 16 }) {
  return e.jsxs("g", {
    children: [
      e.jsx("circle", { cx: t, cy: r, r: s, fill: h }),
      e.jsx(ye, { x: t, y: r, size: s / 18, colour: M, width: 4 }),
    ],
  });
}
function At({ x: t, y: r, w: s, h: i, fill: l = c, top: o = w }) {
  const a = s / 2,
    x = Math.min(14, i / 5),
    j = t + a;
  return e.jsxs("g", {
    children: [
      e.jsx("path", {
        d: `M${t} ${r + x}V${r + i - x}A${a} ${x} 0 0 0 ${t + s} ${r + i - x}V${r + x}Z`,
        fill: l,
        stroke: n,
        strokeWidth: "3",
      }),
      i > 70 &&
        e.jsx("path", {
          d: `M${t} ${r + i / 2}A${a} ${x} 0 0 0 ${t + s} ${r + i / 2}`,
          fill: "none",
          stroke: n,
          strokeWidth: "3",
        }),
      e.jsx("ellipse", {
        cx: j,
        cy: r + x,
        rx: a,
        ry: x,
        fill: o,
        stroke: n,
        strokeWidth: "3",
      }),
    ],
  });
}
function qe({ x: t, y: r, s, lit: i = -1, litColour: l = h }) {
  const o = [1, 2, 3, 4, 5].map((j) => (s * j) / 6),
    a = s - 28,
    x = (a - 18) / 2;
  return e.jsxs("g", {
    children: [
      o.map((j) =>
        e.jsx(
          "path",
          {
            d: `M${t + j} ${r - 12}V${r}M${t + j} ${r + s}V${r + s + 12}M${t - 12} ${r + j}H${t}M${t + s} ${r + j}H${t + s + 12}`,
            stroke: k,
            strokeWidth: "4",
            strokeLinecap: "round",
          },
          j,
        ),
      ),
      e.jsx("rect", {
        x: t,
        y: r,
        width: s,
        height: s,
        rx: "10",
        fill: R,
        stroke: n,
        strokeWidth: "3",
      }),
      e.jsx("rect", {
        x: t + 14,
        y: r + 14,
        width: a,
        height: a,
        rx: "5",
        fill: c,
      }),
      [0, 1, 2, 3].map((j) =>
        e.jsx(
          "rect",
          {
            x: t + 20 + (j % 2) * (x + 6),
            y: r + 20 + Math.floor(j / 2) * (x + 6),
            width: x,
            height: x,
            rx: "4",
            fill: j === i ? l : n,
          },
          j,
        ),
      ),
    ],
  });
}
function Ue({ x: t, y: r, fill: s = c }) {
  return e.jsxs("g", {
    children: [
      e.jsx("path", {
        d: `M${t + 9} ${r - 6}V${r + 36}M${t + 17} ${r - 6}V${r + 36}M${t + 25} ${r - 6}V${r + 36}`,
        stroke: k,
        strokeWidth: "3",
        strokeLinecap: "round",
      }),
      e.jsx("rect", {
        x: t,
        y: r,
        width: "34",
        height: "30",
        rx: "5",
        fill: s,
        stroke: n,
        strokeWidth: "3",
      }),
    ],
  });
}
function St(t, r, s, i) {
  const l = [],
    o = (Math.PI * 2) / i;
  for (let a = 0; a < i; a += 1) {
    const x = a * o,
      j = [
        [s - 9, x],
        [s + 6, x + o * 0.18],
        [s + 6, x + o * 0.5],
        [s - 9, x + o * 0.68],
      ];
    for (const [p, d] of j)
      l.push(
        `${(t + p * Math.cos(d)).toFixed(1)} ${(r + p * Math.sin(d)).toFixed(1)}`,
      );
  }
  return `M${l.join("L")}Z`;
}
function Xe({ cx: t, cy: r, r: s, teeth: i, fill: l }) {
  return e.jsxs("g", {
    children: [
      e.jsx("path", {
        d: St(t, r, s, i),
        fill: l,
        stroke: l,
        strokeWidth: "4",
        strokeLinejoin: "round",
      }),
      e.jsx("circle", { cx: t, cy: r, r: s * 0.32, fill: M }),
    ],
  });
}
function Ye({ x: t, y: r, w: s, h: i }) {
  const l = Math.floor((i - 16) / 24);
  return e.jsxs("g", {
    children: [
      e.jsx(he, { x: t, y: r, w: s, h: i }),
      Array.from({ length: l }, (o, a) =>
        e.jsxs(
          "g",
          {
            children: [
              e.jsx("rect", {
                x: t + 10,
                y: r + 10 + a * 24,
                width: s - 20,
                height: "16",
                rx: "4",
                fill: c,
              }),
              e.jsx("circle", {
                cx: t + s - 20,
                cy: r + 18 + a * 24,
                r: "3.5",
                fill: h,
              }),
              e.jsx("rect", {
                x: t + 18,
                y: r + 16 + a * 24,
                width: s / 3,
                height: "4",
                rx: "2",
                fill: n,
              }),
            ],
          },
          a,
        ),
      ),
    ],
  });
}
function Qe({ x: t, y: r, r: s = 24, colour: i = h }) {
  const l = s * 0.72;
  return e.jsxs("g", {
    children: [
      e.jsx("path", {
        d: `M${t + l} ${r + l}L${t + l + s * 0.8} ${r + l + s * 0.8}`,
        stroke: i,
        strokeWidth: "9",
        strokeLinecap: "round",
      }),
      e.jsx("circle", {
        cx: t,
        cy: r,
        r: s,
        fill: M,
        fillOpacity: "0.4",
        stroke: i,
        strokeWidth: "6",
      }),
    ],
  });
}
function Je({ x: t, y: r, colour: s = m }) {
  return e.jsx("path", {
    d: `M${t} ${r}V${r + 30}C${t} ${r + 48} ${t - 26} ${r + 48} ${t - 26} ${r + 30}L${t - 20} ${r + 24}`,
    fill: "none",
    stroke: s,
    strokeWidth: "5",
    strokeLinecap: "round",
    strokeLinejoin: "round",
  });
}
function et({ x: t, y: r, w: s, h: i, fill: l = m }) {
  return e.jsxs("g", {
    children: [
      e.jsx("rect", { x: t, y: r, width: s, height: i, rx: "8", fill: l }),
      e.jsx("path", {
        d: `M${t + 6} ${r + 6}L${t + s / 2} ${r + i * 0.55}L${t + s - 6} ${r + 6}`,
        fill: "none",
        stroke: k,
        strokeWidth: "4",
        strokeLinejoin: "round",
        strokeLinecap: "round",
      }),
    ],
  });
}
function tt({ x: t, y: r, s = 1, fill: i = h }) {
  return e.jsxs("g", {
    transform: `translate(${t} ${r}) scale(${s})`,
    children: [
      e.jsx("path", {
        d: "M0 -44L36 -30V0C36 24 18 38 0 46C-18 38 -36 24 -36 0V-30Z",
        fill: i,
      }),
      e.jsx(ye, { x: 0, y: 0, size: 1.2, colour: M, width: 7 }),
    ],
  });
}
function xe({ x: t, y: r, r: s = 10, colour: i = A }) {
  const l = s * 0.28;
  return e.jsx("path", {
    d: `M${t} ${r - s}L${t + l} ${r - l}L${t + s} ${r}L${t + l} ${r + l}L${t} ${r + s}L${t - l} ${r + l}L${t - s} ${r}L${t - l} ${r - l}Z`,
    fill: i,
  });
}
function K({
  x: t,
  y: r,
  children: s,
  colour: i = m,
  size: l = 14,
  anchor: o = "middle",
}) {
  return e.jsx("text", {
    x: t,
    y: r,
    fill: i,
    fontFamily: Vt,
    fontSize: l,
    fontWeight: "700",
    textAnchor: o,
    children: s,
  });
}
function Se({ y: t = 176 }) {
  return e.jsx("rect", {
    x: "0",
    y: t,
    width: "320",
    height: 200 - t,
    fill: R,
  });
}
function Et(t, r, s, i, l) {
  return Array.from({ length: l }, (o, a) => {
    const x = (a / l) * Math.PI * 2;
    return [
      Number((t + s * Math.cos(x)).toFixed(1)),
      Number((r + i * Math.sin(x)).toFixed(1)),
    ];
  });
}
const zt = Et(160, 138, 112, 38, 30),
  Tt = {
    "hardware-engineer": [
      e.jsxs(
        "g",
        {
          children: [
            e.jsx(qe, { x: 34, y: 48, s: 104, lit: 0 }),
            e.jsx("path", {
              d: "M156 100H178",
              stroke: h,
              strokeWidth: "4",
              strokeDasharray: "6 6",
              strokeLinecap: "round",
            }),
            e.jsx(he, { x: 182, y: 40, w: 118, h: 120 }),
            e.jsx(K, { x: 241, y: 64, colour: w, children: "SIM" }),
            e.jsx("path", {
              d: "M196 120H214V88H236V120H256V88H276V120H288",
              fill: "none",
              stroke: h,
              strokeWidth: "5",
              strokeLinejoin: "round",
              strokeLinecap: "round",
            }),
            e.jsx("path", { d: "M196 140H288", stroke: n, strokeWidth: "3" }),
            e.jsx(Ae, { x: 292, y: 44, r: 18 }),
          ],
        },
        "0",
      ),
      e.jsxs(
        "g",
        {
          children: [
            e.jsx(qe, { x: 30, y: 52, s: 100, lit: 1, litColour: A }),
            e.jsx("path", {
              d: "M150 82H170M146 102H178M150 122H170",
              stroke: h,
              strokeWidth: "5",
              strokeLinecap: "round",
            }),
            e.jsx("path", {
              d: "M190 112A54 54 0 0 1 298 112",
              fill: "none",
              stroke: c,
              strokeWidth: "14",
              strokeLinecap: "round",
            }),
            e.jsx("path", {
              d: "M244 58A54 54 0 0 1 290.8 85",
              fill: "none",
              stroke: h,
              strokeWidth: "14",
              strokeLinecap: "round",
            }),
            e.jsx("path", {
              d: "M244 112L278 86",
              stroke: q,
              strokeWidth: "6",
              strokeLinecap: "round",
            }),
            e.jsx("circle", { cx: "244", cy: "112", r: "9", fill: q }),
            e.jsx("rect", {
              x: "208",
              y: "140",
              width: "66",
              height: "34",
              rx: "7",
              fill: "none",
              stroke: w,
              strokeWidth: "4",
            }),
            e.jsx("rect", {
              x: "274",
              y: "150",
              width: "7",
              height: "14",
              rx: "2",
              fill: w,
            }),
            e.jsx("rect", {
              x: "215",
              y: "147",
              width: "16",
              height: "20",
              rx: "3",
              fill: w,
            }),
            e.jsx("rect", {
              x: "235",
              y: "147",
              width: "16",
              height: "20",
              rx: "3",
              fill: w,
            }),
            e.jsx("rect", {
              x: "255",
              y: "147",
              width: "12",
              height: "20",
              rx: "3",
              fill: c,
            }),
          ],
        },
        "1",
      ),
      e.jsxs(
        "g",
        {
          children: [
            e.jsx(Se, { y: 168 }),
            e.jsx("rect", {
              x: "114",
              y: "34",
              width: "18",
              height: "50",
              rx: "3",
              fill: c,
            }),
            e.jsx("path", {
              d: "M18 168V96L50 74V96L82 74V96L114 74V96L146 74V168Z",
              fill: R,
              stroke: n,
              strokeWidth: "3",
              strokeLinejoin: "round",
            }),
            e.jsx("rect", {
              x: "34",
              y: "112",
              width: "22",
              height: "20",
              rx: "3",
              fill: c,
            }),
            e.jsx("rect", {
              x: "70",
              y: "112",
              width: "22",
              height: "20",
              rx: "3",
              fill: c,
            }),
            e.jsx("rect", {
              x: "106",
              y: "126",
              width: "28",
              height: "42",
              rx: "3",
              fill: c,
            }),
            e.jsx("rect", {
              x: "146",
              y: "146",
              width: "160",
              height: "16",
              rx: "8",
              fill: c,
            }),
            [160, 192, 224, 256, 288].map((t) =>
              e.jsx("circle", { cx: t, cy: "154", r: "4", fill: k }, t),
            ),
            e.jsx(Ue, { x: 176, y: 110 }),
            e.jsx(Ue, { x: 248, y: 104, fill: h }),
            e.jsx(xe, { x: 292, y: 86, r: 12 }),
            e.jsx(xe, { x: 240, y: 84, r: 7 }),
          ],
        },
        "2",
      ),
    ],
    "data-engineer": [
      e.jsxs(
        "g",
        {
          children: [
            e.jsx("path", {
              d: "M30 84V44L56 38V78",
              fill: "none",
              stroke: m,
              strokeWidth: "5",
              strokeLinejoin: "round",
            }),
            e.jsx("ellipse", { cx: "24", cy: "86", rx: "9", ry: "7", fill: m }),
            e.jsx("ellipse", { cx: "50", cy: "80", rx: "9", ry: "7", fill: m }),
            e.jsx("path", {
              d: "M54 150V116",
              stroke: m,
              strokeWidth: "5",
              strokeLinecap: "round",
            }),
            e.jsx("path", {
              d: "M54 116C62 120 68 126 64 134",
              fill: "none",
              stroke: m,
              strokeWidth: "5",
              strokeLinecap: "round",
            }),
            e.jsx("ellipse", {
              cx: "47",
              cy: "152",
              rx: "9",
              ry: "7",
              fill: m,
            }),
            e.jsx("path", {
              d: "M72 100H216",
              stroke: c,
              strokeWidth: "40",
              strokeLinecap: "round",
            }),
            e.jsx("rect", {
              x: "110",
              y: "76",
              width: "10",
              height: "48",
              rx: "3",
              fill: n,
            }),
            e.jsx("rect", {
              x: "172",
              y: "76",
              width: "10",
              height: "48",
              rx: "3",
              fill: n,
            }),
            [88, 136, 192].map((t) =>
              e.jsx(
                "path",
                {
                  d: `M${t} 89L${t + 16} 100L${t} 111Z`,
                  fill: h,
                  strokeLinejoin: "round",
                },
                t,
              ),
            ),
            e.jsx(At, { x: 222, y: 42, w: 80, h: 120, top: h }),
          ],
        },
        "0",
      ),
      e.jsxs(
        "g",
        {
          children: [
            [0, 1, 2, 3, 4].map((t) =>
              e.jsx(
                "g",
                {
                  children: e.jsx("rect", {
                    x: 30 + t * 8,
                    y: 34 + t * 10,
                    width: "78",
                    height: "96",
                    rx: "8",
                    fill: t === 4 ? c : R,
                    stroke: n,
                    strokeWidth: "3",
                  }),
                },
                t,
              ),
            ),
            e.jsx(J, { x: 74, y: 92, widths: [48, 36, 44], colour: k }),
            e.jsx("path", {
              d: "M140 100H198",
              stroke: h,
              strokeWidth: "7",
              strokeLinecap: "round",
            }),
            e.jsx("path", {
              d: "M186 86L202 100L186 114",
              fill: "none",
              stroke: h,
              strokeWidth: "7",
              strokeLinecap: "round",
              strokeLinejoin: "round",
            }),
            e.jsx("path", {
              d: "M152 76L164 88L152 100M180 76L168 88L180 100",
              fill: "none",
              stroke: k,
              strokeWidth: "4",
              strokeLinecap: "round",
              strokeLinejoin: "round",
              transform: "translate(0 32)",
            }),
            e.jsx("rect", {
              x: "218",
              y: "96",
              width: "76",
              height: "62",
              rx: "10",
              fill: c,
              stroke: n,
              strokeWidth: "3",
            }),
            e.jsx("rect", {
              x: "250",
              y: "96",
              width: "12",
              height: "62",
              fill: h,
            }),
            [104, 116, 128, 140].map((t) =>
              e.jsx(
                "path",
                { d: `M250 ${t}H262`, stroke: G, strokeWidth: "4" },
                t,
              ),
            ),
            e.jsx("rect", {
              x: "246",
              y: "146",
              width: "20",
              height: "16",
              rx: "4",
              fill: A,
            }),
          ],
        },
        "1",
      ),
      e.jsxs(
        "g",
        {
          children: [
            e.jsxs(se, {
              x: 22,
              y: 34,
              w: 276,
              h: 136,
              children: [
                e.jsx(K, {
                  x: 40,
                  y: 84,
                  colour: w,
                  anchor: "start",
                  size: 16,
                  children: "SELECT *",
                }),
                e.jsx("rect", {
                  x: "40",
                  y: "128",
                  width: "240",
                  height: "18",
                  rx: "9",
                  fill: c,
                }),
                e.jsx("rect", {
                  x: "40",
                  y: "128",
                  width: "54",
                  height: "18",
                  rx: "9",
                  fill: ge,
                }),
              ],
            }),
            e.jsx("rect", {
              x: "62",
              y: "114",
              width: "56",
              height: "13",
              rx: "6.5",
              fill: m,
            }),
            e.jsx("path", {
              d: "M110 116L118 98M116 118L126 100",
              stroke: m,
              strokeWidth: "4",
              strokeLinecap: "round",
            }),
            e.jsx("circle", { cx: "118", cy: "97", r: "4", fill: m }),
            e.jsx("circle", { cx: "126", cy: "99", r: "4", fill: m }),
            e.jsx("circle", { cx: "86", cy: "104", r: "20", fill: V }),
            e.jsx("path", {
              d: "M86 104m-4 0a4 4 0 1 1 8 0a9 9 0 1 1 -18 0a14 14 0 1 1 28 0",
              fill: "none",
              stroke: ge,
              strokeWidth: "3.5",
              strokeLinecap: "round",
            }),
            e.jsxs("g", {
              transform: "translate(232 92) rotate(40)",
              children: [
                e.jsx("rect", {
                  x: "-7",
                  y: "-4",
                  width: "14",
                  height: "62",
                  rx: "7",
                  fill: h,
                }),
                e.jsx("circle", { cx: "0", cy: "-10", r: "19", fill: h }),
                e.jsx("rect", {
                  x: "-7",
                  y: "-34",
                  width: "14",
                  height: "22",
                  rx: "2",
                  fill: R,
                }),
              ],
            }),
          ],
        },
        "2",
      ),
    ],
    "network-engineer": [
      e.jsxs(
        "g",
        {
          children: [
            e.jsx("ellipse", {
              cx: "160",
              cy: "138",
              rx: "146",
              ry: "54",
              fill: c,
            }),
            e.jsx("ellipse", {
              cx: "160",
              cy: "138",
              rx: "124",
              ry: "42",
              fill: R,
            }),
            e.jsx("ellipse", {
              cx: "160",
              cy: "140",
              rx: "84",
              ry: "26",
              fill: ae,
            }),
            e.jsx("path", {
              d: "M160 116V164M108 140H212",
              stroke: G,
              strokeWidth: "3",
            }),
            zt.map(([t, r]) =>
              e.jsx(
                "rect",
                {
                  x: t - 3,
                  y: r - 4,
                  width: "6",
                  height: "9",
                  rx: "1.5",
                  fill: A,
                },
                `${t}-${r}`,
              ),
            ),
            e.jsx("path", {
              d: "M118 52A60 60 0 0 1 202 52",
              fill: "none",
              stroke: h,
              strokeWidth: "8",
              strokeLinecap: "round",
            }),
            e.jsx("path", {
              d: "M132 66A40 40 0 0 1 188 66",
              fill: "none",
              stroke: h,
              strokeWidth: "8",
              strokeLinecap: "round",
            }),
            e.jsx("path", {
              d: "M146 80A20 20 0 0 1 174 80",
              fill: "none",
              stroke: h,
              strokeWidth: "8",
              strokeLinecap: "round",
            }),
            e.jsx("circle", { cx: "160", cy: "92", r: "7", fill: h }),
          ],
        },
        "0",
      ),
      e.jsxs(
        "g",
        {
          children: [
            e.jsx(Ye, { x: 18, y: 34, w: 70, h: 136 }),
            e.jsx(Ye, { x: 232, y: 34, w: 70, h: 136 }),
            e.jsx("path", { d: "M88 70H232", stroke: k, strokeWidth: "6" }),
            e.jsx("rect", {
              x: "104",
              y: "61",
              width: "18",
              height: "18",
              rx: "4",
              fill: h,
            }),
            e.jsx("rect", {
              x: "136",
              y: "61",
              width: "18",
              height: "18",
              rx: "4",
              fill: h,
            }),
            e.jsx("rect", {
              x: "200",
              y: "61",
              width: "18",
              height: "18",
              rx: "4",
              fill: h,
            }),
            e.jsx("path", {
              d: "M172 78C176 98 182 112 176 132",
              fill: "none",
              stroke: Z,
              strokeWidth: "4",
              strokeDasharray: "2 8",
              strokeLinecap: "round",
            }),
            e.jsx("rect", {
              x: "164",
              y: "136",
              width: "20",
              height: "20",
              rx: "4",
              fill: Z,
              transform: "rotate(25 174 146)",
            }),
            e.jsx(Qe, { x: 172, y: 78, r: 22, colour: m }),
          ],
        },
        "1",
      ),
      e.jsxs(
        "g",
        {
          children: [
            e.jsx(Se, { y: 170 }),
            e.jsx("rect", {
              x: "104",
              y: "60",
              width: "112",
              height: "110",
              rx: "6",
              fill: R,
              stroke: n,
              strokeWidth: "3",
            }),
            e.jsx("rect", {
              x: "138",
              y: "30",
              width: "44",
              height: "44",
              rx: "8",
              fill: q,
            }),
            e.jsx("path", {
              d: "M160 40V64M148 52H172",
              stroke: re,
              strokeWidth: "8",
              strokeLinecap: "round",
            }),
            [0, 1, 2].map((t) =>
              e.jsxs(
                "g",
                {
                  children: [
                    e.jsx("rect", {
                      x: 118 + t * 32,
                      y: "88",
                      width: "20",
                      height: "16",
                      rx: "3",
                      fill: c,
                    }),
                    e.jsx("rect", {
                      x: 118 + t * 32,
                      y: "114",
                      width: "20",
                      height: "16",
                      rx: "3",
                      fill: c,
                    }),
                  ],
                },
                t,
              ),
            ),
            e.jsx("rect", {
              x: "146",
              y: "140",
              width: "28",
              height: "30",
              rx: "3",
              fill: n,
            }),
            e.jsx("path", {
              d: "M58 96H104M262 96H216",
              stroke: h,
              strokeWidth: "5",
              strokeLinecap: "round",
            }),
            e.jsx("path", {
              d: "M58 96V150H104M262 96V150H216",
              fill: "none",
              stroke: h,
              strokeWidth: "4",
              strokeDasharray: "7 7",
              strokeLinecap: "round",
            }),
            e.jsx("rect", {
              x: "28",
              y: "80",
              width: "40",
              height: "32",
              rx: "7",
              fill: c,
              stroke: h,
              strokeWidth: "3",
            }),
            e.jsx("rect", {
              x: "252",
              y: "80",
              width: "40",
              height: "32",
              rx: "7",
              fill: c,
              stroke: h,
              strokeWidth: "3",
            }),
            e.jsx("circle", { cx: "40", cy: "96", r: "4", fill: A }),
            e.jsx("circle", { cx: "56", cy: "96", r: "4", fill: A }),
            e.jsx("circle", { cx: "264", cy: "96", r: "4", fill: A }),
            e.jsx("circle", { cx: "280", cy: "96", r: "4", fill: A }),
          ],
        },
        "2",
      ),
    ],
    "ethical-hacker": [
      e.jsxs(
        "g",
        {
          children: [
            e.jsxs(se, {
              x: 16,
              y: 30,
              w: 160,
              h: 140,
              children: [
                e.jsx("path", {
                  d: "M96 66L148 88H44Z",
                  fill: w,
                  strokeLinejoin: "round",
                }),
                [54, 78, 102, 126].map((t) =>
                  e.jsx(
                    "rect",
                    {
                      x: t,
                      y: "94",
                      width: "12",
                      height: "44",
                      rx: "2",
                      fill: w,
                    },
                    t,
                  ),
                ),
                e.jsx("rect", {
                  x: "42",
                  y: "142",
                  width: "108",
                  height: "10",
                  rx: "3",
                  fill: w,
                }),
              ],
            }),
            e.jsx(Ve, { x: 198, y: 66, colour: V, open: !0, cracked: !0 }),
            e.jsx("rect", {
              x: "226",
              y: "126",
              width: "74",
              height: "60",
              rx: "8",
              fill: c,
              stroke: n,
              strokeWidth: "3",
            }),
            e.jsx(ye, { x: 244, y: 144, size: 0.5, width: 4 }),
            e.jsx("rect", {
              x: "256",
              y: "141",
              width: "34",
              height: "6",
              rx: "3",
              fill: w,
            }),
            e.jsx(ye, { x: 244, y: 164, size: 0.5, width: 4 }),
            e.jsx("rect", {
              x: "256",
              y: "161",
              width: "26",
              height: "6",
              rx: "3",
              fill: w,
            }),
          ],
        },
        "0",
      ),
      e.jsxs(
        "g",
        {
          children: [
            e.jsx("path", { d: "M170 0V54", stroke: k, strokeWidth: "3" }),
            e.jsx(et, { x: 92, y: 78, w: 140, h: 92 }),
            e.jsx(Je, { x: 170, y: 52, colour: V }),
            e.jsx("path", {
              d: "M252 118L252 168L264 156L274 178L284 173L274 152L290 150Z",
              fill: q,
              stroke: M,
              strokeWidth: "3",
              strokeLinejoin: "round",
            }),
            e.jsx("path", {
              d: "M238 106L230 96M252 100V88M266 106L274 96",
              stroke: h,
              strokeWidth: "4",
              strokeLinecap: "round",
            }),
          ],
        },
        "1",
      ),
      e.jsxs(
        "g",
        {
          children: [
            [0, 1, 2, 3, 4].map((t) =>
              e.jsx(
                "g",
                {
                  children: [0, 1, 2, 3].map((r) =>
                    e.jsx(
                      "rect",
                      {
                        x: 20 + r * 48 + (t % 2) * 24 - (t % 2 ? 24 : 0),
                        y: 40 + t * 26,
                        width: "44",
                        height: "22",
                        rx: "3",
                        fill: c,
                      },
                      r,
                    ),
                  ),
                },
                t,
              ),
            ),
            e.jsx("rect", {
              x: "54",
              y: "62",
              width: "40",
              height: "34",
              rx: "6",
              fill: h,
            }),
            e.jsx("path", {
              d: "M60 70H88M60 88H88",
              stroke: G,
              strokeWidth: "3",
              strokeDasharray: "4 4",
            }),
            e.jsx("rect", {
              x: "120",
              y: "118",
              width: "40",
              height: "34",
              rx: "6",
              fill: h,
            }),
            e.jsx("path", {
              d: "M126 126H154M126 144H154",
              stroke: G,
              strokeWidth: "3",
              strokeDasharray: "4 4",
            }),
            e.jsx("path", {
              d: "M156 64L172 58L186 70L180 84L188 98L170 104L154 94L160 80Z",
              fill: M,
              stroke: Z,
              strokeWidth: "3",
              strokeLinejoin: "round",
            }),
            e.jsx("rect", {
              x: "182",
              y: "120",
              width: "40",
              height: "34",
              rx: "6",
              fill: h,
              transform: "rotate(-14 202 137)",
            }),
            e.jsx("path", {
              d: "M190 118L196 104M204 116L210 102",
              stroke: A,
              strokeWidth: "4",
              strokeLinecap: "round",
            }),
            e.jsx(Ve, { x: 228, y: 92, colour: h }),
          ],
        },
        "2",
      ),
    ],
    "embedded-software-engineer": [
      e.jsxs(
        "g",
        {
          children: [
            e.jsx(Xe, { cx: 86, cy: 108, r: 52, teeth: 12, fill: c }),
            e.jsx(Xe, { cx: 156, cy: 58, r: 30, teeth: 8, fill: k }),
            e.jsx(K, { x: 86, y: 115, colour: A, size: 22, children: "7" }),
            e.jsx(he, { x: 200, y: 30, w: 104, h: 140 }),
            [60, 100, 140].map((t, r) =>
              e.jsxs(
                "g",
                {
                  children: [
                    e.jsx("path", {
                      d: `M218 ${t}H286`,
                      stroke: n,
                      strokeWidth: "5",
                      strokeLinecap: "round",
                    }),
                    e.jsx("circle", {
                      cx: [240, 270, 230][r],
                      cy: t,
                      r: "10",
                      fill: h,
                    }),
                  ],
                },
                t,
              ),
            ),
          ],
        },
        "0",
      ),
      e.jsxs(
        "g",
        {
          children: [
            e.jsx(he, { x: 50, y: 14, w: 220, h: 50 }),
            e.jsx("path", {
              d: "M62 46L84 30L104 42L124 26L146 44L168 32L188 40L210 24L232 38L258 30",
              fill: "none",
              stroke: h,
              strokeWidth: "4",
              strokeLinejoin: "round",
              strokeLinecap: "round",
            }),
            [76, 140, 196, 258].map((t) =>
              e.jsx(
                "path",
                {
                  d: `M${t} 72V${[146, 124, 120, 134][[76, 140, 196, 258].indexOf(t)] - 10}`,
                  stroke: h,
                  strokeWidth: "4",
                  strokeDasharray: "3 7",
                  strokeLinecap: "round",
                },
                t,
              ),
            ),
            e.jsx("path", {
              d: "M30 162H292V146L276 132H208L196 116H170L160 128H118L56 150H30Z",
              fill: c,
              strokeLinejoin: "round",
            }),
            e.jsx("path", {
              d: "M150 128C160 112 182 110 196 118",
              fill: "none",
              stroke: k,
              strokeWidth: "5",
              strokeLinecap: "round",
            }),
            e.jsx("rect", {
              x: "276",
              y: "98",
              width: "10",
              height: "40",
              rx: "3",
              fill: n,
            }),
            e.jsx("rect", {
              x: "262",
              y: "94",
              width: "44",
              height: "12",
              rx: "3",
              fill: k,
            }),
            e.jsx("rect", {
              x: "12",
              y: "158",
              width: "52",
              height: "10",
              rx: "3",
              fill: k,
            }),
            e.jsx("circle", {
              cx: "76",
              cy: "160",
              r: "22",
              fill: fe,
              stroke: n,
              strokeWidth: "5",
            }),
            e.jsx("circle", {
              cx: "244",
              cy: "160",
              r: "24",
              fill: fe,
              stroke: n,
              strokeWidth: "5",
            }),
            [76, 140, 196, 258].map((t, r) =>
              e.jsx(
                "circle",
                {
                  cx: t,
                  cy: [146, 124, 120, 134][r],
                  r: "7",
                  fill: A,
                  stroke: M,
                  strokeWidth: "2",
                },
                t,
              ),
            ),
          ],
        },
        "1",
      ),
      e.jsxs(
        "g",
        {
          children: [
            e.jsx("path", {
              d: "M40 92V112M190 92V112",
              stroke: k,
              strokeWidth: "5",
            }),
            e.jsx("path", {
              d: "M40 112H190",
              stroke: k,
              strokeWidth: "7",
              strokeLinecap: "round",
            }),
            e.jsx("ellipse", {
              cx: "40",
              cy: "90",
              rx: "34",
              ry: "7",
              fill: n,
            }),
            e.jsx("ellipse", {
              cx: "190",
              cy: "90",
              rx: "34",
              ry: "7",
              fill: n,
            }),
            e.jsx("rect", {
              x: "76",
              y: "100",
              width: "78",
              height: "36",
              rx: "12",
              fill: c,
            }),
            e.jsx("circle", {
              cx: "115",
              cy: "144",
              r: "10",
              fill: fe,
              stroke: n,
              strokeWidth: "3",
            }),
            e.jsx("path", {
              d: "M115 108V116",
              stroke: A,
              strokeWidth: "4",
              strokeLinecap: "round",
            }),
            e.jsx("path", {
              d: "M106 112A12 12 0 1 0 124 112",
              fill: "none",
              stroke: A,
              strokeWidth: "4",
              strokeLinecap: "round",
            }),
            e.jsx("path", {
              d: "M86 160L80 176M144 160L150 176",
              stroke: k,
              strokeWidth: "5",
              strokeLinecap: "round",
            }),
            e.jsx("rect", {
              x: "252",
              y: "40",
              width: "20",
              height: "12",
              rx: "3",
              fill: w,
            }),
            e.jsx("circle", {
              cx: "262",
              cy: "104",
              r: "46",
              fill: R,
              stroke: n,
              strokeWidth: "5",
            }),
            e.jsx("path", {
              d: "M262 66A38 38 0 1 1 226.9 89.5",
              fill: "none",
              stroke: h,
              strokeWidth: "8",
              strokeLinecap: "round",
            }),
            e.jsx(K, { x: 262, y: 111, colour: q, size: 20, children: "0.8s" }),
          ],
        },
        "2",
      ),
    ],
    "digital-forensics-investigator": [
      e.jsxs(
        "g",
        {
          children: [
            e.jsxs(pe, {
              x: 110,
              y: 12,
              w: 104,
              h: 178,
              children: [
                e.jsx("rect", {
                  x: "122",
                  y: "36",
                  width: "58",
                  height: "22",
                  rx: "10",
                  fill: c,
                }),
                e.jsx("rect", {
                  x: "144",
                  y: "68",
                  width: "58",
                  height: "22",
                  rx: "10",
                  fill: h,
                }),
                e.jsx("rect", {
                  x: "122",
                  y: "100",
                  width: "66",
                  height: "22",
                  rx: "10",
                  fill: h,
                }),
                e.jsx("rect", {
                  x: "140",
                  y: "132",
                  width: "62",
                  height: "22",
                  rx: "10",
                  fill: "none",
                  stroke: k,
                  strokeWidth: "3",
                  strokeDasharray: "6 5",
                }),
              ],
            }),
            e.jsx("path", {
              d: "M58 70A34 34 0 1 1 46 124",
              fill: "none",
              stroke: h,
              strokeWidth: "7",
              strokeLinecap: "round",
            }),
            e.jsx("path", {
              d: "M42 56L58 70L42 84",
              fill: "none",
              stroke: h,
              strokeWidth: "7",
              strokeLinecap: "round",
              strokeLinejoin: "round",
              transform: "rotate(-20 58 70)",
            }),
            e.jsx("path", {
              d: "M214 40C236 40 246 52 248 66",
              fill: "none",
              stroke: k,
              strokeWidth: "3",
            }),
            e.jsx("path", {
              d: "M236 66H286L300 82L286 98H236Z",
              fill: V,
              strokeLinejoin: "round",
            }),
            e.jsx("circle", { cx: "246", cy: "82", r: "5", fill: M }),
            e.jsx("rect", {
              x: "256",
              y: "78",
              width: "26",
              height: "8",
              rx: "4",
              fill: ge,
            }),
          ],
        },
        "0",
      ),
      e.jsxs(
        "g",
        {
          children: [
            e.jsx(se, {
              x: 20,
              y: 26,
              w: 190,
              h: 150,
              children: ["09:12", "13:40", "02:14", "18:05"].map((t, r) =>
                e.jsxs(
                  "g",
                  {
                    children: [
                      e.jsx("rect", {
                        x: "32",
                        y: 60 + r * 28,
                        width: "166",
                        height: "22",
                        rx: "6",
                        fill: r === 2 ? ge : c,
                      }),
                      e.jsx("circle", {
                        cx: "46",
                        cy: 71 + r * 28,
                        r: "5",
                        fill: "none",
                        stroke: r === 2 ? V : w,
                        strokeWidth: "3",
                      }),
                      e.jsx("path", {
                        d: `M51 ${71 + r * 28}H62`,
                        stroke: r === 2 ? V : w,
                        strokeWidth: "3",
                        strokeLinecap: "round",
                      }),
                      e.jsx(K, {
                        x: 74,
                        y: 77 + r * 28,
                        colour: r === 2 ? q : w,
                        anchor: "start",
                        size: 14,
                        children: t,
                      }),
                      e.jsx("rect", {
                        x: "130",
                        y: 68 + r * 28,
                        width: "56",
                        height: "6",
                        rx: "3",
                        fill: r === 2 ? V : n,
                      }),
                    ],
                  },
                  t,
                ),
              ),
            }),
            e.jsx(Qe, { x: 190, y: 126, r: 30, colour: h }),
            e.jsx("circle", {
              cx: "270",
              cy: "56",
              r: "32",
              fill: R,
              stroke: n,
              strokeWidth: "4",
            }),
            e.jsx("path", {
              d: "M270 56V36M270 56L284 64",
              stroke: q,
              strokeWidth: "5",
              strokeLinecap: "round",
            }),
          ],
        },
        "1",
      ),
      e.jsxs(
        "g",
        {
          children: [
            e.jsx("rect", {
              x: "180",
              y: "24",
              width: "122",
              height: "88",
              rx: "8",
              fill: R,
              stroke: n,
              strokeWidth: "3",
            }),
            e.jsx("path", {
              d: "M212 112L200 176M270 112L282 176",
              stroke: k,
              strokeWidth: "5",
              strokeLinecap: "round",
            }),
            e.jsx("rect", {
              x: "194",
              y: "38",
              width: "36",
              height: "60",
              rx: "7",
              fill: c,
            }),
            e.jsx("rect", {
              x: "200",
              y: "50",
              width: "22",
              height: "9",
              rx: "4",
              fill: h,
            }),
            e.jsx("rect", {
              x: "204",
              y: "66",
              width: "20",
              height: "9",
              rx: "4",
              fill: w,
            }),
            e.jsx(J, {
              x: 242,
              y: 46,
              widths: [46, 36, 46, 28],
              colour: w,
              gap: 13,
            }),
            e.jsx("rect", {
              x: "20",
              y: "24",
              width: "132",
              height: "62",
              rx: "14",
              fill: h,
            }),
            e.jsx("path", { d: "M152 50L172 56L152 64Z", fill: h }),
            e.jsx(J, {
              x: 36,
              y: 40,
              widths: [96, 72, 84],
              colour: ae,
              gap: 11,
            }),
            [0, 1].map((t) =>
              e.jsx(
                "g",
                {
                  children: [0, 1, 2, 3, 4, 5].map((r) =>
                    e.jsx(
                      "rect",
                      {
                        x: 20 + r * 22,
                        y: 110 + t * 26,
                        width: "16",
                        height: "22",
                        rx: "5",
                        fill: t === 0 ? k : n,
                      },
                      r,
                    ),
                  ),
                },
                t,
              ),
            ),
            e.jsx("rect", {
              x: "12",
              y: "154",
              width: "148",
              height: "30",
              rx: "5",
              fill: c,
            }),
          ],
        },
        "2",
      ),
    ],
    "ai-engineer": [
      e.jsxs(
        "g",
        {
          children: [
            e.jsx("rect", {
              x: "20",
              y: "22",
              width: "180",
              height: "156",
              rx: "10",
              fill: fe,
              stroke: n,
              strokeWidth: "3",
            }),
            e.jsx("path", {
              d: "M110 44V96",
              stroke: k,
              strokeWidth: "6",
              strokeLinecap: "round",
            }),
            e.jsx("path", {
              d: "M102 74C82 58 54 76 50 112C46 144 60 160 80 156C98 152 104 136 104 112Z",
              fill: c,
              stroke: k,
              strokeWidth: "3",
            }),
            e.jsx("path", {
              d: "M118 74C138 58 166 76 170 112C174 144 160 160 140 156C122 152 116 136 116 112Z",
              fill: c,
              stroke: k,
              strokeWidth: "3",
            }),
            e.jsx("circle", { cx: "146", cy: "124", r: "7", fill: V }),
            e.jsx("circle", {
              cx: "146",
              cy: "124",
              r: "20",
              fill: "none",
              stroke: Z,
              strokeWidth: "4",
              strokeDasharray: "8 5",
            }),
            e.jsx("path", {
              d: "M166 124H222",
              stroke: Z,
              strokeWidth: "3",
              strokeDasharray: "4 6",
              strokeLinecap: "round",
            }),
            [
              [232, 62],
              [232, 100],
              [232, 138],
              [270, 81],
              [270, 119],
              [300, 100],
            ].map(([t, r], s, i) =>
              e.jsxs(
                "g",
                {
                  children: [
                    s < 3 &&
                      [3, 4].map((l) =>
                        e.jsx(
                          "path",
                          {
                            d: `M${t} ${r}L${i[l][0]} ${i[l][1]}`,
                            stroke: n,
                            strokeWidth: "3",
                          },
                          l,
                        ),
                      ),
                    (s === 3 || s === 4) &&
                      e.jsx("path", {
                        d: `M${t} ${r}L300 100`,
                        stroke: n,
                        strokeWidth: "3",
                      }),
                  ],
                },
                s,
              ),
            ),
            [
              [232, 62],
              [232, 100],
              [232, 138],
              [270, 81],
              [270, 119],
            ].map(([t, r]) =>
              e.jsx("circle", { cx: t, cy: r, r: "9", fill: h }, `${t}-${r}`),
            ),
            e.jsx("circle", { cx: "300", cy: "100", r: "11", fill: Z }),
          ],
        },
        "0",
      ),
      e.jsxs(
        "g",
        {
          children: [
            e.jsx("path", {
              d: "M160 52V170",
              stroke: k,
              strokeWidth: "8",
              strokeLinecap: "round",
            }),
            e.jsx("rect", {
              x: "118",
              y: "168",
              width: "84",
              height: "12",
              rx: "6",
              fill: k,
            }),
            e.jsx("path", {
              d: "M56 52H264",
              stroke: m,
              strokeWidth: "8",
              strokeLinecap: "round",
            }),
            e.jsx("circle", { cx: "160", cy: "52", r: "12", fill: h }),
            e.jsx("path", {
              d: "M60 52L30 120M60 52L90 120M260 52L230 120M260 52L290 120",
              stroke: k,
              strokeWidth: "3",
            }),
            e.jsx("path", {
              d: "M22 120H98C98 140 80 150 60 150C40 150 22 140 22 120Z",
              fill: c,
            }),
            e.jsx("path", {
              d: "M222 120H298C298 140 280 150 260 150C240 150 222 140 222 120Z",
              fill: c,
            }),
            e.jsx("rect", {
              x: "30",
              y: "94",
              width: "34",
              height: "26",
              rx: "5",
              fill: h,
            }),
            e.jsx("rect", {
              x: "62",
              y: "98",
              width: "30",
              height: "22",
              rx: "5",
              fill: G,
            }),
            e.jsx("path", { d: "M42 100L54 107L42 114Z", fill: M }),
            e.jsx("rect", {
              x: "226",
              y: "94",
              width: "34",
              height: "26",
              rx: "5",
              fill: Be,
            }),
            e.jsx("rect", {
              x: "258",
              y: "98",
              width: "30",
              height: "22",
              rx: "5",
              fill: Fe,
            }),
            e.jsx("path", { d: "M238 100L250 107L238 114Z", fill: M }),
            e.jsx("path", {
              d: "M150 26H170M150 34H170",
              stroke: A,
              strokeWidth: "4",
              strokeLinecap: "round",
            }),
          ],
        },
        "1",
      ),
      e.jsxs(
        "g",
        {
          children: [
            e.jsxs(se, {
              x: 18,
              y: 24,
              w: 200,
              h: 152,
              children: [
                e.jsx("rect", {
                  x: "96",
                  y: "60",
                  width: "108",
                  height: "34",
                  rx: "12",
                  fill: c,
                }),
                e.jsx(J, {
                  x: 108,
                  y: 70,
                  widths: [80, 56],
                  colour: w,
                  gap: 10,
                }),
                e.jsx("circle", { cx: "44", cy: "124", r: "14", fill: G }),
                e.jsx(xe, { x: 44, y: 124, r: 9, colour: A }),
                e.jsx("rect", {
                  x: "64",
                  y: "106",
                  width: "130",
                  height: "50",
                  rx: "12",
                  fill: h,
                }),
                e.jsx(J, {
                  x: 78,
                  y: 118,
                  widths: [96, 104, 64],
                  colour: ae,
                  gap: 10,
                }),
              ],
            }),
            e.jsx(tt, { x: 268, y: 100, s: 1.25 }),
          ],
        },
        "2",
      ),
    ],
    "software-developer": [
      e.jsxs(
        "g",
        {
          children: [
            e.jsx("rect", {
              x: "0",
              y: "160",
              width: "320",
              height: "40",
              fill: R,
            }),
            e.jsx("rect", {
              x: "20",
              y: "148",
              width: "100",
              height: "16",
              rx: "4",
              fill: c,
            }),
            e.jsx("rect", {
              x: "186",
              y: "84",
              width: "74",
              height: "16",
              rx: "4",
              fill: c,
            }),
            e.jsx("rect", {
              x: "270",
              y: "40",
              width: "6",
              height: "44",
              rx: "2",
              fill: m,
            }),
            e.jsx("path", { d: "M276 42L300 52L276 62Z", fill: h }),
            e.jsx("rect", {
              x: "40",
              y: "114",
              width: "28",
              height: "28",
              rx: "6",
              fill: m,
            }),
            e.jsx("path", {
              d: "M86 146L96 138L106 146L116 138M86 140",
              fill: "none",
              stroke: Fe,
              strokeWidth: "4",
              strokeLinecap: "round",
              strokeLinejoin: "round",
            }),
            e.jsx("rect", {
              x: "82",
              y: "128",
              width: "38",
              height: "8",
              rx: "4",
              fill: Be,
            }),
            e.jsx("path", {
              d: "M100 124C116 36 186 26 214 70",
              fill: "none",
              stroke: h,
              strokeWidth: "4",
              strokeDasharray: "3 9",
              strokeLinecap: "round",
            }),
            e.jsx("circle", { cx: "150", cy: "60", r: "11", fill: V }),
            e.jsx("circle", { cx: "222", cy: "58", r: "11", fill: V }),
            e.jsx(K, {
              x: 36,
              y: 44,
              colour: A,
              size: 22,
              anchor: "start",
              children: "</>",
            }),
          ],
        },
        "0",
      ),
      e.jsxs(
        "g",
        {
          children: [
            e.jsxs(pe, {
              x: 106,
              y: 10,
              w: 108,
              h: 182,
              children: [
                e.jsx("rect", {
                  x: "118",
                  y: "30",
                  width: "84",
                  height: "20",
                  rx: "6",
                  fill: c,
                }),
                e.jsx("rect", {
                  x: "118",
                  y: "58",
                  width: "84",
                  height: "34",
                  rx: "8",
                  fill: c,
                }),
                e.jsx("rect", {
                  x: "118",
                  y: "140",
                  width: "84",
                  height: "34",
                  rx: "8",
                  fill: c,
                }),
                e.jsx("rect", {
                  x: "118",
                  y: "100",
                  width: "84",
                  height: "32",
                  rx: "8",
                  fill: "none",
                  stroke: h,
                  strokeWidth: "3",
                  strokeDasharray: "6 5",
                }),
              ],
            }),
            e.jsx("rect", {
              x: "156",
              y: "84",
              width: "100",
              height: "40",
              rx: "10",
              fill: h,
              transform: "rotate(-8 206 104)",
            }),
            e.jsx("path", {
              d: "M206 92V116M194 104H218",
              stroke: M,
              strokeWidth: "6",
              strokeLinecap: "round",
              transform: "rotate(-8 206 104)",
            }),
            e.jsx(xe, { x: 272, y: 66, r: 12 }),
            e.jsx(xe, { x: 58, y: 56, r: 8, colour: k }),
            e.jsx(xe, { x: 52, y: 144, r: 10, colour: k }),
            e.jsx(xe, { x: 278, y: 150, r: 8, colour: k }),
          ],
        },
        "1",
      ),
      e.jsxs(
        "g",
        {
          children: [
            e.jsxs(se, {
              x: 16,
              y: 24,
              w: 204,
              h: 152,
              children: [
                [0, 1, 2, 3, 4].map((t) =>
                  e.jsx(
                    "rect",
                    {
                      x: "30",
                      y: 40 + t * 24,
                      width: "12",
                      height: "8",
                      rx: "3",
                      fill: n,
                    },
                    t,
                  ),
                ),
                e.jsx("rect", {
                  x: "50",
                  y: "40",
                  width: "110",
                  height: "8",
                  rx: "4",
                  fill: k,
                }),
                e.jsx("rect", {
                  x: "46",
                  y: "58",
                  width: "164",
                  height: "26",
                  rx: "5",
                  fill: re,
                  fillOpacity: "0.35",
                }),
                e.jsx("rect", {
                  x: "56",
                  y: "67",
                  width: "96",
                  height: "8",
                  rx: "4",
                  fill: Z,
                }),
                e.jsx("rect", {
                  x: "46",
                  y: "86",
                  width: "164",
                  height: "22",
                  rx: "5",
                  fill: ae,
                }),
                e.jsx("rect", {
                  x: "56",
                  y: "93",
                  width: "128",
                  height: "8",
                  rx: "4",
                  fill: A,
                }),
                e.jsx("rect", {
                  x: "50",
                  y: "136",
                  width: "90",
                  height: "8",
                  rx: "4",
                  fill: k,
                }),
                e.jsx("rect", {
                  x: "50",
                  y: "160",
                  width: "120",
                  height: "8",
                  rx: "4",
                  fill: k,
                }),
              ],
            }),
            e.jsx("rect", {
              x: "228",
              y: "62",
              width: "80",
              height: "58",
              rx: "12",
              fill: c,
            }),
            e.jsx("path", { d: "M232 92L214 98L236 104Z", fill: c }),
            e.jsx(J, {
              x: 240,
              y: 76,
              widths: [56, 40, 50],
              colour: w,
              gap: 12,
            }),
            e.jsx(Ae, { x: 268, y: 150, r: 22 }),
          ],
        },
        "2",
      ),
    ],
    "test-engineer": [
      e.jsxs(
        "g",
        {
          children: [
            e.jsx(he, { x: 26, y: 18, w: 168, h: 164 }),
            e.jsx("rect", {
              x: "44",
              y: "34",
              width: "70",
              height: "10",
              rx: "5",
              fill: w,
            }),
            e.jsx("rect", {
              x: "44",
              y: "58",
              width: "132",
              height: "28",
              rx: "6",
              fill: c,
            }),
            e.jsx(J, { x: 54, y: 69, widths: [70], colour: k }),
            e.jsx("rect", {
              x: "44",
              y: "96",
              width: "132",
              height: "28",
              rx: "6",
              fill: M,
              stroke: Z,
              strokeWidth: "3",
            }),
            e.jsx(K, {
              x: 54,
              y: 116,
              colour: Z,
              anchor: "start",
              size: 15,
              children: "%$#@!?",
            }),
            e.jsx("rect", {
              x: "44",
              y: "140",
              width: "80",
              height: "28",
              rx: "14",
              fill: n,
            }),
            e.jsx("path", {
              d: "M150 18L138 52L156 70L140 104L160 132L148 182",
              fill: "none",
              stroke: M,
              strokeWidth: "5",
              strokeLinejoin: "round",
            }),
            e.jsx("path", {
              d: "M248 52L294 136H202Z",
              fill: V,
              strokeLinejoin: "round",
              stroke: V,
              strokeWidth: "8",
            }),
            e.jsx("path", {
              d: "M248 80V108",
              stroke: M,
              strokeWidth: "8",
              strokeLinecap: "round",
            }),
            e.jsx("circle", { cx: "248", cy: "124", r: "5", fill: M }),
          ],
        },
        "0",
      ),
      e.jsxs(
        "g",
        {
          children: [
            e.jsx("path", {
              d: "M112 36A64 64 0 0 1 156 132",
              fill: "none",
              stroke: h,
              strokeWidth: "7",
              strokeLinecap: "round",
            }),
            e.jsx("path", {
              d: "M140 132L158 134L162 116",
              fill: "none",
              stroke: h,
              strokeWidth: "7",
              strokeLinecap: "round",
              strokeLinejoin: "round",
            }),
            e.jsx("path", {
              d: "M86 162A64 64 0 0 1 64 46",
              fill: "none",
              stroke: h,
              strokeWidth: "7",
              strokeLinecap: "round",
            }),
            e.jsx("path", {
              d: "M50 62L62 46L80 50",
              fill: "none",
              stroke: h,
              strokeWidth: "7",
              strokeLinecap: "round",
              strokeLinejoin: "round",
            }),
            e.jsx("path", {
              d: "M78 66H112L126 80V134H78Z",
              fill: c,
              stroke: n,
              strokeWidth: "3",
              strokeLinejoin: "round",
            }),
            e.jsx(J, {
              x: 88,
              y: 88,
              widths: [28, 20, 26],
              colour: w,
              gap: 12,
            }),
            e.jsx(he, { x: 192, y: 26, w: 112, h: 148 }),
            [0, 1, 2, 3].map((t) =>
              e.jsxs(
                "g",
                {
                  children: [
                    e.jsx("rect", {
                      x: "204",
                      y: 40 + t * 33,
                      width: "24",
                      height: "24",
                      rx: "6",
                      fill: h,
                    }),
                    e.jsx(ye, {
                      x: 216,
                      y: 52 + t * 33,
                      size: 0.55,
                      colour: M,
                      width: 4,
                    }),
                    e.jsx("rect", {
                      x: "238",
                      y: 49 + t * 33,
                      width: [52, 40, 48, 36][t],
                      height: "7",
                      rx: "3.5",
                      fill: w,
                    }),
                  ],
                },
                t,
              ),
            ),
          ],
        },
        "1",
      ),
      e.jsxs(
        "g",
        {
          children: [
            e.jsx("path", {
              d: "M26 120C26 98 42 90 60 92H128C146 90 162 98 162 120L170 160C172 178 150 184 140 170L128 154H60L48 170C38 184 16 178 18 160Z",
              fill: c,
            }),
            e.jsx("path", {
              d: "M58 112V136M46 124H70",
              stroke: m,
              strokeWidth: "6",
              strokeLinecap: "round",
            }),
            e.jsx("circle", { cx: "132", cy: "114", r: "7", fill: m }),
            e.jsx("circle", { cx: "146", cy: "128", r: "7", fill: m }),
            e.jsx("circle", {
              cx: "58",
              cy: "42",
              r: "26",
              fill: R,
              stroke: n,
              strokeWidth: "4",
            }),
            e.jsx("path", {
              d: "M58 42V26M58 42L70 50",
              stroke: w,
              strokeWidth: "4",
              strokeLinecap: "round",
            }),
            e.jsx("path", {
              d: "M200 34H276L294 52V140H200Z",
              fill: R,
              stroke: n,
              strokeWidth: "4",
              strokeLinejoin: "round",
            }),
            e.jsx("rect", {
              x: "218",
              y: "34",
              width: "54",
              height: "34",
              rx: "3",
              fill: c,
            }),
            e.jsx("rect", {
              x: "252",
              y: "40",
              width: "12",
              height: "22",
              rx: "2",
              fill: n,
            }),
            e.jsx("rect", {
              x: "214",
              y: "92",
              width: "66",
              height: "48",
              rx: "4",
              fill: c,
            }),
            e.jsx(Ge, { x: 248, y: 114, colour: Z, size: 1.1 }),
          ],
        },
        "2",
      ),
    ],
    "electronics-engineer": [
      e.jsxs(
        "g",
        {
          children: [
            e.jsx("path", {
              d: "M40 92C40 60 64 46 92 50H228C256 46 280 60 280 92L290 150C294 180 258 188 244 168L226 144H94L76 168C62 188 26 180 30 150Z",
              fill: ae,
              stroke: G,
              strokeWidth: "4",
            }),
            e.jsx("path", {
              d: "M90 96H130V120H160M230 96H190V120H160M160 120V144M90 96V140M230 96V140",
              fill: "none",
              stroke: A,
              strokeWidth: "3",
              strokeLinejoin: "round",
            }),
            e.jsx("rect", {
              x: "138",
              y: "72",
              width: "44",
              height: "36",
              rx: "5",
              fill: M,
            }),
            e.jsx("path", {
              d: "M146 68V72M156 68V72M166 68V72M176 68V72M146 108V112M156 108V112M166 108V112M176 108V112",
              stroke: m,
              strokeWidth: "3",
            }),
            [
              [90, 96],
              [230, 96],
              [90, 140],
              [230, 140],
              [160, 144],
            ].map(([t, r]) =>
              e.jsx(
                "circle",
                { cx: t, cy: r, r: "8", fill: m, stroke: ae, strokeWidth: "3" },
                `${t}-${r}`,
              ),
            ),
            e.jsx("rect", {
              x: "66",
              y: "66",
              width: "20",
              height: "12",
              rx: "3",
              fill: M,
            }),
            e.jsx("rect", {
              x: "236",
              y: "66",
              width: "20",
              height: "12",
              rx: "3",
              fill: M,
            }),
          ],
        },
        "0",
      ),
      e.jsxs(
        "g",
        {
          children: [
            e.jsx(Se, { y: 180 }),
            e.jsx("rect", {
              x: "30",
              y: "160",
              width: "64",
              height: "20",
              rx: "6",
              fill: c,
            }),
            e.jsx("path", {
              d: "M62 160L96 82L182 70",
              fill: "none",
              stroke: k,
              strokeWidth: "16",
              strokeLinecap: "round",
              strokeLinejoin: "round",
            }),
            e.jsx("circle", { cx: "62", cy: "158", r: "12", fill: n }),
            e.jsx("circle", { cx: "96", cy: "82", r: "11", fill: n }),
            e.jsx("circle", { cx: "182", cy: "70", r: "9", fill: n }),
            e.jsx("path", {
              d: "M186 70L204 60M186 70L204 82",
              stroke: m,
              strokeWidth: "6",
              strokeLinecap: "round",
            }),
            e.jsx("ellipse", {
              cx: "262",
              cy: "166",
              rx: "40",
              ry: "12",
              fill: c,
            }),
            e.jsx("ellipse", {
              cx: "262",
              cy: "166",
              rx: "26",
              ry: "7",
              fill: G,
            }),
            e.jsx("ellipse", {
              cx: "262",
              cy: "166",
              rx: "10",
              ry: "3.5",
              fill: A,
            }),
            e.jsx("path", {
              d: "M208 72C252 74 276 98 290 132",
              fill: "none",
              stroke: Z,
              strokeWidth: "4",
              strokeDasharray: "3 9",
              strokeLinecap: "round",
            }),
            e.jsx(Ke, { x: 296, y: 142, size: 8, width: 5 }),
          ],
        },
        "1",
      ),
      e.jsxs(
        "g",
        {
          children: [
            e.jsx("rect", {
              x: "84",
              y: "14",
              width: "56",
              height: "44",
              rx: "8",
              fill: c,
            }),
            e.jsx("rect", {
              x: "84",
              y: "142",
              width: "56",
              height: "44",
              rx: "8",
              fill: c,
            }),
            e.jsx("rect", {
              x: "64",
              y: "46",
              width: "96",
              height: "108",
              rx: "24",
              fill: fe,
              stroke: n,
              strokeWidth: "5",
            }),
            e.jsx("rect", {
              x: "160",
              y: "88",
              width: "8",
              height: "22",
              rx: "3",
              fill: n,
            }),
            e.jsx("rect", {
              x: "86",
              y: "80",
              width: "44",
              height: "40",
              rx: "6",
              fill: "none",
              stroke: h,
              strokeWidth: "4",
            }),
            e.jsx("rect", {
              x: "130",
              y: "92",
              width: "6",
              height: "16",
              rx: "2",
              fill: h,
            }),
            e.jsx("rect", {
              x: "92",
              y: "86",
              width: "9",
              height: "28",
              rx: "2",
              fill: h,
            }),
            e.jsx("rect", {
              x: "104",
              y: "86",
              width: "9",
              height: "28",
              rx: "2",
              fill: h,
            }),
            e.jsx("rect", {
              x: "116",
              y: "86",
              width: "9",
              height: "28",
              rx: "2",
              fill: h,
            }),
            e.jsx("rect", {
              x: "206",
              y: "54",
              width: "94",
              height: "92",
              rx: "10",
              fill: R,
              stroke: n,
              strokeWidth: "3",
            }),
            e.jsx("rect", {
              x: "206",
              y: "54",
              width: "94",
              height: "24",
              rx: "10",
              fill: c,
            }),
            e.jsx("path", {
              d: "M228 46V62M278 46V62",
              stroke: w,
              strokeWidth: "5",
              strokeLinecap: "round",
            }),
            e.jsx(K, { x: 253, y: 124, colour: A, size: 26, children: "+1" }),
          ],
        },
        "2",
      ),
    ],
    "app-developer": [
      e.jsxs(
        "g",
        {
          children: [
            e.jsxs(se, {
              x: 14,
              y: 26,
              w: 196,
              h: 150,
              children: [
                e.jsx("rect", {
                  x: "15.5",
                  y: "51.5",
                  width: "44",
                  height: "123",
                  fill: M,
                }),
                e.jsx(J, {
                  x: 24,
                  y: 64,
                  widths: [26, 20, 28, 18],
                  colour: n,
                  gap: 16,
                }),
                e.jsx("rect", {
                  x: "150",
                  y: "6",
                  width: "44",
                  height: "14",
                  rx: "4",
                  fill: G,
                }),
                e.jsx(K, {
                  x: 172,
                  y: 18,
                  colour: q,
                  size: 11,
                  children: ".kt",
                }),
                e.jsx(J, {
                  x: 70,
                  y: 62,
                  widths: [60, 92, 74, 104, 48, 84],
                  colour: k,
                  gap: 17,
                }),
                e.jsx("rect", {
                  x: "70",
                  y: "79",
                  width: "92",
                  height: "6",
                  rx: "3",
                  fill: h,
                }),
              ],
            }),
            e.jsx("path", {
              d: "M216 100H232",
              stroke: h,
              strokeWidth: "5",
              strokeLinecap: "round",
            }),
            e.jsx("path", {
              d: "M226 92L234 100L226 108",
              fill: "none",
              stroke: h,
              strokeWidth: "5",
              strokeLinecap: "round",
              strokeLinejoin: "round",
            }),
            e.jsxs(pe, {
              x: 240,
              y: 24,
              w: 70,
              h: 152,
              children: [
                e.jsx("rect", {
                  x: "248",
                  y: "40",
                  width: "54",
                  height: "22",
                  rx: "5",
                  fill: h,
                }),
                e.jsx("rect", {
                  x: "248",
                  y: "70",
                  width: "54",
                  height: "28",
                  rx: "5",
                  fill: c,
                }),
                e.jsx("rect", {
                  x: "248",
                  y: "104",
                  width: "24",
                  height: "24",
                  rx: "5",
                  fill: c,
                }),
                e.jsx("rect", {
                  x: "278",
                  y: "104",
                  width: "24",
                  height: "24",
                  rx: "5",
                  fill: c,
                }),
                e.jsx("rect", {
                  x: "256",
                  y: "148",
                  width: "38",
                  height: "14",
                  rx: "7",
                  fill: A,
                }),
              ],
            }),
          ],
        },
        "0",
      ),
      e.jsxs(
        "g",
        {
          children: [
            e.jsx("rect", {
              x: "22",
              y: "40",
              width: "88",
              height: "140",
              rx: "10",
              fill: c,
              stroke: n,
              strokeWidth: "4",
            }),
            e.jsx("rect", {
              x: "30",
              y: "20",
              width: "10",
              height: "24",
              rx: "3",
              fill: n,
            }),
            e.jsx("rect", {
              x: "32",
              y: "54",
              width: "68",
              height: "70",
              rx: "4",
              fill: M,
            }),
            e.jsx("path", {
              d: "M48 66L60 84L50 96L66 112",
              fill: "none",
              stroke: Z,
              strokeWidth: "4",
              strokeLinejoin: "round",
            }),
            e.jsx(Ke, { x: 80, y: 88, size: 10, width: 6 }),
            [0, 1, 2].map((t) =>
              e.jsx(
                "g",
                {
                  children: [0, 1, 2].map((r) =>
                    e.jsx(
                      "rect",
                      {
                        x: 38 + r * 20,
                        y: 134 + t * 14,
                        width: "16",
                        height: "9",
                        rx: "3",
                        fill: n,
                      },
                      r,
                    ),
                  ),
                },
                t,
              ),
            ),
            e.jsxs(se, {
              x: 128,
              y: 26,
              w: 176,
              h: 150,
              children: [
                e.jsx("path", { d: "M166 38L176 32V44Z", fill: h }),
                e.jsx("path", {
                  d: "M186 33V43M192 38H202",
                  stroke: h,
                  strokeWidth: "4",
                  strokeLinecap: "round",
                }),
                [0, 1, 2, 3].map((t) =>
                  e.jsx(
                    "rect",
                    {
                      x: "160",
                      y: 64 + t * 26,
                      width: [90, 110, 70, 100][t],
                      height: "8",
                      rx: "4",
                      fill: k,
                    },
                    t,
                  ),
                ),
                e.jsx("rect", {
                  x: "132",
                  y: "84",
                  width: "168",
                  height: "26",
                  rx: "5",
                  fill: re,
                  fillOpacity: "0.35",
                }),
                e.jsx("circle", { cx: "144", cy: "97", r: "7", fill: Z }),
                e.jsx("rect", {
                  x: "160",
                  y: "93",
                  width: "110",
                  height: "8",
                  rx: "4",
                  fill: Z,
                }),
              ],
            }),
            e.jsx(Ge, { x: 272, y: 150, colour: h, size: 0.7 }),
          ],
        },
        "1",
      ),
      e.jsxs(
        "g",
        {
          children: [
            e.jsx("rect", {
              x: "180",
              y: "74",
              width: "120",
              height: "102",
              rx: "6",
              fill: R,
              stroke: n,
              strokeWidth: "3",
            }),
            e.jsx("path", { d: "M172 56H308L300 82H180Z", fill: G }),
            [0, 1, 2, 3].map((t) =>
              e.jsx(
                "path",
                {
                  d: `M${180 + t * 32} 82A16 12 0 0 0 ${212 + t * 32} 82`,
                  fill: t % 2 === 0 ? h : G,
                },
                t,
              ),
            ),
            e.jsx(K, {
              x: 240,
              y: 124,
              colour: q,
              size: 14,
              children: "Play Store",
            }),
            e.jsx("rect", {
              x: "220",
              y: "140",
              width: "40",
              height: "36",
              rx: "4",
              fill: c,
            }),
            e.jsx("path", {
              d: "M86 132C110 54 180 40 214 60",
              fill: "none",
              stroke: h,
              strokeWidth: "4",
              strokeDasharray: "3 9",
              strokeLinecap: "round",
            }),
            e.jsx("rect", {
              x: "34",
              y: "104",
              width: "68",
              height: "68",
              rx: "18",
              fill: h,
            }),
            e.jsx("path", {
              d: "M68 156V120M54 134L68 120L82 134",
              fill: "none",
              stroke: M,
              strokeWidth: "7",
              strokeLinecap: "round",
              strokeLinejoin: "round",
            }),
            e.jsx("rect", {
              x: "74",
              y: "92",
              width: "44",
              height: "22",
              rx: "11",
              fill: V,
            }),
            e.jsx(K, { x: 96, y: 108, colour: M, size: 12, children: "v2.0" }),
            e.jsx("path", {
              d: "M22 186H128",
              stroke: c,
              strokeWidth: "4",
              strokeLinecap: "round",
            }),
          ],
        },
        "2",
      ),
    ],
    "ux-designer": [
      e.jsxs(
        "g",
        {
          children: [
            [0, 1, 2].map((t) => {
              const r = 18 + t * 100,
                s = t === 1;
              return e.jsxs(
                "g",
                {
                  children: [
                    e.jsx("rect", {
                      x: r,
                      y: "22",
                      width: "84",
                      height: "156",
                      rx: "14",
                      fill: R,
                      stroke: s ? h : n,
                      strokeWidth: s ? 4 : 3,
                      strokeDasharray: s ? void 0 : "8 5",
                    }),
                    t === 0 &&
                      e.jsxs("g", {
                        children: [
                          e.jsx("circle", {
                            cx: r + 42,
                            cy: "58",
                            r: "14",
                            fill: c,
                          }),
                          e.jsx("rect", {
                            x: r + 12,
                            y: "86",
                            width: "60",
                            height: "14",
                            rx: "4",
                            fill: c,
                          }),
                          e.jsx("rect", {
                            x: r + 12,
                            y: "108",
                            width: "60",
                            height: "14",
                            rx: "4",
                            fill: c,
                          }),
                          e.jsx("rect", {
                            x: r + 12,
                            y: "146",
                            width: "60",
                            height: "16",
                            rx: "8",
                            fill: k,
                          }),
                        ],
                      }),
                    t === 1 &&
                      e.jsxs("g", {
                        children: [
                          e.jsx("rect", {
                            x: r + 12,
                            y: "40",
                            width: "40",
                            height: "10",
                            rx: "5",
                            fill: w,
                          }),
                          e.jsx("rect", {
                            x: r + 12,
                            y: "62",
                            width: "60",
                            height: "16",
                            rx: "4",
                            fill: c,
                          }),
                          e.jsx("rect", {
                            x: r + 12,
                            y: "86",
                            width: "60",
                            height: "16",
                            rx: "4",
                            fill: c,
                          }),
                          e.jsx("rect", {
                            x: r + 12,
                            y: "110",
                            width: "60",
                            height: "16",
                            rx: "4",
                            fill: c,
                          }),
                          e.jsx("rect", {
                            x: r + 12,
                            y: "142",
                            width: "60",
                            height: "18",
                            rx: "9",
                            fill: h,
                          }),
                        ],
                      }),
                    t === 2 &&
                      e.jsxs("g", {
                        children: [
                          e.jsx("rect", {
                            x: r + 12,
                            y: "40",
                            width: "60",
                            height: "44",
                            rx: "6",
                            fill: c,
                          }),
                          e.jsx("rect", {
                            x: r + 12,
                            y: "96",
                            width: "28",
                            height: "28",
                            rx: "6",
                            fill: c,
                          }),
                          e.jsx("rect", {
                            x: r + 44,
                            y: "96",
                            width: "28",
                            height: "28",
                            rx: "6",
                            fill: c,
                          }),
                          e.jsx("rect", {
                            x: r + 12,
                            y: "146",
                            width: "60",
                            height: "16",
                            rx: "8",
                            fill: k,
                          }),
                        ],
                      }),
                  ],
                },
                t,
              );
            }),
            e.jsx(Ae, { x: 202, y: 26, r: 16 }),
          ],
        },
        "0",
      ),
      e.jsxs(
        "g",
        {
          children: [
            e.jsxs(pe, {
              x: 60,
              y: 10,
              w: 120,
              h: 180,
              children: [
                e.jsx("rect", {
                  x: "74",
                  y: "34",
                  width: "92",
                  height: "22",
                  rx: "6",
                  fill: c,
                }),
                e.jsx("rect", {
                  x: "74",
                  y: "66",
                  width: "92",
                  height: "44",
                  rx: "8",
                  fill: c,
                }),
                e.jsx("rect", {
                  x: "74",
                  y: "150",
                  width: "40",
                  height: "18",
                  rx: "9",
                  fill: n,
                }),
              ],
            }),
            e.jsx("path", {
              d: "M150 60C200 70 210 120 160 116C120 112 120 150 96 158",
              fill: "none",
              stroke: h,
              strokeWidth: "4",
              strokeDasharray: "3 8",
              strokeLinecap: "round",
            }),
            [
              [96, 158, 14],
              [92, 150, 8],
              [104, 162, 8],
            ].map(([t, r, s]) =>
              e.jsx(
                "circle",
                {
                  cx: t,
                  cy: r,
                  r: s,
                  fill: "none",
                  stroke: V,
                  strokeWidth: "3",
                },
                `${t}-${r}`,
              ),
            ),
            e.jsx("circle", { cx: "96", cy: "158", r: "5", fill: V }),
            e.jsx("circle", { cx: "248", cy: "74", r: "34", fill: V }),
            e.jsx("path", { d: "M222 100L214 118L236 104Z", fill: V }),
            e.jsx(K, { x: 248, y: 88, colour: M, size: 40, children: "?" }),
            e.jsx("circle", { cx: "232", cy: "150", r: "12", fill: re }),
            e.jsx("circle", {
              cx: "232",
              cy: "150",
              r: "20",
              fill: "none",
              stroke: re,
              strokeWidth: "3",
            }),
          ],
        },
        "1",
      ),
      e.jsxs(
        "g",
        {
          children: [
            e.jsxs(pe, {
              x: 40,
              y: 10,
              w: 120,
              h: 180,
              children: [
                e.jsx("rect", {
                  x: "54",
                  y: "36",
                  width: "92",
                  height: "14",
                  rx: "5",
                  fill: c,
                }),
                e.jsx("rect", {
                  x: "54",
                  y: "60",
                  width: "92",
                  height: "40",
                  rx: "8",
                  fill: c,
                }),
                e.jsx("rect", {
                  x: "58",
                  y: "120",
                  width: "84",
                  height: "26",
                  rx: "13",
                  fill: k,
                }),
                e.jsx("rect", {
                  x: "50",
                  y: "113",
                  width: "100",
                  height: "40",
                  rx: "18",
                  fill: "none",
                  stroke: h,
                  strokeWidth: "5",
                }),
              ],
            }),
            e.jsx("path", {
              d: "M156 133H184",
              stroke: h,
              strokeWidth: "4",
              strokeDasharray: "3 7",
              strokeLinecap: "round",
            }),
            e.jsx("path", {
              d: "M200 112H216L240 92V174L216 154H200Z",
              fill: m,
              strokeLinejoin: "round",
              stroke: m,
              strokeWidth: "4",
            }),
            e.jsx("path", {
              d: "M256 112A30 30 0 0 1 256 154",
              fill: "none",
              stroke: h,
              strokeWidth: "6",
              strokeLinecap: "round",
            }),
            e.jsx("path", {
              d: "M272 98A50 50 0 0 1 272 168",
              fill: "none",
              stroke: h,
              strokeWidth: "6",
              strokeLinecap: "round",
            }),
            e.jsx("path", {
              d: "M288 84A70 70 0 0 1 288 182",
              fill: "none",
              stroke: h,
              strokeWidth: "6",
              strokeLinecap: "round",
            }),
          ],
        },
        "2",
      ),
    ],
    "data-analyst": [
      e.jsxs(
        "g",
        {
          children: [
            e.jsx("rect", {
              x: "16",
              y: "24",
              width: "288",
              height: "160",
              rx: "10",
              fill: ae,
            }),
            e.jsx("path", { d: "M160 24V184", stroke: G, strokeWidth: "3" }),
            e.jsx("circle", {
              cx: "160",
              cy: "104",
              r: "26",
              fill: "none",
              stroke: G,
              strokeWidth: "3",
            }),
            e.jsx("rect", {
              x: "16",
              y: "66",
              width: "36",
              height: "76",
              fill: "none",
              stroke: G,
              strokeWidth: "3",
            }),
            e.jsx("rect", {
              x: "268",
              y: "66",
              width: "36",
              height: "76",
              fill: "none",
              stroke: G,
              strokeWidth: "3",
            }),
            e.jsx("path", {
              d: "M70 150C90 120 80 90 110 80M210 60C240 70 230 120 260 130M180 160C190 140 220 150 230 130",
              fill: "none",
              stroke: w,
              strokeWidth: "3",
              strokeLinecap: "round",
            }),
            e.jsx("path", {
              d: "M40 50C90 40 120 80 150 70C190 56 200 110 240 100C270 92 280 150 236 162C190 174 120 150 96 170",
              fill: "none",
              stroke: A,
              strokeWidth: "5",
              strokeLinecap: "round",
            }),
            e.jsx("circle", { cx: "40", cy: "50", r: "6", fill: A }),
            e.jsx("circle", { cx: "96", cy: "170", r: "8", fill: V }),
            e.jsx("rect", {
              x: "230",
              y: "10",
              width: "76",
              height: "28",
              rx: "14",
              fill: V,
            }),
            e.jsx(K, { x: 268, y: 29, colour: M, size: 15, children: "12 km" }),
          ],
        },
        "0",
      ),
      e.jsx(
        "g",
        {
          children: e.jsxs(se, {
            x: 14,
            y: 20,
            w: 292,
            h: 164,
            children: [
              e.jsx("rect", {
                x: "270",
                y: "6",
                width: "24",
                height: "12",
                rx: "3",
                fill: q,
              }),
              e.jsx("path", {
                d: "M282 7V17M277 12H287",
                stroke: re,
                strokeWidth: "3",
              }),
              e.jsx("circle", { cx: "82", cy: "104", r: "44", fill: c }),
              e.jsx("path", {
                d: "M82 60A44 44 0 0 1 124 116",
                fill: "none",
                stroke: h,
                strokeWidth: "8",
                strokeLinecap: "round",
              }),
              e.jsx("path", {
                d: "M82 104V76M82 104L100 112",
                stroke: q,
                strokeWidth: "5",
                strokeLinecap: "round",
              }),
              e.jsx("path", { d: "M150 166H294", stroke: n, strokeWidth: "3" }),
              [50, 70, 58, 100, 64, 44].map((t, r) =>
                e.jsx(
                  "rect",
                  {
                    x: 156 + r * 23,
                    y: 164 - t,
                    width: "16",
                    height: t,
                    rx: "4",
                    fill: t > 80 ? V : h,
                  },
                  r,
                ),
              ),
              e.jsx("path", {
                d: "M150 84H296",
                stroke: Z,
                strokeWidth: "3",
                strokeDasharray: "6 6",
              }),
            ],
          }),
        },
        "1",
      ),
      e.jsxs(
        "g",
        {
          children: [
            e.jsx("path", {
              d: "M26 30V170H186",
              fill: "none",
              stroke: n,
              strokeWidth: "4",
              strokeLinecap: "round",
            }),
            e.jsx("path", {
              d: "M38 150L68 140L92 146L120 112L146 100L176 52",
              fill: "none",
              stroke: h,
              strokeWidth: "6",
              strokeLinecap: "round",
              strokeLinejoin: "round",
            }),
            e.jsx("path", {
              d: "M160 52L178 48L180 66",
              fill: "none",
              stroke: h,
              strokeWidth: "6",
              strokeLinecap: "round",
              strokeLinejoin: "round",
            }),
            [
              [38, 150],
              [68, 140],
              [92, 146],
              [120, 112],
              [146, 100],
            ].map(([t, r]) =>
              e.jsx("circle", { cx: t, cy: r, r: "5", fill: A }, t),
            ),
            e.jsx("rect", {
              x: "204",
              y: "24",
              width: "102",
              height: "160",
              rx: "6",
              fill: R,
              stroke: n,
              strokeWidth: "3",
            }),
            e.jsx("path", {
              d: "M204 76H306M204 128H306",
              stroke: n,
              strokeWidth: "4",
            }),
            [0, 1, 2].map((t) =>
              e.jsx(
                "rect",
                {
                  x: 214 + t * 30,
                  y: "46",
                  width: "24",
                  height: "30",
                  rx: "3",
                  fill: c,
                },
                t,
              ),
            ),
            [0, 1].map((t) =>
              e.jsx(
                "rect",
                {
                  x: 214 + t * 30,
                  y: "150",
                  width: "24",
                  height: "30",
                  rx: "3",
                  fill: c,
                },
                t,
              ),
            ),
            e.jsx("rect", {
              x: "214",
              y: "96",
              width: "84",
              height: "32",
              rx: "4",
              fill: "none",
              stroke: V,
              strokeWidth: "3",
              strokeDasharray: "6 5",
            }),
            e.jsx("rect", {
              x: "222",
              y: "104",
              width: "22",
              height: "24",
              rx: "3",
              fill: h,
            }),
            e.jsx("rect", {
              x: "250",
              y: "104",
              width: "22",
              height: "24",
              rx: "3",
              fill: h,
            }),
          ],
        },
        "2",
      ),
    ],
    "cyber-security-analyst": [
      e.jsxs(
        "g",
        {
          children: [
            e.jsx("path", {
              d: "M58 24A26 26 0 1 0 82 60A20 20 0 1 1 58 24Z",
              fill: m,
            }),
            e.jsx(K, {
              x: 70,
              y: 106,
              colour: w,
              size: 18,
              children: "3:02am",
            }),
            e.jsx(he, { x: 128, y: 34, w: 176, h: 130 }),
            e.jsx("rect", {
              x: "128",
              y: "34",
              width: "176",
              height: "28",
              rx: "10",
              fill: re,
            }),
            e.jsx("path", {
              d: "M216 41V51M216 56V57",
              stroke: q,
              strokeWidth: "4",
              strokeLinecap: "round",
            }),
            e.jsx("rect", {
              x: "144",
              y: "76",
              width: "96",
              height: "22",
              rx: "6",
              fill: c,
            }),
            e.jsx("rect", {
              x: "144",
              y: "106",
              width: "96",
              height: "22",
              rx: "6",
              fill: c,
            }),
            [0, 1, 2, 3, 4].map((t) =>
              e.jsx(
                "circle",
                { cx: 156 + t * 16, cy: "117", r: "4", fill: w },
                t,
              ),
            ),
            e.jsx(Ve, { x: 238, y: 100, colour: h }),
            e.jsx("rect", {
              x: "36",
              y: "128",
              width: "58",
              height: "40",
              rx: "8",
              fill: c,
            }),
            e.jsx("circle", { cx: "65", cy: "146", r: "6", fill: Z }),
            e.jsx("path", {
              d: "M94 148H128",
              stroke: Z,
              strokeWidth: "4",
              strokeDasharray: "3 7",
              strokeLinecap: "round",
            }),
          ],
        },
        "0",
      ),
      e.jsxs(
        "g",
        {
          children: [
            [0, 1, 2].map((t) =>
              e.jsx(
                "g",
                {
                  children: [0, 1].map((r) => {
                    const s = 24 + r * 50,
                      i = 22 + t * 56,
                      l = t === 1 && r === 0;
                    return e.jsxs(
                      "g",
                      {
                        children: [
                          e.jsx("path", {
                            d: `M${s} ${i}H${s + 28}L${s + 40} ${i + 12}V${i + 46}H${s}Z`,
                            fill: l ? re : c,
                            strokeLinejoin: "round",
                          }),
                          l &&
                            e.jsxs("g", {
                              children: [
                                e.jsx("path", {
                                  d: `M${s + 14} ${i + 26}V${i + 20}A6 6 0 0 1 ${s + 26} ${i + 20}V${i + 26}`,
                                  fill: "none",
                                  stroke: q,
                                  strokeWidth: "3.5",
                                }),
                                e.jsx("rect", {
                                  x: s + 10,
                                  y: i + 26,
                                  width: "20",
                                  height: "14",
                                  rx: "3",
                                  fill: q,
                                }),
                              ],
                            }),
                        ],
                      },
                      r,
                    );
                  }),
                },
                t,
              ),
            ),
            e.jsx("path", {
              d: "M68 84L76 72M68 116L76 128M70 100H140",
              stroke: Z,
              strokeWidth: "4",
              strokeDasharray: "3 8",
              strokeLinecap: "round",
            }),
            e.jsx(tt, { x: 180, y: 100, s: 1.3 }),
            [0, 1, 2].map((t) =>
              e.jsx(
                "g",
                {
                  children: [0, 1].map((r) => {
                    const s = 228 + r * 46,
                      i = 22 + t * 56;
                    return e.jsx(
                      "path",
                      {
                        d: `M${s} ${i}H${s + 28}L${s + 40} ${i + 12}V${i + 46}H${s}Z`,
                        fill: c,
                        strokeLinejoin: "round",
                      },
                      r,
                    );
                  }),
                },
                t,
              ),
            ),
          ],
        },
        "1",
      ),
      e.jsxs(
        "g",
        {
          children: [
            e.jsx("rect", {
              x: "30",
              y: "16",
              width: "260",
              height: "142",
              rx: "10",
              fill: R,
              stroke: n,
              strokeWidth: "4",
            }),
            e.jsx("path", {
              d: "M160 158V184M120 184H200",
              stroke: k,
              strokeWidth: "6",
              strokeLinecap: "round",
            }),
            e.jsx(et, { x: 70, y: 56, w: 120, h: 80 }),
            e.jsx("path", { d: "M220 16V48", stroke: k, strokeWidth: "3" }),
            e.jsx(Je, { x: 220, y: 46, colour: m }),
            e.jsx("circle", {
              cx: "208",
              cy: "76",
              r: "34",
              fill: "none",
              stroke: V,
              strokeWidth: "5",
            }),
            e.jsx("path", {
              d: "M232 104L252 128",
              stroke: V,
              strokeWidth: "5",
              strokeLinecap: "round",
            }),
            e.jsx(K, {
              x: 266,
              y: 146,
              colour: V,
              size: 13,
              children: "SPOT IT",
            }),
          ],
        },
        "2",
      ),
    ],
  };
function Rt({ careerId: t, index: r }) {
  const s = Tt[t];
  return e.jsxs("svg", {
    viewBox: Ct,
    "aria-hidden": "true",
    "data-day-art": `${t}-${r}`,
    children: [
      e.jsx("rect", { width: "320", height: "200", fill: M }),
      s[Math.max(0, Math.min(s.length - 1, r))],
    ],
  });
}
const W = { fill: "currentColor", fillOpacity: 0.25 },
  Y = (t, r, s = 1.2) => [
    "circle",
    { cx: t, cy: r, r: s, fill: "currentColor", stroke: "none" },
  ],
  Zt = b("WhereChip", [
    ["rect", { x: 6.5, y: 6.5, width: 11, height: 11, rx: 2, ...W }],
    [
      "path",
      {
        d: "M9.5 3v3.5M14.5 3v3.5M9.5 17.5V21M14.5 17.5V21M3 9.5h3.5M3 14.5h3.5M17.5 9.5H21M17.5 14.5H21",
      },
    ],
    Y(12, 12, 1.5),
  ]),
  Dt = b("WherePhone", [
    ["rect", { x: 6.5, y: 2.5, width: 11, height: 19, rx: 2.5, ...W }],
    ["path", { d: "M10.5 5.5h3" }],
    Y(12, 18),
  ]),
  It = b("WhereGamepad", [
    [
      "path",
      {
        d: "M7 7.5h10a4.5 4.5 0 0 1 4.4 5.5l-.9 4a2.5 2.5 0 0 1-4.3 1.1L14.5 16h-5l-1.7 2.1a2.5 2.5 0 0 1-4.3-1.1l-.9-4A4.5 4.5 0 0 1 7 7.5Z",
        ...W,
      },
    ],
    ["path", { d: "M8 10.5v3M6.5 12h3" }],
    Y(15.5, 11),
    Y(17.5, 13),
  ]),
  Ot = b("WhereScreen", [
    ["rect", { x: 2.5, y: 4.5, width: 19, height: 13, rx: 2.5, ...W }],
    ["path", { d: "M8 21h8M12 17.5V21" }],
    ["path", { d: "m10.5 8.5 4 2.5-4 2.5Z", fill: "currentColor" }],
  ]),
  Pt = b("WhereChat", [
    [
      "path",
      {
        d: "M4.5 4.5h15a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H11l-4.5 3.5v-3.5h-2a2 2 0 0 1-2-2v-8a2 2 0 0 1 2-2Z",
        ...W,
      },
    ],
    Y(8, 10.5),
    Y(12, 10.5),
    Y(16, 10.5),
  ]),
  _t = b("WhereBank", [
    ["path", { d: "M3 9.5 12 4l9 5.5Z", ...W }],
    ["path", { d: "M5.5 12v5.5M10 12v5.5M14 12v5.5M18.5 12v5.5M3 20.5h18" }],
  ]),
  Bt = b("WhereHospital", [
    ["rect", { x: 4.5, y: 3.5, width: 15, height: 17, rx: 2.5, ...W }],
    ["path", { d: "M12 7.5v6M9 10.5h6M10 20.5v-3.5h4v3.5" }],
  ]),
  Ft = b("WherePlane", [
    [
      "path",
      {
        d: "M12 2.5c1 0 1.5 1 1.5 2.5v4.5l7.5 4.5v2l-7.5-2v4l2.5 2v1.5L12 20.5l-4 1v-1.5l2.5-2v-4l-7.5 2v-2l7.5-4.5V5c0-1.5.5-2.5 1.5-2.5Z",
        ...W,
      },
    ],
  ]),
  Gt = b("WhereShield", [
    [
      "path",
      {
        d: "M12 2.5 19.5 5.5v6c0 4.5-3 8-7.5 10-4.5-2-7.5-5.5-7.5-10v-6Z",
        ...W,
      },
    ],
    ["path", { d: "m8.5 12 2.5 2.5 4.5-5" }],
  ]),
  Kt = b("WhereBug", [
    ["rect", { x: 7, y: 7.5, width: 10, height: 13, rx: 5, ...W }],
    [
      "path",
      {
        d: "M9.5 7.5a2.5 2.5 0 0 1 5 0M7 12H3.5M20.5 12H17M7.5 17l-3 2M16.5 17l3 2M7.5 9 5 7M16.5 9 19 7M12 11v9",
      },
    ],
  ]),
  qt = b("WhereCar", [
    ["path", { d: "M2.5 15.5v-2.5l2.5-1 3-4h7l3.5 4 3 1v2.5Z", ...W }],
    [
      "circle",
      { cx: 7, cy: 16.5, r: 2.2, fill: "currentColor", fillOpacity: 1 },
    ],
    [
      "circle",
      { cx: 17, cy: 16.5, r: 2.2, fill: "currentColor", fillOpacity: 1 },
    ],
  ]),
  Ut = b("WhereRocket", [
    [
      "path",
      {
        d: "M12 2.5c3 2.5 4.5 6 4.5 10l-1.5 4h-6l-1.5-4c0-4 1.5-7.5 4.5-10Z",
        ...W,
      },
    ],
    [
      "path",
      {
        d: "m7.5 12.5-3 3.5 1 2.5 3.5-1.5M16.5 12.5l3 3.5-1 2.5-3.5-1.5M10.5 19.5 12 21.5l1.5-2",
      },
    ],
    Y(12, 9.5, 1.5),
  ]),
  Xt = b("WhereBadge", [
    [
      "path",
      {
        d: "M12 2.5 14.5 6l4 .5-.5 4 2 3.5-3.5 2-1 4-3.5-1.5L8.5 20l-1-4-3.5-2 2-3.5-.5-4 4-.5Z",
        ...W,
      },
    ],
    Y(12, 11.5, 2),
  ]),
  Yt = b("WhereGavel", [
    ["path", { d: "m13.5 2.5 6 6-3.5 3.5-6-6Z", ...W }],
    ["path", { d: "m11.75 10.25-7.5 7.5M13 21h8" }],
  ]),
  Qt = b("WhereSpark", [
    ["path", { d: "M12 3.5 14 10l6.5 2-6.5 2-2 6.5-2-6.5-6.5-2 6.5-2Z", ...W }],
    ["path", { d: "M19 3v3.5M17.25 4.75h3.5" }],
  ]),
  Jt = b("WhereOffice", [
    ["rect", { x: 4.5, y: 3.5, width: 15, height: 17, rx: 2, ...W }],
    [
      "path",
      { d: "M8.5 7.5h2M13.5 7.5h2M8.5 11.5h2M13.5 11.5h2M10.5 20.5v-4h3v4" },
    ],
  ]),
  er = b("WhereGovernment", [
    ["path", { d: "M12 3.5a5 5 0 0 1 5 5H7a5 5 0 0 1 5-5Z", ...W }],
    [
      "path",
      {
        d: "M12 1.5v2M4 8.5h16M6 11.5v6M10 11.5v6M14 11.5v6M18 11.5v6M3 20.5h18",
      },
    ],
  ]),
  tr = b("WhereChecklist", [
    ["rect", { x: 4.5, y: 3.5, width: 15, height: 17, rx: 2.5, ...W }],
    [
      "path",
      {
        d: "m7.5 9 1.5 1.5 2.5-2.5M13.5 9.5h3M7.5 15l1.5 1.5 2.5-2.5M13.5 15.5h3",
      },
    ],
  ]),
  rr = b("WhereRobot", [
    ["rect", { x: 4.5, y: 7.5, width: 15, height: 11, rx: 3, ...W }],
    ["path", { d: "M12 7.5V4.5M2.5 12v2.5M21.5 12v2.5M9.5 15.5h5" }],
    Y(12, 3.5),
    Y(9, 11.5, 1.4),
    Y(15, 11.5, 1.4),
  ]),
  sr = b("WhereHeadphones", [
    ["path", { d: "M4 15.5v-3a8 8 0 0 1 16 0v3" }],
    ["rect", { x: 3, y: 14, width: 5, height: 7, rx: 2, ...W }],
    ["rect", { x: 16, y: 14, width: 5, height: 7, rx: 2, ...W }],
  ]),
  ir = b("WherePulse", [
    ["rect", { x: 2.5, y: 4.5, width: 19, height: 15, rx: 2.5, ...W }],
    ["path", { d: "M5.5 12.5h3l1.5-3.5 2.5 6.5 1.5-3h4.5" }],
  ]),
  lr = b("WhereCart", [
    ["path", { d: "M2.5 4h2.5l2 11h11l2-8H6", ...W }],
    ["circle", { cx: 9, cy: 19, r: 1.5, fill: "currentColor", stroke: "none" }],
    [
      "circle",
      { cx: 17, cy: 19, r: 1.5, fill: "currentColor", stroke: "none" },
    ],
  ]),
  hr = b("WhereBulb", [
    [
      "path",
      {
        d: "M12 2.5a6.5 6.5 0 0 1 4 11.6V16.5H8v-2.4A6.5 6.5 0 0 1 12 2.5Z",
        ...W,
      },
    ],
    ["path", { d: "M9 19.5h6M10.5 21.5h3" }],
  ]),
  cr = b("WhereLaptop", [
    ["rect", { x: 4.5, y: 4.5, width: 15, height: 11, rx: 2, ...W }],
    ["path", { d: "M2 19.5h20l-2-4H4Z" }],
  ]),
  or = b("WhereBrush", [
    ["path", { d: "M20.5 3.5 11 13l-1.5-1.5 9.5-9.5Z", ...W }],
    [
      "path",
      {
        d: "M9 12.5c-2.5 0-4 1.5-4 4 0 1.5-1 2.5-2.5 3 3.5 1.5 8 .5 8-3.5Z",
        ...W,
      },
    ],
  ]),
  ar = b("WhereBall", [
    ["circle", { cx: 12, cy: 12, r: 9.5, ...W }],
    ["path", { d: "m12 8 3.3 2.4-1.3 3.9h-4l-1.3-3.9Z", fill: "currentColor" }],
    [
      "path",
      {
        d: "M12 8V2.5M15.3 10.4l5-1.6M14 14.3l3 4.2M10 14.3l-3 4.2M8.7 10.4l-5-1.6",
      },
    ],
  ]),
  xr = [
    [/chip|graphics card|arm in/i, Zt],
    [/bug bounty/i, Kt],
    [/cyber security|security operations/i, Gt],
    [/police|crime agency/i, Xt],
    [/law firm/i, Yt],
    [/bank/i, _t],
    [/medical/i, ir],
    [/nhs|hospital/i, Bt],
    [/airport/i, Ft],
    [/formula|car|aircraft/i, qt],
    [/space|drone/i, Ut],
    [/game|console maker/i, It],
    [/robot/i, rr],
    [/consumer electronics/i, sr],
    [/phone|mobile|app/i, Dt],
    [/streaming/i, Ot],
    [/social media/i, Pt],
    [/ai lab|big tech/i, Qt],
    [/government|council|bbc/i, er],
    [/testing/i, tr],
    [/supermarket/i, lr],
    [/start-up/i, hr],
    [/yourself/i, cr],
    [/design/i, or],
    [/football/i, ar],
  ],
  dr = Jt;
function nr(t) {
  return xr.find(([r]) => r.test(t))?.[1] ?? dr;
}
function jr({ career: t, readMore: r = !1 }) {
  const { salary: s } = t,
    { profile: i } = s,
    l = e.jsxs(e.Fragment, {
      children: [
        e.jsxs("section", {
          className: "career-section",
          children: [
            e.jsx("h2", { children: "Where" }),
            e.jsx("ul", {
              className: "career-tags",
              children: t.where.map((x) => {
                const j = nr(x);
                return e.jsxs(
                  "li",
                  {
                    children: [
                      e.jsx(j, { "aria-hidden": "true" }),
                      e.jsx("span", { children: x }),
                    ],
                  },
                  x,
                );
              }),
            }),
          ],
        }),
        e.jsxs("section", {
          className: "career-section",
          children: [
            e.jsx("h2", { children: "How to get there" }),
            e.jsx("ol", {
              className: "career-route",
              children: t.routes.map((x) => e.jsx("li", { children: x }, x)),
            }),
          ],
        }),
        e.jsxs("section", {
          className: "career-section",
          children: [
            e.jsx("h2", { children: "Sources" }),
            e.jsxs("ul", {
              className: "career-sources",
              children: [
                e.jsx("li", {
                  children: e.jsxs("a", {
                    href: i.url,
                    target: "_blank",
                    rel: "noreferrer",
                    children: [
                      "National Careers Service: ",
                      i.title,
                      e.jsx(je, { "aria-hidden": "true" }),
                    ],
                  }),
                }),
                e.jsx("li", {
                  children: e.jsxs("a", {
                    href: nt,
                    target: "_blank",
                    rel: "noreferrer",
                    children: [
                      "ONS: earnings by occupation",
                      e.jsx(je, { "aria-hidden": "true" }),
                    ],
                  }),
                }),
                e.jsx("li", {
                  children: e.jsxs("a", {
                    href: s.url,
                    target: "_blank",
                    rel: "noreferrer",
                    children: [
                      "IT Jobs Watch: ",
                      s.source,
                      e.jsx(je, { "aria-hidden": "true" }),
                    ],
                  }),
                }),
              ],
            }),
          ],
        }),
      ],
    }),
    o = jt(s),
    a = ft(o);
  return e.jsxs(e.Fragment, {
    children: [
      e.jsxs("section", {
        className: "career-section career-reveal",
        children: [
          e.jsx("h2", { children: "Your day" }),
          e.jsx("ul", {
            className: "career-day",
            children: t.day.map((x, j) =>
              e.jsxs(
                "li",
                {
                  className: "career-day-card",
                  children: [
                    e.jsx(Rt, { careerId: t.id, index: j }),
                    e.jsx("p", { children: x }),
                  ],
                },
                x,
              ),
            ),
          }),
        ],
      }),
      e.jsxs("section", {
        className: "career-pay career-reveal",
        "aria-label": "Salary",
        children: [
          e.jsxs("div", {
            className: "career-pay-range",
            children: [
              e.jsxs("p", {
                children: [
                  e.jsx(it, { to: i.starter }),
                  e.jsx("span", {
                    className: "career-pay-label",
                    children: "Starting out",
                  }),
                ],
              }),
              e.jsx("span", {
                className: "career-pay-to",
                "aria-hidden": "true",
                children: "to",
              }),
              e.jsxs("p", {
                children: [
                  e.jsx(it, { to: i.experienced }),
                  e.jsx("span", {
                    className: "career-pay-label",
                    children: "Experienced",
                  }),
                ],
              }),
            ],
          }),
          e.jsx(kr, { low: i.starter, high: i.experienced }),
          e.jsxs("a", {
            className: "career-source",
            href: i.url,
            target: "_blank",
            rel: "noreferrer",
            children: [
              "National Careers Service: ",
              i.title,
              e.jsx(je, { "aria-hidden": "true" }),
            ],
          }),
          e.jsxs("div", {
            className: "career-pay-adverts",
            children: [
              e.jsxs("dl", {
                className: "career-pay-stats",
                children: [
                  s.p10 !== null
                    ? e.jsx(Ee, { label: "Lower end", value: s.p10 })
                    : null,
                  e.jsx(Ee, { label: "Typical", value: s.median }),
                  s.p90 !== null
                    ? e.jsx(Ee, { label: "Top end", value: s.p90 })
                    : null,
                ],
              }),
              a
                ? e.jsxs("div", {
                    className: "career-pay-history",
                    children: [
                      e.jsx(fr, { points: o }),
                      e.jsx("p", { children: a }),
                    ],
                  })
                : null,
              e.jsxs("a", {
                className: "career-source",
                href: s.url,
                target: "_blank",
                rel: "noreferrer",
                children: [
                  "IT Jobs Watch job adverts, UK, ",
                  s.period,
                  a
                    ? ` and the same months in ${o
                        .slice(0, -1)
                        .map((x) => x.year)
                        .join(" and ")}`
                    : "",
                  e.jsx(je, { "aria-hidden": "true" }),
                ],
              }),
            ],
          }),
        ],
      }),
      e.jsxs("section", {
        className: "career-section career-topic",
        children: [
          e.jsx("h2", { className: "career-chip", children: pt(t.unit) }),
          e.jsx("p", { children: t.topicLink }),
        ],
      }),
      r
        ? e.jsxs("details", {
            className: "career-more",
            children: [
              e.jsxs("summary", {
                className: "careers-button",
                children: ["Read more", e.jsx(kt, { "aria-hidden": "true" })],
              }),
              e.jsx("div", { className: "career-more-body", children: l }),
            ],
          })
        : l,
    ],
  });
}
function Ee({ label: t, value: r }) {
  return e.jsxs("div", {
    children: [e.jsx("dt", { children: t }), e.jsx("dd", { children: Ze(r) })],
  });
}
function fr({ points: t }) {
  return e.jsx("ol", {
    className: "career-history",
    "aria-label": "Typical pay by year",
    children: t.map((r, s) =>
      e.jsxs(
        "li",
        {
          "data-latest": s === t.length - 1 ? "true" : void 0,
          children: [
            e.jsx("span", {
              className: "career-history-year",
              children: r.year,
            }),
            e.jsx("span", {
              className: "career-history-track",
              "aria-hidden": "true",
              children: e.jsx("span", {
                className: "career-history-bar",
                style: { width: me(r.median) },
              }),
            }),
            e.jsx("span", {
              className: "career-history-value",
              children: Ze(r.median),
            }),
          ],
        },
        r.year,
      ),
    ),
  });
}
const rt = 2e4,
  pr = 12e4,
  me = (t) => `${Math.min(100, Math.max(0, ((t - rt) / (pr - rt)) * 100))}%`;
function kr({ low: t, high: r }) {
  const s = yr();
  return e.jsxs("div", {
    className: "career-bar",
    "aria-hidden": "true",
    "data-shown": s ? "true" : void 0,
    children: [
      e.jsx("span", {
        className: "career-bar-band",
        style: { left: me(t), width: `calc(${me(r)} - ${me(t)})` },
      }),
      e.jsx("span", {
        className: "career-bar-tick",
        style: { left: "0%" },
        children: "£20k",
      }),
      e.jsx("span", {
        className: "career-bar-tick",
        style: { left: "100%" },
        children: "£120k",
      }),
    ],
  });
}
function yr() {
  const [t, r] = O.useState(!1);
  return (
    O.useEffect(() => {
      const s = window.requestAnimationFrame(() => r(!0));
      return () => window.cancelAnimationFrame(s);
    }, []),
    t
  );
}
function st() {
  return (
    typeof window.matchMedia == "function" &&
    window.matchMedia("(prefers-reduced-motion: reduce)").matches
  );
}
function it({ to: t }) {
  const [r, s] = O.useState(() => (st() ? t : 0));
  return (
    O.useEffect(() => {
      if (st()) {
        s(t);
        return;
      }
      const i = performance.now();
      let l = 0;
      const o = (a) => {
        const x = Math.min(1, (a - i) / 900);
        (s(t * (1 - (1 - x) ** 3)),
          x < 1 && (l = window.requestAnimationFrame(o)));
      };
      return (
        (l = window.requestAnimationFrame(o)),
        () => window.cancelAnimationFrame(l)
      );
    }, [t]),
    e.jsx("span", {
      className: "career-pay-number",
      children: Ze(Math.round(r / 250) * 250),
    })
  );
}
const f = "#020617",
  Ne = "#0f172a",
  S = "#1e293b",
  L = "#334155",
  H = "#475569",
  P = "#64748b",
  g = "#94a3b8",
  I = "#cbd5e1",
  D = "#f8fafc",
  xt = "#042f2e",
  $e = "#134e4a",
  F = "#0f766e",
  y = "#2dd4bf",
  We = "#99f6e4",
  ce = "#4c1d95",
  ur = "#6d28d9",
  X = "#8b5cf6",
  ee = "#c4b5fd",
  be = "#78350f",
  Q = "#b45309",
  N = "#fbbf24",
  de = "#fde68a",
  _ = "#881337",
  u = "#fb7185",
  ue = "#fecdd3";
function lt({ id: t }) {
  return e.jsxs("svg", {
    viewBox: "0 0 200 140",
    "aria-hidden": "true",
    "data-activity-art": t,
    children: [e.jsx("rect", { width: "200", height: "140", fill: Ne }), Mr[t]],
  });
}
function U({
  x: t,
  y: r,
  w: s,
  h: i,
  r: l,
  face: o,
  edge: a,
  rim: x,
  depth: j = 5,
  shadow: p = !0,
}) {
  return e.jsxs("g", {
    children: [
      p
        ? e.jsx("ellipse", {
            cx: t + s / 2,
            cy: r + i + j + 3,
            rx: s * 0.46,
            ry: "4",
            fill: f,
            opacity: "0.7",
          })
        : null,
      e.jsx("rect", { x: t, y: r + j, width: s, height: i, rx: l, fill: a }),
      e.jsx("rect", { x: t, y: r, width: s, height: i, rx: l, fill: o }),
      e.jsx("path", {
        d: `M${t + l} ${r + 1.5}H${t + s - l}`,
        stroke: x,
        strokeWidth: "1.5",
        strokeLinecap: "round",
      }),
    ],
  });
}
function gr({ x: t, y: r, r: s, angle: i = 45, children: l }) {
  const o = s * 1.5;
  return e.jsxs("g", {
    children: [
      e.jsxs("g", {
        transform: `rotate(${i - 90} ${t} ${r})`,
        children: [
          e.jsx("rect", {
            x: t - s * 0.22,
            y: r + s + 1,
            width: s * 0.44,
            height: s * 0.34,
            rx: "1.5",
            fill: g,
          }),
          e.jsx("rect", {
            x: t - s * 0.22,
            y: r + s + 1,
            width: s * 0.14,
            height: s * 0.34,
            fill: I,
          }),
          e.jsx("rect", {
            x: t - s * 0.3,
            y: r + s * 1.32,
            width: s * 0.6,
            height: o,
            rx: s * 0.3,
            fill: be,
          }),
          e.jsx("rect", {
            x: t - s * 0.3,
            y: r + s * 1.32,
            width: s * 0.26,
            height: o,
            rx: s * 0.13,
            fill: Q,
          }),
          [0.35, 0.6, 0.85].map((a) =>
            e.jsx(
              "path",
              {
                d: `M${t - s * 0.3} ${r + s * 1.32 + o * a}h${s * 0.6}`,
                stroke: be,
                strokeWidth: "1.2",
              },
              a,
            ),
          ),
        ],
      }),
      e.jsx("circle", { cx: t, cy: r, r: s, fill: xt, opacity: "0.85" }),
      l,
      e.jsx("path", {
        d: `M${t - s * 0.62} ${r - s * 0.2}a${s * 0.66} ${s * 0.66} 0 0 1 ${s * 0.46} ${-s * 0.44}`,
        fill: "none",
        stroke: D,
        strokeWidth: "2",
        strokeLinecap: "round",
        opacity: "0.55",
      }),
      e.jsx("circle", {
        cx: t,
        cy: r,
        r: s,
        fill: "none",
        stroke: H,
        strokeWidth: s * 0.32,
      }),
      e.jsx("circle", {
        cx: t,
        cy: r,
        r: s,
        fill: "none",
        stroke: I,
        strokeWidth: s * 0.18,
      }),
      e.jsx("path", {
        d: `M${t - s * 0.95} ${r - s * 0.3}a${s} ${s} 0 0 1 ${s * 0.65} ${-s * 0.65}`,
        fill: "none",
        stroke: D,
        strokeWidth: "1.4",
        strokeLinecap: "round",
      }),
    ],
  });
}
const Mr = {
  console: e.jsxs("g", {
    children: [
      e.jsx("path", {
        d: "M40 60L26 40M160 60L174 40",
        stroke: P,
        strokeWidth: "2.5",
        strokeDasharray: "4 5",
        strokeLinecap: "round",
      }),
      e.jsx(U, {
        x: 40,
        y: 44,
        w: 120,
        h: 58,
        r: 11,
        face: L,
        edge: f,
        rim: P,
        depth: 8,
      }),
      e.jsx("rect", {
        x: "48",
        y: "52",
        width: "104",
        height: "44",
        rx: "6",
        fill: S,
      }),
      e.jsx("rect", {
        x: "76",
        y: "58",
        width: "48",
        height: "32",
        rx: "3",
        fill: xt,
      }),
      e.jsx("rect", {
        x: "76",
        y: "58",
        width: "48",
        height: "32",
        rx: "3",
        fill: "none",
        stroke: F,
        strokeWidth: "1.5",
      }),
      e.jsx("rect", {
        x: "92",
        y: "65",
        width: "16",
        height: "16",
        rx: "2",
        fill: f,
        stroke: y,
        strokeWidth: "1.2",
      }),
      e.jsx("path", {
        d: "M80 64h10M80 70h10M80 84h14M110 66h10M110 74h10v8M100 81v6",
        stroke: y,
        strokeWidth: "1.3",
        opacity: "0.8",
      }),
      e.jsx("circle", { cx: "58", cy: "88", r: "5", fill: Q }),
      e.jsx("circle", { cx: "58", cy: "87", r: "5", fill: N }),
      e.jsx("circle", { cx: "56.5", cy: "85.5", r: "1.4", fill: de }),
      [
        [52, 58],
        [148, 58],
        [148, 90],
      ].map(([t, r]) =>
        e.jsx("circle", { cx: t, cy: r, r: "2", fill: P }, `${t}-${r}`),
      ),
      e.jsxs("g", {
        transform: "rotate(-8 100 35)",
        children: [
          e.jsx("rect", {
            x: "62",
            y: "28",
            width: "76",
            height: "20",
            rx: "7",
            fill: f,
          }),
          e.jsx("rect", {
            x: "62",
            y: "22",
            width: "76",
            height: "20",
            rx: "7",
            fill: H,
          }),
          e.jsx("path", {
            d: "M70 23.5h60",
            stroke: g,
            strokeWidth: "1.5",
            strokeLinecap: "round",
          }),
          e.jsx("path", {
            d: "M108 30h20M108 35h20",
            stroke: L,
            strokeWidth: "2",
            strokeLinecap: "round",
          }),
        ],
      }),
      e.jsxs("g", {
        transform: "rotate(-38 158 118)",
        children: [
          e.jsx("ellipse", {
            cx: "160",
            cy: "126",
            rx: "24",
            ry: "3",
            fill: f,
            opacity: "0.6",
          }),
          e.jsx("rect", {
            x: "140",
            y: "113",
            width: "20",
            height: "10",
            rx: "4",
            fill: _,
          }),
          e.jsx("rect", {
            x: "140",
            y: "112",
            width: "20",
            height: "9",
            rx: "4",
            fill: u,
          }),
          e.jsx("path", {
            d: "M143 114h14",
            stroke: ue,
            strokeWidth: "1.2",
            strokeLinecap: "round",
          }),
          e.jsx("rect", {
            x: "160",
            y: "115",
            width: "18",
            height: "3.5",
            rx: "1",
            fill: g,
          }),
          e.jsx("rect", {
            x: "160",
            y: "115",
            width: "18",
            height: "1.4",
            fill: D,
            opacity: "0.7",
          }),
        ],
      }),
    ],
  }),
  glitch: e.jsxs("g", {
    children: [
      e.jsx(U, {
        x: 24,
        y: 20,
        w: 152,
        h: 92,
        r: 9,
        face: L,
        edge: f,
        rim: P,
        depth: 7,
      }),
      e.jsx("rect", {
        x: "31",
        y: "27",
        width: "138",
        height: "78",
        rx: "3",
        fill: ce,
      }),
      e.jsx("rect", {
        x: "31",
        y: "27",
        width: "138",
        height: "40",
        rx: "3",
        fill: S,
        opacity: "0.5",
      }),
      e.jsx("rect", { x: "31", y: "90", width: "138", height: "15", fill: F }),
      e.jsx("rect", { x: "31", y: "90", width: "138", height: "2.5", fill: y }),
      e.jsx("rect", {
        x: "60",
        y: "68",
        width: "18",
        height: "22",
        rx: "3",
        fill: F,
      }),
      e.jsx("rect", {
        x: "60",
        y: "66",
        width: "18",
        height: "22",
        rx: "3",
        fill: y,
      }),
      e.jsx("rect", { x: "66", y: "71", width: "3", height: "3", fill: f }),
      e.jsx("rect", { x: "106", y: "50", width: "40", height: "9", fill: P }),
      e.jsx("rect", {
        x: "112",
        y: "59",
        width: "40",
        height: "9",
        fill: u,
        opacity: "0.85",
      }),
      e.jsx("rect", {
        x: "100",
        y: "68",
        width: "40",
        height: "7",
        fill: X,
        opacity: "0.85",
      }),
      e.jsx("rect", {
        x: "31",
        y: "58",
        width: "138",
        height: "2",
        fill: We,
        opacity: "0.5",
      }),
      [
        [44, 40],
        [90, 46],
        [130, 82],
        [150, 44],
      ].map(([t, r]) =>
        e.jsx(
          "rect",
          { x: t, y: r, width: "3", height: "2", fill: D, opacity: "0.8" },
          `${t}-${r}`,
        ),
      ),
      e.jsx("circle", { cx: "160", cy: "37", r: "14", fill: _ }),
      e.jsx("circle", { cx: "160", cy: "34", r: "14", fill: u }),
      e.jsx("path", {
        d: "M150 28a12 12 0 0 1 8 -6",
        stroke: ue,
        strokeWidth: "1.5",
        fill: "none",
        strokeLinecap: "round",
      }),
      e.jsx("path", {
        d: "M155 29l10 10M165 29l-10 10",
        stroke: D,
        strokeWidth: "3",
        strokeLinecap: "round",
      }),
    ],
  }),
  icon: e.jsxs("g", {
    children: [
      e.jsx(U, {
        x: 62,
        y: 20,
        w: 76,
        h: 76,
        r: 20,
        face: X,
        edge: ce,
        rim: ee,
        depth: 7,
      }),
      e.jsx("path", {
        d: "M70 52V40a18 18 0 0 1 18 -18h24",
        fill: "none",
        stroke: ee,
        strokeWidth: "2",
        strokeLinecap: "round",
        opacity: "0.4",
      }),
      e.jsx("path", {
        d: "M82 74l18-30 18 30z",
        fill: ur,
        transform: "translate(0 3)",
      }),
      e.jsx("path", { d: "M82 74l18-30 18 30z", fill: D }),
      e.jsx("circle", { cx: "100", cy: "66", r: "7", fill: F }),
      e.jsx("circle", { cx: "100", cy: "65", r: "7", fill: y }),
      [y, N, u].map((t, r) =>
        e.jsxs(
          "g",
          {
            children: [
              e.jsx("rect", {
                x: 28 + r * 22,
                y: "111",
                width: "16",
                height: "16",
                rx: "4",
                fill: [F, Q, _][r],
              }),
              e.jsx("rect", {
                x: 28 + r * 22,
                y: "108",
                width: "16",
                height: "16",
                rx: "4",
                fill: t,
              }),
              e.jsx("path", {
                d: `M${31 + r * 22} 109.5h10`,
                stroke: D,
                strokeWidth: "1.2",
                strokeLinecap: "round",
                opacity: "0.5",
              }),
            ],
          },
          t,
        ),
      ),
      e.jsxs("g", {
        transform: "rotate(-33 160 34)",
        children: [
          e.jsx("ellipse", {
            cx: "166",
            cy: "44",
            rx: "22",
            ry: "2.5",
            fill: f,
            opacity: "0.6",
          }),
          e.jsx("rect", {
            x: "150",
            y: "29",
            width: "34",
            height: "10",
            fill: Q,
          }),
          e.jsx("rect", {
            x: "150",
            y: "29",
            width: "34",
            height: "5",
            fill: N,
          }),
          e.jsx("rect", {
            x: "184",
            y: "29",
            width: "5",
            height: "10",
            fill: g,
          }),
          e.jsx("rect", {
            x: "189",
            y: "29",
            width: "6",
            height: "10",
            rx: "2",
            fill: u,
          }),
          e.jsx("path", { d: "M150 29L138 34L150 39Z", fill: de }),
          e.jsx("path", { d: "M142 32.3L138 34L142 35.7Z", fill: L }),
        ],
      }),
    ],
  }),
  code: e.jsxs("g", {
    transform: "translate(0 6)",
    children: [
      e.jsx("path", {
        d: "M78 34v-12a22 22 0 0 1 44 0v12",
        stroke: f,
        strokeWidth: "11",
        fill: "none",
        transform: "translate(0 3)",
      }),
      e.jsx("path", {
        d: "M78 34v-12a22 22 0 0 1 44 0v12",
        stroke: H,
        strokeWidth: "11",
        fill: "none",
      }),
      e.jsx("path", {
        d: "M78 34v-12a22 22 0 0 1 44 0v12",
        stroke: I,
        strokeWidth: "6",
        fill: "none",
      }),
      e.jsx("path", {
        d: "M80.5 20a19.5 19.5 0 0 1 12 -16",
        stroke: D,
        strokeWidth: "1.8",
        fill: "none",
        strokeLinecap: "round",
      }),
      e.jsx(U, {
        x: 54,
        y: 30,
        w: 92,
        h: 84,
        r: 12,
        face: L,
        edge: f,
        rim: P,
        depth: 8,
      }),
      e.jsx("rect", {
        x: "62",
        y: "52",
        width: "76",
        height: "36",
        rx: "5",
        fill: f,
      }),
      [0, 1, 2].map((t) =>
        e.jsxs(
          "g",
          {
            children: [
              e.jsx("rect", {
                x: 66 + t * 24,
                y: "55",
                width: "20",
                height: "30",
                rx: "3",
                fill: S,
              }),
              e.jsx("rect", {
                x: 66 + t * 24,
                y: "55",
                width: "20",
                height: "6",
                rx: "2",
                fill: f,
                opacity: "0.5",
              }),
              e.jsx("rect", {
                x: 66 + t * 24,
                y: "79",
                width: "20",
                height: "6",
                rx: "2",
                fill: f,
                opacity: "0.5",
              }),
              e.jsx("rect", {
                x: 66 + t * 24,
                y: "55",
                width: "20",
                height: "30",
                rx: "3",
                fill: "none",
                stroke: t === 2 ? N : y,
                strokeWidth: "2",
              }),
              e.jsx("text", {
                x: 76 + t * 24,
                y: "76",
                fill: t === 2 ? N : y,
                fontFamily: "monospace",
                fontSize: "16",
                fontWeight: "700",
                textAnchor: "middle",
                children: ["4", "7", "?"][t],
              }),
            ],
          },
          t,
        ),
      ),
      e.jsx("circle", { cx: "100", cy: "100", r: "6", fill: f }),
      e.jsx("rect", {
        x: "98.5",
        y: "100",
        width: "3",
        height: "7",
        rx: "1",
        fill: f,
      }),
      e.jsx("circle", { cx: "100", cy: "99", r: "2.5", fill: y }),
    ],
  }),
  stats: e.jsxs("g", {
    children: [
      e.jsx(U, {
        x: 22,
        y: 18,
        w: 156,
        h: 100,
        r: 10,
        face: L,
        edge: f,
        rim: P,
        depth: 7,
      }),
      e.jsx("rect", {
        x: "29",
        y: "25",
        width: "142",
        height: "86",
        rx: "5",
        fill: S,
      }),
      e.jsx("path", { d: "M36 104h128", stroke: L, strokeWidth: "1.5" }),
      [30, 52, 40, 70, 58].map((t, r) => {
        const s = 40 + r * 26,
          i = 104 - t,
          l = r === 3;
        return e.jsxs(
          "g",
          {
            children: [
              e.jsx("rect", {
                x: s,
                y: i,
                width: "16",
                height: t,
                rx: "2",
                fill: l ? Q : F,
              }),
              e.jsx("rect", {
                x: s,
                y: i,
                width: "11",
                height: t,
                rx: "2",
                fill: l ? N : y,
              }),
              e.jsx("rect", {
                x: s,
                y: i,
                width: "16",
                height: "3",
                rx: "1.5",
                fill: l ? de : We,
              }),
            ],
          },
          r,
        );
      }),
      e.jsx("path", {
        d: "M36 70L66 52L92 62L118 36L146 44",
        stroke: ce,
        strokeWidth: "4",
        fill: "none",
        strokeLinejoin: "round",
        strokeLinecap: "round",
        transform: "translate(0 2)",
      }),
      e.jsx("path", {
        d: "M36 70L66 52L92 62L118 36L146 44",
        stroke: X,
        strokeWidth: "3",
        fill: "none",
        strokeLinejoin: "round",
        strokeLinecap: "round",
      }),
      [
        [66, 52],
        [92, 62],
        [118, 36],
        [146, 44],
      ].map(([t, r]) =>
        e.jsx(
          "circle",
          { cx: t, cy: r, r: "3", fill: ee, stroke: ce, strokeWidth: "1.2" },
          `${t}-${r}`,
        ),
      ),
      e.jsx("circle", { cx: "160", cy: "37", r: "11", fill: g }),
      e.jsx("circle", { cx: "160", cy: "34", r: "11", fill: D }),
      e.jsx("path", {
        d: "M154 34h12M160 28v12",
        stroke: Ne,
        strokeWidth: "2.2",
        strokeLinecap: "round",
      }),
    ],
  }),
  scam: e.jsxs("g", {
    children: [
      e.jsx("path", {
        d: "M58 36l-16 -5M58 48h-18",
        stroke: u,
        strokeWidth: "3",
        strokeLinecap: "round",
      }),
      e.jsx(U, {
        x: 66,
        y: 10,
        w: 68,
        h: 116,
        r: 13,
        face: L,
        edge: f,
        rim: P,
        depth: 6,
      }),
      e.jsx("rect", {
        x: "71",
        y: "15",
        width: "58",
        height: "106",
        rx: "9",
        fill: f,
      }),
      e.jsx("rect", {
        x: "74",
        y: "18",
        width: "52",
        height: "100",
        rx: "7",
        fill: S,
      }),
      e.jsx("rect", {
        x: "92",
        y: "21",
        width: "16",
        height: "4",
        rx: "2",
        fill: f,
      }),
      e.jsx("rect", {
        x: "134",
        y: "34",
        width: "2.5",
        height: "14",
        rx: "1",
        fill: H,
      }),
      e.jsx("rect", {
        x: "77",
        y: "34",
        width: "46",
        height: "26",
        rx: "7",
        fill: _,
        transform: "translate(0 2)",
      }),
      e.jsx("rect", {
        x: "77",
        y: "34",
        width: "46",
        height: "26",
        rx: "7",
        fill: u,
      }),
      e.jsx("path", { d: "M80 56l-3 6 8-3", fill: u }),
      e.jsx("path", {
        d: "M83 42h32M83 50h20",
        stroke: D,
        strokeWidth: "3",
        strokeLinecap: "round",
      }),
      e.jsx("rect", {
        x: "80",
        y: "68",
        width: "38",
        height: "7",
        rx: "3.5",
        fill: L,
      }),
      e.jsx("rect", {
        x: "80",
        y: "80",
        width: "26",
        height: "7",
        rx: "3.5",
        fill: L,
      }),
      e.jsx("path", {
        d: "M126 90l22 8v12c0 12-10 19-22 23-12-4-22-11-22-23v-12z",
        fill: f,
        transform: "translate(0 3)",
      }),
      e.jsx("path", {
        d: "M126 90l22 8v12c0 12-10 19-22 23-12-4-22-11-22-23v-12z",
        fill: F,
      }),
      e.jsx("path", { d: "M126 90l22 8v12c0 12-10 19-22 23z", fill: $e }),
      e.jsx("path", {
        d: "M126 90l22 8v12c0 12-10 19-22 23-12-4-22-11-22-23v-12z",
        fill: "none",
        stroke: y,
        strokeWidth: "2.5",
        strokeLinejoin: "round",
      }),
      e.jsx("path", {
        d: "M116 111l7 7 13-14",
        stroke: D,
        strokeWidth: "3.4",
        fill: "none",
        strokeLinecap: "round",
        strokeLinejoin: "round",
      }),
    ],
  }),
  clues: e.jsxs("g", {
    children: [
      e.jsx(U, {
        x: 20,
        y: 14,
        w: 160,
        h: 106,
        r: 6,
        face: L,
        edge: f,
        rim: P,
        depth: 6,
      }),
      e.jsx("rect", {
        x: "26",
        y: "20",
        width: "148",
        height: "94",
        rx: "3",
        fill: S,
      }),
      e.jsxs("g", {
        children: [
          e.jsx("rect", {
            x: "34",
            y: "31",
            width: "36",
            height: "28",
            fill: f,
            opacity: "0.6",
          }),
          e.jsx("rect", {
            x: "32",
            y: "28",
            width: "36",
            height: "28",
            fill: I,
          }),
          e.jsx("rect", {
            x: "35",
            y: "31",
            width: "30",
            height: "18",
            fill: P,
          }),
          e.jsx("path", { d: "M35 49l9 -9 7 6 6 -5 8 8Z", fill: L }),
        ],
      }),
      e.jsxs("g", {
        children: [
          e.jsx("rect", {
            x: "130",
            y: "37",
            width: "38",
            height: "30",
            fill: f,
            opacity: "0.6",
          }),
          e.jsx("rect", {
            x: "128",
            y: "34",
            width: "38",
            height: "30",
            fill: N,
          }),
          e.jsx("path", {
            d: "M133 44h28M133 50h20M133 56h24",
            stroke: Q,
            strokeWidth: "1.6",
            strokeLinecap: "round",
          }),
        ],
      }),
      e.jsxs("g", {
        children: [
          e.jsx("rect", {
            x: "42",
            y: "85",
            width: "34",
            height: "30",
            fill: f,
            opacity: "0.6",
          }),
          e.jsx("rect", {
            x: "40",
            y: "82",
            width: "34",
            height: "30",
            fill: I,
          }),
          e.jsx("path", {
            d: "M44 88h26M44 94h26M44 100h18M44 106h22",
            stroke: g,
            strokeWidth: "1.6",
            strokeLinecap: "round",
          }),
        ],
      }),
      e.jsx("path", {
        d: "M50 42L146 48L58 96L140 104",
        stroke: _,
        strokeWidth: "2.5",
        fill: "none",
        transform: "translate(0 1.5)",
      }),
      e.jsx("path", {
        d: "M50 42L146 48L58 96L140 104",
        stroke: u,
        strokeWidth: "2",
        fill: "none",
      }),
      [
        [50, 42],
        [146, 48],
        [58, 96],
      ].map(([t, r]) =>
        e.jsxs(
          "g",
          {
            children: [
              e.jsx("circle", { cx: t, cy: r + 1, r: "3.4", fill: _ }),
              e.jsx("circle", { cx: t, cy: r, r: "3.4", fill: u }),
              e.jsx("circle", { cx: t - 1, cy: r - 1, r: "1", fill: ue }),
            ],
          },
          `${t}-${r}`,
        ),
      ),
      e.jsx(gr, {
        x: 120,
        y: 92,
        r: 17,
        children: e.jsx("circle", { cx: "120", cy: "92", r: "4", fill: u }),
      }),
    ],
  }),
  mod: e.jsxs("g", {
    children: [
      e.jsx(U, {
        x: 18,
        y: 20,
        w: 164,
        h: 98,
        r: 9,
        face: L,
        edge: f,
        rim: P,
        depth: 7,
      }),
      e.jsx("rect", {
        x: "18",
        y: "20",
        width: "164",
        height: "15",
        rx: "9",
        fill: H,
      }),
      e.jsx("rect", { x: "18", y: "28", width: "164", height: "7", fill: H }),
      e.jsx("path", {
        d: "M27 21.5h146",
        stroke: g,
        strokeWidth: "1.5",
        strokeLinecap: "round",
      }),
      [u, N, y].map((t, r) =>
        e.jsx("circle", { cx: 29 + r * 8, cy: "27.5", r: "2.4", fill: t }, t),
      ),
      e.jsx("rect", {
        x: "24",
        y: "40",
        width: "80",
        height: "72",
        rx: "4",
        fill: S,
      }),
      e.jsx("path", {
        d: "M32 52h40M44 64h50M44 76h30M32 88h24",
        stroke: y,
        strokeWidth: "4",
        strokeLinecap: "round",
      }),
      e.jsx("path", {
        d: "M74 52h14M76 76h10",
        stroke: ee,
        strokeWidth: "4",
        strokeLinecap: "round",
      }),
      e.jsx("rect", {
        x: "110",
        y: "44",
        width: "62",
        height: "64",
        rx: "5",
        fill: f,
      }),
      e.jsx("path", {
        d: "M110 56h62M110 68h62M110 80h62M110 92h62M122 44v64M134 44v64M146 44v64M158 44v64",
        stroke: S,
        strokeWidth: "0.8",
      }),
      [
        [120, 82, X, ce, ee],
        [134, 82, y, F, We],
        [134, 68, N, Q, de],
        [148, 82, X, ce, ee],
      ].map(([t, r, s, i, l]) =>
        e.jsxs(
          "g",
          {
            children: [
              e.jsx("rect", { x: t, y: r, width: "14", height: "14", fill: i }),
              e.jsx("rect", { x: t, y: r, width: "11", height: "11", fill: s }),
              e.jsx("rect", {
                x: t,
                y: r,
                width: "14",
                height: "2.5",
                fill: l,
              }),
            ],
          },
          `${t}-${r}`,
        ),
      ),
      e.jsx("rect", {
        x: "148",
        y: "68",
        width: "14",
        height: "14",
        fill: "none",
        stroke: D,
        strokeWidth: "1.2",
        strokeDasharray: "2.5 2",
      }),
      e.jsx("rect", {
        x: "110",
        y: "96",
        width: "62",
        height: "12",
        rx: "5",
        fill: be,
      }),
      e.jsx("rect", { x: "110", y: "96", width: "62", height: "3", fill: F }),
    ],
  }),
};
function Me(t) {
  return Math.min(1, Math.max(0, t));
}
const wr = [8, 10, 9, 11, 10, 12, 11, 13],
  Lr = [6, 14, 5, 22, 9, 27, 12, 32];
function ze(t, r, s, i) {
  const l = (i * Math.PI) / 180;
  return `${(t + s * Math.sin(l)).toFixed(2)} ${(r - s * Math.cos(l)).toFixed(2)}`;
}
function mr({ pace: t }) {
  const r = -100 + t * 200;
  return e.jsxs("g", {
    children: [
      e.jsx(U, {
        x: 236,
        y: 12,
        w: 94,
        h: 50,
        r: 4,
        face: S,
        edge: f,
        rim: L,
        depth: 4,
        shadow: !1,
      }),
      [0, 1, 2, 3, 4, 5, 6, 7].map((s) =>
        [0, 1, 2].map((i) =>
          e.jsx(
            "circle",
            { cx: 244 + s * 11, cy: 22 + i * 15, r: "1.2", fill: f },
            `${s}-${i}`,
          ),
        ),
      ),
      e.jsx("circle", { cx: "262", cy: "39", r: "17", fill: H }),
      e.jsx("circle", { cx: "262", cy: "39", r: "14.5", fill: I }),
      [
        [-110, -40, F],
        [-40, 40, Q],
        [40, 110, _],
      ].map(([s, i, l]) =>
        e.jsx(
          "path",
          {
            d: `M${ze(262, 39, 11, s)}A11 11 0 0 1 ${ze(262, 39, 11, i)}`,
            stroke: l,
            strokeWidth: "3",
            fill: "none",
          },
          s,
        ),
      ),
      e.jsx("path", {
        d: `M262 39L${ze(262, 39, 11, r)}`,
        stroke: f,
        strokeWidth: "2",
        strokeLinecap: "round",
      }),
      e.jsx("circle", { cx: "262", cy: "39", r: "2.4", fill: f }),
      e.jsxs("g", {
        transform: "rotate(14 298 22)",
        children: [
          e.jsx("rect", {
            x: "295",
            y: "22",
            width: "6",
            height: "30",
            rx: "3",
            fill: g,
          }),
          e.jsx("path", {
            d: "M298 22m-7 0a7 7 0 1 0 14 0h-4v-5h-6v5z",
            fill: g,
          }),
        ],
      }),
      e.jsx("path", {
        d: "M314 22v28M322 22v28",
        stroke: u,
        strokeWidth: "5",
        strokeLinecap: "round",
      }),
      e.jsx("path", {
        d: "M314 22l4 -6 4 6",
        stroke: H,
        strokeWidth: "4",
        fill: "none",
        strokeLinejoin: "round",
      }),
    ],
  });
}
function Wr({ x: t, scale: r }) {
  return e.jsxs("g", {
    transform: `translate(${t} 146) scale(${r})`,
    children: [
      e.jsx("ellipse", {
        cx: "0",
        cy: "1",
        rx: "30",
        ry: "3",
        fill: f,
        opacity: "0.6",
      }),
      e.jsx("path", { d: "M6 -44v-8", stroke: g, strokeWidth: "2" }),
      e.jsx("circle", { cx: "6", cy: "-53", r: "2.5", fill: N }),
      e.jsx("rect", {
        x: "-11",
        y: "-44",
        width: "22",
        height: "13",
        rx: "3",
        fill: H,
      }),
      e.jsx("path", {
        d: "M-9 -42.5h18",
        stroke: g,
        strokeWidth: "1.2",
        strokeLinecap: "round",
      }),
      [-5, 5].map((s) =>
        e.jsxs(
          "g",
          {
            children: [
              e.jsx("circle", { cx: s, cy: "-37.5", r: "3.8", fill: f }),
              e.jsx("circle", { cx: s, cy: "-37.5", r: "2", fill: y }),
            ],
          },
          s,
        ),
      ),
      e.jsx(U, {
        x: -26,
        y: -31,
        w: 52,
        h: 20,
        r: 4,
        face: X,
        edge: ce,
        rim: ee,
        depth: 4,
        shadow: !1,
      }),
      e.jsx("rect", {
        x: "6",
        y: "-27",
        width: "15",
        height: "12",
        rx: "2",
        fill: ce,
      }),
      e.jsx("path", {
        d: "M8 -24h6v5M12 -22h7M10 -18h9",
        stroke: y,
        strokeWidth: "1.2",
      }),
      e.jsx("path", { d: "M17 -24v3", stroke: N, strokeWidth: "1.2" }),
      [-15, 15].map((s) =>
        e.jsxs(
          "g",
          {
            children: [
              e.jsx("circle", { cx: s, cy: "-6", r: "7", fill: f }),
              e.jsx("circle", { cx: s, cy: "-6", r: "3", fill: H }),
            ],
          },
          s,
        ),
      ),
      e.jsx("ellipse", { cx: "-36", cy: "-1.5", rx: "7.5", ry: "3", fill: f }),
      e.jsx("ellipse", { cx: "-36", cy: "-2.5", rx: "3", ry: "1.2", fill: H }),
    ],
  });
}
function $r({ x: t, scale: r }) {
  return e.jsxs("g", {
    transform: `translate(${t} 146) scale(${r})`,
    children: [
      e.jsx("ellipse", {
        cx: "0",
        cy: "1",
        rx: "32",
        ry: "3",
        fill: f,
        opacity: "0.6",
      }),
      e.jsxs("g", {
        transform: "rotate(-24 22 -24)",
        children: [
          e.jsx("rect", {
            x: "-26",
            y: "-40",
            width: "50",
            height: "14",
            rx: "3",
            fill: f,
            transform: "translate(0 2)",
          }),
          e.jsx("rect", {
            x: "-26",
            y: "-40",
            width: "50",
            height: "14",
            rx: "3",
            fill: H,
          }),
          e.jsx("path", {
            d: "M-22 -38.5h42",
            stroke: g,
            strokeWidth: "1.2",
            strokeLinecap: "round",
          }),
        ],
      }),
      e.jsx(U, {
        x: -28,
        y: -24,
        w: 56,
        h: 20,
        r: 3,
        face: L,
        edge: f,
        rim: P,
        depth: 4,
        shadow: !1,
      }),
      e.jsx("rect", {
        x: "-24",
        y: "-22",
        width: "48",
        height: "10",
        rx: "1.5",
        fill: $e,
      }),
      e.jsx("rect", {
        x: "-6",
        y: "-21",
        width: "10",
        height: "8",
        rx: "1",
        fill: f,
      }),
      e.jsx("path", {
        d: "M-21 -19h12M-21 -15h10M7 -18h14M7 -14h9",
        stroke: y,
        strokeWidth: "1.1",
        opacity: "0.8",
      }),
      e.jsx("path", {
        d: "M2 -26l3 -6M8 -24l6 -4M-2 -27l-1 -6",
        stroke: u,
        strokeWidth: "1.8",
        strokeLinecap: "round",
      }),
      e.jsx("path", {
        d: "M-20 -8h40",
        stroke: f,
        strokeWidth: "1.5",
        strokeDasharray: "3 3",
      }),
      e.jsxs("g", {
        transform: "translate(-36 -2)",
        children: [
          e.jsx("path", {
            d: "M-4 -9v-5a4 4 0 0 1 8 0",
            stroke: g,
            strokeWidth: "2.5",
            fill: "none",
            transform: "rotate(-35 -4 -9)",
          }),
          e.jsx("rect", {
            x: "-7",
            y: "-9",
            width: "14",
            height: "11",
            rx: "2.5",
            fill: _,
            transform: "translate(0 1.5)",
          }),
          e.jsx("rect", {
            x: "-7",
            y: "-9",
            width: "14",
            height: "11",
            rx: "2.5",
            fill: u,
          }),
        ],
      }),
      [
        [32, -1],
        [38, 0],
        [27, 1],
      ].map(([s, i]) =>
        e.jsx("circle", { cx: s, cy: i, r: "1.6", fill: g }, `${s}-${i}`),
      ),
    ],
  });
}
function br({ alerts: t }) {
  return e.jsxs("g", {
    transform: "translate(198 150)",
    children: [
      e.jsx("path", {
        d: "M0 0l16 -1.5 3 7 -16 1.5z",
        fill: f,
        transform: "translate(0 1.5)",
      }),
      e.jsx("path", { d: "M0 0l16 -1.5 3 7 -16 1.5z", fill: L }),
      e.jsx("path", {
        d: "M2 0.8l12.6 -1.2 2 4.6 -12.6 1.2z",
        fill: t ? _ : S,
      }),
      t
        ? e.jsxs("g", {
            children: [
              e.jsx("circle", { cx: "17", cy: "-4", r: "4", fill: u }),
              e.jsx("path", {
                d: "M17 -6v2.4",
                stroke: D,
                strokeWidth: "1.4",
                strokeLinecap: "round",
              }),
              e.jsx("circle", { cx: "17", cy: "-2", r: "0.7", fill: D }),
              e.jsx("path", {
                d: "M-3 -2l-3 -2M22 4l3 1",
                stroke: u,
                strokeWidth: "1.4",
                strokeLinecap: "round",
              }),
            ],
          })
        : null,
    ],
  });
}
const vr = {
  desktop: { x: 85, y: 44, w: 130, h: 80, bezel: 7, r: 7, badge: 6.5 },
  laptop: { x: 96, y: 78, w: 108, h: 62, bezel: 5, r: 5, badge: 5.5 },
  tablet: { x: 106, y: 84, w: 88, h: 56, bezel: 5, r: 7, badge: 5 },
  phone: { x: 122, y: 112, w: 56, h: 30, bezel: 3, r: 6, badge: 4 },
};
function Nr({ clip: t, make: r, split: s }) {
  return e.jsxs("g", {
    children: [
      e.jsx("rect", {
        x: "7",
        y: "7",
        width: "116",
        height: "66",
        rx: "2",
        fill: f,
      }),
      e.jsxs("g", {
        clipPath: `url(#${t}-make)`,
        children: [
          e.jsx("rect", {
            x: "7",
            y: "7",
            width: "116",
            height: "66",
            fill: S,
          }),
          [14, 22, 30, 38, 46, 54, 62].map((i) =>
            e.jsx(
              "rect",
              { x: "11", y: i - 1, width: "4", height: "2", fill: P },
              i,
            ),
          ),
          e.jsx("path", {
            d: "M20 14h24M26 22h30M26 30h18M32 38h22M26 46h28M20 54h14M20 62h22",
            stroke: y,
            strokeWidth: "3",
            strokeLinecap: "round",
          }),
          e.jsx("path", {
            d: "M48 14h12M48 30h10M58 46h8",
            stroke: ee,
            strokeWidth: "3",
            strokeLinecap: "round",
          }),
          e.jsx("path", {
            d: "M60 22h6M40 54h8",
            stroke: N,
            strokeWidth: "3",
            strokeLinecap: "round",
          }),
          e.jsx("rect", {
            x: "84",
            y: "12",
            width: "32",
            height: "56",
            rx: "5",
            fill: I,
          }),
          e.jsx("rect", {
            x: "87",
            y: "17",
            width: "26",
            height: "9",
            rx: "2",
            fill: X,
          }),
          e.jsx("rect", {
            x: "87",
            y: "29",
            width: "26",
            height: "14",
            rx: "2",
            fill: ee,
          }),
          e.jsx("path", {
            d: "M89 48h22M89 53h16",
            stroke: g,
            strokeWidth: "2.5",
            strokeLinecap: "round",
          }),
          e.jsx("rect", {
            x: "89",
            y: "58",
            width: "22",
            height: "6",
            rx: "3",
            fill: F,
          }),
        ],
      }),
      e.jsxs("g", {
        clipPath: `url(#${t}-break)`,
        children: [
          e.jsx("rect", {
            x: "7",
            y: "7",
            width: "116",
            height: "66",
            fill: f,
          }),
          e.jsx("path", {
            d: "M12 14h4M12 26h4M12 38h4M12 50h4",
            stroke: y,
            strokeWidth: "2.5",
            strokeLinecap: "round",
          }),
          e.jsx("path", {
            d: "M20 14h34M20 20h22M20 26h40M20 32h18M20 38h30M20 44h26M20 50h36",
            stroke: g,
            strokeWidth: "2.5",
            strokeLinecap: "round",
            opacity: "0.55",
          }),
          e.jsx("path", {
            d: "M20 32h18M20 44h26",
            stroke: u,
            strokeWidth: "2.5",
            strokeLinecap: "round",
          }),
          e.jsx("rect", {
            x: "12",
            y: "58",
            width: "60",
            height: "7",
            rx: "3.5",
            fill: S,
          }),
          e.jsx("rect", {
            x: "12",
            y: "58",
            width: 14 + r * 46,
            height: "7",
            rx: "3.5",
            fill: N,
          }),
          e.jsxs("g", {
            transform: "translate(100 40)",
            children: [
              e.jsx("path", {
                d: "M-8 -4v-8a8 8 0 0 1 16 0",
                stroke: g,
                strokeWidth: "4",
                fill: "none",
                transform: `rotate(${r * -28} -8 -4)`,
              }),
              e.jsx("rect", {
                x: "-13",
                y: "-4",
                width: "26",
                height: "22",
                rx: "4",
                fill: _,
                transform: "translate(0 2)",
              }),
              e.jsx("rect", {
                x: "-13",
                y: "-4",
                width: "26",
                height: "22",
                rx: "4",
                fill: u,
              }),
              e.jsx("circle", { cx: "0", cy: "5", r: "3", fill: _ }),
              e.jsx("rect", {
                x: "-1.2",
                y: "5",
                width: "2.4",
                height: "6",
                fill: _,
              }),
            ],
          }),
        ],
      }),
      r > 0.02 && r < 0.98
        ? e.jsxs("g", {
            children: [
              e.jsx("rect", {
                x: s - 1,
                y: "7",
                width: "2",
                height: "66",
                fill: H,
              }),
              e.jsx("rect", {
                x: s - 3,
                y: "34",
                width: "6",
                height: "12",
                rx: "3",
                fill: g,
              }),
            ],
          })
        : null,
    ],
  });
}
function Hr({ device: t, clip: r, make: s, split: i, alerts: l }) {
  const { x: o, y: a, w: x, h: j, bezel: p, r: d, badge: C } = vr[t],
    [z, E, v, T] = [o + p, a + p, x - p * 2, j - p * 2],
    He = Math.max(v / 116, T / 66);
  return e.jsxs("g", {
    children: [
      t === "desktop"
        ? e.jsxs("g", {
            children: [
              e.jsx("rect", {
                x: "143",
                y: "124",
                width: "14",
                height: "18",
                fill: H,
              }),
              e.jsx("rect", {
                x: "129",
                y: "140",
                width: "42",
                height: "6",
                rx: "2",
                fill: H,
              }),
              e.jsx("path", {
                d: "M131 141.5h38",
                stroke: g,
                strokeWidth: "1.2",
                strokeLinecap: "round",
              }),
            ],
          })
        : null,
      t === "tablet"
        ? e.jsx("path", { d: "M138 140l-6 6h36l-6 -6z", fill: H })
        : null,
      t === "phone"
        ? e.jsx("path", { d: "M140 142l-4 4h28l-4 -4z", fill: H })
        : null,
      e.jsx(U, {
        x: o,
        y: a,
        w: x,
        h: j,
        r: d,
        face: L,
        edge: f,
        rim: P,
        depth: t === "phone" ? 3 : 5,
        shadow: !1,
      }),
      e.jsx("clipPath", {
        id: `${r}-screen`,
        children: e.jsx("rect", { x: z, y: E, width: v, height: T }),
      }),
      e.jsx("g", {
        clipPath: `url(#${r}-screen)`,
        children: e.jsx("g", {
          transform: `translate(${z + v / 2} ${E + T / 2}) scale(${He}) translate(-65 -40)`,
          children: e.jsx(Nr, { clip: r, make: s, split: i }),
        }),
      }),
      t === "laptop"
        ? e.jsxs("g", {
            children: [
              e.jsx("path", { d: "M84 146l12 -6h108l12 6z", fill: H }),
              e.jsx("path", {
                d: "M97 141h106",
                stroke: g,
                strokeWidth: "1.2",
                strokeLinecap: "round",
              }),
              e.jsx("path", {
                d: "M102 143.5h96",
                stroke: L,
                strokeWidth: "1.5",
                strokeDasharray: "3 1.5",
              }),
            ],
          })
        : null,
      s < 0.6 && (t === "desktop" || t === "laptop")
        ? e.jsx("rect", {
            x: o + 2,
            y: a - 2,
            width: x / 8,
            height: x / 11,
            fill: N,
            opacity: "0.9",
            transform: `rotate(-6 ${o + 8} ${a + 4})`,
          })
        : null,
      Array.from({ length: l }, ($, De) =>
        e.jsxs(
          "g",
          {
            transform: `translate(${o + x - 3 - De * C * 2.2} ${a + 2}) scale(${C / 6.5})`,
            children: [
              e.jsx("circle", { r: "6.5", fill: _, cy: "1.5" }),
              e.jsx("circle", { r: "6.5", fill: u }),
              e.jsx("path", {
                d: "M0 -3v3.5",
                stroke: D,
                strokeWidth: "2",
                strokeLinecap: "round",
              }),
              e.jsx("circle", { cy: "3.2", r: "1.1", fill: D }),
            ],
          },
          De,
        ),
      ),
    ],
  });
}
function Cr({ values: t }) {
  const r = `workspace${O.useId().replace(/:/g, "")}`,
    s = Me(t.kit),
    i = Me(t.make),
    l = Me(t.pace),
    o = 1 - l,
    a =
      s < 0.3
        ? "desktop"
        : s < 0.55
          ? "laptop"
          : s < 0.75
            ? "tablet"
            : s <= 0.9
              ? "phone"
              : null,
    x = s < 0.6,
    j = s > 0.4,
    p = 0.6 + s * 0.55,
    d = 7 + 116 * (1 - i),
    C = l > 0.85 ? 3 : l > 0.6 ? 2 : l > 0.35 ? 1 : 0,
    z = wr.map((v, T) => 50 - (v * o + Lr[T] * l)),
    E = l > 0.5;
  return e.jsxs("svg", {
    viewBox: "0 0 360 200",
    role: "img",
    "aria-label": "Your workspace",
    "data-slider-scene": "",
    children: [
      e.jsxs("defs", {
        children: [
          e.jsx("clipPath", {
            id: `${r}-make`,
            children: e.jsx("rect", {
              x: "7",
              y: "7",
              width: d - 7,
              height: "66",
            }),
          }),
          e.jsx("clipPath", {
            id: `${r}-break`,
            children: e.jsx("rect", {
              x: d,
              y: "7",
              width: 123 - d,
              height: "66",
            }),
          }),
        ],
      }),
      e.jsx("rect", { width: "360", height: "200", fill: Ne }),
      e.jsx("path", { d: "M0 40h360M0 92h360", stroke: S, strokeWidth: "1" }),
      e.jsx("rect", { y: "166", width: "360", height: "34", fill: f }),
      e.jsx("rect", {
        x: "18",
        y: "12",
        width: "78",
        height: "58",
        rx: "4",
        fill: L,
      }),
      e.jsx("rect", {
        x: "22",
        y: "16",
        width: "70",
        height: "50",
        rx: "2",
        fill: f,
      }),
      e.jsx("circle", { cx: "74", cy: "30", r: "8", fill: I }),
      e.jsx("circle", { cx: "71", cy: "28", r: "7", fill: f }),
      [
        [32, 24],
        [48, 36],
        [40, 52],
        [62, 48],
        [84, 54],
      ].map(([v, T]) =>
        e.jsx(
          "rect",
          { x: v, y: T, width: "2", height: "2", fill: D, opacity: "0.7" },
          `${v}-${T}`,
        ),
      ),
      e.jsx("path", { d: "M57 16v50M22 41h70", stroke: L, strokeWidth: "3" }),
      x
        ? e.jsxs("g", {
            children: [
              e.jsx(U, {
                x: 236,
                y: 12,
                w: 94,
                h: 50,
                r: 5,
                face: L,
                edge: f,
                rim: P,
                depth: 4,
                shadow: !1,
              }),
              e.jsx("rect", {
                x: "241",
                y: "17",
                width: "84",
                height: "40",
                rx: "2",
                fill: f,
              }),
              e.jsx("rect", {
                x: "241",
                y: "17",
                width: "84",
                height: "7",
                fill: E ? _ : $e,
              }),
              e.jsx("circle", {
                cx: "246",
                cy: "20.5",
                r: "1.8",
                fill: E ? u : y,
              }),
              e.jsx("path", {
                d: "M252 20.5h20",
                stroke: E ? ue : We,
                strokeWidth: "1.5",
                strokeLinecap: "round",
                opacity: "0.7",
              }),
              e.jsx("path", { d: "M245 50h76", stroke: S, strokeWidth: "1" }),
              e.jsx("path", {
                d: z
                  .map(
                    (v, T) =>
                      `${T === 0 ? "M" : "L"}${246 + T * 10.5} ${v + 3}`,
                  )
                  .join(""),
                stroke: E ? u : y,
                strokeWidth: "2",
                fill: "none",
                strokeLinejoin: "round",
                strokeLinecap: "round",
              }),
            ],
          })
        : e.jsx(mr, { pace: l }),
      e.jsx("rect", {
        x: "338",
        y: "30",
        width: "14",
        height: "5",
        rx: "1.5",
        fill: H,
      }),
      e.jsx("path", { d: "M339 30v-7a6 6 0 0 1 12 0v7z", fill: _ }),
      e.jsx("path", { d: "M339 30v-7a6 6 0 0 1 12 0v7z", fill: u, opacity: l }),
      e.jsx("path", {
        d: "M342 21a3 3 0 0 1 3 -3",
        stroke: ue,
        strokeWidth: "1.5",
        fill: "none",
        strokeLinecap: "round",
        opacity: l,
      }),
      e.jsx("path", {
        d: "M334 18l-8 -5M333 26h-9M356 18l4 -3",
        stroke: u,
        strokeWidth: "2",
        strokeLinecap: "round",
        opacity: Me((l - 0.4) / 0.4),
      }),
      e.jsx("path", { d: "M58 64L24 146H128Z", fill: de, opacity: o * 0.14 }),
      e.jsx("path", {
        d: "M14 146V70L46 50",
        stroke: H,
        strokeWidth: "4",
        fill: "none",
        strokeLinecap: "round",
        strokeLinejoin: "round",
      }),
      e.jsx("circle", { cx: "14", cy: "70", r: "3", fill: g }),
      e.jsx("path", { d: "M40 46l24 6-6 14-20-6z", fill: Q }),
      e.jsx("path", { d: "M40 46l24 6-2 4-22-6z", fill: N }),
      e.jsx("ellipse", {
        cx: "50",
        cy: "61",
        rx: "7",
        ry: "2.5",
        fill: de,
        opacity: 0.25 + o * 0.75,
        transform: "rotate(20 50 61)",
      }),
      e.jsx("rect", { x: "6", y: "146", width: "348", height: "12", fill: L }),
      e.jsx("path", {
        d: "M8 147.5h344",
        stroke: P,
        strokeWidth: "1.5",
        strokeLinecap: "round",
      }),
      e.jsx("rect", { x: "6", y: "158", width: "348", height: "8", fill: S }),
      e.jsx("rect", { x: "16", y: "166", width: "8", height: "30", fill: S }),
      e.jsx("rect", { x: "336", y: "166", width: "8", height: "30", fill: S }),
      a === "desktop"
        ? e.jsxs("g", {
            children: [
              e.jsx("rect", {
                x: "34",
                y: "168",
                width: "22",
                height: "28",
                rx: "2",
                fill: L,
              }),
              e.jsx("path", {
                d: "M37 172h16M37 176h16",
                stroke: S,
                strokeWidth: "1.5",
              }),
              e.jsx("circle", { cx: "45", cy: "189", r: "2", fill: y }),
            ],
          })
        : null,
      j
        ? e.jsxs("g", {
            children: [
              e.jsx("rect", {
                x: "286",
                y: "180",
                width: "40",
                height: "16",
                rx: "2",
                fill: _,
              }),
              e.jsx("rect", {
                x: "286",
                y: "178",
                width: "40",
                height: "14",
                rx: "2",
                fill: u,
              }),
              e.jsx("path", {
                d: "M298 178v-5h16v5",
                stroke: g,
                strokeWidth: "2.5",
                fill: "none",
              }),
              e.jsx("rect", {
                x: "302",
                y: "183",
                width: "8",
                height: "3",
                rx: "1",
                fill: g,
              }),
            ],
          })
        : null,
      s < 0.2
        ? e.jsxs("g", {
            children: [
              e.jsx("path", { d: "M30 86l58 -6v56l-58 4z", fill: f }),
              e.jsx("path", { d: "M28 84l58 -6v56l-58 4z", fill: L }),
              e.jsx("path", {
                d: "M32 88l50 -5v46l-50 4z",
                fill: i < 0.5 ? S : f,
              }),
              i < 0.5
                ? e.jsxs("g", {
                    children: [
                      e.jsx("path", { d: "M38 93l18 -2v6l-18 2z", fill: X }),
                      e.jsx("path", {
                        d: "M38 103l38 -4M38 110l30 -3M38 117l34 -3",
                        stroke: I,
                        strokeWidth: "3",
                        strokeLinecap: "round",
                        opacity: "0.6",
                      }),
                      e.jsx("path", {
                        d: "M38 124l14 -1.4v5l-14 1.4z",
                        fill: y,
                      }),
                    ],
                  })
                : e.jsxs("g", {
                    children: [
                      e.jsx("path", {
                        d: "M42 100L58 112L72 96M58 112L62 126",
                        stroke: P,
                        strokeWidth: "1.5",
                        fill: "none",
                      }),
                      e.jsx("circle", { cx: "42", cy: "100", r: "3", fill: y }),
                      e.jsx("circle", {
                        cx: "58",
                        cy: "112",
                        r: "3.5",
                        fill: u,
                      }),
                      e.jsx("circle", { cx: "72", cy: "96", r: "3", fill: y }),
                      e.jsx("circle", { cx: "62", cy: "126", r: "3", fill: N }),
                    ],
                  }),
              e.jsx("path", { d: "M54 136l6 10h-14z", fill: H }),
            ],
          })
        : null,
      a
        ? e.jsx(Hr, { device: a, clip: r, make: i, split: d, alerts: C })
        : e.jsxs("g", {
            children: [
              i < 0.6
                ? e.jsx(Wr, {
                    x: i > 0.4 ? 104 : 150,
                    scale: i > 0.4 ? 1.15 : 1.45,
                  })
                : null,
              i > 0.4
                ? e.jsx($r, {
                    x: i < 0.6 ? 182 : 150,
                    scale: i < 0.6 ? 1.1 : 1.4,
                  })
                : null,
            ],
          }),
      e.jsx("path", { d: "M34 154l36 -2 4 6 -36 2z", fill: I }),
      e.jsx("path", {
        d: "M40 155l24 -1.3M42 157.4l18 -1",
        stroke: g,
        strokeWidth: "1",
      }),
      e.jsx("path", {
        d: "M62 151l14 -6",
        stroke: X,
        strokeWidth: "2.5",
        strokeLinecap: "round",
      }),
      a === "desktop"
        ? e.jsxs("g", {
            children: [
              e.jsx(U, {
                x: 104,
                y: 150,
                w: 88,
                h: 6,
                r: 2,
                face: H,
                edge: f,
                rim: g,
                depth: 2,
                shadow: !1,
              }),
              e.jsx("path", {
                d: "M110 153h76",
                stroke: L,
                strokeWidth: "2",
                strokeDasharray: "4 2",
              }),
              e.jsx("rect", {
                x: "198",
                y: "149",
                width: "11",
                height: "8",
                rx: "4",
                fill: g,
              }),
            ],
          })
        : null,
      a === "laptop"
        ? e.jsx("rect", {
            x: "204",
            y: "150",
            width: "11",
            height: "7",
            rx: "3.5",
            fill: g,
          })
        : null,
      a === "tablet"
        ? e.jsx("path", {
            d: "M150 155l40 -4",
            stroke: X,
            strokeWidth: "2.5",
            strokeLinecap: "round",
          })
        : null,
      a
        ? null
        : e.jsxs("g", {
            children: [
              e.jsx("rect", {
                x: "112",
                y: "150",
                width: "20",
                height: "7",
                rx: "3",
                fill: _,
              }),
              e.jsx("rect", {
                x: "112",
                y: "149",
                width: "20",
                height: "6",
                rx: "3",
                fill: u,
              }),
              e.jsx("rect", {
                x: "132",
                y: "151",
                width: "24",
                height: "2.5",
                rx: "1",
                fill: g,
              }),
              e.jsx("path", {
                d: "M168 157l14 -8M172 158l16 -5",
                stroke: N,
                strokeWidth: "3",
                strokeLinecap: "round",
              }),
              e.jsx("path", {
                d: "M182 149l8 -3M188 153l8 -1",
                stroke: g,
                strokeWidth: "2.5",
                strokeLinecap: "round",
              }),
              e.jsx(br, { alerts: C }),
            ],
          }),
      e.jsx("path", { d: "M220 146v12h14v-12z", fill: F }),
      e.jsx("path", { d: "M220 146h14v2h-14z", fill: y }),
      e.jsx("path", {
        d: "M234 149a4 4 0 0 1 0 6",
        stroke: F,
        strokeWidth: "2.5",
        fill: "none",
      }),
      e.jsx("path", {
        d: "M224 141c-3 -4 3 -6 0 -10M230 141c-3 -4 3 -6 0 -10",
        stroke: I,
        strokeWidth: "1.5",
        fill: "none",
        strokeLinecap: "round",
        opacity: o * 0.8,
      }),
      j
        ? e.jsxs("g", {
            children: [
              e.jsx("rect", {
                x: "244",
                y: "116",
                width: "44",
                height: "30",
                rx: "2",
                fill: $e,
              }),
              e.jsx("path", {
                d: "M244 117.5h44",
                stroke: F,
                strokeWidth: "1.5",
              }),
              e.jsx("rect", {
                x: "258",
                y: "124",
                width: "14",
                height: "12",
                rx: "1",
                fill: f,
              }),
              e.jsx("path", {
                d: "M249 122h8M249 130h8M273 126h10M273 134h6v8M262 136v8",
                stroke: y,
                strokeWidth: "1.2",
                opacity: "0.8",
              }),
              e.jsx("circle", { cx: "282", cy: "140", r: "2.5", fill: N }),
              e.jsx("path", {
                d: "M248 146l-4 -6M284 146l4 -6",
                stroke: H,
                strokeWidth: "3",
                strokeLinecap: "round",
              }),
              e.jsx("rect", {
                x: "246",
                y: "150",
                width: "22",
                height: "9",
                rx: "2",
                fill: Q,
              }),
              e.jsx("rect", {
                x: "246",
                y: "148",
                width: "22",
                height: "9",
                rx: "2",
                fill: N,
              }),
              e.jsx("path", { d: "M250 155a6 6 0 0 1 12 0z", fill: I }),
              e.jsx("path", {
                d: "M256 155l3 -4.5",
                stroke: _,
                strokeWidth: "1.2",
                strokeLinecap: "round",
              }),
              e.jsx("circle", { cx: "265", cy: "152.5", r: "1.6", fill: be }),
            ],
          })
        : null,
      e.jsxs("g", {
        transform: `translate(316 146) scale(${p})`,
        children: [
          e.jsx("ellipse", {
            cx: "0",
            cy: "2",
            rx: "22",
            ry: "3",
            fill: f,
            opacity: "0.7",
          }),
          e.jsx("rect", {
            x: "-18",
            y: "-10",
            width: "36",
            height: "12",
            rx: "3",
            fill: f,
          }),
          e.jsx("rect", {
            x: "-18",
            y: "-12",
            width: "36",
            height: "10",
            rx: "3",
            fill: H,
          }),
          e.jsx("path", {
            d: "M-15 -10.5h30",
            stroke: g,
            strokeWidth: "1.5",
            strokeLinecap: "round",
          }),
          e.jsx("path", {
            d: "M0 -12V-52L-30 -80L-58 -62",
            stroke: f,
            strokeWidth: "12",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            fill: "none",
            transform: "translate(2 2)",
          }),
          e.jsx("path", {
            d: "M0 -12V-52L-30 -80L-58 -62",
            stroke: H,
            strokeWidth: "11",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            fill: "none",
          }),
          e.jsx("path", {
            d: "M-3 -16V-52L-30 -77",
            stroke: g,
            strokeWidth: "2",
            strokeLinecap: "round",
            fill: "none",
          }),
          e.jsx("path", {
            d: "M-58 -62l-6 10M-58 -62l4 11",
            stroke: I,
            strokeWidth: "4",
            strokeLinecap: "round",
          }),
          [
            [0, -52],
            [-30, -80],
            [-58, -62],
          ].map(([v, T]) =>
            e.jsxs(
              "g",
              {
                children: [
                  e.jsx("circle", { cx: v, cy: T + 1.5, r: "7", fill: Q }),
                  e.jsx("circle", { cx: v, cy: T, r: "7", fill: N }),
                  e.jsx("circle", { cx: v - 2, cy: T - 2, r: "2", fill: de }),
                ],
              },
              `${v}-${T}`,
            ),
          ),
        ],
      }),
      e.jsx("rect", { width: "360", height: "200", fill: u, opacity: l * 0.1 }),
    ],
  });
}
function ht({ id: t }) {
  return e.jsxs("svg", {
    viewBox: "0 0 48 48",
    "aria-hidden": "true",
    "data-priority-art": t,
    children: [
      e.jsx("rect", { width: "48", height: "48", rx: "12", fill: S }),
      Vr[t],
    ],
  });
}
const Vr = {
  safe: e.jsxs("g", {
    children: [
      e.jsx("path", {
        d: "M24 9l13 5v9c0 9-6 14-13 17-7-3-13-8-13-17v-9z",
        fill: F,
        stroke: y,
        strokeWidth: "2.5",
      }),
      e.jsx("path", {
        d: "M18 24l5 5 8-9",
        stroke: D,
        strokeWidth: "3",
        fill: "none",
        strokeLinecap: "round",
      }),
    ],
  }),
  millions: e.jsx("g", {
    children: [0, 1, 2].map((t) =>
      [0, 1, 2].map((r) =>
        e.jsx(
          "circle",
          {
            cx: 14 + r * 10,
            cy: 14 + t * 10,
            r: "3.5",
            fill: t === 1 && r === 1 ? N : y,
          },
          `${t}-${r}`,
        ),
      ),
    ),
  }),
  puzzles: e.jsx("path", {
    d: "M12 14h9a4 4 0 1 1 6 0h9v9a4 4 0 1 0 0 6v9h-9a4 4 0 1 1-6 0h-9z",
    fill: X,
    stroke: D,
    strokeWidth: "1.5",
    strokeLinejoin: "round",
  }),
  looks: e.jsxs("g", {
    children: [
      e.jsx("path", {
        d: "M24 10c8 0 14 6 14 13 0 5-4 6-7 6h-3a3 3 0 0 0-2 5c1 2-1 4-3 4-7 0-13-6-13-14s6-14 14-14z",
        fill: I,
      }),
      e.jsx("circle", { cx: "18", cy: "20", r: "3", fill: u }),
      e.jsx("circle", { cx: "26", cy: "16", r: "3", fill: N }),
      e.jsx("circle", { cx: "32", cy: "22", r: "3", fill: y }),
    ],
  }),
  future: e.jsxs("g", {
    children: [
      e.jsx("path", {
        d: "M24 8c6 4 9 11 8 20l-4 6h-8l-4-6c-1-9 2-16 8-20z",
        fill: I,
      }),
      e.jsx("circle", { cx: "24", cy: "20", r: "3.5", fill: y }),
      e.jsx("path", {
        d: "M20 34l-2 7M24 34v8M28 34l2 7",
        stroke: N,
        strokeWidth: "3",
        strokeLinecap: "round",
      }),
    ],
  }),
};
function Ar() {
  return e.jsxs("svg", {
    viewBox: "0 0 320 320",
    "aria-hidden": "true",
    "data-map-art": "",
    children: [
      e.jsx("rect", { width: "320", height: "320", rx: "20", fill: Ne }),
      e.jsx("rect", {
        x: "0",
        y: "0",
        width: "160",
        height: "160",
        rx: "20",
        fill: X,
        opacity: "0.12",
      }),
      e.jsx("rect", {
        x: "160",
        y: "0",
        width: "160",
        height: "160",
        rx: "20",
        fill: y,
        opacity: "0.1",
      }),
      e.jsx("rect", {
        x: "0",
        y: "160",
        width: "160",
        height: "160",
        rx: "20",
        fill: N,
        opacity: "0.08",
      }),
      e.jsx("rect", {
        x: "160",
        y: "160",
        width: "160",
        height: "160",
        rx: "20",
        fill: u,
        opacity: "0.1",
      }),
      e.jsx("path", {
        d: "M160 16V304M16 160H304",
        stroke: L,
        strokeWidth: "2",
        strokeDasharray: "6 8",
      }),
      e.jsxs("g", {
        transform: "translate(46 44)",
        children: [
          e.jsx("rect", {
            width: "40",
            height: "66",
            rx: "8",
            fill: S,
            stroke: X,
            strokeWidth: "3",
          }),
          e.jsx("rect", {
            x: "8",
            y: "12",
            width: "24",
            height: "12",
            rx: "3",
            fill: X,
          }),
          e.jsx("rect", {
            x: "8",
            y: "30",
            width: "24",
            height: "6",
            rx: "2",
            fill: I,
          }),
          e.jsx("rect", {
            x: "8",
            y: "42",
            width: "16",
            height: "6",
            rx: "2",
            fill: I,
          }),
        ],
      }),
      e.jsxs("g", {
        transform: "translate(216 50)",
        children: [
          e.jsx("path", {
            d: "M6 64V36L30 16L52 30",
            stroke: P,
            strokeWidth: "9",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            fill: "none",
          }),
          e.jsx("circle", { cx: "30", cy: "16", r: "7", fill: y }),
          e.jsx("rect", {
            x: "-8",
            y: "60",
            width: "30",
            height: "10",
            rx: "3",
            fill: L,
          }),
        ],
      }),
      e.jsxs("g", {
        transform: "translate(46 210)",
        children: [
          e.jsx("path", {
            d: "M14 34c0-12 6-20 16-20s16 8 16 20M20 36c0-9 4-14 10-14s10 5 10 14M28 38c0-6 1-8 2-8",
            stroke: N,
            strokeWidth: "3",
            fill: "none",
            strokeLinecap: "round",
          }),
          e.jsx("circle", {
            cx: "30",
            cy: "30",
            r: "24",
            fill: "none",
            stroke: I,
            strokeWidth: "5",
          }),
          e.jsx("path", {
            d: "M48 48l14 14",
            stroke: I,
            strokeWidth: "7",
            strokeLinecap: "round",
          }),
        ],
      }),
      e.jsxs("g", {
        transform: "translate(212 206)",
        children: [
          e.jsx("rect", {
            width: "52",
            height: "18",
            rx: "3",
            fill: S,
            stroke: L,
            strokeWidth: "2",
          }),
          e.jsx("rect", {
            y: "22",
            width: "52",
            height: "18",
            rx: "3",
            fill: S,
            stroke: L,
            strokeWidth: "2",
          }),
          e.jsx("circle", { cx: "9", cy: "9", r: "3", fill: y }),
          e.jsx("circle", { cx: "9", cy: "31", r: "3", fill: u }),
          e.jsx("path", {
            d: "M54 36l16 6v10c0 9-7 14-16 17-9-3-16-8-16-17v-10z",
            fill: F,
            stroke: y,
            strokeWidth: "2.5",
          }),
        ],
      }),
    ],
  });
}
const oe = [
    {
      id: "console",
      label: "Take apart a games console",
      traits: { hardware: 2 },
    },
    {
      id: "glitch",
      label: "Find the glitch that breaks a game",
      traits: { breaker: 2 },
    },
    { id: "icon", label: "Design an app icon", traits: { design: 2 } },
    { id: "code", label: "Crack an escape room code", traits: { solver: 2 } },
    { id: "stats", label: "Track your team’s stats", traits: { data: 2 } },
    { id: "scam", label: "Stop a scam message", traits: { protector: 2 } },
    {
      id: "clues",
      label: "Solve a mystery from clues",
      traits: { detective: 2 },
    },
    { id: "mod", label: "Build a mod for a game", traits: { builder: 2 } },
  ],
  dt = [
    {
      id: "kit",
      left: "Screens",
      right: "Kit",
      leftTraits: { data: 1, design: 1 },
      rightTraits: { hardware: 2 },
    },
    {
      id: "make",
      left: "Make it",
      right: "Break it",
      leftTraits: { builder: 1.5, design: 0.5 },
      rightTraits: { breaker: 1.5, protector: 0.5 },
    },
    {
      id: "pace",
      left: "Think it through",
      right: "Live action",
      leftTraits: { solver: 1, data: 1 },
      rightTraits: { protector: 1, detective: 1 },
    },
  ],
  ve = [
    {
      id: "safe",
      label: "Keeping people safe",
      traits: { protector: 1, detective: 0.5 },
    },
    {
      id: "millions",
      label: "Millions using what I made",
      traits: { builder: 1, design: 0.5 },
    },
    {
      id: "puzzles",
      label: "Cracking hard puzzles",
      traits: { solver: 1, breaker: 0.5 },
    },
    { id: "looks", label: "Making it look amazing", traits: { design: 1.5 } },
    {
      id: "future",
      label: "The newest tech first",
      traits: { hardware: 1, data: 0.5 },
    },
  ],
  Sr = [3, 2, 1, 0.5, 0],
  ke = {
    createPeople: {
      label: "Create for people",
      traits: { design: 2, builder: 1 },
    },
    createMachines: {
      label: "Create with machines",
      traits: { hardware: 2, builder: 1 },
    },
    protectPeople: {
      label: "Protect people",
      traits: { detective: 2, protector: 1 },
    },
    protectMachines: {
      label: "Protect machines",
      traits: { breaker: 2, protector: 1 },
    },
  },
  ct = {
    swipes: {},
    sliders: { kit: 0.5, make: 0.5, pace: 0.5 },
    ranking: ve.map((t) => t.id),
    pin: { x: 0.5, y: 0.5 },
  },
  Er = [
    "builder",
    "breaker",
    "solver",
    "hardware",
    "data",
    "design",
    "protector",
    "detective",
  ];
function ie(t, r, s) {
  for (const [i, l] of Object.entries(r)) t[i] += l * s;
}
function zr(t) {
  const r = Object.fromEntries(Er.map((l) => [l, 0]));
  for (const l of oe) t.swipes[l.id] && ie(r, l.traits, 1);
  for (const l of dt) {
    const o = Te(t.sliders[l.id]);
    (ie(r, l.leftTraits, 1 - o), ie(r, l.rightTraits, o));
  }
  t.ranking.forEach((l, o) => {
    const a = ve.find((x) => x.id === l);
    a && ie(r, a.traits, Sr[o] ?? 0);
  });
  const s = Te(t.pin.x),
    i = Te(t.pin.y);
  return (
    ie(r, ke.createPeople.traits, (1 - s) * (1 - i)),
    ie(r, ke.createMachines.traits, s * (1 - i)),
    ie(r, ke.protectPeople.traits, (1 - s) * i),
    ie(r, ke.protectMachines.traits, s * i),
    r
  );
}
function Te(t) {
  return Math.min(1, Math.max(0, Number.isFinite(t) ? t : 0.5));
}
function Tr(t, r = yt) {
  const s = zr(t),
    i = Math.hypot(...Object.values(s));
  return r
    .map((l, o) => {
      const a = Object.entries(l.traits),
        x = a.reduce((d, [C, z]) => d + s[C] * z, 0),
        j = Math.hypot(...a.map(([, d]) => d)),
        p = i && j ? x / (i * j) : 0;
      return { career: l, percent: Math.round(p * 100), order: o };
    })
    .sort((l, o) => o.percent - l.percent || l.order - o.order)
    .map(({ career: l, percent: o }) => ({ career: l, percent: o }));
}
function Rr(t, r, s) {
  const i = [...t],
    [l] = i.splice(r, 1);
  return (i.splice(Math.min(Math.max(s, 0), i.length), 0, l), i);
}
const we = [
  "Into it or not?",
  "Build your workspace",
  "Drag what matters most to the top",
  "Where do you fit?",
];
function Zr({ link: t }) {
  const [r, s] = O.useState(0),
    [i, l] = O.useState(ct);
  O.useEffect(() => {
    window.scrollTo(0, 0);
  }, [r]);
  const o = () => {
    (l(ct), s(0));
  };
  if (r >= we.length) return e.jsx(_r, { answers: i, onRestart: o, link: t });
  const a = () => {
      if (r === 0) {
        const p = oe.filter((C) => i.swipes[C.id] !== void 0).at(-1);
        if (!p) return;
        const d = { ...i.swipes };
        (delete d[p.id], l({ ...i, swipes: d }));
        return;
      }
      s(r - 1);
    },
    x = r > 0 || Object.keys(i.swipes).length > 0;
  return e.jsxs("div", {
    className: "careers",
    "data-careers-view": "quiz",
    "data-quiz-round": r + 1,
    children: [
      e.jsx("h1", {
        className: "sr-only",
        children: "Which tech job suits you?",
      }),
      e.jsxs("div", {
        className: "career-quiz-top",
        children: [
          x
            ? e.jsx("button", {
                type: "button",
                className: "career-quiz-back",
                onClick: a,
                "aria-label": "Back",
                children: e.jsx(ut, { "aria-hidden": "true" }),
              })
            : e.jsx("span", {
                className: "career-quiz-back",
                "aria-hidden": "true",
              }),
          e.jsx("ol", {
            className: "career-quiz-steps",
            "aria-label": `Round ${r + 1} of ${we.length}`,
            children: we.map((j, p) =>
              e.jsx(
                "li",
                {
                  "data-done": p < r || void 0,
                  "data-current": p === r || void 0,
                },
                j,
              ),
            ),
          }),
        ],
      }),
      e.jsx("h2", { className: "career-quiz-prompt", children: we[r] }, r),
      r === 0
        ? e.jsx(Dr, {
            swipes: i.swipes,
            onSwipe: (j, p) =>
              l((d) => ({ ...d, swipes: { ...d.swipes, [j]: p } })),
            onDone: () => s(1),
          })
        : null,
      r === 1
        ? e.jsx(Ir, {
            values: i.sliders,
            onChange: (j, p) =>
              l((d) => ({ ...d, sliders: { ...d.sliders, [j]: p } })),
            onNext: () => s(2),
          })
        : null,
      r === 2
        ? e.jsx(Or, {
            ranking: i.ranking,
            onChange: (j) => l((p) => ({ ...p, ranking: j })),
            onNext: () => s(3),
          })
        : null,
      r === 3
        ? e.jsx(Pr, {
            pin: i.pin,
            onChange: (j) => l((p) => ({ ...p, pin: j })),
            onNext: () => s(4),
          })
        : null,
    ],
  });
}
const Le = 80;
function Dr({ swipes: t, onSwipe: r, onDone: s }) {
  const i = oe.filter(($) => t[$.id] === void 0),
    l = i[0],
    o = i[1],
    [a, x] = O.useState(null),
    [j, p] = O.useState(null),
    d = O.useRef(null),
    C = oe.filter(($) => t[$.id] === !0).length,
    z = oe.filter(($) => t[$.id] === !1).length;
  (O.useEffect(() => {
    if (!l && !j) {
      const $ = window.setTimeout(s, 250);
      return () => window.clearTimeout($);
    }
  }, [l, j, s]),
    O.useEffect(() => {
      d.current?.focus({ preventScroll: !0 });
    }, [l?.id]));
  const E = ($) => {
      !l ||
        j ||
        (x(null),
        p({ id: l.id, into: $ }),
        window.setTimeout(() => {
          (r(l.id, $), p(null));
        }, 220));
    },
    v = j ? (j.into ? 420 : -420) : (a?.dx ?? 0),
    T = v > Le / 2 ? "into" : v < -Le / 2 ? "not" : void 0,
    He = {
      onPointerDown($) {
        j ||
          ($.pointerType === "mouse" && $.button !== 0) ||
          ($.currentTarget.setPointerCapture?.($.pointerId),
          x({ pointerId: $.pointerId, startX: $.clientX, dx: 0 }));
      },
      onPointerMove($) {
        !a ||
          $.pointerId !== a.pointerId ||
          x({ ...a, dx: $.clientX - a.startX });
      },
      onPointerUp($) {
        !a ||
          $.pointerId !== a.pointerId ||
          (a.dx > Le ? E(!0) : a.dx < -Le ? E(!1) : x(null));
      },
      onPointerCancel() {
        x(null);
      },
      onKeyDown($) {
        ($.key === "ArrowRight" && E(!0), $.key === "ArrowLeft" && E(!1));
      },
    };
  return e.jsxs("div", {
    className: "career-swipe",
    "data-leaning": T,
    children: [
      e.jsxs("div", {
        className: "career-swipe-piles",
        "aria-hidden": "true",
        children: [
          e.jsxs("span", {
            className: "career-swipe-pile",
            "data-pile": "not",
            children: [e.jsx(Ie, {}), " ", z],
          }),
          e.jsxs("span", {
            className: "career-swipe-pile",
            "data-pile": "into",
            children: [C, " ", e.jsx(Oe, {})],
          }),
        ],
      }),
      e.jsxs("div", {
        className: "career-swipe-deck",
        children: [
          o
            ? e.jsxs("div", {
                className: "career-swipe-card career-swipe-card-under",
                "aria-hidden": "true",
                children: [
                  e.jsx(lt, { id: o.id }),
                  e.jsx("p", { children: o.label }),
                ],
              })
            : null,
          l
            ? e.jsxs(
                "div",
                {
                  ref: d,
                  className: "career-swipe-card",
                  role: "button",
                  "aria-roledescription": "swipe card",
                  tabIndex: 0,
                  "aria-label": `${l.label}. Swipe right for yes, left for no.`,
                  "data-swipe-card": l.id,
                  "data-dragging": a ? "true" : void 0,
                  style: {
                    transform: `translateX(${v}px) rotate(${v / 18}deg)`,
                  },
                  ...He,
                  children: [
                    e.jsx(lt, { id: l.id }),
                    e.jsx("p", { children: l.label }),
                    e.jsx("span", {
                      className: "career-swipe-stamp",
                      "data-stamp": "into",
                      "aria-hidden": "true",
                      children: "Yes",
                    }),
                    e.jsx("span", {
                      className: "career-swipe-stamp",
                      "data-stamp": "not",
                      "aria-hidden": "true",
                      children: "No",
                    }),
                  ],
                },
                l.id,
              )
            : null,
        ],
      }),
      e.jsxs("div", {
        className: "career-swipe-buttons",
        children: [
          e.jsx("button", {
            type: "button",
            className: "career-swipe-button",
            "data-swipe": "not",
            onClick: () => E(!1),
            "aria-label": "No",
            disabled: !l,
            children: e.jsx(Ie, { "aria-hidden": "true" }),
          }),
          e.jsxs("span", {
            className: "career-swipe-count",
            children: [
              Math.min(oe.length - i.length + 1, oe.length),
              "/",
              oe.length,
            ],
          }),
          e.jsx("button", {
            type: "button",
            className: "career-swipe-button",
            "data-swipe": "into",
            onClick: () => E(!0),
            "aria-label": "Yes",
            disabled: !l,
            children: e.jsx(Oe, { "aria-hidden": "true" }),
          }),
        ],
      }),
    ],
  });
}
function Ir({ values: t, onChange: r, onNext: s }) {
  return e.jsxs("div", {
    className: "career-sliders",
    children: [
      e.jsx("div", {
        className: "career-quiz-visual",
        children: e.jsx(Cr, { values: t }),
      }),
      dt.map((i) =>
        e.jsxs(
          "label",
          {
            className: "career-slider",
            "data-slider": i.id,
            children: [
              e.jsxs("span", {
                className: "career-slider-ends",
                "aria-hidden": "true",
                children: [
                  e.jsx("span", {
                    "data-active": t[i.id] < 0.4 || void 0,
                    children: i.left,
                  }),
                  e.jsx("span", {
                    "data-active": t[i.id] > 0.6 || void 0,
                    children: i.right,
                  }),
                ],
              }),
              e.jsx("input", {
                type: "range",
                min: 0,
                max: 100,
                value: Math.round(t[i.id] * 100),
                onChange: (l) => r(i.id, Number(l.target.value) / 100),
                "aria-label": `${i.left} or ${i.right}`,
                "aria-valuetext":
                  t[i.id] < 0.4 ? i.left : t[i.id] > 0.6 ? i.right : "Both",
                style: { "--value": `${t[i.id] * 100}%` },
              }),
            ],
          },
          i.id,
        ),
      ),
      e.jsx("button", {
        type: "button",
        className: "careers-button careers-button-primary career-quiz-next",
        onClick: s,
        children: "Next",
      }),
    ],
  });
}
function Or({ ranking: t, onChange: r, onNext: s }) {
  const i = (p, d) => r(Rr(t, t.indexOf(p), d)),
    l = wt({ onDrop: (p, d) => i(p, Number(d)) }),
    o = l.dragging ? ve.find((p) => p.id === l.dragging) : void 0,
    a = (p) => (d) => {
      const C = t.indexOf(p);
      (d.key === "ArrowUp" && C > 0 && (d.preventDefault(), i(p, C - 1)),
        d.key === "ArrowDown" &&
          C < t.length - 1 &&
          (d.preventDefault(), i(p, C + 1)));
    },
    x = O.useRef(new Map()),
    j = O.useRef(null);
  return (
    O.useEffect(() => {
      j.current && x.current.get(j.current)?.focus();
    }, [t]),
    e.jsxs("div", {
      className: "career-rank",
      ref: l.root,
      "data-dragging": l.dragging ?? void 0,
      children: [
        e.jsx("ol", {
          className: "career-rank-list",
          "aria-label": "What matters most, first to last",
          children: t.map((p, d) => {
            const C = ve.find((z) => z.id === p);
            return e.jsx(
              "li",
              {
                ref: l.target(String(d)),
                "data-over": l.over === String(d) || void 0,
                "data-lifted": l.dragging === p || void 0,
                children: e.jsxs("button", {
                  type: "button",
                  ref: (z) => {
                    z ? x.current.set(p, z) : x.current.delete(p);
                  },
                  className: "career-rank-tile",
                  "aria-label": `${d + 1}. ${C.label}. Arrow keys move it.`,
                  "data-rank-tile": p,
                  "data-place": d + 1,
                  onFocus: () => {
                    j.current = p;
                  },
                  onBlur: () => {
                    j.current = null;
                  },
                  onKeyDown: a(p),
                  ...l.handle(p),
                  children: [
                    e.jsx("span", {
                      className: "career-rank-place",
                      "aria-hidden": "true",
                      children: d + 1,
                    }),
                    e.jsx("span", {
                      className: "career-rank-art",
                      children: e.jsx(ht, { id: p }),
                    }),
                    e.jsx("span", {
                      className: "career-rank-label",
                      children: C.label,
                    }),
                    e.jsx("span", {
                      className: "career-rank-grip",
                      "aria-hidden": "true",
                    }),
                  ],
                }),
              },
              p,
            );
          }),
        }),
        o && l.ghostStyle
          ? e.jsxs("div", {
              className: "career-rank-ghost",
              style: l.ghostStyle,
              "aria-hidden": "true",
              children: [
                e.jsx("span", {
                  className: "career-rank-art",
                  children: e.jsx(ht, { id: o.id }),
                }),
                e.jsx("span", {
                  className: "career-rank-label",
                  children: o.label,
                }),
              ],
            })
          : null,
        e.jsx("button", {
          type: "button",
          className: "careers-button careers-button-primary career-quiz-next",
          onClick: s,
          children: "Next",
        }),
      ],
    })
  );
}
function Pr({ pin: t, onChange: r, onNext: s }) {
  const i = O.useRef(null),
    [l, o] = O.useState(null),
    [a, x] = O.useState(!1),
    j = (d, C) => {
      const z = i.current?.getBoundingClientRect();
      if (!z) return;
      const E = (v) => Math.min(1, Math.max(0, v));
      (r({ x: E((d - z.left) / z.width), y: E((C - z.top) / z.height) }),
        x(!0));
    },
    p = (d) => {
      const E = {
        ArrowLeft: [-0.05, 0],
        ArrowRight: [0.05, 0],
        ArrowUp: [0, -0.05],
        ArrowDown: [0, 0.05],
      }[d.key];
      if (!E) return;
      d.preventDefault();
      const v = (T) => Math.min(1, Math.max(0, T));
      (r({ x: v(t.x + E[0]), y: v(t.y + E[1]) }), x(!0));
    };
  return e.jsxs("div", {
    className: "career-map-round",
    children: [
      e.jsx("div", {
        className: "career-map-axis",
        "data-axis": "top",
        "aria-hidden": "true",
        children: "Create",
      }),
      e.jsxs("div", {
        className: "career-map-row",
        children: [
          e.jsx("div", {
            className: "career-map-axis",
            "data-axis": "left",
            "aria-hidden": "true",
            children: "People",
          }),
          e.jsxs("div", {
            ref: i,
            className: "career-map",
            "data-held": l !== null || void 0,
            onPointerDown: (d) => {
              (d.pointerType === "mouse" && d.button !== 0) ||
                (d.currentTarget.setPointerCapture?.(d.pointerId),
                o(d.pointerId),
                j(d.clientX, d.clientY));
            },
            onPointerMove: (d) => {
              l === d.pointerId && j(d.clientX, d.clientY);
            },
            onPointerUp: () => o(null),
            onPointerCancel: () => o(null),
            children: [
              e.jsx(Ar, {}),
              Object.entries(ke).map(([d, C]) =>
                e.jsx(
                  "span",
                  {
                    className: "career-map-corner",
                    "data-corner": d,
                    children: C.label,
                  },
                  d,
                ),
              ),
              e.jsx("button", {
                type: "button",
                className: "career-map-pin",
                style: { left: `${t.x * 100}%`, top: `${t.y * 100}%` },
                "aria-label": "Your pin. Arrow keys move it.",
                onKeyDown: p,
                "data-map-pin": "",
                "data-moved": a || void 0,
                children: "You",
              }),
            ],
          }),
          e.jsx("div", {
            className: "career-map-axis",
            "data-axis": "right",
            "aria-hidden": "true",
            children: "Machines",
          }),
        ],
      }),
      e.jsx("div", {
        className: "career-map-axis",
        "data-axis": "bottom",
        "aria-hidden": "true",
        children: "Protect",
      }),
      e.jsx("button", {
        type: "button",
        className: "careers-button careers-button-primary career-quiz-next",
        onClick: s,
        "data-quiz-finish": "",
        children: "See my match",
      }),
    ],
  });
}
function _r({ answers: t, onRestart: r, link: s }) {
  const [i, ...l] = Tr(t),
    o = l.slice(0, 2);
  return e.jsxs("div", {
    className: "careers",
    "data-careers-view": "quiz-result",
    "data-quiz-match": i.career.id,
    children: [
      e.jsx("div", {
        className: "career-hero",
        children: e.jsx(Lt, {
          career: i.career,
          className: "career-hero-scene",
        }),
      }),
      e.jsxs("div", {
        className: "career-body",
        children: [
          e.jsx("h1", {
            className: "careers-title career-reveal",
            children: i.career.title,
          }),
          e.jsxs("p", {
            className: "career-match career-reveal",
            children: [i.percent, "% match"],
          }),
          e.jsx("p", {
            className: "career-hook career-reveal",
            children: i.career.hook,
          }),
          e.jsx(jr, { career: i.career, readMore: !0 }),
          e.jsxs("section", {
            className: "career-section",
            children: [
              e.jsx("h2", { children: "Also a good fit" }),
              e.jsx("ul", {
                className: "careers-grid",
                children: o.map(({ career: a, percent: x }) =>
                  e.jsx("li", { children: Br(a, x, s) }, a.id),
                ),
              }),
            ],
          }),
          e.jsxs("div", {
            className: "career-actions",
            children: [
              e.jsxs("button", {
                type: "button",
                className: "careers-button careers-button-primary",
                onClick: r,
                children: [e.jsx(gt, { "aria-hidden": "true" }), "Again"],
              }),
              s(
                { view: "hub" },
                { className: "careers-button", children: "All careers" },
              ),
            ],
          }),
        ],
      }),
    ],
  });
}
function Br(t, r, s) {
  return s(
    { view: "career", id: t.id },
    {
      className: "careers-card",
      children: e.jsxs(e.Fragment, {
        children: [
          e.jsx(mt, { career: t, className: "careers-card-face" }),
          e.jsxs("span", {
            className: "careers-card-text",
            children: [
              e.jsx("span", {
                className: "careers-card-title",
                children: t.title,
              }),
              e.jsxs("span", {
                className: "careers-card-unit",
                children: [r, "% match"],
              }),
            ],
          }),
          e.jsx("span", { className: "careers-card-pay", children: Mt(t) }),
        ],
      }),
    },
  );
}
const qr = Object.freeze(
  Object.defineProperty(
    { __proto__: null, CareerQuiz: Zr },
    Symbol.toStringTag,
    { value: "Module" },
  ),
);
export { Zr as C, mt as a, Lt as b, jr as c, qr as d };
