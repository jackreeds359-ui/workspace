import { r as n } from "./react-vendor-BK1G6oO1.js";
const o = "(max-width: 767px) and (orientation: portrait)";
function i() {
  return typeof window < "u" && typeof window.matchMedia == "function"
    ? window.matchMedia(o).matches
    : !1;
}
function s() {
  const [r, a] = n.useState(i);
  return (
    n.useEffect(() => {
      if (typeof window.matchMedia != "function") return;
      const t = window.matchMedia(o),
        e = () => a(t.matches);
      return (
        e(),
        t.addEventListener?.("change", e),
        () => t.removeEventListener?.("change", e)
      );
    }, []),
    r
  );
}
export { s as u };
