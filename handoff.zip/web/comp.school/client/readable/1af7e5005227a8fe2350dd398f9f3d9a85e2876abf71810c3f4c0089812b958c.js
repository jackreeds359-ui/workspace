import { j as e, r as L } from "./react-vendor-BK1G6oO1.js";
import { aq as Xt, aT as Qt } from "./GameNotebook-b0Qw2wzd.js";
import { d as we, K as Jt } from "./keyword-deck-Bo8inXG8.js";
import { u as Zt } from "./use-cover-art-CyGvgy9q.js";
import { u as St } from "./keyword-flashcards-Ha6Msavb.js";
import { I as es } from "./immersive-picker-PA4Q0OWd.js";
import { m as Ft } from "./proxy-DGk2Wawc.js";
import { z as ts, U as ss, Z as rs } from "./ui-components-DeMDYLzO.js";
import "./index-DjyiOHey.js";
const Q = 30,
  tt = 34;
function y(t, s, r = 0) {
  return [(t - s) * Q, ((t + s) * Q) / 2 - r * tt];
}
function M(t, s) {
  const r = Number.parseInt(t.slice(1), 16),
    a = s > 0 ? 255 : 0,
    o = Math.abs(s),
    n = (h) => Math.round(h + (a - h) * o),
    l = n((r >> 16) & 255),
    d = n((r >> 8) & 255),
    c = n(r & 255);
  return `#${((l << 16) | (d << 8) | c).toString(16).padStart(6, "0")}`;
}
function zt(t) {
  return t
    .map(([s, r, a]) => {
      const [o, n] = y(s, r, a);
      return `${o.toFixed(1)},${n.toFixed(1)}`;
    })
    .join(" ");
}
function J({ points: t, fill: s, stroke: r, opacity: a, dash: o }) {
  return e.jsx("polygon", {
    points: zt(t),
    fill: s,
    stroke: r,
    strokeWidth: r ? 1.2 : void 0,
    strokeDasharray: o,
    strokeLinejoin: "round",
    opacity: a,
  });
}
function B({ from: t, to: s, color: r, width: a = 2, dash: o }) {
  const [n, l] = y(...t),
    [d, c] = y(...s);
  return e.jsx("line", {
    x1: n,
    y1: l,
    x2: d,
    y2: c,
    stroke: r,
    strokeWidth: a,
    strokeDasharray: o,
    strokeLinecap: "round",
  });
}
function i({
  x: t,
  y: s,
  z: r = 0,
  w: a,
  d: o,
  h: n,
  color: l,
  top: d,
  left: c,
  right: h,
}) {
  return e.jsxs("g", {
    children: [
      e.jsx(J, {
        points: [
          [t + a, s, r],
          [t + a, s + o, r],
          [t + a, s + o, r + n],
          [t + a, s, r + n],
        ],
        fill: h ?? M(l, -0.24),
      }),
      e.jsx(J, {
        points: [
          [t, s + o, r],
          [t + a, s + o, r],
          [t + a, s + o, r + n],
          [t, s + o, r + n],
        ],
        fill: c ?? M(l, -0.08),
      }),
      e.jsx(J, {
        points: [
          [t, s, r + n],
          [t + a, s, r + n],
          [t + a, s + o, r + n],
          [t, s + o, r + n],
        ],
        fill: d ?? M(l, 0.16),
      }),
    ],
  });
}
function u({ x: t, y: s, z: r, w: a, h: o, children: n }) {
  const [l, d] = y(t, s, r + o);
  return e.jsx("g", {
    transform: `matrix(${(a * Q) / 100} ${(a * Q) / 200} 0 ${(o * tt) / 60} ${l} ${d})`,
    children: n,
  });
}
function G({ x: t, y: s, z: r, d: a, h: o, children: n }) {
  const [l, d] = y(t, s + a, r + o);
  return e.jsx("g", {
    transform: `matrix(${(a * Q) / 100} ${(-a * Q) / 200} 0 ${(o * tt) / 60} ${l} ${d})`,
    children: n,
  });
}
function _e({ x: t, y: s, z: r, w: a, d: o, children: n }) {
  const [l, d] = y(t, s, r);
  return e.jsx("g", {
    transform: `matrix(${(a * Q) / 100} ${(a * Q) / 200} ${(-o * Q) / 100} ${(o * Q) / 200} ${l} ${d})`,
    children: n,
  });
}
function v({ c: t, r: s, plane: r, fill: a, stroke: o, width: n }) {
  const l = [];
  for (let d = 0; d < 28; d++) {
    const c = (d / 28) * Math.PI * 2,
      h = Math.cos(c) * s,
      x = Math.sin(c) * s;
    l.push(
      r === "z"
        ? [t[0] + h, t[1] + x, t[2]]
        : r === "x"
          ? [t[0], t[1] + h, t[2] + x]
          : [t[0] + h, t[1], t[2] + x],
    );
  }
  return e.jsx("polygon", {
    points: zt(l),
    fill: a,
    stroke: o,
    strokeWidth: n,
  });
}
function V({ x: t, y: s, z: r = 0, r: a, h: o, color: n, top: l }) {
  const [d, c] = y(t, s, r),
    [, h] = y(t, s, r + o),
    x = a * Q * Math.SQRT2,
    m = x / 2;
  return e.jsxs("g", {
    children: [
      e.jsx("ellipse", { cx: d, cy: c, rx: x, ry: m, fill: M(n, -0.2) }),
      e.jsx("rect", {
        x: d - x,
        y: h,
        width: x * 2,
        height: c - h,
        fill: M(n, -0.1),
      }),
      e.jsx("ellipse", { cx: d, cy: h, rx: x, ry: m, fill: l ?? M(n, 0.15) }),
    ],
  });
}
function A({ x: t, y: s, z: r = 0, w: a, d: o }) {
  return e.jsx(J, {
    points: [
      [t, s, r],
      [t + a, s, r],
      [t + a, s + o, r],
      [t, s + o, r],
    ],
    fill: "#0f172a",
    opacity: 0.14,
  });
}
const as = ["#f1c9a5", "#d9a57a", "#a8714a", "#7a4b2c"],
  os = ["#2b1d14", "#5b3a24", "#c2873e", "#111827"];
function f({
  x: t,
  y: s,
  z: r = 0,
  shirt: a,
  legs: o = "#334155",
  skin: n = 0,
  hair: l = 0,
  face: d = "y",
  seated: c,
  hood: h,
  phones: x,
  reach: m,
}) {
  const k = d !== "x",
    W = k ? 0.25 : 0.13,
    _ = k ? 0.13 : 0.25,
    p = c ? 0.45 : 0.82,
    E = 0.72,
    K = p + E,
    Z = as[n],
    ye = h ?? os[l];
  return e.jsxs("g", {
    children: [
      c ? null : e.jsx(A, { x: t - 0.3, y: s - 0.3, z: r, w: 0.6, d: 0.6 }),
      c
        ? null
        : k
          ? e.jsxs(e.Fragment, {
              children: [
                e.jsx(i, {
                  x: t - 0.2,
                  y: s - 0.08,
                  z: r,
                  w: 0.17,
                  d: 0.16,
                  h: p,
                  color: o,
                }),
                e.jsx(i, {
                  x: t + 0.03,
                  y: s - 0.08,
                  z: r,
                  w: 0.17,
                  d: 0.16,
                  h: p,
                  color: o,
                }),
              ],
            })
          : e.jsxs(e.Fragment, {
              children: [
                e.jsx(i, {
                  x: t - 0.08,
                  y: s - 0.2,
                  z: r,
                  w: 0.16,
                  d: 0.17,
                  h: p,
                  color: o,
                }),
                e.jsx(i, {
                  x: t - 0.08,
                  y: s + 0.03,
                  z: r,
                  w: 0.16,
                  d: 0.17,
                  h: p,
                  color: o,
                }),
              ],
            }),
      k
        ? e.jsx(i, {
            x: t - W - 0.1,
            y: s - 0.06,
            z: r + p + 0.1,
            w: 0.1,
            d: 0.12,
            h: E - 0.12,
            color: a,
          })
        : e.jsx(i, {
            x: t - 0.06,
            y: s - _ - 0.1,
            z: r + p + 0.1,
            w: 0.12,
            d: 0.1,
            h: E - 0.12,
            color: a,
          }),
      e.jsx(i, {
        x: t - W,
        y: s - _,
        z: r + p,
        w: W * 2,
        d: _ * 2,
        h: E,
        color: a,
      }),
      m
        ? k
          ? e.jsx(i, {
              x: t + W,
              y: s - 0.06,
              z: r + p + E - 0.26,
              w: 0.1,
              d: 0.42,
              h: 0.12,
              color: a,
            })
          : e.jsx(i, {
              x: t - 0.06,
              y: s + _,
              z: r + p + E - 0.26,
              w: 0.42,
              d: 0.1,
              h: 0.12,
              color: a,
            })
        : k
          ? e.jsx(i, {
              x: t + W,
              y: s - 0.06,
              z: r + p + 0.1,
              w: 0.1,
              d: 0.12,
              h: E - 0.12,
              color: a,
            })
          : e.jsx(i, {
              x: t - 0.06,
              y: s + _,
              z: r + p + 0.1,
              w: 0.12,
              d: 0.1,
              h: E - 0.12,
              color: a,
            }),
      e.jsx(i, {
        x: t - 0.08,
        y: s - 0.08,
        z: r + K,
        w: 0.16,
        d: 0.16,
        h: 0.08,
        color: Z,
      }),
      e.jsx(i, {
        x: t - 0.19,
        y: s - 0.19,
        z: r + K + 0.06,
        w: 0.38,
        d: 0.38,
        h: 0.4,
        color: Z,
        left: d === "away" ? ye : M(Z, -0.04),
        right: d === "away" && !k ? ye : M(Z, -0.18),
      }),
      h
        ? e.jsx(i, {
            x: t - 0.23,
            y: s - 0.23,
            z: r + K + 0.36,
            w: 0.46,
            d: 0.46,
            h: 0.16,
            color: h,
          })
        : e.jsx(i, {
            x: t - 0.2,
            y: s - 0.2,
            z: r + K + 0.42,
            w: 0.4,
            d: 0.4,
            h: 0.08,
            color: ye,
          }),
      x
        ? e.jsxs(e.Fragment, {
            children: [
              e.jsx(i, {
                x: t - 0.23,
                y: s - 0.06,
                z: r + K + 0.16,
                w: 0.06,
                d: 0.14,
                h: 0.16,
                color: x,
              }),
              e.jsx(i, {
                x: t + 0.17,
                y: s - 0.06,
                z: r + K + 0.16,
                w: 0.06,
                d: 0.14,
                h: 0.16,
                color: x,
              }),
            ],
          })
        : null,
      d === "y"
        ? e.jsxs(u, {
            x: t - 0.19,
            y: s + 0.19,
            z: r + K + 0.06,
            w: 0.38,
            h: 0.4,
            children: [
              e.jsx("rect", {
                x: 24,
                y: 22,
                width: 12,
                height: 9,
                fill: "#13294b",
              }),
              e.jsx("rect", {
                x: 64,
                y: 22,
                width: 12,
                height: 9,
                fill: "#13294b",
              }),
              e.jsx("rect", {
                x: 38,
                y: 42,
                width: 24,
                height: 4,
                fill: "#13294b",
                opacity: 0.6,
              }),
            ],
          })
        : d === "x"
          ? e.jsxs(G, {
              x: t + 0.19,
              y: s - 0.19,
              z: r + K + 0.06,
              d: 0.38,
              h: 0.4,
              children: [
                e.jsx("rect", {
                  x: 24,
                  y: 22,
                  width: 12,
                  height: 9,
                  fill: "#13294b",
                }),
                e.jsx("rect", {
                  x: 64,
                  y: 22,
                  width: 12,
                  height: 9,
                  fill: "#13294b",
                }),
                e.jsx("rect", {
                  x: 38,
                  y: 42,
                  width: 24,
                  height: 4,
                  fill: "#13294b",
                  opacity: 0.6,
                }),
              ],
            })
          : null,
    ],
  });
}
function P({
  x: t,
  y: s,
  z: r = 0,
  w: a,
  d: o,
  h: n = 0.75,
  color: l = "#b7793f",
}) {
  return e.jsxs("g", {
    children: [
      e.jsx(A, { x: t, y: s, z: r, w: a, d: o }),
      e.jsx(i, {
        x: t + 0.05,
        y: s + 0.05,
        z: r,
        w: 0.1,
        d: 0.1,
        h: n - 0.08,
        color: M(l, -0.2),
      }),
      e.jsx(i, {
        x: t + a - 0.15,
        y: s + 0.05,
        z: r,
        w: 0.1,
        d: 0.1,
        h: n - 0.08,
        color: M(l, -0.2),
      }),
      e.jsx(i, {
        x: t + 0.05,
        y: s + o - 0.15,
        z: r,
        w: 0.1,
        d: 0.1,
        h: n - 0.08,
        color: M(l, -0.2),
      }),
      e.jsx(i, {
        x: t + a - 0.15,
        y: s + o - 0.15,
        z: r,
        w: 0.1,
        d: 0.1,
        h: n - 0.08,
        color: M(l, -0.2),
      }),
      e.jsx(i, { x: t, y: s, z: r + n - 0.08, w: a, d: o, h: 0.08, color: l }),
    ],
  });
}
function se({
  x: t,
  y: s,
  z: r,
  w: a = 1.1,
  h: o = 0.66,
  frame: n = "#0f172a",
  children: l,
}) {
  return e.jsxs("g", {
    children: [
      e.jsx(i, {
        x: t - 0.18,
        y: s - 0.12,
        z: r,
        w: 0.36,
        d: 0.24,
        h: 0.03,
        color: "#475569",
      }),
      e.jsx(i, {
        x: t - 0.04,
        y: s - 0.04,
        z: r + 0.03,
        w: 0.08,
        d: 0.06,
        h: 0.16,
        color: "#475569",
      }),
      e.jsx(i, {
        x: t - a / 2,
        y: s - 0.06,
        z: r + 0.16,
        w: a,
        d: 0.06,
        h: o,
        color: n,
        left: n,
      }),
      e.jsx(u, {
        x: t - a / 2 + 0.04,
        y: s,
        z: r + 0.2,
        w: a - 0.08,
        h: o - 0.08,
        children: l,
      }),
    ],
  });
}
function X({ x: t, y: s, z: r, w: a = 0.8, children: o }) {
  const n = a * 0.62,
    l = a * 0.6;
  return e.jsxs("g", {
    children: [
      e.jsx(i, {
        x: t - a / 2,
        y: s - n / 2,
        z: r,
        w: a,
        d: n,
        h: 0.04,
        color: "#94a3b8",
      }),
      e.jsx(_e, {
        x: t - a / 2 + 0.06,
        y: s - n / 2 + 0.06,
        z: r + 0.041,
        w: a - 0.12,
        d: n - 0.2,
        children: e.jsx("rect", { width: 100, height: 100, fill: "#64748b" }),
      }),
      e.jsx(i, {
        x: t - a / 2,
        y: s - n / 2 - 0.04,
        z: r + 0.04,
        w: a,
        d: 0.04,
        h: l,
        color: "#1f2937",
        left: "#1f2937",
      }),
      e.jsx(u, {
        x: t - a / 2 + 0.04,
        y: s - n / 2,
        z: r + 0.08,
        w: a - 0.08,
        h: l - 0.08,
        children: o,
      }),
    ],
  });
}
function Ke({
  x: t,
  y: s,
  z: r = 0,
  color: a = "#1e293b",
  glow: o = "#22c55e",
}) {
  return e.jsxs("g", {
    children: [
      e.jsx(A, { x: t, y: s, z: r, w: 0.45, d: 0.9 }),
      e.jsx(i, { x: t, y: s, z: r, w: 0.45, d: 0.9, h: 1.05, color: a }),
      e.jsxs(u, {
        x: t,
        y: s + 0.9,
        z: r,
        w: 0.45,
        h: 1.05,
        children: [
          e.jsx("rect", { x: 20, y: 6, width: 60, height: 4, fill: M(a, 0.3) }),
          e.jsx("circle", { cx: 50, cy: 20, r: 5, fill: o }),
          e.jsx("rect", {
            x: 20,
            y: 30,
            width: 60,
            height: 22,
            fill: M(a, -0.3),
          }),
        ],
      }),
      e.jsx(G, {
        x: t + 0.45,
        y: s,
        z: r,
        d: 0.9,
        h: 1.05,
        children: e.jsx("rect", {
          x: 10,
          y: 8,
          width: 80,
          height: 44,
          fill: o,
          opacity: 0.18,
        }),
      }),
    ],
  });
}
function I({ x: t, y: s, color: r = "#334155" }) {
  return e.jsxs("g", {
    children: [
      e.jsx(i, {
        x: t - 0.04,
        y: s - 0.04,
        w: 0.08,
        d: 0.08,
        h: 0.4,
        color: "#475569",
      }),
      e.jsx(i, {
        x: t - 0.26,
        y: s - 0.26,
        z: 0.4,
        w: 0.52,
        d: 0.52,
        h: 0.08,
        color: r,
      }),
    ],
  });
}
function te({ x: t, y: s, z: r = 0, s: a = 1, color: o = "#3f9b4f" }) {
  return e.jsxs("g", {
    children: [
      e.jsx(A, { x: t - 0.5 * a, y: s - 0.5 * a, z: r, w: a, d: a }),
      e.jsx(i, {
        x: t - 0.1 * a,
        y: s - 0.1 * a,
        z: r,
        w: 0.2 * a,
        d: 0.2 * a,
        h: 0.7 * a,
        color: "#7c4a26",
      }),
      e.jsx(i, {
        x: t - 0.45 * a,
        y: s - 0.45 * a,
        z: r + 0.6 * a,
        w: 0.9 * a,
        d: 0.9 * a,
        h: 0.8 * a,
        color: o,
      }),
      e.jsx(i, {
        x: t - 0.28 * a,
        y: s - 0.28 * a,
        z: r + 1.4 * a,
        w: 0.56 * a,
        d: 0.56 * a,
        h: 0.45 * a,
        color: M(o, 0.1),
      }),
    ],
  });
}
function N({ wall: t, a: s, z: r, w: a, h: o, fill: n, frame: l, off: d = 0 }) {
  const c = d + 0.001,
    h =
      t === "y"
        ? [
            [s, c, r],
            [s + a, c, r],
            [s + a, c, r + o],
            [s, c, r + o],
          ]
        : [
            [c, s, r],
            [c, s + a, r],
            [c, s + a, r + o],
            [c, s, r + o],
          ];
  return e.jsx(J, { points: h, fill: n, stroke: l });
}
function is() {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 100, height: 60, fill: "#7dd3fc" }),
      e.jsx("circle", { cx: 78, cy: 16, r: 8, fill: "#fde047" }),
      e.jsx("path", {
        d: "M0 44l22-20 16 12 18-18 26 24 18-10v28H0z",
        fill: "#15803d",
      }),
      e.jsx("path", { d: "M0 52l30-6 30 4 40-8v18H0z", fill: "#a16207" }),
    ],
  });
}
function Be() {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 100, height: 60, fill: "#111827" }),
      e.jsx("g", {
        transform: "translate(6 4) scale(0.88 0.62)",
        children: e.jsx(is, {}),
      }),
      e.jsx("rect", { x: 4, y: 44, width: 92, height: 5, fill: "#1f2937" }),
      e.jsx("rect", { x: 6, y: 44.5, width: 22, height: 4, fill: "#f26b1d" }),
      e.jsx("rect", { x: 30, y: 44.5, width: 30, height: 4, fill: "#60a5fa" }),
      e.jsx("rect", { x: 62, y: 44.5, width: 18, height: 4, fill: "#a78bfa" }),
      e.jsx("rect", { x: 4, y: 51, width: 92, height: 5, fill: "#1f2937" }),
      e.jsx("rect", { x: 14, y: 51.5, width: 40, height: 4, fill: "#34d399" }),
      e.jsx("rect", { x: 46, y: 41, width: 1.6, height: 17, fill: "#f8fafc" }),
    ],
  });
}
function Nt() {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 100, height: 60, fill: "#f8fafc" }),
      e.jsx("rect", { width: 100, height: 10, fill: "#0f766e" }),
      e.jsx("rect", {
        x: 6,
        y: 16,
        width: 18,
        height: 22,
        rx: 2,
        fill: "#cbd5e1",
      }),
      e.jsx("circle", { cx: 15, cy: 24, r: 5, fill: "#94a3b8" }),
      [16, 24, 32, 40, 48].map((t) =>
        e.jsx(
          "rect",
          {
            x: 30,
            y: t,
            width: t === 48 ? 36 : 62,
            height: 3,
            rx: 1.5,
            fill: "#94a3b8",
          },
          t,
        ),
      ),
    ],
  });
}
function Ce() {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 100, height: 60, fill: "#312e81" }),
      e.jsx("path", {
        d: "M0 42l20-16 18 12 22-22 22 18 18-8v34H0z",
        fill: "#4338ca",
      }),
      e.jsx("path", { d: "M0 50l100-6v16H0z", fill: "#1e1b4b" }),
      e.jsx("circle", {
        cx: 50,
        cy: 30,
        r: 7,
        fill: "none",
        stroke: "#f8fafc",
        strokeWidth: 1.5,
      }),
      e.jsx("path", {
        d: "M50 19v6M50 35v6M39 30h6M55 30h6",
        stroke: "#f8fafc",
        strokeWidth: 1.5,
      }),
      e.jsx("rect", {
        x: 4,
        y: 4,
        width: 30,
        height: 4,
        rx: 2,
        fill: "#22c55e",
      }),
    ],
  });
}
function Ze() {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 100, height: 60, fill: "#0c4a6e" }),
      e.jsx("path", {
        d: "M10 14q20-8 40 2t40-4v40q-30 10-50 2t-30 4z",
        fill: "#e0f2fe",
      }),
      e.jsx("path", {
        d: "M30 24q10-4 20 2t20-2",
        fill: "none",
        stroke: "#38bdf8",
        strokeWidth: 2,
      }),
      e.jsx("path", {
        d: "M6 50l14-10 12 6 16-12 18 10 14-6 14 8",
        fill: "none",
        stroke: "#f26b1d",
        strokeWidth: 2,
      }),
    ],
  });
}
function Pt({ id: t, x: s, y: r, z: a }) {
  switch (t) {
    case "ram8":
    case "ram16":
    case "ram32": {
      const o = t === "ram8" ? 1 : t === "ram16" ? 2 : 4;
      return e.jsx("g", {
        "data-scene-part": t,
        children: Array.from({ length: o }, (n, l) =>
          e.jsxs(
            "g",
            {
              children: [
                e.jsx(i, {
                  x: s,
                  y: r + l * 0.13,
                  z: a,
                  w: 0.6,
                  d: 0.09,
                  h: 0.05,
                  color: "#15803d",
                }),
                [0.06, 0.2, 0.34, 0.48].map((d) =>
                  e.jsx(
                    i,
                    {
                      x: s + d,
                      y: r + l * 0.13 + 0.015,
                      z: a + 0.05,
                      w: 0.08,
                      d: 0.06,
                      h: 0.02,
                      color: "#111827",
                    },
                    d,
                  ),
                ),
              ],
            },
            l,
          ),
        ),
      });
    }
    case "ssd":
      return e.jsxs("g", {
        "data-scene-part": t,
        children: [
          e.jsx(i, {
            x: s,
            y: r,
            z: a,
            w: 0.42,
            d: 0.3,
            h: 0.06,
            color: "#1e293b",
          }),
          e.jsxs(_e, {
            x: s + 0.06,
            y: r + 0.06,
            z: a + 0.061,
            w: 0.3,
            d: 0.18,
            children: [
              e.jsx("rect", { width: 100, height: 100, fill: "#1f4fbf" }),
              e.jsx("rect", {
                x: 10,
                y: 30,
                width: 60,
                height: 14,
                fill: "#e2e8f0",
              }),
            ],
          }),
        ],
      });
    case "hdd":
      return e.jsxs("g", {
        "data-scene-part": t,
        children: [
          e.jsx(i, {
            x: s,
            y: r,
            z: a,
            w: 0.5,
            d: 0.36,
            h: 0.12,
            color: "#cbd5e1",
          }),
          e.jsx(v, {
            c: [s + 0.22, r + 0.18, a + 0.121],
            r: 0.13,
            plane: "z",
            fill: "#94a3b8",
          }),
          e.jsx(B, {
            from: [s + 0.22, r + 0.18, a + 0.125],
            to: [s + 0.42, r + 0.06, a + 0.125],
            color: "#475569",
            width: 1.5,
          }),
        ],
      });
    case "ext_hdd":
      return e.jsxs("g", {
        "data-scene-part": t,
        children: [
          e.jsx(i, {
            x: s,
            y: r,
            z: a,
            w: 0.34,
            d: 0.48,
            h: 0.16,
            color: "#111827",
          }),
          e.jsx(u, {
            x: s,
            y: r + 0.48,
            z: a,
            w: 0.34,
            h: 0.16,
            children: e.jsx("circle", {
              cx: 80,
              cy: 30,
              r: 9,
              fill: "#22c55e",
            }),
          }),
        ],
      });
    case "tape":
      return e.jsxs("g", {
        "data-scene-part": t,
        children: [
          e.jsx(i, {
            x: s,
            y: r,
            z: a,
            w: 0.56,
            d: 0.42,
            h: 0.24,
            color: "#475569",
          }),
          e.jsxs(u, {
            x: s,
            y: r + 0.42,
            z: a,
            w: 0.56,
            h: 0.24,
            children: [
              e.jsx("rect", {
                x: 14,
                y: 22,
                width: 50,
                height: 10,
                fill: "#0f172a",
              }),
              e.jsx("circle", { cx: 84, cy: 27, r: 6, fill: "#22c55e" }),
            ],
          }),
          e.jsx(i, {
            x: s + 0.08,
            y: r + 0.08,
            z: a + 0.24,
            w: 0.32,
            d: 0.24,
            h: 0.07,
            color: "#1f4fbf",
          }),
        ],
      });
    case "bluray":
      return e.jsxs("g", {
        "data-scene-part": t,
        children: [
          e.jsx(i, {
            x: s,
            y: r,
            z: a,
            w: 0.56,
            d: 0.46,
            h: 0.1,
            color: "#e2e8f0",
          }),
          e.jsx(v, {
            c: [s + 0.28, r + 0.24, a + 0.101],
            r: 0.17,
            plane: "z",
            fill: "#60a5fa",
          }),
          e.jsx(v, {
            c: [s + 0.28, r + 0.24, a + 0.102],
            r: 0.04,
            plane: "z",
            fill: "#e2e8f0",
          }),
        ],
      });
    case "usb":
      return e.jsxs("g", {
        "data-scene-part": t,
        children: [
          e.jsx(i, {
            x: s,
            y: r,
            z: a,
            w: 0.26,
            d: 0.09,
            h: 0.05,
            color: "#1f4fbf",
          }),
          e.jsx(i, {
            x: s + 0.26,
            y: r + 0.015,
            z: a + 0.005,
            w: 0.08,
            d: 0.06,
            h: 0.035,
            color: "#cbd5e1",
          }),
        ],
      });
    case "sd":
      return e.jsx("g", {
        "data-scene-part": t,
        children: [0, 1, 2, 3].map((o) =>
          e.jsx(
            i,
            {
              x: s + o * 0.13,
              y: r + (o % 2) * 0.05,
              z: a,
              w: 0.11,
              d: 0.14,
              h: 0.02,
              color: "#f26b1d",
            },
            o,
          ),
        ),
      });
    case "ext_ssd":
      return e.jsxs("g", {
        "data-scene-part": t,
        children: [
          e.jsx(i, {
            x: s,
            y: r,
            z: a,
            w: 0.3,
            d: 0.22,
            h: 0.08,
            color: "#f26b1d",
          }),
          e.jsx(_e, {
            x: s + 0.05,
            y: r + 0.05,
            z: a + 0.081,
            w: 0.2,
            d: 0.12,
            children: e.jsx("rect", {
              x: 20,
              y: 30,
              width: 60,
              height: 30,
              fill: "#fde3d2",
            }),
          }),
        ],
      });
  }
}
function ns(t, s, r, a = 0.5) {
  const [o, n, l, d] = t.split(" ").map(Number),
    c = s.map((p) => y(...p)[0]),
    h = Math.min(...c) - 44,
    x = Math.max(...c) + 44,
    m = Math.min(l, Math.max(x - h, d * r)),
    k = Math.max(d, m / r),
    W = Math.min(Math.max((h + x) / 2 - m / 2, o), o + l - m),
    _ = n - (k - d) * a;
  return [W, _, m, k].map((p) => Math.round(p * 10) / 10);
}
const At = {
  ram8: [0.6, 0.09, 0.07],
  ram16: [0.6, 0.22, 0.07],
  ram32: [0.6, 0.48, 0.07],
  ssd: [0.42, 0.3, 0.062],
  hdd: [0.5, 0.36, 0.126],
  ext_hdd: [0.34, 0.48, 0.16],
  tape: [0.56, 0.42, 0.31],
  bluray: [0.56, 0.46, 0.103],
  usb: [0.34, 0.09, 0.05],
  sd: [0.5, 0.19, 0.02],
  ext_ssd: [0.3, 0.22, 0.082],
};
function ls(t) {
  const [s, r, a] = At[t],
    o = [0, s].flatMap((m) =>
      [0, r].flatMap((k) => [0, a].map((W) => y(m, k, W))),
    ),
    n = o.map(([m]) => m),
    l = o.map(([, m]) => m),
    d = (Math.min(...n) + Math.max(...n)) / 2,
    c = (Math.min(...l) + Math.max(...l)) / 2,
    h =
      Math.max(
        Math.max(...n) - Math.min(...n),
        Math.max(...l) - Math.min(...l),
      ) * 1.18,
    x = (m) => Math.round(m * 100) / 100;
  return `${x(d - h / 2)} ${x(c - h / 2)} ${x(h)} ${x(h)}`;
}
const C = "#13294b",
  he = "#1f4fbf",
  H = "#dbe4fb",
  R = "#f26b1d",
  O = "#fffdf7",
  S = {
    stroke: he,
    strokeWidth: 2.5,
    strokeLinejoin: "round",
    strokeLinecap: "round",
  };
function Rt({ id: t, className: s }) {
  return e.jsx("svg", {
    viewBox: "0 0 64 64",
    className: s,
    "aria-hidden": "true",
    children:
      t === "film"
        ? e.jsxs(e.Fragment, {
            children: [
              e.jsx("rect", {
                x: "6",
                y: "24",
                width: "36",
                height: "26",
                rx: "4",
                fill: C,
              }),
              e.jsx("path", { d: "M42 30 58 22v30l-16-8z", fill: R }),
              e.jsx("circle", {
                cx: "16",
                cy: "15",
                r: "8",
                fill: "none",
                stroke: C,
                strokeWidth: "3.5",
              }),
              e.jsx("circle", {
                cx: "33",
                cy: "15",
                r: "8",
                fill: "none",
                stroke: C,
                strokeWidth: "3.5",
              }),
            ],
          })
        : t === "hospital"
          ? e.jsxs(e.Fragment, {
              children: [
                e.jsx("rect", {
                  x: "8",
                  y: "8",
                  width: "48",
                  height: "48",
                  rx: "8",
                  fill: he,
                }),
                e.jsx("rect", {
                  x: "27",
                  y: "17",
                  width: "10",
                  height: "30",
                  rx: "1",
                  fill: O,
                }),
                e.jsx("rect", {
                  x: "17",
                  y: "27",
                  width: "30",
                  height: "10",
                  rx: "1",
                  fill: O,
                }),
              ],
            })
          : t === "esports"
            ? e.jsxs(e.Fragment, {
                children: [
                  e.jsx("path", {
                    d: "M14 18h36a10 10 0 0 1 10 11l-3 15a6 6 0 0 1-11 2l-5-7H23l-5 7a6 6 0 0 1-11-2L4 29a10 10 0 0 1 10-11z",
                    fill: C,
                  }),
                  e.jsx("rect", {
                    x: "13",
                    y: "27",
                    width: "12",
                    height: "4",
                    fill: O,
                  }),
                  e.jsx("rect", {
                    x: "17",
                    y: "23",
                    width: "4",
                    height: "12",
                    fill: O,
                  }),
                  e.jsx("circle", { cx: "44", cy: "27", r: "3.5", fill: R }),
                  e.jsx("circle", { cx: "51", cy: "33", r: "3.5", fill: R }),
                ],
              })
            : t === "finance"
              ? e.jsxs(e.Fragment, {
                  children: [
                    e.jsx("rect", {
                      x: "6",
                      y: "40",
                      width: "10",
                      height: "16",
                      fill: he,
                    }),
                    e.jsx("rect", {
                      x: "21",
                      y: "30",
                      width: "10",
                      height: "26",
                      fill: he,
                    }),
                    e.jsx("rect", {
                      x: "36",
                      y: "20",
                      width: "10",
                      height: "36",
                      fill: C,
                    }),
                    e.jsx("path", {
                      d: "M6 30 22 18l10 6 22-16",
                      fill: "none",
                      stroke: R,
                      strokeWidth: "4",
                      strokeLinecap: "round",
                      strokeLinejoin: "round",
                    }),
                    e.jsx("path", {
                      d: "M46 8h8v8",
                      fill: "none",
                      stroke: R,
                      strokeWidth: "4",
                      strokeLinecap: "round",
                      strokeLinejoin: "round",
                    }),
                    e.jsx("rect", {
                      x: "4",
                      y: "56",
                      width: "56",
                      height: "3",
                      fill: C,
                    }),
                  ],
                })
              : e.jsxs(e.Fragment, {
                  children: [
                    e.jsx("path", {
                      d: "M32 6 60 56H4z",
                      fill: H,
                      stroke: C,
                      strokeWidth: "3",
                      strokeLinejoin: "round",
                    }),
                    e.jsx("path", {
                      d: "M32 6 42 24l-6-3-4 5-4-5-6 3z",
                      fill: O,
                      stroke: C,
                      strokeWidth: "2",
                      strokeLinejoin: "round",
                    }),
                    e.jsx("circle", { cx: "50", cy: "14", r: "5", fill: R }),
                  ],
                }),
  });
}
function Me({ id: t, className: s }) {
  const [r, a] = At[t];
  return e.jsxs("svg", {
    viewBox: ls(t),
    className: s,
    "aria-hidden": "true",
    "data-part-art": t,
    children: [
      e.jsx(A, { x: 0.02, y: 0.02, w: r, d: a }),
      e.jsx(Pt, { id: t, x: 0, y: 0, z: 0 }),
    ],
  });
}
function cs({ kind: t }) {
  switch (t) {
    case "multitask":
      return e.jsxs(e.Fragment, {
        children: [
          e.jsx("rect", {
            x: "22",
            y: "8",
            width: "34",
            height: "26",
            rx: "2",
            fill: O,
            ...S,
          }),
          e.jsx("rect", {
            x: "15",
            y: "18",
            width: "34",
            height: "26",
            rx: "2",
            fill: O,
            ...S,
          }),
          e.jsx("rect", {
            x: "8",
            y: "28",
            width: "34",
            height: "26",
            rx: "2",
            fill: H,
            ...S,
          }),
          e.jsx("path", { d: "M8 34h34", ...S }),
          e.jsx("circle", { cx: "50", cy: "52", r: "7", fill: R }),
        ],
      });
    case "heavy":
      return e.jsxs(e.Fragment, {
        children: [
          e.jsx("rect", {
            x: "8",
            y: "14",
            width: "48",
            height: "36",
            rx: "2",
            fill: C,
          }),
          [0, 1, 2, 3, 4, 5].map((s) =>
            e.jsxs(
              "g",
              {
                fill: O,
                children: [
                  e.jsx("rect", {
                    x: 11 + s * 7.5,
                    y: "17",
                    width: "4",
                    height: "4",
                  }),
                  e.jsx("rect", {
                    x: 11 + s * 7.5,
                    y: "43",
                    width: "4",
                    height: "4",
                  }),
                ],
              },
              s,
            ),
          ),
          e.jsx("rect", {
            x: "14",
            y: "24",
            width: "36",
            height: "16",
            fill: H,
          }),
          e.jsx("path", { d: "M28 27v10l9-5z", fill: R }),
        ],
      });
    case "knock":
      return e.jsxs(e.Fragment, {
        children: [
          e.jsxs("g", {
            transform: "rotate(-24 30 26)",
            children: [
              e.jsx("rect", {
                x: "12",
                y: "14",
                width: "34",
                height: "22",
                rx: "2",
                fill: H,
                ...S,
              }),
              e.jsx("path", { d: "M8 38h42", ...S, strokeWidth: "3.5" }),
            ],
          }),
          e.jsx("path", { d: "M6 56h52", ...S, stroke: C }),
          e.jsx("path", {
            d: "M44 46l4 6M50 44l6 3M38 48l1 6",
            stroke: R,
            strokeWidth: "3",
            strokeLinecap: "round",
          }),
        ],
      });
    case "magnet":
      return e.jsxs(e.Fragment, {
        children: [
          e.jsx("path", {
            d: "M14 10v22a18 18 0 0 0 36 0V10H38v22a6 6 0 0 1-12 0V10z",
            fill: H,
            ...S,
          }),
          e.jsx("rect", {
            x: "14",
            y: "10",
            width: "12",
            height: "8",
            fill: R,
          }),
          e.jsx("rect", {
            x: "38",
            y: "10",
            width: "12",
            height: "8",
            fill: he,
          }),
          e.jsx("path", {
            d: "M4 34c4-3 4 3 8 0M52 34c4-3 4 3 8 0",
            stroke: R,
            strokeWidth: "2",
            fill: "none",
          }),
        ],
      });
    case "speed":
      return e.jsxs(e.Fragment, {
        children: [
          e.jsx("circle", { cx: "32", cy: "36", r: "20", fill: O, ...S }),
          e.jsx("rect", {
            x: "27",
            y: "8",
            width: "10",
            height: "6",
            fill: he,
          }),
          e.jsx("path", {
            d: "M32 36l10-10",
            stroke: R,
            strokeWidth: "3.5",
            strokeLinecap: "round",
          }),
          e.jsx("circle", { cx: "32", cy: "36", r: "3", fill: C }),
        ],
      });
    case "capacity":
      return e.jsxs(e.Fragment, {
        children: [
          e.jsx("rect", {
            x: "8",
            y: "38",
            width: "48",
            height: "16",
            rx: "2",
            fill: H,
            ...S,
          }),
          e.jsx("rect", {
            x: "12",
            y: "22",
            width: "40",
            height: "16",
            rx: "2",
            fill: H,
            ...S,
          }),
          e.jsx("rect", {
            x: "16",
            y: "6",
            width: "32",
            height: "16",
            rx: "2",
            fill: O,
            ...S,
          }),
          e.jsx("path", { d: "M22 46h10M22 30h10M24 14h10", ...S }),
          e.jsx("circle", { cx: "48", cy: "14", r: "3", fill: R }),
        ],
      });
    case "carry":
      return e.jsxs(e.Fragment, {
        children: [
          e.jsx("rect", {
            x: "10",
            y: "16",
            width: "44",
            height: "38",
            rx: "6",
            fill: H,
            ...S,
          }),
          e.jsx("path", {
            d: "M24 16v-4a8 8 0 0 1 16 0v4",
            ...S,
            fill: "none",
          }),
          e.jsx("rect", {
            x: "10",
            y: "30",
            width: "44",
            height: "8",
            fill: he,
          }),
          e.jsx("rect", {
            x: "28",
            y: "28",
            width: "8",
            height: "12",
            rx: "2",
            fill: R,
          }),
        ],
      });
    case "archive":
      return e.jsxs(e.Fragment, {
        children: [
          e.jsx("path", { d: "M6 22h52M6 42h52M6 58h52", ...S, stroke: C }),
          [0, 1, 2, 3, 4].map((s) =>
            e.jsx(
              "rect",
              {
                x: 9 + s * 10,
                y: "8",
                width: "8",
                height: "14",
                fill: s === 2 ? R : H,
                ...S,
                strokeWidth: "1.8",
              },
              s,
            ),
          ),
          [0, 1, 2, 3, 4].map((s) =>
            e.jsx(
              "rect",
              {
                x: 9 + s * 10,
                y: "28",
                width: "8",
                height: "14",
                fill: H,
                ...S,
                strokeWidth: "1.8",
              },
              s,
            ),
          ),
        ],
      });
    case "failure":
      return e.jsxs(e.Fragment, {
        children: [
          e.jsx("rect", {
            x: "8",
            y: "10",
            width: "48",
            height: "44",
            rx: "4",
            fill: O,
            ...S,
          }),
          e.jsx("circle", { cx: "30", cy: "32", r: "14", fill: H, ...S }),
          e.jsx("path", {
            d: "M40 8 32 26l8 4-10 26",
            stroke: R,
            strokeWidth: "3.5",
            fill: "none",
            strokeLinejoin: "round",
          }),
        ],
      });
    case "bulk":
      return e.jsxs(e.Fragment, {
        children: [
          [0, 1, 2].map((s) =>
            e.jsx(
              "ellipse",
              {
                cx: 32,
                cy: 46 - s * 10,
                rx: "24",
                ry: "8",
                fill: s === 2 ? H : O,
                ...S,
              },
              s,
            ),
          ),
          e.jsx("ellipse", { cx: "32", cy: "26", rx: "5", ry: "1.8", fill: R }),
        ],
      });
  }
}
function $t({ kind: t, className: s }) {
  return e.jsx("svg", {
    viewBox: "0 0 64 64",
    className: s,
    "aria-hidden": "true",
    children: e.jsx(cs, { kind: t }),
  });
}
function Wt({ className: t }) {
  return e.jsxs("svg", {
    viewBox: "0 0 64 64",
    className: t,
    "aria-hidden": "true",
    children: [
      e.jsx("rect", {
        x: "14",
        y: "6",
        width: "36",
        height: "52",
        rx: "4",
        fill: H,
        ...S,
      }),
      e.jsx("rect", { x: "19", y: "11", width: "26", height: "11", fill: C }),
      e.jsx("path", { d: "M38 19h4", stroke: R, strokeWidth: "2" }),
      [0, 1, 2].map((s) =>
        [0, 1, 2].map((r) =>
          e.jsx(
            "rect",
            {
              x: 19 + r * 9,
              y: 27 + s * 9,
              width: "7",
              height: "7",
              rx: "1",
              fill: s === 2 && r === 2 ? R : O,
              stroke: he,
              strokeWidth: "1.5",
            },
            `${s}-${r}`,
          ),
        ),
      ),
    ],
  });
}
const Lt = "'IBM Plex Mono', ui-monospace, monospace";
function Re({ build: t, spots: s }) {
  return e.jsx(e.Fragment, {
    children: Object.keys(s).map((r) => {
      const a = t[r];
      if (!a) return null;
      const [o, n, l] = s[r];
      return e.jsx(Pt, { id: a, x: o, y: n, z: l }, r);
    }),
  });
}
function $e({ from: t, to: s, id: r }) {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("defs", {
        children: e.jsxs("linearGradient", {
          id: r,
          x1: "0",
          y1: "0",
          x2: "0",
          y2: "1",
          children: [
            e.jsx("stop", { offset: "0", stopColor: t }),
            e.jsx("stop", { offset: "1", stopColor: s }),
          ],
        }),
      }),
      e.jsx("rect", {
        x: -2e3,
        y: -2e3,
        width: 4e3,
        height: 4e3,
        fill: `url(#${r})`,
      }),
    ],
  });
}
function st({
  w: t,
  d: s,
  wall: r,
  floor: a,
  left: o,
  right: n,
  tiles: l = !0,
}) {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx(i, {
        x: 0,
        y: 0,
        z: -0.35,
        w: t,
        d: s,
        h: 0.35,
        color: M(a, -0.3),
      }),
      e.jsx(J, {
        points: [
          [0, 0, 0],
          [t, 0, 0],
          [t, s, 0],
          [0, s, 0],
        ],
        fill: a,
      }),
      l
        ? Array.from({ length: Math.max(t, s) - 1 }, (d, c) =>
            e.jsxs(
              "g",
              {
                children: [
                  c + 1 < t
                    ? e.jsx(B, {
                        from: [c + 1, 0, 0],
                        to: [c + 1, s, 0],
                        color: M(a, -0.08),
                        width: 1,
                      })
                    : null,
                  c + 1 < s
                    ? e.jsx(B, {
                        from: [0, c + 1, 0],
                        to: [t, c + 1, 0],
                        color: M(a, -0.08),
                        width: 1,
                      })
                    : null,
                ],
              },
              c,
            ),
          )
        : null,
      e.jsx(i, {
        x: -0.2,
        y: 0,
        z: -0.35,
        w: 0.2,
        d: s,
        h: r + 0.35,
        color: o,
        right: o,
        top: M(o, -0.35),
      }),
      e.jsx(i, {
        x: -0.2,
        y: -0.2,
        z: -0.35,
        w: t + 0.2,
        d: 0.2,
        h: r + 0.35,
        color: n,
        left: n,
        top: M(n, -0.35),
      }),
    ],
  });
}
const ds = {
    ram: [2.35, 4.38, 0.8],
    main: [2.35, 4.95, 0.8],
    backup: [3, 4.38, 0.8],
    portable: [2.9, 5.14, 0.8],
    optical: [3.38, 4.85, 0.8],
  },
  hs = {
    viewBox: "-225 -85 520 330",
    backdrop: e.jsxs(e.Fragment, {
      children: [
        e.jsx($e, { id: "si-sky-film", from: "#9fd8f6", to: "#e8f6fd" }),
        e.jsx("circle", { cx: 210, cy: -60, r: 22, fill: "#fde047" }),
        e.jsx("path", {
          d: "M-400 40q120-110 240-40t220-30t200 20t200-10v200h-860z",
          fill: "#a7d3a0",
        }),
        e.jsx("path", {
          d: "M-400 70q150-60 300-10t300-20t300 10v200h-900z",
          fill: "#8fc488",
        }),
      ],
    }),
    draw: (t) =>
      e.jsxs(e.Fragment, {
        children: [
          e.jsx(i, {
            x: 0,
            y: 0,
            z: -0.7,
            w: 9,
            d: 7,
            h: 0.7,
            color: "#86c46f",
            top: "#86c46f",
            left: "#9a6b3c",
            right: "#7c5530",
          }),
          e.jsx(J, {
            points: [
              [0, 5.6, 0.002],
              [9, 4.6, 0.002],
              [9, 5.6, 0.002],
              [0, 6.6, 0.002],
            ],
            fill: "#d9b27c",
          }),
          e.jsx(te, { x: 0.7, y: 0.8 }),
          e.jsx(te, { x: 0.6, y: 2.3, s: 0.8 }),
          e.jsx(te, { x: 2, y: 0.6, s: 0.9 }),
          e.jsx(A, { x: 3.3, y: 0.5, w: 2.8, d: 1.3 }),
          e.jsx(i, {
            x: 3.4,
            y: 0.5,
            z: 0.2,
            w: 2.6,
            d: 1.2,
            h: 1.25,
            color: "#f8fafc",
          }),
          e.jsxs(u, {
            x: 3.4,
            y: 1.7,
            z: 0.2,
            w: 2.6,
            h: 1.25,
            children: [
              e.jsx("rect", {
                x: 0,
                y: 30,
                width: 100,
                height: 8,
                fill: "#f26b1d",
              }),
              e.jsx("rect", {
                x: 6,
                y: 8,
                width: 26,
                height: 16,
                fill: "#7dd3fc",
              }),
            ],
          }),
          e.jsxs(G, {
            x: 6,
            y: 0.5,
            z: 0.2,
            d: 1.2,
            h: 1.25,
            children: [
              e.jsx("rect", {
                x: 10,
                y: 8,
                width: 80,
                height: 20,
                fill: "#7dd3fc",
              }),
              e.jsx("rect", {
                x: 10,
                y: 44,
                width: 20,
                height: 8,
                fill: "#fde047",
              }),
              e.jsx("rect", {
                x: 70,
                y: 44,
                width: 20,
                height: 8,
                fill: "#fde047",
              }),
            ],
          }),
          e.jsx(v, {
            c: [3.95, 1.71, 0.2],
            r: 0.2,
            plane: "y",
            fill: "#1f2937",
          }),
          e.jsx(v, {
            c: [5.45, 1.71, 0.2],
            r: 0.2,
            plane: "y",
            fill: "#1f2937",
          }),
          e.jsx(te, { x: 8.2, y: 0.9 }),
          e.jsx(te, { x: 7.3, y: 0.5, s: 0.7 }),
          e.jsx(f, {
            x: 6.25,
            y: 2,
            shirt: "#1f4fbf",
            skin: 0,
            hair: 2,
            face: "y",
          }),
          e.jsx(B, {
            from: [6.2, 2.6, 1.25],
            to: [5.85, 2.3, 0],
            color: "#334155",
            width: 2.5,
          }),
          e.jsx(B, {
            from: [6.2, 2.6, 1.25],
            to: [6.6, 2.45, 0],
            color: "#334155",
            width: 2.5,
          }),
          e.jsx(B, {
            from: [6.2, 2.6, 1.25],
            to: [6.2, 3.05, 0],
            color: "#334155",
            width: 2.5,
          }),
          e.jsx(i, {
            x: 5.95,
            y: 2.42,
            z: 1.25,
            w: 0.5,
            d: 0.36,
            h: 0.32,
            color: "#1f2937",
          }),
          e.jsx(i, {
            x: 6.1,
            y: 2.78,
            z: 1.3,
            w: 0.2,
            d: 0.2,
            h: 0.2,
            color: "#475569",
          }),
          e.jsx(v, {
            c: [6.08, 2.55, 1.75],
            r: 0.13,
            plane: "x",
            fill: "none",
            stroke: "#1f2937",
            width: 3,
          }),
          e.jsx(v, {
            c: [6.32, 2.55, 1.75],
            r: 0.13,
            plane: "x",
            fill: "none",
            stroke: "#1f2937",
            width: 3,
          }),
          e.jsx(B, {
            from: [8, 4, 0],
            to: [8, 4, 1],
            color: "#475569",
            width: 2,
          }),
          e.jsx(v, {
            c: [8, 4, 1.45],
            r: 0.5,
            plane: "x",
            fill: "#f8fafc",
            stroke: "#cbd5e1",
            width: 2,
          }),
          e.jsx(P, {
            x: 1.2,
            y: 4.3,
            w: 2.8,
            d: 1.1,
            h: 0.8,
            color: "#64748b",
          }),
          e.jsx(V, { x: 1.35, y: 5.3, r: 0.09, h: 0.1, color: "#111827" }),
          e.jsx(V, { x: 3.85, y: 5.3, r: 0.09, h: 0.1, color: "#111827" }),
          e.jsx(X, { x: 1.75, y: 4.85, z: 0.8, children: e.jsx(Be, {}) }),
          e.jsx(Re, { build: t, spots: ds }),
          e.jsx(f, {
            x: 6.6,
            y: 5,
            shirt: "#f26b1d",
            skin: 2,
            hair: 3,
            legs: "#1e3a5f",
            face: "y",
            phones: "#1f2937",
          }),
        ],
      }),
    hot: [1.75, 4.85, 0.8],
    pins: [
      [1.75, 4.6, 1.6],
      [4.7, 1.1, 1.75],
      [1.3, 5.4, 1],
    ],
  },
  xs = {
    ram: [4.1, 3.48, 0.85],
    main: [4.1, 4, 0.85],
    backup: [3.3, 3.95, 0.36],
    portable: [4.75, 4.05, 0.85],
    optical: [4.3, 3.95, 0.36],
  },
  fs = {
    viewBox: "-252 -115 504 372",
    backdrop: e.jsx($e, {
      id: "si-sky-hospital",
      from: "#e6f4f1",
      to: "#f8fbfa",
    }),
    draw: (t) =>
      e.jsxs(e.Fragment, {
        children: [
          e.jsx(st, {
            w: 8,
            d: 8,
            wall: 3,
            floor: "#d6e2e8",
            left: "#c4e3de",
            right: "#d9eeea",
          }),
          e.jsx(N, {
            wall: "y",
            a: 1,
            z: 1.2,
            w: 1.6,
            h: 1.2,
            fill: "#bae6fd",
            frame: "#94a3b8",
          }),
          e.jsx(N, {
            wall: "x",
            a: 5.2,
            z: 0,
            w: 1.2,
            h: 2.2,
            fill: "#94a3b8",
            frame: "#64748b",
          }),
          e.jsx(N, {
            wall: "y",
            a: 6,
            z: 2.4,
            w: 0.5,
            h: 0.45,
            fill: "#facc15",
            frame: "#13294b",
          }),
          e.jsx(i, {
            x: 0.05,
            y: 0.5,
            w: 0.6,
            d: 1.2,
            h: 1.6,
            color: "#94a3b8",
          }),
          e.jsx(G, {
            x: 0.65,
            y: 0.5,
            z: 0,
            d: 1.2,
            h: 1.6,
            children: [6, 26, 46].map((s) =>
              e.jsxs(
                "g",
                {
                  children: [
                    e.jsx("rect", {
                      x: 8,
                      y: s,
                      width: 84,
                      height: 14,
                      fill: "#cbd5e1",
                    }),
                    e.jsx("rect", {
                      x: 40,
                      y: s + 5,
                      width: 20,
                      height: 4,
                      fill: "#475569",
                    }),
                  ],
                },
                s,
              ),
            ),
          }),
          e.jsx(A, { x: 4.5, y: 0.3, w: 2.8, d: 1.8 }),
          e.jsx(i, {
            x: 4.6,
            y: 0.4,
            w: 2.6,
            d: 1.6,
            h: 2.2,
            color: "#e2e8f0",
          }),
          e.jsx(v, {
            c: [5.9, 2.001, 1.1],
            r: 0.85,
            plane: "y",
            fill: "#f8fafc",
            stroke: "#94a3b8",
            width: 4,
          }),
          e.jsx(v, {
            c: [5.9, 2.002, 1.1],
            r: 0.42,
            plane: "y",
            fill: "#334155",
          }),
          e.jsx(i, {
            x: 5.35,
            y: 2,
            z: 0.5,
            w: 1.1,
            d: 1.5,
            h: 0.16,
            color: "#cbd5e1",
          }),
          e.jsx(i, {
            x: 5.75,
            y: 2.4,
            w: 0.3,
            d: 0.8,
            h: 0.5,
            color: "#94a3b8",
          }),
          e.jsx(i, {
            x: 0.4,
            y: 2.6,
            w: 1.1,
            d: 2.2,
            h: 0.55,
            color: "#f1f5f9",
          }),
          e.jsx(i, {
            x: 0.45,
            y: 2.65,
            z: 0.55,
            w: 1,
            d: 0.45,
            h: 0.14,
            color: "#e0f2fe",
          }),
          e.jsx(i, {
            x: 0.8,
            y: 2.72,
            z: 0.69,
            w: 0.32,
            d: 0.3,
            h: 0.26,
            color: "#d9a57a",
          }),
          e.jsx(i, {
            x: 0.45,
            y: 3.2,
            z: 0.55,
            w: 1,
            d: 1.55,
            h: 0.12,
            color: "#93c5fd",
          }),
          e.jsx(B, {
            from: [1.9, 2.4, 0],
            to: [1.9, 2.4, 1.3],
            color: "#94a3b8",
            width: 2,
          }),
          e.jsx(i, {
            x: 1.65,
            y: 2.3,
            z: 1.3,
            w: 0.5,
            d: 0.1,
            h: 0.36,
            color: "#0f172a",
            left: "#0f172a",
          }),
          e.jsx(u, {
            x: 1.68,
            y: 2.4,
            z: 1.33,
            w: 0.44,
            h: 0.3,
            children: e.jsx("path", {
              d: "M4 34h22l6-16 10 30 8-20 6 6h40",
              fill: "none",
              stroke: "#34d399",
              strokeWidth: 5,
            }),
          }),
          e.jsx(P, { x: 3, y: 3.4, w: 2.2, d: 1.1, h: 0.85, color: "#94a3b8" }),
          e.jsx(i, {
            x: 3.05,
            y: 3.45,
            z: 0.3,
            w: 2.1,
            d: 1,
            h: 0.05,
            color: "#cbd5e1",
          }),
          e.jsx(V, { x: 3.15, y: 4.4, r: 0.08, h: 0.08, color: "#111827" }),
          e.jsx(V, { x: 5.05, y: 4.4, r: 0.08, h: 0.08, color: "#111827" }),
          e.jsx(Re, { build: t, spots: xs }),
          e.jsx(se, {
            x: 3.55,
            y: 3.6,
            z: 0.85,
            w: 0.9,
            h: 0.6,
            children: e.jsx(Nt, {}),
          }),
          e.jsx(f, {
            x: 2.5,
            y: 5.3,
            shirt: "#14b8a6",
            legs: "#0f766e",
            skin: 3,
            hair: 3,
            face: "y",
          }),
          e.jsx(V, { x: 7.3, y: 6.9, r: 0.25, h: 0.4, color: "#b45309" }),
          e.jsx(i, {
            x: 7.05,
            y: 6.65,
            z: 0.4,
            w: 0.5,
            d: 0.5,
            h: 0.5,
            color: "#3f9b4f",
          }),
        ],
      }),
    hot: [3.55, 3.6, 0.85],
    pins: [
      [3.55, 3.6, 1.85],
      [0.35, 1.1, 2],
      [5.9, 1.2, 2.55],
    ],
  },
  js = {
    ram: [2.9, 2.66, 0.75],
    main: [1.5, 3.15, 0.75],
    backup: [3.97, 2.65, 1.05],
    portable: [2.05, 3.3, 0.75],
    optical: [3.92, 3.1, 1.05],
  },
  ms = {
    viewBox: "-252 -115 504 372",
    backdrop: e.jsx($e, {
      id: "si-sky-esports",
      from: "#141236",
      to: "#24205a",
    }),
    draw: (t) =>
      e.jsxs(e.Fragment, {
        children: [
          e.jsx(st, {
            w: 8,
            d: 8,
            wall: 3,
            floor: "#3b3680",
            left: "#2a2670",
            right: "#332e84",
          }),
          e.jsx(B, {
            from: [0, 0, 2.7],
            to: [8, 0, 2.7],
            color: "#818cf8",
            width: 3,
          }),
          e.jsx(B, {
            from: [0, 0, 2.7],
            to: [0, 8, 2.7],
            color: "#f472b6",
            width: 3,
          }),
          e.jsx(N, {
            wall: "y",
            a: 2.3,
            z: 1.15,
            w: 3.4,
            h: 1.6,
            fill: "#020617",
            frame: "#818cf8",
          }),
          e.jsx(u, {
            x: 2.4,
            y: 0.003,
            z: 1.22,
            w: 3.2,
            h: 1.46,
            children: e.jsx(Ce, {}),
          }),
          e.jsxs(G, {
            x: 0.003,
            y: 1,
            z: 1.3,
            d: 1.6,
            h: 1.2,
            children: [
              e.jsx("rect", { width: 100, height: 60, fill: "#f26b1d" }),
              e.jsx("text", {
                x: 50,
                y: 40,
                textAnchor: "middle",
                fontSize: 26,
                fontWeight: 700,
                fill: "#fff",
                fontFamily: Lt,
                children: "VOLT",
              }),
            ],
          }),
          e.jsx(P, { x: 1.4, y: 2.6, w: 2.4, d: 1, h: 0.75, color: "#4c1d95" }),
          e.jsx(se, {
            x: 2.2,
            y: 2.75,
            z: 0.75,
            w: 1.1,
            h: 0.62,
            frame: "#020617",
            children: e.jsx(Ce, {}),
          }),
          e.jsx(i, {
            x: 2.15,
            y: 2.68,
            z: 1.53,
            w: 0.14,
            d: 0.08,
            h: 0.08,
            color: "#020617",
          }),
          e.jsx(Ke, { x: 3.95, y: 2.6, glow: "#a855f7" }),
          e.jsx(Re, { build: t, spots: js }),
          e.jsx(I, { x: 2.2, y: 4.15, color: "#f26b1d" }),
          e.jsx(f, {
            x: 2.2,
            y: 4.1,
            z: 0,
            seated: !0,
            shirt: "#f26b1d",
            hair: 3,
            face: "away",
            phones: "#e2e8f0",
          }),
          e.jsx(P, { x: 5, y: 2.6, w: 2.2, d: 1, h: 0.75, color: "#4c1d95" }),
          e.jsx(se, {
            x: 6.1,
            y: 2.75,
            z: 0.75,
            w: 1.1,
            h: 0.62,
            frame: "#020617",
            children: e.jsx(Ce, {}),
          }),
          e.jsx(I, { x: 6.1, y: 4.15, color: "#f26b1d" }),
          e.jsx(f, {
            x: 6.1,
            y: 4.1,
            seated: !0,
            shirt: "#f26b1d",
            hair: 2,
            face: "away",
            phones: "#e2e8f0",
          }),
        ],
      }),
    hot: [2.2, 2.75, 0.75],
    pins: [
      [4, 0, 3.05],
      [4.2, 3, 1.9],
      [2.2, 2.7, 1.85],
    ],
  },
  us = {
    ram: [1.5, 3.6, 0.75],
    main: [2.2, 3.75, 0.75],
    backup: [3.95, 3.55, 0.75],
    portable: [2.78, 3.95, 0.75],
    optical: [3.3, 3.7, 0.75],
  };
function Ee({ seed: t = 0 }) {
  const s = [14, 22, 10, 26, 18, 30, 12, 24, 20, 34];
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 100, height: 60, fill: "#0b1020" }),
      s.map((r, a) => {
        const o = (a + t) % 3 !== 1,
          n = 46 - r - ((a * 7 + t * 5) % 9);
        return e.jsx(
          "rect",
          {
            x: 6 + a * 9,
            y: n,
            width: 5,
            height: r,
            fill: o ? "#22c55e" : "#ef4444",
          },
          a,
        );
      }),
      e.jsx("path", {
        d: `M4 ${40 - t} L30 30 L52 34 L74 18 L96 ${12 + t}`,
        fill: "none",
        stroke: "#fbbf24",
        strokeWidth: 2,
      }),
      e.jsx("rect", { y: 52, width: 100, height: 8, fill: "#111827" }),
      e.jsx("rect", { x: 4, y: 54, width: 20, height: 4, fill: "#22c55e" }),
      e.jsx("rect", { x: 30, y: 54, width: 18, height: 4, fill: "#ef4444" }),
      e.jsx("rect", { x: 54, y: 54, width: 22, height: 4, fill: "#22c55e" }),
    ],
  });
}
function ps() {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 100, height: 60, fill: "#1e3a8a" }),
      e.jsx("rect", {
        y: 36,
        width: 100,
        height: 24,
        fill: "#f59e0b",
        opacity: 0.35,
      }),
      [
        [4, 30, 12],
        [18, 18, 10],
        [30, 26, 14],
        [46, 8, 10],
        [58, 22, 12],
        [72, 14, 9],
        [83, 28, 13],
      ].map(([t = 0, s = 0, r = 0]) =>
        e.jsxs(
          "g",
          {
            children: [
              e.jsx("rect", {
                x: t,
                y: s,
                width: r,
                height: 60 - s,
                fill: "#0f172a",
              }),
              [0, 1, 2, 3].map((a) =>
                e.jsx(
                  "rect",
                  {
                    x: t + 2,
                    y: s + 4 + a * 7,
                    width: r - 4,
                    height: 2,
                    fill: "#fde68a",
                    opacity: 0.6,
                  },
                  a,
                ),
              ),
            ],
          },
          t,
        ),
      ),
    ],
  });
}
const ys = {
    viewBox: "-252 -115 504 372",
    backdrop: e.jsx($e, {
      id: "si-sky-finance",
      from: "#0f172a",
      to: "#1e293b",
    }),
    draw: (t) =>
      e.jsxs(e.Fragment, {
        children: [
          e.jsx(st, {
            w: 8,
            d: 8,
            wall: 3,
            floor: "#3a4256",
            left: "#1f2a44",
            right: "#24304d",
          }),
          e.jsx(B, {
            from: [0, 0, 0.02],
            to: [8, 0, 0.02],
            color: "#d4a017",
            width: 2,
          }),
          e.jsx(B, {
            from: [0, 0, 0.02],
            to: [0, 8, 0.02],
            color: "#d4a017",
            width: 2,
          }),
          [0.4, 2.2, 4].map((s) =>
            e.jsxs(
              "g",
              {
                children: [
                  e.jsx(N, {
                    wall: "x",
                    a: s,
                    z: 0.3,
                    w: 1.6,
                    h: 2.4,
                    fill: "#1e3a8a",
                    frame: "#d4a017",
                  }),
                  e.jsx(G, {
                    x: 0.003,
                    y: s + 0.05,
                    z: 0.35,
                    d: 1.5,
                    h: 2.3,
                    children: e.jsx(ps, {}),
                  }),
                ],
              },
              s,
            ),
          ),
          e.jsx(N, {
            wall: "x",
            a: 5.8,
            z: 0,
            w: 1.2,
            h: 2.2,
            fill: "#0f172a",
            frame: "#d4a017",
          }),
          e.jsx(N, {
            wall: "y",
            a: 2,
            z: 1,
            w: 4.4,
            h: 1.8,
            fill: "#020617",
            frame: "#d4a017",
          }),
          e.jsx(u, {
            x: 2.1,
            y: 0.003,
            z: 1.08,
            w: 4.2,
            h: 1.64,
            children: e.jsx(Ee, { seed: 2 }),
          }),
          e.jsx(A, { x: 0.3, y: 0.5, w: 0.8, d: 1 }),
          e.jsx(i, { x: 0.3, y: 0.5, w: 0.8, d: 1, h: 2.1, color: "#111827" }),
          e.jsx(G, {
            x: 1.1,
            y: 0.5,
            z: 0,
            d: 1,
            h: 2.1,
            children: [6, 14, 22, 30, 38, 46].map((s, r) =>
              e.jsxs(
                "g",
                {
                  children: [
                    e.jsx("rect", {
                      x: 10,
                      y: s,
                      width: 80,
                      height: 5,
                      fill: "#1f2937",
                    }),
                    e.jsx("circle", {
                      cx: 80,
                      cy: s + 2.5,
                      r: 1.6,
                      fill: r % 2 ? "#22c55e" : "#fbbf24",
                    }),
                  ],
                },
                s,
              ),
            ),
          }),
          e.jsx(P, { x: 1.4, y: 3.2, w: 3, d: 1, h: 0.75, color: "#1f2937" }),
          [1.95, 2.85, 3.75].map((s, r) =>
            e.jsxs(
              "g",
              {
                children: [
                  e.jsx(i, {
                    x: s - 0.4,
                    y: 3.2,
                    z: 1.38,
                    w: 0.8,
                    d: 0.05,
                    h: 0.5,
                    color: "#020617",
                    left: "#020617",
                  }),
                  e.jsx(u, {
                    x: s - 0.37,
                    y: 3.25,
                    z: 1.41,
                    w: 0.74,
                    h: 0.44,
                    children: e.jsx(Ee, { seed: r + 3 }),
                  }),
                ],
              },
              `top${s}`,
            ),
          ),
          [1.95, 2.85, 3.75].map((s, r) =>
            e.jsx(
              se,
              {
                x: s,
                y: 3.32,
                z: 0.75,
                w: 0.84,
                h: 0.5,
                frame: "#020617",
                children: e.jsx(Ee, { seed: r }),
              },
              s,
            ),
          ),
          e.jsx(Re, { build: t, spots: us }),
          e.jsx(P, { x: 5, y: 3.2, w: 2.4, d: 1, h: 0.75, color: "#1f2937" }),
          [5.7, 6.6].map((s, r) =>
            e.jsx(
              se,
              {
                x: s,
                y: 3.32,
                z: 0.75,
                w: 0.84,
                h: 0.5,
                frame: "#020617",
                children: e.jsx(Ee, { seed: r + 6 }),
              },
              s,
            ),
          ),
          e.jsx(I, { x: 6.15, y: 4.75, color: "#111827" }),
          e.jsx(f, {
            x: 6.15,
            y: 4.7,
            seated: !0,
            shirt: "#475569",
            hair: 1,
            face: "away",
          }),
          e.jsx(V, { x: 7.3, y: 6.9, r: 0.25, h: 0.45, color: "#d4a017" }),
          e.jsx(i, {
            x: 7.05,
            y: 6.65,
            z: 0.45,
            w: 0.5,
            d: 0.5,
            h: 0.6,
            color: "#2f855a",
          }),
          e.jsx(f, {
            x: 1,
            y: 5.6,
            shirt: "#1e293b",
            legs: "#111827",
            skin: 2,
            hair: 0,
            face: "y",
          }),
        ],
      }),
    hot: [2.85, 3.32, 0.75],
    pins: [
      [2.85, 3.3, 2.15],
      [0.7, 1, 2.45],
      [5.4, 0, 3.05],
    ],
  },
  ws = {
    ram: [2.2, 1.65, 0.75],
    main: [2.2, 2.2, 0.75],
    backup: [2.85, 1.65, 0.75],
    portable: [1.2, 2.38, 0.75],
    optical: [2.85, 2.12, 0.75],
  },
  gs = {
    viewBox: "-245 -95 550 350",
    backdrop: e.jsxs(e.Fragment, {
      children: [
        e.jsx($e, { id: "si-sky-arctic", from: "#0f2546", to: "#3b5b8a" }),
        e.jsx("path", {
          d: "M-400 -40q140-70 280-10t280-20t300 0",
          fill: "none",
          stroke: "#34d399",
          strokeWidth: 22,
          opacity: 0.35,
        }),
        e.jsx("path", {
          d: "M-400 -10q160-50 320 0t340-10t240 0",
          fill: "none",
          stroke: "#a7f3d0",
          strokeWidth: 9,
          opacity: 0.3,
        }),
        [
          [-180, -90],
          [-60, -70],
          [40, -100],
          [150, -80],
          [260, -95],
          [220, -40],
        ].map(([t, s]) =>
          e.jsx(
            "circle",
            { cx: t, cy: s, r: 1.5, fill: "#f8fafc" },
            `${t}${s}`,
          ),
        ),
      ],
    }),
    draw: (t) =>
      e.jsxs(e.Fragment, {
        children: [
          e.jsx(i, {
            x: 0,
            y: 0,
            z: -0.7,
            w: 10,
            d: 8,
            h: 0.7,
            color: "#f1f5f9",
            top: "#f1f5f9",
            left: "#cbd5e1",
            right: "#94a3b8",
          }),
          e.jsx(J, {
            points: [
              [0.4, 0.4, 0.02],
              [5.4, 0.4, 0.02],
              [5.4, 5, 0.02],
              [0.4, 5, 0.02],
            ],
            fill: "#a16207",
          }),
          e.jsx(i, {
            x: 0.2,
            y: 0.4,
            w: 0.2,
            d: 4.6,
            h: 2.6,
            color: "#b91c1c",
            right: "#b91c1c",
            top: "#7f1d1d",
          }),
          e.jsx(i, {
            x: 0.2,
            y: 0.2,
            w: 5.2,
            d: 0.2,
            h: 2.6,
            color: "#dc2626",
            left: "#dc2626",
            top: "#7f1d1d",
          }),
          e.jsx(N, {
            wall: "y",
            off: 0.4,
            a: 1.4,
            z: 1.2,
            w: 1.2,
            h: 0.8,
            fill: "#0f2546",
            frame: "#f8fafc",
          }),
          e.jsx(N, {
            wall: "x",
            off: 0.4,
            a: 3.4,
            z: 1.3,
            w: 1.2,
            h: 0.9,
            fill: "#e2e8f0",
            frame: "#7f1d1d",
          }),
          e.jsx(i, {
            x: 0.45,
            y: 3.6,
            w: 0.5,
            d: 0.8,
            h: 0.9,
            color: "#334155",
          }),
          e.jsx(G, {
            x: 0.95,
            y: 3.6,
            z: 0,
            d: 0.8,
            h: 0.9,
            children: e.jsx("rect", {
              x: 14,
              y: 20,
              width: 72,
              height: 26,
              fill: "#f97316",
            }),
          }),
          e.jsx(P, { x: 1, y: 1.6, w: 2.4, d: 1, h: 0.75, color: "#b7793f" }),
          e.jsx(X, { x: 1.6, y: 2, z: 0.75, children: e.jsx(Ze, {}) }),
          e.jsx(Re, { build: t, spots: ws }),
          e.jsx(f, {
            x: 3.6,
            y: 3.5,
            shirt: "#f26b1d",
            legs: "#1e293b",
            skin: 1,
            hood: "#c2410c",
            face: "y",
          }),
          e.jsx(B, {
            from: [8.6, 1, 0],
            to: [8.6, 1, 2.6],
            color: "#475569",
            width: 3,
          }),
          e.jsx(v, {
            c: [8.6, 1, 2.4],
            r: 0.35,
            plane: "x",
            fill: "#cbd5e1",
            stroke: "#64748b",
            width: 1.5,
          }),
          e.jsx(A, { x: 6.2, y: 0.7, w: 3.4, d: 3 }),
          e.jsx(i, {
            x: 6.5,
            y: 1.95,
            z: 0.1,
            w: 2.6,
            d: 0.08,
            h: 0.05,
            color: "#334155",
          }),
          e.jsx(i, {
            x: 6.5,
            y: 2.42,
            z: 0.1,
            w: 2.6,
            d: 0.08,
            h: 0.05,
            color: "#334155",
          }),
          e.jsx(i, {
            x: 7.2,
            y: 2,
            z: 0.15,
            w: 0.08,
            d: 0.08,
            h: 0.25,
            color: "#334155",
          }),
          e.jsx(i, {
            x: 7.2,
            y: 2.42,
            z: 0.15,
            w: 0.08,
            d: 0.08,
            h: 0.25,
            color: "#334155",
          }),
          e.jsx(i, {
            x: 6.2,
            y: 2,
            z: 0.75,
            w: 0.35,
            d: 0.5,
            h: 0.75,
            color: "#dc2626",
          }),
          e.jsx(i, {
            x: 6.2,
            y: 1.8,
            z: 0.4,
            w: 3,
            d: 0.9,
            h: 0.75,
            color: "#f8fafc",
          }),
          e.jsxs(u, {
            x: 6.2,
            y: 2.7,
            z: 0.4,
            w: 3,
            h: 0.75,
            children: [
              e.jsx("rect", {
                x: 0,
                y: 34,
                width: 100,
                height: 8,
                fill: "#dc2626",
              }),
              [44, 56, 68, 80].map((s) =>
                e.jsx(
                  "rect",
                  { x: s, y: 12, width: 7, height: 12, fill: "#1e3a5f" },
                  s,
                ),
              ),
            ],
          }),
          e.jsx(G, {
            x: 9.2,
            y: 1.8,
            z: 0.4,
            d: 0.9,
            h: 0.75,
            children: e.jsx("rect", {
              x: 20,
              y: 6,
              width: 60,
              height: 18,
              fill: "#1e3a5f",
            }),
          }),
          e.jsx(i, {
            x: 7.6,
            y: 0.4,
            z: 1.15,
            w: 0.9,
            d: 3.6,
            h: 0.08,
            color: "#dc2626",
          }),
          e.jsx(v, {
            c: [9.22, 2.25, 0.78],
            r: 0.45,
            plane: "x",
            fill: "#475569",
          }),
          e.jsx(v, {
            c: [9.23, 2.25, 0.78],
            r: 0.08,
            plane: "x",
            fill: "#111827",
          }),
          e.jsx(i, {
            x: 5.85,
            y: 4.95,
            w: 0.1,
            d: 0.1,
            h: 1.3,
            color: "#64748b",
          }),
          e.jsx(i, {
            x: 5.78,
            y: 4.95,
            z: 0.6,
            w: 0.24,
            d: 0.1,
            h: 0.6,
            color: "#f8fafc",
          }),
          e.jsx(u, {
            x: 5.78,
            y: 5.05,
            z: 0.6,
            w: 0.24,
            h: 0.6,
            children: e.jsx("rect", {
              x: 38,
              y: 30,
              width: 24,
              height: 30,
              fill: "#60a5fa",
            }),
          }),
          e.jsx(i, {
            x: 6.5,
            y: 5.4,
            z: 0.12,
            w: 1.6,
            d: 0.8,
            h: 0.08,
            color: "#a16207",
          }),
          e.jsx(i, {
            x: 6.6,
            y: 5.5,
            z: 0.2,
            w: 0.7,
            d: 0.6,
            h: 0.45,
            color: "#a16207",
          }),
          e.jsx(i, {
            x: 7.4,
            y: 5.55,
            z: 0.2,
            w: 0.6,
            d: 0.5,
            h: 0.35,
            color: "#1f4fbf",
          }),
          e.jsx(B, {
            from: [6.4, 6.25, 0.02],
            to: [8.3, 6.25, 0.02],
            color: "#334155",
            width: 3,
          }),
        ],
      }),
    hot: [1.6, 2, 0.75],
    pins: [
      [5.9, 5, 1.8],
      [8.6, 1, 3],
      [7.6, 2.2, 1.9],
    ],
  },
  bs = { film: hs, hospital: fs, esports: ms, finance: ys, arctic: gs };
function Xe({ x: t, y: s, r, delay: a }) {
  return e.jsx("circle", {
    cx: t,
    cy: s,
    r,
    fill: "#64748b",
    opacity: 0.75,
    className: "si-rise",
    style: { animationDelay: `${a}s` },
  });
}
function ks({ at: t }) {
  const [s, r] = y(t[0], t[1], t[2] + 0.9);
  return e.jsxs("g", {
    children: [
      e.jsx(Xe, { x: s - 6, y: r, r: 12, delay: 0 }),
      e.jsx(Xe, { x: s + 10, y: r - 18, r: 15, delay: 0.3 }),
      e.jsx(Xe, { x: s - 4, y: r - 40, r: 18, delay: 0.6 }),
    ],
  });
}
const vs = { protected: "#1f9d6b", partial: "#d99a0b", vulnerable: "#c8372d" };
function Bs({ room: t, level: s }) {
  const r = vs[s],
    [a, o] = y(t.hot[0], t.hot[1], t.hot[2] + 1.55);
  return e.jsxs("g", {
    "data-scene-outcome": s,
    children: [
      e.jsx("g", {
        opacity: 0.3,
        children: e.jsx(v, {
          c: [t.hot[0], t.hot[1] + 0.2, 0.01],
          r: 1.35,
          plane: "z",
          fill: r,
        }),
      }),
      e.jsx(v, {
        c: [t.hot[0], t.hot[1] + 0.2, 0.01],
        r: 1.35,
        plane: "z",
        fill: "none",
        stroke: r,
        width: 4,
      }),
      s === "vulnerable" ? e.jsx(ks, { at: t.hot }) : null,
      e.jsxs("g", {
        transform: `translate(${a + 48} ${o})`,
        className: "si-pop",
        children: [
          e.jsx("circle", {
            r: 22,
            fill: r,
            stroke: "#fffdf7",
            strokeWidth: 4,
          }),
          s === "protected"
            ? e.jsx("path", {
                d: "M-10 0l7 8 13-15",
                fill: "none",
                stroke: "#fffdf7",
                strokeWidth: 5,
                strokeLinecap: "round",
                strokeLinejoin: "round",
              })
            : s === "partial"
              ? e.jsx("path", {
                  d: "M-10 0h20",
                  stroke: "#fffdf7",
                  strokeWidth: 5,
                  strokeLinecap: "round",
                })
              : e.jsx("path", {
                  d: "M-8 -8l16 16M8 -8l-16 16",
                  stroke: "#fffdf7",
                  strokeWidth: 5,
                  strokeLinecap: "round",
                }),
        ],
      }),
    ],
  });
}
function Ts({ at: t, n: s }) {
  const [r, a] = y(...t);
  return e.jsxs("g", {
    "data-scene-pin": s,
    children: [
      e.jsx("line", {
        x1: r,
        y1: a,
        x2: r,
        y2: a + 16,
        stroke: "#13294b",
        strokeWidth: 2.5,
      }),
      e.jsx("circle", {
        cx: r,
        cy: a,
        r: 13,
        fill: "#f26b1d",
        stroke: "#fffdf7",
        strokeWidth: 3,
      }),
      e.jsx("text", {
        x: r,
        y: a + 4.5,
        textAnchor: "middle",
        fontSize: 13,
        fontWeight: 700,
        fill: "#fffdf7",
        fontFamily: Lt,
        children: s,
      }),
    ],
  });
}
function We({
  client: t,
  title: s,
  build: r = {},
  pins: a,
  level: o,
  night: n,
  scanning: l,
  tall: d,
  className: c,
}) {
  const h = bs[t],
    x = d
      ? ns(h.viewBox, [h.hot, ...h.pins], d.aspect, d.lift).join(" ")
      : h.viewBox;
  return e.jsxs("svg", {
    viewBox: x,
    className: c,
    role: "img",
    "aria-label": s,
    "data-stage-scene": t,
    "data-frame": d ? "tall" : "wide",
    preserveAspectRatio: "xMidYMid meet",
    children: [
      h.backdrop,
      h.draw(r),
      n
        ? e.jsx("rect", {
            x: -2e3,
            y: -2e3,
            width: 4e3,
            height: 4e3,
            fill: "#020617",
            opacity: 0.62,
          })
        : null,
      o ? e.jsx(Bs, { room: h, level: o }) : null,
      a ? h.pins.map((m, k) => e.jsx(Ts, { at: m, n: k + 1 }, k)) : null,
      n
        ? e.jsx("g", {
            className: "si-hum",
            children: (() => {
              const [m, k] = y(...h.hot);
              return e.jsx("ellipse", {
                cx: m,
                cy: k - 20,
                rx: 60,
                ry: 34,
                fill: "#1f4fbf",
                opacity: 0.35,
              });
            })(),
          })
        : null,
      l
        ? e.jsx("g", {
            className: "si-scan",
            children: (() => {
              const [m, k] = y(...h.hot);
              return e.jsx("rect", {
                x: m - 4,
                y: k - 110,
                width: 8,
                height: 170,
                fill: "#f26b1d",
                opacity: 0.6,
              });
            })(),
          })
        : null,
    ],
  });
}
const D = "'IBM Plex Mono', ui-monospace, monospace",
  T = "#13294b",
  j = "#f26b1d",
  b = "#fffdf7",
  F = [0, 0, 0],
  Gt = {
    film_cart: { client: "film", focus: [3.6, 4.2, 0.6], width: 300 },
    film_edit: { client: "film", focus: [3.1, 3.6, 1.5], width: 280 },
    film_rushes: { client: "film", focus: [3.6, 4, 1], width: 300 },
    film_archive: { client: "film", focus: [3.2, 3.2, 1.2], width: 300 },
    film_festival: { client: "film", focus: [3.3, 3.6, 0.9], width: 290 },
    film_library: { client: "film", focus: [3.6, 3.4, 1.1], width: 320 },
    film_failure: { client: "film", focus: [3, 3.6, 0.9], width: 260 },
    film_review: { client: "film", focus: [3, 3.6, 1.1], width: 280 },
    film_shoot: { client: "film", focus: [3.4, 3.6, 1.1], width: 280 },
    film_card: { client: "film", focus: [3.3, 3.4, 1.4], width: 230 },
    hospital_mri: { client: "hospital", focus: [3.4, 3, 1.1], width: 330 },
    hospital_scans: { client: "hospital", focus: [3, 3, 1.2], width: 320 },
    hospital_failure: { client: "hospital", focus: [2.9, 3.1, 1], width: 280 },
    hospital_tabs: { client: "hospital", focus: [3, 3.2, 1.3], width: 290 },
    hospital_restart: { client: "hospital", focus: [2.8, 3.4, 1], width: 300 },
    hospital_transfer: { client: "hospital", focus: [3.6, 2.8, 1], width: 320 },
    hospital_trolley: { client: "hospital", focus: [3, 3.2, 0.7], width: 300 },
    hospital_xrays: { client: "hospital", focus: [3.2, 3, 1.2], width: 320 },
    hospital_week: { client: "hospital", focus: [3, 3, 1.2], width: 300 },
    hospital_tape: { client: "hospital", focus: [3, 3, 1.2], width: 280 },
    esports_load: { client: "esports", focus: [2.8, 2.8, 1.3], width: 320 },
    esports_installs: { client: "esports", focus: [2.9, 2.9, 1.1], width: 290 },
    esports_stream: { client: "esports", focus: [2.8, 2.9, 1.4], width: 300 },
    esports_lan: { client: "esports", focus: [3.4, 3.2, 1], width: 320 },
    esports_coach: { client: "esports", focus: [3.3, 2.6, 0.9], width: 270 },
    esports_replays: { client: "esports", focus: [3, 3, 1.2], width: 320 },
    esports_expo: { client: "esports", focus: [3.2, 3, 1.1], width: 320 },
    esports_failure: { client: "esports", focus: [2.9, 2.7, 1.2], width: 300 },
    esports_space: { client: "esports", focus: [3, 2.6, 1.2], width: 270 },
    esports_month: { client: "esports", focus: [2.8, 2.8, 1.2], width: 290 },
    finance_screens: { client: "finance", focus: [2.9, 2.4, 1.4], width: 230 },
    finance_open: { client: "finance", focus: [2.8, 2.4, 1.4], width: 250 },
    finance_model: { client: "finance", focus: [2.6, 2.2, 1.4], width: 250 },
    finance_failure: { client: "finance", focus: [2, 2.4, 1.2], width: 260 },
    finance_pitch: { client: "finance", focus: [3, 3, 1.1], width: 300 },
    finance_platform: { client: "finance", focus: [3, 3, 0.9], width: 300 },
    finance_records: { client: "finance", focus: [3, 3, 1.2], width: 320 },
    finance_history: { client: "finance", focus: [3, 2.4, 1.2], width: 280 },
    finance_feed: { client: "finance", focus: [2.8, 2.6, 1.4], width: 300 },
    finance_trades: { client: "finance", focus: [3, 2.8, 1.2], width: 280 },
    arctic_plane: { client: "arctic", focus: [3.6, 3, 1], width: 320 },
    arctic_sledge: { client: "arctic", focus: [3, 3, 0.8], width: 290 },
    arctic_sensors: { client: "arctic", focus: [3.2, 3, 1.2], width: 320 },
    arctic_model: { client: "arctic", focus: [2.6, 2.4, 1.4], width: 250 },
    arctic_failure: { client: "arctic", focus: [2.6, 2.6, 1.2], width: 270 },
    arctic_archive: { client: "arctic", focus: [3, 3, 1.2], width: 320 },
    arctic_share: { client: "arctic", focus: [3.4, 3, 1], width: 300 },
    arctic_hut: { client: "arctic", focus: [2.6, 2.4, 1.5], width: 270 },
    arctic_month: { client: "arctic", focus: [2.6, 2.6, 1.4], width: 280 },
    arctic_photos: { client: "arctic", focus: [2.7, 3, 0.8], width: 220 },
  };
function Ms(t) {
  return Gt[t]?.client;
}
function _s(t) {
  const s = Gt[t];
  if (!s) return;
  const [r, a] = y(...s.focus),
    o = (s.width * 10) / 16;
  return [r - s.width / 2, a - o / 2, s.width, o];
}
function z({ frame: t, dx: s = 54, dy: r = 42, children: a }) {
  return e.jsx("g", {
    transform: `translate(${t[0] + s} ${t[1] + r})`,
    children: a,
  });
}
function re({ from: t, to: s, id: r }) {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("defs", {
        children: e.jsxs("linearGradient", {
          id: r,
          x1: "0",
          y1: "0",
          x2: "0",
          y2: "1",
          children: [
            e.jsx("stop", { offset: "0", stopColor: t }),
            e.jsx("stop", { offset: "1", stopColor: s }),
          ],
        }),
      }),
      e.jsx("rect", {
        x: -2e3,
        y: -2e3,
        width: 4e3,
        height: 4e3,
        fill: `url(#${r})`,
      }),
    ],
  });
}
function ie({
  x0: t = -6,
  y0: s = -6,
  x1: r = 14,
  y1: a = 14,
  color: o,
  lines: n = !0,
}) {
  const l = M(o, -0.07);
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx(J, {
        points: [
          [t, s, 0],
          [r, s, 0],
          [r, a, 0],
          [t, a, 0],
        ],
        fill: o,
      }),
      n
        ? Array.from({ length: Math.round(r - t) - 1 }, (d, c) =>
            e.jsxs(
              "g",
              {
                children: [
                  e.jsx(B, {
                    from: [t + c + 1, s, 0],
                    to: [t + c + 1, a, 0],
                    color: l,
                    width: 1,
                  }),
                  e.jsx(B, {
                    from: [t, s + c + 1, 0],
                    to: [r, s + c + 1, 0],
                    color: l,
                    width: 1,
                  }),
                ],
              },
              c,
            ),
          )
        : null,
    ],
  });
}
function Se({ w: t = 14, d: s = 14, h: r = 3, left: a, right: o }) {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx(i, {
        x: -0.2,
        y: 0,
        z: 0,
        w: 0.2,
        d: s,
        h: r,
        color: a,
        right: a,
        top: M(a, -0.35),
      }),
      e.jsx(i, {
        x: -0.2,
        y: -0.2,
        z: 0,
        w: t + 0.2,
        d: 0.2,
        h: r,
        color: o,
        left: o,
        top: M(o, -0.35),
      }),
    ],
  });
}
function xe({ at: t, deg: s, children: r }) {
  const [a, o] = y(...t);
  return e.jsx("g", { transform: `rotate(${s} ${a} ${o})`, children: r });
}
function g({ at: t, text: s, fill: r = T, ink: a = b, size: o = 13 }) {
  const [n, l] = y(...t),
    d = s.length * o * 0.62 + 16,
    c = o + 12;
  return e.jsxs("g", {
    "data-shot-tag": s,
    children: [
      e.jsx("rect", {
        x: n - d / 2,
        y: l - c / 2,
        width: d,
        height: c,
        rx: 5,
        fill: r,
        stroke: b,
        strokeWidth: 2,
      }),
      e.jsx("text", {
        x: n,
        y: l + o * 0.36,
        textAnchor: "middle",
        fontSize: o,
        fontWeight: 700,
        fill: a,
        fontFamily: D,
        children: s,
      }),
    ],
  });
}
function Et({ at: t, children: s, w: r = 46, h: a = 34 }) {
  const [o, n] = y(...t);
  return e.jsxs("g", {
    transform: `translate(${o} ${n})`,
    children: [
      e.jsx("path", {
        d: `M${-r / 2} ${-a - 10}h${r}a6 6 0 0 1 6 6v${a - 12}a6 6 0 0 1-6 6H8l-8 10-4-10H${-r / 2}a6 6 0 0 1-6-6v${-(a - 12)}a6 6 0 0 1 6-6z`,
        fill: b,
        stroke: T,
        strokeWidth: 2.5,
      }),
      e.jsx("g", { transform: `translate(0 ${-a / 2 - 10})`, children: s }),
    ],
  });
}
function me({ at: t, r: s = 20, hour: r = 8, minute: a = 0, fill: o = b }) {
  const [n, l] = y(...t),
    d = ((r % 12) + a / 60) * 30 * (Math.PI / 180),
    c = a * 6 * (Math.PI / 180);
  return e.jsxs("g", {
    transform: `translate(${n} ${l})`,
    children: [
      e.jsx("circle", { r: s, fill: o, stroke: T, strokeWidth: 4 }),
      [0, 90, 180, 270].map((h) =>
        e.jsx(
          "rect",
          {
            x: -1.5,
            y: -s + 3,
            width: 3,
            height: 5,
            fill: T,
            transform: `rotate(${h})`,
          },
          h,
        ),
      ),
      e.jsx("path", {
        d: `M0 0L${Math.sin(d) * s * 0.5} ${-Math.cos(d) * s * 0.5}`,
        stroke: T,
        strokeWidth: 4,
        strokeLinecap: "round",
      }),
      e.jsx("path", {
        d: `M0 0L${Math.sin(c) * s * 0.75} ${-Math.cos(c) * s * 0.75}`,
        stroke: j,
        strokeWidth: 3,
        strokeLinecap: "round",
      }),
    ],
  });
}
function rt({ at: t, s = 1 }) {
  const [r, a] = y(...t);
  return e.jsx("g", {
    transform: `translate(${r} ${a}) scale(${s})`,
    "data-shot-impact": !0,
    children: e.jsx("path", {
      d: "M0 -26l7 15 16-7-9 15 15 8-17 2 2 16-11-11-11 11 1-16-17-3 15-8-9-15 16 8z",
      fill: j,
      stroke: b,
      strokeWidth: 2,
    }),
  });
}
function ue({ at: t, s = 1, color: r = j }) {
  const [a, o] = y(...t);
  return e.jsx("g", {
    transform: `translate(${a} ${o}) scale(${s})`,
    fill: "none",
    stroke: r,
    strokeWidth: 3.5,
    strokeLinecap: "round",
    children: e.jsx("path", {
      d: "M-34 -16q-12 12 -8 28M34 -14q12 12 8 28M-44 6q-6 6 -5 14M44 8q6 6 5 14",
    }),
  });
}
function Ss({ at: t, len: s = 40, color: r = b }) {
  const [a, o] = y(...t);
  return e.jsx("g", {
    stroke: r,
    strokeWidth: 3,
    strokeLinecap: "round",
    opacity: 0.9,
    children: [-10, 0, 10].map((n, l) =>
      e.jsx(
        "line",
        { x1: a + 6, y1: o + n, x2: a + 6 + s - l * 8, y2: o + n },
        n,
      ),
    ),
  });
}
function Fs({
  x: t,
  y: s,
  z: r = 0,
  w: a = 0.6,
  d: o = 0.45,
  h: n = 0.38,
  color: l = "#f59e0b",
  label: d,
}) {
  return e.jsxs("g", {
    children: [
      e.jsx(i, { x: t, y: s, z: r, w: a, d: o, h: n, color: l }),
      e.jsx(u, {
        x: t,
        y: s + o,
        z: r,
        w: a,
        h: n,
        children: d
          ? e.jsxs(e.Fragment, {
              children: [
                e.jsx("rect", { x: 12, y: 14, width: 76, height: 30, fill: b }),
                e.jsx("text", {
                  x: 50,
                  y: 36,
                  textAnchor: "middle",
                  fontSize: 22,
                  fontWeight: 700,
                  fill: T,
                  fontFamily: D,
                  children: d,
                }),
              ],
            })
          : e.jsx("rect", { x: 30, y: 18, width: 40, height: 14, fill: b }),
      }),
    ],
  });
}
function fe({ x: t, y: s, cols: r = 3, color: a = "#f59e0b" }) {
  return e.jsx(e.Fragment, {
    children: Array.from({ length: r }, (o, n) =>
      Array.from({ length: r - n }, (l, d) =>
        e.jsx(Fs, { x: t + n * 0.68, y: s, z: d * 0.4, color: a }, `${n}${d}`),
      ),
    ),
  });
}
function Y({ x: t, y: s, z: r = 0, w: a = 1.6, rows: o = 4, colors: n }) {
  const l = n ?? ["#1f4fbf", "#0f766e", "#7c3aed", j, "#334155"],
    d = Math.round(a / 0.27);
  return e.jsxs("g", {
    children: [
      e.jsx(A, { x: t, y: s, z: r, w: a, d: 0.55 }),
      e.jsx(i, { x: t, y: s, z: r, w: a, d: 0.5, h: 0.06, color: "#78350f" }),
      Array.from({ length: o }, (c, h) =>
        e.jsxs(
          "g",
          {
            children: [
              e.jsx(i, {
                x: t,
                y: s,
                z: r + 0.06 + h * 0.55,
                w: a,
                d: 0.5,
                h: 0.05,
                color: "#92400e",
              }),
              Array.from({ length: d }, (x, m) =>
                e.jsx(
                  i,
                  {
                    x: t + 0.04 + m * 0.27,
                    y: s + 0.08,
                    z: r + 0.11 + h * 0.55,
                    w: 0.2,
                    d: 0.34,
                    h: 0.4,
                    color: l[(m + h) % l.length],
                  },
                  m,
                ),
              ),
            ],
          },
          h,
        ),
      ),
      e.jsx(i, {
        x: t,
        y: s,
        z: r + 0.06 + o * 0.55,
        w: a,
        d: 0.5,
        h: 0.06,
        color: "#92400e",
      }),
      e.jsx(i, {
        x: t,
        y: s,
        z: r,
        w: 0.06,
        d: 0.5,
        h: o * 0.55 + 0.12,
        color: "#78350f",
      }),
      e.jsx(i, {
        x: t + a - 0.06,
        y: s,
        z: r,
        w: 0.06,
        d: 0.5,
        h: o * 0.55 + 0.12,
        color: "#78350f",
      }),
    ],
  });
}
function Oe({ x: t, y: s, z: r = 0, n: a = 6 }) {
  return e.jsx("g", {
    children: Array.from({ length: a }, (o, n) =>
      e.jsxs(
        "g",
        {
          children: [
            e.jsx(i, {
              x: t,
              y: s,
              z: r + n * 0.09,
              w: 0.6,
              d: 0.6,
              h: 0.08,
              color: "#f8fafc",
            }),
            n === a - 1
              ? e.jsx(v, {
                  c: [t + 0.3, s + 0.3, r + n * 0.09 + 0.081],
                  r: 0.2,
                  plane: "z",
                  fill: "#93c5fd",
                })
              : null,
          ],
        },
        n,
      ),
    ),
  });
}
function Ht({ x: t, y: s, z: r = 0, color: a = "#fcd34d" }) {
  return e.jsxs("g", {
    children: [
      e.jsx(i, { x: t, y: s, z: r, w: 0.7, d: 0.5, h: 0.05, color: a }),
      e.jsxs(_e, {
        x: t,
        y: s,
        z: r + 0.051,
        w: 0.7,
        d: 0.5,
        children: [
          e.jsx("rect", {
            x: 40,
            y: 30,
            width: 44,
            height: 8,
            fill: T,
            opacity: 0.7,
          }),
          e.jsx("rect", {
            x: 40,
            y: 46,
            width: 34,
            height: 8,
            fill: T,
            opacity: 0.7,
          }),
          e.jsx("rect", { x: 10, y: 10, width: 16, height: 18, fill: j }),
        ],
      }),
    ],
  });
}
function at({ at: t, n: s = 5, spread: r = 30 }) {
  const [a, o] = y(...t),
    n = ["#1f4fbf", j, "#0f766e", "#7c3aed", "#c8372d", "#d4a017"],
    l = (s - 1) / 2;
  return e.jsx("g", {
    children: Array.from({ length: s }, (d, c) => {
      const h = c - l;
      return e.jsxs(
        "g",
        {
          transform: `translate(${a + h * r} ${o + Math.abs(h) * 12}) rotate(${h * 7})`,
          children: [
            e.jsx("rect", {
              x: -26,
              y: -18,
              width: 52,
              height: 36,
              rx: 3,
              fill: b,
              stroke: T,
              strokeWidth: 2.5,
            }),
            e.jsx("rect", {
              x: -26,
              y: -18,
              width: 52,
              height: 8,
              rx: 3,
              fill: n[c % n.length],
            }),
            e.jsx("rect", {
              x: -20,
              y: -4,
              width: 30,
              height: 3,
              fill: "#94a3b8",
            }),
            e.jsx("rect", {
              x: -20,
              y: 4,
              width: 40,
              height: 3,
              fill: "#94a3b8",
            }),
          ],
        },
        c,
      );
    }),
  });
}
function Pe({ at: t, label: s, color: r = j, s: a = 1, arrows: o = !0 }) {
  const [n, l, d] = t,
    [c, h] = y(n + 0.5 * a, l + 0.5 * a, d);
  return e.jsxs("g", {
    children: [
      e.jsx(i, { x: n, y: l, z: d, w: a, d: a, h: 0.9 * a, color: r }),
      e.jsx(u, {
        x: n,
        y: l + a,
        z: d,
        w: a,
        h: 0.9 * a,
        children: e.jsx("text", {
          x: 50,
          y: 40,
          textAnchor: "middle",
          fontSize: s.length > 2 ? 22 : 28,
          fontWeight: 700,
          fill: b,
          fontFamily: D,
          children: s,
        }),
      }),
      o
        ? e.jsx("path", {
            d: `M${c - 42 * a} ${h + 4}v18m-6-6 6 6 6-6M${c + 42 * a} ${h + 4}v18m-6-6 6 6 6-6`,
            stroke: T,
            strokeWidth: 3,
            fill: "none",
            strokeLinecap: "round",
          })
        : null,
    ],
  });
}
function Le({ at: t }) {
  const [s, r] = y(t[0], t[1], t[2] + 0.4);
  return e.jsxs("g", {
    "data-shot-dead": !0,
    children: [
      e.jsx("circle", {
        cx: s - 6,
        cy: r,
        r: 12,
        fill: "#64748b",
        opacity: 0.75,
      }),
      e.jsx("circle", {
        cx: s + 10,
        cy: r - 18,
        r: 15,
        fill: "#64748b",
        opacity: 0.7,
      }),
      e.jsx("circle", {
        cx: s - 4,
        cy: r - 40,
        r: 18,
        fill: "#64748b",
        opacity: 0.6,
      }),
    ],
  });
}
function U({ at: t, text: s, w: r = 54 }) {
  const [a, o] = y(...t);
  return e.jsxs("g", {
    transform: `translate(${a} ${o})`,
    children: [
      e.jsx("rect", {
        x: -r / 2,
        y: -26,
        width: r,
        height: 46,
        rx: 4,
        fill: b,
        stroke: T,
        strokeWidth: 2.5,
      }),
      e.jsx("rect", {
        x: -r / 2,
        y: -26,
        width: r,
        height: 12,
        rx: 3,
        fill: "#c8372d",
      }),
      e.jsx("text", {
        x: 0,
        y: 10,
        textAnchor: "middle",
        fontSize: s.length > 3 ? 12 : 16,
        fontWeight: 700,
        fill: T,
        fontFamily: D,
        children: s,
      }),
    ],
  });
}
function Ct({ at: t, r: s = 16, sky: r = "#0f172a" }) {
  const [a, o] = y(...t);
  return e.jsxs("g", {
    children: [
      e.jsx("circle", { cx: a, cy: o, r: s, fill: "#fde68a" }),
      e.jsx("circle", {
        cx: a + s * 0.45,
        cy: o - s * 0.3,
        r: s * 0.85,
        fill: r,
      }),
    ],
  });
}
const Ie = j,
  De = "#c2410c";
function ge({ night: t }) {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx(re, {
        id: `si-shot-ice${t ? "n" : ""}`,
        from: t ? "#0f2546" : "#7fb3e0",
        to: t ? "#3b5b8a" : "#dbeafe",
      }),
      t
        ? e.jsx("path", {
            d: "M-600 -120q140-70 280-10t280-20t300 0t300 10",
            fill: "none",
            stroke: "#34d399",
            strokeWidth: 22,
            opacity: 0.35,
          })
        : null,
      e.jsx("path", {
        d: "M-600 30l120-50 90 40 140-70 120 60 110-40 130 50 120-30v400h-830z",
        fill: "#e2e8f0",
      }),
      e.jsx("rect", {
        x: -2e3,
        y: 40,
        width: 4e3,
        height: 4e3,
        fill: "#f1f5f9",
      }),
    ],
  });
}
function He() {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx(re, { id: "si-shot-hut", from: "#7f1d1d", to: "#991b1b" }),
      e.jsx(ie, { color: "#a16207" }),
      e.jsx(Se, { left: "#b91c1c", right: "#dc2626", h: 2.8 }),
    ],
  });
}
function be({ x: t, y: s, face: r = "y", reach: a }) {
  return e.jsx(f, {
    x: t,
    y: s,
    shirt: Ie,
    legs: "#1e293b",
    skin: 1,
    hood: De,
    face: r,
    reach: a,
  });
}
function ht({ x: t, y: s, open: r }) {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx(A, { x: t, y: s - 1.1, w: 3.4, d: 3 }),
      e.jsx(i, {
        x: t + 0.3,
        y: s + 0.15,
        z: 0.1,
        w: 2.6,
        d: 0.08,
        h: 0.05,
        color: "#334155",
      }),
      e.jsx(i, {
        x: t,
        y: s,
        z: 0.75,
        w: 0.35,
        d: 0.5,
        h: 0.75,
        color: "#dc2626",
      }),
      e.jsx(i, {
        x: t,
        y: s - 0.2,
        z: 0.4,
        w: 3,
        d: 0.9,
        h: 0.75,
        color: "#f8fafc",
      }),
      e.jsxs(u, {
        x: t,
        y: s + 0.7,
        z: 0.4,
        w: 3,
        h: 0.75,
        children: [
          e.jsx("rect", {
            x: 0,
            y: 34,
            width: 100,
            height: 8,
            fill: "#dc2626",
          }),
          [44, 56, 68, 80].map((a) =>
            e.jsx(
              "rect",
              { x: a, y: 12, width: 7, height: 12, fill: "#1e3a5f" },
              a,
            ),
          ),
          r
            ? e.jsx("rect", {
                x: 18,
                y: 6,
                width: 18,
                height: 50,
                fill: "#0f172a",
              })
            : null,
        ],
      }),
      e.jsx(G, {
        x: t + 3,
        y: s - 0.2,
        z: 0.4,
        d: 0.9,
        h: 0.75,
        children: e.jsx("rect", {
          x: 20,
          y: 6,
          width: 60,
          height: 18,
          fill: "#1e3a5f",
        }),
      }),
      e.jsx(i, {
        x: t + 1.4,
        y: s - 1.6,
        z: 1.15,
        w: 0.9,
        d: 3.6,
        h: 0.08,
        color: "#dc2626",
      }),
      e.jsx(v, {
        c: [t + 3.02, s + 0.25, 0.78],
        r: 0.45,
        plane: "x",
        fill: "#475569",
      }),
    ],
  });
}
function xt({ x: t, y: s }) {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx(A, { x: t - 0.3, y: s - 0.3, w: 0.6, d: 0.6 }),
      e.jsx(B, {
        from: [t, s, 0],
        to: [t, s, 2.8],
        color: "#475569",
        width: 3,
      }),
      e.jsx(B, {
        from: [t - 0.4, s, 2.6],
        to: [t + 0.4, s, 2.6],
        color: "#475569",
        width: 2,
      }),
      e.jsx(V, {
        x: t - 0.4,
        y: s,
        z: 2.6,
        r: 0.08,
        h: 0.12,
        color: "#f26b1d",
      }),
      e.jsx(V, {
        x: t + 0.4,
        y: s,
        z: 2.6,
        r: 0.08,
        h: 0.12,
        color: "#f26b1d",
      }),
      e.jsx(i, {
        x: t - 0.2,
        y: s + 0.05,
        z: 1.2,
        w: 0.4,
        d: 0.2,
        h: 0.5,
        color: "#f8fafc",
      }),
      e.jsxs(u, {
        x: t - 0.2,
        y: s + 0.25,
        z: 1.2,
        w: 0.4,
        h: 0.5,
        children: [
          e.jsx("rect", {
            x: 20,
            y: 14,
            width: 60,
            height: 14,
            fill: "#0f172a",
          }),
          e.jsx("circle", { cx: 50, cy: 44, r: 6, fill: "#22c55e" }),
        ],
      }),
    ],
  });
}
function ft({ x: t, y: s }) {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx(A, { x: t - 0.2, y: s - 0.2, w: 0.4, d: 0.4 }),
      e.jsx(i, {
        x: t - 0.08,
        y: s - 0.08,
        w: 0.16,
        d: 0.16,
        h: 1.4,
        color: "#78350f",
      }),
      e.jsx(i, {
        x: t - 0.22,
        y: s + 0.08,
        z: 0.7,
        w: 0.44,
        d: 0.22,
        h: 0.5,
        color: "#3f6212",
      }),
      e.jsxs(u, {
        x: t - 0.22,
        y: s + 0.3,
        z: 0.7,
        w: 0.44,
        h: 0.5,
        children: [
          e.jsx("circle", { cx: 50, cy: 30, r: 16, fill: "#0f172a" }),
          e.jsx("circle", { cx: 50, cy: 30, r: 7, fill: "#38bdf8" }),
          e.jsx("rect", { x: 20, y: 6, width: 14, height: 8, fill: "#ef4444" }),
        ],
      }),
    ],
  });
}
function zs({ x: t, y: s }) {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx(A, { x: t - 0.1, y: s - 0.2, w: 0.9, d: 0.5 }),
      e.jsx(i, {
        x: t,
        y: s - 0.12,
        z: 0.2,
        w: 0.6,
        d: 0.24,
        h: 0.28,
        color: "#f8fafc",
      }),
      e.jsx(i, {
        x: t + 0.55,
        y: s - 0.1,
        z: 0.38,
        w: 0.24,
        d: 0.2,
        h: 0.22,
        color: "#f8fafc",
      }),
      e.jsx(i, {
        x: t + 0.6,
        y: s - 0.1,
        z: 0.6,
        w: 0.06,
        d: 0.06,
        h: 0.1,
        color: "#e2e8f0",
      }),
      e.jsx(i, {
        x: t + 0.7,
        y: s + 0.04,
        z: 0.6,
        w: 0.06,
        d: 0.06,
        h: 0.1,
        color: "#e2e8f0",
      }),
      e.jsx(i, {
        x: t + 0.79,
        y: s - 0.04,
        z: 0.44,
        w: 0.06,
        d: 0.08,
        h: 0.06,
        color: "#111827",
      }),
      e.jsx(i, {
        x: t - 0.3,
        y: s - 0.08,
        z: 0.3,
        w: 0.32,
        d: 0.16,
        h: 0.16,
        color: "#e2e8f0",
      }),
      [0.05, 0.45].map((r) =>
        e.jsx(
          i,
          {
            x: t + r,
            y: s - 0.05,
            z: 0,
            w: 0.08,
            d: 0.08,
            h: 0.2,
            color: "#e2e8f0",
          },
          r,
        ),
      ),
    ],
  });
}
function jt({ y: t }) {
  return e.jsx(e.Fragment, {
    children: [0.6, 1.5, 2.6, 3.4, 4.5, 5.3].map((s, r) =>
      e.jsx(
        i,
        {
          x: s,
          y: t + (r % 2) * 0.3,
          w: 0.7,
          d: 0.5,
          h: 0.18 + (r % 3) * 0.1,
          color: "#e0f2fe",
        },
        s,
      ),
    ),
  });
}
const Ns = {
  arctic_plane: (t) =>
    e.jsxs(e.Fragment, {
      children: [
        e.jsx(ge, {}),
        e.jsx(ht, { x: 3, y: 1.6, open: !0 }),
        e.jsx(be, { x: 2.4, y: 3.8, face: "x", reach: !0 }),
        e.jsx(i, {
          x: 2.7,
          y: 3.62,
          z: 0.95,
          w: 0.45,
          d: 0.3,
          h: 0.32,
          color: "#334155",
        }),
        e.jsx(g, { at: [4.2, 4.2, 0.4], text: "60 GB", fill: j }),
        e.jsx(ue, { at: [2.4, 3.8, 1], s: 0.6, color: "#64748b" }),
        e.jsx(z, { frame: t, children: e.jsx(me, { at: F, hour: 1 }) }),
      ],
    }),
  arctic_sledge: (t) =>
    e.jsxs(e.Fragment, {
      children: [
        e.jsx(ge, {}),
        e.jsx(jt, { y: 1.4 }),
        e.jsx(jt, { y: 4.6 }),
        e.jsx(B, {
          from: [4.8, 3.3, 0.9],
          to: [3.4, 3.2, 0.3],
          color: "#334155",
          width: 2.5,
        }),
        e.jsxs(xe, {
          at: [2.6, 3.2, 0.1],
          deg: -12,
          children: [
            e.jsx(i, {
              x: 1.8,
              y: 2.8,
              z: 0.12,
              w: 1.6,
              d: 0.8,
              h: 0.08,
              color: "#a16207",
            }),
            e.jsx(B, {
              from: [1.7, 3.6, 0.02],
              to: [3.5, 3.6, 0.02],
              color: "#334155",
              width: 3,
            }),
            e.jsx(i, {
              x: 2.1,
              y: 2.9,
              z: 0.2,
              w: 0.8,
              d: 0.55,
              h: 0.35,
              color: "#1f4fbf",
            }),
            e.jsx(u, {
              x: 2.1,
              y: 3.45,
              z: 0.2,
              w: 0.8,
              h: 0.35,
              children: e.jsx("rect", {
                x: 30,
                y: 20,
                width: 40,
                height: 14,
                fill: "#94a3b8",
              }),
            }),
          ],
        }),
        e.jsx(ue, { at: [2.5, 3.2, 0.6], s: 0.8 }),
        e.jsx(be, { x: 5.1, y: 3.4, face: "x", reach: !0 }),
        e.jsx(z, {
          frame: t,
          dx: 58,
          children: e.jsx(g, { at: F, text: "-30 °C", fill: "#1e3a8a" }),
        }),
      ],
    }),
  arctic_sensors: () =>
    e.jsxs(e.Fragment, {
      children: [
        e.jsx(ge, {}),
        e.jsx(xt, { x: 1.6, y: 1.8 }),
        e.jsx(ft, { x: 1.4, y: 3.8 }),
        e.jsx(fe, { x: 3.4, y: 1.8, cols: 4, color: "#38bdf8" }),
        e.jsx(fe, { x: 3.6, y: 2.6, cols: 3, color: "#7dd3fc" }),
        e.jsx(g, { at: [5, 2.2, 2.4], text: "2 TB", fill: j }),
        e.jsx(be, { x: 2.8, y: 4.4, face: "away" }),
      ],
    }),
  arctic_model: () =>
    e.jsxs(e.Fragment, {
      children: [
        e.jsx(He, {}),
        e.jsx(N, {
          wall: "y",
          a: 0.4,
          z: 1.2,
          w: 1.2,
          h: 0.8,
          fill: "#0f2546",
          frame: "#f8fafc",
        }),
        e.jsx(P, { x: 1.4, y: 1.4, w: 2, d: 0.9, h: 0.75, color: "#b7793f" }),
        e.jsx(X, { x: 2.3, y: 1.75, z: 0.75, w: 0.9, children: e.jsx(Ze, {}) }),
        e.jsx(Pe, {
          at: [1.95, 1.2, 1.75],
          label: "ICE",
          color: "#0ea5e9",
          s: 0.7,
        }),
        e.jsx(I, { x: 2.3, y: 2.9, color: "#334155" }),
        e.jsx(f, {
          x: 2.3,
          y: 2.85,
          seated: !0,
          shirt: Ie,
          skin: 1,
          hood: De,
          face: "away",
        }),
      ],
    }),
  arctic_failure: (t) =>
    e.jsxs(e.Fragment, {
      children: [
        e.jsx(He, {}),
        e.jsx(N, {
          wall: "y",
          a: 2.8,
          z: 1.2,
          w: 1.3,
          h: 0.9,
          fill: "#cbd5e1",
          frame: "#f8fafc",
        }),
        e.jsx(u, {
          x: 2.8,
          y: 0.003,
          z: 1.2,
          w: 1.3,
          h: 0.9,
          children: e.jsx("path", {
            d: "M6 10l20 10M30 4l18 12M56 14l22 10M10 36l22 10M44 32l20 12M70 40l20 10",
            stroke: b,
            strokeWidth: 4,
            strokeLinecap: "round",
          }),
        }),
        e.jsx(P, { x: 1.4, y: 1.4, w: 2, d: 0.9, h: 0.75, color: "#b7793f" }),
        e.jsx(Le, { at: [2, 1.4, 1.1] }),
        e.jsxs(X, {
          x: 2.3,
          y: 1.75,
          z: 0.75,
          w: 0.9,
          children: [
            e.jsx("rect", { width: 100, height: 60, fill: "#0f172a" }),
            e.jsx("text", {
              x: 50,
              y: 36,
              textAnchor: "middle",
              fontSize: 16,
              fontWeight: 700,
              fill: "#ef4444",
              fontFamily: D,
              children: "NO DISK",
            }),
          ],
        }),
        e.jsx(be, { x: 4, y: 2, face: "away", reach: !0 }),
        e.jsx(z, {
          frame: t,
          dx: 58,
          children: e.jsx(g, { at: F, text: "500 km" }),
        }),
      ],
    }),
  arctic_archive: (t) =>
    e.jsxs(e.Fragment, {
      children: [
        e.jsx(He, {}),
        e.jsx(Y, {
          x: 0.6,
          y: 0.3,
          w: 2.2,
          rows: 4,
          colors: ["#38bdf8", "#0ea5e9", "#e0f2fe", "#1e3a8a"],
        }),
        e.jsx(Y, {
          x: 3,
          y: 0.3,
          w: 2.2,
          rows: 4,
          colors: ["#0ea5e9", "#e0f2fe", "#1e3a8a", "#38bdf8"],
        }),
        e.jsx(f, {
          x: 3.4,
          y: 3.6,
          shirt: Ie,
          legs: "#1e293b",
          skin: 1,
          hood: De,
          face: "y",
          reach: !0,
        }),
        e.jsx(i, {
          x: 3.15,
          y: 3.95,
          z: 1.1,
          w: 0.7,
          d: 0.55,
          h: 0.5,
          color: "#0ea5e9",
        }),
        e.jsx(g, { at: [5, 3.3, 2.4], text: "10 TB", fill: j }),
        e.jsx(z, {
          frame: t,
          children: e.jsx(U, { at: F, text: "20 YRS", w: 66 }),
        }),
      ],
    }),
  arctic_share: () =>
    e.jsxs(e.Fragment, {
      children: [
        e.jsx(ge, {}),
        e.jsx(ht, { x: 3.2, y: 1.4, open: !0 }),
        e.jsx(i, { x: 2.2, y: 3, w: 0.8, d: 0.6, h: 0.6, color: "#a16207" }),
        e.jsx(i, {
          x: 2.4,
          y: 3.1,
          z: 0.6,
          w: 0.4,
          d: 0.4,
          h: 0.15,
          color: "#92400e",
        }),
        [0, 1, 2, 3, 4].map((t) =>
          e.jsx(
            Ht,
            {
              x: 3.2,
              y: 3.3,
              z: t * 0.06,
              color: t % 2 ? "#fcd34d" : "#fde68a",
            },
            t,
          ),
        ),
        e.jsx(g, { at: [2.6, 3.4, 1.6], text: "x40", fill: j }),
        e.jsx(be, { x: 5, y: 3.4, face: "away", reach: !0 }),
      ],
    }),
  arctic_hut: () =>
    e.jsxs(e.Fragment, {
      children: [
        e.jsx(He, {}),
        e.jsx(P, { x: 1.4, y: 1.4, w: 2, d: 0.9, h: 0.75, color: "#b7793f" }),
        e.jsx(X, { x: 2.3, y: 1.75, z: 0.75, w: 0.9, children: e.jsx(Ze, {}) }),
        e.jsx(i, {
          x: 1.5,
          y: 1.9,
          z: 0.75,
          w: 0.4,
          d: 0.3,
          h: 0.06,
          color: "#7c2d12",
        }),
        e.jsx(at, { at: [2, 1.2, 2.5], n: 4, spread: 32 }),
        e.jsx(I, { x: 2.3, y: 2.9, color: "#334155" }),
        e.jsx(f, {
          x: 2.3,
          y: 2.85,
          seated: !0,
          shirt: Ie,
          skin: 1,
          hood: De,
          face: "away",
        }),
      ],
    }),
  arctic_month: (t) =>
    e.jsxs(e.Fragment, {
      children: [
        e.jsx(ge, {}),
        e.jsx(xt, { x: 2, y: 2 }),
        (() => {
          const [s, r] = y(2, 2, 1.95);
          return e.jsx("g", {
            fill: "#0ea5e9",
            children: [0, 1, 2].map((a) =>
              e.jsx(
                "rect",
                {
                  x: s + 14 + a * 14,
                  y: r - 10 - a * 12,
                  width: 10,
                  height: 10,
                  rx: 2,
                  opacity: 1 - a * 0.25,
                },
                a,
              ),
            ),
          });
        })(),
        e.jsx(g, { at: [3.4, 1.6, 2.2], text: "2 MB", fill: j }),
        e.jsx(be, { x: 3.6, y: 3.6, face: "away" }),
        e.jsx(z, {
          frame: t,
          children: e.jsx(U, { at: F, text: "500/DAY", w: 72 }),
        }),
      ],
    }),
  arctic_photos: () =>
    e.jsxs(e.Fragment, {
      children: [
        e.jsx(ge, {}),
        e.jsx(ft, { x: 2, y: 2.2 }),
        e.jsx(zs, { x: 2.6, y: 3.8 }),
        e.jsx(i, {
          x: 3.2,
          y: 2.2,
          z: 1.4,
          w: 0.6,
          d: 0.05,
          h: 0.8,
          color: "#1e3a8a",
          left: "#1e3a8a",
        }),
        e.jsxs(u, {
          x: 3.2,
          y: 2.25,
          z: 1.4,
          w: 0.6,
          h: 0.8,
          children: [
            e.jsx("rect", { x: 10, y: 22, width: 80, height: 22, fill: b }),
            e.jsx("text", {
              x: 50,
              y: 39,
              textAnchor: "middle",
              fontSize: 16,
              fontWeight: 700,
              fill: T,
              fontFamily: D,
              children: "64 GB",
            }),
          ],
        }),
        e.jsx(g, { at: [1.6, 3.2, 1.2], text: "4 MB", fill: j }),
      ],
    }),
};
function Ps({ id: t, frame: s }) {
  return e.jsx(e.Fragment, { children: Ns[t]?.(s) });
}
const Te = j;
function ce() {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx(re, { id: "si-shot-arena", from: "#141236", to: "#24205a" }),
      e.jsx(ie, { color: "#3b3680" }),
      e.jsx(Se, { left: "#2a2670", right: "#332e84" }),
    ],
  });
}
function mt({ night: t }) {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx(re, {
        id: `si-shot-esports-out${t ? "n" : ""}`,
        from: t ? "#141236" : "#93c5fd",
        to: t ? "#3b3680" : "#e0f2fe",
      }),
      e.jsx("rect", {
        x: -2e3,
        y: 40,
        width: 4e3,
        height: 4e3,
        fill: "#64748b",
      }),
      e.jsx(ie, {
        x0: -4,
        y0: 4.6,
        x1: 14,
        y1: 5,
        color: "#f8fafc",
        lines: !1,
      }),
    ],
  });
}
function Fe({ x: t, y: s, screen: r, kai: a = !0 }) {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx(P, { x: t, y: s, w: 1.8, d: 0.9, h: 0.75, color: "#4c1d95" }),
      e.jsx(se, {
        x: t + 0.8,
        y: s + 0.2,
        z: 0.75,
        w: 1.1,
        h: 0.62,
        frame: "#020617",
        children:
          r === "load"
            ? e.jsxs(e.Fragment, {
                children: [
                  e.jsx("rect", { width: 100, height: 60, fill: "#0f172a" }),
                  e.jsx("text", {
                    x: 50,
                    y: 26,
                    textAnchor: "middle",
                    fontSize: 11,
                    fontWeight: 700,
                    fill: "#c7d2fe",
                    fontFamily: D,
                    children: "LOADING",
                  }),
                  e.jsx("rect", {
                    x: 14,
                    y: 34,
                    width: 72,
                    height: 8,
                    rx: 4,
                    fill: "#312e81",
                  }),
                  e.jsx("rect", {
                    x: 14,
                    y: 34,
                    width: 22,
                    height: 8,
                    rx: 4,
                    fill: j,
                  }),
                ],
              })
            : r === "dead"
              ? e.jsx("rect", { width: 100, height: 60, fill: "#020617" })
              : e.jsx(Ce, {}),
      }),
      e.jsx(Ke, {
        x: t + 1.9,
        y: s,
        glow: r === "dead" ? "#ef4444" : "#a855f7",
      }),
      a
        ? e.jsxs(e.Fragment, {
            children: [
              e.jsx(I, { x: t + 0.8, y: s + 1.5, color: j }),
              e.jsx(f, {
                x: t + 0.8,
                y: s + 1.45,
                seated: !0,
                shirt: Te,
                hair: 3,
                face: "away",
                phones: "#e2e8f0",
              }),
            ],
          })
        : null,
    ],
  });
}
function ut({ x: t, y: s, z: r = 0, color: a }) {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx(i, { x: t, y: s, z: r, w: 0.45, d: 0.1, h: 0.6, color: a }),
      e.jsxs(u, {
        x: t,
        y: s + 0.1,
        z: r,
        w: 0.45,
        h: 0.6,
        children: [
          e.jsx("rect", {
            x: 10,
            y: 8,
            width: 80,
            height: 30,
            fill: M(a, 0.35),
          }),
          e.jsx("rect", { x: 10, y: 44, width: 50, height: 6, fill: b }),
        ],
      }),
    ],
  });
}
function pt({ x: t, y: s, hold: r }) {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx(A, { x: t, y: s, w: 5.2, d: 1.5 }),
      e.jsx(i, { x: t, y: s, z: 0.3, w: 5, d: 1.4, h: 1.8, color: "#f8fafc" }),
      e.jsxs(u, {
        x: t,
        y: s + 1.4,
        z: 0.3,
        w: 5,
        h: 1.8,
        children: [
          [4, 22, 40, 58, 76].map((a) =>
            e.jsx(
              "rect",
              { x: a, y: 4, width: 15, height: 18, fill: "#1e3a8a" },
              a,
            ),
          ),
          e.jsx("rect", { x: 0, y: 26, width: 100, height: 6, fill: j }),
          r
            ? e.jsx("rect", {
                x: 30,
                y: 36,
                width: 34,
                height: 22,
                fill: "#0f172a",
              })
            : e.jsx("rect", {
                x: 30,
                y: 36,
                width: 34,
                height: 22,
                fill: "#e2e8f0",
              }),
        ],
      }),
      e.jsx(G, {
        x: t + 5,
        y: s,
        z: 0.3,
        d: 1.4,
        h: 1.8,
        children: e.jsx("rect", {
          x: 8,
          y: 4,
          width: 84,
          height: 20,
          fill: "#1e3a8a",
        }),
      }),
      e.jsx(v, {
        c: [t + 0.9, s + 1.41, 0.3],
        r: 0.3,
        plane: "y",
        fill: "#111827",
      }),
      e.jsx(v, {
        c: [t + 4.1, s + 1.41, 0.3],
        r: 0.3,
        plane: "y",
        fill: "#111827",
      }),
    ],
  });
}
function As({ x: t, y: s, z: r }) {
  const [a, o] = y(t, s, r);
  return e.jsxs("g", {
    transform: `translate(${a} ${o})`,
    children: [
      e.jsx("rect", { x: -10, y: -8, width: 20, height: 8, fill: "#78350f" }),
      e.jsx("rect", { x: -3, y: -20, width: 6, height: 12, fill: "#d4a017" }),
      e.jsx("path", { d: "M-16 -46h32v6a16 16 0 0 1-32 0z", fill: "#fbbf24" }),
      e.jsx("path", {
        d: "M-16 -42h-6v6a8 8 0 0 0 8 6M16 -42h6v6a8 8 0 0 1-8 6",
        fill: "none",
        stroke: "#fbbf24",
        strokeWidth: 3,
      }),
    ],
  });
}
const Rs = {
  esports_load: () =>
    e.jsxs(e.Fragment, {
      children: [
        e.jsx(ce, {}),
        e.jsx(N, {
          wall: "y",
          a: 0.6,
          z: 0.8,
          w: 3,
          h: 1.3,
          fill: "#020617",
          frame: "#818cf8",
        }),
        e.jsxs(u, {
          x: 0.7,
          y: 0.003,
          z: 0.87,
          w: 2.8,
          h: 1.16,
          children: [
            e.jsx("rect", { width: 100, height: 60, fill: "#020617" }),
            e.jsx("text", {
              x: 50,
              y: 42,
              textAnchor: "middle",
              fontSize: 34,
              fontWeight: 700,
              fill: j,
              fontFamily: D,
              children: "0:57",
            }),
          ],
        }),
        e.jsx(Fe, { x: 1.6, y: 1.8, screen: "load" }),
        e.jsx(f, {
          x: 4.4,
          y: 4,
          shirt: "#111827",
          legs: "#111827",
          skin: 2,
          hair: 0,
          face: "away",
          reach: !0,
        }),
      ],
    }),
  esports_installs: () =>
    e.jsxs(e.Fragment, {
      children: [
        e.jsx(ce, {}),
        e.jsx(Fe, { x: 1.4, y: 1.8, kai: !1 }),
        Array.from({ length: 12 }, (t, s) =>
          e.jsx(
            ut,
            {
              x: 4.4 + (s % 4) * 0.5,
              y: 2.2 + Math.floor(s / 4) * 0.35,
              color: [
                "#7c3aed",
                "#1f4fbf",
                "#0f766e",
                "#c8372d",
                "#d4a017",
                "#db2777",
              ][s % 6],
            },
            s,
          ),
        ),
        e.jsx(g, { at: [5.6, 2.4, 1.5], text: "1.5 TB", fill: j }),
        e.jsx(f, {
          x: 3,
          y: 4.2,
          shirt: Te,
          hair: 3,
          face: "x",
          phones: "#e2e8f0",
          reach: !0,
        }),
      ],
    }),
  esports_stream: () =>
    e.jsxs(e.Fragment, {
      children: [
        e.jsx(ce, {}),
        e.jsx(Fe, { x: 1.4, y: 1.6 }),
        e.jsx(i, {
          x: 2.1,
          y: 1.75,
          z: 1.55,
          w: 0.2,
          d: 0.12,
          h: 0.12,
          color: "#111827",
        }),
        e.jsx(i, {
          x: 1.3,
          y: 2.4,
          z: 0.75,
          w: 0.06,
          d: 0.06,
          h: 0.9,
          color: "#475569",
        }),
        e.jsx(i, {
          x: 1.25,
          y: 2.5,
          z: 1.6,
          w: 0.16,
          d: 0.16,
          h: 0.24,
          color: "#111827",
        }),
        e.jsx(v, {
          c: [0.6, 2.6, 1.6],
          r: 0.5,
          plane: "x",
          fill: "#fef3c7",
          stroke: "#fbbf24",
          width: 3,
        }),
        e.jsx(at, { at: [2.6, 1.6, 2.5], n: 4, spread: 34 }),
        e.jsxs("g", {
          transform: `translate(${y(3.8, 1.2, 2.4)[0]} ${y(3.8, 1.2, 2.4)[1]})`,
          children: [
            e.jsx("rect", {
              x: -22,
              y: -11,
              width: 44,
              height: 22,
              rx: 11,
              fill: "#c8372d",
            }),
            e.jsx("text", {
              x: 0,
              y: 5,
              textAnchor: "middle",
              fontSize: 12,
              fontWeight: 700,
              fill: b,
              fontFamily: D,
              children: "LIVE",
            }),
          ],
        }),
      ],
    }),
  esports_lan: () =>
    e.jsxs(e.Fragment, {
      children: [
        e.jsx(mt, {}),
        e.jsx(pt, { x: 1.5, y: 0.6 }),
        e.jsx(f, {
          x: 2.2,
          y: 3.8,
          shirt: Te,
          hair: 3,
          face: "x",
          phones: "#e2e8f0",
          reach: !0,
        }),
        e.jsx(i, {
          x: 2.5,
          y: 3.6,
          z: 0.95,
          w: 0.4,
          d: 0.3,
          h: 0.3,
          color: "#111827",
        }),
        e.jsx(f, { x: 3.6, y: 4.1, shirt: Te, hair: 2, face: "x" }),
        e.jsx(i, {
          x: 3.3,
          y: 3.85,
          z: 0.95,
          w: 0.12,
          d: 0.5,
          h: 0.6,
          color: "#4c1d95",
        }),
        e.jsx(f, { x: 5, y: 4.4, shirt: Te, hair: 1, skin: 3, face: "x" }),
        e.jsx(g, { at: [4.6, 1.2, 2.7], text: "AWAY" }),
      ],
    }),
  esports_coach: () =>
    e.jsxs(e.Fragment, {
      children: [
        e.jsx(mt, {}),
        e.jsx(pt, { x: 0.5, y: 0.2, hold: !0 }),
        e.jsx(xe, {
          at: [2.6, 1.7, 0.5],
          deg: -14,
          children: e.jsx(i, {
            x: 2,
            y: 1.4,
            z: 0.35,
            w: 0.7,
            d: 0.4,
            h: 0.4,
            color: "#1f4fbf",
          }),
        }),
        e.jsx(xe, {
          at: [3.3, 1.7, 0.5],
          deg: 22,
          children: e.jsx(Ke, { x: 3, y: 1.3, z: 0.35, glow: "#a855f7" }),
        }),
        e.jsx(xe, {
          at: [3.9, 1.8, 0.5],
          deg: -8,
          children: e.jsx(i, {
            x: 3.6,
            y: 1.5,
            z: 0.35,
            w: 0.6,
            d: 0.4,
            h: 0.5,
            color: "#c8372d",
          }),
        }),
        e.jsx(ue, { at: [3.2, 1.8, 1.4], s: 0.9 }),
        e.jsx(g, { at: [2, 3.4, 2.6], text: "4 h" }),
      ],
    }),
  esports_replays: (t) =>
    e.jsxs(e.Fragment, {
      children: [
        e.jsx(ce, {}),
        e.jsx(Y, {
          x: 0.6,
          y: 0.3,
          w: 2.2,
          rows: 4,
          colors: ["#7c3aed", "#4338ca", "#db2777", "#1f4fbf"],
        }),
        e.jsx(Y, {
          x: 3,
          y: 0.3,
          w: 2.2,
          rows: 4,
          colors: ["#4338ca", "#db2777", "#7c3aed", "#1f4fbf"],
        }),
        e.jsx(f, {
          x: 3.4,
          y: 3.6,
          shirt: "#0f172a",
          legs: "#0f172a",
          skin: 1,
          hair: 1,
          face: "y",
          reach: !0,
        }),
        e.jsx(i, {
          x: 3.2,
          y: 3.95,
          z: 1.1,
          w: 0.45,
          d: 0.04,
          h: 0.6,
          color: "#b7793f",
        }),
        e.jsxs(u, {
          x: 3.2,
          y: 3.99,
          z: 1.1,
          w: 0.45,
          h: 0.6,
          children: [
            e.jsx("rect", { x: 12, y: 10, width: 76, height: 44, fill: b }),
            e.jsx("path", {
              d: "M22 22h50M22 32h40M22 42h46",
              stroke: T,
              strokeWidth: 4,
            }),
          ],
        }),
        e.jsx(g, { at: [5, 3.3, 2.4], text: "8 TB", fill: j }),
        e.jsx(z, {
          frame: t,
          children: e.jsx(U, { at: F, text: "5 YRS", w: 62 }),
        }),
      ],
    }),
  esports_expo: () =>
    e.jsxs(e.Fragment, {
      children: [
        e.jsx(ce, {}),
        e.jsx(N, {
          wall: "y",
          a: 1,
          z: 1,
          w: 3.6,
          h: 1.6,
          fill: j,
          frame: "#fb923c",
        }),
        e.jsx(u, {
          x: 1,
          y: 0.003,
          z: 1,
          w: 3.6,
          h: 1.6,
          children: e.jsx("text", {
            x: 50,
            y: 40,
            textAnchor: "middle",
            fontSize: 26,
            fontWeight: 700,
            fill: b,
            fontFamily: D,
            children: "VOLT",
          }),
        }),
        e.jsx(P, { x: 1.6, y: 1.8, w: 2.6, d: 1, h: 0.85, color: "#4c1d95" }),
        e.jsx(Oe, { x: 1.8, y: 2, z: 0.85, n: 8 }),
        e.jsx(Oe, { x: 2.6, y: 2, z: 0.85, n: 10 }),
        e.jsx(Oe, { x: 3.4, y: 2, z: 0.85, n: 7 }),
        e.jsx(g, { at: [2.9, 2.3, 2.6], text: "x100", fill: j }),
        e.jsx(f, {
          x: 2,
          y: 4.4,
          shirt: "#22c55e",
          skin: 0,
          hair: 2,
          face: "away",
          reach: !0,
        }),
        e.jsx(f, {
          x: 3.2,
          y: 4.7,
          shirt: "#38bdf8",
          skin: 2,
          hair: 3,
          face: "away",
        }),
        e.jsx(f, {
          x: 4.4,
          y: 4.4,
          shirt: "#f472b6",
          skin: 1,
          hair: 1,
          face: "away",
          reach: !0,
        }),
      ],
    }),
  esports_failure: (t) =>
    e.jsxs(e.Fragment, {
      children: [
        e.jsx(ce, {}),
        e.jsx(N, {
          wall: "y",
          a: 0.4,
          z: 1.2,
          w: 1.4,
          h: 1.1,
          fill: "#020617",
          frame: "#818cf8",
        }),
        e.jsx(Ct, { at: [1.8, 0, 2.1], r: 12, sky: "#020617" }),
        e.jsx(i, {
          x: 4.2,
          y: 0.1,
          z: 1.4,
          w: 1.2,
          d: 0.4,
          h: 0.08,
          color: "#4c1d95",
        }),
        e.jsx(As, { x: 4.8, y: 0.3, z: 1.48 }),
        e.jsx(Le, { at: [3.6, 1.8, 1] }),
        e.jsx(Fe, { x: 1.6, y: 1.6, screen: "dead" }),
        e.jsx(z, {
          frame: t,
          children: e.jsx(U, { at: F, text: "FINAL", w: 62 }),
        }),
      ],
    }),
  esports_space: () =>
    e.jsxs(e.Fragment, {
      children: [
        e.jsx(ce, {}),
        e.jsx(i, { x: 2.6, y: 1.4, w: 0.9, d: 1.4, h: 1.8, color: "#1e293b" }),
        e.jsxs(G, {
          x: 3.5,
          y: 1.4,
          z: 0,
          d: 1.4,
          h: 1.8,
          children: [
            e.jsx("rect", {
              x: 10,
              y: 10,
              width: 80,
              height: 14,
              fill: "#0f172a",
            }),
            e.jsx("rect", { x: 12, y: 12, width: 30, height: 10, fill: j }),
            e.jsx("text", {
              x: 50,
              y: 40,
              textAnchor: "middle",
              fontSize: 11,
              fontWeight: 700,
              fill: "#c7d2fe",
              fontFamily: D,
              children: "400 GB / 1 TB",
            }),
          ],
        }),
        e.jsx(u, {
          x: 2.6,
          y: 2.8,
          z: 0,
          w: 0.9,
          h: 1.8,
          children: e.jsx("circle", { cx: 50, cy: 14, r: 6, fill: "#a855f7" }),
        }),
        e.jsx(ut, { x: 4.4, y: 3.4, z: 0.9, color: "#7c3aed" }),
        e.jsx(g, { at: [4.6, 3.5, 2.2], text: "120 GB", fill: j }),
        e.jsx(f, {
          x: 1.6,
          y: 3.6,
          shirt: Te,
          hair: 3,
          face: "x",
          phones: "#e2e8f0",
        }),
      ],
    }),
  esports_month: (t) =>
    e.jsxs(e.Fragment, {
      children: [
        e.jsx(ce, {}),
        e.jsx(Fe, { x: 1.6, y: 1.6 }),
        e.jsx(g, { at: [2.4, 1.8, 2.3], text: "500 MB", fill: j }),
        e.jsx(z, {
          frame: t,
          children: e.jsx(U, { at: F, text: "40/MO", w: 62 }),
        }),
      ],
    }),
};
function $s({ id: t, frame: s }) {
  return e.jsx(e.Fragment, { children: Rs[t]?.(s) });
}
function ae({ dusk: t, night: s }) {
  const r = s
    ? ["#0f172a", "#1e3a5f"]
    : t
      ? ["#f59e0b", "#fde3d2"]
      : ["#9fd8f6", "#e8f6fd"];
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx(re, {
        id: `si-shot-film-${s ? "n" : t ? "d" : "a"}`,
        from: r[0],
        to: r[1],
      }),
      e.jsx("path", {
        d: "M-600 40q140-90 280-30t260-30t240 20t260-10v400h-1040z",
        fill: s ? "#1f3b2d" : "#a7d3a0",
      }),
      e.jsx("rect", {
        x: -2e3,
        y: 50,
        width: 4e3,
        height: 4e3,
        fill: s ? "#3f6b3a" : "#86c46f",
      }),
      e.jsx(J, {
        points: [
          [0, 6.4, 0.002],
          [12, 4.4, 0.002],
          [12, 5.6, 0.002],
          [0, 7.6, 0.002],
        ],
        fill: s ? "#6b5a3c" : "#d9b27c",
      }),
    ],
  });
}
function ze({ x: t, y: s }) {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx(P, { x: t, y: s, w: 2, d: 1, h: 0.8, color: "#64748b" }),
      e.jsx(i, {
        x: t + 0.05,
        y: s + 0.05,
        z: 0.25,
        w: 1.9,
        d: 0.9,
        h: 0.05,
        color: "#94a3b8",
      }),
      e.jsx(V, { x: t + 0.15, y: s + 0.95, r: 0.08, h: 0.1, color: "#111827" }),
      e.jsx(V, { x: t + 1.85, y: s + 0.95, r: 0.08, h: 0.1, color: "#111827" }),
    ],
  });
}
function yt({ x: t, y: s, slowmo: r }) {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx(A, { x: t - 0.5, y: s - 0.4, w: 1, d: 1 }),
      e.jsx(B, {
        from: [t, s, 1.25],
        to: [t - 0.4, s - 0.3, 0],
        color: "#334155",
        width: 3,
      }),
      e.jsx(B, {
        from: [t, s, 1.25],
        to: [t + 0.4, s - 0.15, 0],
        color: "#334155",
        width: 3,
      }),
      e.jsx(B, {
        from: [t, s, 1.25],
        to: [t, s + 0.45, 0],
        color: "#334155",
        width: 3,
      }),
      e.jsx(i, {
        x: t - 0.25,
        y: s - 0.18,
        z: 1.25,
        w: 0.5,
        d: 0.36,
        h: 0.32,
        color: r ? "#7c2d12" : "#1f2937",
      }),
      e.jsx(i, {
        x: t - 0.1,
        y: s + 0.18,
        z: 1.3,
        w: 0.2,
        d: 0.2,
        h: 0.2,
        color: "#475569",
      }),
      e.jsx(v, {
        c: [t, s + 0.385, 1.4],
        r: 0.09,
        plane: "y",
        fill: "#0ea5e9",
      }),
      e.jsx(v, {
        c: [t - 0.12, s - 0.05, 1.75],
        r: 0.13,
        plane: "x",
        fill: "none",
        stroke: "#1f2937",
        width: 3,
      }),
      e.jsx(v, {
        c: [t + 0.12, s - 0.05, 1.75],
        r: 0.13,
        plane: "x",
        fill: "none",
        stroke: "#1f2937",
        width: 3,
      }),
    ],
  });
}
function Qe({ x: t, y: s }) {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx(A, { x: t - 0.1, y: s, w: 2.8, d: 1.3 }),
      e.jsx(i, {
        x: t,
        y: s,
        z: 0.2,
        w: 2.6,
        d: 1.2,
        h: 1.25,
        color: "#f8fafc",
      }),
      e.jsxs(u, {
        x: t,
        y: s + 1.2,
        z: 0.2,
        w: 2.6,
        h: 1.25,
        children: [
          e.jsx("rect", { x: 0, y: 30, width: 100, height: 8, fill: j }),
          e.jsx("rect", { x: 6, y: 8, width: 26, height: 16, fill: "#7dd3fc" }),
        ],
      }),
      e.jsx(v, {
        c: [t + 0.55, s + 1.21, 0.2],
        r: 0.2,
        plane: "y",
        fill: "#1f2937",
      }),
      e.jsx(v, {
        c: [t + 2.05, s + 1.21, 0.2],
        r: 0.2,
        plane: "y",
        fill: "#1f2937",
      }),
    ],
  });
}
function Ws({ x: t, y: s, z: r }) {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx(i, {
        x: t,
        y: s,
        z: r,
        w: 0.7,
        d: 0.06,
        h: 0.9,
        color: "#1e3a8a",
        left: "#1e3a8a",
      }),
      e.jsxs(u, {
        x: t,
        y: s + 0.06,
        z: r,
        w: 0.7,
        h: 0.9,
        children: [
          e.jsx("rect", { x: 0, y: 0, width: 30, height: 10, fill: "#0f172a" }),
          [40, 52, 64, 76, 88].map((a) =>
            e.jsx(
              "rect",
              { x: a - 4, y: 2, width: 7, height: 10, fill: "#fbbf24" },
              a,
            ),
          ),
          e.jsx("rect", { x: 10, y: 22, width: 80, height: 22, fill: b }),
          e.jsx("text", {
            x: 50,
            y: 39,
            textAnchor: "middle",
            fontSize: 16,
            fontWeight: 700,
            fill: T,
            fontFamily: "'IBM Plex Mono', monospace",
            children: "64 GB",
          }),
        ],
      }),
    ],
  });
}
const Ls = {
  film_cart: () =>
    e.jsxs(e.Fragment, {
      children: [
        e.jsx(ae, {}),
        e.jsx(te, { x: 1, y: 1.2 }),
        e.jsx(ze, { x: 2, y: 2.4 }),
        e.jsx(X, { x: 2.7, y: 2.85, z: 0.8, children: e.jsx(Be, {}) }),
        e.jsx("path", {
          d: (() => {
            const [t, s] = y(3.3, 3.5, 0.6),
              [r, a] = y(4.9, 4.4, 0.15),
              [o, n] = y(6.5, 5.4, 0);
            return `M${t} ${s}L${r} ${a}Q${o - 20} ${n - 30} ${o} ${n}`;
          })(),
          fill: "none",
          stroke: "#111827",
          strokeWidth: 3,
        }),
        e.jsx(i, { x: 6.3, y: 5.2, w: 0.5, d: 0.4, h: 0.35, color: "#facc15" }),
        e.jsx(xe, {
          at: [3.2, 3.9, 0.2],
          deg: -38,
          children: e.jsx(X, {
            x: 3.2,
            y: 3.9,
            z: 0.35,
            children: e.jsx(Be, {}),
          }),
        }),
        e.jsx(rt, { at: [3, 4.6, 0], s: 0.9 }),
        e.jsx(ue, { at: [3.2, 3.9, 0.7], s: 0.8 }),
        e.jsx(xe, {
          at: [5, 4.6, 0],
          deg: 16,
          children: e.jsx(f, {
            x: 5,
            y: 4.6,
            shirt: j,
            skin: 2,
            hair: 3,
            legs: "#1e3a5f",
            face: "y",
            reach: !0,
            phones: "#1f2937",
          }),
        }),
      ],
    }),
  film_edit: () =>
    e.jsxs(e.Fragment, {
      children: [
        e.jsx(ae, { dusk: !0 }),
        e.jsx(te, { x: 1.2, y: 0.9 }),
        e.jsx(ze, { x: 2, y: 2.5 }),
        e.jsx(X, { x: 3, y: 3, z: 0.8, w: 1.1, children: e.jsx(Be, {}) }),
        e.jsx(Pe, {
          at: [2.75, 2.75, 2.75],
          label: "4K",
          color: "#7c3aed",
          s: 0.55,
          arrows: !1,
        }),
        e.jsx(Pe, {
          at: [2.75, 2.75, 2.25],
          label: "4K",
          color: "#1f4fbf",
          s: 0.55,
          arrows: !1,
        }),
        e.jsx(Pe, { at: [2.75, 2.75, 1.75], label: "4K", s: 0.55 }),
        e.jsx(I, { x: 3, y: 4.1, color: "#1f2937" }),
        e.jsx(f, {
          x: 3,
          y: 4.05,
          seated: !0,
          shirt: "#1f4fbf",
          skin: 0,
          hair: 2,
          face: "away",
        }),
      ],
    }),
  film_rushes: (t) =>
    e.jsxs(e.Fragment, {
      children: [
        e.jsx(ae, { night: !0 }),
        e.jsx(z, {
          frame: t,
          dx: 36,
          dy: 36,
          children: e.jsx(me, { at: F, r: 20, hour: 9, fill: "#fde68a" }),
        }),
        e.jsx(Qe, { x: 4.2, y: 1.2 }),
        e.jsx(f, {
          x: 2.8,
          y: 4.4,
          shirt: "#1f4fbf",
          skin: 0,
          hair: 2,
          face: "x",
          reach: !0,
        }),
        e.jsx(Es, {}),
        e.jsx(f, {
          x: 4.6,
          y: 4,
          shirt: "#facc15",
          legs: "#1e293b",
          skin: 3,
          hair: 3,
          face: "away",
        }),
        e.jsx(g, { at: [3.7, 4.2, 2.5], text: "300 GB", fill: j }),
      ],
    }),
  film_archive: () =>
    e.jsxs(e.Fragment, {
      children: [
        e.jsx(re, { id: "si-shot-film-vault", from: "#e2e8f0", to: "#f8fafc" }),
        e.jsx(ie, { color: "#cbd5e1" }),
        e.jsx(Se, { left: "#94a3b8", right: "#cbd5e1" }),
        e.jsx(Y, { x: 0.8, y: 0.3, w: 2.2, rows: 4 }),
        e.jsx(Y, { x: 3.3, y: 0.3, w: 2.2, rows: 4 }),
        e.jsx(U, { at: [6.4, 0, 2.3], text: "10 YRS", w: 66 }),
        e.jsx(f, {
          x: 3.6,
          y: 3.6,
          shirt: "#1f4fbf",
          skin: 0,
          hair: 2,
          face: "y",
          reach: !0,
        }),
        e.jsx(i, {
          x: 3.35,
          y: 3.95,
          z: 1.1,
          w: 0.7,
          d: 0.55,
          h: 0.5,
          color: j,
        }),
        e.jsx(u, {
          x: 3.35,
          y: 4.5,
          z: 1.1,
          w: 0.7,
          h: 0.5,
          children: e.jsx("text", {
            x: 50,
            y: 40,
            textAnchor: "middle",
            fontSize: 26,
            fontWeight: 700,
            fill: b,
            fontFamily: "'IBM Plex Mono', monospace",
            children: "9 TB",
          }),
        }),
      ],
    }),
  film_festival: () =>
    e.jsxs(e.Fragment, {
      children: [
        e.jsx(ae, {}),
        e.jsx(Qe, { x: 4.4, y: 0.4 }),
        e.jsx(P, { x: 1.8, y: 2.6, w: 2.2, d: 1.1, h: 0.8, color: "#b7793f" }),
        [0, 1, 2, 3, 4, 5].map((t) =>
          e.jsx(
            Ht,
            {
              x: 2,
              y: 2.75,
              z: 0.8 + t * 0.06,
              color: t % 2 ? "#fcd34d" : "#fde68a",
            },
            t,
          ),
        ),
        e.jsx(Oe, { x: 3.05, y: 2.8, z: 0.8, n: 7 }),
        e.jsx(g, { at: [2.6, 2.9, 1.9], text: "x50", fill: j }),
        e.jsx(V, { x: 5.4, y: 4.2, r: 0.32, h: 1.3, color: "#c8372d" }),
        e.jsx(i, {
          x: 5.18,
          y: 4.38,
          z: 0.95,
          w: 0.44,
          d: 0.06,
          h: 0.08,
          color: "#111827",
        }),
        e.jsx(f, {
          x: 4.3,
          y: 4.6,
          shirt: "#1f4fbf",
          skin: 0,
          hair: 2,
          face: "x",
          reach: !0,
        }),
        e.jsx(i, {
          x: 4.75,
          y: 4.42,
          z: 1.2,
          w: 0.06,
          d: 0.45,
          h: 0.32,
          color: "#fcd34d",
        }),
      ],
    }),
  film_library: () =>
    e.jsxs(e.Fragment, {
      children: [
        e.jsx(ae, {}),
        e.jsx(te, { x: 0.8, y: 1 }),
        e.jsx(fe, { x: 3.4, y: 1.4, cols: 4 }),
        e.jsx(fe, { x: 3.6, y: 2.2, cols: 3, color: "#fb923c" }),
        e.jsx(ze, { x: 1.6, y: 2.6 }),
        e.jsx(X, { x: 2.4, y: 3, z: 0.8, children: e.jsx(Be, {}) }),
        e.jsx(g, { at: [5, 1.8, 2.3], text: "2 TB", fill: j }),
        e.jsx(f, {
          x: 3.6,
          y: 4.6,
          shirt: "#1f4fbf",
          skin: 0,
          hair: 2,
          face: "away",
        }),
      ],
    }),
  film_failure: (t) =>
    e.jsxs(e.Fragment, {
      children: [
        e.jsx(ae, {}),
        e.jsx(z, { frame: t, children: e.jsx(U, { at: F, text: "WK 6" }) }),
        e.jsx(ze, { x: 2, y: 2.5 }),
        e.jsx(Le, { at: [2.6, 2.6, 1.3] }),
        e.jsxs(X, {
          x: 2.9,
          y: 3,
          z: 0.8,
          w: 1,
          children: [
            e.jsx("rect", { width: 100, height: 60, fill: "#0f172a" }),
            e.jsx("text", {
              x: 50,
              y: 38,
              textAnchor: "middle",
              fontSize: 20,
              fontWeight: 700,
              fill: "#ef4444",
              fontFamily: "'IBM Plex Mono', monospace",
              children: "NO DISK",
            }),
          ],
        }),
        e.jsx(f, {
          x: 4.4,
          y: 2.7,
          shirt: "#1f4fbf",
          skin: 0,
          hair: 2,
          face: "away",
          reach: !0,
        }),
      ],
    }),
  film_review: () =>
    e.jsxs(e.Fragment, {
      children: [
        e.jsx(ae, {}),
        e.jsx(te, { x: 1, y: 1 }),
        e.jsx(ze, { x: 2, y: 2.5 }),
        e.jsx(X, { x: 3, y: 3, z: 0.8, w: 1.1, children: e.jsx(Be, {}) }),
        e.jsx(I, { x: 3, y: 4, color: "#1f2937" }),
        e.jsx(f, {
          x: 3,
          y: 3.95,
          seated: !0,
          shirt: "#1f4fbf",
          skin: 0,
          hair: 2,
          face: "away",
        }),
        e.jsx(f, {
          x: 4.3,
          y: 3.7,
          shirt: "#334155",
          legs: "#111827",
          skin: 3,
          hair: 0,
          face: "away",
          reach: !0,
        }),
        e.jsx(Et, {
          at: [4.6, 3.4, 2.5],
          w: 64,
          h: 34,
          children: e.jsx("path", {
            d: "M-6 -8v16l-12-8zM-20 -8v16l-12-8zM6 -8v16l12-8zM20 -8v16l12-8z",
            fill: j,
          }),
        }),
      ],
    }),
  film_shoot: (t) =>
    e.jsxs(e.Fragment, {
      children: [
        e.jsx(ae, {}),
        e.jsx(Qe, { x: 4.6, y: 0.3 }),
        e.jsx(yt, { x: 3.4, y: 3.2 }),
        e.jsx(f, {
          x: 2.3,
          y: 3.3,
          shirt: "#1f4fbf",
          skin: 0,
          hair: 2,
          face: "x",
        }),
        e.jsx(g, { at: [4.6, 3, 2.2], text: "375 MB/min", fill: j, size: 12 }),
        e.jsxs(z, {
          frame: t,
          dx: 40,
          dy: 38,
          children: [
            e.jsx(me, { at: F, r: 22, hour: 4 }),
            e.jsx(g, { at: [1.2, 0, 0], text: "4 h" }),
          ],
        }),
      ],
    }),
  film_card: () =>
    e.jsxs(e.Fragment, {
      children: [
        e.jsx(ae, {}),
        e.jsx(te, { x: 1, y: 1.4 }),
        e.jsx(yt, { x: 3, y: 3, slowmo: !0 }),
        e.jsx(Ws, { x: 3.8, y: 3.6, z: 1 }),
        e.jsx(g, { at: [1.6, 3.6, 2.3], text: "2 GB/min", fill: j, size: 12 }),
      ],
    }),
};
function Gs({ id: t, frame: s }) {
  return e.jsx(e.Fragment, { children: Ls[t]?.(s) });
}
function Es() {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx(i, {
        x: 3.4,
        y: 4.1,
        z: 1.1,
        w: 0.55,
        d: 0.45,
        h: 0.35,
        color: "#fcd34d",
      }),
      e.jsx(_e, {
        x: 3.4,
        y: 4.1,
        z: 1.451,
        w: 0.55,
        d: 0.45,
        children: e.jsx("rect", {
          x: 10,
          y: 40,
          width: 80,
          height: 14,
          fill: T,
          opacity: 0.5,
        }),
      }),
    ],
  });
}
const q = "#d4a017",
  je = "#9f1239";
function de() {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx(re, { id: "si-shot-desk", from: "#0f172a", to: "#1e293b" }),
      e.jsx(ie, { color: "#3a4256" }),
      e.jsx(Se, { left: "#1f2a44", right: "#24304d" }),
      e.jsx(B, { from: [0, 0, 0.02], to: [14, 0, 0.02], color: q, width: 2 }),
      e.jsx(B, { from: [0, 0, 0.02], to: [0, 14, 0.02], color: q, width: 2 }),
    ],
  });
}
function Ae({ seed: t = 0 }) {
  const s = [14, 22, 10, 26, 18, 30, 12, 24, 20, 34];
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 100, height: 60, fill: "#0b1020" }),
      s.map((r, a) => {
        const o = (a + t) % 3 !== 1,
          n = 46 - r - ((a * 7 + t * 5) % 9);
        return e.jsx(
          "rect",
          {
            x: 6 + a * 9,
            y: n,
            width: 5,
            height: r,
            fill: o ? "#22c55e" : "#ef4444",
          },
          a,
        );
      }),
      e.jsx("path", {
        d: `M4 ${40 - t} L30 30 L52 34 L74 18 L96 ${12 + t}`,
        fill: "none",
        stroke: "#fbbf24",
        strokeWidth: 2,
      }),
      e.jsx("rect", { y: 52, width: 100, height: 8, fill: "#111827" }),
    ],
  });
}
function Hs({ night: t }) {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", {
        width: 100,
        height: 60,
        fill: t ? "#0b1020" : "#1e3a8a",
      }),
      [
        [4, 30, 12],
        [18, 18, 10],
        [30, 26, 14],
        [46, 8, 10],
        [58, 22, 12],
        [72, 14, 9],
        [83, 28, 13],
      ].map(([s = 0, r = 0, a = 0]) =>
        e.jsxs(
          "g",
          {
            children: [
              e.jsx("rect", {
                x: s,
                y: r,
                width: a,
                height: 60 - r,
                fill: "#0f172a",
              }),
              [0, 1, 2, 3].map((o) =>
                e.jsx(
                  "rect",
                  {
                    x: s + 2,
                    y: r + 4 + o * 7,
                    width: a - 4,
                    height: 2,
                    fill: "#fde68a",
                    opacity: 0.6,
                  },
                  o,
                ),
              ),
            ],
          },
          s,
        ),
      ),
    ],
  });
}
function wt({ x: t, y: s, screen: r }) {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx(P, { x: t, y: s, w: 2.8, d: 1, h: 0.75, color: "#1f2937" }),
      [0.5, 1.4, 2.3].map((a, o) =>
        e.jsxs(
          "g",
          {
            children: [
              e.jsx(i, {
                x: t + a - 0.4,
                y: s,
                z: 1.38,
                w: 0.8,
                d: 0.05,
                h: 0.5,
                color: "#020617",
                left: "#020617",
              }),
              e.jsx(u, {
                x: t + a - 0.37,
                y: s + 0.05,
                z: 1.41,
                w: 0.74,
                h: 0.44,
                children: e.jsx(Ae, { seed: o + 3 }),
              }),
            ],
          },
          `top${a}`,
        ),
      ),
      [0.5, 1.4, 2.3].map((a, o) =>
        e.jsx(
          se,
          {
            x: t + a,
            y: s + 0.12,
            z: 0.75,
            w: 0.84,
            h: 0.5,
            frame: "#020617",
            children:
              r === "loading" && o === 1
                ? e.jsxs(e.Fragment, {
                    children: [
                      e.jsx("rect", {
                        width: 100,
                        height: 60,
                        fill: "#0b1020",
                      }),
                      e.jsx("rect", {
                        x: 14,
                        y: 26,
                        width: 72,
                        height: 8,
                        rx: 4,
                        fill: "#1f2937",
                      }),
                      e.jsx("rect", {
                        x: 14,
                        y: 26,
                        width: 26,
                        height: 8,
                        rx: 4,
                        fill: q,
                      }),
                    ],
                  })
                : e.jsx(Ae, { seed: o }),
          },
          a,
        ),
      ),
    ],
  });
}
function Cs() {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx(re, { id: "si-shot-city", from: "#7dd3fc", to: "#e0f2fe" }),
      [
        [-260, -90, 60],
        [-190, -150, 50],
        [-130, -60, 70],
        [-50, -170, 46],
        [10, -110, 64],
        [90, -140, 52],
        [150, -70, 70],
        [230, -160, 56],
        [290, -100, 60],
      ].map(([t = 0, s = 0, r = 0]) =>
        e.jsxs(
          "g",
          {
            children: [
              e.jsx("rect", {
                x: t,
                y: s,
                width: r,
                height: 400,
                fill: "#334155",
              }),
              [0, 1, 2, 3, 4, 5, 6].map((a) =>
                e.jsx(
                  "rect",
                  {
                    x: t + 6,
                    y: s + 10 + a * 18,
                    width: r - 12,
                    height: 6,
                    fill: "#bae6fd",
                    opacity: 0.5,
                  },
                  a,
                ),
              ),
            ],
          },
          t,
        ),
      ),
      e.jsx("rect", {
        x: -2e3,
        y: 60,
        width: 4e3,
        height: 4e3,
        fill: "#9ca3af",
      }),
    ],
  });
}
function gt({ x: t, y: s, z: r }) {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx(i, {
        x: t,
        y: s,
        z: r,
        w: 0.6,
        d: 0.16,
        h: 0.45,
        color: "#111827",
      }),
      e.jsx(u, {
        x: t,
        y: s + 0.16,
        z: r,
        w: 0.6,
        h: 0.45,
        children: e.jsx("rect", {
          x: 10,
          y: 30,
          width: 80,
          height: 6,
          fill: q,
        }),
      }),
    ],
  });
}
const Os = {
  finance_screens: () =>
    e.jsxs(e.Fragment, {
      children: [
        e.jsx(de, {}),
        e.jsx(wt, { x: 1.4, y: 1.4 }),
        e.jsx(I, { x: 2.8, y: 3, color: "#111827" }),
        e.jsx(f, {
          x: 2.8,
          y: 2.95,
          seated: !0,
          shirt: je,
          skin: 2,
          hair: 0,
          face: "away",
        }),
      ],
    }),
  finance_open: (t) =>
    e.jsxs(e.Fragment, {
      children: [
        e.jsx(de, {}),
        e.jsx(wt, { x: 1.4, y: 1.4, screen: "loading" }),
        e.jsx(I, { x: 2.8, y: 3, color: "#111827" }),
        e.jsx(f, {
          x: 2.8,
          y: 2.95,
          seated: !0,
          shirt: je,
          skin: 2,
          hair: 0,
          face: "away",
        }),
        e.jsx(z, {
          frame: t,
          dx: 44,
          children: e.jsx(me, {
            at: F,
            hour: 8,
            minute: 0,
            r: 24,
            fill: "#fef3c7",
          }),
        }),
      ],
    }),
  finance_model: () =>
    e.jsxs(e.Fragment, {
      children: [
        e.jsx(de, {}),
        e.jsx(N, {
          wall: "y",
          a: 0.4,
          z: 0.4,
          w: 2,
          h: 2.3,
          fill: "#0b1020",
          frame: q,
        }),
        e.jsx(u, {
          x: 0.45,
          y: 0.003,
          z: 0.45,
          w: 1.9,
          h: 2.2,
          children: e.jsx(Hs, { night: !0 }),
        }),
        e.jsx(Ct, { at: [2.1, 0, 2.4], r: 10, sky: "#0b1020" }),
        e.jsx(P, { x: 1.6, y: 1.4, w: 2, d: 0.9, h: 0.75, color: "#1f2937" }),
        e.jsx(se, {
          x: 2.3,
          y: 1.55,
          z: 0.75,
          w: 0.9,
          h: 0.55,
          frame: "#020617",
          children: e.jsx(Ae, { seed: 4 }),
        }),
        e.jsx(Ke, { x: 3, y: 1.3, z: 0.75, glow: q }),
        e.jsx(Pe, { at: [2, 1.1, 1.9], label: "£", color: q, s: 0.7 }),
        e.jsx(I, { x: 2.3, y: 2.9, color: "#111827" }),
        e.jsx(f, {
          x: 2.3,
          y: 2.85,
          seated: !0,
          shirt: "#475569",
          skin: 1,
          hair: 1,
          face: "away",
        }),
      ],
    }),
  finance_failure: (t) =>
    e.jsxs(e.Fragment, {
      children: [
        e.jsx(de, {}),
        e.jsx(A, { x: 0.5, y: 0.6, w: 1, d: 1.2 }),
        e.jsx(i, { x: 0.5, y: 0.6, w: 0.9, d: 1.1, h: 2.1, color: "#111827" }),
        e.jsx(G, {
          x: 1.4,
          y: 0.6,
          z: 0,
          d: 1.1,
          h: 2.1,
          children: [6, 14, 22, 30, 38, 46].map((s, r) =>
            e.jsxs(
              "g",
              {
                children: [
                  e.jsx("rect", {
                    x: 10,
                    y: s,
                    width: 80,
                    height: 5,
                    fill: "#1f2937",
                  }),
                  e.jsx("circle", {
                    cx: 80,
                    cy: s + 2.5,
                    r: 2,
                    fill: r === 2 ? "#ef4444" : "#22c55e",
                  }),
                ],
              },
              s,
            ),
          ),
        }),
        e.jsx(Le, { at: [1, 1.4, 1.9] }),
        e.jsx(f, {
          x: 2.6,
          y: 3.3,
          shirt: je,
          skin: 2,
          hair: 0,
          face: "away",
          reach: !0,
        }),
        e.jsx(z, {
          frame: t,
          children: e.jsx(me, { at: F, hour: 3, minute: 0 }),
        }),
      ],
    }),
  finance_pitch: () =>
    e.jsxs(e.Fragment, {
      children: [
        e.jsx(Cs, {}),
        e.jsx(ie, { x0: -4, y0: 1.5, x1: 14, y1: 4.6, color: "#cbd5e1" }),
        e.jsx(Ss, { at: [3, 3.2, 1.6], len: 50, color: "#64748b" }),
        e.jsx(f, { x: 3, y: 3, shirt: je, skin: 2, hair: 0, face: "y" }),
        e.jsx(gt, { x: 2.7, y: 3.24, z: 0.6 }),
        e.jsx(g, { at: [2, 3.8, 1.5], text: "20 GB", fill: j }),
      ],
    }),
  finance_platform: () =>
    e.jsxs(e.Fragment, {
      children: [
        e.jsx(re, { id: "si-shot-station", from: "#cbd5e1", to: "#e2e8f0" }),
        e.jsx(Se, { left: "#94a3b8", right: "#a8b3c4", h: 3.2 }),
        e.jsx(ie, { x0: 0, y0: 0, x1: 14, y1: 4.6, color: "#d1d5db" }),
        e.jsx(J, {
          points: [
            [0, 4.2, 0.003],
            [14, 4.2, 0.003],
            [14, 4.45, 0.003],
            [0, 4.45, 0.003],
          ],
          fill: "#facc15",
        }),
        e.jsx(i, {
          x: 0,
          y: 4.6,
          z: -0.9,
          w: 14,
          d: 0.01,
          h: 0.9,
          color: "#9ca3af",
        }),
        e.jsx(ie, {
          x0: -4,
          y0: 4.6,
          x1: 14,
          y1: 9,
          color: "#57534e",
          lines: !1,
        }),
        e.jsx(f, {
          x: 3.4,
          y: 2.6,
          shirt: je,
          skin: 2,
          hair: 0,
          face: "y",
          reach: !0,
        }),
        e.jsx(xe, {
          at: [3.1, 3.6, 0.1],
          deg: -28,
          children: e.jsx(gt, { x: 2.8, y: 3.4, z: 0.05 }),
        }),
        e.jsx(rt, { at: [2.9, 3.9, 0], s: 0.8 }),
        e.jsx(ue, { at: [3, 3.5, 0.6], s: 0.7 }),
      ],
    }),
  finance_records: (t) =>
    e.jsxs(e.Fragment, {
      children: [
        e.jsx(de, {}),
        e.jsx(Y, {
          x: 0.6,
          y: 0.3,
          w: 2.2,
          rows: 4,
          colors: ["#1e3a8a", q, "#334155", "#475569"],
        }),
        e.jsx(Y, {
          x: 3,
          y: 0.3,
          w: 2.2,
          rows: 4,
          colors: ["#334155", "#1e3a8a", "#475569", q],
        }),
        e.jsx(f, {
          x: 3.4,
          y: 3.6,
          shirt: "#475569",
          legs: "#111827",
          skin: 0,
          hair: 2,
          face: "y",
          phones: "#111827",
        }),
        e.jsx(g, { at: [5, 3.3, 2.4], text: "7 TB", fill: j }),
        e.jsx(z, {
          frame: t,
          children: e.jsx(U, { at: F, text: "5 YRS", w: 62 }),
        }),
      ],
    }),
  finance_history: () =>
    e.jsxs(e.Fragment, {
      children: [
        e.jsx(de, {}),
        e.jsx(P, { x: 1.2, y: 1.4, w: 1.8, d: 0.9, h: 0.75, color: "#1f2937" }),
        e.jsx(se, {
          x: 2,
          y: 1.55,
          z: 0.75,
          w: 0.9,
          h: 0.55,
          frame: "#020617",
          children: e.jsx(Ae, { seed: 2 }),
        }),
        e.jsx(fe, { x: 3.6, y: 1, cols: 4, color: q }),
        e.jsx(fe, { x: 3.8, y: 1.8, cols: 3, color: "#fbbf24" }),
        e.jsx(g, { at: [5.2, 1.4, 2.4], text: "2 TB", fill: j }),
        e.jsx(I, { x: 2, y: 2.9, color: "#111827" }),
        e.jsx(f, {
          x: 2,
          y: 2.85,
          seated: !0,
          shirt: "#475569",
          skin: 3,
          hair: 3,
          face: "away",
        }),
      ],
    }),
  finance_feed: (t) =>
    e.jsxs(e.Fragment, {
      children: [
        e.jsx(de, {}),
        e.jsx(N, {
          wall: "y",
          a: 0.6,
          z: 0.9,
          w: 3.6,
          h: 1.8,
          fill: "#020617",
          frame: q,
        }),
        e.jsx(u, {
          x: 0.7,
          y: 0.003,
          z: 0.98,
          w: 3.4,
          h: 1.64,
          children: e.jsx(Ae, { seed: 2 }),
        }),
        e.jsx(g, { at: [3.6, 0.6, 1.6], text: "50 MB/min", fill: j, size: 12 }),
        e.jsx(I, { x: 2.4, y: 2.6, color: "#111827" }),
        e.jsx(f, {
          x: 2.4,
          y: 2.55,
          seated: !0,
          shirt: je,
          skin: 2,
          hair: 0,
          face: "away",
        }),
        e.jsx(z, { frame: t, children: e.jsx(me, { at: F, hour: 8 }) }),
        e.jsx(z, {
          frame: t,
          dx: 54,
          dy: 86,
          children: e.jsx(g, { at: F, text: "8 h" }),
        }),
      ],
    }),
  finance_trades: () =>
    e.jsxs(e.Fragment, {
      children: [
        e.jsx(de, {}),
        e.jsx(P, { x: 1.8, y: 1.6, w: 2.2, d: 1.1, h: 0.8, color: "#1f2937" }),
        [0, 1, 2].map((t) =>
          Array.from({ length: 9 - t * 2 }, (s, r) =>
            e.jsx(
              i,
              {
                x: 2 + t * 0.65,
                y: 1.8 + (r % 2) * 0.02,
                z: 0.8 + r * 0.07,
                w: 0.55,
                d: 0.7,
                h: 0.06,
                color: b,
              },
              `${t}${r}`,
            ),
          ),
        ),
        e.jsxs(_e, {
          x: 2,
          y: 1.8,
          z: 0.8 + 8 * 0.07 + 0.061,
          w: 0.55,
          d: 0.7,
          children: [
            e.jsx("rect", {
              x: 10,
              y: 14,
              width: 70,
              height: 10,
              fill: T,
              opacity: 0.6,
            }),
            e.jsx("rect", {
              x: 10,
              y: 34,
              width: 50,
              height: 10,
              fill: T,
              opacity: 0.6,
            }),
            e.jsx("rect", {
              x: 10,
              y: 54,
              width: 60,
              height: 10,
              fill: T,
              opacity: 0.6,
            }),
          ],
        }),
        e.jsx(g, { at: [2.3, 2, 2.1], text: "4 KB", fill: j }),
        e.jsx(g, { at: [4.4, 1.6, 2], text: "x5000", fill: q, ink: T }),
        e.jsx(f, {
          x: 1.2,
          y: 2.8,
          shirt: je,
          skin: 2,
          hair: 0,
          face: "x",
          reach: !0,
        }),
      ],
    }),
};
function Is({ id: t, frame: s }) {
  return e.jsx(e.Fragment, { children: Os[t]?.(s) });
}
const ke = "#14b8a6";
function ee() {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx(re, { id: "si-shot-ward", from: "#e6f4f1", to: "#f8fbfa" }),
      e.jsx(ie, { color: "#d6e2e8" }),
      e.jsx(Se, { left: "#c4e3de", right: "#d9eeea" }),
    ],
  });
}
function Je() {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 100, height: 60, fill: "#0f172a" }),
      e.jsx("rect", { x: 48, y: 6, width: 4, height: 48, fill: "#e2e8f0" }),
      [12, 20, 28, 36].map((t) =>
        e.jsxs(
          "g",
          {
            fill: "none",
            stroke: "#cbd5e1",
            strokeWidth: 3,
            children: [
              e.jsx("path", { d: `M46 ${t}q-18 2 -24 10` }),
              e.jsx("path", { d: `M54 ${t}q18 2 24 10` }),
            ],
          },
          t,
        ),
      ),
    ],
  });
}
function ve({ x: t, y: s, screen: r }) {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx(P, { x: t, y: s, w: 1.4, d: 0.9, h: 0.9, color: "#94a3b8" }),
      e.jsx(i, {
        x: t + 0.05,
        y: s + 0.05,
        z: 0.3,
        w: 1.3,
        d: 0.8,
        h: 0.05,
        color: "#cbd5e1",
      }),
      e.jsx(V, {
        x: t + 0.12,
        y: s + 0.85,
        r: 0.08,
        h: 0.08,
        color: "#111827",
      }),
      e.jsx(V, {
        x: t + 1.28,
        y: s + 0.85,
        r: 0.08,
        h: 0.08,
        color: "#111827",
      }),
      e.jsx(se, {
        x: t + 0.7,
        y: s + 0.3,
        z: 0.9,
        w: 1,
        h: 0.62,
        children:
          r === "dead"
            ? e.jsxs(e.Fragment, {
                children: [
                  e.jsx("rect", { width: 100, height: 60, fill: "#0f172a" }),
                  e.jsx("text", {
                    x: 50,
                    y: 36,
                    textAnchor: "middle",
                    fontSize: 16,
                    fontWeight: 700,
                    fill: "#ef4444",
                    fontFamily: D,
                    children: "NO DISK",
                  }),
                ],
              })
            : r === "restart"
              ? e.jsxs(e.Fragment, {
                  children: [
                    e.jsx("rect", { width: 100, height: 60, fill: "#1e3a8a" }),
                    e.jsx("circle", {
                      cx: 50,
                      cy: 26,
                      r: 11,
                      fill: "none",
                      stroke: "#bfdbfe",
                      strokeWidth: 4,
                      strokeDasharray: "40 30",
                    }),
                    e.jsx("rect", {
                      x: 26,
                      y: 44,
                      width: 48,
                      height: 5,
                      rx: 2,
                      fill: "#3b5bdb",
                    }),
                    e.jsx("rect", {
                      x: 26,
                      y: 44,
                      width: 12,
                      height: 5,
                      rx: 2,
                      fill: "#bfdbfe",
                    }),
                  ],
                })
              : e.jsx(Nt, {}),
      }),
    ],
  });
}
function bt({ x: t, y: s, blanket: r = "#93c5fd", skin: a = "#d9a57a" }) {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx(A, { x: t, y: s, w: 1.1, d: 2.2 }),
      e.jsx(i, { x: t, y: s, w: 1.1, d: 2.2, h: 0.55, color: "#f1f5f9" }),
      e.jsx(i, {
        x: t + 0.05,
        y: s + 0.05,
        z: 0.55,
        w: 1,
        d: 0.45,
        h: 0.14,
        color: "#e0f2fe",
      }),
      e.jsx(i, {
        x: t + 0.4,
        y: s + 0.12,
        z: 0.69,
        w: 0.32,
        d: 0.3,
        h: 0.26,
        color: a,
      }),
      e.jsx(i, {
        x: t + 0.05,
        y: s + 0.6,
        z: 0.55,
        w: 1,
        d: 1.55,
        h: 0.14,
        color: r,
      }),
    ],
  });
}
function Ds({ x: t, y: s }) {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx(A, { x: t - 0.1, y: s - 0.1, w: 2.8, d: 1.8 }),
      e.jsx(i, { x: t, y: s, w: 2.6, d: 1.6, h: 2.2, color: "#e2e8f0" }),
      e.jsx(v, {
        c: [t + 1.3, s + 1.601, 1.1],
        r: 0.85,
        plane: "y",
        fill: "#f8fafc",
        stroke: "#94a3b8",
        width: 4,
      }),
      e.jsx(v, {
        c: [t + 1.3, s + 1.602, 1.1],
        r: 0.42,
        plane: "y",
        fill: "#334155",
      }),
      e.jsx(i, {
        x: t + 0.75,
        y: s + 1.6,
        z: 0.5,
        w: 1.1,
        d: 1.3,
        h: 0.16,
        color: "#cbd5e1",
      }),
      e.jsx(i, {
        x: t + 1.15,
        y: s + 2,
        w: 0.3,
        d: 0.7,
        h: 0.5,
        color: "#94a3b8",
      }),
    ],
  });
}
function Vs({ a: t, z: s }) {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx(N, {
        wall: "y",
        a: t,
        z: s,
        w: 0.55,
        h: 0.5,
        fill: "#facc15",
        frame: T,
      }),
      e.jsxs(u, {
        x: t,
        y: 0.002,
        z: s,
        w: 0.55,
        h: 0.5,
        children: [
          e.jsx("path", {
            d: "M50 10 80 52H20z",
            fill: "none",
            stroke: T,
            strokeWidth: 6,
            strokeLinejoin: "round",
          }),
          e.jsx("rect", { x: 47, y: 24, width: 6, height: 14, fill: T }),
          e.jsx("rect", { x: 47, y: 42, width: 6, height: 5, fill: T }),
        ],
      }),
    ],
  });
}
function Ks({ x: t, y: s, z: r }) {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx(i, { x: t, y: s, z: r, w: 1, d: 0.25, h: 1, color: "#1f2937" }),
      e.jsxs(u, {
        x: t,
        y: s + 0.25,
        z: r,
        w: 1,
        h: 1,
        children: [
          e.jsx("rect", { x: 10, y: 8, width: 80, height: 22, fill: b }),
          e.jsx("text", {
            x: 50,
            y: 25,
            textAnchor: "middle",
            fontSize: 16,
            fontWeight: 700,
            fill: T,
            fontFamily: D,
            children: "12 TB",
          }),
          e.jsx("rect", {
            x: 34,
            y: 40,
            width: 32,
            height: 14,
            fill: "#334155",
          }),
        ],
      }),
    ],
  });
}
const qs = {
  hospital_mri: () =>
    e.jsxs(e.Fragment, {
      children: [
        e.jsx(ee, {}),
        e.jsx(Vs, { a: 1.2, z: 1.4 }),
        e.jsx(Ds, { x: 3, y: 0.2 }),
        e.jsx("g", {
          "data-shot-field": !0,
          fill: "none",
          stroke: j,
          strokeWidth: 3,
          strokeDasharray: "7 7",
          children: (() => {
            const [t, s] = y(4.3, 1.8, 1.1);
            return [46, 84, 122].map((r, a) =>
              e.jsx("circle", { cx: t, cy: s, r, opacity: 0.9 - a * 0.22 }, r),
            );
          })(),
        }),
        e.jsx(ve, { x: 2.4, y: 3 }),
        e.jsx(f, {
          x: 3.1,
          y: 4.6,
          shirt: "#1e3a8a",
          legs: "#1e293b",
          skin: 1,
          hair: 0,
          face: "away",
          reach: !0,
        }),
        e.jsx(ue, { at: [3.1, 3.4, 1.2], s: 0.7 }),
      ],
    }),
  hospital_scans: (t) =>
    e.jsxs(e.Fragment, {
      children: [
        e.jsx(ee, {}),
        e.jsx(Y, {
          x: 0.6,
          y: 0.3,
          w: 2.2,
          rows: 4,
          colors: ["#0f766e", "#14b8a6", "#1f4fbf", "#94a3b8"],
        }),
        e.jsx(Y, {
          x: 3,
          y: 0.3,
          w: 2.2,
          rows: 4,
          colors: ["#1f4fbf", "#0f766e", "#94a3b8", "#14b8a6"],
        }),
        e.jsx(f, {
          x: 3.6,
          y: 3.6,
          shirt: ke,
          legs: "#0f766e",
          skin: 3,
          hair: 3,
          face: "y",
          reach: !0,
        }),
        e.jsx(i, {
          x: 3.4,
          y: 3.95,
          z: 1.15,
          w: 0.65,
          d: 0.06,
          h: 0.5,
          color: "#0f172a",
        }),
        e.jsx(u, {
          x: 3.42,
          y: 4.01,
          z: 1.17,
          w: 0.6,
          h: 0.45,
          children: e.jsx(Je, {}),
        }),
        e.jsx(g, { at: [4.9, 3.4, 2.2], text: "9 TB", fill: j }),
        e.jsx(z, {
          frame: t,
          children: e.jsx(U, { at: F, text: "8 YRS", w: 62 }),
        }),
      ],
    }),
  hospital_failure: (t) =>
    e.jsxs(e.Fragment, {
      children: [
        e.jsx(ee, {}),
        e.jsx(N, {
          wall: "y",
          a: 0.8,
          z: 1.2,
          w: 1.4,
          h: 1,
          fill: "#bae6fd",
          frame: "#94a3b8",
        }),
        e.jsx(Le, { at: [3.6, 2.3, 1.3] }),
        e.jsx(ve, { x: 2.5, y: 2.3, screen: "dead" }),
        e.jsx(f, {
          x: 4.6,
          y: 2.8,
          shirt: ke,
          legs: "#0f766e",
          skin: 3,
          hair: 3,
          face: "away",
          reach: !0,
        }),
        e.jsx(z, { frame: t, children: e.jsx(U, { at: F, text: "MON" }) }),
      ],
    }),
  hospital_tabs: () =>
    e.jsxs(e.Fragment, {
      children: [
        e.jsx(ee, {}),
        e.jsx(ve, { x: 2.5, y: 2.3 }),
        e.jsx(at, { at: [3, 2.2, 2.6], n: 5 }),
        e.jsx(f, {
          x: 3.2,
          y: 4,
          shirt: "#f8fafc",
          legs: "#334155",
          skin: 1,
          hair: 0,
          face: "away",
        }),
        e.jsx(i, {
          x: 3,
          y: 3.95,
          z: 1.45,
          w: 0.4,
          d: 0.08,
          h: 0.04,
          color: "#475569",
        }),
      ],
    }),
  hospital_restart: (t) =>
    e.jsxs(e.Fragment, {
      children: [
        e.jsx(ee, {}),
        e.jsx(bt, { x: 0.6, y: 2 }),
        e.jsx(ve, { x: 2.9, y: 2.4, screen: "restart" }),
        e.jsx(f, {
          x: 2.3,
          y: 4.4,
          shirt: "#f8fafc",
          legs: "#334155",
          skin: 2,
          hair: 1,
          face: "away",
        }),
        e.jsxs(Et, {
          at: [2.3, 4.4, 2.6],
          w: 44,
          h: 34,
          children: [
            e.jsx("circle", { r: 11, fill: "#c8372d" }),
            e.jsx("rect", { x: -2, y: -7, width: 4, height: 8, fill: b }),
            e.jsx("rect", { x: -2, y: 3, width: 4, height: 4, fill: b }),
          ],
        }),
        e.jsx(z, {
          frame: t,
          children: e.jsx(me, { at: F, hour: 2, minute: 50 }),
        }),
      ],
    }),
  hospital_transfer: () =>
    e.jsxs(e.Fragment, {
      children: [
        e.jsx(ee, {}),
        e.jsx(N, {
          wall: "y",
          a: 4.2,
          z: 0,
          w: 1.6,
          h: 2.3,
          fill: "#e2e8f0",
          frame: "#64748b",
        }),
        e.jsxs(u, {
          x: 4.5,
          y: 0.003,
          z: 1.3,
          w: 1,
          h: 0.8,
          children: [
            e.jsx("rect", {
              x: 10,
              y: 4,
              width: 80,
              height: 52,
              fill: "#fffdf7",
            }),
            e.jsx("rect", {
              x: 42,
              y: 10,
              width: 16,
              height: 40,
              fill: "#c8372d",
            }),
            e.jsx("rect", {
              x: 22,
              y: 22,
              width: 56,
              height: 16,
              fill: "#c8372d",
            }),
          ],
        }),
        e.jsx(bt, { x: 1.6, y: 1.6, blanket: "#fca5a5", skin: "#a8714a" }),
        e.jsx(f, {
          x: 2,
          y: 4.4,
          shirt: ke,
          legs: "#0f766e",
          skin: 0,
          hair: 2,
          face: "away",
          reach: !0,
        }),
        e.jsx(f, {
          x: 4.3,
          y: 3.2,
          shirt: "#15803d",
          legs: "#14532d",
          skin: 1,
          hair: 0,
          face: "y",
          reach: !0,
        }),
        e.jsx(i, {
          x: 4.1,
          y: 3.62,
          z: 1,
          w: 0.45,
          d: 0.3,
          h: 0.32,
          color: "#334155",
        }),
        e.jsx(g, { at: [4.6, 2.6, 2.6], text: "4 GB", fill: j }),
      ],
    }),
  hospital_trolley: () =>
    e.jsxs(e.Fragment, {
      children: [
        e.jsx(ee, {}),
        e.jsx(N, {
          wall: "y",
          a: 2.4,
          z: 0,
          w: 1.4,
          h: 2.3,
          fill: "#94a3b8",
          frame: "#64748b",
        }),
        e.jsx(i, { x: 2.25, y: 0, w: 0.15, d: 0.3, h: 2.4, color: "#64748b" }),
        e.jsx(i, { x: 3.8, y: 0, w: 0.15, d: 0.3, h: 2.4, color: "#64748b" }),
        e.jsx(xe, {
          at: [2.4, 3.5, 0],
          deg: -62,
          children: e.jsx(ve, { x: 2.4, y: 2.6 }),
        }),
        e.jsx(rt, { at: [2.7, 3.7, 0] }),
        e.jsx(f, {
          x: 4.6,
          y: 4.2,
          shirt: "#1e3a8a",
          legs: "#1e293b",
          skin: 1,
          hair: 0,
          face: "away",
          reach: !0,
        }),
        e.jsx(ue, { at: [4.6, 4.2, 2], s: 0.7 }),
      ],
    }),
  hospital_xrays: () =>
    e.jsxs(e.Fragment, {
      children: [
        e.jsx(ee, {}),
        [0.5, 1.6, 2.7].map((t) =>
          e.jsxs(
            "g",
            {
              children: [
                e.jsx(N, {
                  wall: "x",
                  a: t,
                  z: 1.2,
                  w: 1,
                  h: 0.75,
                  fill: "#0f172a",
                  frame: "#94a3b8",
                }),
                e.jsx(G, {
                  x: 0.003,
                  y: t + 0.05,
                  z: 1.25,
                  d: 0.9,
                  h: 0.65,
                  children: e.jsx(Je, {}),
                }),
              ],
            },
            t,
          ),
        ),
        e.jsx(ve, { x: 1.6, y: 2.4 }),
        e.jsx(fe, { x: 3.4, y: 1, cols: 4, color: "#5eead4" }),
        e.jsx(fe, { x: 3.6, y: 1.8, cols: 3, color: "#2dd4bf" }),
        e.jsx(g, { at: [5.1, 1.4, 2.4], text: "2 TB", fill: j }),
        e.jsx(f, {
          x: 2.6,
          y: 4.4,
          shirt: ke,
          legs: "#0f766e",
          skin: 3,
          hair: 3,
          face: "away",
        }),
      ],
    }),
  hospital_week: (t) =>
    e.jsxs(e.Fragment, {
      children: [
        e.jsx(ee, {}),
        e.jsx(i, { x: 2.6, y: 0.3, w: 0.3, d: 0.3, h: 2.6, color: "#cbd5e1" }),
        e.jsx(i, {
          x: 2.5,
          y: 0.4,
          z: 2.2,
          w: 0.5,
          d: 1.6,
          h: 0.2,
          color: "#e2e8f0",
        }),
        e.jsx(i, {
          x: 2.45,
          y: 1.7,
          z: 1.6,
          w: 0.6,
          d: 0.6,
          h: 0.6,
          color: "#f8fafc",
        }),
        e.jsx(i, { x: 2, y: 1.6, w: 1.5, d: 2, h: 0.7, color: "#e2e8f0" }),
        e.jsx(i, {
          x: 2.2,
          y: 1.75,
          z: 0.7,
          w: 0.32,
          d: 0.3,
          h: 0.26,
          color: "#a8714a",
        }),
        e.jsx(i, {
          x: 2.1,
          y: 2.15,
          z: 0.7,
          w: 1.3,
          d: 1.35,
          h: 0.14,
          color: "#bae6fd",
        }),
        e.jsx(f, {
          x: 3.8,
          y: 4.2,
          shirt: ke,
          legs: "#0f766e",
          skin: 1,
          hair: 2,
          face: "away",
        }),
        [0, 1, 2, 3].map((s) =>
          e.jsxs(
            "g",
            {
              children: [
                e.jsx(i, {
                  x: 4.6 + s * 0.06,
                  y: 1.5 + s * 0.04,
                  z: 0.9 + s * 0.18,
                  w: 0.7,
                  d: 0.06,
                  h: 0.5,
                  color: "#0f172a",
                }),
                e.jsx(u, {
                  x: 4.62 + s * 0.06,
                  y: 1.56 + s * 0.04,
                  z: 0.92 + s * 0.18,
                  w: 0.66,
                  h: 0.46,
                  children: e.jsx(Je, {}),
                }),
              ],
            },
            s,
          ),
        ),
        e.jsx(g, { at: [4.9, 1.7, 2.1], text: "25 MB", fill: j }),
        e.jsx(z, {
          frame: t,
          children: e.jsx(U, { at: F, text: "400/WK", w: 66 }),
        }),
      ],
    }),
  hospital_tape: (t) =>
    e.jsxs(e.Fragment, {
      children: [
        e.jsx(ee, {}),
        e.jsx(Y, {
          x: 0.6,
          y: 0.3,
          w: 1.6,
          rows: 4,
          colors: ["#1f2937", "#334155"],
        }),
        e.jsx(Y, {
          x: 3.8,
          y: 0.3,
          w: 1.6,
          rows: 4,
          colors: ["#1f2937", "#334155"],
        }),
        e.jsx(P, { x: 2.2, y: 2, w: 1.6, d: 1, h: 0.8, color: "#94a3b8" }),
        e.jsx(Ks, { x: 2.5, y: 2.3, z: 0.8 }),
        e.jsx(f, {
          x: 4.6,
          y: 2.4,
          shirt: ke,
          legs: "#0f766e",
          skin: 0,
          hair: 1,
          face: "away",
          reach: !0,
        }),
        e.jsx(z, {
          frame: t,
          children: e.jsx(U, { at: F, text: "3 TB/YR", w: 70 }),
        }),
      ],
    }),
};
function Ys({ id: t, frame: s }) {
  return e.jsx(e.Fragment, { children: qs[t]?.(s) });
}
const Us = { film: Gs, hospital: Ys, esports: $s, finance: Is, arctic: Ps },
  Xs = { protected: "#1f9d6b", partial: "#d99a0b", vulnerable: "#c8372d" };
function Qs({ level: t, frame: s }) {
  const r = Xs[t],
    [a, o, n] = s;
  return e.jsx("g", {
    "data-scene-outcome": t,
    children: e.jsx("g", {
      transform: `translate(${a + n - 34} ${o + 34})`,
      children: e.jsxs("g", {
        className: "si-pop",
        children: [
          e.jsx("circle", { r: 22, fill: r, stroke: b, strokeWidth: 4 }),
          t === "protected"
            ? e.jsx("path", {
                d: "M-10 0l7 8 13-15",
                fill: "none",
                stroke: b,
                strokeWidth: 5,
                strokeLinecap: "round",
                strokeLinejoin: "round",
              })
            : t === "partial"
              ? e.jsx("path", {
                  d: "M-10 0h20",
                  stroke: b,
                  strokeWidth: 5,
                  strokeLinecap: "round",
                })
              : e.jsx("path", {
                  d: "M-8 -8l16 16M8 -8l-16 16",
                  stroke: b,
                  strokeWidth: 5,
                  strokeLinecap: "round",
                }),
        ],
      }),
    }),
  });
}
function Ot({ event: t, kind: s, title: r, level: a, alert: o, className: n }) {
  const l = _s(t),
    d = Ms(t);
  if (!l || !d) return null;
  const c = Us[d],
    [h, x, m] = l;
  return e.jsxs("svg", {
    viewBox: l.join(" "),
    className: n,
    role: "img",
    "aria-label": r,
    "data-story-shot": t,
    "data-scene-event": s,
    preserveAspectRatio: "xMidYMid meet",
    children: [
      e.jsx(c, { id: t, frame: l }),
      a ? e.jsx(Qs, { level: a, frame: l }) : null,
      o
        ? e.jsxs("g", {
            children: [
              e.jsx("rect", {
                x: -2e3,
                y: -2e3,
                width: 4e3,
                height: 4e3,
                fill: "#f26b1d",
                className: "si-flicker",
              }),
              e.jsxs("g", {
                className: "si-pop",
                children: [
                  e.jsx("circle", {
                    cx: h + m - 40,
                    cy: x + 40,
                    r: 30,
                    fill: b,
                    stroke: "#f26b1d",
                    strokeWidth: 4,
                  }),
                  e.jsx("svg", {
                    x: h + m - 61,
                    y: x + 19,
                    width: 42,
                    height: 42,
                    viewBox: "0 0 64 64",
                    children:
                      s === "units" ? e.jsx(Wt, {}) : e.jsx($t, { kind: s }),
                  }),
                ],
              }),
            ],
          })
        : null,
    ],
  });
}
const Js = [
    we("1.2", "Random Access Memory (RAM)", {
      id: "ram",
      term: "RAM",
      name: "Random access memory",
      art: e.jsx(Me, { id: "ram16" }),
    }),
    we("1.2", "Virtual Memory", {
      id: "virtual-memory",
      term: "Virtual memory",
      name: "When RAM is full",
      art: e.jsx($t, { kind: "multitask" }),
    }),
    we("1.2", "Magnetic Storage", {
      id: "magnetic",
      term: "Magnetic",
      name: "Hard disks and tape",
      art: e.jsx(Me, { id: "hdd" }),
      example:
        "A hard disk gives the most space for the money, but its moving parts can be damaged by a knock. Tape holds even more and is cheap per GB, but is slow to find one file, so it suits backups.",
    }),
    we("1.2", "Solid State Storage", {
      id: "solid-state",
      term: "Solid state",
      name: "Flash memory",
      art: e.jsx(Me, { id: "ssd" }),
      example:
        "SSDs, USB sticks and SD cards are all solid state. With no moving parts they survive knocks and fit in a pocket, but an SSD costs more per GB than a hard disk.",
    }),
    we("1.2", "Optical Storage", {
      id: "optical",
      term: "Optical",
      name: "CD, DVD and Blu-ray",
      art: e.jsx(Me, { id: "bluray" }),
      example:
        "A Blu-ray disc holds 25 GB and is cheap to make in bulk and post, so it suits handing out copies of a film.",
    }),
    we("1.2", "Gigabyte (GB)", {
      id: "gigabyte",
      term: "GB",
      name: "Gigabyte",
      art: e.jsx(Wt, {}),
    }),
  ],
  Ge = [
    { id: "ram", name: "RAM", empty: "4 GB stock" },
    { id: "main", name: "Main drive", empty: "none", required: !0 },
    { id: "backup", name: "Backup", empty: "none" },
    { id: "portable", name: "Portable", empty: "none" },
    { id: "optical", name: "Optical drive", empty: "none" },
  ],
  ot = [
    {
      id: "ram8",
      slot: "ram",
      name: "RAM 8 GB",
      spec: "Primary, volatile",
      cost: 40,
    },
    {
      id: "ram16",
      slot: "ram",
      name: "RAM 16 GB",
      spec: "Primary, volatile",
      cost: 80,
    },
    {
      id: "ram32",
      slot: "ram",
      name: "RAM 32 GB",
      spec: "Primary, volatile",
      cost: 160,
    },
    {
      id: "ssd",
      slot: "main",
      name: "SSD 1 TB",
      spec: "Solid state",
      cost: 110,
    },
    {
      id: "hdd",
      slot: "main",
      name: "Hard disk 4 TB",
      spec: "Magnetic",
      cost: 70,
    },
    {
      id: "ext_hdd",
      slot: "backup",
      name: "External hard disk",
      spec: "Magnetic, 4 TB",
      cost: 60,
    },
    {
      id: "tape",
      slot: "backup",
      name: "Tape drive",
      spec: "Magnetic, 12 TB a tape",
      cost: 150,
    },
    {
      id: "bluray",
      slot: "optical",
      name: "Blu-ray burner",
      spec: "Optical, 25 GB a disc",
      cost: 40,
    },
    {
      id: "usb",
      slot: "portable",
      name: "USB stick",
      spec: "Solid state, 128 GB",
      cost: 15,
    },
    {
      id: "sd",
      slot: "portable",
      name: "SD cards x4",
      spec: "Solid state, 64 GB each",
      cost: 40,
    },
    {
      id: "ext_ssd",
      slot: "portable",
      name: "Portable SSD",
      spec: "Solid state, 2 TB",
      cost: 90,
    },
  ],
  Zs = {
    multitask:
      "RAM holds the programs and data in use right now. When it fills up, the operating system moves some of it out to virtual memory on secondary storage, which is far slower, so everything lags.",
    heavy:
      "Big files have to be loaded into RAM to be worked on. Too little RAM means constant swapping to virtual memory on the drive, which is much slower than RAM.",
    knock:
      "An SSD has no moving parts, so it survives knocks and drops. A hard disk reads a spinning platter with a head that floats just above it: a jolt can crash the head into the platter. Durability matters for anything that moves.",
    magnet:
      "A hard disk is magnetic storage, so a strong magnetic field can corrupt what it holds. An SSD stores data in flash memory chips, which magnets do not affect.",
    speed:
      "An SSD has no moving parts to wait for, so it reads and writes much faster than a hard disk, whose platter must spin and head must move to the data.",
    capacity:
      "A hard disk gives the most capacity for the money: 4 TB of magnetic storage costs less than 1 TB of solid state. Choose it when space matters more than speed.",
    carry:
      "Flash storage such as USB sticks, SD cards and portable SSDs is small, light and needs no power to keep its data, so it is the most portable. Capacity decides how much fits.",
    archive:
      "Magnetic tape has huge capacity at a very low cost per GB, and it lasts for years on a shelf. It is read in order, so finding one file means winding through the tape: it suits archives and backups, not everyday work.",
    failure:
      "Every device fails in the end. A backup on a separate device means the data can be restored. The more of it the backup can hold, the more you get back.",
    bulk: "Optical discs are cheap to make in bulk, light to post and read in most players. They hold far less than flash or magnetic storage, which does not matter for one film.",
  },
  et = [
    {
      id: "film",
      name: "Film crew",
      contact: "Ama, documentary director",
      need: "4K footage shot on location. Long days, and the kit gets knocked about.",
      conditions: ["4K footage", "Shot on location", "Kit gets knocked about"],
      budget: 470,
      topUp: 40,
      events: [
        {
          id: "film_cart",
          kind: "knock",
          name: "Laptop knocked off the camera cart",
          scenario:
            "A runner catches the cable and the edit laptop hits the floor mid-copy.",
          protectedBy: ["ssd"],
          alsoHelpedBy: ["ext_hdd", "tape"],
          outcomeProtected:
            "The SSD carried on as if nothing happened. Not a frame lost.",
          outcomePartial:
            "The hard disk is dead, but last night’s backup brought the footage back. Today’s copying was lost.",
          outcomeVulnerable:
            "The hard disk head crashed into the platter. The only copy of two days of footage is gone.",
        },
        {
          id: "film_edit",
          kind: "heavy",
          name: "Editing 4K on location",
          scenario:
            "Ama wants a rough cut tonight: three 4K clips, colour grading and music on one timeline.",
          protectedBy: ["ram32"],
          alsoHelpedBy: ["ram16"],
          outcomeProtected:
            "The whole timeline sits in RAM and plays back smoothly.",
          outcomePartial:
            "It plays, but every effect stutters while the computer swaps to the drive.",
          outcomeVulnerable:
            "The timeline will not play. The computer spends its time swapping to virtual memory.",
        },
        {
          id: "film_rushes",
          kind: "carry",
          name: "Hand the rushes to the editor",
          scenario:
            "The editor is in another city and needs today’s 300 GB of rushes by morning.",
          protectedBy: ["ext_ssd"],
          alsoHelpedBy: ["sd", "usb"],
          outcomeProtected:
            "All 300 GB fit on the portable SSD, which went home in a jacket pocket.",
          outcomePartial:
            "Only part of the rushes fitted. The editor started on what arrived.",
          outcomeVulnerable:
            "Nothing portable to put them on. The rushes stayed on set.",
        },
        {
          id: "film_archive",
          kind: "archive",
          name: "Archive the whole shoot",
          scenario:
            "The broadcaster wants every original clip kept for ten years, all 9 TB of it.",
          protectedBy: ["tape"],
          alsoHelpedBy: ["ext_hdd"],
          outcomeProtected:
            "One tape holds the lot and goes on a shelf for ten years.",
          outcomePartial:
            "The external hard disk holds only 4 TB, so the rest has to be cut down.",
          outcomeVulnerable:
            "No archive. The originals will be deleted to free up space.",
        },
        {
          id: "film_festival",
          kind: "bulk",
          name: "Screeners for 50 festival judges",
          scenario:
            "Every judge needs their own copy of the finished film in the post this week.",
          protectedBy: ["bluray"],
          alsoHelpedBy: ["usb"],
          outcomeProtected:
            "Fifty discs burned and posted for the price of a coffee each.",
          outcomePartial:
            "One USB stick, so the judges had to take turns. Some saw it late.",
          outcomeVulnerable:
            "No way to make copies. Half the judges never saw the film.",
        },
        {
          id: "film_library",
          kind: "capacity",
          name: "Two terabytes of footage",
          scenario:
            "By week three the project holds 2 TB, and it all needs to be with the edit machine.",
          protectedBy: ["hdd", "ext_ssd"],
          alsoHelpedBy: [],
          outcomeProtected: "There is room for the whole project.",
          outcomeVulnerable:
            "The 1 TB drive is full. Footage has to be deleted to keep going.",
        },
        {
          id: "film_failure",
          kind: "failure",
          name: "The main drive gives up",
          scenario: "Six weeks into the shoot, the main drive will not start.",
          protectedBy: ["ext_hdd", "tape"],
          alsoHelpedBy: ["bluray"],
          outcomeProtected:
            "Everything was restored from the backup by lunchtime.",
          outcomePartial:
            "The discs held the finished films, but the raw footage would not fit on them.",
          outcomeVulnerable:
            "No backup. Six weeks of footage went with the drive.",
        },
        {
          id: "film_review",
          kind: "speed",
          name: "The client scrubs the timeline",
          scenario:
            "The producer is watching over Ama’s shoulder, jumping back and forth through the cut.",
          protectedBy: ["ssd"],
          alsoHelpedBy: ["ext_ssd"],
          outcomeProtected:
            "Every jump plays instantly. The producer is impressed.",
          outcomePartial:
            "Clips copied to the portable SSD play fast; the rest lag.",
          outcomeVulnerable:
            "Every jump waits for the hard disk to find the clip. The producer sighs.",
        },
      ],
      units: [
        {
          id: "film_shoot",
          name: "Four-hour shoot tomorrow",
          scenario:
            "The camera writes 375 MB of footage every minute, and tomorrow is a four-hour shoot.",
          question: "How much footage will the shoot make?",
          options: ["90 GB", "9 GB", "900 GB", "1.5 GB"],
          working:
            "375 MB × 240 minutes = 90 000 MB. 90 000 MB ÷ 1000 = 90 GB.",
          outcomeRight:
            "You packed enough cards for 90 GB. The camera never stopped.",
          outcomeWrong:
            "The cards filled up in the last hour. The best interview was not recorded.",
        },
        {
          id: "film_card",
          name: "How long will one card last?",
          scenario:
            "One SD card holds 64 GB. The slow-motion camera writes 2 GB every minute.",
          question: "How many minutes of slow motion fit on one card?",
          options: ["32 minutes", "128 minutes", "3.2 minutes", "62 minutes"],
          working: "64 GB ÷ 2 GB per minute = 32 minutes.",
          outcomeRight:
            "You swapped cards at 30 minutes. Every shot was saved.",
          outcomeWrong:
            "The card filled mid-shot and the stunt had to be done again.",
        },
      ],
    },
    {
      id: "hospital",
      name: "Hospital ward",
      contact: "Sister Okafor, Ward 7",
      need: "Patient records must never be lost, scans are kept for years, and the ward PC sits near the scanners.",
      conditions: [
        "Records never lost",
        "Scans kept for years",
        "Next to the scanners",
      ],
      budget: 350,
      topUp: 80,
      events: [
        {
          id: "hospital_mri",
          kind: "magnet",
          name: "Wheeled into the MRI room",
          scenario:
            "A porter wheels the computer trolley into the MRI scanner room by mistake, close to the magnet, before anyone stops them.",
          protectedBy: ["ssd"],
          alsoHelpedBy: ["ext_hdd", "tape"],
          outcomeProtected:
            "Flash memory ignores magnets. The records were untouched.",
          outcomePartial:
            "The hard disk was corrupted, but the backup, kept in the office, restored the records.",
          outcomeVulnerable:
            "The magnet’s field scrambled the hard disk, and there was no backup. Every record on it was lost.",
        },
        {
          id: "hospital_scans",
          kind: "archive",
          name: "Keep every scan for eight years",
          scenario:
            "NHS rules say adult records are kept for eight years after treatment ends: 9 TB of scans from the last three years.",
          protectedBy: ["tape"],
          alsoHelpedBy: ["ext_hdd"],
          outcomeProtected:
            "One 12 TB tape holds the lot, with room for another year, cheaply, in the records room.",
          outcomePartial:
            "The external hard disk filled at 4 TB. Older scans had to go elsewhere.",
          outcomeVulnerable:
            "Nowhere to archive them. The ward breaks the rules on keeping records.",
        },
        {
          id: "hospital_failure",
          kind: "failure",
          name: "The records PC will not start",
          scenario:
            "Monday morning, and the drive in the ward’s records PC has failed.",
          protectedBy: ["ext_hdd", "tape"],
          alsoHelpedBy: ["bluray"],
          outcomeProtected:
            "The records were restored from the backup before the ward round.",
          outcomePartial:
            "Last month’s discs held some records. Recent ones had to be typed again.",
          outcomeVulnerable: "No backup. Every record on the ward PC was lost.",
        },
        {
          id: "hospital_tabs",
          kind: "multitask",
          name: "Everything open at once",
          scenario:
            "Records, the X-ray viewer, email and the drug chart are all open on one screen.",
          protectedBy: ["ram16", "ram32"],
          alsoHelpedBy: ["ram8"],
          outcomeProtected:
            "Every program stays in RAM and switches instantly.",
          outcomePartial:
            "It copes, but the X-ray viewer is slow to come back each time.",
          outcomeVulnerable:
            "RAM is full, so the computer swaps to virtual memory. Every click takes seconds.",
        },
        {
          id: "hospital_restart",
          kind: "speed",
          name: "Restart in an emergency",
          scenario:
            "An update restarts the PC just as a doctor needs a patient’s allergies.",
          protectedBy: ["ssd"],
          alsoHelpedBy: [],
          outcomeProtected:
            "The SSD loaded the system in seconds. The doctor had the answer.",
          outcomeVulnerable:
            "The hard disk took over a minute to load everything. A long minute.",
        },
        {
          id: "hospital_transfer",
          kind: "carry",
          name: "A patient moves hospital",
          scenario:
            "A patient is transferred, and 4 GB of their scans must travel with them.",
          protectedBy: ["usb", "sd", "ext_ssd", "bluray"],
          alsoHelpedBy: [],
          outcomeProtected: "The scans went in the ambulance with the patient.",
          outcomeVulnerable:
            "Nothing to copy them onto. The other hospital had to scan again.",
        },
        {
          id: "hospital_trolley",
          kind: "knock",
          name: "The trolley hits a door frame",
          scenario:
            "The computer on wheels is bumped through doors all day. Today it tipped over.",
          protectedBy: ["ssd"],
          alsoHelpedBy: ["ext_hdd", "tape"],
          outcomeProtected: "No moving parts to break. The SSD kept working.",
          outcomePartial:
            "The hard disk broke. Records came back from the backup, minus today’s.",
          outcomeVulnerable: "The hard disk broke and there was no backup.",
        },
        {
          id: "hospital_xrays",
          kind: "capacity",
          name: "Two terabytes of X-rays",
          scenario:
            "The ward wants the last four years of X-rays, 2 TB, on its own PC.",
          protectedBy: ["hdd", "ext_ssd"],
          alsoHelpedBy: [],
          outcomeProtected: "There is room for them all.",
          outcomeVulnerable: "The 1 TB drive could hold only half of them.",
        },
      ],
      units: [
        {
          id: "hospital_week",
          name: "A week of X-rays",
          scenario: "Each X-ray is 25 MB, and the ward takes 400 a week.",
          question: "How much space does a week of X-rays need?",
          options: ["10 GB", "100 GB", "1 GB", "10 000 GB"],
          working: "25 MB × 400 = 10 000 MB. 10 000 MB ÷ 1000 = 10 GB.",
          outcomeRight:
            "You set aside 10 GB a week, and the space never ran out.",
          outcomeWrong:
            "The space you set aside was the wrong size. Scans failed to save on Friday.",
        },
        {
          id: "hospital_tape",
          name: "How long will a tape last?",
          scenario:
            "One backup tape holds 12 TB. The ward makes 3 TB of new data a year.",
          question: "How many years of data fit on one tape?",
          options: ["4 years", "36 years", "0.25 years", "9 years"],
          working: "12 TB ÷ 3 TB a year = 4 years.",
          outcomeRight:
            "You ordered the next tape before the fourth year ran out, so nothing was ever left without a backup.",
          outcomeWrong:
            "The tape filled sooner than you planned, and a year went without a backup.",
        },
      ],
    },
    {
      id: "esports",
      name: "Esports team",
      contact: "Kai, Team Volt captain",
      need: "Fast loading, huge game installs, and streaming while they play.",
      conditions: [
        "Fast loading",
        "Huge game installs",
        "Streaming while they play",
      ],
      budget: 420,
      topUp: 90,
      events: [
        {
          id: "esports_load",
          kind: "speed",
          name: "Load in 60 seconds or forfeit",
          scenario:
            "Tournament rules: any player still loading after 60 seconds loses the round.",
          protectedBy: ["ssd"],
          alsoHelpedBy: ["ext_ssd"],
          outcomeProtected:
            "Kai was in the match before the others had finished loading.",
          outcomePartial:
            "The game on the portable SSD loaded fast. The other one did not.",
          outcomeVulnerable:
            "The hard disk was still loading at 61 seconds. Round lost.",
        },
        {
          id: "esports_installs",
          kind: "capacity",
          name: "Twelve games, 1.5 TB",
          scenario:
            "The team plays twelve titles, and between them they need 1.5 TB.",
          protectedBy: ["hdd", "ext_ssd"],
          alsoHelpedBy: [],
          outcomeProtected: "Every game is installed and ready.",
          outcomeVulnerable:
            "Only 1 TB of space. Games are deleted and downloaded again every week.",
        },
        {
          id: "esports_stream",
          kind: "heavy",
          name: "Play, stream and chat at once",
          scenario:
            "Kai plays, streams in HD, runs voice chat and keeps the browser open.",
          protectedBy: ["ram32"],
          alsoHelpedBy: ["ram16"],
          outcomeProtected: "Everything runs in RAM. The stream is smooth.",
          outcomePartial:
            "The game is fine, but the stream drops frames when the RAM fills.",
          outcomeVulnerable:
            "The game freezes while the computer swaps to virtual memory.",
        },
        {
          id: "esports_lan",
          kind: "carry",
          name: "Away tournament",
          scenario:
            "The team must carry their settings, saves and replays to an away venue.",
          protectedBy: ["usb", "sd", "ext_ssd"],
          alsoHelpedBy: [],
          outcomeProtected: "Plugged in at the venue. Every setting was there.",
          outcomeVulnerable:
            "Nothing to carry them on. They played on unfamiliar settings.",
        },
        {
          id: "esports_coach",
          kind: "knock",
          name: "Thrown in the coach hold",
          scenario:
            "The tournament PC rode four hours in the coach hold with the bags.",
          protectedBy: ["ssd"],
          alsoHelpedBy: ["ext_hdd", "tape"],
          outcomeProtected:
            "It started first time. SSDs do not mind a bumpy ride.",
          outcomePartial:
            "The hard disk failed. Everything was restored from backup in time.",
          outcomeVulnerable:
            "The jolts broke the hard disk. Nothing to restore from, and no time to reinstall.",
        },
        {
          id: "esports_replays",
          kind: "archive",
          name: "Keep every replay for coaching",
          scenario:
            "The coach wants five years of match replays and player-camera footage kept: about 8 TB.",
          protectedBy: ["tape"],
          alsoHelpedBy: ["ext_hdd"],
          outcomeProtected: "One cheap tape holds the lot.",
          outcomePartial: "The external hard disk holds only half of it.",
          outcomeVulnerable: "The replays are deleted each season.",
        },
        {
          id: "esports_expo",
          kind: "bulk",
          name: "100 highlight films for fans",
          scenario:
            "The sponsor wants 100 copies of the season highlights to hand out at next month’s expo.",
          protectedBy: ["bluray"],
          alsoHelpedBy: ["usb"],
          outcomeProtected:
            "A hundred discs, burned over a few evenings for pennies each, gone by lunchtime.",
          outcomePartial:
            "One USB stick, so fans queued to copy it. Most gave up.",
          outcomeVulnerable: "Nothing to hand out. The sponsor is not pleased.",
        },
        {
          id: "esports_failure",
          kind: "failure",
          name: "Drive dies the night before",
          scenario:
            "The night before the final, the main drive will not start.",
          protectedBy: ["ext_hdd", "tape"],
          alsoHelpedBy: ["bluray"],
          outcomeProtected:
            "Restored from the backup overnight. Ready for the final.",
          outcomePartial:
            "The discs held the settings, but every game had to be downloaded again.",
          outcomeVulnerable:
            "No backup. The team played the final on borrowed computers.",
        },
      ],
      units: [
        {
          id: "esports_space",
          name: "Room for more games?",
          scenario:
            "Each new game is 120 GB. The 1 TB drive already has 400 GB used.",
          question: "How many more games fit?",
          options: ["5 games", "8 games", "50 games", "3 games"],
          working: "1000 GB − 400 GB = 600 GB free. 600 GB ÷ 120 GB = 5 games.",
          outcomeRight:
            "You installed exactly five. No surprises on match day.",
          outcomeWrong:
            "The last download failed with the drive full, an hour before the match.",
        },
        {
          id: "esports_month",
          name: "A month of replays",
          scenario:
            "Each match replay is 500 MB, and the team plays 40 matches a month.",
          question: "How much space do a month of replays need?",
          options: ["20 GB", "2 GB", "200 GB", "2000 GB"],
          working: "500 MB × 40 = 20 000 MB. 20 000 MB ÷ 1000 = 20 GB.",
          outcomeRight: "You cleared 20 GB each month. Every replay was kept.",
          outcomeWrong:
            "You cleared the wrong amount, and the last week of replays was not saved.",
        },
      ],
    },
    {
      id: "finance",
      name: "Trading desk",
      contact: "Priya, head of trading at Meridian Capital",
      need: "Split-second trading, every trade kept for the regulator, and huge risk models run overnight.",
      conditions: [
        "Split-second trading",
        "Every trade kept for years",
        "Huge risk models",
      ],
      budget: 420,
      topUp: 90,
      events: [
        {
          id: "finance_screens",
          kind: "multitask",
          name: "Six screens of live prices",
          scenario:
            "Live prices, the news feed, charts, the trading platform and a risk sheet are all open at once.",
          protectedBy: ["ram16", "ram32"],
          alsoHelpedBy: ["ram8"],
          outcomeProtected:
            "Every program stays in RAM. Prices update without a flicker.",
          outcomePartial:
            "It copes, but the charts are slow to come back each time Priya switches.",
          outcomeVulnerable:
            "RAM is full, so the computer swaps to virtual memory. The prices on screen are seconds old.",
        },
        {
          id: "finance_open",
          kind: "speed",
          name: "The market opens at 8:00",
          scenario:
            "At 8:00 sharp the trading platform and the day’s price history must load before the first trade.",
          protectedBy: ["ssd"],
          alsoHelpedBy: [],
          outcomeProtected:
            "Loaded in seconds. Priya made the first trade of the morning.",
          outcomeVulnerable:
            "The hard disk was still loading at 8:01. The best prices had gone.",
        },
        {
          id: "finance_model",
          kind: "heavy",
          name: "The overnight risk model",
          scenario:
            "The risk team loads every open trade and a year of prices into one model before morning.",
          protectedBy: ["ram32"],
          alsoHelpedBy: ["ram16"],
          outcomeProtected:
            "The whole model fits in RAM. The report is ready by 6:00.",
          outcomePartial:
            "It runs, but swapping to the drive means the report arrives after the market opens.",
          outcomeVulnerable:
            "The model gives up: not enough RAM, and virtual memory is far too slow.",
        },
        {
          id: "finance_failure",
          kind: "failure",
          name: "The trade log drive fails",
          scenario:
            "Mid-afternoon, the drive holding today’s trade records stops working.",
          protectedBy: ["ext_hdd", "tape"],
          alsoHelpedBy: ["bluray"],
          outcomeProtected:
            "Restored from the backup within the hour. Every trade is accounted for.",
          outcomePartial:
            "Last month’s discs held the older trades. Today’s had to be pieced together by hand.",
          outcomeVulnerable:
            "No backup. The firm cannot prove which trades it made today.",
        },
        {
          id: "finance_pitch",
          kind: "carry",
          name: "Pitch at a pension fund",
          scenario:
            "Priya presents across the city and needs 20 GB of charts and models with her.",
          protectedBy: ["usb", "ext_ssd"],
          alsoHelpedBy: ["sd"],
          outcomeProtected:
            "Everything went in her pocket and opened first time on the client’s screen.",
          outcomePartial:
            "The SD cards needed a card reader, and the client’s laptop had none. Half the pitch was from memory.",
          outcomeVulnerable:
            "Nothing to carry it on. Priya pitched without her charts.",
        },
        {
          id: "finance_platform",
          kind: "knock",
          name: "Dropped on the station platform",
          scenario:
            "On the way to the pitch, the laptop bag slips off Priya’s shoulder onto the concrete.",
          protectedBy: ["ssd"],
          alsoHelpedBy: ["ext_hdd", "tape"],
          outcomeProtected:
            "A scuffed bag, but the SSD has no moving parts. The laptop started first time.",
          outcomePartial:
            "The hard disk died. Last night’s backup brought back everything but today’s changes.",
          outcomeVulnerable:
            "The drop broke the hard disk, and there was no other copy.",
        },
        {
          id: "finance_records",
          kind: "archive",
          name: "Keep every trade for the regulator",
          scenario:
            "The rules say every trade, with the recorded calls and messages behind it, is kept for at least five years: about 7 TB.",
          protectedBy: ["tape"],
          alsoHelpedBy: ["ext_hdd"],
          outcomeProtected:
            "One tape holds the lot, locked away cheaply for as long as the rules need.",
          outcomePartial:
            "Only 4 TB fit on the external hard disk. The oldest records had nowhere to go.",
          outcomeVulnerable:
            "Nowhere to keep them. The regulator fines the firm.",
        },
        {
          id: "finance_history",
          kind: "capacity",
          name: "Twenty years of prices",
          scenario:
            "The analysts want 2 TB of past prices on the desk computer to test new strategies.",
          protectedBy: ["hdd", "ext_ssd"],
          alsoHelpedBy: [],
          outcomeProtected: "There is room for every price.",
          outcomeVulnerable: "The 1 TB drive holds only half of it.",
        },
      ],
      units: [
        {
          id: "finance_feed",
          name: "A day of market data",
          scenario:
            "The price feed sends 50 MB every minute, and the market is open for 8 hours.",
          question: "How much data does one trading day make?",
          options: ["24 GB", "2.4 GB", "240 GB", "400 GB"],
          working:
            "8 hours = 480 minutes. 50 MB × 480 = 24 000 MB. 24 000 MB ÷ 1000 = 24 GB.",
          outcomeRight:
            "You set aside 24 GB a day. The feed never dropped a price.",
          outcomeWrong:
            "The space ran out at 3pm, and the last hour of prices was never saved.",
        },
        {
          id: "finance_trades",
          name: "A day of trade records",
          scenario:
            "The desk makes 5000 trades a day, and each trade record is 4 KB.",
          question: "How much space do a day’s trade records need?",
          options: ["20 MB", "2 MB", "200 MB", "20 GB"],
          working: "5000 × 4 KB = 20 000 KB. 20 000 KB ÷ 1000 = 20 MB.",
          outcomeRight: "You sized the log right. Every trade was recorded.",
          outcomeWrong:
            "The log was sized wrong, and the afternoon’s trades failed to save.",
        },
      ],
    },
    {
      id: "arctic",
      name: "Arctic researcher",
      contact: "Dr Brandt, polar station",
      need: "Bitter cold, no internet, and every byte goes home on the supply plane.",
      conditions: ["Bitter cold", "No internet", "Data flies home by plane"],
      budget: 420,
      topUp: 90,
      events: [
        {
          id: "arctic_plane",
          kind: "carry",
          name: "Data home on the supply plane",
          scenario:
            "The monthly plane leaves in an hour, and this month’s 60 GB must go with it.",
          protectedBy: ["sd", "usb", "ext_ssd"],
          alsoHelpedBy: ["bluray"],
          outcomeProtected:
            "Light, small and sealed in an envelope. It arrived safely.",
          outcomePartial:
            "Burning discs is slow. Two discs, 50 GB, were ready in time; the last 10 GB waits a month.",
          outcomeVulnerable:
            "Nothing to send it on. A month of results waits for the next plane.",
        },
        {
          id: "arctic_sledge",
          kind: "knock",
          name: "Across the ice by sledge",
          scenario:
            "At minus 30, the laptop crosses rough ice on a sledge to reach the far sensor site.",
          protectedBy: ["ssd"],
          alsoHelpedBy: ["ext_hdd", "tape"],
          outcomeProtected:
            "No moving parts to shake loose or stiffen in the cold. It worked on arrival.",
          outcomePartial:
            "The hard disk did not survive. The backup at base still had the data.",
          outcomeVulnerable:
            "The hard disk did not survive, and there was no other copy.",
        },
        {
          id: "arctic_sensors",
          kind: "capacity",
          name: "A season of sensor data",
          scenario:
            "The weather sensors and camera traps have recorded 2 TB this season.",
          protectedBy: ["hdd", "ext_ssd"],
          alsoHelpedBy: [],
          outcomeProtected: "There is room for every reading.",
          outcomeVulnerable:
            "Only 1 TB of space. Half the season’s data was deleted.",
        },
        {
          id: "arctic_model",
          kind: "heavy",
          name: "Run the ice model",
          scenario: "Dr Brandt loads a year of data into the ice-melt model.",
          protectedBy: ["ram32"],
          alsoHelpedBy: ["ram16"],
          outcomeProtected:
            "The whole dataset fits in RAM. The model runs in an hour.",
          outcomePartial:
            "It runs, but swapping to the drive turns an hour into a night.",
          outcomeVulnerable:
            "The model gives up: not enough RAM, and virtual memory is too slow.",
        },
        {
          id: "arctic_failure",
          kind: "failure",
          name: "The only computer for 500 km",
          scenario:
            "The station’s drive fails. The nearest repair shop is a plane ride away.",
          protectedBy: ["ext_hdd", "tape"],
          alsoHelpedBy: ["bluray"],
          outcomeProtected:
            "Restored from the backup onto the station’s spare drive the same day.",
          outcomePartial: "Some readings were on discs. The rest were lost.",
          outcomeVulnerable: "No backup. The season’s readings are gone.",
        },
        {
          id: "arctic_archive",
          kind: "archive",
          name: "Keep it for twenty years",
          scenario:
            "Climate scientists will need these 10 TB of readings for decades.",
          protectedBy: ["tape"],
          alsoHelpedBy: ["ext_hdd"],
          outcomeProtected:
            "One tape, cheap and long-lasting, goes to the archive.",
          outcomePartial: "The external hard disk holds less than half.",
          outcomeVulnerable:
            "No archive. The readings will be lost when the laptop is replaced.",
        },
        {
          id: "arctic_share",
          kind: "bulk",
          name: "Copies for 40 universities",
          scenario:
            "Forty universities each want a copy of the station’s findings film.",
          protectedBy: ["bluray"],
          alsoHelpedBy: ["usb"],
          outcomeProtected: "Forty discs, light enough to go on one plane.",
          outcomePartial:
            "One USB stick, so it was passed from university to university for months.",
          outcomeVulnerable: "No way to make copies.",
        },
        {
          id: "arctic_hut",
          kind: "multitask",
          name: "Everything open in the hut",
          scenario:
            "The logbook, ice maps, sensor charts and photo editing are all open at once.",
          protectedBy: ["ram16", "ram32"],
          alsoHelpedBy: ["ram8"],
          outcomeProtected:
            "Every program stays in RAM. Switching between them is instant.",
          outcomePartial:
            "It copes, but switching to the maps takes a few seconds each time.",
          outcomeVulnerable:
            "RAM is full, so the laptop swaps to virtual memory. Every switch takes ages.",
        },
      ],
      units: [
        {
          id: "arctic_month",
          name: "A month of readings",
          scenario: "Each reading is 2 MB, and the sensors take 500 a day.",
          question: "How much data do 30 days of readings make?",
          options: ["30 GB", "3 GB", "300 GB", "1 GB"],
          working: "2 MB × 500 × 30 = 30 000 MB. 30 000 MB ÷ 1000 = 30 GB.",
          outcomeRight:
            "You knew one 64 GB card would hold the month, and it did.",
          outcomeWrong:
            "You sized it wrong, and a week of readings had nowhere to go.",
        },
        {
          id: "arctic_photos",
          name: "How many photos per card?",
          scenario: "A camera-trap SD card holds 64 GB. Each photo is 4 MB.",
          question: "How many photos fit on one card?",
          options: [
            "16 000 photos",
            "1600 photos",
            "256 photos",
            "160 000 photos",
          ],
          working: "64 GB = 64 000 MB. 64 000 MB ÷ 4 MB = 16 000 photos.",
          outcomeRight:
            "You swapped the card before it reached 16 000 photos. Nothing was missed.",
          outcomeWrong:
            "The card filled up in a week, and the bear arrived in week two.",
        },
      ],
    },
  ],
  Ne = 3,
  it = 5,
  er = Ne;
function kt(t) {
  return et.find((s) => s.id === t);
}
function qe(t) {
  return ot.find((s) => s.id === t);
}
function Ve(t) {
  return t.budget + t.topUp;
}
function Ye(t) {
  return Ge.flatMap((s) => {
    const r = t[s.id];
    return r ? [r] : [];
  });
}
function pe(t) {
  return Ye(t).reduce((s, r) => s + qe(r).cost, 0);
}
function tr(t, s, r) {
  const a = s[t.slot];
  return (a ? pe(s) - qe(a).cost : pe(s)) + t.cost <= r;
}
function sr(t) {
  return Ge.every((s) => !s.required || !!t[s.id]);
}
function rr(t, s) {
  const r = Ye(s);
  return t.protectedBy.some((a) => r.includes(a))
    ? "protected"
    : t.alsoHelpedBy.some((a) => r.includes(a))
      ? "partial"
      : "vulnerable";
}
function vt(t, s) {
  const r = [...t];
  for (let a = r.length - 1; a > 0; a -= 1) {
    const o = Math.floor(s() * (a + 1));
    [r[a], r[o]] = [r[o], r[a]];
  }
  return r;
}
function ar(t, s = Math.random) {
  const r = vt(t.events, s).slice(0, it - 1),
    a = vt(t.units, s)[0],
    o = r.map((n) => ({ type: "event", event: n }));
  return (o.splice(er, 0, { type: "units", event: a }), o);
}
const Bt = { protected: 2, partial: 1, vulnerable: 0 };
function or(t, s) {
  const r = s === 0 ? 0 : Math.round((t / s) * 100);
  return r >= 84
    ? {
        label: "Chief Engineer",
        message:
          "Your client had a great week. You matched every part to what they needed.",
        tone: "good",
      }
    : r >= 50
      ? {
          label: "Solid Technician",
          message:
            "The build coped with most of the week. Look again at what each storage type is best at.",
          tone: "mixed",
        }
      : {
          label: "Work Experience",
          message:
            "The build let your client down. Think about capacity, speed, portability, durability, reliability and cost.",
          tone: "bad",
        };
}
function oe(t) {
  return `£${t}`;
}
const Tt = "spec-it-fonts",
  ir =
    "https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;600&family=Space+Grotesk:wght@400;600;700&display=swap";
function nr() {
  L.useEffect(() => {
    if (document.getElementById(Tt)) return;
    const t = document.createElement("link");
    ((t.id = Tt),
      (t.rel = "stylesheet"),
      (t.href = ir),
      document.head.appendChild(t));
  }, []);
}
const It = 2e3,
  lr = 1300,
  cr = It + lr,
  dr = 1500,
  nt = {
    protected: { short: "Coped" },
    partial: { short: "In part" },
    vulnerable: { short: "Let down" },
  },
  hr = { good: "protected", mixed: "partial", bad: "vulnerable" },
  xr =
    "Work in one unit at a time: 1 KB = 1000 bytes, 1 MB = 1000 KB, 1 GB = 1000 MB, 1 TB = 1000 GB. Multiply to find a total, divide to find how many fit. Exams accept 1000 or 1024, as long as you show your working.",
  fr = { aspect: 2 / 3, lift: 1 },
  jr = { aspect: 0.5, lift: 0.18 };
function mr({ client: t, title: s }) {
  const r = Zt(t);
  return e.jsx("div", {
    className: "si-pick-art",
    ref: r,
    children: e.jsx(We, { client: t, title: s }),
  });
}
function ur({ onPick: t }) {
  return St()
    ? e.jsx("div", {
        "data-spec-stage": "pick",
        children: e.jsx(es, {
          label: "Who are you building for?",
          primaryClass: "si-button",
          chooseLabel: "Take the job",
          picks: et.map((r) => ({
            id: r.id,
            name: r.name,
            aside: oe(r.budget),
            line: r.need,
            art: e.jsx(We, {
              client: r.id,
              title: `${r.name} at work`,
              tall: jr,
            }),
            data: { "data-client": r.id },
          })),
          onPick: (r) => t(r),
        }),
      })
    : e.jsxs("div", {
        className: "space-y-4",
        "data-spec-stage": "pick",
        children: [
          e.jsxs("div", {
            className: "flex flex-wrap items-center justify-between gap-3",
            children: [
              e.jsx("h2", {
                className: "text-2xl font-bold",
                children: "Who are you building for?",
              }),
              e.jsx("span", { className: "si-stamp", children: "JOB SHEET" }),
            ],
          }),
          e.jsx("ul", {
            className: "grid gap-4 sm:grid-cols-2 lg:grid-cols-3",
            "aria-label": "Clients",
            children: et
              .slice(0, 6)
              .map((r) =>
                e.jsxs(
                  "li",
                  {
                    className: "si-card flex flex-col overflow-hidden",
                    "data-client-card": r.id,
                    children: [
                      e.jsx(mr, { client: r.id, title: `${r.name} at work` }),
                      e.jsxs("div", {
                        className:
                          "flex flex-1 flex-col gap-1.5 px-4 pb-4 pt-3",
                        children: [
                          e.jsxs("p", {
                            className:
                              "flex items-baseline justify-between gap-3",
                            children: [
                              e.jsx("span", {
                                className: "text-lg font-bold",
                                children: r.name,
                              }),
                              e.jsx("span", {
                                className:
                                  "si-mono text-sm font-semibold text-[#1f4fbf]",
                                children: oe(r.budget),
                              }),
                            ],
                          }),
                          e.jsx("p", {
                            className:
                              "flex-1 text-sm leading-6 text-[#374151]",
                            children: r.need,
                          }),
                          e.jsx("button", {
                            type: "button",
                            className: "si-button self-start",
                            "data-client": r.id,
                            "aria-label": `Take the job: ${r.name}`,
                            onClick: () => t(r.id),
                            children: "Take the job",
                          }),
                        ],
                      }),
                    ],
                  },
                  r.id,
                ),
              ),
          }),
        ],
      });
}
function Ue({
  client: t,
  spent: s,
  budget: r,
  topUp: a,
  results: o,
  current: n,
  children: l,
}) {
  const d = Math.min(100, (s / r) * 100);
  return e.jsxs("div", {
    className:
      "si-hud sticky top-2 z-10 flex items-center gap-1.5 px-2 py-2 sm:gap-4 sm:px-4",
    "data-spec-hud": !0,
    children: [
      e.jsxs("div", {
        className: "flex shrink-0 items-center gap-2",
        children: [
          e.jsx(Rt, { id: t.id, className: "h-7 w-7 shrink-0 sm:h-8 sm:w-8" }),
          e.jsx("h2", {
            className: "sr-only truncate text-base font-bold sm:not-sr-only",
            children: a ? "Re-spec: budget topped up" : t.name,
          }),
        ],
      }),
      e.jsxs("div", {
        className: "flex items-center gap-2",
        "data-spec-budget": !0,
        children: [
          e.jsxs("span", {
            className: "si-mono whitespace-nowrap text-xs font-semibold",
            children: [
              e.jsxs("span", {
                className: "hidden sm:inline",
                children: [oe(s), " / ", oe(r)],
              }),
              e.jsxs("span", {
                className: "sm:hidden",
                children: [oe(r - s), " left"],
              }),
            ],
          }),
          e.jsx("span", {
            className: "si-meter hidden w-24 sm:inline-block",
            children: e.jsx("span", { style: { width: `${d}%` } }),
          }),
          a
            ? e.jsxs("span", {
                className:
                  "si-mono hidden text-xs font-bold text-[#1f9d6b] sm:inline",
                "data-spec-topup": a,
                children: ["+", oe(a)],
              })
            : null,
        ],
      }),
      e.jsx(yr, { results: o, current: n }),
      l ? e.jsx("div", { className: "ml-auto shrink-0", children: l }) : null,
    ],
  });
}
function Dt(t) {
  const s = St();
  return e.jsx("div", {
    className: "si-stage",
    "data-frame": s ? "tall" : "wide",
    children: e.jsx(We, {
      ...t,
      tall: s ? fr : void 0,
      className: "block h-full w-full",
    }),
  });
}
function Vt({ round: t, level: s }) {
  return e.jsx("div", {
    className: "si-stage",
    children: e.jsx(Ot, {
      event: t.event.id,
      kind: Kt(t),
      level: s,
      title: t.event.name,
      className: "block h-full w-full",
    }),
  });
}
function pr({ build: t, locked: s }) {
  return e.jsxs("div", {
    className: "si-card-dashed space-y-2 p-4",
    "data-spec-build": !0,
    children: [
      e.jsx("p", {
        className: "si-eyebrow text-[#1f4fbf]",
        children: "Your build",
      }),
      e.jsxs("div", {
        className: "si-slot",
        children: [
          e.jsx("span", { children: "ROM" }),
          e.jsx("span", { children: "BIOS (fitted)" }),
        ],
      }),
      Ge.map((r) => {
        const a = t[r.id];
        return e.jsxs(
          "div",
          {
            className: "si-slot",
            "data-empty": a ? void 0 : !0,
            "data-build-slot": r.id,
            children: [
              e.jsxs("span", {
                className: "flex items-center gap-1.5",
                children: [
                  s.includes(r.id)
                    ? e.jsx(rs, {
                        "aria-label": "Locked in",
                        className: "h-3.5 w-3.5",
                      })
                    : null,
                  r.name,
                ],
              }),
              e.jsx("span", {
                className: "text-right",
                children: a ? qe(a).name : r.empty,
              }),
            ],
          },
          r.id,
        );
      }),
      e.jsx("p", {
        className: "pt-1 text-xs leading-5 text-[#5b6474]",
        children:
          "ROM comes fitted: it holds the start-up instructions and keeps them with the power off.",
      }),
    ],
  });
}
function Mt({
  client: t,
  build: s,
  locked: r,
  budget: a,
  results: o,
  onToggle: n,
  onShip: l,
}) {
  const d = r.length > 0 || a > t.budget;
  return e.jsxs("div", {
    className: "space-y-4",
    "data-spec-stage": d ? "respec" : "bench",
    children: [
      e.jsx(Ue, {
        client: t,
        spent: pe(s),
        budget: a,
        topUp: d ? t.topUp : void 0,
        results: o,
        children: e.jsx("button", {
          type: "button",
          className: "si-button",
          disabled: !sr(s),
          onClick: l,
          children: "Ship the build",
        }),
      }),
      e.jsx(Dt, {
        client: t.id,
        build: s,
        pins: !0,
        title: `${t.name}: the build so far`,
      }),
      e.jsx("ol", {
        className: "grid grid-cols-3 gap-2",
        "aria-label": "The brief",
        "data-spec-brief": !0,
        children: t.conditions.map((c, h) =>
          e.jsxs(
            "li",
            {
              className: "si-brief flex items-center gap-2 px-2 py-1.5",
              "data-condition": h,
              children: [
                e.jsx("span", {
                  className: "si-pin",
                  "aria-hidden": "true",
                  children: h + 1,
                }),
                e.jsx("span", {
                  className: "text-xs font-semibold leading-4 sm:text-sm",
                  children: c,
                }),
              ],
            },
            c,
          ),
        ),
      }),
      e.jsxs("div", {
        className: "grid gap-5 lg:grid-cols-[minmax(0,1fr)_18rem]",
        children: [
          e.jsx("div", {
            className: "space-y-4",
            children: Ge.map((c) => {
              const h = r.includes(c.id);
              return e.jsxs(
                "section",
                {
                  "aria-label": c.name,
                  className: "space-y-2",
                  children: [
                    e.jsxs("h3", {
                      className: "si-eyebrow",
                      children: [c.name, c.required ? " (required)" : ""],
                    }),
                    e.jsx("div", {
                      className:
                        "grid grid-cols-3 gap-2 sm:grid-cols-4 sm:gap-3 xl:grid-cols-5",
                      role: "group",
                      "aria-label": `${c.name} parts`,
                      children: ot
                        .filter((x) => x.slot === c.id)
                        .map((x) => {
                          const m = s[c.id] === x.id,
                            k = m || tr(x, s, a);
                          return e.jsxs(
                            "button",
                            {
                              type: "button",
                              "aria-pressed": m,
                              disabled: h || !k,
                              "data-locked": h || void 0,
                              "data-part": x.id,
                              onClick: () => n(x),
                              className:
                                "si-part flex flex-col items-center gap-1 px-1.5 pb-2 pt-1 text-center",
                              children: [
                                e.jsx(Me, {
                                  id: x.id,
                                  className: "si-part-art",
                                }),
                                e.jsx("span", {
                                  className:
                                    "si-caption text-sm font-bold leading-tight",
                                  children: x.name,
                                }),
                                e.jsx("span", {
                                  className:
                                    "si-mono text-sm font-semibold text-[#1f4fbf]",
                                  children: oe(x.cost),
                                }),
                                e.jsx("span", {
                                  className: "sr-only",
                                  children: x.spec,
                                }),
                              ],
                            },
                            x.id,
                          );
                        }),
                    }),
                  ],
                },
                c.id,
              );
            }),
          }),
          e.jsx("div", {
            className: "lg:sticky lg:top-28 lg:self-start",
            children: e.jsx(pr, { build: s, locked: r }),
          }),
        ],
      }),
    ],
  });
}
function yr({ results: t, current: s }) {
  return e.jsx("ol", {
    className: "flex shrink-0 items-center gap-2",
    "aria-label": "Events",
    "data-led-row": !0,
    children: Array.from({ length: it }, (r, a) => {
      const o = t[a],
        n = a === s;
      return e.jsxs(
        "li",
        {
          "aria-current": n ? "step" : void 0,
          children: [
            e.jsx("span", {
              className: "si-led",
              "data-led": o ?? "unplayed",
              "data-active": n || void 0,
            }),
            e.jsxs("span", {
              className: "sr-only",
              children: [
                "Event ",
                a + 1,
                ": ",
                o ? nt[o].short : "still to come",
              ],
            }),
          ],
        },
        a,
      );
    }),
  });
}
function wr({ round: t, client: s, build: r, onDone: a }) {
  const [o, n] = L.useState(!1);
  return (
    L.useEffect(() => {
      const l = window.setTimeout(() => n(!0), It),
        d = window.setTimeout(a, cr);
      return () => {
        (window.clearTimeout(l), window.clearTimeout(d));
      };
    }, [a]),
    e.jsxs("div", {
      className: "si-beat",
      "data-spec-stage": "beat",
      "data-beat-phase": o ? "alert" : "hum",
      children: [
        e.jsx("p", {
          className: "sr-only",
          "aria-live": "assertive",
          children: o
            ? "Something has happened to the build."
            : "The build is hard at work.",
        }),
        o
          ? e.jsx(Ot, {
              event: t.event.id,
              kind: Kt(t),
              alert: !0,
              title: t.event.name,
              className: "block h-full w-full",
            })
          : e.jsx(We, {
              client: s.id,
              build: r,
              night: !0,
              title: s.name,
              className: "block h-full w-full",
            }),
      ],
    })
  );
}
function gr({ client: t, build: s, onDone: r }) {
  return (
    L.useEffect(() => {
      const a = window.setTimeout(r, dr);
      return () => window.clearTimeout(a);
    }, [r]),
    e.jsxs("div", {
      className: "si-beat",
      "data-spec-stage": "test",
      children: [
        e.jsx("p", {
          className: "sr-only",
          "aria-live": "polite",
          children: "Testing the build.",
        }),
        e.jsx(We, {
          client: t.id,
          build: s,
          night: !0,
          scanning: !0,
          title: t.name,
          className: "block h-full w-full",
        }),
      ],
    })
  );
}
function Kt(t) {
  return t.type === "units" ? "units" : t.event.kind;
}
function br({
  round: t,
  index: s,
  client: r,
  build: a,
  budget: o,
  results: n,
  onReveal: l,
  onAnswer: d,
}) {
  return e.jsxs(Ft.div, {
    initial: { opacity: 0 },
    animate: { opacity: 1 },
    className: "space-y-4",
    "data-spec-stage": "event",
    "data-spec-round": t.type,
    children: [
      e.jsx(Ue, { client: r, spent: pe(a), budget: o, results: n, current: s }),
      e.jsx(Vt, { round: t }),
      e.jsxs("div", {
        className: "si-card space-y-2 p-5",
        children: [
          e.jsx("h2", {
            className: "text-2xl font-bold sm:text-3xl",
            children: t.event.name,
          }),
          e.jsx("p", {
            className: "text-lg leading-8 text-[#1f2937]",
            children: t.event.scenario,
          }),
        ],
      }),
      t.type === "units"
        ? e.jsx(kr, { event: t.event, onAnswer: d })
        : e.jsx("button", {
            type: "button",
            className: "si-button",
            onClick: l,
            children: "See what happens",
          }),
    ],
  });
}
function kr({ event: t, onAnswer: s }) {
  const [r] = L.useState(() => {
    const a = t.options.map((o, n) => n);
    for (let o = a.length - 1; o > 0; o -= 1) {
      const n = Math.floor(Math.random() * (o + 1));
      [a[o], a[n]] = [a[n], a[o]];
    }
    return a;
  });
  return e.jsxs("div", {
    className: "space-y-3",
    children: [
      e.jsx("p", { className: "text-lg font-bold", children: t.question }),
      e.jsx("div", {
        className: "grid gap-3 sm:grid-cols-2",
        role: "group",
        "aria-label": "Your answer",
        children: r.map((a) =>
          e.jsx(
            "button",
            {
              type: "button",
              className: "si-option text-left",
              "data-units-option": a === 0 ? "right" : "wrong",
              onClick: () => s(a),
              children: t.options[a],
            },
            a,
          ),
        ),
      }),
    ],
  });
}
function _t({ title: t, ids: s, empty: r, group: a }) {
  return e.jsxs("div", {
    className: "si-card p-4",
    "data-part-group": a,
    children: [
      e.jsx("h3", { className: "si-eyebrow mb-3", children: t }),
      s.length === 0
        ? e.jsx("p", {
            className: "text-sm italic text-[#5b6474]",
            children: r,
          })
        : e.jsx("ul", {
            className: "flex flex-wrap gap-3",
            children: s.map((o) => {
              const n = ot.find((l) => l.id === o);
              return e.jsxs(
                "li",
                {
                  className:
                    "flex items-center gap-2 rounded-md border-2 border-[#1f4fbf] bg-[#fffdf7] py-1 pl-1 pr-3",
                  "data-part-chip": o,
                  children: [
                    e.jsx(Me, { id: n.id, className: "h-9 w-9" }),
                    e.jsx("span", {
                      className: "text-sm font-semibold",
                      children: n.name,
                    }),
                  ],
                },
                o,
              );
            }),
          }),
    ],
  });
}
function vr({
  round: t,
  index: s,
  level: r,
  client: a,
  budget: o,
  results: n,
  build: l,
  pick: d,
  isLast: c,
  beforeRespec: h,
  onNext: x,
}) {
  const m = Ye(l);
  let k, W, _;
  if (t.type === "units") {
    const p = t.event;
    ((k = r === "protected" ? p.outcomeRight : p.outcomeWrong),
      (W = xr),
      (_ = e.jsxs("div", {
        className: "si-working space-y-1 text-sm",
        "data-units-working": !0,
        children: [
          e.jsxs("p", {
            children: [
              "You said: ",
              e.jsx("strong", {
                children: d === void 0 ? "nothing" : p.options[d],
              }),
            ],
          }),
          e.jsxs("p", {
            children: ["Answer: ", e.jsx("strong", { children: p.options[0] })],
          }),
          e.jsx("p", { className: "text-[#1f4fbf]", children: p.working }),
        ],
      })));
  } else {
    const p = t.event;
    ((k =
      r === "protected"
        ? p.outcomeProtected
        : r === "partial"
          ? (p.outcomePartial ?? p.outcomeVulnerable)
          : p.outcomeVulnerable),
      (W = Zs[p.kind]));
    const E = [...p.protectedBy, ...p.alsoHelpedBy].filter((Z) =>
        m.includes(Z),
      ),
      K = p.protectedBy.filter((Z) => !m.includes(Z));
    _ = e.jsxs("div", {
      className: "grid gap-3 sm:grid-cols-2",
      children: [
        e.jsx(_t, {
          title: "Parts that helped",
          ids: E,
          empty: "Nothing you fitted helped here.",
          group: "helped",
        }),
        e.jsx(_t, {
          title: "Would have coped fully",
          ids: r === "protected" ? [] : K,
          empty: "You had it covered.",
          group: "needed",
        }),
      ],
    });
  }
  return e.jsxs(Ft.div, {
    initial: { opacity: 0, y: 10 },
    animate: { opacity: 1, y: 0 },
    className: "space-y-4",
    "data-spec-stage": "result",
    "data-level": r,
    children: [
      e.jsx(Ue, { client: a, spent: pe(l), budget: o, results: n, current: s }),
      e.jsx(Vt, { round: t, level: r }),
      e.jsxs("h2", {
        className: "flex flex-wrap items-center gap-3 text-2xl font-bold",
        children: [
          t.event.name,
          e.jsx("span", {
            className: "si-pill",
            "data-level": r,
            children:
              t.type === "units"
                ? r === "protected"
                  ? "Right"
                  : "Wrong"
                : nt[r].short,
          }),
        ],
      }),
      e.jsxs("div", {
        className: "si-card space-y-2 p-5",
        children: [
          e.jsx("h3", {
            className: "si-eyebrow text-[#1f4fbf]",
            children: "What happened",
          }),
          e.jsx("p", { className: "leading-7", children: k }),
        ],
      }),
      _,
      e.jsxs("div", {
        className: "rounded-lg border-2 border-[#f26b1d] bg-[#fde3d2] p-5",
        children: [
          e.jsx("h3", {
            className: "si-eyebrow mb-2 text-[#c2500f]",
            children: "What you learned",
          }),
          e.jsx("p", { className: "leading-7", children: W }),
        ],
      }),
      e.jsx("button", {
        type: "button",
        className: "si-button",
        onClick: x,
        children: c ? "See the rating" : h ? "Re-spec the build" : "Next event",
      }),
    ],
  });
}
function Br({
  client: t,
  rounds: s,
  results: r,
  build: a,
  onRestart: o,
  onPickAnother: n,
}) {
  const l = r.reduce((h, x) => h + (x ? Bt[x] : 0), 0),
    d = s.length * Bt.protected,
    c = or(l, d);
  return e.jsxs(e.Fragment, {
    children: [
      e.jsxs("div", {
        className: "space-y-5",
        "aria-live": "polite",
        "data-game-finished": c.tone,
        "data-spec-stage": "final",
        children: [
          e.jsx(Ue, { client: t, spent: pe(a), budget: Ve(t), results: r }),
          e.jsx(Dt, {
            client: t.id,
            build: a,
            level: hr[c.tone],
            title: `${t.name}: the week`,
          }),
          e.jsxs("div", {
            className: "si-card flex flex-col gap-6 p-6 sm:flex-row",
            children: [
              e.jsxs("div", {
                className: "shrink-0 text-center sm:w-48",
                children: [
                  e.jsx(Rt, { id: t.id, className: "mx-auto h-20 w-20" }),
                  e.jsx("p", {
                    className: "mt-3 text-3xl font-bold text-[#f26b1d]",
                    children: c.label,
                  }),
                  e.jsxs("p", {
                    className: "si-mono mt-1 text-sm",
                    children: [l, " / ", d],
                  }),
                ],
              }),
              e.jsxs("div", {
                className: "flex-1 space-y-4",
                children: [
                  e.jsx("p", { className: "leading-7", children: c.message }),
                  e.jsxs("div", {
                    children: [
                      e.jsxs("h3", {
                        className: "si-eyebrow mb-2",
                        children: [t.name, ": the week"],
                      }),
                      e.jsx("ul", {
                        className: "space-y-1.5",
                        children: s.map((h, x) => {
                          const m = r[x] ?? "vulnerable";
                          return e.jsxs(
                            "li",
                            {
                              className:
                                "flex items-center justify-between gap-3 text-sm",
                              children: [
                                e.jsx("span", { children: h.event.name }),
                                e.jsx("span", {
                                  className: "si-pill shrink-0",
                                  "data-level": m,
                                  children: nt[m].short,
                                }),
                              ],
                            },
                            h.event.id,
                          );
                        }),
                      }),
                    ],
                  }),
                  e.jsxs("p", {
                    className: "text-sm text-[#5b6474]",
                    children: [
                      "You spent ",
                      oe(pe(a)),
                      " of ",
                      oe(Ve(t)),
                      " on",
                      " ",
                      Ye(a)
                        .map((h) => qe(h).name)
                        .join(", "),
                      ".",
                    ],
                  }),
                ],
              }),
            ],
          }),
          e.jsxs("div", {
            className: "flex flex-wrap gap-3",
            children: [
              e.jsxs("button", {
                type: "button",
                className: "si-button",
                onClick: o,
                children: [
                  e.jsx(ts, { "aria-hidden": "true", className: "h-4 w-4" }),
                  "Same client, new events",
                ],
              }),
              e.jsxs("button", {
                type: "button",
                className: "si-button-ghost",
                onClick: n,
                children: [
                  e.jsx(ss, { "aria-hidden": "true", className: "h-4 w-4" }),
                  "Try another client",
                ],
              }),
            ],
          }),
        ],
      }),
      e.jsx(Qt, { game: "spec-it" }),
    ],
  });
}
function Rr() {
  nr();
  const [t, s] = L.useState({ type: "cards" }),
    [r, a] = L.useState("film"),
    [o, n] = L.useState({}),
    [l, d] = L.useState([]),
    [c, h] = L.useState([]),
    [x, m] = L.useState([]),
    [k, W] = L.useState({}),
    _ = kt(r);
  Xt(x.filter(Boolean).length, it, x.filter((w) => w === "protected").length);
  const p = "round" in t ? t.round : 0,
    E = (w) => (w >= Ne ? Ve(_) : _.budget),
    K = L.useCallback(() => s({ type: "event", round: p }), [p]),
    Z = L.useCallback(() => s({ type: "result", round: p }), [p]);
  function ye(w) {
    (a(w), h(ar(kt(w))), n({}), d([]), m([]), W({}), s({ type: "bench" }));
  }
  function lt(w) {
    l.includes(w.slot) ||
      n(($) => {
        const le = { ...$ };
        return (
          le[w.slot] === w.id ? delete le[w.slot] : (le[w.slot] = w.id),
          le
        );
      });
  }
  function ct(w, $) {
    (m((le) => {
      const dt = [...le];
      return ((dt[w] = $), dt);
    }),
      s({ type: "test", round: w }));
  }
  function qt(w) {
    const $ = c[w];
    $?.type === "event" && ct(w, rr($.event, o));
  }
  function Yt(w, $) {
    (W((le) => ({ ...le, [w]: $ })),
      ct(w, $ === 0 ? "protected" : "vulnerable"));
  }
  function Ut(w) {
    w + 1 >= c.length
      ? s({ type: "final" })
      : w + 1 === Ne
        ? (d(Ge.filter(($) => o[$.id]).map(($) => $.id)), s({ type: "respec" }))
        : s({ type: "beat", round: w + 1 });
  }
  if (t.type === "beat") {
    const w = c[t.round];
    return w
      ? e.jsx(wr, { round: w, client: _, build: o, onDone: K }, t.round)
      : null;
  }
  if (t.type === "test")
    return e.jsx(gr, { client: _, build: o, onDone: Z }, t.round);
  let ne = null;
  switch (t.type) {
    case "cards":
      ne = e.jsx(Jt, {
        title: "Know your parts",
        cards: Js,
        skipLabel: "Skip to the job sheet",
        doneLabel: "Pick a client",
        buttonClass: "si-button-ghost",
        primaryClass: "si-kf-primary",
        titleClass: "si-kf-title",
        onDone: () => s({ type: "pick" }),
      });
      break;
    case "pick":
      ne = e.jsx(ur, { onPick: ye });
      break;
    case "bench":
      ne = e.jsx(Mt, {
        client: _,
        build: o,
        locked: [],
        budget: _.budget,
        results: x,
        onToggle: lt,
        onShip: () => s({ type: "beat", round: 0 }),
      });
      break;
    case "respec":
      ne = e.jsx(Mt, {
        client: _,
        build: o,
        locked: l,
        budget: Ve(_),
        results: x,
        onToggle: lt,
        onShip: () => s({ type: "beat", round: Ne }),
      });
      break;
    case "event": {
      const w = c[t.round];
      ne = w
        ? e.jsx(
            br,
            {
              round: w,
              index: t.round,
              client: _,
              build: o,
              budget: E(t.round),
              results: x,
              onReveal: () => qt(t.round),
              onAnswer: ($) => Yt(t.round, $),
            },
            t.round,
          )
        : null;
      break;
    }
    case "result": {
      const w = c[t.round],
        $ = x[t.round];
      ne =
        w && $
          ? e.jsx(vr, {
              round: w,
              index: t.round,
              level: $,
              client: _,
              budget: E(t.round),
              results: x,
              build: o,
              pick: k[t.round],
              isLast: t.round === c.length - 1,
              beforeRespec: t.round === Ne - 1,
              onNext: () => Ut(t.round),
            })
          : null;
      break;
    }
    case "final":
      ne = e.jsx(Br, {
        client: _,
        rounds: c,
        results: x,
        build: o,
        onRestart: () => ye(r),
        onPickAnother: () => s({ type: "pick" }),
      });
      break;
  }
  return e.jsx("div", { className: "spec-it", children: ne });
}
export {
  lr as ALERT_MS,
  cr as EVENT_BEAT_MS,
  It as HUM_MS,
  dr as TEST_MS,
  Rr as default,
};
