import { T as i, f as a, C as l, h as t, r as s } from "./cinema-CBL_zzZm.js";
const o = "=SUM(D2:D11)",
  h = s("D2:D11", "range"),
  n = (e, r = {}, b = {}) => ({
    sheets: [
      a({
        cols: ["A", "B", "C", "D"],
        to: 12,
        set: { C12: "Total", D12: e },
        hl: r,
      }),
    ],
    ...b,
  }),
  c = (e, r = {}) => ({
    sheets: [
      a({
        cols: ["A", "D", "E", "G"],
        to: 4,
        set: { G1: "Takings", G2: e },
        hl: r,
      }),
    ],
  }),
  p = {
    id: "sum",
    logo: "SUM",
    title: "The SUM Challenge",
    badge: "BTEC DIT · Component 2 · Task 2a / 2b",
    lead: "Every dashboard total starts here: <b>=</b>, a function such as <b>SUM</b>, and the cells to use. Tap a colour to zoom in on that part, or press <b>Watch it work</b>.",
    formula: [
      { t: "=", a: 0 },
      { t: "SUM", a: 1 },
      { t: "(" },
      { t: "D2:D11", a: 2 },
      { t: ")" },
    ],
    args: [
      {
        k: "=",
        c: l.pink,
        tint: "#ffe1ee",
        lab: "This is a formula",
        title: "1. The equals sign",
        txt: "Every formula starts with <b>=</b>. Leave it off and Excel treats what you typed as text and just shows the letters.",
        vis: n(
          "SUM(D2:D11)",
          { D12: "bad" },
          {
            note: "No = sign, so D12 shows the letters SUM(D2:D11) instead of a total.",
          },
        ),
      },
      {
        k: "SUM",
        c: l.orange,
        tint: "#fff0d6",
        lab: "What to work out",
        title: "2. The function",
        txt: "The job to do. <b>SUM</b> adds up. Its cousins use the same brackets: <b>AVERAGE</b>, <b>MIN</b> and <b>MAX</b>.",
        vis: {
          sheets: [
            {
              tab: "Functions",
              cols: ["A", "B", "C"],
              start: 1,
              hdRow: 1,
              data: [
                ["Function", "Does", "On D2:D11"],
                ["SUM", "adds up", 1005],
                ["AVERAGE", "the mean", 100.5],
                ["MIN", "the smallest", 40],
                ["MAX", "the largest", 150],
              ],
              hl: { A2: "look" },
            },
          ],
        },
      },
      {
        k: "D2:D11",
        c: l.green,
        tint: "#d6f7f3",
        lab: "Which cells to use",
        title: "3. The range",
        txt: 'The cells to work on: <b>D2</b> to <b>D11</b>, the ten ticket cells. The <b>colon</b> means "to". The header in D1 stays out.',
        vis: { sheets: [a({ hl: h })] },
      },
    ],
    plain: [
      '"',
      { a: 0, t: "Work this out:" },
      " ",
      { a: 1, t: "add up" },
      " ",
      { a: 2, t: "every cell from D2 to D11" },
      '."',
    ],
    play: [
      {
        a: 0,
        cap: "Step 1: the = tells Excel that D12 holds a formula, not text.",
        vis: n(o, { D12: "look" }),
      },
      { a: 1, cap: "Step 2: SUM means add up.", vis: n(o, { D12: "look" }) },
      {
        a: 2,
        cap: "Step 3: take every cell from D2 to D11.",
        vis: n(o, t(h, { D12: "look" })),
      },
      {
        a: 2,
        cap: "...120 + 85 + 140 + 60 + 95 + 150 + 40 + 75 + 110 + 130.",
        vis: n(o, t(s("D2:D11", "scan"), { D12: "look" })),
      },
      {
        a: -1,
        cap: "Step 4: D12 shows 1005.",
        vis: n(1005, t(s("D2:D11", "hit"), { D12: "ret" }), {
          legend: [
            [i.hit, "added up"],
            [i.ret, "the total"],
          ],
        }),
      },
    ],
    sections: [
      { id: "meet", name: "Meet SUM", c: l.pink },
      { id: "start", name: "Start with =", c: l.orange },
      { id: "range", name: "Colon or Comma", c: l.green },
      { id: "four", name: "The Big Four", c: l.blue },
      { id: "typo", name: "Fix These Typos", c: l.red },
      { id: "bug", name: "Bug Hunt", c: l.purple },
    ],
    questions: [
      {
        sec: "meet",
        type: "match",
        prompt: "Match each part of the formula to what it does.",
        visual: () => ({ fx: o }),
        pairs: [
          ["=", "Tells Excel this is a formula"],
          ["SUM", "The job: add up"],
          ["D2:D11", "The cells to use (the range)"],
        ],
        explain:
          "Every formula has the same shape: <b>=</b>, the <b>function</b>, then the <b>cells</b> in brackets.",
      },
      {
        sec: "meet",
        type: "value",
        prompt: `D12 contains <code>${o}</code>. What does it show?`,
        visual: (e) =>
          n(
            e ? 1005 : o,
            e ? t(s("D2:D11", "hit"), { D12: "ret" }) : t(h, { D12: "look" }),
          ),
        accept: ["1005"],
        traps: {
          150: "150 is the <b>MAX</b>, the biggest single value.",
          100.5: "100.5 is the <b>AVERAGE</b>.",
        },
        hint: "Add the ten ticket numbers together.",
        explain:
          "SUM adds every cell in the range: <b>1005</b> tickets in total.",
      },
      {
        sec: "start",
        type: "mcq",
        prompt:
          "Takings = tickets × price. Which formula belongs in <code>G2</code> for Robot Rescue?",
        visual: (e) =>
          c(
            e ? 720 : "",
            t({ D2: "look", E2: "look" }, e ? { G2: "ret" } : {}),
          ),
        opts: ["=D2*E2", "D2*E2", "=D2xE2", "=SUM(D2:E2)"],
        ans: 0,
        mono: !0,
        explain:
          "Every formula starts with <b>=</b>, and multiply is <b>*</b> (divide is <b>/</b>). G2 shows <b>720</b>, 120 × 6. <code>=SUM(D2:E2)</code> would add them: 126.",
      },
      {
        sec: "start",
        type: "value",
        prompt: "What does <code>=10+2*5</code> show?",
        accept: ["20"],
        traps: {
          60: "60 would be <code>=(10+2)*5</code>. Without brackets Excel multiplies before it adds.",
        },
        hint: "Think BIDMAS from maths lessons.",
        explain:
          "Excel follows <b>BIDMAS</b>, as in maths: 2*5 = 10 first, then 10 + 10 = <b>20</b>. Brackets change the order.",
      },
      {
        sec: "start",
        type: "mcq",
        prompt:
          "Which formula gives the takings for Robot Rescue <b>after</b> a £1 discount on every ticket?",
        visual: (e) =>
          c(
            e ? 600 : "",
            t({ D2: "look", E2: "look" }, e ? { G2: "ret" } : {}),
          ),
        opts: ["=D2*(E2-1)", "=D2*E2-1", "=(D2*E2)-1", "=D2-1*E2"],
        ans: 0,
        mono: !0,
        explain:
          "The brackets work out the new price first: 6 - 1 = 5, then 120 × 5 = <b>600</b>. Without them Excel takes £1 off the whole total, giving 719.",
      },
      {
        sec: "range",
        type: "mcq",
        prompt:
          "What is the difference between <code>=SUM(D2:D11)</code> and <code>=SUM(D2,D11)</code>?",
        visual: (e) =>
          e
            ? {
                sheets: [
                  a({ hl: t(s("D2:D11", "hit"), { D2: "look", D11: "look" }) }),
                ],
                legend: [
                  [i.hit, "D2:D11, all ten"],
                  [i.look, "D2,D11, just two"],
                ],
              }
            : null,
        opts: [
          "The colon adds every cell from D2 to D11; the comma adds only D2 and D11",
          "The comma adds every cell from D2 to D11; the colon adds only D2 and D11",
          'There is no difference, because colons and commas both mean "and" in Excel',
          "The colon adds rows 2 to 11 in every column; the comma adds column D only",
        ],
        ans: 0,
        explain:
          'Read <b>:</b> as "to" and <b>,</b> as "and". <code>=SUM(D2:D11)</code> = <b>1005</b>; <code>=SUM(D2,D11)</code> = 120 + 130 = <b>250</b>.',
      },
      {
        sec: "range",
        type: "value",
        prompt: "What does <code>=SUM(D2:D4)</code> show?",
        visual: (e) => ({
          sheets: [
            a({ cols: ["A", "D"], to: 6, hl: s("D2:D4", e ? "hit" : "range") }),
          ],
        }),
        accept: ["345"],
        traps: {
          260: "260 is <code>=SUM(D2,D4)</code>, just the two ends. The colon takes D3 as well.",
        },
        hint: "D2 to D4 is three cells.",
        explain: "D2, D3 and D4: 120 + 85 + 140 = <b>345</b>.",
      },
      {
        sec: "range",
        type: "mcq",
        prompt: "Which range covers the <b>prices</b> of all ten films?",
        visual: (e) => ({ sheets: [a({ hl: e ? s("E2:E11", "hit") : {} })] }),
        opts: ["E2:E11", "E1:E11", "D2:E11", "E2,E11"],
        ans: 0,
        mono: !0,
        explain:
          "Prices are in column <b>E</b>, rows 2 to 11. E1 is the header, D2:E11 takes the tickets too, and E2,E11 is just two cells.",
      },
      {
        sec: "four",
        type: "value",
        prompt: "Type the number Excel shows for <code>=MAX(D2:D11)</code>.",
        visual: (e) => ({
          sheets: [a({ hl: e ? t(s("D2:D11", "scan"), { D7: "ret" }) : h })],
        }),
        accept: ["150"],
        traps: {
          40: "40 is the <b>MIN</b>, the smallest value.",
          1005: "1005 is the <b>SUM</b>, all the tickets added up.",
          100.5: "100.5 is the <b>AVERAGE</b>.",
        },
        hint: "MAX = the biggest number in the range.",
        explain:
          "MAX returns the <b>largest</b> value: The Vault sold <b>150</b>.",
      },
      {
        sec: "four",
        type: "value",
        prompt: "What does <code>=AVERAGE(D2:D11)</code> show?",
        visual: (e) => ({
          sheets: [a({ hl: s("D2:D11", e ? "hit" : "range") })],
        }),
        accept: ["100.5"],
        traps: {
          1005: "1005 is the <b>SUM</b>. AVERAGE then divides by how many numbers there are.",
        },
        hint: "Total of the tickets, divided by the number of films.",
        explain: "The mean: 1005 ÷ 10 = <b>100.5</b>.",
      },
      {
        sec: "four",
        type: "mcq",
        prompt:
          "Pony Park has no rating yet (F6 is empty). What does <code>=AVERAGE(F2:F11)</code> divide by?",
        visual: (e) => ({
          sheets: [
            a({
              hl: e
                ? t(s("F2:F11", "hit", ["F6"]), { F6: "bad" })
                : { F6: "bad" },
            }),
          ],
        }),
        opts: [
          "9, because AVERAGE skips cells that are empty",
          "10, because there are 10 films in the range",
          "11, because it includes the header row as well",
          "0, so it shows #DIV/0! because of the blank cell",
        ],
        ans: 0,
        explain:
          "AVERAGE ignores empty cells: 34 ÷ 9 = <b>3.78</b>. Type 0 into F6 and it counts, dropping the average to 3.4. <b>Blank and zero are not the same.</b>",
      },
      {
        sec: "four",
        type: "build",
        prompt:
          "Build the formula from the English. Tap a chip to drop it in the box. Tap the box to empty it.",
        english: '"Find the <b>lowest</b> number of tickets sold by any film."',
        fn: "MIN",
        answer: ["D2:D11"],
        chips: ["D2:D11", "E2:E11", "D1:D11", "D2,D11"],
        explain:
          "<code>=MIN(D2:D11)</code> shows <b>40</b>, Quiet Hill. E2:E11 is the prices, D1 is the header and D2,D11 is only two cells.",
      },
      {
        sec: "four",
        type: "order",
        prompt:
          "Put the steps AVERAGE takes in the right order. Tap them 1 to 4.",
        visual: () => ({ fx: "=AVERAGE(F2:F11)" }),
        items: [
          "Go to the range F2:F11",
          "Add up the cells that hold numbers",
          "Count how many cells hold numbers",
          "Divide the total by the count",
        ],
        explain:
          "Add up, count, divide: 34 ÷ 9 = <b>3.78</b>. The empty F6 is in neither the total nor the count.",
      },
      {
        sec: "typo",
        type: "typo",
        prompt: "This shows #NAME?. Fix it.",
        broken: "=SUMM(D2:D11)",
        fixed: "=SUM(D2:D11)",
        shown: o,
        hint: "Check the spelling of the function name.",
        explain:
          "<b>SUMM</b> should be <b>SUM</b>. A misspelt function gives <b>#NAME?</b>",
      },
      {
        sec: "typo",
        type: "typo",
        prompt: "Excel shows #NAME? for the takings. Fix it.",
        broken: "=D2xE2",
        fixed: "=D2*E2",
        shown: "=D2*E2",
        hint: "Which key multiplies on a keyboard?",
        explain:
          "Excel multiplies with <b>*</b>. The letter x is not an operator, so Excel looks for a name D2xE2.",
      },
      {
        sec: "typo",
        type: "typo",
        prompt: "The range is broken. Fix it.",
        broken: "=SUM(D2;D11)",
        fixed: "=SUM(D2:D11)",
        shown: o,
        hint: "A range from one cell to another uses a colon, not a semicolon.",
        explain:
          'Ranges use a <b>colon</b>: <code>D2:D11</code> means "D2 to D11".',
      },
      {
        sec: "typo",
        type: "typo",
        prompt: "Excel says there is a problem with this formula. Fix it.",
        broken: "=AVERAGE(D2:D11",
        fixed: "=AVERAGE(D2:D11)",
        shown: "=AVERAGE(D2:D11)",
        hint: "Count the brackets.",
        explain: "Every opening bracket needs a <b>closing bracket</b>.",
      },
      {
        sec: "bug",
        type: "mcq",
        prompt:
          'Someone typed <b>"120 tickets"</b> into D2. What does <code>=SUM(D2:D11)</code> show now?',
        visual: (e) =>
          n(
            e ? 885 : o,
            e
              ? t(s("D3:D11", "hit"), { D2: "bad", D12: "ret" })
              : { D2: "bad", D12: "look" },
          ),
        opts: [
          "885, because SUM skips the text, so the total is quietly wrong",
          "1005, because Excel reads the number out of the text",
          "#VALUE!, because SUM cannot add text",
          "0, because one cell in the range is text",
        ],
        ans: 0,
        explain: `SUM <b>ignores text</b> in a range, so Robot Rescue's 120 goes missing with no warning: 1005 - 120 = <b>885</b>. Keep units out of number cells; put "Tickets" in the header instead.`,
      },
      {
        sec: "bug",
        type: "mcq",
        prompt: "Same mistake, but now <code>=D2*E2</code>. What does it show?",
        visual: (e) =>
          c(
            e ? "#VALUE!" : "=D2*E2",
            e ? { D2: "bad", G2: "bad" } : { D2: "bad" },
          ),
        opts: ["#VALUE!", "720", "0", "#NAME?"],
        ans: 0,
        explain:
          "Doing maths with text gives <b>#VALUE!</b>. A range function such as SUM skips text; an operator such as * cannot.",
      },
      {
        sec: "bug",
        type: "mcq",
        prompt: "A cell shows <b>#####</b>. What is the most likely cause?",
        opts: [
          "The column is too narrow to show the number",
          "The formula has a typo in it",
          "The cell is dividing by zero",
          "The number is stored as text",
        ],
        ans: 0,
        explain:
          "<b>#####</b> is not an error in the formula. The number does not fit: widen the column.",
      },
    ],
    teach: {
      meet: {
        title: "Equals, function, cells",
        blocks: [
          {
            p: "Every formula on your dashboard has the same three parts. This game uses <b>Harbour Street Cinema</b>, a made-up dataset of ten screenings.",
          },
          { visual: { sheets: [a({ hl: h })] } },
          {
            tip: "Click a cell and look at the formula bar: it shows the formula, while the cell shows the answer.",
          },
        ],
      },
      start: {
        title: "Every formula starts with =",
        blocks: [
          {
            table: {
              head: ["Type", "Means", "Example on this sheet"],
              rows: [
                ["+ -", "add, subtract", "<code>=D2+D3</code> = 205"],
                ["* /", "multiply, divide", "<code>=D2*E2</code> = 720"],
                ["( )", "do this part first", "<code>=D2*(E2-1)</code> = 600"],
              ],
            },
          },
          {
            tip: "Excel uses <b>BIDMAS</b>, as in maths: brackets first, then multiply and divide, then add and subtract.",
          },
        ],
      },
      range: {
        title: "Colon means to, comma means and",
        blocks: [
          {
            visual: {
              sheets: [
                a({
                  cols: ["A", "D"],
                  hl: t(s("D2:D11", "hit"), { D2: "look", D11: "look" }),
                }),
              ],
              legend: [
                [i.hit, "D2:D11"],
                [i.look, "D2,D11"],
              ],
            },
          },
          {
            table: {
              rows: [
                [
                  "D2:D11",
                  '<b>"to"</b>: every cell from D2 to D11 (10 cells).',
                ],
                ["D2,D11", '<b>"and"</b>: just D2 and D11 (2 cells).'],
              ],
            },
          },
          {
            tip: "Drag across the cells while typing a formula and Excel writes the range for you.",
          },
        ],
      },
      four: {
        title: "SUM, AVERAGE, MIN, MAX",
        blocks: [
          {
            table: {
              head: ["Function", "Gives", "On D2:D11"],
              rows: [
                ["SUM", "the total", "1005"],
                ["AVERAGE", "the mean (skips blanks)", "100.5"],
                ["MIN", "the smallest", "40"],
                ["MAX", "the largest", "150"],
              ],
            },
          },
          {
            tip: "All four skip empty cells and text in the range. That keeps them working, but it can hide a mistake.",
          },
        ],
      },
      typo: {
        title: "The syntax checklist",
        blocks: [
          { p: "When a formula breaks, check these in order." },
          {
            table: {
              rows: [
                ["=", "Starts with an equals sign."],
                ["SUM", "Spelt right? A misspelt function shows <b>#NAME?</b>"],
                ["*", "Multiply is a star, not an x."],
                ["D2:D11", "A <b>colon</b> between the first and last cell."],
                ["( )", "Every opening bracket has a closing one."],
              ],
            },
          },
        ],
      },
      bug: {
        title: "Blank, zero and text",
        blocks: [
          {
            p: "Numbers that are not really numbers cause the quietest mistakes.",
          },
          {
            table: {
              head: ["You see", "Most likely cause", "Fix"],
              rows: [
                [
                  "A total too low",
                  'Text such as "120 tickets" in a number cell.',
                  "Keep units in the header.",
                ],
                [
                  "#VALUE!",
                  "Maths with text using + - * /.",
                  "Make the cell a number.",
                ],
                [
                  "An average too low",
                  "A 0 typed where the cell should be blank.",
                  "Leave missing data blank.",
                ],
                ["#####", "The column is too narrow.", "Widen the column."],
              ],
            },
          },
        ],
      },
    },
    cheat: {
      title: "Formula basics checklist for Task 2 (open me)",
      rows: [
        ["1", "Every formula starts with =."],
        ["2", "Multiply is *, divide is /. Brackets are worked out first."],
        ["3", 'Colon means "to" (a range). Comma means "and".'],
        ["4", "Start a range below the header row."],
        ["5", "SUM total, AVERAGE mean, MIN smallest, MAX largest."],
        ["6", "Blank and zero are not the same."],
        ["7", 'Keep units such as "tickets" or "£" out of number cells.'],
      ],
    },
    ratings: [
      "Formula Legend",
      "Spreadsheet Pro",
      "Getting There",
      "Keep Practising",
    ],
    footer: o,
    motif: ["Total", "1005"],
  };
export { p as SUM_GAME };
