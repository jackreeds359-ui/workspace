import { r as s, j as y } from "./react-vendor-BK1G6oO1.js";
import {
  M as T,
  b as W,
  u as z,
  P as A,
  c as D,
  a as H,
  L as K,
} from "./proxy-DGk2Wawc.js";
function L(e, o) {
  if (typeof e == "function") return e(o);
  e != null && (e.current = o);
}
function U(...e) {
  return (o) => {
    let t = !1;
    const r = e.map((i) => {
      const n = L(i, o);
      return (!t && typeof n == "function" && (t = !0), n);
    });
    if (t)
      return () => {
        for (let i = 0; i < r.length; i++) {
          const n = r[i];
          typeof n == "function" ? n() : L(e[i], null);
        }
      };
  };
}
function B(...e) {
  return s.useCallback(U(...e), e);
}
class F extends s.Component {
  getSnapshotBeforeUpdate(o) {
    const t = this.props.childRef.current;
    if (t && o.isPresent && !this.props.isPresent) {
      const r = t.offsetParent,
        i = (W(r) && r.offsetWidth) || 0,
        n = this.props.sizeRef.current;
      ((n.height = t.offsetHeight || 0),
        (n.width = t.offsetWidth || 0),
        (n.top = t.offsetTop),
        (n.left = t.offsetLeft),
        (n.right = i - n.width - n.left));
    }
    return null;
  }
  componentDidUpdate() {}
  render() {
    return this.props.children;
  }
}
function G({ children: e, isPresent: o, anchorX: t, root: r }) {
  const i = s.useId(),
    n = s.useRef(null),
    h = s.useRef({ width: 0, height: 0, top: 0, left: 0, right: 0 }),
    { nonce: x } = s.useContext(T),
    E = B(n, e?.ref);
  return (
    s.useInsertionEffect(() => {
      const { width: f, height: g, top: c, left: a, right: d } = h.current;
      if (o || !n.current || !f || !g) return;
      const m = t === "left" ? `left: ${a}` : `right: ${d}`;
      n.current.dataset.motionPopId = i;
      const l = document.createElement("style");
      x && (l.nonce = x);
      const P = r ?? document.head;
      return (
        P.appendChild(l),
        l.sheet &&
          l.sheet.insertRule(`
          [data-motion-pop-id="${i}"] {
            position: absolute !important;
            width: ${f}px !important;
            height: ${g}px !important;
            ${m}px !important;
            top: ${c}px !important;
          }
        `),
        () => {
          P.contains(l) && P.removeChild(l);
        }
      );
    }, [o]),
    y.jsx(F, {
      isPresent: o,
      childRef: n,
      sizeRef: h,
      children: s.cloneElement(e, { ref: E }),
    })
  );
}
const V = ({
  children: e,
  initial: o,
  isPresent: t,
  onExitComplete: r,
  custom: i,
  presenceAffectsLayout: n,
  mode: h,
  anchorX: x,
  root: E,
}) => {
  const f = z(X),
    g = s.useId();
  let c = !0,
    a = s.useMemo(
      () => (
        (c = !1),
        {
          id: g,
          initial: o,
          isPresent: t,
          custom: i,
          onExitComplete: (d) => {
            f.set(d, !0);
            for (const m of f.values()) if (!m) return;
            r && r();
          },
          register: (d) => (f.set(d, !1), () => f.delete(d)),
        }
      ),
      [t, f, r],
    );
  return (
    n && c && (a = { ...a }),
    s.useMemo(() => {
      f.forEach((d, m) => f.set(m, !1));
    }, [t]),
    s.useEffect(() => {
      !t && !f.size && r && r();
    }, [t]),
    h === "popLayout" &&
      (e = y.jsx(G, { isPresent: t, anchorX: x, root: E, children: e })),
    y.jsx(A.Provider, { value: a, children: e })
  );
};
function X() {
  return new Map();
}
const M = (e) => e.key || "";
function k(e) {
  const o = [];
  return (
    s.Children.forEach(e, (t) => {
      s.isValidElement(t) && o.push(t);
    }),
    o
  );
}
const J = ({
  children: e,
  custom: o,
  initial: t = !0,
  onExitComplete: r,
  presenceAffectsLayout: i = !0,
  mode: n = "sync",
  propagate: h = !1,
  anchorX: x = "left",
  root: E,
}) => {
  const [f, g] = D(h),
    c = s.useMemo(() => k(e), [e]),
    a = h && !f ? [] : c.map(M),
    d = s.useRef(!0),
    m = s.useRef(c),
    l = z(() => new Map()),
    [P, I] = s.useState(c),
    [C, v] = s.useState(c);
  H(() => {
    ((d.current = !1), (m.current = c));
    for (let p = 0; p < C.length; p++) {
      const u = M(C[p]);
      a.includes(u) ? l.delete(u) : l.get(u) !== !0 && l.set(u, !1);
    }
  }, [C, a.length, a.join("-")]);
  const w = [];
  if (c !== P) {
    let p = [...c];
    for (let u = 0; u < C.length; u++) {
      const R = C[u],
        j = M(R);
      a.includes(j) || (p.splice(u, 0, R), w.push(R));
    }
    return (n === "wait" && w.length && (p = w), v(k(p)), I(c), null);
  }
  const { forceRender: b } = s.useContext(K);
  return y.jsx(y.Fragment, {
    children: C.map((p) => {
      const u = M(p),
        R = h && !f ? !1 : c === C || a.includes(u),
        j = () => {
          if (l.has(u)) l.set(u, !0);
          else return;
          let $ = !0;
          (l.forEach((S) => {
            S || ($ = !1);
          }),
            $ && (b?.(), v(m.current), h && g?.(), r && r()));
        };
      return y.jsx(
        V,
        {
          isPresent: R,
          initial: !d.current || t ? void 0 : !1,
          custom: o,
          presenceAffectsLayout: i,
          mode: n,
          root: E,
          onExitComplete: R ? void 0 : j,
          anchorX: x,
          children: p,
        },
        u,
      );
    }),
  });
};
export { J as A };
