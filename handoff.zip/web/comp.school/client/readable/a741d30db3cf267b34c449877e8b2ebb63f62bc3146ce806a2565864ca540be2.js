(function () {
  const g = document.createElement("link").relList;
  if (g && g.supports && g.supports("modulepreload")) return;
  for (const C of document.querySelectorAll('link[rel="modulepreload"]')) j(C);
  new MutationObserver((C) => {
    for (const M of C)
      if (M.type === "childList")
        for (const $ of M.addedNodes)
          $.tagName === "LINK" && $.rel === "modulepreload" && j($);
  }).observe(document, { childList: !0, subtree: !0 });
  function f(C) {
    const M = {};
    return (
      C.integrity && (M.integrity = C.integrity),
      C.referrerPolicy && (M.referrerPolicy = C.referrerPolicy),
      C.crossOrigin === "use-credentials"
        ? (M.credentials = "include")
        : C.crossOrigin === "anonymous"
          ? (M.credentials = "omit")
          : (M.credentials = "same-origin"),
      M
    );
  }
  function j(C) {
    if (C.ep) return;
    C.ep = !0;
    const M = f(C);
    fetch(C.href, M);
  }
})();
function rc(d) {
  return d && d.__esModule && Object.prototype.hasOwnProperty.call(d, "default")
    ? d.default
    : d;
}
var Oi = { exports: {} },
  Er = {},
  Di = { exports: {} },
  H = {};
/**
 * @license React
 * react.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var Ua;
function sd() {
  if (Ua) return H;
  Ua = 1;
  var d = Symbol.for("react.element"),
    g = Symbol.for("react.portal"),
    f = Symbol.for("react.fragment"),
    j = Symbol.for("react.strict_mode"),
    C = Symbol.for("react.profiler"),
    M = Symbol.for("react.provider"),
    $ = Symbol.for("react.context"),
    q = Symbol.for("react.forward_ref"),
    O = Symbol.for("react.suspense"),
    ge = Symbol.for("react.memo"),
    U = Symbol.for("react.lazy"),
    re = Symbol.iterator;
  function K(p) {
    return p === null || typeof p != "object"
      ? null
      : ((p = (re && p[re]) || p["@@iterator"]),
        typeof p == "function" ? p : null);
  }
  var Te = {
      isMounted: function () {
        return !1;
      },
      enqueueForceUpdate: function () {},
      enqueueReplaceState: function () {},
      enqueueSetState: function () {},
    },
    Oe = Object.assign,
    J = {};
  function Q(p, k, W) {
    ((this.props = p),
      (this.context = k),
      (this.refs = J),
      (this.updater = W || Te));
  }
  ((Q.prototype.isReactComponent = {}),
    (Q.prototype.setState = function (p, k) {
      if (typeof p != "object" && typeof p != "function" && p != null)
        throw Error(
          "setState(...): takes an object of state variables to update or a function which returns an object of state variables.",
        );
      this.updater.enqueueSetState(this, p, k, "setState");
    }),
    (Q.prototype.forceUpdate = function (p) {
      this.updater.enqueueForceUpdate(this, p, "forceUpdate");
    }));
  function Ce() {}
  Ce.prototype = Q.prototype;
  function Ze(p, k, W) {
    ((this.props = p),
      (this.context = k),
      (this.refs = J),
      (this.updater = W || Te));
  }
  var Fe = (Ze.prototype = new Ce());
  ((Fe.constructor = Ze), Oe(Fe, Q.prototype), (Fe.isPureReactComponent = !0));
  var te = Array.isArray,
    fe = Object.prototype.hasOwnProperty,
    ne = { current: null },
    ue = { key: !0, ref: !0, __self: !0, __source: !0 };
  function je(p, k, W) {
    var B,
      G = {},
      Y = null,
      ie = null;
    if (k != null)
      for (B in (k.ref !== void 0 && (ie = k.ref),
      k.key !== void 0 && (Y = "" + k.key),
      k))
        fe.call(k, B) && !ue.hasOwnProperty(B) && (G[B] = k[B]);
    var b = arguments.length - 2;
    if (b === 1) G.children = W;
    else if (1 < b) {
      for (var pe = Array(b), tt = 0; tt < b; tt++) pe[tt] = arguments[tt + 2];
      G.children = pe;
    }
    if (p && p.defaultProps)
      for (B in ((b = p.defaultProps), b)) G[B] === void 0 && (G[B] = b[B]);
    return {
      $$typeof: d,
      type: p,
      key: Y,
      ref: ie,
      props: G,
      _owner: ne.current,
    };
  }
  function Ke(p, k) {
    return {
      $$typeof: d,
      type: p.type,
      key: k,
      ref: p.ref,
      props: p.props,
      _owner: p._owner,
    };
  }
  function et(p) {
    return typeof p == "object" && p !== null && p.$$typeof === d;
  }
  function it(p) {
    var k = { "=": "=0", ":": "=2" };
    return (
      "$" +
      p.replace(/[=:]/g, function (W) {
        return k[W];
      })
    );
  }
  var Ae = /\/+/g;
  function Ee(p, k) {
    return typeof p == "object" && p !== null && p.key != null
      ? it("" + p.key)
      : k.toString(36);
  }
  function oe(p, k, W, B, G) {
    var Y = typeof p;
    (Y === "undefined" || Y === "boolean") && (p = null);
    var ie = !1;
    if (p === null) ie = !0;
    else
      switch (Y) {
        case "string":
        case "number":
          ie = !0;
          break;
        case "object":
          switch (p.$$typeof) {
            case d:
            case g:
              ie = !0;
          }
      }
    if (ie)
      return (
        (ie = p),
        (G = G(ie)),
        (p = B === "" ? "." + Ee(ie, 0) : B),
        te(G)
          ? ((W = ""),
            p != null && (W = p.replace(Ae, "$&/") + "/"),
            oe(G, k, W, "", function (tt) {
              return tt;
            }))
          : G != null &&
            (et(G) &&
              (G = Ke(
                G,
                W +
                  (!G.key || (ie && ie.key === G.key)
                    ? ""
                    : ("" + G.key).replace(Ae, "$&/") + "/") +
                  p,
              )),
            k.push(G)),
        1
      );
    if (((ie = 0), (B = B === "" ? "." : B + ":"), te(p)))
      for (var b = 0; b < p.length; b++) {
        Y = p[b];
        var pe = B + Ee(Y, b);
        ie += oe(Y, k, W, pe, G);
      }
    else if (((pe = K(p)), typeof pe == "function"))
      for (p = pe.call(p), b = 0; !(Y = p.next()).done;)
        ((Y = Y.value), (pe = B + Ee(Y, b++)), (ie += oe(Y, k, W, pe, G)));
    else if (Y === "object")
      throw (
        (k = String(p)),
        Error(
          "Objects are not valid as a React child (found: " +
            (k === "[object Object]"
              ? "object with keys {" + Object.keys(p).join(", ") + "}"
              : k) +
            "). If you meant to render a collection of children, use an array instead.",
        )
      );
    return ie;
  }
  function de(p, k, W) {
    if (p == null) return p;
    var B = [],
      G = 0;
    return (
      oe(p, B, "", "", function (Y) {
        return k.call(W, Y, G++);
      }),
      B
    );
  }
  function ve(p) {
    if (p._status === -1) {
      var k = p._result;
      ((k = k()),
        k.then(
          function (W) {
            (p._status === 0 || p._status === -1) &&
              ((p._status = 1), (p._result = W));
          },
          function (W) {
            (p._status === 0 || p._status === -1) &&
              ((p._status = 2), (p._result = W));
          },
        ),
        p._status === -1 && ((p._status = 0), (p._result = k)));
    }
    if (p._status === 1) return p._result.default;
    throw p._result;
  }
  var le = { current: null },
    E = { transition: null },
    F = {
      ReactCurrentDispatcher: le,
      ReactCurrentBatchConfig: E,
      ReactCurrentOwner: ne,
    };
  function L() {
    throw Error("act(...) is not supported in production builds of React.");
  }
  return (
    (H.Children = {
      map: de,
      forEach: function (p, k, W) {
        de(
          p,
          function () {
            k.apply(this, arguments);
          },
          W,
        );
      },
      count: function (p) {
        var k = 0;
        return (
          de(p, function () {
            k++;
          }),
          k
        );
      },
      toArray: function (p) {
        return (
          de(p, function (k) {
            return k;
          }) || []
        );
      },
      only: function (p) {
        if (!et(p))
          throw Error(
            "React.Children.only expected to receive a single React element child.",
          );
        return p;
      },
    }),
    (H.Component = Q),
    (H.Fragment = f),
    (H.Profiler = C),
    (H.PureComponent = Ze),
    (H.StrictMode = j),
    (H.Suspense = O),
    (H.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = F),
    (H.act = L),
    (H.cloneElement = function (p, k, W) {
      if (p == null)
        throw Error(
          "React.cloneElement(...): The argument must be a React element, but you passed " +
            p +
            ".",
        );
      var B = Oe({}, p.props),
        G = p.key,
        Y = p.ref,
        ie = p._owner;
      if (k != null) {
        if (
          (k.ref !== void 0 && ((Y = k.ref), (ie = ne.current)),
          k.key !== void 0 && (G = "" + k.key),
          p.type && p.type.defaultProps)
        )
          var b = p.type.defaultProps;
        for (pe in k)
          fe.call(k, pe) &&
            !ue.hasOwnProperty(pe) &&
            (B[pe] = k[pe] === void 0 && b !== void 0 ? b[pe] : k[pe]);
      }
      var pe = arguments.length - 2;
      if (pe === 1) B.children = W;
      else if (1 < pe) {
        b = Array(pe);
        for (var tt = 0; tt < pe; tt++) b[tt] = arguments[tt + 2];
        B.children = b;
      }
      return {
        $$typeof: d,
        type: p.type,
        key: G,
        ref: Y,
        props: B,
        _owner: ie,
      };
    }),
    (H.createContext = function (p) {
      return (
        (p = {
          $$typeof: $,
          _currentValue: p,
          _currentValue2: p,
          _threadCount: 0,
          Provider: null,
          Consumer: null,
          _defaultValue: null,
          _globalName: null,
        }),
        (p.Provider = { $$typeof: M, _context: p }),
        (p.Consumer = p)
      );
    }),
    (H.createElement = je),
    (H.createFactory = function (p) {
      var k = je.bind(null, p);
      return ((k.type = p), k);
    }),
    (H.createRef = function () {
      return { current: null };
    }),
    (H.forwardRef = function (p) {
      return { $$typeof: q, render: p };
    }),
    (H.isValidElement = et),
    (H.lazy = function (p) {
      return { $$typeof: U, _payload: { _status: -1, _result: p }, _init: ve };
    }),
    (H.memo = function (p, k) {
      return { $$typeof: ge, type: p, compare: k === void 0 ? null : k };
    }),
    (H.startTransition = function (p) {
      var k = E.transition;
      E.transition = {};
      try {
        p();
      } finally {
        E.transition = k;
      }
    }),
    (H.unstable_act = L),
    (H.useCallback = function (p, k) {
      return le.current.useCallback(p, k);
    }),
    (H.useContext = function (p) {
      return le.current.useContext(p);
    }),
    (H.useDebugValue = function () {}),
    (H.useDeferredValue = function (p) {
      return le.current.useDeferredValue(p);
    }),
    (H.useEffect = function (p, k) {
      return le.current.useEffect(p, k);
    }),
    (H.useId = function () {
      return le.current.useId();
    }),
    (H.useImperativeHandle = function (p, k, W) {
      return le.current.useImperativeHandle(p, k, W);
    }),
    (H.useInsertionEffect = function (p, k) {
      return le.current.useInsertionEffect(p, k);
    }),
    (H.useLayoutEffect = function (p, k) {
      return le.current.useLayoutEffect(p, k);
    }),
    (H.useMemo = function (p, k) {
      return le.current.useMemo(p, k);
    }),
    (H.useReducer = function (p, k, W) {
      return le.current.useReducer(p, k, W);
    }),
    (H.useRef = function (p) {
      return le.current.useRef(p);
    }),
    (H.useState = function (p) {
      return le.current.useState(p);
    }),
    (H.useSyncExternalStore = function (p, k, W) {
      return le.current.useSyncExternalStore(p, k, W);
    }),
    (H.useTransition = function () {
      return le.current.useTransition();
    }),
    (H.version = "18.3.1"),
    H
  );
}
var Wa;
function Hi() {
  return (Wa || ((Wa = 1), (Di.exports = sd())), Di.exports);
}
/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var Ha;
function ud() {
  if (Ha) return Er;
  Ha = 1;
  var d = Hi(),
    g = Symbol.for("react.element"),
    f = Symbol.for("react.fragment"),
    j = Object.prototype.hasOwnProperty,
    C = d.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,
    M = { key: !0, ref: !0, __self: !0, __source: !0 };
  function $(q, O, ge) {
    var U,
      re = {},
      K = null,
      Te = null;
    (ge !== void 0 && (K = "" + ge),
      O.key !== void 0 && (K = "" + O.key),
      O.ref !== void 0 && (Te = O.ref));
    for (U in O) j.call(O, U) && !M.hasOwnProperty(U) && (re[U] = O[U]);
    if (q && q.defaultProps)
      for (U in ((O = q.defaultProps), O)) re[U] === void 0 && (re[U] = O[U]);
    return {
      $$typeof: g,
      type: q,
      key: K,
      ref: Te,
      props: re,
      _owner: C.current,
    };
  }
  return ((Er.Fragment = f), (Er.jsx = $), (Er.jsxs = $), Er);
}
var $a;
function ad() {
  return ($a || (($a = 1), (Oi.exports = ud())), Oi.exports);
}
var s = ad(),
  Be = Hi();
const cd = rc(Be);
var Fl = {},
  Ii = { exports: {} },
  be = {},
  Fi = { exports: {} },
  Ai = {};
/**
 * @license React
 * scheduler.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var Ba;
function fd() {
  return (
    Ba ||
      ((Ba = 1),
      (function (d) {
        function g(E, F) {
          var L = E.length;
          E.push(F);
          e: for (; 0 < L;) {
            var p = (L - 1) >>> 1,
              k = E[p];
            if (0 < C(k, F)) ((E[p] = F), (E[L] = k), (L = p));
            else break e;
          }
        }
        function f(E) {
          return E.length === 0 ? null : E[0];
        }
        function j(E) {
          if (E.length === 0) return null;
          var F = E[0],
            L = E.pop();
          if (L !== F) {
            E[0] = L;
            e: for (var p = 0, k = E.length, W = k >>> 1; p < W;) {
              var B = 2 * (p + 1) - 1,
                G = E[B],
                Y = B + 1,
                ie = E[Y];
              if (0 > C(G, L))
                Y < k && 0 > C(ie, G)
                  ? ((E[p] = ie), (E[Y] = L), (p = Y))
                  : ((E[p] = G), (E[B] = L), (p = B));
              else if (Y < k && 0 > C(ie, L))
                ((E[p] = ie), (E[Y] = L), (p = Y));
              else break e;
            }
          }
          return F;
        }
        function C(E, F) {
          var L = E.sortIndex - F.sortIndex;
          return L !== 0 ? L : E.id - F.id;
        }
        if (
          typeof performance == "object" &&
          typeof performance.now == "function"
        ) {
          var M = performance;
          d.unstable_now = function () {
            return M.now();
          };
        } else {
          var $ = Date,
            q = $.now();
          d.unstable_now = function () {
            return $.now() - q;
          };
        }
        var O = [],
          ge = [],
          U = 1,
          re = null,
          K = 3,
          Te = !1,
          Oe = !1,
          J = !1,
          Q = typeof setTimeout == "function" ? setTimeout : null,
          Ce = typeof clearTimeout == "function" ? clearTimeout : null,
          Ze = typeof setImmediate < "u" ? setImmediate : null;
        typeof navigator < "u" &&
          navigator.scheduling !== void 0 &&
          navigator.scheduling.isInputPending !== void 0 &&
          navigator.scheduling.isInputPending.bind(navigator.scheduling);
        function Fe(E) {
          for (var F = f(ge); F !== null;) {
            if (F.callback === null) j(ge);
            else if (F.startTime <= E)
              (j(ge), (F.sortIndex = F.expirationTime), g(O, F));
            else break;
            F = f(ge);
          }
        }
        function te(E) {
          if (((J = !1), Fe(E), !Oe))
            if (f(O) !== null) ((Oe = !0), ve(fe));
            else {
              var F = f(ge);
              F !== null && le(te, F.startTime - E);
            }
        }
        function fe(E, F) {
          ((Oe = !1), J && ((J = !1), Ce(je), (je = -1)), (Te = !0));
          var L = K;
          try {
            for (
              Fe(F), re = f(O);
              re !== null && (!(re.expirationTime > F) || (E && !it()));
            ) {
              var p = re.callback;
              if (typeof p == "function") {
                ((re.callback = null), (K = re.priorityLevel));
                var k = p(re.expirationTime <= F);
                ((F = d.unstable_now()),
                  typeof k == "function"
                    ? (re.callback = k)
                    : re === f(O) && j(O),
                  Fe(F));
              } else j(O);
              re = f(O);
            }
            if (re !== null) var W = !0;
            else {
              var B = f(ge);
              (B !== null && le(te, B.startTime - F), (W = !1));
            }
            return W;
          } finally {
            ((re = null), (K = L), (Te = !1));
          }
        }
        var ne = !1,
          ue = null,
          je = -1,
          Ke = 5,
          et = -1;
        function it() {
          return !(d.unstable_now() - et < Ke);
        }
        function Ae() {
          if (ue !== null) {
            var E = d.unstable_now();
            et = E;
            var F = !0;
            try {
              F = ue(!0, E);
            } finally {
              F ? Ee() : ((ne = !1), (ue = null));
            }
          } else ne = !1;
        }
        var Ee;
        if (typeof Ze == "function")
          Ee = function () {
            Ze(Ae);
          };
        else if (typeof MessageChannel < "u") {
          var oe = new MessageChannel(),
            de = oe.port2;
          ((oe.port1.onmessage = Ae),
            (Ee = function () {
              de.postMessage(null);
            }));
        } else
          Ee = function () {
            Q(Ae, 0);
          };
        function ve(E) {
          ((ue = E), ne || ((ne = !0), Ee()));
        }
        function le(E, F) {
          je = Q(function () {
            E(d.unstable_now());
          }, F);
        }
        ((d.unstable_IdlePriority = 5),
          (d.unstable_ImmediatePriority = 1),
          (d.unstable_LowPriority = 4),
          (d.unstable_NormalPriority = 3),
          (d.unstable_Profiling = null),
          (d.unstable_UserBlockingPriority = 2),
          (d.unstable_cancelCallback = function (E) {
            E.callback = null;
          }),
          (d.unstable_continueExecution = function () {
            Oe || Te || ((Oe = !0), ve(fe));
          }),
          (d.unstable_forceFrameRate = function (E) {
            0 > E || 125 < E
              ? console.error(
                  "forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported",
                )
              : (Ke = 0 < E ? Math.floor(1e3 / E) : 5);
          }),
          (d.unstable_getCurrentPriorityLevel = function () {
            return K;
          }),
          (d.unstable_getFirstCallbackNode = function () {
            return f(O);
          }),
          (d.unstable_next = function (E) {
            switch (K) {
              case 1:
              case 2:
              case 3:
                var F = 3;
                break;
              default:
                F = K;
            }
            var L = K;
            K = F;
            try {
              return E();
            } finally {
              K = L;
            }
          }),
          (d.unstable_pauseExecution = function () {}),
          (d.unstable_requestPaint = function () {}),
          (d.unstable_runWithPriority = function (E, F) {
            switch (E) {
              case 1:
              case 2:
              case 3:
              case 4:
              case 5:
                break;
              default:
                E = 3;
            }
            var L = K;
            K = E;
            try {
              return F();
            } finally {
              K = L;
            }
          }),
          (d.unstable_scheduleCallback = function (E, F, L) {
            var p = d.unstable_now();
            switch (
              (typeof L == "object" && L !== null
                ? ((L = L.delay),
                  (L = typeof L == "number" && 0 < L ? p + L : p))
                : (L = p),
              E)
            ) {
              case 1:
                var k = -1;
                break;
              case 2:
                k = 250;
                break;
              case 5:
                k = 1073741823;
                break;
              case 4:
                k = 1e4;
                break;
              default:
                k = 5e3;
            }
            return (
              (k = L + k),
              (E = {
                id: U++,
                callback: F,
                priorityLevel: E,
                startTime: L,
                expirationTime: k,
                sortIndex: -1,
              }),
              L > p
                ? ((E.sortIndex = L),
                  g(ge, E),
                  f(O) === null &&
                    E === f(ge) &&
                    (J ? (Ce(je), (je = -1)) : (J = !0), le(te, L - p)))
                : ((E.sortIndex = k), g(O, E), Oe || Te || ((Oe = !0), ve(fe))),
              E
            );
          }),
          (d.unstable_shouldYield = it),
          (d.unstable_wrapCallback = function (E) {
            var F = K;
            return function () {
              var L = K;
              K = F;
              try {
                return E.apply(this, arguments);
              } finally {
                K = L;
              }
            };
          }));
      })(Ai)),
    Ai
  );
}
var Va;
function dd() {
  return (Va || ((Va = 1), (Fi.exports = fd())), Fi.exports);
}
/**
 * @license React
 * react-dom.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var Qa;
function pd() {
  if (Qa) return be;
  Qa = 1;
  var d = Hi(),
    g = dd();
  function f(e) {
    for (
      var t = "https://reactjs.org/docs/error-decoder.html?invariant=" + e,
        n = 1;
      n < arguments.length;
      n++
    )
      t += "&args[]=" + encodeURIComponent(arguments[n]);
    return (
      "Minified React error #" +
      e +
      "; visit " +
      t +
      " for the full message or use the non-minified dev environment for full errors and additional helpful warnings."
    );
  }
  var j = new Set(),
    C = {};
  function M(e, t) {
    ($(e, t), $(e + "Capture", t));
  }
  function $(e, t) {
    for (C[e] = t, e = 0; e < t.length; e++) j.add(t[e]);
  }
  var q = !(
      typeof window > "u" ||
      typeof window.document > "u" ||
      typeof window.document.createElement > "u"
    ),
    O = Object.prototype.hasOwnProperty,
    ge =
      /^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/,
    U = {},
    re = {};
  function K(e) {
    return O.call(re, e)
      ? !0
      : O.call(U, e)
        ? !1
        : ge.test(e)
          ? (re[e] = !0)
          : ((U[e] = !0), !1);
  }
  function Te(e, t, n, r) {
    if (n !== null && n.type === 0) return !1;
    switch (typeof t) {
      case "function":
      case "symbol":
        return !0;
      case "boolean":
        return r
          ? !1
          : n !== null
            ? !n.acceptsBooleans
            : ((e = e.toLowerCase().slice(0, 5)),
              e !== "data-" && e !== "aria-");
      default:
        return !1;
    }
  }
  function Oe(e, t, n, r) {
    if (t === null || typeof t > "u" || Te(e, t, n, r)) return !0;
    if (r) return !1;
    if (n !== null)
      switch (n.type) {
        case 3:
          return !t;
        case 4:
          return t === !1;
        case 5:
          return isNaN(t);
        case 6:
          return isNaN(t) || 1 > t;
      }
    return !1;
  }
  function J(e, t, n, r, l, o, i) {
    ((this.acceptsBooleans = t === 2 || t === 3 || t === 4),
      (this.attributeName = r),
      (this.attributeNamespace = l),
      (this.mustUseProperty = n),
      (this.propertyName = e),
      (this.type = t),
      (this.sanitizeURL = o),
      (this.removeEmptyString = i));
  }
  var Q = {};
  ("children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style"
    .split(" ")
    .forEach(function (e) {
      Q[e] = new J(e, 0, !1, e, null, !1, !1);
    }),
    [
      ["acceptCharset", "accept-charset"],
      ["className", "class"],
      ["htmlFor", "for"],
      ["httpEquiv", "http-equiv"],
    ].forEach(function (e) {
      var t = e[0];
      Q[t] = new J(t, 1, !1, e[1], null, !1, !1);
    }),
    ["contentEditable", "draggable", "spellCheck", "value"].forEach(
      function (e) {
        Q[e] = new J(e, 2, !1, e.toLowerCase(), null, !1, !1);
      },
    ),
    [
      "autoReverse",
      "externalResourcesRequired",
      "focusable",
      "preserveAlpha",
    ].forEach(function (e) {
      Q[e] = new J(e, 2, !1, e, null, !1, !1);
    }),
    "allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope"
      .split(" ")
      .forEach(function (e) {
        Q[e] = new J(e, 3, !1, e.toLowerCase(), null, !1, !1);
      }),
    ["checked", "multiple", "muted", "selected"].forEach(function (e) {
      Q[e] = new J(e, 3, !0, e, null, !1, !1);
    }),
    ["capture", "download"].forEach(function (e) {
      Q[e] = new J(e, 4, !1, e, null, !1, !1);
    }),
    ["cols", "rows", "size", "span"].forEach(function (e) {
      Q[e] = new J(e, 6, !1, e, null, !1, !1);
    }),
    ["rowSpan", "start"].forEach(function (e) {
      Q[e] = new J(e, 5, !1, e.toLowerCase(), null, !1, !1);
    }));
  var Ce = /[\-:]([a-z])/g;
  function Ze(e) {
    return e[1].toUpperCase();
  }
  ("accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height"
    .split(" ")
    .forEach(function (e) {
      var t = e.replace(Ce, Ze);
      Q[t] = new J(t, 1, !1, e, null, !1, !1);
    }),
    "xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type"
      .split(" ")
      .forEach(function (e) {
        var t = e.replace(Ce, Ze);
        Q[t] = new J(t, 1, !1, e, "http://www.w3.org/1999/xlink", !1, !1);
      }),
    ["xml:base", "xml:lang", "xml:space"].forEach(function (e) {
      var t = e.replace(Ce, Ze);
      Q[t] = new J(t, 1, !1, e, "http://www.w3.org/XML/1998/namespace", !1, !1);
    }),
    ["tabIndex", "crossOrigin"].forEach(function (e) {
      Q[e] = new J(e, 1, !1, e.toLowerCase(), null, !1, !1);
    }),
    (Q.xlinkHref = new J(
      "xlinkHref",
      1,
      !1,
      "xlink:href",
      "http://www.w3.org/1999/xlink",
      !0,
      !1,
    )),
    ["src", "href", "action", "formAction"].forEach(function (e) {
      Q[e] = new J(e, 1, !1, e.toLowerCase(), null, !0, !0);
    }));
  function Fe(e, t, n, r) {
    var l = Q.hasOwnProperty(t) ? Q[t] : null;
    (l !== null
      ? l.type !== 0
      : r ||
        !(2 < t.length) ||
        (t[0] !== "o" && t[0] !== "O") ||
        (t[1] !== "n" && t[1] !== "N")) &&
      (Oe(t, n, l, r) && (n = null),
      r || l === null
        ? K(t) &&
          (n === null ? e.removeAttribute(t) : e.setAttribute(t, "" + n))
        : l.mustUseProperty
          ? (e[l.propertyName] = n === null ? (l.type === 3 ? !1 : "") : n)
          : ((t = l.attributeName),
            (r = l.attributeNamespace),
            n === null
              ? e.removeAttribute(t)
              : ((l = l.type),
                (n = l === 3 || (l === 4 && n === !0) ? "" : "" + n),
                r ? e.setAttributeNS(r, t, n) : e.setAttribute(t, n))));
  }
  var te = d.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED,
    fe = Symbol.for("react.element"),
    ne = Symbol.for("react.portal"),
    ue = Symbol.for("react.fragment"),
    je = Symbol.for("react.strict_mode"),
    Ke = Symbol.for("react.profiler"),
    et = Symbol.for("react.provider"),
    it = Symbol.for("react.context"),
    Ae = Symbol.for("react.forward_ref"),
    Ee = Symbol.for("react.suspense"),
    oe = Symbol.for("react.suspense_list"),
    de = Symbol.for("react.memo"),
    ve = Symbol.for("react.lazy"),
    le = Symbol.for("react.offscreen"),
    E = Symbol.iterator;
  function F(e) {
    return e === null || typeof e != "object"
      ? null
      : ((e = (E && e[E]) || e["@@iterator"]),
        typeof e == "function" ? e : null);
  }
  var L = Object.assign,
    p;
  function k(e) {
    if (p === void 0)
      try {
        throw Error();
      } catch (n) {
        var t = n.stack.trim().match(/\n( *(at )?)/);
        p = (t && t[1]) || "";
      }
    return (
      `
` +
      p +
      e
    );
  }
  var W = !1;
  function B(e, t) {
    if (!e || W) return "";
    W = !0;
    var n = Error.prepareStackTrace;
    Error.prepareStackTrace = void 0;
    try {
      if (t)
        if (
          ((t = function () {
            throw Error();
          }),
          Object.defineProperty(t.prototype, "props", {
            set: function () {
              throw Error();
            },
          }),
          typeof Reflect == "object" && Reflect.construct)
        ) {
          try {
            Reflect.construct(t, []);
          } catch (y) {
            var r = y;
          }
          Reflect.construct(e, [], t);
        } else {
          try {
            t.call();
          } catch (y) {
            r = y;
          }
          e.call(t.prototype);
        }
      else {
        try {
          throw Error();
        } catch (y) {
          r = y;
        }
        e();
      }
    } catch (y) {
      if (y && r && typeof y.stack == "string") {
        for (
          var l = y.stack.split(`
`),
            o = r.stack.split(`
`),
            i = l.length - 1,
            u = o.length - 1;
          1 <= i && 0 <= u && l[i] !== o[u];
        )
          u--;
        for (; 1 <= i && 0 <= u; i--, u--)
          if (l[i] !== o[u]) {
            if (i !== 1 || u !== 1)
              do
                if ((i--, u--, 0 > u || l[i] !== o[u])) {
                  var a =
                    `
` + l[i].replace(" at new ", " at ");
                  return (
                    e.displayName &&
                      a.includes("<anonymous>") &&
                      (a = a.replace("<anonymous>", e.displayName)),
                    a
                  );
                }
              while (1 <= i && 0 <= u);
            break;
          }
      }
    } finally {
      ((W = !1), (Error.prepareStackTrace = n));
    }
    return (e = e ? e.displayName || e.name : "") ? k(e) : "";
  }
  function G(e) {
    switch (e.tag) {
      case 5:
        return k(e.type);
      case 16:
        return k("Lazy");
      case 13:
        return k("Suspense");
      case 19:
        return k("SuspenseList");
      case 0:
      case 2:
      case 15:
        return ((e = B(e.type, !1)), e);
      case 11:
        return ((e = B(e.type.render, !1)), e);
      case 1:
        return ((e = B(e.type, !0)), e);
      default:
        return "";
    }
  }
  function Y(e) {
    if (e == null) return null;
    if (typeof e == "function") return e.displayName || e.name || null;
    if (typeof e == "string") return e;
    switch (e) {
      case ue:
        return "Fragment";
      case ne:
        return "Portal";
      case Ke:
        return "Profiler";
      case je:
        return "StrictMode";
      case Ee:
        return "Suspense";
      case oe:
        return "SuspenseList";
    }
    if (typeof e == "object")
      switch (e.$$typeof) {
        case it:
          return (e.displayName || "Context") + ".Consumer";
        case et:
          return (e._context.displayName || "Context") + ".Provider";
        case Ae:
          var t = e.render;
          return (
            (e = e.displayName),
            e ||
              ((e = t.displayName || t.name || ""),
              (e = e !== "" ? "ForwardRef(" + e + ")" : "ForwardRef")),
            e
          );
        case de:
          return (
            (t = e.displayName || null),
            t !== null ? t : Y(e.type) || "Memo"
          );
        case ve:
          ((t = e._payload), (e = e._init));
          try {
            return Y(e(t));
          } catch {}
      }
    return null;
  }
  function ie(e) {
    var t = e.type;
    switch (e.tag) {
      case 24:
        return "Cache";
      case 9:
        return (t.displayName || "Context") + ".Consumer";
      case 10:
        return (t._context.displayName || "Context") + ".Provider";
      case 18:
        return "DehydratedFragment";
      case 11:
        return (
          (e = t.render),
          (e = e.displayName || e.name || ""),
          t.displayName || (e !== "" ? "ForwardRef(" + e + ")" : "ForwardRef")
        );
      case 7:
        return "Fragment";
      case 5:
        return t;
      case 4:
        return "Portal";
      case 3:
        return "Root";
      case 6:
        return "Text";
      case 16:
        return Y(t);
      case 8:
        return t === je ? "StrictMode" : "Mode";
      case 22:
        return "Offscreen";
      case 12:
        return "Profiler";
      case 21:
        return "Scope";
      case 13:
        return "Suspense";
      case 19:
        return "SuspenseList";
      case 25:
        return "TracingMarker";
      case 1:
      case 0:
      case 17:
      case 2:
      case 14:
      case 15:
        if (typeof t == "function") return t.displayName || t.name || null;
        if (typeof t == "string") return t;
    }
    return null;
  }
  function b(e) {
    switch (typeof e) {
      case "boolean":
      case "number":
      case "string":
      case "undefined":
        return e;
      case "object":
        return e;
      default:
        return "";
    }
  }
  function pe(e) {
    var t = e.type;
    return (
      (e = e.nodeName) &&
      e.toLowerCase() === "input" &&
      (t === "checkbox" || t === "radio")
    );
  }
  function tt(e) {
    var t = pe(e) ? "checked" : "value",
      n = Object.getOwnPropertyDescriptor(e.constructor.prototype, t),
      r = "" + e[t];
    if (
      !e.hasOwnProperty(t) &&
      typeof n < "u" &&
      typeof n.get == "function" &&
      typeof n.set == "function"
    ) {
      var l = n.get,
        o = n.set;
      return (
        Object.defineProperty(e, t, {
          configurable: !0,
          get: function () {
            return l.call(this);
          },
          set: function (i) {
            ((r = "" + i), o.call(this, i));
          },
        }),
        Object.defineProperty(e, t, { enumerable: n.enumerable }),
        {
          getValue: function () {
            return r;
          },
          setValue: function (i) {
            r = "" + i;
          },
          stopTracking: function () {
            ((e._valueTracker = null), delete e[t]);
          },
        }
      );
    }
  }
  function _r(e) {
    e._valueTracker || (e._valueTracker = tt(e));
  }
  function Qi(e) {
    if (!e) return !1;
    var t = e._valueTracker;
    if (!t) return !0;
    var n = t.getValue(),
      r = "";
    return (
      e && (r = pe(e) ? (e.checked ? "true" : "false") : e.value),
      (e = r),
      e !== n ? (t.setValue(e), !0) : !1
    );
  }
  function Mr(e) {
    if (
      ((e = e || (typeof document < "u" ? document : void 0)), typeof e > "u")
    )
      return null;
    try {
      return e.activeElement || e.body;
    } catch {
      return e.body;
    }
  }
  function Wl(e, t) {
    var n = t.checked;
    return L({}, t, {
      defaultChecked: void 0,
      defaultValue: void 0,
      value: void 0,
      checked: n ?? e._wrapperState.initialChecked,
    });
  }
  function Zi(e, t) {
    var n = t.defaultValue == null ? "" : t.defaultValue,
      r = t.checked != null ? t.checked : t.defaultChecked;
    ((n = b(t.value != null ? t.value : n)),
      (e._wrapperState = {
        initialChecked: r,
        initialValue: n,
        controlled:
          t.type === "checkbox" || t.type === "radio"
            ? t.checked != null
            : t.value != null,
      }));
  }
  function Ki(e, t) {
    ((t = t.checked), t != null && Fe(e, "checked", t, !1));
  }
  function Hl(e, t) {
    Ki(e, t);
    var n = b(t.value),
      r = t.type;
    if (n != null)
      r === "number"
        ? ((n === 0 && e.value === "") || e.value != n) && (e.value = "" + n)
        : e.value !== "" + n && (e.value = "" + n);
    else if (r === "submit" || r === "reset") {
      e.removeAttribute("value");
      return;
    }
    (t.hasOwnProperty("value")
      ? $l(e, t.type, n)
      : t.hasOwnProperty("defaultValue") && $l(e, t.type, b(t.defaultValue)),
      t.checked == null &&
        t.defaultChecked != null &&
        (e.defaultChecked = !!t.defaultChecked));
  }
  function Gi(e, t, n) {
    if (t.hasOwnProperty("value") || t.hasOwnProperty("defaultValue")) {
      var r = t.type;
      if (!(
        (r !== "submit" && r !== "reset") ||
        (t.value !== void 0 && t.value !== null)
      ))
        return;
      ((t = "" + e._wrapperState.initialValue),
        n || t === e.value || (e.value = t),
        (e.defaultValue = t));
    }
    ((n = e.name),
      n !== "" && (e.name = ""),
      (e.defaultChecked = !!e._wrapperState.initialChecked),
      n !== "" && (e.name = n));
  }
  function $l(e, t, n) {
    (t !== "number" || Mr(e.ownerDocument) !== e) &&
      (n == null
        ? (e.defaultValue = "" + e._wrapperState.initialValue)
        : e.defaultValue !== "" + n && (e.defaultValue = "" + n));
  }
  var Hn = Array.isArray;
  function yn(e, t, n, r) {
    if (((e = e.options), t)) {
      t = {};
      for (var l = 0; l < n.length; l++) t["$" + n[l]] = !0;
      for (n = 0; n < e.length; n++)
        ((l = t.hasOwnProperty("$" + e[n].value)),
          e[n].selected !== l && (e[n].selected = l),
          l && r && (e[n].defaultSelected = !0));
    } else {
      for (n = "" + b(n), t = null, l = 0; l < e.length; l++) {
        if (e[l].value === n) {
          ((e[l].selected = !0), r && (e[l].defaultSelected = !0));
          return;
        }
        t !== null || e[l].disabled || (t = e[l]);
      }
      t !== null && (t.selected = !0);
    }
  }
  function Bl(e, t) {
    if (t.dangerouslySetInnerHTML != null) throw Error(f(91));
    return L({}, t, {
      value: void 0,
      defaultValue: void 0,
      children: "" + e._wrapperState.initialValue,
    });
  }
  function Yi(e, t) {
    var n = t.value;
    if (n == null) {
      if (((n = t.children), (t = t.defaultValue), n != null)) {
        if (t != null) throw Error(f(92));
        if (Hn(n)) {
          if (1 < n.length) throw Error(f(93));
          n = n[0];
        }
        t = n;
      }
      (t == null && (t = ""), (n = t));
    }
    e._wrapperState = { initialValue: b(n) };
  }
  function Xi(e, t) {
    var n = b(t.value),
      r = b(t.defaultValue);
    (n != null &&
      ((n = "" + n),
      n !== e.value && (e.value = n),
      t.defaultValue == null && e.defaultValue !== n && (e.defaultValue = n)),
      r != null && (e.defaultValue = "" + r));
  }
  function qi(e) {
    var t = e.textContent;
    t === e._wrapperState.initialValue &&
      t !== "" &&
      t !== null &&
      (e.value = t);
  }
  function Ji(e) {
    switch (e) {
      case "svg":
        return "http://www.w3.org/2000/svg";
      case "math":
        return "http://www.w3.org/1998/Math/MathML";
      default:
        return "http://www.w3.org/1999/xhtml";
    }
  }
  function Vl(e, t) {
    return e == null || e === "http://www.w3.org/1999/xhtml"
      ? Ji(t)
      : e === "http://www.w3.org/2000/svg" && t === "foreignObject"
        ? "http://www.w3.org/1999/xhtml"
        : e;
  }
  var Pr,
    bi = (function (e) {
      return typeof MSApp < "u" && MSApp.execUnsafeLocalFunction
        ? function (t, n, r, l) {
            MSApp.execUnsafeLocalFunction(function () {
              return e(t, n, r, l);
            });
          }
        : e;
    })(function (e, t) {
      if (e.namespaceURI !== "http://www.w3.org/2000/svg" || "innerHTML" in e)
        e.innerHTML = t;
      else {
        for (
          Pr = Pr || document.createElement("div"),
            Pr.innerHTML = "<svg>" + t.valueOf().toString() + "</svg>",
            t = Pr.firstChild;
          e.firstChild;
        )
          e.removeChild(e.firstChild);
        for (; t.firstChild;) e.appendChild(t.firstChild);
      }
    });
  function $n(e, t) {
    if (t) {
      var n = e.firstChild;
      if (n && n === e.lastChild && n.nodeType === 3) {
        n.nodeValue = t;
        return;
      }
    }
    e.textContent = t;
  }
  var Bn = {
      animationIterationCount: !0,
      aspectRatio: !0,
      borderImageOutset: !0,
      borderImageSlice: !0,
      borderImageWidth: !0,
      boxFlex: !0,
      boxFlexGroup: !0,
      boxOrdinalGroup: !0,
      columnCount: !0,
      columns: !0,
      flex: !0,
      flexGrow: !0,
      flexPositive: !0,
      flexShrink: !0,
      flexNegative: !0,
      flexOrder: !0,
      gridArea: !0,
      gridRow: !0,
      gridRowEnd: !0,
      gridRowSpan: !0,
      gridRowStart: !0,
      gridColumn: !0,
      gridColumnEnd: !0,
      gridColumnSpan: !0,
      gridColumnStart: !0,
      fontWeight: !0,
      lineClamp: !0,
      lineHeight: !0,
      opacity: !0,
      order: !0,
      orphans: !0,
      tabSize: !0,
      widows: !0,
      zIndex: !0,
      zoom: !0,
      fillOpacity: !0,
      floodOpacity: !0,
      stopOpacity: !0,
      strokeDasharray: !0,
      strokeDashoffset: !0,
      strokeMiterlimit: !0,
      strokeOpacity: !0,
      strokeWidth: !0,
    },
    cc = ["Webkit", "ms", "Moz", "O"];
  Object.keys(Bn).forEach(function (e) {
    cc.forEach(function (t) {
      ((t = t + e.charAt(0).toUpperCase() + e.substring(1)), (Bn[t] = Bn[e]));
    });
  });
  function es(e, t, n) {
    return t == null || typeof t == "boolean" || t === ""
      ? ""
      : n || typeof t != "number" || t === 0 || (Bn.hasOwnProperty(e) && Bn[e])
        ? ("" + t).trim()
        : t + "px";
  }
  function ts(e, t) {
    e = e.style;
    for (var n in t)
      if (t.hasOwnProperty(n)) {
        var r = n.indexOf("--") === 0,
          l = es(n, t[n], r);
        (n === "float" && (n = "cssFloat"),
          r ? e.setProperty(n, l) : (e[n] = l));
      }
  }
  var fc = L(
    { menuitem: !0 },
    {
      area: !0,
      base: !0,
      br: !0,
      col: !0,
      embed: !0,
      hr: !0,
      img: !0,
      input: !0,
      keygen: !0,
      link: !0,
      meta: !0,
      param: !0,
      source: !0,
      track: !0,
      wbr: !0,
    },
  );
  function Ql(e, t) {
    if (t) {
      if (fc[e] && (t.children != null || t.dangerouslySetInnerHTML != null))
        throw Error(f(137, e));
      if (t.dangerouslySetInnerHTML != null) {
        if (t.children != null) throw Error(f(60));
        if (
          typeof t.dangerouslySetInnerHTML != "object" ||
          !("__html" in t.dangerouslySetInnerHTML)
        )
          throw Error(f(61));
      }
      if (t.style != null && typeof t.style != "object") throw Error(f(62));
    }
  }
  function Zl(e, t) {
    if (e.indexOf("-") === -1) return typeof t.is == "string";
    switch (e) {
      case "annotation-xml":
      case "color-profile":
      case "font-face":
      case "font-face-src":
      case "font-face-uri":
      case "font-face-format":
      case "font-face-name":
      case "missing-glyph":
        return !1;
      default:
        return !0;
    }
  }
  var Kl = null;
  function Gl(e) {
    return (
      (e = e.target || e.srcElement || window),
      e.correspondingUseElement && (e = e.correspondingUseElement),
      e.nodeType === 3 ? e.parentNode : e
    );
  }
  var Yl = null,
    gn = null,
    vn = null;
  function ns(e) {
    if ((e = fr(e))) {
      if (typeof Yl != "function") throw Error(f(280));
      var t = e.stateNode;
      t && ((t = Jr(t)), Yl(e.stateNode, e.type, t));
    }
  }
  function rs(e) {
    gn ? (vn ? vn.push(e) : (vn = [e])) : (gn = e);
  }
  function ls() {
    if (gn) {
      var e = gn,
        t = vn;
      if (((vn = gn = null), ns(e), t)) for (e = 0; e < t.length; e++) ns(t[e]);
    }
  }
  function os(e, t) {
    return e(t);
  }
  function is() {}
  var Xl = !1;
  function ss(e, t, n) {
    if (Xl) return e(t, n);
    Xl = !0;
    try {
      return os(e, t, n);
    } finally {
      ((Xl = !1), (gn !== null || vn !== null) && (is(), ls()));
    }
  }
  function Vn(e, t) {
    var n = e.stateNode;
    if (n === null) return null;
    var r = Jr(n);
    if (r === null) return null;
    n = r[t];
    e: switch (t) {
      case "onClick":
      case "onClickCapture":
      case "onDoubleClick":
      case "onDoubleClickCapture":
      case "onMouseDown":
      case "onMouseDownCapture":
      case "onMouseMove":
      case "onMouseMoveCapture":
      case "onMouseUp":
      case "onMouseUpCapture":
      case "onMouseEnter":
        ((r = !r.disabled) ||
          ((e = e.type),
          (r = !(
            e === "button" ||
            e === "input" ||
            e === "select" ||
            e === "textarea"
          ))),
          (e = !r));
        break e;
      default:
        e = !1;
    }
    if (e) return null;
    if (n && typeof n != "function") throw Error(f(231, t, typeof n));
    return n;
  }
  var ql = !1;
  if (q)
    try {
      var Qn = {};
      (Object.defineProperty(Qn, "passive", {
        get: function () {
          ql = !0;
        },
      }),
        window.addEventListener("test", Qn, Qn),
        window.removeEventListener("test", Qn, Qn));
    } catch {
      ql = !1;
    }
  function dc(e, t, n, r, l, o, i, u, a) {
    var y = Array.prototype.slice.call(arguments, 3);
    try {
      t.apply(n, y);
    } catch (w) {
      this.onError(w);
    }
  }
  var Zn = !1,
    Lr = null,
    Nr = !1,
    Jl = null,
    pc = {
      onError: function (e) {
        ((Zn = !0), (Lr = e));
      },
    };
  function hc(e, t, n, r, l, o, i, u, a) {
    ((Zn = !1), (Lr = null), dc.apply(pc, arguments));
  }
  function mc(e, t, n, r, l, o, i, u, a) {
    if ((hc.apply(this, arguments), Zn)) {
      if (Zn) {
        var y = Lr;
        ((Zn = !1), (Lr = null));
      } else throw Error(f(198));
      Nr || ((Nr = !0), (Jl = y));
    }
  }
  function nn(e) {
    var t = e,
      n = e;
    if (e.alternate) for (; t.return;) t = t.return;
    else {
      e = t;
      do ((t = e), (t.flags & 4098) !== 0 && (n = t.return), (e = t.return));
      while (e);
    }
    return t.tag === 3 ? n : null;
  }
  function us(e) {
    if (e.tag === 13) {
      var t = e.memoizedState;
      if (
        (t === null && ((e = e.alternate), e !== null && (t = e.memoizedState)),
        t !== null)
      )
        return t.dehydrated;
    }
    return null;
  }
  function as(e) {
    if (nn(e) !== e) throw Error(f(188));
  }
  function yc(e) {
    var t = e.alternate;
    if (!t) {
      if (((t = nn(e)), t === null)) throw Error(f(188));
      return t !== e ? null : e;
    }
    for (var n = e, r = t; ;) {
      var l = n.return;
      if (l === null) break;
      var o = l.alternate;
      if (o === null) {
        if (((r = l.return), r !== null)) {
          n = r;
          continue;
        }
        break;
      }
      if (l.child === o.child) {
        for (o = l.child; o;) {
          if (o === n) return (as(l), e);
          if (o === r) return (as(l), t);
          o = o.sibling;
        }
        throw Error(f(188));
      }
      if (n.return !== r.return) ((n = l), (r = o));
      else {
        for (var i = !1, u = l.child; u;) {
          if (u === n) {
            ((i = !0), (n = l), (r = o));
            break;
          }
          if (u === r) {
            ((i = !0), (r = l), (n = o));
            break;
          }
          u = u.sibling;
        }
        if (!i) {
          for (u = o.child; u;) {
            if (u === n) {
              ((i = !0), (n = o), (r = l));
              break;
            }
            if (u === r) {
              ((i = !0), (r = o), (n = l));
              break;
            }
            u = u.sibling;
          }
          if (!i) throw Error(f(189));
        }
      }
      if (n.alternate !== r) throw Error(f(190));
    }
    if (n.tag !== 3) throw Error(f(188));
    return n.stateNode.current === n ? e : t;
  }
  function cs(e) {
    return ((e = yc(e)), e !== null ? fs(e) : null);
  }
  function fs(e) {
    if (e.tag === 5 || e.tag === 6) return e;
    for (e = e.child; e !== null;) {
      var t = fs(e);
      if (t !== null) return t;
      e = e.sibling;
    }
    return null;
  }
  var ds = g.unstable_scheduleCallback,
    ps = g.unstable_cancelCallback,
    gc = g.unstable_shouldYield,
    vc = g.unstable_requestPaint,
    we = g.unstable_now,
    xc = g.unstable_getCurrentPriorityLevel,
    bl = g.unstable_ImmediatePriority,
    hs = g.unstable_UserBlockingPriority,
    Rr = g.unstable_NormalPriority,
    kc = g.unstable_LowPriority,
    ms = g.unstable_IdlePriority,
    Tr = null,
    kt = null;
  function wc(e) {
    if (kt && typeof kt.onCommitFiberRoot == "function")
      try {
        kt.onCommitFiberRoot(Tr, e, void 0, (e.current.flags & 128) === 128);
      } catch {}
  }
  var pt = Math.clz32 ? Math.clz32 : zc,
    Sc = Math.log,
    jc = Math.LN2;
  function zc(e) {
    return ((e >>>= 0), e === 0 ? 32 : (31 - ((Sc(e) / jc) | 0)) | 0);
  }
  var Or = 64,
    Dr = 4194304;
  function Kn(e) {
    switch (e & -e) {
      case 1:
        return 1;
      case 2:
        return 2;
      case 4:
        return 4;
      case 8:
        return 8;
      case 16:
        return 16;
      case 32:
        return 32;
      case 64:
      case 128:
      case 256:
      case 512:
      case 1024:
      case 2048:
      case 4096:
      case 8192:
      case 16384:
      case 32768:
      case 65536:
      case 131072:
      case 262144:
      case 524288:
      case 1048576:
      case 2097152:
        return e & 4194240;
      case 4194304:
      case 8388608:
      case 16777216:
      case 33554432:
      case 67108864:
        return e & 130023424;
      case 134217728:
        return 134217728;
      case 268435456:
        return 268435456;
      case 536870912:
        return 536870912;
      case 1073741824:
        return 1073741824;
      default:
        return e;
    }
  }
  function Ir(e, t) {
    var n = e.pendingLanes;
    if (n === 0) return 0;
    var r = 0,
      l = e.suspendedLanes,
      o = e.pingedLanes,
      i = n & 268435455;
    if (i !== 0) {
      var u = i & ~l;
      u !== 0 ? (r = Kn(u)) : ((o &= i), o !== 0 && (r = Kn(o)));
    } else ((i = n & ~l), i !== 0 ? (r = Kn(i)) : o !== 0 && (r = Kn(o)));
    if (r === 0) return 0;
    if (
      t !== 0 &&
      t !== r &&
      (t & l) === 0 &&
      ((l = r & -r), (o = t & -t), l >= o || (l === 16 && (o & 4194240) !== 0))
    )
      return t;
    if (((r & 4) !== 0 && (r |= n & 16), (t = e.entangledLanes), t !== 0))
      for (e = e.entanglements, t &= r; 0 < t;)
        ((n = 31 - pt(t)), (l = 1 << n), (r |= e[n]), (t &= ~l));
    return r;
  }
  function Cc(e, t) {
    switch (e) {
      case 1:
      case 2:
      case 4:
        return t + 250;
      case 8:
      case 16:
      case 32:
      case 64:
      case 128:
      case 256:
      case 512:
      case 1024:
      case 2048:
      case 4096:
      case 8192:
      case 16384:
      case 32768:
      case 65536:
      case 131072:
      case 262144:
      case 524288:
      case 1048576:
      case 2097152:
        return t + 5e3;
      case 4194304:
      case 8388608:
      case 16777216:
      case 33554432:
      case 67108864:
        return -1;
      case 134217728:
      case 268435456:
      case 536870912:
      case 1073741824:
        return -1;
      default:
        return -1;
    }
  }
  function Ec(e, t) {
    for (
      var n = e.suspendedLanes,
        r = e.pingedLanes,
        l = e.expirationTimes,
        o = e.pendingLanes;
      0 < o;
    ) {
      var i = 31 - pt(o),
        u = 1 << i,
        a = l[i];
      (a === -1
        ? ((u & n) === 0 || (u & r) !== 0) && (l[i] = Cc(u, t))
        : a <= t && (e.expiredLanes |= u),
        (o &= ~u));
    }
  }
  function eo(e) {
    return (
      (e = e.pendingLanes & -1073741825),
      e !== 0 ? e : e & 1073741824 ? 1073741824 : 0
    );
  }
  function ys() {
    var e = Or;
    return ((Or <<= 1), (Or & 4194240) === 0 && (Or = 64), e);
  }
  function to(e) {
    for (var t = [], n = 0; 31 > n; n++) t.push(e);
    return t;
  }
  function Gn(e, t, n) {
    ((e.pendingLanes |= t),
      t !== 536870912 && ((e.suspendedLanes = 0), (e.pingedLanes = 0)),
      (e = e.eventTimes),
      (t = 31 - pt(t)),
      (e[t] = n));
  }
  function _c(e, t) {
    var n = e.pendingLanes & ~t;
    ((e.pendingLanes = t),
      (e.suspendedLanes = 0),
      (e.pingedLanes = 0),
      (e.expiredLanes &= t),
      (e.mutableReadLanes &= t),
      (e.entangledLanes &= t),
      (t = e.entanglements));
    var r = e.eventTimes;
    for (e = e.expirationTimes; 0 < n;) {
      var l = 31 - pt(n),
        o = 1 << l;
      ((t[l] = 0), (r[l] = -1), (e[l] = -1), (n &= ~o));
    }
  }
  function no(e, t) {
    var n = (e.entangledLanes |= t);
    for (e = e.entanglements; n;) {
      var r = 31 - pt(n),
        l = 1 << r;
      ((l & t) | (e[r] & t) && (e[r] |= t), (n &= ~l));
    }
  }
  var ee = 0;
  function gs(e) {
    return (
      (e &= -e),
      1 < e ? (4 < e ? ((e & 268435455) !== 0 ? 16 : 536870912) : 4) : 1
    );
  }
  var vs,
    ro,
    xs,
    ks,
    ws,
    lo = !1,
    Fr = [],
    It = null,
    Ft = null,
    At = null,
    Yn = new Map(),
    Xn = new Map(),
    Ut = [],
    Mc =
      "mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(
        " ",
      );
  function Ss(e, t) {
    switch (e) {
      case "focusin":
      case "focusout":
        It = null;
        break;
      case "dragenter":
      case "dragleave":
        Ft = null;
        break;
      case "mouseover":
      case "mouseout":
        At = null;
        break;
      case "pointerover":
      case "pointerout":
        Yn.delete(t.pointerId);
        break;
      case "gotpointercapture":
      case "lostpointercapture":
        Xn.delete(t.pointerId);
    }
  }
  function qn(e, t, n, r, l, o) {
    return e === null || e.nativeEvent !== o
      ? ((e = {
          blockedOn: t,
          domEventName: n,
          eventSystemFlags: r,
          nativeEvent: o,
          targetContainers: [l],
        }),
        t !== null && ((t = fr(t)), t !== null && ro(t)),
        e)
      : ((e.eventSystemFlags |= r),
        (t = e.targetContainers),
        l !== null && t.indexOf(l) === -1 && t.push(l),
        e);
  }
  function Pc(e, t, n, r, l) {
    switch (t) {
      case "focusin":
        return ((It = qn(It, e, t, n, r, l)), !0);
      case "dragenter":
        return ((Ft = qn(Ft, e, t, n, r, l)), !0);
      case "mouseover":
        return ((At = qn(At, e, t, n, r, l)), !0);
      case "pointerover":
        var o = l.pointerId;
        return (Yn.set(o, qn(Yn.get(o) || null, e, t, n, r, l)), !0);
      case "gotpointercapture":
        return (
          (o = l.pointerId),
          Xn.set(o, qn(Xn.get(o) || null, e, t, n, r, l)),
          !0
        );
    }
    return !1;
  }
  function js(e) {
    var t = rn(e.target);
    if (t !== null) {
      var n = nn(t);
      if (n !== null) {
        if (((t = n.tag), t === 13)) {
          if (((t = us(n)), t !== null)) {
            ((e.blockedOn = t),
              ws(e.priority, function () {
                xs(n);
              }));
            return;
          }
        } else if (t === 3 && n.stateNode.current.memoizedState.isDehydrated) {
          e.blockedOn = n.tag === 3 ? n.stateNode.containerInfo : null;
          return;
        }
      }
    }
    e.blockedOn = null;
  }
  function Ar(e) {
    if (e.blockedOn !== null) return !1;
    for (var t = e.targetContainers; 0 < t.length;) {
      var n = io(e.domEventName, e.eventSystemFlags, t[0], e.nativeEvent);
      if (n === null) {
        n = e.nativeEvent;
        var r = new n.constructor(n.type, n);
        ((Kl = r), n.target.dispatchEvent(r), (Kl = null));
      } else return ((t = fr(n)), t !== null && ro(t), (e.blockedOn = n), !1);
      t.shift();
    }
    return !0;
  }
  function zs(e, t, n) {
    Ar(e) && n.delete(t);
  }
  function Lc() {
    ((lo = !1),
      It !== null && Ar(It) && (It = null),
      Ft !== null && Ar(Ft) && (Ft = null),
      At !== null && Ar(At) && (At = null),
      Yn.forEach(zs),
      Xn.forEach(zs));
  }
  function Jn(e, t) {
    e.blockedOn === t &&
      ((e.blockedOn = null),
      lo ||
        ((lo = !0),
        g.unstable_scheduleCallback(g.unstable_NormalPriority, Lc)));
  }
  function bn(e) {
    function t(l) {
      return Jn(l, e);
    }
    if (0 < Fr.length) {
      Jn(Fr[0], e);
      for (var n = 1; n < Fr.length; n++) {
        var r = Fr[n];
        r.blockedOn === e && (r.blockedOn = null);
      }
    }
    for (
      It !== null && Jn(It, e),
        Ft !== null && Jn(Ft, e),
        At !== null && Jn(At, e),
        Yn.forEach(t),
        Xn.forEach(t),
        n = 0;
      n < Ut.length;
      n++
    )
      ((r = Ut[n]), r.blockedOn === e && (r.blockedOn = null));
    for (; 0 < Ut.length && ((n = Ut[0]), n.blockedOn === null);)
      (js(n), n.blockedOn === null && Ut.shift());
  }
  var xn = te.ReactCurrentBatchConfig,
    Ur = !0;
  function Nc(e, t, n, r) {
    var l = ee,
      o = xn.transition;
    xn.transition = null;
    try {
      ((ee = 1), oo(e, t, n, r));
    } finally {
      ((ee = l), (xn.transition = o));
    }
  }
  function Rc(e, t, n, r) {
    var l = ee,
      o = xn.transition;
    xn.transition = null;
    try {
      ((ee = 4), oo(e, t, n, r));
    } finally {
      ((ee = l), (xn.transition = o));
    }
  }
  function oo(e, t, n, r) {
    if (Ur) {
      var l = io(e, t, n, r);
      if (l === null) (zo(e, t, r, Wr, n), Ss(e, r));
      else if (Pc(l, e, t, n, r)) r.stopPropagation();
      else if ((Ss(e, r), t & 4 && -1 < Mc.indexOf(e))) {
        for (; l !== null;) {
          var o = fr(l);
          if (
            (o !== null && vs(o),
            (o = io(e, t, n, r)),
            o === null && zo(e, t, r, Wr, n),
            o === l)
          )
            break;
          l = o;
        }
        l !== null && r.stopPropagation();
      } else zo(e, t, r, null, n);
    }
  }
  var Wr = null;
  function io(e, t, n, r) {
    if (((Wr = null), (e = Gl(r)), (e = rn(e)), e !== null))
      if (((t = nn(e)), t === null)) e = null;
      else if (((n = t.tag), n === 13)) {
        if (((e = us(t)), e !== null)) return e;
        e = null;
      } else if (n === 3) {
        if (t.stateNode.current.memoizedState.isDehydrated)
          return t.tag === 3 ? t.stateNode.containerInfo : null;
        e = null;
      } else t !== e && (e = null);
    return ((Wr = e), null);
  }
  function Cs(e) {
    switch (e) {
      case "cancel":
      case "click":
      case "close":
      case "contextmenu":
      case "copy":
      case "cut":
      case "auxclick":
      case "dblclick":
      case "dragend":
      case "dragstart":
      case "drop":
      case "focusin":
      case "focusout":
      case "input":
      case "invalid":
      case "keydown":
      case "keypress":
      case "keyup":
      case "mousedown":
      case "mouseup":
      case "paste":
      case "pause":
      case "play":
      case "pointercancel":
      case "pointerdown":
      case "pointerup":
      case "ratechange":
      case "reset":
      case "resize":
      case "seeked":
      case "submit":
      case "touchcancel":
      case "touchend":
      case "touchstart":
      case "volumechange":
      case "change":
      case "selectionchange":
      case "textInput":
      case "compositionstart":
      case "compositionend":
      case "compositionupdate":
      case "beforeblur":
      case "afterblur":
      case "beforeinput":
      case "blur":
      case "fullscreenchange":
      case "focus":
      case "hashchange":
      case "popstate":
      case "select":
      case "selectstart":
        return 1;
      case "drag":
      case "dragenter":
      case "dragexit":
      case "dragleave":
      case "dragover":
      case "mousemove":
      case "mouseout":
      case "mouseover":
      case "pointermove":
      case "pointerout":
      case "pointerover":
      case "scroll":
      case "toggle":
      case "touchmove":
      case "wheel":
      case "mouseenter":
      case "mouseleave":
      case "pointerenter":
      case "pointerleave":
        return 4;
      case "message":
        switch (xc()) {
          case bl:
            return 1;
          case hs:
            return 4;
          case Rr:
          case kc:
            return 16;
          case ms:
            return 536870912;
          default:
            return 16;
        }
      default:
        return 16;
    }
  }
  var Wt = null,
    so = null,
    Hr = null;
  function Es() {
    if (Hr) return Hr;
    var e,
      t = so,
      n = t.length,
      r,
      l = "value" in Wt ? Wt.value : Wt.textContent,
      o = l.length;
    for (e = 0; e < n && t[e] === l[e]; e++);
    var i = n - e;
    for (r = 1; r <= i && t[n - r] === l[o - r]; r++);
    return (Hr = l.slice(e, 1 < r ? 1 - r : void 0));
  }
  function $r(e) {
    var t = e.keyCode;
    return (
      "charCode" in e
        ? ((e = e.charCode), e === 0 && t === 13 && (e = 13))
        : (e = t),
      e === 10 && (e = 13),
      32 <= e || e === 13 ? e : 0
    );
  }
  function Br() {
    return !0;
  }
  function _s() {
    return !1;
  }
  function nt(e) {
    function t(n, r, l, o, i) {
      ((this._reactName = n),
        (this._targetInst = l),
        (this.type = r),
        (this.nativeEvent = o),
        (this.target = i),
        (this.currentTarget = null));
      for (var u in e)
        e.hasOwnProperty(u) && ((n = e[u]), (this[u] = n ? n(o) : o[u]));
      return (
        (this.isDefaultPrevented = (
          o.defaultPrevented != null ? o.defaultPrevented : o.returnValue === !1
        )
          ? Br
          : _s),
        (this.isPropagationStopped = _s),
        this
      );
    }
    return (
      L(t.prototype, {
        preventDefault: function () {
          this.defaultPrevented = !0;
          var n = this.nativeEvent;
          n &&
            (n.preventDefault
              ? n.preventDefault()
              : typeof n.returnValue != "unknown" && (n.returnValue = !1),
            (this.isDefaultPrevented = Br));
        },
        stopPropagation: function () {
          var n = this.nativeEvent;
          n &&
            (n.stopPropagation
              ? n.stopPropagation()
              : typeof n.cancelBubble != "unknown" && (n.cancelBubble = !0),
            (this.isPropagationStopped = Br));
        },
        persist: function () {},
        isPersistent: Br,
      }),
      t
    );
  }
  var kn = {
      eventPhase: 0,
      bubbles: 0,
      cancelable: 0,
      timeStamp: function (e) {
        return e.timeStamp || Date.now();
      },
      defaultPrevented: 0,
      isTrusted: 0,
    },
    uo = nt(kn),
    er = L({}, kn, { view: 0, detail: 0 }),
    Tc = nt(er),
    ao,
    co,
    tr,
    Vr = L({}, er, {
      screenX: 0,
      screenY: 0,
      clientX: 0,
      clientY: 0,
      pageX: 0,
      pageY: 0,
      ctrlKey: 0,
      shiftKey: 0,
      altKey: 0,
      metaKey: 0,
      getModifierState: po,
      button: 0,
      buttons: 0,
      relatedTarget: function (e) {
        return e.relatedTarget === void 0
          ? e.fromElement === e.srcElement
            ? e.toElement
            : e.fromElement
          : e.relatedTarget;
      },
      movementX: function (e) {
        return "movementX" in e
          ? e.movementX
          : (e !== tr &&
              (tr && e.type === "mousemove"
                ? ((ao = e.screenX - tr.screenX), (co = e.screenY - tr.screenY))
                : (co = ao = 0),
              (tr = e)),
            ao);
      },
      movementY: function (e) {
        return "movementY" in e ? e.movementY : co;
      },
    }),
    Ms = nt(Vr),
    Oc = L({}, Vr, { dataTransfer: 0 }),
    Dc = nt(Oc),
    Ic = L({}, er, { relatedTarget: 0 }),
    fo = nt(Ic),
    Fc = L({}, kn, { animationName: 0, elapsedTime: 0, pseudoElement: 0 }),
    Ac = nt(Fc),
    Uc = L({}, kn, {
      clipboardData: function (e) {
        return "clipboardData" in e ? e.clipboardData : window.clipboardData;
      },
    }),
    Wc = nt(Uc),
    Hc = L({}, kn, { data: 0 }),
    Ps = nt(Hc),
    $c = {
      Esc: "Escape",
      Spacebar: " ",
      Left: "ArrowLeft",
      Up: "ArrowUp",
      Right: "ArrowRight",
      Down: "ArrowDown",
      Del: "Delete",
      Win: "OS",
      Menu: "ContextMenu",
      Apps: "ContextMenu",
      Scroll: "ScrollLock",
      MozPrintableKey: "Unidentified",
    },
    Bc = {
      8: "Backspace",
      9: "Tab",
      12: "Clear",
      13: "Enter",
      16: "Shift",
      17: "Control",
      18: "Alt",
      19: "Pause",
      20: "CapsLock",
      27: "Escape",
      32: " ",
      33: "PageUp",
      34: "PageDown",
      35: "End",
      36: "Home",
      37: "ArrowLeft",
      38: "ArrowUp",
      39: "ArrowRight",
      40: "ArrowDown",
      45: "Insert",
      46: "Delete",
      112: "F1",
      113: "F2",
      114: "F3",
      115: "F4",
      116: "F5",
      117: "F6",
      118: "F7",
      119: "F8",
      120: "F9",
      121: "F10",
      122: "F11",
      123: "F12",
      144: "NumLock",
      145: "ScrollLock",
      224: "Meta",
    },
    Vc = {
      Alt: "altKey",
      Control: "ctrlKey",
      Meta: "metaKey",
      Shift: "shiftKey",
    };
  function Qc(e) {
    var t = this.nativeEvent;
    return t.getModifierState
      ? t.getModifierState(e)
      : (e = Vc[e])
        ? !!t[e]
        : !1;
  }
  function po() {
    return Qc;
  }
  var Zc = L({}, er, {
      key: function (e) {
        if (e.key) {
          var t = $c[e.key] || e.key;
          if (t !== "Unidentified") return t;
        }
        return e.type === "keypress"
          ? ((e = $r(e)), e === 13 ? "Enter" : String.fromCharCode(e))
          : e.type === "keydown" || e.type === "keyup"
            ? Bc[e.keyCode] || "Unidentified"
            : "";
      },
      code: 0,
      location: 0,
      ctrlKey: 0,
      shiftKey: 0,
      altKey: 0,
      metaKey: 0,
      repeat: 0,
      locale: 0,
      getModifierState: po,
      charCode: function (e) {
        return e.type === "keypress" ? $r(e) : 0;
      },
      keyCode: function (e) {
        return e.type === "keydown" || e.type === "keyup" ? e.keyCode : 0;
      },
      which: function (e) {
        return e.type === "keypress"
          ? $r(e)
          : e.type === "keydown" || e.type === "keyup"
            ? e.keyCode
            : 0;
      },
    }),
    Kc = nt(Zc),
    Gc = L({}, Vr, {
      pointerId: 0,
      width: 0,
      height: 0,
      pressure: 0,
      tangentialPressure: 0,
      tiltX: 0,
      tiltY: 0,
      twist: 0,
      pointerType: 0,
      isPrimary: 0,
    }),
    Ls = nt(Gc),
    Yc = L({}, er, {
      touches: 0,
      targetTouches: 0,
      changedTouches: 0,
      altKey: 0,
      metaKey: 0,
      ctrlKey: 0,
      shiftKey: 0,
      getModifierState: po,
    }),
    Xc = nt(Yc),
    qc = L({}, kn, { propertyName: 0, elapsedTime: 0, pseudoElement: 0 }),
    Jc = nt(qc),
    bc = L({}, Vr, {
      deltaX: function (e) {
        return "deltaX" in e
          ? e.deltaX
          : "wheelDeltaX" in e
            ? -e.wheelDeltaX
            : 0;
      },
      deltaY: function (e) {
        return "deltaY" in e
          ? e.deltaY
          : "wheelDeltaY" in e
            ? -e.wheelDeltaY
            : "wheelDelta" in e
              ? -e.wheelDelta
              : 0;
      },
      deltaZ: 0,
      deltaMode: 0,
    }),
    ef = nt(bc),
    tf = [9, 13, 27, 32],
    ho = q && "CompositionEvent" in window,
    nr = null;
  q && "documentMode" in document && (nr = document.documentMode);
  var nf = q && "TextEvent" in window && !nr,
    Ns = q && (!ho || (nr && 8 < nr && 11 >= nr)),
    Rs = " ",
    Ts = !1;
  function Os(e, t) {
    switch (e) {
      case "keyup":
        return tf.indexOf(t.keyCode) !== -1;
      case "keydown":
        return t.keyCode !== 229;
      case "keypress":
      case "mousedown":
      case "focusout":
        return !0;
      default:
        return !1;
    }
  }
  function Ds(e) {
    return (
      (e = e.detail),
      typeof e == "object" && "data" in e ? e.data : null
    );
  }
  var wn = !1;
  function rf(e, t) {
    switch (e) {
      case "compositionend":
        return Ds(t);
      case "keypress":
        return t.which !== 32 ? null : ((Ts = !0), Rs);
      case "textInput":
        return ((e = t.data), e === Rs && Ts ? null : e);
      default:
        return null;
    }
  }
  function lf(e, t) {
    if (wn)
      return e === "compositionend" || (!ho && Os(e, t))
        ? ((e = Es()), (Hr = so = Wt = null), (wn = !1), e)
        : null;
    switch (e) {
      case "paste":
        return null;
      case "keypress":
        if (!(t.ctrlKey || t.altKey || t.metaKey) || (t.ctrlKey && t.altKey)) {
          if (t.char && 1 < t.char.length) return t.char;
          if (t.which) return String.fromCharCode(t.which);
        }
        return null;
      case "compositionend":
        return Ns && t.locale !== "ko" ? null : t.data;
      default:
        return null;
    }
  }
  var of = {
    color: !0,
    date: !0,
    datetime: !0,
    "datetime-local": !0,
    email: !0,
    month: !0,
    number: !0,
    password: !0,
    range: !0,
    search: !0,
    tel: !0,
    text: !0,
    time: !0,
    url: !0,
    week: !0,
  };
  function Is(e) {
    var t = e && e.nodeName && e.nodeName.toLowerCase();
    return t === "input" ? !!of[e.type] : t === "textarea";
  }
  function Fs(e, t, n, r) {
    (rs(r),
      (t = Yr(t, "onChange")),
      0 < t.length &&
        ((n = new uo("onChange", "change", null, n, r)),
        e.push({ event: n, listeners: t })));
  }
  var rr = null,
    lr = null;
  function sf(e) {
    tu(e, 0);
  }
  function Qr(e) {
    var t = En(e);
    if (Qi(t)) return e;
  }
  function uf(e, t) {
    if (e === "change") return t;
  }
  var As = !1;
  if (q) {
    var mo;
    if (q) {
      var yo = "oninput" in document;
      if (!yo) {
        var Us = document.createElement("div");
        (Us.setAttribute("oninput", "return;"),
          (yo = typeof Us.oninput == "function"));
      }
      mo = yo;
    } else mo = !1;
    As = mo && (!document.documentMode || 9 < document.documentMode);
  }
  function Ws() {
    rr && (rr.detachEvent("onpropertychange", Hs), (lr = rr = null));
  }
  function Hs(e) {
    if (e.propertyName === "value" && Qr(lr)) {
      var t = [];
      (Fs(t, lr, e, Gl(e)), ss(sf, t));
    }
  }
  function af(e, t, n) {
    e === "focusin"
      ? (Ws(), (rr = t), (lr = n), rr.attachEvent("onpropertychange", Hs))
      : e === "focusout" && Ws();
  }
  function cf(e) {
    if (e === "selectionchange" || e === "keyup" || e === "keydown")
      return Qr(lr);
  }
  function ff(e, t) {
    if (e === "click") return Qr(t);
  }
  function df(e, t) {
    if (e === "input" || e === "change") return Qr(t);
  }
  function pf(e, t) {
    return (e === t && (e !== 0 || 1 / e === 1 / t)) || (e !== e && t !== t);
  }
  var ht = typeof Object.is == "function" ? Object.is : pf;
  function or(e, t) {
    if (ht(e, t)) return !0;
    if (
      typeof e != "object" ||
      e === null ||
      typeof t != "object" ||
      t === null
    )
      return !1;
    var n = Object.keys(e),
      r = Object.keys(t);
    if (n.length !== r.length) return !1;
    for (r = 0; r < n.length; r++) {
      var l = n[r];
      if (!O.call(t, l) || !ht(e[l], t[l])) return !1;
    }
    return !0;
  }
  function $s(e) {
    for (; e && e.firstChild;) e = e.firstChild;
    return e;
  }
  function Bs(e, t) {
    var n = $s(e);
    e = 0;
    for (var r; n;) {
      if (n.nodeType === 3) {
        if (((r = e + n.textContent.length), e <= t && r >= t))
          return { node: n, offset: t - e };
        e = r;
      }
      e: {
        for (; n;) {
          if (n.nextSibling) {
            n = n.nextSibling;
            break e;
          }
          n = n.parentNode;
        }
        n = void 0;
      }
      n = $s(n);
    }
  }
  function Vs(e, t) {
    return e && t
      ? e === t
        ? !0
        : e && e.nodeType === 3
          ? !1
          : t && t.nodeType === 3
            ? Vs(e, t.parentNode)
            : "contains" in e
              ? e.contains(t)
              : e.compareDocumentPosition
                ? !!(e.compareDocumentPosition(t) & 16)
                : !1
      : !1;
  }
  function Qs() {
    for (var e = window, t = Mr(); t instanceof e.HTMLIFrameElement;) {
      try {
        var n = typeof t.contentWindow.location.href == "string";
      } catch {
        n = !1;
      }
      if (n) e = t.contentWindow;
      else break;
      t = Mr(e.document);
    }
    return t;
  }
  function go(e) {
    var t = e && e.nodeName && e.nodeName.toLowerCase();
    return (
      t &&
      ((t === "input" &&
        (e.type === "text" ||
          e.type === "search" ||
          e.type === "tel" ||
          e.type === "url" ||
          e.type === "password")) ||
        t === "textarea" ||
        e.contentEditable === "true")
    );
  }
  function hf(e) {
    var t = Qs(),
      n = e.focusedElem,
      r = e.selectionRange;
    if (
      t !== n &&
      n &&
      n.ownerDocument &&
      Vs(n.ownerDocument.documentElement, n)
    ) {
      if (r !== null && go(n)) {
        if (
          ((t = r.start),
          (e = r.end),
          e === void 0 && (e = t),
          "selectionStart" in n)
        )
          ((n.selectionStart = t),
            (n.selectionEnd = Math.min(e, n.value.length)));
        else if (
          ((e = ((t = n.ownerDocument || document) && t.defaultView) || window),
          e.getSelection)
        ) {
          e = e.getSelection();
          var l = n.textContent.length,
            o = Math.min(r.start, l);
          ((r = r.end === void 0 ? o : Math.min(r.end, l)),
            !e.extend && o > r && ((l = r), (r = o), (o = l)),
            (l = Bs(n, o)));
          var i = Bs(n, r);
          l &&
            i &&
            (e.rangeCount !== 1 ||
              e.anchorNode !== l.node ||
              e.anchorOffset !== l.offset ||
              e.focusNode !== i.node ||
              e.focusOffset !== i.offset) &&
            ((t = t.createRange()),
            t.setStart(l.node, l.offset),
            e.removeAllRanges(),
            o > r
              ? (e.addRange(t), e.extend(i.node, i.offset))
              : (t.setEnd(i.node, i.offset), e.addRange(t)));
        }
      }
      for (t = [], e = n; (e = e.parentNode);)
        e.nodeType === 1 &&
          t.push({ element: e, left: e.scrollLeft, top: e.scrollTop });
      for (typeof n.focus == "function" && n.focus(), n = 0; n < t.length; n++)
        ((e = t[n]),
          (e.element.scrollLeft = e.left),
          (e.element.scrollTop = e.top));
    }
  }
  var mf = q && "documentMode" in document && 11 >= document.documentMode,
    Sn = null,
    vo = null,
    ir = null,
    xo = !1;
  function Zs(e, t, n) {
    var r =
      n.window === n ? n.document : n.nodeType === 9 ? n : n.ownerDocument;
    xo ||
      Sn == null ||
      Sn !== Mr(r) ||
      ((r = Sn),
      "selectionStart" in r && go(r)
        ? (r = { start: r.selectionStart, end: r.selectionEnd })
        : ((r = (
            (r.ownerDocument && r.ownerDocument.defaultView) ||
            window
          ).getSelection()),
          (r = {
            anchorNode: r.anchorNode,
            anchorOffset: r.anchorOffset,
            focusNode: r.focusNode,
            focusOffset: r.focusOffset,
          })),
      (ir && or(ir, r)) ||
        ((ir = r),
        (r = Yr(vo, "onSelect")),
        0 < r.length &&
          ((t = new uo("onSelect", "select", null, t, n)),
          e.push({ event: t, listeners: r }),
          (t.target = Sn))));
  }
  function Zr(e, t) {
    var n = {};
    return (
      (n[e.toLowerCase()] = t.toLowerCase()),
      (n["Webkit" + e] = "webkit" + t),
      (n["Moz" + e] = "moz" + t),
      n
    );
  }
  var jn = {
      animationend: Zr("Animation", "AnimationEnd"),
      animationiteration: Zr("Animation", "AnimationIteration"),
      animationstart: Zr("Animation", "AnimationStart"),
      transitionend: Zr("Transition", "TransitionEnd"),
    },
    ko = {},
    Ks = {};
  q &&
    ((Ks = document.createElement("div").style),
    "AnimationEvent" in window ||
      (delete jn.animationend.animation,
      delete jn.animationiteration.animation,
      delete jn.animationstart.animation),
    "TransitionEvent" in window || delete jn.transitionend.transition);
  function Kr(e) {
    if (ko[e]) return ko[e];
    if (!jn[e]) return e;
    var t = jn[e],
      n;
    for (n in t) if (t.hasOwnProperty(n) && n in Ks) return (ko[e] = t[n]);
    return e;
  }
  var Gs = Kr("animationend"),
    Ys = Kr("animationiteration"),
    Xs = Kr("animationstart"),
    qs = Kr("transitionend"),
    Js = new Map(),
    bs =
      "abort auxClick cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(
        " ",
      );
  function Ht(e, t) {
    (Js.set(e, t), M(t, [e]));
  }
  for (var wo = 0; wo < bs.length; wo++) {
    var So = bs[wo],
      yf = So.toLowerCase(),
      gf = So[0].toUpperCase() + So.slice(1);
    Ht(yf, "on" + gf);
  }
  (Ht(Gs, "onAnimationEnd"),
    Ht(Ys, "onAnimationIteration"),
    Ht(Xs, "onAnimationStart"),
    Ht("dblclick", "onDoubleClick"),
    Ht("focusin", "onFocus"),
    Ht("focusout", "onBlur"),
    Ht(qs, "onTransitionEnd"),
    $("onMouseEnter", ["mouseout", "mouseover"]),
    $("onMouseLeave", ["mouseout", "mouseover"]),
    $("onPointerEnter", ["pointerout", "pointerover"]),
    $("onPointerLeave", ["pointerout", "pointerover"]),
    M(
      "onChange",
      "change click focusin focusout input keydown keyup selectionchange".split(
        " ",
      ),
    ),
    M(
      "onSelect",
      "focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(
        " ",
      ),
    ),
    M("onBeforeInput", ["compositionend", "keypress", "textInput", "paste"]),
    M(
      "onCompositionEnd",
      "compositionend focusout keydown keypress keyup mousedown".split(" "),
    ),
    M(
      "onCompositionStart",
      "compositionstart focusout keydown keypress keyup mousedown".split(" "),
    ),
    M(
      "onCompositionUpdate",
      "compositionupdate focusout keydown keypress keyup mousedown".split(" "),
    ));
  var sr =
      "abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(
        " ",
      ),
    vf = new Set(
      "cancel close invalid load scroll toggle".split(" ").concat(sr),
    );
  function eu(e, t, n) {
    var r = e.type || "unknown-event";
    ((e.currentTarget = n), mc(r, t, void 0, e), (e.currentTarget = null));
  }
  function tu(e, t) {
    t = (t & 4) !== 0;
    for (var n = 0; n < e.length; n++) {
      var r = e[n],
        l = r.event;
      r = r.listeners;
      e: {
        var o = void 0;
        if (t)
          for (var i = r.length - 1; 0 <= i; i--) {
            var u = r[i],
              a = u.instance,
              y = u.currentTarget;
            if (((u = u.listener), a !== o && l.isPropagationStopped()))
              break e;
            (eu(l, u, y), (o = a));
          }
        else
          for (i = 0; i < r.length; i++) {
            if (
              ((u = r[i]),
              (a = u.instance),
              (y = u.currentTarget),
              (u = u.listener),
              a !== o && l.isPropagationStopped())
            )
              break e;
            (eu(l, u, y), (o = a));
          }
      }
    }
    if (Nr) throw ((e = Jl), (Nr = !1), (Jl = null), e);
  }
  function ae(e, t) {
    var n = t[Lo];
    n === void 0 && (n = t[Lo] = new Set());
    var r = e + "__bubble";
    n.has(r) || (nu(t, e, 2, !1), n.add(r));
  }
  function jo(e, t, n) {
    var r = 0;
    (t && (r |= 4), nu(n, e, r, t));
  }
  var Gr = "_reactListening" + Math.random().toString(36).slice(2);
  function ur(e) {
    if (!e[Gr]) {
      ((e[Gr] = !0),
        j.forEach(function (n) {
          n !== "selectionchange" && (vf.has(n) || jo(n, !1, e), jo(n, !0, e));
        }));
      var t = e.nodeType === 9 ? e : e.ownerDocument;
      t === null || t[Gr] || ((t[Gr] = !0), jo("selectionchange", !1, t));
    }
  }
  function nu(e, t, n, r) {
    switch (Cs(t)) {
      case 1:
        var l = Nc;
        break;
      case 4:
        l = Rc;
        break;
      default:
        l = oo;
    }
    ((n = l.bind(null, t, n, e)),
      (l = void 0),
      !ql ||
        (t !== "touchstart" && t !== "touchmove" && t !== "wheel") ||
        (l = !0),
      r
        ? l !== void 0
          ? e.addEventListener(t, n, { capture: !0, passive: l })
          : e.addEventListener(t, n, !0)
        : l !== void 0
          ? e.addEventListener(t, n, { passive: l })
          : e.addEventListener(t, n, !1));
  }
  function zo(e, t, n, r, l) {
    var o = r;
    if ((t & 1) === 0 && (t & 2) === 0 && r !== null)
      e: for (;;) {
        if (r === null) return;
        var i = r.tag;
        if (i === 3 || i === 4) {
          var u = r.stateNode.containerInfo;
          if (u === l || (u.nodeType === 8 && u.parentNode === l)) break;
          if (i === 4)
            for (i = r.return; i !== null;) {
              var a = i.tag;
              if (
                (a === 3 || a === 4) &&
                ((a = i.stateNode.containerInfo),
                a === l || (a.nodeType === 8 && a.parentNode === l))
              )
                return;
              i = i.return;
            }
          for (; u !== null;) {
            if (((i = rn(u)), i === null)) return;
            if (((a = i.tag), a === 5 || a === 6)) {
              r = o = i;
              continue e;
            }
            u = u.parentNode;
          }
        }
        r = r.return;
      }
    ss(function () {
      var y = o,
        w = Gl(n),
        S = [];
      e: {
        var x = Js.get(e);
        if (x !== void 0) {
          var _ = uo,
            N = e;
          switch (e) {
            case "keypress":
              if ($r(n) === 0) break e;
            case "keydown":
            case "keyup":
              _ = Kc;
              break;
            case "focusin":
              ((N = "focus"), (_ = fo));
              break;
            case "focusout":
              ((N = "blur"), (_ = fo));
              break;
            case "beforeblur":
            case "afterblur":
              _ = fo;
              break;
            case "click":
              if (n.button === 2) break e;
            case "auxclick":
            case "dblclick":
            case "mousedown":
            case "mousemove":
            case "mouseup":
            case "mouseout":
            case "mouseover":
            case "contextmenu":
              _ = Ms;
              break;
            case "drag":
            case "dragend":
            case "dragenter":
            case "dragexit":
            case "dragleave":
            case "dragover":
            case "dragstart":
            case "drop":
              _ = Dc;
              break;
            case "touchcancel":
            case "touchend":
            case "touchmove":
            case "touchstart":
              _ = Xc;
              break;
            case Gs:
            case Ys:
            case Xs:
              _ = Ac;
              break;
            case qs:
              _ = Jc;
              break;
            case "scroll":
              _ = Tc;
              break;
            case "wheel":
              _ = ef;
              break;
            case "copy":
            case "cut":
            case "paste":
              _ = Wc;
              break;
            case "gotpointercapture":
            case "lostpointercapture":
            case "pointercancel":
            case "pointerdown":
            case "pointermove":
            case "pointerout":
            case "pointerover":
            case "pointerup":
              _ = Ls;
          }
          var R = (t & 4) !== 0,
            Se = !R && e === "scroll",
            h = R ? (x !== null ? x + "Capture" : null) : x;
          R = [];
          for (var c = y, m; c !== null;) {
            m = c;
            var z = m.stateNode;
            if (
              (m.tag === 5 &&
                z !== null &&
                ((m = z),
                h !== null &&
                  ((z = Vn(c, h)), z != null && R.push(ar(c, z, m)))),
              Se)
            )
              break;
            c = c.return;
          }
          0 < R.length &&
            ((x = new _(x, N, null, n, w)), S.push({ event: x, listeners: R }));
        }
      }
      if ((t & 7) === 0) {
        e: {
          if (
            ((x = e === "mouseover" || e === "pointerover"),
            (_ = e === "mouseout" || e === "pointerout"),
            x &&
              n !== Kl &&
              (N = n.relatedTarget || n.fromElement) &&
              (rn(N) || N[Ct]))
          )
            break e;
          if (
            (_ || x) &&
            ((x =
              w.window === w
                ? w
                : (x = w.ownerDocument)
                  ? x.defaultView || x.parentWindow
                  : window),
            _
              ? ((N = n.relatedTarget || n.toElement),
                (_ = y),
                (N = N ? rn(N) : null),
                N !== null &&
                  ((Se = nn(N)), N !== Se || (N.tag !== 5 && N.tag !== 6)) &&
                  (N = null))
              : ((_ = null), (N = y)),
            _ !== N)
          ) {
            if (
              ((R = Ms),
              (z = "onMouseLeave"),
              (h = "onMouseEnter"),
              (c = "mouse"),
              (e === "pointerout" || e === "pointerover") &&
                ((R = Ls),
                (z = "onPointerLeave"),
                (h = "onPointerEnter"),
                (c = "pointer")),
              (Se = _ == null ? x : En(_)),
              (m = N == null ? x : En(N)),
              (x = new R(z, c + "leave", _, n, w)),
              (x.target = Se),
              (x.relatedTarget = m),
              (z = null),
              rn(w) === y &&
                ((R = new R(h, c + "enter", N, n, w)),
                (R.target = m),
                (R.relatedTarget = Se),
                (z = R)),
              (Se = z),
              _ && N)
            )
              t: {
                for (R = _, h = N, c = 0, m = R; m; m = zn(m)) c++;
                for (m = 0, z = h; z; z = zn(z)) m++;
                for (; 0 < c - m;) ((R = zn(R)), c--);
                for (; 0 < m - c;) ((h = zn(h)), m--);
                for (; c--;) {
                  if (R === h || (h !== null && R === h.alternate)) break t;
                  ((R = zn(R)), (h = zn(h)));
                }
                R = null;
              }
            else R = null;
            (_ !== null && ru(S, x, _, R, !1),
              N !== null && Se !== null && ru(S, Se, N, R, !0));
          }
        }
        e: {
          if (
            ((x = y ? En(y) : window),
            (_ = x.nodeName && x.nodeName.toLowerCase()),
            _ === "select" || (_ === "input" && x.type === "file"))
          )
            var T = uf;
          else if (Is(x))
            if (As) T = df;
            else {
              T = cf;
              var D = af;
            }
          else
            (_ = x.nodeName) &&
              _.toLowerCase() === "input" &&
              (x.type === "checkbox" || x.type === "radio") &&
              (T = ff);
          if (T && (T = T(e, y))) {
            Fs(S, T, n, w);
            break e;
          }
          (D && D(e, x, y),
            e === "focusout" &&
              (D = x._wrapperState) &&
              D.controlled &&
              x.type === "number" &&
              $l(x, "number", x.value));
        }
        switch (((D = y ? En(y) : window), e)) {
          case "focusin":
            (Is(D) || D.contentEditable === "true") &&
              ((Sn = D), (vo = y), (ir = null));
            break;
          case "focusout":
            ir = vo = Sn = null;
            break;
          case "mousedown":
            xo = !0;
            break;
          case "contextmenu":
          case "mouseup":
          case "dragend":
            ((xo = !1), Zs(S, n, w));
            break;
          case "selectionchange":
            if (mf) break;
          case "keydown":
          case "keyup":
            Zs(S, n, w);
        }
        var I;
        if (ho)
          e: {
            switch (e) {
              case "compositionstart":
                var A = "onCompositionStart";
                break e;
              case "compositionend":
                A = "onCompositionEnd";
                break e;
              case "compositionupdate":
                A = "onCompositionUpdate";
                break e;
            }
            A = void 0;
          }
        else
          wn
            ? Os(e, n) && (A = "onCompositionEnd")
            : e === "keydown" &&
              n.keyCode === 229 &&
              (A = "onCompositionStart");
        (A &&
          (Ns &&
            n.locale !== "ko" &&
            (wn || A !== "onCompositionStart"
              ? A === "onCompositionEnd" && wn && (I = Es())
              : ((Wt = w),
                (so = "value" in Wt ? Wt.value : Wt.textContent),
                (wn = !0))),
          (D = Yr(y, A)),
          0 < D.length &&
            ((A = new Ps(A, e, null, n, w)),
            S.push({ event: A, listeners: D }),
            I ? (A.data = I) : ((I = Ds(n)), I !== null && (A.data = I)))),
          (I = nf ? rf(e, n) : lf(e, n)) &&
            ((y = Yr(y, "onBeforeInput")),
            0 < y.length &&
              ((w = new Ps("onBeforeInput", "beforeinput", null, n, w)),
              S.push({ event: w, listeners: y }),
              (w.data = I))));
      }
      tu(S, t);
    });
  }
  function ar(e, t, n) {
    return { instance: e, listener: t, currentTarget: n };
  }
  function Yr(e, t) {
    for (var n = t + "Capture", r = []; e !== null;) {
      var l = e,
        o = l.stateNode;
      (l.tag === 5 &&
        o !== null &&
        ((l = o),
        (o = Vn(e, n)),
        o != null && r.unshift(ar(e, o, l)),
        (o = Vn(e, t)),
        o != null && r.push(ar(e, o, l))),
        (e = e.return));
    }
    return r;
  }
  function zn(e) {
    if (e === null) return null;
    do e = e.return;
    while (e && e.tag !== 5);
    return e || null;
  }
  function ru(e, t, n, r, l) {
    for (var o = t._reactName, i = []; n !== null && n !== r;) {
      var u = n,
        a = u.alternate,
        y = u.stateNode;
      if (a !== null && a === r) break;
      (u.tag === 5 &&
        y !== null &&
        ((u = y),
        l
          ? ((a = Vn(n, o)), a != null && i.unshift(ar(n, a, u)))
          : l || ((a = Vn(n, o)), a != null && i.push(ar(n, a, u)))),
        (n = n.return));
    }
    i.length !== 0 && e.push({ event: t, listeners: i });
  }
  var xf = /\r\n?/g,
    kf = /\u0000|\uFFFD/g;
  function lu(e) {
    return (typeof e == "string" ? e : "" + e)
      .replace(
        xf,
        `
`,
      )
      .replace(kf, "");
  }
  function Xr(e, t, n) {
    if (((t = lu(t)), lu(e) !== t && n)) throw Error(f(425));
  }
  function qr() {}
  var Co = null,
    Eo = null;
  function _o(e, t) {
    return (
      e === "textarea" ||
      e === "noscript" ||
      typeof t.children == "string" ||
      typeof t.children == "number" ||
      (typeof t.dangerouslySetInnerHTML == "object" &&
        t.dangerouslySetInnerHTML !== null &&
        t.dangerouslySetInnerHTML.__html != null)
    );
  }
  var Mo = typeof setTimeout == "function" ? setTimeout : void 0,
    wf = typeof clearTimeout == "function" ? clearTimeout : void 0,
    ou = typeof Promise == "function" ? Promise : void 0,
    Sf =
      typeof queueMicrotask == "function"
        ? queueMicrotask
        : typeof ou < "u"
          ? function (e) {
              return ou.resolve(null).then(e).catch(jf);
            }
          : Mo;
  function jf(e) {
    setTimeout(function () {
      throw e;
    });
  }
  function Po(e, t) {
    var n = t,
      r = 0;
    do {
      var l = n.nextSibling;
      if ((e.removeChild(n), l && l.nodeType === 8))
        if (((n = l.data), n === "/$")) {
          if (r === 0) {
            (e.removeChild(l), bn(t));
            return;
          }
          r--;
        } else (n !== "$" && n !== "$?" && n !== "$!") || r++;
      n = l;
    } while (n);
    bn(t);
  }
  function $t(e) {
    for (; e != null; e = e.nextSibling) {
      var t = e.nodeType;
      if (t === 1 || t === 3) break;
      if (t === 8) {
        if (((t = e.data), t === "$" || t === "$!" || t === "$?")) break;
        if (t === "/$") return null;
      }
    }
    return e;
  }
  function iu(e) {
    e = e.previousSibling;
    for (var t = 0; e;) {
      if (e.nodeType === 8) {
        var n = e.data;
        if (n === "$" || n === "$!" || n === "$?") {
          if (t === 0) return e;
          t--;
        } else n === "/$" && t++;
      }
      e = e.previousSibling;
    }
    return null;
  }
  var Cn = Math.random().toString(36).slice(2),
    wt = "__reactFiber$" + Cn,
    cr = "__reactProps$" + Cn,
    Ct = "__reactContainer$" + Cn,
    Lo = "__reactEvents$" + Cn,
    zf = "__reactListeners$" + Cn,
    Cf = "__reactHandles$" + Cn;
  function rn(e) {
    var t = e[wt];
    if (t) return t;
    for (var n = e.parentNode; n;) {
      if ((t = n[Ct] || n[wt])) {
        if (
          ((n = t.alternate),
          t.child !== null || (n !== null && n.child !== null))
        )
          for (e = iu(e); e !== null;) {
            if ((n = e[wt])) return n;
            e = iu(e);
          }
        return t;
      }
      ((e = n), (n = e.parentNode));
    }
    return null;
  }
  function fr(e) {
    return (
      (e = e[wt] || e[Ct]),
      !e || (e.tag !== 5 && e.tag !== 6 && e.tag !== 13 && e.tag !== 3)
        ? null
        : e
    );
  }
  function En(e) {
    if (e.tag === 5 || e.tag === 6) return e.stateNode;
    throw Error(f(33));
  }
  function Jr(e) {
    return e[cr] || null;
  }
  var No = [],
    _n = -1;
  function Bt(e) {
    return { current: e };
  }
  function ce(e) {
    0 > _n || ((e.current = No[_n]), (No[_n] = null), _n--);
  }
  function se(e, t) {
    (_n++, (No[_n] = e.current), (e.current = t));
  }
  var Vt = {},
    Ue = Bt(Vt),
    Ge = Bt(!1),
    ln = Vt;
  function Mn(e, t) {
    var n = e.type.contextTypes;
    if (!n) return Vt;
    var r = e.stateNode;
    if (r && r.__reactInternalMemoizedUnmaskedChildContext === t)
      return r.__reactInternalMemoizedMaskedChildContext;
    var l = {},
      o;
    for (o in n) l[o] = t[o];
    return (
      r &&
        ((e = e.stateNode),
        (e.__reactInternalMemoizedUnmaskedChildContext = t),
        (e.__reactInternalMemoizedMaskedChildContext = l)),
      l
    );
  }
  function Ye(e) {
    return ((e = e.childContextTypes), e != null);
  }
  function br() {
    (ce(Ge), ce(Ue));
  }
  function su(e, t, n) {
    if (Ue.current !== Vt) throw Error(f(168));
    (se(Ue, t), se(Ge, n));
  }
  function uu(e, t, n) {
    var r = e.stateNode;
    if (((t = t.childContextTypes), typeof r.getChildContext != "function"))
      return n;
    r = r.getChildContext();
    for (var l in r) if (!(l in t)) throw Error(f(108, ie(e) || "Unknown", l));
    return L({}, n, r);
  }
  function el(e) {
    return (
      (e =
        ((e = e.stateNode) && e.__reactInternalMemoizedMergedChildContext) ||
        Vt),
      (ln = Ue.current),
      se(Ue, e),
      se(Ge, Ge.current),
      !0
    );
  }
  function au(e, t, n) {
    var r = e.stateNode;
    if (!r) throw Error(f(169));
    (n
      ? ((e = uu(e, t, ln)),
        (r.__reactInternalMemoizedMergedChildContext = e),
        ce(Ge),
        ce(Ue),
        se(Ue, e))
      : ce(Ge),
      se(Ge, n));
  }
  var Et = null,
    tl = !1,
    Ro = !1;
  function cu(e) {
    Et === null ? (Et = [e]) : Et.push(e);
  }
  function Ef(e) {
    ((tl = !0), cu(e));
  }
  function Qt() {
    if (!Ro && Et !== null) {
      Ro = !0;
      var e = 0,
        t = ee;
      try {
        var n = Et;
        for (ee = 1; e < n.length; e++) {
          var r = n[e];
          do r = r(!0);
          while (r !== null);
        }
        ((Et = null), (tl = !1));
      } catch (l) {
        throw (Et !== null && (Et = Et.slice(e + 1)), ds(bl, Qt), l);
      } finally {
        ((ee = t), (Ro = !1));
      }
    }
    return null;
  }
  var Pn = [],
    Ln = 0,
    nl = null,
    rl = 0,
    st = [],
    ut = 0,
    on = null,
    _t = 1,
    Mt = "";
  function sn(e, t) {
    ((Pn[Ln++] = rl), (Pn[Ln++] = nl), (nl = e), (rl = t));
  }
  function fu(e, t, n) {
    ((st[ut++] = _t), (st[ut++] = Mt), (st[ut++] = on), (on = e));
    var r = _t;
    e = Mt;
    var l = 32 - pt(r) - 1;
    ((r &= ~(1 << l)), (n += 1));
    var o = 32 - pt(t) + l;
    if (30 < o) {
      var i = l - (l % 5);
      ((o = (r & ((1 << i) - 1)).toString(32)),
        (r >>= i),
        (l -= i),
        (_t = (1 << (32 - pt(t) + l)) | (n << l) | r),
        (Mt = o + e));
    } else ((_t = (1 << o) | (n << l) | r), (Mt = e));
  }
  function To(e) {
    e.return !== null && (sn(e, 1), fu(e, 1, 0));
  }
  function Oo(e) {
    for (; e === nl;)
      ((nl = Pn[--Ln]), (Pn[Ln] = null), (rl = Pn[--Ln]), (Pn[Ln] = null));
    for (; e === on;)
      ((on = st[--ut]),
        (st[ut] = null),
        (Mt = st[--ut]),
        (st[ut] = null),
        (_t = st[--ut]),
        (st[ut] = null));
  }
  var rt = null,
    lt = null,
    he = !1,
    mt = null;
  function du(e, t) {
    var n = dt(5, null, null, 0);
    ((n.elementType = "DELETED"),
      (n.stateNode = t),
      (n.return = e),
      (t = e.deletions),
      t === null ? ((e.deletions = [n]), (e.flags |= 16)) : t.push(n));
  }
  function pu(e, t) {
    switch (e.tag) {
      case 5:
        var n = e.type;
        return (
          (t =
            t.nodeType !== 1 || n.toLowerCase() !== t.nodeName.toLowerCase()
              ? null
              : t),
          t !== null
            ? ((e.stateNode = t), (rt = e), (lt = $t(t.firstChild)), !0)
            : !1
        );
      case 6:
        return (
          (t = e.pendingProps === "" || t.nodeType !== 3 ? null : t),
          t !== null ? ((e.stateNode = t), (rt = e), (lt = null), !0) : !1
        );
      case 13:
        return (
          (t = t.nodeType !== 8 ? null : t),
          t !== null
            ? ((n = on !== null ? { id: _t, overflow: Mt } : null),
              (e.memoizedState = {
                dehydrated: t,
                treeContext: n,
                retryLane: 1073741824,
              }),
              (n = dt(18, null, null, 0)),
              (n.stateNode = t),
              (n.return = e),
              (e.child = n),
              (rt = e),
              (lt = null),
              !0)
            : !1
        );
      default:
        return !1;
    }
  }
  function Do(e) {
    return (e.mode & 1) !== 0 && (e.flags & 128) === 0;
  }
  function Io(e) {
    if (he) {
      var t = lt;
      if (t) {
        var n = t;
        if (!pu(e, t)) {
          if (Do(e)) throw Error(f(418));
          t = $t(n.nextSibling);
          var r = rt;
          t && pu(e, t)
            ? du(r, n)
            : ((e.flags = (e.flags & -4097) | 2), (he = !1), (rt = e));
        }
      } else {
        if (Do(e)) throw Error(f(418));
        ((e.flags = (e.flags & -4097) | 2), (he = !1), (rt = e));
      }
    }
  }
  function hu(e) {
    for (
      e = e.return;
      e !== null && e.tag !== 5 && e.tag !== 3 && e.tag !== 13;
    )
      e = e.return;
    rt = e;
  }
  function ll(e) {
    if (e !== rt) return !1;
    if (!he) return (hu(e), (he = !0), !1);
    var t;
    if (
      ((t = e.tag !== 3) &&
        !(t = e.tag !== 5) &&
        ((t = e.type),
        (t = t !== "head" && t !== "body" && !_o(e.type, e.memoizedProps))),
      t && (t = lt))
    ) {
      if (Do(e)) throw (mu(), Error(f(418)));
      for (; t;) (du(e, t), (t = $t(t.nextSibling)));
    }
    if ((hu(e), e.tag === 13)) {
      if (((e = e.memoizedState), (e = e !== null ? e.dehydrated : null), !e))
        throw Error(f(317));
      e: {
        for (e = e.nextSibling, t = 0; e;) {
          if (e.nodeType === 8) {
            var n = e.data;
            if (n === "/$") {
              if (t === 0) {
                lt = $t(e.nextSibling);
                break e;
              }
              t--;
            } else (n !== "$" && n !== "$!" && n !== "$?") || t++;
          }
          e = e.nextSibling;
        }
        lt = null;
      }
    } else lt = rt ? $t(e.stateNode.nextSibling) : null;
    return !0;
  }
  function mu() {
    for (var e = lt; e;) e = $t(e.nextSibling);
  }
  function Nn() {
    ((lt = rt = null), (he = !1));
  }
  function Fo(e) {
    mt === null ? (mt = [e]) : mt.push(e);
  }
  var _f = te.ReactCurrentBatchConfig;
  function dr(e, t, n) {
    if (
      ((e = n.ref),
      e !== null && typeof e != "function" && typeof e != "object")
    ) {
      if (n._owner) {
        if (((n = n._owner), n)) {
          if (n.tag !== 1) throw Error(f(309));
          var r = n.stateNode;
        }
        if (!r) throw Error(f(147, e));
        var l = r,
          o = "" + e;
        return t !== null &&
          t.ref !== null &&
          typeof t.ref == "function" &&
          t.ref._stringRef === o
          ? t.ref
          : ((t = function (i) {
              var u = l.refs;
              i === null ? delete u[o] : (u[o] = i);
            }),
            (t._stringRef = o),
            t);
      }
      if (typeof e != "string") throw Error(f(284));
      if (!n._owner) throw Error(f(290, e));
    }
    return e;
  }
  function ol(e, t) {
    throw (
      (e = Object.prototype.toString.call(t)),
      Error(
        f(
          31,
          e === "[object Object]"
            ? "object with keys {" + Object.keys(t).join(", ") + "}"
            : e,
        ),
      )
    );
  }
  function yu(e) {
    var t = e._init;
    return t(e._payload);
  }
  function gu(e) {
    function t(h, c) {
      if (e) {
        var m = h.deletions;
        m === null ? ((h.deletions = [c]), (h.flags |= 16)) : m.push(c);
      }
    }
    function n(h, c) {
      if (!e) return null;
      for (; c !== null;) (t(h, c), (c = c.sibling));
      return null;
    }
    function r(h, c) {
      for (h = new Map(); c !== null;)
        (c.key !== null ? h.set(c.key, c) : h.set(c.index, c), (c = c.sibling));
      return h;
    }
    function l(h, c) {
      return ((h = bt(h, c)), (h.index = 0), (h.sibling = null), h);
    }
    function o(h, c, m) {
      return (
        (h.index = m),
        e
          ? ((m = h.alternate),
            m !== null
              ? ((m = m.index), m < c ? ((h.flags |= 2), c) : m)
              : ((h.flags |= 2), c))
          : ((h.flags |= 1048576), c)
      );
    }
    function i(h) {
      return (e && h.alternate === null && (h.flags |= 2), h);
    }
    function u(h, c, m, z) {
      return c === null || c.tag !== 6
        ? ((c = Mi(m, h.mode, z)), (c.return = h), c)
        : ((c = l(c, m)), (c.return = h), c);
    }
    function a(h, c, m, z) {
      var T = m.type;
      return T === ue
        ? w(h, c, m.props.children, z, m.key)
        : c !== null &&
            (c.elementType === T ||
              (typeof T == "object" &&
                T !== null &&
                T.$$typeof === ve &&
                yu(T) === c.type))
          ? ((z = l(c, m.props)), (z.ref = dr(h, c, m)), (z.return = h), z)
          : ((z = Pl(m.type, m.key, m.props, null, h.mode, z)),
            (z.ref = dr(h, c, m)),
            (z.return = h),
            z);
    }
    function y(h, c, m, z) {
      return c === null ||
        c.tag !== 4 ||
        c.stateNode.containerInfo !== m.containerInfo ||
        c.stateNode.implementation !== m.implementation
        ? ((c = Pi(m, h.mode, z)), (c.return = h), c)
        : ((c = l(c, m.children || [])), (c.return = h), c);
    }
    function w(h, c, m, z, T) {
      return c === null || c.tag !== 7
        ? ((c = mn(m, h.mode, z, T)), (c.return = h), c)
        : ((c = l(c, m)), (c.return = h), c);
    }
    function S(h, c, m) {
      if ((typeof c == "string" && c !== "") || typeof c == "number")
        return ((c = Mi("" + c, h.mode, m)), (c.return = h), c);
      if (typeof c == "object" && c !== null) {
        switch (c.$$typeof) {
          case fe:
            return (
              (m = Pl(c.type, c.key, c.props, null, h.mode, m)),
              (m.ref = dr(h, null, c)),
              (m.return = h),
              m
            );
          case ne:
            return ((c = Pi(c, h.mode, m)), (c.return = h), c);
          case ve:
            var z = c._init;
            return S(h, z(c._payload), m);
        }
        if (Hn(c) || F(c))
          return ((c = mn(c, h.mode, m, null)), (c.return = h), c);
        ol(h, c);
      }
      return null;
    }
    function x(h, c, m, z) {
      var T = c !== null ? c.key : null;
      if ((typeof m == "string" && m !== "") || typeof m == "number")
        return T !== null ? null : u(h, c, "" + m, z);
      if (typeof m == "object" && m !== null) {
        switch (m.$$typeof) {
          case fe:
            return m.key === T ? a(h, c, m, z) : null;
          case ne:
            return m.key === T ? y(h, c, m, z) : null;
          case ve:
            return ((T = m._init), x(h, c, T(m._payload), z));
        }
        if (Hn(m) || F(m)) return T !== null ? null : w(h, c, m, z, null);
        ol(h, m);
      }
      return null;
    }
    function _(h, c, m, z, T) {
      if ((typeof z == "string" && z !== "") || typeof z == "number")
        return ((h = h.get(m) || null), u(c, h, "" + z, T));
      if (typeof z == "object" && z !== null) {
        switch (z.$$typeof) {
          case fe:
            return (
              (h = h.get(z.key === null ? m : z.key) || null),
              a(c, h, z, T)
            );
          case ne:
            return (
              (h = h.get(z.key === null ? m : z.key) || null),
              y(c, h, z, T)
            );
          case ve:
            var D = z._init;
            return _(h, c, m, D(z._payload), T);
        }
        if (Hn(z) || F(z)) return ((h = h.get(m) || null), w(c, h, z, T, null));
        ol(c, z);
      }
      return null;
    }
    function N(h, c, m, z) {
      for (
        var T = null, D = null, I = c, A = (c = 0), Re = null;
        I !== null && A < m.length;
        A++
      ) {
        I.index > A ? ((Re = I), (I = null)) : (Re = I.sibling);
        var X = x(h, I, m[A], z);
        if (X === null) {
          I === null && (I = Re);
          break;
        }
        (e && I && X.alternate === null && t(h, I),
          (c = o(X, c, A)),
          D === null ? (T = X) : (D.sibling = X),
          (D = X),
          (I = Re));
      }
      if (A === m.length) return (n(h, I), he && sn(h, A), T);
      if (I === null) {
        for (; A < m.length; A++)
          ((I = S(h, m[A], z)),
            I !== null &&
              ((c = o(I, c, A)),
              D === null ? (T = I) : (D.sibling = I),
              (D = I)));
        return (he && sn(h, A), T);
      }
      for (I = r(h, I); A < m.length; A++)
        ((Re = _(I, h, A, m[A], z)),
          Re !== null &&
            (e &&
              Re.alternate !== null &&
              I.delete(Re.key === null ? A : Re.key),
            (c = o(Re, c, A)),
            D === null ? (T = Re) : (D.sibling = Re),
            (D = Re)));
      return (
        e &&
          I.forEach(function (en) {
            return t(h, en);
          }),
        he && sn(h, A),
        T
      );
    }
    function R(h, c, m, z) {
      var T = F(m);
      if (typeof T != "function") throw Error(f(150));
      if (((m = T.call(m)), m == null)) throw Error(f(151));
      for (
        var D = (T = null), I = c, A = (c = 0), Re = null, X = m.next();
        I !== null && !X.done;
        A++, X = m.next()
      ) {
        I.index > A ? ((Re = I), (I = null)) : (Re = I.sibling);
        var en = x(h, I, X.value, z);
        if (en === null) {
          I === null && (I = Re);
          break;
        }
        (e && I && en.alternate === null && t(h, I),
          (c = o(en, c, A)),
          D === null ? (T = en) : (D.sibling = en),
          (D = en),
          (I = Re));
      }
      if (X.done) return (n(h, I), he && sn(h, A), T);
      if (I === null) {
        for (; !X.done; A++, X = m.next())
          ((X = S(h, X.value, z)),
            X !== null &&
              ((c = o(X, c, A)),
              D === null ? (T = X) : (D.sibling = X),
              (D = X)));
        return (he && sn(h, A), T);
      }
      for (I = r(h, I); !X.done; A++, X = m.next())
        ((X = _(I, h, A, X.value, z)),
          X !== null &&
            (e && X.alternate !== null && I.delete(X.key === null ? A : X.key),
            (c = o(X, c, A)),
            D === null ? (T = X) : (D.sibling = X),
            (D = X)));
      return (
        e &&
          I.forEach(function (id) {
            return t(h, id);
          }),
        he && sn(h, A),
        T
      );
    }
    function Se(h, c, m, z) {
      if (
        (typeof m == "object" &&
          m !== null &&
          m.type === ue &&
          m.key === null &&
          (m = m.props.children),
        typeof m == "object" && m !== null)
      ) {
        switch (m.$$typeof) {
          case fe:
            e: {
              for (var T = m.key, D = c; D !== null;) {
                if (D.key === T) {
                  if (((T = m.type), T === ue)) {
                    if (D.tag === 7) {
                      (n(h, D.sibling),
                        (c = l(D, m.props.children)),
                        (c.return = h),
                        (h = c));
                      break e;
                    }
                  } else if (
                    D.elementType === T ||
                    (typeof T == "object" &&
                      T !== null &&
                      T.$$typeof === ve &&
                      yu(T) === D.type)
                  ) {
                    (n(h, D.sibling),
                      (c = l(D, m.props)),
                      (c.ref = dr(h, D, m)),
                      (c.return = h),
                      (h = c));
                    break e;
                  }
                  n(h, D);
                  break;
                } else t(h, D);
                D = D.sibling;
              }
              m.type === ue
                ? ((c = mn(m.props.children, h.mode, z, m.key)),
                  (c.return = h),
                  (h = c))
                : ((z = Pl(m.type, m.key, m.props, null, h.mode, z)),
                  (z.ref = dr(h, c, m)),
                  (z.return = h),
                  (h = z));
            }
            return i(h);
          case ne:
            e: {
              for (D = m.key; c !== null;) {
                if (c.key === D)
                  if (
                    c.tag === 4 &&
                    c.stateNode.containerInfo === m.containerInfo &&
                    c.stateNode.implementation === m.implementation
                  ) {
                    (n(h, c.sibling),
                      (c = l(c, m.children || [])),
                      (c.return = h),
                      (h = c));
                    break e;
                  } else {
                    n(h, c);
                    break;
                  }
                else t(h, c);
                c = c.sibling;
              }
              ((c = Pi(m, h.mode, z)), (c.return = h), (h = c));
            }
            return i(h);
          case ve:
            return ((D = m._init), Se(h, c, D(m._payload), z));
        }
        if (Hn(m)) return N(h, c, m, z);
        if (F(m)) return R(h, c, m, z);
        ol(h, m);
      }
      return (typeof m == "string" && m !== "") || typeof m == "number"
        ? ((m = "" + m),
          c !== null && c.tag === 6
            ? (n(h, c.sibling), (c = l(c, m)), (c.return = h), (h = c))
            : (n(h, c), (c = Mi(m, h.mode, z)), (c.return = h), (h = c)),
          i(h))
        : n(h, c);
    }
    return Se;
  }
  var Rn = gu(!0),
    vu = gu(!1),
    il = Bt(null),
    sl = null,
    Tn = null,
    Ao = null;
  function Uo() {
    Ao = Tn = sl = null;
  }
  function Wo(e) {
    var t = il.current;
    (ce(il), (e._currentValue = t));
  }
  function Ho(e, t, n) {
    for (; e !== null;) {
      var r = e.alternate;
      if (
        ((e.childLanes & t) !== t
          ? ((e.childLanes |= t), r !== null && (r.childLanes |= t))
          : r !== null && (r.childLanes & t) !== t && (r.childLanes |= t),
        e === n)
      )
        break;
      e = e.return;
    }
  }
  function On(e, t) {
    ((sl = e),
      (Ao = Tn = null),
      (e = e.dependencies),
      e !== null &&
        e.firstContext !== null &&
        ((e.lanes & t) !== 0 && (Xe = !0), (e.firstContext = null)));
  }
  function at(e) {
    var t = e._currentValue;
    if (Ao !== e)
      if (((e = { context: e, memoizedValue: t, next: null }), Tn === null)) {
        if (sl === null) throw Error(f(308));
        ((Tn = e), (sl.dependencies = { lanes: 0, firstContext: e }));
      } else Tn = Tn.next = e;
    return t;
  }
  var un = null;
  function $o(e) {
    un === null ? (un = [e]) : un.push(e);
  }
  function xu(e, t, n, r) {
    var l = t.interleaved;
    return (
      l === null ? ((n.next = n), $o(t)) : ((n.next = l.next), (l.next = n)),
      (t.interleaved = n),
      Pt(e, r)
    );
  }
  function Pt(e, t) {
    e.lanes |= t;
    var n = e.alternate;
    for (n !== null && (n.lanes |= t), n = e, e = e.return; e !== null;)
      ((e.childLanes |= t),
        (n = e.alternate),
        n !== null && (n.childLanes |= t),
        (n = e),
        (e = e.return));
    return n.tag === 3 ? n.stateNode : null;
  }
  var Zt = !1;
  function Bo(e) {
    e.updateQueue = {
      baseState: e.memoizedState,
      firstBaseUpdate: null,
      lastBaseUpdate: null,
      shared: { pending: null, interleaved: null, lanes: 0 },
      effects: null,
    };
  }
  function ku(e, t) {
    ((e = e.updateQueue),
      t.updateQueue === e &&
        (t.updateQueue = {
          baseState: e.baseState,
          firstBaseUpdate: e.firstBaseUpdate,
          lastBaseUpdate: e.lastBaseUpdate,
          shared: e.shared,
          effects: e.effects,
        }));
  }
  function Lt(e, t) {
    return {
      eventTime: e,
      lane: t,
      tag: 0,
      payload: null,
      callback: null,
      next: null,
    };
  }
  function Kt(e, t, n) {
    var r = e.updateQueue;
    if (r === null) return null;
    if (((r = r.shared), (Z & 2) !== 0)) {
      var l = r.pending;
      return (
        l === null ? (t.next = t) : ((t.next = l.next), (l.next = t)),
        (r.pending = t),
        Pt(e, n)
      );
    }
    return (
      (l = r.interleaved),
      l === null ? ((t.next = t), $o(r)) : ((t.next = l.next), (l.next = t)),
      (r.interleaved = t),
      Pt(e, n)
    );
  }
  function ul(e, t, n) {
    if (
      ((t = t.updateQueue), t !== null && ((t = t.shared), (n & 4194240) !== 0))
    ) {
      var r = t.lanes;
      ((r &= e.pendingLanes), (n |= r), (t.lanes = n), no(e, n));
    }
  }
  function wu(e, t) {
    var n = e.updateQueue,
      r = e.alternate;
    if (r !== null && ((r = r.updateQueue), n === r)) {
      var l = null,
        o = null;
      if (((n = n.firstBaseUpdate), n !== null)) {
        do {
          var i = {
            eventTime: n.eventTime,
            lane: n.lane,
            tag: n.tag,
            payload: n.payload,
            callback: n.callback,
            next: null,
          };
          (o === null ? (l = o = i) : (o = o.next = i), (n = n.next));
        } while (n !== null);
        o === null ? (l = o = t) : (o = o.next = t);
      } else l = o = t;
      ((n = {
        baseState: r.baseState,
        firstBaseUpdate: l,
        lastBaseUpdate: o,
        shared: r.shared,
        effects: r.effects,
      }),
        (e.updateQueue = n));
      return;
    }
    ((e = n.lastBaseUpdate),
      e === null ? (n.firstBaseUpdate = t) : (e.next = t),
      (n.lastBaseUpdate = t));
  }
  function al(e, t, n, r) {
    var l = e.updateQueue;
    Zt = !1;
    var o = l.firstBaseUpdate,
      i = l.lastBaseUpdate,
      u = l.shared.pending;
    if (u !== null) {
      l.shared.pending = null;
      var a = u,
        y = a.next;
      ((a.next = null), i === null ? (o = y) : (i.next = y), (i = a));
      var w = e.alternate;
      w !== null &&
        ((w = w.updateQueue),
        (u = w.lastBaseUpdate),
        u !== i &&
          (u === null ? (w.firstBaseUpdate = y) : (u.next = y),
          (w.lastBaseUpdate = a)));
    }
    if (o !== null) {
      var S = l.baseState;
      ((i = 0), (w = y = a = null), (u = o));
      do {
        var x = u.lane,
          _ = u.eventTime;
        if ((r & x) === x) {
          w !== null &&
            (w = w.next =
              {
                eventTime: _,
                lane: 0,
                tag: u.tag,
                payload: u.payload,
                callback: u.callback,
                next: null,
              });
          e: {
            var N = e,
              R = u;
            switch (((x = t), (_ = n), R.tag)) {
              case 1:
                if (((N = R.payload), typeof N == "function")) {
                  S = N.call(_, S, x);
                  break e;
                }
                S = N;
                break e;
              case 3:
                N.flags = (N.flags & -65537) | 128;
              case 0:
                if (
                  ((N = R.payload),
                  (x = typeof N == "function" ? N.call(_, S, x) : N),
                  x == null)
                )
                  break e;
                S = L({}, S, x);
                break e;
              case 2:
                Zt = !0;
            }
          }
          u.callback !== null &&
            u.lane !== 0 &&
            ((e.flags |= 64),
            (x = l.effects),
            x === null ? (l.effects = [u]) : x.push(u));
        } else
          ((_ = {
            eventTime: _,
            lane: x,
            tag: u.tag,
            payload: u.payload,
            callback: u.callback,
            next: null,
          }),
            w === null ? ((y = w = _), (a = S)) : (w = w.next = _),
            (i |= x));
        if (((u = u.next), u === null)) {
          if (((u = l.shared.pending), u === null)) break;
          ((x = u),
            (u = x.next),
            (x.next = null),
            (l.lastBaseUpdate = x),
            (l.shared.pending = null));
        }
      } while (!0);
      if (
        (w === null && (a = S),
        (l.baseState = a),
        (l.firstBaseUpdate = y),
        (l.lastBaseUpdate = w),
        (t = l.shared.interleaved),
        t !== null)
      ) {
        l = t;
        do ((i |= l.lane), (l = l.next));
        while (l !== t);
      } else o === null && (l.shared.lanes = 0);
      ((fn |= i), (e.lanes = i), (e.memoizedState = S));
    }
  }
  function Su(e, t, n) {
    if (((e = t.effects), (t.effects = null), e !== null))
      for (t = 0; t < e.length; t++) {
        var r = e[t],
          l = r.callback;
        if (l !== null) {
          if (((r.callback = null), (r = n), typeof l != "function"))
            throw Error(f(191, l));
          l.call(r);
        }
      }
  }
  var pr = {},
    St = Bt(pr),
    hr = Bt(pr),
    mr = Bt(pr);
  function an(e) {
    if (e === pr) throw Error(f(174));
    return e;
  }
  function Vo(e, t) {
    switch ((se(mr, t), se(hr, e), se(St, pr), (e = t.nodeType), e)) {
      case 9:
      case 11:
        t = (t = t.documentElement) ? t.namespaceURI : Vl(null, "");
        break;
      default:
        ((e = e === 8 ? t.parentNode : t),
          (t = e.namespaceURI || null),
          (e = e.tagName),
          (t = Vl(t, e)));
    }
    (ce(St), se(St, t));
  }
  function Dn() {
    (ce(St), ce(hr), ce(mr));
  }
  function ju(e) {
    an(mr.current);
    var t = an(St.current),
      n = Vl(t, e.type);
    t !== n && (se(hr, e), se(St, n));
  }
  function Qo(e) {
    hr.current === e && (ce(St), ce(hr));
  }
  var me = Bt(0);
  function cl(e) {
    for (var t = e; t !== null;) {
      if (t.tag === 13) {
        var n = t.memoizedState;
        if (
          n !== null &&
          ((n = n.dehydrated), n === null || n.data === "$?" || n.data === "$!")
        )
          return t;
      } else if (t.tag === 19 && t.memoizedProps.revealOrder !== void 0) {
        if ((t.flags & 128) !== 0) return t;
      } else if (t.child !== null) {
        ((t.child.return = t), (t = t.child));
        continue;
      }
      if (t === e) break;
      for (; t.sibling === null;) {
        if (t.return === null || t.return === e) return null;
        t = t.return;
      }
      ((t.sibling.return = t.return), (t = t.sibling));
    }
    return null;
  }
  var Zo = [];
  function Ko() {
    for (var e = 0; e < Zo.length; e++)
      Zo[e]._workInProgressVersionPrimary = null;
    Zo.length = 0;
  }
  var fl = te.ReactCurrentDispatcher,
    Go = te.ReactCurrentBatchConfig,
    cn = 0,
    ye = null,
    _e = null,
    Le = null,
    dl = !1,
    yr = !1,
    gr = 0,
    Mf = 0;
  function We() {
    throw Error(f(321));
  }
  function Yo(e, t) {
    if (t === null) return !1;
    for (var n = 0; n < t.length && n < e.length; n++)
      if (!ht(e[n], t[n])) return !1;
    return !0;
  }
  function Xo(e, t, n, r, l, o) {
    if (
      ((cn = o),
      (ye = t),
      (t.memoizedState = null),
      (t.updateQueue = null),
      (t.lanes = 0),
      (fl.current = e === null || e.memoizedState === null ? Rf : Tf),
      (e = n(r, l)),
      yr)
    ) {
      o = 0;
      do {
        if (((yr = !1), (gr = 0), 25 <= o)) throw Error(f(301));
        ((o += 1),
          (Le = _e = null),
          (t.updateQueue = null),
          (fl.current = Of),
          (e = n(r, l)));
      } while (yr);
    }
    if (
      ((fl.current = ml),
      (t = _e !== null && _e.next !== null),
      (cn = 0),
      (Le = _e = ye = null),
      (dl = !1),
      t)
    )
      throw Error(f(300));
    return e;
  }
  function qo() {
    var e = gr !== 0;
    return ((gr = 0), e);
  }
  function jt() {
    var e = {
      memoizedState: null,
      baseState: null,
      baseQueue: null,
      queue: null,
      next: null,
    };
    return (Le === null ? (ye.memoizedState = Le = e) : (Le = Le.next = e), Le);
  }
  function ct() {
    if (_e === null) {
      var e = ye.alternate;
      e = e !== null ? e.memoizedState : null;
    } else e = _e.next;
    var t = Le === null ? ye.memoizedState : Le.next;
    if (t !== null) ((Le = t), (_e = e));
    else {
      if (e === null) throw Error(f(310));
      ((_e = e),
        (e = {
          memoizedState: _e.memoizedState,
          baseState: _e.baseState,
          baseQueue: _e.baseQueue,
          queue: _e.queue,
          next: null,
        }),
        Le === null ? (ye.memoizedState = Le = e) : (Le = Le.next = e));
    }
    return Le;
  }
  function vr(e, t) {
    return typeof t == "function" ? t(e) : t;
  }
  function Jo(e) {
    var t = ct(),
      n = t.queue;
    if (n === null) throw Error(f(311));
    n.lastRenderedReducer = e;
    var r = _e,
      l = r.baseQueue,
      o = n.pending;
    if (o !== null) {
      if (l !== null) {
        var i = l.next;
        ((l.next = o.next), (o.next = i));
      }
      ((r.baseQueue = l = o), (n.pending = null));
    }
    if (l !== null) {
      ((o = l.next), (r = r.baseState));
      var u = (i = null),
        a = null,
        y = o;
      do {
        var w = y.lane;
        if ((cn & w) === w)
          (a !== null &&
            (a = a.next =
              {
                lane: 0,
                action: y.action,
                hasEagerState: y.hasEagerState,
                eagerState: y.eagerState,
                next: null,
              }),
            (r = y.hasEagerState ? y.eagerState : e(r, y.action)));
        else {
          var S = {
            lane: w,
            action: y.action,
            hasEagerState: y.hasEagerState,
            eagerState: y.eagerState,
            next: null,
          };
          (a === null ? ((u = a = S), (i = r)) : (a = a.next = S),
            (ye.lanes |= w),
            (fn |= w));
        }
        y = y.next;
      } while (y !== null && y !== o);
      (a === null ? (i = r) : (a.next = u),
        ht(r, t.memoizedState) || (Xe = !0),
        (t.memoizedState = r),
        (t.baseState = i),
        (t.baseQueue = a),
        (n.lastRenderedState = r));
    }
    if (((e = n.interleaved), e !== null)) {
      l = e;
      do ((o = l.lane), (ye.lanes |= o), (fn |= o), (l = l.next));
      while (l !== e);
    } else l === null && (n.lanes = 0);
    return [t.memoizedState, n.dispatch];
  }
  function bo(e) {
    var t = ct(),
      n = t.queue;
    if (n === null) throw Error(f(311));
    n.lastRenderedReducer = e;
    var r = n.dispatch,
      l = n.pending,
      o = t.memoizedState;
    if (l !== null) {
      n.pending = null;
      var i = (l = l.next);
      do ((o = e(o, i.action)), (i = i.next));
      while (i !== l);
      (ht(o, t.memoizedState) || (Xe = !0),
        (t.memoizedState = o),
        t.baseQueue === null && (t.baseState = o),
        (n.lastRenderedState = o));
    }
    return [o, r];
  }
  function zu() {}
  function Cu(e, t) {
    var n = ye,
      r = ct(),
      l = t(),
      o = !ht(r.memoizedState, l);
    if (
      (o && ((r.memoizedState = l), (Xe = !0)),
      (r = r.queue),
      ei(Mu.bind(null, n, r, e), [e]),
      r.getSnapshot !== t || o || (Le !== null && Le.memoizedState.tag & 1))
    ) {
      if (
        ((n.flags |= 2048),
        xr(9, _u.bind(null, n, r, l, t), void 0, null),
        Ne === null)
      )
        throw Error(f(349));
      (cn & 30) !== 0 || Eu(n, t, l);
    }
    return l;
  }
  function Eu(e, t, n) {
    ((e.flags |= 16384),
      (e = { getSnapshot: t, value: n }),
      (t = ye.updateQueue),
      t === null
        ? ((t = { lastEffect: null, stores: null }),
          (ye.updateQueue = t),
          (t.stores = [e]))
        : ((n = t.stores), n === null ? (t.stores = [e]) : n.push(e)));
  }
  function _u(e, t, n, r) {
    ((t.value = n), (t.getSnapshot = r), Pu(t) && Lu(e));
  }
  function Mu(e, t, n) {
    return n(function () {
      Pu(t) && Lu(e);
    });
  }
  function Pu(e) {
    var t = e.getSnapshot;
    e = e.value;
    try {
      var n = t();
      return !ht(e, n);
    } catch {
      return !0;
    }
  }
  function Lu(e) {
    var t = Pt(e, 1);
    t !== null && xt(t, e, 1, -1);
  }
  function Nu(e) {
    var t = jt();
    return (
      typeof e == "function" && (e = e()),
      (t.memoizedState = t.baseState = e),
      (e = {
        pending: null,
        interleaved: null,
        lanes: 0,
        dispatch: null,
        lastRenderedReducer: vr,
        lastRenderedState: e,
      }),
      (t.queue = e),
      (e = e.dispatch = Nf.bind(null, ye, e)),
      [t.memoizedState, e]
    );
  }
  function xr(e, t, n, r) {
    return (
      (e = { tag: e, create: t, destroy: n, deps: r, next: null }),
      (t = ye.updateQueue),
      t === null
        ? ((t = { lastEffect: null, stores: null }),
          (ye.updateQueue = t),
          (t.lastEffect = e.next = e))
        : ((n = t.lastEffect),
          n === null
            ? (t.lastEffect = e.next = e)
            : ((r = n.next), (n.next = e), (e.next = r), (t.lastEffect = e))),
      e
    );
  }
  function Ru() {
    return ct().memoizedState;
  }
  function pl(e, t, n, r) {
    var l = jt();
    ((ye.flags |= e),
      (l.memoizedState = xr(1 | t, n, void 0, r === void 0 ? null : r)));
  }
  function hl(e, t, n, r) {
    var l = ct();
    r = r === void 0 ? null : r;
    var o = void 0;
    if (_e !== null) {
      var i = _e.memoizedState;
      if (((o = i.destroy), r !== null && Yo(r, i.deps))) {
        l.memoizedState = xr(t, n, o, r);
        return;
      }
    }
    ((ye.flags |= e), (l.memoizedState = xr(1 | t, n, o, r)));
  }
  function Tu(e, t) {
    return pl(8390656, 8, e, t);
  }
  function ei(e, t) {
    return hl(2048, 8, e, t);
  }
  function Ou(e, t) {
    return hl(4, 2, e, t);
  }
  function Du(e, t) {
    return hl(4, 4, e, t);
  }
  function Iu(e, t) {
    if (typeof t == "function")
      return (
        (e = e()),
        t(e),
        function () {
          t(null);
        }
      );
    if (t != null)
      return (
        (e = e()),
        (t.current = e),
        function () {
          t.current = null;
        }
      );
  }
  function Fu(e, t, n) {
    return (
      (n = n != null ? n.concat([e]) : null),
      hl(4, 4, Iu.bind(null, t, e), n)
    );
  }
  function ti() {}
  function Au(e, t) {
    var n = ct();
    t = t === void 0 ? null : t;
    var r = n.memoizedState;
    return r !== null && t !== null && Yo(t, r[1])
      ? r[0]
      : ((n.memoizedState = [e, t]), e);
  }
  function Uu(e, t) {
    var n = ct();
    t = t === void 0 ? null : t;
    var r = n.memoizedState;
    return r !== null && t !== null && Yo(t, r[1])
      ? r[0]
      : ((e = e()), (n.memoizedState = [e, t]), e);
  }
  function Wu(e, t, n) {
    return (cn & 21) === 0
      ? (e.baseState && ((e.baseState = !1), (Xe = !0)), (e.memoizedState = n))
      : (ht(n, t) ||
          ((n = ys()), (ye.lanes |= n), (fn |= n), (e.baseState = !0)),
        t);
  }
  function Pf(e, t) {
    var n = ee;
    ((ee = n !== 0 && 4 > n ? n : 4), e(!0));
    var r = Go.transition;
    Go.transition = {};
    try {
      (e(!1), t());
    } finally {
      ((ee = n), (Go.transition = r));
    }
  }
  function Hu() {
    return ct().memoizedState;
  }
  function Lf(e, t, n) {
    var r = qt(e);
    if (
      ((n = {
        lane: r,
        action: n,
        hasEagerState: !1,
        eagerState: null,
        next: null,
      }),
      $u(e))
    )
      Bu(t, n);
    else if (((n = xu(e, t, n, r)), n !== null)) {
      var l = Qe();
      (xt(n, e, r, l), Vu(n, t, r));
    }
  }
  function Nf(e, t, n) {
    var r = qt(e),
      l = {
        lane: r,
        action: n,
        hasEagerState: !1,
        eagerState: null,
        next: null,
      };
    if ($u(e)) Bu(t, l);
    else {
      var o = e.alternate;
      if (
        e.lanes === 0 &&
        (o === null || o.lanes === 0) &&
        ((o = t.lastRenderedReducer), o !== null)
      )
        try {
          var i = t.lastRenderedState,
            u = o(i, n);
          if (((l.hasEagerState = !0), (l.eagerState = u), ht(u, i))) {
            var a = t.interleaved;
            (a === null
              ? ((l.next = l), $o(t))
              : ((l.next = a.next), (a.next = l)),
              (t.interleaved = l));
            return;
          }
        } catch {
        } finally {
        }
      ((n = xu(e, t, l, r)),
        n !== null && ((l = Qe()), xt(n, e, r, l), Vu(n, t, r)));
    }
  }
  function $u(e) {
    var t = e.alternate;
    return e === ye || (t !== null && t === ye);
  }
  function Bu(e, t) {
    yr = dl = !0;
    var n = e.pending;
    (n === null ? (t.next = t) : ((t.next = n.next), (n.next = t)),
      (e.pending = t));
  }
  function Vu(e, t, n) {
    if ((n & 4194240) !== 0) {
      var r = t.lanes;
      ((r &= e.pendingLanes), (n |= r), (t.lanes = n), no(e, n));
    }
  }
  var ml = {
      readContext: at,
      useCallback: We,
      useContext: We,
      useEffect: We,
      useImperativeHandle: We,
      useInsertionEffect: We,
      useLayoutEffect: We,
      useMemo: We,
      useReducer: We,
      useRef: We,
      useState: We,
      useDebugValue: We,
      useDeferredValue: We,
      useTransition: We,
      useMutableSource: We,
      useSyncExternalStore: We,
      useId: We,
      unstable_isNewReconciler: !1,
    },
    Rf = {
      readContext: at,
      useCallback: function (e, t) {
        return ((jt().memoizedState = [e, t === void 0 ? null : t]), e);
      },
      useContext: at,
      useEffect: Tu,
      useImperativeHandle: function (e, t, n) {
        return (
          (n = n != null ? n.concat([e]) : null),
          pl(4194308, 4, Iu.bind(null, t, e), n)
        );
      },
      useLayoutEffect: function (e, t) {
        return pl(4194308, 4, e, t);
      },
      useInsertionEffect: function (e, t) {
        return pl(4, 2, e, t);
      },
      useMemo: function (e, t) {
        var n = jt();
        return (
          (t = t === void 0 ? null : t),
          (e = e()),
          (n.memoizedState = [e, t]),
          e
        );
      },
      useReducer: function (e, t, n) {
        var r = jt();
        return (
          (t = n !== void 0 ? n(t) : t),
          (r.memoizedState = r.baseState = t),
          (e = {
            pending: null,
            interleaved: null,
            lanes: 0,
            dispatch: null,
            lastRenderedReducer: e,
            lastRenderedState: t,
          }),
          (r.queue = e),
          (e = e.dispatch = Lf.bind(null, ye, e)),
          [r.memoizedState, e]
        );
      },
      useRef: function (e) {
        var t = jt();
        return ((e = { current: e }), (t.memoizedState = e));
      },
      useState: Nu,
      useDebugValue: ti,
      useDeferredValue: function (e) {
        return (jt().memoizedState = e);
      },
      useTransition: function () {
        var e = Nu(!1),
          t = e[0];
        return ((e = Pf.bind(null, e[1])), (jt().memoizedState = e), [t, e]);
      },
      useMutableSource: function () {},
      useSyncExternalStore: function (e, t, n) {
        var r = ye,
          l = jt();
        if (he) {
          if (n === void 0) throw Error(f(407));
          n = n();
        } else {
          if (((n = t()), Ne === null)) throw Error(f(349));
          (cn & 30) !== 0 || Eu(r, t, n);
        }
        l.memoizedState = n;
        var o = { value: n, getSnapshot: t };
        return (
          (l.queue = o),
          Tu(Mu.bind(null, r, o, e), [e]),
          (r.flags |= 2048),
          xr(9, _u.bind(null, r, o, n, t), void 0, null),
          n
        );
      },
      useId: function () {
        var e = jt(),
          t = Ne.identifierPrefix;
        if (he) {
          var n = Mt,
            r = _t;
          ((n = (r & ~(1 << (32 - pt(r) - 1))).toString(32) + n),
            (t = ":" + t + "R" + n),
            (n = gr++),
            0 < n && (t += "H" + n.toString(32)),
            (t += ":"));
        } else ((n = Mf++), (t = ":" + t + "r" + n.toString(32) + ":"));
        return (e.memoizedState = t);
      },
      unstable_isNewReconciler: !1,
    },
    Tf = {
      readContext: at,
      useCallback: Au,
      useContext: at,
      useEffect: ei,
      useImperativeHandle: Fu,
      useInsertionEffect: Ou,
      useLayoutEffect: Du,
      useMemo: Uu,
      useReducer: Jo,
      useRef: Ru,
      useState: function () {
        return Jo(vr);
      },
      useDebugValue: ti,
      useDeferredValue: function (e) {
        var t = ct();
        return Wu(t, _e.memoizedState, e);
      },
      useTransition: function () {
        var e = Jo(vr)[0],
          t = ct().memoizedState;
        return [e, t];
      },
      useMutableSource: zu,
      useSyncExternalStore: Cu,
      useId: Hu,
      unstable_isNewReconciler: !1,
    },
    Of = {
      readContext: at,
      useCallback: Au,
      useContext: at,
      useEffect: ei,
      useImperativeHandle: Fu,
      useInsertionEffect: Ou,
      useLayoutEffect: Du,
      useMemo: Uu,
      useReducer: bo,
      useRef: Ru,
      useState: function () {
        return bo(vr);
      },
      useDebugValue: ti,
      useDeferredValue: function (e) {
        var t = ct();
        return _e === null ? (t.memoizedState = e) : Wu(t, _e.memoizedState, e);
      },
      useTransition: function () {
        var e = bo(vr)[0],
          t = ct().memoizedState;
        return [e, t];
      },
      useMutableSource: zu,
      useSyncExternalStore: Cu,
      useId: Hu,
      unstable_isNewReconciler: !1,
    };
  function yt(e, t) {
    if (e && e.defaultProps) {
      ((t = L({}, t)), (e = e.defaultProps));
      for (var n in e) t[n] === void 0 && (t[n] = e[n]);
      return t;
    }
    return t;
  }
  function ni(e, t, n, r) {
    ((t = e.memoizedState),
      (n = n(r, t)),
      (n = n == null ? t : L({}, t, n)),
      (e.memoizedState = n),
      e.lanes === 0 && (e.updateQueue.baseState = n));
  }
  var yl = {
    isMounted: function (e) {
      return (e = e._reactInternals) ? nn(e) === e : !1;
    },
    enqueueSetState: function (e, t, n) {
      e = e._reactInternals;
      var r = Qe(),
        l = qt(e),
        o = Lt(r, l);
      ((o.payload = t),
        n != null && (o.callback = n),
        (t = Kt(e, o, l)),
        t !== null && (xt(t, e, l, r), ul(t, e, l)));
    },
    enqueueReplaceState: function (e, t, n) {
      e = e._reactInternals;
      var r = Qe(),
        l = qt(e),
        o = Lt(r, l);
      ((o.tag = 1),
        (o.payload = t),
        n != null && (o.callback = n),
        (t = Kt(e, o, l)),
        t !== null && (xt(t, e, l, r), ul(t, e, l)));
    },
    enqueueForceUpdate: function (e, t) {
      e = e._reactInternals;
      var n = Qe(),
        r = qt(e),
        l = Lt(n, r);
      ((l.tag = 2),
        t != null && (l.callback = t),
        (t = Kt(e, l, r)),
        t !== null && (xt(t, e, r, n), ul(t, e, r)));
    },
  };
  function Qu(e, t, n, r, l, o, i) {
    return (
      (e = e.stateNode),
      typeof e.shouldComponentUpdate == "function"
        ? e.shouldComponentUpdate(r, o, i)
        : t.prototype && t.prototype.isPureReactComponent
          ? !or(n, r) || !or(l, o)
          : !0
    );
  }
  function Zu(e, t, n) {
    var r = !1,
      l = Vt,
      o = t.contextType;
    return (
      typeof o == "object" && o !== null
        ? (o = at(o))
        : ((l = Ye(t) ? ln : Ue.current),
          (r = t.contextTypes),
          (o = (r = r != null) ? Mn(e, l) : Vt)),
      (t = new t(n, o)),
      (e.memoizedState =
        t.state !== null && t.state !== void 0 ? t.state : null),
      (t.updater = yl),
      (e.stateNode = t),
      (t._reactInternals = e),
      r &&
        ((e = e.stateNode),
        (e.__reactInternalMemoizedUnmaskedChildContext = l),
        (e.__reactInternalMemoizedMaskedChildContext = o)),
      t
    );
  }
  function Ku(e, t, n, r) {
    ((e = t.state),
      typeof t.componentWillReceiveProps == "function" &&
        t.componentWillReceiveProps(n, r),
      typeof t.UNSAFE_componentWillReceiveProps == "function" &&
        t.UNSAFE_componentWillReceiveProps(n, r),
      t.state !== e && yl.enqueueReplaceState(t, t.state, null));
  }
  function ri(e, t, n, r) {
    var l = e.stateNode;
    ((l.props = n), (l.state = e.memoizedState), (l.refs = {}), Bo(e));
    var o = t.contextType;
    (typeof o == "object" && o !== null
      ? (l.context = at(o))
      : ((o = Ye(t) ? ln : Ue.current), (l.context = Mn(e, o))),
      (l.state = e.memoizedState),
      (o = t.getDerivedStateFromProps),
      typeof o == "function" && (ni(e, t, o, n), (l.state = e.memoizedState)),
      typeof t.getDerivedStateFromProps == "function" ||
        typeof l.getSnapshotBeforeUpdate == "function" ||
        (typeof l.UNSAFE_componentWillMount != "function" &&
          typeof l.componentWillMount != "function") ||
        ((t = l.state),
        typeof l.componentWillMount == "function" && l.componentWillMount(),
        typeof l.UNSAFE_componentWillMount == "function" &&
          l.UNSAFE_componentWillMount(),
        t !== l.state && yl.enqueueReplaceState(l, l.state, null),
        al(e, n, l, r),
        (l.state = e.memoizedState)),
      typeof l.componentDidMount == "function" && (e.flags |= 4194308));
  }
  function In(e, t) {
    try {
      var n = "",
        r = t;
      do ((n += G(r)), (r = r.return));
      while (r);
      var l = n;
    } catch (o) {
      l =
        `
Error generating stack: ` +
        o.message +
        `
` +
        o.stack;
    }
    return { value: e, source: t, stack: l, digest: null };
  }
  function li(e, t, n) {
    return { value: e, source: null, stack: n ?? null, digest: t ?? null };
  }
  function oi(e, t) {
    try {
      console.error(t.value);
    } catch (n) {
      setTimeout(function () {
        throw n;
      });
    }
  }
  var Df = typeof WeakMap == "function" ? WeakMap : Map;
  function Gu(e, t, n) {
    ((n = Lt(-1, n)), (n.tag = 3), (n.payload = { element: null }));
    var r = t.value;
    return (
      (n.callback = function () {
        (jl || ((jl = !0), (ki = r)), oi(e, t));
      }),
      n
    );
  }
  function Yu(e, t, n) {
    ((n = Lt(-1, n)), (n.tag = 3));
    var r = e.type.getDerivedStateFromError;
    if (typeof r == "function") {
      var l = t.value;
      ((n.payload = function () {
        return r(l);
      }),
        (n.callback = function () {
          oi(e, t);
        }));
    }
    var o = e.stateNode;
    return (
      o !== null &&
        typeof o.componentDidCatch == "function" &&
        (n.callback = function () {
          (oi(e, t),
            typeof r != "function" &&
              (Yt === null ? (Yt = new Set([this])) : Yt.add(this)));
          var i = t.stack;
          this.componentDidCatch(t.value, {
            componentStack: i !== null ? i : "",
          });
        }),
      n
    );
  }
  function Xu(e, t, n) {
    var r = e.pingCache;
    if (r === null) {
      r = e.pingCache = new Df();
      var l = new Set();
      r.set(t, l);
    } else ((l = r.get(t)), l === void 0 && ((l = new Set()), r.set(t, l)));
    l.has(n) || (l.add(n), (e = Yf.bind(null, e, t, n)), t.then(e, e));
  }
  function qu(e) {
    do {
      var t;
      if (
        ((t = e.tag === 13) &&
          ((t = e.memoizedState),
          (t = t !== null ? t.dehydrated !== null : !0)),
        t)
      )
        return e;
      e = e.return;
    } while (e !== null);
    return null;
  }
  function Ju(e, t, n, r, l) {
    return (e.mode & 1) === 0
      ? (e === t
          ? (e.flags |= 65536)
          : ((e.flags |= 128),
            (n.flags |= 131072),
            (n.flags &= -52805),
            n.tag === 1 &&
              (n.alternate === null
                ? (n.tag = 17)
                : ((t = Lt(-1, 1)), (t.tag = 2), Kt(n, t, 1))),
            (n.lanes |= 1)),
        e)
      : ((e.flags |= 65536), (e.lanes = l), e);
  }
  var If = te.ReactCurrentOwner,
    Xe = !1;
  function Ve(e, t, n, r) {
    t.child = e === null ? vu(t, null, n, r) : Rn(t, e.child, n, r);
  }
  function bu(e, t, n, r, l) {
    n = n.render;
    var o = t.ref;
    return (
      On(t, l),
      (r = Xo(e, t, n, r, o, l)),
      (n = qo()),
      e !== null && !Xe
        ? ((t.updateQueue = e.updateQueue),
          (t.flags &= -2053),
          (e.lanes &= ~l),
          Nt(e, t, l))
        : (he && n && To(t), (t.flags |= 1), Ve(e, t, r, l), t.child)
    );
  }
  function ea(e, t, n, r, l) {
    if (e === null) {
      var o = n.type;
      return typeof o == "function" &&
        !_i(o) &&
        o.defaultProps === void 0 &&
        n.compare === null &&
        n.defaultProps === void 0
        ? ((t.tag = 15), (t.type = o), ta(e, t, o, r, l))
        : ((e = Pl(n.type, null, r, t, t.mode, l)),
          (e.ref = t.ref),
          (e.return = t),
          (t.child = e));
    }
    if (((o = e.child), (e.lanes & l) === 0)) {
      var i = o.memoizedProps;
      if (
        ((n = n.compare), (n = n !== null ? n : or), n(i, r) && e.ref === t.ref)
      )
        return Nt(e, t, l);
    }
    return (
      (t.flags |= 1),
      (e = bt(o, r)),
      (e.ref = t.ref),
      (e.return = t),
      (t.child = e)
    );
  }
  function ta(e, t, n, r, l) {
    if (e !== null) {
      var o = e.memoizedProps;
      if (or(o, r) && e.ref === t.ref)
        if (((Xe = !1), (t.pendingProps = r = o), (e.lanes & l) !== 0))
          (e.flags & 131072) !== 0 && (Xe = !0);
        else return ((t.lanes = e.lanes), Nt(e, t, l));
    }
    return ii(e, t, n, r, l);
  }
  function na(e, t, n) {
    var r = t.pendingProps,
      l = r.children,
      o = e !== null ? e.memoizedState : null;
    if (r.mode === "hidden")
      if ((t.mode & 1) === 0)
        ((t.memoizedState = {
          baseLanes: 0,
          cachePool: null,
          transitions: null,
        }),
          se(An, ot),
          (ot |= n));
      else {
        if ((n & 1073741824) === 0)
          return (
            (e = o !== null ? o.baseLanes | n : n),
            (t.lanes = t.childLanes = 1073741824),
            (t.memoizedState = {
              baseLanes: e,
              cachePool: null,
              transitions: null,
            }),
            (t.updateQueue = null),
            se(An, ot),
            (ot |= e),
            null
          );
        ((t.memoizedState = {
          baseLanes: 0,
          cachePool: null,
          transitions: null,
        }),
          (r = o !== null ? o.baseLanes : n),
          se(An, ot),
          (ot |= r));
      }
    else
      (o !== null ? ((r = o.baseLanes | n), (t.memoizedState = null)) : (r = n),
        se(An, ot),
        (ot |= r));
    return (Ve(e, t, l, n), t.child);
  }
  function ra(e, t) {
    var n = t.ref;
    ((e === null && n !== null) || (e !== null && e.ref !== n)) &&
      ((t.flags |= 512), (t.flags |= 2097152));
  }
  function ii(e, t, n, r, l) {
    var o = Ye(n) ? ln : Ue.current;
    return (
      (o = Mn(t, o)),
      On(t, l),
      (n = Xo(e, t, n, r, o, l)),
      (r = qo()),
      e !== null && !Xe
        ? ((t.updateQueue = e.updateQueue),
          (t.flags &= -2053),
          (e.lanes &= ~l),
          Nt(e, t, l))
        : (he && r && To(t), (t.flags |= 1), Ve(e, t, n, l), t.child)
    );
  }
  function la(e, t, n, r, l) {
    if (Ye(n)) {
      var o = !0;
      el(t);
    } else o = !1;
    if ((On(t, l), t.stateNode === null))
      (vl(e, t), Zu(t, n, r), ri(t, n, r, l), (r = !0));
    else if (e === null) {
      var i = t.stateNode,
        u = t.memoizedProps;
      i.props = u;
      var a = i.context,
        y = n.contextType;
      typeof y == "object" && y !== null
        ? (y = at(y))
        : ((y = Ye(n) ? ln : Ue.current), (y = Mn(t, y)));
      var w = n.getDerivedStateFromProps,
        S =
          typeof w == "function" ||
          typeof i.getSnapshotBeforeUpdate == "function";
      (S ||
        (typeof i.UNSAFE_componentWillReceiveProps != "function" &&
          typeof i.componentWillReceiveProps != "function") ||
        ((u !== r || a !== y) && Ku(t, i, r, y)),
        (Zt = !1));
      var x = t.memoizedState;
      ((i.state = x),
        al(t, r, i, l),
        (a = t.memoizedState),
        u !== r || x !== a || Ge.current || Zt
          ? (typeof w == "function" && (ni(t, n, w, r), (a = t.memoizedState)),
            (u = Zt || Qu(t, n, u, r, x, a, y))
              ? (S ||
                  (typeof i.UNSAFE_componentWillMount != "function" &&
                    typeof i.componentWillMount != "function") ||
                  (typeof i.componentWillMount == "function" &&
                    i.componentWillMount(),
                  typeof i.UNSAFE_componentWillMount == "function" &&
                    i.UNSAFE_componentWillMount()),
                typeof i.componentDidMount == "function" &&
                  (t.flags |= 4194308))
              : (typeof i.componentDidMount == "function" &&
                  (t.flags |= 4194308),
                (t.memoizedProps = r),
                (t.memoizedState = a)),
            (i.props = r),
            (i.state = a),
            (i.context = y),
            (r = u))
          : (typeof i.componentDidMount == "function" && (t.flags |= 4194308),
            (r = !1)));
    } else {
      ((i = t.stateNode),
        ku(e, t),
        (u = t.memoizedProps),
        (y = t.type === t.elementType ? u : yt(t.type, u)),
        (i.props = y),
        (S = t.pendingProps),
        (x = i.context),
        (a = n.contextType),
        typeof a == "object" && a !== null
          ? (a = at(a))
          : ((a = Ye(n) ? ln : Ue.current), (a = Mn(t, a))));
      var _ = n.getDerivedStateFromProps;
      ((w =
        typeof _ == "function" ||
        typeof i.getSnapshotBeforeUpdate == "function") ||
        (typeof i.UNSAFE_componentWillReceiveProps != "function" &&
          typeof i.componentWillReceiveProps != "function") ||
        ((u !== S || x !== a) && Ku(t, i, r, a)),
        (Zt = !1),
        (x = t.memoizedState),
        (i.state = x),
        al(t, r, i, l));
      var N = t.memoizedState;
      u !== S || x !== N || Ge.current || Zt
        ? (typeof _ == "function" && (ni(t, n, _, r), (N = t.memoizedState)),
          (y = Zt || Qu(t, n, y, r, x, N, a) || !1)
            ? (w ||
                (typeof i.UNSAFE_componentWillUpdate != "function" &&
                  typeof i.componentWillUpdate != "function") ||
                (typeof i.componentWillUpdate == "function" &&
                  i.componentWillUpdate(r, N, a),
                typeof i.UNSAFE_componentWillUpdate == "function" &&
                  i.UNSAFE_componentWillUpdate(r, N, a)),
              typeof i.componentDidUpdate == "function" && (t.flags |= 4),
              typeof i.getSnapshotBeforeUpdate == "function" &&
                (t.flags |= 1024))
            : (typeof i.componentDidUpdate != "function" ||
                (u === e.memoizedProps && x === e.memoizedState) ||
                (t.flags |= 4),
              typeof i.getSnapshotBeforeUpdate != "function" ||
                (u === e.memoizedProps && x === e.memoizedState) ||
                (t.flags |= 1024),
              (t.memoizedProps = r),
              (t.memoizedState = N)),
          (i.props = r),
          (i.state = N),
          (i.context = a),
          (r = y))
        : (typeof i.componentDidUpdate != "function" ||
            (u === e.memoizedProps && x === e.memoizedState) ||
            (t.flags |= 4),
          typeof i.getSnapshotBeforeUpdate != "function" ||
            (u === e.memoizedProps && x === e.memoizedState) ||
            (t.flags |= 1024),
          (r = !1));
    }
    return si(e, t, n, r, o, l);
  }
  function si(e, t, n, r, l, o) {
    ra(e, t);
    var i = (t.flags & 128) !== 0;
    if (!r && !i) return (l && au(t, n, !1), Nt(e, t, o));
    ((r = t.stateNode), (If.current = t));
    var u =
      i && typeof n.getDerivedStateFromError != "function" ? null : r.render();
    return (
      (t.flags |= 1),
      e !== null && i
        ? ((t.child = Rn(t, e.child, null, o)), (t.child = Rn(t, null, u, o)))
        : Ve(e, t, u, o),
      (t.memoizedState = r.state),
      l && au(t, n, !0),
      t.child
    );
  }
  function oa(e) {
    var t = e.stateNode;
    (t.pendingContext
      ? su(e, t.pendingContext, t.pendingContext !== t.context)
      : t.context && su(e, t.context, !1),
      Vo(e, t.containerInfo));
  }
  function ia(e, t, n, r, l) {
    return (Nn(), Fo(l), (t.flags |= 256), Ve(e, t, n, r), t.child);
  }
  var ui = { dehydrated: null, treeContext: null, retryLane: 0 };
  function ai(e) {
    return { baseLanes: e, cachePool: null, transitions: null };
  }
  function sa(e, t, n) {
    var r = t.pendingProps,
      l = me.current,
      o = !1,
      i = (t.flags & 128) !== 0,
      u;
    if (
      ((u = i) ||
        (u = e !== null && e.memoizedState === null ? !1 : (l & 2) !== 0),
      u
        ? ((o = !0), (t.flags &= -129))
        : (e === null || e.memoizedState !== null) && (l |= 1),
      se(me, l & 1),
      e === null)
    )
      return (
        Io(t),
        (e = t.memoizedState),
        e !== null && ((e = e.dehydrated), e !== null)
          ? ((t.mode & 1) === 0
              ? (t.lanes = 1)
              : e.data === "$!"
                ? (t.lanes = 8)
                : (t.lanes = 1073741824),
            null)
          : ((i = r.children),
            (e = r.fallback),
            o
              ? ((r = t.mode),
                (o = t.child),
                (i = { mode: "hidden", children: i }),
                (r & 1) === 0 && o !== null
                  ? ((o.childLanes = 0), (o.pendingProps = i))
                  : (o = Ll(i, r, 0, null)),
                (e = mn(e, r, n, null)),
                (o.return = t),
                (e.return = t),
                (o.sibling = e),
                (t.child = o),
                (t.child.memoizedState = ai(n)),
                (t.memoizedState = ui),
                e)
              : ci(t, i))
      );
    if (((l = e.memoizedState), l !== null && ((u = l.dehydrated), u !== null)))
      return Ff(e, t, i, r, u, l, n);
    if (o) {
      ((o = r.fallback), (i = t.mode), (l = e.child), (u = l.sibling));
      var a = { mode: "hidden", children: r.children };
      return (
        (i & 1) === 0 && t.child !== l
          ? ((r = t.child),
            (r.childLanes = 0),
            (r.pendingProps = a),
            (t.deletions = null))
          : ((r = bt(l, a)), (r.subtreeFlags = l.subtreeFlags & 14680064)),
        u !== null ? (o = bt(u, o)) : ((o = mn(o, i, n, null)), (o.flags |= 2)),
        (o.return = t),
        (r.return = t),
        (r.sibling = o),
        (t.child = r),
        (r = o),
        (o = t.child),
        (i = e.child.memoizedState),
        (i =
          i === null
            ? ai(n)
            : {
                baseLanes: i.baseLanes | n,
                cachePool: null,
                transitions: i.transitions,
              }),
        (o.memoizedState = i),
        (o.childLanes = e.childLanes & ~n),
        (t.memoizedState = ui),
        r
      );
    }
    return (
      (o = e.child),
      (e = o.sibling),
      (r = bt(o, { mode: "visible", children: r.children })),
      (t.mode & 1) === 0 && (r.lanes = n),
      (r.return = t),
      (r.sibling = null),
      e !== null &&
        ((n = t.deletions),
        n === null ? ((t.deletions = [e]), (t.flags |= 16)) : n.push(e)),
      (t.child = r),
      (t.memoizedState = null),
      r
    );
  }
  function ci(e, t) {
    return (
      (t = Ll({ mode: "visible", children: t }, e.mode, 0, null)),
      (t.return = e),
      (e.child = t)
    );
  }
  function gl(e, t, n, r) {
    return (
      r !== null && Fo(r),
      Rn(t, e.child, null, n),
      (e = ci(t, t.pendingProps.children)),
      (e.flags |= 2),
      (t.memoizedState = null),
      e
    );
  }
  function Ff(e, t, n, r, l, o, i) {
    if (n)
      return t.flags & 256
        ? ((t.flags &= -257), (r = li(Error(f(422)))), gl(e, t, i, r))
        : t.memoizedState !== null
          ? ((t.child = e.child), (t.flags |= 128), null)
          : ((o = r.fallback),
            (l = t.mode),
            (r = Ll({ mode: "visible", children: r.children }, l, 0, null)),
            (o = mn(o, l, i, null)),
            (o.flags |= 2),
            (r.return = t),
            (o.return = t),
            (r.sibling = o),
            (t.child = r),
            (t.mode & 1) !== 0 && Rn(t, e.child, null, i),
            (t.child.memoizedState = ai(i)),
            (t.memoizedState = ui),
            o);
    if ((t.mode & 1) === 0) return gl(e, t, i, null);
    if (l.data === "$!") {
      if (((r = l.nextSibling && l.nextSibling.dataset), r)) var u = r.dgst;
      return (
        (r = u),
        (o = Error(f(419))),
        (r = li(o, r, void 0)),
        gl(e, t, i, r)
      );
    }
    if (((u = (i & e.childLanes) !== 0), Xe || u)) {
      if (((r = Ne), r !== null)) {
        switch (i & -i) {
          case 4:
            l = 2;
            break;
          case 16:
            l = 8;
            break;
          case 64:
          case 128:
          case 256:
          case 512:
          case 1024:
          case 2048:
          case 4096:
          case 8192:
          case 16384:
          case 32768:
          case 65536:
          case 131072:
          case 262144:
          case 524288:
          case 1048576:
          case 2097152:
          case 4194304:
          case 8388608:
          case 16777216:
          case 33554432:
          case 67108864:
            l = 32;
            break;
          case 536870912:
            l = 268435456;
            break;
          default:
            l = 0;
        }
        ((l = (l & (r.suspendedLanes | i)) !== 0 ? 0 : l),
          l !== 0 &&
            l !== o.retryLane &&
            ((o.retryLane = l), Pt(e, l), xt(r, e, l, -1)));
      }
      return (Ei(), (r = li(Error(f(421)))), gl(e, t, i, r));
    }
    return l.data === "$?"
      ? ((t.flags |= 128),
        (t.child = e.child),
        (t = Xf.bind(null, e)),
        (l._reactRetry = t),
        null)
      : ((e = o.treeContext),
        (lt = $t(l.nextSibling)),
        (rt = t),
        (he = !0),
        (mt = null),
        e !== null &&
          ((st[ut++] = _t),
          (st[ut++] = Mt),
          (st[ut++] = on),
          (_t = e.id),
          (Mt = e.overflow),
          (on = t)),
        (t = ci(t, r.children)),
        (t.flags |= 4096),
        t);
  }
  function ua(e, t, n) {
    e.lanes |= t;
    var r = e.alternate;
    (r !== null && (r.lanes |= t), Ho(e.return, t, n));
  }
  function fi(e, t, n, r, l) {
    var o = e.memoizedState;
    o === null
      ? (e.memoizedState = {
          isBackwards: t,
          rendering: null,
          renderingStartTime: 0,
          last: r,
          tail: n,
          tailMode: l,
        })
      : ((o.isBackwards = t),
        (o.rendering = null),
        (o.renderingStartTime = 0),
        (o.last = r),
        (o.tail = n),
        (o.tailMode = l));
  }
  function aa(e, t, n) {
    var r = t.pendingProps,
      l = r.revealOrder,
      o = r.tail;
    if ((Ve(e, t, r.children, n), (r = me.current), (r & 2) !== 0))
      ((r = (r & 1) | 2), (t.flags |= 128));
    else {
      if (e !== null && (e.flags & 128) !== 0)
        e: for (e = t.child; e !== null;) {
          if (e.tag === 13) e.memoizedState !== null && ua(e, n, t);
          else if (e.tag === 19) ua(e, n, t);
          else if (e.child !== null) {
            ((e.child.return = e), (e = e.child));
            continue;
          }
          if (e === t) break e;
          for (; e.sibling === null;) {
            if (e.return === null || e.return === t) break e;
            e = e.return;
          }
          ((e.sibling.return = e.return), (e = e.sibling));
        }
      r &= 1;
    }
    if ((se(me, r), (t.mode & 1) === 0)) t.memoizedState = null;
    else
      switch (l) {
        case "forwards":
          for (n = t.child, l = null; n !== null;)
            ((e = n.alternate),
              e !== null && cl(e) === null && (l = n),
              (n = n.sibling));
          ((n = l),
            n === null
              ? ((l = t.child), (t.child = null))
              : ((l = n.sibling), (n.sibling = null)),
            fi(t, !1, l, n, o));
          break;
        case "backwards":
          for (n = null, l = t.child, t.child = null; l !== null;) {
            if (((e = l.alternate), e !== null && cl(e) === null)) {
              t.child = l;
              break;
            }
            ((e = l.sibling), (l.sibling = n), (n = l), (l = e));
          }
          fi(t, !0, n, null, o);
          break;
        case "together":
          fi(t, !1, null, null, void 0);
          break;
        default:
          t.memoizedState = null;
      }
    return t.child;
  }
  function vl(e, t) {
    (t.mode & 1) === 0 &&
      e !== null &&
      ((e.alternate = null), (t.alternate = null), (t.flags |= 2));
  }
  function Nt(e, t, n) {
    if (
      (e !== null && (t.dependencies = e.dependencies),
      (fn |= t.lanes),
      (n & t.childLanes) === 0)
    )
      return null;
    if (e !== null && t.child !== e.child) throw Error(f(153));
    if (t.child !== null) {
      for (
        e = t.child, n = bt(e, e.pendingProps), t.child = n, n.return = t;
        e.sibling !== null;
      )
        ((e = e.sibling),
          (n = n.sibling = bt(e, e.pendingProps)),
          (n.return = t));
      n.sibling = null;
    }
    return t.child;
  }
  function Af(e, t, n) {
    switch (t.tag) {
      case 3:
        (oa(t), Nn());
        break;
      case 5:
        ju(t);
        break;
      case 1:
        Ye(t.type) && el(t);
        break;
      case 4:
        Vo(t, t.stateNode.containerInfo);
        break;
      case 10:
        var r = t.type._context,
          l = t.memoizedProps.value;
        (se(il, r._currentValue), (r._currentValue = l));
        break;
      case 13:
        if (((r = t.memoizedState), r !== null))
          return r.dehydrated !== null
            ? (se(me, me.current & 1), (t.flags |= 128), null)
            : (n & t.child.childLanes) !== 0
              ? sa(e, t, n)
              : (se(me, me.current & 1),
                (e = Nt(e, t, n)),
                e !== null ? e.sibling : null);
        se(me, me.current & 1);
        break;
      case 19:
        if (((r = (n & t.childLanes) !== 0), (e.flags & 128) !== 0)) {
          if (r) return aa(e, t, n);
          t.flags |= 128;
        }
        if (
          ((l = t.memoizedState),
          l !== null &&
            ((l.rendering = null), (l.tail = null), (l.lastEffect = null)),
          se(me, me.current),
          r)
        )
          break;
        return null;
      case 22:
      case 23:
        return ((t.lanes = 0), na(e, t, n));
    }
    return Nt(e, t, n);
  }
  var ca, di, fa, da;
  ((ca = function (e, t) {
    for (var n = t.child; n !== null;) {
      if (n.tag === 5 || n.tag === 6) e.appendChild(n.stateNode);
      else if (n.tag !== 4 && n.child !== null) {
        ((n.child.return = n), (n = n.child));
        continue;
      }
      if (n === t) break;
      for (; n.sibling === null;) {
        if (n.return === null || n.return === t) return;
        n = n.return;
      }
      ((n.sibling.return = n.return), (n = n.sibling));
    }
  }),
    (di = function () {}),
    (fa = function (e, t, n, r) {
      var l = e.memoizedProps;
      if (l !== r) {
        ((e = t.stateNode), an(St.current));
        var o = null;
        switch (n) {
          case "input":
            ((l = Wl(e, l)), (r = Wl(e, r)), (o = []));
            break;
          case "select":
            ((l = L({}, l, { value: void 0 })),
              (r = L({}, r, { value: void 0 })),
              (o = []));
            break;
          case "textarea":
            ((l = Bl(e, l)), (r = Bl(e, r)), (o = []));
            break;
          default:
            typeof l.onClick != "function" &&
              typeof r.onClick == "function" &&
              (e.onclick = qr);
        }
        Ql(n, r);
        var i;
        n = null;
        for (y in l)
          if (!r.hasOwnProperty(y) && l.hasOwnProperty(y) && l[y] != null)
            if (y === "style") {
              var u = l[y];
              for (i in u) u.hasOwnProperty(i) && (n || (n = {}), (n[i] = ""));
            } else
              y !== "dangerouslySetInnerHTML" &&
                y !== "children" &&
                y !== "suppressContentEditableWarning" &&
                y !== "suppressHydrationWarning" &&
                y !== "autoFocus" &&
                (C.hasOwnProperty(y)
                  ? o || (o = [])
                  : (o = o || []).push(y, null));
        for (y in r) {
          var a = r[y];
          if (
            ((u = l?.[y]),
            r.hasOwnProperty(y) && a !== u && (a != null || u != null))
          )
            if (y === "style")
              if (u) {
                for (i in u)
                  !u.hasOwnProperty(i) ||
                    (a && a.hasOwnProperty(i)) ||
                    (n || (n = {}), (n[i] = ""));
                for (i in a)
                  a.hasOwnProperty(i) &&
                    u[i] !== a[i] &&
                    (n || (n = {}), (n[i] = a[i]));
              } else (n || (o || (o = []), o.push(y, n)), (n = a));
            else
              y === "dangerouslySetInnerHTML"
                ? ((a = a ? a.__html : void 0),
                  (u = u ? u.__html : void 0),
                  a != null && u !== a && (o = o || []).push(y, a))
                : y === "children"
                  ? (typeof a != "string" && typeof a != "number") ||
                    (o = o || []).push(y, "" + a)
                  : y !== "suppressContentEditableWarning" &&
                    y !== "suppressHydrationWarning" &&
                    (C.hasOwnProperty(y)
                      ? (a != null && y === "onScroll" && ae("scroll", e),
                        o || u === a || (o = []))
                      : (o = o || []).push(y, a));
        }
        n && (o = o || []).push("style", n);
        var y = o;
        (t.updateQueue = y) && (t.flags |= 4);
      }
    }),
    (da = function (e, t, n, r) {
      n !== r && (t.flags |= 4);
    }));
  function kr(e, t) {
    if (!he)
      switch (e.tailMode) {
        case "hidden":
          t = e.tail;
          for (var n = null; t !== null;)
            (t.alternate !== null && (n = t), (t = t.sibling));
          n === null ? (e.tail = null) : (n.sibling = null);
          break;
        case "collapsed":
          n = e.tail;
          for (var r = null; n !== null;)
            (n.alternate !== null && (r = n), (n = n.sibling));
          r === null
            ? t || e.tail === null
              ? (e.tail = null)
              : (e.tail.sibling = null)
            : (r.sibling = null);
      }
  }
  function He(e) {
    var t = e.alternate !== null && e.alternate.child === e.child,
      n = 0,
      r = 0;
    if (t)
      for (var l = e.child; l !== null;)
        ((n |= l.lanes | l.childLanes),
          (r |= l.subtreeFlags & 14680064),
          (r |= l.flags & 14680064),
          (l.return = e),
          (l = l.sibling));
    else
      for (l = e.child; l !== null;)
        ((n |= l.lanes | l.childLanes),
          (r |= l.subtreeFlags),
          (r |= l.flags),
          (l.return = e),
          (l = l.sibling));
    return ((e.subtreeFlags |= r), (e.childLanes = n), t);
  }
  function Uf(e, t, n) {
    var r = t.pendingProps;
    switch ((Oo(t), t.tag)) {
      case 2:
      case 16:
      case 15:
      case 0:
      case 11:
      case 7:
      case 8:
      case 12:
      case 9:
      case 14:
        return (He(t), null);
      case 1:
        return (Ye(t.type) && br(), He(t), null);
      case 3:
        return (
          (r = t.stateNode),
          Dn(),
          ce(Ge),
          ce(Ue),
          Ko(),
          r.pendingContext &&
            ((r.context = r.pendingContext), (r.pendingContext = null)),
          (e === null || e.child === null) &&
            (ll(t)
              ? (t.flags |= 4)
              : e === null ||
                (e.memoizedState.isDehydrated && (t.flags & 256) === 0) ||
                ((t.flags |= 1024), mt !== null && (ji(mt), (mt = null)))),
          di(e, t),
          He(t),
          null
        );
      case 5:
        Qo(t);
        var l = an(mr.current);
        if (((n = t.type), e !== null && t.stateNode != null))
          (fa(e, t, n, r, l),
            e.ref !== t.ref && ((t.flags |= 512), (t.flags |= 2097152)));
        else {
          if (!r) {
            if (t.stateNode === null) throw Error(f(166));
            return (He(t), null);
          }
          if (((e = an(St.current)), ll(t))) {
            ((r = t.stateNode), (n = t.type));
            var o = t.memoizedProps;
            switch (((r[wt] = t), (r[cr] = o), (e = (t.mode & 1) !== 0), n)) {
              case "dialog":
                (ae("cancel", r), ae("close", r));
                break;
              case "iframe":
              case "object":
              case "embed":
                ae("load", r);
                break;
              case "video":
              case "audio":
                for (l = 0; l < sr.length; l++) ae(sr[l], r);
                break;
              case "source":
                ae("error", r);
                break;
              case "img":
              case "image":
              case "link":
                (ae("error", r), ae("load", r));
                break;
              case "details":
                ae("toggle", r);
                break;
              case "input":
                (Zi(r, o), ae("invalid", r));
                break;
              case "select":
                ((r._wrapperState = { wasMultiple: !!o.multiple }),
                  ae("invalid", r));
                break;
              case "textarea":
                (Yi(r, o), ae("invalid", r));
            }
            (Ql(n, o), (l = null));
            for (var i in o)
              if (o.hasOwnProperty(i)) {
                var u = o[i];
                i === "children"
                  ? typeof u == "string"
                    ? r.textContent !== u &&
                      (o.suppressHydrationWarning !== !0 &&
                        Xr(r.textContent, u, e),
                      (l = ["children", u]))
                    : typeof u == "number" &&
                      r.textContent !== "" + u &&
                      (o.suppressHydrationWarning !== !0 &&
                        Xr(r.textContent, u, e),
                      (l = ["children", "" + u]))
                  : C.hasOwnProperty(i) &&
                    u != null &&
                    i === "onScroll" &&
                    ae("scroll", r);
              }
            switch (n) {
              case "input":
                (_r(r), Gi(r, o, !0));
                break;
              case "textarea":
                (_r(r), qi(r));
                break;
              case "select":
              case "option":
                break;
              default:
                typeof o.onClick == "function" && (r.onclick = qr);
            }
            ((r = l), (t.updateQueue = r), r !== null && (t.flags |= 4));
          } else {
            ((i = l.nodeType === 9 ? l : l.ownerDocument),
              e === "http://www.w3.org/1999/xhtml" && (e = Ji(n)),
              e === "http://www.w3.org/1999/xhtml"
                ? n === "script"
                  ? ((e = i.createElement("div")),
                    (e.innerHTML = "<script><\/script>"),
                    (e = e.removeChild(e.firstChild)))
                  : typeof r.is == "string"
                    ? (e = i.createElement(n, { is: r.is }))
                    : ((e = i.createElement(n)),
                      n === "select" &&
                        ((i = e),
                        r.multiple
                          ? (i.multiple = !0)
                          : r.size && (i.size = r.size)))
                : (e = i.createElementNS(e, n)),
              (e[wt] = t),
              (e[cr] = r),
              ca(e, t, !1, !1),
              (t.stateNode = e));
            e: {
              switch (((i = Zl(n, r)), n)) {
                case "dialog":
                  (ae("cancel", e), ae("close", e), (l = r));
                  break;
                case "iframe":
                case "object":
                case "embed":
                  (ae("load", e), (l = r));
                  break;
                case "video":
                case "audio":
                  for (l = 0; l < sr.length; l++) ae(sr[l], e);
                  l = r;
                  break;
                case "source":
                  (ae("error", e), (l = r));
                  break;
                case "img":
                case "image":
                case "link":
                  (ae("error", e), ae("load", e), (l = r));
                  break;
                case "details":
                  (ae("toggle", e), (l = r));
                  break;
                case "input":
                  (Zi(e, r), (l = Wl(e, r)), ae("invalid", e));
                  break;
                case "option":
                  l = r;
                  break;
                case "select":
                  ((e._wrapperState = { wasMultiple: !!r.multiple }),
                    (l = L({}, r, { value: void 0 })),
                    ae("invalid", e));
                  break;
                case "textarea":
                  (Yi(e, r), (l = Bl(e, r)), ae("invalid", e));
                  break;
                default:
                  l = r;
              }
              (Ql(n, l), (u = l));
              for (o in u)
                if (u.hasOwnProperty(o)) {
                  var a = u[o];
                  o === "style"
                    ? ts(e, a)
                    : o === "dangerouslySetInnerHTML"
                      ? ((a = a ? a.__html : void 0), a != null && bi(e, a))
                      : o === "children"
                        ? typeof a == "string"
                          ? (n !== "textarea" || a !== "") && $n(e, a)
                          : typeof a == "number" && $n(e, "" + a)
                        : o !== "suppressContentEditableWarning" &&
                          o !== "suppressHydrationWarning" &&
                          o !== "autoFocus" &&
                          (C.hasOwnProperty(o)
                            ? a != null && o === "onScroll" && ae("scroll", e)
                            : a != null && Fe(e, o, a, i));
                }
              switch (n) {
                case "input":
                  (_r(e), Gi(e, r, !1));
                  break;
                case "textarea":
                  (_r(e), qi(e));
                  break;
                case "option":
                  r.value != null && e.setAttribute("value", "" + b(r.value));
                  break;
                case "select":
                  ((e.multiple = !!r.multiple),
                    (o = r.value),
                    o != null
                      ? yn(e, !!r.multiple, o, !1)
                      : r.defaultValue != null &&
                        yn(e, !!r.multiple, r.defaultValue, !0));
                  break;
                default:
                  typeof l.onClick == "function" && (e.onclick = qr);
              }
              switch (n) {
                case "button":
                case "input":
                case "select":
                case "textarea":
                  r = !!r.autoFocus;
                  break e;
                case "img":
                  r = !0;
                  break e;
                default:
                  r = !1;
              }
            }
            r && (t.flags |= 4);
          }
          t.ref !== null && ((t.flags |= 512), (t.flags |= 2097152));
        }
        return (He(t), null);
      case 6:
        if (e && t.stateNode != null) da(e, t, e.memoizedProps, r);
        else {
          if (typeof r != "string" && t.stateNode === null) throw Error(f(166));
          if (((n = an(mr.current)), an(St.current), ll(t))) {
            if (
              ((r = t.stateNode),
              (n = t.memoizedProps),
              (r[wt] = t),
              (o = r.nodeValue !== n) && ((e = rt), e !== null))
            )
              switch (e.tag) {
                case 3:
                  Xr(r.nodeValue, n, (e.mode & 1) !== 0);
                  break;
                case 5:
                  e.memoizedProps.suppressHydrationWarning !== !0 &&
                    Xr(r.nodeValue, n, (e.mode & 1) !== 0);
              }
            o && (t.flags |= 4);
          } else
            ((r = (n.nodeType === 9 ? n : n.ownerDocument).createTextNode(r)),
              (r[wt] = t),
              (t.stateNode = r));
        }
        return (He(t), null);
      case 13:
        if (
          (ce(me),
          (r = t.memoizedState),
          e === null ||
            (e.memoizedState !== null && e.memoizedState.dehydrated !== null))
        ) {
          if (he && lt !== null && (t.mode & 1) !== 0 && (t.flags & 128) === 0)
            (mu(), Nn(), (t.flags |= 98560), (o = !1));
          else if (((o = ll(t)), r !== null && r.dehydrated !== null)) {
            if (e === null) {
              if (!o) throw Error(f(318));
              if (
                ((o = t.memoizedState),
                (o = o !== null ? o.dehydrated : null),
                !o)
              )
                throw Error(f(317));
              o[wt] = t;
            } else
              (Nn(),
                (t.flags & 128) === 0 && (t.memoizedState = null),
                (t.flags |= 4));
            (He(t), (o = !1));
          } else (mt !== null && (ji(mt), (mt = null)), (o = !0));
          if (!o) return t.flags & 65536 ? t : null;
        }
        return (t.flags & 128) !== 0
          ? ((t.lanes = n), t)
          : ((r = r !== null),
            r !== (e !== null && e.memoizedState !== null) &&
              r &&
              ((t.child.flags |= 8192),
              (t.mode & 1) !== 0 &&
                (e === null || (me.current & 1) !== 0
                  ? Me === 0 && (Me = 3)
                  : Ei())),
            t.updateQueue !== null && (t.flags |= 4),
            He(t),
            null);
      case 4:
        return (
          Dn(),
          di(e, t),
          e === null && ur(t.stateNode.containerInfo),
          He(t),
          null
        );
      case 10:
        return (Wo(t.type._context), He(t), null);
      case 17:
        return (Ye(t.type) && br(), He(t), null);
      case 19:
        if ((ce(me), (o = t.memoizedState), o === null)) return (He(t), null);
        if (((r = (t.flags & 128) !== 0), (i = o.rendering), i === null))
          if (r) kr(o, !1);
          else {
            if (Me !== 0 || (e !== null && (e.flags & 128) !== 0))
              for (e = t.child; e !== null;) {
                if (((i = cl(e)), i !== null)) {
                  for (
                    t.flags |= 128,
                      kr(o, !1),
                      r = i.updateQueue,
                      r !== null && ((t.updateQueue = r), (t.flags |= 4)),
                      t.subtreeFlags = 0,
                      r = n,
                      n = t.child;
                    n !== null;
                  )
                    ((o = n),
                      (e = r),
                      (o.flags &= 14680066),
                      (i = o.alternate),
                      i === null
                        ? ((o.childLanes = 0),
                          (o.lanes = e),
                          (o.child = null),
                          (o.subtreeFlags = 0),
                          (o.memoizedProps = null),
                          (o.memoizedState = null),
                          (o.updateQueue = null),
                          (o.dependencies = null),
                          (o.stateNode = null))
                        : ((o.childLanes = i.childLanes),
                          (o.lanes = i.lanes),
                          (o.child = i.child),
                          (o.subtreeFlags = 0),
                          (o.deletions = null),
                          (o.memoizedProps = i.memoizedProps),
                          (o.memoizedState = i.memoizedState),
                          (o.updateQueue = i.updateQueue),
                          (o.type = i.type),
                          (e = i.dependencies),
                          (o.dependencies =
                            e === null
                              ? null
                              : {
                                  lanes: e.lanes,
                                  firstContext: e.firstContext,
                                })),
                      (n = n.sibling));
                  return (se(me, (me.current & 1) | 2), t.child);
                }
                e = e.sibling;
              }
            o.tail !== null &&
              we() > Un &&
              ((t.flags |= 128), (r = !0), kr(o, !1), (t.lanes = 4194304));
          }
        else {
          if (!r)
            if (((e = cl(i)), e !== null)) {
              if (
                ((t.flags |= 128),
                (r = !0),
                (n = e.updateQueue),
                n !== null && ((t.updateQueue = n), (t.flags |= 4)),
                kr(o, !0),
                o.tail === null &&
                  o.tailMode === "hidden" &&
                  !i.alternate &&
                  !he)
              )
                return (He(t), null);
            } else
              2 * we() - o.renderingStartTime > Un &&
                n !== 1073741824 &&
                ((t.flags |= 128), (r = !0), kr(o, !1), (t.lanes = 4194304));
          o.isBackwards
            ? ((i.sibling = t.child), (t.child = i))
            : ((n = o.last),
              n !== null ? (n.sibling = i) : (t.child = i),
              (o.last = i));
        }
        return o.tail !== null
          ? ((t = o.tail),
            (o.rendering = t),
            (o.tail = t.sibling),
            (o.renderingStartTime = we()),
            (t.sibling = null),
            (n = me.current),
            se(me, r ? (n & 1) | 2 : n & 1),
            t)
          : (He(t), null);
      case 22:
      case 23:
        return (
          Ci(),
          (r = t.memoizedState !== null),
          e !== null && (e.memoizedState !== null) !== r && (t.flags |= 8192),
          r && (t.mode & 1) !== 0
            ? (ot & 1073741824) !== 0 &&
              (He(t), t.subtreeFlags & 6 && (t.flags |= 8192))
            : He(t),
          null
        );
      case 24:
        return null;
      case 25:
        return null;
    }
    throw Error(f(156, t.tag));
  }
  function Wf(e, t) {
    switch ((Oo(t), t.tag)) {
      case 1:
        return (
          Ye(t.type) && br(),
          (e = t.flags),
          e & 65536 ? ((t.flags = (e & -65537) | 128), t) : null
        );
      case 3:
        return (
          Dn(),
          ce(Ge),
          ce(Ue),
          Ko(),
          (e = t.flags),
          (e & 65536) !== 0 && (e & 128) === 0
            ? ((t.flags = (e & -65537) | 128), t)
            : null
        );
      case 5:
        return (Qo(t), null);
      case 13:
        if (
          (ce(me), (e = t.memoizedState), e !== null && e.dehydrated !== null)
        ) {
          if (t.alternate === null) throw Error(f(340));
          Nn();
        }
        return (
          (e = t.flags),
          e & 65536 ? ((t.flags = (e & -65537) | 128), t) : null
        );
      case 19:
        return (ce(me), null);
      case 4:
        return (Dn(), null);
      case 10:
        return (Wo(t.type._context), null);
      case 22:
      case 23:
        return (Ci(), null);
      case 24:
        return null;
      default:
        return null;
    }
  }
  var xl = !1,
    $e = !1,
    Hf = typeof WeakSet == "function" ? WeakSet : Set,
    P = null;
  function Fn(e, t) {
    var n = e.ref;
    if (n !== null)
      if (typeof n == "function")
        try {
          n(null);
        } catch (r) {
          xe(e, t, r);
        }
      else n.current = null;
  }
  function pi(e, t, n) {
    try {
      n();
    } catch (r) {
      xe(e, t, r);
    }
  }
  var pa = !1;
  function $f(e, t) {
    if (((Co = Ur), (e = Qs()), go(e))) {
      if ("selectionStart" in e)
        var n = { start: e.selectionStart, end: e.selectionEnd };
      else
        e: {
          n = ((n = e.ownerDocument) && n.defaultView) || window;
          var r = n.getSelection && n.getSelection();
          if (r && r.rangeCount !== 0) {
            n = r.anchorNode;
            var l = r.anchorOffset,
              o = r.focusNode;
            r = r.focusOffset;
            try {
              (n.nodeType, o.nodeType);
            } catch {
              n = null;
              break e;
            }
            var i = 0,
              u = -1,
              a = -1,
              y = 0,
              w = 0,
              S = e,
              x = null;
            t: for (;;) {
              for (
                var _;
                S !== n || (l !== 0 && S.nodeType !== 3) || (u = i + l),
                  S !== o || (r !== 0 && S.nodeType !== 3) || (a = i + r),
                  S.nodeType === 3 && (i += S.nodeValue.length),
                  (_ = S.firstChild) !== null;
              )
                ((x = S), (S = _));
              for (;;) {
                if (S === e) break t;
                if (
                  (x === n && ++y === l && (u = i),
                  x === o && ++w === r && (a = i),
                  (_ = S.nextSibling) !== null)
                )
                  break;
                ((S = x), (x = S.parentNode));
              }
              S = _;
            }
            n = u === -1 || a === -1 ? null : { start: u, end: a };
          } else n = null;
        }
      n = n || { start: 0, end: 0 };
    } else n = null;
    for (
      Eo = { focusedElem: e, selectionRange: n }, Ur = !1, P = t;
      P !== null;
    )
      if (((t = P), (e = t.child), (t.subtreeFlags & 1028) !== 0 && e !== null))
        ((e.return = t), (P = e));
      else
        for (; P !== null;) {
          t = P;
          try {
            var N = t.alternate;
            if ((t.flags & 1024) !== 0)
              switch (t.tag) {
                case 0:
                case 11:
                case 15:
                  break;
                case 1:
                  if (N !== null) {
                    var R = N.memoizedProps,
                      Se = N.memoizedState,
                      h = t.stateNode,
                      c = h.getSnapshotBeforeUpdate(
                        t.elementType === t.type ? R : yt(t.type, R),
                        Se,
                      );
                    h.__reactInternalSnapshotBeforeUpdate = c;
                  }
                  break;
                case 3:
                  var m = t.stateNode.containerInfo;
                  m.nodeType === 1
                    ? (m.textContent = "")
                    : m.nodeType === 9 &&
                      m.documentElement &&
                      m.removeChild(m.documentElement);
                  break;
                case 5:
                case 6:
                case 4:
                case 17:
                  break;
                default:
                  throw Error(f(163));
              }
          } catch (z) {
            xe(t, t.return, z);
          }
          if (((e = t.sibling), e !== null)) {
            ((e.return = t.return), (P = e));
            break;
          }
          P = t.return;
        }
    return ((N = pa), (pa = !1), N);
  }
  function wr(e, t, n) {
    var r = t.updateQueue;
    if (((r = r !== null ? r.lastEffect : null), r !== null)) {
      var l = (r = r.next);
      do {
        if ((l.tag & e) === e) {
          var o = l.destroy;
          ((l.destroy = void 0), o !== void 0 && pi(t, n, o));
        }
        l = l.next;
      } while (l !== r);
    }
  }
  function kl(e, t) {
    if (
      ((t = t.updateQueue), (t = t !== null ? t.lastEffect : null), t !== null)
    ) {
      var n = (t = t.next);
      do {
        if ((n.tag & e) === e) {
          var r = n.create;
          n.destroy = r();
        }
        n = n.next;
      } while (n !== t);
    }
  }
  function hi(e) {
    var t = e.ref;
    if (t !== null) {
      var n = e.stateNode;
      switch (e.tag) {
        case 5:
          e = n;
          break;
        default:
          e = n;
      }
      typeof t == "function" ? t(e) : (t.current = e);
    }
  }
  function ha(e) {
    var t = e.alternate;
    (t !== null && ((e.alternate = null), ha(t)),
      (e.child = null),
      (e.deletions = null),
      (e.sibling = null),
      e.tag === 5 &&
        ((t = e.stateNode),
        t !== null &&
          (delete t[wt],
          delete t[cr],
          delete t[Lo],
          delete t[zf],
          delete t[Cf])),
      (e.stateNode = null),
      (e.return = null),
      (e.dependencies = null),
      (e.memoizedProps = null),
      (e.memoizedState = null),
      (e.pendingProps = null),
      (e.stateNode = null),
      (e.updateQueue = null));
  }
  function ma(e) {
    return e.tag === 5 || e.tag === 3 || e.tag === 4;
  }
  function ya(e) {
    e: for (;;) {
      for (; e.sibling === null;) {
        if (e.return === null || ma(e.return)) return null;
        e = e.return;
      }
      for (
        e.sibling.return = e.return, e = e.sibling;
        e.tag !== 5 && e.tag !== 6 && e.tag !== 18;
      ) {
        if (e.flags & 2 || e.child === null || e.tag === 4) continue e;
        ((e.child.return = e), (e = e.child));
      }
      if (!(e.flags & 2)) return e.stateNode;
    }
  }
  function mi(e, t, n) {
    var r = e.tag;
    if (r === 5 || r === 6)
      ((e = e.stateNode),
        t
          ? n.nodeType === 8
            ? n.parentNode.insertBefore(e, t)
            : n.insertBefore(e, t)
          : (n.nodeType === 8
              ? ((t = n.parentNode), t.insertBefore(e, n))
              : ((t = n), t.appendChild(e)),
            (n = n._reactRootContainer),
            n != null || t.onclick !== null || (t.onclick = qr)));
    else if (r !== 4 && ((e = e.child), e !== null))
      for (mi(e, t, n), e = e.sibling; e !== null;)
        (mi(e, t, n), (e = e.sibling));
  }
  function yi(e, t, n) {
    var r = e.tag;
    if (r === 5 || r === 6)
      ((e = e.stateNode), t ? n.insertBefore(e, t) : n.appendChild(e));
    else if (r !== 4 && ((e = e.child), e !== null))
      for (yi(e, t, n), e = e.sibling; e !== null;)
        (yi(e, t, n), (e = e.sibling));
  }
  var De = null,
    gt = !1;
  function Gt(e, t, n) {
    for (n = n.child; n !== null;) (ga(e, t, n), (n = n.sibling));
  }
  function ga(e, t, n) {
    if (kt && typeof kt.onCommitFiberUnmount == "function")
      try {
        kt.onCommitFiberUnmount(Tr, n);
      } catch {}
    switch (n.tag) {
      case 5:
        $e || Fn(n, t);
      case 6:
        var r = De,
          l = gt;
        ((De = null),
          Gt(e, t, n),
          (De = r),
          (gt = l),
          De !== null &&
            (gt
              ? ((e = De),
                (n = n.stateNode),
                e.nodeType === 8
                  ? e.parentNode.removeChild(n)
                  : e.removeChild(n))
              : De.removeChild(n.stateNode)));
        break;
      case 18:
        De !== null &&
          (gt
            ? ((e = De),
              (n = n.stateNode),
              e.nodeType === 8
                ? Po(e.parentNode, n)
                : e.nodeType === 1 && Po(e, n),
              bn(e))
            : Po(De, n.stateNode));
        break;
      case 4:
        ((r = De),
          (l = gt),
          (De = n.stateNode.containerInfo),
          (gt = !0),
          Gt(e, t, n),
          (De = r),
          (gt = l));
        break;
      case 0:
      case 11:
      case 14:
      case 15:
        if (
          !$e &&
          ((r = n.updateQueue), r !== null && ((r = r.lastEffect), r !== null))
        ) {
          l = r = r.next;
          do {
            var o = l,
              i = o.destroy;
            ((o = o.tag),
              i !== void 0 && ((o & 2) !== 0 || (o & 4) !== 0) && pi(n, t, i),
              (l = l.next));
          } while (l !== r);
        }
        Gt(e, t, n);
        break;
      case 1:
        if (
          !$e &&
          (Fn(n, t),
          (r = n.stateNode),
          typeof r.componentWillUnmount == "function")
        )
          try {
            ((r.props = n.memoizedProps),
              (r.state = n.memoizedState),
              r.componentWillUnmount());
          } catch (u) {
            xe(n, t, u);
          }
        Gt(e, t, n);
        break;
      case 21:
        Gt(e, t, n);
        break;
      case 22:
        n.mode & 1
          ? (($e = (r = $e) || n.memoizedState !== null), Gt(e, t, n), ($e = r))
          : Gt(e, t, n);
        break;
      default:
        Gt(e, t, n);
    }
  }
  function va(e) {
    var t = e.updateQueue;
    if (t !== null) {
      e.updateQueue = null;
      var n = e.stateNode;
      (n === null && (n = e.stateNode = new Hf()),
        t.forEach(function (r) {
          var l = qf.bind(null, e, r);
          n.has(r) || (n.add(r), r.then(l, l));
        }));
    }
  }
  function vt(e, t) {
    var n = t.deletions;
    if (n !== null)
      for (var r = 0; r < n.length; r++) {
        var l = n[r];
        try {
          var o = e,
            i = t,
            u = i;
          e: for (; u !== null;) {
            switch (u.tag) {
              case 5:
                ((De = u.stateNode), (gt = !1));
                break e;
              case 3:
                ((De = u.stateNode.containerInfo), (gt = !0));
                break e;
              case 4:
                ((De = u.stateNode.containerInfo), (gt = !0));
                break e;
            }
            u = u.return;
          }
          if (De === null) throw Error(f(160));
          (ga(o, i, l), (De = null), (gt = !1));
          var a = l.alternate;
          (a !== null && (a.return = null), (l.return = null));
        } catch (y) {
          xe(l, t, y);
        }
      }
    if (t.subtreeFlags & 12854)
      for (t = t.child; t !== null;) (xa(t, e), (t = t.sibling));
  }
  function xa(e, t) {
    var n = e.alternate,
      r = e.flags;
    switch (e.tag) {
      case 0:
      case 11:
      case 14:
      case 15:
        if ((vt(t, e), zt(e), r & 4)) {
          try {
            (wr(3, e, e.return), kl(3, e));
          } catch (R) {
            xe(e, e.return, R);
          }
          try {
            wr(5, e, e.return);
          } catch (R) {
            xe(e, e.return, R);
          }
        }
        break;
      case 1:
        (vt(t, e), zt(e), r & 512 && n !== null && Fn(n, n.return));
        break;
      case 5:
        if (
          (vt(t, e),
          zt(e),
          r & 512 && n !== null && Fn(n, n.return),
          e.flags & 32)
        ) {
          var l = e.stateNode;
          try {
            $n(l, "");
          } catch (R) {
            xe(e, e.return, R);
          }
        }
        if (r & 4 && ((l = e.stateNode), l != null)) {
          var o = e.memoizedProps,
            i = n !== null ? n.memoizedProps : o,
            u = e.type,
            a = e.updateQueue;
          if (((e.updateQueue = null), a !== null))
            try {
              (u === "input" &&
                o.type === "radio" &&
                o.name != null &&
                Ki(l, o),
                Zl(u, i));
              var y = Zl(u, o);
              for (i = 0; i < a.length; i += 2) {
                var w = a[i],
                  S = a[i + 1];
                w === "style"
                  ? ts(l, S)
                  : w === "dangerouslySetInnerHTML"
                    ? bi(l, S)
                    : w === "children"
                      ? $n(l, S)
                      : Fe(l, w, S, y);
              }
              switch (u) {
                case "input":
                  Hl(l, o);
                  break;
                case "textarea":
                  Xi(l, o);
                  break;
                case "select":
                  var x = l._wrapperState.wasMultiple;
                  l._wrapperState.wasMultiple = !!o.multiple;
                  var _ = o.value;
                  _ != null
                    ? yn(l, !!o.multiple, _, !1)
                    : x !== !!o.multiple &&
                      (o.defaultValue != null
                        ? yn(l, !!o.multiple, o.defaultValue, !0)
                        : yn(l, !!o.multiple, o.multiple ? [] : "", !1));
              }
              l[cr] = o;
            } catch (R) {
              xe(e, e.return, R);
            }
        }
        break;
      case 6:
        if ((vt(t, e), zt(e), r & 4)) {
          if (e.stateNode === null) throw Error(f(162));
          ((l = e.stateNode), (o = e.memoizedProps));
          try {
            l.nodeValue = o;
          } catch (R) {
            xe(e, e.return, R);
          }
        }
        break;
      case 3:
        if (
          (vt(t, e), zt(e), r & 4 && n !== null && n.memoizedState.isDehydrated)
        )
          try {
            bn(t.containerInfo);
          } catch (R) {
            xe(e, e.return, R);
          }
        break;
      case 4:
        (vt(t, e), zt(e));
        break;
      case 13:
        (vt(t, e),
          zt(e),
          (l = e.child),
          l.flags & 8192 &&
            ((o = l.memoizedState !== null),
            (l.stateNode.isHidden = o),
            !o ||
              (l.alternate !== null && l.alternate.memoizedState !== null) ||
              (xi = we())),
          r & 4 && va(e));
        break;
      case 22:
        if (
          ((w = n !== null && n.memoizedState !== null),
          e.mode & 1 ? (($e = (y = $e) || w), vt(t, e), ($e = y)) : vt(t, e),
          zt(e),
          r & 8192)
        ) {
          if (
            ((y = e.memoizedState !== null),
            (e.stateNode.isHidden = y) && !w && (e.mode & 1) !== 0)
          )
            for (P = e, w = e.child; w !== null;) {
              for (S = P = w; P !== null;) {
                switch (((x = P), (_ = x.child), x.tag)) {
                  case 0:
                  case 11:
                  case 14:
                  case 15:
                    wr(4, x, x.return);
                    break;
                  case 1:
                    Fn(x, x.return);
                    var N = x.stateNode;
                    if (typeof N.componentWillUnmount == "function") {
                      ((r = x), (n = x.return));
                      try {
                        ((t = r),
                          (N.props = t.memoizedProps),
                          (N.state = t.memoizedState),
                          N.componentWillUnmount());
                      } catch (R) {
                        xe(r, n, R);
                      }
                    }
                    break;
                  case 5:
                    Fn(x, x.return);
                    break;
                  case 22:
                    if (x.memoizedState !== null) {
                      Sa(S);
                      continue;
                    }
                }
                _ !== null ? ((_.return = x), (P = _)) : Sa(S);
              }
              w = w.sibling;
            }
          e: for (w = null, S = e; ;) {
            if (S.tag === 5) {
              if (w === null) {
                w = S;
                try {
                  ((l = S.stateNode),
                    y
                      ? ((o = l.style),
                        typeof o.setProperty == "function"
                          ? o.setProperty("display", "none", "important")
                          : (o.display = "none"))
                      : ((u = S.stateNode),
                        (a = S.memoizedProps.style),
                        (i =
                          a != null && a.hasOwnProperty("display")
                            ? a.display
                            : null),
                        (u.style.display = es("display", i))));
                } catch (R) {
                  xe(e, e.return, R);
                }
              }
            } else if (S.tag === 6) {
              if (w === null)
                try {
                  S.stateNode.nodeValue = y ? "" : S.memoizedProps;
                } catch (R) {
                  xe(e, e.return, R);
                }
            } else if (
              ((S.tag !== 22 && S.tag !== 23) ||
                S.memoizedState === null ||
                S === e) &&
              S.child !== null
            ) {
              ((S.child.return = S), (S = S.child));
              continue;
            }
            if (S === e) break e;
            for (; S.sibling === null;) {
              if (S.return === null || S.return === e) break e;
              (w === S && (w = null), (S = S.return));
            }
            (w === S && (w = null),
              (S.sibling.return = S.return),
              (S = S.sibling));
          }
        }
        break;
      case 19:
        (vt(t, e), zt(e), r & 4 && va(e));
        break;
      case 21:
        break;
      default:
        (vt(t, e), zt(e));
    }
  }
  function zt(e) {
    var t = e.flags;
    if (t & 2) {
      try {
        e: {
          for (var n = e.return; n !== null;) {
            if (ma(n)) {
              var r = n;
              break e;
            }
            n = n.return;
          }
          throw Error(f(160));
        }
        switch (r.tag) {
          case 5:
            var l = r.stateNode;
            r.flags & 32 && ($n(l, ""), (r.flags &= -33));
            var o = ya(e);
            yi(e, o, l);
            break;
          case 3:
          case 4:
            var i = r.stateNode.containerInfo,
              u = ya(e);
            mi(e, u, i);
            break;
          default:
            throw Error(f(161));
        }
      } catch (a) {
        xe(e, e.return, a);
      }
      e.flags &= -3;
    }
    t & 4096 && (e.flags &= -4097);
  }
  function Bf(e, t, n) {
    ((P = e), ka(e));
  }
  function ka(e, t, n) {
    for (var r = (e.mode & 1) !== 0; P !== null;) {
      var l = P,
        o = l.child;
      if (l.tag === 22 && r) {
        var i = l.memoizedState !== null || xl;
        if (!i) {
          var u = l.alternate,
            a = (u !== null && u.memoizedState !== null) || $e;
          u = xl;
          var y = $e;
          if (((xl = i), ($e = a) && !y))
            for (P = l; P !== null;)
              ((i = P),
                (a = i.child),
                i.tag === 22 && i.memoizedState !== null
                  ? ja(l)
                  : a !== null
                    ? ((a.return = i), (P = a))
                    : ja(l));
          for (; o !== null;) ((P = o), ka(o), (o = o.sibling));
          ((P = l), (xl = u), ($e = y));
        }
        wa(e);
      } else
        (l.subtreeFlags & 8772) !== 0 && o !== null
          ? ((o.return = l), (P = o))
          : wa(e);
    }
  }
  function wa(e) {
    for (; P !== null;) {
      var t = P;
      if ((t.flags & 8772) !== 0) {
        var n = t.alternate;
        try {
          if ((t.flags & 8772) !== 0)
            switch (t.tag) {
              case 0:
              case 11:
              case 15:
                $e || kl(5, t);
                break;
              case 1:
                var r = t.stateNode;
                if (t.flags & 4 && !$e)
                  if (n === null) r.componentDidMount();
                  else {
                    var l =
                      t.elementType === t.type
                        ? n.memoizedProps
                        : yt(t.type, n.memoizedProps);
                    r.componentDidUpdate(
                      l,
                      n.memoizedState,
                      r.__reactInternalSnapshotBeforeUpdate,
                    );
                  }
                var o = t.updateQueue;
                o !== null && Su(t, o, r);
                break;
              case 3:
                var i = t.updateQueue;
                if (i !== null) {
                  if (((n = null), t.child !== null))
                    switch (t.child.tag) {
                      case 5:
                        n = t.child.stateNode;
                        break;
                      case 1:
                        n = t.child.stateNode;
                    }
                  Su(t, i, n);
                }
                break;
              case 5:
                var u = t.stateNode;
                if (n === null && t.flags & 4) {
                  n = u;
                  var a = t.memoizedProps;
                  switch (t.type) {
                    case "button":
                    case "input":
                    case "select":
                    case "textarea":
                      a.autoFocus && n.focus();
                      break;
                    case "img":
                      a.src && (n.src = a.src);
                  }
                }
                break;
              case 6:
                break;
              case 4:
                break;
              case 12:
                break;
              case 13:
                if (t.memoizedState === null) {
                  var y = t.alternate;
                  if (y !== null) {
                    var w = y.memoizedState;
                    if (w !== null) {
                      var S = w.dehydrated;
                      S !== null && bn(S);
                    }
                  }
                }
                break;
              case 19:
              case 17:
              case 21:
              case 22:
              case 23:
              case 25:
                break;
              default:
                throw Error(f(163));
            }
          $e || (t.flags & 512 && hi(t));
        } catch (x) {
          xe(t, t.return, x);
        }
      }
      if (t === e) {
        P = null;
        break;
      }
      if (((n = t.sibling), n !== null)) {
        ((n.return = t.return), (P = n));
        break;
      }
      P = t.return;
    }
  }
  function Sa(e) {
    for (; P !== null;) {
      var t = P;
      if (t === e) {
        P = null;
        break;
      }
      var n = t.sibling;
      if (n !== null) {
        ((n.return = t.return), (P = n));
        break;
      }
      P = t.return;
    }
  }
  function ja(e) {
    for (; P !== null;) {
      var t = P;
      try {
        switch (t.tag) {
          case 0:
          case 11:
          case 15:
            var n = t.return;
            try {
              kl(4, t);
            } catch (a) {
              xe(t, n, a);
            }
            break;
          case 1:
            var r = t.stateNode;
            if (typeof r.componentDidMount == "function") {
              var l = t.return;
              try {
                r.componentDidMount();
              } catch (a) {
                xe(t, l, a);
              }
            }
            var o = t.return;
            try {
              hi(t);
            } catch (a) {
              xe(t, o, a);
            }
            break;
          case 5:
            var i = t.return;
            try {
              hi(t);
            } catch (a) {
              xe(t, i, a);
            }
        }
      } catch (a) {
        xe(t, t.return, a);
      }
      if (t === e) {
        P = null;
        break;
      }
      var u = t.sibling;
      if (u !== null) {
        ((u.return = t.return), (P = u));
        break;
      }
      P = t.return;
    }
  }
  var Vf = Math.ceil,
    wl = te.ReactCurrentDispatcher,
    gi = te.ReactCurrentOwner,
    ft = te.ReactCurrentBatchConfig,
    Z = 0,
    Ne = null,
    ze = null,
    Ie = 0,
    ot = 0,
    An = Bt(0),
    Me = 0,
    Sr = null,
    fn = 0,
    Sl = 0,
    vi = 0,
    jr = null,
    qe = null,
    xi = 0,
    Un = 1 / 0,
    Rt = null,
    jl = !1,
    ki = null,
    Yt = null,
    zl = !1,
    Xt = null,
    Cl = 0,
    zr = 0,
    wi = null,
    El = -1,
    _l = 0;
  function Qe() {
    return (Z & 6) !== 0 ? we() : El !== -1 ? El : (El = we());
  }
  function qt(e) {
    return (e.mode & 1) === 0
      ? 1
      : (Z & 2) !== 0 && Ie !== 0
        ? Ie & -Ie
        : _f.transition !== null
          ? (_l === 0 && (_l = ys()), _l)
          : ((e = ee),
            e !== 0 ||
              ((e = window.event), (e = e === void 0 ? 16 : Cs(e.type))),
            e);
  }
  function xt(e, t, n, r) {
    if (50 < zr) throw ((zr = 0), (wi = null), Error(f(185)));
    (Gn(e, n, r),
      ((Z & 2) === 0 || e !== Ne) &&
        (e === Ne && ((Z & 2) === 0 && (Sl |= n), Me === 4 && Jt(e, Ie)),
        Je(e, r),
        n === 1 &&
          Z === 0 &&
          (t.mode & 1) === 0 &&
          ((Un = we() + 500), tl && Qt())));
  }
  function Je(e, t) {
    var n = e.callbackNode;
    Ec(e, t);
    var r = Ir(e, e === Ne ? Ie : 0);
    if (r === 0)
      (n !== null && ps(n), (e.callbackNode = null), (e.callbackPriority = 0));
    else if (((t = r & -r), e.callbackPriority !== t)) {
      if ((n != null && ps(n), t === 1))
        (e.tag === 0 ? Ef(Ca.bind(null, e)) : cu(Ca.bind(null, e)),
          Sf(function () {
            (Z & 6) === 0 && Qt();
          }),
          (n = null));
      else {
        switch (gs(r)) {
          case 1:
            n = bl;
            break;
          case 4:
            n = hs;
            break;
          case 16:
            n = Rr;
            break;
          case 536870912:
            n = ms;
            break;
          default:
            n = Rr;
        }
        n = Ta(n, za.bind(null, e));
      }
      ((e.callbackPriority = t), (e.callbackNode = n));
    }
  }
  function za(e, t) {
    if (((El = -1), (_l = 0), (Z & 6) !== 0)) throw Error(f(327));
    var n = e.callbackNode;
    if (Wn() && e.callbackNode !== n) return null;
    var r = Ir(e, e === Ne ? Ie : 0);
    if (r === 0) return null;
    if ((r & 30) !== 0 || (r & e.expiredLanes) !== 0 || t) t = Ml(e, r);
    else {
      t = r;
      var l = Z;
      Z |= 2;
      var o = _a();
      (Ne !== e || Ie !== t) && ((Rt = null), (Un = we() + 500), pn(e, t));
      do
        try {
          Kf();
          break;
        } catch (u) {
          Ea(e, u);
        }
      while (!0);
      (Uo(),
        (wl.current = o),
        (Z = l),
        ze !== null ? (t = 0) : ((Ne = null), (Ie = 0), (t = Me)));
    }
    if (t !== 0) {
      if (
        (t === 2 && ((l = eo(e)), l !== 0 && ((r = l), (t = Si(e, l)))),
        t === 1)
      )
        throw ((n = Sr), pn(e, 0), Jt(e, r), Je(e, we()), n);
      if (t === 6) Jt(e, r);
      else {
        if (
          ((l = e.current.alternate),
          (r & 30) === 0 &&
            !Qf(l) &&
            ((t = Ml(e, r)),
            t === 2 && ((o = eo(e)), o !== 0 && ((r = o), (t = Si(e, o)))),
            t === 1))
        )
          throw ((n = Sr), pn(e, 0), Jt(e, r), Je(e, we()), n);
        switch (((e.finishedWork = l), (e.finishedLanes = r), t)) {
          case 0:
          case 1:
            throw Error(f(345));
          case 2:
            hn(e, qe, Rt);
            break;
          case 3:
            if (
              (Jt(e, r),
              (r & 130023424) === r && ((t = xi + 500 - we()), 10 < t))
            ) {
              if (Ir(e, 0) !== 0) break;
              if (((l = e.suspendedLanes), (l & r) !== r)) {
                (Qe(), (e.pingedLanes |= e.suspendedLanes & l));
                break;
              }
              e.timeoutHandle = Mo(hn.bind(null, e, qe, Rt), t);
              break;
            }
            hn(e, qe, Rt);
            break;
          case 4:
            if ((Jt(e, r), (r & 4194240) === r)) break;
            for (t = e.eventTimes, l = -1; 0 < r;) {
              var i = 31 - pt(r);
              ((o = 1 << i), (i = t[i]), i > l && (l = i), (r &= ~o));
            }
            if (
              ((r = l),
              (r = we() - r),
              (r =
                (120 > r
                  ? 120
                  : 480 > r
                    ? 480
                    : 1080 > r
                      ? 1080
                      : 1920 > r
                        ? 1920
                        : 3e3 > r
                          ? 3e3
                          : 4320 > r
                            ? 4320
                            : 1960 * Vf(r / 1960)) - r),
              10 < r)
            ) {
              e.timeoutHandle = Mo(hn.bind(null, e, qe, Rt), r);
              break;
            }
            hn(e, qe, Rt);
            break;
          case 5:
            hn(e, qe, Rt);
            break;
          default:
            throw Error(f(329));
        }
      }
    }
    return (Je(e, we()), e.callbackNode === n ? za.bind(null, e) : null);
  }
  function Si(e, t) {
    var n = jr;
    return (
      e.current.memoizedState.isDehydrated && (pn(e, t).flags |= 256),
      (e = Ml(e, t)),
      e !== 2 && ((t = qe), (qe = n), t !== null && ji(t)),
      e
    );
  }
  function ji(e) {
    qe === null ? (qe = e) : qe.push.apply(qe, e);
  }
  function Qf(e) {
    for (var t = e; ;) {
      if (t.flags & 16384) {
        var n = t.updateQueue;
        if (n !== null && ((n = n.stores), n !== null))
          for (var r = 0; r < n.length; r++) {
            var l = n[r],
              o = l.getSnapshot;
            l = l.value;
            try {
              if (!ht(o(), l)) return !1;
            } catch {
              return !1;
            }
          }
      }
      if (((n = t.child), t.subtreeFlags & 16384 && n !== null))
        ((n.return = t), (t = n));
      else {
        if (t === e) break;
        for (; t.sibling === null;) {
          if (t.return === null || t.return === e) return !0;
          t = t.return;
        }
        ((t.sibling.return = t.return), (t = t.sibling));
      }
    }
    return !0;
  }
  function Jt(e, t) {
    for (
      t &= ~vi,
        t &= ~Sl,
        e.suspendedLanes |= t,
        e.pingedLanes &= ~t,
        e = e.expirationTimes;
      0 < t;
    ) {
      var n = 31 - pt(t),
        r = 1 << n;
      ((e[n] = -1), (t &= ~r));
    }
  }
  function Ca(e) {
    if ((Z & 6) !== 0) throw Error(f(327));
    Wn();
    var t = Ir(e, 0);
    if ((t & 1) === 0) return (Je(e, we()), null);
    var n = Ml(e, t);
    if (e.tag !== 0 && n === 2) {
      var r = eo(e);
      r !== 0 && ((t = r), (n = Si(e, r)));
    }
    if (n === 1) throw ((n = Sr), pn(e, 0), Jt(e, t), Je(e, we()), n);
    if (n === 6) throw Error(f(345));
    return (
      (e.finishedWork = e.current.alternate),
      (e.finishedLanes = t),
      hn(e, qe, Rt),
      Je(e, we()),
      null
    );
  }
  function zi(e, t) {
    var n = Z;
    Z |= 1;
    try {
      return e(t);
    } finally {
      ((Z = n), Z === 0 && ((Un = we() + 500), tl && Qt()));
    }
  }
  function dn(e) {
    Xt !== null && Xt.tag === 0 && (Z & 6) === 0 && Wn();
    var t = Z;
    Z |= 1;
    var n = ft.transition,
      r = ee;
    try {
      if (((ft.transition = null), (ee = 1), e)) return e();
    } finally {
      ((ee = r), (ft.transition = n), (Z = t), (Z & 6) === 0 && Qt());
    }
  }
  function Ci() {
    ((ot = An.current), ce(An));
  }
  function pn(e, t) {
    ((e.finishedWork = null), (e.finishedLanes = 0));
    var n = e.timeoutHandle;
    if ((n !== -1 && ((e.timeoutHandle = -1), wf(n)), ze !== null))
      for (n = ze.return; n !== null;) {
        var r = n;
        switch ((Oo(r), r.tag)) {
          case 1:
            ((r = r.type.childContextTypes), r != null && br());
            break;
          case 3:
            (Dn(), ce(Ge), ce(Ue), Ko());
            break;
          case 5:
            Qo(r);
            break;
          case 4:
            Dn();
            break;
          case 13:
            ce(me);
            break;
          case 19:
            ce(me);
            break;
          case 10:
            Wo(r.type._context);
            break;
          case 22:
          case 23:
            Ci();
        }
        n = n.return;
      }
    if (
      ((Ne = e),
      (ze = e = bt(e.current, null)),
      (Ie = ot = t),
      (Me = 0),
      (Sr = null),
      (vi = Sl = fn = 0),
      (qe = jr = null),
      un !== null)
    ) {
      for (t = 0; t < un.length; t++)
        if (((n = un[t]), (r = n.interleaved), r !== null)) {
          n.interleaved = null;
          var l = r.next,
            o = n.pending;
          if (o !== null) {
            var i = o.next;
            ((o.next = l), (r.next = i));
          }
          n.pending = r;
        }
      un = null;
    }
    return e;
  }
  function Ea(e, t) {
    do {
      var n = ze;
      try {
        if ((Uo(), (fl.current = ml), dl)) {
          for (var r = ye.memoizedState; r !== null;) {
            var l = r.queue;
            (l !== null && (l.pending = null), (r = r.next));
          }
          dl = !1;
        }
        if (
          ((cn = 0),
          (Le = _e = ye = null),
          (yr = !1),
          (gr = 0),
          (gi.current = null),
          n === null || n.return === null)
        ) {
          ((Me = 1), (Sr = t), (ze = null));
          break;
        }
        e: {
          var o = e,
            i = n.return,
            u = n,
            a = t;
          if (
            ((t = Ie),
            (u.flags |= 32768),
            a !== null && typeof a == "object" && typeof a.then == "function")
          ) {
            var y = a,
              w = u,
              S = w.tag;
            if ((w.mode & 1) === 0 && (S === 0 || S === 11 || S === 15)) {
              var x = w.alternate;
              x
                ? ((w.updateQueue = x.updateQueue),
                  (w.memoizedState = x.memoizedState),
                  (w.lanes = x.lanes))
                : ((w.updateQueue = null), (w.memoizedState = null));
            }
            var _ = qu(i);
            if (_ !== null) {
              ((_.flags &= -257),
                Ju(_, i, u, o, t),
                _.mode & 1 && Xu(o, y, t),
                (t = _),
                (a = y));
              var N = t.updateQueue;
              if (N === null) {
                var R = new Set();
                (R.add(a), (t.updateQueue = R));
              } else N.add(a);
              break e;
            } else {
              if ((t & 1) === 0) {
                (Xu(o, y, t), Ei());
                break e;
              }
              a = Error(f(426));
            }
          } else if (he && u.mode & 1) {
            var Se = qu(i);
            if (Se !== null) {
              ((Se.flags & 65536) === 0 && (Se.flags |= 256),
                Ju(Se, i, u, o, t),
                Fo(In(a, u)));
              break e;
            }
          }
          ((o = a = In(a, u)),
            Me !== 4 && (Me = 2),
            jr === null ? (jr = [o]) : jr.push(o),
            (o = i));
          do {
            switch (o.tag) {
              case 3:
                ((o.flags |= 65536), (t &= -t), (o.lanes |= t));
                var h = Gu(o, a, t);
                wu(o, h);
                break e;
              case 1:
                u = a;
                var c = o.type,
                  m = o.stateNode;
                if (
                  (o.flags & 128) === 0 &&
                  (typeof c.getDerivedStateFromError == "function" ||
                    (m !== null &&
                      typeof m.componentDidCatch == "function" &&
                      (Yt === null || !Yt.has(m))))
                ) {
                  ((o.flags |= 65536), (t &= -t), (o.lanes |= t));
                  var z = Yu(o, u, t);
                  wu(o, z);
                  break e;
                }
            }
            o = o.return;
          } while (o !== null);
        }
        Pa(n);
      } catch (T) {
        ((t = T), ze === n && n !== null && (ze = n = n.return));
        continue;
      }
      break;
    } while (!0);
  }
  function _a() {
    var e = wl.current;
    return ((wl.current = ml), e === null ? ml : e);
  }
  function Ei() {
    ((Me === 0 || Me === 3 || Me === 2) && (Me = 4),
      Ne === null ||
        ((fn & 268435455) === 0 && (Sl & 268435455) === 0) ||
        Jt(Ne, Ie));
  }
  function Ml(e, t) {
    var n = Z;
    Z |= 2;
    var r = _a();
    (Ne !== e || Ie !== t) && ((Rt = null), pn(e, t));
    do
      try {
        Zf();
        break;
      } catch (l) {
        Ea(e, l);
      }
    while (!0);
    if ((Uo(), (Z = n), (wl.current = r), ze !== null)) throw Error(f(261));
    return ((Ne = null), (Ie = 0), Me);
  }
  function Zf() {
    for (; ze !== null;) Ma(ze);
  }
  function Kf() {
    for (; ze !== null && !gc();) Ma(ze);
  }
  function Ma(e) {
    var t = Ra(e.alternate, e, ot);
    ((e.memoizedProps = e.pendingProps),
      t === null ? Pa(e) : (ze = t),
      (gi.current = null));
  }
  function Pa(e) {
    var t = e;
    do {
      var n = t.alternate;
      if (((e = t.return), (t.flags & 32768) === 0)) {
        if (((n = Uf(n, t, ot)), n !== null)) {
          ze = n;
          return;
        }
      } else {
        if (((n = Wf(n, t)), n !== null)) {
          ((n.flags &= 32767), (ze = n));
          return;
        }
        if (e !== null)
          ((e.flags |= 32768), (e.subtreeFlags = 0), (e.deletions = null));
        else {
          ((Me = 6), (ze = null));
          return;
        }
      }
      if (((t = t.sibling), t !== null)) {
        ze = t;
        return;
      }
      ze = t = e;
    } while (t !== null);
    Me === 0 && (Me = 5);
  }
  function hn(e, t, n) {
    var r = ee,
      l = ft.transition;
    try {
      ((ft.transition = null), (ee = 1), Gf(e, t, n, r));
    } finally {
      ((ft.transition = l), (ee = r));
    }
    return null;
  }
  function Gf(e, t, n, r) {
    do Wn();
    while (Xt !== null);
    if ((Z & 6) !== 0) throw Error(f(327));
    n = e.finishedWork;
    var l = e.finishedLanes;
    if (n === null) return null;
    if (((e.finishedWork = null), (e.finishedLanes = 0), n === e.current))
      throw Error(f(177));
    ((e.callbackNode = null), (e.callbackPriority = 0));
    var o = n.lanes | n.childLanes;
    if (
      (_c(e, o),
      e === Ne && ((ze = Ne = null), (Ie = 0)),
      ((n.subtreeFlags & 2064) === 0 && (n.flags & 2064) === 0) ||
        zl ||
        ((zl = !0),
        Ta(Rr, function () {
          return (Wn(), null);
        })),
      (o = (n.flags & 15990) !== 0),
      (n.subtreeFlags & 15990) !== 0 || o)
    ) {
      ((o = ft.transition), (ft.transition = null));
      var i = ee;
      ee = 1;
      var u = Z;
      ((Z |= 4),
        (gi.current = null),
        $f(e, n),
        xa(n, e),
        hf(Eo),
        (Ur = !!Co),
        (Eo = Co = null),
        (e.current = n),
        Bf(n),
        vc(),
        (Z = u),
        (ee = i),
        (ft.transition = o));
    } else e.current = n;
    if (
      (zl && ((zl = !1), (Xt = e), (Cl = l)),
      (o = e.pendingLanes),
      o === 0 && (Yt = null),
      wc(n.stateNode),
      Je(e, we()),
      t !== null)
    )
      for (r = e.onRecoverableError, n = 0; n < t.length; n++)
        ((l = t[n]), r(l.value, { componentStack: l.stack, digest: l.digest }));
    if (jl) throw ((jl = !1), (e = ki), (ki = null), e);
    return (
      (Cl & 1) !== 0 && e.tag !== 0 && Wn(),
      (o = e.pendingLanes),
      (o & 1) !== 0 ? (e === wi ? zr++ : ((zr = 0), (wi = e))) : (zr = 0),
      Qt(),
      null
    );
  }
  function Wn() {
    if (Xt !== null) {
      var e = gs(Cl),
        t = ft.transition,
        n = ee;
      try {
        if (((ft.transition = null), (ee = 16 > e ? 16 : e), Xt === null))
          var r = !1;
        else {
          if (((e = Xt), (Xt = null), (Cl = 0), (Z & 6) !== 0))
            throw Error(f(331));
          var l = Z;
          for (Z |= 4, P = e.current; P !== null;) {
            var o = P,
              i = o.child;
            if ((P.flags & 16) !== 0) {
              var u = o.deletions;
              if (u !== null) {
                for (var a = 0; a < u.length; a++) {
                  var y = u[a];
                  for (P = y; P !== null;) {
                    var w = P;
                    switch (w.tag) {
                      case 0:
                      case 11:
                      case 15:
                        wr(8, w, o);
                    }
                    var S = w.child;
                    if (S !== null) ((S.return = w), (P = S));
                    else
                      for (; P !== null;) {
                        w = P;
                        var x = w.sibling,
                          _ = w.return;
                        if ((ha(w), w === y)) {
                          P = null;
                          break;
                        }
                        if (x !== null) {
                          ((x.return = _), (P = x));
                          break;
                        }
                        P = _;
                      }
                  }
                }
                var N = o.alternate;
                if (N !== null) {
                  var R = N.child;
                  if (R !== null) {
                    N.child = null;
                    do {
                      var Se = R.sibling;
                      ((R.sibling = null), (R = Se));
                    } while (R !== null);
                  }
                }
                P = o;
              }
            }
            if ((o.subtreeFlags & 2064) !== 0 && i !== null)
              ((i.return = o), (P = i));
            else
              e: for (; P !== null;) {
                if (((o = P), (o.flags & 2048) !== 0))
                  switch (o.tag) {
                    case 0:
                    case 11:
                    case 15:
                      wr(9, o, o.return);
                  }
                var h = o.sibling;
                if (h !== null) {
                  ((h.return = o.return), (P = h));
                  break e;
                }
                P = o.return;
              }
          }
          var c = e.current;
          for (P = c; P !== null;) {
            i = P;
            var m = i.child;
            if ((i.subtreeFlags & 2064) !== 0 && m !== null)
              ((m.return = i), (P = m));
            else
              e: for (i = c; P !== null;) {
                if (((u = P), (u.flags & 2048) !== 0))
                  try {
                    switch (u.tag) {
                      case 0:
                      case 11:
                      case 15:
                        kl(9, u);
                    }
                  } catch (T) {
                    xe(u, u.return, T);
                  }
                if (u === i) {
                  P = null;
                  break e;
                }
                var z = u.sibling;
                if (z !== null) {
                  ((z.return = u.return), (P = z));
                  break e;
                }
                P = u.return;
              }
          }
          if (
            ((Z = l), Qt(), kt && typeof kt.onPostCommitFiberRoot == "function")
          )
            try {
              kt.onPostCommitFiberRoot(Tr, e);
            } catch {}
          r = !0;
        }
        return r;
      } finally {
        ((ee = n), (ft.transition = t));
      }
    }
    return !1;
  }
  function La(e, t, n) {
    ((t = In(n, t)),
      (t = Gu(e, t, 1)),
      (e = Kt(e, t, 1)),
      (t = Qe()),
      e !== null && (Gn(e, 1, t), Je(e, t)));
  }
  function xe(e, t, n) {
    if (e.tag === 3) La(e, e, n);
    else
      for (; t !== null;) {
        if (t.tag === 3) {
          La(t, e, n);
          break;
        } else if (t.tag === 1) {
          var r = t.stateNode;
          if (
            typeof t.type.getDerivedStateFromError == "function" ||
            (typeof r.componentDidCatch == "function" &&
              (Yt === null || !Yt.has(r)))
          ) {
            ((e = In(n, e)),
              (e = Yu(t, e, 1)),
              (t = Kt(t, e, 1)),
              (e = Qe()),
              t !== null && (Gn(t, 1, e), Je(t, e)));
            break;
          }
        }
        t = t.return;
      }
  }
  function Yf(e, t, n) {
    var r = e.pingCache;
    (r !== null && r.delete(t),
      (t = Qe()),
      (e.pingedLanes |= e.suspendedLanes & n),
      Ne === e &&
        (Ie & n) === n &&
        (Me === 4 || (Me === 3 && (Ie & 130023424) === Ie && 500 > we() - xi)
          ? pn(e, 0)
          : (vi |= n)),
      Je(e, t));
  }
  function Na(e, t) {
    t === 0 &&
      ((e.mode & 1) === 0
        ? (t = 1)
        : ((t = Dr), (Dr <<= 1), (Dr & 130023424) === 0 && (Dr = 4194304)));
    var n = Qe();
    ((e = Pt(e, t)), e !== null && (Gn(e, t, n), Je(e, n)));
  }
  function Xf(e) {
    var t = e.memoizedState,
      n = 0;
    (t !== null && (n = t.retryLane), Na(e, n));
  }
  function qf(e, t) {
    var n = 0;
    switch (e.tag) {
      case 13:
        var r = e.stateNode,
          l = e.memoizedState;
        l !== null && (n = l.retryLane);
        break;
      case 19:
        r = e.stateNode;
        break;
      default:
        throw Error(f(314));
    }
    (r !== null && r.delete(t), Na(e, n));
  }
  var Ra;
  Ra = function (e, t, n) {
    if (e !== null)
      if (e.memoizedProps !== t.pendingProps || Ge.current) Xe = !0;
      else {
        if ((e.lanes & n) === 0 && (t.flags & 128) === 0)
          return ((Xe = !1), Af(e, t, n));
        Xe = (e.flags & 131072) !== 0;
      }
    else ((Xe = !1), he && (t.flags & 1048576) !== 0 && fu(t, rl, t.index));
    switch (((t.lanes = 0), t.tag)) {
      case 2:
        var r = t.type;
        (vl(e, t), (e = t.pendingProps));
        var l = Mn(t, Ue.current);
        (On(t, n), (l = Xo(null, t, r, e, l, n)));
        var o = qo();
        return (
          (t.flags |= 1),
          typeof l == "object" &&
          l !== null &&
          typeof l.render == "function" &&
          l.$$typeof === void 0
            ? ((t.tag = 1),
              (t.memoizedState = null),
              (t.updateQueue = null),
              Ye(r) ? ((o = !0), el(t)) : (o = !1),
              (t.memoizedState =
                l.state !== null && l.state !== void 0 ? l.state : null),
              Bo(t),
              (l.updater = yl),
              (t.stateNode = l),
              (l._reactInternals = t),
              ri(t, r, e, n),
              (t = si(null, t, r, !0, o, n)))
            : ((t.tag = 0), he && o && To(t), Ve(null, t, l, n), (t = t.child)),
          t
        );
      case 16:
        r = t.elementType;
        e: {
          switch (
            (vl(e, t),
            (e = t.pendingProps),
            (l = r._init),
            (r = l(r._payload)),
            (t.type = r),
            (l = t.tag = bf(r)),
            (e = yt(r, e)),
            l)
          ) {
            case 0:
              t = ii(null, t, r, e, n);
              break e;
            case 1:
              t = la(null, t, r, e, n);
              break e;
            case 11:
              t = bu(null, t, r, e, n);
              break e;
            case 14:
              t = ea(null, t, r, yt(r.type, e), n);
              break e;
          }
          throw Error(f(306, r, ""));
        }
        return t;
      case 0:
        return (
          (r = t.type),
          (l = t.pendingProps),
          (l = t.elementType === r ? l : yt(r, l)),
          ii(e, t, r, l, n)
        );
      case 1:
        return (
          (r = t.type),
          (l = t.pendingProps),
          (l = t.elementType === r ? l : yt(r, l)),
          la(e, t, r, l, n)
        );
      case 3:
        e: {
          if ((oa(t), e === null)) throw Error(f(387));
          ((r = t.pendingProps),
            (o = t.memoizedState),
            (l = o.element),
            ku(e, t),
            al(t, r, null, n));
          var i = t.memoizedState;
          if (((r = i.element), o.isDehydrated))
            if (
              ((o = {
                element: r,
                isDehydrated: !1,
                cache: i.cache,
                pendingSuspenseBoundaries: i.pendingSuspenseBoundaries,
                transitions: i.transitions,
              }),
              (t.updateQueue.baseState = o),
              (t.memoizedState = o),
              t.flags & 256)
            ) {
              ((l = In(Error(f(423)), t)), (t = ia(e, t, r, n, l)));
              break e;
            } else if (r !== l) {
              ((l = In(Error(f(424)), t)), (t = ia(e, t, r, n, l)));
              break e;
            } else
              for (
                lt = $t(t.stateNode.containerInfo.firstChild),
                  rt = t,
                  he = !0,
                  mt = null,
                  n = vu(t, null, r, n),
                  t.child = n;
                n;
              )
                ((n.flags = (n.flags & -3) | 4096), (n = n.sibling));
          else {
            if ((Nn(), r === l)) {
              t = Nt(e, t, n);
              break e;
            }
            Ve(e, t, r, n);
          }
          t = t.child;
        }
        return t;
      case 5:
        return (
          ju(t),
          e === null && Io(t),
          (r = t.type),
          (l = t.pendingProps),
          (o = e !== null ? e.memoizedProps : null),
          (i = l.children),
          _o(r, l) ? (i = null) : o !== null && _o(r, o) && (t.flags |= 32),
          ra(e, t),
          Ve(e, t, i, n),
          t.child
        );
      case 6:
        return (e === null && Io(t), null);
      case 13:
        return sa(e, t, n);
      case 4:
        return (
          Vo(t, t.stateNode.containerInfo),
          (r = t.pendingProps),
          e === null ? (t.child = Rn(t, null, r, n)) : Ve(e, t, r, n),
          t.child
        );
      case 11:
        return (
          (r = t.type),
          (l = t.pendingProps),
          (l = t.elementType === r ? l : yt(r, l)),
          bu(e, t, r, l, n)
        );
      case 7:
        return (Ve(e, t, t.pendingProps, n), t.child);
      case 8:
        return (Ve(e, t, t.pendingProps.children, n), t.child);
      case 12:
        return (Ve(e, t, t.pendingProps.children, n), t.child);
      case 10:
        e: {
          if (
            ((r = t.type._context),
            (l = t.pendingProps),
            (o = t.memoizedProps),
            (i = l.value),
            se(il, r._currentValue),
            (r._currentValue = i),
            o !== null)
          )
            if (ht(o.value, i)) {
              if (o.children === l.children && !Ge.current) {
                t = Nt(e, t, n);
                break e;
              }
            } else
              for (o = t.child, o !== null && (o.return = t); o !== null;) {
                var u = o.dependencies;
                if (u !== null) {
                  i = o.child;
                  for (var a = u.firstContext; a !== null;) {
                    if (a.context === r) {
                      if (o.tag === 1) {
                        ((a = Lt(-1, n & -n)), (a.tag = 2));
                        var y = o.updateQueue;
                        if (y !== null) {
                          y = y.shared;
                          var w = y.pending;
                          (w === null
                            ? (a.next = a)
                            : ((a.next = w.next), (w.next = a)),
                            (y.pending = a));
                        }
                      }
                      ((o.lanes |= n),
                        (a = o.alternate),
                        a !== null && (a.lanes |= n),
                        Ho(o.return, n, t),
                        (u.lanes |= n));
                      break;
                    }
                    a = a.next;
                  }
                } else if (o.tag === 10) i = o.type === t.type ? null : o.child;
                else if (o.tag === 18) {
                  if (((i = o.return), i === null)) throw Error(f(341));
                  ((i.lanes |= n),
                    (u = i.alternate),
                    u !== null && (u.lanes |= n),
                    Ho(i, n, t),
                    (i = o.sibling));
                } else i = o.child;
                if (i !== null) i.return = o;
                else
                  for (i = o; i !== null;) {
                    if (i === t) {
                      i = null;
                      break;
                    }
                    if (((o = i.sibling), o !== null)) {
                      ((o.return = i.return), (i = o));
                      break;
                    }
                    i = i.return;
                  }
                o = i;
              }
          (Ve(e, t, l.children, n), (t = t.child));
        }
        return t;
      case 9:
        return (
          (l = t.type),
          (r = t.pendingProps.children),
          On(t, n),
          (l = at(l)),
          (r = r(l)),
          (t.flags |= 1),
          Ve(e, t, r, n),
          t.child
        );
      case 14:
        return (
          (r = t.type),
          (l = yt(r, t.pendingProps)),
          (l = yt(r.type, l)),
          ea(e, t, r, l, n)
        );
      case 15:
        return ta(e, t, t.type, t.pendingProps, n);
      case 17:
        return (
          (r = t.type),
          (l = t.pendingProps),
          (l = t.elementType === r ? l : yt(r, l)),
          vl(e, t),
          (t.tag = 1),
          Ye(r) ? ((e = !0), el(t)) : (e = !1),
          On(t, n),
          Zu(t, r, l),
          ri(t, r, l, n),
          si(null, t, r, !0, e, n)
        );
      case 19:
        return aa(e, t, n);
      case 22:
        return na(e, t, n);
    }
    throw Error(f(156, t.tag));
  };
  function Ta(e, t) {
    return ds(e, t);
  }
  function Jf(e, t, n, r) {
    ((this.tag = e),
      (this.key = n),
      (this.sibling =
        this.child =
        this.return =
        this.stateNode =
        this.type =
        this.elementType =
          null),
      (this.index = 0),
      (this.ref = null),
      (this.pendingProps = t),
      (this.dependencies =
        this.memoizedState =
        this.updateQueue =
        this.memoizedProps =
          null),
      (this.mode = r),
      (this.subtreeFlags = this.flags = 0),
      (this.deletions = null),
      (this.childLanes = this.lanes = 0),
      (this.alternate = null));
  }
  function dt(e, t, n, r) {
    return new Jf(e, t, n, r);
  }
  function _i(e) {
    return ((e = e.prototype), !(!e || !e.isReactComponent));
  }
  function bf(e) {
    if (typeof e == "function") return _i(e) ? 1 : 0;
    if (e != null) {
      if (((e = e.$$typeof), e === Ae)) return 11;
      if (e === de) return 14;
    }
    return 2;
  }
  function bt(e, t) {
    var n = e.alternate;
    return (
      n === null
        ? ((n = dt(e.tag, t, e.key, e.mode)),
          (n.elementType = e.elementType),
          (n.type = e.type),
          (n.stateNode = e.stateNode),
          (n.alternate = e),
          (e.alternate = n))
        : ((n.pendingProps = t),
          (n.type = e.type),
          (n.flags = 0),
          (n.subtreeFlags = 0),
          (n.deletions = null)),
      (n.flags = e.flags & 14680064),
      (n.childLanes = e.childLanes),
      (n.lanes = e.lanes),
      (n.child = e.child),
      (n.memoizedProps = e.memoizedProps),
      (n.memoizedState = e.memoizedState),
      (n.updateQueue = e.updateQueue),
      (t = e.dependencies),
      (n.dependencies =
        t === null ? null : { lanes: t.lanes, firstContext: t.firstContext }),
      (n.sibling = e.sibling),
      (n.index = e.index),
      (n.ref = e.ref),
      n
    );
  }
  function Pl(e, t, n, r, l, o) {
    var i = 2;
    if (((r = e), typeof e == "function")) _i(e) && (i = 1);
    else if (typeof e == "string") i = 5;
    else
      e: switch (e) {
        case ue:
          return mn(n.children, l, o, t);
        case je:
          ((i = 8), (l |= 8));
          break;
        case Ke:
          return (
            (e = dt(12, n, t, l | 2)),
            (e.elementType = Ke),
            (e.lanes = o),
            e
          );
        case Ee:
          return (
            (e = dt(13, n, t, l)),
            (e.elementType = Ee),
            (e.lanes = o),
            e
          );
        case oe:
          return (
            (e = dt(19, n, t, l)),
            (e.elementType = oe),
            (e.lanes = o),
            e
          );
        case le:
          return Ll(n, l, o, t);
        default:
          if (typeof e == "object" && e !== null)
            switch (e.$$typeof) {
              case et:
                i = 10;
                break e;
              case it:
                i = 9;
                break e;
              case Ae:
                i = 11;
                break e;
              case de:
                i = 14;
                break e;
              case ve:
                ((i = 16), (r = null));
                break e;
            }
          throw Error(f(130, e == null ? e : typeof e, ""));
      }
    return (
      (t = dt(i, n, t, l)),
      (t.elementType = e),
      (t.type = r),
      (t.lanes = o),
      t
    );
  }
  function mn(e, t, n, r) {
    return ((e = dt(7, e, r, t)), (e.lanes = n), e);
  }
  function Ll(e, t, n, r) {
    return (
      (e = dt(22, e, r, t)),
      (e.elementType = le),
      (e.lanes = n),
      (e.stateNode = { isHidden: !1 }),
      e
    );
  }
  function Mi(e, t, n) {
    return ((e = dt(6, e, null, t)), (e.lanes = n), e);
  }
  function Pi(e, t, n) {
    return (
      (t = dt(4, e.children !== null ? e.children : [], e.key, t)),
      (t.lanes = n),
      (t.stateNode = {
        containerInfo: e.containerInfo,
        pendingChildren: null,
        implementation: e.implementation,
      }),
      t
    );
  }
  function ed(e, t, n, r, l) {
    ((this.tag = t),
      (this.containerInfo = e),
      (this.finishedWork =
        this.pingCache =
        this.current =
        this.pendingChildren =
          null),
      (this.timeoutHandle = -1),
      (this.callbackNode = this.pendingContext = this.context = null),
      (this.callbackPriority = 0),
      (this.eventTimes = to(0)),
      (this.expirationTimes = to(-1)),
      (this.entangledLanes =
        this.finishedLanes =
        this.mutableReadLanes =
        this.expiredLanes =
        this.pingedLanes =
        this.suspendedLanes =
        this.pendingLanes =
          0),
      (this.entanglements = to(0)),
      (this.identifierPrefix = r),
      (this.onRecoverableError = l),
      (this.mutableSourceEagerHydrationData = null));
  }
  function Li(e, t, n, r, l, o, i, u, a) {
    return (
      (e = new ed(e, t, n, u, a)),
      t === 1 ? ((t = 1), o === !0 && (t |= 8)) : (t = 0),
      (o = dt(3, null, null, t)),
      (e.current = o),
      (o.stateNode = e),
      (o.memoizedState = {
        element: r,
        isDehydrated: n,
        cache: null,
        transitions: null,
        pendingSuspenseBoundaries: null,
      }),
      Bo(o),
      e
    );
  }
  function td(e, t, n) {
    var r =
      3 < arguments.length && arguments[3] !== void 0 ? arguments[3] : null;
    return {
      $$typeof: ne,
      key: r == null ? null : "" + r,
      children: e,
      containerInfo: t,
      implementation: n,
    };
  }
  function Oa(e) {
    if (!e) return Vt;
    e = e._reactInternals;
    e: {
      if (nn(e) !== e || e.tag !== 1) throw Error(f(170));
      var t = e;
      do {
        switch (t.tag) {
          case 3:
            t = t.stateNode.context;
            break e;
          case 1:
            if (Ye(t.type)) {
              t = t.stateNode.__reactInternalMemoizedMergedChildContext;
              break e;
            }
        }
        t = t.return;
      } while (t !== null);
      throw Error(f(171));
    }
    if (e.tag === 1) {
      var n = e.type;
      if (Ye(n)) return uu(e, n, t);
    }
    return t;
  }
  function Da(e, t, n, r, l, o, i, u, a) {
    return (
      (e = Li(n, r, !0, e, l, o, i, u, a)),
      (e.context = Oa(null)),
      (n = e.current),
      (r = Qe()),
      (l = qt(n)),
      (o = Lt(r, l)),
      (o.callback = t ?? null),
      Kt(n, o, l),
      (e.current.lanes = l),
      Gn(e, l, r),
      Je(e, r),
      e
    );
  }
  function Nl(e, t, n, r) {
    var l = t.current,
      o = Qe(),
      i = qt(l);
    return (
      (n = Oa(n)),
      t.context === null ? (t.context = n) : (t.pendingContext = n),
      (t = Lt(o, i)),
      (t.payload = { element: e }),
      (r = r === void 0 ? null : r),
      r !== null && (t.callback = r),
      (e = Kt(l, t, i)),
      e !== null && (xt(e, l, i, o), ul(e, l, i)),
      i
    );
  }
  function Rl(e) {
    if (((e = e.current), !e.child)) return null;
    switch (e.child.tag) {
      case 5:
        return e.child.stateNode;
      default:
        return e.child.stateNode;
    }
  }
  function Ia(e, t) {
    if (((e = e.memoizedState), e !== null && e.dehydrated !== null)) {
      var n = e.retryLane;
      e.retryLane = n !== 0 && n < t ? n : t;
    }
  }
  function Ni(e, t) {
    (Ia(e, t), (e = e.alternate) && Ia(e, t));
  }
  function nd() {
    return null;
  }
  var Fa =
    typeof reportError == "function"
      ? reportError
      : function (e) {
          console.error(e);
        };
  function Ri(e) {
    this._internalRoot = e;
  }
  ((Tl.prototype.render = Ri.prototype.render =
    function (e) {
      var t = this._internalRoot;
      if (t === null) throw Error(f(409));
      Nl(e, t, null, null);
    }),
    (Tl.prototype.unmount = Ri.prototype.unmount =
      function () {
        var e = this._internalRoot;
        if (e !== null) {
          this._internalRoot = null;
          var t = e.containerInfo;
          (dn(function () {
            Nl(null, e, null, null);
          }),
            (t[Ct] = null));
        }
      }));
  function Tl(e) {
    this._internalRoot = e;
  }
  Tl.prototype.unstable_scheduleHydration = function (e) {
    if (e) {
      var t = ks();
      e = { blockedOn: null, target: e, priority: t };
      for (var n = 0; n < Ut.length && t !== 0 && t < Ut[n].priority; n++);
      (Ut.splice(n, 0, e), n === 0 && js(e));
    }
  };
  function Ti(e) {
    return !(!e || (e.nodeType !== 1 && e.nodeType !== 9 && e.nodeType !== 11));
  }
  function Ol(e) {
    return !(
      !e ||
      (e.nodeType !== 1 &&
        e.nodeType !== 9 &&
        e.nodeType !== 11 &&
        (e.nodeType !== 8 || e.nodeValue !== " react-mount-point-unstable "))
    );
  }
  function Aa() {}
  function rd(e, t, n, r, l) {
    if (l) {
      if (typeof r == "function") {
        var o = r;
        r = function () {
          var y = Rl(i);
          o.call(y);
        };
      }
      var i = Da(t, r, e, 0, null, !1, !1, "", Aa);
      return (
        (e._reactRootContainer = i),
        (e[Ct] = i.current),
        ur(e.nodeType === 8 ? e.parentNode : e),
        dn(),
        i
      );
    }
    for (; (l = e.lastChild);) e.removeChild(l);
    if (typeof r == "function") {
      var u = r;
      r = function () {
        var y = Rl(a);
        u.call(y);
      };
    }
    var a = Li(e, 0, !1, null, null, !1, !1, "", Aa);
    return (
      (e._reactRootContainer = a),
      (e[Ct] = a.current),
      ur(e.nodeType === 8 ? e.parentNode : e),
      dn(function () {
        Nl(t, a, n, r);
      }),
      a
    );
  }
  function Dl(e, t, n, r, l) {
    var o = n._reactRootContainer;
    if (o) {
      var i = o;
      if (typeof l == "function") {
        var u = l;
        l = function () {
          var a = Rl(i);
          u.call(a);
        };
      }
      Nl(t, i, e, l);
    } else i = rd(n, t, e, l, r);
    return Rl(i);
  }
  ((vs = function (e) {
    switch (e.tag) {
      case 3:
        var t = e.stateNode;
        if (t.current.memoizedState.isDehydrated) {
          var n = Kn(t.pendingLanes);
          n !== 0 &&
            (no(t, n | 1),
            Je(t, we()),
            (Z & 6) === 0 && ((Un = we() + 500), Qt()));
        }
        break;
      case 13:
        (dn(function () {
          var r = Pt(e, 1);
          if (r !== null) {
            var l = Qe();
            xt(r, e, 1, l);
          }
        }),
          Ni(e, 1));
    }
  }),
    (ro = function (e) {
      if (e.tag === 13) {
        var t = Pt(e, 134217728);
        if (t !== null) {
          var n = Qe();
          xt(t, e, 134217728, n);
        }
        Ni(e, 134217728);
      }
    }),
    (xs = function (e) {
      if (e.tag === 13) {
        var t = qt(e),
          n = Pt(e, t);
        if (n !== null) {
          var r = Qe();
          xt(n, e, t, r);
        }
        Ni(e, t);
      }
    }),
    (ks = function () {
      return ee;
    }),
    (ws = function (e, t) {
      var n = ee;
      try {
        return ((ee = e), t());
      } finally {
        ee = n;
      }
    }),
    (Yl = function (e, t, n) {
      switch (t) {
        case "input":
          if ((Hl(e, n), (t = n.name), n.type === "radio" && t != null)) {
            for (n = e; n.parentNode;) n = n.parentNode;
            for (
              n = n.querySelectorAll(
                "input[name=" + JSON.stringify("" + t) + '][type="radio"]',
              ),
                t = 0;
              t < n.length;
              t++
            ) {
              var r = n[t];
              if (r !== e && r.form === e.form) {
                var l = Jr(r);
                if (!l) throw Error(f(90));
                (Qi(r), Hl(r, l));
              }
            }
          }
          break;
        case "textarea":
          Xi(e, n);
          break;
        case "select":
          ((t = n.value), t != null && yn(e, !!n.multiple, t, !1));
      }
    }),
    (os = zi),
    (is = dn));
  var ld = { usingClientEntryPoint: !1, Events: [fr, En, Jr, rs, ls, zi] },
    Cr = {
      findFiberByHostInstance: rn,
      bundleType: 0,
      version: "18.3.1",
      rendererPackageName: "react-dom",
    },
    od = {
      bundleType: Cr.bundleType,
      version: Cr.version,
      rendererPackageName: Cr.rendererPackageName,
      rendererConfig: Cr.rendererConfig,
      overrideHookState: null,
      overrideHookStateDeletePath: null,
      overrideHookStateRenamePath: null,
      overrideProps: null,
      overridePropsDeletePath: null,
      overridePropsRenamePath: null,
      setErrorHandler: null,
      setSuspenseHandler: null,
      scheduleUpdate: null,
      currentDispatcherRef: te.ReactCurrentDispatcher,
      findHostInstanceByFiber: function (e) {
        return ((e = cs(e)), e === null ? null : e.stateNode);
      },
      findFiberByHostInstance: Cr.findFiberByHostInstance || nd,
      findHostInstancesForRefresh: null,
      scheduleRefresh: null,
      scheduleRoot: null,
      setRefreshHandler: null,
      getCurrentFiber: null,
      reconcilerVersion: "18.3.1-next-f1338f8080-20240426",
    };
  if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u") {
    var Il = __REACT_DEVTOOLS_GLOBAL_HOOK__;
    if (!Il.isDisabled && Il.supportsFiber)
      try {
        ((Tr = Il.inject(od)), (kt = Il));
      } catch {}
  }
  return (
    (be.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = ld),
    (be.createPortal = function (e, t) {
      var n =
        2 < arguments.length && arguments[2] !== void 0 ? arguments[2] : null;
      if (!Ti(t)) throw Error(f(200));
      return td(e, t, null, n);
    }),
    (be.createRoot = function (e, t) {
      if (!Ti(e)) throw Error(f(299));
      var n = !1,
        r = "",
        l = Fa;
      return (
        t != null &&
          (t.unstable_strictMode === !0 && (n = !0),
          t.identifierPrefix !== void 0 && (r = t.identifierPrefix),
          t.onRecoverableError !== void 0 && (l = t.onRecoverableError)),
        (t = Li(e, 1, !1, null, null, n, !1, r, l)),
        (e[Ct] = t.current),
        ur(e.nodeType === 8 ? e.parentNode : e),
        new Ri(t)
      );
    }),
    (be.findDOMNode = function (e) {
      if (e == null) return null;
      if (e.nodeType === 1) return e;
      var t = e._reactInternals;
      if (t === void 0)
        throw typeof e.render == "function"
          ? Error(f(188))
          : ((e = Object.keys(e).join(",")), Error(f(268, e)));
      return ((e = cs(t)), (e = e === null ? null : e.stateNode), e);
    }),
    (be.flushSync = function (e) {
      return dn(e);
    }),
    (be.hydrate = function (e, t, n) {
      if (!Ol(t)) throw Error(f(200));
      return Dl(null, e, t, !0, n);
    }),
    (be.hydrateRoot = function (e, t, n) {
      if (!Ti(e)) throw Error(f(405));
      var r = (n != null && n.hydratedSources) || null,
        l = !1,
        o = "",
        i = Fa;
      if (
        (n != null &&
          (n.unstable_strictMode === !0 && (l = !0),
          n.identifierPrefix !== void 0 && (o = n.identifierPrefix),
          n.onRecoverableError !== void 0 && (i = n.onRecoverableError)),
        (t = Da(t, null, e, 1, n ?? null, l, !1, o, i)),
        (e[Ct] = t.current),
        ur(e),
        r)
      )
        for (e = 0; e < r.length; e++)
          ((n = r[e]),
            (l = n._getVersion),
            (l = l(n._source)),
            t.mutableSourceEagerHydrationData == null
              ? (t.mutableSourceEagerHydrationData = [n, l])
              : t.mutableSourceEagerHydrationData.push(n, l));
      return new Tl(t);
    }),
    (be.render = function (e, t, n) {
      if (!Ol(t)) throw Error(f(200));
      return Dl(null, e, t, !1, n);
    }),
    (be.unmountComponentAtNode = function (e) {
      if (!Ol(e)) throw Error(f(40));
      return e._reactRootContainer
        ? (dn(function () {
            Dl(null, null, e, !1, function () {
              ((e._reactRootContainer = null), (e[Ct] = null));
            });
          }),
          !0)
        : !1;
    }),
    (be.unstable_batchedUpdates = zi),
    (be.unstable_renderSubtreeIntoContainer = function (e, t, n, r) {
      if (!Ol(n)) throw Error(f(200));
      if (e == null || e._reactInternals === void 0) throw Error(f(38));
      return Dl(e, t, n, !1, r);
    }),
    (be.version = "18.3.1-next-f1338f8080-20240426"),
    be
  );
}
var Za;
function hd() {
  if (Za) return Ii.exports;
  Za = 1;
  function d() {
    if (!(
      typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > "u" ||
      typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != "function"
    ))
      try {
        __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(d);
      } catch (g) {
        console.error(g);
      }
  }
  return (d(), (Ii.exports = pd()), Ii.exports);
}
var Ka;
function md() {
  if (Ka) return Fl;
  Ka = 1;
  var d = hd();
  return ((Fl.createRoot = d.createRoot), (Fl.hydrateRoot = d.hydrateRoot), Fl);
}
var yd = md();
const gd = rc(yd),
  vd = 3600 * 12,
  $i = "comp_school_local_development_session",
  xd = "https://comp.school/fallback",
  tn = "comp.school",
  kd = /^(preview-[a-z0-9-]+)(?:\.[a-z0-9-]+)?\.comp\.school$/i,
  wd = /^(preview-[a-z0-9-]+)\.[a-z0-9-]+\.pages\.dev$/i,
  Sd = Object.freeze({
    "comp.school": 3e3,
    "code.comp.school": 3001,
    "admin.comp.school": 3002,
    "exams.comp.school": 3010,
    "recall.comp.school": 3011,
    "forms.comp.school": 3012,
    "mark.comp.school": 3013,
    "games.comp.school": 3014,
    "self-assess.comp.school": 3015,
    "issues.comp.school": 3016,
    "printouts.comp.school": 3017,
    "docs.comp.school": 3018,
  });
function Bi(d) {
  const g = d
    .trim()
    .toLowerCase()
    .replace(/^\[|\]$/g, "");
  return g === "localhost" || g === "127.0.0.1" || g === "::1";
}
function jd(d) {
  return [
    `${$i}=${encodeURIComponent(JSON.stringify({ version: 1, user: d }))}`,
    "Path=/",
    `Max-Age=${vd}`,
    "SameSite=Lax",
  ].join("; ");
}
function zd() {
  return [`${$i}=`, "Path=/", "Max-Age=0", "SameSite=Lax"].join("; ");
}
function lc(d, g, f) {
  if (!f || !Bi(g)) return null;
  const j = Td(d)[$i];
  if (!j) return null;
  try {
    const C = JSON.parse(j),
      M = C.user;
    return C.version !== 1 ||
      !M ||
      typeof M.id != "string" ||
      typeof M.name != "string" ||
      !["admin", "teacher", "student"].includes(M.role)
      ? null
      : M;
  } catch {
    return null;
  }
}
function Cd(d) {
  return btoa(d).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}
function Ed(d) {
  let g = "";
  for (const f of d) g += String.fromCharCode(f);
  return Cd(g);
}
function _d(d) {
  if (!d || !/^[A-Za-z0-9_-]+$/.test(d))
    throw new Error("Invalid base64url value");
  const g = d
      .replace(/-/g, "+")
      .replace(/_/g, "/")
      .padEnd(Math.ceil(d.length / 4) * 4, "="),
    f = atob(g),
    j = new Uint8Array(f.length);
  for (let C = 0; C < f.length; C += 1) j[C] = f.charCodeAt(C);
  if (Ed(j) !== d) throw new Error("Non-canonical base64url value");
  return j;
}
function Md(d) {
  const g = _d(d);
  return new TextDecoder("utf-8", { fatal: !0 }).decode(g);
}
function Pd(d) {
  return !!d && typeof d == "object" && !Array.isArray(d);
}
function Ld(d) {
  const g = JSON.parse(d);
  if (!Pd(g)) throw new Error("Expected a JSON object");
  return g;
}
function oc(d) {
  const g = d.trim().toLowerCase();
  return (g.match(kd) || g.match(wd))?.[1] || null;
}
function ic(d) {
  if (Bi(d))
    return `http://${d.replace(/^\[|\]$/g, "") === "::1" ? "[::1]" : d}:3000`;
  const g = oc(d);
  return g ? `https://${g}.${tn}` : `https://${tn}`;
}
function sc(d, g) {
  if (Bi(d))
    try {
      const j = new URL(g),
        C = Sd[j.hostname.toLowerCase()];
      if (C)
        return (
          (j.protocol = "http:"),
          (j.hostname = d),
          (j.port = String(C)),
          j.toString()
        );
    } catch {
      return g;
    }
  const f = oc(d);
  if (!f) return g;
  try {
    const j = new URL(g),
      C = j.hostname.toLowerCase();
    if (C === tn || C.endsWith(`.${tn}`))
      return (
        (j.hostname = C === tn ? `${f}.${tn}` : `${f}.${C}`),
        j.toString()
      );
  } catch {
    return g;
  }
  return g;
}
function Nd(d) {
  if (!d?.trim()) return null;
  try {
    const g = new URL(d),
      f = g.hostname.toLowerCase();
    return g.protocol !== "https:" ||
      g.username ||
      g.password ||
      g.port ||
      f === tn ||
      !f.endsWith(`.${tn}`)
      ? null
      : g.toString();
  } catch {
    return null;
  }
}
function Rd(d, g, f) {
  const j = f?.trim() || ic(d),
    C = Nd(sc(d, g));
  if (!C) return j;
  try {
    const M = new URL(j);
    return (M.searchParams.set("returnTo", C), M.toString());
  } catch {
    return j;
  }
}
function Td(d) {
  return d
    ? d.split(";").reduce((g, f) => {
        const [j, ...C] = f.trim().split("=");
        if (!j) return g;
        const M = C.join("=");
        try {
          g[j] = decodeURIComponent(M);
        } catch {
          g[j] = M;
        }
        return g;
      }, {})
    : {};
}
function Ga(d, g = new Date()) {
  if (!d) return !1;
  try {
    const [f] = d.split("."),
      j = Ld(Md(f));
    return (
      j.iss === xd &&
      typeof j.exp == "number" &&
      Number.isInteger(j.exp) &&
      j.exp > Math.floor(g.getTime() / 1e3)
    );
  } catch {
    return !1;
  }
}
const Ya = 64,
  Xa = { x: 9, y: 12, width: 46, height: 44, rx: 13 },
  V = "#1f2937",
  Pe = "#ffffff",
  ke = 33,
  Ot = 24,
  Dt = 40,
  qa = new Set(["shell"]);
function Ul(d) {
  return d.detail || d.shade;
}
function Od(d) {
  const { shade: g, accent: f } = d,
    j = Ul(d);
  switch (d.ears) {
    case "pointed":
      return s.jsxs("g", {
        children: [
          s.jsx("path", { d: "M11 26 17 3 30 17Z", fill: g }),
          s.jsx("path", { d: "M53 26 47 3 34 17Z", fill: g }),
          s.jsx("path", { d: "M16.5 22 19 9.5 26 17Z", fill: f }),
          s.jsx("path", { d: "M47.5 22 45 9.5 38 17Z", fill: f }),
        ],
      });
    case "round":
      return s.jsxs("g", {
        children: [
          s.jsx("circle", { cx: "17", cy: "14", r: "8.5", fill: g }),
          s.jsx("circle", { cx: "47", cy: "14", r: "8.5", fill: g }),
          s.jsx("circle", { cx: "17", cy: "14", r: "4", fill: f }),
          s.jsx("circle", { cx: "47", cy: "14", r: "4", fill: f }),
        ],
      });
    case "tall":
      return s.jsxs("g", {
        children: [
          s.jsxs("g", {
            transform: "rotate(-9 20.5 9)",
            children: [
              s.jsx("rect", {
                x: "15",
                y: "-5",
                width: "11",
                height: "27",
                rx: "5.5",
                fill: g,
              }),
              s.jsx("rect", {
                x: "18",
                y: "0",
                width: "5",
                height: "18",
                rx: "2.5",
                fill: f,
              }),
            ],
          }),
          s.jsxs("g", {
            transform: "rotate(9 43.5 9)",
            children: [
              s.jsx("rect", {
                x: "38",
                y: "-5",
                width: "11",
                height: "27",
                rx: "5.5",
                fill: g,
              }),
              s.jsx("rect", {
                x: "41",
                y: "0",
                width: "5",
                height: "18",
                rx: "2.5",
                fill: f,
              }),
            ],
          }),
        ],
      });
    case "floppy":
      return s.jsxs("g", {
        fill: g,
        children: [
          s.jsx("path", { d: "M15 16C5 18 3 34 9 41c5 4 9-2 9-11Z" }),
          s.jsx("path", { d: "M49 16c10 2 12 18 6 25-5 4-9-2-9-11Z" }),
        ],
      });
    case "tuft":
      return s.jsxs("g", {
        fill: g,
        children: [
          s.jsx("path", { d: "M12 19 15.5 5 24 15.5Z" }),
          s.jsx("path", { d: "M52 19 48.5 5 40 15.5Z" }),
        ],
      });
    case "horns":
      return s.jsxs("g", {
        fill: j,
        children: [
          s.jsx("path", {
            d: "M17.5 13C10 11 6 5 10.5 1.5c2.5 3.5 6.5 6.5 10.5 8.5Z",
          }),
          s.jsx("path", {
            d: "M46.5 13C54 11 58 5 53.5 1.5c-2.5 3.5-6.5 6.5-10.5 8.5Z",
          }),
        ],
      });
    case "antlers":
      return s.jsxs("g", {
        stroke: j,
        strokeWidth: "3",
        strokeLinecap: "round",
        fill: "none",
        children: [
          s.jsx("path", { d: "M21 14 16 3" }),
          s.jsx("path", { d: "M17.6 8 10 5" }),
          s.jsx("path", { d: "M43 14 48 3" }),
          s.jsx("path", { d: "M46.4 8 54 5" }),
        ],
      });
    case "flap":
      return s.jsxs("g", {
        children: [
          s.jsx("ellipse", { cx: "10", cy: "32", rx: "10", ry: "15", fill: g }),
          s.jsx("ellipse", { cx: "54", cy: "32", rx: "10", ry: "15", fill: g }),
          s.jsx("ellipse", { cx: "11", cy: "32", rx: "5", ry: "9", fill: f }),
          s.jsx("ellipse", { cx: "53", cy: "32", rx: "5", ry: "9", fill: f }),
        ],
      });
    case "spikes":
      return s.jsx("path", {
        d: "M8 22 13 3 20 18 26 1 32 17 38 1 44 18 51 3 56 22Z",
        fill: g,
      });
    case "crest":
      return s.jsxs("g", {
        fill: j,
        children: [
          s.jsx("circle", { cx: "25", cy: "10", r: "5" }),
          s.jsx("circle", { cx: "32", cy: "5.5", r: "5.5" }),
          s.jsx("circle", { cx: "39", cy: "10", r: "5" }),
        ],
      });
    case "fins":
      return s.jsxs("g", {
        fill: g,
        children: [
          s.jsx("path", { d: "M12 26 1 19 4 37Z" }),
          s.jsx("path", { d: "M52 26 63 19 60 37Z" }),
          s.jsx("path", { d: "M25 13 32 1 39 13Z" }),
        ],
      });
    case "antennae":
      return s.jsxs("g", {
        children: [
          s.jsxs("g", {
            stroke: g,
            strokeWidth: "2.6",
            strokeLinecap: "round",
            fill: "none",
            children: [
              s.jsx("path", { d: "M23 14C20 7 17 4 13.5 3" }),
              s.jsx("path", { d: "M41 14c3-7 6-10 9.5-11" }),
            ],
          }),
          s.jsx("circle", { cx: "12.5", cy: "3", r: "3", fill: g }),
          s.jsx("circle", { cx: "51.5", cy: "3", r: "3", fill: g }),
        ],
      });
    case "mane":
      return s.jsx("g", {
        fill: j,
        children: Array.from({ length: 12 }, (C, M) => {
          const $ = (M / 12) * Math.PI * 2;
          return s.jsx(
            "circle",
            { cx: 32 + Math.cos($) * 25, cy: 34 + Math.sin($) * 23, r: "8.5" },
            M,
          );
        }),
      });
    case "wool":
      return s.jsxs("g", {
        fill: f,
        children: [
          s.jsx("circle", { cx: "15", cy: "17", r: "8" }),
          s.jsx("circle", { cx: "26", cy: "10", r: "9" }),
          s.jsx("circle", { cx: "38", cy: "10", r: "9" }),
          s.jsx("circle", { cx: "49", cy: "17", r: "8" }),
        ],
      });
    case "wings":
      return s.jsxs("g", {
        fill: j,
        children: [
          s.jsx("path", { d: "M13 22C-1 16 0 42 12 46Z" }),
          s.jsx("path", { d: "M51 22c14-6 13 20 1 24Z" }),
        ],
      });
    case "tentacles":
      return s.jsxs("g", {
        fill: g,
        children: [
          s.jsx("path", { d: "M12 44c-6 4-8 12-6 18 4 1 7-5 9-11Z" }),
          s.jsx("path", { d: "M52 44c6 4 8 12 6 18-4 1-7-5-9-11Z" }),
          s.jsx("path", { d: "M25 50c-3 6-3 12-1 14 3 0 5-6 5-12Z" }),
          s.jsx("path", { d: "M39 50c3 6 3 12 1 14-3 0-5-6-5-12Z" }),
        ],
      });
    case "dome":
      return s.jsx("path", { d: "M11 22a21 21 0 0 1 42 0Z", fill: g });
    case "frill":
      return s.jsxs("g", {
        children: [
          s.jsx("path", { d: "M1 42C1 16 14 1 32 1s31 15 31 41Z", fill: g }),
          s.jsx("g", {
            fill: f,
            children: Array.from({ length: 9 }, (C, M) => {
              const $ = Math.PI + (M + 0.5) * (Math.PI / 9);
              return s.jsx(
                "circle",
                {
                  cx: 32 + Math.cos($) * 27,
                  cy: 40 + Math.sin($) * 33,
                  r: "3.2",
                },
                M,
              );
            }),
          }),
        ],
      });
    case "rays":
      return s.jsx("g", {
        fill: j,
        children: Array.from({ length: 12 }, (C, M) => {
          const $ = (M / 12) * 360;
          return s.jsx(
            "path",
            { d: "M32 2 27 12h10Z", transform: `rotate(${$} 32 34)` },
            M,
          );
        }),
      });
    case "points":
      return s.jsxs("g", {
        fill: g,
        children: [
          s.jsx("path", { d: "M32 0 24 16h16Z" }),
          s.jsx("path", { d: "M6 14 12 30l12-9Z" }),
          s.jsx("path", { d: "M58 14 52 30l-12-9Z" }),
          s.jsx("path", { d: "M8 56 4 42l14 4Z" }),
          s.jsx("path", { d: "M56 56l4-14-14 4Z" }),
        ],
      });
    case "none":
    default:
      return null;
  }
}
function Dd(d) {
  const { base: g, shade: f } = d,
    j = Ul(d);
  switch (d.eyes) {
    case "round":
      return s.jsxs("g", {
        children: [
          s.jsx("circle", { cx: Ot, cy: ke, r: "6.5", fill: Pe }),
          s.jsx("circle", { cx: Dt, cy: ke, r: "6.5", fill: Pe }),
          s.jsx("circle", { cx: Ot, cy: ke, r: "3.4", fill: V }),
          s.jsx("circle", { cx: Dt, cy: ke, r: "3.4", fill: V }),
          s.jsx("circle", { cx: Ot + 1.4, cy: ke - 1.6, r: "1.3", fill: Pe }),
          s.jsx("circle", { cx: Dt + 1.4, cy: ke - 1.6, r: "1.3", fill: Pe }),
        ],
      });
    case "big":
      return s.jsxs("g", {
        children: [
          s.jsx("circle", { cx: "23", cy: "32", r: "9.5", fill: Pe }),
          s.jsx("circle", { cx: "41", cy: "32", r: "9.5", fill: Pe }),
          s.jsx("circle", { cx: "23", cy: "32", r: "5", fill: V }),
          s.jsx("circle", { cx: "41", cy: "32", r: "5", fill: V }),
          s.jsx("circle", { cx: "24.6", cy: "30.2", r: "1.9", fill: Pe }),
          s.jsx("circle", { cx: "42.6", cy: "30.2", r: "1.9", fill: Pe }),
        ],
      });
    case "bulge":
      return s.jsxs("g", {
        children: [
          s.jsx("circle", {
            cx: "20",
            cy: "14",
            r: "9",
            fill: g,
            stroke: f,
            strokeWidth: "1.6",
          }),
          s.jsx("circle", {
            cx: "44",
            cy: "14",
            r: "9",
            fill: g,
            stroke: f,
            strokeWidth: "1.6",
          }),
          s.jsx("circle", { cx: "20", cy: "13.5", r: "4.8", fill: Pe }),
          s.jsx("circle", { cx: "44", cy: "13.5", r: "4.8", fill: Pe }),
          s.jsx("circle", { cx: "20", cy: "13.5", r: "2.6", fill: V }),
          s.jsx("circle", { cx: "44", cy: "13.5", r: "2.6", fill: V }),
        ],
      });
    case "slit":
      return s.jsxs("g", {
        children: [
          s.jsx("ellipse", { cx: Ot, cy: ke, rx: "5.4", ry: "6", fill: j }),
          s.jsx("ellipse", { cx: Dt, cy: ke, rx: "5.4", ry: "6", fill: j }),
          s.jsx("ellipse", { cx: Ot, cy: ke, rx: "1.8", ry: "5", fill: V }),
          s.jsx("ellipse", { cx: Dt, cy: ke, rx: "1.8", ry: "5", fill: V }),
        ],
      });
    case "sleepy":
      return s.jsxs("g", {
        stroke: V,
        strokeWidth: "3",
        strokeLinecap: "round",
        fill: "none",
        children: [
          s.jsx("path", { d: "M18.5 31.5q5.5 5 11 0" }),
          s.jsx("path", { d: "M34.5 31.5q5.5 5 11 0" }),
        ],
      });
    case "wide":
      return s.jsxs("g", {
        children: [
          s.jsx("circle", { cx: "20", cy: ke, r: "3.8", fill: V }),
          s.jsx("circle", { cx: "44", cy: ke, r: "3.8", fill: V }),
          s.jsx("circle", { cx: "21.3", cy: ke - 1.4, r: "1.3", fill: Pe }),
          s.jsx("circle", { cx: "45.3", cy: ke - 1.4, r: "1.3", fill: Pe }),
        ],
      });
    case "turret":
      return s.jsxs("g", {
        children: [
          s.jsx("circle", { cx: "21", cy: "31", r: "7.5", fill: f }),
          s.jsx("circle", { cx: "43", cy: "31", r: "7.5", fill: f }),
          s.jsx("circle", { cx: "21", cy: "31", r: "3.6", fill: j }),
          s.jsx("circle", { cx: "43", cy: "31", r: "3.6", fill: j }),
          s.jsx("circle", { cx: "21", cy: "31", r: "1.7", fill: V }),
          s.jsx("circle", { cx: "43", cy: "31", r: "1.7", fill: V }),
        ],
      });
    case "compound":
      return s.jsxs("g", {
        children: [
          s.jsx("ellipse", {
            cx: "22",
            cy: "31",
            rx: "7.5",
            ry: "9",
            fill: V,
            transform: "rotate(-12 22 31)",
          }),
          s.jsx("ellipse", {
            cx: "42",
            cy: "31",
            rx: "7.5",
            ry: "9",
            fill: V,
            transform: "rotate(12 42 31)",
          }),
          s.jsx("ellipse", {
            cx: "20.5",
            cy: "28",
            rx: "2.2",
            ry: "3",
            fill: Pe,
            opacity: "0.75",
          }),
          s.jsx("ellipse", {
            cx: "43.5",
            cy: "28",
            rx: "2.2",
            ry: "3",
            fill: Pe,
            opacity: "0.75",
          }),
        ],
      });
    case "stalk":
      return s.jsxs("g", {
        children: [
          s.jsxs("g", {
            stroke: f,
            strokeWidth: "2.8",
            strokeLinecap: "round",
            fill: "none",
            children: [
              s.jsx("path", { d: "M23 16 19.5 5" }),
              s.jsx("path", { d: "M41 16 44.5 5" }),
            ],
          }),
          s.jsx("circle", {
            cx: "19",
            cy: "4",
            r: "3.8",
            fill: Pe,
            stroke: f,
            strokeWidth: "1.2",
          }),
          s.jsx("circle", {
            cx: "45",
            cy: "4",
            r: "3.8",
            fill: Pe,
            stroke: f,
            strokeWidth: "1.2",
          }),
          s.jsx("circle", { cx: "19", cy: "4", r: "1.8", fill: V }),
          s.jsx("circle", { cx: "45", cy: "4", r: "1.8", fill: V }),
        ],
      });
    case "visor":
      return s.jsxs("g", {
        children: [
          s.jsx("rect", {
            x: "14",
            y: "26.5",
            width: "36",
            height: "13",
            rx: "6.5",
            fill: V,
          }),
          s.jsx("circle", { cx: Ot, cy: ke, r: "3.2", fill: j }),
          s.jsx("circle", { cx: Dt, cy: ke, r: "3.2", fill: j }),
        ],
      });
    case "dot":
    default:
      return s.jsxs("g", {
        children: [
          s.jsx("circle", { cx: Ot, cy: ke, r: "4.2", fill: V }),
          s.jsx("circle", { cx: Dt, cy: ke, r: "4.2", fill: V }),
          s.jsx("circle", { cx: Ot + 1.4, cy: ke - 1.5, r: "1.4", fill: Pe }),
          s.jsx("circle", { cx: Dt + 1.4, cy: ke - 1.5, r: "1.4", fill: Pe }),
        ],
      });
  }
}
function Ja() {
  return s.jsxs("g", {
    children: [
      s.jsx("path", { d: "M27.5 39q4.5-3.4 9 0Q32 44.6 27.5 39Z", fill: V }),
      s.jsx("path", {
        d: "M32 43.5v2.4M32 45.9q-2.4 2.6-4.6.4M32 45.9q2.4 2.6 4.6.4",
        stroke: V,
        strokeWidth: "2",
        strokeLinecap: "round",
        fill: "none",
      }),
    ],
  });
}
function Id(d) {
  const { accent: g, shade: f } = d,
    j = Ul(d);
  switch (d.muzzle) {
    case "nose":
      return Ja();
    case "snout":
      return s.jsxs("g", {
        children: [
          s.jsx("ellipse", { cx: "32", cy: "43", rx: "13", ry: "9", fill: g }),
          Ja(),
        ],
      });
    case "beak":
      return s.jsxs("g", {
        children: [
          s.jsx("path", { d: "M23 38h18l-9 11Z", fill: j }),
          s.jsx("path", {
            d: "M23 38h18",
            stroke: V,
            strokeWidth: "1.4",
            opacity: "0.35",
          }),
        ],
      });
    case "bill":
      return s.jsxs("g", {
        children: [
          s.jsx("rect", {
            x: "19",
            y: "37.5",
            width: "26",
            height: "11.5",
            rx: "5.75",
            fill: j,
          }),
          s.jsx("circle", { cx: "26", cy: "41.5", r: "1.3", fill: V }),
          s.jsx("circle", { cx: "38", cy: "41.5", r: "1.3", fill: V }),
        ],
      });
    case "pig":
      return s.jsxs("g", {
        children: [
          s.jsx("ellipse", { cx: "32", cy: "43", rx: "11", ry: "8", fill: g }),
          s.jsx("ellipse", { cx: "28", cy: "43", rx: "2.2", ry: "3", fill: V }),
          s.jsx("ellipse", { cx: "36", cy: "43", rx: "2.2", ry: "3", fill: V }),
        ],
      });
    case "wide":
      return s.jsx("path", {
        d: "M16 41q16 11 32 0",
        stroke: V,
        strokeWidth: "3",
        strokeLinecap: "round",
        fill: "none",
      });
    case "tusks":
      return s.jsxs("g", {
        children: [
          s.jsx("ellipse", {
            cx: "32",
            cy: "42",
            rx: "13",
            ry: "8.5",
            fill: g,
          }),
          s.jsx("ellipse", {
            cx: "32",
            cy: "38.5",
            rx: "3.4",
            ry: "2.6",
            fill: V,
          }),
          s.jsx("path", {
            d: "M27 45q-1.6 8-3.6 12M37 45q1.6 8 3.6 12",
            stroke: "#f8fafc",
            strokeWidth: "3.6",
            strokeLinecap: "round",
            fill: "none",
          }),
        ],
      });
    case "trunk":
      return s.jsx("path", {
        d: "M32 36q0 10-3 14t2 10",
        stroke: f,
        strokeWidth: "7.5",
        strokeLinecap: "round",
        fill: "none",
      });
    case "mandibles":
      return s.jsxs("g", {
        stroke: V,
        strokeWidth: "2.6",
        strokeLinecap: "round",
        fill: "none",
        children: [
          s.jsx("path", { d: "M26 43q6 6 12 0" }),
          s.jsx("path", { d: "M24.5 41q-3.5 4.5 0 8" }),
          s.jsx("path", { d: "M39.5 41q3.5 4.5 0 8" }),
        ],
      });
    case "grill":
      return s.jsxs("g", {
        children: [
          s.jsx("rect", {
            x: "23",
            y: "41",
            width: "18",
            height: "8",
            rx: "4",
            fill: V,
          }),
          s.jsx("path", {
            d: "M28 41v8M32 41v8M36 41v8",
            stroke: j,
            strokeWidth: "1.4",
            opacity: "0.8",
          }),
        ],
      });
    case "smile":
    default:
      return s.jsx("path", {
        d: "M26.5 42.5q5.5 5 11 0",
        stroke: V,
        strokeWidth: "2.8",
        strokeLinecap: "round",
        fill: "none",
      });
  }
}
function Ui(d, g, f) {
  const { shade: j, accent: C } = g,
    M = Ul(g);
  switch (d) {
    case "mask":
      return s.jsxs(
        "g",
        {
          clipPath: `url(#${f})`,
          fill: j,
          children: [
            s.jsx("ellipse", { cx: Ot, cy: ke - 0.5, rx: "9", ry: "8.5" }),
            s.jsx("ellipse", { cx: Dt, cy: ke - 0.5, rx: "9", ry: "8.5" }),
          ],
        },
        d,
      );
    case "stripes":
      return s.jsxs(
        "g",
        {
          clipPath: `url(#${f})`,
          stroke: j,
          strokeWidth: "3.4",
          strokeLinecap: "round",
          fill: "none",
          children: [
            s.jsx("path", { d: "M19 11q3 8-2 14" }),
            s.jsx("path", { d: "M32 10v10" }),
            s.jsx("path", { d: "M45 11q-3 8 2 14" }),
          ],
        },
        d,
      );
    case "spots":
      return s.jsxs(
        "g",
        {
          clipPath: `url(#${f})`,
          fill: j,
          opacity: "0.8",
          children: [
            s.jsx("circle", { cx: "16", cy: "24", r: "4" }),
            s.jsx("circle", { cx: "48", cy: "24", r: "4" }),
            s.jsx("circle", { cx: "14", cy: "42", r: "3.4" }),
            s.jsx("circle", { cx: "50", cy: "42", r: "3.4" }),
            s.jsx("circle", { cx: "32", cy: "18", r: "3.4" }),
          ],
        },
        d,
      );
    case "blush":
      return s.jsxs(
        "g",
        {
          clipPath: `url(#${f})`,
          fill: "#f87171",
          opacity: "0.35",
          children: [
            s.jsx("ellipse", { cx: "15", cy: "40", rx: "5.5", ry: "3.6" }),
            s.jsx("ellipse", { cx: "49", cy: "40", rx: "5.5", ry: "3.6" }),
          ],
        },
        d,
      );
    case "patch":
      return s.jsx(
        "g",
        {
          clipPath: `url(#${f})`,
          children: s.jsx("rect", {
            x: "15",
            y: "37",
            width: "34",
            height: "21",
            rx: "11",
            fill: C,
            opacity: "0.9",
          }),
        },
        d,
      );
    case "whiskers":
      return s.jsx(
        "g",
        {
          stroke: V,
          strokeWidth: "1.7",
          strokeLinecap: "round",
          opacity: "0.65",
          fill: "none",
          children: s.jsx("path", {
            d: "M18 40 6 37M18 43.5 6 44M46 40l12-3M46 43.5l12 .5",
          }),
        },
        d,
      );
    case "brows":
      return s.jsxs(
        "g",
        {
          stroke: V,
          strokeWidth: "3",
          strokeLinecap: "round",
          fill: "none",
          children: [
            s.jsx("path", { d: "M17.5 24.5 29 28.5" }),
            s.jsx("path", { d: "M46.5 24.5 35 28.5" }),
          ],
        },
        d,
      );
    case "horn":
      return s.jsxs(
        "g",
        {
          children: [
            s.jsx("path", { d: "M28 15 32-2l4 17Z", fill: M }),
            s.jsx("path", {
              d: "M29.4 10.5h5.2M30.4 6h3.2",
              stroke: V,
              strokeWidth: "1.3",
              opacity: "0.35",
            }),
          ],
        },
        d,
      );
    case "tongue":
      return s.jsx("path", { d: "M28.5 45q3.5 9 7 0Z", fill: "#f472b6" }, d);
    case "fangs":
      return s.jsxs(
        "g",
        {
          fill: Pe,
          children: [
            s.jsx("path", { d: "M26.5 42 29 48l2.5-6Z" }),
            s.jsx("path", { d: "M32.5 42 35 48l2.5-6Z" }),
          ],
        },
        d,
      );
    case "sparkle":
      return s.jsxs(
        "g",
        {
          fill: M,
          children: [
            s.jsx("path", {
              d: "M53 8 54.4 12 58 13.4 54.4 14.8 53 18.6 51.6 14.8 48 13.4 51.6 12Z",
            }),
            s.jsx("path", {
              d: "M10 44 11 47 14 48 11 49 10 52 9 49 6 48 9 47Z",
            }),
          ],
        },
        d,
      );
    case "crown":
      return s.jsxs(
        "g",
        {
          children: [
            s.jsx("path", {
              d: "M19 13 23 3l5 6 5-8 5 8 5-6 4 10Z",
              fill: "#fbbf24",
            }),
            s.jsx("circle", { cx: "32", cy: "6", r: "1.8", fill: "#fde68a" }),
          ],
        },
        d,
      );
    case "shell":
      return s.jsxs(
        "g",
        {
          children: [
            s.jsx("path", { d: "M0 61q0-27 32-27t32 27Z", fill: M }),
            s.jsxs("g", {
              fill: j,
              opacity: "0.55",
              children: [
                s.jsx("circle", { cx: "5.5", cy: "52", r: "3" }),
                s.jsx("circle", { cx: "58.5", cy: "52", r: "3" }),
                s.jsx("circle", { cx: "20", cy: "59", r: "3" }),
                s.jsx("circle", { cx: "44", cy: "59", r: "3" }),
                s.jsx("circle", { cx: "32", cy: "60", r: "3" }),
              ],
            }),
          ],
        },
        d,
      );
    case "stitches":
      return s.jsxs(
        "g",
        {
          clipPath: `url(#${f})`,
          stroke: j,
          strokeWidth: "1.8",
          strokeLinecap: "round",
          children: [
            s.jsx("path", { d: "M45 12v14" }),
            s.jsx("path", { d: "M41.5 16h7M41.5 21h7" }),
            s.jsx("path", { d: "M14 44h9" }),
            s.jsx("path", { d: "M17 41.5v5M21 41.5v5" }),
          ],
        },
        d,
      );
    case "bolt":
      return s.jsx(
        "path",
        { d: "M49 2 39 18h6l-8 14 20-20h-7l6-10Z", fill: M },
        d,
      );
    case "bandage":
      return s.jsxs(
        "g",
        {
          clipPath: `url(#${f})`,
          fill: C,
          opacity: "0.9",
          children: [
            s.jsx("path", { d: "M2 20 62 12v7L2 27Z" }),
            s.jsx("path", { d: "M2 44 62 36v7L2 51Z" }),
            s.jsx("path", { d: "M6 56 58 48v6H6Z" }),
          ],
        },
        d,
      );
    case "visorGlow":
      return s.jsx(
        "g",
        {
          opacity: "0.75",
          children: s.jsx("path", {
            d: "M18 27q14-6 28 0",
            stroke: M,
            strokeWidth: "2",
            fill: "none",
            strokeLinecap: "round",
          }),
        },
        d,
      );
    default:
      return null;
  }
}
function Fd({ features: d, idSuffix: g, className: f, title: j }) {
  const C = `cs-avatar-head-${g}`,
    M = d.marks || [],
    $ = M.filter((O) => qa.has(O)),
    q = M.filter((O) => !qa.has(O));
  return s.jsxs("svg", {
    className: f,
    viewBox: `0 0 ${Ya} ${Ya}`,
    width: "100%",
    height: "100%",
    role: j ? "img" : "presentation",
    "aria-label": j,
    "aria-hidden": j ? void 0 : !0,
    focusable: "false",
    children: [
      s.jsx("defs", {
        children: s.jsx("clipPath", {
          id: C,
          children: s.jsx("rect", { ...Xa }),
        }),
      }),
      $.map((O) => Ui(O, d, C)),
      Od(d),
      s.jsx("rect", { ...Xa, fill: d.base }),
      q
        .filter(
          (O) =>
            O === "mask" ||
            O === "stripes" ||
            O === "spots" ||
            O === "patch" ||
            O === "bandage",
        )
        .map((O) => Ui(O, d, C)),
      Id(d),
      Dd(d),
      q
        .filter(
          (O) =>
            !(
              O === "mask" ||
              O === "stripes" ||
              O === "spots" ||
              O === "patch" ||
              O === "bandage"
            ),
        )
        .map((O) => Ui(O, d, C)),
    ],
  });
}
const Ad = {
  rust: ["#ef8043", "#cd5f27", "#ffe0c6"],
  amber: ["#f0993f", "#cb7220", "#ffe8cd"],
  brown: ["#a97551", "#7d5133", "#f2ddc8"],
  cocoa: ["#8b5e3c", "#5d3c23", "#ebd6c1"],
  sand: ["#e6c48b", "#c39a55", "#fdf1da"],
  cream: ["#f3e3c3", "#d6b988", "#fff8ea"],
  grey: ["#9aa8bb", "#6b7c93", "#e6edf5"],
  slate: ["#7c8ba1", "#4f5d74", "#dde5ef"],
  charcoal: ["#4d5765", "#2e3641", "#c6cedb"],
  snow: ["#eef3f9", "#c0cbd9", "#ffffff"],
  pink: ["#f5a6ba", "#da7c92", "#ffe4ec"],
  rose: ["#ef8ba2", "#cd6079", "#ffdde5"],
  green: ["#5fba70", "#3d9350", "#d9f2dd"],
  moss: ["#7fbc5a", "#5d9639", "#e4f5d5"],
  lime: ["#95cf57", "#6da733", "#eafada"],
  teal: ["#42b5a8", "#2a8a80", "#d3f1ed"],
  blue: ["#5c9cd6", "#3c74a7", "#dceaf8"],
  sky: ["#7cc4ef", "#4d9acb", "#e3f3fd"],
  navy: ["#41628f", "#2b4568", "#d0dcec"],
  yellow: ["#f3c552", "#d09c2c", "#fff3d0"],
  gold: ["#e9aa3c", "#c1811d", "#ffeecb"],
  purple: ["#a68bf5", "#7c5cef", "#e9e3ff"],
  violet: ["#8a6fd4", "#63499f", "#e0d8f6"],
  red: ["#e15c4f", "#b73e33", "#fbdad5"],
  stone: ["#98a0a8", "#6a737c", "#dfe4e8"],
};
function v(d, g, f, j, C) {
  const [M, $, q] = Ad[j];
  return { id: d, label: g, group: f, base: M, shade: $, accent: q, ...C };
}
const Ud = Object.freeze([
    v("fox", "Fox", "woodland", "rust", {
      ears: "pointed",
      eyes: "round",
      muzzle: "snout",
      marks: ["whiskers"],
    }),
    v("owl", "Owl", "woodland", "cocoa", {
      ears: "tuft",
      eyes: "big",
      muzzle: "beak",
      detail: "#f3c552",
    }),
    v("bear", "Bear", "woodland", "brown", {
      ears: "round",
      eyes: "dot",
      muzzle: "snout",
    }),
    v("panda", "Panda", "woodland", "snow", {
      ears: "round",
      eyes: "dot",
      muzzle: "snout",
      marks: ["mask"],
      shade: "#39414d",
    }),
    v("wolf", "Wolf", "woodland", "slate", {
      ears: "pointed",
      eyes: "round",
      muzzle: "snout",
    }),
    v("badger", "Badger", "woodland", "snow", {
      ears: "round",
      eyes: "dot",
      muzzle: "snout",
      marks: ["mask"],
      shade: "#3b4553",
    }),
    v("hedgehog", "Hedgehog", "woodland", "sand", {
      ears: "spikes",
      eyes: "dot",
      muzzle: "nose",
    }),
    v("squirrel", "Squirrel", "woodland", "amber", {
      ears: "tuft",
      eyes: "round",
      muzzle: "nose",
      marks: ["patch"],
    }),
    v("deer", "Deer", "woodland", "sand", {
      ears: "antlers",
      eyes: "round",
      muzzle: "snout",
      marks: ["spots"],
      detail: "#8b5e3c",
    }),
    v("raccoon", "Raccoon", "woodland", "grey", {
      ears: "round",
      eyes: "dot",
      muzzle: "snout",
      marks: ["mask"],
      shade: "#3e4756",
    }),
    v("cat", "Cat", "pets", "amber", {
      ears: "pointed",
      eyes: "slit",
      muzzle: "nose",
      marks: ["stripes", "whiskers"],
      detail: "#5fba70",
    }),
    v("dog", "Dog", "pets", "brown", {
      ears: "floppy",
      eyes: "round",
      muzzle: "snout",
    }),
    v("rabbit", "Rabbit", "pets", "cream", {
      ears: "tall",
      eyes: "round",
      muzzle: "nose",
      marks: ["blush"],
    }),
    v("hamster", "Hamster", "pets", "sand", {
      ears: "round",
      eyes: "dot",
      muzzle: "nose",
      marks: ["patch", "blush"],
    }),
    v("guineapig", "Guinea pig", "pets", "cocoa", {
      ears: "round",
      eyes: "dot",
      muzzle: "nose",
      marks: ["patch"],
    }),
    v("ferret", "Ferret", "pets", "cream", {
      ears: "round",
      eyes: "dot",
      muzzle: "nose",
      marks: ["mask"],
      shade: "#a97551",
    }),
    v("budgie", "Budgie", "pets", "lime", {
      ears: "crest",
      eyes: "dot",
      muzzle: "beak",
      marks: ["blush"],
      detail: "#f3c552",
    }),
    v("goldfish", "Goldfish", "pets", "gold", {
      ears: "fins",
      eyes: "wide",
      muzzle: "smile",
    }),
    v("pony", "Pony", "pets", "sand", {
      ears: "pointed",
      eyes: "round",
      muzzle: "snout",
      marks: ["patch"],
    }),
    v("mouse", "Mouse", "pets", "grey", {
      ears: "round",
      eyes: "dot",
      muzzle: "nose",
      marks: ["whiskers", "blush"],
    }),
    v("cow", "Cow", "farm", "snow", {
      ears: "horns",
      eyes: "round",
      muzzle: "pig",
      marks: ["spots"],
      shade: "#39414d",
      detail: "#e6c48b",
    }),
    v("pig", "Pig", "farm", "pink", {
      ears: "floppy",
      eyes: "dot",
      muzzle: "pig",
      marks: ["blush"],
    }),
    v("sheep", "Sheep", "farm", "cream", {
      ears: "wool",
      eyes: "dot",
      muzzle: "nose",
    }),
    v("goat", "Goat", "farm", "cream", {
      ears: "horns",
      eyes: "slit",
      muzzle: "nose",
      marks: ["patch"],
      detail: "#a97551",
    }),
    v("horse", "Horse", "farm", "cocoa", {
      ears: "pointed",
      eyes: "round",
      muzzle: "snout",
      marks: ["patch"],
    }),
    v("donkey", "Donkey", "farm", "grey", {
      ears: "tall",
      eyes: "sleepy",
      muzzle: "snout",
    }),
    v("chicken", "Chicken", "farm", "snow", {
      ears: "crest",
      eyes: "dot",
      muzzle: "beak",
      detail: "#e15c4f",
    }),
    v("duck", "Duck", "farm", "yellow", {
      ears: "none",
      eyes: "dot",
      muzzle: "bill",
      detail: "#f0993f",
    }),
    v("goose", "Goose", "farm", "snow", {
      ears: "none",
      eyes: "dot",
      muzzle: "bill",
      detail: "#f0993f",
    }),
    v("bull", "Bull", "farm", "charcoal", {
      ears: "horns",
      eyes: "round",
      muzzle: "pig",
      marks: ["brows"],
      detail: "#e6c48b",
    }),
    v("lion", "Lion", "savanna", "gold", {
      ears: "mane",
      eyes: "round",
      muzzle: "snout",
      marks: ["whiskers"],
      detail: "#b9762a",
    }),
    v("tiger", "Tiger", "savanna", "amber", {
      ears: "pointed",
      eyes: "round",
      muzzle: "snout",
      marks: ["stripes", "whiskers"],
      shade: "#8a4a17",
    }),
    v("elephant", "Elephant", "savanna", "grey", {
      ears: "flap",
      eyes: "dot",
      muzzle: "trunk",
    }),
    v("giraffe", "Giraffe", "savanna", "sand", {
      ears: "horns",
      eyes: "round",
      muzzle: "snout",
      marks: ["spots"],
      detail: "#8b5e3c",
    }),
    v("zebra", "Zebra", "savanna", "snow", {
      ears: "round",
      eyes: "round",
      muzzle: "snout",
      marks: ["stripes"],
      shade: "#39414d",
    }),
    v("rhino", "Rhino", "savanna", "stone", {
      ears: "round",
      eyes: "dot",
      muzzle: "pig",
      marks: ["horn"],
      detail: "#dfe4e8",
    }),
    v("hippo", "Hippo", "savanna", "violet", {
      ears: "round",
      eyes: "wide",
      muzzle: "pig",
    }),
    v("cheetah", "Cheetah", "savanna", "sand", {
      ears: "round",
      eyes: "round",
      muzzle: "nose",
      marks: ["spots", "whiskers"],
    }),
    v("meerkat", "Meerkat", "savanna", "cream", {
      ears: "round",
      eyes: "dot",
      muzzle: "nose",
      marks: ["mask"],
      shade: "#8b5e3c",
    }),
    v("monkey", "Monkey", "savanna", "cocoa", {
      ears: "round",
      eyes: "round",
      muzzle: "snout",
      marks: ["patch"],
    }),
    v("polarbear", "Polar bear", "polar", "snow", {
      ears: "round",
      eyes: "dot",
      muzzle: "snout",
    }),
    v("penguin", "Penguin", "polar", "charcoal", {
      ears: "none",
      eyes: "round",
      muzzle: "beak",
      marks: ["patch"],
      accent: "#ffffff",
      detail: "#f0993f",
    }),
    v("seal", "Seal", "polar", "slate", {
      ears: "none",
      eyes: "sleepy",
      muzzle: "nose",
      marks: ["whiskers"],
    }),
    v("arcticfox", "Arctic fox", "polar", "snow", {
      ears: "pointed",
      eyes: "round",
      muzzle: "snout",
      marks: ["whiskers"],
    }),
    v("snowleopard", "Snow leopard", "polar", "snow", {
      ears: "tuft",
      eyes: "slit",
      muzzle: "nose",
      marks: ["spots", "whiskers"],
      detail: "#5fba70",
    }),
    v("walrus", "Walrus", "polar", "brown", {
      ears: "none",
      eyes: "dot",
      muzzle: "tusks",
      marks: ["whiskers"],
    }),
    v("reindeer", "Reindeer", "polar", "cocoa", {
      ears: "antlers",
      eyes: "round",
      muzzle: "snout",
      detail: "#c39a55",
    }),
    v("husky", "Husky", "polar", "slate", {
      ears: "pointed",
      eyes: "slit",
      muzzle: "snout",
      marks: ["mask"],
      detail: "#7cc4ef",
    }),
    v("puffin", "Puffin", "polar", "charcoal", {
      ears: "none",
      eyes: "dot",
      muzzle: "beak",
      marks: ["patch"],
      accent: "#ffffff",
      detail: "#f0993f",
    }),
    v("yak", "Yak", "polar", "cocoa", {
      ears: "horns",
      eyes: "sleepy",
      muzzle: "nose",
      marks: ["patch"],
      detail: "#e6c48b",
    }),
    v("whale", "Whale", "ocean", "navy", {
      ears: "fins",
      eyes: "wide",
      muzzle: "smile",
      marks: ["patch"],
    }),
    v("dolphin", "Dolphin", "ocean", "sky", {
      ears: "fins",
      eyes: "dot",
      muzzle: "smile",
      marks: ["patch"],
    }),
    v("shark", "Shark", "ocean", "slate", {
      ears: "fins",
      eyes: "round",
      muzzle: "wide",
      marks: ["brows", "fangs"],
    }),
    v("octopus", "Octopus", "ocean", "purple", {
      ears: "tentacles",
      eyes: "round",
      muzzle: "smile",
    }),
    v("crab", "Crab", "ocean", "red", {
      ears: "none",
      eyes: "stalk",
      muzzle: "mandibles",
    }),
    v("jellyfish", "Jellyfish", "ocean", "rose", {
      ears: "tentacles",
      eyes: "dot",
      muzzle: "smile",
    }),
    v("seahorse", "Seahorse", "ocean", "yellow", {
      ears: "crest",
      eyes: "wide",
      muzzle: "beak",
      detail: "#d09c2c",
    }),
    v("pufferfish", "Pufferfish", "ocean", "amber", {
      ears: "spikes",
      eyes: "wide",
      muzzle: "smile",
    }),
    v("narwhal", "Narwhal", "ocean", "sky", {
      ears: "fins",
      eyes: "dot",
      muzzle: "smile",
      marks: ["horn"],
      detail: "#eef3f9",
    }),
    v("otter", "Otter", "ocean", "brown", {
      ears: "round",
      eyes: "round",
      muzzle: "snout",
      marks: ["whiskers"],
    }),
    v("frog", "Frog", "creatures", "green", {
      ears: "none",
      eyes: "bulge",
      muzzle: "wide",
      marks: ["tongue"],
    }),
    v("turtle", "Turtle", "creatures", "moss", {
      ears: "none",
      eyes: "round",
      muzzle: "smile",
      marks: ["shell"],
      detail: "#3f7a2a",
    }),
    v("gecko", "Gecko", "creatures", "lime", {
      ears: "none",
      eyes: "round",
      muzzle: "smile",
      marks: ["spots"],
    }),
    v("chameleon", "Chameleon", "creatures", "teal", {
      ears: "crest",
      eyes: "turret",
      muzzle: "smile",
      marks: ["spots"],
      detail: "#f3c552",
    }),
    v("snake", "Snake", "creatures", "moss", {
      ears: "none",
      eyes: "slit",
      muzzle: "smile",
      marks: ["stripes"],
      detail: "#f3c552",
    }),
    v("crocodile", "Crocodile", "creatures", "green", {
      ears: "none",
      eyes: "wide",
      muzzle: "wide",
      marks: ["brows", "fangs"],
    }),
    v("bee", "Bee", "creatures", "yellow", {
      ears: "antennae",
      eyes: "compound",
      muzzle: "mandibles",
      marks: ["stripes"],
      shade: "#39414d",
    }),
    v("ladybird", "Ladybird", "creatures", "red", {
      ears: "antennae",
      eyes: "dot",
      muzzle: "smile",
      marks: ["spots"],
      shade: "#39414d",
    }),
    v("butterfly", "Butterfly", "creatures", "purple", {
      ears: "wings",
      eyes: "compound",
      muzzle: "smile",
      marks: ["sparkle"],
      detail: "#f3c552",
    }),
    v("snail", "Snail", "creatures", "cream", {
      ears: "none",
      eyes: "stalk",
      muzzle: "smile",
      marks: ["shell"],
      detail: "#c39a55",
    }),
    v("dragon", "Dragon", "mythical", "green", {
      ears: "spikes",
      eyes: "slit",
      muzzle: "wide",
      marks: ["fangs", "brows"],
      detail: "#f3c552",
    }),
    v("unicorn", "Unicorn", "mythical", "snow", {
      ears: "pointed",
      eyes: "round",
      muzzle: "snout",
      marks: ["horn", "sparkle"],
      detail: "#a68bf5",
    }),
    v("phoenix", "Phoenix", "mythical", "red", {
      ears: "crest",
      eyes: "round",
      muzzle: "beak",
      marks: ["sparkle"],
      detail: "#f3c552",
    }),
    v("griffin", "Griffin", "mythical", "gold", {
      ears: "wings",
      eyes: "big",
      muzzle: "beak",
      marks: ["brows"],
      detail: "#c1811d",
    }),
    v("yeti", "Yeti", "mythical", "snow", {
      ears: "wool",
      eyes: "round",
      muzzle: "snout",
      marks: ["fangs"],
      accent: "#dcecfb",
    }),
    v("pegasus", "Pegasus", "mythical", "snow", {
      ears: "wings",
      eyes: "round",
      muzzle: "snout",
      marks: ["sparkle"],
      detail: "#7cc4ef",
    }),
    v("kraken", "Kraken", "mythical", "violet", {
      ears: "tentacles",
      eyes: "slit",
      muzzle: "smile",
      marks: ["brows"],
      detail: "#42b5a8",
    }),
    v("sphinx", "Sphinx", "mythical", "sand", {
      ears: "pointed",
      eyes: "round",
      muzzle: "nose",
      marks: ["crown"],
    }),
    v("wyvern", "Wyvern", "mythical", "red", {
      ears: "wings",
      eyes: "slit",
      muzzle: "wide",
      marks: ["horn", "fangs"],
      detail: "#f3c552",
    }),
    v("golem", "Golem", "mythical", "stone", {
      ears: "dome",
      eyes: "visor",
      muzzle: "grill",
      marks: ["sparkle"],
      detail: "#7cc4ef",
    }),
    v("trex", "T. rex", "dinosaurs", "moss", {
      ears: "none",
      eyes: "slit",
      muzzle: "wide",
      marks: ["brows", "fangs"],
      detail: "#f3c552",
    }),
    v("triceratops", "Triceratops", "dinosaurs", "teal", {
      ears: "frill",
      eyes: "round",
      muzzle: "beak",
      marks: ["horn"],
      detail: "#e6c48b",
    }),
    v("stegosaurus", "Stegosaurus", "dinosaurs", "violet", {
      ears: "spikes",
      eyes: "dot",
      muzzle: "smile",
      marks: ["spots"],
    }),
    v("raptor", "Raptor", "dinosaurs", "amber", {
      ears: "none",
      eyes: "slit",
      muzzle: "wide",
      marks: ["stripes", "fangs"],
      detail: "#5fba70",
    }),
    v("pterodactyl", "Pterodactyl", "dinosaurs", "rust", {
      ears: "wings",
      eyes: "round",
      muzzle: "beak",
      detail: "#cd5f27",
    }),
    v("brachiosaurus", "Brachiosaurus", "dinosaurs", "sky", {
      ears: "none",
      eyes: "dot",
      muzzle: "smile",
      marks: ["spots"],
    }),
    v("ankylosaurus", "Ankylosaurus", "dinosaurs", "stone", {
      ears: "points",
      eyes: "dot",
      muzzle: "smile",
      marks: ["spots"],
    }),
    v("spinosaurus", "Spinosaurus", "dinosaurs", "navy", {
      ears: "spikes",
      eyes: "slit",
      muzzle: "wide",
      marks: ["fangs"],
      detail: "#f3c552",
    }),
    v("dilophosaurus", "Dilophosaurus", "dinosaurs", "lime", {
      ears: "crest",
      eyes: "round",
      muzzle: "wide",
      marks: ["tongue"],
      detail: "#e15c4f",
    }),
    v("mosasaurus", "Mosasaurus", "dinosaurs", "teal", {
      ears: "fins",
      eyes: "wide",
      muzzle: "wide",
      marks: ["fangs"],
    }),
    v("astronaut", "Astronaut", "space", "snow", {
      ears: "dome",
      eyes: "visor",
      muzzle: "smile",
      marks: ["visorGlow"],
      detail: "#7cc4ef",
    }),
    v("alien", "Alien", "space", "lime", {
      ears: "antennae",
      eyes: "compound",
      muzzle: "smile",
      detail: "#6da733",
    }),
    v("martian", "Martian", "space", "red", {
      ears: "antennae",
      eyes: "big",
      muzzle: "smile",
      marks: ["blush"],
    }),
    v("moon", "Moon", "space", "snow", {
      ears: "none",
      eyes: "sleepy",
      muzzle: "smile",
      marks: ["spots"],
    }),
    v("sun", "Sun", "space", "yellow", {
      ears: "rays",
      eyes: "dot",
      muzzle: "smile",
      marks: ["blush"],
      detail: "#e9aa3c",
    }),
    v("star", "Star", "space", "yellow", {
      ears: "points",
      eyes: "dot",
      muzzle: "smile",
      marks: ["sparkle"],
      shade: "#e9aa3c",
      detail: "#fff3d0",
    }),
    v("comet", "Comet", "space", "sky", {
      ears: "points",
      eyes: "wide",
      muzzle: "smile",
      marks: ["sparkle", "bolt"],
      detail: "#f3c552",
    }),
    v("satellite", "Satellite", "space", "slate", {
      ears: "antennae",
      eyes: "visor",
      muzzle: "grill",
      marks: ["bolt"],
      detail: "#f3c552",
    }),
    v("ufo", "UFO", "space", "teal", {
      ears: "dome",
      eyes: "big",
      muzzle: "smile",
      marks: ["visorGlow"],
      detail: "#95cf57",
    }),
    v("rover", "Rover", "space", "stone", {
      ears: "antennae",
      eyes: "visor",
      muzzle: "grill",
      marks: ["spots"],
      detail: "#f0993f",
    }),
    v("robot", "Robot", "robots", "stone", {
      ears: "antennae",
      eyes: "visor",
      muzzle: "grill",
      marks: ["bolt"],
      detail: "#7cc4ef",
    }),
    v("android", "Android", "robots", "snow", {
      ears: "none",
      eyes: "round",
      muzzle: "smile",
      marks: ["visorGlow"],
      detail: "#42b5a8",
    }),
    v("cyborg", "Cyborg", "robots", "charcoal", {
      ears: "none",
      eyes: "slit",
      muzzle: "grill",
      marks: ["stitches"],
      detail: "#e15c4f",
    }),
    v("drone", "Drone", "robots", "slate", {
      ears: "fins",
      eyes: "big",
      muzzle: "smile",
      detail: "#95cf57",
    }),
    v("mecha", "Mecha", "robots", "navy", {
      ears: "horns",
      eyes: "visor",
      muzzle: "grill",
      marks: ["bolt"],
      detail: "#f3c552",
    }),
    v("servo", "Servo", "robots", "gold", {
      ears: "antennae",
      eyes: "dot",
      muzzle: "smile",
      marks: ["blush"],
    }),
    v("glitch", "Glitch", "robots", "purple", {
      ears: "points",
      eyes: "compound",
      muzzle: "grill",
      marks: ["sparkle"],
      detail: "#95cf57",
    }),
    v("pixel", "Pixel", "robots", "lime", {
      ears: "none",
      eyes: "dot",
      muzzle: "grill",
      marks: ["spots"],
      detail: "#f3c552",
    }),
    v("sentry", "Sentry", "robots", "red", {
      ears: "dome",
      eyes: "visor",
      muzzle: "grill",
      marks: ["visorGlow"],
      detail: "#f3c552",
    }),
    v("beacon", "Beacon", "robots", "sky", {
      ears: "rays",
      eyes: "dot",
      muzzle: "smile",
      marks: ["sparkle"],
      detail: "#f3c552",
    }),
    v("vampire", "Vampire", "monsters", "snow", {
      ears: "pointed",
      eyes: "slit",
      muzzle: "smile",
      marks: ["brows", "fangs"],
      detail: "#e15c4f",
    }),
    v("werewolf", "Werewolf", "monsters", "charcoal", {
      ears: "pointed",
      eyes: "round",
      muzzle: "snout",
      marks: ["brows", "fangs"],
    }),
    v("zombie", "Zombie", "monsters", "moss", {
      ears: "round",
      eyes: "round",
      muzzle: "smile",
      marks: ["stitches", "fangs"],
    }),
    v("ghost", "Ghost", "monsters", "snow", {
      ears: "none",
      eyes: "big",
      muzzle: "wide",
      marks: ["sparkle"],
      detail: "#a68bf5",
    }),
    v("mummy", "Mummy", "monsters", "cream", {
      ears: "none",
      eyes: "dot",
      muzzle: "smile",
      marks: ["bandage"],
      accent: "#fffaf0",
    }),
    v("frankenstein", "Frankenstein", "monsters", "lime", {
      ears: "none",
      eyes: "sleepy",
      muzzle: "smile",
      marks: ["brows", "stitches", "bolt"],
      detail: "#f3c552",
    }),
    v("goblin", "Goblin", "monsters", "moss", {
      ears: "pointed",
      eyes: "slit",
      muzzle: "wide",
      marks: ["brows", "fangs"],
      detail: "#f3c552",
    }),
    v("ogre", "Ogre", "monsters", "brown", {
      ears: "round",
      eyes: "dot",
      muzzle: "tusks",
      marks: ["brows"],
    }),
    v("slime", "Slime", "monsters", "teal", {
      ears: "none",
      eyes: "round",
      muzzle: "smile",
      marks: ["blush", "sparkle"],
    }),
    v("gargoyle", "Gargoyle", "monsters", "stone", {
      ears: "wings",
      eyes: "slit",
      muzzle: "wide",
      marks: ["brows", "fangs"],
      detail: "#6a737c",
    }),
  ]),
  Wd = new Map(Ud.map((d) => [d.id, d]));
function uc(d) {
  return d ? Wd.get(d) : void 0;
}
const Hd = { small: "1.25rem", medium: "1.75rem", large: "2.5rem" },
  ba = "#f8fafc",
  $d = "#60a5fa",
  ec = [
    { value: "product", label: "Product" },
    { value: "mock", label: "Mock" },
    { value: "real", label: "Real", locked: !0 },
  ];
function Bd({ dataSource: d, onDataSourceChange: g, tone: f = "light" }) {
  const [j, C] = Be.useState(!1),
    M = f === "dark",
    $ = ec.find((U) => U.value === d)?.label || "Product",
    q = M ? "#e2e8f0" : "#334155",
    O = M ? "#94a3b8" : "#64748b",
    ge = M ? "#f8fafc" : "#0f172a";
  return s.jsxs("div", {
    "data-profile-database-row": !0,
    style: { marginBottom: "0.25rem" },
    children: [
      s.jsxs("button", {
        "aria-controls": "profile-database-options",
        "aria-expanded": j,
        "data-profile-database-trigger": !0,
        onClick: () => C((U) => !U),
        style: {
          alignItems: "center",
          background: "transparent",
          border: 0,
          borderRadius: "0.5rem",
          color: q,
          cursor: "pointer",
          display: "flex",
          fontFamily: "inherit",
          fontSize: "0.875rem",
          fontWeight: 650,
          gap: "0.5rem",
          minHeight: "2.25rem",
          padding: "0.5rem",
          textAlign: "left",
          width: "100%",
        },
        type: "button",
        children: [
          s.jsxs("svg", {
            "aria-hidden": "true",
            fill: "none",
            height: "16",
            viewBox: "0 0 24 24",
            width: "16",
            children: [
              s.jsx("ellipse", {
                cx: "12",
                cy: "5",
                rx: "8",
                ry: "3",
                stroke: "currentColor",
                strokeWidth: "1.8",
              }),
              s.jsx("path", {
                d: "M4 5v7c0 1.7 3.6 3 8 3s8-1.3 8-3V5M4 12v7c0 1.7 3.6 3 8 3s8-1.3 8-3v-7",
                stroke: "currentColor",
                strokeWidth: "1.8",
              }),
            ],
          }),
          s.jsx("span", { style: { flex: 1 }, children: "Database" }),
          s.jsx("span", {
            style: { color: O, fontSize: "0.75rem", fontWeight: 600 },
            children: $,
          }),
          s.jsx("svg", {
            "aria-hidden": "true",
            fill: "none",
            height: "15",
            style: { transform: j ? "rotate(180deg)" : void 0 },
            viewBox: "0 0 24 24",
            width: "15",
            children: s.jsx("path", {
              d: "m6 9 6 6 6-6",
              stroke: "currentColor",
              strokeLinecap: "round",
              strokeLinejoin: "round",
              strokeWidth: "2",
            }),
          }),
        ],
      }),
      j
        ? s.jsx("div", {
            "aria-label": "Database",
            id: "profile-database-options",
            role: "radiogroup",
            style: {
              display: "grid",
              gap: "0.125rem",
              gridTemplateColumns: "repeat(3, minmax(0, 1fr))",
              padding: "0.125rem 0.5rem 0.5rem 2rem",
            },
            children: ec.map((U) =>
              s.jsxs(
                "button",
                {
                  "aria-checked": d === U.value,
                  "aria-label": U.locked ? `${U.label}, locked` : U.label,
                  "data-database-source": U.value,
                  disabled: U.locked,
                  onClick: () => g(U.value),
                  role: "radio",
                  style: {
                    background: d === U.value ? ge : "transparent",
                    border: `1px solid ${d === U.value ? ge : M ? "#475569" : "#cbd5e1"}`,
                    borderRadius: "9999px",
                    color: U.locked
                      ? O
                      : d === U.value
                        ? M
                          ? "#0f172a"
                          : "#ffffff"
                        : q,
                    cursor: U.locked ? "not-allowed" : "pointer",
                    display: "inline-flex",
                    fontFamily: "inherit",
                    fontSize: "0.75rem",
                    fontWeight: 700,
                    minHeight: "1.875rem",
                    opacity: U.locked ? 0.62 : 1,
                    padding: "0.25rem 0.45rem",
                    alignItems: "center",
                    justifyContent: "center",
                    gap: "0.2rem",
                  },
                  title: U.locked ? "Locked" : U.label,
                  type: "button",
                  children: [
                    U.locked
                      ? s.jsxs("svg", {
                          "aria-hidden": "true",
                          fill: "none",
                          height: "11",
                          viewBox: "0 0 24 24",
                          width: "11",
                          children: [
                            s.jsx("rect", {
                              height: "10",
                              rx: "2",
                              stroke: "currentColor",
                              strokeWidth: "2",
                              width: "14",
                              x: "5",
                              y: "11",
                            }),
                            s.jsx("path", {
                              d: "M8 11V8a4 4 0 0 1 8 0v3",
                              stroke: "currentColor",
                              strokeLinecap: "round",
                              strokeWidth: "2",
                            }),
                          ],
                        })
                      : null,
                    U.label,
                  ],
                },
                U.value,
              ),
            ),
          })
        : null,
    ],
  });
}
function ac({ className: d, size: g = "medium", style: f }) {
  return s.jsxs("span", {
    "aria-label": "comp.school",
    className: d,
    style: {
      alignItems: "baseline",
      color: "inherit",
      display: "inline-flex",
      fontSize: Hd[g],
      lineHeight: 1,
      textTransform: "none",
      whiteSpace: "nowrap",
      ...f,
    },
    children: [
      s.jsxs("span", {
        "aria-hidden": "true",
        "data-comp-school-wordmark-part": "comp-dot",
        style: {
          color: ba,
          fontFamily:
            "Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
          fontSize: "0.88em",
          fontStyle: "normal",
          fontWeight: 650,
          letterSpacing: "-0.035em",
        },
        children: [
          "comp",
          s.jsx("span", { style: { color: ba }, children: "." }),
        ],
      }),
      s.jsx("span", {
        "aria-hidden": "true",
        "data-comp-school-wordmark-part": "school",
        style: {
          color: $d,
          fontFamily: "'Caveat', 'Segoe Print', cursive",
          fontSize: "1.2em",
          fontStyle: "italic",
          fontWeight: 700,
          letterSpacing: "-0.04em",
          transform: "rotate(-2deg)",
        },
        children: "school",
      }),
    ],
  });
}
function Vd(d) {
  switch (d.trim().toLocaleLowerCase()) {
    case "exams":
      return s.jsxs(s.Fragment, {
        children: [
          s.jsx("path", { d: "m2 9 10-5 10 5-10 5Z" }),
          s.jsx("path", { d: "M6 11.5V16c3.5 2.7 8.5 2.7 12 0v-4.5M22 9v6" }),
        ],
      });
    case "analytics":
      return s.jsx(s.Fragment, {
        children: s.jsx("path", { d: "M4 20V10M10 20V4M16 20v-7M22 20H2" }),
      });
    case "printouts":
      return s.jsxs(s.Fragment, {
        children: [
          s.jsx("path", { d: "M7 8V3h10v5" }),
          s.jsx("path", {
            d: "M7 17H5a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2",
          }),
          s.jsx("path", { d: "M7 14h10v7H7z" }),
          s.jsx("path", { d: "M17 11h.01" }),
        ],
      });
    case "mark":
    case "marking":
      return s.jsxs(s.Fragment, {
        children: [
          s.jsx("path", { d: "M4 3h13a3 3 0 0 1 3 3v15H7a3 3 0 0 1-3-3Z" }),
          s.jsx("path", { d: "M7 17h13M8 8h8M8 12h5" }),
        ],
      });
    case "recall":
    case "topic drills":
      return s.jsxs(s.Fragment, {
        children: [
          s.jsx("circle", { cx: "12", cy: "12", r: "8" }),
          s.jsx("circle", { cx: "12", cy: "12", r: "3" }),
          s.jsx("path", { d: "M12 2v3M22 12h-3M12 22v-3M2 12h3" }),
        ],
      });
    case "coding playground":
      return s.jsx("path", { d: "m8 9-3 3 3 3M16 9l3 3-3 3M14 5l-4 14" });
    case "forms":
    case "self assess":
      return s.jsxs(s.Fragment, {
        children: [
          s.jsx("rect", { height: "18", rx: "2", width: "14", x: "5", y: "4" }),
          s.jsx("path", { d: "M9 4V2h6v2M8.5 13l2 2 5-5" }),
        ],
      });
    case "games":
      return s.jsxs(s.Fragment, {
        children: [
          s.jsx("path", {
            d: "M7.5 8h9a4.5 4.5 0 0 1 4.2 6.1l-1 2.7a2.5 2.5 0 0 1-4.1 1l-1.4-1.3H9.8l-1.4 1.3a2.5 2.5 0 0 1-4.1-1l-1-2.7A4.5 4.5 0 0 1 7.5 8Z",
          }),
          s.jsx("path", { d: "M8 11v4M6 13h4M16.5 12h.01M18.5 14h.01" }),
        ],
      });
    case "admin":
      return s.jsxs(s.Fragment, {
        children: [
          s.jsx("rect", { height: "7", rx: "1", width: "7", x: "3", y: "3" }),
          s.jsx("rect", { height: "7", rx: "1", width: "7", x: "14", y: "3" }),
          s.jsx("rect", { height: "7", rx: "1", width: "7", x: "3", y: "14" }),
          s.jsx("rect", { height: "7", rx: "1", width: "7", x: "14", y: "14" }),
        ],
      });
    case "docs":
      return s.jsxs(s.Fragment, {
        children: [
          s.jsx("path", {
            d: "M4 5.5A3.5 3.5 0 0 1 7.5 2H11v17H7.5A3.5 3.5 0 0 0 4 22Z",
          }),
          s.jsx("path", {
            d: "M20 5.5A3.5 3.5 0 0 0 16.5 2H13v17h3.5A3.5 3.5 0 0 1 20 22Z",
          }),
        ],
      });
    case "issues":
      return s.jsxs(s.Fragment, {
        children: [
          s.jsx("circle", { cx: "12", cy: "12", r: "9" }),
          s.jsx("path", { d: "M12 7v6M12 17h.01" }),
        ],
      });
    default:
      return s.jsxs(s.Fragment, {
        children: [
          s.jsx("rect", { height: "7", rx: "1", width: "7", x: "3", y: "3" }),
          s.jsx("rect", { height: "7", rx: "1", width: "7", x: "14", y: "3" }),
          s.jsx("rect", { height: "7", rx: "1", width: "7", x: "3", y: "14" }),
          s.jsx("rect", { height: "7", rx: "1", width: "7", x: "14", y: "14" }),
        ],
      });
  }
}
function Qd({ appName: d, className: g, style: f }) {
  return s.jsx("svg", {
    "aria-hidden": "true",
    className: g,
    "data-comp-school-app-icon": d,
    fill: "none",
    focusable: "false",
    height: "24",
    stroke: "currentColor",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    strokeWidth: "1.9",
    style: {
      color: "#14b8a6",
      flex: "0 0 auto",
      height: "1.5rem",
      width: "1.5rem",
      ...f,
    },
    viewBox: "0 0 24 24",
    width: "24",
    children: Vd(d),
  });
}
function Zd(d) {
  return d.trim().charAt(0).toLocaleUpperCase() || "U";
}
function tc({ avatar: d, instanceId: g, profileName: f, style: j }) {
  const C = uc(d);
  return C
    ? s.jsx("span", {
        "aria-hidden": "true",
        "data-student-avatar": C.id,
        style: {
          display: "block",
          height: "100%",
          lineHeight: 0,
          width: "100%",
          ...j,
        },
        children: s.jsx(Fd, {
          features: C,
          idSuffix: g ? `${g}-${C.id}` : C.id,
        }),
      })
    : s.jsx("span", {
        "aria-hidden": "true",
        style: { lineHeight: 1, ...j },
        children: Zd(f),
      });
}
function Kd({
  appName: d,
  appIcon: g,
  backHref: f,
  profileName: j,
  backLabel: C = "Back",
  canChangeAvatar: M = !1,
  changeAvatarHref: $,
  children: q,
  className: O,
  contextLabel: ge,
  dataSource: U,
  logoSrc: re = "/favicon/favicon.svg",
  logoTone: K = "brand",
  onBack: Te,
  onDataSourceChange: Oe,
  onSignOut: J,
  profileAvatar: Q,
  reportIssueHref: Ce,
  style: Ze,
  tone: Fe = "dark",
}) {
  const te = Fe === "dark",
    fe = !!uc(Q),
    ne = te ? "#f8fafc" : "#0f172a",
    ue = te ? "#cbd5e1" : "#475569",
    je = te ? "#334155" : "#e2e8f0",
    Ke = te ? "#0f172a" : "#ffffff",
    et = te ? "#1e293b" : "#f8fafc",
    it = s.jsxs(s.Fragment, {
      children: [
        s.jsx("svg", {
          "aria-hidden": "true",
          fill: "none",
          height: "16",
          viewBox: "0 0 24 24",
          width: "16",
          children: s.jsx("path", {
            d: "M19 12H5m7 7-7-7 7-7",
            stroke: "currentColor",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "2",
          }),
        }),
        s.jsx("span", { children: C }),
      ],
    }),
    Ae = {
      alignItems: "center",
      background: et,
      border: `1px solid ${je}`,
      borderRadius: "0.625rem",
      color: ue,
      cursor: "pointer",
      display: "inline-flex",
      fontFamily: "inherit",
      fontSize: "0.875rem",
      fontWeight: 700,
      gap: "0.375rem",
      minHeight: "2.5rem",
      padding: "0.5rem 0.75rem",
      textDecoration: "none",
      whiteSpace: "nowrap",
    },
    Ee = {
      ...Ae,
      background: "transparent",
      border: 0,
      color: ne,
      justifyContent: "flex-start",
      width: "100%",
    };
  return s.jsx("header", {
    "aria-label": `${d} navigation`,
    className: O,
    "data-comp-school-navbar": "standard",
    style: {
      background: Ke,
      borderBottom: `1px solid ${je}`,
      color: ne,
      fontFamily:
        "Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
      position: "relative",
      zIndex: 30,
      ...Ze,
    },
    children: s.jsxs("div", {
      style: {
        alignItems: "center",
        display: "flex",
        gap: "0.75rem",
        justifyContent: "space-between",
        margin: "0 auto",
        maxWidth: "80rem",
        minHeight: "4rem",
        padding: "0.625rem clamp(1rem, 3vw, 2rem)",
        width: "100%",
      },
      children: [
        s.jsxs("div", {
          style: {
            alignItems: "center",
            display: "flex",
            gap: "0.625rem",
            minWidth: 0,
          },
          children: [
            s.jsx("img", {
              alt: "",
              "aria-hidden": "true",
              src: re,
              style: {
                filter: K === "grayscale" ? "grayscale(1)" : void 0,
                height: "2rem",
                objectFit: "contain",
                opacity: K === "grayscale" ? 0.58 : 1,
                width: "2rem",
              },
            }),
            g === void 0 ? s.jsx(Qd, { appName: d }) : g,
            s.jsx("strong", {
              style: {
                color: ne,
                fontSize: "1rem",
                fontWeight: 750,
                lineHeight: 1.2,
                overflow: "hidden",
                textOverflow: "ellipsis",
                whiteSpace: "nowrap",
              },
              children: d,
            }),
            ge
              ? s.jsx("span", {
                  style: {
                    borderLeft: `1px solid ${je}`,
                    color: ue,
                    fontSize: "0.875rem",
                    fontWeight: 650,
                    lineHeight: 1.2,
                    minWidth: 0,
                    overflow: "hidden",
                    paddingLeft: "0.625rem",
                    textOverflow: "ellipsis",
                    whiteSpace: "nowrap",
                  },
                  children: ge,
                })
              : null,
          ],
        }),
        s.jsxs("div", {
          style: { alignItems: "center", display: "flex", gap: "0.625rem" },
          children: [
            Te
              ? s.jsx("button", {
                  "aria-label": C,
                  onClick: Te,
                  style: Ae,
                  type: "button",
                  children: it,
                })
              : s.jsx("a", {
                  "aria-label": C,
                  href: f,
                  style: Ae,
                  children: it,
                }),
            q,
            Ce && J
              ? s.jsxs("details", {
                  "data-comp-school-account-menu": !0,
                  style: { position: "relative" },
                  children: [
                    s.jsx("summary", {
                      "aria-label": `${j} account menu`,
                      title: `${j} account`,
                      style: {
                        alignItems: "center",
                        background: fe
                          ? "transparent"
                          : te
                            ? "#e2e8f0"
                            : "#0f172a",
                        borderRadius: fe ? "0.8rem" : "9999px",
                        color: te ? "#0f172a" : "#ffffff",
                        cursor: "pointer",
                        display: "inline-flex",
                        flex: "0 0 auto",
                        fontSize: "0.875rem",
                        fontWeight: 800,
                        height: "2.5rem",
                        justifyContent: "center",
                        listStyle: "none",
                        overflow: "hidden",
                        width: "2.5rem",
                      },
                      children: s.jsx(tc, { avatar: Q, profileName: j }),
                    }),
                    s.jsxs("div", {
                      style: {
                        background: Ke,
                        border: `1px solid ${je}`,
                        borderRadius: "0.75rem",
                        boxShadow: "0 20px 25px -5px rgba(2, 6, 23, 0.35)",
                        minWidth: "15rem",
                        padding: "0.5rem",
                        position: "absolute",
                        right: 0,
                        top: "calc(100% + 0.5rem)",
                        zIndex: 40,
                      },
                      children: [
                        s.jsx("p", {
                          style: {
                            color: ue,
                            fontSize: "0.75rem",
                            fontWeight: 700,
                            letterSpacing: "0.05em",
                            margin: 0,
                            padding: "0.375rem 0.5rem",
                            textTransform: "uppercase",
                          },
                          children: j.split(" ")[0] || j,
                        }),
                        U && Oe
                          ? s.jsx(Bd, {
                              dataSource: U,
                              onDataSourceChange: Oe,
                              tone: Fe,
                            })
                          : null,
                        M && $
                          ? s.jsxs("a", {
                              href: $,
                              style: Ee,
                              children: [
                                s.jsxs("svg", {
                                  "aria-hidden": "true",
                                  fill: "none",
                                  height: "16",
                                  viewBox: "0 0 24 24",
                                  width: "16",
                                  children: [
                                    s.jsx("path", {
                                      d: "M12 4c-4.4 0-8 3.1-8 7 0 2.9 2 5.4 4.9 6.5L8 21l3.4-2.8H12c4.4 0 8-3.1 8-7s-3.6-7.2-8-7.2Z",
                                      stroke: "currentColor",
                                      strokeLinejoin: "round",
                                      strokeWidth: "1.8",
                                    }),
                                    s.jsx("circle", {
                                      cx: "9",
                                      cy: "10",
                                      fill: "currentColor",
                                      r: "1",
                                    }),
                                    s.jsx("circle", {
                                      cx: "15",
                                      cy: "10",
                                      fill: "currentColor",
                                      r: "1",
                                    }),
                                  ],
                                }),
                                s.jsx("span", { children: "Change avatar" }),
                              ],
                            })
                          : null,
                        s.jsxs("a", {
                          href: Ce,
                          style: Ee,
                          children: [
                            s.jsxs("svg", {
                              "aria-hidden": "true",
                              fill: "none",
                              height: "16",
                              viewBox: "0 0 24 24",
                              width: "16",
                              children: [
                                s.jsx("path", {
                                  d: "M8 2 6.5 5M16 2l1.5 3M4 9H2M22 9h-2M5 19l2.5-2.5M19 19l-2.5-2.5M9 5h6a4 4 0 0 1 4 4v4a7 7 0 0 1-14 0V9a4 4 0 0 1 4-4Z",
                                  stroke: "currentColor",
                                  strokeLinecap: "round",
                                  strokeLinejoin: "round",
                                  strokeWidth: "1.8",
                                }),
                                s.jsx("path", {
                                  d: "M8 12h8M12 8v8",
                                  stroke: "currentColor",
                                  strokeLinecap: "round",
                                  strokeWidth: "1.8",
                                }),
                              ],
                            }),
                            s.jsx("span", { children: "Report an issue" }),
                          ],
                        }),
                        s.jsxs("button", {
                          onClick: J,
                          style: { ...Ee, marginTop: "0.25rem" },
                          type: "button",
                          children: [
                            s.jsx("svg", {
                              "aria-hidden": "true",
                              fill: "none",
                              height: "16",
                              viewBox: "0 0 24 24",
                              width: "16",
                              children: s.jsx("path", {
                                d: "M10 17l5-5-5-5M15 12H3M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4",
                                stroke: "currentColor",
                                strokeLinecap: "round",
                                strokeLinejoin: "round",
                                strokeWidth: "1.8",
                              }),
                            }),
                            s.jsx("span", { children: "Sign out" }),
                          ],
                        }),
                      ],
                    }),
                  ],
                })
              : s.jsx("span", {
                  "aria-label": `${j} profile`,
                  title: j,
                  style: {
                    alignItems: "center",
                    background: fe ? "transparent" : te ? "#e2e8f0" : "#0f172a",
                    borderRadius: fe ? "0.8rem" : "9999px",
                    color: te ? "#0f172a" : "#ffffff",
                    display: "inline-flex",
                    flex: "0 0 auto",
                    fontSize: "0.875rem",
                    fontWeight: 800,
                    height: "2.5rem",
                    justifyContent: "center",
                    overflow: "hidden",
                    width: "2.5rem",
                  },
                  children: s.jsx(tc, { avatar: Q, profileName: j }),
                }),
          ],
        }),
      ],
    }),
  });
}
const Gd = { BASE_URL: "/", DEV: !1, MODE: "production", PROD: !0, SSR: !1 },
  Yd = Be.createContext(null),
  Xd = Be.createContext(null),
  qd = Be.createContext(!1),
  Al = "comp-school-fallback-access";
function nc() {
  return typeof window > "u" || typeof document > "u"
    ? null
    : lc(document.cookie, window.location.hostname, Vi().DEV === !0);
}
function Jd(d) {
  if (typeof window > "u" || typeof document > "u") return;
  const g = jd(d);
  lc(g, window.location.hostname, Vi().DEV === !0) && (document.cookie = g);
}
function bd() {
  typeof document > "u" || (document.cookie = zd());
}
function Wi(d, g) {
  return (
    g &&
    d.role === "teacher" &&
    new URLSearchParams(window.location.search).get("preview") === "student"
  );
}
function ep() {
  if (typeof window > "u") return null;
  const d = new URLSearchParams(window.location.hash.replace(/^#/, "")),
    g = d.get("fallback");
  if (g && Ga(g)) {
    (window.sessionStorage.setItem(Al, g), d.delete("fallback"));
    const j = d.toString();
    window.history.replaceState(
      {},
      "",
      `${window.location.pathname}${window.location.search}${j ? `#${j}` : ""}`,
    );
  }
  const f = g || window.sessionStorage.getItem(Al);
  return Ga(f) ? f : (window.sessionStorage.removeItem(Al), null);
}
const Tt = {
  loadingMain: {
    alignItems: "center",
    background: "#020617",
    color: "#ffffff",
    display: "grid",
    fontFamily:
      'Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
    minHeight: "100vh",
    padding: "1rem",
    placeItems: "center",
  },
  loadingText: {
    color: "#cbd5e1",
    fontSize: "0.875rem",
    fontWeight: 500,
    margin: 0,
  },
  main: {
    alignItems: "center",
    background: "#020617",
    color: "#ffffff",
    display: "flex",
    fontFamily:
      'Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
    justifyContent: "center",
    minHeight: "100vh",
    padding: "2.5rem 1rem",
  },
  panel: {
    background: "var(--cs-surface, #ffffff)",
    border: "1px solid var(--cs-border, rgba(255, 255, 255, 0.1))",
    borderRadius: "0.5rem",
    boxShadow:
      "0 25px 50px -12px rgba(15, 23, 42, 0.45), 0 12px 24px -16px rgba(15, 23, 42, 0.6)",
    color: "var(--cs-text, #020617)",
    maxWidth: "24rem",
    padding: "1.5rem",
    width: "100%",
  },
  title: {
    fontSize: "1.5rem",
    fontWeight: 700,
    lineHeight: 1.2,
    margin: "0.75rem 0 0",
  },
  copy: {
    color: "var(--cs-text-muted, #475569)",
    fontSize: "0.875rem",
    lineHeight: 1.6,
    margin: "0.5rem 0 0",
  },
  actions: { display: "grid", gap: "1rem", marginTop: "1.5rem" },
  error: { color: "#dc2626", fontSize: "0.875rem", fontWeight: 600, margin: 0 },
  link: {
    background: "var(--cs-primary-hover, #2563eb)",
    borderRadius: "0.375rem",
    color: "#ffffff",
    display: "block",
    fontSize: "0.875rem",
    fontWeight: 700,
    padding: "0.75rem 1rem",
    textAlign: "center",
    textDecoration: "none",
    width: "100%",
  },
};
function Vi() {
  return Gd || {};
}
function tp(d) {
  return Rd(window.location.hostname, d, Vi().VITE_PLATFORM_URL);
}
function np({
  appName: d,
  children: g,
  allowedRoles: f,
  navbarChildren: j,
  navbarStyle: C,
  productionUrl: M,
  showNavbar: $ = !0,
  allowFallback: q = !1,
  allowTeacherStudentPreview: O = !1,
}) {
  const U =
      new URLSearchParams(window.location.search).get("sql") === "mock"
        ? "mock"
        : "product",
    re = Be.useMemo(() => tp(M), [M]),
    K = Be.useMemo(() => ic(window.location.hostname), []),
    Te = Be.useMemo(
      () => sc(window.location.hostname, "https://issues.comp.school"),
      [],
    ),
    Oe = Be.useMemo(() => {
      const oe = new URL(K);
      return (oe.searchParams.set("changeAvatar", "1"), oe.toString());
    }, [K]),
    J = f ? f.join(",") : "",
    [Q, Ce] = Be.useState(null),
    [Ze, Fe] = Be.useState(!0),
    [te, fe] = Be.useState(!1),
    [ne, ue] = Be.useState(null),
    [je, Ke] = Be.useState(!1),
    [et, it] = Be.useState(null);
  async function Ae() {
    (await fetch("/api/logout", {
      cache: "no-store",
      credentials: "same-origin",
      method: "POST",
    }).catch(() => {}),
      ue(null),
      bd(),
      window.sessionStorage.removeItem(Al),
      Ke(!1),
      fe(!1),
      window.location.assign(K));
  }
  function Ee(oe) {
    if (oe === "real") return;
    const de = new URL(window.location.href);
    (de.searchParams.set("sql", oe), window.location.assign(de.toString()));
  }
  if (
    (Be.useEffect(() => {
      let oe = !1;
      return (
        fetch("/api/session", {
          cache: "no-store",
          credentials: "same-origin",
          headers: { accept: "application/json" },
        })
          .then(async (de) => {
            const ve = await de.json().catch(() => null);
            if (oe) return;
            if (
              de.ok &&
              ve?.ok &&
              ve.user &&
              (!f || f.includes(ve.user.role) || Wi(ve.user, O))
            ) {
              (Jd(ve.user), Ce(null), ue(ve.user), fe(!0));
              return;
            }
            const le = nc();
            if (le && (!f || f.includes(le.role) || Wi(le, O))) {
              (Ce(null), ue(le), fe(!0));
              return;
            }
            if (q && ep()) {
              (Ce(null), Ke(!0), fe(!0));
              return;
            }
            (Ce(ve?.message || null), ue(null), fe(!1));
          })
          .catch(() => {
            if (!oe) {
              const de = nc();
              if (de && (!f || f.includes(de.role) || Wi(de, O))) {
                (Ce(null), ue(de), fe(!0));
                return;
              }
              (Ce("Unable to check platform access right now."),
                ue(null),
                fe(!1));
            }
          })
          .finally(() => {
            oe || Fe(!1);
          }),
        () => {
          oe = !0;
        }
      );
    }, [J, q, O]),
    Ze)
  )
    return s.jsx("main", {
      style: Tt.loadingMain,
      children: s.jsx("p", {
        style: Tt.loadingText,
        children: "Checking platform access...",
      }),
    });
  if (te) {
    const oe = ne?.role === "admin" || ne?.role === "teacher",
      de = new URL(K);
    return (
      oe && de.searchParams.set("sql", U),
      s.jsxs(s.Fragment, {
        children: [
          $ && (ne || je)
            ? s.jsx(Kd, {
                appName: d,
                backHref: de.toString(),
                canChangeAvatar: ne?.role === "student",
                changeAvatarHref: Oe,
                contextLabel: et,
                dataSource: oe ? U : void 0,
                onDataSourceChange: oe ? Ee : void 0,
                onSignOut: Ae,
                profileAvatar: ne?.role === "student" ? ne.avatar : void 0,
                profileName: ne?.name || "Fallback",
                reportIssueHref: Te,
                style: C,
                children: j,
              })
            : null,
          s.jsx(qd.Provider, {
            value: je,
            children: s.jsx(Xd.Provider, {
              value: ne,
              children: s.jsx(Yd.Provider, { value: it, children: g }),
            }),
          }),
        ],
      })
    );
  }
  return s.jsx("main", {
    style: Tt.main,
    children: s.jsxs("section", {
      style: Tt.panel,
      children: [
        s.jsx(ac, { size: "small", style: { color: "#0f172a" } }),
        s.jsx("h1", { style: Tt.title, children: d }),
        s.jsx("p", {
          style: Tt.copy,
          children: "Open comp.school and enter your access code to continue.",
        }),
        s.jsxs("div", {
          style: Tt.actions,
          children: [
            Q && s.jsx("p", { style: Tt.error, children: Q }),
            s.jsx("a", {
              "aria-label": `Open comp.school to access ${d}`,
              href: re,
              style: Tt.link,
              children: "Open comp.school",
            }),
          ],
        }),
      ],
    }),
  });
}
const rp = ["Keyword sprint", "Trace table", "Syntax match"];
function lp() {
  return s.jsx("main", {
    className: "min-h-screen bg-stone-50 text-stone-950",
    children: s.jsxs("section", {
      className:
        "mx-auto flex min-h-screen w-full max-w-6xl flex-col justify-center px-6 py-12",
      children: [
        s.jsx(ac, { size: "small" }),
        s.jsx("h1", {
          className: "mt-3 text-4xl font-semibold tracking-normal",
          children: "Games",
        }),
        s.jsx("p", {
          className: "mt-4 max-w-2xl text-lg leading-8 text-stone-700",
          children:
            "A lightweight launch point for revision games that turn repeated practice into short, trackable sessions.",
        }),
        s.jsx("div", {
          className: "mt-10 grid gap-4 md:grid-cols-3",
          children: rp.map((d) =>
            s.jsxs(
              "article",
              {
                className: "rounded-lg border border-stone-200 bg-white p-5",
                children: [
                  s.jsx("p", {
                    className: "text-sm text-stone-500",
                    children: "Game mode",
                  }),
                  s.jsx("h2", {
                    className: "mt-2 text-2xl font-semibold",
                    children: d,
                  }),
                ],
              },
              d,
            ),
          ),
        }),
      ],
    }),
  });
}
gd.createRoot(document.getElementById("root")).render(
  s.jsx(cd.StrictMode, {
    children: s.jsx(np, {
      appName: "Games",
      allowedRoles: ["admin", "student"],
      productionUrl: "https://games.comp.school",
      children: s.jsx(lp, {}),
    }),
  }),
);
