const __vite__mapDeps = (
  i,
  m = __vite__mapDeps,
  d = m.f ||
    (m.f = [
      "assets/DocEditor-DeUhOnwy.js",
      "assets/index-CHiQZc8e.js",
      "assets/index-CFivEobA.css",
      "assets/OfficeChrome-BlQi-GP2.js",
      "assets/coursework-editors-DmNamGFm.js",
      "assets/coursework-editors-DaVJxHR9.css",
      "assets/SheetEditor-DPKlmwzo.js",
      "assets/_commonjs-dynamic-modules-TDtrdbi3.js",
      "assets/ColorPicker-BhoKJ44-.js",
      "assets/ColorPicker-CZvJVrS3.css",
      "assets/SheetEditor-BwZZ7LaJ.css",
      "assets/SlidesEditor-D6FV6HWV.js",
      "assets/pictures-CQnqrXNG.js",
      "assets/officeExport-CWuTEx50.js",
    ]),
) => i.map((i) => d[i]);
import {
  i as v,
  k as W,
  l as U,
  j as e,
  F as K,
  m as B,
  n as G,
  o as D,
  q as g,
  L as H,
  t as q,
  P as X,
  v as J,
  w as Q,
  x as Y,
  y as Z,
  z as F,
  r,
  D as ee,
  G as se,
  H as te,
  I as ae,
  J as ne,
  K as le,
  M as L,
  N as re,
  Q as ie,
  U as oe,
  V as ce,
  _ as f,
  R as de,
} from "./index-CHiQZc8e.js";
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const ue = v("Bike", [
  ["circle", { cx: "18.5", cy: "17.5", r: "3.5", key: "15x4ox" }],
  ["circle", { cx: "5.5", cy: "17.5", r: "3.5", key: "1noe27" }],
  ["circle", { cx: "15", cy: "5", r: "1", key: "19l28e" }],
  ["path", { d: "M12 17.5V14l-3-3 4-3 2 3h2", key: "1npguv" }],
]);
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const me = v("Download", [
  ["path", { d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4", key: "ih7n3h" }],
  ["polyline", { points: "7 10 12 15 17 10", key: "2ggqvy" }],
  ["line", { x1: "12", x2: "12", y1: "15", y2: "3", key: "1vk2je" }],
]);
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const xe = v("Maximize2", [
  ["polyline", { points: "15 3 21 3 21 9", key: "mznyad" }],
  ["polyline", { points: "9 21 3 21 3 15", key: "1avn1i" }],
  ["line", { x1: "21", x2: "14", y1: "3", y2: "10", key: "ota7mn" }],
  ["line", { x1: "3", x2: "10", y1: "21", y2: "14", key: "1atl0r" }],
]);
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const he = v("Minimize2", [
    ["polyline", { points: "4 14 10 14 10 20", key: "11kfnr" }],
    ["polyline", { points: "20 10 14 10 14 4", key: "rlmsce" }],
    ["line", { x1: "14", x2: "21", y1: "10", y2: "3", key: "o5lafz" }],
    ["line", { x1: "3", x2: "10", y1: "21", y2: "14", key: "1atl0r" }],
  ]),
  pe = r.lazy(() =>
    f(
      () => import("./DocEditor-DeUhOnwy.js"),
      __vite__mapDeps([0, 1, 2, 3, 4, 5]),
    ).then((t) => ({ default: t.DocEditor })),
  ),
  fe = r.lazy(() =>
    f(
      () => import("./SheetEditor-DPKlmwzo.js"),
      __vite__mapDeps([6, 1, 2, 7, 8, 9, 3, 4, 5, 10]),
    ).then((t) => ({ default: t.SheetEditor })),
  ),
  ke = r.lazy(() =>
    f(
      () => import("./SlidesEditor-D6FV6HWV.js"),
      __vite__mapDeps([11, 1, 2, 12, 8, 9, 4, 5]),
    ).then((t) => ({ default: t.SlidesEditor })),
  ),
  we = { "1a": Q, "1b": J, 2: X, 3: q, 4: H },
  S = { doc: "docx", sheet: "xlsx", slides: "pptx" },
  be = [];
function je(t) {
  try {
    return t ? window.localStorage : window.sessionStorage;
  } catch {
    return null;
  }
}
const T =
  "rounded-md p-1 text-slate-500 transition-colors hover:bg-slate-200 hover:text-slate-950 focus:outline-none focus-visible:ring-2 focus-visible:ring-emerald-600";
function P({ onHome: t, lane: s, task: l }) {
  const a = (n) => (i) => {
    (i.preventDefault(), n());
  };
  return e.jsx("nav", {
    "aria-label": "Breadcrumb",
    className: "min-w-0",
    "data-topic-breadcrumb": !0,
    children: e.jsxs("ol", {
      className: "flex flex-wrap items-center gap-1 text-sm text-slate-500",
      children: [
        e.jsx("li", {
          className: "flex items-center",
          children: e.jsx("a", {
            "aria-label": "Home",
            className: T,
            href: "/",
            onClick: a(t),
            children: e.jsx(le, {
              "aria-hidden": "true",
              className: "h-4 w-4",
            }),
          }),
        }),
        e.jsxs("li", {
          className: "flex items-center gap-1",
          children: [
            e.jsx("span", { "aria-hidden": "true", children: "/" }),
            e.jsx("a", {
              className: `${T} font-semibold`,
              href: L("", { lane: null, task: null }),
              onClick: a(() => g({ lane: null, task: null })),
              children: "Coursework",
            }),
          ],
        }),
        s
          ? e.jsxs("li", {
              className: "flex items-center gap-1",
              children: [
                e.jsx("span", { "aria-hidden": "true", children: "/" }),
                e.jsx("a", {
                  className: `${T} font-semibold`,
                  href: L("", { lane: s.id, task: null }),
                  onClick: a(() => g({ lane: s.id, task: null })),
                  children: s.name,
                }),
              ],
            })
          : null,
        l
          ? e.jsxs("li", {
              className: "flex items-center gap-1",
              children: [
                e.jsx("span", { "aria-hidden": "true", children: "/" }),
                e.jsxs("span", {
                  "aria-current": "page",
                  className: "px-1 font-semibold text-slate-950",
                  children: [l.task, " ", l.name],
                }),
              ],
            })
          : null,
      ],
    }),
  });
}
function ge(t) {
  const [s, l] = r.useState({ status: "loading" });
  return (
    r.useEffect(() => {
      let a = !0;
      return (
        l({ status: "loading" }),
        fetch(`${re}${ie(t)}`, {
          cache: "no-store",
          credentials: "same-origin",
          headers: oe(),
        })
          .then(async (n) => (n.ok ? ce(await n.json()) : null))
          .catch(() => null)
          .then((n) => {
            a && l(n ? { status: "ready", brief: n } : { status: "missing" });
          }),
        () => {
          a = !1;
        }
      );
    }, [t]),
    s
  );
}
function $({ value: t }) {
  return e.jsx(e.Fragment, {
    children: t.map((s, l) =>
      typeof s == "string"
        ? e.jsx(de.Fragment, { children: s }, l)
        : "b" in s
          ? e.jsx("strong", { children: s.b }, l)
          : e.jsx(
              "mark",
              {
                className: "rounded bg-amber-100 px-0.5 text-inherit",
                children: s.mark,
              },
              l,
            ),
    ),
  });
}
function ve({ lane: t, state: s }) {
  if (s.status === "loading")
    return e.jsx("p", {
      className: "p-6 text-sm text-[#605e5c]",
      children: "Loading...",
    });
  if (s.status === "missing")
    return e.jsxs("div", {
      className: "brief-page",
      "data-coursework-brief": "missing",
      children: [
        e.jsx("h2", { className: "brief-title", children: t.name }),
        e.jsx("p", { children: "The brief for this lane is not here yet." }),
      ],
    });
  const { brief: l } = s;
  return e.jsxs("article", {
    "aria-label": `${l.title} brief`,
    className: "brief-page",
    "data-coursework-brief": "ready",
    children: [
      e.jsx("h2", { className: "brief-title", children: l.title }),
      l.series
        ? e.jsx("p", { className: "brief-series", children: l.series })
        : null,
      l.blocks.map((a, n) =>
        "h" in a
          ? e.jsx("h3", { children: a.h }, n)
          : "p" in a
            ? e.jsx("p", { children: e.jsx($, { value: a.p }) }, n)
            : e.jsx(
                "ul",
                {
                  children: a.ul.map((i, d) =>
                    e.jsx("li", { children: e.jsx($, { value: i }) }, d),
                  ),
                },
                n,
              ),
      ),
      l.images.length
        ? e.jsxs(e.Fragment, {
            children: [
              e.jsx("h3", { children: "Resource document" }),
              e.jsx("div", {
                className: "brief-images",
                children: l.images.map((a) => e.jsx(ye, { image: a }, a.key)),
              }),
            ],
          })
        : null,
    ],
  });
}
function ye({ image: t }) {
  const [s, l] = r.useState(void 0);
  return (
    r.useEffect(() => {
      let a = !0;
      return (
        f(
          async () => {
            const { pictureUrl: n } = await import("./pictures-CQnqrXNG.js");
            return { pictureUrl: n };
          },
          __vite__mapDeps([12, 1, 2]),
        )
          .then(({ pictureUrl: n }) => n(`brief:${t.key}`))
          .then((n) => {
            a && l(n);
          }),
        () => {
          a = !1;
        }
      );
    }, [t.key]),
    e.jsxs("figure", {
      className: "brief-image",
      children: [
        s
          ? e.jsx("img", { alt: t.alt, src: s })
          : e.jsx("span", {
              className: "brief-image-empty",
              children: s === null ? "Not available" : "...",
            }),
        t.alt ? e.jsx("figcaption", { children: t.alt }) : null,
      ],
    })
  );
}
function Ne() {
  const t = r.useRef(null),
    s = F(),
    [l, a] = r.useState(!1),
    [n, i] = r.useState(!0),
    d = n || s,
    m = r.useCallback(() => {
      document.fullscreenElement
        ? document.exitFullscreen?.()
        : t.current?.requestFullscreen?.();
    }, []),
    x = r.useCallback(() => {
      (document.fullscreenElement && document.exitFullscreen?.(), i((o) => !o));
    }, []);
  return (
    r.useEffect(() => {
      const o = t.current,
        u = () => a(!!(o && document.fullscreenElement === o));
      return (
        document.addEventListener("fullscreenchange", u),
        () => {
          (document.removeEventListener("fullscreenchange", u),
            o &&
              document.fullscreenElement === o &&
              document.exitFullscreen?.());
        }
      );
    }, []),
    r.useEffect(() => {
      if (!d) return;
      const o = document.documentElement;
      return (
        (o.dataset.gameWindow = "true"),
        () => {
          delete o.dataset.gameWindow;
        }
      );
    }, [d]),
    {
      ref: t,
      fullscreen: l,
      supported: !!document.fullscreenEnabled,
      toggle: m,
      windowed: d,
      toggleWindow: x,
    }
  );
}
function O({ title: t, expanded: s, onToggle: l, expandLabel: a }) {
  const n = s ? he : xe;
  return e.jsxs("div", {
    className: "pane-header",
    children: [
      e.jsx("h2", {
        className: "text-sm font-semibold text-[#323130]",
        children: t,
      }),
      e.jsx("button", {
        "aria-label": s ? "Back to split view" : a,
        "aria-pressed": s,
        className: "pane-toggle",
        onClick: l,
        title: s ? "Back to split view" : a,
        type: "button",
        children: e.jsx(n, { "aria-hidden": "true", className: "h-4 w-4" }),
      }),
    ],
  });
}
function Ee({ lane: t, info: s, signedIn: l, onHome: a }) {
  Z();
  const n = Ne(),
    i = F(),
    d = ge(t),
    [m, x] = r.useState("split"),
    o = r.useMemo(() => je(l), [l]),
    [u, I] = r.useState(() => ee(o, t, s)?.content ?? se(s.kind)),
    [h, A] = r.useState("idle"),
    y = r.useRef(u),
    N = r.useRef(!1),
    p = r.useRef(null),
    k = r.useCallback(() => {
      (p.current !== null &&
        (window.clearTimeout(p.current), (p.current = null)),
        N.current && ((N.current = !1), A(te(o, t, s, y.current))));
    }, [o, t, s]);
  r.useEffect(() => {
    const c = ae(k);
    return () => {
      (c(), k());
    };
  }, [k]);
  const w = i && m === "split" ? "work" : m;
  function E(c) {
    ((y.current = c),
      (N.current = !0),
      I(c),
      p.current !== null && window.clearTimeout(p.current),
      (p.current = window.setTimeout(k, 500)));
  }
  async function M() {
    k();
    const c = await f(
        () => import("./officeExport-CWuTEx50.js"),
        __vite__mapDeps([13, 1, 2]),
      ),
      j = y.current,
      R = S[s.kind],
      z = await (j.kind === "doc"
        ? c.buildDocx(j, `${s.task} ${s.name}`)
        : j.kind === "sheet"
          ? c.buildXlsx(j, s.name)
          : c.buildPptx(
              j,
              (
                await f(
                  async () => {
                    const { pictureDataUrl: V } =
                      await import("./pictures-CQnqrXNG.js");
                    return { pictureDataUrl: V };
                  },
                  __vite__mapDeps([12, 1, 2]),
                )
              ).pictureDataUrl,
            ));
    c.downloadBytes(z, `${s.fileName}.${R}`, c.OFFICE_TYPES[R]);
  }
  const b = `${s.task} ${s.name}`,
    _ = `${s.fileName}.${S[s.kind]}`,
    C = n.windowed || n.fullscreen;
  return e.jsxs("section", {
    "aria-label": b,
    className: C ? "workspace workspace-immersive" : "workspace",
    "data-coursework-task": s.task,
    "data-coursework-workspace": C ? "window" : "page",
    ref: n.ref,
    children: [
      e.jsxs("header", {
        className: "workspace-bar",
        children: [
          e.jsx(P, { lane: t, onHome: a, task: s }),
          e.jsxs("div", {
            className: "ml-auto flex flex-wrap items-center gap-2 pr-1",
            children: [
              e.jsx("span", {
                "aria-live": "polite",
                className:
                  h === "too-big" || h === "failed"
                    ? "rounded-md bg-rose-50 px-2 py-1 text-sm font-semibold text-rose-800"
                    : "sr-only",
                "data-coursework-status": h,
                children:
                  h === "saved"
                    ? "Saved"
                    : h === "too-big"
                      ? "Too big to save. Download it, then split it up."
                      : h === "failed"
                        ? "Not saved. Download it to keep it."
                        : "",
              }),
              l
                ? null
                : e.jsx("span", {
                    className: "text-sm font-semibold text-slate-600",
                    "data-coursework-tab-only": "",
                    children: "This tab only",
                  }),
              e.jsxs("button", {
                className: "workspace-download",
                "data-coursework-download": "",
                onClick: () => void M(),
                type: "button",
                children: [
                  e.jsx(me, { "aria-hidden": "true", className: "h-4 w-4" }),
                  " .",
                  S[s.kind],
                ],
              }),
              e.jsx("div", {
                className: C ? "workspace-view-controls" : void 0,
                children: e.jsx(ne, {
                  className:
                    "border-slate-300 text-slate-700 hover:bg-slate-200",
                  fullscreen: n.fullscreen,
                  immersiveClassName:
                    "border-slate-300 bg-white text-slate-700 hover:bg-slate-100",
                  onToggleFullscreen: n.toggle,
                  onToggleWindow: n.toggleWindow,
                  supported: n.supported,
                  windowed: n.windowed,
                }),
              }),
            ],
          }),
        ],
      }),
      i
        ? e.jsxs("div", {
            "aria-label": "Show",
            className: "workspace-tabs",
            role: "tablist",
            children: [
              e.jsx("button", {
                "aria-selected": w === "brief",
                onClick: () => x("brief"),
                role: "tab",
                type: "button",
                children: "Brief",
              }),
              e.jsx("button", {
                "aria-selected": w !== "brief",
                onClick: () => x("work"),
                role: "tab",
                type: "button",
                children: s.name,
              }),
            ],
          })
        : null,
      e.jsxs("div", {
        className: "workspace-panes",
        "data-focus": w,
        children: [
          e.jsxs("div", {
            className: "workspace-pane workspace-brief",
            "data-pane": "brief",
            hidden: w === "work",
            children: [
              i
                ? null
                : e.jsx(O, {
                    expandLabel: "Open out the brief",
                    expanded: m === "brief",
                    onToggle: () => x(m === "brief" ? "split" : "brief"),
                    title: "Brief",
                  }),
              e.jsx("div", {
                className: "brief-scroll",
                children: e.jsx(ve, { lane: t, state: d }),
              }),
            ],
          }),
          e.jsxs("div", {
            className: "workspace-pane workspace-work",
            "data-pane": "work",
            hidden: w === "brief",
            children: [
              i
                ? null
                : e.jsx(O, {
                    expandLabel: `Open out ${s.name.toLowerCase()}`,
                    expanded: m === "work",
                    onToggle: () => x(m === "work" ? "split" : "work"),
                    title: b,
                  }),
              e.jsx(r.Suspense, {
                fallback: e.jsx("p", {
                  className: "p-6 text-sm font-medium text-slate-500",
                  children: "Loading...",
                }),
                children:
                  u.kind === "doc"
                    ? e.jsx(pe, {
                        content: u,
                        fileName: _,
                        label: b,
                        onChange: E,
                      })
                    : u.kind === "sheet"
                      ? e.jsx(fe, {
                          content: u,
                          fileName: _,
                          label: b,
                          onChange: E,
                        })
                      : e.jsx(ke, {
                          briefImages:
                            d.status === "ready" ? d.brief.images : be,
                          content: u,
                          fileName: _,
                          label: b,
                          onChange: E,
                        }),
              }),
            ],
          }),
        ],
      }),
    ],
  });
}
function Ce({ route: t, signedIn: s, onHome: l }) {
  const a = W(t.lane) ?? null,
    n = a ? U(t.task) : void 0;
  return a && n
    ? e.jsx(
        Ee,
        { info: n, lane: a, onHome: l, signedIn: s },
        `${a.id}:${n.task}:${s}`,
      )
    : e.jsx("section", {
        "aria-labelledby": "btec-options-heading",
        className: "mx-auto w-full max-w-5xl px-4 py-8 sm:px-6 lg:px-8",
        "data-btec-coursework": "",
        children: e.jsxs("div", {
          className: "sm:max-w-2xl",
          children: [
            a
              ? e.jsx(P, { lane: null, onHome: l, task: null })
              : e.jsx(K, { onHome: l }),
            e.jsx("h1", {
              className: "mt-4 text-3xl font-bold text-slate-950 sm:text-5xl",
              id: "btec-options-heading",
              children: a ? a.name : "Coursework",
            }),
            e.jsx("div", {
              className: "mt-6",
              children: a
                ? e.jsx(B, {
                    label: "Component 1",
                    children: G.map((i) =>
                      e.jsx(
                        D,
                        {
                          icon: we[i.task],
                          label: `${i.task} ${i.name}`,
                          onClick: () => g({ lane: a.id, task: i.task }),
                        },
                        i.task,
                      ),
                    ),
                  })
                : e.jsx(B, {
                    label: "Briefs",
                    children: Y.map((i) =>
                      e.jsx(
                        D,
                        {
                          icon: ue,
                          label: i.name,
                          onClick: () => g({ lane: i.id, task: null }),
                        },
                        i.id,
                      ),
                    ),
                  }),
            }),
          ],
        }),
      });
}
export { Ce as default };
