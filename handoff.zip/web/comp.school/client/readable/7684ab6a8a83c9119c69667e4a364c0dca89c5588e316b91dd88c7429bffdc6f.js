(function () {
  const g = document.createElement("link").relList;
  if (g && g.supports && g.supports("modulepreload")) return;
  for (const C of document.querySelectorAll('link[rel="modulepreload"]')) S(C);
  new MutationObserver((C) => {
    for (const _ of C)
      if (_.type === "childList")
        for (const $ of _.addedNodes)
          $.tagName === "LINK" && $.rel === "modulepreload" && S($);
  }).observe(document, { childList: !0, subtree: !0 });
  function c(C) {
    const _ = {};
    return (
      C.integrity && (_.integrity = C.integrity),
      C.referrerPolicy && (_.referrerPolicy = C.referrerPolicy),
      C.crossOrigin === "use-credentials"
        ? (_.credentials = "include")
        : C.crossOrigin === "anonymous"
          ? (_.credentials = "omit")
          : (_.credentials = "same-origin"),
      _
    );
  }
  function S(C) {
    if (C.ep) return;
    C.ep = !0;
    const _ = c(C);
    fetch(C.href, _);
  }
})();
function lc(d) {
  return d && d.__esModule && Object.prototype.hasOwnProperty.call(d, "default")
    ? d.default
    : d;
}
var Oi = { exports: {} },
  Er = {},
  Di = { exports: {} },
  B = {};
/**
 * @license React
 * react.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var Wa;
function sd() {
  if (Wa) return B;
  Wa = 1;
  var d = Symbol.for("react.element"),
    g = Symbol.for("react.portal"),
    c = Symbol.for("react.fragment"),
    S = Symbol.for("react.strict_mode"),
    C = Symbol.for("react.profiler"),
    _ = Symbol.for("react.provider"),
    $ = Symbol.for("react.context"),
    K = Symbol.for("react.forward_ref"),
    R = Symbol.for("react.suspense"),
    re = Symbol.for("react.memo"),
    A = Symbol.for("react.lazy"),
    le = Symbol.iterator;
  function G(p) {
    return p === null || typeof p != "object"
      ? null
      : ((p = (le && p[le]) || p["@@iterator"]),
        typeof p == "function" ? p : null);
  }
  var Me = {
      isMounted: function () {
        return !1;
      },
      enqueueForceUpdate: function () {},
      enqueueReplaceState: function () {},
      enqueueSetState: function () {},
    },
    Pe = Object.assign,
    b = {};
  function V(p, w, H) {
    ((this.props = p),
      (this.context = w),
      (this.refs = b),
      (this.updater = H || Me));
  }
  ((V.prototype.isReactComponent = {}),
    (V.prototype.setState = function (p, w) {
      if (typeof p != "object" && typeof p != "function" && p != null)
        throw Error(
          "setState(...): takes an object of state variables to update or a function which returns an object of state variables.",
        );
      this.updater.enqueueSetState(this, p, w, "setState");
    }),
    (V.prototype.forceUpdate = function (p) {
      this.updater.enqueueForceUpdate(this, p, "forceUpdate");
    }));
  function Ce() {}
  Ce.prototype = V.prototype;
  function $e(p, w, H) {
    ((this.props = p),
      (this.context = w),
      (this.refs = b),
      (this.updater = H || Me));
  }
  var De = ($e.prototype = new Ce());
  ((De.constructor = $e), Pe(De, V.prototype), (De.isPureReactComponent = !0));
  var oe = Array.isArray,
    ce = Object.prototype.hasOwnProperty,
    D = { current: null },
    Y = { key: !0, ref: !0, __self: !0, __source: !0 };
  function Z(p, w, H) {
    var Q,
      ee = {},
      te = null,
      de = null;
    if (w != null)
      for (Q in (w.ref !== void 0 && (de = w.ref),
      w.key !== void 0 && (te = "" + w.key),
      w))
        ce.call(w, Q) && !Y.hasOwnProperty(Q) && (ee[Q] = w[Q]);
    var ie = arguments.length - 2;
    if (ie === 1) ee.children = H;
    else if (1 < ie) {
      for (var ge = Array(ie), tt = 0; tt < ie; tt++)
        ge[tt] = arguments[tt + 2];
      ee.children = ge;
    }
    if (p && p.defaultProps)
      for (Q in ((ie = p.defaultProps), ie))
        ee[Q] === void 0 && (ee[Q] = ie[Q]);
    return {
      $$typeof: d,
      type: p,
      key: te,
      ref: de,
      props: ee,
      _owner: D.current,
    };
  }
  function q(p, w) {
    return {
      $$typeof: d,
      type: p.type,
      key: w,
      ref: p.ref,
      props: p.props,
      _owner: p._owner,
    };
  }
  function xe(p) {
    return typeof p == "object" && p !== null && p.$$typeof === d;
  }
  function it(p) {
    var w = { "=": "=0", ":": "=2" };
    return (
      "$" +
      p.replace(/[=:]/g, function (H) {
        return w[H];
      })
    );
  }
  var He = /\/+/g;
  function Ne(p, w) {
    return typeof p == "object" && p !== null && p.key != null
      ? it("" + p.key)
      : w.toString(36);
  }
  function fe(p, w, H, Q, ee) {
    var te = typeof p;
    (te === "undefined" || te === "boolean") && (p = null);
    var de = !1;
    if (p === null) de = !0;
    else
      switch (te) {
        case "string":
        case "number":
          de = !0;
          break;
        case "object":
          switch (p.$$typeof) {
            case d:
            case g:
              de = !0;
          }
      }
    if (de)
      return (
        (de = p),
        (ee = ee(de)),
        (p = Q === "" ? "." + Ne(de, 0) : Q),
        oe(ee)
          ? ((H = ""),
            p != null && (H = p.replace(He, "$&/") + "/"),
            fe(ee, w, H, "", function (tt) {
              return tt;
            }))
          : ee != null &&
            (xe(ee) &&
              (ee = q(
                ee,
                H +
                  (!ee.key || (de && de.key === ee.key)
                    ? ""
                    : ("" + ee.key).replace(He, "$&/") + "/") +
                  p,
              )),
            w.push(ee)),
        1
      );
    if (((de = 0), (Q = Q === "" ? "." : Q + ":"), oe(p)))
      for (var ie = 0; ie < p.length; ie++) {
        te = p[ie];
        var ge = Q + Ne(te, ie);
        de += fe(te, w, H, ge, ee);
      }
    else if (((ge = G(p)), typeof ge == "function"))
      for (p = ge.call(p), ie = 0; !(te = p.next()).done;)
        ((te = te.value),
          (ge = Q + Ne(te, ie++)),
          (de += fe(te, w, H, ge, ee)));
    else if (te === "object")
      throw (
        (w = String(p)),
        Error(
          "Objects are not valid as a React child (found: " +
            (w === "[object Object]"
              ? "object with keys {" + Object.keys(p).join(", ") + "}"
              : w) +
            "). If you meant to render a collection of children, use an array instead.",
        )
      );
    return de;
  }
  function ye(p, w, H) {
    if (p == null) return p;
    var Q = [],
      ee = 0;
    return (
      fe(p, Q, "", "", function (te) {
        return w.call(H, te, ee++);
      }),
      Q
    );
  }
  function Se(p) {
    if (p._status === -1) {
      var w = p._result;
      ((w = w()),
        w.then(
          function (H) {
            (p._status === 0 || p._status === -1) &&
              ((p._status = 1), (p._result = H));
          },
          function (H) {
            (p._status === 0 || p._status === -1) &&
              ((p._status = 2), (p._result = H));
          },
        ),
        p._status === -1 && ((p._status = 0), (p._result = w)));
    }
    if (p._status === 1) return p._result.default;
    throw p._result;
  }
  var ue = { current: null },
    E = { transition: null },
    U = {
      ReactCurrentDispatcher: ue,
      ReactCurrentBatchConfig: E,
      ReactCurrentOwner: D,
    };
  function L() {
    throw Error("act(...) is not supported in production builds of React.");
  }
  return (
    (B.Children = {
      map: ye,
      forEach: function (p, w, H) {
        ye(
          p,
          function () {
            w.apply(this, arguments);
          },
          H,
        );
      },
      count: function (p) {
        var w = 0;
        return (
          ye(p, function () {
            w++;
          }),
          w
        );
      },
      toArray: function (p) {
        return (
          ye(p, function (w) {
            return w;
          }) || []
        );
      },
      only: function (p) {
        if (!xe(p))
          throw Error(
            "React.Children.only expected to receive a single React element child.",
          );
        return p;
      },
    }),
    (B.Component = V),
    (B.Fragment = c),
    (B.Profiler = C),
    (B.PureComponent = $e),
    (B.StrictMode = S),
    (B.Suspense = R),
    (B.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = U),
    (B.act = L),
    (B.cloneElement = function (p, w, H) {
      if (p == null)
        throw Error(
          "React.cloneElement(...): The argument must be a React element, but you passed " +
            p +
            ".",
        );
      var Q = Pe({}, p.props),
        ee = p.key,
        te = p.ref,
        de = p._owner;
      if (w != null) {
        if (
          (w.ref !== void 0 && ((te = w.ref), (de = D.current)),
          w.key !== void 0 && (ee = "" + w.key),
          p.type && p.type.defaultProps)
        )
          var ie = p.type.defaultProps;
        for (ge in w)
          ce.call(w, ge) &&
            !Y.hasOwnProperty(ge) &&
            (Q[ge] = w[ge] === void 0 && ie !== void 0 ? ie[ge] : w[ge]);
      }
      var ge = arguments.length - 2;
      if (ge === 1) Q.children = H;
      else if (1 < ge) {
        ie = Array(ge);
        for (var tt = 0; tt < ge; tt++) ie[tt] = arguments[tt + 2];
        Q.children = ie;
      }
      return {
        $$typeof: d,
        type: p.type,
        key: ee,
        ref: te,
        props: Q,
        _owner: de,
      };
    }),
    (B.createContext = function (p) {
      return (
        (p = {
          $$typeof: $,
          _currentValue: p,
          _currentValue2: p,
          _threadCount: 0,
          Provider: null,
          Consumer: null,
          _defaultValue: null,
          _globalName: null,
        }),
        (p.Provider = { $$typeof: _, _context: p }),
        (p.Consumer = p)
      );
    }),
    (B.createElement = Z),
    (B.createFactory = function (p) {
      var w = Z.bind(null, p);
      return ((w.type = p), w);
    }),
    (B.createRef = function () {
      return { current: null };
    }),
    (B.forwardRef = function (p) {
      return { $$typeof: K, render: p };
    }),
    (B.isValidElement = xe),
    (B.lazy = function (p) {
      return { $$typeof: A, _payload: { _status: -1, _result: p }, _init: Se };
    }),
    (B.memo = function (p, w) {
      return { $$typeof: re, type: p, compare: w === void 0 ? null : w };
    }),
    (B.startTransition = function (p) {
      var w = E.transition;
      E.transition = {};
      try {
        p();
      } finally {
        E.transition = w;
      }
    }),
    (B.unstable_act = L),
    (B.useCallback = function (p, w) {
      return ue.current.useCallback(p, w);
    }),
    (B.useContext = function (p) {
      return ue.current.useContext(p);
    }),
    (B.useDebugValue = function () {}),
    (B.useDeferredValue = function (p) {
      return ue.current.useDeferredValue(p);
    }),
    (B.useEffect = function (p, w) {
      return ue.current.useEffect(p, w);
    }),
    (B.useId = function () {
      return ue.current.useId();
    }),
    (B.useImperativeHandle = function (p, w, H) {
      return ue.current.useImperativeHandle(p, w, H);
    }),
    (B.useInsertionEffect = function (p, w) {
      return ue.current.useInsertionEffect(p, w);
    }),
    (B.useLayoutEffect = function (p, w) {
      return ue.current.useLayoutEffect(p, w);
    }),
    (B.useMemo = function (p, w) {
      return ue.current.useMemo(p, w);
    }),
    (B.useReducer = function (p, w, H) {
      return ue.current.useReducer(p, w, H);
    }),
    (B.useRef = function (p) {
      return ue.current.useRef(p);
    }),
    (B.useState = function (p) {
      return ue.current.useState(p);
    }),
    (B.useSyncExternalStore = function (p, w, H) {
      return ue.current.useSyncExternalStore(p, w, H);
    }),
    (B.useTransition = function () {
      return ue.current.useTransition();
    }),
    (B.version = "18.3.1"),
    B
  );
}
var $a;
function Hi() {
  return ($a || (($a = 1), (Di.exports = sd())), Di.exports);
}
/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var Ha;
function ud() {
  if (Ha) return Er;
  Ha = 1;
  var d = Hi(),
    g = Symbol.for("react.element"),
    c = Symbol.for("react.fragment"),
    S = Object.prototype.hasOwnProperty,
    C = d.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,
    _ = { key: !0, ref: !0, __self: !0, __source: !0 };
  function $(K, R, re) {
    var A,
      le = {},
      G = null,
      Me = null;
    (re !== void 0 && (G = "" + re),
      R.key !== void 0 && (G = "" + R.key),
      R.ref !== void 0 && (Me = R.ref));
    for (A in R) S.call(R, A) && !_.hasOwnProperty(A) && (le[A] = R[A]);
    if (K && K.defaultProps)
      for (A in ((R = K.defaultProps), R)) le[A] === void 0 && (le[A] = R[A]);
    return {
      $$typeof: g,
      type: K,
      key: G,
      ref: Me,
      props: le,
      _owner: C.current,
    };
  }
  return ((Er.Fragment = c), (Er.jsx = $), (Er.jsxs = $), Er);
}
var Ba;
function ad() {
  return (Ba || ((Ba = 1), (Oi.exports = ud())), Oi.exports);
}
var i = ad(),
  ae = Hi();
const cd = lc(ae);
var Fl = {},
  Ii = { exports: {} },
  et = {},
  Fi = { exports: {} },
  Ui = {};
/**
 * @license React
 * scheduler.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var Va;
function fd() {
  return (
    Va ||
      ((Va = 1),
      (function (d) {
        function g(E, U) {
          var L = E.length;
          E.push(U);
          e: for (; 0 < L;) {
            var p = (L - 1) >>> 1,
              w = E[p];
            if (0 < C(w, U)) ((E[p] = U), (E[L] = w), (L = p));
            else break e;
          }
        }
        function c(E) {
          return E.length === 0 ? null : E[0];
        }
        function S(E) {
          if (E.length === 0) return null;
          var U = E[0],
            L = E.pop();
          if (L !== U) {
            E[0] = L;
            e: for (var p = 0, w = E.length, H = w >>> 1; p < H;) {
              var Q = 2 * (p + 1) - 1,
                ee = E[Q],
                te = Q + 1,
                de = E[te];
              if (0 > C(ee, L))
                te < w && 0 > C(de, ee)
                  ? ((E[p] = de), (E[te] = L), (p = te))
                  : ((E[p] = ee), (E[Q] = L), (p = Q));
              else if (te < w && 0 > C(de, L))
                ((E[p] = de), (E[te] = L), (p = te));
              else break e;
            }
          }
          return U;
        }
        function C(E, U) {
          var L = E.sortIndex - U.sortIndex;
          return L !== 0 ? L : E.id - U.id;
        }
        if (
          typeof performance == "object" &&
          typeof performance.now == "function"
        ) {
          var _ = performance;
          d.unstable_now = function () {
            return _.now();
          };
        } else {
          var $ = Date,
            K = $.now();
          d.unstable_now = function () {
            return $.now() - K;
          };
        }
        var R = [],
          re = [],
          A = 1,
          le = null,
          G = 3,
          Me = !1,
          Pe = !1,
          b = !1,
          V = typeof setTimeout == "function" ? setTimeout : null,
          Ce = typeof clearTimeout == "function" ? clearTimeout : null,
          $e = typeof setImmediate < "u" ? setImmediate : null;
        typeof navigator < "u" &&
          navigator.scheduling !== void 0 &&
          navigator.scheduling.isInputPending !== void 0 &&
          navigator.scheduling.isInputPending.bind(navigator.scheduling);
        function De(E) {
          for (var U = c(re); U !== null;) {
            if (U.callback === null) S(re);
            else if (U.startTime <= E)
              (S(re), (U.sortIndex = U.expirationTime), g(R, U));
            else break;
            U = c(re);
          }
        }
        function oe(E) {
          if (((b = !1), De(E), !Pe))
            if (c(R) !== null) ((Pe = !0), Se(ce));
            else {
              var U = c(re);
              U !== null && ue(oe, U.startTime - E);
            }
        }
        function ce(E, U) {
          ((Pe = !1), b && ((b = !1), Ce(Z), (Z = -1)), (Me = !0));
          var L = G;
          try {
            for (
              De(U), le = c(R);
              le !== null && (!(le.expirationTime > U) || (E && !it()));
            ) {
              var p = le.callback;
              if (typeof p == "function") {
                ((le.callback = null), (G = le.priorityLevel));
                var w = p(le.expirationTime <= U);
                ((U = d.unstable_now()),
                  typeof w == "function"
                    ? (le.callback = w)
                    : le === c(R) && S(R),
                  De(U));
              } else S(R);
              le = c(R);
            }
            if (le !== null) var H = !0;
            else {
              var Q = c(re);
              (Q !== null && ue(oe, Q.startTime - U), (H = !1));
            }
            return H;
          } finally {
            ((le = null), (G = L), (Me = !1));
          }
        }
        var D = !1,
          Y = null,
          Z = -1,
          q = 5,
          xe = -1;
        function it() {
          return !(d.unstable_now() - xe < q);
        }
        function He() {
          if (Y !== null) {
            var E = d.unstable_now();
            xe = E;
            var U = !0;
            try {
              U = Y(!0, E);
            } finally {
              U ? Ne() : ((D = !1), (Y = null));
            }
          } else D = !1;
        }
        var Ne;
        if (typeof $e == "function")
          Ne = function () {
            $e(He);
          };
        else if (typeof MessageChannel < "u") {
          var fe = new MessageChannel(),
            ye = fe.port2;
          ((fe.port1.onmessage = He),
            (Ne = function () {
              ye.postMessage(null);
            }));
        } else
          Ne = function () {
            V(He, 0);
          };
        function Se(E) {
          ((Y = E), D || ((D = !0), Ne()));
        }
        function ue(E, U) {
          Z = V(function () {
            E(d.unstable_now());
          }, U);
        }
        ((d.unstable_IdlePriority = 5),
          (d.unstable_ImmediatePriority = 1),
          (d.unstable_LowPriority = 4),
          (d.unstable_NormalPriority = 3),
          (d.unstable_Profiling = null),
          (d.unstable_UserBlockingPriority = 2),
          (d.unstable_cancelCallback = function (E) {
            E.callback = null;
          }),
          (d.unstable_continueExecution = function () {
            Pe || Me || ((Pe = !0), Se(ce));
          }),
          (d.unstable_forceFrameRate = function (E) {
            0 > E || 125 < E
              ? console.error(
                  "forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported",
                )
              : (q = 0 < E ? Math.floor(1e3 / E) : 5);
          }),
          (d.unstable_getCurrentPriorityLevel = function () {
            return G;
          }),
          (d.unstable_getFirstCallbackNode = function () {
            return c(R);
          }),
          (d.unstable_next = function (E) {
            switch (G) {
              case 1:
              case 2:
              case 3:
                var U = 3;
                break;
              default:
                U = G;
            }
            var L = G;
            G = U;
            try {
              return E();
            } finally {
              G = L;
            }
          }),
          (d.unstable_pauseExecution = function () {}),
          (d.unstable_requestPaint = function () {}),
          (d.unstable_runWithPriority = function (E, U) {
            switch (E) {
              case 1:
              case 2:
              case 3:
              case 4:
              case 5:
                break;
              default:
                E = 3;
            }
            var L = G;
            G = E;
            try {
              return U();
            } finally {
              G = L;
            }
          }),
          (d.unstable_scheduleCallback = function (E, U, L) {
            var p = d.unstable_now();
            switch (
              (typeof L == "object" && L !== null
                ? ((L = L.delay),
                  (L = typeof L == "number" && 0 < L ? p + L : p))
                : (L = p),
              E)
            ) {
              case 1:
                var w = -1;
                break;
              case 2:
                w = 250;
                break;
              case 5:
                w = 1073741823;
                break;
              case 4:
                w = 1e4;
                break;
              default:
                w = 5e3;
            }
            return (
              (w = L + w),
              (E = {
                id: A++,
                callback: U,
                priorityLevel: E,
                startTime: L,
                expirationTime: w,
                sortIndex: -1,
              }),
              L > p
                ? ((E.sortIndex = L),
                  g(re, E),
                  c(R) === null &&
                    E === c(re) &&
                    (b ? (Ce(Z), (Z = -1)) : (b = !0), ue(oe, L - p)))
                : ((E.sortIndex = w), g(R, E), Pe || Me || ((Pe = !0), Se(ce))),
              E
            );
          }),
          (d.unstable_shouldYield = it),
          (d.unstable_wrapCallback = function (E) {
            var U = G;
            return function () {
              var L = G;
              G = U;
              try {
                return E.apply(this, arguments);
              } finally {
                G = L;
              }
            };
          }));
      })(Ui)),
    Ui
  );
}
var Qa;
function dd() {
  return (Qa || ((Qa = 1), (Fi.exports = fd())), Fi.exports);
}
/**
 * @license React
 * react-dom.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var Za;
function pd() {
  if (Za) return et;
  Za = 1;
  var d = Hi(),
    g = dd();
  function c(e) {
    for (
      var t = "https://reactjs.org/docs/error-decoder.html?invariant=" + e,
        n = 1;
      n < arguments.length;
      n++
    )
      t += "&args[]=" + encodeURIComponent(arguments[n]);
    return (
      "Minified React error #" +
      e +
      "; visit " +
      t +
      " for the full message or use the non-minified dev environment for full errors and additional helpful warnings."
    );
  }
  var S = new Set(),
    C = {};
  function _(e, t) {
    ($(e, t), $(e + "Capture", t));
  }
  function $(e, t) {
    for (C[e] = t, e = 0; e < t.length; e++) S.add(t[e]);
  }
  var K = !(
      typeof window > "u" ||
      typeof window.document > "u" ||
      typeof window.document.createElement > "u"
    ),
    R = Object.prototype.hasOwnProperty,
    re =
      /^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/,
    A = {},
    le = {};
  function G(e) {
    return R.call(le, e)
      ? !0
      : R.call(A, e)
        ? !1
        : re.test(e)
          ? (le[e] = !0)
          : ((A[e] = !0), !1);
  }
  function Me(e, t, n, r) {
    if (n !== null && n.type === 0) return !1;
    switch (typeof t) {
      case "function":
      case "symbol":
        return !0;
      case "boolean":
        return r
          ? !1
          : n !== null
            ? !n.acceptsBooleans
            : ((e = e.toLowerCase().slice(0, 5)),
              e !== "data-" && e !== "aria-");
      default:
        return !1;
    }
  }
  function Pe(e, t, n, r) {
    if (t === null || typeof t > "u" || Me(e, t, n, r)) return !0;
    if (r) return !1;
    if (n !== null)
      switch (n.type) {
        case 3:
          return !t;
        case 4:
          return t === !1;
        case 5:
          return isNaN(t);
        case 6:
          return isNaN(t) || 1 > t;
      }
    return !1;
  }
  function b(e, t, n, r, l, o, s) {
    ((this.acceptsBooleans = t === 2 || t === 3 || t === 4),
      (this.attributeName = r),
      (this.attributeNamespace = l),
      (this.mustUseProperty = n),
      (this.propertyName = e),
      (this.type = t),
      (this.sanitizeURL = o),
      (this.removeEmptyString = s));
  }
  var V = {};
  ("children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style"
    .split(" ")
    .forEach(function (e) {
      V[e] = new b(e, 0, !1, e, null, !1, !1);
    }),
    [
      ["acceptCharset", "accept-charset"],
      ["className", "class"],
      ["htmlFor", "for"],
      ["httpEquiv", "http-equiv"],
    ].forEach(function (e) {
      var t = e[0];
      V[t] = new b(t, 1, !1, e[1], null, !1, !1);
    }),
    ["contentEditable", "draggable", "spellCheck", "value"].forEach(
      function (e) {
        V[e] = new b(e, 2, !1, e.toLowerCase(), null, !1, !1);
      },
    ),
    [
      "autoReverse",
      "externalResourcesRequired",
      "focusable",
      "preserveAlpha",
    ].forEach(function (e) {
      V[e] = new b(e, 2, !1, e, null, !1, !1);
    }),
    "allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope"
      .split(" ")
      .forEach(function (e) {
        V[e] = new b(e, 3, !1, e.toLowerCase(), null, !1, !1);
      }),
    ["checked", "multiple", "muted", "selected"].forEach(function (e) {
      V[e] = new b(e, 3, !0, e, null, !1, !1);
    }),
    ["capture", "download"].forEach(function (e) {
      V[e] = new b(e, 4, !1, e, null, !1, !1);
    }),
    ["cols", "rows", "size", "span"].forEach(function (e) {
      V[e] = new b(e, 6, !1, e, null, !1, !1);
    }),
    ["rowSpan", "start"].forEach(function (e) {
      V[e] = new b(e, 5, !1, e.toLowerCase(), null, !1, !1);
    }));
  var Ce = /[\-:]([a-z])/g;
  function $e(e) {
    return e[1].toUpperCase();
  }
  ("accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height"
    .split(" ")
    .forEach(function (e) {
      var t = e.replace(Ce, $e);
      V[t] = new b(t, 1, !1, e, null, !1, !1);
    }),
    "xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type"
      .split(" ")
      .forEach(function (e) {
        var t = e.replace(Ce, $e);
        V[t] = new b(t, 1, !1, e, "http://www.w3.org/1999/xlink", !1, !1);
      }),
    ["xml:base", "xml:lang", "xml:space"].forEach(function (e) {
      var t = e.replace(Ce, $e);
      V[t] = new b(t, 1, !1, e, "http://www.w3.org/XML/1998/namespace", !1, !1);
    }),
    ["tabIndex", "crossOrigin"].forEach(function (e) {
      V[e] = new b(e, 1, !1, e.toLowerCase(), null, !1, !1);
    }),
    (V.xlinkHref = new b(
      "xlinkHref",
      1,
      !1,
      "xlink:href",
      "http://www.w3.org/1999/xlink",
      !0,
      !1,
    )),
    ["src", "href", "action", "formAction"].forEach(function (e) {
      V[e] = new b(e, 1, !1, e.toLowerCase(), null, !0, !0);
    }));
  function De(e, t, n, r) {
    var l = V.hasOwnProperty(t) ? V[t] : null;
    (l !== null
      ? l.type !== 0
      : r ||
        !(2 < t.length) ||
        (t[0] !== "o" && t[0] !== "O") ||
        (t[1] !== "n" && t[1] !== "N")) &&
      (Pe(t, n, l, r) && (n = null),
      r || l === null
        ? G(t) &&
          (n === null ? e.removeAttribute(t) : e.setAttribute(t, "" + n))
        : l.mustUseProperty
          ? (e[l.propertyName] = n === null ? (l.type === 3 ? !1 : "") : n)
          : ((t = l.attributeName),
            (r = l.attributeNamespace),
            n === null
              ? e.removeAttribute(t)
              : ((l = l.type),
                (n = l === 3 || (l === 4 && n === !0) ? "" : "" + n),
                r ? e.setAttributeNS(r, t, n) : e.setAttribute(t, n))));
  }
  var oe = d.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED,
    ce = Symbol.for("react.element"),
    D = Symbol.for("react.portal"),
    Y = Symbol.for("react.fragment"),
    Z = Symbol.for("react.strict_mode"),
    q = Symbol.for("react.profiler"),
    xe = Symbol.for("react.provider"),
    it = Symbol.for("react.context"),
    He = Symbol.for("react.forward_ref"),
    Ne = Symbol.for("react.suspense"),
    fe = Symbol.for("react.suspense_list"),
    ye = Symbol.for("react.memo"),
    Se = Symbol.for("react.lazy"),
    ue = Symbol.for("react.offscreen"),
    E = Symbol.iterator;
  function U(e) {
    return e === null || typeof e != "object"
      ? null
      : ((e = (E && e[E]) || e["@@iterator"]),
        typeof e == "function" ? e : null);
  }
  var L = Object.assign,
    p;
  function w(e) {
    if (p === void 0)
      try {
        throw Error();
      } catch (n) {
        var t = n.stack.trim().match(/\n( *(at )?)/);
        p = (t && t[1]) || "";
      }
    return (
      `
` +
      p +
      e
    );
  }
  var H = !1;
  function Q(e, t) {
    if (!e || H) return "";
    H = !0;
    var n = Error.prepareStackTrace;
    Error.prepareStackTrace = void 0;
    try {
      if (t)
        if (
          ((t = function () {
            throw Error();
          }),
          Object.defineProperty(t.prototype, "props", {
            set: function () {
              throw Error();
            },
          }),
          typeof Reflect == "object" && Reflect.construct)
        ) {
          try {
            Reflect.construct(t, []);
          } catch (y) {
            var r = y;
          }
          Reflect.construct(e, [], t);
        } else {
          try {
            t.call();
          } catch (y) {
            r = y;
          }
          e.call(t.prototype);
        }
      else {
        try {
          throw Error();
        } catch (y) {
          r = y;
        }
        e();
      }
    } catch (y) {
      if (y && r && typeof y.stack == "string") {
        for (
          var l = y.stack.split(`
`),
            o = r.stack.split(`
`),
            s = l.length - 1,
            u = o.length - 1;
          1 <= s && 0 <= u && l[s] !== o[u];
        )
          u--;
        for (; 1 <= s && 0 <= u; s--, u--)
          if (l[s] !== o[u]) {
            if (s !== 1 || u !== 1)
              do
                if ((s--, u--, 0 > u || l[s] !== o[u])) {
                  var a =
                    `
` + l[s].replace(" at new ", " at ");
                  return (
                    e.displayName &&
                      a.includes("<anonymous>") &&
                      (a = a.replace("<anonymous>", e.displayName)),
                    a
                  );
                }
              while (1 <= s && 0 <= u);
            break;
          }
      }
    } finally {
      ((H = !1), (Error.prepareStackTrace = n));
    }
    return (e = e ? e.displayName || e.name : "") ? w(e) : "";
  }
  function ee(e) {
    switch (e.tag) {
      case 5:
        return w(e.type);
      case 16:
        return w("Lazy");
      case 13:
        return w("Suspense");
      case 19:
        return w("SuspenseList");
      case 0:
      case 2:
      case 15:
        return ((e = Q(e.type, !1)), e);
      case 11:
        return ((e = Q(e.type.render, !1)), e);
      case 1:
        return ((e = Q(e.type, !0)), e);
      default:
        return "";
    }
  }
  function te(e) {
    if (e == null) return null;
    if (typeof e == "function") return e.displayName || e.name || null;
    if (typeof e == "string") return e;
    switch (e) {
      case Y:
        return "Fragment";
      case D:
        return "Portal";
      case q:
        return "Profiler";
      case Z:
        return "StrictMode";
      case Ne:
        return "Suspense";
      case fe:
        return "SuspenseList";
    }
    if (typeof e == "object")
      switch (e.$$typeof) {
        case it:
          return (e.displayName || "Context") + ".Consumer";
        case xe:
          return (e._context.displayName || "Context") + ".Provider";
        case He:
          var t = e.render;
          return (
            (e = e.displayName),
            e ||
              ((e = t.displayName || t.name || ""),
              (e = e !== "" ? "ForwardRef(" + e + ")" : "ForwardRef")),
            e
          );
        case ye:
          return (
            (t = e.displayName || null),
            t !== null ? t : te(e.type) || "Memo"
          );
        case Se:
          ((t = e._payload), (e = e._init));
          try {
            return te(e(t));
          } catch {}
      }
    return null;
  }
  function de(e) {
    var t = e.type;
    switch (e.tag) {
      case 24:
        return "Cache";
      case 9:
        return (t.displayName || "Context") + ".Consumer";
      case 10:
        return (t._context.displayName || "Context") + ".Provider";
      case 18:
        return "DehydratedFragment";
      case 11:
        return (
          (e = t.render),
          (e = e.displayName || e.name || ""),
          t.displayName || (e !== "" ? "ForwardRef(" + e + ")" : "ForwardRef")
        );
      case 7:
        return "Fragment";
      case 5:
        return t;
      case 4:
        return "Portal";
      case 3:
        return "Root";
      case 6:
        return "Text";
      case 16:
        return te(t);
      case 8:
        return t === Z ? "StrictMode" : "Mode";
      case 22:
        return "Offscreen";
      case 12:
        return "Profiler";
      case 21:
        return "Scope";
      case 13:
        return "Suspense";
      case 19:
        return "SuspenseList";
      case 25:
        return "TracingMarker";
      case 1:
      case 0:
      case 17:
      case 2:
      case 14:
      case 15:
        if (typeof t == "function") return t.displayName || t.name || null;
        if (typeof t == "string") return t;
    }
    return null;
  }
  function ie(e) {
    switch (typeof e) {
      case "boolean":
      case "number":
      case "string":
      case "undefined":
        return e;
      case "object":
        return e;
      default:
        return "";
    }
  }
  function ge(e) {
    var t = e.type;
    return (
      (e = e.nodeName) &&
      e.toLowerCase() === "input" &&
      (t === "checkbox" || t === "radio")
    );
  }
  function tt(e) {
    var t = ge(e) ? "checked" : "value",
      n = Object.getOwnPropertyDescriptor(e.constructor.prototype, t),
      r = "" + e[t];
    if (
      !e.hasOwnProperty(t) &&
      typeof n < "u" &&
      typeof n.get == "function" &&
      typeof n.set == "function"
    ) {
      var l = n.get,
        o = n.set;
      return (
        Object.defineProperty(e, t, {
          configurable: !0,
          get: function () {
            return l.call(this);
          },
          set: function (s) {
            ((r = "" + s), o.call(this, s));
          },
        }),
        Object.defineProperty(e, t, { enumerable: n.enumerable }),
        {
          getValue: function () {
            return r;
          },
          setValue: function (s) {
            r = "" + s;
          },
          stopTracking: function () {
            ((e._valueTracker = null), delete e[t]);
          },
        }
      );
    }
  }
  function _r(e) {
    e._valueTracker || (e._valueTracker = tt(e));
  }
  function Zi(e) {
    if (!e) return !1;
    var t = e._valueTracker;
    if (!t) return !0;
    var n = t.getValue(),
      r = "";
    return (
      e && (r = ge(e) ? (e.checked ? "true" : "false") : e.value),
      (e = r),
      e !== n ? (t.setValue(e), !0) : !1
    );
  }
  function Mr(e) {
    if (
      ((e = e || (typeof document < "u" ? document : void 0)), typeof e > "u")
    )
      return null;
    try {
      return e.activeElement || e.body;
    } catch {
      return e.body;
    }
  }
  function Wl(e, t) {
    var n = t.checked;
    return L({}, t, {
      defaultChecked: void 0,
      defaultValue: void 0,
      value: void 0,
      checked: n ?? e._wrapperState.initialChecked,
    });
  }
  function Ki(e, t) {
    var n = t.defaultValue == null ? "" : t.defaultValue,
      r = t.checked != null ? t.checked : t.defaultChecked;
    ((n = ie(t.value != null ? t.value : n)),
      (e._wrapperState = {
        initialChecked: r,
        initialValue: n,
        controlled:
          t.type === "checkbox" || t.type === "radio"
            ? t.checked != null
            : t.value != null,
      }));
  }
  function Gi(e, t) {
    ((t = t.checked), t != null && De(e, "checked", t, !1));
  }
  function $l(e, t) {
    Gi(e, t);
    var n = ie(t.value),
      r = t.type;
    if (n != null)
      r === "number"
        ? ((n === 0 && e.value === "") || e.value != n) && (e.value = "" + n)
        : e.value !== "" + n && (e.value = "" + n);
    else if (r === "submit" || r === "reset") {
      e.removeAttribute("value");
      return;
    }
    (t.hasOwnProperty("value")
      ? Hl(e, t.type, n)
      : t.hasOwnProperty("defaultValue") && Hl(e, t.type, ie(t.defaultValue)),
      t.checked == null &&
        t.defaultChecked != null &&
        (e.defaultChecked = !!t.defaultChecked));
  }
  function Yi(e, t, n) {
    if (t.hasOwnProperty("value") || t.hasOwnProperty("defaultValue")) {
      var r = t.type;
      if (!(
        (r !== "submit" && r !== "reset") ||
        (t.value !== void 0 && t.value !== null)
      ))
        return;
      ((t = "" + e._wrapperState.initialValue),
        n || t === e.value || (e.value = t),
        (e.defaultValue = t));
    }
    ((n = e.name),
      n !== "" && (e.name = ""),
      (e.defaultChecked = !!e._wrapperState.initialChecked),
      n !== "" && (e.name = n));
  }
  function Hl(e, t, n) {
    (t !== "number" || Mr(e.ownerDocument) !== e) &&
      (n == null
        ? (e.defaultValue = "" + e._wrapperState.initialValue)
        : e.defaultValue !== "" + n && (e.defaultValue = "" + n));
  }
  var $n = Array.isArray;
  function yn(e, t, n, r) {
    if (((e = e.options), t)) {
      t = {};
      for (var l = 0; l < n.length; l++) t["$" + n[l]] = !0;
      for (n = 0; n < e.length; n++)
        ((l = t.hasOwnProperty("$" + e[n].value)),
          e[n].selected !== l && (e[n].selected = l),
          l && r && (e[n].defaultSelected = !0));
    } else {
      for (n = "" + ie(n), t = null, l = 0; l < e.length; l++) {
        if (e[l].value === n) {
          ((e[l].selected = !0), r && (e[l].defaultSelected = !0));
          return;
        }
        t !== null || e[l].disabled || (t = e[l]);
      }
      t !== null && (t.selected = !0);
    }
  }
  function Bl(e, t) {
    if (t.dangerouslySetInnerHTML != null) throw Error(c(91));
    return L({}, t, {
      value: void 0,
      defaultValue: void 0,
      children: "" + e._wrapperState.initialValue,
    });
  }
  function Xi(e, t) {
    var n = t.value;
    if (n == null) {
      if (((n = t.children), (t = t.defaultValue), n != null)) {
        if (t != null) throw Error(c(92));
        if ($n(n)) {
          if (1 < n.length) throw Error(c(93));
          n = n[0];
        }
        t = n;
      }
      (t == null && (t = ""), (n = t));
    }
    e._wrapperState = { initialValue: ie(n) };
  }
  function qi(e, t) {
    var n = ie(t.value),
      r = ie(t.defaultValue);
    (n != null &&
      ((n = "" + n),
      n !== e.value && (e.value = n),
      t.defaultValue == null && e.defaultValue !== n && (e.defaultValue = n)),
      r != null && (e.defaultValue = "" + r));
  }
  function Ji(e) {
    var t = e.textContent;
    t === e._wrapperState.initialValue &&
      t !== "" &&
      t !== null &&
      (e.value = t);
  }
  function bi(e) {
    switch (e) {
      case "svg":
        return "http://www.w3.org/2000/svg";
      case "math":
        return "http://www.w3.org/1998/Math/MathML";
      default:
        return "http://www.w3.org/1999/xhtml";
    }
  }
  function Vl(e, t) {
    return e == null || e === "http://www.w3.org/1999/xhtml"
      ? bi(t)
      : e === "http://www.w3.org/2000/svg" && t === "foreignObject"
        ? "http://www.w3.org/1999/xhtml"
        : e;
  }
  var Pr,
    es = (function (e) {
      return typeof MSApp < "u" && MSApp.execUnsafeLocalFunction
        ? function (t, n, r, l) {
            MSApp.execUnsafeLocalFunction(function () {
              return e(t, n, r, l);
            });
          }
        : e;
    })(function (e, t) {
      if (e.namespaceURI !== "http://www.w3.org/2000/svg" || "innerHTML" in e)
        e.innerHTML = t;
      else {
        for (
          Pr = Pr || document.createElement("div"),
            Pr.innerHTML = "<svg>" + t.valueOf().toString() + "</svg>",
            t = Pr.firstChild;
          e.firstChild;
        )
          e.removeChild(e.firstChild);
        for (; t.firstChild;) e.appendChild(t.firstChild);
      }
    });
  function Hn(e, t) {
    if (t) {
      var n = e.firstChild;
      if (n && n === e.lastChild && n.nodeType === 3) {
        n.nodeValue = t;
        return;
      }
    }
    e.textContent = t;
  }
  var Bn = {
      animationIterationCount: !0,
      aspectRatio: !0,
      borderImageOutset: !0,
      borderImageSlice: !0,
      borderImageWidth: !0,
      boxFlex: !0,
      boxFlexGroup: !0,
      boxOrdinalGroup: !0,
      columnCount: !0,
      columns: !0,
      flex: !0,
      flexGrow: !0,
      flexPositive: !0,
      flexShrink: !0,
      flexNegative: !0,
      flexOrder: !0,
      gridArea: !0,
      gridRow: !0,
      gridRowEnd: !0,
      gridRowSpan: !0,
      gridRowStart: !0,
      gridColumn: !0,
      gridColumnEnd: !0,
      gridColumnSpan: !0,
      gridColumnStart: !0,
      fontWeight: !0,
      lineClamp: !0,
      lineHeight: !0,
      opacity: !0,
      order: !0,
      orphans: !0,
      tabSize: !0,
      widows: !0,
      zIndex: !0,
      zoom: !0,
      fillOpacity: !0,
      floodOpacity: !0,
      stopOpacity: !0,
      strokeDasharray: !0,
      strokeDashoffset: !0,
      strokeMiterlimit: !0,
      strokeOpacity: !0,
      strokeWidth: !0,
    },
    cc = ["Webkit", "ms", "Moz", "O"];
  Object.keys(Bn).forEach(function (e) {
    cc.forEach(function (t) {
      ((t = t + e.charAt(0).toUpperCase() + e.substring(1)), (Bn[t] = Bn[e]));
    });
  });
  function ts(e, t, n) {
    return t == null || typeof t == "boolean" || t === ""
      ? ""
      : n || typeof t != "number" || t === 0 || (Bn.hasOwnProperty(e) && Bn[e])
        ? ("" + t).trim()
        : t + "px";
  }
  function ns(e, t) {
    e = e.style;
    for (var n in t)
      if (t.hasOwnProperty(n)) {
        var r = n.indexOf("--") === 0,
          l = ts(n, t[n], r);
        (n === "float" && (n = "cssFloat"),
          r ? e.setProperty(n, l) : (e[n] = l));
      }
  }
  var fc = L(
    { menuitem: !0 },
    {
      area: !0,
      base: !0,
      br: !0,
      col: !0,
      embed: !0,
      hr: !0,
      img: !0,
      input: !0,
      keygen: !0,
      link: !0,
      meta: !0,
      param: !0,
      source: !0,
      track: !0,
      wbr: !0,
    },
  );
  function Ql(e, t) {
    if (t) {
      if (fc[e] && (t.children != null || t.dangerouslySetInnerHTML != null))
        throw Error(c(137, e));
      if (t.dangerouslySetInnerHTML != null) {
        if (t.children != null) throw Error(c(60));
        if (
          typeof t.dangerouslySetInnerHTML != "object" ||
          !("__html" in t.dangerouslySetInnerHTML)
        )
          throw Error(c(61));
      }
      if (t.style != null && typeof t.style != "object") throw Error(c(62));
    }
  }
  function Zl(e, t) {
    if (e.indexOf("-") === -1) return typeof t.is == "string";
    switch (e) {
      case "annotation-xml":
      case "color-profile":
      case "font-face":
      case "font-face-src":
      case "font-face-uri":
      case "font-face-format":
      case "font-face-name":
      case "missing-glyph":
        return !1;
      default:
        return !0;
    }
  }
  var Kl = null;
  function Gl(e) {
    return (
      (e = e.target || e.srcElement || window),
      e.correspondingUseElement && (e = e.correspondingUseElement),
      e.nodeType === 3 ? e.parentNode : e
    );
  }
  var Yl = null,
    gn = null,
    vn = null;
  function rs(e) {
    if ((e = fr(e))) {
      if (typeof Yl != "function") throw Error(c(280));
      var t = e.stateNode;
      t && ((t = Jr(t)), Yl(e.stateNode, e.type, t));
    }
  }
  function ls(e) {
    gn ? (vn ? vn.push(e) : (vn = [e])) : (gn = e);
  }
  function os() {
    if (gn) {
      var e = gn,
        t = vn;
      if (((vn = gn = null), rs(e), t)) for (e = 0; e < t.length; e++) rs(t[e]);
    }
  }
  function is(e, t) {
    return e(t);
  }
  function ss() {}
  var Xl = !1;
  function us(e, t, n) {
    if (Xl) return e(t, n);
    Xl = !0;
    try {
      return is(e, t, n);
    } finally {
      ((Xl = !1), (gn !== null || vn !== null) && (ss(), os()));
    }
  }
  function Vn(e, t) {
    var n = e.stateNode;
    if (n === null) return null;
    var r = Jr(n);
    if (r === null) return null;
    n = r[t];
    e: switch (t) {
      case "onClick":
      case "onClickCapture":
      case "onDoubleClick":
      case "onDoubleClickCapture":
      case "onMouseDown":
      case "onMouseDownCapture":
      case "onMouseMove":
      case "onMouseMoveCapture":
      case "onMouseUp":
      case "onMouseUpCapture":
      case "onMouseEnter":
        ((r = !r.disabled) ||
          ((e = e.type),
          (r = !(
            e === "button" ||
            e === "input" ||
            e === "select" ||
            e === "textarea"
          ))),
          (e = !r));
        break e;
      default:
        e = !1;
    }
    if (e) return null;
    if (n && typeof n != "function") throw Error(c(231, t, typeof n));
    return n;
  }
  var ql = !1;
  if (K)
    try {
      var Qn = {};
      (Object.defineProperty(Qn, "passive", {
        get: function () {
          ql = !0;
        },
      }),
        window.addEventListener("test", Qn, Qn),
        window.removeEventListener("test", Qn, Qn));
    } catch {
      ql = !1;
    }
  function dc(e, t, n, r, l, o, s, u, a) {
    var y = Array.prototype.slice.call(arguments, 3);
    try {
      t.apply(n, y);
    } catch (k) {
      this.onError(k);
    }
  }
  var Zn = !1,
    Lr = null,
    Nr = !1,
    Jl = null,
    pc = {
      onError: function (e) {
        ((Zn = !0), (Lr = e));
      },
    };
  function hc(e, t, n, r, l, o, s, u, a) {
    ((Zn = !1), (Lr = null), dc.apply(pc, arguments));
  }
  function mc(e, t, n, r, l, o, s, u, a) {
    if ((hc.apply(this, arguments), Zn)) {
      if (Zn) {
        var y = Lr;
        ((Zn = !1), (Lr = null));
      } else throw Error(c(198));
      Nr || ((Nr = !0), (Jl = y));
    }
  }
  function nn(e) {
    var t = e,
      n = e;
    if (e.alternate) for (; t.return;) t = t.return;
    else {
      e = t;
      do ((t = e), (t.flags & 4098) !== 0 && (n = t.return), (e = t.return));
      while (e);
    }
    return t.tag === 3 ? n : null;
  }
  function as(e) {
    if (e.tag === 13) {
      var t = e.memoizedState;
      if (
        (t === null && ((e = e.alternate), e !== null && (t = e.memoizedState)),
        t !== null)
      )
        return t.dehydrated;
    }
    return null;
  }
  function cs(e) {
    if (nn(e) !== e) throw Error(c(188));
  }
  function yc(e) {
    var t = e.alternate;
    if (!t) {
      if (((t = nn(e)), t === null)) throw Error(c(188));
      return t !== e ? null : e;
    }
    for (var n = e, r = t; ;) {
      var l = n.return;
      if (l === null) break;
      var o = l.alternate;
      if (o === null) {
        if (((r = l.return), r !== null)) {
          n = r;
          continue;
        }
        break;
      }
      if (l.child === o.child) {
        for (o = l.child; o;) {
          if (o === n) return (cs(l), e);
          if (o === r) return (cs(l), t);
          o = o.sibling;
        }
        throw Error(c(188));
      }
      if (n.return !== r.return) ((n = l), (r = o));
      else {
        for (var s = !1, u = l.child; u;) {
          if (u === n) {
            ((s = !0), (n = l), (r = o));
            break;
          }
          if (u === r) {
            ((s = !0), (r = l), (n = o));
            break;
          }
          u = u.sibling;
        }
        if (!s) {
          for (u = o.child; u;) {
            if (u === n) {
              ((s = !0), (n = o), (r = l));
              break;
            }
            if (u === r) {
              ((s = !0), (r = o), (n = l));
              break;
            }
            u = u.sibling;
          }
          if (!s) throw Error(c(189));
        }
      }
      if (n.alternate !== r) throw Error(c(190));
    }
    if (n.tag !== 3) throw Error(c(188));
    return n.stateNode.current === n ? e : t;
  }
  function fs(e) {
    return ((e = yc(e)), e !== null ? ds(e) : null);
  }
  function ds(e) {
    if (e.tag === 5 || e.tag === 6) return e;
    for (e = e.child; e !== null;) {
      var t = ds(e);
      if (t !== null) return t;
      e = e.sibling;
    }
    return null;
  }
  var ps = g.unstable_scheduleCallback,
    hs = g.unstable_cancelCallback,
    gc = g.unstable_shouldYield,
    vc = g.unstable_requestPaint,
    Ee = g.unstable_now,
    xc = g.unstable_getCurrentPriorityLevel,
    bl = g.unstable_ImmediatePriority,
    ms = g.unstable_UserBlockingPriority,
    Rr = g.unstable_NormalPriority,
    wc = g.unstable_LowPriority,
    ys = g.unstable_IdlePriority,
    Tr = null,
    wt = null;
  function kc(e) {
    if (wt && typeof wt.onCommitFiberRoot == "function")
      try {
        wt.onCommitFiberRoot(Tr, e, void 0, (e.current.flags & 128) === 128);
      } catch {}
  }
  var pt = Math.clz32 ? Math.clz32 : zc,
    Sc = Math.log,
    jc = Math.LN2;
  function zc(e) {
    return ((e >>>= 0), e === 0 ? 32 : (31 - ((Sc(e) / jc) | 0)) | 0);
  }
  var Or = 64,
    Dr = 4194304;
  function Kn(e) {
    switch (e & -e) {
      case 1:
        return 1;
      case 2:
        return 2;
      case 4:
        return 4;
      case 8:
        return 8;
      case 16:
        return 16;
      case 32:
        return 32;
      case 64:
      case 128:
      case 256:
      case 512:
      case 1024:
      case 2048:
      case 4096:
      case 8192:
      case 16384:
      case 32768:
      case 65536:
      case 131072:
      case 262144:
      case 524288:
      case 1048576:
      case 2097152:
        return e & 4194240;
      case 4194304:
      case 8388608:
      case 16777216:
      case 33554432:
      case 67108864:
        return e & 130023424;
      case 134217728:
        return 134217728;
      case 268435456:
        return 268435456;
      case 536870912:
        return 536870912;
      case 1073741824:
        return 1073741824;
      default:
        return e;
    }
  }
  function Ir(e, t) {
    var n = e.pendingLanes;
    if (n === 0) return 0;
    var r = 0,
      l = e.suspendedLanes,
      o = e.pingedLanes,
      s = n & 268435455;
    if (s !== 0) {
      var u = s & ~l;
      u !== 0 ? (r = Kn(u)) : ((o &= s), o !== 0 && (r = Kn(o)));
    } else ((s = n & ~l), s !== 0 ? (r = Kn(s)) : o !== 0 && (r = Kn(o)));
    if (r === 0) return 0;
    if (
      t !== 0 &&
      t !== r &&
      (t & l) === 0 &&
      ((l = r & -r), (o = t & -t), l >= o || (l === 16 && (o & 4194240) !== 0))
    )
      return t;
    if (((r & 4) !== 0 && (r |= n & 16), (t = e.entangledLanes), t !== 0))
      for (e = e.entanglements, t &= r; 0 < t;)
        ((n = 31 - pt(t)), (l = 1 << n), (r |= e[n]), (t &= ~l));
    return r;
  }
  function Cc(e, t) {
    switch (e) {
      case 1:
      case 2:
      case 4:
        return t + 250;
      case 8:
      case 16:
      case 32:
      case 64:
      case 128:
      case 256:
      case 512:
      case 1024:
      case 2048:
      case 4096:
      case 8192:
      case 16384:
      case 32768:
      case 65536:
      case 131072:
      case 262144:
      case 524288:
      case 1048576:
      case 2097152:
        return t + 5e3;
      case 4194304:
      case 8388608:
      case 16777216:
      case 33554432:
      case 67108864:
        return -1;
      case 134217728:
      case 268435456:
      case 536870912:
      case 1073741824:
        return -1;
      default:
        return -1;
    }
  }
  function Ec(e, t) {
    for (
      var n = e.suspendedLanes,
        r = e.pingedLanes,
        l = e.expirationTimes,
        o = e.pendingLanes;
      0 < o;
    ) {
      var s = 31 - pt(o),
        u = 1 << s,
        a = l[s];
      (a === -1
        ? ((u & n) === 0 || (u & r) !== 0) && (l[s] = Cc(u, t))
        : a <= t && (e.expiredLanes |= u),
        (o &= ~u));
    }
  }
  function eo(e) {
    return (
      (e = e.pendingLanes & -1073741825),
      e !== 0 ? e : e & 1073741824 ? 1073741824 : 0
    );
  }
  function gs() {
    var e = Or;
    return ((Or <<= 1), (Or & 4194240) === 0 && (Or = 64), e);
  }
  function to(e) {
    for (var t = [], n = 0; 31 > n; n++) t.push(e);
    return t;
  }
  function Gn(e, t, n) {
    ((e.pendingLanes |= t),
      t !== 536870912 && ((e.suspendedLanes = 0), (e.pingedLanes = 0)),
      (e = e.eventTimes),
      (t = 31 - pt(t)),
      (e[t] = n));
  }
  function _c(e, t) {
    var n = e.pendingLanes & ~t;
    ((e.pendingLanes = t),
      (e.suspendedLanes = 0),
      (e.pingedLanes = 0),
      (e.expiredLanes &= t),
      (e.mutableReadLanes &= t),
      (e.entangledLanes &= t),
      (t = e.entanglements));
    var r = e.eventTimes;
    for (e = e.expirationTimes; 0 < n;) {
      var l = 31 - pt(n),
        o = 1 << l;
      ((t[l] = 0), (r[l] = -1), (e[l] = -1), (n &= ~o));
    }
  }
  function no(e, t) {
    var n = (e.entangledLanes |= t);
    for (e = e.entanglements; n;) {
      var r = 31 - pt(n),
        l = 1 << r;
      ((l & t) | (e[r] & t) && (e[r] |= t), (n &= ~l));
    }
  }
  var se = 0;
  function vs(e) {
    return (
      (e &= -e),
      1 < e ? (4 < e ? ((e & 268435455) !== 0 ? 16 : 536870912) : 4) : 1
    );
  }
  var xs,
    ro,
    ws,
    ks,
    Ss,
    lo = !1,
    Fr = [],
    It = null,
    Ft = null,
    Ut = null,
    Yn = new Map(),
    Xn = new Map(),
    At = [],
    Mc =
      "mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(
        " ",
      );
  function js(e, t) {
    switch (e) {
      case "focusin":
      case "focusout":
        It = null;
        break;
      case "dragenter":
      case "dragleave":
        Ft = null;
        break;
      case "mouseover":
      case "mouseout":
        Ut = null;
        break;
      case "pointerover":
      case "pointerout":
        Yn.delete(t.pointerId);
        break;
      case "gotpointercapture":
      case "lostpointercapture":
        Xn.delete(t.pointerId);
    }
  }
  function qn(e, t, n, r, l, o) {
    return e === null || e.nativeEvent !== o
      ? ((e = {
          blockedOn: t,
          domEventName: n,
          eventSystemFlags: r,
          nativeEvent: o,
          targetContainers: [l],
        }),
        t !== null && ((t = fr(t)), t !== null && ro(t)),
        e)
      : ((e.eventSystemFlags |= r),
        (t = e.targetContainers),
        l !== null && t.indexOf(l) === -1 && t.push(l),
        e);
  }
  function Pc(e, t, n, r, l) {
    switch (t) {
      case "focusin":
        return ((It = qn(It, e, t, n, r, l)), !0);
      case "dragenter":
        return ((Ft = qn(Ft, e, t, n, r, l)), !0);
      case "mouseover":
        return ((Ut = qn(Ut, e, t, n, r, l)), !0);
      case "pointerover":
        var o = l.pointerId;
        return (Yn.set(o, qn(Yn.get(o) || null, e, t, n, r, l)), !0);
      case "gotpointercapture":
        return (
          (o = l.pointerId),
          Xn.set(o, qn(Xn.get(o) || null, e, t, n, r, l)),
          !0
        );
    }
    return !1;
  }
  function zs(e) {
    var t = rn(e.target);
    if (t !== null) {
      var n = nn(t);
      if (n !== null) {
        if (((t = n.tag), t === 13)) {
          if (((t = as(n)), t !== null)) {
            ((e.blockedOn = t),
              Ss(e.priority, function () {
                ws(n);
              }));
            return;
          }
        } else if (t === 3 && n.stateNode.current.memoizedState.isDehydrated) {
          e.blockedOn = n.tag === 3 ? n.stateNode.containerInfo : null;
          return;
        }
      }
    }
    e.blockedOn = null;
  }
  function Ur(e) {
    if (e.blockedOn !== null) return !1;
    for (var t = e.targetContainers; 0 < t.length;) {
      var n = io(e.domEventName, e.eventSystemFlags, t[0], e.nativeEvent);
      if (n === null) {
        n = e.nativeEvent;
        var r = new n.constructor(n.type, n);
        ((Kl = r), n.target.dispatchEvent(r), (Kl = null));
      } else return ((t = fr(n)), t !== null && ro(t), (e.blockedOn = n), !1);
      t.shift();
    }
    return !0;
  }
  function Cs(e, t, n) {
    Ur(e) && n.delete(t);
  }
  function Lc() {
    ((lo = !1),
      It !== null && Ur(It) && (It = null),
      Ft !== null && Ur(Ft) && (Ft = null),
      Ut !== null && Ur(Ut) && (Ut = null),
      Yn.forEach(Cs),
      Xn.forEach(Cs));
  }
  function Jn(e, t) {
    e.blockedOn === t &&
      ((e.blockedOn = null),
      lo ||
        ((lo = !0),
        g.unstable_scheduleCallback(g.unstable_NormalPriority, Lc)));
  }
  function bn(e) {
    function t(l) {
      return Jn(l, e);
    }
    if (0 < Fr.length) {
      Jn(Fr[0], e);
      for (var n = 1; n < Fr.length; n++) {
        var r = Fr[n];
        r.blockedOn === e && (r.blockedOn = null);
      }
    }
    for (
      It !== null && Jn(It, e),
        Ft !== null && Jn(Ft, e),
        Ut !== null && Jn(Ut, e),
        Yn.forEach(t),
        Xn.forEach(t),
        n = 0;
      n < At.length;
      n++
    )
      ((r = At[n]), r.blockedOn === e && (r.blockedOn = null));
    for (; 0 < At.length && ((n = At[0]), n.blockedOn === null);)
      (zs(n), n.blockedOn === null && At.shift());
  }
  var xn = oe.ReactCurrentBatchConfig,
    Ar = !0;
  function Nc(e, t, n, r) {
    var l = se,
      o = xn.transition;
    xn.transition = null;
    try {
      ((se = 1), oo(e, t, n, r));
    } finally {
      ((se = l), (xn.transition = o));
    }
  }
  function Rc(e, t, n, r) {
    var l = se,
      o = xn.transition;
    xn.transition = null;
    try {
      ((se = 4), oo(e, t, n, r));
    } finally {
      ((se = l), (xn.transition = o));
    }
  }
  function oo(e, t, n, r) {
    if (Ar) {
      var l = io(e, t, n, r);
      if (l === null) (zo(e, t, r, Wr, n), js(e, r));
      else if (Pc(l, e, t, n, r)) r.stopPropagation();
      else if ((js(e, r), t & 4 && -1 < Mc.indexOf(e))) {
        for (; l !== null;) {
          var o = fr(l);
          if (
            (o !== null && xs(o),
            (o = io(e, t, n, r)),
            o === null && zo(e, t, r, Wr, n),
            o === l)
          )
            break;
          l = o;
        }
        l !== null && r.stopPropagation();
      } else zo(e, t, r, null, n);
    }
  }
  var Wr = null;
  function io(e, t, n, r) {
    if (((Wr = null), (e = Gl(r)), (e = rn(e)), e !== null))
      if (((t = nn(e)), t === null)) e = null;
      else if (((n = t.tag), n === 13)) {
        if (((e = as(t)), e !== null)) return e;
        e = null;
      } else if (n === 3) {
        if (t.stateNode.current.memoizedState.isDehydrated)
          return t.tag === 3 ? t.stateNode.containerInfo : null;
        e = null;
      } else t !== e && (e = null);
    return ((Wr = e), null);
  }
  function Es(e) {
    switch (e) {
      case "cancel":
      case "click":
      case "close":
      case "contextmenu":
      case "copy":
      case "cut":
      case "auxclick":
      case "dblclick":
      case "dragend":
      case "dragstart":
      case "drop":
      case "focusin":
      case "focusout":
      case "input":
      case "invalid":
      case "keydown":
      case "keypress":
      case "keyup":
      case "mousedown":
      case "mouseup":
      case "paste":
      case "pause":
      case "play":
      case "pointercancel":
      case "pointerdown":
      case "pointerup":
      case "ratechange":
      case "reset":
      case "resize":
      case "seeked":
      case "submit":
      case "touchcancel":
      case "touchend":
      case "touchstart":
      case "volumechange":
      case "change":
      case "selectionchange":
      case "textInput":
      case "compositionstart":
      case "compositionend":
      case "compositionupdate":
      case "beforeblur":
      case "afterblur":
      case "beforeinput":
      case "blur":
      case "fullscreenchange":
      case "focus":
      case "hashchange":
      case "popstate":
      case "select":
      case "selectstart":
        return 1;
      case "drag":
      case "dragenter":
      case "dragexit":
      case "dragleave":
      case "dragover":
      case "mousemove":
      case "mouseout":
      case "mouseover":
      case "pointermove":
      case "pointerout":
      case "pointerover":
      case "scroll":
      case "toggle":
      case "touchmove":
      case "wheel":
      case "mouseenter":
      case "mouseleave":
      case "pointerenter":
      case "pointerleave":
        return 4;
      case "message":
        switch (xc()) {
          case bl:
            return 1;
          case ms:
            return 4;
          case Rr:
          case wc:
            return 16;
          case ys:
            return 536870912;
          default:
            return 16;
        }
      default:
        return 16;
    }
  }
  var Wt = null,
    so = null,
    $r = null;
  function _s() {
    if ($r) return $r;
    var e,
      t = so,
      n = t.length,
      r,
      l = "value" in Wt ? Wt.value : Wt.textContent,
      o = l.length;
    for (e = 0; e < n && t[e] === l[e]; e++);
    var s = n - e;
    for (r = 1; r <= s && t[n - r] === l[o - r]; r++);
    return ($r = l.slice(e, 1 < r ? 1 - r : void 0));
  }
  function Hr(e) {
    var t = e.keyCode;
    return (
      "charCode" in e
        ? ((e = e.charCode), e === 0 && t === 13 && (e = 13))
        : (e = t),
      e === 10 && (e = 13),
      32 <= e || e === 13 ? e : 0
    );
  }
  function Br() {
    return !0;
  }
  function Ms() {
    return !1;
  }
  function nt(e) {
    function t(n, r, l, o, s) {
      ((this._reactName = n),
        (this._targetInst = l),
        (this.type = r),
        (this.nativeEvent = o),
        (this.target = s),
        (this.currentTarget = null));
      for (var u in e)
        e.hasOwnProperty(u) && ((n = e[u]), (this[u] = n ? n(o) : o[u]));
      return (
        (this.isDefaultPrevented = (
          o.defaultPrevented != null ? o.defaultPrevented : o.returnValue === !1
        )
          ? Br
          : Ms),
        (this.isPropagationStopped = Ms),
        this
      );
    }
    return (
      L(t.prototype, {
        preventDefault: function () {
          this.defaultPrevented = !0;
          var n = this.nativeEvent;
          n &&
            (n.preventDefault
              ? n.preventDefault()
              : typeof n.returnValue != "unknown" && (n.returnValue = !1),
            (this.isDefaultPrevented = Br));
        },
        stopPropagation: function () {
          var n = this.nativeEvent;
          n &&
            (n.stopPropagation
              ? n.stopPropagation()
              : typeof n.cancelBubble != "unknown" && (n.cancelBubble = !0),
            (this.isPropagationStopped = Br));
        },
        persist: function () {},
        isPersistent: Br,
      }),
      t
    );
  }
  var wn = {
      eventPhase: 0,
      bubbles: 0,
      cancelable: 0,
      timeStamp: function (e) {
        return e.timeStamp || Date.now();
      },
      defaultPrevented: 0,
      isTrusted: 0,
    },
    uo = nt(wn),
    er = L({}, wn, { view: 0, detail: 0 }),
    Tc = nt(er),
    ao,
    co,
    tr,
    Vr = L({}, er, {
      screenX: 0,
      screenY: 0,
      clientX: 0,
      clientY: 0,
      pageX: 0,
      pageY: 0,
      ctrlKey: 0,
      shiftKey: 0,
      altKey: 0,
      metaKey: 0,
      getModifierState: po,
      button: 0,
      buttons: 0,
      relatedTarget: function (e) {
        return e.relatedTarget === void 0
          ? e.fromElement === e.srcElement
            ? e.toElement
            : e.fromElement
          : e.relatedTarget;
      },
      movementX: function (e) {
        return "movementX" in e
          ? e.movementX
          : (e !== tr &&
              (tr && e.type === "mousemove"
                ? ((ao = e.screenX - tr.screenX), (co = e.screenY - tr.screenY))
                : (co = ao = 0),
              (tr = e)),
            ao);
      },
      movementY: function (e) {
        return "movementY" in e ? e.movementY : co;
      },
    }),
    Ps = nt(Vr),
    Oc = L({}, Vr, { dataTransfer: 0 }),
    Dc = nt(Oc),
    Ic = L({}, er, { relatedTarget: 0 }),
    fo = nt(Ic),
    Fc = L({}, wn, { animationName: 0, elapsedTime: 0, pseudoElement: 0 }),
    Uc = nt(Fc),
    Ac = L({}, wn, {
      clipboardData: function (e) {
        return "clipboardData" in e ? e.clipboardData : window.clipboardData;
      },
    }),
    Wc = nt(Ac),
    $c = L({}, wn, { data: 0 }),
    Ls = nt($c),
    Hc = {
      Esc: "Escape",
      Spacebar: " ",
      Left: "ArrowLeft",
      Up: "ArrowUp",
      Right: "ArrowRight",
      Down: "ArrowDown",
      Del: "Delete",
      Win: "OS",
      Menu: "ContextMenu",
      Apps: "ContextMenu",
      Scroll: "ScrollLock",
      MozPrintableKey: "Unidentified",
    },
    Bc = {
      8: "Backspace",
      9: "Tab",
      12: "Clear",
      13: "Enter",
      16: "Shift",
      17: "Control",
      18: "Alt",
      19: "Pause",
      20: "CapsLock",
      27: "Escape",
      32: " ",
      33: "PageUp",
      34: "PageDown",
      35: "End",
      36: "Home",
      37: "ArrowLeft",
      38: "ArrowUp",
      39: "ArrowRight",
      40: "ArrowDown",
      45: "Insert",
      46: "Delete",
      112: "F1",
      113: "F2",
      114: "F3",
      115: "F4",
      116: "F5",
      117: "F6",
      118: "F7",
      119: "F8",
      120: "F9",
      121: "F10",
      122: "F11",
      123: "F12",
      144: "NumLock",
      145: "ScrollLock",
      224: "Meta",
    },
    Vc = {
      Alt: "altKey",
      Control: "ctrlKey",
      Meta: "metaKey",
      Shift: "shiftKey",
    };
  function Qc(e) {
    var t = this.nativeEvent;
    return t.getModifierState
      ? t.getModifierState(e)
      : (e = Vc[e])
        ? !!t[e]
        : !1;
  }
  function po() {
    return Qc;
  }
  var Zc = L({}, er, {
      key: function (e) {
        if (e.key) {
          var t = Hc[e.key] || e.key;
          if (t !== "Unidentified") return t;
        }
        return e.type === "keypress"
          ? ((e = Hr(e)), e === 13 ? "Enter" : String.fromCharCode(e))
          : e.type === "keydown" || e.type === "keyup"
            ? Bc[e.keyCode] || "Unidentified"
            : "";
      },
      code: 0,
      location: 0,
      ctrlKey: 0,
      shiftKey: 0,
      altKey: 0,
      metaKey: 0,
      repeat: 0,
      locale: 0,
      getModifierState: po,
      charCode: function (e) {
        return e.type === "keypress" ? Hr(e) : 0;
      },
      keyCode: function (e) {
        return e.type === "keydown" || e.type === "keyup" ? e.keyCode : 0;
      },
      which: function (e) {
        return e.type === "keypress"
          ? Hr(e)
          : e.type === "keydown" || e.type === "keyup"
            ? e.keyCode
            : 0;
      },
    }),
    Kc = nt(Zc),
    Gc = L({}, Vr, {
      pointerId: 0,
      width: 0,
      height: 0,
      pressure: 0,
      tangentialPressure: 0,
      tiltX: 0,
      tiltY: 0,
      twist: 0,
      pointerType: 0,
      isPrimary: 0,
    }),
    Ns = nt(Gc),
    Yc = L({}, er, {
      touches: 0,
      targetTouches: 0,
      changedTouches: 0,
      altKey: 0,
      metaKey: 0,
      ctrlKey: 0,
      shiftKey: 0,
      getModifierState: po,
    }),
    Xc = nt(Yc),
    qc = L({}, wn, { propertyName: 0, elapsedTime: 0, pseudoElement: 0 }),
    Jc = nt(qc),
    bc = L({}, Vr, {
      deltaX: function (e) {
        return "deltaX" in e
          ? e.deltaX
          : "wheelDeltaX" in e
            ? -e.wheelDeltaX
            : 0;
      },
      deltaY: function (e) {
        return "deltaY" in e
          ? e.deltaY
          : "wheelDeltaY" in e
            ? -e.wheelDeltaY
            : "wheelDelta" in e
              ? -e.wheelDelta
              : 0;
      },
      deltaZ: 0,
      deltaMode: 0,
    }),
    ef = nt(bc),
    tf = [9, 13, 27, 32],
    ho = K && "CompositionEvent" in window,
    nr = null;
  K && "documentMode" in document && (nr = document.documentMode);
  var nf = K && "TextEvent" in window && !nr,
    Rs = K && (!ho || (nr && 8 < nr && 11 >= nr)),
    Ts = " ",
    Os = !1;
  function Ds(e, t) {
    switch (e) {
      case "keyup":
        return tf.indexOf(t.keyCode) !== -1;
      case "keydown":
        return t.keyCode !== 229;
      case "keypress":
      case "mousedown":
      case "focusout":
        return !0;
      default:
        return !1;
    }
  }
  function Is(e) {
    return (
      (e = e.detail),
      typeof e == "object" && "data" in e ? e.data : null
    );
  }
  var kn = !1;
  function rf(e, t) {
    switch (e) {
      case "compositionend":
        return Is(t);
      case "keypress":
        return t.which !== 32 ? null : ((Os = !0), Ts);
      case "textInput":
        return ((e = t.data), e === Ts && Os ? null : e);
      default:
        return null;
    }
  }
  function lf(e, t) {
    if (kn)
      return e === "compositionend" || (!ho && Ds(e, t))
        ? ((e = _s()), ($r = so = Wt = null), (kn = !1), e)
        : null;
    switch (e) {
      case "paste":
        return null;
      case "keypress":
        if (!(t.ctrlKey || t.altKey || t.metaKey) || (t.ctrlKey && t.altKey)) {
          if (t.char && 1 < t.char.length) return t.char;
          if (t.which) return String.fromCharCode(t.which);
        }
        return null;
      case "compositionend":
        return Rs && t.locale !== "ko" ? null : t.data;
      default:
        return null;
    }
  }
  var of = {
    color: !0,
    date: !0,
    datetime: !0,
    "datetime-local": !0,
    email: !0,
    month: !0,
    number: !0,
    password: !0,
    range: !0,
    search: !0,
    tel: !0,
    text: !0,
    time: !0,
    url: !0,
    week: !0,
  };
  function Fs(e) {
    var t = e && e.nodeName && e.nodeName.toLowerCase();
    return t === "input" ? !!of[e.type] : t === "textarea";
  }
  function Us(e, t, n, r) {
    (ls(r),
      (t = Yr(t, "onChange")),
      0 < t.length &&
        ((n = new uo("onChange", "change", null, n, r)),
        e.push({ event: n, listeners: t })));
  }
  var rr = null,
    lr = null;
  function sf(e) {
    nu(e, 0);
  }
  function Qr(e) {
    var t = En(e);
    if (Zi(t)) return e;
  }
  function uf(e, t) {
    if (e === "change") return t;
  }
  var As = !1;
  if (K) {
    var mo;
    if (K) {
      var yo = "oninput" in document;
      if (!yo) {
        var Ws = document.createElement("div");
        (Ws.setAttribute("oninput", "return;"),
          (yo = typeof Ws.oninput == "function"));
      }
      mo = yo;
    } else mo = !1;
    As = mo && (!document.documentMode || 9 < document.documentMode);
  }
  function $s() {
    rr && (rr.detachEvent("onpropertychange", Hs), (lr = rr = null));
  }
  function Hs(e) {
    if (e.propertyName === "value" && Qr(lr)) {
      var t = [];
      (Us(t, lr, e, Gl(e)), us(sf, t));
    }
  }
  function af(e, t, n) {
    e === "focusin"
      ? ($s(), (rr = t), (lr = n), rr.attachEvent("onpropertychange", Hs))
      : e === "focusout" && $s();
  }
  function cf(e) {
    if (e === "selectionchange" || e === "keyup" || e === "keydown")
      return Qr(lr);
  }
  function ff(e, t) {
    if (e === "click") return Qr(t);
  }
  function df(e, t) {
    if (e === "input" || e === "change") return Qr(t);
  }
  function pf(e, t) {
    return (e === t && (e !== 0 || 1 / e === 1 / t)) || (e !== e && t !== t);
  }
  var ht = typeof Object.is == "function" ? Object.is : pf;
  function or(e, t) {
    if (ht(e, t)) return !0;
    if (
      typeof e != "object" ||
      e === null ||
      typeof t != "object" ||
      t === null
    )
      return !1;
    var n = Object.keys(e),
      r = Object.keys(t);
    if (n.length !== r.length) return !1;
    for (r = 0; r < n.length; r++) {
      var l = n[r];
      if (!R.call(t, l) || !ht(e[l], t[l])) return !1;
    }
    return !0;
  }
  function Bs(e) {
    for (; e && e.firstChild;) e = e.firstChild;
    return e;
  }
  function Vs(e, t) {
    var n = Bs(e);
    e = 0;
    for (var r; n;) {
      if (n.nodeType === 3) {
        if (((r = e + n.textContent.length), e <= t && r >= t))
          return { node: n, offset: t - e };
        e = r;
      }
      e: {
        for (; n;) {
          if (n.nextSibling) {
            n = n.nextSibling;
            break e;
          }
          n = n.parentNode;
        }
        n = void 0;
      }
      n = Bs(n);
    }
  }
  function Qs(e, t) {
    return e && t
      ? e === t
        ? !0
        : e && e.nodeType === 3
          ? !1
          : t && t.nodeType === 3
            ? Qs(e, t.parentNode)
            : "contains" in e
              ? e.contains(t)
              : e.compareDocumentPosition
                ? !!(e.compareDocumentPosition(t) & 16)
                : !1
      : !1;
  }
  function Zs() {
    for (var e = window, t = Mr(); t instanceof e.HTMLIFrameElement;) {
      try {
        var n = typeof t.contentWindow.location.href == "string";
      } catch {
        n = !1;
      }
      if (n) e = t.contentWindow;
      else break;
      t = Mr(e.document);
    }
    return t;
  }
  function go(e) {
    var t = e && e.nodeName && e.nodeName.toLowerCase();
    return (
      t &&
      ((t === "input" &&
        (e.type === "text" ||
          e.type === "search" ||
          e.type === "tel" ||
          e.type === "url" ||
          e.type === "password")) ||
        t === "textarea" ||
        e.contentEditable === "true")
    );
  }
  function hf(e) {
    var t = Zs(),
      n = e.focusedElem,
      r = e.selectionRange;
    if (
      t !== n &&
      n &&
      n.ownerDocument &&
      Qs(n.ownerDocument.documentElement, n)
    ) {
      if (r !== null && go(n)) {
        if (
          ((t = r.start),
          (e = r.end),
          e === void 0 && (e = t),
          "selectionStart" in n)
        )
          ((n.selectionStart = t),
            (n.selectionEnd = Math.min(e, n.value.length)));
        else if (
          ((e = ((t = n.ownerDocument || document) && t.defaultView) || window),
          e.getSelection)
        ) {
          e = e.getSelection();
          var l = n.textContent.length,
            o = Math.min(r.start, l);
          ((r = r.end === void 0 ? o : Math.min(r.end, l)),
            !e.extend && o > r && ((l = r), (r = o), (o = l)),
            (l = Vs(n, o)));
          var s = Vs(n, r);
          l &&
            s &&
            (e.rangeCount !== 1 ||
              e.anchorNode !== l.node ||
              e.anchorOffset !== l.offset ||
              e.focusNode !== s.node ||
              e.focusOffset !== s.offset) &&
            ((t = t.createRange()),
            t.setStart(l.node, l.offset),
            e.removeAllRanges(),
            o > r
              ? (e.addRange(t), e.extend(s.node, s.offset))
              : (t.setEnd(s.node, s.offset), e.addRange(t)));
        }
      }
      for (t = [], e = n; (e = e.parentNode);)
        e.nodeType === 1 &&
          t.push({ element: e, left: e.scrollLeft, top: e.scrollTop });
      for (typeof n.focus == "function" && n.focus(), n = 0; n < t.length; n++)
        ((e = t[n]),
          (e.element.scrollLeft = e.left),
          (e.element.scrollTop = e.top));
    }
  }
  var mf = K && "documentMode" in document && 11 >= document.documentMode,
    Sn = null,
    vo = null,
    ir = null,
    xo = !1;
  function Ks(e, t, n) {
    var r =
      n.window === n ? n.document : n.nodeType === 9 ? n : n.ownerDocument;
    xo ||
      Sn == null ||
      Sn !== Mr(r) ||
      ((r = Sn),
      "selectionStart" in r && go(r)
        ? (r = { start: r.selectionStart, end: r.selectionEnd })
        : ((r = (
            (r.ownerDocument && r.ownerDocument.defaultView) ||
            window
          ).getSelection()),
          (r = {
            anchorNode: r.anchorNode,
            anchorOffset: r.anchorOffset,
            focusNode: r.focusNode,
            focusOffset: r.focusOffset,
          })),
      (ir && or(ir, r)) ||
        ((ir = r),
        (r = Yr(vo, "onSelect")),
        0 < r.length &&
          ((t = new uo("onSelect", "select", null, t, n)),
          e.push({ event: t, listeners: r }),
          (t.target = Sn))));
  }
  function Zr(e, t) {
    var n = {};
    return (
      (n[e.toLowerCase()] = t.toLowerCase()),
      (n["Webkit" + e] = "webkit" + t),
      (n["Moz" + e] = "moz" + t),
      n
    );
  }
  var jn = {
      animationend: Zr("Animation", "AnimationEnd"),
      animationiteration: Zr("Animation", "AnimationIteration"),
      animationstart: Zr("Animation", "AnimationStart"),
      transitionend: Zr("Transition", "TransitionEnd"),
    },
    wo = {},
    Gs = {};
  K &&
    ((Gs = document.createElement("div").style),
    "AnimationEvent" in window ||
      (delete jn.animationend.animation,
      delete jn.animationiteration.animation,
      delete jn.animationstart.animation),
    "TransitionEvent" in window || delete jn.transitionend.transition);
  function Kr(e) {
    if (wo[e]) return wo[e];
    if (!jn[e]) return e;
    var t = jn[e],
      n;
    for (n in t) if (t.hasOwnProperty(n) && n in Gs) return (wo[e] = t[n]);
    return e;
  }
  var Ys = Kr("animationend"),
    Xs = Kr("animationiteration"),
    qs = Kr("animationstart"),
    Js = Kr("transitionend"),
    bs = new Map(),
    eu =
      "abort auxClick cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(
        " ",
      );
  function $t(e, t) {
    (bs.set(e, t), _(t, [e]));
  }
  for (var ko = 0; ko < eu.length; ko++) {
    var So = eu[ko],
      yf = So.toLowerCase(),
      gf = So[0].toUpperCase() + So.slice(1);
    $t(yf, "on" + gf);
  }
  ($t(Ys, "onAnimationEnd"),
    $t(Xs, "onAnimationIteration"),
    $t(qs, "onAnimationStart"),
    $t("dblclick", "onDoubleClick"),
    $t("focusin", "onFocus"),
    $t("focusout", "onBlur"),
    $t(Js, "onTransitionEnd"),
    $("onMouseEnter", ["mouseout", "mouseover"]),
    $("onMouseLeave", ["mouseout", "mouseover"]),
    $("onPointerEnter", ["pointerout", "pointerover"]),
    $("onPointerLeave", ["pointerout", "pointerover"]),
    _(
      "onChange",
      "change click focusin focusout input keydown keyup selectionchange".split(
        " ",
      ),
    ),
    _(
      "onSelect",
      "focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(
        " ",
      ),
    ),
    _("onBeforeInput", ["compositionend", "keypress", "textInput", "paste"]),
    _(
      "onCompositionEnd",
      "compositionend focusout keydown keypress keyup mousedown".split(" "),
    ),
    _(
      "onCompositionStart",
      "compositionstart focusout keydown keypress keyup mousedown".split(" "),
    ),
    _(
      "onCompositionUpdate",
      "compositionupdate focusout keydown keypress keyup mousedown".split(" "),
    ));
  var sr =
      "abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(
        " ",
      ),
    vf = new Set(
      "cancel close invalid load scroll toggle".split(" ").concat(sr),
    );
  function tu(e, t, n) {
    var r = e.type || "unknown-event";
    ((e.currentTarget = n), mc(r, t, void 0, e), (e.currentTarget = null));
  }
  function nu(e, t) {
    t = (t & 4) !== 0;
    for (var n = 0; n < e.length; n++) {
      var r = e[n],
        l = r.event;
      r = r.listeners;
      e: {
        var o = void 0;
        if (t)
          for (var s = r.length - 1; 0 <= s; s--) {
            var u = r[s],
              a = u.instance,
              y = u.currentTarget;
            if (((u = u.listener), a !== o && l.isPropagationStopped()))
              break e;
            (tu(l, u, y), (o = a));
          }
        else
          for (s = 0; s < r.length; s++) {
            if (
              ((u = r[s]),
              (a = u.instance),
              (y = u.currentTarget),
              (u = u.listener),
              a !== o && l.isPropagationStopped())
            )
              break e;
            (tu(l, u, y), (o = a));
          }
      }
    }
    if (Nr) throw ((e = Jl), (Nr = !1), (Jl = null), e);
  }
  function he(e, t) {
    var n = t[Lo];
    n === void 0 && (n = t[Lo] = new Set());
    var r = e + "__bubble";
    n.has(r) || (ru(t, e, 2, !1), n.add(r));
  }
  function jo(e, t, n) {
    var r = 0;
    (t && (r |= 4), ru(n, e, r, t));
  }
  var Gr = "_reactListening" + Math.random().toString(36).slice(2);
  function ur(e) {
    if (!e[Gr]) {
      ((e[Gr] = !0),
        S.forEach(function (n) {
          n !== "selectionchange" && (vf.has(n) || jo(n, !1, e), jo(n, !0, e));
        }));
      var t = e.nodeType === 9 ? e : e.ownerDocument;
      t === null || t[Gr] || ((t[Gr] = !0), jo("selectionchange", !1, t));
    }
  }
  function ru(e, t, n, r) {
    switch (Es(t)) {
      case 1:
        var l = Nc;
        break;
      case 4:
        l = Rc;
        break;
      default:
        l = oo;
    }
    ((n = l.bind(null, t, n, e)),
      (l = void 0),
      !ql ||
        (t !== "touchstart" && t !== "touchmove" && t !== "wheel") ||
        (l = !0),
      r
        ? l !== void 0
          ? e.addEventListener(t, n, { capture: !0, passive: l })
          : e.addEventListener(t, n, !0)
        : l !== void 0
          ? e.addEventListener(t, n, { passive: l })
          : e.addEventListener(t, n, !1));
  }
  function zo(e, t, n, r, l) {
    var o = r;
    if ((t & 1) === 0 && (t & 2) === 0 && r !== null)
      e: for (;;) {
        if (r === null) return;
        var s = r.tag;
        if (s === 3 || s === 4) {
          var u = r.stateNode.containerInfo;
          if (u === l || (u.nodeType === 8 && u.parentNode === l)) break;
          if (s === 4)
            for (s = r.return; s !== null;) {
              var a = s.tag;
              if (
                (a === 3 || a === 4) &&
                ((a = s.stateNode.containerInfo),
                a === l || (a.nodeType === 8 && a.parentNode === l))
              )
                return;
              s = s.return;
            }
          for (; u !== null;) {
            if (((s = rn(u)), s === null)) return;
            if (((a = s.tag), a === 5 || a === 6)) {
              r = o = s;
              continue e;
            }
            u = u.parentNode;
          }
        }
        r = r.return;
      }
    us(function () {
      var y = o,
        k = Gl(n),
        j = [];
      e: {
        var x = bs.get(e);
        if (x !== void 0) {
          var M = uo,
            N = e;
          switch (e) {
            case "keypress":
              if (Hr(n) === 0) break e;
            case "keydown":
            case "keyup":
              M = Kc;
              break;
            case "focusin":
              ((N = "focus"), (M = fo));
              break;
            case "focusout":
              ((N = "blur"), (M = fo));
              break;
            case "beforeblur":
            case "afterblur":
              M = fo;
              break;
            case "click":
              if (n.button === 2) break e;
            case "auxclick":
            case "dblclick":
            case "mousedown":
            case "mousemove":
            case "mouseup":
            case "mouseout":
            case "mouseover":
            case "contextmenu":
              M = Ps;
              break;
            case "drag":
            case "dragend":
            case "dragenter":
            case "dragexit":
            case "dragleave":
            case "dragover":
            case "dragstart":
            case "drop":
              M = Dc;
              break;
            case "touchcancel":
            case "touchend":
            case "touchmove":
            case "touchstart":
              M = Xc;
              break;
            case Ys:
            case Xs:
            case qs:
              M = Uc;
              break;
            case Js:
              M = Jc;
              break;
            case "scroll":
              M = Tc;
              break;
            case "wheel":
              M = ef;
              break;
            case "copy":
            case "cut":
            case "paste":
              M = Wc;
              break;
            case "gotpointercapture":
            case "lostpointercapture":
            case "pointercancel":
            case "pointerdown":
            case "pointermove":
            case "pointerout":
            case "pointerover":
            case "pointerup":
              M = Ns;
          }
          var T = (t & 4) !== 0,
            _e = !T && e === "scroll",
            h = T ? (x !== null ? x + "Capture" : null) : x;
          T = [];
          for (var f = y, m; f !== null;) {
            m = f;
            var z = m.stateNode;
            if (
              (m.tag === 5 &&
                z !== null &&
                ((m = z),
                h !== null &&
                  ((z = Vn(f, h)), z != null && T.push(ar(f, z, m)))),
              _e)
            )
              break;
            f = f.return;
          }
          0 < T.length &&
            ((x = new M(x, N, null, n, k)), j.push({ event: x, listeners: T }));
        }
      }
      if ((t & 7) === 0) {
        e: {
          if (
            ((x = e === "mouseover" || e === "pointerover"),
            (M = e === "mouseout" || e === "pointerout"),
            x &&
              n !== Kl &&
              (N = n.relatedTarget || n.fromElement) &&
              (rn(N) || N[Ct]))
          )
            break e;
          if (
            (M || x) &&
            ((x =
              k.window === k
                ? k
                : (x = k.ownerDocument)
                  ? x.defaultView || x.parentWindow
                  : window),
            M
              ? ((N = n.relatedTarget || n.toElement),
                (M = y),
                (N = N ? rn(N) : null),
                N !== null &&
                  ((_e = nn(N)), N !== _e || (N.tag !== 5 && N.tag !== 6)) &&
                  (N = null))
              : ((M = null), (N = y)),
            M !== N)
          ) {
            if (
              ((T = Ps),
              (z = "onMouseLeave"),
              (h = "onMouseEnter"),
              (f = "mouse"),
              (e === "pointerout" || e === "pointerover") &&
                ((T = Ns),
                (z = "onPointerLeave"),
                (h = "onPointerEnter"),
                (f = "pointer")),
              (_e = M == null ? x : En(M)),
              (m = N == null ? x : En(N)),
              (x = new T(z, f + "leave", M, n, k)),
              (x.target = _e),
              (x.relatedTarget = m),
              (z = null),
              rn(k) === y &&
                ((T = new T(h, f + "enter", N, n, k)),
                (T.target = m),
                (T.relatedTarget = _e),
                (z = T)),
              (_e = z),
              M && N)
            )
              t: {
                for (T = M, h = N, f = 0, m = T; m; m = zn(m)) f++;
                for (m = 0, z = h; z; z = zn(z)) m++;
                for (; 0 < f - m;) ((T = zn(T)), f--);
                for (; 0 < m - f;) ((h = zn(h)), m--);
                for (; f--;) {
                  if (T === h || (h !== null && T === h.alternate)) break t;
                  ((T = zn(T)), (h = zn(h)));
                }
                T = null;
              }
            else T = null;
            (M !== null && lu(j, x, M, T, !1),
              N !== null && _e !== null && lu(j, _e, N, T, !0));
          }
        }
        e: {
          if (
            ((x = y ? En(y) : window),
            (M = x.nodeName && x.nodeName.toLowerCase()),
            M === "select" || (M === "input" && x.type === "file"))
          )
            var O = uf;
          else if (Fs(x))
            if (As) O = df;
            else {
              O = cf;
              var I = af;
            }
          else
            (M = x.nodeName) &&
              M.toLowerCase() === "input" &&
              (x.type === "checkbox" || x.type === "radio") &&
              (O = ff);
          if (O && (O = O(e, y))) {
            Us(j, O, n, k);
            break e;
          }
          (I && I(e, x, y),
            e === "focusout" &&
              (I = x._wrapperState) &&
              I.controlled &&
              x.type === "number" &&
              Hl(x, "number", x.value));
        }
        switch (((I = y ? En(y) : window), e)) {
          case "focusin":
            (Fs(I) || I.contentEditable === "true") &&
              ((Sn = I), (vo = y), (ir = null));
            break;
          case "focusout":
            ir = vo = Sn = null;
            break;
          case "mousedown":
            xo = !0;
            break;
          case "contextmenu":
          case "mouseup":
          case "dragend":
            ((xo = !1), Ks(j, n, k));
            break;
          case "selectionchange":
            if (mf) break;
          case "keydown":
          case "keyup":
            Ks(j, n, k);
        }
        var F;
        if (ho)
          e: {
            switch (e) {
              case "compositionstart":
                var W = "onCompositionStart";
                break e;
              case "compositionend":
                W = "onCompositionEnd";
                break e;
              case "compositionupdate":
                W = "onCompositionUpdate";
                break e;
            }
            W = void 0;
          }
        else
          kn
            ? Ds(e, n) && (W = "onCompositionEnd")
            : e === "keydown" &&
              n.keyCode === 229 &&
              (W = "onCompositionStart");
        (W &&
          (Rs &&
            n.locale !== "ko" &&
            (kn || W !== "onCompositionStart"
              ? W === "onCompositionEnd" && kn && (F = _s())
              : ((Wt = k),
                (so = "value" in Wt ? Wt.value : Wt.textContent),
                (kn = !0))),
          (I = Yr(y, W)),
          0 < I.length &&
            ((W = new Ls(W, e, null, n, k)),
            j.push({ event: W, listeners: I }),
            F ? (W.data = F) : ((F = Is(n)), F !== null && (W.data = F)))),
          (F = nf ? rf(e, n) : lf(e, n)) &&
            ((y = Yr(y, "onBeforeInput")),
            0 < y.length &&
              ((k = new Ls("onBeforeInput", "beforeinput", null, n, k)),
              j.push({ event: k, listeners: y }),
              (k.data = F))));
      }
      nu(j, t);
    });
  }
  function ar(e, t, n) {
    return { instance: e, listener: t, currentTarget: n };
  }
  function Yr(e, t) {
    for (var n = t + "Capture", r = []; e !== null;) {
      var l = e,
        o = l.stateNode;
      (l.tag === 5 &&
        o !== null &&
        ((l = o),
        (o = Vn(e, n)),
        o != null && r.unshift(ar(e, o, l)),
        (o = Vn(e, t)),
        o != null && r.push(ar(e, o, l))),
        (e = e.return));
    }
    return r;
  }
  function zn(e) {
    if (e === null) return null;
    do e = e.return;
    while (e && e.tag !== 5);
    return e || null;
  }
  function lu(e, t, n, r, l) {
    for (var o = t._reactName, s = []; n !== null && n !== r;) {
      var u = n,
        a = u.alternate,
        y = u.stateNode;
      if (a !== null && a === r) break;
      (u.tag === 5 &&
        y !== null &&
        ((u = y),
        l
          ? ((a = Vn(n, o)), a != null && s.unshift(ar(n, a, u)))
          : l || ((a = Vn(n, o)), a != null && s.push(ar(n, a, u)))),
        (n = n.return));
    }
    s.length !== 0 && e.push({ event: t, listeners: s });
  }
  var xf = /\r\n?/g,
    wf = /\u0000|\uFFFD/g;
  function ou(e) {
    return (typeof e == "string" ? e : "" + e)
      .replace(
        xf,
        `
`,
      )
      .replace(wf, "");
  }
  function Xr(e, t, n) {
    if (((t = ou(t)), ou(e) !== t && n)) throw Error(c(425));
  }
  function qr() {}
  var Co = null,
    Eo = null;
  function _o(e, t) {
    return (
      e === "textarea" ||
      e === "noscript" ||
      typeof t.children == "string" ||
      typeof t.children == "number" ||
      (typeof t.dangerouslySetInnerHTML == "object" &&
        t.dangerouslySetInnerHTML !== null &&
        t.dangerouslySetInnerHTML.__html != null)
    );
  }
  var Mo = typeof setTimeout == "function" ? setTimeout : void 0,
    kf = typeof clearTimeout == "function" ? clearTimeout : void 0,
    iu = typeof Promise == "function" ? Promise : void 0,
    Sf =
      typeof queueMicrotask == "function"
        ? queueMicrotask
        : typeof iu < "u"
          ? function (e) {
              return iu.resolve(null).then(e).catch(jf);
            }
          : Mo;
  function jf(e) {
    setTimeout(function () {
      throw e;
    });
  }
  function Po(e, t) {
    var n = t,
      r = 0;
    do {
      var l = n.nextSibling;
      if ((e.removeChild(n), l && l.nodeType === 8))
        if (((n = l.data), n === "/$")) {
          if (r === 0) {
            (e.removeChild(l), bn(t));
            return;
          }
          r--;
        } else (n !== "$" && n !== "$?" && n !== "$!") || r++;
      n = l;
    } while (n);
    bn(t);
  }
  function Ht(e) {
    for (; e != null; e = e.nextSibling) {
      var t = e.nodeType;
      if (t === 1 || t === 3) break;
      if (t === 8) {
        if (((t = e.data), t === "$" || t === "$!" || t === "$?")) break;
        if (t === "/$") return null;
      }
    }
    return e;
  }
  function su(e) {
    e = e.previousSibling;
    for (var t = 0; e;) {
      if (e.nodeType === 8) {
        var n = e.data;
        if (n === "$" || n === "$!" || n === "$?") {
          if (t === 0) return e;
          t--;
        } else n === "/$" && t++;
      }
      e = e.previousSibling;
    }
    return null;
  }
  var Cn = Math.random().toString(36).slice(2),
    kt = "__reactFiber$" + Cn,
    cr = "__reactProps$" + Cn,
    Ct = "__reactContainer$" + Cn,
    Lo = "__reactEvents$" + Cn,
    zf = "__reactListeners$" + Cn,
    Cf = "__reactHandles$" + Cn;
  function rn(e) {
    var t = e[kt];
    if (t) return t;
    for (var n = e.parentNode; n;) {
      if ((t = n[Ct] || n[kt])) {
        if (
          ((n = t.alternate),
          t.child !== null || (n !== null && n.child !== null))
        )
          for (e = su(e); e !== null;) {
            if ((n = e[kt])) return n;
            e = su(e);
          }
        return t;
      }
      ((e = n), (n = e.parentNode));
    }
    return null;
  }
  function fr(e) {
    return (
      (e = e[kt] || e[Ct]),
      !e || (e.tag !== 5 && e.tag !== 6 && e.tag !== 13 && e.tag !== 3)
        ? null
        : e
    );
  }
  function En(e) {
    if (e.tag === 5 || e.tag === 6) return e.stateNode;
    throw Error(c(33));
  }
  function Jr(e) {
    return e[cr] || null;
  }
  var No = [],
    _n = -1;
  function Bt(e) {
    return { current: e };
  }
  function me(e) {
    0 > _n || ((e.current = No[_n]), (No[_n] = null), _n--);
  }
  function pe(e, t) {
    (_n++, (No[_n] = e.current), (e.current = t));
  }
  var Vt = {},
    Be = Bt(Vt),
    Ye = Bt(!1),
    ln = Vt;
  function Mn(e, t) {
    var n = e.type.contextTypes;
    if (!n) return Vt;
    var r = e.stateNode;
    if (r && r.__reactInternalMemoizedUnmaskedChildContext === t)
      return r.__reactInternalMemoizedMaskedChildContext;
    var l = {},
      o;
    for (o in n) l[o] = t[o];
    return (
      r &&
        ((e = e.stateNode),
        (e.__reactInternalMemoizedUnmaskedChildContext = t),
        (e.__reactInternalMemoizedMaskedChildContext = l)),
      l
    );
  }
  function Xe(e) {
    return ((e = e.childContextTypes), e != null);
  }
  function br() {
    (me(Ye), me(Be));
  }
  function uu(e, t, n) {
    if (Be.current !== Vt) throw Error(c(168));
    (pe(Be, t), pe(Ye, n));
  }
  function au(e, t, n) {
    var r = e.stateNode;
    if (((t = t.childContextTypes), typeof r.getChildContext != "function"))
      return n;
    r = r.getChildContext();
    for (var l in r) if (!(l in t)) throw Error(c(108, de(e) || "Unknown", l));
    return L({}, n, r);
  }
  function el(e) {
    return (
      (e =
        ((e = e.stateNode) && e.__reactInternalMemoizedMergedChildContext) ||
        Vt),
      (ln = Be.current),
      pe(Be, e),
      pe(Ye, Ye.current),
      !0
    );
  }
  function cu(e, t, n) {
    var r = e.stateNode;
    if (!r) throw Error(c(169));
    (n
      ? ((e = au(e, t, ln)),
        (r.__reactInternalMemoizedMergedChildContext = e),
        me(Ye),
        me(Be),
        pe(Be, e))
      : me(Ye),
      pe(Ye, n));
  }
  var Et = null,
    tl = !1,
    Ro = !1;
  function fu(e) {
    Et === null ? (Et = [e]) : Et.push(e);
  }
  function Ef(e) {
    ((tl = !0), fu(e));
  }
  function Qt() {
    if (!Ro && Et !== null) {
      Ro = !0;
      var e = 0,
        t = se;
      try {
        var n = Et;
        for (se = 1; e < n.length; e++) {
          var r = n[e];
          do r = r(!0);
          while (r !== null);
        }
        ((Et = null), (tl = !1));
      } catch (l) {
        throw (Et !== null && (Et = Et.slice(e + 1)), ps(bl, Qt), l);
      } finally {
        ((se = t), (Ro = !1));
      }
    }
    return null;
  }
  var Pn = [],
    Ln = 0,
    nl = null,
    rl = 0,
    st = [],
    ut = 0,
    on = null,
    _t = 1,
    Mt = "";
  function sn(e, t) {
    ((Pn[Ln++] = rl), (Pn[Ln++] = nl), (nl = e), (rl = t));
  }
  function du(e, t, n) {
    ((st[ut++] = _t), (st[ut++] = Mt), (st[ut++] = on), (on = e));
    var r = _t;
    e = Mt;
    var l = 32 - pt(r) - 1;
    ((r &= ~(1 << l)), (n += 1));
    var o = 32 - pt(t) + l;
    if (30 < o) {
      var s = l - (l % 5);
      ((o = (r & ((1 << s) - 1)).toString(32)),
        (r >>= s),
        (l -= s),
        (_t = (1 << (32 - pt(t) + l)) | (n << l) | r),
        (Mt = o + e));
    } else ((_t = (1 << o) | (n << l) | r), (Mt = e));
  }
  function To(e) {
    e.return !== null && (sn(e, 1), du(e, 1, 0));
  }
  function Oo(e) {
    for (; e === nl;)
      ((nl = Pn[--Ln]), (Pn[Ln] = null), (rl = Pn[--Ln]), (Pn[Ln] = null));
    for (; e === on;)
      ((on = st[--ut]),
        (st[ut] = null),
        (Mt = st[--ut]),
        (st[ut] = null),
        (_t = st[--ut]),
        (st[ut] = null));
  }
  var rt = null,
    lt = null,
    ve = !1,
    mt = null;
  function pu(e, t) {
    var n = dt(5, null, null, 0);
    ((n.elementType = "DELETED"),
      (n.stateNode = t),
      (n.return = e),
      (t = e.deletions),
      t === null ? ((e.deletions = [n]), (e.flags |= 16)) : t.push(n));
  }
  function hu(e, t) {
    switch (e.tag) {
      case 5:
        var n = e.type;
        return (
          (t =
            t.nodeType !== 1 || n.toLowerCase() !== t.nodeName.toLowerCase()
              ? null
              : t),
          t !== null
            ? ((e.stateNode = t), (rt = e), (lt = Ht(t.firstChild)), !0)
            : !1
        );
      case 6:
        return (
          (t = e.pendingProps === "" || t.nodeType !== 3 ? null : t),
          t !== null ? ((e.stateNode = t), (rt = e), (lt = null), !0) : !1
        );
      case 13:
        return (
          (t = t.nodeType !== 8 ? null : t),
          t !== null
            ? ((n = on !== null ? { id: _t, overflow: Mt } : null),
              (e.memoizedState = {
                dehydrated: t,
                treeContext: n,
                retryLane: 1073741824,
              }),
              (n = dt(18, null, null, 0)),
              (n.stateNode = t),
              (n.return = e),
              (e.child = n),
              (rt = e),
              (lt = null),
              !0)
            : !1
        );
      default:
        return !1;
    }
  }
  function Do(e) {
    return (e.mode & 1) !== 0 && (e.flags & 128) === 0;
  }
  function Io(e) {
    if (ve) {
      var t = lt;
      if (t) {
        var n = t;
        if (!hu(e, t)) {
          if (Do(e)) throw Error(c(418));
          t = Ht(n.nextSibling);
          var r = rt;
          t && hu(e, t)
            ? pu(r, n)
            : ((e.flags = (e.flags & -4097) | 2), (ve = !1), (rt = e));
        }
      } else {
        if (Do(e)) throw Error(c(418));
        ((e.flags = (e.flags & -4097) | 2), (ve = !1), (rt = e));
      }
    }
  }
  function mu(e) {
    for (
      e = e.return;
      e !== null && e.tag !== 5 && e.tag !== 3 && e.tag !== 13;
    )
      e = e.return;
    rt = e;
  }
  function ll(e) {
    if (e !== rt) return !1;
    if (!ve) return (mu(e), (ve = !0), !1);
    var t;
    if (
      ((t = e.tag !== 3) &&
        !(t = e.tag !== 5) &&
        ((t = e.type),
        (t = t !== "head" && t !== "body" && !_o(e.type, e.memoizedProps))),
      t && (t = lt))
    ) {
      if (Do(e)) throw (yu(), Error(c(418)));
      for (; t;) (pu(e, t), (t = Ht(t.nextSibling)));
    }
    if ((mu(e), e.tag === 13)) {
      if (((e = e.memoizedState), (e = e !== null ? e.dehydrated : null), !e))
        throw Error(c(317));
      e: {
        for (e = e.nextSibling, t = 0; e;) {
          if (e.nodeType === 8) {
            var n = e.data;
            if (n === "/$") {
              if (t === 0) {
                lt = Ht(e.nextSibling);
                break e;
              }
              t--;
            } else (n !== "$" && n !== "$!" && n !== "$?") || t++;
          }
          e = e.nextSibling;
        }
        lt = null;
      }
    } else lt = rt ? Ht(e.stateNode.nextSibling) : null;
    return !0;
  }
  function yu() {
    for (var e = lt; e;) e = Ht(e.nextSibling);
  }
  function Nn() {
    ((lt = rt = null), (ve = !1));
  }
  function Fo(e) {
    mt === null ? (mt = [e]) : mt.push(e);
  }
  var _f = oe.ReactCurrentBatchConfig;
  function dr(e, t, n) {
    if (
      ((e = n.ref),
      e !== null && typeof e != "function" && typeof e != "object")
    ) {
      if (n._owner) {
        if (((n = n._owner), n)) {
          if (n.tag !== 1) throw Error(c(309));
          var r = n.stateNode;
        }
        if (!r) throw Error(c(147, e));
        var l = r,
          o = "" + e;
        return t !== null &&
          t.ref !== null &&
          typeof t.ref == "function" &&
          t.ref._stringRef === o
          ? t.ref
          : ((t = function (s) {
              var u = l.refs;
              s === null ? delete u[o] : (u[o] = s);
            }),
            (t._stringRef = o),
            t);
      }
      if (typeof e != "string") throw Error(c(284));
      if (!n._owner) throw Error(c(290, e));
    }
    return e;
  }
  function ol(e, t) {
    throw (
      (e = Object.prototype.toString.call(t)),
      Error(
        c(
          31,
          e === "[object Object]"
            ? "object with keys {" + Object.keys(t).join(", ") + "}"
            : e,
        ),
      )
    );
  }
  function gu(e) {
    var t = e._init;
    return t(e._payload);
  }
  function vu(e) {
    function t(h, f) {
      if (e) {
        var m = h.deletions;
        m === null ? ((h.deletions = [f]), (h.flags |= 16)) : m.push(f);
      }
    }
    function n(h, f) {
      if (!e) return null;
      for (; f !== null;) (t(h, f), (f = f.sibling));
      return null;
    }
    function r(h, f) {
      for (h = new Map(); f !== null;)
        (f.key !== null ? h.set(f.key, f) : h.set(f.index, f), (f = f.sibling));
      return h;
    }
    function l(h, f) {
      return ((h = bt(h, f)), (h.index = 0), (h.sibling = null), h);
    }
    function o(h, f, m) {
      return (
        (h.index = m),
        e
          ? ((m = h.alternate),
            m !== null
              ? ((m = m.index), m < f ? ((h.flags |= 2), f) : m)
              : ((h.flags |= 2), f))
          : ((h.flags |= 1048576), f)
      );
    }
    function s(h) {
      return (e && h.alternate === null && (h.flags |= 2), h);
    }
    function u(h, f, m, z) {
      return f === null || f.tag !== 6
        ? ((f = Mi(m, h.mode, z)), (f.return = h), f)
        : ((f = l(f, m)), (f.return = h), f);
    }
    function a(h, f, m, z) {
      var O = m.type;
      return O === Y
        ? k(h, f, m.props.children, z, m.key)
        : f !== null &&
            (f.elementType === O ||
              (typeof O == "object" &&
                O !== null &&
                O.$$typeof === Se &&
                gu(O) === f.type))
          ? ((z = l(f, m.props)), (z.ref = dr(h, f, m)), (z.return = h), z)
          : ((z = Pl(m.type, m.key, m.props, null, h.mode, z)),
            (z.ref = dr(h, f, m)),
            (z.return = h),
            z);
    }
    function y(h, f, m, z) {
      return f === null ||
        f.tag !== 4 ||
        f.stateNode.containerInfo !== m.containerInfo ||
        f.stateNode.implementation !== m.implementation
        ? ((f = Pi(m, h.mode, z)), (f.return = h), f)
        : ((f = l(f, m.children || [])), (f.return = h), f);
    }
    function k(h, f, m, z, O) {
      return f === null || f.tag !== 7
        ? ((f = mn(m, h.mode, z, O)), (f.return = h), f)
        : ((f = l(f, m)), (f.return = h), f);
    }
    function j(h, f, m) {
      if ((typeof f == "string" && f !== "") || typeof f == "number")
        return ((f = Mi("" + f, h.mode, m)), (f.return = h), f);
      if (typeof f == "object" && f !== null) {
        switch (f.$$typeof) {
          case ce:
            return (
              (m = Pl(f.type, f.key, f.props, null, h.mode, m)),
              (m.ref = dr(h, null, f)),
              (m.return = h),
              m
            );
          case D:
            return ((f = Pi(f, h.mode, m)), (f.return = h), f);
          case Se:
            var z = f._init;
            return j(h, z(f._payload), m);
        }
        if ($n(f) || U(f))
          return ((f = mn(f, h.mode, m, null)), (f.return = h), f);
        ol(h, f);
      }
      return null;
    }
    function x(h, f, m, z) {
      var O = f !== null ? f.key : null;
      if ((typeof m == "string" && m !== "") || typeof m == "number")
        return O !== null ? null : u(h, f, "" + m, z);
      if (typeof m == "object" && m !== null) {
        switch (m.$$typeof) {
          case ce:
            return m.key === O ? a(h, f, m, z) : null;
          case D:
            return m.key === O ? y(h, f, m, z) : null;
          case Se:
            return ((O = m._init), x(h, f, O(m._payload), z));
        }
        if ($n(m) || U(m)) return O !== null ? null : k(h, f, m, z, null);
        ol(h, m);
      }
      return null;
    }
    function M(h, f, m, z, O) {
      if ((typeof z == "string" && z !== "") || typeof z == "number")
        return ((h = h.get(m) || null), u(f, h, "" + z, O));
      if (typeof z == "object" && z !== null) {
        switch (z.$$typeof) {
          case ce:
            return (
              (h = h.get(z.key === null ? m : z.key) || null),
              a(f, h, z, O)
            );
          case D:
            return (
              (h = h.get(z.key === null ? m : z.key) || null),
              y(f, h, z, O)
            );
          case Se:
            var I = z._init;
            return M(h, f, m, I(z._payload), O);
        }
        if ($n(z) || U(z)) return ((h = h.get(m) || null), k(f, h, z, O, null));
        ol(f, z);
      }
      return null;
    }
    function N(h, f, m, z) {
      for (
        var O = null, I = null, F = f, W = (f = 0), Ue = null;
        F !== null && W < m.length;
        W++
      ) {
        F.index > W ? ((Ue = F), (F = null)) : (Ue = F.sibling);
        var ne = x(h, F, m[W], z);
        if (ne === null) {
          F === null && (F = Ue);
          break;
        }
        (e && F && ne.alternate === null && t(h, F),
          (f = o(ne, f, W)),
          I === null ? (O = ne) : (I.sibling = ne),
          (I = ne),
          (F = Ue));
      }
      if (W === m.length) return (n(h, F), ve && sn(h, W), O);
      if (F === null) {
        for (; W < m.length; W++)
          ((F = j(h, m[W], z)),
            F !== null &&
              ((f = o(F, f, W)),
              I === null ? (O = F) : (I.sibling = F),
              (I = F)));
        return (ve && sn(h, W), O);
      }
      for (F = r(h, F); W < m.length; W++)
        ((Ue = M(F, h, W, m[W], z)),
          Ue !== null &&
            (e &&
              Ue.alternate !== null &&
              F.delete(Ue.key === null ? W : Ue.key),
            (f = o(Ue, f, W)),
            I === null ? (O = Ue) : (I.sibling = Ue),
            (I = Ue)));
      return (
        e &&
          F.forEach(function (en) {
            return t(h, en);
          }),
        ve && sn(h, W),
        O
      );
    }
    function T(h, f, m, z) {
      var O = U(m);
      if (typeof O != "function") throw Error(c(150));
      if (((m = O.call(m)), m == null)) throw Error(c(151));
      for (
        var I = (O = null), F = f, W = (f = 0), Ue = null, ne = m.next();
        F !== null && !ne.done;
        W++, ne = m.next()
      ) {
        F.index > W ? ((Ue = F), (F = null)) : (Ue = F.sibling);
        var en = x(h, F, ne.value, z);
        if (en === null) {
          F === null && (F = Ue);
          break;
        }
        (e && F && en.alternate === null && t(h, F),
          (f = o(en, f, W)),
          I === null ? (O = en) : (I.sibling = en),
          (I = en),
          (F = Ue));
      }
      if (ne.done) return (n(h, F), ve && sn(h, W), O);
      if (F === null) {
        for (; !ne.done; W++, ne = m.next())
          ((ne = j(h, ne.value, z)),
            ne !== null &&
              ((f = o(ne, f, W)),
              I === null ? (O = ne) : (I.sibling = ne),
              (I = ne)));
        return (ve && sn(h, W), O);
      }
      for (F = r(h, F); !ne.done; W++, ne = m.next())
        ((ne = M(F, h, W, ne.value, z)),
          ne !== null &&
            (e &&
              ne.alternate !== null &&
              F.delete(ne.key === null ? W : ne.key),
            (f = o(ne, f, W)),
            I === null ? (O = ne) : (I.sibling = ne),
            (I = ne)));
      return (
        e &&
          F.forEach(function (id) {
            return t(h, id);
          }),
        ve && sn(h, W),
        O
      );
    }
    function _e(h, f, m, z) {
      if (
        (typeof m == "object" &&
          m !== null &&
          m.type === Y &&
          m.key === null &&
          (m = m.props.children),
        typeof m == "object" && m !== null)
      ) {
        switch (m.$$typeof) {
          case ce:
            e: {
              for (var O = m.key, I = f; I !== null;) {
                if (I.key === O) {
                  if (((O = m.type), O === Y)) {
                    if (I.tag === 7) {
                      (n(h, I.sibling),
                        (f = l(I, m.props.children)),
                        (f.return = h),
                        (h = f));
                      break e;
                    }
                  } else if (
                    I.elementType === O ||
                    (typeof O == "object" &&
                      O !== null &&
                      O.$$typeof === Se &&
                      gu(O) === I.type)
                  ) {
                    (n(h, I.sibling),
                      (f = l(I, m.props)),
                      (f.ref = dr(h, I, m)),
                      (f.return = h),
                      (h = f));
                    break e;
                  }
                  n(h, I);
                  break;
                } else t(h, I);
                I = I.sibling;
              }
              m.type === Y
                ? ((f = mn(m.props.children, h.mode, z, m.key)),
                  (f.return = h),
                  (h = f))
                : ((z = Pl(m.type, m.key, m.props, null, h.mode, z)),
                  (z.ref = dr(h, f, m)),
                  (z.return = h),
                  (h = z));
            }
            return s(h);
          case D:
            e: {
              for (I = m.key; f !== null;) {
                if (f.key === I)
                  if (
                    f.tag === 4 &&
                    f.stateNode.containerInfo === m.containerInfo &&
                    f.stateNode.implementation === m.implementation
                  ) {
                    (n(h, f.sibling),
                      (f = l(f, m.children || [])),
                      (f.return = h),
                      (h = f));
                    break e;
                  } else {
                    n(h, f);
                    break;
                  }
                else t(h, f);
                f = f.sibling;
              }
              ((f = Pi(m, h.mode, z)), (f.return = h), (h = f));
            }
            return s(h);
          case Se:
            return ((I = m._init), _e(h, f, I(m._payload), z));
        }
        if ($n(m)) return N(h, f, m, z);
        if (U(m)) return T(h, f, m, z);
        ol(h, m);
      }
      return (typeof m == "string" && m !== "") || typeof m == "number"
        ? ((m = "" + m),
          f !== null && f.tag === 6
            ? (n(h, f.sibling), (f = l(f, m)), (f.return = h), (h = f))
            : (n(h, f), (f = Mi(m, h.mode, z)), (f.return = h), (h = f)),
          s(h))
        : n(h, f);
    }
    return _e;
  }
  var Rn = vu(!0),
    xu = vu(!1),
    il = Bt(null),
    sl = null,
    Tn = null,
    Uo = null;
  function Ao() {
    Uo = Tn = sl = null;
  }
  function Wo(e) {
    var t = il.current;
    (me(il), (e._currentValue = t));
  }
  function $o(e, t, n) {
    for (; e !== null;) {
      var r = e.alternate;
      if (
        ((e.childLanes & t) !== t
          ? ((e.childLanes |= t), r !== null && (r.childLanes |= t))
          : r !== null && (r.childLanes & t) !== t && (r.childLanes |= t),
        e === n)
      )
        break;
      e = e.return;
    }
  }
  function On(e, t) {
    ((sl = e),
      (Uo = Tn = null),
      (e = e.dependencies),
      e !== null &&
        e.firstContext !== null &&
        ((e.lanes & t) !== 0 && (qe = !0), (e.firstContext = null)));
  }
  function at(e) {
    var t = e._currentValue;
    if (Uo !== e)
      if (((e = { context: e, memoizedValue: t, next: null }), Tn === null)) {
        if (sl === null) throw Error(c(308));
        ((Tn = e), (sl.dependencies = { lanes: 0, firstContext: e }));
      } else Tn = Tn.next = e;
    return t;
  }
  var un = null;
  function Ho(e) {
    un === null ? (un = [e]) : un.push(e);
  }
  function wu(e, t, n, r) {
    var l = t.interleaved;
    return (
      l === null ? ((n.next = n), Ho(t)) : ((n.next = l.next), (l.next = n)),
      (t.interleaved = n),
      Pt(e, r)
    );
  }
  function Pt(e, t) {
    e.lanes |= t;
    var n = e.alternate;
    for (n !== null && (n.lanes |= t), n = e, e = e.return; e !== null;)
      ((e.childLanes |= t),
        (n = e.alternate),
        n !== null && (n.childLanes |= t),
        (n = e),
        (e = e.return));
    return n.tag === 3 ? n.stateNode : null;
  }
  var Zt = !1;
  function Bo(e) {
    e.updateQueue = {
      baseState: e.memoizedState,
      firstBaseUpdate: null,
      lastBaseUpdate: null,
      shared: { pending: null, interleaved: null, lanes: 0 },
      effects: null,
    };
  }
  function ku(e, t) {
    ((e = e.updateQueue),
      t.updateQueue === e &&
        (t.updateQueue = {
          baseState: e.baseState,
          firstBaseUpdate: e.firstBaseUpdate,
          lastBaseUpdate: e.lastBaseUpdate,
          shared: e.shared,
          effects: e.effects,
        }));
  }
  function Lt(e, t) {
    return {
      eventTime: e,
      lane: t,
      tag: 0,
      payload: null,
      callback: null,
      next: null,
    };
  }
  function Kt(e, t, n) {
    var r = e.updateQueue;
    if (r === null) return null;
    if (((r = r.shared), (J & 2) !== 0)) {
      var l = r.pending;
      return (
        l === null ? (t.next = t) : ((t.next = l.next), (l.next = t)),
        (r.pending = t),
        Pt(e, n)
      );
    }
    return (
      (l = r.interleaved),
      l === null ? ((t.next = t), Ho(r)) : ((t.next = l.next), (l.next = t)),
      (r.interleaved = t),
      Pt(e, n)
    );
  }
  function ul(e, t, n) {
    if (
      ((t = t.updateQueue), t !== null && ((t = t.shared), (n & 4194240) !== 0))
    ) {
      var r = t.lanes;
      ((r &= e.pendingLanes), (n |= r), (t.lanes = n), no(e, n));
    }
  }
  function Su(e, t) {
    var n = e.updateQueue,
      r = e.alternate;
    if (r !== null && ((r = r.updateQueue), n === r)) {
      var l = null,
        o = null;
      if (((n = n.firstBaseUpdate), n !== null)) {
        do {
          var s = {
            eventTime: n.eventTime,
            lane: n.lane,
            tag: n.tag,
            payload: n.payload,
            callback: n.callback,
            next: null,
          };
          (o === null ? (l = o = s) : (o = o.next = s), (n = n.next));
        } while (n !== null);
        o === null ? (l = o = t) : (o = o.next = t);
      } else l = o = t;
      ((n = {
        baseState: r.baseState,
        firstBaseUpdate: l,
        lastBaseUpdate: o,
        shared: r.shared,
        effects: r.effects,
      }),
        (e.updateQueue = n));
      return;
    }
    ((e = n.lastBaseUpdate),
      e === null ? (n.firstBaseUpdate = t) : (e.next = t),
      (n.lastBaseUpdate = t));
  }
  function al(e, t, n, r) {
    var l = e.updateQueue;
    Zt = !1;
    var o = l.firstBaseUpdate,
      s = l.lastBaseUpdate,
      u = l.shared.pending;
    if (u !== null) {
      l.shared.pending = null;
      var a = u,
        y = a.next;
      ((a.next = null), s === null ? (o = y) : (s.next = y), (s = a));
      var k = e.alternate;
      k !== null &&
        ((k = k.updateQueue),
        (u = k.lastBaseUpdate),
        u !== s &&
          (u === null ? (k.firstBaseUpdate = y) : (u.next = y),
          (k.lastBaseUpdate = a)));
    }
    if (o !== null) {
      var j = l.baseState;
      ((s = 0), (k = y = a = null), (u = o));
      do {
        var x = u.lane,
          M = u.eventTime;
        if ((r & x) === x) {
          k !== null &&
            (k = k.next =
              {
                eventTime: M,
                lane: 0,
                tag: u.tag,
                payload: u.payload,
                callback: u.callback,
                next: null,
              });
          e: {
            var N = e,
              T = u;
            switch (((x = t), (M = n), T.tag)) {
              case 1:
                if (((N = T.payload), typeof N == "function")) {
                  j = N.call(M, j, x);
                  break e;
                }
                j = N;
                break e;
              case 3:
                N.flags = (N.flags & -65537) | 128;
              case 0:
                if (
                  ((N = T.payload),
                  (x = typeof N == "function" ? N.call(M, j, x) : N),
                  x == null)
                )
                  break e;
                j = L({}, j, x);
                break e;
              case 2:
                Zt = !0;
            }
          }
          u.callback !== null &&
            u.lane !== 0 &&
            ((e.flags |= 64),
            (x = l.effects),
            x === null ? (l.effects = [u]) : x.push(u));
        } else
          ((M = {
            eventTime: M,
            lane: x,
            tag: u.tag,
            payload: u.payload,
            callback: u.callback,
            next: null,
          }),
            k === null ? ((y = k = M), (a = j)) : (k = k.next = M),
            (s |= x));
        if (((u = u.next), u === null)) {
          if (((u = l.shared.pending), u === null)) break;
          ((x = u),
            (u = x.next),
            (x.next = null),
            (l.lastBaseUpdate = x),
            (l.shared.pending = null));
        }
      } while (!0);
      if (
        (k === null && (a = j),
        (l.baseState = a),
        (l.firstBaseUpdate = y),
        (l.lastBaseUpdate = k),
        (t = l.shared.interleaved),
        t !== null)
      ) {
        l = t;
        do ((s |= l.lane), (l = l.next));
        while (l !== t);
      } else o === null && (l.shared.lanes = 0);
      ((fn |= s), (e.lanes = s), (e.memoizedState = j));
    }
  }
  function ju(e, t, n) {
    if (((e = t.effects), (t.effects = null), e !== null))
      for (t = 0; t < e.length; t++) {
        var r = e[t],
          l = r.callback;
        if (l !== null) {
          if (((r.callback = null), (r = n), typeof l != "function"))
            throw Error(c(191, l));
          l.call(r);
        }
      }
  }
  var pr = {},
    St = Bt(pr),
    hr = Bt(pr),
    mr = Bt(pr);
  function an(e) {
    if (e === pr) throw Error(c(174));
    return e;
  }
  function Vo(e, t) {
    switch ((pe(mr, t), pe(hr, e), pe(St, pr), (e = t.nodeType), e)) {
      case 9:
      case 11:
        t = (t = t.documentElement) ? t.namespaceURI : Vl(null, "");
        break;
      default:
        ((e = e === 8 ? t.parentNode : t),
          (t = e.namespaceURI || null),
          (e = e.tagName),
          (t = Vl(t, e)));
    }
    (me(St), pe(St, t));
  }
  function Dn() {
    (me(St), me(hr), me(mr));
  }
  function zu(e) {
    an(mr.current);
    var t = an(St.current),
      n = Vl(t, e.type);
    t !== n && (pe(hr, e), pe(St, n));
  }
  function Qo(e) {
    hr.current === e && (me(St), me(hr));
  }
  var we = Bt(0);
  function cl(e) {
    for (var t = e; t !== null;) {
      if (t.tag === 13) {
        var n = t.memoizedState;
        if (
          n !== null &&
          ((n = n.dehydrated), n === null || n.data === "$?" || n.data === "$!")
        )
          return t;
      } else if (t.tag === 19 && t.memoizedProps.revealOrder !== void 0) {
        if ((t.flags & 128) !== 0) return t;
      } else if (t.child !== null) {
        ((t.child.return = t), (t = t.child));
        continue;
      }
      if (t === e) break;
      for (; t.sibling === null;) {
        if (t.return === null || t.return === e) return null;
        t = t.return;
      }
      ((t.sibling.return = t.return), (t = t.sibling));
    }
    return null;
  }
  var Zo = [];
  function Ko() {
    for (var e = 0; e < Zo.length; e++)
      Zo[e]._workInProgressVersionPrimary = null;
    Zo.length = 0;
  }
  var fl = oe.ReactCurrentDispatcher,
    Go = oe.ReactCurrentBatchConfig,
    cn = 0,
    ke = null,
    Re = null,
    Ie = null,
    dl = !1,
    yr = !1,
    gr = 0,
    Mf = 0;
  function Ve() {
    throw Error(c(321));
  }
  function Yo(e, t) {
    if (t === null) return !1;
    for (var n = 0; n < t.length && n < e.length; n++)
      if (!ht(e[n], t[n])) return !1;
    return !0;
  }
  function Xo(e, t, n, r, l, o) {
    if (
      ((cn = o),
      (ke = t),
      (t.memoizedState = null),
      (t.updateQueue = null),
      (t.lanes = 0),
      (fl.current = e === null || e.memoizedState === null ? Rf : Tf),
      (e = n(r, l)),
      yr)
    ) {
      o = 0;
      do {
        if (((yr = !1), (gr = 0), 25 <= o)) throw Error(c(301));
        ((o += 1),
          (Ie = Re = null),
          (t.updateQueue = null),
          (fl.current = Of),
          (e = n(r, l)));
      } while (yr);
    }
    if (
      ((fl.current = ml),
      (t = Re !== null && Re.next !== null),
      (cn = 0),
      (Ie = Re = ke = null),
      (dl = !1),
      t)
    )
      throw Error(c(300));
    return e;
  }
  function qo() {
    var e = gr !== 0;
    return ((gr = 0), e);
  }
  function jt() {
    var e = {
      memoizedState: null,
      baseState: null,
      baseQueue: null,
      queue: null,
      next: null,
    };
    return (Ie === null ? (ke.memoizedState = Ie = e) : (Ie = Ie.next = e), Ie);
  }
  function ct() {
    if (Re === null) {
      var e = ke.alternate;
      e = e !== null ? e.memoizedState : null;
    } else e = Re.next;
    var t = Ie === null ? ke.memoizedState : Ie.next;
    if (t !== null) ((Ie = t), (Re = e));
    else {
      if (e === null) throw Error(c(310));
      ((Re = e),
        (e = {
          memoizedState: Re.memoizedState,
          baseState: Re.baseState,
          baseQueue: Re.baseQueue,
          queue: Re.queue,
          next: null,
        }),
        Ie === null ? (ke.memoizedState = Ie = e) : (Ie = Ie.next = e));
    }
    return Ie;
  }
  function vr(e, t) {
    return typeof t == "function" ? t(e) : t;
  }
  function Jo(e) {
    var t = ct(),
      n = t.queue;
    if (n === null) throw Error(c(311));
    n.lastRenderedReducer = e;
    var r = Re,
      l = r.baseQueue,
      o = n.pending;
    if (o !== null) {
      if (l !== null) {
        var s = l.next;
        ((l.next = o.next), (o.next = s));
      }
      ((r.baseQueue = l = o), (n.pending = null));
    }
    if (l !== null) {
      ((o = l.next), (r = r.baseState));
      var u = (s = null),
        a = null,
        y = o;
      do {
        var k = y.lane;
        if ((cn & k) === k)
          (a !== null &&
            (a = a.next =
              {
                lane: 0,
                action: y.action,
                hasEagerState: y.hasEagerState,
                eagerState: y.eagerState,
                next: null,
              }),
            (r = y.hasEagerState ? y.eagerState : e(r, y.action)));
        else {
          var j = {
            lane: k,
            action: y.action,
            hasEagerState: y.hasEagerState,
            eagerState: y.eagerState,
            next: null,
          };
          (a === null ? ((u = a = j), (s = r)) : (a = a.next = j),
            (ke.lanes |= k),
            (fn |= k));
        }
        y = y.next;
      } while (y !== null && y !== o);
      (a === null ? (s = r) : (a.next = u),
        ht(r, t.memoizedState) || (qe = !0),
        (t.memoizedState = r),
        (t.baseState = s),
        (t.baseQueue = a),
        (n.lastRenderedState = r));
    }
    if (((e = n.interleaved), e !== null)) {
      l = e;
      do ((o = l.lane), (ke.lanes |= o), (fn |= o), (l = l.next));
      while (l !== e);
    } else l === null && (n.lanes = 0);
    return [t.memoizedState, n.dispatch];
  }
  function bo(e) {
    var t = ct(),
      n = t.queue;
    if (n === null) throw Error(c(311));
    n.lastRenderedReducer = e;
    var r = n.dispatch,
      l = n.pending,
      o = t.memoizedState;
    if (l !== null) {
      n.pending = null;
      var s = (l = l.next);
      do ((o = e(o, s.action)), (s = s.next));
      while (s !== l);
      (ht(o, t.memoizedState) || (qe = !0),
        (t.memoizedState = o),
        t.baseQueue === null && (t.baseState = o),
        (n.lastRenderedState = o));
    }
    return [o, r];
  }
  function Cu() {}
  function Eu(e, t) {
    var n = ke,
      r = ct(),
      l = t(),
      o = !ht(r.memoizedState, l);
    if (
      (o && ((r.memoizedState = l), (qe = !0)),
      (r = r.queue),
      ei(Pu.bind(null, n, r, e), [e]),
      r.getSnapshot !== t || o || (Ie !== null && Ie.memoizedState.tag & 1))
    ) {
      if (
        ((n.flags |= 2048),
        xr(9, Mu.bind(null, n, r, l, t), void 0, null),
        Fe === null)
      )
        throw Error(c(349));
      (cn & 30) !== 0 || _u(n, t, l);
    }
    return l;
  }
  function _u(e, t, n) {
    ((e.flags |= 16384),
      (e = { getSnapshot: t, value: n }),
      (t = ke.updateQueue),
      t === null
        ? ((t = { lastEffect: null, stores: null }),
          (ke.updateQueue = t),
          (t.stores = [e]))
        : ((n = t.stores), n === null ? (t.stores = [e]) : n.push(e)));
  }
  function Mu(e, t, n, r) {
    ((t.value = n), (t.getSnapshot = r), Lu(t) && Nu(e));
  }
  function Pu(e, t, n) {
    return n(function () {
      Lu(t) && Nu(e);
    });
  }
  function Lu(e) {
    var t = e.getSnapshot;
    e = e.value;
    try {
      var n = t();
      return !ht(e, n);
    } catch {
      return !0;
    }
  }
  function Nu(e) {
    var t = Pt(e, 1);
    t !== null && xt(t, e, 1, -1);
  }
  function Ru(e) {
    var t = jt();
    return (
      typeof e == "function" && (e = e()),
      (t.memoizedState = t.baseState = e),
      (e = {
        pending: null,
        interleaved: null,
        lanes: 0,
        dispatch: null,
        lastRenderedReducer: vr,
        lastRenderedState: e,
      }),
      (t.queue = e),
      (e = e.dispatch = Nf.bind(null, ke, e)),
      [t.memoizedState, e]
    );
  }
  function xr(e, t, n, r) {
    return (
      (e = { tag: e, create: t, destroy: n, deps: r, next: null }),
      (t = ke.updateQueue),
      t === null
        ? ((t = { lastEffect: null, stores: null }),
          (ke.updateQueue = t),
          (t.lastEffect = e.next = e))
        : ((n = t.lastEffect),
          n === null
            ? (t.lastEffect = e.next = e)
            : ((r = n.next), (n.next = e), (e.next = r), (t.lastEffect = e))),
      e
    );
  }
  function Tu() {
    return ct().memoizedState;
  }
  function pl(e, t, n, r) {
    var l = jt();
    ((ke.flags |= e),
      (l.memoizedState = xr(1 | t, n, void 0, r === void 0 ? null : r)));
  }
  function hl(e, t, n, r) {
    var l = ct();
    r = r === void 0 ? null : r;
    var o = void 0;
    if (Re !== null) {
      var s = Re.memoizedState;
      if (((o = s.destroy), r !== null && Yo(r, s.deps))) {
        l.memoizedState = xr(t, n, o, r);
        return;
      }
    }
    ((ke.flags |= e), (l.memoizedState = xr(1 | t, n, o, r)));
  }
  function Ou(e, t) {
    return pl(8390656, 8, e, t);
  }
  function ei(e, t) {
    return hl(2048, 8, e, t);
  }
  function Du(e, t) {
    return hl(4, 2, e, t);
  }
  function Iu(e, t) {
    return hl(4, 4, e, t);
  }
  function Fu(e, t) {
    if (typeof t == "function")
      return (
        (e = e()),
        t(e),
        function () {
          t(null);
        }
      );
    if (t != null)
      return (
        (e = e()),
        (t.current = e),
        function () {
          t.current = null;
        }
      );
  }
  function Uu(e, t, n) {
    return (
      (n = n != null ? n.concat([e]) : null),
      hl(4, 4, Fu.bind(null, t, e), n)
    );
  }
  function ti() {}
  function Au(e, t) {
    var n = ct();
    t = t === void 0 ? null : t;
    var r = n.memoizedState;
    return r !== null && t !== null && Yo(t, r[1])
      ? r[0]
      : ((n.memoizedState = [e, t]), e);
  }
  function Wu(e, t) {
    var n = ct();
    t = t === void 0 ? null : t;
    var r = n.memoizedState;
    return r !== null && t !== null && Yo(t, r[1])
      ? r[0]
      : ((e = e()), (n.memoizedState = [e, t]), e);
  }
  function $u(e, t, n) {
    return (cn & 21) === 0
      ? (e.baseState && ((e.baseState = !1), (qe = !0)), (e.memoizedState = n))
      : (ht(n, t) ||
          ((n = gs()), (ke.lanes |= n), (fn |= n), (e.baseState = !0)),
        t);
  }
  function Pf(e, t) {
    var n = se;
    ((se = n !== 0 && 4 > n ? n : 4), e(!0));
    var r = Go.transition;
    Go.transition = {};
    try {
      (e(!1), t());
    } finally {
      ((se = n), (Go.transition = r));
    }
  }
  function Hu() {
    return ct().memoizedState;
  }
  function Lf(e, t, n) {
    var r = qt(e);
    if (
      ((n = {
        lane: r,
        action: n,
        hasEagerState: !1,
        eagerState: null,
        next: null,
      }),
      Bu(e))
    )
      Vu(t, n);
    else if (((n = wu(e, t, n, r)), n !== null)) {
      var l = Ge();
      (xt(n, e, r, l), Qu(n, t, r));
    }
  }
  function Nf(e, t, n) {
    var r = qt(e),
      l = {
        lane: r,
        action: n,
        hasEagerState: !1,
        eagerState: null,
        next: null,
      };
    if (Bu(e)) Vu(t, l);
    else {
      var o = e.alternate;
      if (
        e.lanes === 0 &&
        (o === null || o.lanes === 0) &&
        ((o = t.lastRenderedReducer), o !== null)
      )
        try {
          var s = t.lastRenderedState,
            u = o(s, n);
          if (((l.hasEagerState = !0), (l.eagerState = u), ht(u, s))) {
            var a = t.interleaved;
            (a === null
              ? ((l.next = l), Ho(t))
              : ((l.next = a.next), (a.next = l)),
              (t.interleaved = l));
            return;
          }
        } catch {
        } finally {
        }
      ((n = wu(e, t, l, r)),
        n !== null && ((l = Ge()), xt(n, e, r, l), Qu(n, t, r)));
    }
  }
  function Bu(e) {
    var t = e.alternate;
    return e === ke || (t !== null && t === ke);
  }
  function Vu(e, t) {
    yr = dl = !0;
    var n = e.pending;
    (n === null ? (t.next = t) : ((t.next = n.next), (n.next = t)),
      (e.pending = t));
  }
  function Qu(e, t, n) {
    if ((n & 4194240) !== 0) {
      var r = t.lanes;
      ((r &= e.pendingLanes), (n |= r), (t.lanes = n), no(e, n));
    }
  }
  var ml = {
      readContext: at,
      useCallback: Ve,
      useContext: Ve,
      useEffect: Ve,
      useImperativeHandle: Ve,
      useInsertionEffect: Ve,
      useLayoutEffect: Ve,
      useMemo: Ve,
      useReducer: Ve,
      useRef: Ve,
      useState: Ve,
      useDebugValue: Ve,
      useDeferredValue: Ve,
      useTransition: Ve,
      useMutableSource: Ve,
      useSyncExternalStore: Ve,
      useId: Ve,
      unstable_isNewReconciler: !1,
    },
    Rf = {
      readContext: at,
      useCallback: function (e, t) {
        return ((jt().memoizedState = [e, t === void 0 ? null : t]), e);
      },
      useContext: at,
      useEffect: Ou,
      useImperativeHandle: function (e, t, n) {
        return (
          (n = n != null ? n.concat([e]) : null),
          pl(4194308, 4, Fu.bind(null, t, e), n)
        );
      },
      useLayoutEffect: function (e, t) {
        return pl(4194308, 4, e, t);
      },
      useInsertionEffect: function (e, t) {
        return pl(4, 2, e, t);
      },
      useMemo: function (e, t) {
        var n = jt();
        return (
          (t = t === void 0 ? null : t),
          (e = e()),
          (n.memoizedState = [e, t]),
          e
        );
      },
      useReducer: function (e, t, n) {
        var r = jt();
        return (
          (t = n !== void 0 ? n(t) : t),
          (r.memoizedState = r.baseState = t),
          (e = {
            pending: null,
            interleaved: null,
            lanes: 0,
            dispatch: null,
            lastRenderedReducer: e,
            lastRenderedState: t,
          }),
          (r.queue = e),
          (e = e.dispatch = Lf.bind(null, ke, e)),
          [r.memoizedState, e]
        );
      },
      useRef: function (e) {
        var t = jt();
        return ((e = { current: e }), (t.memoizedState = e));
      },
      useState: Ru,
      useDebugValue: ti,
      useDeferredValue: function (e) {
        return (jt().memoizedState = e);
      },
      useTransition: function () {
        var e = Ru(!1),
          t = e[0];
        return ((e = Pf.bind(null, e[1])), (jt().memoizedState = e), [t, e]);
      },
      useMutableSource: function () {},
      useSyncExternalStore: function (e, t, n) {
        var r = ke,
          l = jt();
        if (ve) {
          if (n === void 0) throw Error(c(407));
          n = n();
        } else {
          if (((n = t()), Fe === null)) throw Error(c(349));
          (cn & 30) !== 0 || _u(r, t, n);
        }
        l.memoizedState = n;
        var o = { value: n, getSnapshot: t };
        return (
          (l.queue = o),
          Ou(Pu.bind(null, r, o, e), [e]),
          (r.flags |= 2048),
          xr(9, Mu.bind(null, r, o, n, t), void 0, null),
          n
        );
      },
      useId: function () {
        var e = jt(),
          t = Fe.identifierPrefix;
        if (ve) {
          var n = Mt,
            r = _t;
          ((n = (r & ~(1 << (32 - pt(r) - 1))).toString(32) + n),
            (t = ":" + t + "R" + n),
            (n = gr++),
            0 < n && (t += "H" + n.toString(32)),
            (t += ":"));
        } else ((n = Mf++), (t = ":" + t + "r" + n.toString(32) + ":"));
        return (e.memoizedState = t);
      },
      unstable_isNewReconciler: !1,
    },
    Tf = {
      readContext: at,
      useCallback: Au,
      useContext: at,
      useEffect: ei,
      useImperativeHandle: Uu,
      useInsertionEffect: Du,
      useLayoutEffect: Iu,
      useMemo: Wu,
      useReducer: Jo,
      useRef: Tu,
      useState: function () {
        return Jo(vr);
      },
      useDebugValue: ti,
      useDeferredValue: function (e) {
        var t = ct();
        return $u(t, Re.memoizedState, e);
      },
      useTransition: function () {
        var e = Jo(vr)[0],
          t = ct().memoizedState;
        return [e, t];
      },
      useMutableSource: Cu,
      useSyncExternalStore: Eu,
      useId: Hu,
      unstable_isNewReconciler: !1,
    },
    Of = {
      readContext: at,
      useCallback: Au,
      useContext: at,
      useEffect: ei,
      useImperativeHandle: Uu,
      useInsertionEffect: Du,
      useLayoutEffect: Iu,
      useMemo: Wu,
      useReducer: bo,
      useRef: Tu,
      useState: function () {
        return bo(vr);
      },
      useDebugValue: ti,
      useDeferredValue: function (e) {
        var t = ct();
        return Re === null ? (t.memoizedState = e) : $u(t, Re.memoizedState, e);
      },
      useTransition: function () {
        var e = bo(vr)[0],
          t = ct().memoizedState;
        return [e, t];
      },
      useMutableSource: Cu,
      useSyncExternalStore: Eu,
      useId: Hu,
      unstable_isNewReconciler: !1,
    };
  function yt(e, t) {
    if (e && e.defaultProps) {
      ((t = L({}, t)), (e = e.defaultProps));
      for (var n in e) t[n] === void 0 && (t[n] = e[n]);
      return t;
    }
    return t;
  }
  function ni(e, t, n, r) {
    ((t = e.memoizedState),
      (n = n(r, t)),
      (n = n == null ? t : L({}, t, n)),
      (e.memoizedState = n),
      e.lanes === 0 && (e.updateQueue.baseState = n));
  }
  var yl = {
    isMounted: function (e) {
      return (e = e._reactInternals) ? nn(e) === e : !1;
    },
    enqueueSetState: function (e, t, n) {
      e = e._reactInternals;
      var r = Ge(),
        l = qt(e),
        o = Lt(r, l);
      ((o.payload = t),
        n != null && (o.callback = n),
        (t = Kt(e, o, l)),
        t !== null && (xt(t, e, l, r), ul(t, e, l)));
    },
    enqueueReplaceState: function (e, t, n) {
      e = e._reactInternals;
      var r = Ge(),
        l = qt(e),
        o = Lt(r, l);
      ((o.tag = 1),
        (o.payload = t),
        n != null && (o.callback = n),
        (t = Kt(e, o, l)),
        t !== null && (xt(t, e, l, r), ul(t, e, l)));
    },
    enqueueForceUpdate: function (e, t) {
      e = e._reactInternals;
      var n = Ge(),
        r = qt(e),
        l = Lt(n, r);
      ((l.tag = 2),
        t != null && (l.callback = t),
        (t = Kt(e, l, r)),
        t !== null && (xt(t, e, r, n), ul(t, e, r)));
    },
  };
  function Zu(e, t, n, r, l, o, s) {
    return (
      (e = e.stateNode),
      typeof e.shouldComponentUpdate == "function"
        ? e.shouldComponentUpdate(r, o, s)
        : t.prototype && t.prototype.isPureReactComponent
          ? !or(n, r) || !or(l, o)
          : !0
    );
  }
  function Ku(e, t, n) {
    var r = !1,
      l = Vt,
      o = t.contextType;
    return (
      typeof o == "object" && o !== null
        ? (o = at(o))
        : ((l = Xe(t) ? ln : Be.current),
          (r = t.contextTypes),
          (o = (r = r != null) ? Mn(e, l) : Vt)),
      (t = new t(n, o)),
      (e.memoizedState =
        t.state !== null && t.state !== void 0 ? t.state : null),
      (t.updater = yl),
      (e.stateNode = t),
      (t._reactInternals = e),
      r &&
        ((e = e.stateNode),
        (e.__reactInternalMemoizedUnmaskedChildContext = l),
        (e.__reactInternalMemoizedMaskedChildContext = o)),
      t
    );
  }
  function Gu(e, t, n, r) {
    ((e = t.state),
      typeof t.componentWillReceiveProps == "function" &&
        t.componentWillReceiveProps(n, r),
      typeof t.UNSAFE_componentWillReceiveProps == "function" &&
        t.UNSAFE_componentWillReceiveProps(n, r),
      t.state !== e && yl.enqueueReplaceState(t, t.state, null));
  }
  function ri(e, t, n, r) {
    var l = e.stateNode;
    ((l.props = n), (l.state = e.memoizedState), (l.refs = {}), Bo(e));
    var o = t.contextType;
    (typeof o == "object" && o !== null
      ? (l.context = at(o))
      : ((o = Xe(t) ? ln : Be.current), (l.context = Mn(e, o))),
      (l.state = e.memoizedState),
      (o = t.getDerivedStateFromProps),
      typeof o == "function" && (ni(e, t, o, n), (l.state = e.memoizedState)),
      typeof t.getDerivedStateFromProps == "function" ||
        typeof l.getSnapshotBeforeUpdate == "function" ||
        (typeof l.UNSAFE_componentWillMount != "function" &&
          typeof l.componentWillMount != "function") ||
        ((t = l.state),
        typeof l.componentWillMount == "function" && l.componentWillMount(),
        typeof l.UNSAFE_componentWillMount == "function" &&
          l.UNSAFE_componentWillMount(),
        t !== l.state && yl.enqueueReplaceState(l, l.state, null),
        al(e, n, l, r),
        (l.state = e.memoizedState)),
      typeof l.componentDidMount == "function" && (e.flags |= 4194308));
  }
  function In(e, t) {
    try {
      var n = "",
        r = t;
      do ((n += ee(r)), (r = r.return));
      while (r);
      var l = n;
    } catch (o) {
      l =
        `
Error generating stack: ` +
        o.message +
        `
` +
        o.stack;
    }
    return { value: e, source: t, stack: l, digest: null };
  }
  function li(e, t, n) {
    return { value: e, source: null, stack: n ?? null, digest: t ?? null };
  }
  function oi(e, t) {
    try {
      console.error(t.value);
    } catch (n) {
      setTimeout(function () {
        throw n;
      });
    }
  }
  var Df = typeof WeakMap == "function" ? WeakMap : Map;
  function Yu(e, t, n) {
    ((n = Lt(-1, n)), (n.tag = 3), (n.payload = { element: null }));
    var r = t.value;
    return (
      (n.callback = function () {
        (jl || ((jl = !0), (wi = r)), oi(e, t));
      }),
      n
    );
  }
  function Xu(e, t, n) {
    ((n = Lt(-1, n)), (n.tag = 3));
    var r = e.type.getDerivedStateFromError;
    if (typeof r == "function") {
      var l = t.value;
      ((n.payload = function () {
        return r(l);
      }),
        (n.callback = function () {
          oi(e, t);
        }));
    }
    var o = e.stateNode;
    return (
      o !== null &&
        typeof o.componentDidCatch == "function" &&
        (n.callback = function () {
          (oi(e, t),
            typeof r != "function" &&
              (Yt === null ? (Yt = new Set([this])) : Yt.add(this)));
          var s = t.stack;
          this.componentDidCatch(t.value, {
            componentStack: s !== null ? s : "",
          });
        }),
      n
    );
  }
  function qu(e, t, n) {
    var r = e.pingCache;
    if (r === null) {
      r = e.pingCache = new Df();
      var l = new Set();
      r.set(t, l);
    } else ((l = r.get(t)), l === void 0 && ((l = new Set()), r.set(t, l)));
    l.has(n) || (l.add(n), (e = Yf.bind(null, e, t, n)), t.then(e, e));
  }
  function Ju(e) {
    do {
      var t;
      if (
        ((t = e.tag === 13) &&
          ((t = e.memoizedState),
          (t = t !== null ? t.dehydrated !== null : !0)),
        t)
      )
        return e;
      e = e.return;
    } while (e !== null);
    return null;
  }
  function bu(e, t, n, r, l) {
    return (e.mode & 1) === 0
      ? (e === t
          ? (e.flags |= 65536)
          : ((e.flags |= 128),
            (n.flags |= 131072),
            (n.flags &= -52805),
            n.tag === 1 &&
              (n.alternate === null
                ? (n.tag = 17)
                : ((t = Lt(-1, 1)), (t.tag = 2), Kt(n, t, 1))),
            (n.lanes |= 1)),
        e)
      : ((e.flags |= 65536), (e.lanes = l), e);
  }
  var If = oe.ReactCurrentOwner,
    qe = !1;
  function Ke(e, t, n, r) {
    t.child = e === null ? xu(t, null, n, r) : Rn(t, e.child, n, r);
  }
  function ea(e, t, n, r, l) {
    n = n.render;
    var o = t.ref;
    return (
      On(t, l),
      (r = Xo(e, t, n, r, o, l)),
      (n = qo()),
      e !== null && !qe
        ? ((t.updateQueue = e.updateQueue),
          (t.flags &= -2053),
          (e.lanes &= ~l),
          Nt(e, t, l))
        : (ve && n && To(t), (t.flags |= 1), Ke(e, t, r, l), t.child)
    );
  }
  function ta(e, t, n, r, l) {
    if (e === null) {
      var o = n.type;
      return typeof o == "function" &&
        !_i(o) &&
        o.defaultProps === void 0 &&
        n.compare === null &&
        n.defaultProps === void 0
        ? ((t.tag = 15), (t.type = o), na(e, t, o, r, l))
        : ((e = Pl(n.type, null, r, t, t.mode, l)),
          (e.ref = t.ref),
          (e.return = t),
          (t.child = e));
    }
    if (((o = e.child), (e.lanes & l) === 0)) {
      var s = o.memoizedProps;
      if (
        ((n = n.compare), (n = n !== null ? n : or), n(s, r) && e.ref === t.ref)
      )
        return Nt(e, t, l);
    }
    return (
      (t.flags |= 1),
      (e = bt(o, r)),
      (e.ref = t.ref),
      (e.return = t),
      (t.child = e)
    );
  }
  function na(e, t, n, r, l) {
    if (e !== null) {
      var o = e.memoizedProps;
      if (or(o, r) && e.ref === t.ref)
        if (((qe = !1), (t.pendingProps = r = o), (e.lanes & l) !== 0))
          (e.flags & 131072) !== 0 && (qe = !0);
        else return ((t.lanes = e.lanes), Nt(e, t, l));
    }
    return ii(e, t, n, r, l);
  }
  function ra(e, t, n) {
    var r = t.pendingProps,
      l = r.children,
      o = e !== null ? e.memoizedState : null;
    if (r.mode === "hidden")
      if ((t.mode & 1) === 0)
        ((t.memoizedState = {
          baseLanes: 0,
          cachePool: null,
          transitions: null,
        }),
          pe(Un, ot),
          (ot |= n));
      else {
        if ((n & 1073741824) === 0)
          return (
            (e = o !== null ? o.baseLanes | n : n),
            (t.lanes = t.childLanes = 1073741824),
            (t.memoizedState = {
              baseLanes: e,
              cachePool: null,
              transitions: null,
            }),
            (t.updateQueue = null),
            pe(Un, ot),
            (ot |= e),
            null
          );
        ((t.memoizedState = {
          baseLanes: 0,
          cachePool: null,
          transitions: null,
        }),
          (r = o !== null ? o.baseLanes : n),
          pe(Un, ot),
          (ot |= r));
      }
    else
      (o !== null ? ((r = o.baseLanes | n), (t.memoizedState = null)) : (r = n),
        pe(Un, ot),
        (ot |= r));
    return (Ke(e, t, l, n), t.child);
  }
  function la(e, t) {
    var n = t.ref;
    ((e === null && n !== null) || (e !== null && e.ref !== n)) &&
      ((t.flags |= 512), (t.flags |= 2097152));
  }
  function ii(e, t, n, r, l) {
    var o = Xe(n) ? ln : Be.current;
    return (
      (o = Mn(t, o)),
      On(t, l),
      (n = Xo(e, t, n, r, o, l)),
      (r = qo()),
      e !== null && !qe
        ? ((t.updateQueue = e.updateQueue),
          (t.flags &= -2053),
          (e.lanes &= ~l),
          Nt(e, t, l))
        : (ve && r && To(t), (t.flags |= 1), Ke(e, t, n, l), t.child)
    );
  }
  function oa(e, t, n, r, l) {
    if (Xe(n)) {
      var o = !0;
      el(t);
    } else o = !1;
    if ((On(t, l), t.stateNode === null))
      (vl(e, t), Ku(t, n, r), ri(t, n, r, l), (r = !0));
    else if (e === null) {
      var s = t.stateNode,
        u = t.memoizedProps;
      s.props = u;
      var a = s.context,
        y = n.contextType;
      typeof y == "object" && y !== null
        ? (y = at(y))
        : ((y = Xe(n) ? ln : Be.current), (y = Mn(t, y)));
      var k = n.getDerivedStateFromProps,
        j =
          typeof k == "function" ||
          typeof s.getSnapshotBeforeUpdate == "function";
      (j ||
        (typeof s.UNSAFE_componentWillReceiveProps != "function" &&
          typeof s.componentWillReceiveProps != "function") ||
        ((u !== r || a !== y) && Gu(t, s, r, y)),
        (Zt = !1));
      var x = t.memoizedState;
      ((s.state = x),
        al(t, r, s, l),
        (a = t.memoizedState),
        u !== r || x !== a || Ye.current || Zt
          ? (typeof k == "function" && (ni(t, n, k, r), (a = t.memoizedState)),
            (u = Zt || Zu(t, n, u, r, x, a, y))
              ? (j ||
                  (typeof s.UNSAFE_componentWillMount != "function" &&
                    typeof s.componentWillMount != "function") ||
                  (typeof s.componentWillMount == "function" &&
                    s.componentWillMount(),
                  typeof s.UNSAFE_componentWillMount == "function" &&
                    s.UNSAFE_componentWillMount()),
                typeof s.componentDidMount == "function" &&
                  (t.flags |= 4194308))
              : (typeof s.componentDidMount == "function" &&
                  (t.flags |= 4194308),
                (t.memoizedProps = r),
                (t.memoizedState = a)),
            (s.props = r),
            (s.state = a),
            (s.context = y),
            (r = u))
          : (typeof s.componentDidMount == "function" && (t.flags |= 4194308),
            (r = !1)));
    } else {
      ((s = t.stateNode),
        ku(e, t),
        (u = t.memoizedProps),
        (y = t.type === t.elementType ? u : yt(t.type, u)),
        (s.props = y),
        (j = t.pendingProps),
        (x = s.context),
        (a = n.contextType),
        typeof a == "object" && a !== null
          ? (a = at(a))
          : ((a = Xe(n) ? ln : Be.current), (a = Mn(t, a))));
      var M = n.getDerivedStateFromProps;
      ((k =
        typeof M == "function" ||
        typeof s.getSnapshotBeforeUpdate == "function") ||
        (typeof s.UNSAFE_componentWillReceiveProps != "function" &&
          typeof s.componentWillReceiveProps != "function") ||
        ((u !== j || x !== a) && Gu(t, s, r, a)),
        (Zt = !1),
        (x = t.memoizedState),
        (s.state = x),
        al(t, r, s, l));
      var N = t.memoizedState;
      u !== j || x !== N || Ye.current || Zt
        ? (typeof M == "function" && (ni(t, n, M, r), (N = t.memoizedState)),
          (y = Zt || Zu(t, n, y, r, x, N, a) || !1)
            ? (k ||
                (typeof s.UNSAFE_componentWillUpdate != "function" &&
                  typeof s.componentWillUpdate != "function") ||
                (typeof s.componentWillUpdate == "function" &&
                  s.componentWillUpdate(r, N, a),
                typeof s.UNSAFE_componentWillUpdate == "function" &&
                  s.UNSAFE_componentWillUpdate(r, N, a)),
              typeof s.componentDidUpdate == "function" && (t.flags |= 4),
              typeof s.getSnapshotBeforeUpdate == "function" &&
                (t.flags |= 1024))
            : (typeof s.componentDidUpdate != "function" ||
                (u === e.memoizedProps && x === e.memoizedState) ||
                (t.flags |= 4),
              typeof s.getSnapshotBeforeUpdate != "function" ||
                (u === e.memoizedProps && x === e.memoizedState) ||
                (t.flags |= 1024),
              (t.memoizedProps = r),
              (t.memoizedState = N)),
          (s.props = r),
          (s.state = N),
          (s.context = a),
          (r = y))
        : (typeof s.componentDidUpdate != "function" ||
            (u === e.memoizedProps && x === e.memoizedState) ||
            (t.flags |= 4),
          typeof s.getSnapshotBeforeUpdate != "function" ||
            (u === e.memoizedProps && x === e.memoizedState) ||
            (t.flags |= 1024),
          (r = !1));
    }
    return si(e, t, n, r, o, l);
  }
  function si(e, t, n, r, l, o) {
    la(e, t);
    var s = (t.flags & 128) !== 0;
    if (!r && !s) return (l && cu(t, n, !1), Nt(e, t, o));
    ((r = t.stateNode), (If.current = t));
    var u =
      s && typeof n.getDerivedStateFromError != "function" ? null : r.render();
    return (
      (t.flags |= 1),
      e !== null && s
        ? ((t.child = Rn(t, e.child, null, o)), (t.child = Rn(t, null, u, o)))
        : Ke(e, t, u, o),
      (t.memoizedState = r.state),
      l && cu(t, n, !0),
      t.child
    );
  }
  function ia(e) {
    var t = e.stateNode;
    (t.pendingContext
      ? uu(e, t.pendingContext, t.pendingContext !== t.context)
      : t.context && uu(e, t.context, !1),
      Vo(e, t.containerInfo));
  }
  function sa(e, t, n, r, l) {
    return (Nn(), Fo(l), (t.flags |= 256), Ke(e, t, n, r), t.child);
  }
  var ui = { dehydrated: null, treeContext: null, retryLane: 0 };
  function ai(e) {
    return { baseLanes: e, cachePool: null, transitions: null };
  }
  function ua(e, t, n) {
    var r = t.pendingProps,
      l = we.current,
      o = !1,
      s = (t.flags & 128) !== 0,
      u;
    if (
      ((u = s) ||
        (u = e !== null && e.memoizedState === null ? !1 : (l & 2) !== 0),
      u
        ? ((o = !0), (t.flags &= -129))
        : (e === null || e.memoizedState !== null) && (l |= 1),
      pe(we, l & 1),
      e === null)
    )
      return (
        Io(t),
        (e = t.memoizedState),
        e !== null && ((e = e.dehydrated), e !== null)
          ? ((t.mode & 1) === 0
              ? (t.lanes = 1)
              : e.data === "$!"
                ? (t.lanes = 8)
                : (t.lanes = 1073741824),
            null)
          : ((s = r.children),
            (e = r.fallback),
            o
              ? ((r = t.mode),
                (o = t.child),
                (s = { mode: "hidden", children: s }),
                (r & 1) === 0 && o !== null
                  ? ((o.childLanes = 0), (o.pendingProps = s))
                  : (o = Ll(s, r, 0, null)),
                (e = mn(e, r, n, null)),
                (o.return = t),
                (e.return = t),
                (o.sibling = e),
                (t.child = o),
                (t.child.memoizedState = ai(n)),
                (t.memoizedState = ui),
                e)
              : ci(t, s))
      );
    if (((l = e.memoizedState), l !== null && ((u = l.dehydrated), u !== null)))
      return Ff(e, t, s, r, u, l, n);
    if (o) {
      ((o = r.fallback), (s = t.mode), (l = e.child), (u = l.sibling));
      var a = { mode: "hidden", children: r.children };
      return (
        (s & 1) === 0 && t.child !== l
          ? ((r = t.child),
            (r.childLanes = 0),
            (r.pendingProps = a),
            (t.deletions = null))
          : ((r = bt(l, a)), (r.subtreeFlags = l.subtreeFlags & 14680064)),
        u !== null ? (o = bt(u, o)) : ((o = mn(o, s, n, null)), (o.flags |= 2)),
        (o.return = t),
        (r.return = t),
        (r.sibling = o),
        (t.child = r),
        (r = o),
        (o = t.child),
        (s = e.child.memoizedState),
        (s =
          s === null
            ? ai(n)
            : {
                baseLanes: s.baseLanes | n,
                cachePool: null,
                transitions: s.transitions,
              }),
        (o.memoizedState = s),
        (o.childLanes = e.childLanes & ~n),
        (t.memoizedState = ui),
        r
      );
    }
    return (
      (o = e.child),
      (e = o.sibling),
      (r = bt(o, { mode: "visible", children: r.children })),
      (t.mode & 1) === 0 && (r.lanes = n),
      (r.return = t),
      (r.sibling = null),
      e !== null &&
        ((n = t.deletions),
        n === null ? ((t.deletions = [e]), (t.flags |= 16)) : n.push(e)),
      (t.child = r),
      (t.memoizedState = null),
      r
    );
  }
  function ci(e, t) {
    return (
      (t = Ll({ mode: "visible", children: t }, e.mode, 0, null)),
      (t.return = e),
      (e.child = t)
    );
  }
  function gl(e, t, n, r) {
    return (
      r !== null && Fo(r),
      Rn(t, e.child, null, n),
      (e = ci(t, t.pendingProps.children)),
      (e.flags |= 2),
      (t.memoizedState = null),
      e
    );
  }
  function Ff(e, t, n, r, l, o, s) {
    if (n)
      return t.flags & 256
        ? ((t.flags &= -257), (r = li(Error(c(422)))), gl(e, t, s, r))
        : t.memoizedState !== null
          ? ((t.child = e.child), (t.flags |= 128), null)
          : ((o = r.fallback),
            (l = t.mode),
            (r = Ll({ mode: "visible", children: r.children }, l, 0, null)),
            (o = mn(o, l, s, null)),
            (o.flags |= 2),
            (r.return = t),
            (o.return = t),
            (r.sibling = o),
            (t.child = r),
            (t.mode & 1) !== 0 && Rn(t, e.child, null, s),
            (t.child.memoizedState = ai(s)),
            (t.memoizedState = ui),
            o);
    if ((t.mode & 1) === 0) return gl(e, t, s, null);
    if (l.data === "$!") {
      if (((r = l.nextSibling && l.nextSibling.dataset), r)) var u = r.dgst;
      return (
        (r = u),
        (o = Error(c(419))),
        (r = li(o, r, void 0)),
        gl(e, t, s, r)
      );
    }
    if (((u = (s & e.childLanes) !== 0), qe || u)) {
      if (((r = Fe), r !== null)) {
        switch (s & -s) {
          case 4:
            l = 2;
            break;
          case 16:
            l = 8;
            break;
          case 64:
          case 128:
          case 256:
          case 512:
          case 1024:
          case 2048:
          case 4096:
          case 8192:
          case 16384:
          case 32768:
          case 65536:
          case 131072:
          case 262144:
          case 524288:
          case 1048576:
          case 2097152:
          case 4194304:
          case 8388608:
          case 16777216:
          case 33554432:
          case 67108864:
            l = 32;
            break;
          case 536870912:
            l = 268435456;
            break;
          default:
            l = 0;
        }
        ((l = (l & (r.suspendedLanes | s)) !== 0 ? 0 : l),
          l !== 0 &&
            l !== o.retryLane &&
            ((o.retryLane = l), Pt(e, l), xt(r, e, l, -1)));
      }
      return (Ei(), (r = li(Error(c(421)))), gl(e, t, s, r));
    }
    return l.data === "$?"
      ? ((t.flags |= 128),
        (t.child = e.child),
        (t = Xf.bind(null, e)),
        (l._reactRetry = t),
        null)
      : ((e = o.treeContext),
        (lt = Ht(l.nextSibling)),
        (rt = t),
        (ve = !0),
        (mt = null),
        e !== null &&
          ((st[ut++] = _t),
          (st[ut++] = Mt),
          (st[ut++] = on),
          (_t = e.id),
          (Mt = e.overflow),
          (on = t)),
        (t = ci(t, r.children)),
        (t.flags |= 4096),
        t);
  }
  function aa(e, t, n) {
    e.lanes |= t;
    var r = e.alternate;
    (r !== null && (r.lanes |= t), $o(e.return, t, n));
  }
  function fi(e, t, n, r, l) {
    var o = e.memoizedState;
    o === null
      ? (e.memoizedState = {
          isBackwards: t,
          rendering: null,
          renderingStartTime: 0,
          last: r,
          tail: n,
          tailMode: l,
        })
      : ((o.isBackwards = t),
        (o.rendering = null),
        (o.renderingStartTime = 0),
        (o.last = r),
        (o.tail = n),
        (o.tailMode = l));
  }
  function ca(e, t, n) {
    var r = t.pendingProps,
      l = r.revealOrder,
      o = r.tail;
    if ((Ke(e, t, r.children, n), (r = we.current), (r & 2) !== 0))
      ((r = (r & 1) | 2), (t.flags |= 128));
    else {
      if (e !== null && (e.flags & 128) !== 0)
        e: for (e = t.child; e !== null;) {
          if (e.tag === 13) e.memoizedState !== null && aa(e, n, t);
          else if (e.tag === 19) aa(e, n, t);
          else if (e.child !== null) {
            ((e.child.return = e), (e = e.child));
            continue;
          }
          if (e === t) break e;
          for (; e.sibling === null;) {
            if (e.return === null || e.return === t) break e;
            e = e.return;
          }
          ((e.sibling.return = e.return), (e = e.sibling));
        }
      r &= 1;
    }
    if ((pe(we, r), (t.mode & 1) === 0)) t.memoizedState = null;
    else
      switch (l) {
        case "forwards":
          for (n = t.child, l = null; n !== null;)
            ((e = n.alternate),
              e !== null && cl(e) === null && (l = n),
              (n = n.sibling));
          ((n = l),
            n === null
              ? ((l = t.child), (t.child = null))
              : ((l = n.sibling), (n.sibling = null)),
            fi(t, !1, l, n, o));
          break;
        case "backwards":
          for (n = null, l = t.child, t.child = null; l !== null;) {
            if (((e = l.alternate), e !== null && cl(e) === null)) {
              t.child = l;
              break;
            }
            ((e = l.sibling), (l.sibling = n), (n = l), (l = e));
          }
          fi(t, !0, n, null, o);
          break;
        case "together":
          fi(t, !1, null, null, void 0);
          break;
        default:
          t.memoizedState = null;
      }
    return t.child;
  }
  function vl(e, t) {
    (t.mode & 1) === 0 &&
      e !== null &&
      ((e.alternate = null), (t.alternate = null), (t.flags |= 2));
  }
  function Nt(e, t, n) {
    if (
      (e !== null && (t.dependencies = e.dependencies),
      (fn |= t.lanes),
      (n & t.childLanes) === 0)
    )
      return null;
    if (e !== null && t.child !== e.child) throw Error(c(153));
    if (t.child !== null) {
      for (
        e = t.child, n = bt(e, e.pendingProps), t.child = n, n.return = t;
        e.sibling !== null;
      )
        ((e = e.sibling),
          (n = n.sibling = bt(e, e.pendingProps)),
          (n.return = t));
      n.sibling = null;
    }
    return t.child;
  }
  function Uf(e, t, n) {
    switch (t.tag) {
      case 3:
        (ia(t), Nn());
        break;
      case 5:
        zu(t);
        break;
      case 1:
        Xe(t.type) && el(t);
        break;
      case 4:
        Vo(t, t.stateNode.containerInfo);
        break;
      case 10:
        var r = t.type._context,
          l = t.memoizedProps.value;
        (pe(il, r._currentValue), (r._currentValue = l));
        break;
      case 13:
        if (((r = t.memoizedState), r !== null))
          return r.dehydrated !== null
            ? (pe(we, we.current & 1), (t.flags |= 128), null)
            : (n & t.child.childLanes) !== 0
              ? ua(e, t, n)
              : (pe(we, we.current & 1),
                (e = Nt(e, t, n)),
                e !== null ? e.sibling : null);
        pe(we, we.current & 1);
        break;
      case 19:
        if (((r = (n & t.childLanes) !== 0), (e.flags & 128) !== 0)) {
          if (r) return ca(e, t, n);
          t.flags |= 128;
        }
        if (
          ((l = t.memoizedState),
          l !== null &&
            ((l.rendering = null), (l.tail = null), (l.lastEffect = null)),
          pe(we, we.current),
          r)
        )
          break;
        return null;
      case 22:
      case 23:
        return ((t.lanes = 0), ra(e, t, n));
    }
    return Nt(e, t, n);
  }
  var fa, di, da, pa;
  ((fa = function (e, t) {
    for (var n = t.child; n !== null;) {
      if (n.tag === 5 || n.tag === 6) e.appendChild(n.stateNode);
      else if (n.tag !== 4 && n.child !== null) {
        ((n.child.return = n), (n = n.child));
        continue;
      }
      if (n === t) break;
      for (; n.sibling === null;) {
        if (n.return === null || n.return === t) return;
        n = n.return;
      }
      ((n.sibling.return = n.return), (n = n.sibling));
    }
  }),
    (di = function () {}),
    (da = function (e, t, n, r) {
      var l = e.memoizedProps;
      if (l !== r) {
        ((e = t.stateNode), an(St.current));
        var o = null;
        switch (n) {
          case "input":
            ((l = Wl(e, l)), (r = Wl(e, r)), (o = []));
            break;
          case "select":
            ((l = L({}, l, { value: void 0 })),
              (r = L({}, r, { value: void 0 })),
              (o = []));
            break;
          case "textarea":
            ((l = Bl(e, l)), (r = Bl(e, r)), (o = []));
            break;
          default:
            typeof l.onClick != "function" &&
              typeof r.onClick == "function" &&
              (e.onclick = qr);
        }
        Ql(n, r);
        var s;
        n = null;
        for (y in l)
          if (!r.hasOwnProperty(y) && l.hasOwnProperty(y) && l[y] != null)
            if (y === "style") {
              var u = l[y];
              for (s in u) u.hasOwnProperty(s) && (n || (n = {}), (n[s] = ""));
            } else
              y !== "dangerouslySetInnerHTML" &&
                y !== "children" &&
                y !== "suppressContentEditableWarning" &&
                y !== "suppressHydrationWarning" &&
                y !== "autoFocus" &&
                (C.hasOwnProperty(y)
                  ? o || (o = [])
                  : (o = o || []).push(y, null));
        for (y in r) {
          var a = r[y];
          if (
            ((u = l?.[y]),
            r.hasOwnProperty(y) && a !== u && (a != null || u != null))
          )
            if (y === "style")
              if (u) {
                for (s in u)
                  !u.hasOwnProperty(s) ||
                    (a && a.hasOwnProperty(s)) ||
                    (n || (n = {}), (n[s] = ""));
                for (s in a)
                  a.hasOwnProperty(s) &&
                    u[s] !== a[s] &&
                    (n || (n = {}), (n[s] = a[s]));
              } else (n || (o || (o = []), o.push(y, n)), (n = a));
            else
              y === "dangerouslySetInnerHTML"
                ? ((a = a ? a.__html : void 0),
                  (u = u ? u.__html : void 0),
                  a != null && u !== a && (o = o || []).push(y, a))
                : y === "children"
                  ? (typeof a != "string" && typeof a != "number") ||
                    (o = o || []).push(y, "" + a)
                  : y !== "suppressContentEditableWarning" &&
                    y !== "suppressHydrationWarning" &&
                    (C.hasOwnProperty(y)
                      ? (a != null && y === "onScroll" && he("scroll", e),
                        o || u === a || (o = []))
                      : (o = o || []).push(y, a));
        }
        n && (o = o || []).push("style", n);
        var y = o;
        (t.updateQueue = y) && (t.flags |= 4);
      }
    }),
    (pa = function (e, t, n, r) {
      n !== r && (t.flags |= 4);
    }));
  function wr(e, t) {
    if (!ve)
      switch (e.tailMode) {
        case "hidden":
          t = e.tail;
          for (var n = null; t !== null;)
            (t.alternate !== null && (n = t), (t = t.sibling));
          n === null ? (e.tail = null) : (n.sibling = null);
          break;
        case "collapsed":
          n = e.tail;
          for (var r = null; n !== null;)
            (n.alternate !== null && (r = n), (n = n.sibling));
          r === null
            ? t || e.tail === null
              ? (e.tail = null)
              : (e.tail.sibling = null)
            : (r.sibling = null);
      }
  }
  function Qe(e) {
    var t = e.alternate !== null && e.alternate.child === e.child,
      n = 0,
      r = 0;
    if (t)
      for (var l = e.child; l !== null;)
        ((n |= l.lanes | l.childLanes),
          (r |= l.subtreeFlags & 14680064),
          (r |= l.flags & 14680064),
          (l.return = e),
          (l = l.sibling));
    else
      for (l = e.child; l !== null;)
        ((n |= l.lanes | l.childLanes),
          (r |= l.subtreeFlags),
          (r |= l.flags),
          (l.return = e),
          (l = l.sibling));
    return ((e.subtreeFlags |= r), (e.childLanes = n), t);
  }
  function Af(e, t, n) {
    var r = t.pendingProps;
    switch ((Oo(t), t.tag)) {
      case 2:
      case 16:
      case 15:
      case 0:
      case 11:
      case 7:
      case 8:
      case 12:
      case 9:
      case 14:
        return (Qe(t), null);
      case 1:
        return (Xe(t.type) && br(), Qe(t), null);
      case 3:
        return (
          (r = t.stateNode),
          Dn(),
          me(Ye),
          me(Be),
          Ko(),
          r.pendingContext &&
            ((r.context = r.pendingContext), (r.pendingContext = null)),
          (e === null || e.child === null) &&
            (ll(t)
              ? (t.flags |= 4)
              : e === null ||
                (e.memoizedState.isDehydrated && (t.flags & 256) === 0) ||
                ((t.flags |= 1024), mt !== null && (ji(mt), (mt = null)))),
          di(e, t),
          Qe(t),
          null
        );
      case 5:
        Qo(t);
        var l = an(mr.current);
        if (((n = t.type), e !== null && t.stateNode != null))
          (da(e, t, n, r, l),
            e.ref !== t.ref && ((t.flags |= 512), (t.flags |= 2097152)));
        else {
          if (!r) {
            if (t.stateNode === null) throw Error(c(166));
            return (Qe(t), null);
          }
          if (((e = an(St.current)), ll(t))) {
            ((r = t.stateNode), (n = t.type));
            var o = t.memoizedProps;
            switch (((r[kt] = t), (r[cr] = o), (e = (t.mode & 1) !== 0), n)) {
              case "dialog":
                (he("cancel", r), he("close", r));
                break;
              case "iframe":
              case "object":
              case "embed":
                he("load", r);
                break;
              case "video":
              case "audio":
                for (l = 0; l < sr.length; l++) he(sr[l], r);
                break;
              case "source":
                he("error", r);
                break;
              case "img":
              case "image":
              case "link":
                (he("error", r), he("load", r));
                break;
              case "details":
                he("toggle", r);
                break;
              case "input":
                (Ki(r, o), he("invalid", r));
                break;
              case "select":
                ((r._wrapperState = { wasMultiple: !!o.multiple }),
                  he("invalid", r));
                break;
              case "textarea":
                (Xi(r, o), he("invalid", r));
            }
            (Ql(n, o), (l = null));
            for (var s in o)
              if (o.hasOwnProperty(s)) {
                var u = o[s];
                s === "children"
                  ? typeof u == "string"
                    ? r.textContent !== u &&
                      (o.suppressHydrationWarning !== !0 &&
                        Xr(r.textContent, u, e),
                      (l = ["children", u]))
                    : typeof u == "number" &&
                      r.textContent !== "" + u &&
                      (o.suppressHydrationWarning !== !0 &&
                        Xr(r.textContent, u, e),
                      (l = ["children", "" + u]))
                  : C.hasOwnProperty(s) &&
                    u != null &&
                    s === "onScroll" &&
                    he("scroll", r);
              }
            switch (n) {
              case "input":
                (_r(r), Yi(r, o, !0));
                break;
              case "textarea":
                (_r(r), Ji(r));
                break;
              case "select":
              case "option":
                break;
              default:
                typeof o.onClick == "function" && (r.onclick = qr);
            }
            ((r = l), (t.updateQueue = r), r !== null && (t.flags |= 4));
          } else {
            ((s = l.nodeType === 9 ? l : l.ownerDocument),
              e === "http://www.w3.org/1999/xhtml" && (e = bi(n)),
              e === "http://www.w3.org/1999/xhtml"
                ? n === "script"
                  ? ((e = s.createElement("div")),
                    (e.innerHTML = "<script><\/script>"),
                    (e = e.removeChild(e.firstChild)))
                  : typeof r.is == "string"
                    ? (e = s.createElement(n, { is: r.is }))
                    : ((e = s.createElement(n)),
                      n === "select" &&
                        ((s = e),
                        r.multiple
                          ? (s.multiple = !0)
                          : r.size && (s.size = r.size)))
                : (e = s.createElementNS(e, n)),
              (e[kt] = t),
              (e[cr] = r),
              fa(e, t, !1, !1),
              (t.stateNode = e));
            e: {
              switch (((s = Zl(n, r)), n)) {
                case "dialog":
                  (he("cancel", e), he("close", e), (l = r));
                  break;
                case "iframe":
                case "object":
                case "embed":
                  (he("load", e), (l = r));
                  break;
                case "video":
                case "audio":
                  for (l = 0; l < sr.length; l++) he(sr[l], e);
                  l = r;
                  break;
                case "source":
                  (he("error", e), (l = r));
                  break;
                case "img":
                case "image":
                case "link":
                  (he("error", e), he("load", e), (l = r));
                  break;
                case "details":
                  (he("toggle", e), (l = r));
                  break;
                case "input":
                  (Ki(e, r), (l = Wl(e, r)), he("invalid", e));
                  break;
                case "option":
                  l = r;
                  break;
                case "select":
                  ((e._wrapperState = { wasMultiple: !!r.multiple }),
                    (l = L({}, r, { value: void 0 })),
                    he("invalid", e));
                  break;
                case "textarea":
                  (Xi(e, r), (l = Bl(e, r)), he("invalid", e));
                  break;
                default:
                  l = r;
              }
              (Ql(n, l), (u = l));
              for (o in u)
                if (u.hasOwnProperty(o)) {
                  var a = u[o];
                  o === "style"
                    ? ns(e, a)
                    : o === "dangerouslySetInnerHTML"
                      ? ((a = a ? a.__html : void 0), a != null && es(e, a))
                      : o === "children"
                        ? typeof a == "string"
                          ? (n !== "textarea" || a !== "") && Hn(e, a)
                          : typeof a == "number" && Hn(e, "" + a)
                        : o !== "suppressContentEditableWarning" &&
                          o !== "suppressHydrationWarning" &&
                          o !== "autoFocus" &&
                          (C.hasOwnProperty(o)
                            ? a != null && o === "onScroll" && he("scroll", e)
                            : a != null && De(e, o, a, s));
                }
              switch (n) {
                case "input":
                  (_r(e), Yi(e, r, !1));
                  break;
                case "textarea":
                  (_r(e), Ji(e));
                  break;
                case "option":
                  r.value != null && e.setAttribute("value", "" + ie(r.value));
                  break;
                case "select":
                  ((e.multiple = !!r.multiple),
                    (o = r.value),
                    o != null
                      ? yn(e, !!r.multiple, o, !1)
                      : r.defaultValue != null &&
                        yn(e, !!r.multiple, r.defaultValue, !0));
                  break;
                default:
                  typeof l.onClick == "function" && (e.onclick = qr);
              }
              switch (n) {
                case "button":
                case "input":
                case "select":
                case "textarea":
                  r = !!r.autoFocus;
                  break e;
                case "img":
                  r = !0;
                  break e;
                default:
                  r = !1;
              }
            }
            r && (t.flags |= 4);
          }
          t.ref !== null && ((t.flags |= 512), (t.flags |= 2097152));
        }
        return (Qe(t), null);
      case 6:
        if (e && t.stateNode != null) pa(e, t, e.memoizedProps, r);
        else {
          if (typeof r != "string" && t.stateNode === null) throw Error(c(166));
          if (((n = an(mr.current)), an(St.current), ll(t))) {
            if (
              ((r = t.stateNode),
              (n = t.memoizedProps),
              (r[kt] = t),
              (o = r.nodeValue !== n) && ((e = rt), e !== null))
            )
              switch (e.tag) {
                case 3:
                  Xr(r.nodeValue, n, (e.mode & 1) !== 0);
                  break;
                case 5:
                  e.memoizedProps.suppressHydrationWarning !== !0 &&
                    Xr(r.nodeValue, n, (e.mode & 1) !== 0);
              }
            o && (t.flags |= 4);
          } else
            ((r = (n.nodeType === 9 ? n : n.ownerDocument).createTextNode(r)),
              (r[kt] = t),
              (t.stateNode = r));
        }
        return (Qe(t), null);
      case 13:
        if (
          (me(we),
          (r = t.memoizedState),
          e === null ||
            (e.memoizedState !== null && e.memoizedState.dehydrated !== null))
        ) {
          if (ve && lt !== null && (t.mode & 1) !== 0 && (t.flags & 128) === 0)
            (yu(), Nn(), (t.flags |= 98560), (o = !1));
          else if (((o = ll(t)), r !== null && r.dehydrated !== null)) {
            if (e === null) {
              if (!o) throw Error(c(318));
              if (
                ((o = t.memoizedState),
                (o = o !== null ? o.dehydrated : null),
                !o)
              )
                throw Error(c(317));
              o[kt] = t;
            } else
              (Nn(),
                (t.flags & 128) === 0 && (t.memoizedState = null),
                (t.flags |= 4));
            (Qe(t), (o = !1));
          } else (mt !== null && (ji(mt), (mt = null)), (o = !0));
          if (!o) return t.flags & 65536 ? t : null;
        }
        return (t.flags & 128) !== 0
          ? ((t.lanes = n), t)
          : ((r = r !== null),
            r !== (e !== null && e.memoizedState !== null) &&
              r &&
              ((t.child.flags |= 8192),
              (t.mode & 1) !== 0 &&
                (e === null || (we.current & 1) !== 0
                  ? Te === 0 && (Te = 3)
                  : Ei())),
            t.updateQueue !== null && (t.flags |= 4),
            Qe(t),
            null);
      case 4:
        return (
          Dn(),
          di(e, t),
          e === null && ur(t.stateNode.containerInfo),
          Qe(t),
          null
        );
      case 10:
        return (Wo(t.type._context), Qe(t), null);
      case 17:
        return (Xe(t.type) && br(), Qe(t), null);
      case 19:
        if ((me(we), (o = t.memoizedState), o === null)) return (Qe(t), null);
        if (((r = (t.flags & 128) !== 0), (s = o.rendering), s === null))
          if (r) wr(o, !1);
          else {
            if (Te !== 0 || (e !== null && (e.flags & 128) !== 0))
              for (e = t.child; e !== null;) {
                if (((s = cl(e)), s !== null)) {
                  for (
                    t.flags |= 128,
                      wr(o, !1),
                      r = s.updateQueue,
                      r !== null && ((t.updateQueue = r), (t.flags |= 4)),
                      t.subtreeFlags = 0,
                      r = n,
                      n = t.child;
                    n !== null;
                  )
                    ((o = n),
                      (e = r),
                      (o.flags &= 14680066),
                      (s = o.alternate),
                      s === null
                        ? ((o.childLanes = 0),
                          (o.lanes = e),
                          (o.child = null),
                          (o.subtreeFlags = 0),
                          (o.memoizedProps = null),
                          (o.memoizedState = null),
                          (o.updateQueue = null),
                          (o.dependencies = null),
                          (o.stateNode = null))
                        : ((o.childLanes = s.childLanes),
                          (o.lanes = s.lanes),
                          (o.child = s.child),
                          (o.subtreeFlags = 0),
                          (o.deletions = null),
                          (o.memoizedProps = s.memoizedProps),
                          (o.memoizedState = s.memoizedState),
                          (o.updateQueue = s.updateQueue),
                          (o.type = s.type),
                          (e = s.dependencies),
                          (o.dependencies =
                            e === null
                              ? null
                              : {
                                  lanes: e.lanes,
                                  firstContext: e.firstContext,
                                })),
                      (n = n.sibling));
                  return (pe(we, (we.current & 1) | 2), t.child);
                }
                e = e.sibling;
              }
            o.tail !== null &&
              Ee() > An &&
              ((t.flags |= 128), (r = !0), wr(o, !1), (t.lanes = 4194304));
          }
        else {
          if (!r)
            if (((e = cl(s)), e !== null)) {
              if (
                ((t.flags |= 128),
                (r = !0),
                (n = e.updateQueue),
                n !== null && ((t.updateQueue = n), (t.flags |= 4)),
                wr(o, !0),
                o.tail === null &&
                  o.tailMode === "hidden" &&
                  !s.alternate &&
                  !ve)
              )
                return (Qe(t), null);
            } else
              2 * Ee() - o.renderingStartTime > An &&
                n !== 1073741824 &&
                ((t.flags |= 128), (r = !0), wr(o, !1), (t.lanes = 4194304));
          o.isBackwards
            ? ((s.sibling = t.child), (t.child = s))
            : ((n = o.last),
              n !== null ? (n.sibling = s) : (t.child = s),
              (o.last = s));
        }
        return o.tail !== null
          ? ((t = o.tail),
            (o.rendering = t),
            (o.tail = t.sibling),
            (o.renderingStartTime = Ee()),
            (t.sibling = null),
            (n = we.current),
            pe(we, r ? (n & 1) | 2 : n & 1),
            t)
          : (Qe(t), null);
      case 22:
      case 23:
        return (
          Ci(),
          (r = t.memoizedState !== null),
          e !== null && (e.memoizedState !== null) !== r && (t.flags |= 8192),
          r && (t.mode & 1) !== 0
            ? (ot & 1073741824) !== 0 &&
              (Qe(t), t.subtreeFlags & 6 && (t.flags |= 8192))
            : Qe(t),
          null
        );
      case 24:
        return null;
      case 25:
        return null;
    }
    throw Error(c(156, t.tag));
  }
  function Wf(e, t) {
    switch ((Oo(t), t.tag)) {
      case 1:
        return (
          Xe(t.type) && br(),
          (e = t.flags),
          e & 65536 ? ((t.flags = (e & -65537) | 128), t) : null
        );
      case 3:
        return (
          Dn(),
          me(Ye),
          me(Be),
          Ko(),
          (e = t.flags),
          (e & 65536) !== 0 && (e & 128) === 0
            ? ((t.flags = (e & -65537) | 128), t)
            : null
        );
      case 5:
        return (Qo(t), null);
      case 13:
        if (
          (me(we), (e = t.memoizedState), e !== null && e.dehydrated !== null)
        ) {
          if (t.alternate === null) throw Error(c(340));
          Nn();
        }
        return (
          (e = t.flags),
          e & 65536 ? ((t.flags = (e & -65537) | 128), t) : null
        );
      case 19:
        return (me(we), null);
      case 4:
        return (Dn(), null);
      case 10:
        return (Wo(t.type._context), null);
      case 22:
      case 23:
        return (Ci(), null);
      case 24:
        return null;
      default:
        return null;
    }
  }
  var xl = !1,
    Ze = !1,
    $f = typeof WeakSet == "function" ? WeakSet : Set,
    P = null;
  function Fn(e, t) {
    var n = e.ref;
    if (n !== null)
      if (typeof n == "function")
        try {
          n(null);
        } catch (r) {
          je(e, t, r);
        }
      else n.current = null;
  }
  function pi(e, t, n) {
    try {
      n();
    } catch (r) {
      je(e, t, r);
    }
  }
  var ha = !1;
  function Hf(e, t) {
    if (((Co = Ar), (e = Zs()), go(e))) {
      if ("selectionStart" in e)
        var n = { start: e.selectionStart, end: e.selectionEnd };
      else
        e: {
          n = ((n = e.ownerDocument) && n.defaultView) || window;
          var r = n.getSelection && n.getSelection();
          if (r && r.rangeCount !== 0) {
            n = r.anchorNode;
            var l = r.anchorOffset,
              o = r.focusNode;
            r = r.focusOffset;
            try {
              (n.nodeType, o.nodeType);
            } catch {
              n = null;
              break e;
            }
            var s = 0,
              u = -1,
              a = -1,
              y = 0,
              k = 0,
              j = e,
              x = null;
            t: for (;;) {
              for (
                var M;
                j !== n || (l !== 0 && j.nodeType !== 3) || (u = s + l),
                  j !== o || (r !== 0 && j.nodeType !== 3) || (a = s + r),
                  j.nodeType === 3 && (s += j.nodeValue.length),
                  (M = j.firstChild) !== null;
              )
                ((x = j), (j = M));
              for (;;) {
                if (j === e) break t;
                if (
                  (x === n && ++y === l && (u = s),
                  x === o && ++k === r && (a = s),
                  (M = j.nextSibling) !== null)
                )
                  break;
                ((j = x), (x = j.parentNode));
              }
              j = M;
            }
            n = u === -1 || a === -1 ? null : { start: u, end: a };
          } else n = null;
        }
      n = n || { start: 0, end: 0 };
    } else n = null;
    for (
      Eo = { focusedElem: e, selectionRange: n }, Ar = !1, P = t;
      P !== null;
    )
      if (((t = P), (e = t.child), (t.subtreeFlags & 1028) !== 0 && e !== null))
        ((e.return = t), (P = e));
      else
        for (; P !== null;) {
          t = P;
          try {
            var N = t.alternate;
            if ((t.flags & 1024) !== 0)
              switch (t.tag) {
                case 0:
                case 11:
                case 15:
                  break;
                case 1:
                  if (N !== null) {
                    var T = N.memoizedProps,
                      _e = N.memoizedState,
                      h = t.stateNode,
                      f = h.getSnapshotBeforeUpdate(
                        t.elementType === t.type ? T : yt(t.type, T),
                        _e,
                      );
                    h.__reactInternalSnapshotBeforeUpdate = f;
                  }
                  break;
                case 3:
                  var m = t.stateNode.containerInfo;
                  m.nodeType === 1
                    ? (m.textContent = "")
                    : m.nodeType === 9 &&
                      m.documentElement &&
                      m.removeChild(m.documentElement);
                  break;
                case 5:
                case 6:
                case 4:
                case 17:
                  break;
                default:
                  throw Error(c(163));
              }
          } catch (z) {
            je(t, t.return, z);
          }
          if (((e = t.sibling), e !== null)) {
            ((e.return = t.return), (P = e));
            break;
          }
          P = t.return;
        }
    return ((N = ha), (ha = !1), N);
  }
  function kr(e, t, n) {
    var r = t.updateQueue;
    if (((r = r !== null ? r.lastEffect : null), r !== null)) {
      var l = (r = r.next);
      do {
        if ((l.tag & e) === e) {
          var o = l.destroy;
          ((l.destroy = void 0), o !== void 0 && pi(t, n, o));
        }
        l = l.next;
      } while (l !== r);
    }
  }
  function wl(e, t) {
    if (
      ((t = t.updateQueue), (t = t !== null ? t.lastEffect : null), t !== null)
    ) {
      var n = (t = t.next);
      do {
        if ((n.tag & e) === e) {
          var r = n.create;
          n.destroy = r();
        }
        n = n.next;
      } while (n !== t);
    }
  }
  function hi(e) {
    var t = e.ref;
    if (t !== null) {
      var n = e.stateNode;
      switch (e.tag) {
        case 5:
          e = n;
          break;
        default:
          e = n;
      }
      typeof t == "function" ? t(e) : (t.current = e);
    }
  }
  function ma(e) {
    var t = e.alternate;
    (t !== null && ((e.alternate = null), ma(t)),
      (e.child = null),
      (e.deletions = null),
      (e.sibling = null),
      e.tag === 5 &&
        ((t = e.stateNode),
        t !== null &&
          (delete t[kt],
          delete t[cr],
          delete t[Lo],
          delete t[zf],
          delete t[Cf])),
      (e.stateNode = null),
      (e.return = null),
      (e.dependencies = null),
      (e.memoizedProps = null),
      (e.memoizedState = null),
      (e.pendingProps = null),
      (e.stateNode = null),
      (e.updateQueue = null));
  }
  function ya(e) {
    return e.tag === 5 || e.tag === 3 || e.tag === 4;
  }
  function ga(e) {
    e: for (;;) {
      for (; e.sibling === null;) {
        if (e.return === null || ya(e.return)) return null;
        e = e.return;
      }
      for (
        e.sibling.return = e.return, e = e.sibling;
        e.tag !== 5 && e.tag !== 6 && e.tag !== 18;
      ) {
        if (e.flags & 2 || e.child === null || e.tag === 4) continue e;
        ((e.child.return = e), (e = e.child));
      }
      if (!(e.flags & 2)) return e.stateNode;
    }
  }
  function mi(e, t, n) {
    var r = e.tag;
    if (r === 5 || r === 6)
      ((e = e.stateNode),
        t
          ? n.nodeType === 8
            ? n.parentNode.insertBefore(e, t)
            : n.insertBefore(e, t)
          : (n.nodeType === 8
              ? ((t = n.parentNode), t.insertBefore(e, n))
              : ((t = n), t.appendChild(e)),
            (n = n._reactRootContainer),
            n != null || t.onclick !== null || (t.onclick = qr)));
    else if (r !== 4 && ((e = e.child), e !== null))
      for (mi(e, t, n), e = e.sibling; e !== null;)
        (mi(e, t, n), (e = e.sibling));
  }
  function yi(e, t, n) {
    var r = e.tag;
    if (r === 5 || r === 6)
      ((e = e.stateNode), t ? n.insertBefore(e, t) : n.appendChild(e));
    else if (r !== 4 && ((e = e.child), e !== null))
      for (yi(e, t, n), e = e.sibling; e !== null;)
        (yi(e, t, n), (e = e.sibling));
  }
  var Ae = null,
    gt = !1;
  function Gt(e, t, n) {
    for (n = n.child; n !== null;) (va(e, t, n), (n = n.sibling));
  }
  function va(e, t, n) {
    if (wt && typeof wt.onCommitFiberUnmount == "function")
      try {
        wt.onCommitFiberUnmount(Tr, n);
      } catch {}
    switch (n.tag) {
      case 5:
        Ze || Fn(n, t);
      case 6:
        var r = Ae,
          l = gt;
        ((Ae = null),
          Gt(e, t, n),
          (Ae = r),
          (gt = l),
          Ae !== null &&
            (gt
              ? ((e = Ae),
                (n = n.stateNode),
                e.nodeType === 8
                  ? e.parentNode.removeChild(n)
                  : e.removeChild(n))
              : Ae.removeChild(n.stateNode)));
        break;
      case 18:
        Ae !== null &&
          (gt
            ? ((e = Ae),
              (n = n.stateNode),
              e.nodeType === 8
                ? Po(e.parentNode, n)
                : e.nodeType === 1 && Po(e, n),
              bn(e))
            : Po(Ae, n.stateNode));
        break;
      case 4:
        ((r = Ae),
          (l = gt),
          (Ae = n.stateNode.containerInfo),
          (gt = !0),
          Gt(e, t, n),
          (Ae = r),
          (gt = l));
        break;
      case 0:
      case 11:
      case 14:
      case 15:
        if (
          !Ze &&
          ((r = n.updateQueue), r !== null && ((r = r.lastEffect), r !== null))
        ) {
          l = r = r.next;
          do {
            var o = l,
              s = o.destroy;
            ((o = o.tag),
              s !== void 0 && ((o & 2) !== 0 || (o & 4) !== 0) && pi(n, t, s),
              (l = l.next));
          } while (l !== r);
        }
        Gt(e, t, n);
        break;
      case 1:
        if (
          !Ze &&
          (Fn(n, t),
          (r = n.stateNode),
          typeof r.componentWillUnmount == "function")
        )
          try {
            ((r.props = n.memoizedProps),
              (r.state = n.memoizedState),
              r.componentWillUnmount());
          } catch (u) {
            je(n, t, u);
          }
        Gt(e, t, n);
        break;
      case 21:
        Gt(e, t, n);
        break;
      case 22:
        n.mode & 1
          ? ((Ze = (r = Ze) || n.memoizedState !== null), Gt(e, t, n), (Ze = r))
          : Gt(e, t, n);
        break;
      default:
        Gt(e, t, n);
    }
  }
  function xa(e) {
    var t = e.updateQueue;
    if (t !== null) {
      e.updateQueue = null;
      var n = e.stateNode;
      (n === null && (n = e.stateNode = new $f()),
        t.forEach(function (r) {
          var l = qf.bind(null, e, r);
          n.has(r) || (n.add(r), r.then(l, l));
        }));
    }
  }
  function vt(e, t) {
    var n = t.deletions;
    if (n !== null)
      for (var r = 0; r < n.length; r++) {
        var l = n[r];
        try {
          var o = e,
            s = t,
            u = s;
          e: for (; u !== null;) {
            switch (u.tag) {
              case 5:
                ((Ae = u.stateNode), (gt = !1));
                break e;
              case 3:
                ((Ae = u.stateNode.containerInfo), (gt = !0));
                break e;
              case 4:
                ((Ae = u.stateNode.containerInfo), (gt = !0));
                break e;
            }
            u = u.return;
          }
          if (Ae === null) throw Error(c(160));
          (va(o, s, l), (Ae = null), (gt = !1));
          var a = l.alternate;
          (a !== null && (a.return = null), (l.return = null));
        } catch (y) {
          je(l, t, y);
        }
      }
    if (t.subtreeFlags & 12854)
      for (t = t.child; t !== null;) (wa(t, e), (t = t.sibling));
  }
  function wa(e, t) {
    var n = e.alternate,
      r = e.flags;
    switch (e.tag) {
      case 0:
      case 11:
      case 14:
      case 15:
        if ((vt(t, e), zt(e), r & 4)) {
          try {
            (kr(3, e, e.return), wl(3, e));
          } catch (T) {
            je(e, e.return, T);
          }
          try {
            kr(5, e, e.return);
          } catch (T) {
            je(e, e.return, T);
          }
        }
        break;
      case 1:
        (vt(t, e), zt(e), r & 512 && n !== null && Fn(n, n.return));
        break;
      case 5:
        if (
          (vt(t, e),
          zt(e),
          r & 512 && n !== null && Fn(n, n.return),
          e.flags & 32)
        ) {
          var l = e.stateNode;
          try {
            Hn(l, "");
          } catch (T) {
            je(e, e.return, T);
          }
        }
        if (r & 4 && ((l = e.stateNode), l != null)) {
          var o = e.memoizedProps,
            s = n !== null ? n.memoizedProps : o,
            u = e.type,
            a = e.updateQueue;
          if (((e.updateQueue = null), a !== null))
            try {
              (u === "input" &&
                o.type === "radio" &&
                o.name != null &&
                Gi(l, o),
                Zl(u, s));
              var y = Zl(u, o);
              for (s = 0; s < a.length; s += 2) {
                var k = a[s],
                  j = a[s + 1];
                k === "style"
                  ? ns(l, j)
                  : k === "dangerouslySetInnerHTML"
                    ? es(l, j)
                    : k === "children"
                      ? Hn(l, j)
                      : De(l, k, j, y);
              }
              switch (u) {
                case "input":
                  $l(l, o);
                  break;
                case "textarea":
                  qi(l, o);
                  break;
                case "select":
                  var x = l._wrapperState.wasMultiple;
                  l._wrapperState.wasMultiple = !!o.multiple;
                  var M = o.value;
                  M != null
                    ? yn(l, !!o.multiple, M, !1)
                    : x !== !!o.multiple &&
                      (o.defaultValue != null
                        ? yn(l, !!o.multiple, o.defaultValue, !0)
                        : yn(l, !!o.multiple, o.multiple ? [] : "", !1));
              }
              l[cr] = o;
            } catch (T) {
              je(e, e.return, T);
            }
        }
        break;
      case 6:
        if ((vt(t, e), zt(e), r & 4)) {
          if (e.stateNode === null) throw Error(c(162));
          ((l = e.stateNode), (o = e.memoizedProps));
          try {
            l.nodeValue = o;
          } catch (T) {
            je(e, e.return, T);
          }
        }
        break;
      case 3:
        if (
          (vt(t, e), zt(e), r & 4 && n !== null && n.memoizedState.isDehydrated)
        )
          try {
            bn(t.containerInfo);
          } catch (T) {
            je(e, e.return, T);
          }
        break;
      case 4:
        (vt(t, e), zt(e));
        break;
      case 13:
        (vt(t, e),
          zt(e),
          (l = e.child),
          l.flags & 8192 &&
            ((o = l.memoizedState !== null),
            (l.stateNode.isHidden = o),
            !o ||
              (l.alternate !== null && l.alternate.memoizedState !== null) ||
              (xi = Ee())),
          r & 4 && xa(e));
        break;
      case 22:
        if (
          ((k = n !== null && n.memoizedState !== null),
          e.mode & 1 ? ((Ze = (y = Ze) || k), vt(t, e), (Ze = y)) : vt(t, e),
          zt(e),
          r & 8192)
        ) {
          if (
            ((y = e.memoizedState !== null),
            (e.stateNode.isHidden = y) && !k && (e.mode & 1) !== 0)
          )
            for (P = e, k = e.child; k !== null;) {
              for (j = P = k; P !== null;) {
                switch (((x = P), (M = x.child), x.tag)) {
                  case 0:
                  case 11:
                  case 14:
                  case 15:
                    kr(4, x, x.return);
                    break;
                  case 1:
                    Fn(x, x.return);
                    var N = x.stateNode;
                    if (typeof N.componentWillUnmount == "function") {
                      ((r = x), (n = x.return));
                      try {
                        ((t = r),
                          (N.props = t.memoizedProps),
                          (N.state = t.memoizedState),
                          N.componentWillUnmount());
                      } catch (T) {
                        je(r, n, T);
                      }
                    }
                    break;
                  case 5:
                    Fn(x, x.return);
                    break;
                  case 22:
                    if (x.memoizedState !== null) {
                      ja(j);
                      continue;
                    }
                }
                M !== null ? ((M.return = x), (P = M)) : ja(j);
              }
              k = k.sibling;
            }
          e: for (k = null, j = e; ;) {
            if (j.tag === 5) {
              if (k === null) {
                k = j;
                try {
                  ((l = j.stateNode),
                    y
                      ? ((o = l.style),
                        typeof o.setProperty == "function"
                          ? o.setProperty("display", "none", "important")
                          : (o.display = "none"))
                      : ((u = j.stateNode),
                        (a = j.memoizedProps.style),
                        (s =
                          a != null && a.hasOwnProperty("display")
                            ? a.display
                            : null),
                        (u.style.display = ts("display", s))));
                } catch (T) {
                  je(e, e.return, T);
                }
              }
            } else if (j.tag === 6) {
              if (k === null)
                try {
                  j.stateNode.nodeValue = y ? "" : j.memoizedProps;
                } catch (T) {
                  je(e, e.return, T);
                }
            } else if (
              ((j.tag !== 22 && j.tag !== 23) ||
                j.memoizedState === null ||
                j === e) &&
              j.child !== null
            ) {
              ((j.child.return = j), (j = j.child));
              continue;
            }
            if (j === e) break e;
            for (; j.sibling === null;) {
              if (j.return === null || j.return === e) break e;
              (k === j && (k = null), (j = j.return));
            }
            (k === j && (k = null),
              (j.sibling.return = j.return),
              (j = j.sibling));
          }
        }
        break;
      case 19:
        (vt(t, e), zt(e), r & 4 && xa(e));
        break;
      case 21:
        break;
      default:
        (vt(t, e), zt(e));
    }
  }
  function zt(e) {
    var t = e.flags;
    if (t & 2) {
      try {
        e: {
          for (var n = e.return; n !== null;) {
            if (ya(n)) {
              var r = n;
              break e;
            }
            n = n.return;
          }
          throw Error(c(160));
        }
        switch (r.tag) {
          case 5:
            var l = r.stateNode;
            r.flags & 32 && (Hn(l, ""), (r.flags &= -33));
            var o = ga(e);
            yi(e, o, l);
            break;
          case 3:
          case 4:
            var s = r.stateNode.containerInfo,
              u = ga(e);
            mi(e, u, s);
            break;
          default:
            throw Error(c(161));
        }
      } catch (a) {
        je(e, e.return, a);
      }
      e.flags &= -3;
    }
    t & 4096 && (e.flags &= -4097);
  }
  function Bf(e, t, n) {
    ((P = e), ka(e));
  }
  function ka(e, t, n) {
    for (var r = (e.mode & 1) !== 0; P !== null;) {
      var l = P,
        o = l.child;
      if (l.tag === 22 && r) {
        var s = l.memoizedState !== null || xl;
        if (!s) {
          var u = l.alternate,
            a = (u !== null && u.memoizedState !== null) || Ze;
          u = xl;
          var y = Ze;
          if (((xl = s), (Ze = a) && !y))
            for (P = l; P !== null;)
              ((s = P),
                (a = s.child),
                s.tag === 22 && s.memoizedState !== null
                  ? za(l)
                  : a !== null
                    ? ((a.return = s), (P = a))
                    : za(l));
          for (; o !== null;) ((P = o), ka(o), (o = o.sibling));
          ((P = l), (xl = u), (Ze = y));
        }
        Sa(e);
      } else
        (l.subtreeFlags & 8772) !== 0 && o !== null
          ? ((o.return = l), (P = o))
          : Sa(e);
    }
  }
  function Sa(e) {
    for (; P !== null;) {
      var t = P;
      if ((t.flags & 8772) !== 0) {
        var n = t.alternate;
        try {
          if ((t.flags & 8772) !== 0)
            switch (t.tag) {
              case 0:
              case 11:
              case 15:
                Ze || wl(5, t);
                break;
              case 1:
                var r = t.stateNode;
                if (t.flags & 4 && !Ze)
                  if (n === null) r.componentDidMount();
                  else {
                    var l =
                      t.elementType === t.type
                        ? n.memoizedProps
                        : yt(t.type, n.memoizedProps);
                    r.componentDidUpdate(
                      l,
                      n.memoizedState,
                      r.__reactInternalSnapshotBeforeUpdate,
                    );
                  }
                var o = t.updateQueue;
                o !== null && ju(t, o, r);
                break;
              case 3:
                var s = t.updateQueue;
                if (s !== null) {
                  if (((n = null), t.child !== null))
                    switch (t.child.tag) {
                      case 5:
                        n = t.child.stateNode;
                        break;
                      case 1:
                        n = t.child.stateNode;
                    }
                  ju(t, s, n);
                }
                break;
              case 5:
                var u = t.stateNode;
                if (n === null && t.flags & 4) {
                  n = u;
                  var a = t.memoizedProps;
                  switch (t.type) {
                    case "button":
                    case "input":
                    case "select":
                    case "textarea":
                      a.autoFocus && n.focus();
                      break;
                    case "img":
                      a.src && (n.src = a.src);
                  }
                }
                break;
              case 6:
                break;
              case 4:
                break;
              case 12:
                break;
              case 13:
                if (t.memoizedState === null) {
                  var y = t.alternate;
                  if (y !== null) {
                    var k = y.memoizedState;
                    if (k !== null) {
                      var j = k.dehydrated;
                      j !== null && bn(j);
                    }
                  }
                }
                break;
              case 19:
              case 17:
              case 21:
              case 22:
              case 23:
              case 25:
                break;
              default:
                throw Error(c(163));
            }
          Ze || (t.flags & 512 && hi(t));
        } catch (x) {
          je(t, t.return, x);
        }
      }
      if (t === e) {
        P = null;
        break;
      }
      if (((n = t.sibling), n !== null)) {
        ((n.return = t.return), (P = n));
        break;
      }
      P = t.return;
    }
  }
  function ja(e) {
    for (; P !== null;) {
      var t = P;
      if (t === e) {
        P = null;
        break;
      }
      var n = t.sibling;
      if (n !== null) {
        ((n.return = t.return), (P = n));
        break;
      }
      P = t.return;
    }
  }
  function za(e) {
    for (; P !== null;) {
      var t = P;
      try {
        switch (t.tag) {
          case 0:
          case 11:
          case 15:
            var n = t.return;
            try {
              wl(4, t);
            } catch (a) {
              je(t, n, a);
            }
            break;
          case 1:
            var r = t.stateNode;
            if (typeof r.componentDidMount == "function") {
              var l = t.return;
              try {
                r.componentDidMount();
              } catch (a) {
                je(t, l, a);
              }
            }
            var o = t.return;
            try {
              hi(t);
            } catch (a) {
              je(t, o, a);
            }
            break;
          case 5:
            var s = t.return;
            try {
              hi(t);
            } catch (a) {
              je(t, s, a);
            }
        }
      } catch (a) {
        je(t, t.return, a);
      }
      if (t === e) {
        P = null;
        break;
      }
      var u = t.sibling;
      if (u !== null) {
        ((u.return = t.return), (P = u));
        break;
      }
      P = t.return;
    }
  }
  var Vf = Math.ceil,
    kl = oe.ReactCurrentDispatcher,
    gi = oe.ReactCurrentOwner,
    ft = oe.ReactCurrentBatchConfig,
    J = 0,
    Fe = null,
    Le = null,
    We = 0,
    ot = 0,
    Un = Bt(0),
    Te = 0,
    Sr = null,
    fn = 0,
    Sl = 0,
    vi = 0,
    jr = null,
    Je = null,
    xi = 0,
    An = 1 / 0,
    Rt = null,
    jl = !1,
    wi = null,
    Yt = null,
    zl = !1,
    Xt = null,
    Cl = 0,
    zr = 0,
    ki = null,
    El = -1,
    _l = 0;
  function Ge() {
    return (J & 6) !== 0 ? Ee() : El !== -1 ? El : (El = Ee());
  }
  function qt(e) {
    return (e.mode & 1) === 0
      ? 1
      : (J & 2) !== 0 && We !== 0
        ? We & -We
        : _f.transition !== null
          ? (_l === 0 && (_l = gs()), _l)
          : ((e = se),
            e !== 0 ||
              ((e = window.event), (e = e === void 0 ? 16 : Es(e.type))),
            e);
  }
  function xt(e, t, n, r) {
    if (50 < zr) throw ((zr = 0), (ki = null), Error(c(185)));
    (Gn(e, n, r),
      ((J & 2) === 0 || e !== Fe) &&
        (e === Fe && ((J & 2) === 0 && (Sl |= n), Te === 4 && Jt(e, We)),
        be(e, r),
        n === 1 &&
          J === 0 &&
          (t.mode & 1) === 0 &&
          ((An = Ee() + 500), tl && Qt())));
  }
  function be(e, t) {
    var n = e.callbackNode;
    Ec(e, t);
    var r = Ir(e, e === Fe ? We : 0);
    if (r === 0)
      (n !== null && hs(n), (e.callbackNode = null), (e.callbackPriority = 0));
    else if (((t = r & -r), e.callbackPriority !== t)) {
      if ((n != null && hs(n), t === 1))
        (e.tag === 0 ? Ef(Ea.bind(null, e)) : fu(Ea.bind(null, e)),
          Sf(function () {
            (J & 6) === 0 && Qt();
          }),
          (n = null));
      else {
        switch (vs(r)) {
          case 1:
            n = bl;
            break;
          case 4:
            n = ms;
            break;
          case 16:
            n = Rr;
            break;
          case 536870912:
            n = ys;
            break;
          default:
            n = Rr;
        }
        n = Oa(n, Ca.bind(null, e));
      }
      ((e.callbackPriority = t), (e.callbackNode = n));
    }
  }
  function Ca(e, t) {
    if (((El = -1), (_l = 0), (J & 6) !== 0)) throw Error(c(327));
    var n = e.callbackNode;
    if (Wn() && e.callbackNode !== n) return null;
    var r = Ir(e, e === Fe ? We : 0);
    if (r === 0) return null;
    if ((r & 30) !== 0 || (r & e.expiredLanes) !== 0 || t) t = Ml(e, r);
    else {
      t = r;
      var l = J;
      J |= 2;
      var o = Ma();
      (Fe !== e || We !== t) && ((Rt = null), (An = Ee() + 500), pn(e, t));
      do
        try {
          Kf();
          break;
        } catch (u) {
          _a(e, u);
        }
      while (!0);
      (Ao(),
        (kl.current = o),
        (J = l),
        Le !== null ? (t = 0) : ((Fe = null), (We = 0), (t = Te)));
    }
    if (t !== 0) {
      if (
        (t === 2 && ((l = eo(e)), l !== 0 && ((r = l), (t = Si(e, l)))),
        t === 1)
      )
        throw ((n = Sr), pn(e, 0), Jt(e, r), be(e, Ee()), n);
      if (t === 6) Jt(e, r);
      else {
        if (
          ((l = e.current.alternate),
          (r & 30) === 0 &&
            !Qf(l) &&
            ((t = Ml(e, r)),
            t === 2 && ((o = eo(e)), o !== 0 && ((r = o), (t = Si(e, o)))),
            t === 1))
        )
          throw ((n = Sr), pn(e, 0), Jt(e, r), be(e, Ee()), n);
        switch (((e.finishedWork = l), (e.finishedLanes = r), t)) {
          case 0:
          case 1:
            throw Error(c(345));
          case 2:
            hn(e, Je, Rt);
            break;
          case 3:
            if (
              (Jt(e, r),
              (r & 130023424) === r && ((t = xi + 500 - Ee()), 10 < t))
            ) {
              if (Ir(e, 0) !== 0) break;
              if (((l = e.suspendedLanes), (l & r) !== r)) {
                (Ge(), (e.pingedLanes |= e.suspendedLanes & l));
                break;
              }
              e.timeoutHandle = Mo(hn.bind(null, e, Je, Rt), t);
              break;
            }
            hn(e, Je, Rt);
            break;
          case 4:
            if ((Jt(e, r), (r & 4194240) === r)) break;
            for (t = e.eventTimes, l = -1; 0 < r;) {
              var s = 31 - pt(r);
              ((o = 1 << s), (s = t[s]), s > l && (l = s), (r &= ~o));
            }
            if (
              ((r = l),
              (r = Ee() - r),
              (r =
                (120 > r
                  ? 120
                  : 480 > r
                    ? 480
                    : 1080 > r
                      ? 1080
                      : 1920 > r
                        ? 1920
                        : 3e3 > r
                          ? 3e3
                          : 4320 > r
                            ? 4320
                            : 1960 * Vf(r / 1960)) - r),
              10 < r)
            ) {
              e.timeoutHandle = Mo(hn.bind(null, e, Je, Rt), r);
              break;
            }
            hn(e, Je, Rt);
            break;
          case 5:
            hn(e, Je, Rt);
            break;
          default:
            throw Error(c(329));
        }
      }
    }
    return (be(e, Ee()), e.callbackNode === n ? Ca.bind(null, e) : null);
  }
  function Si(e, t) {
    var n = jr;
    return (
      e.current.memoizedState.isDehydrated && (pn(e, t).flags |= 256),
      (e = Ml(e, t)),
      e !== 2 && ((t = Je), (Je = n), t !== null && ji(t)),
      e
    );
  }
  function ji(e) {
    Je === null ? (Je = e) : Je.push.apply(Je, e);
  }
  function Qf(e) {
    for (var t = e; ;) {
      if (t.flags & 16384) {
        var n = t.updateQueue;
        if (n !== null && ((n = n.stores), n !== null))
          for (var r = 0; r < n.length; r++) {
            var l = n[r],
              o = l.getSnapshot;
            l = l.value;
            try {
              if (!ht(o(), l)) return !1;
            } catch {
              return !1;
            }
          }
      }
      if (((n = t.child), t.subtreeFlags & 16384 && n !== null))
        ((n.return = t), (t = n));
      else {
        if (t === e) break;
        for (; t.sibling === null;) {
          if (t.return === null || t.return === e) return !0;
          t = t.return;
        }
        ((t.sibling.return = t.return), (t = t.sibling));
      }
    }
    return !0;
  }
  function Jt(e, t) {
    for (
      t &= ~vi,
        t &= ~Sl,
        e.suspendedLanes |= t,
        e.pingedLanes &= ~t,
        e = e.expirationTimes;
      0 < t;
    ) {
      var n = 31 - pt(t),
        r = 1 << n;
      ((e[n] = -1), (t &= ~r));
    }
  }
  function Ea(e) {
    if ((J & 6) !== 0) throw Error(c(327));
    Wn();
    var t = Ir(e, 0);
    if ((t & 1) === 0) return (be(e, Ee()), null);
    var n = Ml(e, t);
    if (e.tag !== 0 && n === 2) {
      var r = eo(e);
      r !== 0 && ((t = r), (n = Si(e, r)));
    }
    if (n === 1) throw ((n = Sr), pn(e, 0), Jt(e, t), be(e, Ee()), n);
    if (n === 6) throw Error(c(345));
    return (
      (e.finishedWork = e.current.alternate),
      (e.finishedLanes = t),
      hn(e, Je, Rt),
      be(e, Ee()),
      null
    );
  }
  function zi(e, t) {
    var n = J;
    J |= 1;
    try {
      return e(t);
    } finally {
      ((J = n), J === 0 && ((An = Ee() + 500), tl && Qt()));
    }
  }
  function dn(e) {
    Xt !== null && Xt.tag === 0 && (J & 6) === 0 && Wn();
    var t = J;
    J |= 1;
    var n = ft.transition,
      r = se;
    try {
      if (((ft.transition = null), (se = 1), e)) return e();
    } finally {
      ((se = r), (ft.transition = n), (J = t), (J & 6) === 0 && Qt());
    }
  }
  function Ci() {
    ((ot = Un.current), me(Un));
  }
  function pn(e, t) {
    ((e.finishedWork = null), (e.finishedLanes = 0));
    var n = e.timeoutHandle;
    if ((n !== -1 && ((e.timeoutHandle = -1), kf(n)), Le !== null))
      for (n = Le.return; n !== null;) {
        var r = n;
        switch ((Oo(r), r.tag)) {
          case 1:
            ((r = r.type.childContextTypes), r != null && br());
            break;
          case 3:
            (Dn(), me(Ye), me(Be), Ko());
            break;
          case 5:
            Qo(r);
            break;
          case 4:
            Dn();
            break;
          case 13:
            me(we);
            break;
          case 19:
            me(we);
            break;
          case 10:
            Wo(r.type._context);
            break;
          case 22:
          case 23:
            Ci();
        }
        n = n.return;
      }
    if (
      ((Fe = e),
      (Le = e = bt(e.current, null)),
      (We = ot = t),
      (Te = 0),
      (Sr = null),
      (vi = Sl = fn = 0),
      (Je = jr = null),
      un !== null)
    ) {
      for (t = 0; t < un.length; t++)
        if (((n = un[t]), (r = n.interleaved), r !== null)) {
          n.interleaved = null;
          var l = r.next,
            o = n.pending;
          if (o !== null) {
            var s = o.next;
            ((o.next = l), (r.next = s));
          }
          n.pending = r;
        }
      un = null;
    }
    return e;
  }
  function _a(e, t) {
    do {
      var n = Le;
      try {
        if ((Ao(), (fl.current = ml), dl)) {
          for (var r = ke.memoizedState; r !== null;) {
            var l = r.queue;
            (l !== null && (l.pending = null), (r = r.next));
          }
          dl = !1;
        }
        if (
          ((cn = 0),
          (Ie = Re = ke = null),
          (yr = !1),
          (gr = 0),
          (gi.current = null),
          n === null || n.return === null)
        ) {
          ((Te = 1), (Sr = t), (Le = null));
          break;
        }
        e: {
          var o = e,
            s = n.return,
            u = n,
            a = t;
          if (
            ((t = We),
            (u.flags |= 32768),
            a !== null && typeof a == "object" && typeof a.then == "function")
          ) {
            var y = a,
              k = u,
              j = k.tag;
            if ((k.mode & 1) === 0 && (j === 0 || j === 11 || j === 15)) {
              var x = k.alternate;
              x
                ? ((k.updateQueue = x.updateQueue),
                  (k.memoizedState = x.memoizedState),
                  (k.lanes = x.lanes))
                : ((k.updateQueue = null), (k.memoizedState = null));
            }
            var M = Ju(s);
            if (M !== null) {
              ((M.flags &= -257),
                bu(M, s, u, o, t),
                M.mode & 1 && qu(o, y, t),
                (t = M),
                (a = y));
              var N = t.updateQueue;
              if (N === null) {
                var T = new Set();
                (T.add(a), (t.updateQueue = T));
              } else N.add(a);
              break e;
            } else {
              if ((t & 1) === 0) {
                (qu(o, y, t), Ei());
                break e;
              }
              a = Error(c(426));
            }
          } else if (ve && u.mode & 1) {
            var _e = Ju(s);
            if (_e !== null) {
              ((_e.flags & 65536) === 0 && (_e.flags |= 256),
                bu(_e, s, u, o, t),
                Fo(In(a, u)));
              break e;
            }
          }
          ((o = a = In(a, u)),
            Te !== 4 && (Te = 2),
            jr === null ? (jr = [o]) : jr.push(o),
            (o = s));
          do {
            switch (o.tag) {
              case 3:
                ((o.flags |= 65536), (t &= -t), (o.lanes |= t));
                var h = Yu(o, a, t);
                Su(o, h);
                break e;
              case 1:
                u = a;
                var f = o.type,
                  m = o.stateNode;
                if (
                  (o.flags & 128) === 0 &&
                  (typeof f.getDerivedStateFromError == "function" ||
                    (m !== null &&
                      typeof m.componentDidCatch == "function" &&
                      (Yt === null || !Yt.has(m))))
                ) {
                  ((o.flags |= 65536), (t &= -t), (o.lanes |= t));
                  var z = Xu(o, u, t);
                  Su(o, z);
                  break e;
                }
            }
            o = o.return;
          } while (o !== null);
        }
        La(n);
      } catch (O) {
        ((t = O), Le === n && n !== null && (Le = n = n.return));
        continue;
      }
      break;
    } while (!0);
  }
  function Ma() {
    var e = kl.current;
    return ((kl.current = ml), e === null ? ml : e);
  }
  function Ei() {
    ((Te === 0 || Te === 3 || Te === 2) && (Te = 4),
      Fe === null ||
        ((fn & 268435455) === 0 && (Sl & 268435455) === 0) ||
        Jt(Fe, We));
  }
  function Ml(e, t) {
    var n = J;
    J |= 2;
    var r = Ma();
    (Fe !== e || We !== t) && ((Rt = null), pn(e, t));
    do
      try {
        Zf();
        break;
      } catch (l) {
        _a(e, l);
      }
    while (!0);
    if ((Ao(), (J = n), (kl.current = r), Le !== null)) throw Error(c(261));
    return ((Fe = null), (We = 0), Te);
  }
  function Zf() {
    for (; Le !== null;) Pa(Le);
  }
  function Kf() {
    for (; Le !== null && !gc();) Pa(Le);
  }
  function Pa(e) {
    var t = Ta(e.alternate, e, ot);
    ((e.memoizedProps = e.pendingProps),
      t === null ? La(e) : (Le = t),
      (gi.current = null));
  }
  function La(e) {
    var t = e;
    do {
      var n = t.alternate;
      if (((e = t.return), (t.flags & 32768) === 0)) {
        if (((n = Af(n, t, ot)), n !== null)) {
          Le = n;
          return;
        }
      } else {
        if (((n = Wf(n, t)), n !== null)) {
          ((n.flags &= 32767), (Le = n));
          return;
        }
        if (e !== null)
          ((e.flags |= 32768), (e.subtreeFlags = 0), (e.deletions = null));
        else {
          ((Te = 6), (Le = null));
          return;
        }
      }
      if (((t = t.sibling), t !== null)) {
        Le = t;
        return;
      }
      Le = t = e;
    } while (t !== null);
    Te === 0 && (Te = 5);
  }
  function hn(e, t, n) {
    var r = se,
      l = ft.transition;
    try {
      ((ft.transition = null), (se = 1), Gf(e, t, n, r));
    } finally {
      ((ft.transition = l), (se = r));
    }
    return null;
  }
  function Gf(e, t, n, r) {
    do Wn();
    while (Xt !== null);
    if ((J & 6) !== 0) throw Error(c(327));
    n = e.finishedWork;
    var l = e.finishedLanes;
    if (n === null) return null;
    if (((e.finishedWork = null), (e.finishedLanes = 0), n === e.current))
      throw Error(c(177));
    ((e.callbackNode = null), (e.callbackPriority = 0));
    var o = n.lanes | n.childLanes;
    if (
      (_c(e, o),
      e === Fe && ((Le = Fe = null), (We = 0)),
      ((n.subtreeFlags & 2064) === 0 && (n.flags & 2064) === 0) ||
        zl ||
        ((zl = !0),
        Oa(Rr, function () {
          return (Wn(), null);
        })),
      (o = (n.flags & 15990) !== 0),
      (n.subtreeFlags & 15990) !== 0 || o)
    ) {
      ((o = ft.transition), (ft.transition = null));
      var s = se;
      se = 1;
      var u = J;
      ((J |= 4),
        (gi.current = null),
        Hf(e, n),
        wa(n, e),
        hf(Eo),
        (Ar = !!Co),
        (Eo = Co = null),
        (e.current = n),
        Bf(n),
        vc(),
        (J = u),
        (se = s),
        (ft.transition = o));
    } else e.current = n;
    if (
      (zl && ((zl = !1), (Xt = e), (Cl = l)),
      (o = e.pendingLanes),
      o === 0 && (Yt = null),
      kc(n.stateNode),
      be(e, Ee()),
      t !== null)
    )
      for (r = e.onRecoverableError, n = 0; n < t.length; n++)
        ((l = t[n]), r(l.value, { componentStack: l.stack, digest: l.digest }));
    if (jl) throw ((jl = !1), (e = wi), (wi = null), e);
    return (
      (Cl & 1) !== 0 && e.tag !== 0 && Wn(),
      (o = e.pendingLanes),
      (o & 1) !== 0 ? (e === ki ? zr++ : ((zr = 0), (ki = e))) : (zr = 0),
      Qt(),
      null
    );
  }
  function Wn() {
    if (Xt !== null) {
      var e = vs(Cl),
        t = ft.transition,
        n = se;
      try {
        if (((ft.transition = null), (se = 16 > e ? 16 : e), Xt === null))
          var r = !1;
        else {
          if (((e = Xt), (Xt = null), (Cl = 0), (J & 6) !== 0))
            throw Error(c(331));
          var l = J;
          for (J |= 4, P = e.current; P !== null;) {
            var o = P,
              s = o.child;
            if ((P.flags & 16) !== 0) {
              var u = o.deletions;
              if (u !== null) {
                for (var a = 0; a < u.length; a++) {
                  var y = u[a];
                  for (P = y; P !== null;) {
                    var k = P;
                    switch (k.tag) {
                      case 0:
                      case 11:
                      case 15:
                        kr(8, k, o);
                    }
                    var j = k.child;
                    if (j !== null) ((j.return = k), (P = j));
                    else
                      for (; P !== null;) {
                        k = P;
                        var x = k.sibling,
                          M = k.return;
                        if ((ma(k), k === y)) {
                          P = null;
                          break;
                        }
                        if (x !== null) {
                          ((x.return = M), (P = x));
                          break;
                        }
                        P = M;
                      }
                  }
                }
                var N = o.alternate;
                if (N !== null) {
                  var T = N.child;
                  if (T !== null) {
                    N.child = null;
                    do {
                      var _e = T.sibling;
                      ((T.sibling = null), (T = _e));
                    } while (T !== null);
                  }
                }
                P = o;
              }
            }
            if ((o.subtreeFlags & 2064) !== 0 && s !== null)
              ((s.return = o), (P = s));
            else
              e: for (; P !== null;) {
                if (((o = P), (o.flags & 2048) !== 0))
                  switch (o.tag) {
                    case 0:
                    case 11:
                    case 15:
                      kr(9, o, o.return);
                  }
                var h = o.sibling;
                if (h !== null) {
                  ((h.return = o.return), (P = h));
                  break e;
                }
                P = o.return;
              }
          }
          var f = e.current;
          for (P = f; P !== null;) {
            s = P;
            var m = s.child;
            if ((s.subtreeFlags & 2064) !== 0 && m !== null)
              ((m.return = s), (P = m));
            else
              e: for (s = f; P !== null;) {
                if (((u = P), (u.flags & 2048) !== 0))
                  try {
                    switch (u.tag) {
                      case 0:
                      case 11:
                      case 15:
                        wl(9, u);
                    }
                  } catch (O) {
                    je(u, u.return, O);
                  }
                if (u === s) {
                  P = null;
                  break e;
                }
                var z = u.sibling;
                if (z !== null) {
                  ((z.return = u.return), (P = z));
                  break e;
                }
                P = u.return;
              }
          }
          if (
            ((J = l), Qt(), wt && typeof wt.onPostCommitFiberRoot == "function")
          )
            try {
              wt.onPostCommitFiberRoot(Tr, e);
            } catch {}
          r = !0;
        }
        return r;
      } finally {
        ((se = n), (ft.transition = t));
      }
    }
    return !1;
  }
  function Na(e, t, n) {
    ((t = In(n, t)),
      (t = Yu(e, t, 1)),
      (e = Kt(e, t, 1)),
      (t = Ge()),
      e !== null && (Gn(e, 1, t), be(e, t)));
  }
  function je(e, t, n) {
    if (e.tag === 3) Na(e, e, n);
    else
      for (; t !== null;) {
        if (t.tag === 3) {
          Na(t, e, n);
          break;
        } else if (t.tag === 1) {
          var r = t.stateNode;
          if (
            typeof t.type.getDerivedStateFromError == "function" ||
            (typeof r.componentDidCatch == "function" &&
              (Yt === null || !Yt.has(r)))
          ) {
            ((e = In(n, e)),
              (e = Xu(t, e, 1)),
              (t = Kt(t, e, 1)),
              (e = Ge()),
              t !== null && (Gn(t, 1, e), be(t, e)));
            break;
          }
        }
        t = t.return;
      }
  }
  function Yf(e, t, n) {
    var r = e.pingCache;
    (r !== null && r.delete(t),
      (t = Ge()),
      (e.pingedLanes |= e.suspendedLanes & n),
      Fe === e &&
        (We & n) === n &&
        (Te === 4 || (Te === 3 && (We & 130023424) === We && 500 > Ee() - xi)
          ? pn(e, 0)
          : (vi |= n)),
      be(e, t));
  }
  function Ra(e, t) {
    t === 0 &&
      ((e.mode & 1) === 0
        ? (t = 1)
        : ((t = Dr), (Dr <<= 1), (Dr & 130023424) === 0 && (Dr = 4194304)));
    var n = Ge();
    ((e = Pt(e, t)), e !== null && (Gn(e, t, n), be(e, n)));
  }
  function Xf(e) {
    var t = e.memoizedState,
      n = 0;
    (t !== null && (n = t.retryLane), Ra(e, n));
  }
  function qf(e, t) {
    var n = 0;
    switch (e.tag) {
      case 13:
        var r = e.stateNode,
          l = e.memoizedState;
        l !== null && (n = l.retryLane);
        break;
      case 19:
        r = e.stateNode;
        break;
      default:
        throw Error(c(314));
    }
    (r !== null && r.delete(t), Ra(e, n));
  }
  var Ta;
  Ta = function (e, t, n) {
    if (e !== null)
      if (e.memoizedProps !== t.pendingProps || Ye.current) qe = !0;
      else {
        if ((e.lanes & n) === 0 && (t.flags & 128) === 0)
          return ((qe = !1), Uf(e, t, n));
        qe = (e.flags & 131072) !== 0;
      }
    else ((qe = !1), ve && (t.flags & 1048576) !== 0 && du(t, rl, t.index));
    switch (((t.lanes = 0), t.tag)) {
      case 2:
        var r = t.type;
        (vl(e, t), (e = t.pendingProps));
        var l = Mn(t, Be.current);
        (On(t, n), (l = Xo(null, t, r, e, l, n)));
        var o = qo();
        return (
          (t.flags |= 1),
          typeof l == "object" &&
          l !== null &&
          typeof l.render == "function" &&
          l.$$typeof === void 0
            ? ((t.tag = 1),
              (t.memoizedState = null),
              (t.updateQueue = null),
              Xe(r) ? ((o = !0), el(t)) : (o = !1),
              (t.memoizedState =
                l.state !== null && l.state !== void 0 ? l.state : null),
              Bo(t),
              (l.updater = yl),
              (t.stateNode = l),
              (l._reactInternals = t),
              ri(t, r, e, n),
              (t = si(null, t, r, !0, o, n)))
            : ((t.tag = 0), ve && o && To(t), Ke(null, t, l, n), (t = t.child)),
          t
        );
      case 16:
        r = t.elementType;
        e: {
          switch (
            (vl(e, t),
            (e = t.pendingProps),
            (l = r._init),
            (r = l(r._payload)),
            (t.type = r),
            (l = t.tag = bf(r)),
            (e = yt(r, e)),
            l)
          ) {
            case 0:
              t = ii(null, t, r, e, n);
              break e;
            case 1:
              t = oa(null, t, r, e, n);
              break e;
            case 11:
              t = ea(null, t, r, e, n);
              break e;
            case 14:
              t = ta(null, t, r, yt(r.type, e), n);
              break e;
          }
          throw Error(c(306, r, ""));
        }
        return t;
      case 0:
        return (
          (r = t.type),
          (l = t.pendingProps),
          (l = t.elementType === r ? l : yt(r, l)),
          ii(e, t, r, l, n)
        );
      case 1:
        return (
          (r = t.type),
          (l = t.pendingProps),
          (l = t.elementType === r ? l : yt(r, l)),
          oa(e, t, r, l, n)
        );
      case 3:
        e: {
          if ((ia(t), e === null)) throw Error(c(387));
          ((r = t.pendingProps),
            (o = t.memoizedState),
            (l = o.element),
            ku(e, t),
            al(t, r, null, n));
          var s = t.memoizedState;
          if (((r = s.element), o.isDehydrated))
            if (
              ((o = {
                element: r,
                isDehydrated: !1,
                cache: s.cache,
                pendingSuspenseBoundaries: s.pendingSuspenseBoundaries,
                transitions: s.transitions,
              }),
              (t.updateQueue.baseState = o),
              (t.memoizedState = o),
              t.flags & 256)
            ) {
              ((l = In(Error(c(423)), t)), (t = sa(e, t, r, n, l)));
              break e;
            } else if (r !== l) {
              ((l = In(Error(c(424)), t)), (t = sa(e, t, r, n, l)));
              break e;
            } else
              for (
                lt = Ht(t.stateNode.containerInfo.firstChild),
                  rt = t,
                  ve = !0,
                  mt = null,
                  n = xu(t, null, r, n),
                  t.child = n;
                n;
              )
                ((n.flags = (n.flags & -3) | 4096), (n = n.sibling));
          else {
            if ((Nn(), r === l)) {
              t = Nt(e, t, n);
              break e;
            }
            Ke(e, t, r, n);
          }
          t = t.child;
        }
        return t;
      case 5:
        return (
          zu(t),
          e === null && Io(t),
          (r = t.type),
          (l = t.pendingProps),
          (o = e !== null ? e.memoizedProps : null),
          (s = l.children),
          _o(r, l) ? (s = null) : o !== null && _o(r, o) && (t.flags |= 32),
          la(e, t),
          Ke(e, t, s, n),
          t.child
        );
      case 6:
        return (e === null && Io(t), null);
      case 13:
        return ua(e, t, n);
      case 4:
        return (
          Vo(t, t.stateNode.containerInfo),
          (r = t.pendingProps),
          e === null ? (t.child = Rn(t, null, r, n)) : Ke(e, t, r, n),
          t.child
        );
      case 11:
        return (
          (r = t.type),
          (l = t.pendingProps),
          (l = t.elementType === r ? l : yt(r, l)),
          ea(e, t, r, l, n)
        );
      case 7:
        return (Ke(e, t, t.pendingProps, n), t.child);
      case 8:
        return (Ke(e, t, t.pendingProps.children, n), t.child);
      case 12:
        return (Ke(e, t, t.pendingProps.children, n), t.child);
      case 10:
        e: {
          if (
            ((r = t.type._context),
            (l = t.pendingProps),
            (o = t.memoizedProps),
            (s = l.value),
            pe(il, r._currentValue),
            (r._currentValue = s),
            o !== null)
          )
            if (ht(o.value, s)) {
              if (o.children === l.children && !Ye.current) {
                t = Nt(e, t, n);
                break e;
              }
            } else
              for (o = t.child, o !== null && (o.return = t); o !== null;) {
                var u = o.dependencies;
                if (u !== null) {
                  s = o.child;
                  for (var a = u.firstContext; a !== null;) {
                    if (a.context === r) {
                      if (o.tag === 1) {
                        ((a = Lt(-1, n & -n)), (a.tag = 2));
                        var y = o.updateQueue;
                        if (y !== null) {
                          y = y.shared;
                          var k = y.pending;
                          (k === null
                            ? (a.next = a)
                            : ((a.next = k.next), (k.next = a)),
                            (y.pending = a));
                        }
                      }
                      ((o.lanes |= n),
                        (a = o.alternate),
                        a !== null && (a.lanes |= n),
                        $o(o.return, n, t),
                        (u.lanes |= n));
                      break;
                    }
                    a = a.next;
                  }
                } else if (o.tag === 10) s = o.type === t.type ? null : o.child;
                else if (o.tag === 18) {
                  if (((s = o.return), s === null)) throw Error(c(341));
                  ((s.lanes |= n),
                    (u = s.alternate),
                    u !== null && (u.lanes |= n),
                    $o(s, n, t),
                    (s = o.sibling));
                } else s = o.child;
                if (s !== null) s.return = o;
                else
                  for (s = o; s !== null;) {
                    if (s === t) {
                      s = null;
                      break;
                    }
                    if (((o = s.sibling), o !== null)) {
                      ((o.return = s.return), (s = o));
                      break;
                    }
                    s = s.return;
                  }
                o = s;
              }
          (Ke(e, t, l.children, n), (t = t.child));
        }
        return t;
      case 9:
        return (
          (l = t.type),
          (r = t.pendingProps.children),
          On(t, n),
          (l = at(l)),
          (r = r(l)),
          (t.flags |= 1),
          Ke(e, t, r, n),
          t.child
        );
      case 14:
        return (
          (r = t.type),
          (l = yt(r, t.pendingProps)),
          (l = yt(r.type, l)),
          ta(e, t, r, l, n)
        );
      case 15:
        return na(e, t, t.type, t.pendingProps, n);
      case 17:
        return (
          (r = t.type),
          (l = t.pendingProps),
          (l = t.elementType === r ? l : yt(r, l)),
          vl(e, t),
          (t.tag = 1),
          Xe(r) ? ((e = !0), el(t)) : (e = !1),
          On(t, n),
          Ku(t, r, l),
          ri(t, r, l, n),
          si(null, t, r, !0, e, n)
        );
      case 19:
        return ca(e, t, n);
      case 22:
        return ra(e, t, n);
    }
    throw Error(c(156, t.tag));
  };
  function Oa(e, t) {
    return ps(e, t);
  }
  function Jf(e, t, n, r) {
    ((this.tag = e),
      (this.key = n),
      (this.sibling =
        this.child =
        this.return =
        this.stateNode =
        this.type =
        this.elementType =
          null),
      (this.index = 0),
      (this.ref = null),
      (this.pendingProps = t),
      (this.dependencies =
        this.memoizedState =
        this.updateQueue =
        this.memoizedProps =
          null),
      (this.mode = r),
      (this.subtreeFlags = this.flags = 0),
      (this.deletions = null),
      (this.childLanes = this.lanes = 0),
      (this.alternate = null));
  }
  function dt(e, t, n, r) {
    return new Jf(e, t, n, r);
  }
  function _i(e) {
    return ((e = e.prototype), !(!e || !e.isReactComponent));
  }
  function bf(e) {
    if (typeof e == "function") return _i(e) ? 1 : 0;
    if (e != null) {
      if (((e = e.$$typeof), e === He)) return 11;
      if (e === ye) return 14;
    }
    return 2;
  }
  function bt(e, t) {
    var n = e.alternate;
    return (
      n === null
        ? ((n = dt(e.tag, t, e.key, e.mode)),
          (n.elementType = e.elementType),
          (n.type = e.type),
          (n.stateNode = e.stateNode),
          (n.alternate = e),
          (e.alternate = n))
        : ((n.pendingProps = t),
          (n.type = e.type),
          (n.flags = 0),
          (n.subtreeFlags = 0),
          (n.deletions = null)),
      (n.flags = e.flags & 14680064),
      (n.childLanes = e.childLanes),
      (n.lanes = e.lanes),
      (n.child = e.child),
      (n.memoizedProps = e.memoizedProps),
      (n.memoizedState = e.memoizedState),
      (n.updateQueue = e.updateQueue),
      (t = e.dependencies),
      (n.dependencies =
        t === null ? null : { lanes: t.lanes, firstContext: t.firstContext }),
      (n.sibling = e.sibling),
      (n.index = e.index),
      (n.ref = e.ref),
      n
    );
  }
  function Pl(e, t, n, r, l, o) {
    var s = 2;
    if (((r = e), typeof e == "function")) _i(e) && (s = 1);
    else if (typeof e == "string") s = 5;
    else
      e: switch (e) {
        case Y:
          return mn(n.children, l, o, t);
        case Z:
          ((s = 8), (l |= 8));
          break;
        case q:
          return (
            (e = dt(12, n, t, l | 2)),
            (e.elementType = q),
            (e.lanes = o),
            e
          );
        case Ne:
          return (
            (e = dt(13, n, t, l)),
            (e.elementType = Ne),
            (e.lanes = o),
            e
          );
        case fe:
          return (
            (e = dt(19, n, t, l)),
            (e.elementType = fe),
            (e.lanes = o),
            e
          );
        case ue:
          return Ll(n, l, o, t);
        default:
          if (typeof e == "object" && e !== null)
            switch (e.$$typeof) {
              case xe:
                s = 10;
                break e;
              case it:
                s = 9;
                break e;
              case He:
                s = 11;
                break e;
              case ye:
                s = 14;
                break e;
              case Se:
                ((s = 16), (r = null));
                break e;
            }
          throw Error(c(130, e == null ? e : typeof e, ""));
      }
    return (
      (t = dt(s, n, t, l)),
      (t.elementType = e),
      (t.type = r),
      (t.lanes = o),
      t
    );
  }
  function mn(e, t, n, r) {
    return ((e = dt(7, e, r, t)), (e.lanes = n), e);
  }
  function Ll(e, t, n, r) {
    return (
      (e = dt(22, e, r, t)),
      (e.elementType = ue),
      (e.lanes = n),
      (e.stateNode = { isHidden: !1 }),
      e
    );
  }
  function Mi(e, t, n) {
    return ((e = dt(6, e, null, t)), (e.lanes = n), e);
  }
  function Pi(e, t, n) {
    return (
      (t = dt(4, e.children !== null ? e.children : [], e.key, t)),
      (t.lanes = n),
      (t.stateNode = {
        containerInfo: e.containerInfo,
        pendingChildren: null,
        implementation: e.implementation,
      }),
      t
    );
  }
  function ed(e, t, n, r, l) {
    ((this.tag = t),
      (this.containerInfo = e),
      (this.finishedWork =
        this.pingCache =
        this.current =
        this.pendingChildren =
          null),
      (this.timeoutHandle = -1),
      (this.callbackNode = this.pendingContext = this.context = null),
      (this.callbackPriority = 0),
      (this.eventTimes = to(0)),
      (this.expirationTimes = to(-1)),
      (this.entangledLanes =
        this.finishedLanes =
        this.mutableReadLanes =
        this.expiredLanes =
        this.pingedLanes =
        this.suspendedLanes =
        this.pendingLanes =
          0),
      (this.entanglements = to(0)),
      (this.identifierPrefix = r),
      (this.onRecoverableError = l),
      (this.mutableSourceEagerHydrationData = null));
  }
  function Li(e, t, n, r, l, o, s, u, a) {
    return (
      (e = new ed(e, t, n, u, a)),
      t === 1 ? ((t = 1), o === !0 && (t |= 8)) : (t = 0),
      (o = dt(3, null, null, t)),
      (e.current = o),
      (o.stateNode = e),
      (o.memoizedState = {
        element: r,
        isDehydrated: n,
        cache: null,
        transitions: null,
        pendingSuspenseBoundaries: null,
      }),
      Bo(o),
      e
    );
  }
  function td(e, t, n) {
    var r =
      3 < arguments.length && arguments[3] !== void 0 ? arguments[3] : null;
    return {
      $$typeof: D,
      key: r == null ? null : "" + r,
      children: e,
      containerInfo: t,
      implementation: n,
    };
  }
  function Da(e) {
    if (!e) return Vt;
    e = e._reactInternals;
    e: {
      if (nn(e) !== e || e.tag !== 1) throw Error(c(170));
      var t = e;
      do {
        switch (t.tag) {
          case 3:
            t = t.stateNode.context;
            break e;
          case 1:
            if (Xe(t.type)) {
              t = t.stateNode.__reactInternalMemoizedMergedChildContext;
              break e;
            }
        }
        t = t.return;
      } while (t !== null);
      throw Error(c(171));
    }
    if (e.tag === 1) {
      var n = e.type;
      if (Xe(n)) return au(e, n, t);
    }
    return t;
  }
  function Ia(e, t, n, r, l, o, s, u, a) {
    return (
      (e = Li(n, r, !0, e, l, o, s, u, a)),
      (e.context = Da(null)),
      (n = e.current),
      (r = Ge()),
      (l = qt(n)),
      (o = Lt(r, l)),
      (o.callback = t ?? null),
      Kt(n, o, l),
      (e.current.lanes = l),
      Gn(e, l, r),
      be(e, r),
      e
    );
  }
  function Nl(e, t, n, r) {
    var l = t.current,
      o = Ge(),
      s = qt(l);
    return (
      (n = Da(n)),
      t.context === null ? (t.context = n) : (t.pendingContext = n),
      (t = Lt(o, s)),
      (t.payload = { element: e }),
      (r = r === void 0 ? null : r),
      r !== null && (t.callback = r),
      (e = Kt(l, t, s)),
      e !== null && (xt(e, l, s, o), ul(e, l, s)),
      s
    );
  }
  function Rl(e) {
    if (((e = e.current), !e.child)) return null;
    switch (e.child.tag) {
      case 5:
        return e.child.stateNode;
      default:
        return e.child.stateNode;
    }
  }
  function Fa(e, t) {
    if (((e = e.memoizedState), e !== null && e.dehydrated !== null)) {
      var n = e.retryLane;
      e.retryLane = n !== 0 && n < t ? n : t;
    }
  }
  function Ni(e, t) {
    (Fa(e, t), (e = e.alternate) && Fa(e, t));
  }
  function nd() {
    return null;
  }
  var Ua =
    typeof reportError == "function"
      ? reportError
      : function (e) {
          console.error(e);
        };
  function Ri(e) {
    this._internalRoot = e;
  }
  ((Tl.prototype.render = Ri.prototype.render =
    function (e) {
      var t = this._internalRoot;
      if (t === null) throw Error(c(409));
      Nl(e, t, null, null);
    }),
    (Tl.prototype.unmount = Ri.prototype.unmount =
      function () {
        var e = this._internalRoot;
        if (e !== null) {
          this._internalRoot = null;
          var t = e.containerInfo;
          (dn(function () {
            Nl(null, e, null, null);
          }),
            (t[Ct] = null));
        }
      }));
  function Tl(e) {
    this._internalRoot = e;
  }
  Tl.prototype.unstable_scheduleHydration = function (e) {
    if (e) {
      var t = ks();
      e = { blockedOn: null, target: e, priority: t };
      for (var n = 0; n < At.length && t !== 0 && t < At[n].priority; n++);
      (At.splice(n, 0, e), n === 0 && zs(e));
    }
  };
  function Ti(e) {
    return !(!e || (e.nodeType !== 1 && e.nodeType !== 9 && e.nodeType !== 11));
  }
  function Ol(e) {
    return !(
      !e ||
      (e.nodeType !== 1 &&
        e.nodeType !== 9 &&
        e.nodeType !== 11 &&
        (e.nodeType !== 8 || e.nodeValue !== " react-mount-point-unstable "))
    );
  }
  function Aa() {}
  function rd(e, t, n, r, l) {
    if (l) {
      if (typeof r == "function") {
        var o = r;
        r = function () {
          var y = Rl(s);
          o.call(y);
        };
      }
      var s = Ia(t, r, e, 0, null, !1, !1, "", Aa);
      return (
        (e._reactRootContainer = s),
        (e[Ct] = s.current),
        ur(e.nodeType === 8 ? e.parentNode : e),
        dn(),
        s
      );
    }
    for (; (l = e.lastChild);) e.removeChild(l);
    if (typeof r == "function") {
      var u = r;
      r = function () {
        var y = Rl(a);
        u.call(y);
      };
    }
    var a = Li(e, 0, !1, null, null, !1, !1, "", Aa);
    return (
      (e._reactRootContainer = a),
      (e[Ct] = a.current),
      ur(e.nodeType === 8 ? e.parentNode : e),
      dn(function () {
        Nl(t, a, n, r);
      }),
      a
    );
  }
  function Dl(e, t, n, r, l) {
    var o = n._reactRootContainer;
    if (o) {
      var s = o;
      if (typeof l == "function") {
        var u = l;
        l = function () {
          var a = Rl(s);
          u.call(a);
        };
      }
      Nl(t, s, e, l);
    } else s = rd(n, t, e, l, r);
    return Rl(s);
  }
  ((xs = function (e) {
    switch (e.tag) {
      case 3:
        var t = e.stateNode;
        if (t.current.memoizedState.isDehydrated) {
          var n = Kn(t.pendingLanes);
          n !== 0 &&
            (no(t, n | 1),
            be(t, Ee()),
            (J & 6) === 0 && ((An = Ee() + 500), Qt()));
        }
        break;
      case 13:
        (dn(function () {
          var r = Pt(e, 1);
          if (r !== null) {
            var l = Ge();
            xt(r, e, 1, l);
          }
        }),
          Ni(e, 1));
    }
  }),
    (ro = function (e) {
      if (e.tag === 13) {
        var t = Pt(e, 134217728);
        if (t !== null) {
          var n = Ge();
          xt(t, e, 134217728, n);
        }
        Ni(e, 134217728);
      }
    }),
    (ws = function (e) {
      if (e.tag === 13) {
        var t = qt(e),
          n = Pt(e, t);
        if (n !== null) {
          var r = Ge();
          xt(n, e, t, r);
        }
        Ni(e, t);
      }
    }),
    (ks = function () {
      return se;
    }),
    (Ss = function (e, t) {
      var n = se;
      try {
        return ((se = e), t());
      } finally {
        se = n;
      }
    }),
    (Yl = function (e, t, n) {
      switch (t) {
        case "input":
          if (($l(e, n), (t = n.name), n.type === "radio" && t != null)) {
            for (n = e; n.parentNode;) n = n.parentNode;
            for (
              n = n.querySelectorAll(
                "input[name=" + JSON.stringify("" + t) + '][type="radio"]',
              ),
                t = 0;
              t < n.length;
              t++
            ) {
              var r = n[t];
              if (r !== e && r.form === e.form) {
                var l = Jr(r);
                if (!l) throw Error(c(90));
                (Zi(r), $l(r, l));
              }
            }
          }
          break;
        case "textarea":
          qi(e, n);
          break;
        case "select":
          ((t = n.value), t != null && yn(e, !!n.multiple, t, !1));
      }
    }),
    (is = zi),
    (ss = dn));
  var ld = { usingClientEntryPoint: !1, Events: [fr, En, Jr, ls, os, zi] },
    Cr = {
      findFiberByHostInstance: rn,
      bundleType: 0,
      version: "18.3.1",
      rendererPackageName: "react-dom",
    },
    od = {
      bundleType: Cr.bundleType,
      version: Cr.version,
      rendererPackageName: Cr.rendererPackageName,
      rendererConfig: Cr.rendererConfig,
      overrideHookState: null,
      overrideHookStateDeletePath: null,
      overrideHookStateRenamePath: null,
      overrideProps: null,
      overridePropsDeletePath: null,
      overridePropsRenamePath: null,
      setErrorHandler: null,
      setSuspenseHandler: null,
      scheduleUpdate: null,
      currentDispatcherRef: oe.ReactCurrentDispatcher,
      findHostInstanceByFiber: function (e) {
        return ((e = fs(e)), e === null ? null : e.stateNode);
      },
      findFiberByHostInstance: Cr.findFiberByHostInstance || nd,
      findHostInstancesForRefresh: null,
      scheduleRefresh: null,
      scheduleRoot: null,
      setRefreshHandler: null,
      getCurrentFiber: null,
      reconcilerVersion: "18.3.1-next-f1338f8080-20240426",
    };
  if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u") {
    var Il = __REACT_DEVTOOLS_GLOBAL_HOOK__;
    if (!Il.isDisabled && Il.supportsFiber)
      try {
        ((Tr = Il.inject(od)), (wt = Il));
      } catch {}
  }
  return (
    (et.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = ld),
    (et.createPortal = function (e, t) {
      var n =
        2 < arguments.length && arguments[2] !== void 0 ? arguments[2] : null;
      if (!Ti(t)) throw Error(c(200));
      return td(e, t, null, n);
    }),
    (et.createRoot = function (e, t) {
      if (!Ti(e)) throw Error(c(299));
      var n = !1,
        r = "",
        l = Ua;
      return (
        t != null &&
          (t.unstable_strictMode === !0 && (n = !0),
          t.identifierPrefix !== void 0 && (r = t.identifierPrefix),
          t.onRecoverableError !== void 0 && (l = t.onRecoverableError)),
        (t = Li(e, 1, !1, null, null, n, !1, r, l)),
        (e[Ct] = t.current),
        ur(e.nodeType === 8 ? e.parentNode : e),
        new Ri(t)
      );
    }),
    (et.findDOMNode = function (e) {
      if (e == null) return null;
      if (e.nodeType === 1) return e;
      var t = e._reactInternals;
      if (t === void 0)
        throw typeof e.render == "function"
          ? Error(c(188))
          : ((e = Object.keys(e).join(",")), Error(c(268, e)));
      return ((e = fs(t)), (e = e === null ? null : e.stateNode), e);
    }),
    (et.flushSync = function (e) {
      return dn(e);
    }),
    (et.hydrate = function (e, t, n) {
      if (!Ol(t)) throw Error(c(200));
      return Dl(null, e, t, !0, n);
    }),
    (et.hydrateRoot = function (e, t, n) {
      if (!Ti(e)) throw Error(c(405));
      var r = (n != null && n.hydratedSources) || null,
        l = !1,
        o = "",
        s = Ua;
      if (
        (n != null &&
          (n.unstable_strictMode === !0 && (l = !0),
          n.identifierPrefix !== void 0 && (o = n.identifierPrefix),
          n.onRecoverableError !== void 0 && (s = n.onRecoverableError)),
        (t = Ia(t, null, e, 1, n ?? null, l, !1, o, s)),
        (e[Ct] = t.current),
        ur(e),
        r)
      )
        for (e = 0; e < r.length; e++)
          ((n = r[e]),
            (l = n._getVersion),
            (l = l(n._source)),
            t.mutableSourceEagerHydrationData == null
              ? (t.mutableSourceEagerHydrationData = [n, l])
              : t.mutableSourceEagerHydrationData.push(n, l));
      return new Tl(t);
    }),
    (et.render = function (e, t, n) {
      if (!Ol(t)) throw Error(c(200));
      return Dl(null, e, t, !1, n);
    }),
    (et.unmountComponentAtNode = function (e) {
      if (!Ol(e)) throw Error(c(40));
      return e._reactRootContainer
        ? (dn(function () {
            Dl(null, null, e, !1, function () {
              ((e._reactRootContainer = null), (e[Ct] = null));
            });
          }),
          !0)
        : !1;
    }),
    (et.unstable_batchedUpdates = zi),
    (et.unstable_renderSubtreeIntoContainer = function (e, t, n, r) {
      if (!Ol(n)) throw Error(c(200));
      if (e == null || e._reactInternals === void 0) throw Error(c(38));
      return Dl(e, t, n, !1, r);
    }),
    (et.version = "18.3.1-next-f1338f8080-20240426"),
    et
  );
}
var Ka;
function hd() {
  if (Ka) return Ii.exports;
  Ka = 1;
  function d() {
    if (!(
      typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > "u" ||
      typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != "function"
    ))
      try {
        __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(d);
      } catch (g) {
        console.error(g);
      }
  }
  return (d(), (Ii.exports = pd()), Ii.exports);
}
var Ga;
function md() {
  if (Ga) return Fl;
  Ga = 1;
  var d = hd();
  return ((Fl.createRoot = d.createRoot), (Fl.hydrateRoot = d.hydrateRoot), Fl);
}
var yd = md();
const gd = lc(yd),
  vd = 3600 * 12,
  Bi = "comp_school_local_development_session",
  xd = "https://comp.school/fallback",
  tn = "comp.school",
  wd = /^(preview-[a-z0-9-]+)(?:\.[a-z0-9-]+)?\.comp\.school$/i,
  kd = /^(preview-[a-z0-9-]+)\.[a-z0-9-]+\.pages\.dev$/i,
  Sd = Object.freeze({
    "comp.school": 3e3,
    "code.comp.school": 3001,
    "admin.comp.school": 3002,
    "exams.comp.school": 3010,
    "recall.comp.school": 3011,
    "forms.comp.school": 3012,
    "mark.comp.school": 3013,
    "games.comp.school": 3014,
    "self-assess.comp.school": 3015,
    "issues.comp.school": 3016,
    "printouts.comp.school": 3017,
    "docs.comp.school": 3018,
  });
function Vi(d) {
  const g = d
    .trim()
    .toLowerCase()
    .replace(/^\[|\]$/g, "");
  return g === "localhost" || g === "127.0.0.1" || g === "::1";
}
function jd(d) {
  return [
    `${Bi}=${encodeURIComponent(JSON.stringify({ version: 1, user: d }))}`,
    "Path=/",
    `Max-Age=${vd}`,
    "SameSite=Lax",
  ].join("; ");
}
function zd() {
  return [`${Bi}=`, "Path=/", "Max-Age=0", "SameSite=Lax"].join("; ");
}
function oc(d, g, c) {
  if (!c || !Vi(g)) return null;
  const S = Td(d)[Bi];
  if (!S) return null;
  try {
    const C = JSON.parse(S),
      _ = C.user;
    return C.version !== 1 ||
      !_ ||
      typeof _.id != "string" ||
      typeof _.name != "string" ||
      !["admin", "teacher", "student"].includes(_.role)
      ? null
      : _;
  } catch {
    return null;
  }
}
function Cd(d) {
  return btoa(d).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}
function Ed(d) {
  let g = "";
  for (const c of d) g += String.fromCharCode(c);
  return Cd(g);
}
function _d(d) {
  if (!d || !/^[A-Za-z0-9_-]+$/.test(d))
    throw new Error("Invalid base64url value");
  const g = d
      .replace(/-/g, "+")
      .replace(/_/g, "/")
      .padEnd(Math.ceil(d.length / 4) * 4, "="),
    c = atob(g),
    S = new Uint8Array(c.length);
  for (let C = 0; C < c.length; C += 1) S[C] = c.charCodeAt(C);
  if (Ed(S) !== d) throw new Error("Non-canonical base64url value");
  return S;
}
function Md(d) {
  const g = _d(d);
  return new TextDecoder("utf-8", { fatal: !0 }).decode(g);
}
function Pd(d) {
  return !!d && typeof d == "object" && !Array.isArray(d);
}
function Ld(d) {
  const g = JSON.parse(d);
  if (!Pd(g)) throw new Error("Expected a JSON object");
  return g;
}
function ic(d) {
  const g = d.trim().toLowerCase();
  return (g.match(wd) || g.match(kd))?.[1] || null;
}
function sc(d) {
  if (Vi(d))
    return `http://${d.replace(/^\[|\]$/g, "") === "::1" ? "[::1]" : d}:3000`;
  const g = ic(d);
  return g ? `https://${g}.${tn}` : `https://${tn}`;
}
function uc(d, g) {
  if (Vi(d))
    try {
      const S = new URL(g),
        C = Sd[S.hostname.toLowerCase()];
      if (C)
        return (
          (S.protocol = "http:"),
          (S.hostname = d),
          (S.port = String(C)),
          S.toString()
        );
    } catch {
      return g;
    }
  const c = ic(d);
  if (!c) return g;
  try {
    const S = new URL(g),
      C = S.hostname.toLowerCase();
    if (C === tn || C.endsWith(`.${tn}`))
      return (
        (S.hostname = C === tn ? `${c}.${tn}` : `${c}.${C}`),
        S.toString()
      );
  } catch {
    return g;
  }
  return g;
}
function Nd(d) {
  if (!d?.trim()) return null;
  try {
    const g = new URL(d),
      c = g.hostname.toLowerCase();
    return g.protocol !== "https:" ||
      g.username ||
      g.password ||
      g.port ||
      c === tn ||
      !c.endsWith(`.${tn}`)
      ? null
      : g.toString();
  } catch {
    return null;
  }
}
function Rd(d, g, c) {
  const S = c?.trim() || sc(d),
    C = Nd(uc(d, g));
  if (!C) return S;
  try {
    const _ = new URL(S);
    return (_.searchParams.set("returnTo", C), _.toString());
  } catch {
    return S;
  }
}
function Td(d) {
  return d
    ? d.split(";").reduce((g, c) => {
        const [S, ...C] = c.trim().split("=");
        if (!S) return g;
        const _ = C.join("=");
        try {
          g[S] = decodeURIComponent(_);
        } catch {
          g[S] = _;
        }
        return g;
      }, {})
    : {};
}
function Ya(d, g = new Date()) {
  if (!d) return !1;
  try {
    const [c] = d.split("."),
      S = Ld(Md(c));
    return (
      S.iss === xd &&
      typeof S.exp == "number" &&
      Number.isInteger(S.exp) &&
      S.exp > Math.floor(g.getTime() / 1e3)
    );
  } catch {
    return !1;
  }
}
const Xa = 64,
  qa = { x: 9, y: 12, width: 46, height: 44, rx: 13 },
  X = "#1f2937",
  Oe = "#ffffff",
  ze = 33,
  Ot = 24,
  Dt = 40,
  Ja = new Set(["shell"]);
function Al(d) {
  return d.detail || d.shade;
}
function Od(d) {
  const { shade: g, accent: c } = d,
    S = Al(d);
  switch (d.ears) {
    case "pointed":
      return i.jsxs("g", {
        children: [
          i.jsx("path", { d: "M11 26 17 3 30 17Z", fill: g }),
          i.jsx("path", { d: "M53 26 47 3 34 17Z", fill: g }),
          i.jsx("path", { d: "M16.5 22 19 9.5 26 17Z", fill: c }),
          i.jsx("path", { d: "M47.5 22 45 9.5 38 17Z", fill: c }),
        ],
      });
    case "round":
      return i.jsxs("g", {
        children: [
          i.jsx("circle", { cx: "17", cy: "14", r: "8.5", fill: g }),
          i.jsx("circle", { cx: "47", cy: "14", r: "8.5", fill: g }),
          i.jsx("circle", { cx: "17", cy: "14", r: "4", fill: c }),
          i.jsx("circle", { cx: "47", cy: "14", r: "4", fill: c }),
        ],
      });
    case "tall":
      return i.jsxs("g", {
        children: [
          i.jsxs("g", {
            transform: "rotate(-9 20.5 9)",
            children: [
              i.jsx("rect", {
                x: "15",
                y: "-5",
                width: "11",
                height: "27",
                rx: "5.5",
                fill: g,
              }),
              i.jsx("rect", {
                x: "18",
                y: "0",
                width: "5",
                height: "18",
                rx: "2.5",
                fill: c,
              }),
            ],
          }),
          i.jsxs("g", {
            transform: "rotate(9 43.5 9)",
            children: [
              i.jsx("rect", {
                x: "38",
                y: "-5",
                width: "11",
                height: "27",
                rx: "5.5",
                fill: g,
              }),
              i.jsx("rect", {
                x: "41",
                y: "0",
                width: "5",
                height: "18",
                rx: "2.5",
                fill: c,
              }),
            ],
          }),
        ],
      });
    case "floppy":
      return i.jsxs("g", {
        fill: g,
        children: [
          i.jsx("path", { d: "M15 16C5 18 3 34 9 41c5 4 9-2 9-11Z" }),
          i.jsx("path", { d: "M49 16c10 2 12 18 6 25-5 4-9-2-9-11Z" }),
        ],
      });
    case "tuft":
      return i.jsxs("g", {
        fill: g,
        children: [
          i.jsx("path", { d: "M12 19 15.5 5 24 15.5Z" }),
          i.jsx("path", { d: "M52 19 48.5 5 40 15.5Z" }),
        ],
      });
    case "horns":
      return i.jsxs("g", {
        fill: S,
        children: [
          i.jsx("path", {
            d: "M17.5 13C10 11 6 5 10.5 1.5c2.5 3.5 6.5 6.5 10.5 8.5Z",
          }),
          i.jsx("path", {
            d: "M46.5 13C54 11 58 5 53.5 1.5c-2.5 3.5-6.5 6.5-10.5 8.5Z",
          }),
        ],
      });
    case "antlers":
      return i.jsxs("g", {
        stroke: S,
        strokeWidth: "3",
        strokeLinecap: "round",
        fill: "none",
        children: [
          i.jsx("path", { d: "M21 14 16 3" }),
          i.jsx("path", { d: "M17.6 8 10 5" }),
          i.jsx("path", { d: "M43 14 48 3" }),
          i.jsx("path", { d: "M46.4 8 54 5" }),
        ],
      });
    case "flap":
      return i.jsxs("g", {
        children: [
          i.jsx("ellipse", { cx: "10", cy: "32", rx: "10", ry: "15", fill: g }),
          i.jsx("ellipse", { cx: "54", cy: "32", rx: "10", ry: "15", fill: g }),
          i.jsx("ellipse", { cx: "11", cy: "32", rx: "5", ry: "9", fill: c }),
          i.jsx("ellipse", { cx: "53", cy: "32", rx: "5", ry: "9", fill: c }),
        ],
      });
    case "spikes":
      return i.jsx("path", {
        d: "M8 22 13 3 20 18 26 1 32 17 38 1 44 18 51 3 56 22Z",
        fill: g,
      });
    case "crest":
      return i.jsxs("g", {
        fill: S,
        children: [
          i.jsx("circle", { cx: "25", cy: "10", r: "5" }),
          i.jsx("circle", { cx: "32", cy: "5.5", r: "5.5" }),
          i.jsx("circle", { cx: "39", cy: "10", r: "5" }),
        ],
      });
    case "fins":
      return i.jsxs("g", {
        fill: g,
        children: [
          i.jsx("path", { d: "M12 26 1 19 4 37Z" }),
          i.jsx("path", { d: "M52 26 63 19 60 37Z" }),
          i.jsx("path", { d: "M25 13 32 1 39 13Z" }),
        ],
      });
    case "antennae":
      return i.jsxs("g", {
        children: [
          i.jsxs("g", {
            stroke: g,
            strokeWidth: "2.6",
            strokeLinecap: "round",
            fill: "none",
            children: [
              i.jsx("path", { d: "M23 14C20 7 17 4 13.5 3" }),
              i.jsx("path", { d: "M41 14c3-7 6-10 9.5-11" }),
            ],
          }),
          i.jsx("circle", { cx: "12.5", cy: "3", r: "3", fill: g }),
          i.jsx("circle", { cx: "51.5", cy: "3", r: "3", fill: g }),
        ],
      });
    case "mane":
      return i.jsx("g", {
        fill: S,
        children: Array.from({ length: 12 }, (C, _) => {
          const $ = (_ / 12) * Math.PI * 2;
          return i.jsx(
            "circle",
            { cx: 32 + Math.cos($) * 25, cy: 34 + Math.sin($) * 23, r: "8.5" },
            _,
          );
        }),
      });
    case "wool":
      return i.jsxs("g", {
        fill: c,
        children: [
          i.jsx("circle", { cx: "15", cy: "17", r: "8" }),
          i.jsx("circle", { cx: "26", cy: "10", r: "9" }),
          i.jsx("circle", { cx: "38", cy: "10", r: "9" }),
          i.jsx("circle", { cx: "49", cy: "17", r: "8" }),
        ],
      });
    case "wings":
      return i.jsxs("g", {
        fill: S,
        children: [
          i.jsx("path", { d: "M13 22C-1 16 0 42 12 46Z" }),
          i.jsx("path", { d: "M51 22c14-6 13 20 1 24Z" }),
        ],
      });
    case "tentacles":
      return i.jsxs("g", {
        fill: g,
        children: [
          i.jsx("path", { d: "M12 44c-6 4-8 12-6 18 4 1 7-5 9-11Z" }),
          i.jsx("path", { d: "M52 44c6 4 8 12 6 18-4 1-7-5-9-11Z" }),
          i.jsx("path", { d: "M25 50c-3 6-3 12-1 14 3 0 5-6 5-12Z" }),
          i.jsx("path", { d: "M39 50c3 6 3 12 1 14-3 0-5-6-5-12Z" }),
        ],
      });
    case "dome":
      return i.jsx("path", { d: "M11 22a21 21 0 0 1 42 0Z", fill: g });
    case "frill":
      return i.jsxs("g", {
        children: [
          i.jsx("path", { d: "M1 42C1 16 14 1 32 1s31 15 31 41Z", fill: g }),
          i.jsx("g", {
            fill: c,
            children: Array.from({ length: 9 }, (C, _) => {
              const $ = Math.PI + (_ + 0.5) * (Math.PI / 9);
              return i.jsx(
                "circle",
                {
                  cx: 32 + Math.cos($) * 27,
                  cy: 40 + Math.sin($) * 33,
                  r: "3.2",
                },
                _,
              );
            }),
          }),
        ],
      });
    case "rays":
      return i.jsx("g", {
        fill: S,
        children: Array.from({ length: 12 }, (C, _) => {
          const $ = (_ / 12) * 360;
          return i.jsx(
            "path",
            { d: "M32 2 27 12h10Z", transform: `rotate(${$} 32 34)` },
            _,
          );
        }),
      });
    case "points":
      return i.jsxs("g", {
        fill: g,
        children: [
          i.jsx("path", { d: "M32 0 24 16h16Z" }),
          i.jsx("path", { d: "M6 14 12 30l12-9Z" }),
          i.jsx("path", { d: "M58 14 52 30l-12-9Z" }),
          i.jsx("path", { d: "M8 56 4 42l14 4Z" }),
          i.jsx("path", { d: "M56 56l4-14-14 4Z" }),
        ],
      });
    case "none":
    default:
      return null;
  }
}
function Dd(d) {
  const { base: g, shade: c } = d,
    S = Al(d);
  switch (d.eyes) {
    case "round":
      return i.jsxs("g", {
        children: [
          i.jsx("circle", { cx: Ot, cy: ze, r: "6.5", fill: Oe }),
          i.jsx("circle", { cx: Dt, cy: ze, r: "6.5", fill: Oe }),
          i.jsx("circle", { cx: Ot, cy: ze, r: "3.4", fill: X }),
          i.jsx("circle", { cx: Dt, cy: ze, r: "3.4", fill: X }),
          i.jsx("circle", { cx: Ot + 1.4, cy: ze - 1.6, r: "1.3", fill: Oe }),
          i.jsx("circle", { cx: Dt + 1.4, cy: ze - 1.6, r: "1.3", fill: Oe }),
        ],
      });
    case "big":
      return i.jsxs("g", {
        children: [
          i.jsx("circle", { cx: "23", cy: "32", r: "9.5", fill: Oe }),
          i.jsx("circle", { cx: "41", cy: "32", r: "9.5", fill: Oe }),
          i.jsx("circle", { cx: "23", cy: "32", r: "5", fill: X }),
          i.jsx("circle", { cx: "41", cy: "32", r: "5", fill: X }),
          i.jsx("circle", { cx: "24.6", cy: "30.2", r: "1.9", fill: Oe }),
          i.jsx("circle", { cx: "42.6", cy: "30.2", r: "1.9", fill: Oe }),
        ],
      });
    case "bulge":
      return i.jsxs("g", {
        children: [
          i.jsx("circle", {
            cx: "20",
            cy: "14",
            r: "9",
            fill: g,
            stroke: c,
            strokeWidth: "1.6",
          }),
          i.jsx("circle", {
            cx: "44",
            cy: "14",
            r: "9",
            fill: g,
            stroke: c,
            strokeWidth: "1.6",
          }),
          i.jsx("circle", { cx: "20", cy: "13.5", r: "4.8", fill: Oe }),
          i.jsx("circle", { cx: "44", cy: "13.5", r: "4.8", fill: Oe }),
          i.jsx("circle", { cx: "20", cy: "13.5", r: "2.6", fill: X }),
          i.jsx("circle", { cx: "44", cy: "13.5", r: "2.6", fill: X }),
        ],
      });
    case "slit":
      return i.jsxs("g", {
        children: [
          i.jsx("ellipse", { cx: Ot, cy: ze, rx: "5.4", ry: "6", fill: S }),
          i.jsx("ellipse", { cx: Dt, cy: ze, rx: "5.4", ry: "6", fill: S }),
          i.jsx("ellipse", { cx: Ot, cy: ze, rx: "1.8", ry: "5", fill: X }),
          i.jsx("ellipse", { cx: Dt, cy: ze, rx: "1.8", ry: "5", fill: X }),
        ],
      });
    case "sleepy":
      return i.jsxs("g", {
        stroke: X,
        strokeWidth: "3",
        strokeLinecap: "round",
        fill: "none",
        children: [
          i.jsx("path", { d: "M18.5 31.5q5.5 5 11 0" }),
          i.jsx("path", { d: "M34.5 31.5q5.5 5 11 0" }),
        ],
      });
    case "wide":
      return i.jsxs("g", {
        children: [
          i.jsx("circle", { cx: "20", cy: ze, r: "3.8", fill: X }),
          i.jsx("circle", { cx: "44", cy: ze, r: "3.8", fill: X }),
          i.jsx("circle", { cx: "21.3", cy: ze - 1.4, r: "1.3", fill: Oe }),
          i.jsx("circle", { cx: "45.3", cy: ze - 1.4, r: "1.3", fill: Oe }),
        ],
      });
    case "turret":
      return i.jsxs("g", {
        children: [
          i.jsx("circle", { cx: "21", cy: "31", r: "7.5", fill: c }),
          i.jsx("circle", { cx: "43", cy: "31", r: "7.5", fill: c }),
          i.jsx("circle", { cx: "21", cy: "31", r: "3.6", fill: S }),
          i.jsx("circle", { cx: "43", cy: "31", r: "3.6", fill: S }),
          i.jsx("circle", { cx: "21", cy: "31", r: "1.7", fill: X }),
          i.jsx("circle", { cx: "43", cy: "31", r: "1.7", fill: X }),
        ],
      });
    case "compound":
      return i.jsxs("g", {
        children: [
          i.jsx("ellipse", {
            cx: "22",
            cy: "31",
            rx: "7.5",
            ry: "9",
            fill: X,
            transform: "rotate(-12 22 31)",
          }),
          i.jsx("ellipse", {
            cx: "42",
            cy: "31",
            rx: "7.5",
            ry: "9",
            fill: X,
            transform: "rotate(12 42 31)",
          }),
          i.jsx("ellipse", {
            cx: "20.5",
            cy: "28",
            rx: "2.2",
            ry: "3",
            fill: Oe,
            opacity: "0.75",
          }),
          i.jsx("ellipse", {
            cx: "43.5",
            cy: "28",
            rx: "2.2",
            ry: "3",
            fill: Oe,
            opacity: "0.75",
          }),
        ],
      });
    case "stalk":
      return i.jsxs("g", {
        children: [
          i.jsxs("g", {
            stroke: c,
            strokeWidth: "2.8",
            strokeLinecap: "round",
            fill: "none",
            children: [
              i.jsx("path", { d: "M23 16 19.5 5" }),
              i.jsx("path", { d: "M41 16 44.5 5" }),
            ],
          }),
          i.jsx("circle", {
            cx: "19",
            cy: "4",
            r: "3.8",
            fill: Oe,
            stroke: c,
            strokeWidth: "1.2",
          }),
          i.jsx("circle", {
            cx: "45",
            cy: "4",
            r: "3.8",
            fill: Oe,
            stroke: c,
            strokeWidth: "1.2",
          }),
          i.jsx("circle", { cx: "19", cy: "4", r: "1.8", fill: X }),
          i.jsx("circle", { cx: "45", cy: "4", r: "1.8", fill: X }),
        ],
      });
    case "visor":
      return i.jsxs("g", {
        children: [
          i.jsx("rect", {
            x: "14",
            y: "26.5",
            width: "36",
            height: "13",
            rx: "6.5",
            fill: X,
          }),
          i.jsx("circle", { cx: Ot, cy: ze, r: "3.2", fill: S }),
          i.jsx("circle", { cx: Dt, cy: ze, r: "3.2", fill: S }),
        ],
      });
    case "dot":
    default:
      return i.jsxs("g", {
        children: [
          i.jsx("circle", { cx: Ot, cy: ze, r: "4.2", fill: X }),
          i.jsx("circle", { cx: Dt, cy: ze, r: "4.2", fill: X }),
          i.jsx("circle", { cx: Ot + 1.4, cy: ze - 1.5, r: "1.4", fill: Oe }),
          i.jsx("circle", { cx: Dt + 1.4, cy: ze - 1.5, r: "1.4", fill: Oe }),
        ],
      });
  }
}
function ba() {
  return i.jsxs("g", {
    children: [
      i.jsx("path", { d: "M27.5 39q4.5-3.4 9 0Q32 44.6 27.5 39Z", fill: X }),
      i.jsx("path", {
        d: "M32 43.5v2.4M32 45.9q-2.4 2.6-4.6.4M32 45.9q2.4 2.6 4.6.4",
        stroke: X,
        strokeWidth: "2",
        strokeLinecap: "round",
        fill: "none",
      }),
    ],
  });
}
function Id(d) {
  const { accent: g, shade: c } = d,
    S = Al(d);
  switch (d.muzzle) {
    case "nose":
      return ba();
    case "snout":
      return i.jsxs("g", {
        children: [
          i.jsx("ellipse", { cx: "32", cy: "43", rx: "13", ry: "9", fill: g }),
          ba(),
        ],
      });
    case "beak":
      return i.jsxs("g", {
        children: [
          i.jsx("path", { d: "M23 38h18l-9 11Z", fill: S }),
          i.jsx("path", {
            d: "M23 38h18",
            stroke: X,
            strokeWidth: "1.4",
            opacity: "0.35",
          }),
        ],
      });
    case "bill":
      return i.jsxs("g", {
        children: [
          i.jsx("rect", {
            x: "19",
            y: "37.5",
            width: "26",
            height: "11.5",
            rx: "5.75",
            fill: S,
          }),
          i.jsx("circle", { cx: "26", cy: "41.5", r: "1.3", fill: X }),
          i.jsx("circle", { cx: "38", cy: "41.5", r: "1.3", fill: X }),
        ],
      });
    case "pig":
      return i.jsxs("g", {
        children: [
          i.jsx("ellipse", { cx: "32", cy: "43", rx: "11", ry: "8", fill: g }),
          i.jsx("ellipse", { cx: "28", cy: "43", rx: "2.2", ry: "3", fill: X }),
          i.jsx("ellipse", { cx: "36", cy: "43", rx: "2.2", ry: "3", fill: X }),
        ],
      });
    case "wide":
      return i.jsx("path", {
        d: "M16 41q16 11 32 0",
        stroke: X,
        strokeWidth: "3",
        strokeLinecap: "round",
        fill: "none",
      });
    case "tusks":
      return i.jsxs("g", {
        children: [
          i.jsx("ellipse", {
            cx: "32",
            cy: "42",
            rx: "13",
            ry: "8.5",
            fill: g,
          }),
          i.jsx("ellipse", {
            cx: "32",
            cy: "38.5",
            rx: "3.4",
            ry: "2.6",
            fill: X,
          }),
          i.jsx("path", {
            d: "M27 45q-1.6 8-3.6 12M37 45q1.6 8 3.6 12",
            stroke: "#f8fafc",
            strokeWidth: "3.6",
            strokeLinecap: "round",
            fill: "none",
          }),
        ],
      });
    case "trunk":
      return i.jsx("path", {
        d: "M32 36q0 10-3 14t2 10",
        stroke: c,
        strokeWidth: "7.5",
        strokeLinecap: "round",
        fill: "none",
      });
    case "mandibles":
      return i.jsxs("g", {
        stroke: X,
        strokeWidth: "2.6",
        strokeLinecap: "round",
        fill: "none",
        children: [
          i.jsx("path", { d: "M26 43q6 6 12 0" }),
          i.jsx("path", { d: "M24.5 41q-3.5 4.5 0 8" }),
          i.jsx("path", { d: "M39.5 41q3.5 4.5 0 8" }),
        ],
      });
    case "grill":
      return i.jsxs("g", {
        children: [
          i.jsx("rect", {
            x: "23",
            y: "41",
            width: "18",
            height: "8",
            rx: "4",
            fill: X,
          }),
          i.jsx("path", {
            d: "M28 41v8M32 41v8M36 41v8",
            stroke: S,
            strokeWidth: "1.4",
            opacity: "0.8",
          }),
        ],
      });
    case "smile":
    default:
      return i.jsx("path", {
        d: "M26.5 42.5q5.5 5 11 0",
        stroke: X,
        strokeWidth: "2.8",
        strokeLinecap: "round",
        fill: "none",
      });
  }
}
function Ai(d, g, c) {
  const { shade: S, accent: C } = g,
    _ = Al(g);
  switch (d) {
    case "mask":
      return i.jsxs(
        "g",
        {
          clipPath: `url(#${c})`,
          fill: S,
          children: [
            i.jsx("ellipse", { cx: Ot, cy: ze - 0.5, rx: "9", ry: "8.5" }),
            i.jsx("ellipse", { cx: Dt, cy: ze - 0.5, rx: "9", ry: "8.5" }),
          ],
        },
        d,
      );
    case "stripes":
      return i.jsxs(
        "g",
        {
          clipPath: `url(#${c})`,
          stroke: S,
          strokeWidth: "3.4",
          strokeLinecap: "round",
          fill: "none",
          children: [
            i.jsx("path", { d: "M19 11q3 8-2 14" }),
            i.jsx("path", { d: "M32 10v10" }),
            i.jsx("path", { d: "M45 11q-3 8 2 14" }),
          ],
        },
        d,
      );
    case "spots":
      return i.jsxs(
        "g",
        {
          clipPath: `url(#${c})`,
          fill: S,
          opacity: "0.8",
          children: [
            i.jsx("circle", { cx: "16", cy: "24", r: "4" }),
            i.jsx("circle", { cx: "48", cy: "24", r: "4" }),
            i.jsx("circle", { cx: "14", cy: "42", r: "3.4" }),
            i.jsx("circle", { cx: "50", cy: "42", r: "3.4" }),
            i.jsx("circle", { cx: "32", cy: "18", r: "3.4" }),
          ],
        },
        d,
      );
    case "blush":
      return i.jsxs(
        "g",
        {
          clipPath: `url(#${c})`,
          fill: "#f87171",
          opacity: "0.35",
          children: [
            i.jsx("ellipse", { cx: "15", cy: "40", rx: "5.5", ry: "3.6" }),
            i.jsx("ellipse", { cx: "49", cy: "40", rx: "5.5", ry: "3.6" }),
          ],
        },
        d,
      );
    case "patch":
      return i.jsx(
        "g",
        {
          clipPath: `url(#${c})`,
          children: i.jsx("rect", {
            x: "15",
            y: "37",
            width: "34",
            height: "21",
            rx: "11",
            fill: C,
            opacity: "0.9",
          }),
        },
        d,
      );
    case "whiskers":
      return i.jsx(
        "g",
        {
          stroke: X,
          strokeWidth: "1.7",
          strokeLinecap: "round",
          opacity: "0.65",
          fill: "none",
          children: i.jsx("path", {
            d: "M18 40 6 37M18 43.5 6 44M46 40l12-3M46 43.5l12 .5",
          }),
        },
        d,
      );
    case "brows":
      return i.jsxs(
        "g",
        {
          stroke: X,
          strokeWidth: "3",
          strokeLinecap: "round",
          fill: "none",
          children: [
            i.jsx("path", { d: "M17.5 24.5 29 28.5" }),
            i.jsx("path", { d: "M46.5 24.5 35 28.5" }),
          ],
        },
        d,
      );
    case "horn":
      return i.jsxs(
        "g",
        {
          children: [
            i.jsx("path", { d: "M28 15 32-2l4 17Z", fill: _ }),
            i.jsx("path", {
              d: "M29.4 10.5h5.2M30.4 6h3.2",
              stroke: X,
              strokeWidth: "1.3",
              opacity: "0.35",
            }),
          ],
        },
        d,
      );
    case "tongue":
      return i.jsx("path", { d: "M28.5 45q3.5 9 7 0Z", fill: "#f472b6" }, d);
    case "fangs":
      return i.jsxs(
        "g",
        {
          fill: Oe,
          children: [
            i.jsx("path", { d: "M26.5 42 29 48l2.5-6Z" }),
            i.jsx("path", { d: "M32.5 42 35 48l2.5-6Z" }),
          ],
        },
        d,
      );
    case "sparkle":
      return i.jsxs(
        "g",
        {
          fill: _,
          children: [
            i.jsx("path", {
              d: "M53 8 54.4 12 58 13.4 54.4 14.8 53 18.6 51.6 14.8 48 13.4 51.6 12Z",
            }),
            i.jsx("path", {
              d: "M10 44 11 47 14 48 11 49 10 52 9 49 6 48 9 47Z",
            }),
          ],
        },
        d,
      );
    case "crown":
      return i.jsxs(
        "g",
        {
          children: [
            i.jsx("path", {
              d: "M19 13 23 3l5 6 5-8 5 8 5-6 4 10Z",
              fill: "#fbbf24",
            }),
            i.jsx("circle", { cx: "32", cy: "6", r: "1.8", fill: "#fde68a" }),
          ],
        },
        d,
      );
    case "shell":
      return i.jsxs(
        "g",
        {
          children: [
            i.jsx("path", { d: "M0 61q0-27 32-27t32 27Z", fill: _ }),
            i.jsxs("g", {
              fill: S,
              opacity: "0.55",
              children: [
                i.jsx("circle", { cx: "5.5", cy: "52", r: "3" }),
                i.jsx("circle", { cx: "58.5", cy: "52", r: "3" }),
                i.jsx("circle", { cx: "20", cy: "59", r: "3" }),
                i.jsx("circle", { cx: "44", cy: "59", r: "3" }),
                i.jsx("circle", { cx: "32", cy: "60", r: "3" }),
              ],
            }),
          ],
        },
        d,
      );
    case "stitches":
      return i.jsxs(
        "g",
        {
          clipPath: `url(#${c})`,
          stroke: S,
          strokeWidth: "1.8",
          strokeLinecap: "round",
          children: [
            i.jsx("path", { d: "M45 12v14" }),
            i.jsx("path", { d: "M41.5 16h7M41.5 21h7" }),
            i.jsx("path", { d: "M14 44h9" }),
            i.jsx("path", { d: "M17 41.5v5M21 41.5v5" }),
          ],
        },
        d,
      );
    case "bolt":
      return i.jsx(
        "path",
        { d: "M49 2 39 18h6l-8 14 20-20h-7l6-10Z", fill: _ },
        d,
      );
    case "bandage":
      return i.jsxs(
        "g",
        {
          clipPath: `url(#${c})`,
          fill: C,
          opacity: "0.9",
          children: [
            i.jsx("path", { d: "M2 20 62 12v7L2 27Z" }),
            i.jsx("path", { d: "M2 44 62 36v7L2 51Z" }),
            i.jsx("path", { d: "M6 56 58 48v6H6Z" }),
          ],
        },
        d,
      );
    case "visorGlow":
      return i.jsx(
        "g",
        {
          opacity: "0.75",
          children: i.jsx("path", {
            d: "M18 27q14-6 28 0",
            stroke: _,
            strokeWidth: "2",
            fill: "none",
            strokeLinecap: "round",
          }),
        },
        d,
      );
    default:
      return null;
  }
}
function Fd({ features: d, idSuffix: g, className: c, title: S }) {
  const C = `cs-avatar-head-${g}`,
    _ = d.marks || [],
    $ = _.filter((R) => Ja.has(R)),
    K = _.filter((R) => !Ja.has(R));
  return i.jsxs("svg", {
    className: c,
    viewBox: `0 0 ${Xa} ${Xa}`,
    width: "100%",
    height: "100%",
    role: S ? "img" : "presentation",
    "aria-label": S,
    "aria-hidden": S ? void 0 : !0,
    focusable: "false",
    children: [
      i.jsx("defs", {
        children: i.jsx("clipPath", {
          id: C,
          children: i.jsx("rect", { ...qa }),
        }),
      }),
      $.map((R) => Ai(R, d, C)),
      Od(d),
      i.jsx("rect", { ...qa, fill: d.base }),
      K.filter(
        (R) =>
          R === "mask" ||
          R === "stripes" ||
          R === "spots" ||
          R === "patch" ||
          R === "bandage",
      ).map((R) => Ai(R, d, C)),
      Id(d),
      Dd(d),
      K.filter(
        (R) =>
          !(
            R === "mask" ||
            R === "stripes" ||
            R === "spots" ||
            R === "patch" ||
            R === "bandage"
          ),
      ).map((R) => Ai(R, d, C)),
    ],
  });
}
const Ud = {
  rust: ["#ef8043", "#cd5f27", "#ffe0c6"],
  amber: ["#f0993f", "#cb7220", "#ffe8cd"],
  brown: ["#a97551", "#7d5133", "#f2ddc8"],
  cocoa: ["#8b5e3c", "#5d3c23", "#ebd6c1"],
  sand: ["#e6c48b", "#c39a55", "#fdf1da"],
  cream: ["#f3e3c3", "#d6b988", "#fff8ea"],
  grey: ["#9aa8bb", "#6b7c93", "#e6edf5"],
  slate: ["#7c8ba1", "#4f5d74", "#dde5ef"],
  charcoal: ["#4d5765", "#2e3641", "#c6cedb"],
  snow: ["#eef3f9", "#c0cbd9", "#ffffff"],
  pink: ["#f5a6ba", "#da7c92", "#ffe4ec"],
  rose: ["#ef8ba2", "#cd6079", "#ffdde5"],
  green: ["#5fba70", "#3d9350", "#d9f2dd"],
  moss: ["#7fbc5a", "#5d9639", "#e4f5d5"],
  lime: ["#95cf57", "#6da733", "#eafada"],
  teal: ["#42b5a8", "#2a8a80", "#d3f1ed"],
  blue: ["#5c9cd6", "#3c74a7", "#dceaf8"],
  sky: ["#7cc4ef", "#4d9acb", "#e3f3fd"],
  navy: ["#41628f", "#2b4568", "#d0dcec"],
  yellow: ["#f3c552", "#d09c2c", "#fff3d0"],
  gold: ["#e9aa3c", "#c1811d", "#ffeecb"],
  purple: ["#a68bf5", "#7c5cef", "#e9e3ff"],
  violet: ["#8a6fd4", "#63499f", "#e0d8f6"],
  red: ["#e15c4f", "#b73e33", "#fbdad5"],
  stone: ["#98a0a8", "#6a737c", "#dfe4e8"],
};
function v(d, g, c, S, C) {
  const [_, $, K] = Ud[S];
  return { id: d, label: g, group: c, base: _, shade: $, accent: K, ...C };
}
const Ad = Object.freeze([
    v("fox", "Fox", "woodland", "rust", {
      ears: "pointed",
      eyes: "round",
      muzzle: "snout",
      marks: ["whiskers"],
    }),
    v("owl", "Owl", "woodland", "cocoa", {
      ears: "tuft",
      eyes: "big",
      muzzle: "beak",
      detail: "#f3c552",
    }),
    v("bear", "Bear", "woodland", "brown", {
      ears: "round",
      eyes: "dot",
      muzzle: "snout",
    }),
    v("panda", "Panda", "woodland", "snow", {
      ears: "round",
      eyes: "dot",
      muzzle: "snout",
      marks: ["mask"],
      shade: "#39414d",
    }),
    v("wolf", "Wolf", "woodland", "slate", {
      ears: "pointed",
      eyes: "round",
      muzzle: "snout",
    }),
    v("badger", "Badger", "woodland", "snow", {
      ears: "round",
      eyes: "dot",
      muzzle: "snout",
      marks: ["mask"],
      shade: "#3b4553",
    }),
    v("hedgehog", "Hedgehog", "woodland", "sand", {
      ears: "spikes",
      eyes: "dot",
      muzzle: "nose",
    }),
    v("squirrel", "Squirrel", "woodland", "amber", {
      ears: "tuft",
      eyes: "round",
      muzzle: "nose",
      marks: ["patch"],
    }),
    v("deer", "Deer", "woodland", "sand", {
      ears: "antlers",
      eyes: "round",
      muzzle: "snout",
      marks: ["spots"],
      detail: "#8b5e3c",
    }),
    v("raccoon", "Raccoon", "woodland", "grey", {
      ears: "round",
      eyes: "dot",
      muzzle: "snout",
      marks: ["mask"],
      shade: "#3e4756",
    }),
    v("cat", "Cat", "pets", "amber", {
      ears: "pointed",
      eyes: "slit",
      muzzle: "nose",
      marks: ["stripes", "whiskers"],
      detail: "#5fba70",
    }),
    v("dog", "Dog", "pets", "brown", {
      ears: "floppy",
      eyes: "round",
      muzzle: "snout",
    }),
    v("rabbit", "Rabbit", "pets", "cream", {
      ears: "tall",
      eyes: "round",
      muzzle: "nose",
      marks: ["blush"],
    }),
    v("hamster", "Hamster", "pets", "sand", {
      ears: "round",
      eyes: "dot",
      muzzle: "nose",
      marks: ["patch", "blush"],
    }),
    v("guineapig", "Guinea pig", "pets", "cocoa", {
      ears: "round",
      eyes: "dot",
      muzzle: "nose",
      marks: ["patch"],
    }),
    v("ferret", "Ferret", "pets", "cream", {
      ears: "round",
      eyes: "dot",
      muzzle: "nose",
      marks: ["mask"],
      shade: "#a97551",
    }),
    v("budgie", "Budgie", "pets", "lime", {
      ears: "crest",
      eyes: "dot",
      muzzle: "beak",
      marks: ["blush"],
      detail: "#f3c552",
    }),
    v("goldfish", "Goldfish", "pets", "gold", {
      ears: "fins",
      eyes: "wide",
      muzzle: "smile",
    }),
    v("pony", "Pony", "pets", "sand", {
      ears: "pointed",
      eyes: "round",
      muzzle: "snout",
      marks: ["patch"],
    }),
    v("mouse", "Mouse", "pets", "grey", {
      ears: "round",
      eyes: "dot",
      muzzle: "nose",
      marks: ["whiskers", "blush"],
    }),
    v("cow", "Cow", "farm", "snow", {
      ears: "horns",
      eyes: "round",
      muzzle: "pig",
      marks: ["spots"],
      shade: "#39414d",
      detail: "#e6c48b",
    }),
    v("pig", "Pig", "farm", "pink", {
      ears: "floppy",
      eyes: "dot",
      muzzle: "pig",
      marks: ["blush"],
    }),
    v("sheep", "Sheep", "farm", "cream", {
      ears: "wool",
      eyes: "dot",
      muzzle: "nose",
    }),
    v("goat", "Goat", "farm", "cream", {
      ears: "horns",
      eyes: "slit",
      muzzle: "nose",
      marks: ["patch"],
      detail: "#a97551",
    }),
    v("horse", "Horse", "farm", "cocoa", {
      ears: "pointed",
      eyes: "round",
      muzzle: "snout",
      marks: ["patch"],
    }),
    v("donkey", "Donkey", "farm", "grey", {
      ears: "tall",
      eyes: "sleepy",
      muzzle: "snout",
    }),
    v("chicken", "Chicken", "farm", "snow", {
      ears: "crest",
      eyes: "dot",
      muzzle: "beak",
      detail: "#e15c4f",
    }),
    v("duck", "Duck", "farm", "yellow", {
      ears: "none",
      eyes: "dot",
      muzzle: "bill",
      detail: "#f0993f",
    }),
    v("goose", "Goose", "farm", "snow", {
      ears: "none",
      eyes: "dot",
      muzzle: "bill",
      detail: "#f0993f",
    }),
    v("bull", "Bull", "farm", "charcoal", {
      ears: "horns",
      eyes: "round",
      muzzle: "pig",
      marks: ["brows"],
      detail: "#e6c48b",
    }),
    v("lion", "Lion", "savanna", "gold", {
      ears: "mane",
      eyes: "round",
      muzzle: "snout",
      marks: ["whiskers"],
      detail: "#b9762a",
    }),
    v("tiger", "Tiger", "savanna", "amber", {
      ears: "pointed",
      eyes: "round",
      muzzle: "snout",
      marks: ["stripes", "whiskers"],
      shade: "#8a4a17",
    }),
    v("elephant", "Elephant", "savanna", "grey", {
      ears: "flap",
      eyes: "dot",
      muzzle: "trunk",
    }),
    v("giraffe", "Giraffe", "savanna", "sand", {
      ears: "horns",
      eyes: "round",
      muzzle: "snout",
      marks: ["spots"],
      detail: "#8b5e3c",
    }),
    v("zebra", "Zebra", "savanna", "snow", {
      ears: "round",
      eyes: "round",
      muzzle: "snout",
      marks: ["stripes"],
      shade: "#39414d",
    }),
    v("rhino", "Rhino", "savanna", "stone", {
      ears: "round",
      eyes: "dot",
      muzzle: "pig",
      marks: ["horn"],
      detail: "#dfe4e8",
    }),
    v("hippo", "Hippo", "savanna", "violet", {
      ears: "round",
      eyes: "wide",
      muzzle: "pig",
    }),
    v("cheetah", "Cheetah", "savanna", "sand", {
      ears: "round",
      eyes: "round",
      muzzle: "nose",
      marks: ["spots", "whiskers"],
    }),
    v("meerkat", "Meerkat", "savanna", "cream", {
      ears: "round",
      eyes: "dot",
      muzzle: "nose",
      marks: ["mask"],
      shade: "#8b5e3c",
    }),
    v("monkey", "Monkey", "savanna", "cocoa", {
      ears: "round",
      eyes: "round",
      muzzle: "snout",
      marks: ["patch"],
    }),
    v("polarbear", "Polar bear", "polar", "snow", {
      ears: "round",
      eyes: "dot",
      muzzle: "snout",
    }),
    v("penguin", "Penguin", "polar", "charcoal", {
      ears: "none",
      eyes: "round",
      muzzle: "beak",
      marks: ["patch"],
      accent: "#ffffff",
      detail: "#f0993f",
    }),
    v("seal", "Seal", "polar", "slate", {
      ears: "none",
      eyes: "sleepy",
      muzzle: "nose",
      marks: ["whiskers"],
    }),
    v("arcticfox", "Arctic fox", "polar", "snow", {
      ears: "pointed",
      eyes: "round",
      muzzle: "snout",
      marks: ["whiskers"],
    }),
    v("snowleopard", "Snow leopard", "polar", "snow", {
      ears: "tuft",
      eyes: "slit",
      muzzle: "nose",
      marks: ["spots", "whiskers"],
      detail: "#5fba70",
    }),
    v("walrus", "Walrus", "polar", "brown", {
      ears: "none",
      eyes: "dot",
      muzzle: "tusks",
      marks: ["whiskers"],
    }),
    v("reindeer", "Reindeer", "polar", "cocoa", {
      ears: "antlers",
      eyes: "round",
      muzzle: "snout",
      detail: "#c39a55",
    }),
    v("husky", "Husky", "polar", "slate", {
      ears: "pointed",
      eyes: "slit",
      muzzle: "snout",
      marks: ["mask"],
      detail: "#7cc4ef",
    }),
    v("puffin", "Puffin", "polar", "charcoal", {
      ears: "none",
      eyes: "dot",
      muzzle: "beak",
      marks: ["patch"],
      accent: "#ffffff",
      detail: "#f0993f",
    }),
    v("yak", "Yak", "polar", "cocoa", {
      ears: "horns",
      eyes: "sleepy",
      muzzle: "nose",
      marks: ["patch"],
      detail: "#e6c48b",
    }),
    v("whale", "Whale", "ocean", "navy", {
      ears: "fins",
      eyes: "wide",
      muzzle: "smile",
      marks: ["patch"],
    }),
    v("dolphin", "Dolphin", "ocean", "sky", {
      ears: "fins",
      eyes: "dot",
      muzzle: "smile",
      marks: ["patch"],
    }),
    v("shark", "Shark", "ocean", "slate", {
      ears: "fins",
      eyes: "round",
      muzzle: "wide",
      marks: ["brows", "fangs"],
    }),
    v("octopus", "Octopus", "ocean", "purple", {
      ears: "tentacles",
      eyes: "round",
      muzzle: "smile",
    }),
    v("crab", "Crab", "ocean", "red", {
      ears: "none",
      eyes: "stalk",
      muzzle: "mandibles",
    }),
    v("jellyfish", "Jellyfish", "ocean", "rose", {
      ears: "tentacles",
      eyes: "dot",
      muzzle: "smile",
    }),
    v("seahorse", "Seahorse", "ocean", "yellow", {
      ears: "crest",
      eyes: "wide",
      muzzle: "beak",
      detail: "#d09c2c",
    }),
    v("pufferfish", "Pufferfish", "ocean", "amber", {
      ears: "spikes",
      eyes: "wide",
      muzzle: "smile",
    }),
    v("narwhal", "Narwhal", "ocean", "sky", {
      ears: "fins",
      eyes: "dot",
      muzzle: "smile",
      marks: ["horn"],
      detail: "#eef3f9",
    }),
    v("otter", "Otter", "ocean", "brown", {
      ears: "round",
      eyes: "round",
      muzzle: "snout",
      marks: ["whiskers"],
    }),
    v("frog", "Frog", "creatures", "green", {
      ears: "none",
      eyes: "bulge",
      muzzle: "wide",
      marks: ["tongue"],
    }),
    v("turtle", "Turtle", "creatures", "moss", {
      ears: "none",
      eyes: "round",
      muzzle: "smile",
      marks: ["shell"],
      detail: "#3f7a2a",
    }),
    v("gecko", "Gecko", "creatures", "lime", {
      ears: "none",
      eyes: "round",
      muzzle: "smile",
      marks: ["spots"],
    }),
    v("chameleon", "Chameleon", "creatures", "teal", {
      ears: "crest",
      eyes: "turret",
      muzzle: "smile",
      marks: ["spots"],
      detail: "#f3c552",
    }),
    v("snake", "Snake", "creatures", "moss", {
      ears: "none",
      eyes: "slit",
      muzzle: "smile",
      marks: ["stripes"],
      detail: "#f3c552",
    }),
    v("crocodile", "Crocodile", "creatures", "green", {
      ears: "none",
      eyes: "wide",
      muzzle: "wide",
      marks: ["brows", "fangs"],
    }),
    v("bee", "Bee", "creatures", "yellow", {
      ears: "antennae",
      eyes: "compound",
      muzzle: "mandibles",
      marks: ["stripes"],
      shade: "#39414d",
    }),
    v("ladybird", "Ladybird", "creatures", "red", {
      ears: "antennae",
      eyes: "dot",
      muzzle: "smile",
      marks: ["spots"],
      shade: "#39414d",
    }),
    v("butterfly", "Butterfly", "creatures", "purple", {
      ears: "wings",
      eyes: "compound",
      muzzle: "smile",
      marks: ["sparkle"],
      detail: "#f3c552",
    }),
    v("snail", "Snail", "creatures", "cream", {
      ears: "none",
      eyes: "stalk",
      muzzle: "smile",
      marks: ["shell"],
      detail: "#c39a55",
    }),
    v("dragon", "Dragon", "mythical", "green", {
      ears: "spikes",
      eyes: "slit",
      muzzle: "wide",
      marks: ["fangs", "brows"],
      detail: "#f3c552",
    }),
    v("unicorn", "Unicorn", "mythical", "snow", {
      ears: "pointed",
      eyes: "round",
      muzzle: "snout",
      marks: ["horn", "sparkle"],
      detail: "#a68bf5",
    }),
    v("phoenix", "Phoenix", "mythical", "red", {
      ears: "crest",
      eyes: "round",
      muzzle: "beak",
      marks: ["sparkle"],
      detail: "#f3c552",
    }),
    v("griffin", "Griffin", "mythical", "gold", {
      ears: "wings",
      eyes: "big",
      muzzle: "beak",
      marks: ["brows"],
      detail: "#c1811d",
    }),
    v("yeti", "Yeti", "mythical", "snow", {
      ears: "wool",
      eyes: "round",
      muzzle: "snout",
      marks: ["fangs"],
      accent: "#dcecfb",
    }),
    v("pegasus", "Pegasus", "mythical", "snow", {
      ears: "wings",
      eyes: "round",
      muzzle: "snout",
      marks: ["sparkle"],
      detail: "#7cc4ef",
    }),
    v("kraken", "Kraken", "mythical", "violet", {
      ears: "tentacles",
      eyes: "slit",
      muzzle: "smile",
      marks: ["brows"],
      detail: "#42b5a8",
    }),
    v("sphinx", "Sphinx", "mythical", "sand", {
      ears: "pointed",
      eyes: "round",
      muzzle: "nose",
      marks: ["crown"],
    }),
    v("wyvern", "Wyvern", "mythical", "red", {
      ears: "wings",
      eyes: "slit",
      muzzle: "wide",
      marks: ["horn", "fangs"],
      detail: "#f3c552",
    }),
    v("golem", "Golem", "mythical", "stone", {
      ears: "dome",
      eyes: "visor",
      muzzle: "grill",
      marks: ["sparkle"],
      detail: "#7cc4ef",
    }),
    v("trex", "T. rex", "dinosaurs", "moss", {
      ears: "none",
      eyes: "slit",
      muzzle: "wide",
      marks: ["brows", "fangs"],
      detail: "#f3c552",
    }),
    v("triceratops", "Triceratops", "dinosaurs", "teal", {
      ears: "frill",
      eyes: "round",
      muzzle: "beak",
      marks: ["horn"],
      detail: "#e6c48b",
    }),
    v("stegosaurus", "Stegosaurus", "dinosaurs", "violet", {
      ears: "spikes",
      eyes: "dot",
      muzzle: "smile",
      marks: ["spots"],
    }),
    v("raptor", "Raptor", "dinosaurs", "amber", {
      ears: "none",
      eyes: "slit",
      muzzle: "wide",
      marks: ["stripes", "fangs"],
      detail: "#5fba70",
    }),
    v("pterodactyl", "Pterodactyl", "dinosaurs", "rust", {
      ears: "wings",
      eyes: "round",
      muzzle: "beak",
      detail: "#cd5f27",
    }),
    v("brachiosaurus", "Brachiosaurus", "dinosaurs", "sky", {
      ears: "none",
      eyes: "dot",
      muzzle: "smile",
      marks: ["spots"],
    }),
    v("ankylosaurus", "Ankylosaurus", "dinosaurs", "stone", {
      ears: "points",
      eyes: "dot",
      muzzle: "smile",
      marks: ["spots"],
    }),
    v("spinosaurus", "Spinosaurus", "dinosaurs", "navy", {
      ears: "spikes",
      eyes: "slit",
      muzzle: "wide",
      marks: ["fangs"],
      detail: "#f3c552",
    }),
    v("dilophosaurus", "Dilophosaurus", "dinosaurs", "lime", {
      ears: "crest",
      eyes: "round",
      muzzle: "wide",
      marks: ["tongue"],
      detail: "#e15c4f",
    }),
    v("mosasaurus", "Mosasaurus", "dinosaurs", "teal", {
      ears: "fins",
      eyes: "wide",
      muzzle: "wide",
      marks: ["fangs"],
    }),
    v("astronaut", "Astronaut", "space", "snow", {
      ears: "dome",
      eyes: "visor",
      muzzle: "smile",
      marks: ["visorGlow"],
      detail: "#7cc4ef",
    }),
    v("alien", "Alien", "space", "lime", {
      ears: "antennae",
      eyes: "compound",
      muzzle: "smile",
      detail: "#6da733",
    }),
    v("martian", "Martian", "space", "red", {
      ears: "antennae",
      eyes: "big",
      muzzle: "smile",
      marks: ["blush"],
    }),
    v("moon", "Moon", "space", "snow", {
      ears: "none",
      eyes: "sleepy",
      muzzle: "smile",
      marks: ["spots"],
    }),
    v("sun", "Sun", "space", "yellow", {
      ears: "rays",
      eyes: "dot",
      muzzle: "smile",
      marks: ["blush"],
      detail: "#e9aa3c",
    }),
    v("star", "Star", "space", "yellow", {
      ears: "points",
      eyes: "dot",
      muzzle: "smile",
      marks: ["sparkle"],
      shade: "#e9aa3c",
      detail: "#fff3d0",
    }),
    v("comet", "Comet", "space", "sky", {
      ears: "points",
      eyes: "wide",
      muzzle: "smile",
      marks: ["sparkle", "bolt"],
      detail: "#f3c552",
    }),
    v("satellite", "Satellite", "space", "slate", {
      ears: "antennae",
      eyes: "visor",
      muzzle: "grill",
      marks: ["bolt"],
      detail: "#f3c552",
    }),
    v("ufo", "UFO", "space", "teal", {
      ears: "dome",
      eyes: "big",
      muzzle: "smile",
      marks: ["visorGlow"],
      detail: "#95cf57",
    }),
    v("rover", "Rover", "space", "stone", {
      ears: "antennae",
      eyes: "visor",
      muzzle: "grill",
      marks: ["spots"],
      detail: "#f0993f",
    }),
    v("robot", "Robot", "robots", "stone", {
      ears: "antennae",
      eyes: "visor",
      muzzle: "grill",
      marks: ["bolt"],
      detail: "#7cc4ef",
    }),
    v("android", "Android", "robots", "snow", {
      ears: "none",
      eyes: "round",
      muzzle: "smile",
      marks: ["visorGlow"],
      detail: "#42b5a8",
    }),
    v("cyborg", "Cyborg", "robots", "charcoal", {
      ears: "none",
      eyes: "slit",
      muzzle: "grill",
      marks: ["stitches"],
      detail: "#e15c4f",
    }),
    v("drone", "Drone", "robots", "slate", {
      ears: "fins",
      eyes: "big",
      muzzle: "smile",
      detail: "#95cf57",
    }),
    v("mecha", "Mecha", "robots", "navy", {
      ears: "horns",
      eyes: "visor",
      muzzle: "grill",
      marks: ["bolt"],
      detail: "#f3c552",
    }),
    v("servo", "Servo", "robots", "gold", {
      ears: "antennae",
      eyes: "dot",
      muzzle: "smile",
      marks: ["blush"],
    }),
    v("glitch", "Glitch", "robots", "purple", {
      ears: "points",
      eyes: "compound",
      muzzle: "grill",
      marks: ["sparkle"],
      detail: "#95cf57",
    }),
    v("pixel", "Pixel", "robots", "lime", {
      ears: "none",
      eyes: "dot",
      muzzle: "grill",
      marks: ["spots"],
      detail: "#f3c552",
    }),
    v("sentry", "Sentry", "robots", "red", {
      ears: "dome",
      eyes: "visor",
      muzzle: "grill",
      marks: ["visorGlow"],
      detail: "#f3c552",
    }),
    v("beacon", "Beacon", "robots", "sky", {
      ears: "rays",
      eyes: "dot",
      muzzle: "smile",
      marks: ["sparkle"],
      detail: "#f3c552",
    }),
    v("vampire", "Vampire", "monsters", "snow", {
      ears: "pointed",
      eyes: "slit",
      muzzle: "smile",
      marks: ["brows", "fangs"],
      detail: "#e15c4f",
    }),
    v("werewolf", "Werewolf", "monsters", "charcoal", {
      ears: "pointed",
      eyes: "round",
      muzzle: "snout",
      marks: ["brows", "fangs"],
    }),
    v("zombie", "Zombie", "monsters", "moss", {
      ears: "round",
      eyes: "round",
      muzzle: "smile",
      marks: ["stitches", "fangs"],
    }),
    v("ghost", "Ghost", "monsters", "snow", {
      ears: "none",
      eyes: "big",
      muzzle: "wide",
      marks: ["sparkle"],
      detail: "#a68bf5",
    }),
    v("mummy", "Mummy", "monsters", "cream", {
      ears: "none",
      eyes: "dot",
      muzzle: "smile",
      marks: ["bandage"],
      accent: "#fffaf0",
    }),
    v("frankenstein", "Frankenstein", "monsters", "lime", {
      ears: "none",
      eyes: "sleepy",
      muzzle: "smile",
      marks: ["brows", "stitches", "bolt"],
      detail: "#f3c552",
    }),
    v("goblin", "Goblin", "monsters", "moss", {
      ears: "pointed",
      eyes: "slit",
      muzzle: "wide",
      marks: ["brows", "fangs"],
      detail: "#f3c552",
    }),
    v("ogre", "Ogre", "monsters", "brown", {
      ears: "round",
      eyes: "dot",
      muzzle: "tusks",
      marks: ["brows"],
    }),
    v("slime", "Slime", "monsters", "teal", {
      ears: "none",
      eyes: "round",
      muzzle: "smile",
      marks: ["blush", "sparkle"],
    }),
    v("gargoyle", "Gargoyle", "monsters", "stone", {
      ears: "wings",
      eyes: "slit",
      muzzle: "wide",
      marks: ["brows", "fangs"],
      detail: "#6a737c",
    }),
  ]),
  Wd = new Map(Ad.map((d) => [d.id, d]));
function ac(d) {
  return d ? Wd.get(d) : void 0;
}
const $d = { small: "1.25rem", medium: "1.75rem", large: "2.5rem" },
  ec = "#f8fafc",
  Hd = "#60a5fa",
  tc = [
    { value: "product", label: "Product" },
    { value: "mock", label: "Mock" },
    { value: "real", label: "Real", locked: !0 },
  ];
function Bd({ dataSource: d, onDataSourceChange: g, tone: c = "light" }) {
  const [S, C] = ae.useState(!1),
    _ = c === "dark",
    $ = tc.find((A) => A.value === d)?.label || "Product",
    K = _ ? "#e2e8f0" : "#334155",
    R = _ ? "#94a3b8" : "#64748b",
    re = _ ? "#f8fafc" : "#0f172a";
  return i.jsxs("div", {
    "data-profile-database-row": !0,
    style: { marginBottom: "0.25rem" },
    children: [
      i.jsxs("button", {
        "aria-controls": "profile-database-options",
        "aria-expanded": S,
        "data-profile-database-trigger": !0,
        onClick: () => C((A) => !A),
        style: {
          alignItems: "center",
          background: "transparent",
          border: 0,
          borderRadius: "0.5rem",
          color: K,
          cursor: "pointer",
          display: "flex",
          fontFamily: "inherit",
          fontSize: "0.875rem",
          fontWeight: 650,
          gap: "0.5rem",
          minHeight: "2.25rem",
          padding: "0.5rem",
          textAlign: "left",
          width: "100%",
        },
        type: "button",
        children: [
          i.jsxs("svg", {
            "aria-hidden": "true",
            fill: "none",
            height: "16",
            viewBox: "0 0 24 24",
            width: "16",
            children: [
              i.jsx("ellipse", {
                cx: "12",
                cy: "5",
                rx: "8",
                ry: "3",
                stroke: "currentColor",
                strokeWidth: "1.8",
              }),
              i.jsx("path", {
                d: "M4 5v7c0 1.7 3.6 3 8 3s8-1.3 8-3V5M4 12v7c0 1.7 3.6 3 8 3s8-1.3 8-3v-7",
                stroke: "currentColor",
                strokeWidth: "1.8",
              }),
            ],
          }),
          i.jsx("span", { style: { flex: 1 }, children: "Database" }),
          i.jsx("span", {
            style: { color: R, fontSize: "0.75rem", fontWeight: 600 },
            children: $,
          }),
          i.jsx("svg", {
            "aria-hidden": "true",
            fill: "none",
            height: "15",
            style: { transform: S ? "rotate(180deg)" : void 0 },
            viewBox: "0 0 24 24",
            width: "15",
            children: i.jsx("path", {
              d: "m6 9 6 6 6-6",
              stroke: "currentColor",
              strokeLinecap: "round",
              strokeLinejoin: "round",
              strokeWidth: "2",
            }),
          }),
        ],
      }),
      S
        ? i.jsx("div", {
            "aria-label": "Database",
            id: "profile-database-options",
            role: "radiogroup",
            style: {
              display: "grid",
              gap: "0.125rem",
              gridTemplateColumns: "repeat(3, minmax(0, 1fr))",
              padding: "0.125rem 0.5rem 0.5rem 2rem",
            },
            children: tc.map((A) =>
              i.jsxs(
                "button",
                {
                  "aria-checked": d === A.value,
                  "aria-label": A.locked ? `${A.label}, locked` : A.label,
                  "data-database-source": A.value,
                  disabled: A.locked,
                  onClick: () => g(A.value),
                  role: "radio",
                  style: {
                    background: d === A.value ? re : "transparent",
                    border: `1px solid ${d === A.value ? re : _ ? "#475569" : "#cbd5e1"}`,
                    borderRadius: "9999px",
                    color: A.locked
                      ? R
                      : d === A.value
                        ? _
                          ? "#0f172a"
                          : "#ffffff"
                        : K,
                    cursor: A.locked ? "not-allowed" : "pointer",
                    display: "inline-flex",
                    fontFamily: "inherit",
                    fontSize: "0.75rem",
                    fontWeight: 700,
                    minHeight: "1.875rem",
                    opacity: A.locked ? 0.62 : 1,
                    padding: "0.25rem 0.45rem",
                    alignItems: "center",
                    justifyContent: "center",
                    gap: "0.2rem",
                  },
                  title: A.locked ? "Locked" : A.label,
                  type: "button",
                  children: [
                    A.locked
                      ? i.jsxs("svg", {
                          "aria-hidden": "true",
                          fill: "none",
                          height: "11",
                          viewBox: "0 0 24 24",
                          width: "11",
                          children: [
                            i.jsx("rect", {
                              height: "10",
                              rx: "2",
                              stroke: "currentColor",
                              strokeWidth: "2",
                              width: "14",
                              x: "5",
                              y: "11",
                            }),
                            i.jsx("path", {
                              d: "M8 11V8a4 4 0 0 1 8 0v3",
                              stroke: "currentColor",
                              strokeLinecap: "round",
                              strokeWidth: "2",
                            }),
                          ],
                        })
                      : null,
                    A.label,
                  ],
                },
                A.value,
              ),
            ),
          })
        : null,
    ],
  });
}
function Vd({ className: d, size: g = "medium", style: c }) {
  return i.jsxs("span", {
    "aria-label": "comp.school",
    className: d,
    style: {
      alignItems: "baseline",
      color: "inherit",
      display: "inline-flex",
      fontSize: $d[g],
      lineHeight: 1,
      textTransform: "none",
      whiteSpace: "nowrap",
      ...c,
    },
    children: [
      i.jsxs("span", {
        "aria-hidden": "true",
        "data-comp-school-wordmark-part": "comp-dot",
        style: {
          color: ec,
          fontFamily:
            "Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
          fontSize: "0.88em",
          fontStyle: "normal",
          fontWeight: 650,
          letterSpacing: "-0.035em",
        },
        children: [
          "comp",
          i.jsx("span", { style: { color: ec }, children: "." }),
        ],
      }),
      i.jsx("span", {
        "aria-hidden": "true",
        "data-comp-school-wordmark-part": "school",
        style: {
          color: Hd,
          fontFamily: "'Caveat', 'Segoe Print', cursive",
          fontSize: "1.2em",
          fontStyle: "italic",
          fontWeight: 700,
          letterSpacing: "-0.04em",
          transform: "rotate(-2deg)",
        },
        children: "school",
      }),
    ],
  });
}
function Qd(d) {
  switch (d.trim().toLocaleLowerCase()) {
    case "exams":
      return i.jsxs(i.Fragment, {
        children: [
          i.jsx("path", { d: "m2 9 10-5 10 5-10 5Z" }),
          i.jsx("path", { d: "M6 11.5V16c3.5 2.7 8.5 2.7 12 0v-4.5M22 9v6" }),
        ],
      });
    case "analytics":
      return i.jsx(i.Fragment, {
        children: i.jsx("path", { d: "M4 20V10M10 20V4M16 20v-7M22 20H2" }),
      });
    case "printouts":
      return i.jsxs(i.Fragment, {
        children: [
          i.jsx("path", { d: "M7 8V3h10v5" }),
          i.jsx("path", {
            d: "M7 17H5a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2",
          }),
          i.jsx("path", { d: "M7 14h10v7H7z" }),
          i.jsx("path", { d: "M17 11h.01" }),
        ],
      });
    case "mark":
    case "marking":
      return i.jsxs(i.Fragment, {
        children: [
          i.jsx("path", { d: "M4 3h13a3 3 0 0 1 3 3v15H7a3 3 0 0 1-3-3Z" }),
          i.jsx("path", { d: "M7 17h13M8 8h8M8 12h5" }),
        ],
      });
    case "recall":
    case "topic drills":
      return i.jsxs(i.Fragment, {
        children: [
          i.jsx("circle", { cx: "12", cy: "12", r: "8" }),
          i.jsx("circle", { cx: "12", cy: "12", r: "3" }),
          i.jsx("path", { d: "M12 2v3M22 12h-3M12 22v-3M2 12h3" }),
        ],
      });
    case "coding playground":
      return i.jsx("path", { d: "m8 9-3 3 3 3M16 9l3 3-3 3M14 5l-4 14" });
    case "forms":
    case "self assess":
      return i.jsxs(i.Fragment, {
        children: [
          i.jsx("rect", { height: "18", rx: "2", width: "14", x: "5", y: "4" }),
          i.jsx("path", { d: "M9 4V2h6v2M8.5 13l2 2 5-5" }),
        ],
      });
    case "games":
      return i.jsxs(i.Fragment, {
        children: [
          i.jsx("path", {
            d: "M7.5 8h9a4.5 4.5 0 0 1 4.2 6.1l-1 2.7a2.5 2.5 0 0 1-4.1 1l-1.4-1.3H9.8l-1.4 1.3a2.5 2.5 0 0 1-4.1-1l-1-2.7A4.5 4.5 0 0 1 7.5 8Z",
          }),
          i.jsx("path", { d: "M8 11v4M6 13h4M16.5 12h.01M18.5 14h.01" }),
        ],
      });
    case "admin":
      return i.jsxs(i.Fragment, {
        children: [
          i.jsx("rect", { height: "7", rx: "1", width: "7", x: "3", y: "3" }),
          i.jsx("rect", { height: "7", rx: "1", width: "7", x: "14", y: "3" }),
          i.jsx("rect", { height: "7", rx: "1", width: "7", x: "3", y: "14" }),
          i.jsx("rect", { height: "7", rx: "1", width: "7", x: "14", y: "14" }),
        ],
      });
    case "docs":
      return i.jsxs(i.Fragment, {
        children: [
          i.jsx("path", {
            d: "M4 5.5A3.5 3.5 0 0 1 7.5 2H11v17H7.5A3.5 3.5 0 0 0 4 22Z",
          }),
          i.jsx("path", {
            d: "M20 5.5A3.5 3.5 0 0 0 16.5 2H13v17h3.5A3.5 3.5 0 0 1 20 22Z",
          }),
        ],
      });
    case "issues":
      return i.jsxs(i.Fragment, {
        children: [
          i.jsx("circle", { cx: "12", cy: "12", r: "9" }),
          i.jsx("path", { d: "M12 7v6M12 17h.01" }),
        ],
      });
    default:
      return i.jsxs(i.Fragment, {
        children: [
          i.jsx("rect", { height: "7", rx: "1", width: "7", x: "3", y: "3" }),
          i.jsx("rect", { height: "7", rx: "1", width: "7", x: "14", y: "3" }),
          i.jsx("rect", { height: "7", rx: "1", width: "7", x: "3", y: "14" }),
          i.jsx("rect", { height: "7", rx: "1", width: "7", x: "14", y: "14" }),
        ],
      });
  }
}
function Zd({ appName: d, className: g, style: c }) {
  return i.jsx("svg", {
    "aria-hidden": "true",
    className: g,
    "data-comp-school-app-icon": d,
    fill: "none",
    focusable: "false",
    height: "24",
    stroke: "currentColor",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    strokeWidth: "1.9",
    style: {
      color: "#14b8a6",
      flex: "0 0 auto",
      height: "1.5rem",
      width: "1.5rem",
      ...c,
    },
    viewBox: "0 0 24 24",
    width: "24",
    children: Qd(d),
  });
}
function Kd(d) {
  return d.trim().charAt(0).toLocaleUpperCase() || "U";
}
function nc({ avatar: d, instanceId: g, profileName: c, style: S }) {
  const C = ac(d);
  return C
    ? i.jsx("span", {
        "aria-hidden": "true",
        "data-student-avatar": C.id,
        style: {
          display: "block",
          height: "100%",
          lineHeight: 0,
          width: "100%",
          ...S,
        },
        children: i.jsx(Fd, {
          features: C,
          idSuffix: g ? `${g}-${C.id}` : C.id,
        }),
      })
    : i.jsx("span", {
        "aria-hidden": "true",
        style: { lineHeight: 1, ...S },
        children: Kd(c),
      });
}
function Gd({
  appName: d,
  appIcon: g,
  backHref: c,
  profileName: S,
  backLabel: C = "Back",
  canChangeAvatar: _ = !1,
  changeAvatarHref: $,
  children: K,
  className: R,
  contextLabel: re,
  dataSource: A,
  logoSrc: le = "/favicon/favicon.svg",
  logoTone: G = "brand",
  onBack: Me,
  onDataSourceChange: Pe,
  onSignOut: b,
  profileAvatar: V,
  reportIssueHref: Ce,
  style: $e,
  tone: De = "dark",
}) {
  const oe = De === "dark",
    ce = !!ac(V),
    D = oe ? "#f8fafc" : "#0f172a",
    Y = oe ? "#cbd5e1" : "#475569",
    Z = oe ? "#334155" : "#e2e8f0",
    q = oe ? "#0f172a" : "#ffffff",
    xe = oe ? "#1e293b" : "#f8fafc",
    it = i.jsxs(i.Fragment, {
      children: [
        i.jsx("svg", {
          "aria-hidden": "true",
          fill: "none",
          height: "16",
          viewBox: "0 0 24 24",
          width: "16",
          children: i.jsx("path", {
            d: "M19 12H5m7 7-7-7 7-7",
            stroke: "currentColor",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "2",
          }),
        }),
        i.jsx("span", { children: C }),
      ],
    }),
    He = {
      alignItems: "center",
      background: xe,
      border: `1px solid ${Z}`,
      borderRadius: "0.625rem",
      color: Y,
      cursor: "pointer",
      display: "inline-flex",
      fontFamily: "inherit",
      fontSize: "0.875rem",
      fontWeight: 700,
      gap: "0.375rem",
      minHeight: "2.5rem",
      padding: "0.5rem 0.75rem",
      textDecoration: "none",
      whiteSpace: "nowrap",
    },
    Ne = {
      ...He,
      background: "transparent",
      border: 0,
      color: D,
      justifyContent: "flex-start",
      width: "100%",
    };
  return i.jsx("header", {
    "aria-label": `${d} navigation`,
    className: R,
    "data-comp-school-navbar": "standard",
    style: {
      background: q,
      borderBottom: `1px solid ${Z}`,
      color: D,
      fontFamily:
        "Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
      position: "relative",
      zIndex: 30,
      ...$e,
    },
    children: i.jsxs("div", {
      style: {
        alignItems: "center",
        display: "flex",
        gap: "0.75rem",
        justifyContent: "space-between",
        margin: "0 auto",
        maxWidth: "80rem",
        minHeight: "4rem",
        padding: "0.625rem clamp(1rem, 3vw, 2rem)",
        width: "100%",
      },
      children: [
        i.jsxs("div", {
          style: {
            alignItems: "center",
            display: "flex",
            gap: "0.625rem",
            minWidth: 0,
          },
          children: [
            i.jsx("img", {
              alt: "",
              "aria-hidden": "true",
              src: le,
              style: {
                filter: G === "grayscale" ? "grayscale(1)" : void 0,
                height: "2rem",
                objectFit: "contain",
                opacity: G === "grayscale" ? 0.58 : 1,
                width: "2rem",
              },
            }),
            g === void 0 ? i.jsx(Zd, { appName: d }) : g,
            i.jsx("strong", {
              style: {
                color: D,
                fontSize: "1rem",
                fontWeight: 750,
                lineHeight: 1.2,
                overflow: "hidden",
                textOverflow: "ellipsis",
                whiteSpace: "nowrap",
              },
              children: d,
            }),
            re
              ? i.jsx("span", {
                  style: {
                    borderLeft: `1px solid ${Z}`,
                    color: Y,
                    fontSize: "0.875rem",
                    fontWeight: 650,
                    lineHeight: 1.2,
                    minWidth: 0,
                    overflow: "hidden",
                    paddingLeft: "0.625rem",
                    textOverflow: "ellipsis",
                    whiteSpace: "nowrap",
                  },
                  children: re,
                })
              : null,
          ],
        }),
        i.jsxs("div", {
          style: { alignItems: "center", display: "flex", gap: "0.625rem" },
          children: [
            Me
              ? i.jsx("button", {
                  "aria-label": C,
                  onClick: Me,
                  style: He,
                  type: "button",
                  children: it,
                })
              : i.jsx("a", {
                  "aria-label": C,
                  href: c,
                  style: He,
                  children: it,
                }),
            K,
            Ce && b
              ? i.jsxs("details", {
                  "data-comp-school-account-menu": !0,
                  style: { position: "relative" },
                  children: [
                    i.jsx("summary", {
                      "aria-label": `${S} account menu`,
                      title: `${S} account`,
                      style: {
                        alignItems: "center",
                        background: ce
                          ? "transparent"
                          : oe
                            ? "#e2e8f0"
                            : "#0f172a",
                        borderRadius: ce ? "0.8rem" : "9999px",
                        color: oe ? "#0f172a" : "#ffffff",
                        cursor: "pointer",
                        display: "inline-flex",
                        flex: "0 0 auto",
                        fontSize: "0.875rem",
                        fontWeight: 800,
                        height: "2.5rem",
                        justifyContent: "center",
                        listStyle: "none",
                        overflow: "hidden",
                        width: "2.5rem",
                      },
                      children: i.jsx(nc, { avatar: V, profileName: S }),
                    }),
                    i.jsxs("div", {
                      style: {
                        background: q,
                        border: `1px solid ${Z}`,
                        borderRadius: "0.75rem",
                        boxShadow: "0 20px 25px -5px rgba(2, 6, 23, 0.35)",
                        minWidth: "15rem",
                        padding: "0.5rem",
                        position: "absolute",
                        right: 0,
                        top: "calc(100% + 0.5rem)",
                        zIndex: 40,
                      },
                      children: [
                        i.jsx("p", {
                          style: {
                            color: Y,
                            fontSize: "0.75rem",
                            fontWeight: 700,
                            letterSpacing: "0.05em",
                            margin: 0,
                            padding: "0.375rem 0.5rem",
                            textTransform: "uppercase",
                          },
                          children: S.split(" ")[0] || S,
                        }),
                        A && Pe
                          ? i.jsx(Bd, {
                              dataSource: A,
                              onDataSourceChange: Pe,
                              tone: De,
                            })
                          : null,
                        _ && $
                          ? i.jsxs("a", {
                              href: $,
                              style: Ne,
                              children: [
                                i.jsxs("svg", {
                                  "aria-hidden": "true",
                                  fill: "none",
                                  height: "16",
                                  viewBox: "0 0 24 24",
                                  width: "16",
                                  children: [
                                    i.jsx("path", {
                                      d: "M12 4c-4.4 0-8 3.1-8 7 0 2.9 2 5.4 4.9 6.5L8 21l3.4-2.8H12c4.4 0 8-3.1 8-7s-3.6-7.2-8-7.2Z",
                                      stroke: "currentColor",
                                      strokeLinejoin: "round",
                                      strokeWidth: "1.8",
                                    }),
                                    i.jsx("circle", {
                                      cx: "9",
                                      cy: "10",
                                      fill: "currentColor",
                                      r: "1",
                                    }),
                                    i.jsx("circle", {
                                      cx: "15",
                                      cy: "10",
                                      fill: "currentColor",
                                      r: "1",
                                    }),
                                  ],
                                }),
                                i.jsx("span", { children: "Change avatar" }),
                              ],
                            })
                          : null,
                        i.jsxs("a", {
                          href: Ce,
                          style: Ne,
                          children: [
                            i.jsxs("svg", {
                              "aria-hidden": "true",
                              fill: "none",
                              height: "16",
                              viewBox: "0 0 24 24",
                              width: "16",
                              children: [
                                i.jsx("path", {
                                  d: "M8 2 6.5 5M16 2l1.5 3M4 9H2M22 9h-2M5 19l2.5-2.5M19 19l-2.5-2.5M9 5h6a4 4 0 0 1 4 4v4a7 7 0 0 1-14 0V9a4 4 0 0 1 4-4Z",
                                  stroke: "currentColor",
                                  strokeLinecap: "round",
                                  strokeLinejoin: "round",
                                  strokeWidth: "1.8",
                                }),
                                i.jsx("path", {
                                  d: "M8 12h8M12 8v8",
                                  stroke: "currentColor",
                                  strokeLinecap: "round",
                                  strokeWidth: "1.8",
                                }),
                              ],
                            }),
                            i.jsx("span", { children: "Report an issue" }),
                          ],
                        }),
                        i.jsxs("button", {
                          onClick: b,
                          style: { ...Ne, marginTop: "0.25rem" },
                          type: "button",
                          children: [
                            i.jsx("svg", {
                              "aria-hidden": "true",
                              fill: "none",
                              height: "16",
                              viewBox: "0 0 24 24",
                              width: "16",
                              children: i.jsx("path", {
                                d: "M10 17l5-5-5-5M15 12H3M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4",
                                stroke: "currentColor",
                                strokeLinecap: "round",
                                strokeLinejoin: "round",
                                strokeWidth: "1.8",
                              }),
                            }),
                            i.jsx("span", { children: "Sign out" }),
                          ],
                        }),
                      ],
                    }),
                  ],
                })
              : i.jsx("span", {
                  "aria-label": `${S} profile`,
                  title: S,
                  style: {
                    alignItems: "center",
                    background: ce ? "transparent" : oe ? "#e2e8f0" : "#0f172a",
                    borderRadius: ce ? "0.8rem" : "9999px",
                    color: oe ? "#0f172a" : "#ffffff",
                    display: "inline-flex",
                    flex: "0 0 auto",
                    fontSize: "0.875rem",
                    fontWeight: 800,
                    height: "2.5rem",
                    justifyContent: "center",
                    overflow: "hidden",
                    width: "2.5rem",
                  },
                  children: i.jsx(nc, { avatar: V, profileName: S }),
                }),
          ],
        }),
      ],
    }),
  });
}
const Yd = { BASE_URL: "/", DEV: !1, MODE: "production", PROD: !0, SSR: !1 },
  Xd = ae.createContext(null),
  qd = ae.createContext(null),
  Jd = ae.createContext(!1),
  Ul = "comp-school-fallback-access";
function rc() {
  return typeof window > "u" || typeof document > "u"
    ? null
    : oc(document.cookie, window.location.hostname, Qi().DEV === !0);
}
function bd(d) {
  if (typeof window > "u" || typeof document > "u") return;
  const g = jd(d);
  oc(g, window.location.hostname, Qi().DEV === !0) && (document.cookie = g);
}
function ep() {
  typeof document > "u" || (document.cookie = zd());
}
function Wi(d, g) {
  return (
    g &&
    d.role === "teacher" &&
    new URLSearchParams(window.location.search).get("preview") === "student"
  );
}
function tp() {
  if (typeof window > "u") return null;
  const d = new URLSearchParams(window.location.hash.replace(/^#/, "")),
    g = d.get("fallback");
  if (g && Ya(g)) {
    (window.sessionStorage.setItem(Ul, g), d.delete("fallback"));
    const S = d.toString();
    window.history.replaceState(
      {},
      "",
      `${window.location.pathname}${window.location.search}${S ? `#${S}` : ""}`,
    );
  }
  const c = g || window.sessionStorage.getItem(Ul);
  return Ya(c) ? c : (window.sessionStorage.removeItem(Ul), null);
}
const Tt = {
  loadingMain: {
    alignItems: "center",
    background: "#020617",
    color: "#ffffff",
    display: "grid",
    fontFamily:
      'Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
    minHeight: "100vh",
    padding: "1rem",
    placeItems: "center",
  },
  loadingText: {
    color: "#cbd5e1",
    fontSize: "0.875rem",
    fontWeight: 500,
    margin: 0,
  },
  main: {
    alignItems: "center",
    background: "#020617",
    color: "#ffffff",
    display: "flex",
    fontFamily:
      'Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
    justifyContent: "center",
    minHeight: "100vh",
    padding: "2.5rem 1rem",
  },
  panel: {
    background: "var(--cs-surface, #ffffff)",
    border: "1px solid var(--cs-border, rgba(255, 255, 255, 0.1))",
    borderRadius: "0.5rem",
    boxShadow:
      "0 25px 50px -12px rgba(15, 23, 42, 0.45), 0 12px 24px -16px rgba(15, 23, 42, 0.6)",
    color: "var(--cs-text, #020617)",
    maxWidth: "24rem",
    padding: "1.5rem",
    width: "100%",
  },
  title: {
    fontSize: "1.5rem",
    fontWeight: 700,
    lineHeight: 1.2,
    margin: "0.75rem 0 0",
  },
  copy: {
    color: "var(--cs-text-muted, #475569)",
    fontSize: "0.875rem",
    lineHeight: 1.6,
    margin: "0.5rem 0 0",
  },
  actions: { display: "grid", gap: "1rem", marginTop: "1.5rem" },
  error: { color: "#dc2626", fontSize: "0.875rem", fontWeight: 600, margin: 0 },
  link: {
    background: "var(--cs-primary-hover, #2563eb)",
    borderRadius: "0.375rem",
    color: "#ffffff",
    display: "block",
    fontSize: "0.875rem",
    fontWeight: 700,
    padding: "0.75rem 1rem",
    textAlign: "center",
    textDecoration: "none",
    width: "100%",
  },
};
function Qi() {
  return Yd || {};
}
function np(d) {
  return Rd(window.location.hostname, d, Qi().VITE_PLATFORM_URL);
}
function rp({
  appName: d,
  children: g,
  allowedRoles: c,
  navbarChildren: S,
  navbarStyle: C,
  productionUrl: _,
  showNavbar: $ = !0,
  allowFallback: K = !1,
  allowTeacherStudentPreview: R = !1,
}) {
  const A =
      new URLSearchParams(window.location.search).get("sql") === "mock"
        ? "mock"
        : "product",
    le = ae.useMemo(() => np(_), [_]),
    G = ae.useMemo(() => sc(window.location.hostname), []),
    Me = ae.useMemo(
      () => uc(window.location.hostname, "https://issues.comp.school"),
      [],
    ),
    Pe = ae.useMemo(() => {
      const fe = new URL(G);
      return (fe.searchParams.set("changeAvatar", "1"), fe.toString());
    }, [G]),
    b = c ? c.join(",") : "",
    [V, Ce] = ae.useState(null),
    [$e, De] = ae.useState(!0),
    [oe, ce] = ae.useState(!1),
    [D, Y] = ae.useState(null),
    [Z, q] = ae.useState(!1),
    [xe, it] = ae.useState(null);
  async function He() {
    (await fetch("/api/logout", {
      cache: "no-store",
      credentials: "same-origin",
      method: "POST",
    }).catch(() => {}),
      Y(null),
      ep(),
      window.sessionStorage.removeItem(Ul),
      q(!1),
      ce(!1),
      window.location.assign(G));
  }
  function Ne(fe) {
    if (fe === "real") return;
    const ye = new URL(window.location.href);
    (ye.searchParams.set("sql", fe), window.location.assign(ye.toString()));
  }
  if (
    (ae.useEffect(() => {
      let fe = !1;
      return (
        fetch("/api/session", {
          cache: "no-store",
          credentials: "same-origin",
          headers: { accept: "application/json" },
        })
          .then(async (ye) => {
            const Se = await ye.json().catch(() => null);
            if (fe) return;
            if (
              ye.ok &&
              Se?.ok &&
              Se.user &&
              (!c || c.includes(Se.user.role) || Wi(Se.user, R))
            ) {
              (bd(Se.user), Ce(null), Y(Se.user), ce(!0));
              return;
            }
            const ue = rc();
            if (ue && (!c || c.includes(ue.role) || Wi(ue, R))) {
              (Ce(null), Y(ue), ce(!0));
              return;
            }
            if (K && tp()) {
              (Ce(null), q(!0), ce(!0));
              return;
            }
            (Ce(Se?.message || null), Y(null), ce(!1));
          })
          .catch(() => {
            if (!fe) {
              const ye = rc();
              if (ye && (!c || c.includes(ye.role) || Wi(ye, R))) {
                (Ce(null), Y(ye), ce(!0));
                return;
              }
              (Ce("Unable to check platform access right now."),
                Y(null),
                ce(!1));
            }
          })
          .finally(() => {
            fe || De(!1);
          }),
        () => {
          fe = !0;
        }
      );
    }, [b, K, R]),
    $e)
  )
    return i.jsx("main", {
      style: Tt.loadingMain,
      children: i.jsx("p", {
        style: Tt.loadingText,
        children: "Checking platform access...",
      }),
    });
  if (oe) {
    const fe = D?.role === "admin" || D?.role === "teacher",
      ye = new URL(G);
    return (
      fe && ye.searchParams.set("sql", A),
      i.jsxs(i.Fragment, {
        children: [
          $ && (D || Z)
            ? i.jsx(Gd, {
                appName: d,
                backHref: ye.toString(),
                canChangeAvatar: D?.role === "student",
                changeAvatarHref: Pe,
                contextLabel: xe,
                dataSource: fe ? A : void 0,
                onDataSourceChange: fe ? Ne : void 0,
                onSignOut: He,
                profileAvatar: D?.role === "student" ? D.avatar : void 0,
                profileName: D?.name || "Fallback",
                reportIssueHref: Me,
                style: C,
                children: S,
              })
            : null,
          i.jsx(Jd.Provider, {
            value: Z,
            children: i.jsx(qd.Provider, {
              value: D,
              children: i.jsx(Xd.Provider, { value: it, children: g }),
            }),
          }),
        ],
      })
    );
  }
  return i.jsx("main", {
    style: Tt.main,
    children: i.jsxs("section", {
      style: Tt.panel,
      children: [
        i.jsx(Vd, { size: "small", style: { color: "#0f172a" } }),
        i.jsx("h1", { style: Tt.title, children: d }),
        i.jsx("p", {
          style: Tt.copy,
          children: "Open comp.school and enter your access code to continue.",
        }),
        i.jsxs("div", {
          style: Tt.actions,
          children: [
            V && i.jsx("p", { style: Tt.error, children: V }),
            i.jsx("a", {
              "aria-label": `Open comp.school to access ${d}`,
              href: le,
              style: Tt.link,
              children: "Open comp.school",
            }),
          ],
        }),
      ],
    }),
  });
}
const lp = [
  { value: "exam-host", label: "Exams" },
  { value: "recall", label: "Recall" },
  { value: "marking", label: "Marking" },
  { value: "coding", label: "Coding" },
  { value: "analytics", label: "Analytics" },
];
function op({ onChange: d, value: g }) {
  return i.jsxs("fieldset", {
    className: "grid grid-cols-2 gap-1 rounded-2xl bg-[#f1f0ed] p-1",
    children: [
      i.jsx("legend", { className: "sr-only", children: "Report type" }),
      ["bug", "feature"].map((c) =>
        i.jsx(
          "button",
          {
            type: "button",
            "aria-pressed": g === c,
            onClick: () => d(c),
            className: `rounded-xl px-4 py-2.5 text-sm font-semibold transition ${g === c ? "bg-white text-[#20231f] shadow-sm" : "text-[#737770] hover:text-[#363a35]"}`,
            children: c === "bug" ? "Report a bug" : "Request a feature",
          },
          c,
        ),
      ),
    ],
  });
}
function ip({ onChange: d, value: g }) {
  return i.jsxs("fieldset", {
    className: "mt-5 px-1",
    children: [
      i.jsxs("div", {
        className: "flex items-baseline justify-between gap-4",
        children: [
          i.jsx("legend", {
            className: "text-sm font-semibold",
            children: "Which app?",
          }),
          i.jsx("span", {
            className: "text-xs text-[#8a8e87]",
            children: "Optional",
          }),
        ],
      }),
      i.jsx("div", {
        className: "mt-2 flex flex-wrap gap-2",
        children: lp.map((c) =>
          i.jsx(
            "button",
            {
              type: "button",
              "aria-pressed": g === c.value,
              onClick: () => d(g === c.value ? null : c.value),
              className: `rounded-full border px-3.5 py-2 text-sm font-medium transition ${g === c.value ? "border-[#315e3f] bg-[#eaf3ec] text-[#285438]" : "border-black/[0.08] bg-white text-[#656a63] hover:border-black/20 hover:text-[#2d312d]"}`,
              children: c.label,
            },
            c.value,
          ),
        ),
      }),
    ],
  });
}
const sp = new Set(["image/png", "image/jpeg"]),
  $i = 5,
  up = 8 * 1024 * 1024;
function ap() {
  return i.jsxs("svg", {
    viewBox: "0 0 24 24",
    "aria-hidden": "true",
    className: "h-5 w-5",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "1.8",
    children: [
      i.jsx("rect", { x: "3", y: "4", width: "18", height: "16", rx: "3" }),
      i.jsx("circle", { cx: "8.5", cy: "9", r: "1.5" }),
      i.jsx("path", { d: "m5 18 4.5-4.5 3 3 2.2-2.2L19 18" }),
    ],
  });
}
function cp() {
  return i.jsx("svg", {
    viewBox: "0 0 24 24",
    "aria-hidden": "true",
    className: "h-5 w-5",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    children: i.jsx("path", {
      d: "M12 19V5m0 0-6 6m6-6 6 6",
      strokeLinecap: "round",
      strokeLinejoin: "round",
    }),
  });
}
function fp() {
  return i.jsx("svg", {
    viewBox: "0 0 24 24",
    "aria-hidden": "true",
    className: "h-7 w-7",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2.2",
    children: i.jsx("path", {
      d: "m5 12 4.5 4.5L19 7",
      strokeLinecap: "round",
      strokeLinejoin: "round",
    }),
  });
}
function dp() {
  return i.jsxs("svg", {
    viewBox: "0 0 24 24",
    "aria-hidden": "true",
    className: "h-5 w-5",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "1.8",
    children: [
      i.jsx("rect", { x: "4", y: "4", width: "6", height: "6", rx: "1.5" }),
      i.jsx("rect", { x: "14", y: "4", width: "6", height: "6", rx: "1.5" }),
      i.jsx("rect", { x: "4", y: "14", width: "6", height: "6", rx: "1.5" }),
      i.jsx("rect", { x: "14", y: "14", width: "6", height: "6", rx: "1.5" }),
    ],
  });
}
function pp() {
  const [d, g] = ae.useState("bug"),
    [c, S] = ae.useState(null),
    [C, _] = ae.useState(""),
    [$, K] = ae.useState([]),
    [R, re] = ae.useState(""),
    [A, le] = ae.useState(!1),
    [G, Me] = ae.useState(null),
    Pe = ae.useRef(null),
    b = ae.useRef([]);
  (ae.useEffect(() => {
    b.current = $;
  }, [$]),
    ae.useEffect(
      () => () => b.current.forEach((D) => URL.revokeObjectURL(D.previewUrl)),
      [],
    ));
  function V(D) {
    if ((re(""), D.find((q) => !sp.has(q.type)))) {
      re("Only PNG and JPEG images can be attached.");
      return;
    }
    if (D.find((q) => q.size > up)) {
      re("Each image must be smaller than 8 MB.");
      return;
    }
    if ($.length + D.length > $i) {
      re(`You can attach up to ${$i} images.`);
      return;
    }
    K((q) => [
      ...q,
      ...D.map((xe) => ({
        id: `${xe.name}-${xe.size}-${crypto.randomUUID()}`,
        file: xe,
        previewUrl: URL.createObjectURL(xe),
      })),
    ]);
  }
  function Ce(D) {
    (V(Array.from(D.target.files ?? [])), (D.target.value = ""));
  }
  function $e(D) {
    const Y = Array.from(D.clipboardData.items)
      .filter((Z) => Z.kind === "file")
      .map((Z) => Z.getAsFile())
      .filter((Z) => !!Z);
    Y.length && (D.preventDefault(), V(Y));
  }
  function De(D) {
    K((Y) => {
      const Z = Y.find((q) => q.id === D);
      return (
        Z && URL.revokeObjectURL(Z.previewUrl),
        Y.filter((q) => q.id !== D)
      );
    });
  }
  function oe() {
    ($.forEach((D) => URL.revokeObjectURL(D.previewUrl)),
      g("bug"),
      S(null),
      _(""),
      K([]),
      re(""),
      Me(null));
  }
  async function ce(D) {
    D.preventDefault();
    const Y = C.trim();
    if (Y.length < 3) {
      re("Please add a little more detail before sending.");
      return;
    }
    (re(""), le(!0));
    const Z = new FormData();
    (Z.set("kind", d),
      Z.set("description", Y),
      c && Z.set("app", c),
      $.forEach((q) => Z.append("images", q.file, q.file.name)));
    try {
      const q = await fetch("/api/report", {
          method: "POST",
          body: Z,
          credentials: "same-origin",
        }),
        xe = await q.json().catch(() => null);
      if (!q.ok || !xe?.ok || !xe.issue)
        throw new Error(
          xe?.message || "Your issue could not be sent. Please try again.",
        );
      Me(xe.issue);
    } catch (q) {
      re(
        q instanceof Error
          ? q.message
          : "Your issue could not be sent. Please try again.",
      );
    } finally {
      le(!1);
    }
  }
  return G
    ? i.jsx("main", {
        className:
          "grid min-h-screen place-items-center bg-[#f6f5f2] px-6 py-12 text-[#1d201d]",
        children: i.jsxs("section", {
          className:
            "w-full max-w-lg rounded-[2rem] border border-black/[0.06] bg-white px-8 py-12 text-center shadow-[0_24px_70px_rgba(44,45,39,0.10)] sm:px-12",
          children: [
            i.jsx("div", {
              className:
                "mx-auto grid h-16 w-16 place-items-center rounded-full bg-[#e5f4e8] text-[#26753d]",
              children: i.jsx(fp, {}),
            }),
            i.jsx("p", {
              className:
                "mt-7 text-sm font-semibold uppercase tracking-[0.18em] text-[#26753d]",
              children: "Sent successfully",
            }),
            i.jsx("h1", {
              className: "mt-3 text-3xl font-semibold tracking-[-0.035em]",
              children: "Your issue has been sent",
            }),
            i.jsxs("p", {
              className:
                "mx-auto mt-4 max-w-sm text-base leading-7 text-[#656a64]",
              children: [
                "Thanks for helping us improve comp.school. Ticket #",
                G.number,
                " is ready for the team to review.",
              ],
            }),
            i.jsxs("div", {
              className: "mt-8 flex flex-col justify-center gap-3 sm:flex-row",
              children: [
                i.jsx("button", {
                  type: "button",
                  onClick: oe,
                  className:
                    "rounded-full bg-[#1e211e] px-5 py-3 text-sm font-semibold text-white transition hover:bg-black",
                  children: "Send another",
                }),
                i.jsx("a", {
                  href: "https://comp.school",
                  "aria-label": "Back to comp.school menu",
                  title: "Back to menu",
                  className:
                    "grid h-11 w-11 place-items-center self-center rounded-full border border-black/10 text-[#353935] transition hover:bg-[#f6f5f2]",
                  children: i.jsx(dp, {}),
                }),
              ],
            }),
          ],
        }),
      })
    : i.jsx("main", {
        className: "min-h-screen bg-[#f6f5f2] text-[#1d201d]",
        children: i.jsxs("div", {
          className:
            "mx-auto flex min-h-screen w-full max-w-3xl flex-col px-5 py-8 sm:px-8 sm:py-12",
          children: [
            i.jsx("header", { className: "flex items-center justify-between" }),
            i.jsxs("section", {
              className: "my-auto py-12 sm:py-16",
              children: [
                i.jsxs("div", {
                  className: "mb-8 text-center",
                  children: [
                    i.jsx("h1", {
                      className:
                        "mx-auto mt-3 max-w-xl text-4xl font-semibold tracking-[-0.045em] sm:text-5xl",
                      children: "What would you like to see improved?",
                    }),
                    i.jsx("p", {
                      className:
                        "mx-auto mt-4 max-w-lg text-base leading-7 text-[#6a6e68]",
                      children:
                        "Report something that is not working or share an idea. A screenshot often tells the story fastest.",
                    }),
                  ],
                }),
                i.jsxs("form", {
                  onSubmit: ce,
                  className:
                    "rounded-[1.75rem] border border-black/[0.07] bg-white p-3 shadow-[0_22px_65px_rgba(42,43,38,0.09)] sm:p-4",
                  children: [
                    i.jsx(op, { onChange: g, value: d }),
                    i.jsx(ip, { onChange: S, value: c }),
                    i.jsxs("div", {
                      className:
                        "mt-5 rounded-2xl border border-black/[0.09] bg-[#fbfbfa] p-3 focus-within:border-[#60806a] focus-within:ring-4 focus-within:ring-[#60806a]/10",
                      children: [
                        $.length > 0 &&
                          i.jsx("div", {
                            className: "mb-3 flex gap-2 overflow-x-auto pb-1",
                            "aria-label": "Attached images",
                            children: $.map((D) =>
                              i.jsxs(
                                "div",
                                {
                                  className:
                                    "group relative h-20 w-20 shrink-0 overflow-hidden rounded-xl border border-black/10 bg-white",
                                  children: [
                                    i.jsx("img", {
                                      src: D.previewUrl,
                                      alt: D.file.name || "Pasted screenshot",
                                      className: "h-full w-full object-cover",
                                    }),
                                    i.jsx("button", {
                                      type: "button",
                                      onClick: () => De(D.id),
                                      "aria-label": `Remove ${D.file.name || "image"}`,
                                      className:
                                        "absolute right-1 top-1 grid h-6 w-6 place-items-center rounded-full bg-black/70 text-base leading-none text-white opacity-100 transition sm:opacity-0 sm:group-hover:opacity-100 sm:group-focus-within:opacity-100",
                                      children: "×",
                                    }),
                                  ],
                                },
                                D.id,
                              ),
                            ),
                          }),
                        i.jsx("label", {
                          htmlFor: "issue-description",
                          className: "sr-only",
                          children: "Describe the issue or idea",
                        }),
                        i.jsx("textarea", {
                          id: "issue-description",
                          value: C,
                          onChange: (D) => _(D.target.value),
                          onPaste: $e,
                          maxLength: 1e4,
                          rows: 6,
                          placeholder:
                            d === "bug"
                              ? "Tell us what happened, what you expected, and how to reproduce it…"
                              : "Describe your idea and how it would help…",
                          className:
                            "block min-h-36 w-full resize-none bg-transparent px-1 py-1 text-base leading-7 text-[#252824] outline-none placeholder:text-[#9a9d97]",
                        }),
                        i.jsxs("div", {
                          className:
                            "mt-2 flex items-center justify-between gap-3",
                          children: [
                            i.jsxs("div", {
                              className: "flex items-center gap-2",
                              children: [
                                i.jsx("input", {
                                  ref: Pe,
                                  type: "file",
                                  accept: "image/png,image/jpeg",
                                  multiple: !0,
                                  onChange: Ce,
                                  className: "sr-only",
                                }),
                                i.jsx("button", {
                                  type: "button",
                                  onClick: () => Pe.current?.click(),
                                  disabled: $.length >= $i,
                                  "aria-label": "Attach images",
                                  className:
                                    "grid h-10 w-10 place-items-center rounded-full border border-black/[0.08] bg-white text-[#555a54] transition hover:bg-[#f0efec] disabled:cursor-not-allowed disabled:opacity-40",
                                  children: i.jsx(ap, {}),
                                }),
                                i.jsx("span", {
                                  className:
                                    "hidden text-xs text-[#8a8e87] sm:inline",
                                  children:
                                    "Paste an image with Ctrl+V · PNG or JPEG",
                                }),
                              ],
                            }),
                            i.jsx("button", {
                              type: "submit",
                              disabled: A || C.trim().length < 3,
                              "aria-label": "Send issue",
                              className:
                                "grid h-10 w-10 place-items-center rounded-full bg-[#1e211e] text-white transition hover:bg-black disabled:cursor-not-allowed disabled:bg-[#c8cac5]",
                              children: A
                                ? i.jsx("span", {
                                    className:
                                      "h-4 w-4 animate-spin rounded-full border-2 border-white/40 border-t-white",
                                  })
                                : i.jsx(cp, {}),
                            }),
                          ],
                        }),
                      ],
                    }),
                    i.jsx("div", {
                      "aria-live": "polite",
                      className: "min-h-7 px-2 pt-2",
                      children: R
                        ? i.jsx("p", {
                            className: "text-sm font-medium text-[#ad342d]",
                            children: R,
                          })
                        : i.jsx("p", {
                            className: "text-xs text-[#92958f]",
                            children:
                              "Images are uploaded to ImageKit and included with your ticket.",
                          }),
                    }),
                  ],
                }),
              ],
            }),
          ],
        }),
      });
}
gd.createRoot(document.getElementById("root")).render(
  i.jsx(cd.StrictMode, {
    children: i.jsx(rp, {
      appName: "Issues",
      allowedRoles: ["admin", "teacher", "student"],
      productionUrl: "https://issues.comp.school",
      children: i.jsx(pp, {}),
    }),
  }),
);
