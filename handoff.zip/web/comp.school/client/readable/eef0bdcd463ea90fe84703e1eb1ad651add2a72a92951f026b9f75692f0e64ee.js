import { r as S, j as fe } from "./react-vendor-BK1G6oO1.js";
const Cs = S.createContext({});
function or(t) {
  const e = S.useRef(null);
  return (e.current === null && (e.current = t()), e.current);
}
const Fe = typeof window < "u",
  ar = Fe ? S.useLayoutEffect : S.useEffect,
  Be = S.createContext(null);
function Ie(t, e) {
  t.indexOf(e) === -1 && t.push(e);
}
function Oe(t, e) {
  const n = t.indexOf(e);
  n > -1 && t.splice(n, 1);
}
const z = (t, e, n) => (n > e ? e : n < t ? t : n);
let je = () => {};
const X = {},
  Ms = (t) => /^-?(?:\d+(?:\.\d+)?|\.\d+)$/u.test(t);
function Ds(t) {
  return typeof t == "object" && t !== null;
}
const Es = (t) => /^0[^.\s]+$/u.test(t);
function Ne(t) {
  let e;
  return () => (e === void 0 && (e = t()), e);
}
const $ = (t) => t,
  lr = (t, e) => (n) => e(t(n)),
  Lt = (...t) => t.reduce(lr),
  Vt = (t, e, n) => {
    const s = e - t;
    return s === 0 ? 1 : (n - t) / s;
  };
class Ue {
  constructor() {
    this.subscriptions = [];
  }
  add(e) {
    return (Ie(this.subscriptions, e), () => Oe(this.subscriptions, e));
  }
  notify(e, n, s) {
    const i = this.subscriptions.length;
    if (i)
      if (i === 1) this.subscriptions[0](e, n, s);
      else
        for (let o = 0; o < i; o++) {
          const r = this.subscriptions[o];
          r && r(e, n, s);
        }
  }
  getSize() {
    return this.subscriptions.length;
  }
  clear() {
    this.subscriptions.length = 0;
  }
}
const H = (t) => t * 1e3,
  W = (t) => t / 1e3;
function Rs(t, e) {
  return e ? t * (1e3 / e) : 0;
}
const Ls = (t, e, n) =>
    (((1 - 3 * n + 3 * e) * t + (3 * n - 6 * e)) * t + 3 * e) * t,
  ur = 1e-7,
  cr = 12;
function hr(t, e, n, s, i) {
  let o,
    r,
    a = 0;
  do ((r = e + (n - e) / 2), (o = Ls(r, s, i) - t), o > 0 ? (n = r) : (e = r));
  while (Math.abs(o) > ur && ++a < cr);
  return r;
}
function kt(t, e, n, s) {
  if (t === e && n === s) return $;
  const i = (o) => hr(o, 0, 1, t, n);
  return (o) => (o === 0 || o === 1 ? o : Ls(i(o), e, s));
}
const ks = (t) => (e) => (e <= 0.5 ? t(2 * e) / 2 : (2 - t(2 * (1 - e))) / 2),
  Fs = (t) => (e) => 1 - t(1 - e),
  Bs = kt(0.33, 1.53, 0.69, 0.99),
  Ke = Fs(Bs),
  Is = ks(Ke),
  Os = (t) =>
    (t *= 2) < 1 ? 0.5 * Ke(t) : 0.5 * (2 - Math.pow(2, -10 * (t - 1))),
  We = (t) => 1 - Math.sin(Math.acos(t)),
  js = Fs(We),
  Ns = ks(We),
  fr = kt(0.42, 0, 1, 1),
  dr = kt(0, 0, 0.58, 1),
  Us = kt(0.42, 0, 0.58, 1),
  mr = (t) => Array.isArray(t) && typeof t[0] != "number",
  Ks = (t) => Array.isArray(t) && typeof t[0] == "number",
  pr = {
    linear: $,
    easeIn: fr,
    easeInOut: Us,
    easeOut: dr,
    circIn: We,
    circInOut: Ns,
    circOut: js,
    backIn: Ke,
    backInOut: Is,
    backOut: Bs,
    anticipate: Os,
  },
  gr = (t) => typeof t == "string",
  gn = (t) => {
    if (Ks(t)) {
      je(t.length === 4);
      const [e, n, s, i] = t;
      return kt(e, n, s, i);
    } else if (gr(t)) return pr[t];
    return t;
  },
  It = [
    "setup",
    "read",
    "resolveKeyframes",
    "preUpdate",
    "update",
    "preRender",
    "render",
    "postRender",
  ];
function yr(t, e) {
  let n = new Set(),
    s = new Set(),
    i = !1,
    o = !1;
  const r = new WeakSet();
  let a = { delta: 0, timestamp: 0, isProcessing: !1 };
  function l(u) {
    (r.has(u) && (c.schedule(u), t()), u(a));
  }
  const c = {
    schedule: (u, h = !1, f = !1) => {
      const m = f && i ? n : s;
      return (h && r.add(u), m.has(u) || m.add(u), u);
    },
    cancel: (u) => {
      (s.delete(u), r.delete(u));
    },
    process: (u) => {
      if (((a = u), i)) {
        o = !0;
        return;
      }
      ((i = !0),
        ([n, s] = [s, n]),
        n.forEach(l),
        n.clear(),
        (i = !1),
        o && ((o = !1), c.process(u)));
    },
  };
  return c;
}
const vr = 40;
function Ws(t, e) {
  let n = !1,
    s = !0;
  const i = { delta: 0, timestamp: 0, isProcessing: !1 },
    o = () => (n = !0),
    r = It.reduce((g, A) => ((g[A] = yr(o)), g), {}),
    {
      setup: a,
      read: l,
      resolveKeyframes: c,
      preUpdate: u,
      update: h,
      preRender: f,
      render: d,
      postRender: m,
    } = r,
    v = () => {
      const g = X.useManualTiming ? i.timestamp : performance.now();
      ((n = !1),
        X.useManualTiming ||
          (i.delta = s ? 1e3 / 60 : Math.max(Math.min(g - i.timestamp, vr), 1)),
        (i.timestamp = g),
        (i.isProcessing = !0),
        a.process(i),
        l.process(i),
        c.process(i),
        u.process(i),
        h.process(i),
        f.process(i),
        d.process(i),
        m.process(i),
        (i.isProcessing = !1),
        n && e && ((s = !1), t(v)));
    },
    y = () => {
      ((n = !0), (s = !0), i.isProcessing || t(v));
    };
  return {
    schedule: It.reduce((g, A) => {
      const P = r[A];
      return (
        (g[A] = (w, R = !1, b = !1) => (n || y(), P.schedule(w, R, b))),
        g
      );
    }, {}),
    cancel: (g) => {
      for (let A = 0; A < It.length; A++) r[It[A]].cancel(g);
    },
    state: i,
    steps: r,
  };
}
const {
  schedule: V,
  cancel: q,
  state: k,
  steps: Zt,
} = Ws(typeof requestAnimationFrame < "u" ? requestAnimationFrame : $, !0);
let Nt;
function Tr() {
  Nt = void 0;
}
const O = {
    now: () => (
      Nt === void 0 &&
        O.set(
          k.isProcessing || X.useManualTiming ? k.timestamp : performance.now(),
        ),
      Nt
    ),
    set: (t) => {
      ((Nt = t), queueMicrotask(Tr));
    },
  },
  $s = (t) => (e) => typeof e == "string" && e.startsWith(t),
  $e = $s("--"),
  xr = $s("var(--"),
  Ge = (t) => (xr(t) ? Pr.test(t.split("/*")[0].trim()) : !1),
  Pr =
    /var\(--(?:[\w-]+\s*|[\w-]+\s*,(?:\s*[^)(\s]|\s*\((?:[^)(]|\([^)(]*\))*\))+\s*)\)$/iu,
  gt = {
    test: (t) => typeof t == "number",
    parse: parseFloat,
    transform: (t) => t,
  },
  Ct = { ...gt, transform: (t) => z(0, 1, t) },
  Ot = { ...gt, default: 1 },
  Pt = (t) => Math.round(t * 1e5) / 1e5,
  He = /-?(?:\d+(?:\.\d+)?|\.\d+)/gu;
function Sr(t) {
  return t == null;
}
const br =
    /^(?:#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\))$/iu,
  _e = (t, e) => (n) =>
    !!(
      (typeof n == "string" && br.test(n) && n.startsWith(t)) ||
      (e && !Sr(n) && Object.prototype.hasOwnProperty.call(n, e))
    ),
  Gs = (t, e, n) => (s) => {
    if (typeof s != "string") return s;
    const [i, o, r, a] = s.match(He);
    return {
      [t]: parseFloat(i),
      [e]: parseFloat(o),
      [n]: parseFloat(r),
      alpha: a !== void 0 ? parseFloat(a) : 1,
    };
  },
  Ar = (t) => z(0, 255, t),
  Jt = { ...gt, transform: (t) => Math.round(Ar(t)) },
  nt = {
    test: _e("rgb", "red"),
    parse: Gs("red", "green", "blue"),
    transform: ({ red: t, green: e, blue: n, alpha: s = 1 }) =>
      "rgba(" +
      Jt.transform(t) +
      ", " +
      Jt.transform(e) +
      ", " +
      Jt.transform(n) +
      ", " +
      Pt(Ct.transform(s)) +
      ")",
  };
function wr(t) {
  let e = "",
    n = "",
    s = "",
    i = "";
  return (
    t.length > 5
      ? ((e = t.substring(1, 3)),
        (n = t.substring(3, 5)),
        (s = t.substring(5, 7)),
        (i = t.substring(7, 9)))
      : ((e = t.substring(1, 2)),
        (n = t.substring(2, 3)),
        (s = t.substring(3, 4)),
        (i = t.substring(4, 5)),
        (e += e),
        (n += n),
        (s += s),
        (i += i)),
    {
      red: parseInt(e, 16),
      green: parseInt(n, 16),
      blue: parseInt(s, 16),
      alpha: i ? parseInt(i, 16) / 255 : 1,
    }
  );
}
const de = { test: _e("#"), parse: wr, transform: nt.transform },
  Ft = (t) => ({
    test: (e) =>
      typeof e == "string" && e.endsWith(t) && e.split(" ").length === 1,
    parse: parseFloat,
    transform: (e) => `${e}${t}`,
  }),
  Y = Ft("deg"),
  _ = Ft("%"),
  x = Ft("px"),
  Vr = Ft("vh"),
  Cr = Ft("vw"),
  yn = {
    ..._,
    parse: (t) => _.parse(t) / 100,
    transform: (t) => _.transform(t * 100),
  },
  lt = {
    test: _e("hsl", "hue"),
    parse: Gs("hue", "saturation", "lightness"),
    transform: ({ hue: t, saturation: e, lightness: n, alpha: s = 1 }) =>
      "hsla(" +
      Math.round(t) +
      ", " +
      _.transform(Pt(e)) +
      ", " +
      _.transform(Pt(n)) +
      ", " +
      Pt(Ct.transform(s)) +
      ")",
  },
  E = {
    test: (t) => nt.test(t) || de.test(t) || lt.test(t),
    parse: (t) =>
      nt.test(t) ? nt.parse(t) : lt.test(t) ? lt.parse(t) : de.parse(t),
    transform: (t) =>
      typeof t == "string"
        ? t
        : t.hasOwnProperty("red")
          ? nt.transform(t)
          : lt.transform(t),
    getAnimatableNone: (t) => {
      const e = E.parse(t);
      return ((e.alpha = 0), E.transform(e));
    },
  },
  Mr =
    /(?:#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\))/giu;
function Dr(t) {
  return (
    isNaN(t) &&
    typeof t == "string" &&
    (t.match(He)?.length || 0) + (t.match(Mr)?.length || 0) > 0
  );
}
const Hs = "number",
  _s = "color",
  Er = "var",
  Rr = "var(",
  vn = "${}",
  Lr =
    /var\s*\(\s*--(?:[\w-]+\s*|[\w-]+\s*,(?:\s*[^)(\s]|\s*\((?:[^)(]|\([^)(]*\))*\))+\s*)\)|#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\)|-?(?:\d+(?:\.\d+)?|\.\d+)/giu;
function Mt(t) {
  const e = t.toString(),
    n = [],
    s = { color: [], number: [], var: [] },
    i = [];
  let o = 0;
  const a = e
    .replace(
      Lr,
      (l) => (
        E.test(l)
          ? (s.color.push(o), i.push(_s), n.push(E.parse(l)))
          : l.startsWith(Rr)
            ? (s.var.push(o), i.push(Er), n.push(l))
            : (s.number.push(o), i.push(Hs), n.push(parseFloat(l))),
        ++o,
        vn
      ),
    )
    .split(vn);
  return { values: n, split: a, indexes: s, types: i };
}
function zs(t) {
  return Mt(t).values;
}
function Xs(t) {
  const { split: e, types: n } = Mt(t),
    s = e.length;
  return (i) => {
    let o = "";
    for (let r = 0; r < s; r++)
      if (((o += e[r]), i[r] !== void 0)) {
        const a = n[r];
        a === Hs
          ? (o += Pt(i[r]))
          : a === _s
            ? (o += E.transform(i[r]))
            : (o += i[r]);
      }
    return o;
  };
}
const kr = (t) =>
  typeof t == "number" ? 0 : E.test(t) ? E.getAnimatableNone(t) : t;
function Fr(t) {
  const e = zs(t);
  return Xs(t)(e.map(kr));
}
const Z = { test: Dr, parse: zs, createTransformer: Xs, getAnimatableNone: Fr };
function Qt(t, e, n) {
  return (
    n < 0 && (n += 1),
    n > 1 && (n -= 1),
    n < 1 / 6
      ? t + (e - t) * 6 * n
      : n < 1 / 2
        ? e
        : n < 2 / 3
          ? t + (e - t) * (2 / 3 - n) * 6
          : t
  );
}
function Br({ hue: t, saturation: e, lightness: n, alpha: s }) {
  ((t /= 360), (e /= 100), (n /= 100));
  let i = 0,
    o = 0,
    r = 0;
  if (!e) i = o = r = n;
  else {
    const a = n < 0.5 ? n * (1 + e) : n + e - n * e,
      l = 2 * n - a;
    ((i = Qt(l, a, t + 1 / 3)), (o = Qt(l, a, t)), (r = Qt(l, a, t - 1 / 3)));
  }
  return {
    red: Math.round(i * 255),
    green: Math.round(o * 255),
    blue: Math.round(r * 255),
    alpha: s,
  };
}
function $t(t, e) {
  return (n) => (n > 0 ? e : t);
}
const C = (t, e, n) => t + (e - t) * n,
  te = (t, e, n) => {
    const s = t * t,
      i = n * (e * e - s) + s;
    return i < 0 ? 0 : Math.sqrt(i);
  },
  Ir = [de, nt, lt],
  Or = (t) => Ir.find((e) => e.test(t));
function Tn(t) {
  const e = Or(t);
  if (!e) return !1;
  let n = e.parse(t);
  return (e === lt && (n = Br(n)), n);
}
const xn = (t, e) => {
    const n = Tn(t),
      s = Tn(e);
    if (!n || !s) return $t(t, e);
    const i = { ...n };
    return (o) => (
      (i.red = te(n.red, s.red, o)),
      (i.green = te(n.green, s.green, o)),
      (i.blue = te(n.blue, s.blue, o)),
      (i.alpha = C(n.alpha, s.alpha, o)),
      nt.transform(i)
    );
  },
  me = new Set(["none", "hidden"]);
function jr(t, e) {
  return me.has(t) ? (n) => (n <= 0 ? t : e) : (n) => (n >= 1 ? e : t);
}
function Nr(t, e) {
  return (n) => C(t, e, n);
}
function ze(t) {
  return typeof t == "number"
    ? Nr
    : typeof t == "string"
      ? Ge(t)
        ? $t
        : E.test(t)
          ? xn
          : Wr
      : Array.isArray(t)
        ? Ys
        : typeof t == "object"
          ? E.test(t)
            ? xn
            : Ur
          : $t;
}
function Ys(t, e) {
  const n = [...t],
    s = n.length,
    i = t.map((o, r) => ze(o)(o, e[r]));
  return (o) => {
    for (let r = 0; r < s; r++) n[r] = i[r](o);
    return n;
  };
}
function Ur(t, e) {
  const n = { ...t, ...e },
    s = {};
  for (const i in n)
    t[i] !== void 0 && e[i] !== void 0 && (s[i] = ze(t[i])(t[i], e[i]));
  return (i) => {
    for (const o in s) n[o] = s[o](i);
    return n;
  };
}
function Kr(t, e) {
  const n = [],
    s = { color: 0, var: 0, number: 0 };
  for (let i = 0; i < e.values.length; i++) {
    const o = e.types[i],
      r = t.indexes[o][s[o]],
      a = t.values[r] ?? 0;
    ((n[i] = a), s[o]++);
  }
  return n;
}
const Wr = (t, e) => {
  const n = Z.createTransformer(e),
    s = Mt(t),
    i = Mt(e);
  return s.indexes.var.length === i.indexes.var.length &&
    s.indexes.color.length === i.indexes.color.length &&
    s.indexes.number.length >= i.indexes.number.length
    ? (me.has(t) && !i.values.length) || (me.has(e) && !s.values.length)
      ? jr(t, e)
      : Lt(Ys(Kr(s, i), i.values), n)
    : $t(t, e);
};
function qs(t, e, n) {
  return typeof t == "number" && typeof e == "number" && typeof n == "number"
    ? C(t, e, n)
    : ze(t)(t, e);
}
const $r = (t) => {
    const e = ({ timestamp: n }) => t(n);
    return {
      start: (n = !0) => V.update(e, n),
      stop: () => q(e),
      now: () => (k.isProcessing ? k.timestamp : O.now()),
    };
  },
  Zs = (t, e, n = 10) => {
    let s = "";
    const i = Math.max(Math.round(e / n), 2);
    for (let o = 0; o < i; o++)
      s += Math.round(t(o / (i - 1)) * 1e4) / 1e4 + ", ";
    return `linear(${s.substring(0, s.length - 2)})`;
  },
  Gt = 2e4;
function Xe(t) {
  let e = 0;
  const n = 50;
  let s = t.next(e);
  for (; !s.done && e < Gt;) ((e += n), (s = t.next(e)));
  return e >= Gt ? 1 / 0 : e;
}
function Gr(t, e = 100, n) {
  const s = n({ ...t, keyframes: [0, e] }),
    i = Math.min(Xe(s), Gt);
  return {
    type: "keyframes",
    ease: (o) => s.next(i * o).value / e,
    duration: W(i),
  };
}
const Hr = 5;
function Js(t, e, n) {
  const s = Math.max(e - Hr, 0);
  return Rs(n - t(s), e - s);
}
const M = {
    stiffness: 100,
    damping: 10,
    mass: 1,
    velocity: 0,
    duration: 800,
    bounce: 0.3,
    visualDuration: 0.3,
    restSpeed: { granular: 0.01, default: 2 },
    restDelta: { granular: 0.005, default: 0.5 },
    minDuration: 0.01,
    maxDuration: 10,
    minDamping: 0.05,
    maxDamping: 1,
  },
  ee = 0.001;
function _r({
  duration: t = M.duration,
  bounce: e = M.bounce,
  velocity: n = M.velocity,
  mass: s = M.mass,
}) {
  let i,
    o,
    r = 1 - e;
  ((r = z(M.minDamping, M.maxDamping, r)),
    (t = z(M.minDuration, M.maxDuration, W(t))),
    r < 1
      ? ((i = (c) => {
          const u = c * r,
            h = u * t,
            f = u - n,
            d = pe(c, r),
            m = Math.exp(-h);
          return ee - (f / d) * m;
        }),
        (o = (c) => {
          const h = c * r * t,
            f = h * n + n,
            d = Math.pow(r, 2) * Math.pow(c, 2) * t,
            m = Math.exp(-h),
            v = pe(Math.pow(c, 2), r);
          return ((-i(c) + ee > 0 ? -1 : 1) * ((f - d) * m)) / v;
        }))
      : ((i = (c) => {
          const u = Math.exp(-c * t),
            h = (c - n) * t + 1;
          return -ee + u * h;
        }),
        (o = (c) => {
          const u = Math.exp(-c * t),
            h = (n - c) * (t * t);
          return u * h;
        })));
  const a = 5 / t,
    l = Xr(i, o, a);
  if (((t = H(t)), isNaN(l)))
    return { stiffness: M.stiffness, damping: M.damping, duration: t };
  {
    const c = Math.pow(l, 2) * s;
    return { stiffness: c, damping: r * 2 * Math.sqrt(s * c), duration: t };
  }
}
const zr = 12;
function Xr(t, e, n) {
  let s = n;
  for (let i = 1; i < zr; i++) s = s - t(s) / e(s);
  return s;
}
function pe(t, e) {
  return t * Math.sqrt(1 - e * e);
}
const Yr = ["duration", "bounce"],
  qr = ["stiffness", "damping", "mass"];
function Pn(t, e) {
  return e.some((n) => t[n] !== void 0);
}
function Zr(t) {
  let e = {
    velocity: M.velocity,
    stiffness: M.stiffness,
    damping: M.damping,
    mass: M.mass,
    isResolvedFromDuration: !1,
    ...t,
  };
  if (!Pn(t, qr) && Pn(t, Yr))
    if (t.visualDuration) {
      const n = t.visualDuration,
        s = (2 * Math.PI) / (n * 1.2),
        i = s * s,
        o = 2 * z(0.05, 1, 1 - (t.bounce || 0)) * Math.sqrt(i);
      e = { ...e, mass: M.mass, stiffness: i, damping: o };
    } else {
      const n = _r(t);
      ((e = { ...e, ...n, mass: M.mass }), (e.isResolvedFromDuration = !0));
    }
  return e;
}
function Ht(t = M.visualDuration, e = M.bounce) {
  const n =
    typeof t != "object"
      ? { visualDuration: t, keyframes: [0, 1], bounce: e }
      : t;
  let { restSpeed: s, restDelta: i } = n;
  const o = n.keyframes[0],
    r = n.keyframes[n.keyframes.length - 1],
    a = { done: !1, value: o },
    {
      stiffness: l,
      damping: c,
      mass: u,
      duration: h,
      velocity: f,
      isResolvedFromDuration: d,
    } = Zr({ ...n, velocity: -W(n.velocity || 0) }),
    m = f || 0,
    v = c / (2 * Math.sqrt(l * u)),
    y = r - o,
    p = W(Math.sqrt(l / u)),
    T = Math.abs(y) < 5;
  (s || (s = T ? M.restSpeed.granular : M.restSpeed.default),
    i || (i = T ? M.restDelta.granular : M.restDelta.default));
  let g;
  if (v < 1) {
    const P = pe(p, v);
    g = (w) => {
      const R = Math.exp(-v * p * w);
      return (
        r - R * (((m + v * p * y) / P) * Math.sin(P * w) + y * Math.cos(P * w))
      );
    };
  } else if (v === 1) g = (P) => r - Math.exp(-p * P) * (y + (m + p * y) * P);
  else {
    const P = p * Math.sqrt(v * v - 1);
    g = (w) => {
      const R = Math.exp(-v * p * w),
        b = Math.min(P * w, 300);
      return (
        r - (R * ((m + v * p * y) * Math.sinh(b) + P * y * Math.cosh(b))) / P
      );
    };
  }
  const A = {
    calculatedDuration: (d && h) || null,
    next: (P) => {
      const w = g(P);
      if (d) a.done = P >= h;
      else {
        let R = P === 0 ? m : 0;
        v < 1 && (R = P === 0 ? H(m) : Js(g, P, w));
        const b = Math.abs(R) <= s,
          I = Math.abs(r - w) <= i;
        a.done = b && I;
      }
      return ((a.value = a.done ? r : w), a);
    },
    toString: () => {
      const P = Math.min(Xe(A), Gt),
        w = Zs((R) => A.next(P * R).value, P, 30);
      return P + "ms " + w;
    },
    toTransition: () => {},
  };
  return A;
}
Ht.applyToOptions = (t) => {
  const e = Gr(t, 100, Ht);
  return (
    (t.ease = e.ease),
    (t.duration = H(e.duration)),
    (t.type = "keyframes"),
    t
  );
};
function ge({
  keyframes: t,
  velocity: e = 0,
  power: n = 0.8,
  timeConstant: s = 325,
  bounceDamping: i = 10,
  bounceStiffness: o = 500,
  modifyTarget: r,
  min: a,
  max: l,
  restDelta: c = 0.5,
  restSpeed: u,
}) {
  const h = t[0],
    f = { done: !1, value: h },
    d = (b) => (a !== void 0 && b < a) || (l !== void 0 && b > l),
    m = (b) =>
      a === void 0
        ? l
        : l === void 0 || Math.abs(a - b) < Math.abs(l - b)
          ? a
          : l;
  let v = n * e;
  const y = h + v,
    p = r === void 0 ? y : r(y);
  p !== y && (v = p - h);
  const T = (b) => -v * Math.exp(-b / s),
    g = (b) => p + T(b),
    A = (b) => {
      const I = T(b),
        j = g(b);
      ((f.done = Math.abs(I) <= c), (f.value = f.done ? p : j));
    };
  let P, w;
  const R = (b) => {
    d(f.value) &&
      ((P = b),
      (w = Ht({
        keyframes: [f.value, m(f.value)],
        velocity: Js(g, b, f.value),
        damping: i,
        stiffness: o,
        restDelta: c,
        restSpeed: u,
      })));
  };
  return (
    R(0),
    {
      calculatedDuration: null,
      next: (b) => {
        let I = !1;
        return (
          !w && P === void 0 && ((I = !0), A(b), R(b)),
          P !== void 0 && b >= P ? w.next(b - P) : (!I && A(b), f)
        );
      },
    }
  );
}
function Jr(t, e, n) {
  const s = [],
    i = n || X.mix || qs,
    o = t.length - 1;
  for (let r = 0; r < o; r++) {
    let a = i(t[r], t[r + 1]);
    if (e) {
      const l = Array.isArray(e) ? e[r] || $ : e;
      a = Lt(l, a);
    }
    s.push(a);
  }
  return s;
}
function Qr(t, e, { clamp: n = !0, ease: s, mixer: i } = {}) {
  const o = t.length;
  if ((je(o === e.length), o === 1)) return () => e[0];
  if (o === 2 && e[0] === e[1]) return () => e[1];
  const r = t[0] === t[1];
  t[0] > t[o - 1] && ((t = [...t].reverse()), (e = [...e].reverse()));
  const a = Jr(e, s, i),
    l = a.length,
    c = (u) => {
      if (r && u < t[0]) return e[0];
      let h = 0;
      if (l > 1) for (; h < t.length - 2 && !(u < t[h + 1]); h++);
      const f = Vt(t[h], t[h + 1], u);
      return a[h](f);
    };
  return n ? (u) => c(z(t[0], t[o - 1], u)) : c;
}
function to(t, e) {
  const n = t[t.length - 1];
  for (let s = 1; s <= e; s++) {
    const i = Vt(0, e, s);
    t.push(C(n, 1, i));
  }
}
function eo(t) {
  const e = [0];
  return (to(e, t.length - 1), e);
}
function no(t, e) {
  return t.map((n) => n * e);
}
function so(t, e) {
  return t.map(() => e || Us).splice(0, t.length - 1);
}
function St({
  duration: t = 300,
  keyframes: e,
  times: n,
  ease: s = "easeInOut",
}) {
  const i = mr(s) ? s.map(gn) : gn(s),
    o = { done: !1, value: e[0] },
    r = no(n && n.length === e.length ? n : eo(e), t),
    a = Qr(r, e, { ease: Array.isArray(i) ? i : so(e, i) });
  return {
    calculatedDuration: t,
    next: (l) => ((o.value = a(l)), (o.done = l >= t), o),
  };
}
const io = (t) => t !== null;
function Ye(t, { repeat: e, repeatType: n = "loop" }, s, i = 1) {
  const o = t.filter(io),
    a = i < 0 || (e && n !== "loop" && e % 2 === 1) ? 0 : o.length - 1;
  return !a || s === void 0 ? o[a] : s;
}
const ro = { decay: ge, inertia: ge, tween: St, keyframes: St, spring: Ht };
function Qs(t) {
  typeof t.type == "string" && (t.type = ro[t.type]);
}
class qe {
  constructor() {
    this.updateFinished();
  }
  get finished() {
    return this._finished;
  }
  updateFinished() {
    this._finished = new Promise((e) => {
      this.resolve = e;
    });
  }
  notifyFinished() {
    this.resolve();
  }
  then(e, n) {
    return this.finished.then(e, n);
  }
}
const oo = (t) => t / 100;
class Ze extends qe {
  constructor(e) {
    (super(),
      (this.state = "idle"),
      (this.startTime = null),
      (this.isStopped = !1),
      (this.currentTime = 0),
      (this.holdTime = null),
      (this.playbackSpeed = 1),
      (this.stop = () => {
        const { motionValue: n } = this.options;
        (n && n.updatedAt !== O.now() && this.tick(O.now()),
          (this.isStopped = !0),
          this.state !== "idle" && (this.teardown(), this.options.onStop?.()));
      }),
      (this.options = e),
      this.initAnimation(),
      this.play(),
      e.autoplay === !1 && this.pause());
  }
  initAnimation() {
    const { options: e } = this;
    Qs(e);
    const {
      type: n = St,
      repeat: s = 0,
      repeatDelay: i = 0,
      repeatType: o,
      velocity: r = 0,
    } = e;
    let { keyframes: a } = e;
    const l = n || St;
    l !== St &&
      typeof a[0] != "number" &&
      ((this.mixKeyframes = Lt(oo, qs(a[0], a[1]))), (a = [0, 100]));
    const c = l({ ...e, keyframes: a });
    (o === "mirror" &&
      (this.mirroredGenerator = l({
        ...e,
        keyframes: [...a].reverse(),
        velocity: -r,
      })),
      c.calculatedDuration === null && (c.calculatedDuration = Xe(c)));
    const { calculatedDuration: u } = c;
    ((this.calculatedDuration = u),
      (this.resolvedDuration = u + i),
      (this.totalDuration = this.resolvedDuration * (s + 1) - i),
      (this.generator = c));
  }
  updateTime(e) {
    const n = Math.round(e - this.startTime) * this.playbackSpeed;
    this.holdTime !== null
      ? (this.currentTime = this.holdTime)
      : (this.currentTime = n);
  }
  tick(e, n = !1) {
    const {
      generator: s,
      totalDuration: i,
      mixKeyframes: o,
      mirroredGenerator: r,
      resolvedDuration: a,
      calculatedDuration: l,
    } = this;
    if (this.startTime === null) return s.next(0);
    const {
      delay: c = 0,
      keyframes: u,
      repeat: h,
      repeatType: f,
      repeatDelay: d,
      type: m,
      onUpdate: v,
      finalKeyframe: y,
    } = this.options;
    (this.speed > 0
      ? (this.startTime = Math.min(this.startTime, e))
      : this.speed < 0 &&
        (this.startTime = Math.min(e - i / this.speed, this.startTime)),
      n ? (this.currentTime = e) : this.updateTime(e));
    const p = this.currentTime - c * (this.playbackSpeed >= 0 ? 1 : -1),
      T = this.playbackSpeed >= 0 ? p < 0 : p > i;
    ((this.currentTime = Math.max(p, 0)),
      this.state === "finished" &&
        this.holdTime === null &&
        (this.currentTime = i));
    let g = this.currentTime,
      A = s;
    if (h) {
      const b = Math.min(this.currentTime, i) / a;
      let I = Math.floor(b),
        j = b % 1;
      (!j && b >= 1 && (j = 1),
        j === 1 && I--,
        (I = Math.min(I, h + 1)),
        !!(I % 2) &&
          (f === "reverse"
            ? ((j = 1 - j), d && (j -= d / a))
            : f === "mirror" && (A = r)),
        (g = z(0, 1, j) * a));
    }
    const P = T ? { done: !1, value: u[0] } : A.next(g);
    o && (P.value = o(P.value));
    let { done: w } = P;
    !T &&
      l !== null &&
      (w =
        this.playbackSpeed >= 0
          ? this.currentTime >= i
          : this.currentTime <= 0);
    const R =
      this.holdTime === null &&
      (this.state === "finished" || (this.state === "running" && w));
    return (
      R && m !== ge && (P.value = Ye(u, this.options, y, this.speed)),
      v && v(P.value),
      R && this.finish(),
      P
    );
  }
  then(e, n) {
    return this.finished.then(e, n);
  }
  get duration() {
    return W(this.calculatedDuration);
  }
  get iterationDuration() {
    const { delay: e = 0 } = this.options || {};
    return this.duration + W(e);
  }
  get time() {
    return W(this.currentTime);
  }
  set time(e) {
    ((e = H(e)),
      (this.currentTime = e),
      this.startTime === null ||
      this.holdTime !== null ||
      this.playbackSpeed === 0
        ? (this.holdTime = e)
        : this.driver &&
          (this.startTime = this.driver.now() - e / this.playbackSpeed),
      this.driver?.start(!1));
  }
  get speed() {
    return this.playbackSpeed;
  }
  set speed(e) {
    this.updateTime(O.now());
    const n = this.playbackSpeed !== e;
    ((this.playbackSpeed = e), n && (this.time = W(this.currentTime)));
  }
  play() {
    if (this.isStopped) return;
    const { driver: e = $r, startTime: n } = this.options;
    (this.driver || (this.driver = e((i) => this.tick(i))),
      this.options.onPlay?.());
    const s = this.driver.now();
    (this.state === "finished"
      ? (this.updateFinished(), (this.startTime = s))
      : this.holdTime !== null
        ? (this.startTime = s - this.holdTime)
        : this.startTime || (this.startTime = n ?? s),
      this.state === "finished" &&
        this.speed < 0 &&
        (this.startTime += this.calculatedDuration),
      (this.holdTime = null),
      (this.state = "running"),
      this.driver.start());
  }
  pause() {
    ((this.state = "paused"),
      this.updateTime(O.now()),
      (this.holdTime = this.currentTime));
  }
  complete() {
    (this.state !== "running" && this.play(),
      (this.state = "finished"),
      (this.holdTime = null));
  }
  finish() {
    (this.notifyFinished(),
      this.teardown(),
      (this.state = "finished"),
      this.options.onComplete?.());
  }
  cancel() {
    ((this.holdTime = null),
      (this.startTime = 0),
      this.tick(0),
      this.teardown(),
      this.options.onCancel?.());
  }
  teardown() {
    ((this.state = "idle"),
      this.stopDriver(),
      (this.startTime = this.holdTime = null));
  }
  stopDriver() {
    this.driver && (this.driver.stop(), (this.driver = void 0));
  }
  sample(e) {
    return ((this.startTime = 0), this.tick(e, !0));
  }
  attachTimeline(e) {
    return (
      this.options.allowFlatten &&
        ((this.options.type = "keyframes"),
        (this.options.ease = "linear"),
        this.initAnimation()),
      this.driver?.stop(),
      e.observe(this)
    );
  }
}
function ao(t) {
  for (let e = 1; e < t.length; e++) t[e] ?? (t[e] = t[e - 1]);
}
const st = (t) => (t * 180) / Math.PI,
  ye = (t) => {
    const e = st(Math.atan2(t[1], t[0]));
    return ve(e);
  },
  lo = {
    x: 4,
    y: 5,
    translateX: 4,
    translateY: 5,
    scaleX: 0,
    scaleY: 3,
    scale: (t) => (Math.abs(t[0]) + Math.abs(t[3])) / 2,
    rotate: ye,
    rotateZ: ye,
    skewX: (t) => st(Math.atan(t[1])),
    skewY: (t) => st(Math.atan(t[2])),
    skew: (t) => (Math.abs(t[1]) + Math.abs(t[2])) / 2,
  },
  ve = (t) => ((t = t % 360), t < 0 && (t += 360), t),
  Sn = ye,
  bn = (t) => Math.sqrt(t[0] * t[0] + t[1] * t[1]),
  An = (t) => Math.sqrt(t[4] * t[4] + t[5] * t[5]),
  uo = {
    x: 12,
    y: 13,
    z: 14,
    translateX: 12,
    translateY: 13,
    translateZ: 14,
    scaleX: bn,
    scaleY: An,
    scale: (t) => (bn(t) + An(t)) / 2,
    rotateX: (t) => ve(st(Math.atan2(t[6], t[5]))),
    rotateY: (t) => ve(st(Math.atan2(-t[2], t[0]))),
    rotateZ: Sn,
    rotate: Sn,
    skewX: (t) => st(Math.atan(t[4])),
    skewY: (t) => st(Math.atan(t[1])),
    skew: (t) => (Math.abs(t[1]) + Math.abs(t[4])) / 2,
  };
function Te(t) {
  return t.includes("scale") ? 1 : 0;
}
function xe(t, e) {
  if (!t || t === "none") return Te(e);
  const n = t.match(/^matrix3d\(([-\d.e\s,]+)\)$/u);
  let s, i;
  if (n) ((s = uo), (i = n));
  else {
    const a = t.match(/^matrix\(([-\d.e\s,]+)\)$/u);
    ((s = lo), (i = a));
  }
  if (!i) return Te(e);
  const o = s[e],
    r = i[1].split(",").map(ho);
  return typeof o == "function" ? o(r) : r[o];
}
const co = (t, e) => {
  const { transform: n = "none" } = getComputedStyle(t);
  return xe(n, e);
};
function ho(t) {
  return parseFloat(t.trim());
}
const yt = [
    "transformPerspective",
    "x",
    "y",
    "z",
    "translateX",
    "translateY",
    "translateZ",
    "scale",
    "scaleX",
    "scaleY",
    "rotate",
    "rotateX",
    "rotateY",
    "rotateZ",
    "skew",
    "skewX",
    "skewY",
  ],
  vt = new Set(yt),
  wn = (t) => t === gt || t === x,
  fo = new Set(["x", "y", "z"]),
  mo = yt.filter((t) => !fo.has(t));
function po(t) {
  const e = [];
  return (
    mo.forEach((n) => {
      const s = t.getValue(n);
      s !== void 0 &&
        (e.push([n, s.get()]), s.set(n.startsWith("scale") ? 1 : 0));
    }),
    e
  );
}
const it = {
  width: ({ x: t }, { paddingLeft: e = "0", paddingRight: n = "0" }) =>
    t.max - t.min - parseFloat(e) - parseFloat(n),
  height: ({ y: t }, { paddingTop: e = "0", paddingBottom: n = "0" }) =>
    t.max - t.min - parseFloat(e) - parseFloat(n),
  top: (t, { top: e }) => parseFloat(e),
  left: (t, { left: e }) => parseFloat(e),
  bottom: ({ y: t }, { top: e }) => parseFloat(e) + (t.max - t.min),
  right: ({ x: t }, { left: e }) => parseFloat(e) + (t.max - t.min),
  x: (t, { transform: e }) => xe(e, "x"),
  y: (t, { transform: e }) => xe(e, "y"),
};
it.translateX = it.x;
it.translateY = it.y;
const rt = new Set();
let Pe = !1,
  Se = !1,
  be = !1;
function ti() {
  if (Se) {
    const t = Array.from(rt).filter((s) => s.needsMeasurement),
      e = new Set(t.map((s) => s.element)),
      n = new Map();
    (e.forEach((s) => {
      const i = po(s);
      i.length && (n.set(s, i), s.render());
    }),
      t.forEach((s) => s.measureInitialState()),
      e.forEach((s) => {
        s.render();
        const i = n.get(s);
        i &&
          i.forEach(([o, r]) => {
            s.getValue(o)?.set(r);
          });
      }),
      t.forEach((s) => s.measureEndState()),
      t.forEach((s) => {
        s.suspendedScrollY !== void 0 && window.scrollTo(0, s.suspendedScrollY);
      }));
  }
  ((Se = !1), (Pe = !1), rt.forEach((t) => t.complete(be)), rt.clear());
}
function ei() {
  rt.forEach((t) => {
    (t.readKeyframes(), t.needsMeasurement && (Se = !0));
  });
}
function go() {
  ((be = !0), ei(), ti(), (be = !1));
}
class Je {
  constructor(e, n, s, i, o, r = !1) {
    ((this.state = "pending"),
      (this.isAsync = !1),
      (this.needsMeasurement = !1),
      (this.unresolvedKeyframes = [...e]),
      (this.onComplete = n),
      (this.name = s),
      (this.motionValue = i),
      (this.element = o),
      (this.isAsync = r));
  }
  scheduleResolve() {
    ((this.state = "scheduled"),
      this.isAsync
        ? (rt.add(this), Pe || ((Pe = !0), V.read(ei), V.resolveKeyframes(ti)))
        : (this.readKeyframes(), this.complete()));
  }
  readKeyframes() {
    const {
      unresolvedKeyframes: e,
      name: n,
      element: s,
      motionValue: i,
    } = this;
    if (e[0] === null) {
      const o = i?.get(),
        r = e[e.length - 1];
      if (o !== void 0) e[0] = o;
      else if (s && n) {
        const a = s.readValue(n, r);
        a != null && (e[0] = a);
      }
      (e[0] === void 0 && (e[0] = r), i && o === void 0 && i.set(e[0]));
    }
    ao(e);
  }
  setFinalKeyframe() {}
  measureInitialState() {}
  renderEndStyles() {}
  measureEndState() {}
  complete(e = !1) {
    ((this.state = "complete"),
      this.onComplete(this.unresolvedKeyframes, this.finalKeyframe, e),
      rt.delete(this));
  }
  cancel() {
    this.state === "scheduled" && (rt.delete(this), (this.state = "pending"));
  }
  resume() {
    this.state === "pending" && this.scheduleResolve();
  }
}
const yo = (t) => t.startsWith("--");
function vo(t, e, n) {
  yo(e) ? t.style.setProperty(e, n) : (t.style[e] = n);
}
const To = Ne(() => window.ScrollTimeline !== void 0),
  xo = {};
function Po(t, e) {
  const n = Ne(t);
  return () => xo[e] ?? n();
}
const ni = Po(() => {
    try {
      document
        .createElement("div")
        .animate({ opacity: 0 }, { easing: "linear(0, 1)" });
    } catch {
      return !1;
    }
    return !0;
  }, "linearEasing"),
  xt = ([t, e, n, s]) => `cubic-bezier(${t}, ${e}, ${n}, ${s})`,
  Vn = {
    linear: "linear",
    ease: "ease",
    easeIn: "ease-in",
    easeOut: "ease-out",
    easeInOut: "ease-in-out",
    circIn: xt([0, 0.65, 0.55, 1]),
    circOut: xt([0.55, 0, 1, 0.45]),
    backIn: xt([0.31, 0.01, 0.66, -0.59]),
    backOut: xt([0.33, 1.53, 0.69, 0.99]),
  };
function si(t, e) {
  if (t)
    return typeof t == "function"
      ? ni()
        ? Zs(t, e)
        : "ease-out"
      : Ks(t)
        ? xt(t)
        : Array.isArray(t)
          ? t.map((n) => si(n, e) || Vn.easeOut)
          : Vn[t];
}
function So(
  t,
  e,
  n,
  {
    delay: s = 0,
    duration: i = 300,
    repeat: o = 0,
    repeatType: r = "loop",
    ease: a = "easeOut",
    times: l,
  } = {},
  c = void 0,
) {
  const u = { [e]: n };
  l && (u.offset = l);
  const h = si(a, i);
  Array.isArray(h) && (u.easing = h);
  const f = {
    delay: s,
    duration: i,
    easing: Array.isArray(h) ? "linear" : h,
    fill: "both",
    iterations: o + 1,
    direction: r === "reverse" ? "alternate" : "normal",
  };
  return (c && (f.pseudoElement = c), t.animate(u, f));
}
function ii(t) {
  return typeof t == "function" && "applyToOptions" in t;
}
function bo({ type: t, ...e }) {
  return ii(t) && ni()
    ? t.applyToOptions(e)
    : (e.duration ?? (e.duration = 300), e.ease ?? (e.ease = "easeOut"), e);
}
class Ao extends qe {
  constructor(e) {
    if ((super(), (this.finishedTime = null), (this.isStopped = !1), !e))
      return;
    const {
      element: n,
      name: s,
      keyframes: i,
      pseudoElement: o,
      allowFlatten: r = !1,
      finalKeyframe: a,
      onComplete: l,
    } = e;
    ((this.isPseudoElement = !!o),
      (this.allowFlatten = r),
      (this.options = e),
      je(typeof e.type != "string"));
    const c = bo(e);
    ((this.animation = So(n, s, i, c, o)),
      c.autoplay === !1 && this.animation.pause(),
      (this.animation.onfinish = () => {
        if (((this.finishedTime = this.time), !o)) {
          const u = Ye(i, this.options, a, this.speed);
          (this.updateMotionValue ? this.updateMotionValue(u) : vo(n, s, u),
            this.animation.cancel());
        }
        (l?.(), this.notifyFinished());
      }));
  }
  play() {
    this.isStopped ||
      (this.animation.play(),
      this.state === "finished" && this.updateFinished());
  }
  pause() {
    this.animation.pause();
  }
  complete() {
    this.animation.finish?.();
  }
  cancel() {
    try {
      this.animation.cancel();
    } catch {}
  }
  stop() {
    if (this.isStopped) return;
    this.isStopped = !0;
    const { state: e } = this;
    e === "idle" ||
      e === "finished" ||
      (this.updateMotionValue ? this.updateMotionValue() : this.commitStyles(),
      this.isPseudoElement || this.cancel());
  }
  commitStyles() {
    this.isPseudoElement || this.animation.commitStyles?.();
  }
  get duration() {
    const e = this.animation.effect?.getComputedTiming?.().duration || 0;
    return W(Number(e));
  }
  get iterationDuration() {
    const { delay: e = 0 } = this.options || {};
    return this.duration + W(e);
  }
  get time() {
    return W(Number(this.animation.currentTime) || 0);
  }
  set time(e) {
    ((this.finishedTime = null), (this.animation.currentTime = H(e)));
  }
  get speed() {
    return this.animation.playbackRate;
  }
  set speed(e) {
    (e < 0 && (this.finishedTime = null), (this.animation.playbackRate = e));
  }
  get state() {
    return this.finishedTime !== null ? "finished" : this.animation.playState;
  }
  get startTime() {
    return Number(this.animation.startTime);
  }
  set startTime(e) {
    this.animation.startTime = e;
  }
  attachTimeline({ timeline: e, observe: n }) {
    return (
      this.allowFlatten &&
        this.animation.effect?.updateTiming({ easing: "linear" }),
      (this.animation.onfinish = null),
      e && To() ? ((this.animation.timeline = e), $) : n(this)
    );
  }
}
const ri = { anticipate: Os, backInOut: Is, circInOut: Ns };
function wo(t) {
  return t in ri;
}
function Vo(t) {
  typeof t.ease == "string" && wo(t.ease) && (t.ease = ri[t.ease]);
}
const Cn = 10;
class Co extends Ao {
  constructor(e) {
    (Vo(e),
      Qs(e),
      super(e),
      e.startTime && (this.startTime = e.startTime),
      (this.options = e));
  }
  updateMotionValue(e) {
    const {
      motionValue: n,
      onUpdate: s,
      onComplete: i,
      element: o,
      ...r
    } = this.options;
    if (!n) return;
    if (e !== void 0) {
      n.set(e);
      return;
    }
    const a = new Ze({ ...r, autoplay: !1 }),
      l = H(this.finishedTime ?? this.time);
    (n.setWithVelocity(a.sample(l - Cn).value, a.sample(l).value, Cn),
      a.stop());
  }
}
const Mn = (t, e) =>
  e === "zIndex"
    ? !1
    : !!(
        typeof t == "number" ||
        Array.isArray(t) ||
        (typeof t == "string" &&
          (Z.test(t) || t === "0") &&
          !t.startsWith("url("))
      );
function Mo(t) {
  const e = t[0];
  if (t.length === 1) return !0;
  for (let n = 0; n < t.length; n++) if (t[n] !== e) return !0;
}
function Do(t, e, n, s) {
  const i = t[0];
  if (i === null) return !1;
  if (e === "display" || e === "visibility") return !0;
  const o = t[t.length - 1],
    r = Mn(i, e),
    a = Mn(o, e);
  return !r || !a ? !1 : Mo(t) || ((n === "spring" || ii(n)) && s);
}
function Ae(t) {
  ((t.duration = 0), (t.type = "keyframes"));
}
const Eo = new Set(["opacity", "clipPath", "filter", "transform"]),
  Ro = Ne(() => Object.hasOwnProperty.call(Element.prototype, "animate"));
function Lo(t) {
  const {
    motionValue: e,
    name: n,
    repeatDelay: s,
    repeatType: i,
    damping: o,
    type: r,
  } = t;
  if (!(e?.owner?.current instanceof HTMLElement)) return !1;
  const { onUpdate: l, transformTemplate: c } = e.owner.getProps();
  return (
    Ro() &&
    n &&
    Eo.has(n) &&
    (n !== "transform" || !c) &&
    !l &&
    !s &&
    i !== "mirror" &&
    o !== 0 &&
    r !== "inertia"
  );
}
const ko = 40;
class Fo extends qe {
  constructor({
    autoplay: e = !0,
    delay: n = 0,
    type: s = "keyframes",
    repeat: i = 0,
    repeatDelay: o = 0,
    repeatType: r = "loop",
    keyframes: a,
    name: l,
    motionValue: c,
    element: u,
    ...h
  }) {
    (super(),
      (this.stop = () => {
        (this._animation && (this._animation.stop(), this.stopTimeline?.()),
          this.keyframeResolver?.cancel());
      }),
      (this.createdAt = O.now()));
    const f = {
        autoplay: e,
        delay: n,
        type: s,
        repeat: i,
        repeatDelay: o,
        repeatType: r,
        name: l,
        motionValue: c,
        element: u,
        ...h,
      },
      d = u?.KeyframeResolver || Je;
    ((this.keyframeResolver = new d(
      a,
      (m, v, y) => this.onKeyframesResolved(m, v, f, !y),
      l,
      c,
      u,
    )),
      this.keyframeResolver?.scheduleResolve());
  }
  onKeyframesResolved(e, n, s, i) {
    this.keyframeResolver = void 0;
    const {
      name: o,
      type: r,
      velocity: a,
      delay: l,
      isHandoff: c,
      onUpdate: u,
    } = s;
    ((this.resolvedAt = O.now()),
      Do(e, o, r, a) ||
        ((X.instantAnimations || !l) && u?.(Ye(e, s, n)),
        (e[0] = e[e.length - 1]),
        Ae(s),
        (s.repeat = 0)));
    const f = {
        startTime: i
          ? this.resolvedAt
            ? this.resolvedAt - this.createdAt > ko
              ? this.resolvedAt
              : this.createdAt
            : this.createdAt
          : void 0,
        finalKeyframe: n,
        ...s,
        keyframes: e,
      },
      d =
        !c && Lo(f)
          ? new Co({ ...f, element: f.motionValue.owner.current })
          : new Ze(f);
    (d.finished.then(() => this.notifyFinished()).catch($),
      this.pendingTimeline &&
        ((this.stopTimeline = d.attachTimeline(this.pendingTimeline)),
        (this.pendingTimeline = void 0)),
      (this._animation = d));
  }
  get finished() {
    return this._animation ? this.animation.finished : this._finished;
  }
  then(e, n) {
    return this.finished.finally(e).then(() => {});
  }
  get animation() {
    return (
      this._animation || (this.keyframeResolver?.resume(), go()),
      this._animation
    );
  }
  get duration() {
    return this.animation.duration;
  }
  get iterationDuration() {
    return this.animation.iterationDuration;
  }
  get time() {
    return this.animation.time;
  }
  set time(e) {
    this.animation.time = e;
  }
  get speed() {
    return this.animation.speed;
  }
  get state() {
    return this.animation.state;
  }
  set speed(e) {
    this.animation.speed = e;
  }
  get startTime() {
    return this.animation.startTime;
  }
  attachTimeline(e) {
    return (
      this._animation
        ? (this.stopTimeline = this.animation.attachTimeline(e))
        : (this.pendingTimeline = e),
      () => this.stop()
    );
  }
  play() {
    this.animation.play();
  }
  pause() {
    this.animation.pause();
  }
  complete() {
    this.animation.complete();
  }
  cancel() {
    (this._animation && this.animation.cancel(),
      this.keyframeResolver?.cancel());
  }
}
const Bo = /^var\(--(?:([\w-]+)|([\w-]+), ?([a-zA-Z\d ()%#.,-]+))\)/u;
function Io(t) {
  const e = Bo.exec(t);
  if (!e) return [,];
  const [, n, s, i] = e;
  return [`--${n ?? s}`, i];
}
function oi(t, e, n = 1) {
  const [s, i] = Io(t);
  if (!s) return;
  const o = window.getComputedStyle(e).getPropertyValue(s);
  if (o) {
    const r = o.trim();
    return Ms(r) ? parseFloat(r) : r;
  }
  return Ge(i) ? oi(i, e, n + 1) : i;
}
function Qe(t, e) {
  return t?.[e] ?? t?.default ?? t;
}
const ai = new Set([
    "width",
    "height",
    "top",
    "left",
    "right",
    "bottom",
    ...yt,
  ]),
  Oo = { test: (t) => t === "auto", parse: (t) => t },
  li = (t) => (e) => e.test(t),
  ui = [gt, x, _, Y, Cr, Vr, Oo],
  Dn = (t) => ui.find(li(t));
function jo(t) {
  return typeof t == "number"
    ? t === 0
    : t !== null
      ? t === "none" || t === "0" || Es(t)
      : !0;
}
const No = new Set(["brightness", "contrast", "saturate", "opacity"]);
function Uo(t) {
  const [e, n] = t.slice(0, -1).split("(");
  if (e === "drop-shadow") return t;
  const [s] = n.match(He) || [];
  if (!s) return t;
  const i = n.replace(s, "");
  let o = No.has(e) ? 1 : 0;
  return (s !== n && (o *= 100), e + "(" + o + i + ")");
}
const Ko = /\b([a-z-]*)\(.*?\)/gu,
  we = {
    ...Z,
    getAnimatableNone: (t) => {
      const e = t.match(Ko);
      return e ? e.map(Uo).join(" ") : t;
    },
  },
  En = { ...gt, transform: Math.round },
  Wo = {
    rotate: Y,
    rotateX: Y,
    rotateY: Y,
    rotateZ: Y,
    scale: Ot,
    scaleX: Ot,
    scaleY: Ot,
    scaleZ: Ot,
    skew: Y,
    skewX: Y,
    skewY: Y,
    distance: x,
    translateX: x,
    translateY: x,
    translateZ: x,
    x,
    y: x,
    z: x,
    perspective: x,
    transformPerspective: x,
    opacity: Ct,
    originX: yn,
    originY: yn,
    originZ: x,
  },
  tn = {
    borderWidth: x,
    borderTopWidth: x,
    borderRightWidth: x,
    borderBottomWidth: x,
    borderLeftWidth: x,
    borderRadius: x,
    radius: x,
    borderTopLeftRadius: x,
    borderTopRightRadius: x,
    borderBottomRightRadius: x,
    borderBottomLeftRadius: x,
    width: x,
    maxWidth: x,
    height: x,
    maxHeight: x,
    top: x,
    right: x,
    bottom: x,
    left: x,
    padding: x,
    paddingTop: x,
    paddingRight: x,
    paddingBottom: x,
    paddingLeft: x,
    margin: x,
    marginTop: x,
    marginRight: x,
    marginBottom: x,
    marginLeft: x,
    backgroundPositionX: x,
    backgroundPositionY: x,
    ...Wo,
    zIndex: En,
    fillOpacity: Ct,
    strokeOpacity: Ct,
    numOctaves: En,
  },
  $o = {
    ...tn,
    color: E,
    backgroundColor: E,
    outlineColor: E,
    fill: E,
    stroke: E,
    borderColor: E,
    borderTopColor: E,
    borderRightColor: E,
    borderBottomColor: E,
    borderLeftColor: E,
    filter: we,
    WebkitFilter: we,
  },
  ci = (t) => $o[t];
function hi(t, e) {
  let n = ci(t);
  return (
    n !== we && (n = Z),
    n.getAnimatableNone ? n.getAnimatableNone(e) : void 0
  );
}
const Go = new Set(["auto", "none", "0"]);
function Ho(t, e, n) {
  let s = 0,
    i;
  for (; s < t.length && !i;) {
    const o = t[s];
    (typeof o == "string" && !Go.has(o) && Mt(o).values.length && (i = t[s]),
      s++);
  }
  if (i && n) for (const o of e) t[o] = hi(n, i);
}
class _o extends Je {
  constructor(e, n, s, i, o) {
    super(e, n, s, i, o, !0);
  }
  readKeyframes() {
    const { unresolvedKeyframes: e, element: n, name: s } = this;
    if (!n || !n.current) return;
    super.readKeyframes();
    for (let l = 0; l < e.length; l++) {
      let c = e[l];
      if (typeof c == "string" && ((c = c.trim()), Ge(c))) {
        const u = oi(c, n.current);
        (u !== void 0 && (e[l] = u),
          l === e.length - 1 && (this.finalKeyframe = c));
      }
    }
    if ((this.resolveNoneKeyframes(), !ai.has(s) || e.length !== 2)) return;
    const [i, o] = e,
      r = Dn(i),
      a = Dn(o);
    if (r !== a)
      if (wn(r) && wn(a))
        for (let l = 0; l < e.length; l++) {
          const c = e[l];
          typeof c == "string" && (e[l] = parseFloat(c));
        }
      else it[s] && (this.needsMeasurement = !0);
  }
  resolveNoneKeyframes() {
    const { unresolvedKeyframes: e, name: n } = this,
      s = [];
    for (let i = 0; i < e.length; i++) (e[i] === null || jo(e[i])) && s.push(i);
    s.length && Ho(e, s, n);
  }
  measureInitialState() {
    const { element: e, unresolvedKeyframes: n, name: s } = this;
    if (!e || !e.current) return;
    (s === "height" && (this.suspendedScrollY = window.pageYOffset),
      (this.measuredOrigin = it[s](
        e.measureViewportBox(),
        window.getComputedStyle(e.current),
      )),
      (n[0] = this.measuredOrigin));
    const i = n[n.length - 1];
    i !== void 0 && e.getValue(s, i).jump(i, !1);
  }
  measureEndState() {
    const { element: e, name: n, unresolvedKeyframes: s } = this;
    if (!e || !e.current) return;
    const i = e.getValue(n);
    i && i.jump(this.measuredOrigin, !1);
    const o = s.length - 1,
      r = s[o];
    ((s[o] = it[n](e.measureViewportBox(), window.getComputedStyle(e.current))),
      r !== null && this.finalKeyframe === void 0 && (this.finalKeyframe = r),
      this.removedTransforms?.length &&
        this.removedTransforms.forEach(([a, l]) => {
          e.getValue(a).set(l);
        }),
      this.resolveNoneKeyframes());
  }
}
function zo(t, e, n) {
  if (t instanceof EventTarget) return [t];
  if (typeof t == "string") {
    let s = document;
    const i = n?.[t] ?? s.querySelectorAll(t);
    return i ? Array.from(i) : [];
  }
  return Array.from(t);
}
const fi = (t, e) => (e && typeof t == "number" ? e.transform(t) : t);
function Xo(t) {
  return Ds(t) && "offsetHeight" in t;
}
const Rn = 30,
  Yo = (t) => !isNaN(parseFloat(t));
class qo {
  constructor(e, n = {}) {
    ((this.canTrackVelocity = null),
      (this.events = {}),
      (this.updateAndNotify = (s) => {
        const i = O.now();
        if (
          (this.updatedAt !== i && this.setPrevFrameValue(),
          (this.prev = this.current),
          this.setCurrent(s),
          this.current !== this.prev &&
            (this.events.change?.notify(this.current), this.dependents))
        )
          for (const o of this.dependents) o.dirty();
      }),
      (this.hasAnimated = !1),
      this.setCurrent(e),
      (this.owner = n.owner));
  }
  setCurrent(e) {
    ((this.current = e),
      (this.updatedAt = O.now()),
      this.canTrackVelocity === null &&
        e !== void 0 &&
        (this.canTrackVelocity = Yo(this.current)));
  }
  setPrevFrameValue(e = this.current) {
    ((this.prevFrameValue = e), (this.prevUpdatedAt = this.updatedAt));
  }
  onChange(e) {
    return this.on("change", e);
  }
  on(e, n) {
    this.events[e] || (this.events[e] = new Ue());
    const s = this.events[e].add(n);
    return e === "change"
      ? () => {
          (s(),
            V.read(() => {
              this.events.change.getSize() || this.stop();
            }));
        }
      : s;
  }
  clearListeners() {
    for (const e in this.events) this.events[e].clear();
  }
  attach(e, n) {
    ((this.passiveEffect = e), (this.stopPassiveEffect = n));
  }
  set(e) {
    this.passiveEffect
      ? this.passiveEffect(e, this.updateAndNotify)
      : this.updateAndNotify(e);
  }
  setWithVelocity(e, n, s) {
    (this.set(n),
      (this.prev = void 0),
      (this.prevFrameValue = e),
      (this.prevUpdatedAt = this.updatedAt - s));
  }
  jump(e, n = !0) {
    (this.updateAndNotify(e),
      (this.prev = e),
      (this.prevUpdatedAt = this.prevFrameValue = void 0),
      n && this.stop(),
      this.stopPassiveEffect && this.stopPassiveEffect());
  }
  dirty() {
    this.events.change?.notify(this.current);
  }
  addDependent(e) {
    (this.dependents || (this.dependents = new Set()), this.dependents.add(e));
  }
  removeDependent(e) {
    this.dependents && this.dependents.delete(e);
  }
  get() {
    return this.current;
  }
  getPrevious() {
    return this.prev;
  }
  getVelocity() {
    const e = O.now();
    if (
      !this.canTrackVelocity ||
      this.prevFrameValue === void 0 ||
      e - this.updatedAt > Rn
    )
      return 0;
    const n = Math.min(this.updatedAt - this.prevUpdatedAt, Rn);
    return Rs(parseFloat(this.current) - parseFloat(this.prevFrameValue), n);
  }
  start(e) {
    return (
      this.stop(),
      new Promise((n) => {
        ((this.hasAnimated = !0),
          (this.animation = e(n)),
          this.events.animationStart && this.events.animationStart.notify());
      }).then(() => {
        (this.events.animationComplete &&
          this.events.animationComplete.notify(),
          this.clearAnimation());
      })
    );
  }
  stop() {
    (this.animation &&
      (this.animation.stop(),
      this.events.animationCancel && this.events.animationCancel.notify()),
      this.clearAnimation());
  }
  isAnimating() {
    return !!this.animation;
  }
  clearAnimation() {
    delete this.animation;
  }
  destroy() {
    (this.dependents?.clear(),
      this.events.destroy?.notify(),
      this.clearListeners(),
      this.stop(),
      this.stopPassiveEffect && this.stopPassiveEffect());
  }
}
function mt(t, e) {
  return new qo(t, e);
}
const { schedule: en } = Ws(queueMicrotask, !1),
  G = { x: !1, y: !1 };
function di() {
  return G.x || G.y;
}
function Zo(t) {
  return t === "x" || t === "y"
    ? G[t]
      ? null
      : ((G[t] = !0),
        () => {
          G[t] = !1;
        })
    : G.x || G.y
      ? null
      : ((G.x = G.y = !0),
        () => {
          G.x = G.y = !1;
        });
}
function mi(t, e) {
  const n = zo(t),
    s = new AbortController(),
    i = { passive: !0, ...e, signal: s.signal };
  return [n, i, () => s.abort()];
}
function Ln(t) {
  return !(t.pointerType === "touch" || di());
}
function Jo(t, e, n = {}) {
  const [s, i, o] = mi(t, n),
    r = (a) => {
      if (!Ln(a)) return;
      const { target: l } = a,
        c = e(l, a);
      if (typeof c != "function" || !l) return;
      const u = (h) => {
        Ln(h) && (c(h), l.removeEventListener("pointerleave", u));
      };
      l.addEventListener("pointerleave", u, i);
    };
  return (
    s.forEach((a) => {
      a.addEventListener("pointerenter", r, i);
    }),
    o
  );
}
const pi = (t, e) => (e ? (t === e ? !0 : pi(t, e.parentElement)) : !1),
  nn = (t) =>
    t.pointerType === "mouse"
      ? typeof t.button != "number" || t.button <= 0
      : t.isPrimary !== !1,
  Qo = new Set(["BUTTON", "INPUT", "SELECT", "TEXTAREA", "A"]);
function ta(t) {
  return Qo.has(t.tagName) || t.tabIndex !== -1;
}
const Ut = new WeakSet();
function kn(t) {
  return (e) => {
    e.key === "Enter" && t(e);
  };
}
function ne(t, e) {
  t.dispatchEvent(
    new PointerEvent("pointer" + e, { isPrimary: !0, bubbles: !0 }),
  );
}
const ea = (t, e) => {
  const n = t.currentTarget;
  if (!n) return;
  const s = kn(() => {
    if (Ut.has(n)) return;
    ne(n, "down");
    const i = kn(() => {
        ne(n, "up");
      }),
      o = () => ne(n, "cancel");
    (n.addEventListener("keyup", i, e), n.addEventListener("blur", o, e));
  });
  (n.addEventListener("keydown", s, e),
    n.addEventListener("blur", () => n.removeEventListener("keydown", s), e));
};
function Fn(t) {
  return nn(t) && !di();
}
function na(t, e, n = {}) {
  const [s, i, o] = mi(t, n),
    r = (a) => {
      const l = a.currentTarget;
      if (!Fn(a)) return;
      Ut.add(l);
      const c = e(l, a),
        u = (d, m) => {
          (window.removeEventListener("pointerup", h),
            window.removeEventListener("pointercancel", f),
            Ut.has(l) && Ut.delete(l),
            Fn(d) && typeof c == "function" && c(d, { success: m }));
        },
        h = (d) => {
          u(
            d,
            l === window ||
              l === document ||
              n.useGlobalTarget ||
              pi(l, d.target),
          );
        },
        f = (d) => {
          u(d, !1);
        };
      (window.addEventListener("pointerup", h, i),
        window.addEventListener("pointercancel", f, i));
    };
  return (
    s.forEach((a) => {
      ((n.useGlobalTarget ? window : a).addEventListener("pointerdown", r, i),
        Xo(a) &&
          (a.addEventListener("focus", (c) => ea(c, i)),
          !ta(a) && !a.hasAttribute("tabindex") && (a.tabIndex = 0)));
    }),
    o
  );
}
function gi(t) {
  return Ds(t) && "ownerSVGElement" in t;
}
function sa(t) {
  return gi(t) && t.tagName === "svg";
}
const F = (t) => !!(t && t.getVelocity),
  ia = [...ui, E, Z],
  ra = (t) => ia.find(li(t)),
  yi = S.createContext({
    transformPagePoint: (t) => t,
    isStatic: !1,
    reducedMotion: "never",
  });
function oa(t = !0) {
  const e = S.useContext(Be);
  if (e === null) return [!0, null];
  const { isPresent: n, onExitComplete: s, register: i } = e,
    o = S.useId();
  S.useEffect(() => {
    if (t) return i(o);
  }, [t]);
  const r = S.useCallback(() => t && s && s(o), [o, s, t]);
  return !n && s ? [!1, r] : [!0];
}
const vi = S.createContext({ strict: !1 }),
  Bn = {
    animation: [
      "animate",
      "variants",
      "whileHover",
      "whileTap",
      "exit",
      "whileInView",
      "whileFocus",
      "whileDrag",
    ],
    exit: ["exit"],
    drag: ["drag", "dragControls"],
    focus: ["whileFocus"],
    hover: ["whileHover", "onHoverStart", "onHoverEnd"],
    tap: ["whileTap", "onTap", "onTapStart", "onTapCancel"],
    pan: ["onPan", "onPanStart", "onPanSessionStart", "onPanEnd"],
    inView: ["whileInView", "onViewportEnter", "onViewportLeave"],
    layout: ["layout", "layoutId"],
  },
  pt = {};
for (const t in Bn) pt[t] = { isEnabled: (e) => Bn[t].some((n) => !!e[n]) };
function aa(t) {
  for (const e in t) pt[e] = { ...pt[e], ...t[e] };
}
const la = new Set([
  "animate",
  "exit",
  "variants",
  "initial",
  "style",
  "values",
  "variants",
  "transition",
  "transformTemplate",
  "custom",
  "inherit",
  "onBeforeLayoutMeasure",
  "onAnimationStart",
  "onAnimationComplete",
  "onUpdate",
  "onDragStart",
  "onDrag",
  "onDragEnd",
  "onMeasureDragConstraints",
  "onDirectionLock",
  "onDragTransitionEnd",
  "_dragX",
  "_dragY",
  "onHoverStart",
  "onHoverEnd",
  "onViewportEnter",
  "onViewportLeave",
  "globalTapTarget",
  "ignoreStrict",
  "viewport",
]);
function _t(t) {
  return (
    t.startsWith("while") ||
    (t.startsWith("drag") && t !== "draggable") ||
    t.startsWith("layout") ||
    t.startsWith("onTap") ||
    t.startsWith("onPan") ||
    t.startsWith("onLayout") ||
    la.has(t)
  );
}
let Ti = (t) => !_t(t);
function ua(t) {
  typeof t == "function" && (Ti = (e) => (e.startsWith("on") ? !_t(e) : t(e)));
}
try {
  ua(require("@emotion/is-prop-valid").default);
} catch {}
function ca(t, e, n) {
  const s = {};
  for (const i in t)
    (i === "values" && typeof t.values == "object") ||
      ((Ti(i) ||
        (n === !0 && _t(i)) ||
        (!e && !_t(i)) ||
        (t.draggable && i.startsWith("onDrag"))) &&
        (s[i] = t[i]));
  return s;
}
const Xt = S.createContext({});
function Yt(t) {
  return t !== null && typeof t == "object" && typeof t.start == "function";
}
function Dt(t) {
  return typeof t == "string" || Array.isArray(t);
}
const sn = [
    "animate",
    "whileInView",
    "whileFocus",
    "whileHover",
    "whileTap",
    "whileDrag",
    "exit",
  ],
  rn = ["initial", ...sn];
function qt(t) {
  return Yt(t.animate) || rn.some((e) => Dt(t[e]));
}
function xi(t) {
  return !!(qt(t) || t.variants);
}
function ha(t, e) {
  if (qt(t)) {
    const { initial: n, animate: s } = t;
    return {
      initial: n === !1 || Dt(n) ? n : void 0,
      animate: Dt(s) ? s : void 0,
    };
  }
  return t.inherit !== !1 ? e : {};
}
function fa(t) {
  const { initial: e, animate: n } = ha(t, S.useContext(Xt));
  return S.useMemo(() => ({ initial: e, animate: n }), [In(e), In(n)]);
}
function In(t) {
  return Array.isArray(t) ? t.join(" ") : t;
}
const Et = {};
function da(t) {
  for (const e in t) ((Et[e] = t[e]), $e(e) && (Et[e].isCSSVariable = !0));
}
function Pi(t, { layout: e, layoutId: n }) {
  return (
    vt.has(t) ||
    t.startsWith("origin") ||
    ((e || n !== void 0) && (!!Et[t] || t === "opacity"))
  );
}
const ma = {
    x: "translateX",
    y: "translateY",
    z: "translateZ",
    transformPerspective: "perspective",
  },
  pa = yt.length;
function ga(t, e, n) {
  let s = "",
    i = !0;
  for (let o = 0; o < pa; o++) {
    const r = yt[o],
      a = t[r];
    if (a === void 0) continue;
    let l = !0;
    if (
      (typeof a == "number"
        ? (l = a === (r.startsWith("scale") ? 1 : 0))
        : (l = parseFloat(a) === 0),
      !l || n)
    ) {
      const c = fi(a, tn[r]);
      if (!l) {
        i = !1;
        const u = ma[r] || r;
        s += `${u}(${c}) `;
      }
      n && (e[r] = c);
    }
  }
  return ((s = s.trim()), n ? (s = n(e, i ? "" : s)) : i && (s = "none"), s);
}
function on(t, e, n) {
  const { style: s, vars: i, transformOrigin: o } = t;
  let r = !1,
    a = !1;
  for (const l in e) {
    const c = e[l];
    if (vt.has(l)) {
      r = !0;
      continue;
    } else if ($e(l)) {
      i[l] = c;
      continue;
    } else {
      const u = fi(c, tn[l]);
      l.startsWith("origin") ? ((a = !0), (o[l] = u)) : (s[l] = u);
    }
  }
  if (
    (e.transform ||
      (r || n
        ? (s.transform = ga(e, t.transform, n))
        : s.transform && (s.transform = "none")),
    a)
  ) {
    const { originX: l = "50%", originY: c = "50%", originZ: u = 0 } = o;
    s.transformOrigin = `${l} ${c} ${u}`;
  }
}
const an = () => ({ style: {}, transform: {}, transformOrigin: {}, vars: {} });
function Si(t, e, n) {
  for (const s in e) !F(e[s]) && !Pi(s, n) && (t[s] = e[s]);
}
function ya({ transformTemplate: t }, e) {
  return S.useMemo(() => {
    const n = an();
    return (on(n, e, t), Object.assign({}, n.vars, n.style));
  }, [e]);
}
function va(t, e) {
  const n = t.style || {},
    s = {};
  return (Si(s, n, t), Object.assign(s, ya(t, e)), s);
}
function Ta(t, e) {
  const n = {},
    s = va(t, e);
  return (
    t.drag &&
      t.dragListener !== !1 &&
      ((n.draggable = !1),
      (s.userSelect = s.WebkitUserSelect = s.WebkitTouchCallout = "none"),
      (s.touchAction =
        t.drag === !0 ? "none" : `pan-${t.drag === "x" ? "y" : "x"}`)),
    t.tabIndex === void 0 &&
      (t.onTap || t.onTapStart || t.whileTap) &&
      (n.tabIndex = 0),
    (n.style = s),
    n
  );
}
const xa = { offset: "stroke-dashoffset", array: "stroke-dasharray" },
  Pa = { offset: "strokeDashoffset", array: "strokeDasharray" };
function Sa(t, e, n = 1, s = 0, i = !0) {
  t.pathLength = 1;
  const o = i ? xa : Pa;
  t[o.offset] = x.transform(-s);
  const r = x.transform(e),
    a = x.transform(n);
  t[o.array] = `${r} ${a}`;
}
function bi(
  t,
  {
    attrX: e,
    attrY: n,
    attrScale: s,
    pathLength: i,
    pathSpacing: o = 1,
    pathOffset: r = 0,
    ...a
  },
  l,
  c,
  u,
) {
  if ((on(t, a, c), l)) {
    t.style.viewBox && (t.attrs.viewBox = t.style.viewBox);
    return;
  }
  ((t.attrs = t.style), (t.style = {}));
  const { attrs: h, style: f } = t;
  (h.transform && ((f.transform = h.transform), delete h.transform),
    (f.transform || h.transformOrigin) &&
      ((f.transformOrigin = h.transformOrigin ?? "50% 50%"),
      delete h.transformOrigin),
    f.transform &&
      ((f.transformBox = u?.transformBox ?? "fill-box"), delete h.transformBox),
    e !== void 0 && (h.x = e),
    n !== void 0 && (h.y = n),
    s !== void 0 && (h.scale = s),
    i !== void 0 && Sa(h, i, o, r, !1));
}
const Ai = () => ({ ...an(), attrs: {} }),
  wi = (t) => typeof t == "string" && t.toLowerCase() === "svg";
function ba(t, e, n, s) {
  const i = S.useMemo(() => {
    const o = Ai();
    return (
      bi(o, e, wi(s), t.transformTemplate, t.style),
      { ...o.attrs, style: { ...o.style } }
    );
  }, [e]);
  if (t.style) {
    const o = {};
    (Si(o, t.style, t), (i.style = { ...o, ...i.style }));
  }
  return i;
}
const Aa = [
  "animate",
  "circle",
  "defs",
  "desc",
  "ellipse",
  "g",
  "image",
  "line",
  "filter",
  "marker",
  "mask",
  "metadata",
  "path",
  "pattern",
  "polygon",
  "polyline",
  "rect",
  "stop",
  "switch",
  "symbol",
  "svg",
  "text",
  "tspan",
  "use",
  "view",
];
function ln(t) {
  return typeof t != "string" || t.includes("-")
    ? !1
    : !!(Aa.indexOf(t) > -1 || /[A-Z]/u.test(t));
}
function wa(t, e, n, { latestValues: s }, i, o = !1) {
  const a = (ln(t) ? ba : Ta)(e, s, i, t),
    l = ca(e, typeof t == "string", o),
    c = t !== S.Fragment ? { ...l, ...a, ref: n } : {},
    { children: u } = e,
    h = S.useMemo(() => (F(u) ? u.get() : u), [u]);
  return S.createElement(t, { ...c, children: h });
}
function On(t) {
  const e = [{}, {}];
  return (
    t?.values.forEach((n, s) => {
      ((e[0][s] = n.get()), (e[1][s] = n.getVelocity()));
    }),
    e
  );
}
function un(t, e, n, s) {
  if (typeof e == "function") {
    const [i, o] = On(s);
    e = e(n !== void 0 ? n : t.custom, i, o);
  }
  if (
    (typeof e == "string" && (e = t.variants && t.variants[e]),
    typeof e == "function")
  ) {
    const [i, o] = On(s);
    e = e(n !== void 0 ? n : t.custom, i, o);
  }
  return e;
}
function Kt(t) {
  return F(t) ? t.get() : t;
}
function Va({ scrapeMotionValuesFromProps: t, createRenderState: e }, n, s, i) {
  return { latestValues: Ca(n, s, i, t), renderState: e() };
}
function Ca(t, e, n, s) {
  const i = {},
    o = s(t, {});
  for (const f in o) i[f] = Kt(o[f]);
  let { initial: r, animate: a } = t;
  const l = qt(t),
    c = xi(t);
  e &&
    c &&
    !l &&
    t.inherit !== !1 &&
    (r === void 0 && (r = e.initial), a === void 0 && (a = e.animate));
  let u = n ? n.initial === !1 : !1;
  u = u || r === !1;
  const h = u ? a : r;
  if (h && typeof h != "boolean" && !Yt(h)) {
    const f = Array.isArray(h) ? h : [h];
    for (let d = 0; d < f.length; d++) {
      const m = un(t, f[d]);
      if (m) {
        const { transitionEnd: v, transition: y, ...p } = m;
        for (const T in p) {
          let g = p[T];
          if (Array.isArray(g)) {
            const A = u ? g.length - 1 : 0;
            g = g[A];
          }
          g !== null && (i[T] = g);
        }
        for (const T in v) i[T] = v[T];
      }
    }
  }
  return i;
}
const Vi = (t) => (e, n) => {
  const s = S.useContext(Xt),
    i = S.useContext(Be),
    o = () => Va(t, e, s, i);
  return n ? o() : or(o);
};
function cn(t, e, n) {
  const { style: s } = t,
    i = {};
  for (const o in s)
    (F(s[o]) ||
      (e.style && F(e.style[o])) ||
      Pi(o, t) ||
      n?.getValue(o)?.liveStyle !== void 0) &&
      (i[o] = s[o]);
  return i;
}
const Ma = Vi({ scrapeMotionValuesFromProps: cn, createRenderState: an });
function Ci(t, e, n) {
  const s = cn(t, e, n);
  for (const i in t)
    if (F(t[i]) || F(e[i])) {
      const o =
        yt.indexOf(i) !== -1
          ? "attr" + i.charAt(0).toUpperCase() + i.substring(1)
          : i;
      s[o] = t[i];
    }
  return s;
}
const Da = Vi({ scrapeMotionValuesFromProps: Ci, createRenderState: Ai }),
  Ea = Symbol.for("motionComponentSymbol");
function ut(t) {
  return (
    t &&
    typeof t == "object" &&
    Object.prototype.hasOwnProperty.call(t, "current")
  );
}
function Ra(t, e, n) {
  return S.useCallback(
    (s) => {
      (s && t.onMount && t.onMount(s),
        e && (s ? e.mount(s) : e.unmount()),
        n && (typeof n == "function" ? n(s) : ut(n) && (n.current = s)));
    },
    [e],
  );
}
const hn = (t) => t.replace(/([a-z])([A-Z])/gu, "$1-$2").toLowerCase(),
  La = "framerAppearId",
  Mi = "data-" + hn(La),
  Di = S.createContext({});
function ka(t, e, n, s, i) {
  const { visualElement: o } = S.useContext(Xt),
    r = S.useContext(vi),
    a = S.useContext(Be),
    l = S.useContext(yi).reducedMotion,
    c = S.useRef(null);
  ((s = s || r.renderer),
    !c.current &&
      s &&
      (c.current = s(t, {
        visualState: e,
        parent: o,
        props: n,
        presenceContext: a,
        blockInitialAnimation: a ? a.initial === !1 : !1,
        reducedMotionConfig: l,
      })));
  const u = c.current,
    h = S.useContext(Di);
  u &&
    !u.projection &&
    i &&
    (u.type === "html" || u.type === "svg") &&
    Fa(c.current, n, i, h);
  const f = S.useRef(!1);
  S.useInsertionEffect(() => {
    u && f.current && u.update(n, a);
  });
  const d = n[Mi],
    m = S.useRef(
      !!d &&
        !window.MotionHandoffIsComplete?.(d) &&
        window.MotionHasOptimisedAnimation?.(d),
    );
  return (
    ar(() => {
      u &&
        ((f.current = !0),
        (window.MotionIsMounted = !0),
        u.updateFeatures(),
        u.scheduleRenderMicrotask(),
        m.current && u.animationState && u.animationState.animateChanges());
    }),
    S.useEffect(() => {
      u &&
        (!m.current && u.animationState && u.animationState.animateChanges(),
        m.current &&
          (queueMicrotask(() => {
            window.MotionHandoffMarkAsComplete?.(d);
          }),
          (m.current = !1)),
        (u.enteringChildren = void 0));
    }),
    u
  );
}
function Fa(t, e, n, s) {
  const {
    layoutId: i,
    layout: o,
    drag: r,
    dragConstraints: a,
    layoutScroll: l,
    layoutRoot: c,
    layoutCrossfade: u,
  } = e;
  ((t.projection = new n(
    t.latestValues,
    e["data-framer-portal-id"] ? void 0 : Ei(t.parent),
  )),
    t.projection.setOptions({
      layoutId: i,
      layout: o,
      alwaysMeasureLayout: !!r || (a && ut(a)),
      visualElement: t,
      animationType: typeof o == "string" ? o : "both",
      initialPromotionConfig: s,
      crossfade: u,
      layoutScroll: l,
      layoutRoot: c,
    }));
}
function Ei(t) {
  if (t) return t.options.allowProjection !== !1 ? t.projection : Ei(t.parent);
}
function se(t, { forwardMotionProps: e = !1 } = {}, n, s) {
  n && aa(n);
  const i = ln(t) ? Da : Ma;
  function o(a, l) {
    let c;
    const u = { ...S.useContext(yi), ...a, layoutId: Ba(a) },
      { isStatic: h } = u,
      f = fa(a),
      d = i(a, h);
    if (!h && Fe) {
      Ia();
      const m = Oa(u);
      ((c = m.MeasureLayout),
        (f.visualElement = ka(t, d, u, s, m.ProjectionNode)));
    }
    return fe.jsxs(Xt.Provider, {
      value: f,
      children: [
        c && f.visualElement
          ? fe.jsx(c, { visualElement: f.visualElement, ...u })
          : null,
        wa(t, a, Ra(d, f.visualElement, l), d, h, e),
      ],
    });
  }
  o.displayName = `motion.${typeof t == "string" ? t : `create(${t.displayName ?? t.name ?? ""})`}`;
  const r = S.forwardRef(o);
  return ((r[Ea] = t), r);
}
function Ba({ layoutId: t }) {
  const e = S.useContext(Cs).id;
  return e && t !== void 0 ? e + "-" + t : t;
}
function Ia(t, e) {
  S.useContext(vi).strict;
}
function Oa(t) {
  const { drag: e, layout: n } = pt;
  if (!e && !n) return {};
  const s = { ...e, ...n };
  return {
    MeasureLayout:
      e?.isEnabled(t) || n?.isEnabled(t) ? s.MeasureLayout : void 0,
    ProjectionNode: s.ProjectionNode,
  };
}
function ja(t, e) {
  if (typeof Proxy > "u") return se;
  const n = new Map(),
    s = (o, r) => se(o, r, t, e),
    i = (o, r) => s(o, r);
  return new Proxy(i, {
    get: (o, r) =>
      r === "create"
        ? s
        : (n.has(r) || n.set(r, se(r, void 0, t, e)), n.get(r)),
  });
}
function Ri({ top: t, left: e, right: n, bottom: s }) {
  return { x: { min: e, max: n }, y: { min: t, max: s } };
}
function Na({ x: t, y: e }) {
  return { top: e.min, right: t.max, bottom: e.max, left: t.min };
}
function Ua(t, e) {
  if (!e) return t;
  const n = e({ x: t.left, y: t.top }),
    s = e({ x: t.right, y: t.bottom });
  return { top: n.y, left: n.x, bottom: s.y, right: s.x };
}
function ie(t) {
  return t === void 0 || t === 1;
}
function Ve({ scale: t, scaleX: e, scaleY: n }) {
  return !ie(t) || !ie(e) || !ie(n);
}
function et(t) {
  return (
    Ve(t) ||
    Li(t) ||
    t.z ||
    t.rotate ||
    t.rotateX ||
    t.rotateY ||
    t.skewX ||
    t.skewY
  );
}
function Li(t) {
  return jn(t.x) || jn(t.y);
}
function jn(t) {
  return t && t !== "0%";
}
function zt(t, e, n) {
  const s = t - n,
    i = e * s;
  return n + i;
}
function Nn(t, e, n, s, i) {
  return (i !== void 0 && (t = zt(t, i, s)), zt(t, n, s) + e);
}
function Ce(t, e = 0, n = 1, s, i) {
  ((t.min = Nn(t.min, e, n, s, i)), (t.max = Nn(t.max, e, n, s, i)));
}
function ki(t, { x: e, y: n }) {
  (Ce(t.x, e.translate, e.scale, e.originPoint),
    Ce(t.y, n.translate, n.scale, n.originPoint));
}
const Un = 0.999999999999,
  Kn = 1.0000000000001;
function Ka(t, e, n, s = !1) {
  const i = n.length;
  if (!i) return;
  e.x = e.y = 1;
  let o, r;
  for (let a = 0; a < i; a++) {
    ((o = n[a]), (r = o.projectionDelta));
    const { visualElement: l } = o.options;
    (l && l.props.style && l.props.style.display === "contents") ||
      (s &&
        o.options.layoutScroll &&
        o.scroll &&
        o !== o.root &&
        ht(t, { x: -o.scroll.offset.x, y: -o.scroll.offset.y }),
      r && ((e.x *= r.x.scale), (e.y *= r.y.scale), ki(t, r)),
      s && et(o.latestValues) && ht(t, o.latestValues));
  }
  (e.x < Kn && e.x > Un && (e.x = 1), e.y < Kn && e.y > Un && (e.y = 1));
}
function ct(t, e) {
  ((t.min = t.min + e), (t.max = t.max + e));
}
function Wn(t, e, n, s, i = 0.5) {
  const o = C(t.min, t.max, i);
  Ce(t, e, n, o, s);
}
function ht(t, e) {
  (Wn(t.x, e.x, e.scaleX, e.scale, e.originX),
    Wn(t.y, e.y, e.scaleY, e.scale, e.originY));
}
function Fi(t, e) {
  return Ri(Ua(t.getBoundingClientRect(), e));
}
function Wa(t, e, n) {
  const s = Fi(t, n),
    { scroll: i } = e;
  return (i && (ct(s.x, i.offset.x), ct(s.y, i.offset.y)), s);
}
const $n = () => ({ translate: 0, scale: 1, origin: 0, originPoint: 0 }),
  ft = () => ({ x: $n(), y: $n() }),
  Gn = () => ({ min: 0, max: 0 }),
  D = () => ({ x: Gn(), y: Gn() }),
  Me = { current: null },
  Bi = { current: !1 };
function $a() {
  if (((Bi.current = !0), !!Fe))
    if (window.matchMedia) {
      const t = window.matchMedia("(prefers-reduced-motion)"),
        e = () => (Me.current = t.matches);
      (t.addEventListener("change", e), e());
    } else Me.current = !1;
}
const Ga = new WeakMap();
function Ha(t, e, n) {
  for (const s in e) {
    const i = e[s],
      o = n[s];
    if (F(i)) t.addValue(s, i);
    else if (F(o)) t.addValue(s, mt(i, { owner: t }));
    else if (o !== i)
      if (t.hasValue(s)) {
        const r = t.getValue(s);
        r.liveStyle === !0 ? r.jump(i) : r.hasAnimated || r.set(i);
      } else {
        const r = t.getStaticValue(s);
        t.addValue(s, mt(r !== void 0 ? r : i, { owner: t }));
      }
  }
  for (const s in n) e[s] === void 0 && t.removeValue(s);
  return e;
}
const Hn = [
  "AnimationStart",
  "AnimationComplete",
  "Update",
  "BeforeLayoutMeasure",
  "LayoutMeasure",
  "LayoutAnimationStart",
  "LayoutAnimationComplete",
];
class _a {
  scrapeMotionValuesFromProps(e, n, s) {
    return {};
  }
  constructor(
    {
      parent: e,
      props: n,
      presenceContext: s,
      reducedMotionConfig: i,
      blockInitialAnimation: o,
      visualState: r,
    },
    a = {},
  ) {
    ((this.current = null),
      (this.children = new Set()),
      (this.isVariantNode = !1),
      (this.isControllingVariants = !1),
      (this.shouldReduceMotion = null),
      (this.values = new Map()),
      (this.KeyframeResolver = Je),
      (this.features = {}),
      (this.valueSubscriptions = new Map()),
      (this.prevMotionValues = {}),
      (this.events = {}),
      (this.propEventSubscriptions = {}),
      (this.notifyUpdate = () => this.notify("Update", this.latestValues)),
      (this.render = () => {
        this.current &&
          (this.triggerBuild(),
          this.renderInstance(
            this.current,
            this.renderState,
            this.props.style,
            this.projection,
          ));
      }),
      (this.renderScheduledAt = 0),
      (this.scheduleRender = () => {
        const f = O.now();
        this.renderScheduledAt < f &&
          ((this.renderScheduledAt = f), V.render(this.render, !1, !0));
      }));
    const { latestValues: l, renderState: c } = r;
    ((this.latestValues = l),
      (this.baseTarget = { ...l }),
      (this.initialValues = n.initial ? { ...l } : {}),
      (this.renderState = c),
      (this.parent = e),
      (this.props = n),
      (this.presenceContext = s),
      (this.depth = e ? e.depth + 1 : 0),
      (this.reducedMotionConfig = i),
      (this.options = a),
      (this.blockInitialAnimation = !!o),
      (this.isControllingVariants = qt(n)),
      (this.isVariantNode = xi(n)),
      this.isVariantNode && (this.variantChildren = new Set()),
      (this.manuallyAnimateOnMount = !!(e && e.current)));
    const { willChange: u, ...h } = this.scrapeMotionValuesFromProps(
      n,
      {},
      this,
    );
    for (const f in h) {
      const d = h[f];
      l[f] !== void 0 && F(d) && d.set(l[f]);
    }
  }
  mount(e) {
    ((this.current = e),
      Ga.set(e, this),
      this.projection && !this.projection.instance && this.projection.mount(e),
      this.parent &&
        this.isVariantNode &&
        !this.isControllingVariants &&
        (this.removeFromVariantTree = this.parent.addVariantChild(this)),
      this.values.forEach((n, s) => this.bindToMotionValue(s, n)),
      Bi.current || $a(),
      (this.shouldReduceMotion =
        this.reducedMotionConfig === "never"
          ? !1
          : this.reducedMotionConfig === "always"
            ? !0
            : Me.current),
      this.parent?.addChild(this),
      this.update(this.props, this.presenceContext));
  }
  unmount() {
    (this.projection && this.projection.unmount(),
      q(this.notifyUpdate),
      q(this.render),
      this.valueSubscriptions.forEach((e) => e()),
      this.valueSubscriptions.clear(),
      this.removeFromVariantTree && this.removeFromVariantTree(),
      this.parent?.removeChild(this));
    for (const e in this.events) this.events[e].clear();
    for (const e in this.features) {
      const n = this.features[e];
      n && (n.unmount(), (n.isMounted = !1));
    }
    this.current = null;
  }
  addChild(e) {
    (this.children.add(e),
      this.enteringChildren ?? (this.enteringChildren = new Set()),
      this.enteringChildren.add(e));
  }
  removeChild(e) {
    (this.children.delete(e),
      this.enteringChildren && this.enteringChildren.delete(e));
  }
  bindToMotionValue(e, n) {
    this.valueSubscriptions.has(e) && this.valueSubscriptions.get(e)();
    const s = vt.has(e);
    s && this.onBindTransform && this.onBindTransform();
    const i = n.on("change", (r) => {
      ((this.latestValues[e] = r),
        this.props.onUpdate && V.preRender(this.notifyUpdate),
        s && this.projection && (this.projection.isTransformDirty = !0),
        this.scheduleRender());
    });
    let o;
    (window.MotionCheckAppearSync &&
      (o = window.MotionCheckAppearSync(this, e, n)),
      this.valueSubscriptions.set(e, () => {
        (i(), o && o(), n.owner && n.stop());
      }));
  }
  sortNodePosition(e) {
    return !this.current ||
      !this.sortInstanceNodePosition ||
      this.type !== e.type
      ? 0
      : this.sortInstanceNodePosition(this.current, e.current);
  }
  updateFeatures() {
    let e = "animation";
    for (e in pt) {
      const n = pt[e];
      if (!n) continue;
      const { isEnabled: s, Feature: i } = n;
      if (
        (!this.features[e] &&
          i &&
          s(this.props) &&
          (this.features[e] = new i(this)),
        this.features[e])
      ) {
        const o = this.features[e];
        o.isMounted ? o.update() : (o.mount(), (o.isMounted = !0));
      }
    }
  }
  triggerBuild() {
    this.build(this.renderState, this.latestValues, this.props);
  }
  measureViewportBox() {
    return this.current
      ? this.measureInstanceViewportBox(this.current, this.props)
      : D();
  }
  getStaticValue(e) {
    return this.latestValues[e];
  }
  setStaticValue(e, n) {
    this.latestValues[e] = n;
  }
  update(e, n) {
    ((e.transformTemplate || this.props.transformTemplate) &&
      this.scheduleRender(),
      (this.prevProps = this.props),
      (this.props = e),
      (this.prevPresenceContext = this.presenceContext),
      (this.presenceContext = n));
    for (let s = 0; s < Hn.length; s++) {
      const i = Hn[s];
      this.propEventSubscriptions[i] &&
        (this.propEventSubscriptions[i](),
        delete this.propEventSubscriptions[i]);
      const o = "on" + i,
        r = e[o];
      r && (this.propEventSubscriptions[i] = this.on(i, r));
    }
    ((this.prevMotionValues = Ha(
      this,
      this.scrapeMotionValuesFromProps(e, this.prevProps, this),
      this.prevMotionValues,
    )),
      this.handleChildMotionValue && this.handleChildMotionValue());
  }
  getProps() {
    return this.props;
  }
  getVariant(e) {
    return this.props.variants ? this.props.variants[e] : void 0;
  }
  getDefaultTransition() {
    return this.props.transition;
  }
  getTransformPagePoint() {
    return this.props.transformPagePoint;
  }
  getClosestVariantNode() {
    return this.isVariantNode
      ? this
      : this.parent
        ? this.parent.getClosestVariantNode()
        : void 0;
  }
  addVariantChild(e) {
    const n = this.getClosestVariantNode();
    if (n)
      return (
        n.variantChildren && n.variantChildren.add(e),
        () => n.variantChildren.delete(e)
      );
  }
  addValue(e, n) {
    const s = this.values.get(e);
    n !== s &&
      (s && this.removeValue(e),
      this.bindToMotionValue(e, n),
      this.values.set(e, n),
      (this.latestValues[e] = n.get()));
  }
  removeValue(e) {
    this.values.delete(e);
    const n = this.valueSubscriptions.get(e);
    (n && (n(), this.valueSubscriptions.delete(e)),
      delete this.latestValues[e],
      this.removeValueFromRenderState(e, this.renderState));
  }
  hasValue(e) {
    return this.values.has(e);
  }
  getValue(e, n) {
    if (this.props.values && this.props.values[e]) return this.props.values[e];
    let s = this.values.get(e);
    return (
      s === void 0 &&
        n !== void 0 &&
        ((s = mt(n === null ? void 0 : n, { owner: this })),
        this.addValue(e, s)),
      s
    );
  }
  readValue(e, n) {
    let s =
      this.latestValues[e] !== void 0 || !this.current
        ? this.latestValues[e]
        : (this.getBaseTargetFromProps(this.props, e) ??
          this.readValueFromInstance(this.current, e, this.options));
    return (
      s != null &&
        (typeof s == "string" && (Ms(s) || Es(s))
          ? (s = parseFloat(s))
          : !ra(s) && Z.test(n) && (s = hi(e, n)),
        this.setBaseTarget(e, F(s) ? s.get() : s)),
      F(s) ? s.get() : s
    );
  }
  setBaseTarget(e, n) {
    this.baseTarget[e] = n;
  }
  getBaseTarget(e) {
    const { initial: n } = this.props;
    let s;
    if (typeof n == "string" || typeof n == "object") {
      const o = un(this.props, n, this.presenceContext?.custom);
      o && (s = o[e]);
    }
    if (n && s !== void 0) return s;
    const i = this.getBaseTargetFromProps(this.props, e);
    return i !== void 0 && !F(i)
      ? i
      : this.initialValues[e] !== void 0 && s === void 0
        ? void 0
        : this.baseTarget[e];
  }
  on(e, n) {
    return (
      this.events[e] || (this.events[e] = new Ue()),
      this.events[e].add(n)
    );
  }
  notify(e, ...n) {
    this.events[e] && this.events[e].notify(...n);
  }
  scheduleRenderMicrotask() {
    en.render(this.render);
  }
}
class Ii extends _a {
  constructor() {
    (super(...arguments), (this.KeyframeResolver = _o));
  }
  sortInstanceNodePosition(e, n) {
    return e.compareDocumentPosition(n) & 2 ? 1 : -1;
  }
  getBaseTargetFromProps(e, n) {
    return e.style ? e.style[n] : void 0;
  }
  removeValueFromRenderState(e, { vars: n, style: s }) {
    (delete n[e], delete s[e]);
  }
  handleChildMotionValue() {
    this.childSubscription &&
      (this.childSubscription(), delete this.childSubscription);
    const { children: e } = this.props;
    F(e) &&
      (this.childSubscription = e.on("change", (n) => {
        this.current && (this.current.textContent = `${n}`);
      }));
  }
}
function Oi(t, { style: e, vars: n }, s, i) {
  const o = t.style;
  let r;
  for (r in e) o[r] = e[r];
  i?.applyProjectionStyles(o, s);
  for (r in n) o.setProperty(r, n[r]);
}
function za(t) {
  return window.getComputedStyle(t);
}
class Xa extends Ii {
  constructor() {
    (super(...arguments), (this.type = "html"), (this.renderInstance = Oi));
  }
  readValueFromInstance(e, n) {
    if (vt.has(n)) return this.projection?.isProjecting ? Te(n) : co(e, n);
    {
      const s = za(e),
        i = ($e(n) ? s.getPropertyValue(n) : s[n]) || 0;
      return typeof i == "string" ? i.trim() : i;
    }
  }
  measureInstanceViewportBox(e, { transformPagePoint: n }) {
    return Fi(e, n);
  }
  build(e, n, s) {
    on(e, n, s.transformTemplate);
  }
  scrapeMotionValuesFromProps(e, n, s) {
    return cn(e, n, s);
  }
}
const ji = new Set([
  "baseFrequency",
  "diffuseConstant",
  "kernelMatrix",
  "kernelUnitLength",
  "keySplines",
  "keyTimes",
  "limitingConeAngle",
  "markerHeight",
  "markerWidth",
  "numOctaves",
  "targetX",
  "targetY",
  "surfaceScale",
  "specularConstant",
  "specularExponent",
  "stdDeviation",
  "tableValues",
  "viewBox",
  "gradientTransform",
  "pathLength",
  "startOffset",
  "textLength",
  "lengthAdjust",
]);
function Ya(t, e, n, s) {
  Oi(t, e, void 0, s);
  for (const i in e.attrs) t.setAttribute(ji.has(i) ? i : hn(i), e.attrs[i]);
}
class qa extends Ii {
  constructor() {
    (super(...arguments),
      (this.type = "svg"),
      (this.isSVGTag = !1),
      (this.measureInstanceViewportBox = D));
  }
  getBaseTargetFromProps(e, n) {
    return e[n];
  }
  readValueFromInstance(e, n) {
    if (vt.has(n)) {
      const s = ci(n);
      return (s && s.default) || 0;
    }
    return ((n = ji.has(n) ? n : hn(n)), e.getAttribute(n));
  }
  scrapeMotionValuesFromProps(e, n, s) {
    return Ci(e, n, s);
  }
  build(e, n, s) {
    bi(e, n, this.isSVGTag, s.transformTemplate, s.style);
  }
  renderInstance(e, n, s, i) {
    Ya(e, n, s, i);
  }
  mount(e) {
    ((this.isSVGTag = wi(e.tagName)), super.mount(e));
  }
}
const Za = (t, e) =>
  ln(t) ? new qa(e) : new Xa(e, { allowProjection: t !== S.Fragment });
function dt(t, e, n) {
  const s = t.getProps();
  return un(s, e, n !== void 0 ? n : s.custom, t);
}
const De = (t) => Array.isArray(t);
function Ja(t, e, n) {
  t.hasValue(e) ? t.getValue(e).set(n) : t.addValue(e, mt(n));
}
function Qa(t) {
  return De(t) ? t[t.length - 1] || 0 : t;
}
function tl(t, e) {
  const n = dt(t, e);
  let { transitionEnd: s = {}, transition: i = {}, ...o } = n || {};
  o = { ...o, ...s };
  for (const r in o) {
    const a = Qa(o[r]);
    Ja(t, r, a);
  }
}
function el(t) {
  return !!(F(t) && t.add);
}
function Ee(t, e) {
  const n = t.getValue("willChange");
  if (el(n)) return n.add(e);
  if (!n && X.WillChange) {
    const s = new X.WillChange("auto");
    (t.addValue("willChange", s), s.add(e));
  }
}
function Ni(t) {
  return t.props[Mi];
}
const nl = (t) => t !== null;
function sl(t, { repeat: e, repeatType: n = "loop" }, s) {
  const i = t.filter(nl),
    o = e && n !== "loop" && e % 2 === 1 ? 0 : i.length - 1;
  return i[o];
}
const il = { type: "spring", stiffness: 500, damping: 25, restSpeed: 10 },
  rl = (t) => ({
    type: "spring",
    stiffness: 550,
    damping: t === 0 ? 2 * Math.sqrt(550) : 30,
    restSpeed: 10,
  }),
  ol = { type: "keyframes", duration: 0.8 },
  al = { type: "keyframes", ease: [0.25, 0.1, 0.35, 1], duration: 0.3 },
  ll = (t, { keyframes: e }) =>
    e.length > 2
      ? ol
      : vt.has(t)
        ? t.startsWith("scale")
          ? rl(e[1])
          : il
        : al;
function ul({
  when: t,
  delay: e,
  delayChildren: n,
  staggerChildren: s,
  staggerDirection: i,
  repeat: o,
  repeatType: r,
  repeatDelay: a,
  from: l,
  elapsed: c,
  ...u
}) {
  return !!Object.keys(u).length;
}
const fn =
  (t, e, n, s = {}, i, o) =>
  (r) => {
    const a = Qe(s, t) || {},
      l = a.delay || s.delay || 0;
    let { elapsed: c = 0 } = s;
    c = c - H(l);
    const u = {
      keyframes: Array.isArray(n) ? n : [null, n],
      ease: "easeOut",
      velocity: e.getVelocity(),
      ...a,
      delay: -c,
      onUpdate: (f) => {
        (e.set(f), a.onUpdate && a.onUpdate(f));
      },
      onComplete: () => {
        (r(), a.onComplete && a.onComplete());
      },
      name: t,
      motionValue: e,
      element: o ? void 0 : i,
    };
    (ul(a) || Object.assign(u, ll(t, u)),
      u.duration && (u.duration = H(u.duration)),
      u.repeatDelay && (u.repeatDelay = H(u.repeatDelay)),
      u.from !== void 0 && (u.keyframes[0] = u.from));
    let h = !1;
    if (
      ((u.type === !1 || (u.duration === 0 && !u.repeatDelay)) &&
        (Ae(u), u.delay === 0 && (h = !0)),
      (X.instantAnimations || X.skipAnimations) &&
        ((h = !0), Ae(u), (u.delay = 0)),
      (u.allowFlatten = !a.type && !a.ease),
      h && !o && e.get() !== void 0)
    ) {
      const f = sl(u.keyframes, a);
      if (f !== void 0) {
        V.update(() => {
          (u.onUpdate(f), u.onComplete());
        });
        return;
      }
    }
    return a.isSync ? new Ze(u) : new Fo(u);
  };
function cl({ protectedKeys: t, needsAnimating: e }, n) {
  const s = t.hasOwnProperty(n) && e[n] !== !0;
  return ((e[n] = !1), s);
}
function Ui(t, e, { delay: n = 0, transitionOverride: s, type: i } = {}) {
  let { transition: o = t.getDefaultTransition(), transitionEnd: r, ...a } = e;
  s && (o = s);
  const l = [],
    c = i && t.animationState && t.animationState.getState()[i];
  for (const u in a) {
    const h = t.getValue(u, t.latestValues[u] ?? null),
      f = a[u];
    if (f === void 0 || (c && cl(c, u))) continue;
    const d = { delay: n, ...Qe(o || {}, u) },
      m = h.get();
    if (
      m !== void 0 &&
      !h.isAnimating &&
      !Array.isArray(f) &&
      f === m &&
      !d.velocity
    )
      continue;
    let v = !1;
    if (window.MotionHandoffAnimation) {
      const p = Ni(t);
      if (p) {
        const T = window.MotionHandoffAnimation(p, u, V);
        T !== null && ((d.startTime = T), (v = !0));
      }
    }
    (Ee(t, u),
      h.start(
        fn(u, h, f, t.shouldReduceMotion && ai.has(u) ? { type: !1 } : d, t, v),
      ));
    const y = h.animation;
    y && l.push(y);
  }
  return (
    r &&
      Promise.all(l).then(() => {
        V.update(() => {
          r && tl(t, r);
        });
      }),
    l
  );
}
function Ki(t, e, n, s = 0, i = 1) {
  const o = Array.from(t)
      .sort((c, u) => c.sortNodePosition(u))
      .indexOf(e),
    r = t.size,
    a = (r - 1) * s;
  return typeof n == "function" ? n(o, r) : i === 1 ? o * s : a - o * s;
}
function Re(t, e, n = {}) {
  const s = dt(t, e, n.type === "exit" ? t.presenceContext?.custom : void 0);
  let { transition: i = t.getDefaultTransition() || {} } = s || {};
  n.transitionOverride && (i = n.transitionOverride);
  const o = s ? () => Promise.all(Ui(t, s, n)) : () => Promise.resolve(),
    r =
      t.variantChildren && t.variantChildren.size
        ? (l = 0) => {
            const {
              delayChildren: c = 0,
              staggerChildren: u,
              staggerDirection: h,
            } = i;
            return hl(t, e, l, c, u, h, n);
          }
        : () => Promise.resolve(),
    { when: a } = i;
  if (a) {
    const [l, c] = a === "beforeChildren" ? [o, r] : [r, o];
    return l().then(() => c());
  } else return Promise.all([o(), r(n.delay)]);
}
function hl(t, e, n = 0, s = 0, i = 0, o = 1, r) {
  const a = [];
  for (const l of t.variantChildren)
    (l.notify("AnimationStart", e),
      a.push(
        Re(l, e, {
          ...r,
          delay:
            n +
            (typeof s == "function" ? 0 : s) +
            Ki(t.variantChildren, l, s, i, o),
        }).then(() => l.notify("AnimationComplete", e)),
      ));
  return Promise.all(a);
}
function fl(t, e, n = {}) {
  t.notify("AnimationStart", e);
  let s;
  if (Array.isArray(e)) {
    const i = e.map((o) => Re(t, o, n));
    s = Promise.all(i);
  } else if (typeof e == "string") s = Re(t, e, n);
  else {
    const i = typeof e == "function" ? dt(t, e, n.custom) : e;
    s = Promise.all(Ui(t, i, n));
  }
  return s.then(() => {
    t.notify("AnimationComplete", e);
  });
}
function Wi(t, e) {
  if (!Array.isArray(e)) return !1;
  const n = e.length;
  if (n !== t.length) return !1;
  for (let s = 0; s < n; s++) if (e[s] !== t[s]) return !1;
  return !0;
}
const dl = rn.length;
function $i(t) {
  if (!t) return;
  if (!t.isControllingVariants) {
    const n = t.parent ? $i(t.parent) || {} : {};
    return (t.props.initial !== void 0 && (n.initial = t.props.initial), n);
  }
  const e = {};
  for (let n = 0; n < dl; n++) {
    const s = rn[n],
      i = t.props[s];
    (Dt(i) || i === !1) && (e[s] = i);
  }
  return e;
}
const ml = [...sn].reverse(),
  pl = sn.length;
function gl(t) {
  return (e) =>
    Promise.all(e.map(({ animation: n, options: s }) => fl(t, n, s)));
}
function yl(t) {
  let e = gl(t),
    n = _n(),
    s = !0;
  const i = (l) => (c, u) => {
    const h = dt(t, u, l === "exit" ? t.presenceContext?.custom : void 0);
    if (h) {
      const { transition: f, transitionEnd: d, ...m } = h;
      c = { ...c, ...m, ...d };
    }
    return c;
  };
  function o(l) {
    e = l(t);
  }
  function r(l) {
    const { props: c } = t,
      u = $i(t.parent) || {},
      h = [],
      f = new Set();
    let d = {},
      m = 1 / 0;
    for (let y = 0; y < pl; y++) {
      const p = ml[y],
        T = n[p],
        g = c[p] !== void 0 ? c[p] : u[p],
        A = Dt(g),
        P = p === l ? T.isActive : null;
      P === !1 && (m = y);
      let w = g === u[p] && g !== c[p] && A;
      if (
        (w && s && t.manuallyAnimateOnMount && (w = !1),
        (T.protectedKeys = { ...d }),
        (!T.isActive && P === null) ||
          (!g && !T.prevProp) ||
          Yt(g) ||
          typeof g == "boolean")
      )
        continue;
      const R = vl(T.prevProp, g);
      let b = R || (p === l && T.isActive && !w && A) || (y > m && A),
        I = !1;
      const j = Array.isArray(g) ? g : [g];
      let ot = j.reduce(i(p), {});
      P === !1 && (ot = {});
      const { prevResolvedValues: dn = {} } = T,
        ir = { ...dn, ...ot },
        mn = (L) => {
          ((b = !0),
            f.has(L) && ((I = !0), f.delete(L)),
            (T.needsAnimating[L] = !0));
          const N = t.getValue(L);
          N && (N.liveStyle = !1);
        };
      for (const L in ir) {
        const N = ot[L],
          Q = dn[L];
        if (d.hasOwnProperty(L)) continue;
        let at = !1;
        (De(N) && De(Q) ? (at = !Wi(N, Q)) : (at = N !== Q),
          at
            ? N != null
              ? mn(L)
              : f.add(L)
            : N !== void 0 && f.has(L)
              ? mn(L)
              : (T.protectedKeys[L] = !0));
      }
      ((T.prevProp = g),
        (T.prevResolvedValues = ot),
        T.isActive && (d = { ...d, ...ot }),
        s && t.blockInitialAnimation && (b = !1));
      const pn = w && R;
      b &&
        (!pn || I) &&
        h.push(
          ...j.map((L) => {
            const N = { type: p };
            if (
              typeof L == "string" &&
              s &&
              !pn &&
              t.manuallyAnimateOnMount &&
              t.parent
            ) {
              const { parent: Q } = t,
                at = dt(Q, L);
              if (Q.enteringChildren && at) {
                const { delayChildren: rr } = at.transition || {};
                N.delay = Ki(Q.enteringChildren, t, rr);
              }
            }
            return { animation: L, options: N };
          }),
        );
    }
    if (f.size) {
      const y = {};
      if (typeof c.initial != "boolean") {
        const p = dt(t, Array.isArray(c.initial) ? c.initial[0] : c.initial);
        p && p.transition && (y.transition = p.transition);
      }
      (f.forEach((p) => {
        const T = t.getBaseTarget(p),
          g = t.getValue(p);
        (g && (g.liveStyle = !0), (y[p] = T ?? null));
      }),
        h.push({ animation: y }));
    }
    let v = !!h.length;
    return (
      s &&
        (c.initial === !1 || c.initial === c.animate) &&
        !t.manuallyAnimateOnMount &&
        (v = !1),
      (s = !1),
      v ? e(h) : Promise.resolve()
    );
  }
  function a(l, c) {
    if (n[l].isActive === c) return Promise.resolve();
    (t.variantChildren?.forEach((h) => h.animationState?.setActive(l, c)),
      (n[l].isActive = c));
    const u = r(l);
    for (const h in n) n[h].protectedKeys = {};
    return u;
  }
  return {
    animateChanges: r,
    setActive: a,
    setAnimateFunction: o,
    getState: () => n,
    reset: () => {
      n = _n();
    },
  };
}
function vl(t, e) {
  return typeof e == "string" ? e !== t : Array.isArray(e) ? !Wi(e, t) : !1;
}
function tt(t = !1) {
  return {
    isActive: t,
    protectedKeys: {},
    needsAnimating: {},
    prevResolvedValues: {},
  };
}
function _n() {
  return {
    animate: tt(!0),
    whileInView: tt(),
    whileHover: tt(),
    whileTap: tt(),
    whileDrag: tt(),
    whileFocus: tt(),
    exit: tt(),
  };
}
class J {
  constructor(e) {
    ((this.isMounted = !1), (this.node = e));
  }
  update() {}
}
class Tl extends J {
  constructor(e) {
    (super(e), e.animationState || (e.animationState = yl(e)));
  }
  updateAnimationControlsSubscription() {
    const { animate: e } = this.node.getProps();
    Yt(e) && (this.unmountControls = e.subscribe(this.node));
  }
  mount() {
    this.updateAnimationControlsSubscription();
  }
  update() {
    const { animate: e } = this.node.getProps(),
      { animate: n } = this.node.prevProps || {};
    e !== n && this.updateAnimationControlsSubscription();
  }
  unmount() {
    (this.node.animationState.reset(), this.unmountControls?.());
  }
}
let xl = 0;
class Pl extends J {
  constructor() {
    (super(...arguments), (this.id = xl++));
  }
  update() {
    if (!this.node.presenceContext) return;
    const { isPresent: e, onExitComplete: n } = this.node.presenceContext,
      { isPresent: s } = this.node.prevPresenceContext || {};
    if (!this.node.animationState || e === s) return;
    const i = this.node.animationState.setActive("exit", !e);
    n &&
      !e &&
      i.then(() => {
        n(this.id);
      });
  }
  mount() {
    const { register: e, onExitComplete: n } = this.node.presenceContext || {};
    (n && n(this.id), e && (this.unmount = e(this.id)));
  }
  unmount() {}
}
const Sl = { animation: { Feature: Tl }, exit: { Feature: Pl } };
function Rt(t, e, n, s = { passive: !0 }) {
  return (t.addEventListener(e, n, s), () => t.removeEventListener(e, n));
}
function Bt(t) {
  return { point: { x: t.pageX, y: t.pageY } };
}
const bl = (t) => (e) => nn(e) && t(e, Bt(e));
function bt(t, e, n, s) {
  return Rt(t, e, bl(n), s);
}
const Gi = 1e-4,
  Al = 1 - Gi,
  wl = 1 + Gi,
  Hi = 0.01,
  Vl = 0 - Hi,
  Cl = 0 + Hi;
function B(t) {
  return t.max - t.min;
}
function Ml(t, e, n) {
  return Math.abs(t - e) <= n;
}
function zn(t, e, n, s = 0.5) {
  ((t.origin = s),
    (t.originPoint = C(e.min, e.max, t.origin)),
    (t.scale = B(n) / B(e)),
    (t.translate = C(n.min, n.max, t.origin) - t.originPoint),
    ((t.scale >= Al && t.scale <= wl) || isNaN(t.scale)) && (t.scale = 1),
    ((t.translate >= Vl && t.translate <= Cl) || isNaN(t.translate)) &&
      (t.translate = 0));
}
function At(t, e, n, s) {
  (zn(t.x, e.x, n.x, s ? s.originX : void 0),
    zn(t.y, e.y, n.y, s ? s.originY : void 0));
}
function Xn(t, e, n) {
  ((t.min = n.min + e.min), (t.max = t.min + B(e)));
}
function Dl(t, e, n) {
  (Xn(t.x, e.x, n.x), Xn(t.y, e.y, n.y));
}
function Yn(t, e, n) {
  ((t.min = e.min - n.min), (t.max = t.min + B(e)));
}
function wt(t, e, n) {
  (Yn(t.x, e.x, n.x), Yn(t.y, e.y, n.y));
}
function K(t) {
  return [t("x"), t("y")];
}
const _i = ({ current: t }) => (t ? t.ownerDocument.defaultView : null),
  qn = (t, e) => Math.abs(t - e);
function El(t, e) {
  const n = qn(t.x, e.x),
    s = qn(t.y, e.y);
  return Math.sqrt(n ** 2 + s ** 2);
}
class zi {
  constructor(
    e,
    n,
    {
      transformPagePoint: s,
      contextWindow: i = window,
      dragSnapToOrigin: o = !1,
      distanceThreshold: r = 3,
    } = {},
  ) {
    if (
      ((this.startEvent = null),
      (this.lastMoveEvent = null),
      (this.lastMoveEventInfo = null),
      (this.handlers = {}),
      (this.contextWindow = window),
      (this.updatePoint = () => {
        if (!(this.lastMoveEvent && this.lastMoveEventInfo)) return;
        const f = oe(this.lastMoveEventInfo, this.history),
          d = this.startEvent !== null,
          m = El(f.offset, { x: 0, y: 0 }) >= this.distanceThreshold;
        if (!d && !m) return;
        const { point: v } = f,
          { timestamp: y } = k;
        this.history.push({ ...v, timestamp: y });
        const { onStart: p, onMove: T } = this.handlers;
        (d ||
          (p && p(this.lastMoveEvent, f),
          (this.startEvent = this.lastMoveEvent)),
          T && T(this.lastMoveEvent, f));
      }),
      (this.handlePointerMove = (f, d) => {
        ((this.lastMoveEvent = f),
          (this.lastMoveEventInfo = re(d, this.transformPagePoint)),
          V.update(this.updatePoint, !0));
      }),
      (this.handlePointerUp = (f, d) => {
        this.end();
        const { onEnd: m, onSessionEnd: v, resumeAnimation: y } = this.handlers;
        if (
          (this.dragSnapToOrigin && y && y(),
          !(this.lastMoveEvent && this.lastMoveEventInfo))
        )
          return;
        const p = oe(
          f.type === "pointercancel"
            ? this.lastMoveEventInfo
            : re(d, this.transformPagePoint),
          this.history,
        );
        (this.startEvent && m && m(f, p), v && v(f, p));
      }),
      !nn(e))
    )
      return;
    ((this.dragSnapToOrigin = o),
      (this.handlers = n),
      (this.transformPagePoint = s),
      (this.distanceThreshold = r),
      (this.contextWindow = i || window));
    const a = Bt(e),
      l = re(a, this.transformPagePoint),
      { point: c } = l,
      { timestamp: u } = k;
    this.history = [{ ...c, timestamp: u }];
    const { onSessionStart: h } = n;
    (h && h(e, oe(l, this.history)),
      (this.removeListeners = Lt(
        bt(this.contextWindow, "pointermove", this.handlePointerMove),
        bt(this.contextWindow, "pointerup", this.handlePointerUp),
        bt(this.contextWindow, "pointercancel", this.handlePointerUp),
      )));
  }
  updateHandlers(e) {
    this.handlers = e;
  }
  end() {
    (this.removeListeners && this.removeListeners(), q(this.updatePoint));
  }
}
function re(t, e) {
  return e ? { point: e(t.point) } : t;
}
function Zn(t, e) {
  return { x: t.x - e.x, y: t.y - e.y };
}
function oe({ point: t }, e) {
  return {
    point: t,
    delta: Zn(t, Xi(e)),
    offset: Zn(t, Rl(e)),
    velocity: Ll(e, 0.1),
  };
}
function Rl(t) {
  return t[0];
}
function Xi(t) {
  return t[t.length - 1];
}
function Ll(t, e) {
  if (t.length < 2) return { x: 0, y: 0 };
  let n = t.length - 1,
    s = null;
  const i = Xi(t);
  for (; n >= 0 && ((s = t[n]), !(i.timestamp - s.timestamp > H(e)));) n--;
  if (!s) return { x: 0, y: 0 };
  const o = W(i.timestamp - s.timestamp);
  if (o === 0) return { x: 0, y: 0 };
  const r = { x: (i.x - s.x) / o, y: (i.y - s.y) / o };
  return (r.x === 1 / 0 && (r.x = 0), r.y === 1 / 0 && (r.y = 0), r);
}
function kl(t, { min: e, max: n }, s) {
  return (
    e !== void 0 && t < e
      ? (t = s ? C(e, t, s.min) : Math.max(t, e))
      : n !== void 0 && t > n && (t = s ? C(n, t, s.max) : Math.min(t, n)),
    t
  );
}
function Jn(t, e, n) {
  return {
    min: e !== void 0 ? t.min + e : void 0,
    max: n !== void 0 ? t.max + n - (t.max - t.min) : void 0,
  };
}
function Fl(t, { top: e, left: n, bottom: s, right: i }) {
  return { x: Jn(t.x, n, i), y: Jn(t.y, e, s) };
}
function Qn(t, e) {
  let n = e.min - t.min,
    s = e.max - t.max;
  return (
    e.max - e.min < t.max - t.min && ([n, s] = [s, n]),
    { min: n, max: s }
  );
}
function Bl(t, e) {
  return { x: Qn(t.x, e.x), y: Qn(t.y, e.y) };
}
function Il(t, e) {
  let n = 0.5;
  const s = B(t),
    i = B(e);
  return (
    i > s
      ? (n = Vt(e.min, e.max - s, t.min))
      : s > i && (n = Vt(t.min, t.max - i, e.min)),
    z(0, 1, n)
  );
}
function Ol(t, e) {
  const n = {};
  return (
    e.min !== void 0 && (n.min = e.min - t.min),
    e.max !== void 0 && (n.max = e.max - t.min),
    n
  );
}
const Le = 0.35;
function jl(t = Le) {
  return (
    t === !1 ? (t = 0) : t === !0 && (t = Le),
    { x: ts(t, "left", "right"), y: ts(t, "top", "bottom") }
  );
}
function ts(t, e, n) {
  return { min: es(t, e), max: es(t, n) };
}
function es(t, e) {
  return typeof t == "number" ? t : t[e] || 0;
}
const Nl = new WeakMap();
class Ul {
  constructor(e) {
    ((this.openDragLock = null),
      (this.isDragging = !1),
      (this.currentDirection = null),
      (this.originPoint = { x: 0, y: 0 }),
      (this.constraints = !1),
      (this.hasMutatedConstraints = !1),
      (this.elastic = D()),
      (this.latestPointerEvent = null),
      (this.latestPanInfo = null),
      (this.visualElement = e));
  }
  start(e, { snapToCursor: n = !1, distanceThreshold: s } = {}) {
    const { presenceContext: i } = this.visualElement;
    if (i && i.isPresent === !1) return;
    const o = (h) => {
        const { dragSnapToOrigin: f } = this.getProps();
        (f ? this.pauseAnimation() : this.stopAnimation(),
          n && this.snapToCursor(Bt(h).point));
      },
      r = (h, f) => {
        const { drag: d, dragPropagation: m, onDragStart: v } = this.getProps();
        if (
          d &&
          !m &&
          (this.openDragLock && this.openDragLock(),
          (this.openDragLock = Zo(d)),
          !this.openDragLock)
        )
          return;
        ((this.latestPointerEvent = h),
          (this.latestPanInfo = f),
          (this.isDragging = !0),
          (this.currentDirection = null),
          this.resolveConstraints(),
          this.visualElement.projection &&
            ((this.visualElement.projection.isAnimationBlocked = !0),
            (this.visualElement.projection.target = void 0)),
          K((p) => {
            let T = this.getAxisMotionValue(p).get() || 0;
            if (_.test(T)) {
              const { projection: g } = this.visualElement;
              if (g && g.layout) {
                const A = g.layout.layoutBox[p];
                A && (T = B(A) * (parseFloat(T) / 100));
              }
            }
            this.originPoint[p] = T;
          }),
          v && V.postRender(() => v(h, f)),
          Ee(this.visualElement, "transform"));
        const { animationState: y } = this.visualElement;
        y && y.setActive("whileDrag", !0);
      },
      a = (h, f) => {
        ((this.latestPointerEvent = h), (this.latestPanInfo = f));
        const {
          dragPropagation: d,
          dragDirectionLock: m,
          onDirectionLock: v,
          onDrag: y,
        } = this.getProps();
        if (!d && !this.openDragLock) return;
        const { offset: p } = f;
        if (m && this.currentDirection === null) {
          ((this.currentDirection = Kl(p)),
            this.currentDirection !== null && v && v(this.currentDirection));
          return;
        }
        (this.updateAxis("x", f.point, p),
          this.updateAxis("y", f.point, p),
          this.visualElement.render(),
          y && y(h, f));
      },
      l = (h, f) => {
        ((this.latestPointerEvent = h),
          (this.latestPanInfo = f),
          this.stop(h, f),
          (this.latestPointerEvent = null),
          (this.latestPanInfo = null));
      },
      c = () =>
        K(
          (h) =>
            this.getAnimationState(h) === "paused" &&
            this.getAxisMotionValue(h).animation?.play(),
        ),
      { dragSnapToOrigin: u } = this.getProps();
    this.panSession = new zi(
      e,
      {
        onSessionStart: o,
        onStart: r,
        onMove: a,
        onSessionEnd: l,
        resumeAnimation: c,
      },
      {
        transformPagePoint: this.visualElement.getTransformPagePoint(),
        dragSnapToOrigin: u,
        distanceThreshold: s,
        contextWindow: _i(this.visualElement),
      },
    );
  }
  stop(e, n) {
    const s = e || this.latestPointerEvent,
      i = n || this.latestPanInfo,
      o = this.isDragging;
    if ((this.cancel(), !o || !i || !s)) return;
    const { velocity: r } = i;
    this.startAnimation(r);
    const { onDragEnd: a } = this.getProps();
    a && V.postRender(() => a(s, i));
  }
  cancel() {
    this.isDragging = !1;
    const { projection: e, animationState: n } = this.visualElement;
    (e && (e.isAnimationBlocked = !1),
      this.panSession && this.panSession.end(),
      (this.panSession = void 0));
    const { dragPropagation: s } = this.getProps();
    (!s &&
      this.openDragLock &&
      (this.openDragLock(), (this.openDragLock = null)),
      n && n.setActive("whileDrag", !1));
  }
  updateAxis(e, n, s) {
    const { drag: i } = this.getProps();
    if (!s || !jt(e, i, this.currentDirection)) return;
    const o = this.getAxisMotionValue(e);
    let r = this.originPoint[e] + s[e];
    (this.constraints &&
      this.constraints[e] &&
      (r = kl(r, this.constraints[e], this.elastic[e])),
      o.set(r));
  }
  resolveConstraints() {
    const { dragConstraints: e, dragElastic: n } = this.getProps(),
      s =
        this.visualElement.projection && !this.visualElement.projection.layout
          ? this.visualElement.projection.measure(!1)
          : this.visualElement.projection?.layout,
      i = this.constraints;
    (e && ut(e)
      ? this.constraints || (this.constraints = this.resolveRefConstraints())
      : e && s
        ? (this.constraints = Fl(s.layoutBox, e))
        : (this.constraints = !1),
      (this.elastic = jl(n)),
      i !== this.constraints &&
        s &&
        this.constraints &&
        !this.hasMutatedConstraints &&
        K((o) => {
          this.constraints !== !1 &&
            this.getAxisMotionValue(o) &&
            (this.constraints[o] = Ol(s.layoutBox[o], this.constraints[o]));
        }));
  }
  resolveRefConstraints() {
    const { dragConstraints: e, onMeasureDragConstraints: n } = this.getProps();
    if (!e || !ut(e)) return !1;
    const s = e.current,
      { projection: i } = this.visualElement;
    if (!i || !i.layout) return !1;
    const o = Wa(s, i.root, this.visualElement.getTransformPagePoint());
    let r = Bl(i.layout.layoutBox, o);
    if (n) {
      const a = n(Na(r));
      ((this.hasMutatedConstraints = !!a), a && (r = Ri(a)));
    }
    return r;
  }
  startAnimation(e) {
    const {
        drag: n,
        dragMomentum: s,
        dragElastic: i,
        dragTransition: o,
        dragSnapToOrigin: r,
        onDragTransitionEnd: a,
      } = this.getProps(),
      l = this.constraints || {},
      c = K((u) => {
        if (!jt(u, n, this.currentDirection)) return;
        let h = (l && l[u]) || {};
        r && (h = { min: 0, max: 0 });
        const f = i ? 200 : 1e6,
          d = i ? 40 : 1e7,
          m = {
            type: "inertia",
            velocity: s ? e[u] : 0,
            bounceStiffness: f,
            bounceDamping: d,
            timeConstant: 750,
            restDelta: 1,
            restSpeed: 10,
            ...o,
            ...h,
          };
        return this.startAxisValueAnimation(u, m);
      });
    return Promise.all(c).then(a);
  }
  startAxisValueAnimation(e, n) {
    const s = this.getAxisMotionValue(e);
    return (
      Ee(this.visualElement, e),
      s.start(fn(e, s, 0, n, this.visualElement, !1))
    );
  }
  stopAnimation() {
    K((e) => this.getAxisMotionValue(e).stop());
  }
  pauseAnimation() {
    K((e) => this.getAxisMotionValue(e).animation?.pause());
  }
  getAnimationState(e) {
    return this.getAxisMotionValue(e).animation?.state;
  }
  getAxisMotionValue(e) {
    const n = `_drag${e.toUpperCase()}`,
      s = this.visualElement.getProps(),
      i = s[n];
    return (
      i ||
      this.visualElement.getValue(e, (s.initial ? s.initial[e] : void 0) || 0)
    );
  }
  snapToCursor(e) {
    K((n) => {
      const { drag: s } = this.getProps();
      if (!jt(n, s, this.currentDirection)) return;
      const { projection: i } = this.visualElement,
        o = this.getAxisMotionValue(n);
      if (i && i.layout) {
        const { min: r, max: a } = i.layout.layoutBox[n];
        o.set(e[n] - C(r, a, 0.5));
      }
    });
  }
  scalePositionWithinConstraints() {
    if (!this.visualElement.current) return;
    const { drag: e, dragConstraints: n } = this.getProps(),
      { projection: s } = this.visualElement;
    if (!ut(n) || !s || !this.constraints) return;
    this.stopAnimation();
    const i = { x: 0, y: 0 };
    K((r) => {
      const a = this.getAxisMotionValue(r);
      if (a && this.constraints !== !1) {
        const l = a.get();
        i[r] = Il({ min: l, max: l }, this.constraints[r]);
      }
    });
    const { transformTemplate: o } = this.visualElement.getProps();
    ((this.visualElement.current.style.transform = o ? o({}, "") : "none"),
      s.root && s.root.updateScroll(),
      s.updateLayout(),
      this.resolveConstraints(),
      K((r) => {
        if (!jt(r, e, null)) return;
        const a = this.getAxisMotionValue(r),
          { min: l, max: c } = this.constraints[r];
        a.set(C(l, c, i[r]));
      }));
  }
  addListeners() {
    if (!this.visualElement.current) return;
    Nl.set(this.visualElement, this);
    const e = this.visualElement.current,
      n = bt(e, "pointerdown", (l) => {
        const { drag: c, dragListener: u = !0 } = this.getProps();
        c && u && this.start(l);
      }),
      s = () => {
        const { dragConstraints: l } = this.getProps();
        ut(l) && l.current && (this.constraints = this.resolveRefConstraints());
      },
      { projection: i } = this.visualElement,
      o = i.addEventListener("measure", s);
    (i && !i.layout && (i.root && i.root.updateScroll(), i.updateLayout()),
      V.read(s));
    const r = Rt(window, "resize", () => this.scalePositionWithinConstraints()),
      a = i.addEventListener(
        "didUpdate",
        ({ delta: l, hasLayoutChanged: c }) => {
          this.isDragging &&
            c &&
            (K((u) => {
              const h = this.getAxisMotionValue(u);
              h &&
                ((this.originPoint[u] += l[u].translate),
                h.set(h.get() + l[u].translate));
            }),
            this.visualElement.render());
        },
      );
    return () => {
      (r(), n(), o(), a && a());
    };
  }
  getProps() {
    const e = this.visualElement.getProps(),
      {
        drag: n = !1,
        dragDirectionLock: s = !1,
        dragPropagation: i = !1,
        dragConstraints: o = !1,
        dragElastic: r = Le,
        dragMomentum: a = !0,
      } = e;
    return {
      ...e,
      drag: n,
      dragDirectionLock: s,
      dragPropagation: i,
      dragConstraints: o,
      dragElastic: r,
      dragMomentum: a,
    };
  }
}
function jt(t, e, n) {
  return (e === !0 || e === t) && (n === null || n === t);
}
function Kl(t, e = 10) {
  let n = null;
  return (Math.abs(t.y) > e ? (n = "y") : Math.abs(t.x) > e && (n = "x"), n);
}
class Wl extends J {
  constructor(e) {
    (super(e),
      (this.removeGroupControls = $),
      (this.removeListeners = $),
      (this.controls = new Ul(e)));
  }
  mount() {
    const { dragControls: e } = this.node.getProps();
    (e && (this.removeGroupControls = e.subscribe(this.controls)),
      (this.removeListeners = this.controls.addListeners() || $));
  }
  unmount() {
    (this.removeGroupControls(), this.removeListeners());
  }
}
const ns = (t) => (e, n) => {
  t && V.postRender(() => t(e, n));
};
class $l extends J {
  constructor() {
    (super(...arguments), (this.removePointerDownListener = $));
  }
  onPointerDown(e) {
    this.session = new zi(e, this.createPanHandlers(), {
      transformPagePoint: this.node.getTransformPagePoint(),
      contextWindow: _i(this.node),
    });
  }
  createPanHandlers() {
    const {
      onPanSessionStart: e,
      onPanStart: n,
      onPan: s,
      onPanEnd: i,
    } = this.node.getProps();
    return {
      onSessionStart: ns(e),
      onStart: ns(n),
      onMove: s,
      onEnd: (o, r) => {
        (delete this.session, i && V.postRender(() => i(o, r)));
      },
    };
  }
  mount() {
    this.removePointerDownListener = bt(this.node.current, "pointerdown", (e) =>
      this.onPointerDown(e),
    );
  }
  update() {
    this.session && this.session.updateHandlers(this.createPanHandlers());
  }
  unmount() {
    (this.removePointerDownListener(), this.session && this.session.end());
  }
}
const Wt = { hasAnimatedSinceResize: !0, hasEverUpdated: !1 };
function ss(t, e) {
  return e.max === e.min ? 0 : (t / (e.max - e.min)) * 100;
}
const Tt = {
    correct: (t, e) => {
      if (!e.target) return t;
      if (typeof t == "string")
        if (x.test(t)) t = parseFloat(t);
        else return t;
      const n = ss(t, e.target.x),
        s = ss(t, e.target.y);
      return `${n}% ${s}%`;
    },
  },
  Gl = {
    correct: (t, { treeScale: e, projectionDelta: n }) => {
      const s = t,
        i = Z.parse(t);
      if (i.length > 5) return s;
      const o = Z.createTransformer(t),
        r = typeof i[0] != "number" ? 1 : 0,
        a = n.x.scale * e.x,
        l = n.y.scale * e.y;
      ((i[0 + r] /= a), (i[1 + r] /= l));
      const c = C(a, l, 0.5);
      return (
        typeof i[2 + r] == "number" && (i[2 + r] /= c),
        typeof i[3 + r] == "number" && (i[3 + r] /= c),
        o(i)
      );
    },
  };
let ae = !1;
class Hl extends S.Component {
  componentDidMount() {
    const {
        visualElement: e,
        layoutGroup: n,
        switchLayoutGroup: s,
        layoutId: i,
      } = this.props,
      { projection: o } = e;
    (da(_l),
      o &&
        (n.group && n.group.add(o),
        s && s.register && i && s.register(o),
        ae && o.root.didUpdate(),
        o.addEventListener("animationComplete", () => {
          this.safeToRemove();
        }),
        o.setOptions({
          ...o.options,
          onExitComplete: () => this.safeToRemove(),
        })),
      (Wt.hasEverUpdated = !0));
  }
  getSnapshotBeforeUpdate(e) {
    const {
        layoutDependency: n,
        visualElement: s,
        drag: i,
        isPresent: o,
      } = this.props,
      { projection: r } = s;
    return (
      r &&
        ((r.isPresent = o),
        (ae = !0),
        i || e.layoutDependency !== n || n === void 0 || e.isPresent !== o
          ? r.willUpdate()
          : this.safeToRemove(),
        e.isPresent !== o &&
          (o
            ? r.promote()
            : r.relegate() ||
              V.postRender(() => {
                const a = r.getStack();
                (!a || !a.members.length) && this.safeToRemove();
              }))),
      null
    );
  }
  componentDidUpdate() {
    const { projection: e } = this.props.visualElement;
    e &&
      (e.root.didUpdate(),
      en.postRender(() => {
        !e.currentAnimation && e.isLead() && this.safeToRemove();
      }));
  }
  componentWillUnmount() {
    const {
        visualElement: e,
        layoutGroup: n,
        switchLayoutGroup: s,
      } = this.props,
      { projection: i } = e;
    ((ae = !0),
      i &&
        (i.scheduleCheckAfterUnmount(),
        n && n.group && n.group.remove(i),
        s && s.deregister && s.deregister(i)));
  }
  safeToRemove() {
    const { safeToRemove: e } = this.props;
    e && e();
  }
  render() {
    return null;
  }
}
function Yi(t) {
  const [e, n] = oa(),
    s = S.useContext(Cs);
  return fe.jsx(Hl, {
    ...t,
    layoutGroup: s,
    switchLayoutGroup: S.useContext(Di),
    isPresent: e,
    safeToRemove: n,
  });
}
const _l = {
  borderRadius: {
    ...Tt,
    applyTo: [
      "borderTopLeftRadius",
      "borderTopRightRadius",
      "borderBottomLeftRadius",
      "borderBottomRightRadius",
    ],
  },
  borderTopLeftRadius: Tt,
  borderTopRightRadius: Tt,
  borderBottomLeftRadius: Tt,
  borderBottomRightRadius: Tt,
  boxShadow: Gl,
};
function zl(t, e, n) {
  const s = F(t) ? t : mt(t);
  return (s.start(fn("", s, e, n)), s.animation);
}
const Xl = (t, e) => t.depth - e.depth;
class Yl {
  constructor() {
    ((this.children = []), (this.isDirty = !1));
  }
  add(e) {
    (Ie(this.children, e), (this.isDirty = !0));
  }
  remove(e) {
    (Oe(this.children, e), (this.isDirty = !0));
  }
  forEach(e) {
    (this.isDirty && this.children.sort(Xl),
      (this.isDirty = !1),
      this.children.forEach(e));
  }
}
function ql(t, e) {
  const n = O.now(),
    s = ({ timestamp: i }) => {
      const o = i - n;
      o >= e && (q(s), t(o - e));
    };
  return (V.setup(s, !0), () => q(s));
}
const qi = ["TopLeft", "TopRight", "BottomLeft", "BottomRight"],
  Zl = qi.length,
  is = (t) => (typeof t == "string" ? parseFloat(t) : t),
  rs = (t) => typeof t == "number" || x.test(t);
function Jl(t, e, n, s, i, o) {
  i
    ? ((t.opacity = C(0, n.opacity ?? 1, Ql(s))),
      (t.opacityExit = C(e.opacity ?? 1, 0, tu(s))))
    : o && (t.opacity = C(e.opacity ?? 1, n.opacity ?? 1, s));
  for (let r = 0; r < Zl; r++) {
    const a = `border${qi[r]}Radius`;
    let l = os(e, a),
      c = os(n, a);
    if (l === void 0 && c === void 0) continue;
    (l || (l = 0),
      c || (c = 0),
      l === 0 || c === 0 || rs(l) === rs(c)
        ? ((t[a] = Math.max(C(is(l), is(c), s), 0)),
          (_.test(c) || _.test(l)) && (t[a] += "%"))
        : (t[a] = c));
  }
  (e.rotate || n.rotate) && (t.rotate = C(e.rotate || 0, n.rotate || 0, s));
}
function os(t, e) {
  return t[e] !== void 0 ? t[e] : t.borderRadius;
}
const Ql = Zi(0, 0.5, js),
  tu = Zi(0.5, 0.95, $);
function Zi(t, e, n) {
  return (s) => (s < t ? 0 : s > e ? 1 : n(Vt(t, e, s)));
}
function as(t, e) {
  ((t.min = e.min), (t.max = e.max));
}
function U(t, e) {
  (as(t.x, e.x), as(t.y, e.y));
}
function ls(t, e) {
  ((t.translate = e.translate),
    (t.scale = e.scale),
    (t.originPoint = e.originPoint),
    (t.origin = e.origin));
}
function us(t, e, n, s, i) {
  return (
    (t -= e),
    (t = zt(t, 1 / n, s)),
    i !== void 0 && (t = zt(t, 1 / i, s)),
    t
  );
}
function eu(t, e = 0, n = 1, s = 0.5, i, o = t, r = t) {
  if (
    (_.test(e) && ((e = parseFloat(e)), (e = C(r.min, r.max, e / 100) - r.min)),
    typeof e != "number")
  )
    return;
  let a = C(o.min, o.max, s);
  (t === o && (a -= e),
    (t.min = us(t.min, e, n, a, i)),
    (t.max = us(t.max, e, n, a, i)));
}
function cs(t, e, [n, s, i], o, r) {
  eu(t, e[n], e[s], e[i], e.scale, o, r);
}
const nu = ["x", "scaleX", "originX"],
  su = ["y", "scaleY", "originY"];
function hs(t, e, n, s) {
  (cs(t.x, e, nu, n ? n.x : void 0, s ? s.x : void 0),
    cs(t.y, e, su, n ? n.y : void 0, s ? s.y : void 0));
}
function fs(t) {
  return t.translate === 0 && t.scale === 1;
}
function Ji(t) {
  return fs(t.x) && fs(t.y);
}
function ds(t, e) {
  return t.min === e.min && t.max === e.max;
}
function iu(t, e) {
  return ds(t.x, e.x) && ds(t.y, e.y);
}
function ms(t, e) {
  return (
    Math.round(t.min) === Math.round(e.min) &&
    Math.round(t.max) === Math.round(e.max)
  );
}
function Qi(t, e) {
  return ms(t.x, e.x) && ms(t.y, e.y);
}
function ps(t) {
  return B(t.x) / B(t.y);
}
function gs(t, e) {
  return (
    t.translate === e.translate &&
    t.scale === e.scale &&
    t.originPoint === e.originPoint
  );
}
class ru {
  constructor() {
    this.members = [];
  }
  add(e) {
    (Ie(this.members, e), e.scheduleRender());
  }
  remove(e) {
    if (
      (Oe(this.members, e),
      e === this.prevLead && (this.prevLead = void 0),
      e === this.lead)
    ) {
      const n = this.members[this.members.length - 1];
      n && this.promote(n);
    }
  }
  relegate(e) {
    const n = this.members.findIndex((i) => e === i);
    if (n === 0) return !1;
    let s;
    for (let i = n; i >= 0; i--) {
      const o = this.members[i];
      if (o.isPresent !== !1) {
        s = o;
        break;
      }
    }
    return s ? (this.promote(s), !0) : !1;
  }
  promote(e, n) {
    const s = this.lead;
    if (e !== s && ((this.prevLead = s), (this.lead = e), e.show(), s)) {
      (s.instance && s.scheduleRender(),
        e.scheduleRender(),
        (e.resumeFrom = s),
        n && (e.resumeFrom.preserveOpacity = !0),
        s.snapshot &&
          ((e.snapshot = s.snapshot),
          (e.snapshot.latestValues = s.animationValues || s.latestValues)),
        e.root && e.root.isUpdating && (e.isLayoutDirty = !0));
      const { crossfade: i } = e.options;
      i === !1 && s.hide();
    }
  }
  exitAnimationComplete() {
    this.members.forEach((e) => {
      const { options: n, resumingFrom: s } = e;
      (n.onExitComplete && n.onExitComplete(),
        s && s.options.onExitComplete && s.options.onExitComplete());
    });
  }
  scheduleRender() {
    this.members.forEach((e) => {
      e.instance && e.scheduleRender(!1);
    });
  }
  removeLeadSnapshot() {
    this.lead && this.lead.snapshot && (this.lead.snapshot = void 0);
  }
}
function ou(t, e, n) {
  let s = "";
  const i = t.x.translate / e.x,
    o = t.y.translate / e.y,
    r = n?.z || 0;
  if (
    ((i || o || r) && (s = `translate3d(${i}px, ${o}px, ${r}px) `),
    (e.x !== 1 || e.y !== 1) && (s += `scale(${1 / e.x}, ${1 / e.y}) `),
    n)
  ) {
    const {
      transformPerspective: c,
      rotate: u,
      rotateX: h,
      rotateY: f,
      skewX: d,
      skewY: m,
    } = n;
    (c && (s = `perspective(${c}px) ${s}`),
      u && (s += `rotate(${u}deg) `),
      h && (s += `rotateX(${h}deg) `),
      f && (s += `rotateY(${f}deg) `),
      d && (s += `skewX(${d}deg) `),
      m && (s += `skewY(${m}deg) `));
  }
  const a = t.x.scale * e.x,
    l = t.y.scale * e.y;
  return ((a !== 1 || l !== 1) && (s += `scale(${a}, ${l})`), s || "none");
}
const le = ["", "X", "Y", "Z"],
  au = 1e3;
let lu = 0;
function ue(t, e, n, s) {
  const { latestValues: i } = e;
  i[t] && ((n[t] = i[t]), e.setStaticValue(t, 0), s && (s[t] = 0));
}
function tr(t) {
  if (((t.hasCheckedOptimisedAppear = !0), t.root === t)) return;
  const { visualElement: e } = t.options;
  if (!e) return;
  const n = Ni(e);
  if (window.MotionHasOptimisedAnimation(n, "transform")) {
    const { layout: i, layoutId: o } = t.options;
    window.MotionCancelOptimisedAnimation(n, "transform", V, !(i || o));
  }
  const { parent: s } = t;
  s && !s.hasCheckedOptimisedAppear && tr(s);
}
function er({
  attachResizeListener: t,
  defaultParent: e,
  measureScroll: n,
  checkIsScrollRoot: s,
  resetTransform: i,
}) {
  return class {
    constructor(r = {}, a = e?.()) {
      ((this.id = lu++),
        (this.animationId = 0),
        (this.animationCommitId = 0),
        (this.children = new Set()),
        (this.options = {}),
        (this.isTreeAnimating = !1),
        (this.isAnimationBlocked = !1),
        (this.isLayoutDirty = !1),
        (this.isProjectionDirty = !1),
        (this.isSharedProjectionDirty = !1),
        (this.isTransformDirty = !1),
        (this.updateManuallyBlocked = !1),
        (this.updateBlockedByResize = !1),
        (this.isUpdating = !1),
        (this.isSVG = !1),
        (this.needsReset = !1),
        (this.shouldResetTransform = !1),
        (this.hasCheckedOptimisedAppear = !1),
        (this.treeScale = { x: 1, y: 1 }),
        (this.eventHandlers = new Map()),
        (this.hasTreeAnimated = !1),
        (this.updateScheduled = !1),
        (this.scheduleUpdate = () => this.update()),
        (this.projectionUpdateScheduled = !1),
        (this.checkUpdateFailed = () => {
          this.isUpdating && ((this.isUpdating = !1), this.clearAllSnapshots());
        }),
        (this.updateProjection = () => {
          ((this.projectionUpdateScheduled = !1),
            this.nodes.forEach(hu),
            this.nodes.forEach(pu),
            this.nodes.forEach(gu),
            this.nodes.forEach(fu));
        }),
        (this.resolvedRelativeTargetAt = 0),
        (this.hasProjected = !1),
        (this.isVisible = !0),
        (this.animationProgress = 0),
        (this.sharedNodes = new Map()),
        (this.latestValues = r),
        (this.root = a ? a.root || a : this),
        (this.path = a ? [...a.path, a] : []),
        (this.parent = a),
        (this.depth = a ? a.depth + 1 : 0));
      for (let l = 0; l < this.path.length; l++)
        this.path[l].shouldResetTransform = !0;
      this.root === this && (this.nodes = new Yl());
    }
    addEventListener(r, a) {
      return (
        this.eventHandlers.has(r) || this.eventHandlers.set(r, new Ue()),
        this.eventHandlers.get(r).add(a)
      );
    }
    notifyListeners(r, ...a) {
      const l = this.eventHandlers.get(r);
      l && l.notify(...a);
    }
    hasListeners(r) {
      return this.eventHandlers.has(r);
    }
    mount(r) {
      if (this.instance) return;
      ((this.isSVG = gi(r) && !sa(r)), (this.instance = r));
      const { layoutId: a, layout: l, visualElement: c } = this.options;
      if (
        (c && !c.current && c.mount(r),
        this.root.nodes.add(this),
        this.parent && this.parent.children.add(this),
        this.root.hasTreeAnimated && (l || a) && (this.isLayoutDirty = !0),
        t)
      ) {
        let u,
          h = 0;
        const f = () => (this.root.updateBlockedByResize = !1);
        (V.read(() => {
          h = window.innerWidth;
        }),
          t(r, () => {
            const d = window.innerWidth;
            d !== h &&
              ((h = d),
              (this.root.updateBlockedByResize = !0),
              u && u(),
              (u = ql(f, 250)),
              Wt.hasAnimatedSinceResize &&
                ((Wt.hasAnimatedSinceResize = !1), this.nodes.forEach(Ts)));
          }));
      }
      (a && this.root.registerSharedNode(a, this),
        this.options.animate !== !1 &&
          c &&
          (a || l) &&
          this.addEventListener(
            "didUpdate",
            ({
              delta: u,
              hasLayoutChanged: h,
              hasRelativeLayoutChanged: f,
              layout: d,
            }) => {
              if (this.isTreeAnimationBlocked()) {
                ((this.target = void 0), (this.relativeTarget = void 0));
                return;
              }
              const m =
                  this.options.transition || c.getDefaultTransition() || Pu,
                { onLayoutAnimationStart: v, onLayoutAnimationComplete: y } =
                  c.getProps(),
                p = !this.targetLayout || !Qi(this.targetLayout, d),
                T = !h && f;
              if (
                this.options.layoutRoot ||
                this.resumeFrom ||
                T ||
                (h && (p || !this.currentAnimation))
              ) {
                this.resumeFrom &&
                  ((this.resumingFrom = this.resumeFrom),
                  (this.resumingFrom.resumingFrom = void 0));
                const g = { ...Qe(m, "layout"), onPlay: v, onComplete: y };
                ((c.shouldReduceMotion || this.options.layoutRoot) &&
                  ((g.delay = 0), (g.type = !1)),
                  this.startAnimation(g),
                  this.setAnimationOrigin(u, T));
              } else
                (h || Ts(this),
                  this.isLead() &&
                    this.options.onExitComplete &&
                    this.options.onExitComplete());
              this.targetLayout = d;
            },
          ));
    }
    unmount() {
      (this.options.layoutId && this.willUpdate(),
        this.root.nodes.remove(this));
      const r = this.getStack();
      (r && r.remove(this),
        this.parent && this.parent.children.delete(this),
        (this.instance = void 0),
        this.eventHandlers.clear(),
        q(this.updateProjection));
    }
    blockUpdate() {
      this.updateManuallyBlocked = !0;
    }
    unblockUpdate() {
      this.updateManuallyBlocked = !1;
    }
    isUpdateBlocked() {
      return this.updateManuallyBlocked || this.updateBlockedByResize;
    }
    isTreeAnimationBlocked() {
      return (
        this.isAnimationBlocked ||
        (this.parent && this.parent.isTreeAnimationBlocked()) ||
        !1
      );
    }
    startUpdate() {
      this.isUpdateBlocked() ||
        ((this.isUpdating = !0),
        this.nodes && this.nodes.forEach(yu),
        this.animationId++);
    }
    getTransformTemplate() {
      const { visualElement: r } = this.options;
      return r && r.getProps().transformTemplate;
    }
    willUpdate(r = !0) {
      if (((this.root.hasTreeAnimated = !0), this.root.isUpdateBlocked())) {
        this.options.onExitComplete && this.options.onExitComplete();
        return;
      }
      if (
        (window.MotionCancelOptimisedAnimation &&
          !this.hasCheckedOptimisedAppear &&
          tr(this),
        !this.root.isUpdating && this.root.startUpdate(),
        this.isLayoutDirty)
      )
        return;
      this.isLayoutDirty = !0;
      for (let u = 0; u < this.path.length; u++) {
        const h = this.path[u];
        ((h.shouldResetTransform = !0),
          h.updateScroll("snapshot"),
          h.options.layoutRoot && h.willUpdate(!1));
      }
      const { layoutId: a, layout: l } = this.options;
      if (a === void 0 && !l) return;
      const c = this.getTransformTemplate();
      ((this.prevTransformTemplateValue = c
        ? c(this.latestValues, "")
        : void 0),
        this.updateSnapshot(),
        r && this.notifyListeners("willUpdate"));
    }
    update() {
      if (((this.updateScheduled = !1), this.isUpdateBlocked())) {
        (this.unblockUpdate(),
          this.clearAllSnapshots(),
          this.nodes.forEach(ys));
        return;
      }
      if (this.animationId <= this.animationCommitId) {
        this.nodes.forEach(vs);
        return;
      }
      ((this.animationCommitId = this.animationId),
        this.isUpdating
          ? ((this.isUpdating = !1),
            this.nodes.forEach(mu),
            this.nodes.forEach(uu),
            this.nodes.forEach(cu))
          : this.nodes.forEach(vs),
        this.clearAllSnapshots());
      const a = O.now();
      ((k.delta = z(0, 1e3 / 60, a - k.timestamp)),
        (k.timestamp = a),
        (k.isProcessing = !0),
        Zt.update.process(k),
        Zt.preRender.process(k),
        Zt.render.process(k),
        (k.isProcessing = !1));
    }
    didUpdate() {
      this.updateScheduled ||
        ((this.updateScheduled = !0), en.read(this.scheduleUpdate));
    }
    clearAllSnapshots() {
      (this.nodes.forEach(du), this.sharedNodes.forEach(vu));
    }
    scheduleUpdateProjection() {
      this.projectionUpdateScheduled ||
        ((this.projectionUpdateScheduled = !0),
        V.preRender(this.updateProjection, !1, !0));
    }
    scheduleCheckAfterUnmount() {
      V.postRender(() => {
        this.isLayoutDirty
          ? this.root.didUpdate()
          : this.root.checkUpdateFailed();
      });
    }
    updateSnapshot() {
      this.snapshot ||
        !this.instance ||
        ((this.snapshot = this.measure()),
        this.snapshot &&
          !B(this.snapshot.measuredBox.x) &&
          !B(this.snapshot.measuredBox.y) &&
          (this.snapshot = void 0));
    }
    updateLayout() {
      if (
        !this.instance ||
        (this.updateScroll(),
        !(this.options.alwaysMeasureLayout && this.isLead()) &&
          !this.isLayoutDirty)
      )
        return;
      if (this.resumeFrom && !this.resumeFrom.instance)
        for (let l = 0; l < this.path.length; l++) this.path[l].updateScroll();
      const r = this.layout;
      ((this.layout = this.measure(!1)),
        (this.layoutCorrected = D()),
        (this.isLayoutDirty = !1),
        (this.projectionDelta = void 0),
        this.notifyListeners("measure", this.layout.layoutBox));
      const { visualElement: a } = this.options;
      a &&
        a.notify(
          "LayoutMeasure",
          this.layout.layoutBox,
          r ? r.layoutBox : void 0,
        );
    }
    updateScroll(r = "measure") {
      let a = !!(this.options.layoutScroll && this.instance);
      if (
        (this.scroll &&
          this.scroll.animationId === this.root.animationId &&
          this.scroll.phase === r &&
          (a = !1),
        a && this.instance)
      ) {
        const l = s(this.instance);
        this.scroll = {
          animationId: this.root.animationId,
          phase: r,
          isRoot: l,
          offset: n(this.instance),
          wasRoot: this.scroll ? this.scroll.isRoot : l,
        };
      }
    }
    resetTransform() {
      if (!i) return;
      const r =
          this.isLayoutDirty ||
          this.shouldResetTransform ||
          this.options.alwaysMeasureLayout,
        a = this.projectionDelta && !Ji(this.projectionDelta),
        l = this.getTransformTemplate(),
        c = l ? l(this.latestValues, "") : void 0,
        u = c !== this.prevTransformTemplateValue;
      r &&
        this.instance &&
        (a || et(this.latestValues) || u) &&
        (i(this.instance, c),
        (this.shouldResetTransform = !1),
        this.scheduleRender());
    }
    measure(r = !0) {
      const a = this.measurePageBox();
      let l = this.removeElementScroll(a);
      return (
        r && (l = this.removeTransform(l)),
        Su(l),
        {
          animationId: this.root.animationId,
          measuredBox: a,
          layoutBox: l,
          latestValues: {},
          source: this.id,
        }
      );
    }
    measurePageBox() {
      const { visualElement: r } = this.options;
      if (!r) return D();
      const a = r.measureViewportBox();
      if (!(this.scroll?.wasRoot || this.path.some(bu))) {
        const { scroll: c } = this.root;
        c && (ct(a.x, c.offset.x), ct(a.y, c.offset.y));
      }
      return a;
    }
    removeElementScroll(r) {
      const a = D();
      if ((U(a, r), this.scroll?.wasRoot)) return a;
      for (let l = 0; l < this.path.length; l++) {
        const c = this.path[l],
          { scroll: u, options: h } = c;
        c !== this.root &&
          u &&
          h.layoutScroll &&
          (u.wasRoot && U(a, r), ct(a.x, u.offset.x), ct(a.y, u.offset.y));
      }
      return a;
    }
    applyTransform(r, a = !1) {
      const l = D();
      U(l, r);
      for (let c = 0; c < this.path.length; c++) {
        const u = this.path[c];
        (!a &&
          u.options.layoutScroll &&
          u.scroll &&
          u !== u.root &&
          ht(l, { x: -u.scroll.offset.x, y: -u.scroll.offset.y }),
          et(u.latestValues) && ht(l, u.latestValues));
      }
      return (et(this.latestValues) && ht(l, this.latestValues), l);
    }
    removeTransform(r) {
      const a = D();
      U(a, r);
      for (let l = 0; l < this.path.length; l++) {
        const c = this.path[l];
        if (!c.instance || !et(c.latestValues)) continue;
        Ve(c.latestValues) && c.updateSnapshot();
        const u = D(),
          h = c.measurePageBox();
        (U(u, h),
          hs(a, c.latestValues, c.snapshot ? c.snapshot.layoutBox : void 0, u));
      }
      return (et(this.latestValues) && hs(a, this.latestValues), a);
    }
    setTargetDelta(r) {
      ((this.targetDelta = r),
        this.root.scheduleUpdateProjection(),
        (this.isProjectionDirty = !0));
    }
    setOptions(r) {
      this.options = {
        ...this.options,
        ...r,
        crossfade: r.crossfade !== void 0 ? r.crossfade : !0,
      };
    }
    clearMeasurements() {
      ((this.scroll = void 0),
        (this.layout = void 0),
        (this.snapshot = void 0),
        (this.prevTransformTemplateValue = void 0),
        (this.targetDelta = void 0),
        (this.target = void 0),
        (this.isLayoutDirty = !1));
    }
    forceRelativeParentToResolveTarget() {
      this.relativeParent &&
        this.relativeParent.resolvedRelativeTargetAt !== k.timestamp &&
        this.relativeParent.resolveTargetDelta(!0);
    }
    resolveTargetDelta(r = !1) {
      const a = this.getLead();
      (this.isProjectionDirty || (this.isProjectionDirty = a.isProjectionDirty),
        this.isTransformDirty || (this.isTransformDirty = a.isTransformDirty),
        this.isSharedProjectionDirty ||
          (this.isSharedProjectionDirty = a.isSharedProjectionDirty));
      const l = !!this.resumingFrom || this !== a;
      if (!(
        r ||
        (l && this.isSharedProjectionDirty) ||
        this.isProjectionDirty ||
        this.parent?.isProjectionDirty ||
        this.attemptToResolveRelativeTarget ||
        this.root.updateBlockedByResize
      ))
        return;
      const { layout: u, layoutId: h } = this.options;
      if (!(!this.layout || !(u || h))) {
        if (
          ((this.resolvedRelativeTargetAt = k.timestamp),
          !this.targetDelta && !this.relativeTarget)
        ) {
          const f = this.getClosestProjectingParent();
          f && f.layout && this.animationProgress !== 1
            ? ((this.relativeParent = f),
              this.forceRelativeParentToResolveTarget(),
              (this.relativeTarget = D()),
              (this.relativeTargetOrigin = D()),
              wt(
                this.relativeTargetOrigin,
                this.layout.layoutBox,
                f.layout.layoutBox,
              ),
              U(this.relativeTarget, this.relativeTargetOrigin))
            : (this.relativeParent = this.relativeTarget = void 0);
        }
        if (
          !(!this.relativeTarget && !this.targetDelta) &&
          (this.target ||
            ((this.target = D()), (this.targetWithTransforms = D())),
          this.relativeTarget &&
          this.relativeTargetOrigin &&
          this.relativeParent &&
          this.relativeParent.target
            ? (this.forceRelativeParentToResolveTarget(),
              Dl(this.target, this.relativeTarget, this.relativeParent.target))
            : this.targetDelta
              ? (this.resumingFrom
                  ? (this.target = this.applyTransform(this.layout.layoutBox))
                  : U(this.target, this.layout.layoutBox),
                ki(this.target, this.targetDelta))
              : U(this.target, this.layout.layoutBox),
          this.attemptToResolveRelativeTarget)
        ) {
          this.attemptToResolveRelativeTarget = !1;
          const f = this.getClosestProjectingParent();
          f &&
          !!f.resumingFrom == !!this.resumingFrom &&
          !f.options.layoutScroll &&
          f.target &&
          this.animationProgress !== 1
            ? ((this.relativeParent = f),
              this.forceRelativeParentToResolveTarget(),
              (this.relativeTarget = D()),
              (this.relativeTargetOrigin = D()),
              wt(this.relativeTargetOrigin, this.target, f.target),
              U(this.relativeTarget, this.relativeTargetOrigin))
            : (this.relativeParent = this.relativeTarget = void 0);
        }
      }
    }
    getClosestProjectingParent() {
      if (!(
        !this.parent ||
        Ve(this.parent.latestValues) ||
        Li(this.parent.latestValues)
      ))
        return this.parent.isProjecting()
          ? this.parent
          : this.parent.getClosestProjectingParent();
    }
    isProjecting() {
      return !!(
        (this.relativeTarget || this.targetDelta || this.options.layoutRoot) &&
        this.layout
      );
    }
    calcProjection() {
      const r = this.getLead(),
        a = !!this.resumingFrom || this !== r;
      let l = !0;
      if (
        ((this.isProjectionDirty || this.parent?.isProjectionDirty) && (l = !1),
        a &&
          (this.isSharedProjectionDirty || this.isTransformDirty) &&
          (l = !1),
        this.resolvedRelativeTargetAt === k.timestamp && (l = !1),
        l)
      )
        return;
      const { layout: c, layoutId: u } = this.options;
      if (
        ((this.isTreeAnimating = !!(
          (this.parent && this.parent.isTreeAnimating) ||
          this.currentAnimation ||
          this.pendingAnimation
        )),
        this.isTreeAnimating ||
          (this.targetDelta = this.relativeTarget = void 0),
        !this.layout || !(c || u))
      )
        return;
      U(this.layoutCorrected, this.layout.layoutBox);
      const h = this.treeScale.x,
        f = this.treeScale.y;
      (Ka(this.layoutCorrected, this.treeScale, this.path, a),
        r.layout &&
          !r.target &&
          (this.treeScale.x !== 1 || this.treeScale.y !== 1) &&
          ((r.target = r.layout.layoutBox), (r.targetWithTransforms = D())));
      const { target: d } = r;
      if (!d) {
        this.prevProjectionDelta &&
          (this.createProjectionDeltas(), this.scheduleRender());
        return;
      }
      (!this.projectionDelta || !this.prevProjectionDelta
        ? this.createProjectionDeltas()
        : (ls(this.prevProjectionDelta.x, this.projectionDelta.x),
          ls(this.prevProjectionDelta.y, this.projectionDelta.y)),
        At(this.projectionDelta, this.layoutCorrected, d, this.latestValues),
        (this.treeScale.x !== h ||
          this.treeScale.y !== f ||
          !gs(this.projectionDelta.x, this.prevProjectionDelta.x) ||
          !gs(this.projectionDelta.y, this.prevProjectionDelta.y)) &&
          ((this.hasProjected = !0),
          this.scheduleRender(),
          this.notifyListeners("projectionUpdate", d)));
    }
    hide() {
      this.isVisible = !1;
    }
    show() {
      this.isVisible = !0;
    }
    scheduleRender(r = !0) {
      if ((this.options.visualElement?.scheduleRender(), r)) {
        const a = this.getStack();
        a && a.scheduleRender();
      }
      this.resumingFrom &&
        !this.resumingFrom.instance &&
        (this.resumingFrom = void 0);
    }
    createProjectionDeltas() {
      ((this.prevProjectionDelta = ft()),
        (this.projectionDelta = ft()),
        (this.projectionDeltaWithTransform = ft()));
    }
    setAnimationOrigin(r, a = !1) {
      const l = this.snapshot,
        c = l ? l.latestValues : {},
        u = { ...this.latestValues },
        h = ft();
      ((!this.relativeParent || !this.relativeParent.options.layoutRoot) &&
        (this.relativeTarget = this.relativeTargetOrigin = void 0),
        (this.attemptToResolveRelativeTarget = !a));
      const f = D(),
        d = l ? l.source : void 0,
        m = this.layout ? this.layout.source : void 0,
        v = d !== m,
        y = this.getStack(),
        p = !y || y.members.length <= 1,
        T = !!(v && !p && this.options.crossfade === !0 && !this.path.some(xu));
      this.animationProgress = 0;
      let g;
      ((this.mixTargetDelta = (A) => {
        const P = A / 1e3;
        (xs(h.x, r.x, P),
          xs(h.y, r.y, P),
          this.setTargetDelta(h),
          this.relativeTarget &&
            this.relativeTargetOrigin &&
            this.layout &&
            this.relativeParent &&
            this.relativeParent.layout &&
            (wt(f, this.layout.layoutBox, this.relativeParent.layout.layoutBox),
            Tu(this.relativeTarget, this.relativeTargetOrigin, f, P),
            g && iu(this.relativeTarget, g) && (this.isProjectionDirty = !1),
            g || (g = D()),
            U(g, this.relativeTarget)),
          v &&
            ((this.animationValues = u), Jl(u, c, this.latestValues, P, T, p)),
          this.root.scheduleUpdateProjection(),
          this.scheduleRender(),
          (this.animationProgress = P));
      }),
        this.mixTargetDelta(this.options.layoutRoot ? 1e3 : 0));
    }
    startAnimation(r) {
      (this.notifyListeners("animationStart"),
        this.currentAnimation?.stop(),
        this.resumingFrom?.currentAnimation?.stop(),
        this.pendingAnimation &&
          (q(this.pendingAnimation), (this.pendingAnimation = void 0)),
        (this.pendingAnimation = V.update(() => {
          ((Wt.hasAnimatedSinceResize = !0),
            this.motionValue || (this.motionValue = mt(0)),
            (this.currentAnimation = zl(this.motionValue, [0, 1e3], {
              ...r,
              velocity: 0,
              isSync: !0,
              onUpdate: (a) => {
                (this.mixTargetDelta(a), r.onUpdate && r.onUpdate(a));
              },
              onStop: () => {},
              onComplete: () => {
                (r.onComplete && r.onComplete(), this.completeAnimation());
              },
            })),
            this.resumingFrom &&
              (this.resumingFrom.currentAnimation = this.currentAnimation),
            (this.pendingAnimation = void 0));
        })));
    }
    completeAnimation() {
      this.resumingFrom &&
        ((this.resumingFrom.currentAnimation = void 0),
        (this.resumingFrom.preserveOpacity = void 0));
      const r = this.getStack();
      (r && r.exitAnimationComplete(),
        (this.resumingFrom =
          this.currentAnimation =
          this.animationValues =
            void 0),
        this.notifyListeners("animationComplete"));
    }
    finishAnimation() {
      (this.currentAnimation &&
        (this.mixTargetDelta && this.mixTargetDelta(au),
        this.currentAnimation.stop()),
        this.completeAnimation());
    }
    applyTransformsToTarget() {
      const r = this.getLead();
      let {
        targetWithTransforms: a,
        target: l,
        layout: c,
        latestValues: u,
      } = r;
      if (!(!a || !l || !c)) {
        if (
          this !== r &&
          this.layout &&
          c &&
          nr(this.options.animationType, this.layout.layoutBox, c.layoutBox)
        ) {
          l = this.target || D();
          const h = B(this.layout.layoutBox.x);
          ((l.x.min = r.target.x.min), (l.x.max = l.x.min + h));
          const f = B(this.layout.layoutBox.y);
          ((l.y.min = r.target.y.min), (l.y.max = l.y.min + f));
        }
        (U(a, l),
          ht(a, u),
          At(this.projectionDeltaWithTransform, this.layoutCorrected, a, u));
      }
    }
    registerSharedNode(r, a) {
      (this.sharedNodes.has(r) || this.sharedNodes.set(r, new ru()),
        this.sharedNodes.get(r).add(a));
      const c = a.options.initialPromotionConfig;
      a.promote({
        transition: c ? c.transition : void 0,
        preserveFollowOpacity:
          c && c.shouldPreserveFollowOpacity
            ? c.shouldPreserveFollowOpacity(a)
            : void 0,
      });
    }
    isLead() {
      const r = this.getStack();
      return r ? r.lead === this : !0;
    }
    getLead() {
      const { layoutId: r } = this.options;
      return r ? this.getStack()?.lead || this : this;
    }
    getPrevLead() {
      const { layoutId: r } = this.options;
      return r ? this.getStack()?.prevLead : void 0;
    }
    getStack() {
      const { layoutId: r } = this.options;
      if (r) return this.root.sharedNodes.get(r);
    }
    promote({ needsReset: r, transition: a, preserveFollowOpacity: l } = {}) {
      const c = this.getStack();
      (c && c.promote(this, l),
        r && ((this.projectionDelta = void 0), (this.needsReset = !0)),
        a && this.setOptions({ transition: a }));
    }
    relegate() {
      const r = this.getStack();
      return r ? r.relegate(this) : !1;
    }
    resetSkewAndRotation() {
      const { visualElement: r } = this.options;
      if (!r) return;
      let a = !1;
      const { latestValues: l } = r;
      if (
        ((l.z ||
          l.rotate ||
          l.rotateX ||
          l.rotateY ||
          l.rotateZ ||
          l.skewX ||
          l.skewY) &&
          (a = !0),
        !a)
      )
        return;
      const c = {};
      l.z && ue("z", r, c, this.animationValues);
      for (let u = 0; u < le.length; u++)
        (ue(`rotate${le[u]}`, r, c, this.animationValues),
          ue(`skew${le[u]}`, r, c, this.animationValues));
      r.render();
      for (const u in c)
        (r.setStaticValue(u, c[u]),
          this.animationValues && (this.animationValues[u] = c[u]));
      r.scheduleRender();
    }
    applyProjectionStyles(r, a) {
      if (!this.instance || this.isSVG) return;
      if (!this.isVisible) {
        r.visibility = "hidden";
        return;
      }
      const l = this.getTransformTemplate();
      if (this.needsReset) {
        ((this.needsReset = !1),
          (r.visibility = ""),
          (r.opacity = ""),
          (r.pointerEvents = Kt(a?.pointerEvents) || ""),
          (r.transform = l ? l(this.latestValues, "") : "none"));
        return;
      }
      const c = this.getLead();
      if (!this.projectionDelta || !this.layout || !c.target) {
        (this.options.layoutId &&
          ((r.opacity =
            this.latestValues.opacity !== void 0
              ? this.latestValues.opacity
              : 1),
          (r.pointerEvents = Kt(a?.pointerEvents) || "")),
          this.hasProjected &&
            !et(this.latestValues) &&
            ((r.transform = l ? l({}, "") : "none"), (this.hasProjected = !1)));
        return;
      }
      r.visibility = "";
      const u = c.animationValues || c.latestValues;
      this.applyTransformsToTarget();
      let h = ou(this.projectionDeltaWithTransform, this.treeScale, u);
      (l && (h = l(u, h)), (r.transform = h));
      const { x: f, y: d } = this.projectionDelta;
      ((r.transformOrigin = `${f.origin * 100}% ${d.origin * 100}% 0`),
        c.animationValues
          ? (r.opacity =
              c === this
                ? (u.opacity ?? this.latestValues.opacity ?? 1)
                : this.preserveOpacity
                  ? this.latestValues.opacity
                  : u.opacityExit)
          : (r.opacity =
              c === this
                ? u.opacity !== void 0
                  ? u.opacity
                  : ""
                : u.opacityExit !== void 0
                  ? u.opacityExit
                  : 0));
      for (const m in Et) {
        if (u[m] === void 0) continue;
        const { correct: v, applyTo: y, isCSSVariable: p } = Et[m],
          T = h === "none" ? u[m] : v(u[m], c);
        if (y) {
          const g = y.length;
          for (let A = 0; A < g; A++) r[y[A]] = T;
        } else
          p ? (this.options.visualElement.renderState.vars[m] = T) : (r[m] = T);
      }
      this.options.layoutId &&
        (r.pointerEvents = c === this ? Kt(a?.pointerEvents) || "" : "none");
    }
    clearSnapshot() {
      this.resumeFrom = this.snapshot = void 0;
    }
    resetTree() {
      (this.root.nodes.forEach((r) => r.currentAnimation?.stop()),
        this.root.nodes.forEach(ys),
        this.root.sharedNodes.clear());
    }
  };
}
function uu(t) {
  t.updateLayout();
}
function cu(t) {
  const e = t.resumeFrom?.snapshot || t.snapshot;
  if (t.isLead() && t.layout && e && t.hasListeners("didUpdate")) {
    const { layoutBox: n, measuredBox: s } = t.layout,
      { animationType: i } = t.options,
      o = e.source !== t.layout.source;
    i === "size"
      ? K((u) => {
          const h = o ? e.measuredBox[u] : e.layoutBox[u],
            f = B(h);
          ((h.min = n[u].min), (h.max = h.min + f));
        })
      : nr(i, e.layoutBox, n) &&
        K((u) => {
          const h = o ? e.measuredBox[u] : e.layoutBox[u],
            f = B(n[u]);
          ((h.max = h.min + f),
            t.relativeTarget &&
              !t.currentAnimation &&
              ((t.isProjectionDirty = !0),
              (t.relativeTarget[u].max = t.relativeTarget[u].min + f)));
        });
    const r = ft();
    At(r, n, e.layoutBox);
    const a = ft();
    o ? At(a, t.applyTransform(s, !0), e.measuredBox) : At(a, n, e.layoutBox);
    const l = !Ji(r);
    let c = !1;
    if (!t.resumeFrom) {
      const u = t.getClosestProjectingParent();
      if (u && !u.resumeFrom) {
        const { snapshot: h, layout: f } = u;
        if (h && f) {
          const d = D();
          wt(d, e.layoutBox, h.layoutBox);
          const m = D();
          (wt(m, n, f.layoutBox),
            Qi(d, m) || (c = !0),
            u.options.layoutRoot &&
              ((t.relativeTarget = m),
              (t.relativeTargetOrigin = d),
              (t.relativeParent = u)));
        }
      }
    }
    t.notifyListeners("didUpdate", {
      layout: n,
      snapshot: e,
      delta: a,
      layoutDelta: r,
      hasLayoutChanged: l,
      hasRelativeLayoutChanged: c,
    });
  } else if (t.isLead()) {
    const { onExitComplete: n } = t.options;
    n && n();
  }
  t.options.transition = void 0;
}
function hu(t) {
  t.parent &&
    (t.isProjecting() || (t.isProjectionDirty = t.parent.isProjectionDirty),
    t.isSharedProjectionDirty ||
      (t.isSharedProjectionDirty = !!(
        t.isProjectionDirty ||
        t.parent.isProjectionDirty ||
        t.parent.isSharedProjectionDirty
      )),
    t.isTransformDirty || (t.isTransformDirty = t.parent.isTransformDirty));
}
function fu(t) {
  t.isProjectionDirty = t.isSharedProjectionDirty = t.isTransformDirty = !1;
}
function du(t) {
  t.clearSnapshot();
}
function ys(t) {
  t.clearMeasurements();
}
function vs(t) {
  t.isLayoutDirty = !1;
}
function mu(t) {
  const { visualElement: e } = t.options;
  (e && e.getProps().onBeforeLayoutMeasure && e.notify("BeforeLayoutMeasure"),
    t.resetTransform());
}
function Ts(t) {
  (t.finishAnimation(),
    (t.targetDelta = t.relativeTarget = t.target = void 0),
    (t.isProjectionDirty = !0));
}
function pu(t) {
  t.resolveTargetDelta();
}
function gu(t) {
  t.calcProjection();
}
function yu(t) {
  t.resetSkewAndRotation();
}
function vu(t) {
  t.removeLeadSnapshot();
}
function xs(t, e, n) {
  ((t.translate = C(e.translate, 0, n)),
    (t.scale = C(e.scale, 1, n)),
    (t.origin = e.origin),
    (t.originPoint = e.originPoint));
}
function Ps(t, e, n, s) {
  ((t.min = C(e.min, n.min, s)), (t.max = C(e.max, n.max, s)));
}
function Tu(t, e, n, s) {
  (Ps(t.x, e.x, n.x, s), Ps(t.y, e.y, n.y, s));
}
function xu(t) {
  return t.animationValues && t.animationValues.opacityExit !== void 0;
}
const Pu = { duration: 0.45, ease: [0.4, 0, 0.1, 1] },
  Ss = (t) =>
    typeof navigator < "u" &&
    navigator.userAgent &&
    navigator.userAgent.toLowerCase().includes(t),
  bs = Ss("applewebkit/") && !Ss("chrome/") ? Math.round : $;
function As(t) {
  ((t.min = bs(t.min)), (t.max = bs(t.max)));
}
function Su(t) {
  (As(t.x), As(t.y));
}
function nr(t, e, n) {
  return (
    t === "position" || (t === "preserve-aspect" && !Ml(ps(e), ps(n), 0.2))
  );
}
function bu(t) {
  return t !== t.root && t.scroll?.wasRoot;
}
const Au = er({
    attachResizeListener: (t, e) => Rt(t, "resize", e),
    measureScroll: () => ({
      x: document.documentElement.scrollLeft || document.body.scrollLeft,
      y: document.documentElement.scrollTop || document.body.scrollTop,
    }),
    checkIsScrollRoot: () => !0,
  }),
  ce = { current: void 0 },
  sr = er({
    measureScroll: (t) => ({ x: t.scrollLeft, y: t.scrollTop }),
    defaultParent: () => {
      if (!ce.current) {
        const t = new Au({});
        (t.mount(window), t.setOptions({ layoutScroll: !0 }), (ce.current = t));
      }
      return ce.current;
    },
    resetTransform: (t, e) => {
      t.style.transform = e !== void 0 ? e : "none";
    },
    checkIsScrollRoot: (t) => window.getComputedStyle(t).position === "fixed",
  }),
  wu = {
    pan: { Feature: $l },
    drag: { Feature: Wl, ProjectionNode: sr, MeasureLayout: Yi },
  };
function ws(t, e, n) {
  const { props: s } = t;
  t.animationState &&
    s.whileHover &&
    t.animationState.setActive("whileHover", n === "Start");
  const i = "onHover" + n,
    o = s[i];
  o && V.postRender(() => o(e, Bt(e)));
}
class Vu extends J {
  mount() {
    const { current: e } = this.node;
    e &&
      (this.unmount = Jo(
        e,
        (n, s) => (ws(this.node, s, "Start"), (i) => ws(this.node, i, "End")),
      ));
  }
  unmount() {}
}
class Cu extends J {
  constructor() {
    (super(...arguments), (this.isActive = !1));
  }
  onFocus() {
    let e = !1;
    try {
      e = this.node.current.matches(":focus-visible");
    } catch {
      e = !0;
    }
    !e ||
      !this.node.animationState ||
      (this.node.animationState.setActive("whileFocus", !0),
      (this.isActive = !0));
  }
  onBlur() {
    !this.isActive ||
      !this.node.animationState ||
      (this.node.animationState.setActive("whileFocus", !1),
      (this.isActive = !1));
  }
  mount() {
    this.unmount = Lt(
      Rt(this.node.current, "focus", () => this.onFocus()),
      Rt(this.node.current, "blur", () => this.onBlur()),
    );
  }
  unmount() {}
}
function Vs(t, e, n) {
  const { props: s } = t;
  if (t.current instanceof HTMLButtonElement && t.current.disabled) return;
  t.animationState &&
    s.whileTap &&
    t.animationState.setActive("whileTap", n === "Start");
  const i = "onTap" + (n === "End" ? "" : n),
    o = s[i];
  o && V.postRender(() => o(e, Bt(e)));
}
class Mu extends J {
  mount() {
    const { current: e } = this.node;
    e &&
      (this.unmount = na(
        e,
        (n, s) => (
          Vs(this.node, s, "Start"),
          (i, { success: o }) => Vs(this.node, i, o ? "End" : "Cancel")
        ),
        { useGlobalTarget: this.node.props.globalTapTarget },
      ));
  }
  unmount() {}
}
const ke = new WeakMap(),
  he = new WeakMap(),
  Du = (t) => {
    const e = ke.get(t.target);
    e && e(t);
  },
  Eu = (t) => {
    t.forEach(Du);
  };
function Ru({ root: t, ...e }) {
  const n = t || document;
  he.has(n) || he.set(n, {});
  const s = he.get(n),
    i = JSON.stringify(e);
  return (
    s[i] || (s[i] = new IntersectionObserver(Eu, { root: t, ...e })),
    s[i]
  );
}
function Lu(t, e, n) {
  const s = Ru(e);
  return (
    ke.set(t, n),
    s.observe(t),
    () => {
      (ke.delete(t), s.unobserve(t));
    }
  );
}
const ku = { some: 0, all: 1 };
class Fu extends J {
  constructor() {
    (super(...arguments), (this.hasEnteredView = !1), (this.isInView = !1));
  }
  startObserver() {
    this.unmount();
    const { viewport: e = {} } = this.node.getProps(),
      { root: n, margin: s, amount: i = "some", once: o } = e,
      r = {
        root: n ? n.current : void 0,
        rootMargin: s,
        threshold: typeof i == "number" ? i : ku[i],
      },
      a = (l) => {
        const { isIntersecting: c } = l;
        if (
          this.isInView === c ||
          ((this.isInView = c), o && !c && this.hasEnteredView)
        )
          return;
        (c && (this.hasEnteredView = !0),
          this.node.animationState &&
            this.node.animationState.setActive("whileInView", c));
        const { onViewportEnter: u, onViewportLeave: h } = this.node.getProps(),
          f = c ? u : h;
        f && f(l);
      };
    return Lu(this.node.current, r, a);
  }
  mount() {
    this.startObserver();
  }
  update() {
    if (typeof IntersectionObserver > "u") return;
    const { props: e, prevProps: n } = this.node;
    ["amount", "margin", "root"].some(Bu(e, n)) && this.startObserver();
  }
  unmount() {}
}
function Bu({ viewport: t = {} }, { viewport: e = {} } = {}) {
  return (n) => t[n] !== e[n];
}
const Iu = {
    inView: { Feature: Fu },
    tap: { Feature: Mu },
    focus: { Feature: Cu },
    hover: { Feature: Vu },
  },
  Ou = { layout: { ProjectionNode: sr, MeasureLayout: Yi } },
  ju = { ...Sl, ...Iu, ...wu, ...Ou },
  Wu = ja(ju, Za);
export {
  Cs as L,
  yi as M,
  Be as P,
  ar as a,
  Xo as b,
  oa as c,
  V as f,
  Bi as h,
  $a as i,
  ua as l,
  Wu as m,
  Me as p,
  or as u,
};
