import { j as e } from "./react-vendor-BK1G6oO1.js";
import {
  cl as i,
  cm as l,
  cn as t,
  co as n,
  cp as d,
  cq as m,
} from "./index-DjyiOHey.js";
import { C as o, a as h, b as u, c as x } from "./CareerQuiz-8ISD3rOQ.js";
import "./ui-components-DeMDYLzO.js";
import "./NetworkTraceGame-Qz8SQ8Dr.js";
import "./GameNotebook-b0Qw2wzd.js";
import "./network-build-z_ixRQe6.js";
import "./immersive-picker-PA4Q0OWd.js";
import "./keyword-flashcards-Ha6Msavb.js";
import "./use-cover-art-CyGvgy9q.js";
import "./helpers-DmEFZcxj.js";
function A({ target: r, link: s, lead: c }) {
  if (r.view === "quiz") return e.jsx(o, { link: s });
  if (r.view === "career") {
    const a = i(r.id);
    if (a) return e.jsx(p, { career: a, link: s }, a.id);
  }
  return e.jsx(j, { link: s, lead: c });
}
function j({ link: r, lead: s = "j277" }) {
  const c = s === "btec" ? [...t, ...n] : d;
  return e.jsxs("div", {
    className: "careers",
    "data-careers-view": "hub",
    children: [
      e.jsx("h1", { className: "careers-title", children: "Careers hub" }),
      r(
        { view: "quiz" },
        {
          className: "careers-quiz-card",
          children: e.jsxs(e.Fragment, {
            children: [
              e.jsx("span", {
                className: "careers-quiz-card-icon",
                "aria-hidden": "true",
                children: e.jsx(l, {}),
              }),
              e.jsxs("span", {
                className: "careers-quiz-card-text",
                children: [
                  e.jsx("span", {
                    className: "careers-quiz-card-title",
                    children: "Which tech job suits you?",
                  }),
                  e.jsx("span", {
                    className: "careers-quiz-card-meta",
                    children: "Click to play",
                  }),
                ],
              }),
            ],
          }),
        },
      ),
      e.jsx("ul", {
        className: "careers-grid",
        "aria-label": "Careers",
        children: c.map((a) =>
          e.jsx(
            "li",
            {
              children: r(
                { view: "career", id: a.id },
                {
                  className: "careers-card",
                  children: e.jsxs(e.Fragment, {
                    children: [
                      e.jsx(h, { career: a, className: "careers-card-face" }),
                      e.jsxs("span", {
                        className: "careers-card-text",
                        children: [
                          e.jsx("span", {
                            className: "careers-card-title",
                            children: a.title,
                          }),
                          e.jsx("span", {
                            className: "careers-card-unit",
                            children: m(a.unit),
                          }),
                        ],
                      }),
                    ],
                  }),
                },
              ),
            },
            a.id,
          ),
        ),
      }),
    ],
  });
}
function p({ career: r, link: s }) {
  return e.jsxs("article", {
    className: "careers",
    "data-careers-view": "career",
    "data-career": r.id,
    children: [
      e.jsx("div", {
        className: "career-hero",
        children: e.jsx(u, { career: r, className: "career-hero-scene" }),
      }),
      e.jsxs("div", {
        className: "career-body",
        children: [
          e.jsx("h1", {
            className: "careers-title career-reveal",
            children: r.title,
          }),
          e.jsx("p", {
            className: "career-hook career-reveal",
            children: r.hook,
          }),
          e.jsx(x, { career: r }),
          e.jsxs("div", {
            className: "career-actions",
            children: [
              s(
                { view: "quiz" },
                {
                  className: "careers-button careers-button-primary",
                  children: "Take the quiz",
                },
              ),
              s(
                { view: "hub" },
                { className: "careers-button", children: "All careers" },
              ),
            ],
          }),
        ],
      }),
    ],
  });
}
export { p as CareerProfile, j as CareersHub, A as CareersView };
