import { cn as b, U as f, ci as y } from "./index-CHiQZc8e.js";
const c = new Map();
function I(n) {
  let t = c.get(n);
  return (
    t ||
      ((t = (
        n.startsWith("brief:")
          ? u(n.slice(6))
          : n.startsWith("local:")
            ? d(n.slice(6))
            : Promise.resolve(null)
      )
        .then((e) => (e ? URL.createObjectURL(e) : null))
        .catch(() => null)),
      t.then((e) => {
        e || c.delete(n);
      }),
      c.set(n, t)),
    t
  );
}
async function R(n) {
  const t = n.startsWith("brief:")
    ? await u(n.slice(6))
    : n.startsWith("local:")
      ? await d(n.slice(6))
      : null;
  return t
    ? new Promise((e) => {
        const r = new FileReader();
        ((r.onload = () => e(typeof r.result == "string" ? r.result : null)),
          (r.onerror = () => e(null)),
          r.readAsDataURL(t));
      })
    : null;
}
async function u(n) {
  const t = await fetch(`${b}${n}`, {
      cache: "no-store",
      credentials: "same-origin",
      headers: f(),
    }),
    e = t.headers.get("content-type") ?? "";
  return t.ok && e.startsWith("image/") ? t.blob() : null;
}
const M = "comp-school-coursework-pictures",
  a = "pictures";
function h() {
  return new Promise((n, t) => {
    const e = indexedDB.open(M, 1);
    ((e.onupgradeneeded = () => e.result.createObjectStore(a)),
      (e.onsuccess = () => n(e.result)),
      (e.onerror = () => t(e.error)));
  });
}
async function d(n) {
  const t = await h();
  return new Promise((e) => {
    const r = t.transaction(a).objectStore(a).get(n);
    ((r.onsuccess = () => e(r.result instanceof Blob ? r.result : null)),
      (r.onerror = () => e(null)));
  });
}
const E = 1600;
async function B(n) {
  if (!n.type.startsWith("image/")) return null;
  const t = await createImageBitmap(n).catch(() => null);
  if (!t) return null;
  const e = Math.min(1, E / Math.max(t.width, t.height)),
    r = document.createElement("canvas");
  ((r.width = Math.max(1, Math.round(t.width * e))),
    (r.height = Math.max(1, Math.round(t.height * e))),
    r.getContext("2d")?.drawImage(t, 0, 0, r.width, r.height));
  const g = t.width / t.height;
  t.close();
  const m = n.type === "image/png" ? "image/png" : "image/jpeg",
    s = await new Promise((i) => r.toBlob(i, m, 0.85));
  if (!s) return null;
  const l = y("p")
      .toLowerCase()
      .replace(/[^a-z0-9]/g, "")
      .slice(0, 40),
    p = await h();
  return (
    await new Promise((i, w) => {
      const o = p.transaction(a, "readwrite");
      (o.objectStore(a).put(s, l),
        (o.oncomplete = () => i()),
        (o.onerror = () => w(o.error)));
    }),
    { src: `local:${l}`, ratio: g }
  );
}
function D(n) {
  return new Promise((t) => {
    const e = new Image();
    ((e.onload = () =>
      t(e.naturalHeight ? e.naturalWidth / e.naturalHeight : 4 / 3)),
      (e.onerror = () => t(4 / 3)),
      (e.src = n));
  });
}
export {
  B as addLocalPicture,
  R as pictureDataUrl,
  D as pictureRatio,
  I as pictureUrl,
};
