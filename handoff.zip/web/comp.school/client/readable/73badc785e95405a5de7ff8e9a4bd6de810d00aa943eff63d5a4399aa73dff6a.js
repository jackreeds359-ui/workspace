(function () {
  const u = document.createElement("link").relList;
  if (u && u.supports && u.supports("modulepreload")) return;
  for (const p of document.querySelectorAll('link[rel="modulepreload"]')) d(p);
  new MutationObserver((p) => {
    for (const y of p)
      if (y.type === "childList")
        for (const S of y.addedNodes)
          S.tagName === "LINK" && S.rel === "modulepreload" && d(S);
  }).observe(document, { childList: !0, subtree: !0 });
  function l(p) {
    const y = {};
    return (
      p.integrity && (y.integrity = p.integrity),
      p.referrerPolicy && (y.referrerPolicy = p.referrerPolicy),
      p.crossOrigin === "use-credentials"
        ? (y.credentials = "include")
        : p.crossOrigin === "anonymous"
          ? (y.credentials = "omit")
          : (y.credentials = "same-origin"),
      y
    );
  }
  function d(p) {
    if (p.ep) return;
    p.ep = !0;
    const y = l(p);
    fetch(p.href, y);
  }
})();
function Ed(i) {
  return i && i.__esModule && Object.prototype.hasOwnProperty.call(i, "default")
    ? i.default
    : i;
}
var is = { exports: {} },
  Kr = {},
  as = { exports: {} },
  oe = {};
/**
 * @license React
 * react.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var $c;
function am() {
  if ($c) return oe;
  $c = 1;
  var i = Symbol.for("react.element"),
    u = Symbol.for("react.portal"),
    l = Symbol.for("react.fragment"),
    d = Symbol.for("react.strict_mode"),
    p = Symbol.for("react.profiler"),
    y = Symbol.for("react.provider"),
    S = Symbol.for("react.context"),
    j = Symbol.for("react.forward_ref"),
    k = Symbol.for("react.suspense"),
    F = Symbol.for("react.memo"),
    L = Symbol.for("react.lazy"),
    D = Symbol.iterator;
  function O(h) {
    return h === null || typeof h != "object"
      ? null
      : ((h = (D && h[D]) || h["@@iterator"]),
        typeof h == "function" ? h : null);
  }
  var K = {
      isMounted: function () {
        return !1;
      },
      enqueueForceUpdate: function () {},
      enqueueReplaceState: function () {},
      enqueueSetState: function () {},
    },
    Q = Object.assign,
    M = {};
  function B(h, C, G) {
    ((this.props = h),
      (this.context = C),
      (this.refs = M),
      (this.updater = G || K));
  }
  ((B.prototype.isReactComponent = {}),
    (B.prototype.setState = function (h, C) {
      if (typeof h != "object" && typeof h != "function" && h != null)
        throw Error(
          "setState(...): takes an object of state variables to update or a function which returns an object of state variables.",
        );
      this.updater.enqueueSetState(this, h, C, "setState");
    }),
    (B.prototype.forceUpdate = function (h) {
      this.updater.enqueueForceUpdate(this, h, "forceUpdate");
    }));
  function V() {}
  V.prototype = B.prototype;
  function ie(h, C, G) {
    ((this.props = h),
      (this.context = C),
      (this.refs = M),
      (this.updater = G || K));
  }
  var J = (ie.prototype = new V());
  ((J.constructor = ie), Q(J, B.prototype), (J.isPureReactComponent = !0));
  var ee = Array.isArray,
    ge = Object.prototype.hasOwnProperty,
    fe = { current: null },
    re = { key: !0, ref: !0, __self: !0, __source: !0 };
  function ce(h, C, G) {
    var te,
      ae = {},
      le = null,
      we = null;
    if (C != null)
      for (te in (C.ref !== void 0 && (we = C.ref),
      C.key !== void 0 && (le = "" + C.key),
      C))
        ge.call(C, te) && !re.hasOwnProperty(te) && (ae[te] = C[te]);
    var ue = arguments.length - 2;
    if (ue === 1) ae.children = G;
    else if (1 < ue) {
      for (var Y = Array(ue), xe = 0; xe < ue; xe++) Y[xe] = arguments[xe + 2];
      ae.children = Y;
    }
    if (h && h.defaultProps)
      for (te in ((ue = h.defaultProps), ue))
        ae[te] === void 0 && (ae[te] = ue[te]);
    return {
      $$typeof: i,
      type: h,
      key: le,
      ref: we,
      props: ae,
      _owner: fe.current,
    };
  }
  function ke(h, C) {
    return {
      $$typeof: i,
      type: h.type,
      key: C,
      ref: h.ref,
      props: h.props,
      _owner: h._owner,
    };
  }
  function ve(h) {
    return typeof h == "object" && h !== null && h.$$typeof === i;
  }
  function ne(h) {
    var C = { "=": "=0", ":": "=2" };
    return (
      "$" +
      h.replace(/[=:]/g, function (G) {
        return C[G];
      })
    );
  }
  var Ce = /\/+/g;
  function pe(h, C) {
    return typeof h == "object" && h !== null && h.key != null
      ? ne("" + h.key)
      : C.toString(36);
  }
  function Se(h, C, G, te, ae) {
    var le = typeof h;
    (le === "undefined" || le === "boolean") && (h = null);
    var we = !1;
    if (h === null) we = !0;
    else
      switch (le) {
        case "string":
        case "number":
          we = !0;
          break;
        case "object":
          switch (h.$$typeof) {
            case i:
            case u:
              we = !0;
          }
      }
    if (we)
      return (
        (we = h),
        (ae = ae(we)),
        (h = te === "" ? "." + pe(we, 0) : te),
        ee(ae)
          ? ((G = ""),
            h != null && (G = h.replace(Ce, "$&/") + "/"),
            Se(ae, C, G, "", function (xe) {
              return xe;
            }))
          : ae != null &&
            (ve(ae) &&
              (ae = ke(
                ae,
                G +
                  (!ae.key || (we && we.key === ae.key)
                    ? ""
                    : ("" + ae.key).replace(Ce, "$&/") + "/") +
                  h,
              )),
            C.push(ae)),
        1
      );
    if (((we = 0), (te = te === "" ? "." : te + ":"), ee(h)))
      for (var ue = 0; ue < h.length; ue++) {
        le = h[ue];
        var Y = te + pe(le, ue);
        we += Se(le, C, G, Y, ae);
      }
    else if (((Y = O(h)), typeof Y == "function"))
      for (h = Y.call(h), ue = 0; !(le = h.next()).done;)
        ((le = le.value), (Y = te + pe(le, ue++)), (we += Se(le, C, G, Y, ae)));
    else if (le === "object")
      throw (
        (C = String(h)),
        Error(
          "Objects are not valid as a React child (found: " +
            (C === "[object Object]"
              ? "object with keys {" + Object.keys(h).join(", ") + "}"
              : C) +
            "). If you meant to render a collection of children, use an array instead.",
        )
      );
    return we;
  }
  function Ne(h, C, G) {
    if (h == null) return h;
    var te = [],
      ae = 0;
    return (
      Se(h, te, "", "", function (le) {
        return C.call(G, le, ae++);
      }),
      te
    );
  }
  function Ae(h) {
    if (h._status === -1) {
      var C = h._result;
      ((C = C()),
        C.then(
          function (G) {
            (h._status === 0 || h._status === -1) &&
              ((h._status = 1), (h._result = G));
          },
          function (G) {
            (h._status === 0 || h._status === -1) &&
              ((h._status = 2), (h._result = G));
          },
        ),
        h._status === -1 && ((h._status = 0), (h._result = C)));
    }
    if (h._status === 1) return h._result.default;
    throw h._result;
  }
  var he = { current: null },
    N = { transition: null },
    E = {
      ReactCurrentDispatcher: he,
      ReactCurrentBatchConfig: N,
      ReactCurrentOwner: fe,
    };
  function _() {
    throw Error("act(...) is not supported in production builds of React.");
  }
  return (
    (oe.Children = {
      map: Ne,
      forEach: function (h, C, G) {
        Ne(
          h,
          function () {
            C.apply(this, arguments);
          },
          G,
        );
      },
      count: function (h) {
        var C = 0;
        return (
          Ne(h, function () {
            C++;
          }),
          C
        );
      },
      toArray: function (h) {
        return (
          Ne(h, function (C) {
            return C;
          }) || []
        );
      },
      only: function (h) {
        if (!ve(h))
          throw Error(
            "React.Children.only expected to receive a single React element child.",
          );
        return h;
      },
    }),
    (oe.Component = B),
    (oe.Fragment = l),
    (oe.Profiler = p),
    (oe.PureComponent = ie),
    (oe.StrictMode = d),
    (oe.Suspense = k),
    (oe.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = E),
    (oe.act = _),
    (oe.cloneElement = function (h, C, G) {
      if (h == null)
        throw Error(
          "React.cloneElement(...): The argument must be a React element, but you passed " +
            h +
            ".",
        );
      var te = Q({}, h.props),
        ae = h.key,
        le = h.ref,
        we = h._owner;
      if (C != null) {
        if (
          (C.ref !== void 0 && ((le = C.ref), (we = fe.current)),
          C.key !== void 0 && (ae = "" + C.key),
          h.type && h.type.defaultProps)
        )
          var ue = h.type.defaultProps;
        for (Y in C)
          ge.call(C, Y) &&
            !re.hasOwnProperty(Y) &&
            (te[Y] = C[Y] === void 0 && ue !== void 0 ? ue[Y] : C[Y]);
      }
      var Y = arguments.length - 2;
      if (Y === 1) te.children = G;
      else if (1 < Y) {
        ue = Array(Y);
        for (var xe = 0; xe < Y; xe++) ue[xe] = arguments[xe + 2];
        te.children = ue;
      }
      return {
        $$typeof: i,
        type: h.type,
        key: ae,
        ref: le,
        props: te,
        _owner: we,
      };
    }),
    (oe.createContext = function (h) {
      return (
        (h = {
          $$typeof: S,
          _currentValue: h,
          _currentValue2: h,
          _threadCount: 0,
          Provider: null,
          Consumer: null,
          _defaultValue: null,
          _globalName: null,
        }),
        (h.Provider = { $$typeof: y, _context: h }),
        (h.Consumer = h)
      );
    }),
    (oe.createElement = ce),
    (oe.createFactory = function (h) {
      var C = ce.bind(null, h);
      return ((C.type = h), C);
    }),
    (oe.createRef = function () {
      return { current: null };
    }),
    (oe.forwardRef = function (h) {
      return { $$typeof: j, render: h };
    }),
    (oe.isValidElement = ve),
    (oe.lazy = function (h) {
      return { $$typeof: L, _payload: { _status: -1, _result: h }, _init: Ae };
    }),
    (oe.memo = function (h, C) {
      return { $$typeof: F, type: h, compare: C === void 0 ? null : C };
    }),
    (oe.startTransition = function (h) {
      var C = N.transition;
      N.transition = {};
      try {
        h();
      } finally {
        N.transition = C;
      }
    }),
    (oe.unstable_act = _),
    (oe.useCallback = function (h, C) {
      return he.current.useCallback(h, C);
    }),
    (oe.useContext = function (h) {
      return he.current.useContext(h);
    }),
    (oe.useDebugValue = function () {}),
    (oe.useDeferredValue = function (h) {
      return he.current.useDeferredValue(h);
    }),
    (oe.useEffect = function (h, C) {
      return he.current.useEffect(h, C);
    }),
    (oe.useId = function () {
      return he.current.useId();
    }),
    (oe.useImperativeHandle = function (h, C, G) {
      return he.current.useImperativeHandle(h, C, G);
    }),
    (oe.useInsertionEffect = function (h, C) {
      return he.current.useInsertionEffect(h, C);
    }),
    (oe.useLayoutEffect = function (h, C) {
      return he.current.useLayoutEffect(h, C);
    }),
    (oe.useMemo = function (h, C) {
      return he.current.useMemo(h, C);
    }),
    (oe.useReducer = function (h, C, G) {
      return he.current.useReducer(h, C, G);
    }),
    (oe.useRef = function (h) {
      return he.current.useRef(h);
    }),
    (oe.useState = function (h) {
      return he.current.useState(h);
    }),
    (oe.useSyncExternalStore = function (h, C, G) {
      return he.current.useSyncExternalStore(h, C, G);
    }),
    (oe.useTransition = function () {
      return he.current.useTransition();
    }),
    (oe.version = "18.3.1"),
    oe
  );
}
var Fc;
function Ds() {
  return (Fc || ((Fc = 1), (as.exports = am())), as.exports);
}
/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var Wc;
function sm() {
  if (Wc) return Kr;
  Wc = 1;
  var i = Ds(),
    u = Symbol.for("react.element"),
    l = Symbol.for("react.fragment"),
    d = Object.prototype.hasOwnProperty,
    p = i.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,
    y = { key: !0, ref: !0, __self: !0, __source: !0 };
  function S(j, k, F) {
    var L,
      D = {},
      O = null,
      K = null;
    (F !== void 0 && (O = "" + F),
      k.key !== void 0 && (O = "" + k.key),
      k.ref !== void 0 && (K = k.ref));
    for (L in k) d.call(k, L) && !y.hasOwnProperty(L) && (D[L] = k[L]);
    if (j && j.defaultProps)
      for (L in ((k = j.defaultProps), k)) D[L] === void 0 && (D[L] = k[L]);
    return {
      $$typeof: u,
      type: j,
      key: O,
      ref: K,
      props: D,
      _owner: p.current,
    };
  }
  return ((Kr.Fragment = l), (Kr.jsx = S), (Kr.jsxs = S), Kr);
}
var Bc;
function lm() {
  return (Bc || ((Bc = 1), (is.exports = sm())), is.exports);
}
var s = lm(),
  R = Ds();
const um = Ed(R);
var ai = {},
  ss = { exports: {} },
  at = {},
  ls = { exports: {} },
  us = {};
/**
 * @license React
 * scheduler.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var Hc;
function cm() {
  return (
    Hc ||
      ((Hc = 1),
      (function (i) {
        function u(N, E) {
          var _ = N.length;
          N.push(E);
          e: for (; 0 < _;) {
            var h = (_ - 1) >>> 1,
              C = N[h];
            if (0 < p(C, E)) ((N[h] = E), (N[_] = C), (_ = h));
            else break e;
          }
        }
        function l(N) {
          return N.length === 0 ? null : N[0];
        }
        function d(N) {
          if (N.length === 0) return null;
          var E = N[0],
            _ = N.pop();
          if (_ !== E) {
            N[0] = _;
            e: for (var h = 0, C = N.length, G = C >>> 1; h < G;) {
              var te = 2 * (h + 1) - 1,
                ae = N[te],
                le = te + 1,
                we = N[le];
              if (0 > p(ae, _))
                le < C && 0 > p(we, ae)
                  ? ((N[h] = we), (N[le] = _), (h = le))
                  : ((N[h] = ae), (N[te] = _), (h = te));
              else if (le < C && 0 > p(we, _))
                ((N[h] = we), (N[le] = _), (h = le));
              else break e;
            }
          }
          return E;
        }
        function p(N, E) {
          var _ = N.sortIndex - E.sortIndex;
          return _ !== 0 ? _ : N.id - E.id;
        }
        if (
          typeof performance == "object" &&
          typeof performance.now == "function"
        ) {
          var y = performance;
          i.unstable_now = function () {
            return y.now();
          };
        } else {
          var S = Date,
            j = S.now();
          i.unstable_now = function () {
            return S.now() - j;
          };
        }
        var k = [],
          F = [],
          L = 1,
          D = null,
          O = 3,
          K = !1,
          Q = !1,
          M = !1,
          B = typeof setTimeout == "function" ? setTimeout : null,
          V = typeof clearTimeout == "function" ? clearTimeout : null,
          ie = typeof setImmediate < "u" ? setImmediate : null;
        typeof navigator < "u" &&
          navigator.scheduling !== void 0 &&
          navigator.scheduling.isInputPending !== void 0 &&
          navigator.scheduling.isInputPending.bind(navigator.scheduling);
        function J(N) {
          for (var E = l(F); E !== null;) {
            if (E.callback === null) d(F);
            else if (E.startTime <= N)
              (d(F), (E.sortIndex = E.expirationTime), u(k, E));
            else break;
            E = l(F);
          }
        }
        function ee(N) {
          if (((M = !1), J(N), !Q))
            if (l(k) !== null) ((Q = !0), Ae(ge));
            else {
              var E = l(F);
              E !== null && he(ee, E.startTime - N);
            }
        }
        function ge(N, E) {
          ((Q = !1), M && ((M = !1), V(ce), (ce = -1)), (K = !0));
          var _ = O;
          try {
            for (
              J(E), D = l(k);
              D !== null && (!(D.expirationTime > E) || (N && !ne()));
            ) {
              var h = D.callback;
              if (typeof h == "function") {
                ((D.callback = null), (O = D.priorityLevel));
                var C = h(D.expirationTime <= E);
                ((E = i.unstable_now()),
                  typeof C == "function"
                    ? (D.callback = C)
                    : D === l(k) && d(k),
                  J(E));
              } else d(k);
              D = l(k);
            }
            if (D !== null) var G = !0;
            else {
              var te = l(F);
              (te !== null && he(ee, te.startTime - E), (G = !1));
            }
            return G;
          } finally {
            ((D = null), (O = _), (K = !1));
          }
        }
        var fe = !1,
          re = null,
          ce = -1,
          ke = 5,
          ve = -1;
        function ne() {
          return !(i.unstable_now() - ve < ke);
        }
        function Ce() {
          if (re !== null) {
            var N = i.unstable_now();
            ve = N;
            var E = !0;
            try {
              E = re(!0, N);
            } finally {
              E ? pe() : ((fe = !1), (re = null));
            }
          } else fe = !1;
        }
        var pe;
        if (typeof ie == "function")
          pe = function () {
            ie(Ce);
          };
        else if (typeof MessageChannel < "u") {
          var Se = new MessageChannel(),
            Ne = Se.port2;
          ((Se.port1.onmessage = Ce),
            (pe = function () {
              Ne.postMessage(null);
            }));
        } else
          pe = function () {
            B(Ce, 0);
          };
        function Ae(N) {
          ((re = N), fe || ((fe = !0), pe()));
        }
        function he(N, E) {
          ce = B(function () {
            N(i.unstable_now());
          }, E);
        }
        ((i.unstable_IdlePriority = 5),
          (i.unstable_ImmediatePriority = 1),
          (i.unstable_LowPriority = 4),
          (i.unstable_NormalPriority = 3),
          (i.unstable_Profiling = null),
          (i.unstable_UserBlockingPriority = 2),
          (i.unstable_cancelCallback = function (N) {
            N.callback = null;
          }),
          (i.unstable_continueExecution = function () {
            Q || K || ((Q = !0), Ae(ge));
          }),
          (i.unstable_forceFrameRate = function (N) {
            0 > N || 125 < N
              ? console.error(
                  "forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported",
                )
              : (ke = 0 < N ? Math.floor(1e3 / N) : 5);
          }),
          (i.unstable_getCurrentPriorityLevel = function () {
            return O;
          }),
          (i.unstable_getFirstCallbackNode = function () {
            return l(k);
          }),
          (i.unstable_next = function (N) {
            switch (O) {
              case 1:
              case 2:
              case 3:
                var E = 3;
                break;
              default:
                E = O;
            }
            var _ = O;
            O = E;
            try {
              return N();
            } finally {
              O = _;
            }
          }),
          (i.unstable_pauseExecution = function () {}),
          (i.unstable_requestPaint = function () {}),
          (i.unstable_runWithPriority = function (N, E) {
            switch (N) {
              case 1:
              case 2:
              case 3:
              case 4:
              case 5:
                break;
              default:
                N = 3;
            }
            var _ = O;
            O = N;
            try {
              return E();
            } finally {
              O = _;
            }
          }),
          (i.unstable_scheduleCallback = function (N, E, _) {
            var h = i.unstable_now();
            switch (
              (typeof _ == "object" && _ !== null
                ? ((_ = _.delay),
                  (_ = typeof _ == "number" && 0 < _ ? h + _ : h))
                : (_ = h),
              N)
            ) {
              case 1:
                var C = -1;
                break;
              case 2:
                C = 250;
                break;
              case 5:
                C = 1073741823;
                break;
              case 4:
                C = 1e4;
                break;
              default:
                C = 5e3;
            }
            return (
              (C = _ + C),
              (N = {
                id: L++,
                callback: E,
                priorityLevel: N,
                startTime: _,
                expirationTime: C,
                sortIndex: -1,
              }),
              _ > h
                ? ((N.sortIndex = _),
                  u(F, N),
                  l(k) === null &&
                    N === l(F) &&
                    (M ? (V(ce), (ce = -1)) : (M = !0), he(ee, _ - h)))
                : ((N.sortIndex = C), u(k, N), Q || K || ((Q = !0), Ae(ge))),
              N
            );
          }),
          (i.unstable_shouldYield = ne),
          (i.unstable_wrapCallback = function (N) {
            var E = O;
            return function () {
              var _ = O;
              O = E;
              try {
                return N.apply(this, arguments);
              } finally {
                O = _;
              }
            };
          }));
      })(us)),
    us
  );
}
var Vc;
function dm() {
  return (Vc || ((Vc = 1), (ls.exports = cm())), ls.exports);
}
/**
 * @license React
 * react-dom.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var Jc;
function fm() {
  if (Jc) return at;
  Jc = 1;
  var i = Ds(),
    u = dm();
  function l(e) {
    for (
      var t = "https://reactjs.org/docs/error-decoder.html?invariant=" + e,
        n = 1;
      n < arguments.length;
      n++
    )
      t += "&args[]=" + encodeURIComponent(arguments[n]);
    return (
      "Minified React error #" +
      e +
      "; visit " +
      t +
      " for the full message or use the non-minified dev environment for full errors and additional helpful warnings."
    );
  }
  var d = new Set(),
    p = {};
  function y(e, t) {
    (S(e, t), S(e + "Capture", t));
  }
  function S(e, t) {
    for (p[e] = t, e = 0; e < t.length; e++) d.add(t[e]);
  }
  var j = !(
      typeof window > "u" ||
      typeof window.document > "u" ||
      typeof window.document.createElement > "u"
    ),
    k = Object.prototype.hasOwnProperty,
    F =
      /^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/,
    L = {},
    D = {};
  function O(e) {
    return k.call(D, e)
      ? !0
      : k.call(L, e)
        ? !1
        : F.test(e)
          ? (D[e] = !0)
          : ((L[e] = !0), !1);
  }
  function K(e, t, n, r) {
    if (n !== null && n.type === 0) return !1;
    switch (typeof t) {
      case "function":
      case "symbol":
        return !0;
      case "boolean":
        return r
          ? !1
          : n !== null
            ? !n.acceptsBooleans
            : ((e = e.toLowerCase().slice(0, 5)),
              e !== "data-" && e !== "aria-");
      default:
        return !1;
    }
  }
  function Q(e, t, n, r) {
    if (t === null || typeof t > "u" || K(e, t, n, r)) return !0;
    if (r) return !1;
    if (n !== null)
      switch (n.type) {
        case 3:
          return !t;
        case 4:
          return t === !1;
        case 5:
          return isNaN(t);
        case 6:
          return isNaN(t) || 1 > t;
      }
    return !1;
  }
  function M(e, t, n, r, o, a, c) {
    ((this.acceptsBooleans = t === 2 || t === 3 || t === 4),
      (this.attributeName = r),
      (this.attributeNamespace = o),
      (this.mustUseProperty = n),
      (this.propertyName = e),
      (this.type = t),
      (this.sanitizeURL = a),
      (this.removeEmptyString = c));
  }
  var B = {};
  ("children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style"
    .split(" ")
    .forEach(function (e) {
      B[e] = new M(e, 0, !1, e, null, !1, !1);
    }),
    [
      ["acceptCharset", "accept-charset"],
      ["className", "class"],
      ["htmlFor", "for"],
      ["httpEquiv", "http-equiv"],
    ].forEach(function (e) {
      var t = e[0];
      B[t] = new M(t, 1, !1, e[1], null, !1, !1);
    }),
    ["contentEditable", "draggable", "spellCheck", "value"].forEach(
      function (e) {
        B[e] = new M(e, 2, !1, e.toLowerCase(), null, !1, !1);
      },
    ),
    [
      "autoReverse",
      "externalResourcesRequired",
      "focusable",
      "preserveAlpha",
    ].forEach(function (e) {
      B[e] = new M(e, 2, !1, e, null, !1, !1);
    }),
    "allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope"
      .split(" ")
      .forEach(function (e) {
        B[e] = new M(e, 3, !1, e.toLowerCase(), null, !1, !1);
      }),
    ["checked", "multiple", "muted", "selected"].forEach(function (e) {
      B[e] = new M(e, 3, !0, e, null, !1, !1);
    }),
    ["capture", "download"].forEach(function (e) {
      B[e] = new M(e, 4, !1, e, null, !1, !1);
    }),
    ["cols", "rows", "size", "span"].forEach(function (e) {
      B[e] = new M(e, 6, !1, e, null, !1, !1);
    }),
    ["rowSpan", "start"].forEach(function (e) {
      B[e] = new M(e, 5, !1, e.toLowerCase(), null, !1, !1);
    }));
  var V = /[\-:]([a-z])/g;
  function ie(e) {
    return e[1].toUpperCase();
  }
  ("accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height"
    .split(" ")
    .forEach(function (e) {
      var t = e.replace(V, ie);
      B[t] = new M(t, 1, !1, e, null, !1, !1);
    }),
    "xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type"
      .split(" ")
      .forEach(function (e) {
        var t = e.replace(V, ie);
        B[t] = new M(t, 1, !1, e, "http://www.w3.org/1999/xlink", !1, !1);
      }),
    ["xml:base", "xml:lang", "xml:space"].forEach(function (e) {
      var t = e.replace(V, ie);
      B[t] = new M(t, 1, !1, e, "http://www.w3.org/XML/1998/namespace", !1, !1);
    }),
    ["tabIndex", "crossOrigin"].forEach(function (e) {
      B[e] = new M(e, 1, !1, e.toLowerCase(), null, !1, !1);
    }),
    (B.xlinkHref = new M(
      "xlinkHref",
      1,
      !1,
      "xlink:href",
      "http://www.w3.org/1999/xlink",
      !0,
      !1,
    )),
    ["src", "href", "action", "formAction"].forEach(function (e) {
      B[e] = new M(e, 1, !1, e.toLowerCase(), null, !0, !0);
    }));
  function J(e, t, n, r) {
    var o = B.hasOwnProperty(t) ? B[t] : null;
    (o !== null
      ? o.type !== 0
      : r ||
        !(2 < t.length) ||
        (t[0] !== "o" && t[0] !== "O") ||
        (t[1] !== "n" && t[1] !== "N")) &&
      (Q(t, n, o, r) && (n = null),
      r || o === null
        ? O(t) &&
          (n === null ? e.removeAttribute(t) : e.setAttribute(t, "" + n))
        : o.mustUseProperty
          ? (e[o.propertyName] = n === null ? (o.type === 3 ? !1 : "") : n)
          : ((t = o.attributeName),
            (r = o.attributeNamespace),
            n === null
              ? e.removeAttribute(t)
              : ((o = o.type),
                (n = o === 3 || (o === 4 && n === !0) ? "" : "" + n),
                r ? e.setAttributeNS(r, t, n) : e.setAttribute(t, n))));
  }
  var ee = i.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED,
    ge = Symbol.for("react.element"),
    fe = Symbol.for("react.portal"),
    re = Symbol.for("react.fragment"),
    ce = Symbol.for("react.strict_mode"),
    ke = Symbol.for("react.profiler"),
    ve = Symbol.for("react.provider"),
    ne = Symbol.for("react.context"),
    Ce = Symbol.for("react.forward_ref"),
    pe = Symbol.for("react.suspense"),
    Se = Symbol.for("react.suspense_list"),
    Ne = Symbol.for("react.memo"),
    Ae = Symbol.for("react.lazy"),
    he = Symbol.for("react.offscreen"),
    N = Symbol.iterator;
  function E(e) {
    return e === null || typeof e != "object"
      ? null
      : ((e = (N && e[N]) || e["@@iterator"]),
        typeof e == "function" ? e : null);
  }
  var _ = Object.assign,
    h;
  function C(e) {
    if (h === void 0)
      try {
        throw Error();
      } catch (n) {
        var t = n.stack.trim().match(/\n( *(at )?)/);
        h = (t && t[1]) || "";
      }
    return (
      `
` +
      h +
      e
    );
  }
  var G = !1;
  function te(e, t) {
    if (!e || G) return "";
    G = !0;
    var n = Error.prepareStackTrace;
    Error.prepareStackTrace = void 0;
    try {
      if (t)
        if (
          ((t = function () {
            throw Error();
          }),
          Object.defineProperty(t.prototype, "props", {
            set: function () {
              throw Error();
            },
          }),
          typeof Reflect == "object" && Reflect.construct)
        ) {
          try {
            Reflect.construct(t, []);
          } catch (x) {
            var r = x;
          }
          Reflect.construct(e, [], t);
        } else {
          try {
            t.call();
          } catch (x) {
            r = x;
          }
          e.call(t.prototype);
        }
      else {
        try {
          throw Error();
        } catch (x) {
          r = x;
        }
        e();
      }
    } catch (x) {
      if (x && r && typeof x.stack == "string") {
        for (
          var o = x.stack.split(`
`),
            a = r.stack.split(`
`),
            c = o.length - 1,
            f = a.length - 1;
          1 <= c && 0 <= f && o[c] !== a[f];
        )
          f--;
        for (; 1 <= c && 0 <= f; c--, f--)
          if (o[c] !== a[f]) {
            if (c !== 1 || f !== 1)
              do
                if ((c--, f--, 0 > f || o[c] !== a[f])) {
                  var m =
                    `
` + o[c].replace(" at new ", " at ");
                  return (
                    e.displayName &&
                      m.includes("<anonymous>") &&
                      (m = m.replace("<anonymous>", e.displayName)),
                    m
                  );
                }
              while (1 <= c && 0 <= f);
            break;
          }
      }
    } finally {
      ((G = !1), (Error.prepareStackTrace = n));
    }
    return (e = e ? e.displayName || e.name : "") ? C(e) : "";
  }
  function ae(e) {
    switch (e.tag) {
      case 5:
        return C(e.type);
      case 16:
        return C("Lazy");
      case 13:
        return C("Suspense");
      case 19:
        return C("SuspenseList");
      case 0:
      case 2:
      case 15:
        return ((e = te(e.type, !1)), e);
      case 11:
        return ((e = te(e.type.render, !1)), e);
      case 1:
        return ((e = te(e.type, !0)), e);
      default:
        return "";
    }
  }
  function le(e) {
    if (e == null) return null;
    if (typeof e == "function") return e.displayName || e.name || null;
    if (typeof e == "string") return e;
    switch (e) {
      case re:
        return "Fragment";
      case fe:
        return "Portal";
      case ke:
        return "Profiler";
      case ce:
        return "StrictMode";
      case pe:
        return "Suspense";
      case Se:
        return "SuspenseList";
    }
    if (typeof e == "object")
      switch (e.$$typeof) {
        case ne:
          return (e.displayName || "Context") + ".Consumer";
        case ve:
          return (e._context.displayName || "Context") + ".Provider";
        case Ce:
          var t = e.render;
          return (
            (e = e.displayName),
            e ||
              ((e = t.displayName || t.name || ""),
              (e = e !== "" ? "ForwardRef(" + e + ")" : "ForwardRef")),
            e
          );
        case Ne:
          return (
            (t = e.displayName || null),
            t !== null ? t : le(e.type) || "Memo"
          );
        case Ae:
          ((t = e._payload), (e = e._init));
          try {
            return le(e(t));
          } catch {}
      }
    return null;
  }
  function we(e) {
    var t = e.type;
    switch (e.tag) {
      case 24:
        return "Cache";
      case 9:
        return (t.displayName || "Context") + ".Consumer";
      case 10:
        return (t._context.displayName || "Context") + ".Provider";
      case 18:
        return "DehydratedFragment";
      case 11:
        return (
          (e = t.render),
          (e = e.displayName || e.name || ""),
          t.displayName || (e !== "" ? "ForwardRef(" + e + ")" : "ForwardRef")
        );
      case 7:
        return "Fragment";
      case 5:
        return t;
      case 4:
        return "Portal";
      case 3:
        return "Root";
      case 6:
        return "Text";
      case 16:
        return le(t);
      case 8:
        return t === ce ? "StrictMode" : "Mode";
      case 22:
        return "Offscreen";
      case 12:
        return "Profiler";
      case 21:
        return "Scope";
      case 13:
        return "Suspense";
      case 19:
        return "SuspenseList";
      case 25:
        return "TracingMarker";
      case 1:
      case 0:
      case 17:
      case 2:
      case 14:
      case 15:
        if (typeof t == "function") return t.displayName || t.name || null;
        if (typeof t == "string") return t;
    }
    return null;
  }
  function ue(e) {
    switch (typeof e) {
      case "boolean":
      case "number":
      case "string":
      case "undefined":
        return e;
      case "object":
        return e;
      default:
        return "";
    }
  }
  function Y(e) {
    var t = e.type;
    return (
      (e = e.nodeName) &&
      e.toLowerCase() === "input" &&
      (t === "checkbox" || t === "radio")
    );
  }
  function xe(e) {
    var t = Y(e) ? "checked" : "value",
      n = Object.getOwnPropertyDescriptor(e.constructor.prototype, t),
      r = "" + e[t];
    if (
      !e.hasOwnProperty(t) &&
      typeof n < "u" &&
      typeof n.get == "function" &&
      typeof n.set == "function"
    ) {
      var o = n.get,
        a = n.set;
      return (
        Object.defineProperty(e, t, {
          configurable: !0,
          get: function () {
            return o.call(this);
          },
          set: function (c) {
            ((r = "" + c), a.call(this, c));
          },
        }),
        Object.defineProperty(e, t, { enumerable: n.enumerable }),
        {
          getValue: function () {
            return r;
          },
          setValue: function (c) {
            r = "" + c;
          },
          stopTracking: function () {
            ((e._valueTracker = null), delete e[t]);
          },
        }
      );
    }
  }
  function qe(e) {
    e._valueTracker || (e._valueTracker = xe(e));
  }
  function He(e) {
    if (!e) return !1;
    var t = e._valueTracker;
    if (!t) return !0;
    var n = t.getValue(),
      r = "";
    return (
      e && (r = Y(e) ? (e.checked ? "true" : "false") : e.value),
      (e = r),
      e !== n ? (t.setValue(e), !0) : !1
    );
  }
  function Pe(e) {
    if (
      ((e = e || (typeof document < "u" ? document : void 0)), typeof e > "u")
    )
      return null;
    try {
      return e.activeElement || e.body;
    } catch {
      return e.body;
    }
  }
  function Lt(e, t) {
    var n = t.checked;
    return _({}, t, {
      defaultChecked: void 0,
      defaultValue: void 0,
      value: void 0,
      checked: n ?? e._wrapperState.initialChecked,
    });
  }
  function et(e, t) {
    var n = t.defaultValue == null ? "" : t.defaultValue,
      r = t.checked != null ? t.checked : t.defaultChecked;
    ((n = ue(t.value != null ? t.value : n)),
      (e._wrapperState = {
        initialChecked: r,
        initialValue: n,
        controlled:
          t.type === "checkbox" || t.type === "radio"
            ? t.checked != null
            : t.value != null,
      }));
  }
  function Rt(e, t) {
    ((t = t.checked), t != null && J(e, "checked", t, !1));
  }
  function sr(e, t) {
    Rt(e, t);
    var n = ue(t.value),
      r = t.type;
    if (n != null)
      r === "number"
        ? ((n === 0 && e.value === "") || e.value != n) && (e.value = "" + n)
        : e.value !== "" + n && (e.value = "" + n);
    else if (r === "submit" || r === "reset") {
      e.removeAttribute("value");
      return;
    }
    (t.hasOwnProperty("value")
      ? mi(e, t.type, n)
      : t.hasOwnProperty("defaultValue") && mi(e, t.type, ue(t.defaultValue)),
      t.checked == null &&
        t.defaultChecked != null &&
        (e.defaultChecked = !!t.defaultChecked));
  }
  function Gs(e, t, n) {
    if (t.hasOwnProperty("value") || t.hasOwnProperty("defaultValue")) {
      var r = t.type;
      if (!(
        (r !== "submit" && r !== "reset") ||
        (t.value !== void 0 && t.value !== null)
      ))
        return;
      ((t = "" + e._wrapperState.initialValue),
        n || t === e.value || (e.value = t),
        (e.defaultValue = t));
    }
    ((n = e.name),
      n !== "" && (e.name = ""),
      (e.defaultChecked = !!e._wrapperState.initialChecked),
      n !== "" && (e.name = n));
  }
  function mi(e, t, n) {
    (t !== "number" || Pe(e.ownerDocument) !== e) &&
      (n == null
        ? (e.defaultValue = "" + e._wrapperState.initialValue)
        : e.defaultValue !== "" + n && (e.defaultValue = "" + n));
  }
  var lr = Array.isArray;
  function Rn(e, t, n, r) {
    if (((e = e.options), t)) {
      t = {};
      for (var o = 0; o < n.length; o++) t["$" + n[o]] = !0;
      for (n = 0; n < e.length; n++)
        ((o = t.hasOwnProperty("$" + e[n].value)),
          e[n].selected !== o && (e[n].selected = o),
          o && r && (e[n].defaultSelected = !0));
    } else {
      for (n = "" + ue(n), t = null, o = 0; o < e.length; o++) {
        if (e[o].value === n) {
          ((e[o].selected = !0), r && (e[o].defaultSelected = !0));
          return;
        }
        t !== null || e[o].disabled || (t = e[o]);
      }
      t !== null && (t.selected = !0);
    }
  }
  function hi(e, t) {
    if (t.dangerouslySetInnerHTML != null) throw Error(l(91));
    return _({}, t, {
      value: void 0,
      defaultValue: void 0,
      children: "" + e._wrapperState.initialValue,
    });
  }
  function Zs(e, t) {
    var n = t.value;
    if (n == null) {
      if (((n = t.children), (t = t.defaultValue), n != null)) {
        if (t != null) throw Error(l(92));
        if (lr(n)) {
          if (1 < n.length) throw Error(l(93));
          n = n[0];
        }
        t = n;
      }
      (t == null && (t = ""), (n = t));
    }
    e._wrapperState = { initialValue: ue(n) };
  }
  function qs(e, t) {
    var n = ue(t.value),
      r = ue(t.defaultValue);
    (n != null &&
      ((n = "" + n),
      n !== e.value && (e.value = n),
      t.defaultValue == null && e.defaultValue !== n && (e.defaultValue = n)),
      r != null && (e.defaultValue = "" + r));
  }
  function Ys(e) {
    var t = e.textContent;
    t === e._wrapperState.initialValue &&
      t !== "" &&
      t !== null &&
      (e.value = t);
  }
  function Xs(e) {
    switch (e) {
      case "svg":
        return "http://www.w3.org/2000/svg";
      case "math":
        return "http://www.w3.org/1998/Math/MathML";
      default:
        return "http://www.w3.org/1999/xhtml";
    }
  }
  function gi(e, t) {
    return e == null || e === "http://www.w3.org/1999/xhtml"
      ? Xs(t)
      : e === "http://www.w3.org/2000/svg" && t === "foreignObject"
        ? "http://www.w3.org/1999/xhtml"
        : e;
  }
  var qr,
    el = (function (e) {
      return typeof MSApp < "u" && MSApp.execUnsafeLocalFunction
        ? function (t, n, r, o) {
            MSApp.execUnsafeLocalFunction(function () {
              return e(t, n, r, o);
            });
          }
        : e;
    })(function (e, t) {
      if (e.namespaceURI !== "http://www.w3.org/2000/svg" || "innerHTML" in e)
        e.innerHTML = t;
      else {
        for (
          qr = qr || document.createElement("div"),
            qr.innerHTML = "<svg>" + t.valueOf().toString() + "</svg>",
            t = qr.firstChild;
          e.firstChild;
        )
          e.removeChild(e.firstChild);
        for (; t.firstChild;) e.appendChild(t.firstChild);
      }
    });
  function ur(e, t) {
    if (t) {
      var n = e.firstChild;
      if (n && n === e.lastChild && n.nodeType === 3) {
        n.nodeValue = t;
        return;
      }
    }
    e.textContent = t;
  }
  var cr = {
      animationIterationCount: !0,
      aspectRatio: !0,
      borderImageOutset: !0,
      borderImageSlice: !0,
      borderImageWidth: !0,
      boxFlex: !0,
      boxFlexGroup: !0,
      boxOrdinalGroup: !0,
      columnCount: !0,
      columns: !0,
      flex: !0,
      flexGrow: !0,
      flexPositive: !0,
      flexShrink: !0,
      flexNegative: !0,
      flexOrder: !0,
      gridArea: !0,
      gridRow: !0,
      gridRowEnd: !0,
      gridRowSpan: !0,
      gridRowStart: !0,
      gridColumn: !0,
      gridColumnEnd: !0,
      gridColumnSpan: !0,
      gridColumnStart: !0,
      fontWeight: !0,
      lineClamp: !0,
      lineHeight: !0,
      opacity: !0,
      order: !0,
      orphans: !0,
      tabSize: !0,
      widows: !0,
      zIndex: !0,
      zoom: !0,
      fillOpacity: !0,
      floodOpacity: !0,
      stopOpacity: !0,
      strokeDasharray: !0,
      strokeDashoffset: !0,
      strokeMiterlimit: !0,
      strokeOpacity: !0,
      strokeWidth: !0,
    },
    cf = ["Webkit", "ms", "Moz", "O"];
  Object.keys(cr).forEach(function (e) {
    cf.forEach(function (t) {
      ((t = t + e.charAt(0).toUpperCase() + e.substring(1)), (cr[t] = cr[e]));
    });
  });
  function tl(e, t, n) {
    return t == null || typeof t == "boolean" || t === ""
      ? ""
      : n || typeof t != "number" || t === 0 || (cr.hasOwnProperty(e) && cr[e])
        ? ("" + t).trim()
        : t + "px";
  }
  function nl(e, t) {
    e = e.style;
    for (var n in t)
      if (t.hasOwnProperty(n)) {
        var r = n.indexOf("--") === 0,
          o = tl(n, t[n], r);
        (n === "float" && (n = "cssFloat"),
          r ? e.setProperty(n, o) : (e[n] = o));
      }
  }
  var df = _(
    { menuitem: !0 },
    {
      area: !0,
      base: !0,
      br: !0,
      col: !0,
      embed: !0,
      hr: !0,
      img: !0,
      input: !0,
      keygen: !0,
      link: !0,
      meta: !0,
      param: !0,
      source: !0,
      track: !0,
      wbr: !0,
    },
  );
  function yi(e, t) {
    if (t) {
      if (df[e] && (t.children != null || t.dangerouslySetInnerHTML != null))
        throw Error(l(137, e));
      if (t.dangerouslySetInnerHTML != null) {
        if (t.children != null) throw Error(l(60));
        if (
          typeof t.dangerouslySetInnerHTML != "object" ||
          !("__html" in t.dangerouslySetInnerHTML)
        )
          throw Error(l(61));
      }
      if (t.style != null && typeof t.style != "object") throw Error(l(62));
    }
  }
  function vi(e, t) {
    if (e.indexOf("-") === -1) return typeof t.is == "string";
    switch (e) {
      case "annotation-xml":
      case "color-profile":
      case "font-face":
      case "font-face-src":
      case "font-face-uri":
      case "font-face-format":
      case "font-face-name":
      case "missing-glyph":
        return !1;
      default:
        return !0;
    }
  }
  var wi = null;
  function xi(e) {
    return (
      (e = e.target || e.srcElement || window),
      e.correspondingUseElement && (e = e.correspondingUseElement),
      e.nodeType === 3 ? e.parentNode : e
    );
  }
  var ki = null,
    On = null,
    Nn = null;
  function rl(e) {
    if ((e = Mr(e))) {
      if (typeof ki != "function") throw Error(l(280));
      var t = e.stateNode;
      t && ((t = ko(t)), ki(e.stateNode, e.type, t));
    }
  }
  function ol(e) {
    On ? (Nn ? Nn.push(e) : (Nn = [e])) : (On = e);
  }
  function il() {
    if (On) {
      var e = On,
        t = Nn;
      if (((Nn = On = null), rl(e), t)) for (e = 0; e < t.length; e++) rl(t[e]);
    }
  }
  function al(e, t) {
    return e(t);
  }
  function sl() {}
  var Si = !1;
  function ll(e, t, n) {
    if (Si) return e(t, n);
    Si = !0;
    try {
      return al(e, t, n);
    } finally {
      ((Si = !1), (On !== null || Nn !== null) && (sl(), il()));
    }
  }
  function dr(e, t) {
    var n = e.stateNode;
    if (n === null) return null;
    var r = ko(n);
    if (r === null) return null;
    n = r[t];
    e: switch (t) {
      case "onClick":
      case "onClickCapture":
      case "onDoubleClick":
      case "onDoubleClickCapture":
      case "onMouseDown":
      case "onMouseDownCapture":
      case "onMouseMove":
      case "onMouseMoveCapture":
      case "onMouseUp":
      case "onMouseUpCapture":
      case "onMouseEnter":
        ((r = !r.disabled) ||
          ((e = e.type),
          (r = !(
            e === "button" ||
            e === "input" ||
            e === "select" ||
            e === "textarea"
          ))),
          (e = !r));
        break e;
      default:
        e = !1;
    }
    if (e) return null;
    if (n && typeof n != "function") throw Error(l(231, t, typeof n));
    return n;
  }
  var Ci = !1;
  if (j)
    try {
      var fr = {};
      (Object.defineProperty(fr, "passive", {
        get: function () {
          Ci = !0;
        },
      }),
        window.addEventListener("test", fr, fr),
        window.removeEventListener("test", fr, fr));
    } catch {
      Ci = !1;
    }
  function ff(e, t, n, r, o, a, c, f, m) {
    var x = Array.prototype.slice.call(arguments, 3);
    try {
      t.apply(n, x);
    } catch (P) {
      this.onError(P);
    }
  }
  var pr = !1,
    Yr = null,
    Xr = !1,
    bi = null,
    pf = {
      onError: function (e) {
        ((pr = !0), (Yr = e));
      },
    };
  function mf(e, t, n, r, o, a, c, f, m) {
    ((pr = !1), (Yr = null), ff.apply(pf, arguments));
  }
  function hf(e, t, n, r, o, a, c, f, m) {
    if ((mf.apply(this, arguments), pr)) {
      if (pr) {
        var x = Yr;
        ((pr = !1), (Yr = null));
      } else throw Error(l(198));
      Xr || ((Xr = !0), (bi = x));
    }
  }
  function hn(e) {
    var t = e,
      n = e;
    if (e.alternate) for (; t.return;) t = t.return;
    else {
      e = t;
      do ((t = e), (t.flags & 4098) !== 0 && (n = t.return), (e = t.return));
      while (e);
    }
    return t.tag === 3 ? n : null;
  }
  function ul(e) {
    if (e.tag === 13) {
      var t = e.memoizedState;
      if (
        (t === null && ((e = e.alternate), e !== null && (t = e.memoizedState)),
        t !== null)
      )
        return t.dehydrated;
    }
    return null;
  }
  function cl(e) {
    if (hn(e) !== e) throw Error(l(188));
  }
  function gf(e) {
    var t = e.alternate;
    if (!t) {
      if (((t = hn(e)), t === null)) throw Error(l(188));
      return t !== e ? null : e;
    }
    for (var n = e, r = t; ;) {
      var o = n.return;
      if (o === null) break;
      var a = o.alternate;
      if (a === null) {
        if (((r = o.return), r !== null)) {
          n = r;
          continue;
        }
        break;
      }
      if (o.child === a.child) {
        for (a = o.child; a;) {
          if (a === n) return (cl(o), e);
          if (a === r) return (cl(o), t);
          a = a.sibling;
        }
        throw Error(l(188));
      }
      if (n.return !== r.return) ((n = o), (r = a));
      else {
        for (var c = !1, f = o.child; f;) {
          if (f === n) {
            ((c = !0), (n = o), (r = a));
            break;
          }
          if (f === r) {
            ((c = !0), (r = o), (n = a));
            break;
          }
          f = f.sibling;
        }
        if (!c) {
          for (f = a.child; f;) {
            if (f === n) {
              ((c = !0), (n = a), (r = o));
              break;
            }
            if (f === r) {
              ((c = !0), (r = a), (n = o));
              break;
            }
            f = f.sibling;
          }
          if (!c) throw Error(l(189));
        }
      }
      if (n.alternate !== r) throw Error(l(190));
    }
    if (n.tag !== 3) throw Error(l(188));
    return n.stateNode.current === n ? e : t;
  }
  function dl(e) {
    return ((e = gf(e)), e !== null ? fl(e) : null);
  }
  function fl(e) {
    if (e.tag === 5 || e.tag === 6) return e;
    for (e = e.child; e !== null;) {
      var t = fl(e);
      if (t !== null) return t;
      e = e.sibling;
    }
    return null;
  }
  var pl = u.unstable_scheduleCallback,
    ml = u.unstable_cancelCallback,
    yf = u.unstable_shouldYield,
    vf = u.unstable_requestPaint,
    Re = u.unstable_now,
    wf = u.unstable_getCurrentPriorityLevel,
    _i = u.unstable_ImmediatePriority,
    hl = u.unstable_UserBlockingPriority,
    eo = u.unstable_NormalPriority,
    xf = u.unstable_LowPriority,
    gl = u.unstable_IdlePriority,
    to = null,
    At = null;
  function kf(e) {
    if (At && typeof At.onCommitFiberRoot == "function")
      try {
        At.onCommitFiberRoot(to, e, void 0, (e.current.flags & 128) === 128);
      } catch {}
  }
  var xt = Math.clz32 ? Math.clz32 : bf,
    Sf = Math.log,
    Cf = Math.LN2;
  function bf(e) {
    return ((e >>>= 0), e === 0 ? 32 : (31 - ((Sf(e) / Cf) | 0)) | 0);
  }
  var no = 64,
    ro = 4194304;
  function mr(e) {
    switch (e & -e) {
      case 1:
        return 1;
      case 2:
        return 2;
      case 4:
        return 4;
      case 8:
        return 8;
      case 16:
        return 16;
      case 32:
        return 32;
      case 64:
      case 128:
      case 256:
      case 512:
      case 1024:
      case 2048:
      case 4096:
      case 8192:
      case 16384:
      case 32768:
      case 65536:
      case 131072:
      case 262144:
      case 524288:
      case 1048576:
      case 2097152:
        return e & 4194240;
      case 4194304:
      case 8388608:
      case 16777216:
      case 33554432:
      case 67108864:
        return e & 130023424;
      case 134217728:
        return 134217728;
      case 268435456:
        return 268435456;
      case 536870912:
        return 536870912;
      case 1073741824:
        return 1073741824;
      default:
        return e;
    }
  }
  function oo(e, t) {
    var n = e.pendingLanes;
    if (n === 0) return 0;
    var r = 0,
      o = e.suspendedLanes,
      a = e.pingedLanes,
      c = n & 268435455;
    if (c !== 0) {
      var f = c & ~o;
      f !== 0 ? (r = mr(f)) : ((a &= c), a !== 0 && (r = mr(a)));
    } else ((c = n & ~o), c !== 0 ? (r = mr(c)) : a !== 0 && (r = mr(a)));
    if (r === 0) return 0;
    if (
      t !== 0 &&
      t !== r &&
      (t & o) === 0 &&
      ((o = r & -r), (a = t & -t), o >= a || (o === 16 && (a & 4194240) !== 0))
    )
      return t;
    if (((r & 4) !== 0 && (r |= n & 16), (t = e.entangledLanes), t !== 0))
      for (e = e.entanglements, t &= r; 0 < t;)
        ((n = 31 - xt(t)), (o = 1 << n), (r |= e[n]), (t &= ~o));
    return r;
  }
  function _f(e, t) {
    switch (e) {
      case 1:
      case 2:
      case 4:
        return t + 250;
      case 8:
      case 16:
      case 32:
      case 64:
      case 128:
      case 256:
      case 512:
      case 1024:
      case 2048:
      case 4096:
      case 8192:
      case 16384:
      case 32768:
      case 65536:
      case 131072:
      case 262144:
      case 524288:
      case 1048576:
      case 2097152:
        return t + 5e3;
      case 4194304:
      case 8388608:
      case 16777216:
      case 33554432:
      case 67108864:
        return -1;
      case 134217728:
      case 268435456:
      case 536870912:
      case 1073741824:
        return -1;
      default:
        return -1;
    }
  }
  function jf(e, t) {
    for (
      var n = e.suspendedLanes,
        r = e.pingedLanes,
        o = e.expirationTimes,
        a = e.pendingLanes;
      0 < a;
    ) {
      var c = 31 - xt(a),
        f = 1 << c,
        m = o[c];
      (m === -1
        ? ((f & n) === 0 || (f & r) !== 0) && (o[c] = _f(f, t))
        : m <= t && (e.expiredLanes |= f),
        (a &= ~f));
    }
  }
  function ji(e) {
    return (
      (e = e.pendingLanes & -1073741825),
      e !== 0 ? e : e & 1073741824 ? 1073741824 : 0
    );
  }
  function yl() {
    var e = no;
    return ((no <<= 1), (no & 4194240) === 0 && (no = 64), e);
  }
  function Ei(e) {
    for (var t = [], n = 0; 31 > n; n++) t.push(e);
    return t;
  }
  function hr(e, t, n) {
    ((e.pendingLanes |= t),
      t !== 536870912 && ((e.suspendedLanes = 0), (e.pingedLanes = 0)),
      (e = e.eventTimes),
      (t = 31 - xt(t)),
      (e[t] = n));
  }
  function Ef(e, t) {
    var n = e.pendingLanes & ~t;
    ((e.pendingLanes = t),
      (e.suspendedLanes = 0),
      (e.pingedLanes = 0),
      (e.expiredLanes &= t),
      (e.mutableReadLanes &= t),
      (e.entangledLanes &= t),
      (t = e.entanglements));
    var r = e.eventTimes;
    for (e = e.expirationTimes; 0 < n;) {
      var o = 31 - xt(n),
        a = 1 << o;
      ((t[o] = 0), (r[o] = -1), (e[o] = -1), (n &= ~a));
    }
  }
  function Ai(e, t) {
    var n = (e.entangledLanes |= t);
    for (e = e.entanglements; n;) {
      var r = 31 - xt(n),
        o = 1 << r;
      ((o & t) | (e[r] & t) && (e[r] |= t), (n &= ~o));
    }
  }
  var ye = 0;
  function vl(e) {
    return (
      (e &= -e),
      1 < e ? (4 < e ? ((e & 268435455) !== 0 ? 16 : 536870912) : 4) : 1
    );
  }
  var wl,
    Pi,
    xl,
    kl,
    Sl,
    Ti = !1,
    io = [],
    Jt = null,
    Kt = null,
    Qt = null,
    gr = new Map(),
    yr = new Map(),
    Gt = [],
    Af =
      "mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(
        " ",
      );
  function Cl(e, t) {
    switch (e) {
      case "focusin":
      case "focusout":
        Jt = null;
        break;
      case "dragenter":
      case "dragleave":
        Kt = null;
        break;
      case "mouseover":
      case "mouseout":
        Qt = null;
        break;
      case "pointerover":
      case "pointerout":
        gr.delete(t.pointerId);
        break;
      case "gotpointercapture":
      case "lostpointercapture":
        yr.delete(t.pointerId);
    }
  }
  function vr(e, t, n, r, o, a) {
    return e === null || e.nativeEvent !== a
      ? ((e = {
          blockedOn: t,
          domEventName: n,
          eventSystemFlags: r,
          nativeEvent: a,
          targetContainers: [o],
        }),
        t !== null && ((t = Mr(t)), t !== null && Pi(t)),
        e)
      : ((e.eventSystemFlags |= r),
        (t = e.targetContainers),
        o !== null && t.indexOf(o) === -1 && t.push(o),
        e);
  }
  function Pf(e, t, n, r, o) {
    switch (t) {
      case "focusin":
        return ((Jt = vr(Jt, e, t, n, r, o)), !0);
      case "dragenter":
        return ((Kt = vr(Kt, e, t, n, r, o)), !0);
      case "mouseover":
        return ((Qt = vr(Qt, e, t, n, r, o)), !0);
      case "pointerover":
        var a = o.pointerId;
        return (gr.set(a, vr(gr.get(a) || null, e, t, n, r, o)), !0);
      case "gotpointercapture":
        return (
          (a = o.pointerId),
          yr.set(a, vr(yr.get(a) || null, e, t, n, r, o)),
          !0
        );
    }
    return !1;
  }
  function bl(e) {
    var t = gn(e.target);
    if (t !== null) {
      var n = hn(t);
      if (n !== null) {
        if (((t = n.tag), t === 13)) {
          if (((t = ul(n)), t !== null)) {
            ((e.blockedOn = t),
              Sl(e.priority, function () {
                xl(n);
              }));
            return;
          }
        } else if (t === 3 && n.stateNode.current.memoizedState.isDehydrated) {
          e.blockedOn = n.tag === 3 ? n.stateNode.containerInfo : null;
          return;
        }
      }
    }
    e.blockedOn = null;
  }
  function ao(e) {
    if (e.blockedOn !== null) return !1;
    for (var t = e.targetContainers; 0 < t.length;) {
      var n = Mi(e.domEventName, e.eventSystemFlags, t[0], e.nativeEvent);
      if (n === null) {
        n = e.nativeEvent;
        var r = new n.constructor(n.type, n);
        ((wi = r), n.target.dispatchEvent(r), (wi = null));
      } else return ((t = Mr(n)), t !== null && Pi(t), (e.blockedOn = n), !1);
      t.shift();
    }
    return !0;
  }
  function _l(e, t, n) {
    ao(e) && n.delete(t);
  }
  function Tf() {
    ((Ti = !1),
      Jt !== null && ao(Jt) && (Jt = null),
      Kt !== null && ao(Kt) && (Kt = null),
      Qt !== null && ao(Qt) && (Qt = null),
      gr.forEach(_l),
      yr.forEach(_l));
  }
  function wr(e, t) {
    e.blockedOn === t &&
      ((e.blockedOn = null),
      Ti ||
        ((Ti = !0),
        u.unstable_scheduleCallback(u.unstable_NormalPriority, Tf)));
  }
  function xr(e) {
    function t(o) {
      return wr(o, e);
    }
    if (0 < io.length) {
      wr(io[0], e);
      for (var n = 1; n < io.length; n++) {
        var r = io[n];
        r.blockedOn === e && (r.blockedOn = null);
      }
    }
    for (
      Jt !== null && wr(Jt, e),
        Kt !== null && wr(Kt, e),
        Qt !== null && wr(Qt, e),
        gr.forEach(t),
        yr.forEach(t),
        n = 0;
      n < Gt.length;
      n++
    )
      ((r = Gt[n]), r.blockedOn === e && (r.blockedOn = null));
    for (; 0 < Gt.length && ((n = Gt[0]), n.blockedOn === null);)
      (bl(n), n.blockedOn === null && Gt.shift());
  }
  var In = ee.ReactCurrentBatchConfig,
    so = !0;
  function zf(e, t, n, r) {
    var o = ye,
      a = In.transition;
    In.transition = null;
    try {
      ((ye = 1), zi(e, t, n, r));
    } finally {
      ((ye = o), (In.transition = a));
    }
  }
  function Mf(e, t, n, r) {
    var o = ye,
      a = In.transition;
    In.transition = null;
    try {
      ((ye = 4), zi(e, t, n, r));
    } finally {
      ((ye = o), (In.transition = a));
    }
  }
  function zi(e, t, n, r) {
    if (so) {
      var o = Mi(e, t, n, r);
      if (o === null) (Gi(e, t, r, lo, n), Cl(e, r));
      else if (Pf(o, e, t, n, r)) r.stopPropagation();
      else if ((Cl(e, r), t & 4 && -1 < Af.indexOf(e))) {
        for (; o !== null;) {
          var a = Mr(o);
          if (
            (a !== null && wl(a),
            (a = Mi(e, t, n, r)),
            a === null && Gi(e, t, r, lo, n),
            a === o)
          )
            break;
          o = a;
        }
        o !== null && r.stopPropagation();
      } else Gi(e, t, r, null, n);
    }
  }
  var lo = null;
  function Mi(e, t, n, r) {
    if (((lo = null), (e = xi(r)), (e = gn(e)), e !== null))
      if (((t = hn(e)), t === null)) e = null;
      else if (((n = t.tag), n === 13)) {
        if (((e = ul(t)), e !== null)) return e;
        e = null;
      } else if (n === 3) {
        if (t.stateNode.current.memoizedState.isDehydrated)
          return t.tag === 3 ? t.stateNode.containerInfo : null;
        e = null;
      } else t !== e && (e = null);
    return ((lo = e), null);
  }
  function jl(e) {
    switch (e) {
      case "cancel":
      case "click":
      case "close":
      case "contextmenu":
      case "copy":
      case "cut":
      case "auxclick":
      case "dblclick":
      case "dragend":
      case "dragstart":
      case "drop":
      case "focusin":
      case "focusout":
      case "input":
      case "invalid":
      case "keydown":
      case "keypress":
      case "keyup":
      case "mousedown":
      case "mouseup":
      case "paste":
      case "pause":
      case "play":
      case "pointercancel":
      case "pointerdown":
      case "pointerup":
      case "ratechange":
      case "reset":
      case "resize":
      case "seeked":
      case "submit":
      case "touchcancel":
      case "touchend":
      case "touchstart":
      case "volumechange":
      case "change":
      case "selectionchange":
      case "textInput":
      case "compositionstart":
      case "compositionend":
      case "compositionupdate":
      case "beforeblur":
      case "afterblur":
      case "beforeinput":
      case "blur":
      case "fullscreenchange":
      case "focus":
      case "hashchange":
      case "popstate":
      case "select":
      case "selectstart":
        return 1;
      case "drag":
      case "dragenter":
      case "dragexit":
      case "dragleave":
      case "dragover":
      case "mousemove":
      case "mouseout":
      case "mouseover":
      case "pointermove":
      case "pointerout":
      case "pointerover":
      case "scroll":
      case "toggle":
      case "touchmove":
      case "wheel":
      case "mouseenter":
      case "mouseleave":
      case "pointerenter":
      case "pointerleave":
        return 4;
      case "message":
        switch (wf()) {
          case _i:
            return 1;
          case hl:
            return 4;
          case eo:
          case xf:
            return 16;
          case gl:
            return 536870912;
          default:
            return 16;
        }
      default:
        return 16;
    }
  }
  var Zt = null,
    Li = null,
    uo = null;
  function El() {
    if (uo) return uo;
    var e,
      t = Li,
      n = t.length,
      r,
      o = "value" in Zt ? Zt.value : Zt.textContent,
      a = o.length;
    for (e = 0; e < n && t[e] === o[e]; e++);
    var c = n - e;
    for (r = 1; r <= c && t[n - r] === o[a - r]; r++);
    return (uo = o.slice(e, 1 < r ? 1 - r : void 0));
  }
  function co(e) {
    var t = e.keyCode;
    return (
      "charCode" in e
        ? ((e = e.charCode), e === 0 && t === 13 && (e = 13))
        : (e = t),
      e === 10 && (e = 13),
      32 <= e || e === 13 ? e : 0
    );
  }
  function fo() {
    return !0;
  }
  function Al() {
    return !1;
  }
  function lt(e) {
    function t(n, r, o, a, c) {
      ((this._reactName = n),
        (this._targetInst = o),
        (this.type = r),
        (this.nativeEvent = a),
        (this.target = c),
        (this.currentTarget = null));
      for (var f in e)
        e.hasOwnProperty(f) && ((n = e[f]), (this[f] = n ? n(a) : a[f]));
      return (
        (this.isDefaultPrevented = (
          a.defaultPrevented != null ? a.defaultPrevented : a.returnValue === !1
        )
          ? fo
          : Al),
        (this.isPropagationStopped = Al),
        this
      );
    }
    return (
      _(t.prototype, {
        preventDefault: function () {
          this.defaultPrevented = !0;
          var n = this.nativeEvent;
          n &&
            (n.preventDefault
              ? n.preventDefault()
              : typeof n.returnValue != "unknown" && (n.returnValue = !1),
            (this.isDefaultPrevented = fo));
        },
        stopPropagation: function () {
          var n = this.nativeEvent;
          n &&
            (n.stopPropagation
              ? n.stopPropagation()
              : typeof n.cancelBubble != "unknown" && (n.cancelBubble = !0),
            (this.isPropagationStopped = fo));
        },
        persist: function () {},
        isPersistent: fo,
      }),
      t
    );
  }
  var Dn = {
      eventPhase: 0,
      bubbles: 0,
      cancelable: 0,
      timeStamp: function (e) {
        return e.timeStamp || Date.now();
      },
      defaultPrevented: 0,
      isTrusted: 0,
    },
    Ri = lt(Dn),
    kr = _({}, Dn, { view: 0, detail: 0 }),
    Lf = lt(kr),
    Oi,
    Ni,
    Sr,
    po = _({}, kr, {
      screenX: 0,
      screenY: 0,
      clientX: 0,
      clientY: 0,
      pageX: 0,
      pageY: 0,
      ctrlKey: 0,
      shiftKey: 0,
      altKey: 0,
      metaKey: 0,
      getModifierState: Di,
      button: 0,
      buttons: 0,
      relatedTarget: function (e) {
        return e.relatedTarget === void 0
          ? e.fromElement === e.srcElement
            ? e.toElement
            : e.fromElement
          : e.relatedTarget;
      },
      movementX: function (e) {
        return "movementX" in e
          ? e.movementX
          : (e !== Sr &&
              (Sr && e.type === "mousemove"
                ? ((Oi = e.screenX - Sr.screenX), (Ni = e.screenY - Sr.screenY))
                : (Ni = Oi = 0),
              (Sr = e)),
            Oi);
      },
      movementY: function (e) {
        return "movementY" in e ? e.movementY : Ni;
      },
    }),
    Pl = lt(po),
    Rf = _({}, po, { dataTransfer: 0 }),
    Of = lt(Rf),
    Nf = _({}, kr, { relatedTarget: 0 }),
    Ii = lt(Nf),
    If = _({}, Dn, { animationName: 0, elapsedTime: 0, pseudoElement: 0 }),
    Df = lt(If),
    Uf = _({}, Dn, {
      clipboardData: function (e) {
        return "clipboardData" in e ? e.clipboardData : window.clipboardData;
      },
    }),
    $f = lt(Uf),
    Ff = _({}, Dn, { data: 0 }),
    Tl = lt(Ff),
    Wf = {
      Esc: "Escape",
      Spacebar: " ",
      Left: "ArrowLeft",
      Up: "ArrowUp",
      Right: "ArrowRight",
      Down: "ArrowDown",
      Del: "Delete",
      Win: "OS",
      Menu: "ContextMenu",
      Apps: "ContextMenu",
      Scroll: "ScrollLock",
      MozPrintableKey: "Unidentified",
    },
    Bf = {
      8: "Backspace",
      9: "Tab",
      12: "Clear",
      13: "Enter",
      16: "Shift",
      17: "Control",
      18: "Alt",
      19: "Pause",
      20: "CapsLock",
      27: "Escape",
      32: " ",
      33: "PageUp",
      34: "PageDown",
      35: "End",
      36: "Home",
      37: "ArrowLeft",
      38: "ArrowUp",
      39: "ArrowRight",
      40: "ArrowDown",
      45: "Insert",
      46: "Delete",
      112: "F1",
      113: "F2",
      114: "F3",
      115: "F4",
      116: "F5",
      117: "F6",
      118: "F7",
      119: "F8",
      120: "F9",
      121: "F10",
      122: "F11",
      123: "F12",
      144: "NumLock",
      145: "ScrollLock",
      224: "Meta",
    },
    Hf = {
      Alt: "altKey",
      Control: "ctrlKey",
      Meta: "metaKey",
      Shift: "shiftKey",
    };
  function Vf(e) {
    var t = this.nativeEvent;
    return t.getModifierState
      ? t.getModifierState(e)
      : (e = Hf[e])
        ? !!t[e]
        : !1;
  }
  function Di() {
    return Vf;
  }
  var Jf = _({}, kr, {
      key: function (e) {
        if (e.key) {
          var t = Wf[e.key] || e.key;
          if (t !== "Unidentified") return t;
        }
        return e.type === "keypress"
          ? ((e = co(e)), e === 13 ? "Enter" : String.fromCharCode(e))
          : e.type === "keydown" || e.type === "keyup"
            ? Bf[e.keyCode] || "Unidentified"
            : "";
      },
      code: 0,
      location: 0,
      ctrlKey: 0,
      shiftKey: 0,
      altKey: 0,
      metaKey: 0,
      repeat: 0,
      locale: 0,
      getModifierState: Di,
      charCode: function (e) {
        return e.type === "keypress" ? co(e) : 0;
      },
      keyCode: function (e) {
        return e.type === "keydown" || e.type === "keyup" ? e.keyCode : 0;
      },
      which: function (e) {
        return e.type === "keypress"
          ? co(e)
          : e.type === "keydown" || e.type === "keyup"
            ? e.keyCode
            : 0;
      },
    }),
    Kf = lt(Jf),
    Qf = _({}, po, {
      pointerId: 0,
      width: 0,
      height: 0,
      pressure: 0,
      tangentialPressure: 0,
      tiltX: 0,
      tiltY: 0,
      twist: 0,
      pointerType: 0,
      isPrimary: 0,
    }),
    zl = lt(Qf),
    Gf = _({}, kr, {
      touches: 0,
      targetTouches: 0,
      changedTouches: 0,
      altKey: 0,
      metaKey: 0,
      ctrlKey: 0,
      shiftKey: 0,
      getModifierState: Di,
    }),
    Zf = lt(Gf),
    qf = _({}, Dn, { propertyName: 0, elapsedTime: 0, pseudoElement: 0 }),
    Yf = lt(qf),
    Xf = _({}, po, {
      deltaX: function (e) {
        return "deltaX" in e
          ? e.deltaX
          : "wheelDeltaX" in e
            ? -e.wheelDeltaX
            : 0;
      },
      deltaY: function (e) {
        return "deltaY" in e
          ? e.deltaY
          : "wheelDeltaY" in e
            ? -e.wheelDeltaY
            : "wheelDelta" in e
              ? -e.wheelDelta
              : 0;
      },
      deltaZ: 0,
      deltaMode: 0,
    }),
    ep = lt(Xf),
    tp = [9, 13, 27, 32],
    Ui = j && "CompositionEvent" in window,
    Cr = null;
  j && "documentMode" in document && (Cr = document.documentMode);
  var np = j && "TextEvent" in window && !Cr,
    Ml = j && (!Ui || (Cr && 8 < Cr && 11 >= Cr)),
    Ll = " ",
    Rl = !1;
  function Ol(e, t) {
    switch (e) {
      case "keyup":
        return tp.indexOf(t.keyCode) !== -1;
      case "keydown":
        return t.keyCode !== 229;
      case "keypress":
      case "mousedown":
      case "focusout":
        return !0;
      default:
        return !1;
    }
  }
  function Nl(e) {
    return (
      (e = e.detail),
      typeof e == "object" && "data" in e ? e.data : null
    );
  }
  var Un = !1;
  function rp(e, t) {
    switch (e) {
      case "compositionend":
        return Nl(t);
      case "keypress":
        return t.which !== 32 ? null : ((Rl = !0), Ll);
      case "textInput":
        return ((e = t.data), e === Ll && Rl ? null : e);
      default:
        return null;
    }
  }
  function op(e, t) {
    if (Un)
      return e === "compositionend" || (!Ui && Ol(e, t))
        ? ((e = El()), (uo = Li = Zt = null), (Un = !1), e)
        : null;
    switch (e) {
      case "paste":
        return null;
      case "keypress":
        if (!(t.ctrlKey || t.altKey || t.metaKey) || (t.ctrlKey && t.altKey)) {
          if (t.char && 1 < t.char.length) return t.char;
          if (t.which) return String.fromCharCode(t.which);
        }
        return null;
      case "compositionend":
        return Ml && t.locale !== "ko" ? null : t.data;
      default:
        return null;
    }
  }
  var ip = {
    color: !0,
    date: !0,
    datetime: !0,
    "datetime-local": !0,
    email: !0,
    month: !0,
    number: !0,
    password: !0,
    range: !0,
    search: !0,
    tel: !0,
    text: !0,
    time: !0,
    url: !0,
    week: !0,
  };
  function Il(e) {
    var t = e && e.nodeName && e.nodeName.toLowerCase();
    return t === "input" ? !!ip[e.type] : t === "textarea";
  }
  function Dl(e, t, n, r) {
    (ol(r),
      (t = vo(t, "onChange")),
      0 < t.length &&
        ((n = new Ri("onChange", "change", null, n, r)),
        e.push({ event: n, listeners: t })));
  }
  var br = null,
    _r = null;
  function ap(e) {
    nu(e, 0);
  }
  function mo(e) {
    var t = Hn(e);
    if (He(t)) return e;
  }
  function sp(e, t) {
    if (e === "change") return t;
  }
  var Ul = !1;
  if (j) {
    var $i;
    if (j) {
      var Fi = "oninput" in document;
      if (!Fi) {
        var $l = document.createElement("div");
        ($l.setAttribute("oninput", "return;"),
          (Fi = typeof $l.oninput == "function"));
      }
      $i = Fi;
    } else $i = !1;
    Ul = $i && (!document.documentMode || 9 < document.documentMode);
  }
  function Fl() {
    br && (br.detachEvent("onpropertychange", Wl), (_r = br = null));
  }
  function Wl(e) {
    if (e.propertyName === "value" && mo(_r)) {
      var t = [];
      (Dl(t, _r, e, xi(e)), ll(ap, t));
    }
  }
  function lp(e, t, n) {
    e === "focusin"
      ? (Fl(), (br = t), (_r = n), br.attachEvent("onpropertychange", Wl))
      : e === "focusout" && Fl();
  }
  function up(e) {
    if (e === "selectionchange" || e === "keyup" || e === "keydown")
      return mo(_r);
  }
  function cp(e, t) {
    if (e === "click") return mo(t);
  }
  function dp(e, t) {
    if (e === "input" || e === "change") return mo(t);
  }
  function fp(e, t) {
    return (e === t && (e !== 0 || 1 / e === 1 / t)) || (e !== e && t !== t);
  }
  var kt = typeof Object.is == "function" ? Object.is : fp;
  function jr(e, t) {
    if (kt(e, t)) return !0;
    if (
      typeof e != "object" ||
      e === null ||
      typeof t != "object" ||
      t === null
    )
      return !1;
    var n = Object.keys(e),
      r = Object.keys(t);
    if (n.length !== r.length) return !1;
    for (r = 0; r < n.length; r++) {
      var o = n[r];
      if (!k.call(t, o) || !kt(e[o], t[o])) return !1;
    }
    return !0;
  }
  function Bl(e) {
    for (; e && e.firstChild;) e = e.firstChild;
    return e;
  }
  function Hl(e, t) {
    var n = Bl(e);
    e = 0;
    for (var r; n;) {
      if (n.nodeType === 3) {
        if (((r = e + n.textContent.length), e <= t && r >= t))
          return { node: n, offset: t - e };
        e = r;
      }
      e: {
        for (; n;) {
          if (n.nextSibling) {
            n = n.nextSibling;
            break e;
          }
          n = n.parentNode;
        }
        n = void 0;
      }
      n = Bl(n);
    }
  }
  function Vl(e, t) {
    return e && t
      ? e === t
        ? !0
        : e && e.nodeType === 3
          ? !1
          : t && t.nodeType === 3
            ? Vl(e, t.parentNode)
            : "contains" in e
              ? e.contains(t)
              : e.compareDocumentPosition
                ? !!(e.compareDocumentPosition(t) & 16)
                : !1
      : !1;
  }
  function Jl() {
    for (var e = window, t = Pe(); t instanceof e.HTMLIFrameElement;) {
      try {
        var n = typeof t.contentWindow.location.href == "string";
      } catch {
        n = !1;
      }
      if (n) e = t.contentWindow;
      else break;
      t = Pe(e.document);
    }
    return t;
  }
  function Wi(e) {
    var t = e && e.nodeName && e.nodeName.toLowerCase();
    return (
      t &&
      ((t === "input" &&
        (e.type === "text" ||
          e.type === "search" ||
          e.type === "tel" ||
          e.type === "url" ||
          e.type === "password")) ||
        t === "textarea" ||
        e.contentEditable === "true")
    );
  }
  function pp(e) {
    var t = Jl(),
      n = e.focusedElem,
      r = e.selectionRange;
    if (
      t !== n &&
      n &&
      n.ownerDocument &&
      Vl(n.ownerDocument.documentElement, n)
    ) {
      if (r !== null && Wi(n)) {
        if (
          ((t = r.start),
          (e = r.end),
          e === void 0 && (e = t),
          "selectionStart" in n)
        )
          ((n.selectionStart = t),
            (n.selectionEnd = Math.min(e, n.value.length)));
        else if (
          ((e = ((t = n.ownerDocument || document) && t.defaultView) || window),
          e.getSelection)
        ) {
          e = e.getSelection();
          var o = n.textContent.length,
            a = Math.min(r.start, o);
          ((r = r.end === void 0 ? a : Math.min(r.end, o)),
            !e.extend && a > r && ((o = r), (r = a), (a = o)),
            (o = Hl(n, a)));
          var c = Hl(n, r);
          o &&
            c &&
            (e.rangeCount !== 1 ||
              e.anchorNode !== o.node ||
              e.anchorOffset !== o.offset ||
              e.focusNode !== c.node ||
              e.focusOffset !== c.offset) &&
            ((t = t.createRange()),
            t.setStart(o.node, o.offset),
            e.removeAllRanges(),
            a > r
              ? (e.addRange(t), e.extend(c.node, c.offset))
              : (t.setEnd(c.node, c.offset), e.addRange(t)));
        }
      }
      for (t = [], e = n; (e = e.parentNode);)
        e.nodeType === 1 &&
          t.push({ element: e, left: e.scrollLeft, top: e.scrollTop });
      for (typeof n.focus == "function" && n.focus(), n = 0; n < t.length; n++)
        ((e = t[n]),
          (e.element.scrollLeft = e.left),
          (e.element.scrollTop = e.top));
    }
  }
  var mp = j && "documentMode" in document && 11 >= document.documentMode,
    $n = null,
    Bi = null,
    Er = null,
    Hi = !1;
  function Kl(e, t, n) {
    var r =
      n.window === n ? n.document : n.nodeType === 9 ? n : n.ownerDocument;
    Hi ||
      $n == null ||
      $n !== Pe(r) ||
      ((r = $n),
      "selectionStart" in r && Wi(r)
        ? (r = { start: r.selectionStart, end: r.selectionEnd })
        : ((r = (
            (r.ownerDocument && r.ownerDocument.defaultView) ||
            window
          ).getSelection()),
          (r = {
            anchorNode: r.anchorNode,
            anchorOffset: r.anchorOffset,
            focusNode: r.focusNode,
            focusOffset: r.focusOffset,
          })),
      (Er && jr(Er, r)) ||
        ((Er = r),
        (r = vo(Bi, "onSelect")),
        0 < r.length &&
          ((t = new Ri("onSelect", "select", null, t, n)),
          e.push({ event: t, listeners: r }),
          (t.target = $n))));
  }
  function ho(e, t) {
    var n = {};
    return (
      (n[e.toLowerCase()] = t.toLowerCase()),
      (n["Webkit" + e] = "webkit" + t),
      (n["Moz" + e] = "moz" + t),
      n
    );
  }
  var Fn = {
      animationend: ho("Animation", "AnimationEnd"),
      animationiteration: ho("Animation", "AnimationIteration"),
      animationstart: ho("Animation", "AnimationStart"),
      transitionend: ho("Transition", "TransitionEnd"),
    },
    Vi = {},
    Ql = {};
  j &&
    ((Ql = document.createElement("div").style),
    "AnimationEvent" in window ||
      (delete Fn.animationend.animation,
      delete Fn.animationiteration.animation,
      delete Fn.animationstart.animation),
    "TransitionEvent" in window || delete Fn.transitionend.transition);
  function go(e) {
    if (Vi[e]) return Vi[e];
    if (!Fn[e]) return e;
    var t = Fn[e],
      n;
    for (n in t) if (t.hasOwnProperty(n) && n in Ql) return (Vi[e] = t[n]);
    return e;
  }
  var Gl = go("animationend"),
    Zl = go("animationiteration"),
    ql = go("animationstart"),
    Yl = go("transitionend"),
    Xl = new Map(),
    eu =
      "abort auxClick cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(
        " ",
      );
  function qt(e, t) {
    (Xl.set(e, t), y(t, [e]));
  }
  for (var Ji = 0; Ji < eu.length; Ji++) {
    var Ki = eu[Ji],
      hp = Ki.toLowerCase(),
      gp = Ki[0].toUpperCase() + Ki.slice(1);
    qt(hp, "on" + gp);
  }
  (qt(Gl, "onAnimationEnd"),
    qt(Zl, "onAnimationIteration"),
    qt(ql, "onAnimationStart"),
    qt("dblclick", "onDoubleClick"),
    qt("focusin", "onFocus"),
    qt("focusout", "onBlur"),
    qt(Yl, "onTransitionEnd"),
    S("onMouseEnter", ["mouseout", "mouseover"]),
    S("onMouseLeave", ["mouseout", "mouseover"]),
    S("onPointerEnter", ["pointerout", "pointerover"]),
    S("onPointerLeave", ["pointerout", "pointerover"]),
    y(
      "onChange",
      "change click focusin focusout input keydown keyup selectionchange".split(
        " ",
      ),
    ),
    y(
      "onSelect",
      "focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(
        " ",
      ),
    ),
    y("onBeforeInput", ["compositionend", "keypress", "textInput", "paste"]),
    y(
      "onCompositionEnd",
      "compositionend focusout keydown keypress keyup mousedown".split(" "),
    ),
    y(
      "onCompositionStart",
      "compositionstart focusout keydown keypress keyup mousedown".split(" "),
    ),
    y(
      "onCompositionUpdate",
      "compositionupdate focusout keydown keypress keyup mousedown".split(" "),
    ));
  var Ar =
      "abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(
        " ",
      ),
    yp = new Set(
      "cancel close invalid load scroll toggle".split(" ").concat(Ar),
    );
  function tu(e, t, n) {
    var r = e.type || "unknown-event";
    ((e.currentTarget = n), hf(r, t, void 0, e), (e.currentTarget = null));
  }
  function nu(e, t) {
    t = (t & 4) !== 0;
    for (var n = 0; n < e.length; n++) {
      var r = e[n],
        o = r.event;
      r = r.listeners;
      e: {
        var a = void 0;
        if (t)
          for (var c = r.length - 1; 0 <= c; c--) {
            var f = r[c],
              m = f.instance,
              x = f.currentTarget;
            if (((f = f.listener), m !== a && o.isPropagationStopped()))
              break e;
            (tu(o, f, x), (a = m));
          }
        else
          for (c = 0; c < r.length; c++) {
            if (
              ((f = r[c]),
              (m = f.instance),
              (x = f.currentTarget),
              (f = f.listener),
              m !== a && o.isPropagationStopped())
            )
              break e;
            (tu(o, f, x), (a = m));
          }
      }
    }
    if (Xr) throw ((e = bi), (Xr = !1), (bi = null), e);
  }
  function _e(e, t) {
    var n = t[ta];
    n === void 0 && (n = t[ta] = new Set());
    var r = e + "__bubble";
    n.has(r) || (ru(t, e, 2, !1), n.add(r));
  }
  function Qi(e, t, n) {
    var r = 0;
    (t && (r |= 4), ru(n, e, r, t));
  }
  var yo = "_reactListening" + Math.random().toString(36).slice(2);
  function Pr(e) {
    if (!e[yo]) {
      ((e[yo] = !0),
        d.forEach(function (n) {
          n !== "selectionchange" && (yp.has(n) || Qi(n, !1, e), Qi(n, !0, e));
        }));
      var t = e.nodeType === 9 ? e : e.ownerDocument;
      t === null || t[yo] || ((t[yo] = !0), Qi("selectionchange", !1, t));
    }
  }
  function ru(e, t, n, r) {
    switch (jl(t)) {
      case 1:
        var o = zf;
        break;
      case 4:
        o = Mf;
        break;
      default:
        o = zi;
    }
    ((n = o.bind(null, t, n, e)),
      (o = void 0),
      !Ci ||
        (t !== "touchstart" && t !== "touchmove" && t !== "wheel") ||
        (o = !0),
      r
        ? o !== void 0
          ? e.addEventListener(t, n, { capture: !0, passive: o })
          : e.addEventListener(t, n, !0)
        : o !== void 0
          ? e.addEventListener(t, n, { passive: o })
          : e.addEventListener(t, n, !1));
  }
  function Gi(e, t, n, r, o) {
    var a = r;
    if ((t & 1) === 0 && (t & 2) === 0 && r !== null)
      e: for (;;) {
        if (r === null) return;
        var c = r.tag;
        if (c === 3 || c === 4) {
          var f = r.stateNode.containerInfo;
          if (f === o || (f.nodeType === 8 && f.parentNode === o)) break;
          if (c === 4)
            for (c = r.return; c !== null;) {
              var m = c.tag;
              if (
                (m === 3 || m === 4) &&
                ((m = c.stateNode.containerInfo),
                m === o || (m.nodeType === 8 && m.parentNode === o))
              )
                return;
              c = c.return;
            }
          for (; f !== null;) {
            if (((c = gn(f)), c === null)) return;
            if (((m = c.tag), m === 5 || m === 6)) {
              r = a = c;
              continue e;
            }
            f = f.parentNode;
          }
        }
        r = r.return;
      }
    ll(function () {
      var x = a,
        P = xi(n),
        T = [];
      e: {
        var A = Xl.get(e);
        if (A !== void 0) {
          var I = Ri,
            $ = e;
          switch (e) {
            case "keypress":
              if (co(n) === 0) break e;
            case "keydown":
            case "keyup":
              I = Kf;
              break;
            case "focusin":
              (($ = "focus"), (I = Ii));
              break;
            case "focusout":
              (($ = "blur"), (I = Ii));
              break;
            case "beforeblur":
            case "afterblur":
              I = Ii;
              break;
            case "click":
              if (n.button === 2) break e;
            case "auxclick":
            case "dblclick":
            case "mousedown":
            case "mousemove":
            case "mouseup":
            case "mouseout":
            case "mouseover":
            case "contextmenu":
              I = Pl;
              break;
            case "drag":
            case "dragend":
            case "dragenter":
            case "dragexit":
            case "dragleave":
            case "dragover":
            case "dragstart":
            case "drop":
              I = Of;
              break;
            case "touchcancel":
            case "touchend":
            case "touchmove":
            case "touchstart":
              I = Zf;
              break;
            case Gl:
            case Zl:
            case ql:
              I = Df;
              break;
            case Yl:
              I = Yf;
              break;
            case "scroll":
              I = Lf;
              break;
            case "wheel":
              I = ep;
              break;
            case "copy":
            case "cut":
            case "paste":
              I = $f;
              break;
            case "gotpointercapture":
            case "lostpointercapture":
            case "pointercancel":
            case "pointerdown":
            case "pointermove":
            case "pointerout":
            case "pointerover":
            case "pointerup":
              I = zl;
          }
          var W = (t & 4) !== 0,
            Oe = !W && e === "scroll",
            v = W ? (A !== null ? A + "Capture" : null) : A;
          W = [];
          for (var g = x, w; g !== null;) {
            w = g;
            var z = w.stateNode;
            if (
              (w.tag === 5 &&
                z !== null &&
                ((w = z),
                v !== null &&
                  ((z = dr(g, v)), z != null && W.push(Tr(g, z, w)))),
              Oe)
            )
              break;
            g = g.return;
          }
          0 < W.length &&
            ((A = new I(A, $, null, n, P)), T.push({ event: A, listeners: W }));
        }
      }
      if ((t & 7) === 0) {
        e: {
          if (
            ((A = e === "mouseover" || e === "pointerover"),
            (I = e === "mouseout" || e === "pointerout"),
            A &&
              n !== wi &&
              ($ = n.relatedTarget || n.fromElement) &&
              (gn($) || $[Ot]))
          )
            break e;
          if (
            (I || A) &&
            ((A =
              P.window === P
                ? P
                : (A = P.ownerDocument)
                  ? A.defaultView || A.parentWindow
                  : window),
            I
              ? (($ = n.relatedTarget || n.toElement),
                (I = x),
                ($ = $ ? gn($) : null),
                $ !== null &&
                  ((Oe = hn($)), $ !== Oe || ($.tag !== 5 && $.tag !== 6)) &&
                  ($ = null))
              : ((I = null), ($ = x)),
            I !== $)
          ) {
            if (
              ((W = Pl),
              (z = "onMouseLeave"),
              (v = "onMouseEnter"),
              (g = "mouse"),
              (e === "pointerout" || e === "pointerover") &&
                ((W = zl),
                (z = "onPointerLeave"),
                (v = "onPointerEnter"),
                (g = "pointer")),
              (Oe = I == null ? A : Hn(I)),
              (w = $ == null ? A : Hn($)),
              (A = new W(z, g + "leave", I, n, P)),
              (A.target = Oe),
              (A.relatedTarget = w),
              (z = null),
              gn(P) === x &&
                ((W = new W(v, g + "enter", $, n, P)),
                (W.target = w),
                (W.relatedTarget = Oe),
                (z = W)),
              (Oe = z),
              I && $)
            )
              t: {
                for (W = I, v = $, g = 0, w = W; w; w = Wn(w)) g++;
                for (w = 0, z = v; z; z = Wn(z)) w++;
                for (; 0 < g - w;) ((W = Wn(W)), g--);
                for (; 0 < w - g;) ((v = Wn(v)), w--);
                for (; g--;) {
                  if (W === v || (v !== null && W === v.alternate)) break t;
                  ((W = Wn(W)), (v = Wn(v)));
                }
                W = null;
              }
            else W = null;
            (I !== null && ou(T, A, I, W, !1),
              $ !== null && Oe !== null && ou(T, Oe, $, W, !0));
          }
        }
        e: {
          if (
            ((A = x ? Hn(x) : window),
            (I = A.nodeName && A.nodeName.toLowerCase()),
            I === "select" || (I === "input" && A.type === "file"))
          )
            var H = sp;
          else if (Il(A))
            if (Ul) H = dp;
            else {
              H = up;
              var Z = lp;
            }
          else
            (I = A.nodeName) &&
              I.toLowerCase() === "input" &&
              (A.type === "checkbox" || A.type === "radio") &&
              (H = cp);
          if (H && (H = H(e, x))) {
            Dl(T, H, n, P);
            break e;
          }
          (Z && Z(e, A, x),
            e === "focusout" &&
              (Z = A._wrapperState) &&
              Z.controlled &&
              A.type === "number" &&
              mi(A, "number", A.value));
        }
        switch (((Z = x ? Hn(x) : window), e)) {
          case "focusin":
            (Il(Z) || Z.contentEditable === "true") &&
              (($n = Z), (Bi = x), (Er = null));
            break;
          case "focusout":
            Er = Bi = $n = null;
            break;
          case "mousedown":
            Hi = !0;
            break;
          case "contextmenu":
          case "mouseup":
          case "dragend":
            ((Hi = !1), Kl(T, n, P));
            break;
          case "selectionchange":
            if (mp) break;
          case "keydown":
          case "keyup":
            Kl(T, n, P);
        }
        var q;
        if (Ui)
          e: {
            switch (e) {
              case "compositionstart":
                var X = "onCompositionStart";
                break e;
              case "compositionend":
                X = "onCompositionEnd";
                break e;
              case "compositionupdate":
                X = "onCompositionUpdate";
                break e;
            }
            X = void 0;
          }
        else
          Un
            ? Ol(e, n) && (X = "onCompositionEnd")
            : e === "keydown" &&
              n.keyCode === 229 &&
              (X = "onCompositionStart");
        (X &&
          (Ml &&
            n.locale !== "ko" &&
            (Un || X !== "onCompositionStart"
              ? X === "onCompositionEnd" && Un && (q = El())
              : ((Zt = P),
                (Li = "value" in Zt ? Zt.value : Zt.textContent),
                (Un = !0))),
          (Z = vo(x, X)),
          0 < Z.length &&
            ((X = new Tl(X, e, null, n, P)),
            T.push({ event: X, listeners: Z }),
            q ? (X.data = q) : ((q = Nl(n)), q !== null && (X.data = q)))),
          (q = np ? rp(e, n) : op(e, n)) &&
            ((x = vo(x, "onBeforeInput")),
            0 < x.length &&
              ((P = new Tl("onBeforeInput", "beforeinput", null, n, P)),
              T.push({ event: P, listeners: x }),
              (P.data = q))));
      }
      nu(T, t);
    });
  }
  function Tr(e, t, n) {
    return { instance: e, listener: t, currentTarget: n };
  }
  function vo(e, t) {
    for (var n = t + "Capture", r = []; e !== null;) {
      var o = e,
        a = o.stateNode;
      (o.tag === 5 &&
        a !== null &&
        ((o = a),
        (a = dr(e, n)),
        a != null && r.unshift(Tr(e, a, o)),
        (a = dr(e, t)),
        a != null && r.push(Tr(e, a, o))),
        (e = e.return));
    }
    return r;
  }
  function Wn(e) {
    if (e === null) return null;
    do e = e.return;
    while (e && e.tag !== 5);
    return e || null;
  }
  function ou(e, t, n, r, o) {
    for (var a = t._reactName, c = []; n !== null && n !== r;) {
      var f = n,
        m = f.alternate,
        x = f.stateNode;
      if (m !== null && m === r) break;
      (f.tag === 5 &&
        x !== null &&
        ((f = x),
        o
          ? ((m = dr(n, a)), m != null && c.unshift(Tr(n, m, f)))
          : o || ((m = dr(n, a)), m != null && c.push(Tr(n, m, f)))),
        (n = n.return));
    }
    c.length !== 0 && e.push({ event: t, listeners: c });
  }
  var vp = /\r\n?/g,
    wp = /\u0000|\uFFFD/g;
  function iu(e) {
    return (typeof e == "string" ? e : "" + e)
      .replace(
        vp,
        `
`,
      )
      .replace(wp, "");
  }
  function wo(e, t, n) {
    if (((t = iu(t)), iu(e) !== t && n)) throw Error(l(425));
  }
  function xo() {}
  var Zi = null,
    qi = null;
  function Yi(e, t) {
    return (
      e === "textarea" ||
      e === "noscript" ||
      typeof t.children == "string" ||
      typeof t.children == "number" ||
      (typeof t.dangerouslySetInnerHTML == "object" &&
        t.dangerouslySetInnerHTML !== null &&
        t.dangerouslySetInnerHTML.__html != null)
    );
  }
  var Xi = typeof setTimeout == "function" ? setTimeout : void 0,
    xp = typeof clearTimeout == "function" ? clearTimeout : void 0,
    au = typeof Promise == "function" ? Promise : void 0,
    kp =
      typeof queueMicrotask == "function"
        ? queueMicrotask
        : typeof au < "u"
          ? function (e) {
              return au.resolve(null).then(e).catch(Sp);
            }
          : Xi;
  function Sp(e) {
    setTimeout(function () {
      throw e;
    });
  }
  function ea(e, t) {
    var n = t,
      r = 0;
    do {
      var o = n.nextSibling;
      if ((e.removeChild(n), o && o.nodeType === 8))
        if (((n = o.data), n === "/$")) {
          if (r === 0) {
            (e.removeChild(o), xr(t));
            return;
          }
          r--;
        } else (n !== "$" && n !== "$?" && n !== "$!") || r++;
      n = o;
    } while (n);
    xr(t);
  }
  function Yt(e) {
    for (; e != null; e = e.nextSibling) {
      var t = e.nodeType;
      if (t === 1 || t === 3) break;
      if (t === 8) {
        if (((t = e.data), t === "$" || t === "$!" || t === "$?")) break;
        if (t === "/$") return null;
      }
    }
    return e;
  }
  function su(e) {
    e = e.previousSibling;
    for (var t = 0; e;) {
      if (e.nodeType === 8) {
        var n = e.data;
        if (n === "$" || n === "$!" || n === "$?") {
          if (t === 0) return e;
          t--;
        } else n === "/$" && t++;
      }
      e = e.previousSibling;
    }
    return null;
  }
  var Bn = Math.random().toString(36).slice(2),
    Pt = "__reactFiber$" + Bn,
    zr = "__reactProps$" + Bn,
    Ot = "__reactContainer$" + Bn,
    ta = "__reactEvents$" + Bn,
    Cp = "__reactListeners$" + Bn,
    bp = "__reactHandles$" + Bn;
  function gn(e) {
    var t = e[Pt];
    if (t) return t;
    for (var n = e.parentNode; n;) {
      if ((t = n[Ot] || n[Pt])) {
        if (
          ((n = t.alternate),
          t.child !== null || (n !== null && n.child !== null))
        )
          for (e = su(e); e !== null;) {
            if ((n = e[Pt])) return n;
            e = su(e);
          }
        return t;
      }
      ((e = n), (n = e.parentNode));
    }
    return null;
  }
  function Mr(e) {
    return (
      (e = e[Pt] || e[Ot]),
      !e || (e.tag !== 5 && e.tag !== 6 && e.tag !== 13 && e.tag !== 3)
        ? null
        : e
    );
  }
  function Hn(e) {
    if (e.tag === 5 || e.tag === 6) return e.stateNode;
    throw Error(l(33));
  }
  function ko(e) {
    return e[zr] || null;
  }
  var na = [],
    Vn = -1;
  function Xt(e) {
    return { current: e };
  }
  function je(e) {
    0 > Vn || ((e.current = na[Vn]), (na[Vn] = null), Vn--);
  }
  function be(e, t) {
    (Vn++, (na[Vn] = e.current), (e.current = t));
  }
  var en = {},
    Ke = Xt(en),
    tt = Xt(!1),
    yn = en;
  function Jn(e, t) {
    var n = e.type.contextTypes;
    if (!n) return en;
    var r = e.stateNode;
    if (r && r.__reactInternalMemoizedUnmaskedChildContext === t)
      return r.__reactInternalMemoizedMaskedChildContext;
    var o = {},
      a;
    for (a in n) o[a] = t[a];
    return (
      r &&
        ((e = e.stateNode),
        (e.__reactInternalMemoizedUnmaskedChildContext = t),
        (e.__reactInternalMemoizedMaskedChildContext = o)),
      o
    );
  }
  function nt(e) {
    return ((e = e.childContextTypes), e != null);
  }
  function So() {
    (je(tt), je(Ke));
  }
  function lu(e, t, n) {
    if (Ke.current !== en) throw Error(l(168));
    (be(Ke, t), be(tt, n));
  }
  function uu(e, t, n) {
    var r = e.stateNode;
    if (((t = t.childContextTypes), typeof r.getChildContext != "function"))
      return n;
    r = r.getChildContext();
    for (var o in r) if (!(o in t)) throw Error(l(108, we(e) || "Unknown", o));
    return _({}, n, r);
  }
  function Co(e) {
    return (
      (e =
        ((e = e.stateNode) && e.__reactInternalMemoizedMergedChildContext) ||
        en),
      (yn = Ke.current),
      be(Ke, e),
      be(tt, tt.current),
      !0
    );
  }
  function cu(e, t, n) {
    var r = e.stateNode;
    if (!r) throw Error(l(169));
    (n
      ? ((e = uu(e, t, yn)),
        (r.__reactInternalMemoizedMergedChildContext = e),
        je(tt),
        je(Ke),
        be(Ke, e))
      : je(tt),
      be(tt, n));
  }
  var Nt = null,
    bo = !1,
    ra = !1;
  function du(e) {
    Nt === null ? (Nt = [e]) : Nt.push(e);
  }
  function _p(e) {
    ((bo = !0), du(e));
  }
  function tn() {
    if (!ra && Nt !== null) {
      ra = !0;
      var e = 0,
        t = ye;
      try {
        var n = Nt;
        for (ye = 1; e < n.length; e++) {
          var r = n[e];
          do r = r(!0);
          while (r !== null);
        }
        ((Nt = null), (bo = !1));
      } catch (o) {
        throw (Nt !== null && (Nt = Nt.slice(e + 1)), pl(_i, tn), o);
      } finally {
        ((ye = t), (ra = !1));
      }
    }
    return null;
  }
  var Kn = [],
    Qn = 0,
    _o = null,
    jo = 0,
    ft = [],
    pt = 0,
    vn = null,
    It = 1,
    Dt = "";
  function wn(e, t) {
    ((Kn[Qn++] = jo), (Kn[Qn++] = _o), (_o = e), (jo = t));
  }
  function fu(e, t, n) {
    ((ft[pt++] = It), (ft[pt++] = Dt), (ft[pt++] = vn), (vn = e));
    var r = It;
    e = Dt;
    var o = 32 - xt(r) - 1;
    ((r &= ~(1 << o)), (n += 1));
    var a = 32 - xt(t) + o;
    if (30 < a) {
      var c = o - (o % 5);
      ((a = (r & ((1 << c) - 1)).toString(32)),
        (r >>= c),
        (o -= c),
        (It = (1 << (32 - xt(t) + o)) | (n << o) | r),
        (Dt = a + e));
    } else ((It = (1 << a) | (n << o) | r), (Dt = e));
  }
  function oa(e) {
    e.return !== null && (wn(e, 1), fu(e, 1, 0));
  }
  function ia(e) {
    for (; e === _o;)
      ((_o = Kn[--Qn]), (Kn[Qn] = null), (jo = Kn[--Qn]), (Kn[Qn] = null));
    for (; e === vn;)
      ((vn = ft[--pt]),
        (ft[pt] = null),
        (Dt = ft[--pt]),
        (ft[pt] = null),
        (It = ft[--pt]),
        (ft[pt] = null));
  }
  var ut = null,
    ct = null,
    Ee = !1,
    St = null;
  function pu(e, t) {
    var n = yt(5, null, null, 0);
    ((n.elementType = "DELETED"),
      (n.stateNode = t),
      (n.return = e),
      (t = e.deletions),
      t === null ? ((e.deletions = [n]), (e.flags |= 16)) : t.push(n));
  }
  function mu(e, t) {
    switch (e.tag) {
      case 5:
        var n = e.type;
        return (
          (t =
            t.nodeType !== 1 || n.toLowerCase() !== t.nodeName.toLowerCase()
              ? null
              : t),
          t !== null
            ? ((e.stateNode = t), (ut = e), (ct = Yt(t.firstChild)), !0)
            : !1
        );
      case 6:
        return (
          (t = e.pendingProps === "" || t.nodeType !== 3 ? null : t),
          t !== null ? ((e.stateNode = t), (ut = e), (ct = null), !0) : !1
        );
      case 13:
        return (
          (t = t.nodeType !== 8 ? null : t),
          t !== null
            ? ((n = vn !== null ? { id: It, overflow: Dt } : null),
              (e.memoizedState = {
                dehydrated: t,
                treeContext: n,
                retryLane: 1073741824,
              }),
              (n = yt(18, null, null, 0)),
              (n.stateNode = t),
              (n.return = e),
              (e.child = n),
              (ut = e),
              (ct = null),
              !0)
            : !1
        );
      default:
        return !1;
    }
  }
  function aa(e) {
    return (e.mode & 1) !== 0 && (e.flags & 128) === 0;
  }
  function sa(e) {
    if (Ee) {
      var t = ct;
      if (t) {
        var n = t;
        if (!mu(e, t)) {
          if (aa(e)) throw Error(l(418));
          t = Yt(n.nextSibling);
          var r = ut;
          t && mu(e, t)
            ? pu(r, n)
            : ((e.flags = (e.flags & -4097) | 2), (Ee = !1), (ut = e));
        }
      } else {
        if (aa(e)) throw Error(l(418));
        ((e.flags = (e.flags & -4097) | 2), (Ee = !1), (ut = e));
      }
    }
  }
  function hu(e) {
    for (
      e = e.return;
      e !== null && e.tag !== 5 && e.tag !== 3 && e.tag !== 13;
    )
      e = e.return;
    ut = e;
  }
  function Eo(e) {
    if (e !== ut) return !1;
    if (!Ee) return (hu(e), (Ee = !0), !1);
    var t;
    if (
      ((t = e.tag !== 3) &&
        !(t = e.tag !== 5) &&
        ((t = e.type),
        (t = t !== "head" && t !== "body" && !Yi(e.type, e.memoizedProps))),
      t && (t = ct))
    ) {
      if (aa(e)) throw (gu(), Error(l(418)));
      for (; t;) (pu(e, t), (t = Yt(t.nextSibling)));
    }
    if ((hu(e), e.tag === 13)) {
      if (((e = e.memoizedState), (e = e !== null ? e.dehydrated : null), !e))
        throw Error(l(317));
      e: {
        for (e = e.nextSibling, t = 0; e;) {
          if (e.nodeType === 8) {
            var n = e.data;
            if (n === "/$") {
              if (t === 0) {
                ct = Yt(e.nextSibling);
                break e;
              }
              t--;
            } else (n !== "$" && n !== "$!" && n !== "$?") || t++;
          }
          e = e.nextSibling;
        }
        ct = null;
      }
    } else ct = ut ? Yt(e.stateNode.nextSibling) : null;
    return !0;
  }
  function gu() {
    for (var e = ct; e;) e = Yt(e.nextSibling);
  }
  function Gn() {
    ((ct = ut = null), (Ee = !1));
  }
  function la(e) {
    St === null ? (St = [e]) : St.push(e);
  }
  var jp = ee.ReactCurrentBatchConfig;
  function Lr(e, t, n) {
    if (
      ((e = n.ref),
      e !== null && typeof e != "function" && typeof e != "object")
    ) {
      if (n._owner) {
        if (((n = n._owner), n)) {
          if (n.tag !== 1) throw Error(l(309));
          var r = n.stateNode;
        }
        if (!r) throw Error(l(147, e));
        var o = r,
          a = "" + e;
        return t !== null &&
          t.ref !== null &&
          typeof t.ref == "function" &&
          t.ref._stringRef === a
          ? t.ref
          : ((t = function (c) {
              var f = o.refs;
              c === null ? delete f[a] : (f[a] = c);
            }),
            (t._stringRef = a),
            t);
      }
      if (typeof e != "string") throw Error(l(284));
      if (!n._owner) throw Error(l(290, e));
    }
    return e;
  }
  function Ao(e, t) {
    throw (
      (e = Object.prototype.toString.call(t)),
      Error(
        l(
          31,
          e === "[object Object]"
            ? "object with keys {" + Object.keys(t).join(", ") + "}"
            : e,
        ),
      )
    );
  }
  function yu(e) {
    var t = e._init;
    return t(e._payload);
  }
  function vu(e) {
    function t(v, g) {
      if (e) {
        var w = v.deletions;
        w === null ? ((v.deletions = [g]), (v.flags |= 16)) : w.push(g);
      }
    }
    function n(v, g) {
      if (!e) return null;
      for (; g !== null;) (t(v, g), (g = g.sibling));
      return null;
    }
    function r(v, g) {
      for (v = new Map(); g !== null;)
        (g.key !== null ? v.set(g.key, g) : v.set(g.index, g), (g = g.sibling));
      return v;
    }
    function o(v, g) {
      return ((v = cn(v, g)), (v.index = 0), (v.sibling = null), v);
    }
    function a(v, g, w) {
      return (
        (v.index = w),
        e
          ? ((w = v.alternate),
            w !== null
              ? ((w = w.index), w < g ? ((v.flags |= 2), g) : w)
              : ((v.flags |= 2), g))
          : ((v.flags |= 1048576), g)
      );
    }
    function c(v) {
      return (e && v.alternate === null && (v.flags |= 2), v);
    }
    function f(v, g, w, z) {
      return g === null || g.tag !== 6
        ? ((g = Xa(w, v.mode, z)), (g.return = v), g)
        : ((g = o(g, w)), (g.return = v), g);
    }
    function m(v, g, w, z) {
      var H = w.type;
      return H === re
        ? P(v, g, w.props.children, z, w.key)
        : g !== null &&
            (g.elementType === H ||
              (typeof H == "object" &&
                H !== null &&
                H.$$typeof === Ae &&
                yu(H) === g.type))
          ? ((z = o(g, w.props)), (z.ref = Lr(v, g, w)), (z.return = v), z)
          : ((z = Yo(w.type, w.key, w.props, null, v.mode, z)),
            (z.ref = Lr(v, g, w)),
            (z.return = v),
            z);
    }
    function x(v, g, w, z) {
      return g === null ||
        g.tag !== 4 ||
        g.stateNode.containerInfo !== w.containerInfo ||
        g.stateNode.implementation !== w.implementation
        ? ((g = es(w, v.mode, z)), (g.return = v), g)
        : ((g = o(g, w.children || [])), (g.return = v), g);
    }
    function P(v, g, w, z, H) {
      return g === null || g.tag !== 7
        ? ((g = En(w, v.mode, z, H)), (g.return = v), g)
        : ((g = o(g, w)), (g.return = v), g);
    }
    function T(v, g, w) {
      if ((typeof g == "string" && g !== "") || typeof g == "number")
        return ((g = Xa("" + g, v.mode, w)), (g.return = v), g);
      if (typeof g == "object" && g !== null) {
        switch (g.$$typeof) {
          case ge:
            return (
              (w = Yo(g.type, g.key, g.props, null, v.mode, w)),
              (w.ref = Lr(v, null, g)),
              (w.return = v),
              w
            );
          case fe:
            return ((g = es(g, v.mode, w)), (g.return = v), g);
          case Ae:
            var z = g._init;
            return T(v, z(g._payload), w);
        }
        if (lr(g) || E(g))
          return ((g = En(g, v.mode, w, null)), (g.return = v), g);
        Ao(v, g);
      }
      return null;
    }
    function A(v, g, w, z) {
      var H = g !== null ? g.key : null;
      if ((typeof w == "string" && w !== "") || typeof w == "number")
        return H !== null ? null : f(v, g, "" + w, z);
      if (typeof w == "object" && w !== null) {
        switch (w.$$typeof) {
          case ge:
            return w.key === H ? m(v, g, w, z) : null;
          case fe:
            return w.key === H ? x(v, g, w, z) : null;
          case Ae:
            return ((H = w._init), A(v, g, H(w._payload), z));
        }
        if (lr(w) || E(w)) return H !== null ? null : P(v, g, w, z, null);
        Ao(v, w);
      }
      return null;
    }
    function I(v, g, w, z, H) {
      if ((typeof z == "string" && z !== "") || typeof z == "number")
        return ((v = v.get(w) || null), f(g, v, "" + z, H));
      if (typeof z == "object" && z !== null) {
        switch (z.$$typeof) {
          case ge:
            return (
              (v = v.get(z.key === null ? w : z.key) || null),
              m(g, v, z, H)
            );
          case fe:
            return (
              (v = v.get(z.key === null ? w : z.key) || null),
              x(g, v, z, H)
            );
          case Ae:
            var Z = z._init;
            return I(v, g, w, Z(z._payload), H);
        }
        if (lr(z) || E(z)) return ((v = v.get(w) || null), P(g, v, z, H, null));
        Ao(g, z);
      }
      return null;
    }
    function $(v, g, w, z) {
      for (
        var H = null, Z = null, q = g, X = (g = 0), Be = null;
        q !== null && X < w.length;
        X++
      ) {
        q.index > X ? ((Be = q), (q = null)) : (Be = q.sibling);
        var me = A(v, q, w[X], z);
        if (me === null) {
          q === null && (q = Be);
          break;
        }
        (e && q && me.alternate === null && t(v, q),
          (g = a(me, g, X)),
          Z === null ? (H = me) : (Z.sibling = me),
          (Z = me),
          (q = Be));
      }
      if (X === w.length) return (n(v, q), Ee && wn(v, X), H);
      if (q === null) {
        for (; X < w.length; X++)
          ((q = T(v, w[X], z)),
            q !== null &&
              ((g = a(q, g, X)),
              Z === null ? (H = q) : (Z.sibling = q),
              (Z = q)));
        return (Ee && wn(v, X), H);
      }
      for (q = r(v, q); X < w.length; X++)
        ((Be = I(q, v, X, w[X], z)),
          Be !== null &&
            (e &&
              Be.alternate !== null &&
              q.delete(Be.key === null ? X : Be.key),
            (g = a(Be, g, X)),
            Z === null ? (H = Be) : (Z.sibling = Be),
            (Z = Be)));
      return (
        e &&
          q.forEach(function (dn) {
            return t(v, dn);
          }),
        Ee && wn(v, X),
        H
      );
    }
    function W(v, g, w, z) {
      var H = E(w);
      if (typeof H != "function") throw Error(l(150));
      if (((w = H.call(w)), w == null)) throw Error(l(151));
      for (
        var Z = (H = null), q = g, X = (g = 0), Be = null, me = w.next();
        q !== null && !me.done;
        X++, me = w.next()
      ) {
        q.index > X ? ((Be = q), (q = null)) : (Be = q.sibling);
        var dn = A(v, q, me.value, z);
        if (dn === null) {
          q === null && (q = Be);
          break;
        }
        (e && q && dn.alternate === null && t(v, q),
          (g = a(dn, g, X)),
          Z === null ? (H = dn) : (Z.sibling = dn),
          (Z = dn),
          (q = Be));
      }
      if (me.done) return (n(v, q), Ee && wn(v, X), H);
      if (q === null) {
        for (; !me.done; X++, me = w.next())
          ((me = T(v, me.value, z)),
            me !== null &&
              ((g = a(me, g, X)),
              Z === null ? (H = me) : (Z.sibling = me),
              (Z = me)));
        return (Ee && wn(v, X), H);
      }
      for (q = r(v, q); !me.done; X++, me = w.next())
        ((me = I(q, v, X, me.value, z)),
          me !== null &&
            (e &&
              me.alternate !== null &&
              q.delete(me.key === null ? X : me.key),
            (g = a(me, g, X)),
            Z === null ? (H = me) : (Z.sibling = me),
            (Z = me)));
      return (
        e &&
          q.forEach(function (im) {
            return t(v, im);
          }),
        Ee && wn(v, X),
        H
      );
    }
    function Oe(v, g, w, z) {
      if (
        (typeof w == "object" &&
          w !== null &&
          w.type === re &&
          w.key === null &&
          (w = w.props.children),
        typeof w == "object" && w !== null)
      ) {
        switch (w.$$typeof) {
          case ge:
            e: {
              for (var H = w.key, Z = g; Z !== null;) {
                if (Z.key === H) {
                  if (((H = w.type), H === re)) {
                    if (Z.tag === 7) {
                      (n(v, Z.sibling),
                        (g = o(Z, w.props.children)),
                        (g.return = v),
                        (v = g));
                      break e;
                    }
                  } else if (
                    Z.elementType === H ||
                    (typeof H == "object" &&
                      H !== null &&
                      H.$$typeof === Ae &&
                      yu(H) === Z.type)
                  ) {
                    (n(v, Z.sibling),
                      (g = o(Z, w.props)),
                      (g.ref = Lr(v, Z, w)),
                      (g.return = v),
                      (v = g));
                    break e;
                  }
                  n(v, Z);
                  break;
                } else t(v, Z);
                Z = Z.sibling;
              }
              w.type === re
                ? ((g = En(w.props.children, v.mode, z, w.key)),
                  (g.return = v),
                  (v = g))
                : ((z = Yo(w.type, w.key, w.props, null, v.mode, z)),
                  (z.ref = Lr(v, g, w)),
                  (z.return = v),
                  (v = z));
            }
            return c(v);
          case fe:
            e: {
              for (Z = w.key; g !== null;) {
                if (g.key === Z)
                  if (
                    g.tag === 4 &&
                    g.stateNode.containerInfo === w.containerInfo &&
                    g.stateNode.implementation === w.implementation
                  ) {
                    (n(v, g.sibling),
                      (g = o(g, w.children || [])),
                      (g.return = v),
                      (v = g));
                    break e;
                  } else {
                    n(v, g);
                    break;
                  }
                else t(v, g);
                g = g.sibling;
              }
              ((g = es(w, v.mode, z)), (g.return = v), (v = g));
            }
            return c(v);
          case Ae:
            return ((Z = w._init), Oe(v, g, Z(w._payload), z));
        }
        if (lr(w)) return $(v, g, w, z);
        if (E(w)) return W(v, g, w, z);
        Ao(v, w);
      }
      return (typeof w == "string" && w !== "") || typeof w == "number"
        ? ((w = "" + w),
          g !== null && g.tag === 6
            ? (n(v, g.sibling), (g = o(g, w)), (g.return = v), (v = g))
            : (n(v, g), (g = Xa(w, v.mode, z)), (g.return = v), (v = g)),
          c(v))
        : n(v, g);
    }
    return Oe;
  }
  var Zn = vu(!0),
    wu = vu(!1),
    Po = Xt(null),
    To = null,
    qn = null,
    ua = null;
  function ca() {
    ua = qn = To = null;
  }
  function da(e) {
    var t = Po.current;
    (je(Po), (e._currentValue = t));
  }
  function fa(e, t, n) {
    for (; e !== null;) {
      var r = e.alternate;
      if (
        ((e.childLanes & t) !== t
          ? ((e.childLanes |= t), r !== null && (r.childLanes |= t))
          : r !== null && (r.childLanes & t) !== t && (r.childLanes |= t),
        e === n)
      )
        break;
      e = e.return;
    }
  }
  function Yn(e, t) {
    ((To = e),
      (ua = qn = null),
      (e = e.dependencies),
      e !== null &&
        e.firstContext !== null &&
        ((e.lanes & t) !== 0 && (rt = !0), (e.firstContext = null)));
  }
  function mt(e) {
    var t = e._currentValue;
    if (ua !== e)
      if (((e = { context: e, memoizedValue: t, next: null }), qn === null)) {
        if (To === null) throw Error(l(308));
        ((qn = e), (To.dependencies = { lanes: 0, firstContext: e }));
      } else qn = qn.next = e;
    return t;
  }
  var xn = null;
  function pa(e) {
    xn === null ? (xn = [e]) : xn.push(e);
  }
  function xu(e, t, n, r) {
    var o = t.interleaved;
    return (
      o === null ? ((n.next = n), pa(t)) : ((n.next = o.next), (o.next = n)),
      (t.interleaved = n),
      Ut(e, r)
    );
  }
  function Ut(e, t) {
    e.lanes |= t;
    var n = e.alternate;
    for (n !== null && (n.lanes |= t), n = e, e = e.return; e !== null;)
      ((e.childLanes |= t),
        (n = e.alternate),
        n !== null && (n.childLanes |= t),
        (n = e),
        (e = e.return));
    return n.tag === 3 ? n.stateNode : null;
  }
  var nn = !1;
  function ma(e) {
    e.updateQueue = {
      baseState: e.memoizedState,
      firstBaseUpdate: null,
      lastBaseUpdate: null,
      shared: { pending: null, interleaved: null, lanes: 0 },
      effects: null,
    };
  }
  function ku(e, t) {
    ((e = e.updateQueue),
      t.updateQueue === e &&
        (t.updateQueue = {
          baseState: e.baseState,
          firstBaseUpdate: e.firstBaseUpdate,
          lastBaseUpdate: e.lastBaseUpdate,
          shared: e.shared,
          effects: e.effects,
        }));
  }
  function $t(e, t) {
    return {
      eventTime: e,
      lane: t,
      tag: 0,
      payload: null,
      callback: null,
      next: null,
    };
  }
  function rn(e, t, n) {
    var r = e.updateQueue;
    if (r === null) return null;
    if (((r = r.shared), (de & 2) !== 0)) {
      var o = r.pending;
      return (
        o === null ? (t.next = t) : ((t.next = o.next), (o.next = t)),
        (r.pending = t),
        Ut(e, n)
      );
    }
    return (
      (o = r.interleaved),
      o === null ? ((t.next = t), pa(r)) : ((t.next = o.next), (o.next = t)),
      (r.interleaved = t),
      Ut(e, n)
    );
  }
  function zo(e, t, n) {
    if (
      ((t = t.updateQueue), t !== null && ((t = t.shared), (n & 4194240) !== 0))
    ) {
      var r = t.lanes;
      ((r &= e.pendingLanes), (n |= r), (t.lanes = n), Ai(e, n));
    }
  }
  function Su(e, t) {
    var n = e.updateQueue,
      r = e.alternate;
    if (r !== null && ((r = r.updateQueue), n === r)) {
      var o = null,
        a = null;
      if (((n = n.firstBaseUpdate), n !== null)) {
        do {
          var c = {
            eventTime: n.eventTime,
            lane: n.lane,
            tag: n.tag,
            payload: n.payload,
            callback: n.callback,
            next: null,
          };
          (a === null ? (o = a = c) : (a = a.next = c), (n = n.next));
        } while (n !== null);
        a === null ? (o = a = t) : (a = a.next = t);
      } else o = a = t;
      ((n = {
        baseState: r.baseState,
        firstBaseUpdate: o,
        lastBaseUpdate: a,
        shared: r.shared,
        effects: r.effects,
      }),
        (e.updateQueue = n));
      return;
    }
    ((e = n.lastBaseUpdate),
      e === null ? (n.firstBaseUpdate = t) : (e.next = t),
      (n.lastBaseUpdate = t));
  }
  function Mo(e, t, n, r) {
    var o = e.updateQueue;
    nn = !1;
    var a = o.firstBaseUpdate,
      c = o.lastBaseUpdate,
      f = o.shared.pending;
    if (f !== null) {
      o.shared.pending = null;
      var m = f,
        x = m.next;
      ((m.next = null), c === null ? (a = x) : (c.next = x), (c = m));
      var P = e.alternate;
      P !== null &&
        ((P = P.updateQueue),
        (f = P.lastBaseUpdate),
        f !== c &&
          (f === null ? (P.firstBaseUpdate = x) : (f.next = x),
          (P.lastBaseUpdate = m)));
    }
    if (a !== null) {
      var T = o.baseState;
      ((c = 0), (P = x = m = null), (f = a));
      do {
        var A = f.lane,
          I = f.eventTime;
        if ((r & A) === A) {
          P !== null &&
            (P = P.next =
              {
                eventTime: I,
                lane: 0,
                tag: f.tag,
                payload: f.payload,
                callback: f.callback,
                next: null,
              });
          e: {
            var $ = e,
              W = f;
            switch (((A = t), (I = n), W.tag)) {
              case 1:
                if ((($ = W.payload), typeof $ == "function")) {
                  T = $.call(I, T, A);
                  break e;
                }
                T = $;
                break e;
              case 3:
                $.flags = ($.flags & -65537) | 128;
              case 0:
                if (
                  (($ = W.payload),
                  (A = typeof $ == "function" ? $.call(I, T, A) : $),
                  A == null)
                )
                  break e;
                T = _({}, T, A);
                break e;
              case 2:
                nn = !0;
            }
          }
          f.callback !== null &&
            f.lane !== 0 &&
            ((e.flags |= 64),
            (A = o.effects),
            A === null ? (o.effects = [f]) : A.push(f));
        } else
          ((I = {
            eventTime: I,
            lane: A,
            tag: f.tag,
            payload: f.payload,
            callback: f.callback,
            next: null,
          }),
            P === null ? ((x = P = I), (m = T)) : (P = P.next = I),
            (c |= A));
        if (((f = f.next), f === null)) {
          if (((f = o.shared.pending), f === null)) break;
          ((A = f),
            (f = A.next),
            (A.next = null),
            (o.lastBaseUpdate = A),
            (o.shared.pending = null));
        }
      } while (!0);
      if (
        (P === null && (m = T),
        (o.baseState = m),
        (o.firstBaseUpdate = x),
        (o.lastBaseUpdate = P),
        (t = o.shared.interleaved),
        t !== null)
      ) {
        o = t;
        do ((c |= o.lane), (o = o.next));
        while (o !== t);
      } else a === null && (o.shared.lanes = 0);
      ((Cn |= c), (e.lanes = c), (e.memoizedState = T));
    }
  }
  function Cu(e, t, n) {
    if (((e = t.effects), (t.effects = null), e !== null))
      for (t = 0; t < e.length; t++) {
        var r = e[t],
          o = r.callback;
        if (o !== null) {
          if (((r.callback = null), (r = n), typeof o != "function"))
            throw Error(l(191, o));
          o.call(r);
        }
      }
  }
  var Rr = {},
    Tt = Xt(Rr),
    Or = Xt(Rr),
    Nr = Xt(Rr);
  function kn(e) {
    if (e === Rr) throw Error(l(174));
    return e;
  }
  function ha(e, t) {
    switch ((be(Nr, t), be(Or, e), be(Tt, Rr), (e = t.nodeType), e)) {
      case 9:
      case 11:
        t = (t = t.documentElement) ? t.namespaceURI : gi(null, "");
        break;
      default:
        ((e = e === 8 ? t.parentNode : t),
          (t = e.namespaceURI || null),
          (e = e.tagName),
          (t = gi(t, e)));
    }
    (je(Tt), be(Tt, t));
  }
  function Xn() {
    (je(Tt), je(Or), je(Nr));
  }
  function bu(e) {
    kn(Nr.current);
    var t = kn(Tt.current),
      n = gi(t, e.type);
    t !== n && (be(Or, e), be(Tt, n));
  }
  function ga(e) {
    Or.current === e && (je(Tt), je(Or));
  }
  var Te = Xt(0);
  function Lo(e) {
    for (var t = e; t !== null;) {
      if (t.tag === 13) {
        var n = t.memoizedState;
        if (
          n !== null &&
          ((n = n.dehydrated), n === null || n.data === "$?" || n.data === "$!")
        )
          return t;
      } else if (t.tag === 19 && t.memoizedProps.revealOrder !== void 0) {
        if ((t.flags & 128) !== 0) return t;
      } else if (t.child !== null) {
        ((t.child.return = t), (t = t.child));
        continue;
      }
      if (t === e) break;
      for (; t.sibling === null;) {
        if (t.return === null || t.return === e) return null;
        t = t.return;
      }
      ((t.sibling.return = t.return), (t = t.sibling));
    }
    return null;
  }
  var ya = [];
  function va() {
    for (var e = 0; e < ya.length; e++)
      ya[e]._workInProgressVersionPrimary = null;
    ya.length = 0;
  }
  var Ro = ee.ReactCurrentDispatcher,
    wa = ee.ReactCurrentBatchConfig,
    Sn = 0,
    ze = null,
    De = null,
    Fe = null,
    Oo = !1,
    Ir = !1,
    Dr = 0,
    Ep = 0;
  function Qe() {
    throw Error(l(321));
  }
  function xa(e, t) {
    if (t === null) return !1;
    for (var n = 0; n < t.length && n < e.length; n++)
      if (!kt(e[n], t[n])) return !1;
    return !0;
  }
  function ka(e, t, n, r, o, a) {
    if (
      ((Sn = a),
      (ze = t),
      (t.memoizedState = null),
      (t.updateQueue = null),
      (t.lanes = 0),
      (Ro.current = e === null || e.memoizedState === null ? zp : Mp),
      (e = n(r, o)),
      Ir)
    ) {
      a = 0;
      do {
        if (((Ir = !1), (Dr = 0), 25 <= a)) throw Error(l(301));
        ((a += 1),
          (Fe = De = null),
          (t.updateQueue = null),
          (Ro.current = Lp),
          (e = n(r, o)));
      } while (Ir);
    }
    if (
      ((Ro.current = Do),
      (t = De !== null && De.next !== null),
      (Sn = 0),
      (Fe = De = ze = null),
      (Oo = !1),
      t)
    )
      throw Error(l(300));
    return e;
  }
  function Sa() {
    var e = Dr !== 0;
    return ((Dr = 0), e);
  }
  function zt() {
    var e = {
      memoizedState: null,
      baseState: null,
      baseQueue: null,
      queue: null,
      next: null,
    };
    return (Fe === null ? (ze.memoizedState = Fe = e) : (Fe = Fe.next = e), Fe);
  }
  function ht() {
    if (De === null) {
      var e = ze.alternate;
      e = e !== null ? e.memoizedState : null;
    } else e = De.next;
    var t = Fe === null ? ze.memoizedState : Fe.next;
    if (t !== null) ((Fe = t), (De = e));
    else {
      if (e === null) throw Error(l(310));
      ((De = e),
        (e = {
          memoizedState: De.memoizedState,
          baseState: De.baseState,
          baseQueue: De.baseQueue,
          queue: De.queue,
          next: null,
        }),
        Fe === null ? (ze.memoizedState = Fe = e) : (Fe = Fe.next = e));
    }
    return Fe;
  }
  function Ur(e, t) {
    return typeof t == "function" ? t(e) : t;
  }
  function Ca(e) {
    var t = ht(),
      n = t.queue;
    if (n === null) throw Error(l(311));
    n.lastRenderedReducer = e;
    var r = De,
      o = r.baseQueue,
      a = n.pending;
    if (a !== null) {
      if (o !== null) {
        var c = o.next;
        ((o.next = a.next), (a.next = c));
      }
      ((r.baseQueue = o = a), (n.pending = null));
    }
    if (o !== null) {
      ((a = o.next), (r = r.baseState));
      var f = (c = null),
        m = null,
        x = a;
      do {
        var P = x.lane;
        if ((Sn & P) === P)
          (m !== null &&
            (m = m.next =
              {
                lane: 0,
                action: x.action,
                hasEagerState: x.hasEagerState,
                eagerState: x.eagerState,
                next: null,
              }),
            (r = x.hasEagerState ? x.eagerState : e(r, x.action)));
        else {
          var T = {
            lane: P,
            action: x.action,
            hasEagerState: x.hasEagerState,
            eagerState: x.eagerState,
            next: null,
          };
          (m === null ? ((f = m = T), (c = r)) : (m = m.next = T),
            (ze.lanes |= P),
            (Cn |= P));
        }
        x = x.next;
      } while (x !== null && x !== a);
      (m === null ? (c = r) : (m.next = f),
        kt(r, t.memoizedState) || (rt = !0),
        (t.memoizedState = r),
        (t.baseState = c),
        (t.baseQueue = m),
        (n.lastRenderedState = r));
    }
    if (((e = n.interleaved), e !== null)) {
      o = e;
      do ((a = o.lane), (ze.lanes |= a), (Cn |= a), (o = o.next));
      while (o !== e);
    } else o === null && (n.lanes = 0);
    return [t.memoizedState, n.dispatch];
  }
  function ba(e) {
    var t = ht(),
      n = t.queue;
    if (n === null) throw Error(l(311));
    n.lastRenderedReducer = e;
    var r = n.dispatch,
      o = n.pending,
      a = t.memoizedState;
    if (o !== null) {
      n.pending = null;
      var c = (o = o.next);
      do ((a = e(a, c.action)), (c = c.next));
      while (c !== o);
      (kt(a, t.memoizedState) || (rt = !0),
        (t.memoizedState = a),
        t.baseQueue === null && (t.baseState = a),
        (n.lastRenderedState = a));
    }
    return [a, r];
  }
  function _u() {}
  function ju(e, t) {
    var n = ze,
      r = ht(),
      o = t(),
      a = !kt(r.memoizedState, o);
    if (
      (a && ((r.memoizedState = o), (rt = !0)),
      (r = r.queue),
      _a(Pu.bind(null, n, r, e), [e]),
      r.getSnapshot !== t || a || (Fe !== null && Fe.memoizedState.tag & 1))
    ) {
      if (
        ((n.flags |= 2048),
        $r(9, Au.bind(null, n, r, o, t), void 0, null),
        We === null)
      )
        throw Error(l(349));
      (Sn & 30) !== 0 || Eu(n, t, o);
    }
    return o;
  }
  function Eu(e, t, n) {
    ((e.flags |= 16384),
      (e = { getSnapshot: t, value: n }),
      (t = ze.updateQueue),
      t === null
        ? ((t = { lastEffect: null, stores: null }),
          (ze.updateQueue = t),
          (t.stores = [e]))
        : ((n = t.stores), n === null ? (t.stores = [e]) : n.push(e)));
  }
  function Au(e, t, n, r) {
    ((t.value = n), (t.getSnapshot = r), Tu(t) && zu(e));
  }
  function Pu(e, t, n) {
    return n(function () {
      Tu(t) && zu(e);
    });
  }
  function Tu(e) {
    var t = e.getSnapshot;
    e = e.value;
    try {
      var n = t();
      return !kt(e, n);
    } catch {
      return !0;
    }
  }
  function zu(e) {
    var t = Ut(e, 1);
    t !== null && jt(t, e, 1, -1);
  }
  function Mu(e) {
    var t = zt();
    return (
      typeof e == "function" && (e = e()),
      (t.memoizedState = t.baseState = e),
      (e = {
        pending: null,
        interleaved: null,
        lanes: 0,
        dispatch: null,
        lastRenderedReducer: Ur,
        lastRenderedState: e,
      }),
      (t.queue = e),
      (e = e.dispatch = Tp.bind(null, ze, e)),
      [t.memoizedState, e]
    );
  }
  function $r(e, t, n, r) {
    return (
      (e = { tag: e, create: t, destroy: n, deps: r, next: null }),
      (t = ze.updateQueue),
      t === null
        ? ((t = { lastEffect: null, stores: null }),
          (ze.updateQueue = t),
          (t.lastEffect = e.next = e))
        : ((n = t.lastEffect),
          n === null
            ? (t.lastEffect = e.next = e)
            : ((r = n.next), (n.next = e), (e.next = r), (t.lastEffect = e))),
      e
    );
  }
  function Lu() {
    return ht().memoizedState;
  }
  function No(e, t, n, r) {
    var o = zt();
    ((ze.flags |= e),
      (o.memoizedState = $r(1 | t, n, void 0, r === void 0 ? null : r)));
  }
  function Io(e, t, n, r) {
    var o = ht();
    r = r === void 0 ? null : r;
    var a = void 0;
    if (De !== null) {
      var c = De.memoizedState;
      if (((a = c.destroy), r !== null && xa(r, c.deps))) {
        o.memoizedState = $r(t, n, a, r);
        return;
      }
    }
    ((ze.flags |= e), (o.memoizedState = $r(1 | t, n, a, r)));
  }
  function Ru(e, t) {
    return No(8390656, 8, e, t);
  }
  function _a(e, t) {
    return Io(2048, 8, e, t);
  }
  function Ou(e, t) {
    return Io(4, 2, e, t);
  }
  function Nu(e, t) {
    return Io(4, 4, e, t);
  }
  function Iu(e, t) {
    if (typeof t == "function")
      return (
        (e = e()),
        t(e),
        function () {
          t(null);
        }
      );
    if (t != null)
      return (
        (e = e()),
        (t.current = e),
        function () {
          t.current = null;
        }
      );
  }
  function Du(e, t, n) {
    return (
      (n = n != null ? n.concat([e]) : null),
      Io(4, 4, Iu.bind(null, t, e), n)
    );
  }
  function ja() {}
  function Uu(e, t) {
    var n = ht();
    t = t === void 0 ? null : t;
    var r = n.memoizedState;
    return r !== null && t !== null && xa(t, r[1])
      ? r[0]
      : ((n.memoizedState = [e, t]), e);
  }
  function $u(e, t) {
    var n = ht();
    t = t === void 0 ? null : t;
    var r = n.memoizedState;
    return r !== null && t !== null && xa(t, r[1])
      ? r[0]
      : ((e = e()), (n.memoizedState = [e, t]), e);
  }
  function Fu(e, t, n) {
    return (Sn & 21) === 0
      ? (e.baseState && ((e.baseState = !1), (rt = !0)), (e.memoizedState = n))
      : (kt(n, t) ||
          ((n = yl()), (ze.lanes |= n), (Cn |= n), (e.baseState = !0)),
        t);
  }
  function Ap(e, t) {
    var n = ye;
    ((ye = n !== 0 && 4 > n ? n : 4), e(!0));
    var r = wa.transition;
    wa.transition = {};
    try {
      (e(!1), t());
    } finally {
      ((ye = n), (wa.transition = r));
    }
  }
  function Wu() {
    return ht().memoizedState;
  }
  function Pp(e, t, n) {
    var r = ln(e);
    if (
      ((n = {
        lane: r,
        action: n,
        hasEagerState: !1,
        eagerState: null,
        next: null,
      }),
      Bu(e))
    )
      Hu(t, n);
    else if (((n = xu(e, t, n, r)), n !== null)) {
      var o = Xe();
      (jt(n, e, r, o), Vu(n, t, r));
    }
  }
  function Tp(e, t, n) {
    var r = ln(e),
      o = {
        lane: r,
        action: n,
        hasEagerState: !1,
        eagerState: null,
        next: null,
      };
    if (Bu(e)) Hu(t, o);
    else {
      var a = e.alternate;
      if (
        e.lanes === 0 &&
        (a === null || a.lanes === 0) &&
        ((a = t.lastRenderedReducer), a !== null)
      )
        try {
          var c = t.lastRenderedState,
            f = a(c, n);
          if (((o.hasEagerState = !0), (o.eagerState = f), kt(f, c))) {
            var m = t.interleaved;
            (m === null
              ? ((o.next = o), pa(t))
              : ((o.next = m.next), (m.next = o)),
              (t.interleaved = o));
            return;
          }
        } catch {
        } finally {
        }
      ((n = xu(e, t, o, r)),
        n !== null && ((o = Xe()), jt(n, e, r, o), Vu(n, t, r)));
    }
  }
  function Bu(e) {
    var t = e.alternate;
    return e === ze || (t !== null && t === ze);
  }
  function Hu(e, t) {
    Ir = Oo = !0;
    var n = e.pending;
    (n === null ? (t.next = t) : ((t.next = n.next), (n.next = t)),
      (e.pending = t));
  }
  function Vu(e, t, n) {
    if ((n & 4194240) !== 0) {
      var r = t.lanes;
      ((r &= e.pendingLanes), (n |= r), (t.lanes = n), Ai(e, n));
    }
  }
  var Do = {
      readContext: mt,
      useCallback: Qe,
      useContext: Qe,
      useEffect: Qe,
      useImperativeHandle: Qe,
      useInsertionEffect: Qe,
      useLayoutEffect: Qe,
      useMemo: Qe,
      useReducer: Qe,
      useRef: Qe,
      useState: Qe,
      useDebugValue: Qe,
      useDeferredValue: Qe,
      useTransition: Qe,
      useMutableSource: Qe,
      useSyncExternalStore: Qe,
      useId: Qe,
      unstable_isNewReconciler: !1,
    },
    zp = {
      readContext: mt,
      useCallback: function (e, t) {
        return ((zt().memoizedState = [e, t === void 0 ? null : t]), e);
      },
      useContext: mt,
      useEffect: Ru,
      useImperativeHandle: function (e, t, n) {
        return (
          (n = n != null ? n.concat([e]) : null),
          No(4194308, 4, Iu.bind(null, t, e), n)
        );
      },
      useLayoutEffect: function (e, t) {
        return No(4194308, 4, e, t);
      },
      useInsertionEffect: function (e, t) {
        return No(4, 2, e, t);
      },
      useMemo: function (e, t) {
        var n = zt();
        return (
          (t = t === void 0 ? null : t),
          (e = e()),
          (n.memoizedState = [e, t]),
          e
        );
      },
      useReducer: function (e, t, n) {
        var r = zt();
        return (
          (t = n !== void 0 ? n(t) : t),
          (r.memoizedState = r.baseState = t),
          (e = {
            pending: null,
            interleaved: null,
            lanes: 0,
            dispatch: null,
            lastRenderedReducer: e,
            lastRenderedState: t,
          }),
          (r.queue = e),
          (e = e.dispatch = Pp.bind(null, ze, e)),
          [r.memoizedState, e]
        );
      },
      useRef: function (e) {
        var t = zt();
        return ((e = { current: e }), (t.memoizedState = e));
      },
      useState: Mu,
      useDebugValue: ja,
      useDeferredValue: function (e) {
        return (zt().memoizedState = e);
      },
      useTransition: function () {
        var e = Mu(!1),
          t = e[0];
        return ((e = Ap.bind(null, e[1])), (zt().memoizedState = e), [t, e]);
      },
      useMutableSource: function () {},
      useSyncExternalStore: function (e, t, n) {
        var r = ze,
          o = zt();
        if (Ee) {
          if (n === void 0) throw Error(l(407));
          n = n();
        } else {
          if (((n = t()), We === null)) throw Error(l(349));
          (Sn & 30) !== 0 || Eu(r, t, n);
        }
        o.memoizedState = n;
        var a = { value: n, getSnapshot: t };
        return (
          (o.queue = a),
          Ru(Pu.bind(null, r, a, e), [e]),
          (r.flags |= 2048),
          $r(9, Au.bind(null, r, a, n, t), void 0, null),
          n
        );
      },
      useId: function () {
        var e = zt(),
          t = We.identifierPrefix;
        if (Ee) {
          var n = Dt,
            r = It;
          ((n = (r & ~(1 << (32 - xt(r) - 1))).toString(32) + n),
            (t = ":" + t + "R" + n),
            (n = Dr++),
            0 < n && (t += "H" + n.toString(32)),
            (t += ":"));
        } else ((n = Ep++), (t = ":" + t + "r" + n.toString(32) + ":"));
        return (e.memoizedState = t);
      },
      unstable_isNewReconciler: !1,
    },
    Mp = {
      readContext: mt,
      useCallback: Uu,
      useContext: mt,
      useEffect: _a,
      useImperativeHandle: Du,
      useInsertionEffect: Ou,
      useLayoutEffect: Nu,
      useMemo: $u,
      useReducer: Ca,
      useRef: Lu,
      useState: function () {
        return Ca(Ur);
      },
      useDebugValue: ja,
      useDeferredValue: function (e) {
        var t = ht();
        return Fu(t, De.memoizedState, e);
      },
      useTransition: function () {
        var e = Ca(Ur)[0],
          t = ht().memoizedState;
        return [e, t];
      },
      useMutableSource: _u,
      useSyncExternalStore: ju,
      useId: Wu,
      unstable_isNewReconciler: !1,
    },
    Lp = {
      readContext: mt,
      useCallback: Uu,
      useContext: mt,
      useEffect: _a,
      useImperativeHandle: Du,
      useInsertionEffect: Ou,
      useLayoutEffect: Nu,
      useMemo: $u,
      useReducer: ba,
      useRef: Lu,
      useState: function () {
        return ba(Ur);
      },
      useDebugValue: ja,
      useDeferredValue: function (e) {
        var t = ht();
        return De === null ? (t.memoizedState = e) : Fu(t, De.memoizedState, e);
      },
      useTransition: function () {
        var e = ba(Ur)[0],
          t = ht().memoizedState;
        return [e, t];
      },
      useMutableSource: _u,
      useSyncExternalStore: ju,
      useId: Wu,
      unstable_isNewReconciler: !1,
    };
  function Ct(e, t) {
    if (e && e.defaultProps) {
      ((t = _({}, t)), (e = e.defaultProps));
      for (var n in e) t[n] === void 0 && (t[n] = e[n]);
      return t;
    }
    return t;
  }
  function Ea(e, t, n, r) {
    ((t = e.memoizedState),
      (n = n(r, t)),
      (n = n == null ? t : _({}, t, n)),
      (e.memoizedState = n),
      e.lanes === 0 && (e.updateQueue.baseState = n));
  }
  var Uo = {
    isMounted: function (e) {
      return (e = e._reactInternals) ? hn(e) === e : !1;
    },
    enqueueSetState: function (e, t, n) {
      e = e._reactInternals;
      var r = Xe(),
        o = ln(e),
        a = $t(r, o);
      ((a.payload = t),
        n != null && (a.callback = n),
        (t = rn(e, a, o)),
        t !== null && (jt(t, e, o, r), zo(t, e, o)));
    },
    enqueueReplaceState: function (e, t, n) {
      e = e._reactInternals;
      var r = Xe(),
        o = ln(e),
        a = $t(r, o);
      ((a.tag = 1),
        (a.payload = t),
        n != null && (a.callback = n),
        (t = rn(e, a, o)),
        t !== null && (jt(t, e, o, r), zo(t, e, o)));
    },
    enqueueForceUpdate: function (e, t) {
      e = e._reactInternals;
      var n = Xe(),
        r = ln(e),
        o = $t(n, r);
      ((o.tag = 2),
        t != null && (o.callback = t),
        (t = rn(e, o, r)),
        t !== null && (jt(t, e, r, n), zo(t, e, r)));
    },
  };
  function Ju(e, t, n, r, o, a, c) {
    return (
      (e = e.stateNode),
      typeof e.shouldComponentUpdate == "function"
        ? e.shouldComponentUpdate(r, a, c)
        : t.prototype && t.prototype.isPureReactComponent
          ? !jr(n, r) || !jr(o, a)
          : !0
    );
  }
  function Ku(e, t, n) {
    var r = !1,
      o = en,
      a = t.contextType;
    return (
      typeof a == "object" && a !== null
        ? (a = mt(a))
        : ((o = nt(t) ? yn : Ke.current),
          (r = t.contextTypes),
          (a = (r = r != null) ? Jn(e, o) : en)),
      (t = new t(n, a)),
      (e.memoizedState =
        t.state !== null && t.state !== void 0 ? t.state : null),
      (t.updater = Uo),
      (e.stateNode = t),
      (t._reactInternals = e),
      r &&
        ((e = e.stateNode),
        (e.__reactInternalMemoizedUnmaskedChildContext = o),
        (e.__reactInternalMemoizedMaskedChildContext = a)),
      t
    );
  }
  function Qu(e, t, n, r) {
    ((e = t.state),
      typeof t.componentWillReceiveProps == "function" &&
        t.componentWillReceiveProps(n, r),
      typeof t.UNSAFE_componentWillReceiveProps == "function" &&
        t.UNSAFE_componentWillReceiveProps(n, r),
      t.state !== e && Uo.enqueueReplaceState(t, t.state, null));
  }
  function Aa(e, t, n, r) {
    var o = e.stateNode;
    ((o.props = n), (o.state = e.memoizedState), (o.refs = {}), ma(e));
    var a = t.contextType;
    (typeof a == "object" && a !== null
      ? (o.context = mt(a))
      : ((a = nt(t) ? yn : Ke.current), (o.context = Jn(e, a))),
      (o.state = e.memoizedState),
      (a = t.getDerivedStateFromProps),
      typeof a == "function" && (Ea(e, t, a, n), (o.state = e.memoizedState)),
      typeof t.getDerivedStateFromProps == "function" ||
        typeof o.getSnapshotBeforeUpdate == "function" ||
        (typeof o.UNSAFE_componentWillMount != "function" &&
          typeof o.componentWillMount != "function") ||
        ((t = o.state),
        typeof o.componentWillMount == "function" && o.componentWillMount(),
        typeof o.UNSAFE_componentWillMount == "function" &&
          o.UNSAFE_componentWillMount(),
        t !== o.state && Uo.enqueueReplaceState(o, o.state, null),
        Mo(e, n, o, r),
        (o.state = e.memoizedState)),
      typeof o.componentDidMount == "function" && (e.flags |= 4194308));
  }
  function er(e, t) {
    try {
      var n = "",
        r = t;
      do ((n += ae(r)), (r = r.return));
      while (r);
      var o = n;
    } catch (a) {
      o =
        `
Error generating stack: ` +
        a.message +
        `
` +
        a.stack;
    }
    return { value: e, source: t, stack: o, digest: null };
  }
  function Pa(e, t, n) {
    return { value: e, source: null, stack: n ?? null, digest: t ?? null };
  }
  function Ta(e, t) {
    try {
      console.error(t.value);
    } catch (n) {
      setTimeout(function () {
        throw n;
      });
    }
  }
  var Rp = typeof WeakMap == "function" ? WeakMap : Map;
  function Gu(e, t, n) {
    ((n = $t(-1, n)), (n.tag = 3), (n.payload = { element: null }));
    var r = t.value;
    return (
      (n.callback = function () {
        (Jo || ((Jo = !0), (Va = r)), Ta(e, t));
      }),
      n
    );
  }
  function Zu(e, t, n) {
    ((n = $t(-1, n)), (n.tag = 3));
    var r = e.type.getDerivedStateFromError;
    if (typeof r == "function") {
      var o = t.value;
      ((n.payload = function () {
        return r(o);
      }),
        (n.callback = function () {
          Ta(e, t);
        }));
    }
    var a = e.stateNode;
    return (
      a !== null &&
        typeof a.componentDidCatch == "function" &&
        (n.callback = function () {
          (Ta(e, t),
            typeof r != "function" &&
              (an === null ? (an = new Set([this])) : an.add(this)));
          var c = t.stack;
          this.componentDidCatch(t.value, {
            componentStack: c !== null ? c : "",
          });
        }),
      n
    );
  }
  function qu(e, t, n) {
    var r = e.pingCache;
    if (r === null) {
      r = e.pingCache = new Rp();
      var o = new Set();
      r.set(t, o);
    } else ((o = r.get(t)), o === void 0 && ((o = new Set()), r.set(t, o)));
    o.has(n) || (o.add(n), (e = Qp.bind(null, e, t, n)), t.then(e, e));
  }
  function Yu(e) {
    do {
      var t;
      if (
        ((t = e.tag === 13) &&
          ((t = e.memoizedState),
          (t = t !== null ? t.dehydrated !== null : !0)),
        t)
      )
        return e;
      e = e.return;
    } while (e !== null);
    return null;
  }
  function Xu(e, t, n, r, o) {
    return (e.mode & 1) === 0
      ? (e === t
          ? (e.flags |= 65536)
          : ((e.flags |= 128),
            (n.flags |= 131072),
            (n.flags &= -52805),
            n.tag === 1 &&
              (n.alternate === null
                ? (n.tag = 17)
                : ((t = $t(-1, 1)), (t.tag = 2), rn(n, t, 1))),
            (n.lanes |= 1)),
        e)
      : ((e.flags |= 65536), (e.lanes = o), e);
  }
  var Op = ee.ReactCurrentOwner,
    rt = !1;
  function Ye(e, t, n, r) {
    t.child = e === null ? wu(t, null, n, r) : Zn(t, e.child, n, r);
  }
  function ec(e, t, n, r, o) {
    n = n.render;
    var a = t.ref;
    return (
      Yn(t, o),
      (r = ka(e, t, n, r, a, o)),
      (n = Sa()),
      e !== null && !rt
        ? ((t.updateQueue = e.updateQueue),
          (t.flags &= -2053),
          (e.lanes &= ~o),
          Ft(e, t, o))
        : (Ee && n && oa(t), (t.flags |= 1), Ye(e, t, r, o), t.child)
    );
  }
  function tc(e, t, n, r, o) {
    if (e === null) {
      var a = n.type;
      return typeof a == "function" &&
        !Ya(a) &&
        a.defaultProps === void 0 &&
        n.compare === null &&
        n.defaultProps === void 0
        ? ((t.tag = 15), (t.type = a), nc(e, t, a, r, o))
        : ((e = Yo(n.type, null, r, t, t.mode, o)),
          (e.ref = t.ref),
          (e.return = t),
          (t.child = e));
    }
    if (((a = e.child), (e.lanes & o) === 0)) {
      var c = a.memoizedProps;
      if (
        ((n = n.compare), (n = n !== null ? n : jr), n(c, r) && e.ref === t.ref)
      )
        return Ft(e, t, o);
    }
    return (
      (t.flags |= 1),
      (e = cn(a, r)),
      (e.ref = t.ref),
      (e.return = t),
      (t.child = e)
    );
  }
  function nc(e, t, n, r, o) {
    if (e !== null) {
      var a = e.memoizedProps;
      if (jr(a, r) && e.ref === t.ref)
        if (((rt = !1), (t.pendingProps = r = a), (e.lanes & o) !== 0))
          (e.flags & 131072) !== 0 && (rt = !0);
        else return ((t.lanes = e.lanes), Ft(e, t, o));
    }
    return za(e, t, n, r, o);
  }
  function rc(e, t, n) {
    var r = t.pendingProps,
      o = r.children,
      a = e !== null ? e.memoizedState : null;
    if (r.mode === "hidden")
      if ((t.mode & 1) === 0)
        ((t.memoizedState = {
          baseLanes: 0,
          cachePool: null,
          transitions: null,
        }),
          be(nr, dt),
          (dt |= n));
      else {
        if ((n & 1073741824) === 0)
          return (
            (e = a !== null ? a.baseLanes | n : n),
            (t.lanes = t.childLanes = 1073741824),
            (t.memoizedState = {
              baseLanes: e,
              cachePool: null,
              transitions: null,
            }),
            (t.updateQueue = null),
            be(nr, dt),
            (dt |= e),
            null
          );
        ((t.memoizedState = {
          baseLanes: 0,
          cachePool: null,
          transitions: null,
        }),
          (r = a !== null ? a.baseLanes : n),
          be(nr, dt),
          (dt |= r));
      }
    else
      (a !== null ? ((r = a.baseLanes | n), (t.memoizedState = null)) : (r = n),
        be(nr, dt),
        (dt |= r));
    return (Ye(e, t, o, n), t.child);
  }
  function oc(e, t) {
    var n = t.ref;
    ((e === null && n !== null) || (e !== null && e.ref !== n)) &&
      ((t.flags |= 512), (t.flags |= 2097152));
  }
  function za(e, t, n, r, o) {
    var a = nt(n) ? yn : Ke.current;
    return (
      (a = Jn(t, a)),
      Yn(t, o),
      (n = ka(e, t, n, r, a, o)),
      (r = Sa()),
      e !== null && !rt
        ? ((t.updateQueue = e.updateQueue),
          (t.flags &= -2053),
          (e.lanes &= ~o),
          Ft(e, t, o))
        : (Ee && r && oa(t), (t.flags |= 1), Ye(e, t, n, o), t.child)
    );
  }
  function ic(e, t, n, r, o) {
    if (nt(n)) {
      var a = !0;
      Co(t);
    } else a = !1;
    if ((Yn(t, o), t.stateNode === null))
      (Fo(e, t), Ku(t, n, r), Aa(t, n, r, o), (r = !0));
    else if (e === null) {
      var c = t.stateNode,
        f = t.memoizedProps;
      c.props = f;
      var m = c.context,
        x = n.contextType;
      typeof x == "object" && x !== null
        ? (x = mt(x))
        : ((x = nt(n) ? yn : Ke.current), (x = Jn(t, x)));
      var P = n.getDerivedStateFromProps,
        T =
          typeof P == "function" ||
          typeof c.getSnapshotBeforeUpdate == "function";
      (T ||
        (typeof c.UNSAFE_componentWillReceiveProps != "function" &&
          typeof c.componentWillReceiveProps != "function") ||
        ((f !== r || m !== x) && Qu(t, c, r, x)),
        (nn = !1));
      var A = t.memoizedState;
      ((c.state = A),
        Mo(t, r, c, o),
        (m = t.memoizedState),
        f !== r || A !== m || tt.current || nn
          ? (typeof P == "function" && (Ea(t, n, P, r), (m = t.memoizedState)),
            (f = nn || Ju(t, n, f, r, A, m, x))
              ? (T ||
                  (typeof c.UNSAFE_componentWillMount != "function" &&
                    typeof c.componentWillMount != "function") ||
                  (typeof c.componentWillMount == "function" &&
                    c.componentWillMount(),
                  typeof c.UNSAFE_componentWillMount == "function" &&
                    c.UNSAFE_componentWillMount()),
                typeof c.componentDidMount == "function" &&
                  (t.flags |= 4194308))
              : (typeof c.componentDidMount == "function" &&
                  (t.flags |= 4194308),
                (t.memoizedProps = r),
                (t.memoizedState = m)),
            (c.props = r),
            (c.state = m),
            (c.context = x),
            (r = f))
          : (typeof c.componentDidMount == "function" && (t.flags |= 4194308),
            (r = !1)));
    } else {
      ((c = t.stateNode),
        ku(e, t),
        (f = t.memoizedProps),
        (x = t.type === t.elementType ? f : Ct(t.type, f)),
        (c.props = x),
        (T = t.pendingProps),
        (A = c.context),
        (m = n.contextType),
        typeof m == "object" && m !== null
          ? (m = mt(m))
          : ((m = nt(n) ? yn : Ke.current), (m = Jn(t, m))));
      var I = n.getDerivedStateFromProps;
      ((P =
        typeof I == "function" ||
        typeof c.getSnapshotBeforeUpdate == "function") ||
        (typeof c.UNSAFE_componentWillReceiveProps != "function" &&
          typeof c.componentWillReceiveProps != "function") ||
        ((f !== T || A !== m) && Qu(t, c, r, m)),
        (nn = !1),
        (A = t.memoizedState),
        (c.state = A),
        Mo(t, r, c, o));
      var $ = t.memoizedState;
      f !== T || A !== $ || tt.current || nn
        ? (typeof I == "function" && (Ea(t, n, I, r), ($ = t.memoizedState)),
          (x = nn || Ju(t, n, x, r, A, $, m) || !1)
            ? (P ||
                (typeof c.UNSAFE_componentWillUpdate != "function" &&
                  typeof c.componentWillUpdate != "function") ||
                (typeof c.componentWillUpdate == "function" &&
                  c.componentWillUpdate(r, $, m),
                typeof c.UNSAFE_componentWillUpdate == "function" &&
                  c.UNSAFE_componentWillUpdate(r, $, m)),
              typeof c.componentDidUpdate == "function" && (t.flags |= 4),
              typeof c.getSnapshotBeforeUpdate == "function" &&
                (t.flags |= 1024))
            : (typeof c.componentDidUpdate != "function" ||
                (f === e.memoizedProps && A === e.memoizedState) ||
                (t.flags |= 4),
              typeof c.getSnapshotBeforeUpdate != "function" ||
                (f === e.memoizedProps && A === e.memoizedState) ||
                (t.flags |= 1024),
              (t.memoizedProps = r),
              (t.memoizedState = $)),
          (c.props = r),
          (c.state = $),
          (c.context = m),
          (r = x))
        : (typeof c.componentDidUpdate != "function" ||
            (f === e.memoizedProps && A === e.memoizedState) ||
            (t.flags |= 4),
          typeof c.getSnapshotBeforeUpdate != "function" ||
            (f === e.memoizedProps && A === e.memoizedState) ||
            (t.flags |= 1024),
          (r = !1));
    }
    return Ma(e, t, n, r, a, o);
  }
  function Ma(e, t, n, r, o, a) {
    oc(e, t);
    var c = (t.flags & 128) !== 0;
    if (!r && !c) return (o && cu(t, n, !1), Ft(e, t, a));
    ((r = t.stateNode), (Op.current = t));
    var f =
      c && typeof n.getDerivedStateFromError != "function" ? null : r.render();
    return (
      (t.flags |= 1),
      e !== null && c
        ? ((t.child = Zn(t, e.child, null, a)), (t.child = Zn(t, null, f, a)))
        : Ye(e, t, f, a),
      (t.memoizedState = r.state),
      o && cu(t, n, !0),
      t.child
    );
  }
  function ac(e) {
    var t = e.stateNode;
    (t.pendingContext
      ? lu(e, t.pendingContext, t.pendingContext !== t.context)
      : t.context && lu(e, t.context, !1),
      ha(e, t.containerInfo));
  }
  function sc(e, t, n, r, o) {
    return (Gn(), la(o), (t.flags |= 256), Ye(e, t, n, r), t.child);
  }
  var La = { dehydrated: null, treeContext: null, retryLane: 0 };
  function Ra(e) {
    return { baseLanes: e, cachePool: null, transitions: null };
  }
  function lc(e, t, n) {
    var r = t.pendingProps,
      o = Te.current,
      a = !1,
      c = (t.flags & 128) !== 0,
      f;
    if (
      ((f = c) ||
        (f = e !== null && e.memoizedState === null ? !1 : (o & 2) !== 0),
      f
        ? ((a = !0), (t.flags &= -129))
        : (e === null || e.memoizedState !== null) && (o |= 1),
      be(Te, o & 1),
      e === null)
    )
      return (
        sa(t),
        (e = t.memoizedState),
        e !== null && ((e = e.dehydrated), e !== null)
          ? ((t.mode & 1) === 0
              ? (t.lanes = 1)
              : e.data === "$!"
                ? (t.lanes = 8)
                : (t.lanes = 1073741824),
            null)
          : ((c = r.children),
            (e = r.fallback),
            a
              ? ((r = t.mode),
                (a = t.child),
                (c = { mode: "hidden", children: c }),
                (r & 1) === 0 && a !== null
                  ? ((a.childLanes = 0), (a.pendingProps = c))
                  : (a = Xo(c, r, 0, null)),
                (e = En(e, r, n, null)),
                (a.return = t),
                (e.return = t),
                (a.sibling = e),
                (t.child = a),
                (t.child.memoizedState = Ra(n)),
                (t.memoizedState = La),
                e)
              : Oa(t, c))
      );
    if (((o = e.memoizedState), o !== null && ((f = o.dehydrated), f !== null)))
      return Np(e, t, c, r, f, o, n);
    if (a) {
      ((a = r.fallback), (c = t.mode), (o = e.child), (f = o.sibling));
      var m = { mode: "hidden", children: r.children };
      return (
        (c & 1) === 0 && t.child !== o
          ? ((r = t.child),
            (r.childLanes = 0),
            (r.pendingProps = m),
            (t.deletions = null))
          : ((r = cn(o, m)), (r.subtreeFlags = o.subtreeFlags & 14680064)),
        f !== null ? (a = cn(f, a)) : ((a = En(a, c, n, null)), (a.flags |= 2)),
        (a.return = t),
        (r.return = t),
        (r.sibling = a),
        (t.child = r),
        (r = a),
        (a = t.child),
        (c = e.child.memoizedState),
        (c =
          c === null
            ? Ra(n)
            : {
                baseLanes: c.baseLanes | n,
                cachePool: null,
                transitions: c.transitions,
              }),
        (a.memoizedState = c),
        (a.childLanes = e.childLanes & ~n),
        (t.memoizedState = La),
        r
      );
    }
    return (
      (a = e.child),
      (e = a.sibling),
      (r = cn(a, { mode: "visible", children: r.children })),
      (t.mode & 1) === 0 && (r.lanes = n),
      (r.return = t),
      (r.sibling = null),
      e !== null &&
        ((n = t.deletions),
        n === null ? ((t.deletions = [e]), (t.flags |= 16)) : n.push(e)),
      (t.child = r),
      (t.memoizedState = null),
      r
    );
  }
  function Oa(e, t) {
    return (
      (t = Xo({ mode: "visible", children: t }, e.mode, 0, null)),
      (t.return = e),
      (e.child = t)
    );
  }
  function $o(e, t, n, r) {
    return (
      r !== null && la(r),
      Zn(t, e.child, null, n),
      (e = Oa(t, t.pendingProps.children)),
      (e.flags |= 2),
      (t.memoizedState = null),
      e
    );
  }
  function Np(e, t, n, r, o, a, c) {
    if (n)
      return t.flags & 256
        ? ((t.flags &= -257), (r = Pa(Error(l(422)))), $o(e, t, c, r))
        : t.memoizedState !== null
          ? ((t.child = e.child), (t.flags |= 128), null)
          : ((a = r.fallback),
            (o = t.mode),
            (r = Xo({ mode: "visible", children: r.children }, o, 0, null)),
            (a = En(a, o, c, null)),
            (a.flags |= 2),
            (r.return = t),
            (a.return = t),
            (r.sibling = a),
            (t.child = r),
            (t.mode & 1) !== 0 && Zn(t, e.child, null, c),
            (t.child.memoizedState = Ra(c)),
            (t.memoizedState = La),
            a);
    if ((t.mode & 1) === 0) return $o(e, t, c, null);
    if (o.data === "$!") {
      if (((r = o.nextSibling && o.nextSibling.dataset), r)) var f = r.dgst;
      return (
        (r = f),
        (a = Error(l(419))),
        (r = Pa(a, r, void 0)),
        $o(e, t, c, r)
      );
    }
    if (((f = (c & e.childLanes) !== 0), rt || f)) {
      if (((r = We), r !== null)) {
        switch (c & -c) {
          case 4:
            o = 2;
            break;
          case 16:
            o = 8;
            break;
          case 64:
          case 128:
          case 256:
          case 512:
          case 1024:
          case 2048:
          case 4096:
          case 8192:
          case 16384:
          case 32768:
          case 65536:
          case 131072:
          case 262144:
          case 524288:
          case 1048576:
          case 2097152:
          case 4194304:
          case 8388608:
          case 16777216:
          case 33554432:
          case 67108864:
            o = 32;
            break;
          case 536870912:
            o = 268435456;
            break;
          default:
            o = 0;
        }
        ((o = (o & (r.suspendedLanes | c)) !== 0 ? 0 : o),
          o !== 0 &&
            o !== a.retryLane &&
            ((a.retryLane = o), Ut(e, o), jt(r, e, o, -1)));
      }
      return (qa(), (r = Pa(Error(l(421)))), $o(e, t, c, r));
    }
    return o.data === "$?"
      ? ((t.flags |= 128),
        (t.child = e.child),
        (t = Gp.bind(null, e)),
        (o._reactRetry = t),
        null)
      : ((e = a.treeContext),
        (ct = Yt(o.nextSibling)),
        (ut = t),
        (Ee = !0),
        (St = null),
        e !== null &&
          ((ft[pt++] = It),
          (ft[pt++] = Dt),
          (ft[pt++] = vn),
          (It = e.id),
          (Dt = e.overflow),
          (vn = t)),
        (t = Oa(t, r.children)),
        (t.flags |= 4096),
        t);
  }
  function uc(e, t, n) {
    e.lanes |= t;
    var r = e.alternate;
    (r !== null && (r.lanes |= t), fa(e.return, t, n));
  }
  function Na(e, t, n, r, o) {
    var a = e.memoizedState;
    a === null
      ? (e.memoizedState = {
          isBackwards: t,
          rendering: null,
          renderingStartTime: 0,
          last: r,
          tail: n,
          tailMode: o,
        })
      : ((a.isBackwards = t),
        (a.rendering = null),
        (a.renderingStartTime = 0),
        (a.last = r),
        (a.tail = n),
        (a.tailMode = o));
  }
  function cc(e, t, n) {
    var r = t.pendingProps,
      o = r.revealOrder,
      a = r.tail;
    if ((Ye(e, t, r.children, n), (r = Te.current), (r & 2) !== 0))
      ((r = (r & 1) | 2), (t.flags |= 128));
    else {
      if (e !== null && (e.flags & 128) !== 0)
        e: for (e = t.child; e !== null;) {
          if (e.tag === 13) e.memoizedState !== null && uc(e, n, t);
          else if (e.tag === 19) uc(e, n, t);
          else if (e.child !== null) {
            ((e.child.return = e), (e = e.child));
            continue;
          }
          if (e === t) break e;
          for (; e.sibling === null;) {
            if (e.return === null || e.return === t) break e;
            e = e.return;
          }
          ((e.sibling.return = e.return), (e = e.sibling));
        }
      r &= 1;
    }
    if ((be(Te, r), (t.mode & 1) === 0)) t.memoizedState = null;
    else
      switch (o) {
        case "forwards":
          for (n = t.child, o = null; n !== null;)
            ((e = n.alternate),
              e !== null && Lo(e) === null && (o = n),
              (n = n.sibling));
          ((n = o),
            n === null
              ? ((o = t.child), (t.child = null))
              : ((o = n.sibling), (n.sibling = null)),
            Na(t, !1, o, n, a));
          break;
        case "backwards":
          for (n = null, o = t.child, t.child = null; o !== null;) {
            if (((e = o.alternate), e !== null && Lo(e) === null)) {
              t.child = o;
              break;
            }
            ((e = o.sibling), (o.sibling = n), (n = o), (o = e));
          }
          Na(t, !0, n, null, a);
          break;
        case "together":
          Na(t, !1, null, null, void 0);
          break;
        default:
          t.memoizedState = null;
      }
    return t.child;
  }
  function Fo(e, t) {
    (t.mode & 1) === 0 &&
      e !== null &&
      ((e.alternate = null), (t.alternate = null), (t.flags |= 2));
  }
  function Ft(e, t, n) {
    if (
      (e !== null && (t.dependencies = e.dependencies),
      (Cn |= t.lanes),
      (n & t.childLanes) === 0)
    )
      return null;
    if (e !== null && t.child !== e.child) throw Error(l(153));
    if (t.child !== null) {
      for (
        e = t.child, n = cn(e, e.pendingProps), t.child = n, n.return = t;
        e.sibling !== null;
      )
        ((e = e.sibling),
          (n = n.sibling = cn(e, e.pendingProps)),
          (n.return = t));
      n.sibling = null;
    }
    return t.child;
  }
  function Ip(e, t, n) {
    switch (t.tag) {
      case 3:
        (ac(t), Gn());
        break;
      case 5:
        bu(t);
        break;
      case 1:
        nt(t.type) && Co(t);
        break;
      case 4:
        ha(t, t.stateNode.containerInfo);
        break;
      case 10:
        var r = t.type._context,
          o = t.memoizedProps.value;
        (be(Po, r._currentValue), (r._currentValue = o));
        break;
      case 13:
        if (((r = t.memoizedState), r !== null))
          return r.dehydrated !== null
            ? (be(Te, Te.current & 1), (t.flags |= 128), null)
            : (n & t.child.childLanes) !== 0
              ? lc(e, t, n)
              : (be(Te, Te.current & 1),
                (e = Ft(e, t, n)),
                e !== null ? e.sibling : null);
        be(Te, Te.current & 1);
        break;
      case 19:
        if (((r = (n & t.childLanes) !== 0), (e.flags & 128) !== 0)) {
          if (r) return cc(e, t, n);
          t.flags |= 128;
        }
        if (
          ((o = t.memoizedState),
          o !== null &&
            ((o.rendering = null), (o.tail = null), (o.lastEffect = null)),
          be(Te, Te.current),
          r)
        )
          break;
        return null;
      case 22:
      case 23:
        return ((t.lanes = 0), rc(e, t, n));
    }
    return Ft(e, t, n);
  }
  var dc, Ia, fc, pc;
  ((dc = function (e, t) {
    for (var n = t.child; n !== null;) {
      if (n.tag === 5 || n.tag === 6) e.appendChild(n.stateNode);
      else if (n.tag !== 4 && n.child !== null) {
        ((n.child.return = n), (n = n.child));
        continue;
      }
      if (n === t) break;
      for (; n.sibling === null;) {
        if (n.return === null || n.return === t) return;
        n = n.return;
      }
      ((n.sibling.return = n.return), (n = n.sibling));
    }
  }),
    (Ia = function () {}),
    (fc = function (e, t, n, r) {
      var o = e.memoizedProps;
      if (o !== r) {
        ((e = t.stateNode), kn(Tt.current));
        var a = null;
        switch (n) {
          case "input":
            ((o = Lt(e, o)), (r = Lt(e, r)), (a = []));
            break;
          case "select":
            ((o = _({}, o, { value: void 0 })),
              (r = _({}, r, { value: void 0 })),
              (a = []));
            break;
          case "textarea":
            ((o = hi(e, o)), (r = hi(e, r)), (a = []));
            break;
          default:
            typeof o.onClick != "function" &&
              typeof r.onClick == "function" &&
              (e.onclick = xo);
        }
        yi(n, r);
        var c;
        n = null;
        for (x in o)
          if (!r.hasOwnProperty(x) && o.hasOwnProperty(x) && o[x] != null)
            if (x === "style") {
              var f = o[x];
              for (c in f) f.hasOwnProperty(c) && (n || (n = {}), (n[c] = ""));
            } else
              x !== "dangerouslySetInnerHTML" &&
                x !== "children" &&
                x !== "suppressContentEditableWarning" &&
                x !== "suppressHydrationWarning" &&
                x !== "autoFocus" &&
                (p.hasOwnProperty(x)
                  ? a || (a = [])
                  : (a = a || []).push(x, null));
        for (x in r) {
          var m = r[x];
          if (
            ((f = o?.[x]),
            r.hasOwnProperty(x) && m !== f && (m != null || f != null))
          )
            if (x === "style")
              if (f) {
                for (c in f)
                  !f.hasOwnProperty(c) ||
                    (m && m.hasOwnProperty(c)) ||
                    (n || (n = {}), (n[c] = ""));
                for (c in m)
                  m.hasOwnProperty(c) &&
                    f[c] !== m[c] &&
                    (n || (n = {}), (n[c] = m[c]));
              } else (n || (a || (a = []), a.push(x, n)), (n = m));
            else
              x === "dangerouslySetInnerHTML"
                ? ((m = m ? m.__html : void 0),
                  (f = f ? f.__html : void 0),
                  m != null && f !== m && (a = a || []).push(x, m))
                : x === "children"
                  ? (typeof m != "string" && typeof m != "number") ||
                    (a = a || []).push(x, "" + m)
                  : x !== "suppressContentEditableWarning" &&
                    x !== "suppressHydrationWarning" &&
                    (p.hasOwnProperty(x)
                      ? (m != null && x === "onScroll" && _e("scroll", e),
                        a || f === m || (a = []))
                      : (a = a || []).push(x, m));
        }
        n && (a = a || []).push("style", n);
        var x = a;
        (t.updateQueue = x) && (t.flags |= 4);
      }
    }),
    (pc = function (e, t, n, r) {
      n !== r && (t.flags |= 4);
    }));
  function Fr(e, t) {
    if (!Ee)
      switch (e.tailMode) {
        case "hidden":
          t = e.tail;
          for (var n = null; t !== null;)
            (t.alternate !== null && (n = t), (t = t.sibling));
          n === null ? (e.tail = null) : (n.sibling = null);
          break;
        case "collapsed":
          n = e.tail;
          for (var r = null; n !== null;)
            (n.alternate !== null && (r = n), (n = n.sibling));
          r === null
            ? t || e.tail === null
              ? (e.tail = null)
              : (e.tail.sibling = null)
            : (r.sibling = null);
      }
  }
  function Ge(e) {
    var t = e.alternate !== null && e.alternate.child === e.child,
      n = 0,
      r = 0;
    if (t)
      for (var o = e.child; o !== null;)
        ((n |= o.lanes | o.childLanes),
          (r |= o.subtreeFlags & 14680064),
          (r |= o.flags & 14680064),
          (o.return = e),
          (o = o.sibling));
    else
      for (o = e.child; o !== null;)
        ((n |= o.lanes | o.childLanes),
          (r |= o.subtreeFlags),
          (r |= o.flags),
          (o.return = e),
          (o = o.sibling));
    return ((e.subtreeFlags |= r), (e.childLanes = n), t);
  }
  function Dp(e, t, n) {
    var r = t.pendingProps;
    switch ((ia(t), t.tag)) {
      case 2:
      case 16:
      case 15:
      case 0:
      case 11:
      case 7:
      case 8:
      case 12:
      case 9:
      case 14:
        return (Ge(t), null);
      case 1:
        return (nt(t.type) && So(), Ge(t), null);
      case 3:
        return (
          (r = t.stateNode),
          Xn(),
          je(tt),
          je(Ke),
          va(),
          r.pendingContext &&
            ((r.context = r.pendingContext), (r.pendingContext = null)),
          (e === null || e.child === null) &&
            (Eo(t)
              ? (t.flags |= 4)
              : e === null ||
                (e.memoizedState.isDehydrated && (t.flags & 256) === 0) ||
                ((t.flags |= 1024), St !== null && (Qa(St), (St = null)))),
          Ia(e, t),
          Ge(t),
          null
        );
      case 5:
        ga(t);
        var o = kn(Nr.current);
        if (((n = t.type), e !== null && t.stateNode != null))
          (fc(e, t, n, r, o),
            e.ref !== t.ref && ((t.flags |= 512), (t.flags |= 2097152)));
        else {
          if (!r) {
            if (t.stateNode === null) throw Error(l(166));
            return (Ge(t), null);
          }
          if (((e = kn(Tt.current)), Eo(t))) {
            ((r = t.stateNode), (n = t.type));
            var a = t.memoizedProps;
            switch (((r[Pt] = t), (r[zr] = a), (e = (t.mode & 1) !== 0), n)) {
              case "dialog":
                (_e("cancel", r), _e("close", r));
                break;
              case "iframe":
              case "object":
              case "embed":
                _e("load", r);
                break;
              case "video":
              case "audio":
                for (o = 0; o < Ar.length; o++) _e(Ar[o], r);
                break;
              case "source":
                _e("error", r);
                break;
              case "img":
              case "image":
              case "link":
                (_e("error", r), _e("load", r));
                break;
              case "details":
                _e("toggle", r);
                break;
              case "input":
                (et(r, a), _e("invalid", r));
                break;
              case "select":
                ((r._wrapperState = { wasMultiple: !!a.multiple }),
                  _e("invalid", r));
                break;
              case "textarea":
                (Zs(r, a), _e("invalid", r));
            }
            (yi(n, a), (o = null));
            for (var c in a)
              if (a.hasOwnProperty(c)) {
                var f = a[c];
                c === "children"
                  ? typeof f == "string"
                    ? r.textContent !== f &&
                      (a.suppressHydrationWarning !== !0 &&
                        wo(r.textContent, f, e),
                      (o = ["children", f]))
                    : typeof f == "number" &&
                      r.textContent !== "" + f &&
                      (a.suppressHydrationWarning !== !0 &&
                        wo(r.textContent, f, e),
                      (o = ["children", "" + f]))
                  : p.hasOwnProperty(c) &&
                    f != null &&
                    c === "onScroll" &&
                    _e("scroll", r);
              }
            switch (n) {
              case "input":
                (qe(r), Gs(r, a, !0));
                break;
              case "textarea":
                (qe(r), Ys(r));
                break;
              case "select":
              case "option":
                break;
              default:
                typeof a.onClick == "function" && (r.onclick = xo);
            }
            ((r = o), (t.updateQueue = r), r !== null && (t.flags |= 4));
          } else {
            ((c = o.nodeType === 9 ? o : o.ownerDocument),
              e === "http://www.w3.org/1999/xhtml" && (e = Xs(n)),
              e === "http://www.w3.org/1999/xhtml"
                ? n === "script"
                  ? ((e = c.createElement("div")),
                    (e.innerHTML = "<script><\/script>"),
                    (e = e.removeChild(e.firstChild)))
                  : typeof r.is == "string"
                    ? (e = c.createElement(n, { is: r.is }))
                    : ((e = c.createElement(n)),
                      n === "select" &&
                        ((c = e),
                        r.multiple
                          ? (c.multiple = !0)
                          : r.size && (c.size = r.size)))
                : (e = c.createElementNS(e, n)),
              (e[Pt] = t),
              (e[zr] = r),
              dc(e, t, !1, !1),
              (t.stateNode = e));
            e: {
              switch (((c = vi(n, r)), n)) {
                case "dialog":
                  (_e("cancel", e), _e("close", e), (o = r));
                  break;
                case "iframe":
                case "object":
                case "embed":
                  (_e("load", e), (o = r));
                  break;
                case "video":
                case "audio":
                  for (o = 0; o < Ar.length; o++) _e(Ar[o], e);
                  o = r;
                  break;
                case "source":
                  (_e("error", e), (o = r));
                  break;
                case "img":
                case "image":
                case "link":
                  (_e("error", e), _e("load", e), (o = r));
                  break;
                case "details":
                  (_e("toggle", e), (o = r));
                  break;
                case "input":
                  (et(e, r), (o = Lt(e, r)), _e("invalid", e));
                  break;
                case "option":
                  o = r;
                  break;
                case "select":
                  ((e._wrapperState = { wasMultiple: !!r.multiple }),
                    (o = _({}, r, { value: void 0 })),
                    _e("invalid", e));
                  break;
                case "textarea":
                  (Zs(e, r), (o = hi(e, r)), _e("invalid", e));
                  break;
                default:
                  o = r;
              }
              (yi(n, o), (f = o));
              for (a in f)
                if (f.hasOwnProperty(a)) {
                  var m = f[a];
                  a === "style"
                    ? nl(e, m)
                    : a === "dangerouslySetInnerHTML"
                      ? ((m = m ? m.__html : void 0), m != null && el(e, m))
                      : a === "children"
                        ? typeof m == "string"
                          ? (n !== "textarea" || m !== "") && ur(e, m)
                          : typeof m == "number" && ur(e, "" + m)
                        : a !== "suppressContentEditableWarning" &&
                          a !== "suppressHydrationWarning" &&
                          a !== "autoFocus" &&
                          (p.hasOwnProperty(a)
                            ? m != null && a === "onScroll" && _e("scroll", e)
                            : m != null && J(e, a, m, c));
                }
              switch (n) {
                case "input":
                  (qe(e), Gs(e, r, !1));
                  break;
                case "textarea":
                  (qe(e), Ys(e));
                  break;
                case "option":
                  r.value != null && e.setAttribute("value", "" + ue(r.value));
                  break;
                case "select":
                  ((e.multiple = !!r.multiple),
                    (a = r.value),
                    a != null
                      ? Rn(e, !!r.multiple, a, !1)
                      : r.defaultValue != null &&
                        Rn(e, !!r.multiple, r.defaultValue, !0));
                  break;
                default:
                  typeof o.onClick == "function" && (e.onclick = xo);
              }
              switch (n) {
                case "button":
                case "input":
                case "select":
                case "textarea":
                  r = !!r.autoFocus;
                  break e;
                case "img":
                  r = !0;
                  break e;
                default:
                  r = !1;
              }
            }
            r && (t.flags |= 4);
          }
          t.ref !== null && ((t.flags |= 512), (t.flags |= 2097152));
        }
        return (Ge(t), null);
      case 6:
        if (e && t.stateNode != null) pc(e, t, e.memoizedProps, r);
        else {
          if (typeof r != "string" && t.stateNode === null) throw Error(l(166));
          if (((n = kn(Nr.current)), kn(Tt.current), Eo(t))) {
            if (
              ((r = t.stateNode),
              (n = t.memoizedProps),
              (r[Pt] = t),
              (a = r.nodeValue !== n) && ((e = ut), e !== null))
            )
              switch (e.tag) {
                case 3:
                  wo(r.nodeValue, n, (e.mode & 1) !== 0);
                  break;
                case 5:
                  e.memoizedProps.suppressHydrationWarning !== !0 &&
                    wo(r.nodeValue, n, (e.mode & 1) !== 0);
              }
            a && (t.flags |= 4);
          } else
            ((r = (n.nodeType === 9 ? n : n.ownerDocument).createTextNode(r)),
              (r[Pt] = t),
              (t.stateNode = r));
        }
        return (Ge(t), null);
      case 13:
        if (
          (je(Te),
          (r = t.memoizedState),
          e === null ||
            (e.memoizedState !== null && e.memoizedState.dehydrated !== null))
        ) {
          if (Ee && ct !== null && (t.mode & 1) !== 0 && (t.flags & 128) === 0)
            (gu(), Gn(), (t.flags |= 98560), (a = !1));
          else if (((a = Eo(t)), r !== null && r.dehydrated !== null)) {
            if (e === null) {
              if (!a) throw Error(l(318));
              if (
                ((a = t.memoizedState),
                (a = a !== null ? a.dehydrated : null),
                !a)
              )
                throw Error(l(317));
              a[Pt] = t;
            } else
              (Gn(),
                (t.flags & 128) === 0 && (t.memoizedState = null),
                (t.flags |= 4));
            (Ge(t), (a = !1));
          } else (St !== null && (Qa(St), (St = null)), (a = !0));
          if (!a) return t.flags & 65536 ? t : null;
        }
        return (t.flags & 128) !== 0
          ? ((t.lanes = n), t)
          : ((r = r !== null),
            r !== (e !== null && e.memoizedState !== null) &&
              r &&
              ((t.child.flags |= 8192),
              (t.mode & 1) !== 0 &&
                (e === null || (Te.current & 1) !== 0
                  ? Ue === 0 && (Ue = 3)
                  : qa())),
            t.updateQueue !== null && (t.flags |= 4),
            Ge(t),
            null);
      case 4:
        return (
          Xn(),
          Ia(e, t),
          e === null && Pr(t.stateNode.containerInfo),
          Ge(t),
          null
        );
      case 10:
        return (da(t.type._context), Ge(t), null);
      case 17:
        return (nt(t.type) && So(), Ge(t), null);
      case 19:
        if ((je(Te), (a = t.memoizedState), a === null)) return (Ge(t), null);
        if (((r = (t.flags & 128) !== 0), (c = a.rendering), c === null))
          if (r) Fr(a, !1);
          else {
            if (Ue !== 0 || (e !== null && (e.flags & 128) !== 0))
              for (e = t.child; e !== null;) {
                if (((c = Lo(e)), c !== null)) {
                  for (
                    t.flags |= 128,
                      Fr(a, !1),
                      r = c.updateQueue,
                      r !== null && ((t.updateQueue = r), (t.flags |= 4)),
                      t.subtreeFlags = 0,
                      r = n,
                      n = t.child;
                    n !== null;
                  )
                    ((a = n),
                      (e = r),
                      (a.flags &= 14680066),
                      (c = a.alternate),
                      c === null
                        ? ((a.childLanes = 0),
                          (a.lanes = e),
                          (a.child = null),
                          (a.subtreeFlags = 0),
                          (a.memoizedProps = null),
                          (a.memoizedState = null),
                          (a.updateQueue = null),
                          (a.dependencies = null),
                          (a.stateNode = null))
                        : ((a.childLanes = c.childLanes),
                          (a.lanes = c.lanes),
                          (a.child = c.child),
                          (a.subtreeFlags = 0),
                          (a.deletions = null),
                          (a.memoizedProps = c.memoizedProps),
                          (a.memoizedState = c.memoizedState),
                          (a.updateQueue = c.updateQueue),
                          (a.type = c.type),
                          (e = c.dependencies),
                          (a.dependencies =
                            e === null
                              ? null
                              : {
                                  lanes: e.lanes,
                                  firstContext: e.firstContext,
                                })),
                      (n = n.sibling));
                  return (be(Te, (Te.current & 1) | 2), t.child);
                }
                e = e.sibling;
              }
            a.tail !== null &&
              Re() > rr &&
              ((t.flags |= 128), (r = !0), Fr(a, !1), (t.lanes = 4194304));
          }
        else {
          if (!r)
            if (((e = Lo(c)), e !== null)) {
              if (
                ((t.flags |= 128),
                (r = !0),
                (n = e.updateQueue),
                n !== null && ((t.updateQueue = n), (t.flags |= 4)),
                Fr(a, !0),
                a.tail === null &&
                  a.tailMode === "hidden" &&
                  !c.alternate &&
                  !Ee)
              )
                return (Ge(t), null);
            } else
              2 * Re() - a.renderingStartTime > rr &&
                n !== 1073741824 &&
                ((t.flags |= 128), (r = !0), Fr(a, !1), (t.lanes = 4194304));
          a.isBackwards
            ? ((c.sibling = t.child), (t.child = c))
            : ((n = a.last),
              n !== null ? (n.sibling = c) : (t.child = c),
              (a.last = c));
        }
        return a.tail !== null
          ? ((t = a.tail),
            (a.rendering = t),
            (a.tail = t.sibling),
            (a.renderingStartTime = Re()),
            (t.sibling = null),
            (n = Te.current),
            be(Te, r ? (n & 1) | 2 : n & 1),
            t)
          : (Ge(t), null);
      case 22:
      case 23:
        return (
          Za(),
          (r = t.memoizedState !== null),
          e !== null && (e.memoizedState !== null) !== r && (t.flags |= 8192),
          r && (t.mode & 1) !== 0
            ? (dt & 1073741824) !== 0 &&
              (Ge(t), t.subtreeFlags & 6 && (t.flags |= 8192))
            : Ge(t),
          null
        );
      case 24:
        return null;
      case 25:
        return null;
    }
    throw Error(l(156, t.tag));
  }
  function Up(e, t) {
    switch ((ia(t), t.tag)) {
      case 1:
        return (
          nt(t.type) && So(),
          (e = t.flags),
          e & 65536 ? ((t.flags = (e & -65537) | 128), t) : null
        );
      case 3:
        return (
          Xn(),
          je(tt),
          je(Ke),
          va(),
          (e = t.flags),
          (e & 65536) !== 0 && (e & 128) === 0
            ? ((t.flags = (e & -65537) | 128), t)
            : null
        );
      case 5:
        return (ga(t), null);
      case 13:
        if (
          (je(Te), (e = t.memoizedState), e !== null && e.dehydrated !== null)
        ) {
          if (t.alternate === null) throw Error(l(340));
          Gn();
        }
        return (
          (e = t.flags),
          e & 65536 ? ((t.flags = (e & -65537) | 128), t) : null
        );
      case 19:
        return (je(Te), null);
      case 4:
        return (Xn(), null);
      case 10:
        return (da(t.type._context), null);
      case 22:
      case 23:
        return (Za(), null);
      case 24:
        return null;
      default:
        return null;
    }
  }
  var Wo = !1,
    Ze = !1,
    $p = typeof WeakSet == "function" ? WeakSet : Set,
    U = null;
  function tr(e, t) {
    var n = e.ref;
    if (n !== null)
      if (typeof n == "function")
        try {
          n(null);
        } catch (r) {
          Me(e, t, r);
        }
      else n.current = null;
  }
  function Da(e, t, n) {
    try {
      n();
    } catch (r) {
      Me(e, t, r);
    }
  }
  var mc = !1;
  function Fp(e, t) {
    if (((Zi = so), (e = Jl()), Wi(e))) {
      if ("selectionStart" in e)
        var n = { start: e.selectionStart, end: e.selectionEnd };
      else
        e: {
          n = ((n = e.ownerDocument) && n.defaultView) || window;
          var r = n.getSelection && n.getSelection();
          if (r && r.rangeCount !== 0) {
            n = r.anchorNode;
            var o = r.anchorOffset,
              a = r.focusNode;
            r = r.focusOffset;
            try {
              (n.nodeType, a.nodeType);
            } catch {
              n = null;
              break e;
            }
            var c = 0,
              f = -1,
              m = -1,
              x = 0,
              P = 0,
              T = e,
              A = null;
            t: for (;;) {
              for (
                var I;
                T !== n || (o !== 0 && T.nodeType !== 3) || (f = c + o),
                  T !== a || (r !== 0 && T.nodeType !== 3) || (m = c + r),
                  T.nodeType === 3 && (c += T.nodeValue.length),
                  (I = T.firstChild) !== null;
              )
                ((A = T), (T = I));
              for (;;) {
                if (T === e) break t;
                if (
                  (A === n && ++x === o && (f = c),
                  A === a && ++P === r && (m = c),
                  (I = T.nextSibling) !== null)
                )
                  break;
                ((T = A), (A = T.parentNode));
              }
              T = I;
            }
            n = f === -1 || m === -1 ? null : { start: f, end: m };
          } else n = null;
        }
      n = n || { start: 0, end: 0 };
    } else n = null;
    for (
      qi = { focusedElem: e, selectionRange: n }, so = !1, U = t;
      U !== null;
    )
      if (((t = U), (e = t.child), (t.subtreeFlags & 1028) !== 0 && e !== null))
        ((e.return = t), (U = e));
      else
        for (; U !== null;) {
          t = U;
          try {
            var $ = t.alternate;
            if ((t.flags & 1024) !== 0)
              switch (t.tag) {
                case 0:
                case 11:
                case 15:
                  break;
                case 1:
                  if ($ !== null) {
                    var W = $.memoizedProps,
                      Oe = $.memoizedState,
                      v = t.stateNode,
                      g = v.getSnapshotBeforeUpdate(
                        t.elementType === t.type ? W : Ct(t.type, W),
                        Oe,
                      );
                    v.__reactInternalSnapshotBeforeUpdate = g;
                  }
                  break;
                case 3:
                  var w = t.stateNode.containerInfo;
                  w.nodeType === 1
                    ? (w.textContent = "")
                    : w.nodeType === 9 &&
                      w.documentElement &&
                      w.removeChild(w.documentElement);
                  break;
                case 5:
                case 6:
                case 4:
                case 17:
                  break;
                default:
                  throw Error(l(163));
              }
          } catch (z) {
            Me(t, t.return, z);
          }
          if (((e = t.sibling), e !== null)) {
            ((e.return = t.return), (U = e));
            break;
          }
          U = t.return;
        }
    return (($ = mc), (mc = !1), $);
  }
  function Wr(e, t, n) {
    var r = t.updateQueue;
    if (((r = r !== null ? r.lastEffect : null), r !== null)) {
      var o = (r = r.next);
      do {
        if ((o.tag & e) === e) {
          var a = o.destroy;
          ((o.destroy = void 0), a !== void 0 && Da(t, n, a));
        }
        o = o.next;
      } while (o !== r);
    }
  }
  function Bo(e, t) {
    if (
      ((t = t.updateQueue), (t = t !== null ? t.lastEffect : null), t !== null)
    ) {
      var n = (t = t.next);
      do {
        if ((n.tag & e) === e) {
          var r = n.create;
          n.destroy = r();
        }
        n = n.next;
      } while (n !== t);
    }
  }
  function Ua(e) {
    var t = e.ref;
    if (t !== null) {
      var n = e.stateNode;
      switch (e.tag) {
        case 5:
          e = n;
          break;
        default:
          e = n;
      }
      typeof t == "function" ? t(e) : (t.current = e);
    }
  }
  function hc(e) {
    var t = e.alternate;
    (t !== null && ((e.alternate = null), hc(t)),
      (e.child = null),
      (e.deletions = null),
      (e.sibling = null),
      e.tag === 5 &&
        ((t = e.stateNode),
        t !== null &&
          (delete t[Pt],
          delete t[zr],
          delete t[ta],
          delete t[Cp],
          delete t[bp])),
      (e.stateNode = null),
      (e.return = null),
      (e.dependencies = null),
      (e.memoizedProps = null),
      (e.memoizedState = null),
      (e.pendingProps = null),
      (e.stateNode = null),
      (e.updateQueue = null));
  }
  function gc(e) {
    return e.tag === 5 || e.tag === 3 || e.tag === 4;
  }
  function yc(e) {
    e: for (;;) {
      for (; e.sibling === null;) {
        if (e.return === null || gc(e.return)) return null;
        e = e.return;
      }
      for (
        e.sibling.return = e.return, e = e.sibling;
        e.tag !== 5 && e.tag !== 6 && e.tag !== 18;
      ) {
        if (e.flags & 2 || e.child === null || e.tag === 4) continue e;
        ((e.child.return = e), (e = e.child));
      }
      if (!(e.flags & 2)) return e.stateNode;
    }
  }
  function $a(e, t, n) {
    var r = e.tag;
    if (r === 5 || r === 6)
      ((e = e.stateNode),
        t
          ? n.nodeType === 8
            ? n.parentNode.insertBefore(e, t)
            : n.insertBefore(e, t)
          : (n.nodeType === 8
              ? ((t = n.parentNode), t.insertBefore(e, n))
              : ((t = n), t.appendChild(e)),
            (n = n._reactRootContainer),
            n != null || t.onclick !== null || (t.onclick = xo)));
    else if (r !== 4 && ((e = e.child), e !== null))
      for ($a(e, t, n), e = e.sibling; e !== null;)
        ($a(e, t, n), (e = e.sibling));
  }
  function Fa(e, t, n) {
    var r = e.tag;
    if (r === 5 || r === 6)
      ((e = e.stateNode), t ? n.insertBefore(e, t) : n.appendChild(e));
    else if (r !== 4 && ((e = e.child), e !== null))
      for (Fa(e, t, n), e = e.sibling; e !== null;)
        (Fa(e, t, n), (e = e.sibling));
  }
  var Ve = null,
    bt = !1;
  function on(e, t, n) {
    for (n = n.child; n !== null;) (vc(e, t, n), (n = n.sibling));
  }
  function vc(e, t, n) {
    if (At && typeof At.onCommitFiberUnmount == "function")
      try {
        At.onCommitFiberUnmount(to, n);
      } catch {}
    switch (n.tag) {
      case 5:
        Ze || tr(n, t);
      case 6:
        var r = Ve,
          o = bt;
        ((Ve = null),
          on(e, t, n),
          (Ve = r),
          (bt = o),
          Ve !== null &&
            (bt
              ? ((e = Ve),
                (n = n.stateNode),
                e.nodeType === 8
                  ? e.parentNode.removeChild(n)
                  : e.removeChild(n))
              : Ve.removeChild(n.stateNode)));
        break;
      case 18:
        Ve !== null &&
          (bt
            ? ((e = Ve),
              (n = n.stateNode),
              e.nodeType === 8
                ? ea(e.parentNode, n)
                : e.nodeType === 1 && ea(e, n),
              xr(e))
            : ea(Ve, n.stateNode));
        break;
      case 4:
        ((r = Ve),
          (o = bt),
          (Ve = n.stateNode.containerInfo),
          (bt = !0),
          on(e, t, n),
          (Ve = r),
          (bt = o));
        break;
      case 0:
      case 11:
      case 14:
      case 15:
        if (
          !Ze &&
          ((r = n.updateQueue), r !== null && ((r = r.lastEffect), r !== null))
        ) {
          o = r = r.next;
          do {
            var a = o,
              c = a.destroy;
            ((a = a.tag),
              c !== void 0 && ((a & 2) !== 0 || (a & 4) !== 0) && Da(n, t, c),
              (o = o.next));
          } while (o !== r);
        }
        on(e, t, n);
        break;
      case 1:
        if (
          !Ze &&
          (tr(n, t),
          (r = n.stateNode),
          typeof r.componentWillUnmount == "function")
        )
          try {
            ((r.props = n.memoizedProps),
              (r.state = n.memoizedState),
              r.componentWillUnmount());
          } catch (f) {
            Me(n, t, f);
          }
        on(e, t, n);
        break;
      case 21:
        on(e, t, n);
        break;
      case 22:
        n.mode & 1
          ? ((Ze = (r = Ze) || n.memoizedState !== null), on(e, t, n), (Ze = r))
          : on(e, t, n);
        break;
      default:
        on(e, t, n);
    }
  }
  function wc(e) {
    var t = e.updateQueue;
    if (t !== null) {
      e.updateQueue = null;
      var n = e.stateNode;
      (n === null && (n = e.stateNode = new $p()),
        t.forEach(function (r) {
          var o = Zp.bind(null, e, r);
          n.has(r) || (n.add(r), r.then(o, o));
        }));
    }
  }
  function _t(e, t) {
    var n = t.deletions;
    if (n !== null)
      for (var r = 0; r < n.length; r++) {
        var o = n[r];
        try {
          var a = e,
            c = t,
            f = c;
          e: for (; f !== null;) {
            switch (f.tag) {
              case 5:
                ((Ve = f.stateNode), (bt = !1));
                break e;
              case 3:
                ((Ve = f.stateNode.containerInfo), (bt = !0));
                break e;
              case 4:
                ((Ve = f.stateNode.containerInfo), (bt = !0));
                break e;
            }
            f = f.return;
          }
          if (Ve === null) throw Error(l(160));
          (vc(a, c, o), (Ve = null), (bt = !1));
          var m = o.alternate;
          (m !== null && (m.return = null), (o.return = null));
        } catch (x) {
          Me(o, t, x);
        }
      }
    if (t.subtreeFlags & 12854)
      for (t = t.child; t !== null;) (xc(t, e), (t = t.sibling));
  }
  function xc(e, t) {
    var n = e.alternate,
      r = e.flags;
    switch (e.tag) {
      case 0:
      case 11:
      case 14:
      case 15:
        if ((_t(t, e), Mt(e), r & 4)) {
          try {
            (Wr(3, e, e.return), Bo(3, e));
          } catch (W) {
            Me(e, e.return, W);
          }
          try {
            Wr(5, e, e.return);
          } catch (W) {
            Me(e, e.return, W);
          }
        }
        break;
      case 1:
        (_t(t, e), Mt(e), r & 512 && n !== null && tr(n, n.return));
        break;
      case 5:
        if (
          (_t(t, e),
          Mt(e),
          r & 512 && n !== null && tr(n, n.return),
          e.flags & 32)
        ) {
          var o = e.stateNode;
          try {
            ur(o, "");
          } catch (W) {
            Me(e, e.return, W);
          }
        }
        if (r & 4 && ((o = e.stateNode), o != null)) {
          var a = e.memoizedProps,
            c = n !== null ? n.memoizedProps : a,
            f = e.type,
            m = e.updateQueue;
          if (((e.updateQueue = null), m !== null))
            try {
              (f === "input" &&
                a.type === "radio" &&
                a.name != null &&
                Rt(o, a),
                vi(f, c));
              var x = vi(f, a);
              for (c = 0; c < m.length; c += 2) {
                var P = m[c],
                  T = m[c + 1];
                P === "style"
                  ? nl(o, T)
                  : P === "dangerouslySetInnerHTML"
                    ? el(o, T)
                    : P === "children"
                      ? ur(o, T)
                      : J(o, P, T, x);
              }
              switch (f) {
                case "input":
                  sr(o, a);
                  break;
                case "textarea":
                  qs(o, a);
                  break;
                case "select":
                  var A = o._wrapperState.wasMultiple;
                  o._wrapperState.wasMultiple = !!a.multiple;
                  var I = a.value;
                  I != null
                    ? Rn(o, !!a.multiple, I, !1)
                    : A !== !!a.multiple &&
                      (a.defaultValue != null
                        ? Rn(o, !!a.multiple, a.defaultValue, !0)
                        : Rn(o, !!a.multiple, a.multiple ? [] : "", !1));
              }
              o[zr] = a;
            } catch (W) {
              Me(e, e.return, W);
            }
        }
        break;
      case 6:
        if ((_t(t, e), Mt(e), r & 4)) {
          if (e.stateNode === null) throw Error(l(162));
          ((o = e.stateNode), (a = e.memoizedProps));
          try {
            o.nodeValue = a;
          } catch (W) {
            Me(e, e.return, W);
          }
        }
        break;
      case 3:
        if (
          (_t(t, e), Mt(e), r & 4 && n !== null && n.memoizedState.isDehydrated)
        )
          try {
            xr(t.containerInfo);
          } catch (W) {
            Me(e, e.return, W);
          }
        break;
      case 4:
        (_t(t, e), Mt(e));
        break;
      case 13:
        (_t(t, e),
          Mt(e),
          (o = e.child),
          o.flags & 8192 &&
            ((a = o.memoizedState !== null),
            (o.stateNode.isHidden = a),
            !a ||
              (o.alternate !== null && o.alternate.memoizedState !== null) ||
              (Ha = Re())),
          r & 4 && wc(e));
        break;
      case 22:
        if (
          ((P = n !== null && n.memoizedState !== null),
          e.mode & 1 ? ((Ze = (x = Ze) || P), _t(t, e), (Ze = x)) : _t(t, e),
          Mt(e),
          r & 8192)
        ) {
          if (
            ((x = e.memoizedState !== null),
            (e.stateNode.isHidden = x) && !P && (e.mode & 1) !== 0)
          )
            for (U = e, P = e.child; P !== null;) {
              for (T = U = P; U !== null;) {
                switch (((A = U), (I = A.child), A.tag)) {
                  case 0:
                  case 11:
                  case 14:
                  case 15:
                    Wr(4, A, A.return);
                    break;
                  case 1:
                    tr(A, A.return);
                    var $ = A.stateNode;
                    if (typeof $.componentWillUnmount == "function") {
                      ((r = A), (n = A.return));
                      try {
                        ((t = r),
                          ($.props = t.memoizedProps),
                          ($.state = t.memoizedState),
                          $.componentWillUnmount());
                      } catch (W) {
                        Me(r, n, W);
                      }
                    }
                    break;
                  case 5:
                    tr(A, A.return);
                    break;
                  case 22:
                    if (A.memoizedState !== null) {
                      Cc(T);
                      continue;
                    }
                }
                I !== null ? ((I.return = A), (U = I)) : Cc(T);
              }
              P = P.sibling;
            }
          e: for (P = null, T = e; ;) {
            if (T.tag === 5) {
              if (P === null) {
                P = T;
                try {
                  ((o = T.stateNode),
                    x
                      ? ((a = o.style),
                        typeof a.setProperty == "function"
                          ? a.setProperty("display", "none", "important")
                          : (a.display = "none"))
                      : ((f = T.stateNode),
                        (m = T.memoizedProps.style),
                        (c =
                          m != null && m.hasOwnProperty("display")
                            ? m.display
                            : null),
                        (f.style.display = tl("display", c))));
                } catch (W) {
                  Me(e, e.return, W);
                }
              }
            } else if (T.tag === 6) {
              if (P === null)
                try {
                  T.stateNode.nodeValue = x ? "" : T.memoizedProps;
                } catch (W) {
                  Me(e, e.return, W);
                }
            } else if (
              ((T.tag !== 22 && T.tag !== 23) ||
                T.memoizedState === null ||
                T === e) &&
              T.child !== null
            ) {
              ((T.child.return = T), (T = T.child));
              continue;
            }
            if (T === e) break e;
            for (; T.sibling === null;) {
              if (T.return === null || T.return === e) break e;
              (P === T && (P = null), (T = T.return));
            }
            (P === T && (P = null),
              (T.sibling.return = T.return),
              (T = T.sibling));
          }
        }
        break;
      case 19:
        (_t(t, e), Mt(e), r & 4 && wc(e));
        break;
      case 21:
        break;
      default:
        (_t(t, e), Mt(e));
    }
  }
  function Mt(e) {
    var t = e.flags;
    if (t & 2) {
      try {
        e: {
          for (var n = e.return; n !== null;) {
            if (gc(n)) {
              var r = n;
              break e;
            }
            n = n.return;
          }
          throw Error(l(160));
        }
        switch (r.tag) {
          case 5:
            var o = r.stateNode;
            r.flags & 32 && (ur(o, ""), (r.flags &= -33));
            var a = yc(e);
            Fa(e, a, o);
            break;
          case 3:
          case 4:
            var c = r.stateNode.containerInfo,
              f = yc(e);
            $a(e, f, c);
            break;
          default:
            throw Error(l(161));
        }
      } catch (m) {
        Me(e, e.return, m);
      }
      e.flags &= -3;
    }
    t & 4096 && (e.flags &= -4097);
  }
  function Wp(e, t, n) {
    ((U = e), kc(e));
  }
  function kc(e, t, n) {
    for (var r = (e.mode & 1) !== 0; U !== null;) {
      var o = U,
        a = o.child;
      if (o.tag === 22 && r) {
        var c = o.memoizedState !== null || Wo;
        if (!c) {
          var f = o.alternate,
            m = (f !== null && f.memoizedState !== null) || Ze;
          f = Wo;
          var x = Ze;
          if (((Wo = c), (Ze = m) && !x))
            for (U = o; U !== null;)
              ((c = U),
                (m = c.child),
                c.tag === 22 && c.memoizedState !== null
                  ? bc(o)
                  : m !== null
                    ? ((m.return = c), (U = m))
                    : bc(o));
          for (; a !== null;) ((U = a), kc(a), (a = a.sibling));
          ((U = o), (Wo = f), (Ze = x));
        }
        Sc(e);
      } else
        (o.subtreeFlags & 8772) !== 0 && a !== null
          ? ((a.return = o), (U = a))
          : Sc(e);
    }
  }
  function Sc(e) {
    for (; U !== null;) {
      var t = U;
      if ((t.flags & 8772) !== 0) {
        var n = t.alternate;
        try {
          if ((t.flags & 8772) !== 0)
            switch (t.tag) {
              case 0:
              case 11:
              case 15:
                Ze || Bo(5, t);
                break;
              case 1:
                var r = t.stateNode;
                if (t.flags & 4 && !Ze)
                  if (n === null) r.componentDidMount();
                  else {
                    var o =
                      t.elementType === t.type
                        ? n.memoizedProps
                        : Ct(t.type, n.memoizedProps);
                    r.componentDidUpdate(
                      o,
                      n.memoizedState,
                      r.__reactInternalSnapshotBeforeUpdate,
                    );
                  }
                var a = t.updateQueue;
                a !== null && Cu(t, a, r);
                break;
              case 3:
                var c = t.updateQueue;
                if (c !== null) {
                  if (((n = null), t.child !== null))
                    switch (t.child.tag) {
                      case 5:
                        n = t.child.stateNode;
                        break;
                      case 1:
                        n = t.child.stateNode;
                    }
                  Cu(t, c, n);
                }
                break;
              case 5:
                var f = t.stateNode;
                if (n === null && t.flags & 4) {
                  n = f;
                  var m = t.memoizedProps;
                  switch (t.type) {
                    case "button":
                    case "input":
                    case "select":
                    case "textarea":
                      m.autoFocus && n.focus();
                      break;
                    case "img":
                      m.src && (n.src = m.src);
                  }
                }
                break;
              case 6:
                break;
              case 4:
                break;
              case 12:
                break;
              case 13:
                if (t.memoizedState === null) {
                  var x = t.alternate;
                  if (x !== null) {
                    var P = x.memoizedState;
                    if (P !== null) {
                      var T = P.dehydrated;
                      T !== null && xr(T);
                    }
                  }
                }
                break;
              case 19:
              case 17:
              case 21:
              case 22:
              case 23:
              case 25:
                break;
              default:
                throw Error(l(163));
            }
          Ze || (t.flags & 512 && Ua(t));
        } catch (A) {
          Me(t, t.return, A);
        }
      }
      if (t === e) {
        U = null;
        break;
      }
      if (((n = t.sibling), n !== null)) {
        ((n.return = t.return), (U = n));
        break;
      }
      U = t.return;
    }
  }
  function Cc(e) {
    for (; U !== null;) {
      var t = U;
      if (t === e) {
        U = null;
        break;
      }
      var n = t.sibling;
      if (n !== null) {
        ((n.return = t.return), (U = n));
        break;
      }
      U = t.return;
    }
  }
  function bc(e) {
    for (; U !== null;) {
      var t = U;
      try {
        switch (t.tag) {
          case 0:
          case 11:
          case 15:
            var n = t.return;
            try {
              Bo(4, t);
            } catch (m) {
              Me(t, n, m);
            }
            break;
          case 1:
            var r = t.stateNode;
            if (typeof r.componentDidMount == "function") {
              var o = t.return;
              try {
                r.componentDidMount();
              } catch (m) {
                Me(t, o, m);
              }
            }
            var a = t.return;
            try {
              Ua(t);
            } catch (m) {
              Me(t, a, m);
            }
            break;
          case 5:
            var c = t.return;
            try {
              Ua(t);
            } catch (m) {
              Me(t, c, m);
            }
        }
      } catch (m) {
        Me(t, t.return, m);
      }
      if (t === e) {
        U = null;
        break;
      }
      var f = t.sibling;
      if (f !== null) {
        ((f.return = t.return), (U = f));
        break;
      }
      U = t.return;
    }
  }
  var Bp = Math.ceil,
    Ho = ee.ReactCurrentDispatcher,
    Wa = ee.ReactCurrentOwner,
    gt = ee.ReactCurrentBatchConfig,
    de = 0,
    We = null,
    Ie = null,
    Je = 0,
    dt = 0,
    nr = Xt(0),
    Ue = 0,
    Br = null,
    Cn = 0,
    Vo = 0,
    Ba = 0,
    Hr = null,
    ot = null,
    Ha = 0,
    rr = 1 / 0,
    Wt = null,
    Jo = !1,
    Va = null,
    an = null,
    Ko = !1,
    sn = null,
    Qo = 0,
    Vr = 0,
    Ja = null,
    Go = -1,
    Zo = 0;
  function Xe() {
    return (de & 6) !== 0 ? Re() : Go !== -1 ? Go : (Go = Re());
  }
  function ln(e) {
    return (e.mode & 1) === 0
      ? 1
      : (de & 2) !== 0 && Je !== 0
        ? Je & -Je
        : jp.transition !== null
          ? (Zo === 0 && (Zo = yl()), Zo)
          : ((e = ye),
            e !== 0 ||
              ((e = window.event), (e = e === void 0 ? 16 : jl(e.type))),
            e);
  }
  function jt(e, t, n, r) {
    if (50 < Vr) throw ((Vr = 0), (Ja = null), Error(l(185)));
    (hr(e, n, r),
      ((de & 2) === 0 || e !== We) &&
        (e === We && ((de & 2) === 0 && (Vo |= n), Ue === 4 && un(e, Je)),
        it(e, r),
        n === 1 &&
          de === 0 &&
          (t.mode & 1) === 0 &&
          ((rr = Re() + 500), bo && tn())));
  }
  function it(e, t) {
    var n = e.callbackNode;
    jf(e, t);
    var r = oo(e, e === We ? Je : 0);
    if (r === 0)
      (n !== null && ml(n), (e.callbackNode = null), (e.callbackPriority = 0));
    else if (((t = r & -r), e.callbackPriority !== t)) {
      if ((n != null && ml(n), t === 1))
        (e.tag === 0 ? _p(jc.bind(null, e)) : du(jc.bind(null, e)),
          kp(function () {
            (de & 6) === 0 && tn();
          }),
          (n = null));
      else {
        switch (vl(r)) {
          case 1:
            n = _i;
            break;
          case 4:
            n = hl;
            break;
          case 16:
            n = eo;
            break;
          case 536870912:
            n = gl;
            break;
          default:
            n = eo;
        }
        n = Rc(n, _c.bind(null, e));
      }
      ((e.callbackPriority = t), (e.callbackNode = n));
    }
  }
  function _c(e, t) {
    if (((Go = -1), (Zo = 0), (de & 6) !== 0)) throw Error(l(327));
    var n = e.callbackNode;
    if (or() && e.callbackNode !== n) return null;
    var r = oo(e, e === We ? Je : 0);
    if (r === 0) return null;
    if ((r & 30) !== 0 || (r & e.expiredLanes) !== 0 || t) t = qo(e, r);
    else {
      t = r;
      var o = de;
      de |= 2;
      var a = Ac();
      (We !== e || Je !== t) && ((Wt = null), (rr = Re() + 500), _n(e, t));
      do
        try {
          Jp();
          break;
        } catch (f) {
          Ec(e, f);
        }
      while (!0);
      (ca(),
        (Ho.current = a),
        (de = o),
        Ie !== null ? (t = 0) : ((We = null), (Je = 0), (t = Ue)));
    }
    if (t !== 0) {
      if (
        (t === 2 && ((o = ji(e)), o !== 0 && ((r = o), (t = Ka(e, o)))),
        t === 1)
      )
        throw ((n = Br), _n(e, 0), un(e, r), it(e, Re()), n);
      if (t === 6) un(e, r);
      else {
        if (
          ((o = e.current.alternate),
          (r & 30) === 0 &&
            !Hp(o) &&
            ((t = qo(e, r)),
            t === 2 && ((a = ji(e)), a !== 0 && ((r = a), (t = Ka(e, a)))),
            t === 1))
        )
          throw ((n = Br), _n(e, 0), un(e, r), it(e, Re()), n);
        switch (((e.finishedWork = o), (e.finishedLanes = r), t)) {
          case 0:
          case 1:
            throw Error(l(345));
          case 2:
            jn(e, ot, Wt);
            break;
          case 3:
            if (
              (un(e, r),
              (r & 130023424) === r && ((t = Ha + 500 - Re()), 10 < t))
            ) {
              if (oo(e, 0) !== 0) break;
              if (((o = e.suspendedLanes), (o & r) !== r)) {
                (Xe(), (e.pingedLanes |= e.suspendedLanes & o));
                break;
              }
              e.timeoutHandle = Xi(jn.bind(null, e, ot, Wt), t);
              break;
            }
            jn(e, ot, Wt);
            break;
          case 4:
            if ((un(e, r), (r & 4194240) === r)) break;
            for (t = e.eventTimes, o = -1; 0 < r;) {
              var c = 31 - xt(r);
              ((a = 1 << c), (c = t[c]), c > o && (o = c), (r &= ~a));
            }
            if (
              ((r = o),
              (r = Re() - r),
              (r =
                (120 > r
                  ? 120
                  : 480 > r
                    ? 480
                    : 1080 > r
                      ? 1080
                      : 1920 > r
                        ? 1920
                        : 3e3 > r
                          ? 3e3
                          : 4320 > r
                            ? 4320
                            : 1960 * Bp(r / 1960)) - r),
              10 < r)
            ) {
              e.timeoutHandle = Xi(jn.bind(null, e, ot, Wt), r);
              break;
            }
            jn(e, ot, Wt);
            break;
          case 5:
            jn(e, ot, Wt);
            break;
          default:
            throw Error(l(329));
        }
      }
    }
    return (it(e, Re()), e.callbackNode === n ? _c.bind(null, e) : null);
  }
  function Ka(e, t) {
    var n = Hr;
    return (
      e.current.memoizedState.isDehydrated && (_n(e, t).flags |= 256),
      (e = qo(e, t)),
      e !== 2 && ((t = ot), (ot = n), t !== null && Qa(t)),
      e
    );
  }
  function Qa(e) {
    ot === null ? (ot = e) : ot.push.apply(ot, e);
  }
  function Hp(e) {
    for (var t = e; ;) {
      if (t.flags & 16384) {
        var n = t.updateQueue;
        if (n !== null && ((n = n.stores), n !== null))
          for (var r = 0; r < n.length; r++) {
            var o = n[r],
              a = o.getSnapshot;
            o = o.value;
            try {
              if (!kt(a(), o)) return !1;
            } catch {
              return !1;
            }
          }
      }
      if (((n = t.child), t.subtreeFlags & 16384 && n !== null))
        ((n.return = t), (t = n));
      else {
        if (t === e) break;
        for (; t.sibling === null;) {
          if (t.return === null || t.return === e) return !0;
          t = t.return;
        }
        ((t.sibling.return = t.return), (t = t.sibling));
      }
    }
    return !0;
  }
  function un(e, t) {
    for (
      t &= ~Ba,
        t &= ~Vo,
        e.suspendedLanes |= t,
        e.pingedLanes &= ~t,
        e = e.expirationTimes;
      0 < t;
    ) {
      var n = 31 - xt(t),
        r = 1 << n;
      ((e[n] = -1), (t &= ~r));
    }
  }
  function jc(e) {
    if ((de & 6) !== 0) throw Error(l(327));
    or();
    var t = oo(e, 0);
    if ((t & 1) === 0) return (it(e, Re()), null);
    var n = qo(e, t);
    if (e.tag !== 0 && n === 2) {
      var r = ji(e);
      r !== 0 && ((t = r), (n = Ka(e, r)));
    }
    if (n === 1) throw ((n = Br), _n(e, 0), un(e, t), it(e, Re()), n);
    if (n === 6) throw Error(l(345));
    return (
      (e.finishedWork = e.current.alternate),
      (e.finishedLanes = t),
      jn(e, ot, Wt),
      it(e, Re()),
      null
    );
  }
  function Ga(e, t) {
    var n = de;
    de |= 1;
    try {
      return e(t);
    } finally {
      ((de = n), de === 0 && ((rr = Re() + 500), bo && tn()));
    }
  }
  function bn(e) {
    sn !== null && sn.tag === 0 && (de & 6) === 0 && or();
    var t = de;
    de |= 1;
    var n = gt.transition,
      r = ye;
    try {
      if (((gt.transition = null), (ye = 1), e)) return e();
    } finally {
      ((ye = r), (gt.transition = n), (de = t), (de & 6) === 0 && tn());
    }
  }
  function Za() {
    ((dt = nr.current), je(nr));
  }
  function _n(e, t) {
    ((e.finishedWork = null), (e.finishedLanes = 0));
    var n = e.timeoutHandle;
    if ((n !== -1 && ((e.timeoutHandle = -1), xp(n)), Ie !== null))
      for (n = Ie.return; n !== null;) {
        var r = n;
        switch ((ia(r), r.tag)) {
          case 1:
            ((r = r.type.childContextTypes), r != null && So());
            break;
          case 3:
            (Xn(), je(tt), je(Ke), va());
            break;
          case 5:
            ga(r);
            break;
          case 4:
            Xn();
            break;
          case 13:
            je(Te);
            break;
          case 19:
            je(Te);
            break;
          case 10:
            da(r.type._context);
            break;
          case 22:
          case 23:
            Za();
        }
        n = n.return;
      }
    if (
      ((We = e),
      (Ie = e = cn(e.current, null)),
      (Je = dt = t),
      (Ue = 0),
      (Br = null),
      (Ba = Vo = Cn = 0),
      (ot = Hr = null),
      xn !== null)
    ) {
      for (t = 0; t < xn.length; t++)
        if (((n = xn[t]), (r = n.interleaved), r !== null)) {
          n.interleaved = null;
          var o = r.next,
            a = n.pending;
          if (a !== null) {
            var c = a.next;
            ((a.next = o), (r.next = c));
          }
          n.pending = r;
        }
      xn = null;
    }
    return e;
  }
  function Ec(e, t) {
    do {
      var n = Ie;
      try {
        if ((ca(), (Ro.current = Do), Oo)) {
          for (var r = ze.memoizedState; r !== null;) {
            var o = r.queue;
            (o !== null && (o.pending = null), (r = r.next));
          }
          Oo = !1;
        }
        if (
          ((Sn = 0),
          (Fe = De = ze = null),
          (Ir = !1),
          (Dr = 0),
          (Wa.current = null),
          n === null || n.return === null)
        ) {
          ((Ue = 1), (Br = t), (Ie = null));
          break;
        }
        e: {
          var a = e,
            c = n.return,
            f = n,
            m = t;
          if (
            ((t = Je),
            (f.flags |= 32768),
            m !== null && typeof m == "object" && typeof m.then == "function")
          ) {
            var x = m,
              P = f,
              T = P.tag;
            if ((P.mode & 1) === 0 && (T === 0 || T === 11 || T === 15)) {
              var A = P.alternate;
              A
                ? ((P.updateQueue = A.updateQueue),
                  (P.memoizedState = A.memoizedState),
                  (P.lanes = A.lanes))
                : ((P.updateQueue = null), (P.memoizedState = null));
            }
            var I = Yu(c);
            if (I !== null) {
              ((I.flags &= -257),
                Xu(I, c, f, a, t),
                I.mode & 1 && qu(a, x, t),
                (t = I),
                (m = x));
              var $ = t.updateQueue;
              if ($ === null) {
                var W = new Set();
                (W.add(m), (t.updateQueue = W));
              } else $.add(m);
              break e;
            } else {
              if ((t & 1) === 0) {
                (qu(a, x, t), qa());
                break e;
              }
              m = Error(l(426));
            }
          } else if (Ee && f.mode & 1) {
            var Oe = Yu(c);
            if (Oe !== null) {
              ((Oe.flags & 65536) === 0 && (Oe.flags |= 256),
                Xu(Oe, c, f, a, t),
                la(er(m, f)));
              break e;
            }
          }
          ((a = m = er(m, f)),
            Ue !== 4 && (Ue = 2),
            Hr === null ? (Hr = [a]) : Hr.push(a),
            (a = c));
          do {
            switch (a.tag) {
              case 3:
                ((a.flags |= 65536), (t &= -t), (a.lanes |= t));
                var v = Gu(a, m, t);
                Su(a, v);
                break e;
              case 1:
                f = m;
                var g = a.type,
                  w = a.stateNode;
                if (
                  (a.flags & 128) === 0 &&
                  (typeof g.getDerivedStateFromError == "function" ||
                    (w !== null &&
                      typeof w.componentDidCatch == "function" &&
                      (an === null || !an.has(w))))
                ) {
                  ((a.flags |= 65536), (t &= -t), (a.lanes |= t));
                  var z = Zu(a, f, t);
                  Su(a, z);
                  break e;
                }
            }
            a = a.return;
          } while (a !== null);
        }
        Tc(n);
      } catch (H) {
        ((t = H), Ie === n && n !== null && (Ie = n = n.return));
        continue;
      }
      break;
    } while (!0);
  }
  function Ac() {
    var e = Ho.current;
    return ((Ho.current = Do), e === null ? Do : e);
  }
  function qa() {
    ((Ue === 0 || Ue === 3 || Ue === 2) && (Ue = 4),
      We === null ||
        ((Cn & 268435455) === 0 && (Vo & 268435455) === 0) ||
        un(We, Je));
  }
  function qo(e, t) {
    var n = de;
    de |= 2;
    var r = Ac();
    (We !== e || Je !== t) && ((Wt = null), _n(e, t));
    do
      try {
        Vp();
        break;
      } catch (o) {
        Ec(e, o);
      }
    while (!0);
    if ((ca(), (de = n), (Ho.current = r), Ie !== null)) throw Error(l(261));
    return ((We = null), (Je = 0), Ue);
  }
  function Vp() {
    for (; Ie !== null;) Pc(Ie);
  }
  function Jp() {
    for (; Ie !== null && !yf();) Pc(Ie);
  }
  function Pc(e) {
    var t = Lc(e.alternate, e, dt);
    ((e.memoizedProps = e.pendingProps),
      t === null ? Tc(e) : (Ie = t),
      (Wa.current = null));
  }
  function Tc(e) {
    var t = e;
    do {
      var n = t.alternate;
      if (((e = t.return), (t.flags & 32768) === 0)) {
        if (((n = Dp(n, t, dt)), n !== null)) {
          Ie = n;
          return;
        }
      } else {
        if (((n = Up(n, t)), n !== null)) {
          ((n.flags &= 32767), (Ie = n));
          return;
        }
        if (e !== null)
          ((e.flags |= 32768), (e.subtreeFlags = 0), (e.deletions = null));
        else {
          ((Ue = 6), (Ie = null));
          return;
        }
      }
      if (((t = t.sibling), t !== null)) {
        Ie = t;
        return;
      }
      Ie = t = e;
    } while (t !== null);
    Ue === 0 && (Ue = 5);
  }
  function jn(e, t, n) {
    var r = ye,
      o = gt.transition;
    try {
      ((gt.transition = null), (ye = 1), Kp(e, t, n, r));
    } finally {
      ((gt.transition = o), (ye = r));
    }
    return null;
  }
  function Kp(e, t, n, r) {
    do or();
    while (sn !== null);
    if ((de & 6) !== 0) throw Error(l(327));
    n = e.finishedWork;
    var o = e.finishedLanes;
    if (n === null) return null;
    if (((e.finishedWork = null), (e.finishedLanes = 0), n === e.current))
      throw Error(l(177));
    ((e.callbackNode = null), (e.callbackPriority = 0));
    var a = n.lanes | n.childLanes;
    if (
      (Ef(e, a),
      e === We && ((Ie = We = null), (Je = 0)),
      ((n.subtreeFlags & 2064) === 0 && (n.flags & 2064) === 0) ||
        Ko ||
        ((Ko = !0),
        Rc(eo, function () {
          return (or(), null);
        })),
      (a = (n.flags & 15990) !== 0),
      (n.subtreeFlags & 15990) !== 0 || a)
    ) {
      ((a = gt.transition), (gt.transition = null));
      var c = ye;
      ye = 1;
      var f = de;
      ((de |= 4),
        (Wa.current = null),
        Fp(e, n),
        xc(n, e),
        pp(qi),
        (so = !!Zi),
        (qi = Zi = null),
        (e.current = n),
        Wp(n),
        vf(),
        (de = f),
        (ye = c),
        (gt.transition = a));
    } else e.current = n;
    if (
      (Ko && ((Ko = !1), (sn = e), (Qo = o)),
      (a = e.pendingLanes),
      a === 0 && (an = null),
      kf(n.stateNode),
      it(e, Re()),
      t !== null)
    )
      for (r = e.onRecoverableError, n = 0; n < t.length; n++)
        ((o = t[n]), r(o.value, { componentStack: o.stack, digest: o.digest }));
    if (Jo) throw ((Jo = !1), (e = Va), (Va = null), e);
    return (
      (Qo & 1) !== 0 && e.tag !== 0 && or(),
      (a = e.pendingLanes),
      (a & 1) !== 0 ? (e === Ja ? Vr++ : ((Vr = 0), (Ja = e))) : (Vr = 0),
      tn(),
      null
    );
  }
  function or() {
    if (sn !== null) {
      var e = vl(Qo),
        t = gt.transition,
        n = ye;
      try {
        if (((gt.transition = null), (ye = 16 > e ? 16 : e), sn === null))
          var r = !1;
        else {
          if (((e = sn), (sn = null), (Qo = 0), (de & 6) !== 0))
            throw Error(l(331));
          var o = de;
          for (de |= 4, U = e.current; U !== null;) {
            var a = U,
              c = a.child;
            if ((U.flags & 16) !== 0) {
              var f = a.deletions;
              if (f !== null) {
                for (var m = 0; m < f.length; m++) {
                  var x = f[m];
                  for (U = x; U !== null;) {
                    var P = U;
                    switch (P.tag) {
                      case 0:
                      case 11:
                      case 15:
                        Wr(8, P, a);
                    }
                    var T = P.child;
                    if (T !== null) ((T.return = P), (U = T));
                    else
                      for (; U !== null;) {
                        P = U;
                        var A = P.sibling,
                          I = P.return;
                        if ((hc(P), P === x)) {
                          U = null;
                          break;
                        }
                        if (A !== null) {
                          ((A.return = I), (U = A));
                          break;
                        }
                        U = I;
                      }
                  }
                }
                var $ = a.alternate;
                if ($ !== null) {
                  var W = $.child;
                  if (W !== null) {
                    $.child = null;
                    do {
                      var Oe = W.sibling;
                      ((W.sibling = null), (W = Oe));
                    } while (W !== null);
                  }
                }
                U = a;
              }
            }
            if ((a.subtreeFlags & 2064) !== 0 && c !== null)
              ((c.return = a), (U = c));
            else
              e: for (; U !== null;) {
                if (((a = U), (a.flags & 2048) !== 0))
                  switch (a.tag) {
                    case 0:
                    case 11:
                    case 15:
                      Wr(9, a, a.return);
                  }
                var v = a.sibling;
                if (v !== null) {
                  ((v.return = a.return), (U = v));
                  break e;
                }
                U = a.return;
              }
          }
          var g = e.current;
          for (U = g; U !== null;) {
            c = U;
            var w = c.child;
            if ((c.subtreeFlags & 2064) !== 0 && w !== null)
              ((w.return = c), (U = w));
            else
              e: for (c = g; U !== null;) {
                if (((f = U), (f.flags & 2048) !== 0))
                  try {
                    switch (f.tag) {
                      case 0:
                      case 11:
                      case 15:
                        Bo(9, f);
                    }
                  } catch (H) {
                    Me(f, f.return, H);
                  }
                if (f === c) {
                  U = null;
                  break e;
                }
                var z = f.sibling;
                if (z !== null) {
                  ((z.return = f.return), (U = z));
                  break e;
                }
                U = f.return;
              }
          }
          if (
            ((de = o),
            tn(),
            At && typeof At.onPostCommitFiberRoot == "function")
          )
            try {
              At.onPostCommitFiberRoot(to, e);
            } catch {}
          r = !0;
        }
        return r;
      } finally {
        ((ye = n), (gt.transition = t));
      }
    }
    return !1;
  }
  function zc(e, t, n) {
    ((t = er(n, t)),
      (t = Gu(e, t, 1)),
      (e = rn(e, t, 1)),
      (t = Xe()),
      e !== null && (hr(e, 1, t), it(e, t)));
  }
  function Me(e, t, n) {
    if (e.tag === 3) zc(e, e, n);
    else
      for (; t !== null;) {
        if (t.tag === 3) {
          zc(t, e, n);
          break;
        } else if (t.tag === 1) {
          var r = t.stateNode;
          if (
            typeof t.type.getDerivedStateFromError == "function" ||
            (typeof r.componentDidCatch == "function" &&
              (an === null || !an.has(r)))
          ) {
            ((e = er(n, e)),
              (e = Zu(t, e, 1)),
              (t = rn(t, e, 1)),
              (e = Xe()),
              t !== null && (hr(t, 1, e), it(t, e)));
            break;
          }
        }
        t = t.return;
      }
  }
  function Qp(e, t, n) {
    var r = e.pingCache;
    (r !== null && r.delete(t),
      (t = Xe()),
      (e.pingedLanes |= e.suspendedLanes & n),
      We === e &&
        (Je & n) === n &&
        (Ue === 4 || (Ue === 3 && (Je & 130023424) === Je && 500 > Re() - Ha)
          ? _n(e, 0)
          : (Ba |= n)),
      it(e, t));
  }
  function Mc(e, t) {
    t === 0 &&
      ((e.mode & 1) === 0
        ? (t = 1)
        : ((t = ro), (ro <<= 1), (ro & 130023424) === 0 && (ro = 4194304)));
    var n = Xe();
    ((e = Ut(e, t)), e !== null && (hr(e, t, n), it(e, n)));
  }
  function Gp(e) {
    var t = e.memoizedState,
      n = 0;
    (t !== null && (n = t.retryLane), Mc(e, n));
  }
  function Zp(e, t) {
    var n = 0;
    switch (e.tag) {
      case 13:
        var r = e.stateNode,
          o = e.memoizedState;
        o !== null && (n = o.retryLane);
        break;
      case 19:
        r = e.stateNode;
        break;
      default:
        throw Error(l(314));
    }
    (r !== null && r.delete(t), Mc(e, n));
  }
  var Lc;
  Lc = function (e, t, n) {
    if (e !== null)
      if (e.memoizedProps !== t.pendingProps || tt.current) rt = !0;
      else {
        if ((e.lanes & n) === 0 && (t.flags & 128) === 0)
          return ((rt = !1), Ip(e, t, n));
        rt = (e.flags & 131072) !== 0;
      }
    else ((rt = !1), Ee && (t.flags & 1048576) !== 0 && fu(t, jo, t.index));
    switch (((t.lanes = 0), t.tag)) {
      case 2:
        var r = t.type;
        (Fo(e, t), (e = t.pendingProps));
        var o = Jn(t, Ke.current);
        (Yn(t, n), (o = ka(null, t, r, e, o, n)));
        var a = Sa();
        return (
          (t.flags |= 1),
          typeof o == "object" &&
          o !== null &&
          typeof o.render == "function" &&
          o.$$typeof === void 0
            ? ((t.tag = 1),
              (t.memoizedState = null),
              (t.updateQueue = null),
              nt(r) ? ((a = !0), Co(t)) : (a = !1),
              (t.memoizedState =
                o.state !== null && o.state !== void 0 ? o.state : null),
              ma(t),
              (o.updater = Uo),
              (t.stateNode = o),
              (o._reactInternals = t),
              Aa(t, r, e, n),
              (t = Ma(null, t, r, !0, a, n)))
            : ((t.tag = 0), Ee && a && oa(t), Ye(null, t, o, n), (t = t.child)),
          t
        );
      case 16:
        r = t.elementType;
        e: {
          switch (
            (Fo(e, t),
            (e = t.pendingProps),
            (o = r._init),
            (r = o(r._payload)),
            (t.type = r),
            (o = t.tag = Yp(r)),
            (e = Ct(r, e)),
            o)
          ) {
            case 0:
              t = za(null, t, r, e, n);
              break e;
            case 1:
              t = ic(null, t, r, e, n);
              break e;
            case 11:
              t = ec(null, t, r, e, n);
              break e;
            case 14:
              t = tc(null, t, r, Ct(r.type, e), n);
              break e;
          }
          throw Error(l(306, r, ""));
        }
        return t;
      case 0:
        return (
          (r = t.type),
          (o = t.pendingProps),
          (o = t.elementType === r ? o : Ct(r, o)),
          za(e, t, r, o, n)
        );
      case 1:
        return (
          (r = t.type),
          (o = t.pendingProps),
          (o = t.elementType === r ? o : Ct(r, o)),
          ic(e, t, r, o, n)
        );
      case 3:
        e: {
          if ((ac(t), e === null)) throw Error(l(387));
          ((r = t.pendingProps),
            (a = t.memoizedState),
            (o = a.element),
            ku(e, t),
            Mo(t, r, null, n));
          var c = t.memoizedState;
          if (((r = c.element), a.isDehydrated))
            if (
              ((a = {
                element: r,
                isDehydrated: !1,
                cache: c.cache,
                pendingSuspenseBoundaries: c.pendingSuspenseBoundaries,
                transitions: c.transitions,
              }),
              (t.updateQueue.baseState = a),
              (t.memoizedState = a),
              t.flags & 256)
            ) {
              ((o = er(Error(l(423)), t)), (t = sc(e, t, r, n, o)));
              break e;
            } else if (r !== o) {
              ((o = er(Error(l(424)), t)), (t = sc(e, t, r, n, o)));
              break e;
            } else
              for (
                ct = Yt(t.stateNode.containerInfo.firstChild),
                  ut = t,
                  Ee = !0,
                  St = null,
                  n = wu(t, null, r, n),
                  t.child = n;
                n;
              )
                ((n.flags = (n.flags & -3) | 4096), (n = n.sibling));
          else {
            if ((Gn(), r === o)) {
              t = Ft(e, t, n);
              break e;
            }
            Ye(e, t, r, n);
          }
          t = t.child;
        }
        return t;
      case 5:
        return (
          bu(t),
          e === null && sa(t),
          (r = t.type),
          (o = t.pendingProps),
          (a = e !== null ? e.memoizedProps : null),
          (c = o.children),
          Yi(r, o) ? (c = null) : a !== null && Yi(r, a) && (t.flags |= 32),
          oc(e, t),
          Ye(e, t, c, n),
          t.child
        );
      case 6:
        return (e === null && sa(t), null);
      case 13:
        return lc(e, t, n);
      case 4:
        return (
          ha(t, t.stateNode.containerInfo),
          (r = t.pendingProps),
          e === null ? (t.child = Zn(t, null, r, n)) : Ye(e, t, r, n),
          t.child
        );
      case 11:
        return (
          (r = t.type),
          (o = t.pendingProps),
          (o = t.elementType === r ? o : Ct(r, o)),
          ec(e, t, r, o, n)
        );
      case 7:
        return (Ye(e, t, t.pendingProps, n), t.child);
      case 8:
        return (Ye(e, t, t.pendingProps.children, n), t.child);
      case 12:
        return (Ye(e, t, t.pendingProps.children, n), t.child);
      case 10:
        e: {
          if (
            ((r = t.type._context),
            (o = t.pendingProps),
            (a = t.memoizedProps),
            (c = o.value),
            be(Po, r._currentValue),
            (r._currentValue = c),
            a !== null)
          )
            if (kt(a.value, c)) {
              if (a.children === o.children && !tt.current) {
                t = Ft(e, t, n);
                break e;
              }
            } else
              for (a = t.child, a !== null && (a.return = t); a !== null;) {
                var f = a.dependencies;
                if (f !== null) {
                  c = a.child;
                  for (var m = f.firstContext; m !== null;) {
                    if (m.context === r) {
                      if (a.tag === 1) {
                        ((m = $t(-1, n & -n)), (m.tag = 2));
                        var x = a.updateQueue;
                        if (x !== null) {
                          x = x.shared;
                          var P = x.pending;
                          (P === null
                            ? (m.next = m)
                            : ((m.next = P.next), (P.next = m)),
                            (x.pending = m));
                        }
                      }
                      ((a.lanes |= n),
                        (m = a.alternate),
                        m !== null && (m.lanes |= n),
                        fa(a.return, n, t),
                        (f.lanes |= n));
                      break;
                    }
                    m = m.next;
                  }
                } else if (a.tag === 10) c = a.type === t.type ? null : a.child;
                else if (a.tag === 18) {
                  if (((c = a.return), c === null)) throw Error(l(341));
                  ((c.lanes |= n),
                    (f = c.alternate),
                    f !== null && (f.lanes |= n),
                    fa(c, n, t),
                    (c = a.sibling));
                } else c = a.child;
                if (c !== null) c.return = a;
                else
                  for (c = a; c !== null;) {
                    if (c === t) {
                      c = null;
                      break;
                    }
                    if (((a = c.sibling), a !== null)) {
                      ((a.return = c.return), (c = a));
                      break;
                    }
                    c = c.return;
                  }
                a = c;
              }
          (Ye(e, t, o.children, n), (t = t.child));
        }
        return t;
      case 9:
        return (
          (o = t.type),
          (r = t.pendingProps.children),
          Yn(t, n),
          (o = mt(o)),
          (r = r(o)),
          (t.flags |= 1),
          Ye(e, t, r, n),
          t.child
        );
      case 14:
        return (
          (r = t.type),
          (o = Ct(r, t.pendingProps)),
          (o = Ct(r.type, o)),
          tc(e, t, r, o, n)
        );
      case 15:
        return nc(e, t, t.type, t.pendingProps, n);
      case 17:
        return (
          (r = t.type),
          (o = t.pendingProps),
          (o = t.elementType === r ? o : Ct(r, o)),
          Fo(e, t),
          (t.tag = 1),
          nt(r) ? ((e = !0), Co(t)) : (e = !1),
          Yn(t, n),
          Ku(t, r, o),
          Aa(t, r, o, n),
          Ma(null, t, r, !0, e, n)
        );
      case 19:
        return cc(e, t, n);
      case 22:
        return rc(e, t, n);
    }
    throw Error(l(156, t.tag));
  };
  function Rc(e, t) {
    return pl(e, t);
  }
  function qp(e, t, n, r) {
    ((this.tag = e),
      (this.key = n),
      (this.sibling =
        this.child =
        this.return =
        this.stateNode =
        this.type =
        this.elementType =
          null),
      (this.index = 0),
      (this.ref = null),
      (this.pendingProps = t),
      (this.dependencies =
        this.memoizedState =
        this.updateQueue =
        this.memoizedProps =
          null),
      (this.mode = r),
      (this.subtreeFlags = this.flags = 0),
      (this.deletions = null),
      (this.childLanes = this.lanes = 0),
      (this.alternate = null));
  }
  function yt(e, t, n, r) {
    return new qp(e, t, n, r);
  }
  function Ya(e) {
    return ((e = e.prototype), !(!e || !e.isReactComponent));
  }
  function Yp(e) {
    if (typeof e == "function") return Ya(e) ? 1 : 0;
    if (e != null) {
      if (((e = e.$$typeof), e === Ce)) return 11;
      if (e === Ne) return 14;
    }
    return 2;
  }
  function cn(e, t) {
    var n = e.alternate;
    return (
      n === null
        ? ((n = yt(e.tag, t, e.key, e.mode)),
          (n.elementType = e.elementType),
          (n.type = e.type),
          (n.stateNode = e.stateNode),
          (n.alternate = e),
          (e.alternate = n))
        : ((n.pendingProps = t),
          (n.type = e.type),
          (n.flags = 0),
          (n.subtreeFlags = 0),
          (n.deletions = null)),
      (n.flags = e.flags & 14680064),
      (n.childLanes = e.childLanes),
      (n.lanes = e.lanes),
      (n.child = e.child),
      (n.memoizedProps = e.memoizedProps),
      (n.memoizedState = e.memoizedState),
      (n.updateQueue = e.updateQueue),
      (t = e.dependencies),
      (n.dependencies =
        t === null ? null : { lanes: t.lanes, firstContext: t.firstContext }),
      (n.sibling = e.sibling),
      (n.index = e.index),
      (n.ref = e.ref),
      n
    );
  }
  function Yo(e, t, n, r, o, a) {
    var c = 2;
    if (((r = e), typeof e == "function")) Ya(e) && (c = 1);
    else if (typeof e == "string") c = 5;
    else
      e: switch (e) {
        case re:
          return En(n.children, o, a, t);
        case ce:
          ((c = 8), (o |= 8));
          break;
        case ke:
          return (
            (e = yt(12, n, t, o | 2)),
            (e.elementType = ke),
            (e.lanes = a),
            e
          );
        case pe:
          return (
            (e = yt(13, n, t, o)),
            (e.elementType = pe),
            (e.lanes = a),
            e
          );
        case Se:
          return (
            (e = yt(19, n, t, o)),
            (e.elementType = Se),
            (e.lanes = a),
            e
          );
        case he:
          return Xo(n, o, a, t);
        default:
          if (typeof e == "object" && e !== null)
            switch (e.$$typeof) {
              case ve:
                c = 10;
                break e;
              case ne:
                c = 9;
                break e;
              case Ce:
                c = 11;
                break e;
              case Ne:
                c = 14;
                break e;
              case Ae:
                ((c = 16), (r = null));
                break e;
            }
          throw Error(l(130, e == null ? e : typeof e, ""));
      }
    return (
      (t = yt(c, n, t, o)),
      (t.elementType = e),
      (t.type = r),
      (t.lanes = a),
      t
    );
  }
  function En(e, t, n, r) {
    return ((e = yt(7, e, r, t)), (e.lanes = n), e);
  }
  function Xo(e, t, n, r) {
    return (
      (e = yt(22, e, r, t)),
      (e.elementType = he),
      (e.lanes = n),
      (e.stateNode = { isHidden: !1 }),
      e
    );
  }
  function Xa(e, t, n) {
    return ((e = yt(6, e, null, t)), (e.lanes = n), e);
  }
  function es(e, t, n) {
    return (
      (t = yt(4, e.children !== null ? e.children : [], e.key, t)),
      (t.lanes = n),
      (t.stateNode = {
        containerInfo: e.containerInfo,
        pendingChildren: null,
        implementation: e.implementation,
      }),
      t
    );
  }
  function Xp(e, t, n, r, o) {
    ((this.tag = t),
      (this.containerInfo = e),
      (this.finishedWork =
        this.pingCache =
        this.current =
        this.pendingChildren =
          null),
      (this.timeoutHandle = -1),
      (this.callbackNode = this.pendingContext = this.context = null),
      (this.callbackPriority = 0),
      (this.eventTimes = Ei(0)),
      (this.expirationTimes = Ei(-1)),
      (this.entangledLanes =
        this.finishedLanes =
        this.mutableReadLanes =
        this.expiredLanes =
        this.pingedLanes =
        this.suspendedLanes =
        this.pendingLanes =
          0),
      (this.entanglements = Ei(0)),
      (this.identifierPrefix = r),
      (this.onRecoverableError = o),
      (this.mutableSourceEagerHydrationData = null));
  }
  function ts(e, t, n, r, o, a, c, f, m) {
    return (
      (e = new Xp(e, t, n, f, m)),
      t === 1 ? ((t = 1), a === !0 && (t |= 8)) : (t = 0),
      (a = yt(3, null, null, t)),
      (e.current = a),
      (a.stateNode = e),
      (a.memoizedState = {
        element: r,
        isDehydrated: n,
        cache: null,
        transitions: null,
        pendingSuspenseBoundaries: null,
      }),
      ma(a),
      e
    );
  }
  function em(e, t, n) {
    var r =
      3 < arguments.length && arguments[3] !== void 0 ? arguments[3] : null;
    return {
      $$typeof: fe,
      key: r == null ? null : "" + r,
      children: e,
      containerInfo: t,
      implementation: n,
    };
  }
  function Oc(e) {
    if (!e) return en;
    e = e._reactInternals;
    e: {
      if (hn(e) !== e || e.tag !== 1) throw Error(l(170));
      var t = e;
      do {
        switch (t.tag) {
          case 3:
            t = t.stateNode.context;
            break e;
          case 1:
            if (nt(t.type)) {
              t = t.stateNode.__reactInternalMemoizedMergedChildContext;
              break e;
            }
        }
        t = t.return;
      } while (t !== null);
      throw Error(l(171));
    }
    if (e.tag === 1) {
      var n = e.type;
      if (nt(n)) return uu(e, n, t);
    }
    return t;
  }
  function Nc(e, t, n, r, o, a, c, f, m) {
    return (
      (e = ts(n, r, !0, e, o, a, c, f, m)),
      (e.context = Oc(null)),
      (n = e.current),
      (r = Xe()),
      (o = ln(n)),
      (a = $t(r, o)),
      (a.callback = t ?? null),
      rn(n, a, o),
      (e.current.lanes = o),
      hr(e, o, r),
      it(e, r),
      e
    );
  }
  function ei(e, t, n, r) {
    var o = t.current,
      a = Xe(),
      c = ln(o);
    return (
      (n = Oc(n)),
      t.context === null ? (t.context = n) : (t.pendingContext = n),
      (t = $t(a, c)),
      (t.payload = { element: e }),
      (r = r === void 0 ? null : r),
      r !== null && (t.callback = r),
      (e = rn(o, t, c)),
      e !== null && (jt(e, o, c, a), zo(e, o, c)),
      c
    );
  }
  function ti(e) {
    if (((e = e.current), !e.child)) return null;
    switch (e.child.tag) {
      case 5:
        return e.child.stateNode;
      default:
        return e.child.stateNode;
    }
  }
  function Ic(e, t) {
    if (((e = e.memoizedState), e !== null && e.dehydrated !== null)) {
      var n = e.retryLane;
      e.retryLane = n !== 0 && n < t ? n : t;
    }
  }
  function ns(e, t) {
    (Ic(e, t), (e = e.alternate) && Ic(e, t));
  }
  function tm() {
    return null;
  }
  var Dc =
    typeof reportError == "function"
      ? reportError
      : function (e) {
          console.error(e);
        };
  function rs(e) {
    this._internalRoot = e;
  }
  ((ni.prototype.render = rs.prototype.render =
    function (e) {
      var t = this._internalRoot;
      if (t === null) throw Error(l(409));
      ei(e, t, null, null);
    }),
    (ni.prototype.unmount = rs.prototype.unmount =
      function () {
        var e = this._internalRoot;
        if (e !== null) {
          this._internalRoot = null;
          var t = e.containerInfo;
          (bn(function () {
            ei(null, e, null, null);
          }),
            (t[Ot] = null));
        }
      }));
  function ni(e) {
    this._internalRoot = e;
  }
  ni.prototype.unstable_scheduleHydration = function (e) {
    if (e) {
      var t = kl();
      e = { blockedOn: null, target: e, priority: t };
      for (var n = 0; n < Gt.length && t !== 0 && t < Gt[n].priority; n++);
      (Gt.splice(n, 0, e), n === 0 && bl(e));
    }
  };
  function os(e) {
    return !(!e || (e.nodeType !== 1 && e.nodeType !== 9 && e.nodeType !== 11));
  }
  function ri(e) {
    return !(
      !e ||
      (e.nodeType !== 1 &&
        e.nodeType !== 9 &&
        e.nodeType !== 11 &&
        (e.nodeType !== 8 || e.nodeValue !== " react-mount-point-unstable "))
    );
  }
  function Uc() {}
  function nm(e, t, n, r, o) {
    if (o) {
      if (typeof r == "function") {
        var a = r;
        r = function () {
          var x = ti(c);
          a.call(x);
        };
      }
      var c = Nc(t, r, e, 0, null, !1, !1, "", Uc);
      return (
        (e._reactRootContainer = c),
        (e[Ot] = c.current),
        Pr(e.nodeType === 8 ? e.parentNode : e),
        bn(),
        c
      );
    }
    for (; (o = e.lastChild);) e.removeChild(o);
    if (typeof r == "function") {
      var f = r;
      r = function () {
        var x = ti(m);
        f.call(x);
      };
    }
    var m = ts(e, 0, !1, null, null, !1, !1, "", Uc);
    return (
      (e._reactRootContainer = m),
      (e[Ot] = m.current),
      Pr(e.nodeType === 8 ? e.parentNode : e),
      bn(function () {
        ei(t, m, n, r);
      }),
      m
    );
  }
  function oi(e, t, n, r, o) {
    var a = n._reactRootContainer;
    if (a) {
      var c = a;
      if (typeof o == "function") {
        var f = o;
        o = function () {
          var m = ti(c);
          f.call(m);
        };
      }
      ei(t, c, e, o);
    } else c = nm(n, t, e, o, r);
    return ti(c);
  }
  ((wl = function (e) {
    switch (e.tag) {
      case 3:
        var t = e.stateNode;
        if (t.current.memoizedState.isDehydrated) {
          var n = mr(t.pendingLanes);
          n !== 0 &&
            (Ai(t, n | 1),
            it(t, Re()),
            (de & 6) === 0 && ((rr = Re() + 500), tn()));
        }
        break;
      case 13:
        (bn(function () {
          var r = Ut(e, 1);
          if (r !== null) {
            var o = Xe();
            jt(r, e, 1, o);
          }
        }),
          ns(e, 1));
    }
  }),
    (Pi = function (e) {
      if (e.tag === 13) {
        var t = Ut(e, 134217728);
        if (t !== null) {
          var n = Xe();
          jt(t, e, 134217728, n);
        }
        ns(e, 134217728);
      }
    }),
    (xl = function (e) {
      if (e.tag === 13) {
        var t = ln(e),
          n = Ut(e, t);
        if (n !== null) {
          var r = Xe();
          jt(n, e, t, r);
        }
        ns(e, t);
      }
    }),
    (kl = function () {
      return ye;
    }),
    (Sl = function (e, t) {
      var n = ye;
      try {
        return ((ye = e), t());
      } finally {
        ye = n;
      }
    }),
    (ki = function (e, t, n) {
      switch (t) {
        case "input":
          if ((sr(e, n), (t = n.name), n.type === "radio" && t != null)) {
            for (n = e; n.parentNode;) n = n.parentNode;
            for (
              n = n.querySelectorAll(
                "input[name=" + JSON.stringify("" + t) + '][type="radio"]',
              ),
                t = 0;
              t < n.length;
              t++
            ) {
              var r = n[t];
              if (r !== e && r.form === e.form) {
                var o = ko(r);
                if (!o) throw Error(l(90));
                (He(r), sr(r, o));
              }
            }
          }
          break;
        case "textarea":
          qs(e, n);
          break;
        case "select":
          ((t = n.value), t != null && Rn(e, !!n.multiple, t, !1));
      }
    }),
    (al = Ga),
    (sl = bn));
  var rm = { usingClientEntryPoint: !1, Events: [Mr, Hn, ko, ol, il, Ga] },
    Jr = {
      findFiberByHostInstance: gn,
      bundleType: 0,
      version: "18.3.1",
      rendererPackageName: "react-dom",
    },
    om = {
      bundleType: Jr.bundleType,
      version: Jr.version,
      rendererPackageName: Jr.rendererPackageName,
      rendererConfig: Jr.rendererConfig,
      overrideHookState: null,
      overrideHookStateDeletePath: null,
      overrideHookStateRenamePath: null,
      overrideProps: null,
      overridePropsDeletePath: null,
      overridePropsRenamePath: null,
      setErrorHandler: null,
      setSuspenseHandler: null,
      scheduleUpdate: null,
      currentDispatcherRef: ee.ReactCurrentDispatcher,
      findHostInstanceByFiber: function (e) {
        return ((e = dl(e)), e === null ? null : e.stateNode);
      },
      findFiberByHostInstance: Jr.findFiberByHostInstance || tm,
      findHostInstancesForRefresh: null,
      scheduleRefresh: null,
      scheduleRoot: null,
      setRefreshHandler: null,
      getCurrentFiber: null,
      reconcilerVersion: "18.3.1-next-f1338f8080-20240426",
    };
  if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u") {
    var ii = __REACT_DEVTOOLS_GLOBAL_HOOK__;
    if (!ii.isDisabled && ii.supportsFiber)
      try {
        ((to = ii.inject(om)), (At = ii));
      } catch {}
  }
  return (
    (at.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = rm),
    (at.createPortal = function (e, t) {
      var n =
        2 < arguments.length && arguments[2] !== void 0 ? arguments[2] : null;
      if (!os(t)) throw Error(l(200));
      return em(e, t, null, n);
    }),
    (at.createRoot = function (e, t) {
      if (!os(e)) throw Error(l(299));
      var n = !1,
        r = "",
        o = Dc;
      return (
        t != null &&
          (t.unstable_strictMode === !0 && (n = !0),
          t.identifierPrefix !== void 0 && (r = t.identifierPrefix),
          t.onRecoverableError !== void 0 && (o = t.onRecoverableError)),
        (t = ts(e, 1, !1, null, null, n, !1, r, o)),
        (e[Ot] = t.current),
        Pr(e.nodeType === 8 ? e.parentNode : e),
        new rs(t)
      );
    }),
    (at.findDOMNode = function (e) {
      if (e == null) return null;
      if (e.nodeType === 1) return e;
      var t = e._reactInternals;
      if (t === void 0)
        throw typeof e.render == "function"
          ? Error(l(188))
          : ((e = Object.keys(e).join(",")), Error(l(268, e)));
      return ((e = dl(t)), (e = e === null ? null : e.stateNode), e);
    }),
    (at.flushSync = function (e) {
      return bn(e);
    }),
    (at.hydrate = function (e, t, n) {
      if (!ri(t)) throw Error(l(200));
      return oi(null, e, t, !0, n);
    }),
    (at.hydrateRoot = function (e, t, n) {
      if (!os(e)) throw Error(l(405));
      var r = (n != null && n.hydratedSources) || null,
        o = !1,
        a = "",
        c = Dc;
      if (
        (n != null &&
          (n.unstable_strictMode === !0 && (o = !0),
          n.identifierPrefix !== void 0 && (a = n.identifierPrefix),
          n.onRecoverableError !== void 0 && (c = n.onRecoverableError)),
        (t = Nc(t, null, e, 1, n ?? null, o, !1, a, c)),
        (e[Ot] = t.current),
        Pr(e),
        r)
      )
        for (e = 0; e < r.length; e++)
          ((n = r[e]),
            (o = n._getVersion),
            (o = o(n._source)),
            t.mutableSourceEagerHydrationData == null
              ? (t.mutableSourceEagerHydrationData = [n, o])
              : t.mutableSourceEagerHydrationData.push(n, o));
      return new ni(t);
    }),
    (at.render = function (e, t, n) {
      if (!ri(t)) throw Error(l(200));
      return oi(null, e, t, !1, n);
    }),
    (at.unmountComponentAtNode = function (e) {
      if (!ri(e)) throw Error(l(40));
      return e._reactRootContainer
        ? (bn(function () {
            oi(null, null, e, !1, function () {
              ((e._reactRootContainer = null), (e[Ot] = null));
            });
          }),
          !0)
        : !1;
    }),
    (at.unstable_batchedUpdates = Ga),
    (at.unstable_renderSubtreeIntoContainer = function (e, t, n, r) {
      if (!ri(n)) throw Error(l(200));
      if (e == null || e._reactInternals === void 0) throw Error(l(38));
      return oi(e, t, n, !1, r);
    }),
    (at.version = "18.3.1-next-f1338f8080-20240426"),
    at
  );
}
var Kc;
function pm() {
  if (Kc) return ss.exports;
  Kc = 1;
  function i() {
    if (!(
      typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > "u" ||
      typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != "function"
    ))
      try {
        __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(i);
      } catch (u) {
        console.error(u);
      }
  }
  return (i(), (ss.exports = fm()), ss.exports);
}
var Qc;
function mm() {
  if (Qc) return ai;
  Qc = 1;
  var i = pm();
  return ((ai.createRoot = i.createRoot), (ai.hydrateRoot = i.hydrateRoot), ai);
}
var hm = mm();
const gm = Ed(hm);
let Gc = [];
const ym = new Set();
function vm(i) {
  if (i.join() !== Gc.join()) {
    Gc = i;
    for (const u of ym) u();
  }
}
function Ad(i) {
  const u = [...i.getAll("source"), ...i.getAll("sql")];
  return u.length
    ? u.some((l) => l !== "product" && l !== "mock" && l !== "real") ||
      new Set(u).size !== 1
      ? null
      : u[0]
    : "real";
}
new TextEncoder();
const wm = {},
  ir = [
    "fox",
    "owl",
    "bear",
    "panda",
    "wolf",
    "badger",
    "hedgehog",
    "squirrel",
    "deer",
    "raccoon",
    "cat",
    "dog",
    "rabbit",
    "hamster",
    "guineapig",
    "ferret",
    "budgie",
    "goldfish",
    "pony",
    "mouse",
    "cow",
    "pig",
    "sheep",
    "goat",
    "horse",
    "donkey",
    "chicken",
    "duck",
    "goose",
    "bull",
    "lion",
    "tiger",
    "elephant",
    "giraffe",
    "zebra",
    "rhino",
    "hippo",
    "cheetah",
    "meerkat",
    "monkey",
    "polarbear",
    "penguin",
    "seal",
    "arcticfox",
    "snowleopard",
    "walrus",
    "reindeer",
    "husky",
    "puffin",
    "yak",
    "whale",
    "dolphin",
    "shark",
    "octopus",
    "crab",
    "jellyfish",
    "seahorse",
    "pufferfish",
    "narwhal",
    "otter",
    "frog",
    "turtle",
    "gecko",
    "chameleon",
    "snake",
    "crocodile",
    "bee",
    "ladybird",
    "butterfly",
    "snail",
    "dragon",
    "unicorn",
    "phoenix",
    "griffin",
    "yeti",
    "pegasus",
    "kraken",
    "sphinx",
    "wyvern",
    "golem",
    "trex",
    "triceratops",
    "stegosaurus",
    "raptor",
    "pterodactyl",
    "brachiosaurus",
    "ankylosaurus",
    "spinosaurus",
    "dilophosaurus",
    "mosasaurus",
    "astronaut",
    "alien",
    "martian",
    "moon",
    "sun",
    "star",
    "comet",
    "satellite",
    "ufo",
    "rover",
    "robot",
    "android",
    "cyborg",
    "drone",
    "mecha",
    "servo",
    "glitch",
    "pixel",
    "sentry",
    "beacon",
    "vampire",
    "werewolf",
    "zombie",
    "ghost",
    "mummy",
    "frankenstein",
    "goblin",
    "ogre",
    "slime",
    "gargoyle",
  ];
function Zc(i) {
  return typeof i == "string" && ir.includes(i);
}
function xm(i) {
  return !(i?.role === "student" && i.aiAccess === !1);
}
function zn(i) {
  return i?.role === "student" && i.lane === "fallback";
}
function km(i) {
  return i.role === "student" && i.dataSource === "real" ? "real" : "product";
}
const Sm = 3600 * 12,
  Us = "comp_school_local_development_session",
  Cm = "x-comp-school-fallback-access",
  Pd = "https://comp.school/fallback",
  Et = "comp.school",
  bm = /^(preview-[a-z0-9-]+)(?:\.[a-z0-9-]+)?\.comp\.school$/i,
  _m = /^(preview-[a-z0-9-]+)\.[a-z0-9-]+\.pages\.dev$/i,
  jm = Object.freeze({
    "comp.school": 3e3,
    "code.comp.school": 3001,
    "admin.comp.school": 3002,
    "exams.comp.school": 3010,
    "recall.comp.school": 3011,
    "mark.comp.school": 3013,
    "games.comp.school": 3014,
    "self-assess.comp.school": 3015,
    "issues.comp.school": 3016,
    "printouts.comp.school": 3017,
    "docs.comp.school": 3018,
    "homework.comp.school": 3019,
  });
function fi() {
  return wm?.VITE_COMP_SCHOOL_TARGET === "android";
}
function qc(i) {
  return `${globalThis.location.origin}${i.pathname}${i.search}${i.hash}`;
}
function $s(i) {
  const u = i
    .trim()
    .toLowerCase()
    .replace(/^\[|\]$/g, "");
  return u === "localhost" || u === "127.0.0.1" || u === "::1";
}
function Em(i) {
  return [
    `${Us}=${encodeURIComponent(JSON.stringify({ version: 1, user: i }))}`,
    "Path=/",
    `Max-Age=${Sm}`,
    "SameSite=Lax",
  ].join("; ");
}
function Am() {
  return [`${Us}=`, "Path=/", "Max-Age=0", "SameSite=Lax"].join("; ");
}
function Td(i, u, l) {
  if (!l || !$s(u)) return null;
  const d = $m(i)[Us];
  if (!d) return null;
  try {
    const p = JSON.parse(d),
      y = p.user;
    return p.version !== 1 ||
      !y ||
      typeof y.id != "string" ||
      typeof y.name != "string" ||
      !["admin", "teacher", "student"].includes(y.role)
      ? null
      : y;
  } catch {
    return null;
  }
}
function Pm(i, u, l) {
  const d = new URL(i),
    p = new URLSearchParams(d.hash.replace(/^#/, ""));
  return (
    p.set("fallback", u),
    (d.hash = p.toString()),
    l ? zd(d.toString(), l) : d.toString()
  );
}
function zd(i, u) {
  const l = new URL(i),
    d = new URLSearchParams(l.hash.replace(/^#/, ""));
  return (d.set(_s, u), (l.hash = d.toString()), l.toString());
}
const _s = "fallbackAvatar",
  js = "comp-school-fallback-avatar";
function Tm(i) {
  let u = 2166136261;
  for (let l = 0; l < i.length; l += 1)
    ((u ^= i.charCodeAt(l)), (u = Math.imul(u, 16777619) >>> 0));
  return ir[u % ir.length];
}
function zm(i = Math.random) {
  const u = Math.min(ir.length - 1, Math.max(0, Math.floor(i() * ir.length)));
  return ir[u];
}
function Mm(i, u, l = Math.random) {
  const d = i.getItem(js),
    p = Zc(u) ? u : Zc(d) ? d : zm(l);
  return (p !== d && i.setItem(js, p), p);
}
function Lm(i) {
  return btoa(i).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}
function Rm(i) {
  let u = "";
  for (const l of i) u += String.fromCharCode(l);
  return Lm(u);
}
function Om(i) {
  if (!i || !/^[A-Za-z0-9_-]+$/.test(i))
    throw new Error("Invalid base64url value");
  const u = i
      .replace(/-/g, "+")
      .replace(/_/g, "/")
      .padEnd(Math.ceil(i.length / 4) * 4, "="),
    l = atob(u),
    d = new Uint8Array(l.length);
  for (let p = 0; p < l.length; p += 1) d[p] = l.charCodeAt(p);
  if (Rm(d) !== i) throw new Error("Non-canonical base64url value");
  return d;
}
function Md(i) {
  const u = Om(i);
  return new TextDecoder("utf-8", { fatal: !0 }).decode(u);
}
function Nm(i) {
  return !!i && typeof i == "object" && !Array.isArray(i);
}
function Ld(i) {
  const u = JSON.parse(i);
  if (!Nm(u)) throw new Error("Expected a JSON object");
  return u;
}
const Rd = Object.freeze([
    {
      hostname: "exams.comp.school",
      prefix: "/exams",
      pagesProject: "exam-host",
    },
    {
      hostname: "recall.comp.school",
      prefix: "/recall",
      pagesProject: "comp-school-recall",
    },
    {
      hostname: "code.comp.school",
      prefix: "/code",
      pagesProject: "coding-playground",
    },
  ]),
  Im = /^(preview-[a-z0-9-]+)\./i;
function Dm(i) {
  const u = i.trim().toLowerCase().replace(Im, "");
  return Rd.find((l) => l.hostname === u) ?? null;
}
function Od(i) {
  return Rd.find((u) => i === u.prefix || i.startsWith(`${u.prefix}/`)) ?? null;
}
function Nd(i) {
  const u = i.trim().toLowerCase();
  return (u.match(bm) || u.match(_m))?.[1] || null;
}
function mn(i) {
  if (fi()) return globalThis.location.origin;
  if ($s(i))
    return `http://${i.replace(/^\[|\]$/g, "") === "::1" ? "[::1]" : i}:3000`;
  const u = Nd(i);
  return u ? `https://${u}.${Et}` : `https://${Et}`;
}
function Zr(i, u) {
  if (fi()) {
    const p = Yc(Et, u);
    if (p) return qc(new URL(p));
    try {
      const y = new URL(u);
      return y.hostname.toLowerCase() === Et ? qc(y) : u;
    } catch {
      return u;
    }
  }
  if ($s(i))
    try {
      const p = new URL(u),
        y = jm[p.hostname.toLowerCase()];
      if (y)
        return (
          (p.protocol = "http:"),
          (p.hostname = i),
          (p.port = String(y)),
          p.toString()
        );
    } catch {
      return u;
    }
  const l = Yc(i, u);
  if (l) return l;
  const d = Nd(i);
  if (!d) return u;
  try {
    const p = new URL(u),
      y = p.hostname.toLowerCase();
    if (y === Et || y.endsWith(`.${Et}`))
      return (
        (p.hostname = y === Et ? `${d}.${Et}` : `${d}.${y}`),
        p.toString()
      );
  } catch {
    return u;
  }
  return u;
}
function Yc(i, u) {
  try {
    const l = new URL(u),
      d = Dm(l.hostname);
    if (!d || l.hostname.toLowerCase() !== d.hostname) return null;
    const p = new URL(mn(i));
    return (
      (l.protocol = p.protocol),
      (l.hostname = p.hostname),
      (l.port = p.port),
      (l.pathname = `${d.prefix}${l.pathname}`),
      l.toString()
    );
  } catch {
    return null;
  }
}
function Id(i) {
  if (!i?.trim()) return null;
  try {
    const u = new URL(i),
      l = u.hostname.toLowerCase();
    return u.protocol !== "https:" ||
      u.username ||
      u.password ||
      u.port ||
      !(l === Et || l.endsWith(`.${Et}`)) ||
      (l.replace(/^preview-[a-z0-9-]+\./, "") === Et && !Od(u.pathname))
      ? null
      : u.toString();
  } catch {
    return null;
  }
}
function Um(i, u, l) {
  const d = l?.trim() || mn(i),
    p = Id(Zr(i, u));
  if (!p) return d;
  try {
    const y = new URL(d);
    return (y.searchParams.set("returnTo", p), y.toString());
  } catch {
    return d;
  }
}
function $m(i) {
  return i
    ? i.split(";").reduce((u, l) => {
        const [d, ...p] = l.trim().split("=");
        if (!d) return u;
        const y = p.join("=");
        try {
          u[d] = decodeURIComponent(y);
        } catch {
          u[d] = y;
        }
        return u;
      }, {})
    : {};
}
function cs(i) {
  if (!i) return null;
  try {
    const u = Ld(Md(i.split(".")[0] ?? ""));
    return u.iss === Pd && typeof u.exp == "number" && Number.isInteger(u.exp)
      ? u.exp * 1e3
      : null;
  } catch {
    return null;
  }
}
function Es(i, u = new Date()) {
  if (!i) return !1;
  try {
    const [l, d, p] = i.split(".");
    if (!l || p !== void 0 || !d || !/^[A-Za-z0-9_-]+$/.test(d)) return !1;
    const y = Ld(Md(l));
    return (
      y.iss === Pd &&
      typeof y.exp == "number" &&
      Number.isInteger(y.exp) &&
      (fi() || y.exp > Math.floor(u.getTime() / 1e3))
    );
  } catch {
    return !1;
  }
}
function Fm(i) {
  const u = window.location.hostname.toLowerCase(),
    l =
      u === "comp.school" || u.endsWith(".comp.school")
        ? "; Domain=comp.school"
        : "",
    d = window.location.protocol === "https:" ? "; Secure" : "";
  return `; Path=/; Max-Age=${i}; SameSite=Lax${l}${d}`;
}
const Wm = [
    "examhost:",
    "coding-playground:theme:",
    "companion:variant:",
    "comp-school:flashcards:",
    "comp-school:paused:",
    "comp-school-self-assessment-v2",
    "comp-school:game-clock:",
    "comp-school:homework-done:",
    "comp-school:btec-coursework:",
    "comp-school:btec-games:",
  ],
  Dd = ["comp_school_recent_sessions", "comp_school_btec_recent_sessions"],
  Bm = 200,
  Ud = 64e3,
  $d = /^\d{1,20}$/;
function Fd(i) {
  if (typeof i != "string" || i.length > Bm || /[\u0000-\u001f]/.test(i))
    return !1;
  if (i.startsWith("cookie:")) return Dd.includes(i.slice(7));
  if (!i.startsWith("local:")) return !1;
  const u = i.slice(6);
  return Wm.some((l) => u.startsWith(l) && u.length > l.length);
}
function li(i, u) {
  const l = {};
  for (const [p, y] of Object.entries(u)) i[p] !== y && (l[p] = y);
  const d = Object.keys(i).filter((p) => !(p in u));
  return { set: l, remove: d };
}
function Qr(i) {
  return i.remove.length > 0 || Object.keys(i.set).length > 0;
}
function Wd(i) {
  let u = 2166136261;
  for (let l = 0; l < i.length; l += 1)
    ((u ^= i.charCodeAt(l)), (u = Math.imul(u, 16777619)));
  return `${(u >>> 0).toString(36)}.${i.length.toString(36)}`;
}
function Hm(i) {
  return Object.fromEntries(Object.entries(i).map(([u, l]) => [u, Wd(l)]));
}
function Vm(i, u) {
  const l = {};
  for (const [p, y] of Object.entries(u)) i[p] !== Wd(y) && (l[p] = y);
  const d = Object.keys(i).filter((p) => !(p in u));
  return { set: l, remove: d };
}
function Jm(i, u) {
  const l = { ...i, ...u.set };
  for (const d of u.remove) delete l[d];
  return l;
}
const ci = "comp-school:saved-state-owner",
  Mn = "comp-school:saved-state-dirty",
  Fs = "comp-school:saved-state-confirmed",
  Ws = "comp-school:saved-state-revisions",
  Km = 4320 * 60 * 60,
  Qm = 3e3,
  Gm = "comp-school:recent-sessions-change";
function Zm(i) {
  return `${i.dataSource === "real" ? "real" : "product"}:${i.id}`;
}
function wt() {
  try {
    return window.localStorage;
  } catch {
    return null;
  }
}
function qm(i) {
  const u = `${i}=`,
    d = window.document.cookie
      .split("; ")
      .find((p) => p.startsWith(u))
      ?.slice(u.length);
  return d || null;
}
function Bs() {
  const i = {},
    u = wt();
  if (u)
    for (let l = 0; l < u.length; l += 1) {
      const d = u.key(l);
      if (!d || !Fd(`local:${d}`)) continue;
      const p = u.getItem(d);
      p !== null && p.length <= Ud && (i[`local:${d}`] = p);
    }
  for (const l of Dd) {
    const d = qm(l);
    d !== null && (i[`cookie:${l}`] = d);
  }
  return i;
}
function Hs() {
  const i = [],
    u = wt();
  if (!u) return i;
  for (let l = 0; l < u.length; l += 1) {
    const d = u.key(l);
    if (!d || !Fd(`local:${d}`)) continue;
    const p = u.getItem(d);
    p !== null && p.length > Ud && i.push(`local:${d}`);
  }
  return i;
}
function Xc(i, u) {
  if (i.startsWith("cookie:")) {
    const d = i.slice(7);
    window.document.cookie = `${d}=${u ?? ""}${Fm(u === null ? 0 : Km)}`;
    return;
  }
  const l = i.slice(6);
  u === null ? wt()?.removeItem(l) : wt()?.setItem(l, u);
}
function ui(i, u = new Set()) {
  for (const l of [...Object.keys(Bs()), ...Hs()])
    !(l in i) && !u.has(l) && Xc(l, null);
  for (const [l, d] of Object.entries(i)) u.has(l) || Xc(l, d);
  window.dispatchEvent(new Event(Gm));
}
const As = "comp-school:saved-state-notice",
  ed = new Set();
function Ps(i, u) {
  const l = u.filter((d) => !ed.has(`${i}:${d}`));
  if (!(!l.length || typeof window > "u")) {
    for (const d of l) ed.add(`${i}:${d}`);
    window.dispatchEvent(new CustomEvent(As, { detail: { kind: i, keys: l } }));
  }
}
function Ym(i) {
  const u = (l) => {
    const d = l.detail;
    d && (d.kind === "conflict" || d.kind === "too-big") && i(d);
  };
  return (
    window.addEventListener(As, u),
    () => window.removeEventListener(As, u)
  );
}
function Vs() {
  const i = wt();
  i?.getItem(ci) &&
    (ui({}),
    i.removeItem(ci),
    i.removeItem(Mn),
    i.removeItem(Fs),
    i.removeItem(Ws));
}
function Xm() {
  try {
    const i = JSON.parse(wt()?.getItem(Fs) ?? "null");
    return !i || typeof i != "object" || Array.isArray(i)
      ? null
      : Object.fromEntries(
          Object.entries(i).filter((u) => typeof u[1] == "string"),
        );
  } catch {
    return null;
  }
}
function Ts(i) {
  try {
    wt()?.setItem(Fs, JSON.stringify(Hm(i)));
  } catch {}
}
function Bd() {
  try {
    const i = JSON.parse(wt()?.getItem(Ws) ?? "null");
    return !i || typeof i != "object" || Array.isArray(i)
      ? null
      : Object.fromEntries(
          Object.entries(i).filter(
            (u) => typeof u[1] == "string" && $d.test(u[1]),
          ),
        );
  } catch {
    return null;
  }
}
function zs(i) {
  try {
    wt()?.setItem(Ws, JSON.stringify(i));
  } catch {}
}
function Hd(i, u, l) {
  const d = {};
  if (!u) return d;
  for (const p of [...Object.keys(i.set), ...i.remove])
    u[p] ? (d[p] = u[p]) : p in l || (d[p] = "0");
  return d;
}
function Vd(i, u, l) {
  const d = { ...i },
    p = new Set(l.conflicts);
  for (const y of u.remove) p.has(y) || delete d[y];
  for (const y of Object.keys(u.set))
    !p.has(y) && !l.revisions[y] && delete d[y];
  return { ...d, ...l.revisions };
}
const eh = new Set();
function Ms() {
  for (const i of [...eh])
    try {
      i();
    } catch {}
}
function td(i) {
  return !i || typeof i != "object" || Array.isArray(i)
    ? {}
    : Object.fromEntries(
        Object.entries(i).filter(
          (u) => typeof u[1] == "string" && $d.test(u[1]),
        ),
      );
}
function th(i) {
  const u = new URL("/api/saved-state", i).toString();
  return {
    async read() {
      const l = await fetch(u, {
          cache: "no-store",
          credentials: "include",
          headers: { accept: "application/json" },
        }),
        d = await l.json().catch(() => null);
      if (!l.ok || !d?.ok || !d.items)
        throw new Error("Saved state could not be read.");
      return { items: d.items, revisions: td(d.revisions) };
    },
    async write(l, { keepalive: d = !1 } = {}) {
      const p = await fetch(u, {
        method: "POST",
        cache: "no-store",
        credentials: "include",
        keepalive: d,
        headers: {
          accept: "application/json",
          "content-type": "application/json",
        },
        body: JSON.stringify(l),
      });
      if (!p.ok) throw new Error("Saved state could not be written.");
      const y = await p.json().catch(() => null),
        S = new Set([...Object.keys(l.set), ...l.remove]);
      return {
        revisions: td(y?.revisions),
        conflicts: Array.isArray(y?.conflicts)
          ? y.conflicts.filter((j) => typeof j == "string" && S.has(j))
          : [],
      };
    },
  };
}
async function nh(i, u) {
  const l = wt();
  if (!l) return null;
  const d = Zm(i),
    p = l.getItem(ci);
  p && p !== d && Vs();
  let y;
  try {
    y = await u.read();
  } catch {
    return null;
  }
  const S = y.items,
    j = Bs(),
    k = new Set(p === d ? Hs() : []);
  for (const Q of k) Q in S && (j[Q] = S[Q]);
  k.size && Ps("too-big", [...k]);
  const F = p === d ? Xm() : null,
    L = p === d ? Bd() : p ? {} : y.revisions,
    D =
      (p === d && l.getItem(Mn) !== null) ||
      (!p && Object.keys(S).length === 0 && Object.keys(j).length > 0),
    O = F && !D ? Vm(F, j) : null;
  l.setItem(ci, d);
  const K = D ? j : O && Qr(O) ? Jm(S, O) : null;
  if (K) {
    const Q = li(S, K);
    try {
      let M = K,
        B = y.revisions;
      if (Qr(Q)) {
        const V = await u.write({ ...Q, base: Hd(Q, L, F ?? {}) });
        if (((B = Vd(y.revisions, Q, V)), V.conflicts.length)) {
          M = { ...K };
          for (const ie of V.conflicts)
            ie in S ? (M[ie] = S[ie]) : delete M[ie];
        }
      }
      return (M !== j && ui(M, k), l.removeItem(Mn), Ts(M), zs(B), M);
    } catch {
      return (l.setItem(Mn, "1"), K !== j && ui(K, k), S);
    }
  }
  return (ui(S, k), l.removeItem(Mn), Ts(S), zs(y.revisions), S);
}
function rh(i, u, l = Qm) {
  let d = i,
    p = Bd();
  const y = new Set();
  let S = !1;
  function j() {
    const O = Bs(),
      K = Hs();
    K.length && Ps("too-big", K);
    for (const Q of [...K, ...y]) Q in d ? (O[Q] = d[Q]) : delete O[Q];
    return O;
  }
  async function k(O = !1) {
    if (S && !O) return;
    const K = j(),
      Q = li(d, K);
    if (Qr(Q)) {
      (wt()?.setItem(Mn, "1"), (S = !0));
      try {
        const M = await u.write({ ...Q, base: Hd(Q, p, d) }, { keepalive: O });
        ((p = Vd(p, Q, M)), zs(p));
        const B = { ...K };
        for (const V of M.conflicts)
          (y.add(V), V in d ? (B[V] = d[V]) : delete B[V]);
        ((d = B),
          Ts(B),
          M.conflicts.length && Ps("conflict", M.conflicts),
          Qr(li(d, j())) || wt()?.removeItem(Mn));
      } catch {
      } finally {
        S = !1;
      }
    }
  }
  const F = window.setInterval(() => void k(), l),
    L = () => {
      window.document.visibilityState === "hidden" && (Ms(), k(!0));
    },
    D = () => {
      (Ms(), k(!0));
    };
  return (
    window.document.addEventListener("visibilitychange", L),
    window.addEventListener("pagehide", D),
    {
      flush: () => k(),
      pending: () => Qr(li(d, j())),
      stop() {
        (window.clearInterval(F),
          window.document.removeEventListener("visibilitychange", L),
          window.removeEventListener("pagehide", D));
      },
    }
  );
}
let Gr = null;
function oh(i) {
  return (
    (Gr ??= (async () => {
      const u = th(mn(window.location.hostname)),
        l = await nh(i, u);
      return l ? rh(l, u) : null;
    })()),
    Gr
  );
}
async function ih(i = 4e3) {
  const u = await Gr?.catch(() => null);
  if (!u) return;
  const l = Date.now() + i;
  do {
    if ((await u.flush().catch(() => {}), !u.pending())) return;
    await new Promise((d) => window.setTimeout(d, 150));
  } while (Date.now() < l);
}
async function Ls(i = 4e3) {
  (Ms(), await ih(i));
}
async function ah() {
  const i = await Gr?.catch(() => null);
  ((Gr = null), i && (await i.flush().catch(() => {}), i.stop()), Vs());
}
const Jd = {
    1.1: [
      {
        term: "Arithmetic Logic Unit (ALU)",
        definition:
          "Performs calculations and logical comparisons inside the Central Processing Unit (CPU)",
        example: "Adding two numbers together, comparing if A > B",
      },
      {
        term: "Control Unit (CU)",
        definition:
          "Directs the flow of data and instructions around the CPU by sending control signals",
        example:
          "Sends signals telling memory to release data to the correct register",
      },
      {
        term: "Cache",
        definition:
          "Small, fast memory inside the CPU that stores frequently used data and instructions",
        example:
          "Stores the next instruction the CPU is likely to need so it does not have to fetch from Random Access Memory (RAM)",
      },
      {
        term: "Register",
        definition:
          "A tiny, high-speed storage location inside the CPU that temporarily holds data, instructions or memory addresses",
        example:
          "Memory Address Register (MAR), Memory Data Register (MDR), Accumulator (ACC), Program Counter (PC)",
      },
      {
        term: "Memory Address Register (MAR)",
        definition:
          "A register that holds the memory address of the data or instruction the CPU wants to read or write",
        example:
          "Before fetching the next instruction, the Program Counter copies its address into the MAR",
      },
      {
        term: "Memory Data Register (MDR)",
        definition:
          "A register that holds the data or instruction just fetched from memory, or about to be written to memory",
        example:
          "After fetching, the instruction at the address held in the MAR is loaded into the MDR",
      },
      {
        term: "Program Counter (PC)",
        definition:
          "A register that holds the memory address of the next instruction to be fetched, incrementing automatically after each fetch",
        example:
          "After fetching the instruction at address 100, the PC updates to 101 ready for the next cycle",
      },
      {
        term: "Accumulator (ACC)",
        definition:
          "A register in the CPU that temporarily stores the result of arithmetic and logical operations carried out by the ALU",
        example:
          "When the ALU calculates 5 + 3, the result 8 is held in the Accumulator before being moved to memory",
      },
      {
        term: "Fetch-Decode-Execute (FDE) Cycle",
        definition:
          "The repeated process of fetching an instruction from memory, decoding what it means, then executing it",
        example:
          "The CPU fetches an instruction from RAM; the CU decodes it; the CPU carries it out, for example using the ALU to add two values",
      },
      {
        term: "Clock Speed",
        definition:
          "The number of CPU clock cycles per second, usually measured in Gigahertz (GHz); a higher clock speed allows more cycles each second",
        example:
          "A 3.5 GHz processor has 3.5 billion clock cycles per second; clock speed alone does not determine performance",
      },
      {
        term: "Cores",
        definition:
          "Independent processing units within a CPU that can work on instructions concurrently",
        example:
          "More cores can speed up work that can be split between them; doubling cores does not necessarily halve running time",
      },
      {
        term: "Cache Size",
        definition:
          "The amount of fast cache memory available to store frequently used data and instructions",
        example:
          "More cache can reduce fetching from slower RAM, improving performance when the needed data is in cache",
      },
      {
        term: "Embedded System",
        definition:
          "A computer built into a larger device to carry out a specific task or a limited set of related tasks",
        example:
          "A washing-machine controller runs the wash cycle; a thermostat controls heating; a car's automatic-light controller switches its lights according to light levels",
      },
      {
        term: "Von Neumann Architecture",
        definition:
          "A model of computer design where a single memory stores both data and instructions, and the CPU processes them sequentially via the fetch-decode-execute cycle",
        example:
          "The CPU fetches instructions from the same memory where data is stored, using registers like MAR, MDR, PC and ACC to manage the process",
      },
      {
        term: "Embedded System Characteristics",
        definition:
          "Dedicated hardware and software perform limited functions; the user cannot easily repurpose the system to run unrelated applications",
        example:
          "A car's automatic-light controller has a processor dedicated to checking the light sensor and switching the lamps, rather than running general-purpose applications",
      },
    ],
    1.2: [
      {
        term: "Random Access Memory (RAM)",
        definition:
          "Volatile primary storage that holds data and programs currently in use; contents are lost when power is off",
        example:
          "When you open Google Chrome, its program code is loaded from storage into RAM",
      },
      {
        term: "Read Only Memory (ROM)",
        definition:
          "Non-volatile primary storage that retains startup or firmware instructions without power; its contents are not normally changed during use",
        example:
          "A car controller's ROM can hold its startup instructions and the firmware that controls the system",
      },
      {
        term: "Virtual Memory",
        definition:
          "Secondary storage used to hold data moved out of RAM when RAM is full; the OS transfers data back to RAM when needed",
        example:
          "An OS moves inactive data to an SSD or HDD to free RAM; accessing secondary storage is slower than accessing RAM",
      },
      {
        term: "Magnetic Storage",
        definition:
          "Non-volatile storage that records data magnetically, for example on hard disks or magnetic tape",
        example:
          "An HDD uses rotating platters and a read/write head; magnetic tape is often used for large backups",
      },
      {
        term: "Optical Storage",
        definition: "Uses a laser to read and write data on a reflective disc",
        example: "Compact Disc (CD), Digital Versatile Disc (DVD), Blu-ray",
      },
      {
        term: "Solid State Storage",
        definition:
          "Uses electronic flash memory with no moving parts, making it faster and more durable",
        example:
          "Solid State Drive (SSD), Universal Serial Bus (USB) flash drive",
      },
      {
        term: "Bit",
        definition:
          "The smallest unit of data in computing; a single binary digit, either 0 or 1",
        example: "One switch that is either on (1) or off (0)",
      },
      {
        term: "Nibble",
        definition: "A group of 4 bits",
        example: "Half a byte, e.g. 1010",
      },
      {
        term: "Byte",
        definition: "A group of 8 bits",
        example: "Can represent a whole number from 0 to 255",
      },
      {
        term: "Kilobyte (KB)",
        definition:
          "A unit of data storage equal to 1000 bytes (OCR also accepts 1024)",
        example: "A small text file might be 50 KB",
      },
      {
        term: "Megabyte (MB)",
        definition:
          "A unit of data storage equal to 1000 kilobytes (OCR also accepts 1024)",
        example: "A photo might be several MB",
      },
      {
        term: "Gigabyte (GB)",
        definition:
          "A unit of data storage equal to 1000 megabytes (OCR also accepts 1024)",
        example: "A high-definition film might be 4 GB",
      },
      {
        term: "Terabyte (TB)",
        definition:
          "A unit of data storage equal to 1000 gigabytes (OCR also accepts 1024)",
        example: "A laptop hard drive might store 1 TB of data",
      },
      {
        term: "Petabyte (PB)",
        definition:
          "A unit of data storage equal to 1000 terabytes (OCR also accepts 1024)",
        example: "Large cloud providers may store many PB of data",
      },
      {
        term: "Binary",
        definition: "Base-2 number system using only the digits 0 and 1",
        example: "01001010 in binary represents 74 in denary",
      },
      {
        term: "Denary",
        definition:
          "Base-10 number system using digits 0 to 9; the everyday counting system",
        example: "The number 255 in denary is 11111111 in binary",
      },
      {
        term: "Hexadecimal",
        definition: "Base-16 number system using digits 0-9 and letters A-F",
        example:
          "2F = 2 x 16 + 15 = 47 in denary; each hex digit maps to four bits, so 2F = 0010 1111",
      },
      {
        term: "Binary Addition",
        definition:
          "Adding two binary numbers together, carrying over when a column totals 2 or more",
        example: "1011 + 0111 = 10010 (11 + 7 = 18 in denary)",
      },
      {
        term: "Overflow",
        definition:
          "An error that occurs when the result of a binary calculation needs more bits than are available; the extra bit is lost so the stored answer is incorrect",
        example:
          "Adding 11111111 + 00000001 in 8 bits gives 100000000 - the leading 1 is dropped and the result is recorded as 00000000",
      },
      {
        term: "Binary Shift",
        definition:
          "Moving every bit a set number of places, filling empty positions with zero and discarding bits shifted out",
        example:
          "For unsigned 8-bit values, 00001100 shifted left once becomes 00011000 (12 to 24); 00001101 shifted right once becomes 00000110 (13 to 6). Left shifts double per place only if no significant bit is lost",
      },
      {
        term: "Most Significant Bit (MSB)",
        definition:
          "The bit with the highest place value in a binary number, usually the leftmost bit",
        example: "In 10110001, the MSB is 1 and represents 128",
      },
      {
        term: "Least Significant Bit (LSB)",
        definition:
          "The bit with the lowest place value in a binary number, usually the rightmost bit",
        example: "In 10110001, the LSB is 1 and represents 1",
      },
      {
        term: "Character Set",
        definition:
          "A collection of characters with a unique code for each; n bits can represent up to 2^n different codes",
        example:
          "7 bits give 128 codes; 8 bits give 256, so representing 150 different characters requires at least 8 bits",
      },
      {
        term: "American Standard Code for Information Interchange (ASCII)",
        definition:
          "A character set mapping characters to numeric codes; OCR J277 questions represent ASCII using 8 bits per character (original ASCII used 7 bits)",
        example:
          "'A' is 65 (01000001), 'B' is 66 (01000010); consecutive letters have consecutive codes",
      },
      {
        term: "Unicode",
        definition:
          "A character set covering many languages and symbols; the number of bits used depends on the encoding",
        example:
          "Unicode can represent Hello, Chinese characters and emojis; ASCII cannot represent all of these. Use the stated bits per character in file-size questions",
      },
      {
        term: "Sound Sampling",
        definition:
          "Converting analogue sound to digital by measuring amplitude at regular intervals and storing each sample as a binary value",
        example:
          "Higher sample rate or bit depth can improve fidelity and increase file size; a longer recording increases file size without improving fidelity",
      },
      {
        term: "Sample Rate",
        definition:
          "The number of audio samples taken per second, measured in Hertz (Hz)",
        example: "CD quality audio uses 44,100 samples per second (44.1 kHz)",
      },
      {
        term: "Bit Depth",
        definition:
          "The number of bits used to record each audio sample; more bits means more detail",
        example:
          "16-bit audio gives 65,536 possible amplitude levels per sample",
      },
      {
        term: "Pixel",
        definition:
          "The smallest individual element of a digital image; each pixel stores a single colour value as a binary code",
        example:
          "A 1920 x 1080 image is made up of 2,073,600 pixels arranged in a grid",
      },
      {
        term: "Bitmap Image",
        definition:
          "A graphic made up of a grid of pixels, each assigned a colour value",
        example: "A 1920 x 1080 image contains over 2 million pixels",
      },
      {
        term: "Colour Depth",
        definition:
          "The number of bits used for each pixel; n bits allow up to 2^n colours",
        example:
          "7 bits allow 128 colours; 8 allow 256, so 240 colours need 8 bits. More bits can improve colour detail but increase file size",
      },
      {
        term: "Resolution",
        definition:
          "The dimensions of an image in pixels, usually width x height",
        example:
          "A 200 x 100 image has 20,000 pixels. Increasing dimensions can capture more detail but increases file size at the same colour depth",
      },
      {
        term: "Metadata",
        definition:
          "Additional data stored alongside an image or sound file describing its properties so the file can be interpreted correctly",
        example:
          "An image file's metadata includes width, height, colour depth, date taken and camera model",
      },
      {
        term: "Image File Size Calculation",
        definition:
          "File size = width x height x colour depth (in bits), then convert to bytes",
        example:
          "100 x 100 pixels at 24-bit colour = 240,000 bits = 30,000 bytes",
      },
      {
        term: "Sound File Size Calculation",
        definition:
          "File size = sample rate x bit depth x duration (seconds), then convert to bytes",
        example: "44,100 x 16 x 10 seconds = 7,056,000 bits = 882,000 bytes",
      },
      {
        term: "Text File Size Calculation",
        definition:
          "File size = bits per character x number of characters, then convert bits to bytes if required",
        example:
          "A 1,000-character message in 8-bit ASCII = 1,000 x 8 = 8,000 bits = 1,000 bytes (1 KB)",
      },
      {
        term: "Compression",
        definition:
          "Reducing the size of a file so it takes up less storage and transfers more quickly across a network; can be lossy or lossless",
        example:
          "A 10 MB photo compressed to 2 MB downloads five times faster on the same connection",
      },
      {
        term: "Lossy Compression",
        definition:
          "Reduces file size by permanently removing some data that cannot be recovered",
        example:
          "Joint Photographic Experts Group (JPEG) removes colour detail the human eye barely notices",
      },
      {
        term: "Lossless Compression",
        definition:
          "Reduces file size without losing any data; the original file can be perfectly rebuilt",
        example:
          "Portable Network Graphics (PNG), ZIP files; identical data when decompressed",
      },
      {
        term: "Secondary Storage",
        definition:
          "Non-volatile storage that keeps programs and files when power is off",
        example:
          "A saved document remains on an SSD after shutdown; it is loaded into RAM when opened",
      },
      {
        term: "Choosing Storage",
        definition:
          "Compare capacity, speed, cost, portability, durability and reliability against the needs of the user",
        example:
          "A portable SSD is fast, compact and resists knocks because it has no moving parts; an HDD may offer more capacity for the same cost, but moving parts are vulnerable to damage",
      },
    ],
    1.3: [
      {
        term: "Local Area Network (LAN)",
        definition:
          "A network covering a small geographical area, typically owned and managed by one organisation",
        example:
          "A school network connecting all computers across one or two buildings",
      },
      {
        term: "Wide Area Network (WAN)",
        definition:
          "A network covering a large geographical area, using third-party communication links",
        example:
          "The internet connecting users in London to servers in New York",
      },
      {
        term: "Bandwidth",
        definition:
          "The maximum amount of data that can be transmitted across a network connection in a fixed time, usually measured in megabits per second (Mbps); a key factor affecting network performance alongside the number of connected devices",
        example:
          "A 100 Mbps fibre line shared between 10 users averages 10 Mbps each; a school Wi-Fi slows at break time when many phones connect",
      },
      {
        term: "Star Topology",
        definition:
          "A network layout where all devices connect to a central switch or hub",
        example:
          "A failed device link leaves other devices connected, but failure of the central switch affects the whole network; adding a device requires a link to the switch",
      },
      {
        term: "Mesh Topology",
        definition:
          "A network with multiple direct connections between devices; a full mesh connects every pair, while a partial mesh connects only some pairs",
        example:
          "Alternative paths can keep communication working if a link fails; extra connections can make setup more complex",
      },
      {
        term: "Client-Server Network",
        definition:
          "A central server provides services and resources; client devices make requests",
        example:
          "A school file server holds shared folders that students access from their PCs",
      },
      {
        term: "Peer-to-Peer (P2P) Network",
        definition:
          "All devices are equal and share resources directly with each other without a central server",
        example: "Two laptops sharing files directly over a home network",
      },
      {
        term: "Wired Connection (Ethernet)",
        definition:
          "Connecting devices using physical cables and Ethernet standards",
        example:
          "A fixed office computer can use a stable, high-bandwidth cable connection, but installing cables costs money and restricts movement",
      },
      {
        term: "Wireless Connection (Wi-Fi)",
        definition:
          "Connecting devices using radio waves through a Wireless Access Point (WAP)",
        example:
          "A tablet can move within signal range without a cable, but walls, interference and shared bandwidth can reduce performance",
      },
      {
        term: "Bluetooth",
        definition:
          "Short-range wireless technology for pairing devices over a few metres",
        example: "Wireless headphones connecting to a smartphone",
      },
      {
        term: "Internet Protocol (IP) Address",
        definition:
          "An address used to identify a device or interface on an IP network and route data to it",
        example:
          "IPv4 example: 192.168.1.1. IPv6 example: 2001:0db8:0000:0000:0000:0000:0000:0001",
      },
      {
        term: "Media Access Control (MAC) Address",
        definition:
          "A unique hardware address permanently burned into a device's Network Interface Card (NIC)",
        example:
          "00:1A:2B:3C:4D:5E; set during manufacturing and cannot normally be changed",
      },
      {
        term: "TCP (Transmission Control Protocol)",
        definition:
          "A network protocol that checks packets are delivered reliably and reassembles them in the correct order",
        example:
          "When a web page is downloaded, TCP can request missing packets again so the page data arrives complete",
      },
      {
        term: "IP (Internet Protocol)",
        definition:
          "A network protocol that adds source and destination addresses so packets can be routed between networks",
        example:
          "Each packet travelling across the internet includes an IP address for the device it is being sent to",
      },
      {
        term: "HyperText Transfer Protocol (HTTP) / Secure (HTTPS)",
        definition:
          "Protocols for requesting and transferring web pages; HTTPS also encrypts the data between the browser and the web server",
        example:
          "Visiting https://www.bbc.co.uk; the padlock icon shows HTTPS is active",
      },
      {
        term: "File Transfer Protocol (FTP)",
        definition:
          "A protocol used for transferring files between a client and a server",
        example:
          "Uploading website files from a local computer to a web hosting server",
      },
      {
        term: "SMTP (Simple Mail Transfer Protocol)",
        definition:
          "The protocol used to send emails from a client to a server, or between mail servers",
        example:
          "When you click Send in Gmail, SMTP transfers your email to the recipient's mail server",
      },
      {
        term: "POP (Post Office Protocol)",
        definition:
          "An email protocol that downloads messages from the server to the local device and then removes them from the server",
        example:
          "Downloading emails to a desktop client using POP means they are no longer accessible from your phone",
      },
      {
        term: "IMAP (Internet Message Access Protocol)",
        definition:
          "An email protocol that keeps messages stored on the server and syncs them across all devices",
        example:
          "Reading an email on your phone and it also appearing as read on your laptop uses IMAP",
      },
      {
        term: "Email Protocols",
        definition:
          "A set of rules that govern how emails are sent, received, and stored across networks; SMTP handles sending, while POP and IMAP handle receiving",
        example:
          "When you send an email, SMTP delivers it to the recipient's server; when they check their inbox, POP or IMAP retrieves it",
      },
      {
        term: "Layering",
        definition:
          "The concept of dividing network communication into separate, independent layers where each layer has a specific role and communicates only with the layers directly above and below it",
        example:
          "Switching from Ethernet to Wi-Fi only changes the layer that handles the connection; the layers above it, such as the one where HTTP works, are unaffected",
      },
      {
        term: "Network Interface Card (NIC)",
        definition:
          "Hardware component that allows a device to connect to a network, either wired or wirelessly",
        example: "Every laptop has a built-in wireless NIC",
      },
      {
        term: "Router",
        definition:
          "A device that forwards packets between different networks and determines the best route",
        example:
          "Your home router sends data between your LAN and the internet (WAN)",
      },
      {
        term: "Switch",
        definition:
          "A device that connects devices within a LAN and sends data only to the intended recipient using MAC addresses",
        example:
          "A 24-port switch in a school server room connecting all classroom PCs",
      },
      {
        term: "Wireless Access Point (WAP)",
        definition:
          "A device that allows wireless devices to connect to a wired network",
        example: "A WAP mounted on a classroom ceiling providing Wi-Fi",
      },
      {
        term: "Transmission Media",
        definition:
          "The physical pathways that carry data signals between devices on a network, either wired (cables) or wireless (radio waves)",
        example:
          "Copper Ethernet cable, fibre optic cable and Wi-Fi radio waves are all transmission media",
      },
      {
        term: "Domain Name System (DNS)",
        definition:
          "A system of Domain Name Servers that converts human-readable domain names into IP addresses so browsers can locate websites",
        example:
          "Typing www.bbc.co.uk into a browser; the DNS converts this to an IP address like 151.101.0.81 so the request reaches the correct server",
      },
      {
        term: "The Cloud",
        definition:
          "Remote provision of storage, software or processing over a network, usually the internet",
        example:
          "Cloud storage allows access from different devices and can reduce local hardware needs, but depends on connectivity and the provider, and may have ongoing costs",
      },
      {
        term: "Hosting",
        definition:
          "The provision of server space and resources by a hosting company so that websites, applications or files are continuously available over the internet",
        example:
          "A web hosting company stores a school's website files on its servers so they can be reached at any time via the school's domain name",
      },
      {
        term: "Web Server and Client",
        definition:
          "A web server stores and delivers web pages; a client is a device or program that requests and displays those pages",
        example:
          "A web server hosts the BBC website; your browser acts as the client requesting and displaying the page",
      },
      {
        term: "Standards",
        definition:
          "Agreed rules and specifications that allow hardware and software from different manufacturers to work together",
        example:
          "Standards ensure a keyboard made by one company works with a computer made by another; they enable interoperability across the industry",
      },
      {
        term: "IP Address Formats",
        definition:
          "IPv4 has four decimal groups from 0 to 255 separated by dots. An uncompressed IPv6 address has eight groups of up to four hexadecimal digits separated by colons",
        example:
          "192.168.1.1 is valid IPv4; 258.0.0.1 is invalid. 2001:0db8:0000:0000:0000:0000:0000:0001 is valid IPv6",
      },
    ],
    1.4: [
      {
        term: "Malware",
        definition:
          "Malicious software designed to damage systems or gain unauthorised access",
        example: "Virus, trojan, spyware, ransomware, worm",
      },
      {
        term: "Virus",
        definition:
          "Malware that attaches to a legitimate file and spreads when the file is executed",
        example:
          "A virus hidden inside a downloaded game installer that corrupts files when run",
      },
      {
        term: "Trojan",
        definition:
          "Malware disguised as legitimate software that creates a backdoor for attackers",
        example:
          "A free app that secretly installs a keylogger to record passwords",
      },
      {
        term: "Spyware",
        definition:
          "Malware that secretly monitors user activity and sends data to a third party",
        example:
          "Software tracking every website you visit and sending it to advertisers",
      },
      {
        term: "Ransomware",
        definition:
          "Malware that encrypts a victim's files and demands payment for the decryption key",
        example:
          "WannaCry attack in 2017 locked hospital computers and demanded Bitcoin",
      },
      {
        term: "Worm",
        definition:
          "Self-replicating malware that spreads automatically across networks without needing a host file or user action",
        example:
          "A worm exploits a vulnerability in connected computers and copies itself between them, slowing the network as it spreads",
      },
      {
        term: "Phishing",
        definition:
          "Fake communication (usually email) designed to trick users into revealing personal data",
        example:
          "An email pretending to be from a bank asking you to click a link and enter your login details",
      },
      {
        term: "Brute Force Attack",
        definition:
          "Trying every possible password combination systematically until the correct one is found",
        example:
          "Software cycling through millions of password combinations per second",
      },
      {
        term: "Denial of Service (DoS) Attack",
        definition:
          "Flooding a server with so many requests that it becomes overloaded and unavailable to legitimate users",
        example:
          "Overloading an online shop's server so real customers cannot access the website",
      },
      {
        term: "Structured Query Language (SQL) Injection",
        definition:
          "Inserting malicious SQL code into a website's input field to access or manipulate the database",
        example:
          "Typing ' OR 1=1 -- into a login form to bypass authentication",
      },
      {
        term: "Data Interception and Theft",
        definition:
          "Intercepting data as it is being transmitted across a network, often using packet sniffing tools or man-in-the-middle techniques",
        example:
          "An attacker on a public Wi-Fi network capturing unencrypted login credentials as they are sent between a laptop and a server",
      },
      {
        term: "Social Engineering",
        definition:
          "Manipulating people psychologically into giving up confidential information or access",
        example:
          "Phoning an IT helpdesk pretending to be a senior manager to get a password reset",
      },
      {
        term: "Penetration Testing",
        definition:
          "An authorised simulated attack carried out to identify security weaknesses before real attackers do",
        example:
          "An ethical hacker hired by a company to test whether their firewall can be breached",
      },
      {
        term: "Anti-Malware Software",
        definition:
          "Software that scans for, blocks and removes malicious programs such as viruses, trojans and spyware before they can damage the system",
        example:
          "Microsoft Defender or Norton scanning incoming downloads and quarantining infected files",
      },
      {
        term: "Passwords",
        definition:
          "A secret string of characters used to authenticate a user; strong passwords combine length, mixed case, digits and symbols to resist brute-force attacks",
        example:
          "Requiring at least 12 characters with mixed case, digits and symbols, and locking the account after three failed attempts",
      },
      {
        term: "Firewall",
        definition:
          "Software or hardware that monitors and filters incoming and outgoing network traffic based on security rules",
        example: "Blocking incoming connections from unrecognised IP addresses",
      },
      {
        term: "Encryption",
        definition:
          "Using an algorithm and key to turn readable data into ciphertext that needs the appropriate key to decrypt",
        example:
          "HTTPS encrypts transmitted data so an interceptor cannot understand it without the decryption key; encryption does not prevent interception",
      },
      {
        term: "User Access Levels",
        definition:
          "Rules that give each user only the access they need: which files, folders and software they can use, and whether they can read, edit or delete them",
        example:
          "A student account cannot install software, but an admin account can",
      },
      {
        term: "Physical Security",
        definition:
          "Measures that physically protect computer systems and data from unauthorised access, theft or damage",
        example:
          "Locked server rooms, security cameras, biometric door entry systems, cable locks on laptops",
      },
    ],
    1.5: [
      {
        term: "Operating System (OS)",
        definition:
          "System software that manages hardware resources and provides a platform for application software to run",
        example: "Microsoft Windows, Apple macOS, Linux, Google Android",
      },
      {
        term: "User Interface",
        definition:
          "The means by which the user interacts with the computer system",
        example:
          "Graphical User Interface (GUI) uses icons, windows and menus; Command Line Interface (CLI) uses typed text commands",
      },
      {
        term: "Memory Management",
        definition:
          "The OS allocates and frees RAM, manages transfers to and from memory, and keeps running programs separate to support multitasking",
        example:
          "The OS gives each application memory and can move inactive data to secondary storage when RAM is full",
      },
      {
        term: "Multitasking",
        definition:
          "The OS rapidly switches between running programs so they appear to run at the same time",
        example: "Listening to music on Spotify while typing an essay in Word",
      },
      {
        term: "Peripheral Management",
        definition:
          "An operating system function that controls communication with input, output and storage devices",
        example:
          "The OS manages sending data to a printer and receiving data from a scanner",
      },
      {
        term: "Drivers",
        definition:
          "Software that lets the operating system communicate with and control a specific hardware device",
        example:
          "Installing a printer driver so the OS knows how to send documents to print",
      },
      {
        term: "User Management",
        definition:
          "The OS controls user accounts, access levels and permissions",
        example:
          "An admin account has full access; a student account has restricted permissions",
      },
      {
        term: "File Management",
        definition:
          "The OS organises files into folders and directories and controls who can read, write or delete them",
        example:
          "Creating a folder called Homework, moving files into it, setting read-only permissions",
      },
      {
        term: "Defragmentation",
        definition:
          "A utility that reorganises fragmented files on a Hard Disk Drive (HDD) so they are stored in contiguous blocks",
        example:
          "Files accessed faster because the read/write head does not need to jump across the platter",
      },
      {
        term: "Compression Utility",
        definition:
          "Software that reduces the size of files for storage or transfer",
        example:
          "Zipping a folder of images before emailing it to reduce the attachment size",
      },
      {
        term: "Encryption Utility",
        definition:
          "Software that scrambles files or drives so they cannot be understood without the decryption key",
        example:
          "Encrypting a USB flash drive with BitLocker so its contents are protected if lost",
      },
      {
        term: "Utility Software",
        definition:
          "System software that maintains, protects or optimises a computer",
        example:
          "Encryption protects stored data; compression reduces file size; defragmentation speeds access to fragmented files on an HDD",
      },
    ],
    1.6: [
      {
        term: "Data Protection Act (DPA) 2018 / General Data Protection Regulation (GDPR)",
        definition:
          "United Kingdom (UK) law governing how personal data is collected, stored, used and shared; organisations must keep data secure",
        example:
          "A school must keep student records secure, only use them for educational purposes, and delete them when no longer needed",
      },
      {
        term: "Computer Misuse Act (CMA) 1990",
        definition:
          "UK law making it illegal to gain unauthorised access to computer systems, or to modify data without permission",
        example:
          "Hacking into someone's email account is a criminal offence, even if no data is stolen",
      },
      {
        term: "Copyright, Designs and Patents Act 1988",
        definition:
          "UK law protecting creators' intellectual property from being copied, distributed or modified without permission",
        example:
          "Illegally downloading music, films or software without paying the creator",
      },
      {
        term: "Open Source Software",
        definition:
          "Software supplied with source code and a licence allowing users to inspect, modify and redistribute it under the licence terms",
        example:
          "A school can adapt an open-source program to its needs, but needs the skills to maintain changes and must follow the licence conditions",
      },
      {
        term: "Proprietary Software",
        definition:
          "Software controlled by its owner; source code is normally unavailable and use or modification is restricted by its licence. It may be free or paid",
        example:
          "A school might choose a supported commercial package for vendor support, but cannot normally adapt its source code",
      },
      {
        term: "Software Licence",
        definition:
          "A legal agreement that defines how software can be installed, used, copied and distributed; protects the creator's intellectual property and sets the terms of use",
        example:
          "A school buying a site licence for Microsoft Office that permits installation on every staff computer for one year",
      },
      {
        term: "Digital Divide",
        definition:
          "The gap between people who can access and effectively use digital technology and those who cannot",
        example:
          "Moving homework online offers flexible access, but can disadvantage pupils without devices, connectivity or digital skills",
      },
      {
        term: "Privacy",
        definition:
          "Control over access to personal information and how it is collected, used and shared",
        example:
          "Facial recognition may help identify offenders, but also records innocent people; consider security benefits, privacy, consent and how data is protected",
      },
      {
        term: "Cyberbullying",
        definition:
          "Using digital technology to harass, threaten or humiliate someone",
        example: "Sending abusive messages through social media or group chats",
      },
      {
        term: "Environmental Impact of Technology",
        definition:
          "The effects of manufacturing, using and disposing of technology on the environment",
        example:
          "Replacing school tablets uses raw materials and creates e-waste; keeping usable devices longer reduces waste, while newer efficient devices may use less power",
      },
      {
        term: "Sustainability",
        definition:
          "Designing and using technology in ways that minimise environmental harm",
        example:
          "Using renewable energy to power data centres, recycling old devices",
      },
    ],
    2.1: [
      {
        term: "Computational Thinking",
        definition:
          "Analysing a problem so that it can be solved in a logical way, using abstraction, decomposition and algorithmic thinking",
        example:
          "Planning a quiz app before coding: ignore the colours, split it into questions and scoring, then write the steps for each part",
      },
      {
        term: "Abstraction",
        definition:
          "Removing unnecessary detail to focus on the important information needed to solve a problem",
        example:
          "A London Underground map removes real geography and shows only stations and connections",
      },
      {
        term: "Decomposition",
        definition:
          "Breaking a large, complex problem down into smaller, more manageable sub-problems",
        example:
          "Building a game: break it into input handling, scoring, graphics, and collision detection",
      },
      {
        term: "Algorithmic Thinking",
        definition:
          "Creating a step-by-step set of instructions (an algorithm) to solve a problem",
        example:
          "Writing out the steps for making a cup of tea in the exact order a computer would follow",
      },
      {
        term: "Pseudocode",
        definition:
          "A way of writing out an algorithm in structured English that resembles code but is not tied to any programming language",
        example: 'IF age >= 18 THEN OUTPUT "You can vote"',
      },
      {
        term: "Flowchart",
        definition:
          "A diagram using standard shapes to represent the steps and decisions in an algorithm",
        example:
          "Oval = start/stop, rectangle = process, diamond = decision, parallelogram = input/output",
      },
      {
        term: "Structure Diagram",
        definition:
          "A hierarchical diagram that shows how a problem has been decomposed into sub-problems",
        example:
          "A top box labelled Quiz Program with sub-boxes for Ask Questions, Check Answers, Display Score",
      },
      {
        term: "Trace Table",
        definition:
          "A table used to manually track the values of variables as an algorithm is executed step by step",
        example:
          "Tracking the value of count through each iteration of a loop to check the output is correct",
      },
      {
        term: "Identifying Errors",
        definition:
          "Using trace tables, dry runs or testing to find logical or syntactical mistakes in an algorithm",
        example:
          "Tracing a sorting algorithm and spotting that two values are swapped in the wrong order",
      },
      {
        term: "Inputs, Processes, Outputs",
        definition:
          "Inputs provide data, processing transforms it, and outputs communicate the result",
        example: `Python: age = int(input("Age: ")); print(age + 1) inputs an age, calculates next year's age and outputs it`,
      },
      {
        term: "Linear Search",
        definition:
          "A searching algorithm that checks each item in a list one by one from start to end until the target is found or the list ends",
        example:
          "Searching for Zain in an unsorted register by reading every name from the top",
      },
      {
        term: "Binary Search",
        definition:
          "A searching algorithm that repeatedly halves a sorted list by comparing the target to the middle item",
        example:
          "Searching for 42 in a sorted list: check middle, discard the half that cannot contain 42, repeat",
      },
      {
        term: "Bubble Sort",
        definition:
          "A sorting algorithm that repeatedly compares adjacent pairs and swaps them if they are in the wrong order; passes continue until no swaps are needed",
        example:
          "List [5, 3, 8, 1]: first pass compares 5-3 (swap), 5-8 (no swap), 8-1 (swap)",
      },
      {
        term: "Merge Sort",
        definition:
          "A sorting algorithm that splits the list in half repeatedly until each sub-list has one item, then merges them back together in order",
        example:
          "[6,3,8,1] splits into [6,3] and [8,1], then [6],[3],[8],[1], then merges: [3,6],[1,8], then [1,3,6,8]",
      },
      {
        term: "Insertion Sort",
        definition:
          "A sorting algorithm that takes one item at a time and inserts it into the correct position within the already-sorted portion of the list",
        example:
          "Like sorting a hand of playing cards: pick up each card and slide it into the right place",
      },
    ],
    2.2: [
      {
        term: "Variable",
        definition:
          "A named storage location in memory whose value can change while the program runs",
        example:
          "score = 0; the value of score can be updated as the game progresses",
      },
      {
        term: "Constant",
        definition:
          "A named storage location whose value is set once and does not change during the program",
        example: "VAT_RATE = 0.20; the rate stays the same throughout",
      },
      {
        term: "Local Variable",
        definition:
          "A variable defined within a subprogram whose scope is that subprogram",
        example:
          "A function's total is local; a local constant such as TAX_RATE is also restricted to that function. In Python, uppercase names indicate constants by convention",
      },
      {
        term: "Global Variable",
        definition:
          "A variable defined at program scope and accessible from subprograms, subject to the language's scope rules",
        example:
          "A global constant such as MAX_SCORE can be read by functions. In Python, assigning a global variable inside a function requires a global declaration",
      },
      {
        term: "Assignment",
        definition:
          "Storing a value in a variable or constant using the assignment operator",
        example: 'name = "Ada" assigns the string to the variable name',
      },
      {
        term: "Sequence",
        definition:
          "Instructions executed one after another in the order they are written",
        example: "Line 1 runs, then line 2, then line 3",
      },
      {
        term: "Selection (IF/ELSE/ELIF)",
        definition:
          "A decision point where the program chooses which path to follow based on a condition",
        example: 'IF temperature > 30 THEN OUTPUT "Hot" ELSE OUTPUT "Cold"',
      },
      {
        term: "Iteration (Loops)",
        definition:
          "Repeating a block of code either a set number of times or until a condition is met",
        example:
          'FOR i = 1 TO 10 (count-controlled) or WHILE answer != "quit" (condition-controlled)',
      },
      {
        term: "Count-Controlled Loop (FOR)",
        definition: "A loop that repeats a fixed number of times",
        example: "for i in range(5): runs exactly 5 times",
      },
      {
        term: "Condition-Controlled Loop (WHILE / DO UNTIL)",
        definition:
          "A loop controlled by a condition: WHILE checks before the body and may run zero times; DO UNTIL checks after the body and runs at least once",
        example:
          "OCR: do ... until valid == true repeats until valid. Python: while not valid: repeats while valid is false",
      },
      {
        term: "Arithmetic Operators",
        definition: "Symbols used to perform mathematical calculations",
        example:
          "OCR notation: +, -, *, /, MOD (remainder), DIV (quotient), ^ (power). Python uses %, // and ** for the last three",
      },
      {
        term: "Comparison Operators",
        definition:
          "Symbols used to compare two values, returning True or False",
        example:
          "== (equal to), != (not equal to), < (less than), > (greater than), <=, >=",
      },
      {
        term: "Boolean Operators",
        definition: "Logical operators used to combine or invert conditions",
        example:
          "AND (both must be true), OR (at least one must be true), NOT (reverses the condition)",
      },
      {
        term: "Integer",
        definition: "A whole number data type with no decimal point",
        example: "42, -7, 0",
      },
      {
        term: "Real (Float)",
        definition: "A number data type that includes a decimal point",
        example: "3.14, -0.5, 99.99",
      },
      {
        term: "Boolean",
        definition: "A data type with only two possible values: True or False",
        example: "gameOver = True",
      },
      {
        term: "Character",
        definition: "A single letter, digit or symbol",
        example: "'A', '7', '!'",
      },
      {
        term: "String",
        definition:
          "A sequence of characters, typically enclosed in quotation marks",
        example: '"Hello World", "OCR J277"',
      },
      {
        term: "Casting",
        definition: "Converting a value from one data type to another",
        example:
          'int("42") converts the string "42" into the integer 42; str(100) converts 100 into "100"',
      },
      {
        term: "String Manipulation",
        definition:
          "Operations performed on strings such as extracting, finding length, joining or converting case",
        example:
          '"hello".upper() returns "HELLO"; "hello"[0] returns "h"; len("hello") returns 5',
      },
      {
        term: "String Concatenation",
        definition: "Joining two or more strings together",
        example: '"Hello " + "World" produces "Hello World"',
      },
      {
        term: "String Slicing",
        definition:
          "Extracting a portion (substring) of a string by specifying a start and end position",
        example:
          '"Hello World"[0:5] returns "Hello"; "Hello World"[6:] returns "World"',
      },
      {
        term: "File Handling",
        definition:
          "Opening a file, reading or writing its contents, then closing it so data can persist between runs",
        example:
          'Python: f = open("scores.txt", "w"); f.write("42"); f.close(). To read: f = open("scores.txt", "r"); score = f.read(); f.close()',
      },
      {
        term: "Record",
        definition:
          "A data structure that groups together related fields of different data types under one name",
        example:
          "A student record containing: name (string), age (integer), enrolled (Boolean)",
      },
      {
        term: "One-Dimensional (1D) Array",
        definition:
          "A fixed-length collection of values of the same type accessed by one index; Python lists can be used as an equivalent but can change length",
        example:
          'Python: names = ["Ali", "Ben", "Cara"]; names[0] is "Ali". Valid indices are 0 to len(names) - 1',
      },
      {
        term: "Two-Dimensional (2D) Array",
        definition:
          "A table-like collection accessed by row and column indices; Python can represent it as a list of lists",
        example:
          "With zero-based indexing, grid[2][3] accesses the third row and fourth column; pass grid to a function as an argument to process its rows",
      },
      {
        term: "Structured Query Language (SQL)",
        definition:
          "A language used to search for and retrieve data from a database",
        example: "SELECT name FROM students WHERE grade = 9;",
      },
      {
        term: "SQL SELECT",
        definition:
          "Retrieves specific fields from a database table, with optional conditions",
        example: "SELECT name, score FROM results WHERE score > 50;",
      },
      {
        term: "SQL FROM",
        definition:
          "Specifies which database table the SELECT statement should retrieve data from",
        example:
          "SELECT name FROM students; pulls the name column from the students table",
      },
      {
        term: "SQL WHERE",
        definition:
          "Filters the rows returned by a SELECT statement so only rows that match a condition are included",
        example:
          "SELECT name FROM students WHERE year = 11; returns only Year 11 students",
      },
      {
        term: "Sub Program",
        definition:
          "A named block of code that performs a specific task, called from the main program to reduce repetition",
        example:
          "Using a sub program called calculateAverage() whenever you need to find a mean",
      },
      {
        term: "Function",
        definition:
          "A subprogram that returns a value to its caller and may receive parameters",
        example:
          "Python: def first(items): return items[0] accepts an array/list; def copy(items): return items[:] returns a new list",
      },
      {
        term: "Procedure",
        definition:
          "A subprogram that performs a task without returning a useful value; it may receive parameters",
        example:
          'Python: def printWelcome(): print("Welcome") needs no parameters; printWelcome() calls it. Python returns None implicitly',
      },
      {
        term: "Parameter",
        definition:
          "A variable in a sub program definition that receives a value (argument) when the sub program is called",
        example: "In def greet(name):, name is the parameter",
      },
      {
        term: "Passing Data to Sub Programs",
        definition:
          "Sending values (arguments) into a function or procedure so it can use them",
        example:
          'greet("Hamid") passes the string "Hamid" as the argument for the parameter name',
      },
      {
        term: "Returning Values",
        definition:
          "A function sends a result back to the code that called it using a return statement",
        example:
          "return total sends the value of total back to the main program",
      },
      {
        term: "Random Number Generation",
        definition:
          "Using a built-in library to produce a random number within a specified range",
        example:
          "import random then random.randint(1, 6) simulates rolling a dice",
      },
    ],
    2.3: [
      {
        term: "Defensive Design",
        definition:
          "Writing programs that anticipate and handle potential misuse or errors gracefully",
        example:
          "Checking that a user enters a number, not text, before performing a calculation",
      },
      {
        term: "Anticipating Misuse",
        definition:
          "A defensive design consideration where the programmer thinks ahead about how a program might be used incorrectly or maliciously and writes safeguards against it",
        example:
          "Designing a banking app to refuse negative withdrawal amounts and to lock the account after suspicious activity",
      },
      {
        term: "Input Validation",
        definition:
          "Checking that data entered by a user meets specific rules before the program accepts it",
        example:
          "Range check: age must be between 0 and 120. Presence check: field cannot be left empty. Type check: must be a number",
      },
      {
        term: "Authentication",
        definition:
          "Verifying a user's identity before allowing access to a program or its features",
        example:
          "Asking for a username and password at login; locking the account after 3 failed attempts",
      },
      {
        term: "Maintainability",
        definition:
          "Writing code that other programmers (or your future self) can easily read, understand and update",
        example:
          "Using meaningful variable names, adding comments, consistent indentation, modular sub programs",
      },
      {
        term: "Comments",
        definition:
          "Notes written in the source code that are ignored by the translator, used to explain what the code does",
        example: "# This loop checks each item in the list",
      },
      {
        term: "Indentation",
        definition:
          "Using consistent spacing to show the structure of code, especially inside loops, selections and sub programs",
        example: "All lines inside a for loop are indented by the same amount",
      },
      {
        term: "Naming Conventions",
        definition:
          "Using clear, descriptive names for variables, constants and sub programs so their purpose is obvious",
        example:
          "total_score is clearer than ts; calculateAverage() is clearer than ca()",
      },
      {
        term: "Iterative Testing",
        definition:
          "Testing individual parts of the program during development, fixing issues as they arise",
        example:
          "Testing the login module before building the rest of the program",
      },
      {
        term: "Final (Terminal) Testing",
        definition:
          "Testing the complete program at the end of development to check it meets all requirements",
        example:
          "Running the finished quiz program through every scenario to confirm it works as a whole",
      },
      {
        term: "Syntax Error",
        definition:
          "An error that breaks a programming language's grammatical rules and prevents the affected code from being parsed",
        example:
          'print("Hello" has a missing closing bracket; printt("Hello") misspells the keyword print',
      },
      {
        term: "Logic Error",
        definition:
          "The code runs without crashing but produces an incorrect or unexpected result",
        example:
          "Using > instead of >= so the boundary value is excluded when it should be included",
      },
      {
        term: "Normal Test Data",
        definition:
          "Valid data that the program should handle correctly under typical use",
        example:
          "Entering the age 25 when the program expects an age between 0 and 120",
      },
      {
        term: "Boundary Test Data",
        definition:
          "Valid data at the very edge of an accepted range, testing that limits are handled correctly",
        example:
          "Entering 0 and 120 for an age range of 0 to 120; both should be accepted",
      },
      {
        term: "Invalid Test Data",
        definition:
          "Data of the correct data type that should still be rejected because it is outside the accepted rules",
        example:
          "Entering -5 or 200 when the program expects an age between 0 and 120",
      },
      {
        term: "Erroneous Test Data",
        definition:
          "Data of the wrong data type that the program should reject before any processing takes place",
        example:
          'Entering "abc" or a date when the program expects an integer age',
      },
      {
        term: "Test Plan",
        definition:
          "A set of tests giving the input, expected outcome and space to record the actual outcome and any action needed",
        example:
          'For integer ages 0 to 120: 25 accepted (normal); 0 and 120 accepted (boundaries); -1 rejected (invalid); "abc" rejected (erroneous)',
      },
    ],
    2.4: [
      {
        term: "AND Gate",
        definition:
          "A logic gate that outputs 1 (True) only when both inputs are 1",
        example:
          "Input A = 1, Input B = 1, Output = 1. Any other combination gives 0",
      },
      {
        term: "OR Gate",
        definition:
          "A logic gate that outputs 1 (True) when at least one input is 1",
        example: "Input A = 0, Input B = 1, Output = 1. Only 0,0 gives 0",
      },
      {
        term: "NOT Gate",
        definition:
          "A logic gate that inverts the input: 1 becomes 0, and 0 becomes 1",
        example: "Input = 1, Output = 0. Input = 0, Output = 1",
      },
      {
        term: "Truth Table",
        definition:
          "A table showing every possible combination of inputs and the resulting output for a logic gate or circuit",
        example:
          "A 2-input AND gate has 4 rows: (0,0)=0, (0,1)=0, (1,0)=0, (1,1)=1",
      },
      {
        term: "Logic Diagram / Logic Circuit",
        definition:
          "A diagram using standard gate symbols to represent a Boolean expression visually",
        example:
          "Drawing an AND gate feeding into a NOT gate to represent NOT (A AND B)",
      },
      {
        term: "Combining Logic Gates",
        definition:
          "Connecting multiple gates together to create more complex Boolean expressions",
        example:
          "(A OR B) AND (NOT C): an OR gate and a NOT gate both feeding into an AND gate",
      },
    ],
    2.5: [
      {
        term: "High-Level Language",
        definition:
          "A language with human-readable constructs that must be translated for execution",
        example:
          "Python is easier to read and portable across systems with a suitable implementation; low-level languages offer closer hardware control",
      },
      {
        term: "Low-Level Language",
        definition:
          "A language closely tied to a processor's instructions and hardware",
        example:
          "Assembly can offer direct hardware control and efficient resource use, but is harder to develop and less portable than high-level code",
      },
      {
        term: "Machine Code",
        definition:
          "Binary instructions (0s and 1s) that the CPU can execute directly without translation",
        example:
          "10110000 01100001: the only language the processor actually understands",
      },
      {
        term: "Translator",
        definition:
          "Software that converts source code into machine code so the CPU can run it",
        example: "Compilers and interpreters are both types of translator",
      },
      {
        term: "Compiler",
        definition:
          "A translator that translates a whole program before execution, commonly producing an executable",
        example:
          "A compiled executable can run without the compiler and is often fast; after changing source code, it must be compiled again",
      },
      {
        term: "Interpreter",
        definition:
          "A translator that executes a program as it translates instructions, rather than first producing a standalone executable",
        example:
          "An interpreter supports quick testing and debugging, but translation is needed when running the source again and execution may be slower",
      },
      {
        term: "Integrated Development Environment (IDE)",
        definition:
          "A software application that provides a complete set of tools for writing, testing and debugging code in one place",
        example: "Visual Studio Code, PyCharm, IDLE, Thonny",
      },
      {
        term: "Code Editor",
        definition:
          "The IDE feature that provides a text area for writing code, often with syntax highlighting and auto-complete",
        example:
          "Keywords like def and for are colour-coded; bracket matching highlights pairs",
      },
      {
        term: "Error Diagnostics",
        definition:
          "IDE tools that identify and describe errors in the code, showing line numbers and error messages",
        example:
          "A red underline on line 12 with the message IndentationError: unexpected indent",
      },
      {
        term: "Run-Time Environment",
        definition:
          "The IDE feature that allows the programmer to execute their code and see the output within the same application",
        example:
          "Clicking Run in Thonny and seeing the output appear in the console below",
      },
      {
        term: "Debugging Tools",
        definition:
          "IDE features that help locate and fix errors, such as breakpoints, stepping through code, and variable watches",
        example:
          "Setting a breakpoint on line 20 so the program pauses there, then inspecting the current value of each variable",
      },
    ],
  },
  di = {
    1.1: "Systems architecture",
    1.2: "Memory and storage",
    1.3: "Networks and protocols",
    1.4: "Network security",
    1.5: "Systems software",
    1.6: "Ethical, legal and environmental impacts",
    2.1: "Algorithms",
    2.2: "Programming fundamentals",
    2.3: "Producing robust programs",
    2.4: "Boolean logic",
    2.5: "Languages and IDEs",
  },
  sh = 24,
  lh = 13,
  uh = 3,
  ch = 6,
  Kd = /\s*\(([^)]*)\)\s*/g;
function nd(i) {
  return i.toUpperCase().replace(/[^A-Z0-9]/g, "");
}
function dh(i) {
  const u = i.replace(Kd, " ").replace(/\s+/g, " ").trim();
  if (/[/,]/.test(u)) return null;
  const l = u
      .split(" ")
      .map((y) =>
        [...y].flatMap((S) =>
          /[A-Za-z0-9]/.test(S)
            ? [{ kind: "letter", char: S.toUpperCase() }]
            : S === "-"
              ? [{ kind: "fixed", char: S }]
              : [],
        ),
      ),
    d = l.map((y) => y.filter((S) => S.kind === "letter").length),
    p = d.reduce((y, S) => y + S, 0);
  return p < uh || p > sh || d.some((y) => y === 0 || y > lh)
    ? null
    : { shown: u, words: l };
}
const rd = (i) => i.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
function fh(i) {
  const u = i.match(/[A-Za-z0-9]+/g) ?? [],
    l = new Set(
      u.filter(
        (p) => (p.match(/[A-Z]/g) ?? []).length >= 2 || /^\d[A-Z]$/.test(p),
      ),
    ),
    d = new Set(
      u.filter((p) => p.length >= 4 && !l.has(p)).map((p) => p.toLowerCase()),
    );
  return [
    ...[...l].map((p) => new RegExp(`\\b${rd(p)}s?\\b`, "gi")),
    ...[...d].map((p) => new RegExp(`\\b${rd(p)}\\w*`, "gi")),
  ];
}
function od(i, u) {
  let l = u.trim().replace(/[.\s]+$/, "");
  for (const d of fh(i)) l = l.replace(d, "…");
  return l;
}
const ph = /\(([A-Za-z0-9-]{2,7})\)(.*)$/;
function mh(i) {
  const u = i.match(ph);
  return !u || (u[1].match(/[A-Z]/g) ?? []).length < 1
    ? []
    : [nd(u[1]) + nd(u[2].replace(Kd, " "))];
}
function hh(i) {
  const u = dh(i.term);
  if (!u) return null;
  const l = u.words
      .flat()
      .filter((p) => p.kind === "letter")
      .map((p) => p.char)
      .join(""),
    d = mh(i.term);
  return {
    id: `${i.deck}/${i.term}`,
    deck: i.deck,
    term: i.term,
    shown: u.shown,
    words: u.words,
    answer: l,
    accept: [...new Set(d)].filter((p) => p !== l && p.length > 0),
    definition: od(i.term, i.definition),
    example: i.example ? od(i.term, i.example) : null,
    meaning: i.definition.trim(),
  };
}
function gh(i) {
  const u = new Set();
  return i.flatMap((l) => {
    const d = hh(l);
    return !d || u.has(d.answer) ? [] : (u.add(d.answer), [d]);
  });
}
const ds = Object.entries(Jd).flatMap(([i, u]) =>
  gh(u.map((l) => ({ ...l, deck: i }))),
);
[
  ds.filter((i) => i.deck.startsWith("1.")),
  ds.filter((i) => i.deck.startsWith("2.")),
  ...Object.keys(di)
    .map((i) => ({
      id: i,
      title: `${i} ${di[i]}`,
      words: ds.filter((u) => u.deck === i),
    }))
    .filter((i) => i.words.length >= ch),
];
function yh(i) {
  let u = 2166136261;
  for (const l of i.id)
    ((u ^= l.charCodeAt(0)), (u = Math.imul(u, 16777619) >>> 0));
  return `w${u.toString(36)}`;
}
const vh = 3,
  wh = 13,
  Qd = /^(.*?)\s*\(([A-Z]{3,6})\)\s*$/;
function xh(i) {
  if (/^SQL\s/.test(i)) return null;
  const u = i.match(Qd);
  if (u) return { answer: u[2], enumeration: String(u[2].length) };
  if (/[()\d]/.test(i) || i.includes("-")) return null;
  const l = i.match(/[A-Za-z]+/g) ?? [],
    d = l.join("").toUpperCase();
  return d.length < vh || d.length > wh
    ? null
    : { answer: d, enumeration: l.map((p) => p.length).join(",") };
}
const fs = (i) => i.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"),
  kh = new Set(["the", "and", "for", "of", "to", "in", "on", "a", "an", "or"]);
function Gd(i, u) {
  const l = i.match(Qd),
    d = (l ? l[1] : i).match(/[A-Za-z]+/g) ?? [],
    p = d.filter((k) => /^[A-Z]{2,}$/.test(k)),
    y = l ? 4 : 3,
    S = new Set(
      d
        .filter(
          (k) => k.length >= y && !p.includes(k) && !kh.has(k.toLowerCase()),
        )
        .map((k) => k.toLowerCase().replace(new RegExp("(?<=\\w{3})s$"), "")),
    );
  let j = u.trim().replace(/[.\s]+$/, "");
  d.length > 1 &&
    (j = j.replace(
      new RegExp(`\\b${d.map(fs).join("[\\s-]+")}\\w*`, "gi"),
      "…",
    ));
  for (const k of [...(l ? [l[2]] : []), ...p])
    j = j.replace(new RegExp(`\\b${fs(k)}s?\\b`, "gi"), "…");
  for (const k of S) j = j.replace(new RegExp(`\\b${fs(k)}\\w*`, "gi"), "…");
  return j.replace(/…(?:[\s-]+…)+/g, "…");
}
function Sh(i, u, l) {
  return `${Gd(i, u)} (${l})`;
}
const ps = Object.entries(Jd).flatMap(([i, u]) => {
    const l = new Set();
    return u.flatMap((d) => {
      const p = xh(d.term);
      return !p || l.has(p.answer)
        ? []
        : (l.add(p.answer),
          [
            {
              id: `${i}/${p.answer}`,
              topic: i,
              term: d.term,
              ...p,
              clue: Sh(d.term, d.definition, p.enumeration),
              definition: d.definition.trim(),
              example: d.example?.trim() ? Gd(d.term, d.example) : null,
              ref: yh({ id: `${i}/${d.term}` }),
            },
          ]);
    });
  }),
  Ch = 8;
[
  ps.filter((i) => i.topic.startsWith("1.")),
  ps.filter((i) => i.topic.startsWith("2.")),
  ...Object.keys(di)
    .map((i) => ({
      id: i,
      title: `${i} ${di[i]}`,
      words: ps.filter((u) => u.topic === i),
    }))
    .filter((i) => i.words.length >= Ch),
];
const bh = 15e3;
function Zd(i) {
  return !!(i && i.live === !0);
}
function _h(i, u = {}) {
  const l = new URL("/api/lobby", i);
  for (const [S, j] of Object.entries(u)) l.searchParams.set(S, j);
  const d = l.toString(),
    p = (S, j) => {
      const k = new URL(d);
      return (k.searchParams.set(S, j), k.toString());
    };
  async function y(S, j = {}) {
    const k = { accept: "application/json" };
    j.body && (k["content-type"] = "application/json");
    try {
      const F = await fetch(S, {
          cache: "no-store",
          credentials: "include",
          ...j,
          headers: k,
        }),
        L = await F.json().catch(() => null);
      return !F.ok || !L?.ok
        ? {
            ok: !1,
            status: F.status,
            message: L?.message ?? "The lobby could not be reached.",
          }
        : { ok: !0, data: L.data ?? null };
    } catch {
      return { ok: !1, status: 0, message: "The lobby could not be reached." };
    }
  }
  return {
    overview: () => y(d),
    takeover: () => y(p("view", "takeover")),
    get: (S, j) => {
      const k = new URL(p("id", S));
      return (j && k.searchParams.set("version", String(j)), y(k.toString()));
    },
    send: (S) =>
      y(d, {
        method: "POST",
        body: JSON.stringify(S),
        keepalive: S.action === "leave",
      }),
    live: (S, j) => {
      const k = new URL(p("view", "live"));
      return (
        S && k.searchParams.set("classId", S),
        j && j !== "crossword" && k.searchParams.set("game", j),
        y(k.toString())
      );
    },
    liveStatus: (S, j) => {
      const k = new URL(p("view", "live-status"));
      return (
        S && k.searchParams.set("classId", S),
        j && j !== "crossword" && k.searchParams.set("game", j),
        y(k.toString())
      );
    },
    liveStart: (S, j, k) =>
      y(d, {
        method: "POST",
        body: JSON.stringify({
          action: "live-start",
          classId: S,
          set: j,
          ...(k ? { pupils: k } : {}),
        }),
      }),
    liveRecord: (S) =>
      y(d, {
        method: "POST",
        body: JSON.stringify({ action: "live-record", receipt: S }),
        keepalive: !0,
      }),
    liveBoard: () => y(p("view", "live-board")),
    liveEnd: (S) =>
      y(d, {
        method: "POST",
        body: JSON.stringify({ action: "live-end", classId: S }),
      }),
  };
}
const qd = "back",
  jh = "data-room-held";
function id() {
  return typeof document < "u" && document.documentElement.hasAttribute(jh);
}
const Eh = 1e4,
  Ah = "Your teacher has started a game. Saving your work...";
function Ph(i, u, l = window.location.hostname) {
  const d = new URL(Zr(l, "https://exams.comp.school"));
  return (
    (d.pathname = `${d.pathname.replace(/\/$/, "")}/games/lobby`),
    (d.search = ""),
    d.searchParams.set("id", i),
    u && d.searchParams.set(qd, u),
    d.toString()
  );
}
function Th(i, u = window.location) {
  return (
    /\/games\/lobby\/?$/.test(u.pathname) &&
    new URLSearchParams(u.search).get("id") === i
  );
}
function zh(i, u = window.location.hostname) {
  const l = new URL(Zr(u, "https://exams.comp.school"));
  return (
    (l.pathname = `${l.pathname.replace(/\/$/, "")}/games/crossword`),
    (l.search = ""),
    i && l.searchParams.set(qd, i),
    l.toString()
  );
}
function Mh(i = window.location) {
  return /\/games\/crossword\/?$/.test(i.pathname);
}
function ad(i, u = window.location) {
  return Zd(i) ? Mh(u) : Th(i.id, u);
}
function Lh(i, u) {
  return Zd(i) ? zh(u) : Ph(i.id, u);
}
function Rh(i) {
  return i?.role === "student" && i.aiAccess === !1;
}
function Oh(i) {
  return (
    i?.role === "student" && !Rh(i) && (i.courses ?? ["j277"]).includes("j277")
  );
}
const Nh = {
  position: "fixed",
  insetInline: "1rem",
  top: "1rem",
  zIndex: 2147483e3,
  maxWidth: "32rem",
  marginInline: "auto",
  padding: "1rem 1.25rem",
  borderRadius: "0.75rem",
  border: "2px solid #0f766e",
  background: "#ffffff",
  color: "#0f172a",
  boxShadow: "0 10px 30px rgba(15, 23, 42, 0.25)",
  fontSize: "1.125rem",
  fontWeight: 600,
  lineHeight: 1.4,
  textAlign: "center",
};
function Ih({ user: i }) {
  const u = Oh(i),
    [l, d] = R.useState(!1);
  return (
    R.useEffect(() => {
      if (!u) return;
      const p = _h(mn(window.location.hostname));
      let y = !1,
        S = !1,
        j = null;
      async function k() {
        if (!(S || y || j !== null || document.visibilityState === "hidden")) {
          S = !0;
          try {
            const O = await p.takeover();
            if (y || !O.ok || !O.data || ad(O.data) || id()) return;
            (d(!0), (j = window.setTimeout(() => void F(), Eh)));
          } finally {
            S = !1;
          }
        }
      }
      async function F() {
        await Ls();
        const O = await p.takeover();
        if (!y) {
          if (!O.ok || !O.data || ad(O.data) || id()) {
            ((j = null), d(!1));
            return;
          }
          window.location.assign(Lh(O.data, window.location.href));
        }
      }
      k();
      const L = window.setInterval(() => void k(), bh),
        D = () => void k();
      return (
        document.addEventListener("visibilitychange", D),
        () => {
          ((y = !0),
            window.clearInterval(L),
            j !== null && window.clearTimeout(j),
            document.removeEventListener("visibilitychange", D));
        }
      );
    }, [u]),
    !u || !l
      ? null
      : s.jsx("div", {
          role: "status",
          "aria-live": "assertive",
          style: Nh,
          "data-lobby-takeover-notice": !0,
          children: Ah,
        })
  );
}
const Dh = 5e3,
  sd = 1e4,
  ms = "Room control could not be reached.";
function Uh(i) {
  return typeof i == "object" && i !== null && typeof i.live == "boolean";
}
function $h(i, u = {}) {
  const l = (y = {}) => {
    const S = new URL("/api/room-control", i);
    for (const [j, k] of Object.entries({ ...u, ...y }))
      S.searchParams.set(j, k);
    return S.toString();
  };
  async function d(y, S) {
    const j = { accept: "application/json" };
    S !== void 0 && (j["content-type"] = "application/json");
    try {
      const k = await fetch(y, {
          cache: "no-store",
          credentials: "include",
          headers: j,
          ...(S === void 0 ? {} : { method: "POST", body: JSON.stringify(S) }),
        }),
        F = await k.json().catch(() => null);
      return !k.ok || !F?.ok
        ? {
            ok: !1,
            status: k.status,
            message: F?.message ?? ms,
            ...(F?.current ? { current: F.current } : {}),
          }
        : { ok: !0, data: F.data ?? null };
    } catch {
      return { ok: !1, status: 0, message: ms };
    }
  }
  async function p(y, S) {
    const j = await d(y, S);
    return j.ok
      ? Uh(j.data)
        ? { ok: !0, data: j.data }
        : { ok: !1, status: 0, message: ms }
      : j;
  }
  return {
    roster: (y) => d(l({ roster: y })),
    state: (y) => d(l({ class: y })),
    presence: (y) => d(l({ presence: y })),
    send: (y, S, j) => d(l(), { class: y, action: S, edits: j }),
    directive: () => p(l({ me: "1" })),
    complete: (y) => p(l(), { complete: y }),
    playlists: () => d(l({ playlists: "1" })),
    savePlaylist: (y) => d(l(), { playlist: y }),
    deletePlaylist: (y) => d(l(), { deletePlaylist: y }),
  };
}
const Js = "roomStep",
  Fh = "roomStepKind",
  Wh = "roomStepCount",
  ld = "comp-school:room-step-completed",
  Bh = {
    "matching-terms": {
      label: "Matching terms",
      cohorts: ["gcse", "ks3"],
      needsTopic: !0,
      completes: !0,
    },
    "guess-the-term": {
      label: "Guess the term",
      cohorts: ["gcse", "ks3"],
      needsTopic: !0,
      completes: !0,
    },
    flashcards: {
      label: "Flashcards",
      cohorts: ["gcse", "ks3"],
      needsTopic: !0,
      completes: !0,
    },
    "coding-challenge": {
      label: "Coding challenge",
      cohorts: ["gcse", "ks3"],
      needsTopic: !1,
      completes: !0,
    },
    "past-paper-questions": {
      label: "Past paper questions",
      cohorts: ["gcse"],
      needsTopic: !0,
      completes: !0,
    },
    "past-paper": {
      label: "Past paper",
      cohorts: ["gcse"],
      needsTopic: !1,
      completes: !0,
    },
    "tell-me-why": {
      label: "Tell me why",
      cohorts: ["gcse"],
      needsTopic: !0,
      completes: !0,
    },
    "live-game": {
      label: "Live class game",
      cohorts: ["gcse"],
      needsTopic: !1,
      completes: !1,
    },
    "topic-game": {
      label: "Topic game",
      cohorts: ["gcse", "ks3"],
      needsTopic: !0,
      completes: !0,
    },
    "crit-wall": {
      label: "Crit wall",
      cohorts: ["gcse"],
      needsTopic: !0,
      completes: !0,
    },
  },
  ud = "https://exams.comp.school",
  An = "https://recall.comp.school",
  Hh = "https://code.comp.school",
  Vh = "set",
  Jh = ["crossword", "code-climb"],
  cd = /^[12]\.\d$/,
  hs = /^[12]\.\d\.\d{1,2}$/,
  Kh = /^J277-0([12])-[A-Za-z0-9-]+$/,
  Qh = {
    io: "io",
    if: "if",
    for: "for",
    while: "while",
    fn: "functions",
    scratch: "scratch",
  },
  Gh = /^(io|if|for|while|fn|scratch)-[a-z0-9-]+$/;
function Zh(i) {
  return i.split(".").slice(0, 2).join(".");
}
function Pn(i, u, l) {
  const d = new URL(i);
  (d.searchParams.set("paper", u.charAt(0)),
    d.searchParams.set("topic", Zh(u)),
    d.searchParams.set("sub", u));
  for (const [p, y] of Object.entries(l)) d.searchParams.set(p, y);
  return d;
}
function qh(i) {
  return `topic-${i.replace(/\./g, "-")}`;
}
function Yh(i) {
  const u = i.topic ?? "",
    l = cd.test(u) || hs.test(u);
  switch (i.kind) {
    case "matching-terms":
      return l ? Pn(`${An}/`, u, { activity: "matching" }) : null;
    case "guess-the-term":
      return l ? Pn(`${An}/`, u, { activity: "guess" }) : null;
    case "crit-wall":
      return l ? Pn(`${An}/`, u, { activity: "crit-wall" }) : null;
    case "flashcards":
      return l ? Pn(`${An}/`, u, { activity: "flashcards" }) : null;
    case "tell-me-why":
      return l ? Pn(`${An}/`, u, { activity: "tell-me-why" }) : null;
    case "topic-game":
      return hs.test(u) && i.target
        ? Pn(`${An}/`, u, { activity: "game", game: i.target })
        : null;
    case "past-paper-questions":
      return hs.test(u)
        ? Pn(`${An}/`, u, {
            target: qh(u),
            revision: "0",
            ...(i.count && i.count > 0 ? { [Wh]: String(i.count) } : {}),
          })
        : null;
    case "past-paper": {
      const d = i.target?.match(Kh)?.[1];
      if (!d || !i.target) return null;
      const p = new URL(`${ud}/`);
      return (
        p.searchParams.set("paper", d),
        p.searchParams.set("target", i.target),
        p
      );
    }
    case "coding-challenge": {
      const d = i.target?.match(Gh)?.[1],
        p = d ? Qh[d] : void 0;
      if (!p || !i.target) return null;
      const y = new URL(`${Hh}/essentials/${p}`);
      return (y.searchParams.set("challenge", i.target), y);
    }
    case "live-game": {
      if (!Jh.includes(i.target ?? "")) return null;
      const d = new URL(`${ud}/games/${i.target}`);
      return (
        i.target === "crossword" && cd.test(u) && d.searchParams.set(Vh, u),
        d
      );
    }
  }
}
function Yd(i, u) {
  const l = Yh(i);
  if (!l) return u;
  (l.searchParams.set(Js, i.id), l.searchParams.set(Fh, i.kind));
  let d;
  try {
    d = new URL(u).hostname;
  } catch {
    return u;
  }
  return Zr(d, l.toString());
}
const Xh = "Your teacher is moving you. Saving your work...",
  eg = "You have finished. Retake a step or choose something else.",
  tg = "Next step...",
  ng = 6e4,
  vt = "data-room-held",
  gs = "comp-school-room-control:finished-seen";
function rg(i) {
  return i?.role === "student" && (i.courses ?? ["j277"]).includes("j277");
}
function Tn(i) {
  return !!(i && i.live && !i.free);
}
function og(i) {
  return `Step ${i.index + 1} of ${i.total}`;
}
function ig(i) {
  const u = Bh[i.kind]?.label ?? "Activity";
  return i.topic ? `${u} ${i.topic}` : u;
}
function ys(i, u, l = Yd) {
  const d = new URL(l(i, u));
  return (d.searchParams.set(Js, i.id), d.toString());
}
function vs(i, u, l, d = null) {
  const p = new URL(l);
  return p.origin !== new URL(u).origin
    ? !1
    : p.searchParams.get(Js) === i.id
      ? !0
      : d?.stepId === i.id && d.pathname === p.pathname;
}
const ag = `
html[${vt}] [data-session-sidebar],
html[${vt}] [data-session-sidebar-toggle],
html[${vt}] [data-session-sidebar-rail-toggle],
html[${vt}] [data-session-sidebar-search],
html[${vt}] [data-session-sidebar-search-open],
html[${vt}] [data-topic-breadcrumb],
html[${vt}] nav[aria-label="Breadcrumb"],
html[${vt}] [data-phone-bar-back],
html[${vt}] [data-launcher-phone-bar] { display: none !important; }
html[${vt}] [data-session-sidebar-layout] { padding-left: 0 !important; }
`,
  sg = {
    display: "flex",
    flexWrap: "wrap",
    alignItems: "baseline",
    justifyContent: "center",
    gap: "0.25rem 0.75rem",
    padding: "0.5rem 1rem",
    background: "#0f172a",
    color: "#f8fafc",
    fontSize: "1rem",
    lineHeight: 1.4,
    textAlign: "center",
  },
  Rs = {
    position: "fixed",
    insetInline: "1rem",
    top: "1rem",
    zIndex: 2147483e3,
    maxWidth: "32rem",
    marginInline: "auto",
    padding: "1rem 1.25rem",
    borderRadius: "0.75rem",
    border: "2px solid #0f766e",
    background: "#ffffff",
    color: "#0f172a",
    boxShadow: "0 10px 30px rgba(15, 23, 42, 0.25)",
    fontSize: "1.125rem",
    fontWeight: 600,
    lineHeight: 1.4,
    textAlign: "center",
  },
  lg = {
    ...Rs,
    cursor: "pointer",
    font: "inherit",
    fontSize: "1.125rem",
    fontWeight: 600,
  };
function ug(i) {
  try {
    return window.localStorage.getItem(i) === "1";
  } catch {
    return !1;
  }
}
function dd(i, u) {
  try {
    u ? window.localStorage.setItem(i, "1") : window.localStorage.removeItem(i);
  } catch {}
}
function cg({ user: i, transport: u, navigate: l, stepUrl: d = Yd }) {
  const p = rg(i),
    [y, S] = R.useState(null),
    [j, k] = R.useState(!1),
    [F, L] = R.useState(!1),
    [D, O] = R.useState(!1),
    K = R.useRef(u),
    Q = R.useRef(l);
  ((K.current = u), (Q.current = l));
  const M = R.useRef(d);
  ((M.current = d),
    R.useEffect(() => {
      if (!p) return;
      const V = mn(window.location.hostname),
        ie = K.current ?? $h(V),
        J = (_) => (Q.current ? Q.current(_) : window.location.assign(_));
      let ee = !1,
        ge = !1,
        fe = null,
        re = !1,
        ce = null,
        ke = !1,
        ve = 0,
        ne = null;
      function Ce(_) {
        ((ce = _),
          S(_),
          _.live && _.free && _.finished
            ? ug(gs) || (dd(gs, !0), L(!0))
            : (dd(gs, !1), L(!1)));
      }
      function pe() {
        (fe !== null && window.clearTimeout(fe), (fe = null), k(!1));
      }
      async function Se() {
        if (!(ge || ee || re || document.visibilityState === "hidden")) {
          ge = !0;
          try {
            const _ = await ie.directive();
            if (ee) return;
            if (!_.ok) {
              Date.now() - ve >= ng && (pe(), Ce({ live: !1 }));
              return;
            }
            ve = Date.now();
            const h = ce,
              C = !ke;
            ke = !0;
            const G = _.data;
            if ((Ce(G), !Tn(G))) {
              pe();
              return;
            }
            const te = ys(G.step, V, M.current);
            if (vs(G.step, te, window.location.href, ne)) {
              (ne?.stepId !== G.step.id &&
                (ne = {
                  stepId: G.step.id,
                  pathname: window.location.pathname,
                }),
                pe());
              return;
            }
            if (fe !== null) return;
            if (!(!C && !(Tn(h) && h.step.id === G.step.id))) {
              Ne();
              return;
            }
            (k(!0), (fe = window.setTimeout(() => void Ne(), sd)));
          } finally {
            ge = !1;
          }
        }
      }
      async function Ne() {
        ((re = !0), await Ls());
        const _ = await ie.directive();
        if (ee) return;
        const h = _.ok ? _.data : ce;
        _.ok && ((ve = Date.now()), Ce(_.data));
        const C = Tn(h) ? ys(h.step, V, M.current) : null;
        if (!Tn(h) || !C || vs(h.step, C, window.location.href, ne)) {
          ((re = !1), (fe = null), k(!1));
          return;
        }
        J(C);
      }
      async function Ae(_) {
        const h = _.detail;
        if (
          ee ||
          re ||
          !h ||
          typeof h != "object" ||
          typeof h.live != "boolean" ||
          ((ve = Date.now()), (ke = !0), pe(), Ce(h), !Tn(h))
        )
          return;
        const C = ys(h.step, V, M.current);
        if (vs(h.step, C, window.location.href, ne)) {
          ne?.stepId !== h.step.id &&
            (ne = { stepId: h.step.id, pathname: window.location.pathname });
          return;
        }
        ((re = !0), O(!0), await Ls(), !ee && J(C));
      }
      const he = (_) => void Ae(_);
      (window.addEventListener(ld, he), Se());
      const N = window.setInterval(() => void Se(), Dh),
        E = () => void Se();
      return (
        document.addEventListener("visibilitychange", E),
        window.addEventListener("popstate", E),
        () => {
          ((ee = !0),
            window.clearInterval(N),
            fe !== null && window.clearTimeout(fe),
            document.removeEventListener("visibilitychange", E),
            window.removeEventListener("popstate", E),
            window.removeEventListener(ld, he));
        }
      );
    }, [p]));
  const B = p && Tn(y);
  return (
    R.useEffect(() => {
      if (B)
        return (
          document.documentElement.setAttribute(vt, ""),
          () => document.documentElement.removeAttribute(vt)
        );
    }, [B]),
    R.useEffect(() => {
      if (!F) return;
      const V = window.setTimeout(() => L(!1), sd);
      return () => window.clearTimeout(V);
    }, [F]),
    p
      ? s.jsxs(s.Fragment, {
          children: [
            B && Tn(y)
              ? s.jsxs(s.Fragment, {
                  children: [
                    s.jsx("style", { children: ag }),
                    s.jsxs("div", {
                      style: sg,
                      "data-room-step-bar": "",
                      children: [
                        s.jsx("strong", { children: og(y) }),
                        s.jsx("span", { children: ig(y.step) }),
                      ],
                    }),
                  ],
                })
              : null,
            j
              ? s.jsx("div", {
                  role: "status",
                  "aria-live": "assertive",
                  style: Rs,
                  "data-room-move-notice": "",
                  children: Xh,
                })
              : null,
            D && !j
              ? s.jsx("div", {
                  role: "status",
                  "aria-live": "polite",
                  style: Rs,
                  "data-room-next-step": "",
                  children: tg,
                })
              : null,
            F && !j && !D
              ? s.jsx("button", {
                  type: "button",
                  role: "status",
                  "aria-live": "polite",
                  style: lg,
                  onClick: () => L(!1),
                  "data-room-finished-notice": "",
                  children: eg,
                })
              : null,
          ],
        })
      : null
  );
}
const Os = "cs_reduce_motion",
  Ns = "data-reduce-motion",
  dg = 3600 * 24 * 365;
function fg(i) {
  return i === "comp.school" || i.endsWith(".comp.school")
    ? "; Domain=.comp.school"
    : "";
}
function pg(i = typeof document > "u" ? "" : document.cookie) {
  return i.split(";").some((u) => u.trim() === `${Os}=1`);
}
function mg(i, u) {
  const l = fg(u);
  return i
    ? `${Os}=1; Path=/; Max-Age=${dg}; SameSite=Lax${l}`
    : `${Os}=; Path=/; Max-Age=0; SameSite=Lax${l}`;
}
function Xd(i) {
  typeof document > "u" ||
    (i
      ? document.documentElement.setAttribute(Ns, "true")
      : document.documentElement.removeAttribute(Ns));
}
function hg(i) {
  typeof document > "u" ||
    ((document.cookie = mg(i, window.location.hostname)), Xd(i));
}
function gg() {
  return (
    typeof document < "u" &&
    document.documentElement.getAttribute(Ns) === "true"
  );
}
Xd(pg());
const ef = "Accessibility";
function tf() {
  return s.jsxs("svg", {
    "aria-hidden": "true",
    fill: "none",
    height: "16",
    stroke: "currentColor",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    strokeWidth: "1.8",
    viewBox: "0 0 24 24",
    width: "16",
    children: [
      s.jsx("circle", { cx: "12", cy: "5", r: "1" }),
      s.jsx("path", { d: "m9 20 3-6 3 6M6 8l6 2 6-2M12 10v4" }),
    ],
  });
}
function yg({ style: i, tone: u = "light" }) {
  const [l, d] = R.useState(gg),
    p = u === "dark",
    y = p ? "rgb(var(--slate-200, 226 232 240))" : "#334155",
    S = l
      ? p
        ? "rgb(var(--slate-50, 248 250 252))"
        : "#0f172a"
      : p
        ? "rgb(var(--slate-600, 71 85 105))"
        : "#cbd5e1",
    j = l && p ? "rgb(var(--slate-900, 15 23 42))" : "#ffffff";
  return s.jsxs("button", {
    "aria-checked": l,
    "data-profile-reduce-motion": !0,
    onClick: () => {
      (hg(!l), d(!l));
    },
    role: "switch",
    style: {
      alignItems: "center",
      background: "transparent",
      border: 0,
      borderRadius: "0.5rem",
      color: y,
      cursor: "pointer",
      display: "flex",
      fontFamily: "inherit",
      fontSize: "0.875rem",
      fontWeight: 650,
      gap: "0.5rem",
      minHeight: "2.25rem",
      padding: "0.5rem",
      textAlign: "left",
      width: "100%",
      ...i,
    },
    type: "button",
    children: [
      s.jsxs("svg", {
        "aria-hidden": "true",
        fill: "none",
        height: "16",
        viewBox: "0 0 24 24",
        width: "16",
        children: [
          s.jsx("path", {
            d: "M3 12h4M17 12h4M12 3v4M12 17v4",
            stroke: "currentColor",
            strokeLinecap: "round",
            strokeWidth: "1.8",
          }),
          s.jsx("circle", {
            cx: "12",
            cy: "12",
            r: "3",
            stroke: "currentColor",
            strokeWidth: "1.8",
          }),
        ],
      }),
      s.jsx("span", { style: { flex: 1 }, children: "Reduce motion" }),
      s.jsx("span", {
        "aria-hidden": "true",
        style: {
          background: S,
          borderRadius: "9999px",
          display: "inline-flex",
          height: "1.125rem",
          padding: "0.125rem",
          transition: "background 120ms",
          width: "2rem",
        },
        children: s.jsx("span", {
          style: {
            background: j,
            borderRadius: "9999px",
            height: "0.875rem",
            transform: l ? "translateX(0.875rem)" : void 0,
            transition: "transform 120ms",
            width: "0.875rem",
          },
        }),
      }),
    ],
  });
}
function vg({ dialogRef: i, tone: u = "dark" }) {
  const l = R.useId(),
    d = u === "dark",
    p = d ? "rgb(var(--slate-50, 248 250 252))" : "#0f172a",
    y = d ? "rgb(var(--slate-700, 51 65 85))" : "#e2e8f0",
    S = d ? "rgb(var(--slate-900, 15 23 42))" : "#ffffff",
    j = d ? "rgb(var(--slate-800, 30 41 59))" : "#f1f5f9";
  return s.jsxs("dialog", {
    "aria-labelledby": l,
    "data-comp-school-accessibility-dialog": !0,
    onClick: (k) => {
      k.target === k.currentTarget && k.currentTarget.close();
    },
    ref: i,
    style: {
      background: S,
      border: `1px solid ${y}`,
      borderRadius: "1rem",
      boxShadow: "0 25px 50px -12px rgb(var(--slate-950, 2 6 23) / 0.5)",
      color: p,
      fontFamily: "inherit",
      margin: "auto",
      maxWidth: "min(92vw, 24rem)",
      padding: 0,
      textAlign: "left",
      width: "100%",
    },
    children: [
      s.jsx("style", {
        children:
          "[data-comp-school-accessibility-dialog]::backdrop{background:rgb(var(--slate-950, 2 6 23) / 0.7)}",
      }),
      s.jsxs("div", {
        style: {
          display: "flex",
          flexDirection: "column",
          gap: "0.875rem",
          padding: "1.25rem",
        },
        children: [
          s.jsxs("h2", {
            id: l,
            style: {
              alignItems: "center",
              display: "flex",
              fontSize: "1.125rem",
              fontWeight: 800,
              gap: "0.5rem",
              margin: 0,
            },
            children: [s.jsx(tf, {}), ef],
          }),
          s.jsx(yg, {
            style: {
              background: j,
              borderRadius: "0.625rem",
              minHeight: "2.75rem",
              padding: "0.625rem 0.75rem",
            },
            tone: u,
          }),
          s.jsx("form", {
            method: "dialog",
            style: { display: "flex", justifyContent: "flex-end", margin: 0 },
            children: s.jsx("button", {
              style: {
                background: d
                  ? "rgb(var(--slate-200, 226 232 240))"
                  : "#0f172a",
                border: 0,
                borderRadius: "0.625rem",
                color: d ? "rgb(var(--slate-900, 15 23 42))" : "#ffffff",
                cursor: "pointer",
                fontFamily: "inherit",
                fontSize: "0.875rem",
                fontWeight: 700,
                minHeight: "2.5rem",
                padding: "0.5rem 1rem",
              },
              type: "submit",
              children: "Close",
            }),
          }),
        ],
      }),
    ],
  });
}
const wg = "Send feedback",
  xg = "https://forms.cloud.microsoft/e/LdA5fPwYt1",
  fd = 64,
  pd = { x: 9, y: 12, width: 46, height: 44, rx: 13 },
  se = "#1f2937",
  $e = "#ffffff",
  Le = 33,
  Ht = 24,
  Vt = 40,
  md = new Set(["shell"]);
function pi(i) {
  return i.detail || i.shade;
}
function kg(i) {
  const { shade: u, accent: l } = i,
    d = pi(i);
  switch (i.ears) {
    case "pointed":
      return s.jsxs("g", {
        children: [
          s.jsx("path", { d: "M11 26 17 3 30 17Z", fill: u }),
          s.jsx("path", { d: "M53 26 47 3 34 17Z", fill: u }),
          s.jsx("path", { d: "M16.5 22 19 9.5 26 17Z", fill: l }),
          s.jsx("path", { d: "M47.5 22 45 9.5 38 17Z", fill: l }),
        ],
      });
    case "round":
      return s.jsxs("g", {
        children: [
          s.jsx("circle", { cx: "17", cy: "14", r: "8.5", fill: u }),
          s.jsx("circle", { cx: "47", cy: "14", r: "8.5", fill: u }),
          s.jsx("circle", { cx: "17", cy: "14", r: "4", fill: l }),
          s.jsx("circle", { cx: "47", cy: "14", r: "4", fill: l }),
        ],
      });
    case "tall":
      return s.jsxs("g", {
        children: [
          s.jsxs("g", {
            transform: "rotate(-9 20.5 9)",
            children: [
              s.jsx("rect", {
                x: "15",
                y: "-5",
                width: "11",
                height: "27",
                rx: "5.5",
                fill: u,
              }),
              s.jsx("rect", {
                x: "18",
                y: "0",
                width: "5",
                height: "18",
                rx: "2.5",
                fill: l,
              }),
            ],
          }),
          s.jsxs("g", {
            transform: "rotate(9 43.5 9)",
            children: [
              s.jsx("rect", {
                x: "38",
                y: "-5",
                width: "11",
                height: "27",
                rx: "5.5",
                fill: u,
              }),
              s.jsx("rect", {
                x: "41",
                y: "0",
                width: "5",
                height: "18",
                rx: "2.5",
                fill: l,
              }),
            ],
          }),
        ],
      });
    case "floppy":
      return s.jsxs("g", {
        fill: u,
        children: [
          s.jsx("path", { d: "M15 16C5 18 3 34 9 41c5 4 9-2 9-11Z" }),
          s.jsx("path", { d: "M49 16c10 2 12 18 6 25-5 4-9-2-9-11Z" }),
        ],
      });
    case "tuft":
      return s.jsxs("g", {
        fill: u,
        children: [
          s.jsx("path", { d: "M12 19 15.5 5 24 15.5Z" }),
          s.jsx("path", { d: "M52 19 48.5 5 40 15.5Z" }),
        ],
      });
    case "horns":
      return s.jsxs("g", {
        fill: d,
        children: [
          s.jsx("path", {
            d: "M17.5 13C10 11 6 5 10.5 1.5c2.5 3.5 6.5 6.5 10.5 8.5Z",
          }),
          s.jsx("path", {
            d: "M46.5 13C54 11 58 5 53.5 1.5c-2.5 3.5-6.5 6.5-10.5 8.5Z",
          }),
        ],
      });
    case "antlers":
      return s.jsxs("g", {
        stroke: d,
        strokeWidth: "3",
        strokeLinecap: "round",
        fill: "none",
        children: [
          s.jsx("path", { d: "M21 14 16 3" }),
          s.jsx("path", { d: "M17.6 8 10 5" }),
          s.jsx("path", { d: "M43 14 48 3" }),
          s.jsx("path", { d: "M46.4 8 54 5" }),
        ],
      });
    case "flap":
      return s.jsxs("g", {
        children: [
          s.jsx("ellipse", { cx: "10", cy: "32", rx: "10", ry: "15", fill: u }),
          s.jsx("ellipse", { cx: "54", cy: "32", rx: "10", ry: "15", fill: u }),
          s.jsx("ellipse", { cx: "11", cy: "32", rx: "5", ry: "9", fill: l }),
          s.jsx("ellipse", { cx: "53", cy: "32", rx: "5", ry: "9", fill: l }),
        ],
      });
    case "spikes":
      return s.jsx("path", {
        d: "M8 22 13 3 20 18 26 1 32 17 38 1 44 18 51 3 56 22Z",
        fill: u,
      });
    case "crest":
      return s.jsxs("g", {
        fill: d,
        children: [
          s.jsx("circle", { cx: "25", cy: "10", r: "5" }),
          s.jsx("circle", { cx: "32", cy: "5.5", r: "5.5" }),
          s.jsx("circle", { cx: "39", cy: "10", r: "5" }),
        ],
      });
    case "fins":
      return s.jsxs("g", {
        fill: u,
        children: [
          s.jsx("path", { d: "M12 26 1 19 4 37Z" }),
          s.jsx("path", { d: "M52 26 63 19 60 37Z" }),
          s.jsx("path", { d: "M25 13 32 1 39 13Z" }),
        ],
      });
    case "antennae":
      return s.jsxs("g", {
        children: [
          s.jsxs("g", {
            stroke: u,
            strokeWidth: "2.6",
            strokeLinecap: "round",
            fill: "none",
            children: [
              s.jsx("path", { d: "M23 14C20 7 17 4 13.5 3" }),
              s.jsx("path", { d: "M41 14c3-7 6-10 9.5-11" }),
            ],
          }),
          s.jsx("circle", { cx: "12.5", cy: "3", r: "3", fill: u }),
          s.jsx("circle", { cx: "51.5", cy: "3", r: "3", fill: u }),
        ],
      });
    case "mane":
      return s.jsx("g", {
        fill: d,
        children: Array.from({ length: 12 }, (p, y) => {
          const S = (y / 12) * Math.PI * 2;
          return s.jsx(
            "circle",
            { cx: 32 + Math.cos(S) * 25, cy: 34 + Math.sin(S) * 23, r: "8.5" },
            y,
          );
        }),
      });
    case "wool":
      return s.jsxs("g", {
        fill: l,
        children: [
          s.jsx("circle", { cx: "15", cy: "17", r: "8" }),
          s.jsx("circle", { cx: "26", cy: "10", r: "9" }),
          s.jsx("circle", { cx: "38", cy: "10", r: "9" }),
          s.jsx("circle", { cx: "49", cy: "17", r: "8" }),
        ],
      });
    case "wings":
      return s.jsxs("g", {
        fill: d,
        children: [
          s.jsx("path", { d: "M13 22C-1 16 0 42 12 46Z" }),
          s.jsx("path", { d: "M51 22c14-6 13 20 1 24Z" }),
        ],
      });
    case "tentacles":
      return s.jsxs("g", {
        fill: u,
        children: [
          s.jsx("path", { d: "M12 44c-6 4-8 12-6 18 4 1 7-5 9-11Z" }),
          s.jsx("path", { d: "M52 44c6 4 8 12 6 18-4 1-7-5-9-11Z" }),
          s.jsx("path", { d: "M25 50c-3 6-3 12-1 14 3 0 5-6 5-12Z" }),
          s.jsx("path", { d: "M39 50c3 6 3 12 1 14-3 0-5-6-5-12Z" }),
        ],
      });
    case "dome":
      return s.jsx("path", { d: "M11 22a21 21 0 0 1 42 0Z", fill: u });
    case "frill":
      return s.jsxs("g", {
        children: [
          s.jsx("path", { d: "M1 42C1 16 14 1 32 1s31 15 31 41Z", fill: u }),
          s.jsx("g", {
            fill: l,
            children: Array.from({ length: 9 }, (p, y) => {
              const S = Math.PI + (y + 0.5) * (Math.PI / 9);
              return s.jsx(
                "circle",
                {
                  cx: 32 + Math.cos(S) * 27,
                  cy: 40 + Math.sin(S) * 33,
                  r: "3.2",
                },
                y,
              );
            }),
          }),
        ],
      });
    case "rays":
      return s.jsx("g", {
        fill: d,
        children: Array.from({ length: 12 }, (p, y) => {
          const S = (y / 12) * 360;
          return s.jsx(
            "path",
            { d: "M32 2 27 12h10Z", transform: `rotate(${S} 32 34)` },
            y,
          );
        }),
      });
    case "points":
      return s.jsxs("g", {
        fill: u,
        children: [
          s.jsx("path", { d: "M32 0 24 16h16Z" }),
          s.jsx("path", { d: "M6 14 12 30l12-9Z" }),
          s.jsx("path", { d: "M58 14 52 30l-12-9Z" }),
          s.jsx("path", { d: "M8 56 4 42l14 4Z" }),
          s.jsx("path", { d: "M56 56l4-14-14 4Z" }),
        ],
      });
    case "none":
    default:
      return null;
  }
}
function Sg(i) {
  const { base: u, shade: l } = i,
    d = pi(i);
  switch (i.eyes) {
    case "round":
      return s.jsxs("g", {
        children: [
          s.jsx("circle", { cx: Ht, cy: Le, r: "6.5", fill: $e }),
          s.jsx("circle", { cx: Vt, cy: Le, r: "6.5", fill: $e }),
          s.jsx("circle", { cx: Ht, cy: Le, r: "3.4", fill: se }),
          s.jsx("circle", { cx: Vt, cy: Le, r: "3.4", fill: se }),
          s.jsx("circle", { cx: Ht + 1.4, cy: Le - 1.6, r: "1.3", fill: $e }),
          s.jsx("circle", { cx: Vt + 1.4, cy: Le - 1.6, r: "1.3", fill: $e }),
        ],
      });
    case "big":
      return s.jsxs("g", {
        children: [
          s.jsx("circle", { cx: "23", cy: "32", r: "9.5", fill: $e }),
          s.jsx("circle", { cx: "41", cy: "32", r: "9.5", fill: $e }),
          s.jsx("circle", { cx: "23", cy: "32", r: "5", fill: se }),
          s.jsx("circle", { cx: "41", cy: "32", r: "5", fill: se }),
          s.jsx("circle", { cx: "24.6", cy: "30.2", r: "1.9", fill: $e }),
          s.jsx("circle", { cx: "42.6", cy: "30.2", r: "1.9", fill: $e }),
        ],
      });
    case "bulge":
      return s.jsxs("g", {
        children: [
          s.jsx("circle", {
            cx: "20",
            cy: "14",
            r: "9",
            fill: u,
            stroke: l,
            strokeWidth: "1.6",
          }),
          s.jsx("circle", {
            cx: "44",
            cy: "14",
            r: "9",
            fill: u,
            stroke: l,
            strokeWidth: "1.6",
          }),
          s.jsx("circle", { cx: "20", cy: "13.5", r: "4.8", fill: $e }),
          s.jsx("circle", { cx: "44", cy: "13.5", r: "4.8", fill: $e }),
          s.jsx("circle", { cx: "20", cy: "13.5", r: "2.6", fill: se }),
          s.jsx("circle", { cx: "44", cy: "13.5", r: "2.6", fill: se }),
        ],
      });
    case "slit":
      return s.jsxs("g", {
        children: [
          s.jsx("ellipse", { cx: Ht, cy: Le, rx: "5.4", ry: "6", fill: d }),
          s.jsx("ellipse", { cx: Vt, cy: Le, rx: "5.4", ry: "6", fill: d }),
          s.jsx("ellipse", { cx: Ht, cy: Le, rx: "1.8", ry: "5", fill: se }),
          s.jsx("ellipse", { cx: Vt, cy: Le, rx: "1.8", ry: "5", fill: se }),
        ],
      });
    case "sleepy":
      return s.jsxs("g", {
        stroke: se,
        strokeWidth: "3",
        strokeLinecap: "round",
        fill: "none",
        children: [
          s.jsx("path", { d: "M18.5 31.5q5.5 5 11 0" }),
          s.jsx("path", { d: "M34.5 31.5q5.5 5 11 0" }),
        ],
      });
    case "wide":
      return s.jsxs("g", {
        children: [
          s.jsx("circle", { cx: "20", cy: Le, r: "3.8", fill: se }),
          s.jsx("circle", { cx: "44", cy: Le, r: "3.8", fill: se }),
          s.jsx("circle", { cx: "21.3", cy: Le - 1.4, r: "1.3", fill: $e }),
          s.jsx("circle", { cx: "45.3", cy: Le - 1.4, r: "1.3", fill: $e }),
        ],
      });
    case "turret":
      return s.jsxs("g", {
        children: [
          s.jsx("circle", { cx: "21", cy: "31", r: "7.5", fill: l }),
          s.jsx("circle", { cx: "43", cy: "31", r: "7.5", fill: l }),
          s.jsx("circle", { cx: "21", cy: "31", r: "3.6", fill: d }),
          s.jsx("circle", { cx: "43", cy: "31", r: "3.6", fill: d }),
          s.jsx("circle", { cx: "21", cy: "31", r: "1.7", fill: se }),
          s.jsx("circle", { cx: "43", cy: "31", r: "1.7", fill: se }),
        ],
      });
    case "compound":
      return s.jsxs("g", {
        children: [
          s.jsx("ellipse", {
            cx: "22",
            cy: "31",
            rx: "7.5",
            ry: "9",
            fill: se,
            transform: "rotate(-12 22 31)",
          }),
          s.jsx("ellipse", {
            cx: "42",
            cy: "31",
            rx: "7.5",
            ry: "9",
            fill: se,
            transform: "rotate(12 42 31)",
          }),
          s.jsx("ellipse", {
            cx: "20.5",
            cy: "28",
            rx: "2.2",
            ry: "3",
            fill: $e,
            opacity: "0.75",
          }),
          s.jsx("ellipse", {
            cx: "43.5",
            cy: "28",
            rx: "2.2",
            ry: "3",
            fill: $e,
            opacity: "0.75",
          }),
        ],
      });
    case "stalk":
      return s.jsxs("g", {
        children: [
          s.jsxs("g", {
            stroke: l,
            strokeWidth: "2.8",
            strokeLinecap: "round",
            fill: "none",
            children: [
              s.jsx("path", { d: "M23 16 19.5 5" }),
              s.jsx("path", { d: "M41 16 44.5 5" }),
            ],
          }),
          s.jsx("circle", {
            cx: "19",
            cy: "4",
            r: "3.8",
            fill: $e,
            stroke: l,
            strokeWidth: "1.2",
          }),
          s.jsx("circle", {
            cx: "45",
            cy: "4",
            r: "3.8",
            fill: $e,
            stroke: l,
            strokeWidth: "1.2",
          }),
          s.jsx("circle", { cx: "19", cy: "4", r: "1.8", fill: se }),
          s.jsx("circle", { cx: "45", cy: "4", r: "1.8", fill: se }),
        ],
      });
    case "visor":
      return s.jsxs("g", {
        children: [
          s.jsx("rect", {
            x: "14",
            y: "26.5",
            width: "36",
            height: "13",
            rx: "6.5",
            fill: se,
          }),
          s.jsx("circle", { cx: Ht, cy: Le, r: "3.2", fill: d }),
          s.jsx("circle", { cx: Vt, cy: Le, r: "3.2", fill: d }),
        ],
      });
    case "dot":
    default:
      return s.jsxs("g", {
        children: [
          s.jsx("circle", { cx: Ht, cy: Le, r: "4.2", fill: se }),
          s.jsx("circle", { cx: Vt, cy: Le, r: "4.2", fill: se }),
          s.jsx("circle", { cx: Ht + 1.4, cy: Le - 1.5, r: "1.4", fill: $e }),
          s.jsx("circle", { cx: Vt + 1.4, cy: Le - 1.5, r: "1.4", fill: $e }),
        ],
      });
  }
}
function hd() {
  return s.jsxs("g", {
    children: [
      s.jsx("path", { d: "M27.5 39q4.5-3.4 9 0Q32 44.6 27.5 39Z", fill: se }),
      s.jsx("path", {
        d: "M32 43.5v2.4M32 45.9q-2.4 2.6-4.6.4M32 45.9q2.4 2.6 4.6.4",
        stroke: se,
        strokeWidth: "2",
        strokeLinecap: "round",
        fill: "none",
      }),
    ],
  });
}
function Cg(i) {
  const { accent: u, shade: l } = i,
    d = pi(i);
  switch (i.muzzle) {
    case "nose":
      return hd();
    case "snout":
      return s.jsxs("g", {
        children: [
          s.jsx("ellipse", { cx: "32", cy: "43", rx: "13", ry: "9", fill: u }),
          hd(),
        ],
      });
    case "beak":
      return s.jsxs("g", {
        children: [
          s.jsx("path", { d: "M23 38h18l-9 11Z", fill: d }),
          s.jsx("path", {
            d: "M23 38h18",
            stroke: se,
            strokeWidth: "1.4",
            opacity: "0.35",
          }),
        ],
      });
    case "bill":
      return s.jsxs("g", {
        children: [
          s.jsx("rect", {
            x: "19",
            y: "37.5",
            width: "26",
            height: "11.5",
            rx: "5.75",
            fill: d,
          }),
          s.jsx("circle", { cx: "26", cy: "41.5", r: "1.3", fill: se }),
          s.jsx("circle", { cx: "38", cy: "41.5", r: "1.3", fill: se }),
        ],
      });
    case "pig":
      return s.jsxs("g", {
        children: [
          s.jsx("ellipse", { cx: "32", cy: "43", rx: "11", ry: "8", fill: u }),
          s.jsx("ellipse", {
            cx: "28",
            cy: "43",
            rx: "2.2",
            ry: "3",
            fill: se,
          }),
          s.jsx("ellipse", {
            cx: "36",
            cy: "43",
            rx: "2.2",
            ry: "3",
            fill: se,
          }),
        ],
      });
    case "wide":
      return s.jsx("path", {
        d: "M16 41q16 11 32 0",
        stroke: se,
        strokeWidth: "3",
        strokeLinecap: "round",
        fill: "none",
      });
    case "tusks":
      return s.jsxs("g", {
        children: [
          s.jsx("ellipse", {
            cx: "32",
            cy: "42",
            rx: "13",
            ry: "8.5",
            fill: u,
          }),
          s.jsx("ellipse", {
            cx: "32",
            cy: "38.5",
            rx: "3.4",
            ry: "2.6",
            fill: se,
          }),
          s.jsx("path", {
            d: "M27 45q-1.6 8-3.6 12M37 45q1.6 8 3.6 12",
            stroke: "#f8fafc",
            strokeWidth: "3.6",
            strokeLinecap: "round",
            fill: "none",
          }),
        ],
      });
    case "trunk":
      return s.jsx("path", {
        d: "M32 36q0 10-3 14t2 10",
        stroke: l,
        strokeWidth: "7.5",
        strokeLinecap: "round",
        fill: "none",
      });
    case "mandibles":
      return s.jsxs("g", {
        stroke: se,
        strokeWidth: "2.6",
        strokeLinecap: "round",
        fill: "none",
        children: [
          s.jsx("path", { d: "M26 43q6 6 12 0" }),
          s.jsx("path", { d: "M24.5 41q-3.5 4.5 0 8" }),
          s.jsx("path", { d: "M39.5 41q3.5 4.5 0 8" }),
        ],
      });
    case "grill":
      return s.jsxs("g", {
        children: [
          s.jsx("rect", {
            x: "23",
            y: "41",
            width: "18",
            height: "8",
            rx: "4",
            fill: se,
          }),
          s.jsx("path", {
            d: "M28 41v8M32 41v8M36 41v8",
            stroke: d,
            strokeWidth: "1.4",
            opacity: "0.8",
          }),
        ],
      });
    case "smile":
    default:
      return s.jsx("path", {
        d: "M26.5 42.5q5.5 5 11 0",
        stroke: se,
        strokeWidth: "2.8",
        strokeLinecap: "round",
        fill: "none",
      });
  }
}
function ws(i, u, l) {
  const { shade: d, accent: p } = u,
    y = pi(u);
  switch (i) {
    case "mask":
      return s.jsxs(
        "g",
        {
          clipPath: `url(#${l})`,
          fill: d,
          children: [
            s.jsx("ellipse", { cx: Ht, cy: Le - 0.5, rx: "9", ry: "8.5" }),
            s.jsx("ellipse", { cx: Vt, cy: Le - 0.5, rx: "9", ry: "8.5" }),
          ],
        },
        i,
      );
    case "stripes":
      return s.jsxs(
        "g",
        {
          clipPath: `url(#${l})`,
          stroke: d,
          strokeWidth: "3.4",
          strokeLinecap: "round",
          fill: "none",
          children: [
            s.jsx("path", { d: "M19 11q3 8-2 14" }),
            s.jsx("path", { d: "M32 10v10" }),
            s.jsx("path", { d: "M45 11q-3 8 2 14" }),
          ],
        },
        i,
      );
    case "spots":
      return s.jsxs(
        "g",
        {
          clipPath: `url(#${l})`,
          fill: d,
          opacity: "0.8",
          children: [
            s.jsx("circle", { cx: "16", cy: "24", r: "4" }),
            s.jsx("circle", { cx: "48", cy: "24", r: "4" }),
            s.jsx("circle", { cx: "14", cy: "42", r: "3.4" }),
            s.jsx("circle", { cx: "50", cy: "42", r: "3.4" }),
            s.jsx("circle", { cx: "32", cy: "18", r: "3.4" }),
          ],
        },
        i,
      );
    case "blush":
      return s.jsxs(
        "g",
        {
          clipPath: `url(#${l})`,
          fill: "#f87171",
          opacity: "0.35",
          children: [
            s.jsx("ellipse", { cx: "15", cy: "40", rx: "5.5", ry: "3.6" }),
            s.jsx("ellipse", { cx: "49", cy: "40", rx: "5.5", ry: "3.6" }),
          ],
        },
        i,
      );
    case "patch":
      return s.jsx(
        "g",
        {
          clipPath: `url(#${l})`,
          children: s.jsx("rect", {
            x: "15",
            y: "37",
            width: "34",
            height: "21",
            rx: "11",
            fill: p,
            opacity: "0.9",
          }),
        },
        i,
      );
    case "whiskers":
      return s.jsx(
        "g",
        {
          stroke: se,
          strokeWidth: "1.7",
          strokeLinecap: "round",
          opacity: "0.65",
          fill: "none",
          children: s.jsx("path", {
            d: "M18 40 6 37M18 43.5 6 44M46 40l12-3M46 43.5l12 .5",
          }),
        },
        i,
      );
    case "brows":
      return s.jsxs(
        "g",
        {
          stroke: se,
          strokeWidth: "3",
          strokeLinecap: "round",
          fill: "none",
          children: [
            s.jsx("path", { d: "M17.5 24.5 29 28.5" }),
            s.jsx("path", { d: "M46.5 24.5 35 28.5" }),
          ],
        },
        i,
      );
    case "horn":
      return s.jsxs(
        "g",
        {
          children: [
            s.jsx("path", { d: "M28 15 32-2l4 17Z", fill: y }),
            s.jsx("path", {
              d: "M29.4 10.5h5.2M30.4 6h3.2",
              stroke: se,
              strokeWidth: "1.3",
              opacity: "0.35",
            }),
          ],
        },
        i,
      );
    case "tongue":
      return s.jsx("path", { d: "M28.5 45q3.5 9 7 0Z", fill: "#f472b6" }, i);
    case "fangs":
      return s.jsxs(
        "g",
        {
          fill: $e,
          children: [
            s.jsx("path", { d: "M26.5 42 29 48l2.5-6Z" }),
            s.jsx("path", { d: "M32.5 42 35 48l2.5-6Z" }),
          ],
        },
        i,
      );
    case "sparkle":
      return s.jsxs(
        "g",
        {
          fill: y,
          children: [
            s.jsx("path", {
              d: "M53 8 54.4 12 58 13.4 54.4 14.8 53 18.6 51.6 14.8 48 13.4 51.6 12Z",
            }),
            s.jsx("path", {
              d: "M10 44 11 47 14 48 11 49 10 52 9 49 6 48 9 47Z",
            }),
          ],
        },
        i,
      );
    case "crown":
      return s.jsxs(
        "g",
        {
          children: [
            s.jsx("path", {
              d: "M19 13 23 3l5 6 5-8 5 8 5-6 4 10Z",
              fill: "#fbbf24",
            }),
            s.jsx("circle", { cx: "32", cy: "6", r: "1.8", fill: "#fde68a" }),
          ],
        },
        i,
      );
    case "shell":
      return s.jsxs(
        "g",
        {
          children: [
            s.jsx("path", { d: "M0 61q0-27 32-27t32 27Z", fill: y }),
            s.jsxs("g", {
              fill: d,
              opacity: "0.55",
              children: [
                s.jsx("circle", { cx: "5.5", cy: "52", r: "3" }),
                s.jsx("circle", { cx: "58.5", cy: "52", r: "3" }),
                s.jsx("circle", { cx: "20", cy: "59", r: "3" }),
                s.jsx("circle", { cx: "44", cy: "59", r: "3" }),
                s.jsx("circle", { cx: "32", cy: "60", r: "3" }),
              ],
            }),
          ],
        },
        i,
      );
    case "stitches":
      return s.jsxs(
        "g",
        {
          clipPath: `url(#${l})`,
          stroke: d,
          strokeWidth: "1.8",
          strokeLinecap: "round",
          children: [
            s.jsx("path", { d: "M45 12v14" }),
            s.jsx("path", { d: "M41.5 16h7M41.5 21h7" }),
            s.jsx("path", { d: "M14 44h9" }),
            s.jsx("path", { d: "M17 41.5v5M21 41.5v5" }),
          ],
        },
        i,
      );
    case "bolt":
      return s.jsx(
        "path",
        { d: "M49 2 39 18h6l-8 14 20-20h-7l6-10Z", fill: y },
        i,
      );
    case "bandage":
      return s.jsxs(
        "g",
        {
          clipPath: `url(#${l})`,
          fill: p,
          opacity: "0.9",
          children: [
            s.jsx("path", { d: "M2 20 62 12v7L2 27Z" }),
            s.jsx("path", { d: "M2 44 62 36v7L2 51Z" }),
            s.jsx("path", { d: "M6 56 58 48v6H6Z" }),
          ],
        },
        i,
      );
    case "visorGlow":
      return s.jsx(
        "g",
        {
          opacity: "0.75",
          children: s.jsx("path", {
            d: "M18 27q14-6 28 0",
            stroke: y,
            strokeWidth: "2",
            fill: "none",
            strokeLinecap: "round",
          }),
        },
        i,
      );
    default:
      return null;
  }
}
function bg({ features: i, idSuffix: u, className: l, title: d }) {
  const p = `cs-avatar-head-${u}`,
    y = i.marks || [],
    S = y.filter((k) => md.has(k)),
    j = y.filter((k) => !md.has(k));
  return s.jsxs("svg", {
    className: l,
    viewBox: `0 0 ${fd} ${fd}`,
    width: "100%",
    height: "100%",
    role: d ? "img" : "presentation",
    "aria-label": d,
    "aria-hidden": d ? void 0 : !0,
    focusable: "false",
    children: [
      s.jsx("defs", {
        children: s.jsx("clipPath", {
          id: p,
          children: s.jsx("rect", { ...pd }),
        }),
      }),
      S.map((k) => ws(k, i, p)),
      kg(i),
      s.jsx("rect", { ...pd, fill: i.base }),
      j
        .filter(
          (k) =>
            k === "mask" ||
            k === "stripes" ||
            k === "spots" ||
            k === "patch" ||
            k === "bandage",
        )
        .map((k) => ws(k, i, p)),
      Cg(i),
      Sg(i),
      j
        .filter(
          (k) =>
            !(
              k === "mask" ||
              k === "stripes" ||
              k === "spots" ||
              k === "patch" ||
              k === "bandage"
            ),
        )
        .map((k) => ws(k, i, p)),
    ],
  });
}
const _g = {
  rust: ["#ef8043", "#cd5f27", "#ffe0c6"],
  amber: ["#f0993f", "#cb7220", "#ffe8cd"],
  brown: ["#a97551", "#7d5133", "#f2ddc8"],
  cocoa: ["#8b5e3c", "#5d3c23", "#ebd6c1"],
  sand: ["#e6c48b", "#c39a55", "#fdf1da"],
  cream: ["#f3e3c3", "#d6b988", "#fff8ea"],
  grey: ["#9aa8bb", "#6b7c93", "#e6edf5"],
  slate: ["#7c8ba1", "#4f5d74", "#dde5ef"],
  charcoal: ["#4d5765", "#2e3641", "#c6cedb"],
  snow: ["#eef3f9", "#c0cbd9", "#ffffff"],
  pink: ["#f5a6ba", "#da7c92", "#ffe4ec"],
  rose: ["#ef8ba2", "#cd6079", "#ffdde5"],
  green: ["#5fba70", "#3d9350", "#d9f2dd"],
  moss: ["#7fbc5a", "#5d9639", "#e4f5d5"],
  lime: ["#95cf57", "#6da733", "#eafada"],
  teal: ["#42b5a8", "#2a8a80", "#d3f1ed"],
  blue: ["#5c9cd6", "#3c74a7", "#dceaf8"],
  sky: ["#7cc4ef", "#4d9acb", "#e3f3fd"],
  navy: ["#41628f", "#2b4568", "#d0dcec"],
  yellow: ["#f3c552", "#d09c2c", "#fff3d0"],
  gold: ["#e9aa3c", "#c1811d", "#ffeecb"],
  purple: ["#a68bf5", "#7c5cef", "#e9e3ff"],
  violet: ["#8a6fd4", "#63499f", "#e0d8f6"],
  red: ["#e15c4f", "#b73e33", "#fbdad5"],
  stone: ["#98a0a8", "#6a737c", "#dfe4e8"],
};
function b(i, u, l, d, p) {
  const [y, S, j] = _g[d];
  return { id: i, label: u, group: l, base: y, shade: S, accent: j, ...p };
}
const jg = Object.freeze([
    b("fox", "Fox", "woodland", "rust", {
      ears: "pointed",
      eyes: "round",
      muzzle: "snout",
      marks: ["whiskers"],
    }),
    b("owl", "Owl", "woodland", "cocoa", {
      ears: "tuft",
      eyes: "big",
      muzzle: "beak",
      detail: "#f3c552",
    }),
    b("bear", "Bear", "woodland", "brown", {
      ears: "round",
      eyes: "dot",
      muzzle: "snout",
    }),
    b("panda", "Panda", "woodland", "snow", {
      ears: "round",
      eyes: "dot",
      muzzle: "snout",
      marks: ["mask"],
      shade: "#39414d",
    }),
    b("wolf", "Wolf", "woodland", "slate", {
      ears: "pointed",
      eyes: "round",
      muzzle: "snout",
    }),
    b("badger", "Badger", "woodland", "snow", {
      ears: "round",
      eyes: "dot",
      muzzle: "snout",
      marks: ["mask"],
      shade: "#3b4553",
    }),
    b("hedgehog", "Hedgehog", "woodland", "sand", {
      ears: "spikes",
      eyes: "dot",
      muzzle: "nose",
    }),
    b("squirrel", "Squirrel", "woodland", "amber", {
      ears: "tuft",
      eyes: "round",
      muzzle: "nose",
      marks: ["patch"],
    }),
    b("deer", "Deer", "woodland", "sand", {
      ears: "antlers",
      eyes: "round",
      muzzle: "snout",
      marks: ["spots"],
      detail: "#8b5e3c",
    }),
    b("raccoon", "Raccoon", "woodland", "grey", {
      ears: "round",
      eyes: "dot",
      muzzle: "snout",
      marks: ["mask"],
      shade: "#3e4756",
    }),
    b("cat", "Cat", "pets", "amber", {
      ears: "pointed",
      eyes: "slit",
      muzzle: "nose",
      marks: ["stripes", "whiskers"],
      detail: "#5fba70",
    }),
    b("dog", "Dog", "pets", "brown", {
      ears: "floppy",
      eyes: "round",
      muzzle: "snout",
    }),
    b("rabbit", "Rabbit", "pets", "cream", {
      ears: "tall",
      eyes: "round",
      muzzle: "nose",
      marks: ["blush"],
    }),
    b("hamster", "Hamster", "pets", "sand", {
      ears: "round",
      eyes: "dot",
      muzzle: "nose",
      marks: ["patch", "blush"],
    }),
    b("guineapig", "Guinea pig", "pets", "cocoa", {
      ears: "round",
      eyes: "dot",
      muzzle: "nose",
      marks: ["patch"],
    }),
    b("ferret", "Ferret", "pets", "cream", {
      ears: "round",
      eyes: "dot",
      muzzle: "nose",
      marks: ["mask"],
      shade: "#a97551",
    }),
    b("budgie", "Budgie", "pets", "lime", {
      ears: "crest",
      eyes: "dot",
      muzzle: "beak",
      marks: ["blush"],
      detail: "#f3c552",
    }),
    b("goldfish", "Goldfish", "pets", "gold", {
      ears: "fins",
      eyes: "wide",
      muzzle: "smile",
    }),
    b("pony", "Pony", "pets", "sand", {
      ears: "pointed",
      eyes: "round",
      muzzle: "snout",
      marks: ["patch"],
    }),
    b("mouse", "Mouse", "pets", "grey", {
      ears: "round",
      eyes: "dot",
      muzzle: "nose",
      marks: ["whiskers", "blush"],
    }),
    b("cow", "Cow", "farm", "snow", {
      ears: "horns",
      eyes: "round",
      muzzle: "pig",
      marks: ["spots"],
      shade: "#39414d",
      detail: "#e6c48b",
    }),
    b("pig", "Pig", "farm", "pink", {
      ears: "floppy",
      eyes: "dot",
      muzzle: "pig",
      marks: ["blush"],
    }),
    b("sheep", "Sheep", "farm", "cream", {
      ears: "wool",
      eyes: "dot",
      muzzle: "nose",
    }),
    b("goat", "Goat", "farm", "cream", {
      ears: "horns",
      eyes: "slit",
      muzzle: "nose",
      marks: ["patch"],
      detail: "#a97551",
    }),
    b("horse", "Horse", "farm", "cocoa", {
      ears: "pointed",
      eyes: "round",
      muzzle: "snout",
      marks: ["patch"],
    }),
    b("donkey", "Donkey", "farm", "grey", {
      ears: "tall",
      eyes: "sleepy",
      muzzle: "snout",
    }),
    b("chicken", "Chicken", "farm", "snow", {
      ears: "crest",
      eyes: "dot",
      muzzle: "beak",
      detail: "#e15c4f",
    }),
    b("duck", "Duck", "farm", "yellow", {
      ears: "none",
      eyes: "dot",
      muzzle: "bill",
      detail: "#f0993f",
    }),
    b("goose", "Goose", "farm", "snow", {
      ears: "none",
      eyes: "dot",
      muzzle: "bill",
      detail: "#f0993f",
    }),
    b("bull", "Bull", "farm", "charcoal", {
      ears: "horns",
      eyes: "round",
      muzzle: "pig",
      marks: ["brows"],
      detail: "#e6c48b",
    }),
    b("lion", "Lion", "savanna", "gold", {
      ears: "mane",
      eyes: "round",
      muzzle: "snout",
      marks: ["whiskers"],
      detail: "#b9762a",
    }),
    b("tiger", "Tiger", "savanna", "amber", {
      ears: "pointed",
      eyes: "round",
      muzzle: "snout",
      marks: ["stripes", "whiskers"],
      shade: "#8a4a17",
    }),
    b("elephant", "Elephant", "savanna", "grey", {
      ears: "flap",
      eyes: "dot",
      muzzle: "trunk",
    }),
    b("giraffe", "Giraffe", "savanna", "sand", {
      ears: "horns",
      eyes: "round",
      muzzle: "snout",
      marks: ["spots"],
      detail: "#8b5e3c",
    }),
    b("zebra", "Zebra", "savanna", "snow", {
      ears: "round",
      eyes: "round",
      muzzle: "snout",
      marks: ["stripes"],
      shade: "#39414d",
    }),
    b("rhino", "Rhino", "savanna", "stone", {
      ears: "round",
      eyes: "dot",
      muzzle: "pig",
      marks: ["horn"],
      detail: "#dfe4e8",
    }),
    b("hippo", "Hippo", "savanna", "violet", {
      ears: "round",
      eyes: "wide",
      muzzle: "pig",
    }),
    b("cheetah", "Cheetah", "savanna", "sand", {
      ears: "round",
      eyes: "round",
      muzzle: "nose",
      marks: ["spots", "whiskers"],
    }),
    b("meerkat", "Meerkat", "savanna", "cream", {
      ears: "round",
      eyes: "dot",
      muzzle: "nose",
      marks: ["mask"],
      shade: "#8b5e3c",
    }),
    b("monkey", "Monkey", "savanna", "cocoa", {
      ears: "round",
      eyes: "round",
      muzzle: "snout",
      marks: ["patch"],
    }),
    b("polarbear", "Polar bear", "polar", "snow", {
      ears: "round",
      eyes: "dot",
      muzzle: "snout",
    }),
    b("penguin", "Penguin", "polar", "charcoal", {
      ears: "none",
      eyes: "round",
      muzzle: "beak",
      marks: ["patch"],
      accent: "#ffffff",
      detail: "#f0993f",
    }),
    b("seal", "Seal", "polar", "slate", {
      ears: "none",
      eyes: "sleepy",
      muzzle: "nose",
      marks: ["whiskers"],
    }),
    b("arcticfox", "Arctic fox", "polar", "snow", {
      ears: "pointed",
      eyes: "round",
      muzzle: "snout",
      marks: ["whiskers"],
    }),
    b("snowleopard", "Snow leopard", "polar", "snow", {
      ears: "tuft",
      eyes: "slit",
      muzzle: "nose",
      marks: ["spots", "whiskers"],
      detail: "#5fba70",
    }),
    b("walrus", "Walrus", "polar", "brown", {
      ears: "none",
      eyes: "dot",
      muzzle: "tusks",
      marks: ["whiskers"],
    }),
    b("reindeer", "Reindeer", "polar", "cocoa", {
      ears: "antlers",
      eyes: "round",
      muzzle: "snout",
      detail: "#c39a55",
    }),
    b("husky", "Husky", "polar", "slate", {
      ears: "pointed",
      eyes: "slit",
      muzzle: "snout",
      marks: ["mask"],
      detail: "#7cc4ef",
    }),
    b("puffin", "Puffin", "polar", "charcoal", {
      ears: "none",
      eyes: "dot",
      muzzle: "beak",
      marks: ["patch"],
      accent: "#ffffff",
      detail: "#f0993f",
    }),
    b("yak", "Yak", "polar", "cocoa", {
      ears: "horns",
      eyes: "sleepy",
      muzzle: "nose",
      marks: ["patch"],
      detail: "#e6c48b",
    }),
    b("whale", "Whale", "ocean", "navy", {
      ears: "fins",
      eyes: "wide",
      muzzle: "smile",
      marks: ["patch"],
    }),
    b("dolphin", "Dolphin", "ocean", "sky", {
      ears: "fins",
      eyes: "dot",
      muzzle: "smile",
      marks: ["patch"],
    }),
    b("shark", "Shark", "ocean", "slate", {
      ears: "fins",
      eyes: "round",
      muzzle: "wide",
      marks: ["brows", "fangs"],
    }),
    b("octopus", "Octopus", "ocean", "purple", {
      ears: "tentacles",
      eyes: "round",
      muzzle: "smile",
    }),
    b("crab", "Crab", "ocean", "red", {
      ears: "none",
      eyes: "stalk",
      muzzle: "mandibles",
    }),
    b("jellyfish", "Jellyfish", "ocean", "rose", {
      ears: "tentacles",
      eyes: "dot",
      muzzle: "smile",
    }),
    b("seahorse", "Seahorse", "ocean", "yellow", {
      ears: "crest",
      eyes: "wide",
      muzzle: "beak",
      detail: "#d09c2c",
    }),
    b("pufferfish", "Pufferfish", "ocean", "amber", {
      ears: "spikes",
      eyes: "wide",
      muzzle: "smile",
    }),
    b("narwhal", "Narwhal", "ocean", "sky", {
      ears: "fins",
      eyes: "dot",
      muzzle: "smile",
      marks: ["horn"],
      detail: "#eef3f9",
    }),
    b("otter", "Otter", "ocean", "brown", {
      ears: "round",
      eyes: "round",
      muzzle: "snout",
      marks: ["whiskers"],
    }),
    b("frog", "Frog", "creatures", "green", {
      ears: "none",
      eyes: "bulge",
      muzzle: "wide",
      marks: ["tongue"],
    }),
    b("turtle", "Turtle", "creatures", "moss", {
      ears: "none",
      eyes: "round",
      muzzle: "smile",
      marks: ["shell"],
      detail: "#3f7a2a",
    }),
    b("gecko", "Gecko", "creatures", "lime", {
      ears: "none",
      eyes: "round",
      muzzle: "smile",
      marks: ["spots"],
    }),
    b("chameleon", "Chameleon", "creatures", "teal", {
      ears: "crest",
      eyes: "turret",
      muzzle: "smile",
      marks: ["spots"],
      detail: "#f3c552",
    }),
    b("snake", "Snake", "creatures", "moss", {
      ears: "none",
      eyes: "slit",
      muzzle: "smile",
      marks: ["stripes"],
      detail: "#f3c552",
    }),
    b("crocodile", "Crocodile", "creatures", "green", {
      ears: "none",
      eyes: "wide",
      muzzle: "wide",
      marks: ["brows", "fangs"],
    }),
    b("bee", "Bee", "creatures", "yellow", {
      ears: "antennae",
      eyes: "compound",
      muzzle: "mandibles",
      marks: ["stripes"],
      shade: "#39414d",
    }),
    b("ladybird", "Ladybird", "creatures", "red", {
      ears: "antennae",
      eyes: "dot",
      muzzle: "smile",
      marks: ["spots"],
      shade: "#39414d",
    }),
    b("butterfly", "Butterfly", "creatures", "purple", {
      ears: "wings",
      eyes: "compound",
      muzzle: "smile",
      marks: ["sparkle"],
      detail: "#f3c552",
    }),
    b("snail", "Snail", "creatures", "cream", {
      ears: "none",
      eyes: "stalk",
      muzzle: "smile",
      marks: ["shell"],
      detail: "#c39a55",
    }),
    b("dragon", "Dragon", "mythical", "green", {
      ears: "spikes",
      eyes: "slit",
      muzzle: "wide",
      marks: ["fangs", "brows"],
      detail: "#f3c552",
    }),
    b("unicorn", "Unicorn", "mythical", "snow", {
      ears: "pointed",
      eyes: "round",
      muzzle: "snout",
      marks: ["horn", "sparkle"],
      detail: "#a68bf5",
    }),
    b("phoenix", "Phoenix", "mythical", "red", {
      ears: "crest",
      eyes: "round",
      muzzle: "beak",
      marks: ["sparkle"],
      detail: "#f3c552",
    }),
    b("griffin", "Griffin", "mythical", "gold", {
      ears: "wings",
      eyes: "big",
      muzzle: "beak",
      marks: ["brows"],
      detail: "#c1811d",
    }),
    b("yeti", "Yeti", "mythical", "snow", {
      ears: "wool",
      eyes: "round",
      muzzle: "snout",
      marks: ["fangs"],
      accent: "#dcecfb",
    }),
    b("pegasus", "Pegasus", "mythical", "snow", {
      ears: "wings",
      eyes: "round",
      muzzle: "snout",
      marks: ["sparkle"],
      detail: "#7cc4ef",
    }),
    b("kraken", "Kraken", "mythical", "violet", {
      ears: "tentacles",
      eyes: "slit",
      muzzle: "smile",
      marks: ["brows"],
      detail: "#42b5a8",
    }),
    b("sphinx", "Sphinx", "mythical", "sand", {
      ears: "pointed",
      eyes: "round",
      muzzle: "nose",
      marks: ["crown"],
    }),
    b("wyvern", "Wyvern", "mythical", "red", {
      ears: "wings",
      eyes: "slit",
      muzzle: "wide",
      marks: ["horn", "fangs"],
      detail: "#f3c552",
    }),
    b("golem", "Golem", "mythical", "stone", {
      ears: "dome",
      eyes: "visor",
      muzzle: "grill",
      marks: ["sparkle"],
      detail: "#7cc4ef",
    }),
    b("trex", "T. rex", "dinosaurs", "moss", {
      ears: "none",
      eyes: "slit",
      muzzle: "wide",
      marks: ["brows", "fangs"],
      detail: "#f3c552",
    }),
    b("triceratops", "Triceratops", "dinosaurs", "teal", {
      ears: "frill",
      eyes: "round",
      muzzle: "beak",
      marks: ["horn"],
      detail: "#e6c48b",
    }),
    b("stegosaurus", "Stegosaurus", "dinosaurs", "violet", {
      ears: "spikes",
      eyes: "dot",
      muzzle: "smile",
      marks: ["spots"],
    }),
    b("raptor", "Raptor", "dinosaurs", "amber", {
      ears: "none",
      eyes: "slit",
      muzzle: "wide",
      marks: ["stripes", "fangs"],
      detail: "#5fba70",
    }),
    b("pterodactyl", "Pterodactyl", "dinosaurs", "rust", {
      ears: "wings",
      eyes: "round",
      muzzle: "beak",
      detail: "#cd5f27",
    }),
    b("brachiosaurus", "Brachiosaurus", "dinosaurs", "sky", {
      ears: "none",
      eyes: "dot",
      muzzle: "smile",
      marks: ["spots"],
    }),
    b("ankylosaurus", "Ankylosaurus", "dinosaurs", "stone", {
      ears: "points",
      eyes: "dot",
      muzzle: "smile",
      marks: ["spots"],
    }),
    b("spinosaurus", "Spinosaurus", "dinosaurs", "navy", {
      ears: "spikes",
      eyes: "slit",
      muzzle: "wide",
      marks: ["fangs"],
      detail: "#f3c552",
    }),
    b("dilophosaurus", "Dilophosaurus", "dinosaurs", "lime", {
      ears: "crest",
      eyes: "round",
      muzzle: "wide",
      marks: ["tongue"],
      detail: "#e15c4f",
    }),
    b("mosasaurus", "Mosasaurus", "dinosaurs", "teal", {
      ears: "fins",
      eyes: "wide",
      muzzle: "wide",
      marks: ["fangs"],
    }),
    b("astronaut", "Astronaut", "space", "snow", {
      ears: "dome",
      eyes: "visor",
      muzzle: "smile",
      marks: ["visorGlow"],
      detail: "#7cc4ef",
    }),
    b("alien", "Alien", "space", "lime", {
      ears: "antennae",
      eyes: "compound",
      muzzle: "smile",
      detail: "#6da733",
    }),
    b("martian", "Martian", "space", "red", {
      ears: "antennae",
      eyes: "big",
      muzzle: "smile",
      marks: ["blush"],
    }),
    b("moon", "Moon", "space", "snow", {
      ears: "none",
      eyes: "sleepy",
      muzzle: "smile",
      marks: ["spots"],
    }),
    b("sun", "Sun", "space", "yellow", {
      ears: "rays",
      eyes: "dot",
      muzzle: "smile",
      marks: ["blush"],
      detail: "#e9aa3c",
    }),
    b("star", "Star", "space", "yellow", {
      ears: "points",
      eyes: "dot",
      muzzle: "smile",
      marks: ["sparkle"],
      shade: "#e9aa3c",
      detail: "#fff3d0",
    }),
    b("comet", "Comet", "space", "sky", {
      ears: "points",
      eyes: "wide",
      muzzle: "smile",
      marks: ["sparkle", "bolt"],
      detail: "#f3c552",
    }),
    b("satellite", "Satellite", "space", "slate", {
      ears: "antennae",
      eyes: "visor",
      muzzle: "grill",
      marks: ["bolt"],
      detail: "#f3c552",
    }),
    b("ufo", "UFO", "space", "teal", {
      ears: "dome",
      eyes: "big",
      muzzle: "smile",
      marks: ["visorGlow"],
      detail: "#95cf57",
    }),
    b("rover", "Rover", "space", "stone", {
      ears: "antennae",
      eyes: "visor",
      muzzle: "grill",
      marks: ["spots"],
      detail: "#f0993f",
    }),
    b("robot", "Robot", "robots", "stone", {
      ears: "antennae",
      eyes: "visor",
      muzzle: "grill",
      marks: ["bolt"],
      detail: "#7cc4ef",
    }),
    b("android", "Android", "robots", "snow", {
      ears: "none",
      eyes: "round",
      muzzle: "smile",
      marks: ["visorGlow"],
      detail: "#42b5a8",
    }),
    b("cyborg", "Cyborg", "robots", "charcoal", {
      ears: "none",
      eyes: "slit",
      muzzle: "grill",
      marks: ["stitches"],
      detail: "#e15c4f",
    }),
    b("drone", "Drone", "robots", "slate", {
      ears: "fins",
      eyes: "big",
      muzzle: "smile",
      detail: "#95cf57",
    }),
    b("mecha", "Mecha", "robots", "navy", {
      ears: "horns",
      eyes: "visor",
      muzzle: "grill",
      marks: ["bolt"],
      detail: "#f3c552",
    }),
    b("servo", "Servo", "robots", "gold", {
      ears: "antennae",
      eyes: "dot",
      muzzle: "smile",
      marks: ["blush"],
    }),
    b("glitch", "Glitch", "robots", "purple", {
      ears: "points",
      eyes: "compound",
      muzzle: "grill",
      marks: ["sparkle"],
      detail: "#95cf57",
    }),
    b("pixel", "Pixel", "robots", "lime", {
      ears: "none",
      eyes: "dot",
      muzzle: "grill",
      marks: ["spots"],
      detail: "#f3c552",
    }),
    b("sentry", "Sentry", "robots", "red", {
      ears: "dome",
      eyes: "visor",
      muzzle: "grill",
      marks: ["visorGlow"],
      detail: "#f3c552",
    }),
    b("beacon", "Beacon", "robots", "sky", {
      ears: "rays",
      eyes: "dot",
      muzzle: "smile",
      marks: ["sparkle"],
      detail: "#f3c552",
    }),
    b("vampire", "Vampire", "monsters", "snow", {
      ears: "pointed",
      eyes: "slit",
      muzzle: "smile",
      marks: ["brows", "fangs"],
      detail: "#e15c4f",
    }),
    b("werewolf", "Werewolf", "monsters", "charcoal", {
      ears: "pointed",
      eyes: "round",
      muzzle: "snout",
      marks: ["brows", "fangs"],
    }),
    b("zombie", "Zombie", "monsters", "moss", {
      ears: "round",
      eyes: "round",
      muzzle: "smile",
      marks: ["stitches", "fangs"],
    }),
    b("ghost", "Ghost", "monsters", "snow", {
      ears: "none",
      eyes: "big",
      muzzle: "wide",
      marks: ["sparkle"],
      detail: "#a68bf5",
    }),
    b("mummy", "Mummy", "monsters", "cream", {
      ears: "none",
      eyes: "dot",
      muzzle: "smile",
      marks: ["bandage"],
      accent: "#fffaf0",
    }),
    b("frankenstein", "Frankenstein", "monsters", "lime", {
      ears: "none",
      eyes: "sleepy",
      muzzle: "smile",
      marks: ["brows", "stitches", "bolt"],
      detail: "#f3c552",
    }),
    b("goblin", "Goblin", "monsters", "moss", {
      ears: "pointed",
      eyes: "slit",
      muzzle: "wide",
      marks: ["brows", "fangs"],
      detail: "#f3c552",
    }),
    b("ogre", "Ogre", "monsters", "brown", {
      ears: "round",
      eyes: "dot",
      muzzle: "tusks",
      marks: ["brows"],
    }),
    b("slime", "Slime", "monsters", "teal", {
      ears: "none",
      eyes: "round",
      muzzle: "smile",
      marks: ["blush", "sparkle"],
    }),
    b("gargoyle", "Gargoyle", "monsters", "stone", {
      ears: "wings",
      eyes: "slit",
      muzzle: "wide",
      marks: ["brows", "fangs"],
      detail: "#6a737c",
    }),
  ]),
  Eg = new Map(jg.map((i) => [i.id, i]));
function nf(i) {
  return i ? Eg.get(i) : void 0;
}
const Ks = "(max-width: 639px)";
function Ag(i) {
  if (typeof window > "u" || typeof window.matchMedia != "function")
    return () => {};
  const u = window.matchMedia(Ks);
  return (
    u.addEventListener("change", i),
    () => u.removeEventListener("change", i)
  );
}
function Pg() {
  return (
    typeof window < "u" &&
    typeof window.matchMedia == "function" &&
    window.matchMedia(Ks).matches
  );
}
function Tg() {
  return R.useSyncExternalStore(Ag, Pg, () => !1);
}
const zg = R.createContext(null),
  gd = "var(--safe-area-inset-top, env(safe-area-inset-top, 0px))",
  yd = "var(--safe-area-inset-left, env(safe-area-inset-left, 0px))",
  vd = "var(--comp-school-phone-bar-bg, hsl(var(--background, 222 47% 11%)))",
  Mg = `
[data-phone-bar-slot] { display: none; }
@media ${Ks} {
  [data-phone-bar] {
    position: sticky !important;
    top: 0;
    z-index: 30 !important;
    border-bottom: 0 !important;
    background: linear-gradient(to bottom, ${vd} 0, ${vd} 72%, transparent) !important;
  }
  [data-phone-bar] [data-phone-bar-row] {
    justify-content: flex-start !important;
    min-height: 0 !important;
    max-width: none !important;
    padding: calc(${gd} + 0.75rem) 0.75rem 1rem calc(${yd} + 0.75rem) !important;
  }
  [data-phone-bar] [data-phone-bar-row] > div:first-of-type {
    flex: 1 1 auto;
  }
  [data-phone-bar] [data-phone-bar-hide] { display: none !important; }
  [data-phone-bar] [data-phone-bar-slot] {
    display: flex;
    flex: 1 1 auto;
    min-width: 0;
    align-items: center;
  }
  [data-phone-bar] [data-phone-bar-leading] > button {
    display: inline-flex;
    width: 2.75rem;
    height: 2.75rem;
    flex-shrink: 0;
    align-items: center;
    justify-content: center;
    border: 1px solid rgb(255 255 255 / 0.15);
    border-radius: 0.5rem;
    background: rgb(2 6 23 / 0.7);
    color: rgb(241 245 249);
    pointer-events: auto;
    -webkit-backdrop-filter: blur(8px);
    backdrop-filter: blur(8px);
  }
}
/* The bare bar is the floating button alone, at every width below a desktop.
   It sits over a full-screen page's own layers (Aquatic Sort's sea is 35) and
   under the sidebar (45). */
[data-phone-bar='bare'] {
  position: fixed !important;
  inset: 0 auto auto 0;
  z-index: 40 !important;
  border-bottom: 0 !important;
  background: none !important;
  pointer-events: none;
}
[data-phone-bar='bare'] [data-phone-bar-row] {
  justify-content: flex-start !important;
  min-height: 0 !important;
  max-width: none !important;
  padding: calc(${gd} + 0.75rem) 0.75rem 1rem calc(${yd} + 0.75rem) !important;
}
[data-phone-bar='bare'] [data-phone-bar-hide],
[data-phone-bar='bare'] [data-phone-bar-back],
[data-phone-bar='bare'] [data-phone-bar-slot] { display: none !important; }
[data-phone-bar='bare'] [data-phone-bar-leading] > button {
  display: inline-flex;
  width: 2.75rem;
  height: 2.75rem;
  flex-shrink: 0;
  align-items: center;
  justify-content: center;
  border: 1px solid rgb(255 255 255 / 0.15);
  border-radius: 0.5rem;
  background: rgb(2 6 23 / 0.7);
  color: rgb(241 245 249);
  pointer-events: auto;
  -webkit-backdrop-filter: blur(8px);
  backdrop-filter: blur(8px);
}
@media (min-width: 1024px) {
  [data-phone-bar='bare'] { display: none !important; }
}
`;
function Lg() {
  return s.jsx("style", { children: Mg });
}
const Rg = "Checking platform access...",
  Og = {
    alignItems: "center",
    background: "var(--cs-background, #020617)",
    color: "rgb(var(--slate-50, 248 250 252))",
    display: "grid",
    minHeight: "100vh",
    padding: "1rem",
    placeItems: "center",
  },
  Ng = { opacity: 0.5 },
  Ig = {
    border: 0,
    clip: "rect(0 0 0 0)",
    height: "1px",
    margin: "-1px",
    overflow: "hidden",
    padding: 0,
    position: "absolute",
    whiteSpace: "nowrap",
    width: "1px",
  };
function Dg() {
  return s.jsxs("main", {
    "aria-busy": "true",
    "data-comp-school-loading": "",
    style: Og,
    children: [
      s.jsx(rf, { size: "large", style: Ng }),
      s.jsx("p", { role: "status", style: Ig, children: Rg }),
    ],
  });
}
function Ug() {
  const [i, u] = R.useState(null);
  return (
    R.useEffect(
      () =>
        Ym((l) => {
          u((d) => (d === "conflict" ? d : l.kind));
        }),
      [],
    ),
    i
      ? s.jsxs("div", {
          role: "alert",
          "data-testid": "saved-state-notice",
          style: si.banner,
          children: [
            s.jsx("p", {
              style: si.copy,
              children:
                i === "conflict"
                  ? "This was changed on another device. Reload."
                  : "This is too long to save to your account. It is saved on this device.",
            }),
            i === "conflict"
              ? s.jsx("button", {
                  type: "button",
                  style: si.button,
                  onClick: () => window.location.reload(),
                  children: "Reload",
                })
              : s.jsx("button", {
                  type: "button",
                  style: si.button,
                  onClick: () => u(null),
                  children: "OK",
                }),
          ],
        })
      : null
  );
}
const si = {
    banner: {
      alignItems: "center",
      background: "var(--cs-surface, #ffffff)",
      border: "1px solid var(--cs-border, #cbd5e1)",
      borderRadius: "0.5rem",
      bottom: "1rem",
      boxShadow: "0 12px 24px -12px rgb(15 23 42 / 0.45)",
      boxSizing: "border-box",
      color: "var(--cs-text, #020617)",
      display: "flex",
      flexWrap: "wrap",
      fontFamily:
        'Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
      gap: "0.75rem",
      justifyContent: "space-between",
      left: "50%",
      maxWidth: "calc(100vw - 2rem)",
      padding: "0.75rem 1rem",
      position: "fixed",
      transform: "translateX(-50%)",
      width: "32rem",
      zIndex: 2147483e3,
    },
    copy: {
      flex: "1 1 14rem",
      fontSize: "1rem",
      fontWeight: 600,
      lineHeight: 1.4,
      margin: 0,
    },
    button: {
      background: "var(--cs-primary-hover, #2563eb)",
      border: 0,
      borderRadius: "0.375rem",
      color: "#ffffff",
      cursor: "pointer",
      fontSize: "1rem",
      fontWeight: 700,
      minHeight: "2.75rem",
      minWidth: "6rem",
      padding: "0.5rem 1rem",
    },
  },
  $g = { small: "1.25rem", medium: "1.75rem", large: "2.5rem" },
  wd = "#f8fafc",
  Fg = "#60a5fa",
  xd = [
    { value: "product", label: "Product" },
    { value: "mock", label: "Mock" },
    { value: "real", label: "Real" },
  ];
function Wg({ dataSource: i, onDataSourceChange: u, tone: l = "light" }) {
  const [d, p] = R.useState(!1),
    y = l === "dark",
    S = xd.find((L) => L.value === i)?.label || "Product",
    j = y ? "rgb(var(--slate-200, 226 232 240))" : "#334155",
    k = y ? "rgb(var(--slate-400, 148 163 184))" : "#64748b",
    F = y ? "rgb(var(--slate-50, 248 250 252))" : "#0f172a";
  return s.jsxs("div", {
    "data-profile-database-row": !0,
    style: { marginBottom: "0.25rem" },
    children: [
      s.jsxs("button", {
        "aria-controls": "profile-database-options",
        "aria-expanded": d,
        "data-profile-database-trigger": !0,
        onClick: () => p((L) => !L),
        style: {
          alignItems: "center",
          background: "transparent",
          border: 0,
          borderRadius: "0.5rem",
          color: j,
          cursor: "pointer",
          display: "flex",
          fontFamily: "inherit",
          fontSize: "0.875rem",
          fontWeight: 650,
          gap: "0.5rem",
          minHeight: "2.25rem",
          padding: "0.5rem",
          textAlign: "left",
          width: "100%",
        },
        type: "button",
        children: [
          s.jsxs("svg", {
            "aria-hidden": "true",
            fill: "none",
            height: "16",
            viewBox: "0 0 24 24",
            width: "16",
            children: [
              s.jsx("ellipse", {
                cx: "12",
                cy: "5",
                rx: "8",
                ry: "3",
                stroke: "currentColor",
                strokeWidth: "1.8",
              }),
              s.jsx("path", {
                d: "M4 5v7c0 1.7 3.6 3 8 3s8-1.3 8-3V5M4 12v7c0 1.7 3.6 3 8 3s8-1.3 8-3v-7",
                stroke: "currentColor",
                strokeWidth: "1.8",
              }),
            ],
          }),
          s.jsx("span", { style: { flex: 1 }, children: "Database" }),
          s.jsx("span", {
            style: { color: k, fontSize: "0.75rem", fontWeight: 600 },
            children: S,
          }),
          s.jsx("svg", {
            "aria-hidden": "true",
            fill: "none",
            height: "15",
            style: { transform: d ? "rotate(180deg)" : void 0 },
            viewBox: "0 0 24 24",
            width: "15",
            children: s.jsx("path", {
              d: "m6 9 6 6 6-6",
              stroke: "currentColor",
              strokeLinecap: "round",
              strokeLinejoin: "round",
              strokeWidth: "2",
            }),
          }),
        ],
      }),
      d
        ? s.jsx("div", {
            "aria-label": "Database",
            id: "profile-database-options",
            role: "radiogroup",
            style: {
              display: "grid",
              gap: "0.125rem",
              gridTemplateColumns: "repeat(3, minmax(0, 1fr))",
              padding: "0.125rem 0.5rem 0.5rem 2rem",
            },
            children: xd.map((L) =>
              s.jsxs(
                "button",
                {
                  "aria-checked": i === L.value,
                  "aria-label": L.locked ? `${L.label}, locked` : L.label,
                  "data-database-source": L.value,
                  disabled: L.locked,
                  onClick: () => u(L.value),
                  role: "radio",
                  style: {
                    background: i === L.value ? F : "transparent",
                    border: `1px solid ${i === L.value ? F : y ? "rgb(var(--slate-600, 71 85 105))" : "#cbd5e1"}`,
                    borderRadius: "9999px",
                    color: L.locked
                      ? k
                      : i === L.value
                        ? y
                          ? "rgb(var(--slate-900, 15 23 42))"
                          : "#ffffff"
                        : j,
                    cursor: L.locked ? "not-allowed" : "pointer",
                    display: "inline-flex",
                    fontFamily: "inherit",
                    fontSize: "0.75rem",
                    fontWeight: 700,
                    minHeight: "1.875rem",
                    opacity: L.locked ? 0.62 : 1,
                    padding: "0.25rem 0.45rem",
                    alignItems: "center",
                    justifyContent: "center",
                    gap: "0.2rem",
                  },
                  title: L.locked ? "Locked" : L.label,
                  type: "button",
                  children: [
                    L.locked
                      ? s.jsxs("svg", {
                          "aria-hidden": "true",
                          fill: "none",
                          height: "11",
                          viewBox: "0 0 24 24",
                          width: "11",
                          children: [
                            s.jsx("rect", {
                              height: "10",
                              rx: "2",
                              stroke: "currentColor",
                              strokeWidth: "2",
                              width: "14",
                              x: "5",
                              y: "11",
                            }),
                            s.jsx("path", {
                              d: "M8 11V8a4 4 0 0 1 8 0v3",
                              stroke: "currentColor",
                              strokeLinecap: "round",
                              strokeWidth: "2",
                            }),
                          ],
                        })
                      : null,
                    L.label,
                  ],
                },
                L.value,
              ),
            ),
          })
        : null,
    ],
  });
}
function rf({ className: i, size: u = "medium", style: l }) {
  return s.jsxs("span", {
    "aria-label": "comp.school",
    className: i,
    style: {
      alignItems: "baseline",
      color: "inherit",
      display: "inline-flex",
      fontSize: $g[u],
      lineHeight: 1,
      textTransform: "none",
      whiteSpace: "nowrap",
      ...l,
    },
    children: [
      s.jsxs("span", {
        "aria-hidden": "true",
        "data-comp-school-wordmark-part": "comp-dot",
        style: {
          color: wd,
          fontFamily:
            "Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
          fontSize: "0.88em",
          fontStyle: "normal",
          fontWeight: 650,
          letterSpacing: "-0.035em",
        },
        children: [
          "comp",
          s.jsx("span", { style: { color: wd }, children: "." }),
        ],
      }),
      s.jsx("span", {
        "aria-hidden": "true",
        "data-comp-school-wordmark-part": "school",
        style: {
          color: Fg,
          fontFamily: "'Caveat', 'Segoe Print', cursive",
          fontSize: "1.2em",
          fontStyle: "italic",
          fontWeight: 700,
          letterSpacing: "-0.04em",
          transform: "rotate(-2deg)",
        },
        children: "school",
      }),
    ],
  });
}
function Bg(i) {
  return i.trim().charAt(0).toLocaleUpperCase() || "U";
}
function kd({ avatar: i, instanceId: u, profileName: l, style: d }) {
  const p = nf(i);
  return p
    ? s.jsx("span", {
        "aria-hidden": "true",
        "data-student-avatar": p.id,
        style: {
          display: "block",
          height: "100%",
          lineHeight: 0,
          width: "100%",
          ...d,
        },
        children: s.jsx(bg, {
          features: p,
          idSuffix: u ? `${u}-${p.id}` : p.id,
        }),
      })
    : s.jsx("span", {
        "aria-hidden": "true",
        style: { lineHeight: 1, ...d },
        children: Bg(l),
      });
}
function Sd() {
  return s.jsxs("svg", {
    "aria-hidden": "true",
    fill: "none",
    height: "16",
    viewBox: "0 0 24 24",
    width: "16",
    children: [
      s.jsx("path", {
        d: "M12 4c-4.4 0-8 3.1-8 7 0 2.9 2 5.4 4.9 6.5L8 21l3.4-2.8H12c4.4 0 8-3.1 8-7s-3.6-7.2-8-7.2Z",
        stroke: "currentColor",
        strokeLinejoin: "round",
        strokeWidth: "1.8",
      }),
      s.jsx("circle", { cx: "9", cy: "10", fill: "currentColor", r: "1" }),
      s.jsx("circle", { cx: "15", cy: "10", fill: "currentColor", r: "1" }),
    ],
  });
}
function Hg(i) {
  if (typeof window > "u") return "https://comp.school/?page=release-log";
  const u = new URL(mn(window.location.hostname));
  u.searchParams.set("page", "release-log");
  const l = window.sessionStorage.getItem("comp-school-fallback-access");
  return l && Es(l) ? Pm(u.toString(), l, i) : u.toString();
}
function Vg({
  profileName: i,
  canChangeAvatar: u = !1,
  changeAvatarHref: l,
  onChangeAvatar: d,
  dataSource: p,
  feedbackWelcomeInstead: y = !1,
  onDataSourceChange: S,
  onSignOut: j,
  profileAvatar: k,
  reportIssueHref: F,
  releaseLogHref: L,
  tone: D = "dark",
  placement: O = "below-end",
  showName: K = !1,
}) {
  const Q = R.useRef(null),
    [M, B] = R.useState(!1),
    V = D === "dark",
    ie = !!nf(k),
    J = V ? "rgb(var(--slate-50, 248 250 252))" : "#0f172a",
    ee = V ? "rgb(var(--slate-300, 203 213 225))" : "#475569",
    ge = V ? "rgb(var(--slate-700, 51 65 85))" : "#e2e8f0",
    fe = V ? "rgb(var(--slate-900, 15 23 42))" : "#ffffff",
    re = {
      alignItems: "center",
      background: "transparent",
      border: 0,
      borderRadius: "0.625rem",
      color: J,
      cursor: "pointer",
      display: "inline-flex",
      fontFamily: "inherit",
      fontSize: "0.875rem",
      fontWeight: 700,
      gap: "0.375rem",
      justifyContent: "flex-start",
      minHeight: "2.5rem",
      padding: "0.5rem 0.75rem",
      textDecoration: "none",
      whiteSpace: "nowrap",
      width: "100%",
    },
    ce = {
      alignItems: "center",
      background: ie
        ? "transparent"
        : V
          ? "rgb(var(--slate-200, 226 232 240))"
          : "#0f172a",
      borderRadius: ie ? "0.8rem" : "9999px",
      color: V ? "rgb(var(--slate-900, 15 23 42))" : "#ffffff",
      display: "inline-flex",
      flex: "0 0 auto",
      fontSize: "0.875rem",
      fontWeight: 800,
      height: "2.5rem",
      justifyContent: "center",
      overflow: "hidden",
      width: "2.5rem",
    };
  return (F || y) && j
    ? s.jsxs(s.Fragment, {
        children: [
          s.jsxs("details", {
            "data-comp-school-account-menu": !0,
            onToggle: (ke) => {
              ke.currentTarget.open || B(!1);
            },
            style: { position: "relative", width: K ? "100%" : void 0 },
            children: [
              s.jsxs("summary", {
                "aria-label": `${i} account menu`,
                title: `${i} account`,
                style: {
                  alignItems: "center",
                  borderRadius: "0.625rem",
                  color: J,
                  cursor: "pointer",
                  display: "flex",
                  gap: "0.625rem",
                  listStyle: "none",
                  padding: K ? "0.25rem" : 0,
                  width: K ? "100%" : void 0,
                },
                children: [
                  s.jsx("span", {
                    style: ce,
                    children: s.jsx(kd, { avatar: k, profileName: i }),
                  }),
                  K
                    ? s.jsx("span", {
                        style: {
                          fontSize: "0.875rem",
                          fontWeight: 600,
                          minWidth: 0,
                          overflow: "hidden",
                          textOverflow: "ellipsis",
                          whiteSpace: "nowrap",
                        },
                        children: i,
                      })
                    : null,
                ],
              }),
              s.jsxs("div", {
                style: {
                  background: fe,
                  border: `1px solid ${ge}`,
                  borderRadius: "0.75rem",
                  boxShadow: "0 20px 25px -5px rgba(2, 6, 23, 0.35)",
                  minWidth: "15rem",
                  padding: "0.5rem",
                  position: "absolute",
                  zIndex: 40,
                  ...(O === "above-start"
                    ? { bottom: "calc(100% + 0.5rem)", left: 0 }
                    : { right: 0, top: "calc(100% + 0.5rem)" }),
                },
                children: [
                  O === "above-start"
                    ? null
                    : s.jsx("p", {
                        style: {
                          color: ee,
                          fontSize: "0.75rem",
                          fontWeight: 700,
                          letterSpacing: "0.05em",
                          margin: 0,
                          padding: "0.375rem 0.5rem",
                          textTransform: "uppercase",
                        },
                        children: i.split(" ")[0] || i,
                      }),
                  p && S
                    ? s.jsx(Wg, {
                        dataSource: p,
                        onDataSourceChange: S,
                        tone: D,
                      })
                    : null,
                  M
                    ? s.jsxs(s.Fragment, {
                        children: [
                          s.jsxs("button", {
                            "data-account-menu-back": !0,
                            onClick: () => B(!1),
                            style: { ...re, textAlign: "left" },
                            type: "button",
                            children: [
                              s.jsx("svg", {
                                "aria-hidden": "true",
                                fill: "none",
                                height: "16",
                                viewBox: "0 0 24 24",
                                width: "16",
                                children: s.jsx("path", {
                                  d: "m15 18-6-6 6-6",
                                  stroke: "currentColor",
                                  strokeLinecap: "round",
                                  strokeLinejoin: "round",
                                  strokeWidth: "1.8",
                                }),
                              }),
                              s.jsx("span", { children: "Back" }),
                            ],
                          }),
                          s.jsxs("a", {
                            href: L ?? Hg(k),
                            style: re,
                            children: [
                              s.jsx("svg", {
                                "aria-hidden": "true",
                                fill: "none",
                                height: "16",
                                viewBox: "0 0 24 24",
                                width: "16",
                                children: s.jsx("path", {
                                  d: "M3 11a9 9 0 1 1 2.6 6.4M3 5v6h6m3-4v5l3 2",
                                  stroke: "currentColor",
                                  strokeLinecap: "round",
                                  strokeLinejoin: "round",
                                  strokeWidth: "1.8",
                                }),
                              }),
                              s.jsx("span", { children: "What's new" }),
                            ],
                          }),
                          s.jsxs("button", {
                            "data-profile-accessibility": !0,
                            onClick: (ke) => {
                              (ke.currentTarget
                                .closest("[data-comp-school-account-menu]")
                                ?.removeAttribute("open"),
                                Q.current?.showModal());
                            },
                            style: { ...re, textAlign: "left" },
                            type: "button",
                            children: [
                              s.jsx(tf, {}),
                              s.jsx("span", { children: ef }),
                            ],
                          }),
                        ],
                      })
                    : s.jsxs(s.Fragment, {
                        children: [
                          u && d
                            ? s.jsxs("button", {
                                onClick: (ke) => {
                                  (ke.currentTarget
                                    .closest("details")
                                    ?.removeAttribute("open"),
                                    d());
                                },
                                style: re,
                                type: "button",
                                children: [
                                  s.jsx(Sd, {}),
                                  s.jsx("span", { children: "Change avatar" }),
                                ],
                              })
                            : u && l
                              ? s.jsxs("a", {
                                  href: l,
                                  style: re,
                                  children: [
                                    s.jsx(Sd, {}),
                                    s.jsx("span", {
                                      children: "Change avatar",
                                    }),
                                  ],
                                })
                              : null,
                          y
                            ? s.jsxs("a", {
                                href: xg,
                                onClick: (ke) =>
                                  ke.currentTarget
                                    .closest("details")
                                    ?.removeAttribute("open"),
                                rel: "noopener noreferrer",
                                style: re,
                                target: "_blank",
                                children: [
                                  s.jsxs("svg", {
                                    "aria-hidden": "true",
                                    fill: "none",
                                    height: "16",
                                    viewBox: "0 0 24 24",
                                    width: "16",
                                    children: [
                                      s.jsx("rect", {
                                        height: "14",
                                        rx: "2",
                                        stroke: "currentColor",
                                        strokeWidth: "1.8",
                                        width: "18",
                                        x: "3",
                                        y: "5",
                                      }),
                                      s.jsx("path", {
                                        d: "m4 7 8 6 8-6",
                                        stroke: "currentColor",
                                        strokeLinecap: "round",
                                        strokeLinejoin: "round",
                                        strokeWidth: "1.8",
                                      }),
                                    ],
                                  }),
                                  s.jsx("span", { children: wg }),
                                ],
                              })
                            : s.jsxs("a", {
                                href: F,
                                style: re,
                                children: [
                                  s.jsxs("svg", {
                                    "aria-hidden": "true",
                                    fill: "none",
                                    height: "16",
                                    viewBox: "0 0 24 24",
                                    width: "16",
                                    children: [
                                      s.jsx("path", {
                                        d: "M8 2 6.5 5M16 2l1.5 3M4 9H2M22 9h-2M5 19l2.5-2.5M19 19l-2.5-2.5M9 5h6a4 4 0 0 1 4 4v4a7 7 0 0 1-14 0V9a4 4 0 0 1 4-4Z",
                                        stroke: "currentColor",
                                        strokeLinecap: "round",
                                        strokeLinejoin: "round",
                                        strokeWidth: "1.8",
                                      }),
                                      s.jsx("path", {
                                        d: "M8 12h8M12 8v8",
                                        stroke: "currentColor",
                                        strokeLinecap: "round",
                                        strokeWidth: "1.8",
                                      }),
                                    ],
                                  }),
                                  s.jsx("span", {
                                    children: "Report an issue",
                                  }),
                                ],
                              }),
                          s.jsxs("button", {
                            "data-account-menu-more": !0,
                            onClick: () => B(!0),
                            style: { ...re, textAlign: "left" },
                            type: "button",
                            children: [
                              s.jsxs("svg", {
                                "aria-hidden": "true",
                                fill: "none",
                                height: "16",
                                viewBox: "0 0 24 24",
                                width: "16",
                                children: [
                                  s.jsx("circle", {
                                    cx: "5",
                                    cy: "12",
                                    r: "1.6",
                                    fill: "currentColor",
                                  }),
                                  s.jsx("circle", {
                                    cx: "12",
                                    cy: "12",
                                    r: "1.6",
                                    fill: "currentColor",
                                  }),
                                  s.jsx("circle", {
                                    cx: "19",
                                    cy: "12",
                                    r: "1.6",
                                    fill: "currentColor",
                                  }),
                                ],
                              }),
                              s.jsx("span", { children: "More" }),
                            ],
                          }),
                          s.jsxs("button", {
                            onClick: j,
                            style: { ...re, marginTop: "0.25rem" },
                            type: "button",
                            children: [
                              s.jsx("svg", {
                                "aria-hidden": "true",
                                fill: "none",
                                height: "16",
                                viewBox: "0 0 24 24",
                                width: "16",
                                children: s.jsx("path", {
                                  d: "M10 17l5-5-5-5M15 12H3M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4",
                                  stroke: "currentColor",
                                  strokeLinecap: "round",
                                  strokeLinejoin: "round",
                                  strokeWidth: "1.8",
                                }),
                              }),
                              s.jsx("span", { children: "Sign out" }),
                            ],
                          }),
                        ],
                      }),
                ],
              }),
            ],
          }),
          s.jsx(vg, { dialogRef: Q, tone: D }),
        ],
      })
    : s.jsx("span", {
        "aria-label": `${i} profile`,
        title: i,
        style: ce,
        children: s.jsx(kd, { avatar: k, profileName: i }),
      });
}
function Jg({
  appName: i,
  backHref: u,
  profileName: l,
  backLabel: d = "Back",
  canChangeAvatar: p = !1,
  changeAvatarHref: y,
  children: S,
  className: j,
  contextLabel: k,
  dataSource: F,
  onBack: L,
  onDataSourceChange: D,
  onSignOut: O,
  profileAvatar: K,
  feedbackWelcomeInstead: Q = !1,
  leading: M,
  hideAccountMenu: B = !1,
  breadcrumbNavigation: V = !1,
  phoneBar: ie,
  phoneBarSlotRef: J,
  actionsSlotRef: ee,
  reportIssueHref: ge,
  style: fe,
  tone: re = "dark",
}) {
  const ce = re === "dark",
    ke = ce ? "rgb(var(--slate-50, 248 250 252))" : "#0f172a",
    ve = ce ? "rgb(var(--slate-300, 203 213 225))" : "#475569",
    ne = ce ? "rgb(var(--slate-700, 51 65 85))" : "#e2e8f0",
    Ce = ce ? "rgb(var(--slate-900, 15 23 42))" : "#ffffff",
    pe = ce ? "rgb(var(--slate-800, 30 41 59))" : "#f8fafc",
    Se = s.jsxs(s.Fragment, {
      children: [
        s.jsx("svg", {
          "aria-hidden": "true",
          fill: "none",
          height: "16",
          viewBox: "0 0 24 24",
          width: "16",
          children: s.jsx("path", {
            d: "M19 12H5m7 7-7-7 7-7",
            stroke: "currentColor",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "2",
          }),
        }),
        s.jsx("span", { children: d }),
      ],
    }),
    Ne = {
      alignItems: "center",
      background: pe,
      border: `1px solid ${ne}`,
      borderRadius: "0.625rem",
      color: ve,
      cursor: "pointer",
      display: "inline-flex",
      fontFamily: "inherit",
      fontSize: "0.875rem",
      fontWeight: 700,
      gap: "0.375rem",
      minHeight: "2.5rem",
      padding: "0.5rem 0.75rem",
      textDecoration: "none",
      whiteSpace: "nowrap",
    },
    Ae = V && B && !S && !k;
  return s.jsx("header", {
    "aria-label": `${i} navigation`,
    className: j,
    "data-comp-school-navbar": V ? "breadcrumb" : "standard",
    "data-navbar-wide-hidden": Ae ? "" : void 0,
    "data-phone-bar": ie,
    style: {
      background: Ce,
      borderBottom: `1px solid ${ne}`,
      color: ke,
      fontFamily:
        "Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
      position: "relative",
      zIndex: 30,
      ...fe,
    },
    children: s.jsxs("div", {
      "data-phone-bar-row": ie ? "" : void 0,
      style: {
        alignItems: "center",
        display: "flex",
        gap: "0.75rem",
        justifyContent: "space-between",
        margin: "0 auto",
        maxWidth: "80rem",
        minHeight: "4rem",
        padding: "0.625rem clamp(1rem, 3vw, 2rem)",
        width: "100%",
      },
      children: [
        Ae
          ? s.jsx("style", {
              children:
                "@media (min-width: 1024px) { [data-navbar-wide-hidden] { display: none; } }",
            })
          : null,
        ie ? s.jsx(Lg, {}) : null,
        s.jsxs("div", {
          style: {
            alignItems: "center",
            display: "flex",
            gap: "0.625rem",
            minWidth: 0,
          },
          children: [
            ie
              ? s.jsx("span", {
                  "data-phone-bar-leading": "",
                  style: { display: "contents" },
                  children: M,
                })
              : M,
            V
              ? null
              : L
                ? s.jsx("button", {
                    "aria-label": d,
                    "data-phone-bar-back": "",
                    onClick: L,
                    style: Ne,
                    type: "button",
                    children: Se,
                  })
                : s.jsx("a", {
                    "aria-label": d,
                    "data-phone-bar-back": "",
                    href: u,
                    style: Ne,
                    children: Se,
                  }),
            ie ? s.jsx("div", { "data-phone-bar-slot": "", ref: J }) : null,
            k
              ? s.jsx("span", {
                  "data-phone-bar-hide": "",
                  style: {
                    borderLeft: `1px solid ${ne}`,
                    color: ve,
                    fontSize: "0.875rem",
                    fontWeight: 650,
                    lineHeight: 1.2,
                    minWidth: 0,
                    overflow: "hidden",
                    paddingLeft: "0.625rem",
                    textOverflow: "ellipsis",
                    whiteSpace: "nowrap",
                  },
                  children: k,
                })
              : null,
          ],
        }),
        s.jsxs("div", {
          "data-phone-bar-hide": ie ? "" : void 0,
          style: { alignItems: "center", display: "flex", gap: "0.625rem" },
          children: [
            ee
              ? s.jsx("div", {
                  "data-navbar-actions": "",
                  ref: ee,
                  style: {
                    alignItems: "center",
                    display: "flex",
                    gap: "0.5rem",
                  },
                })
              : null,
            S,
            B
              ? null
              : s.jsx(Vg, {
                  canChangeAvatar: p,
                  changeAvatarHref: y,
                  dataSource: F,
                  feedbackWelcomeInstead: Q,
                  onDataSourceChange: D,
                  onSignOut: O,
                  profileAvatar: K,
                  profileName: l,
                  reportIssueHref: ge,
                  tone: re,
                }),
          ],
        }),
      ],
    }),
  });
}
const Kg = 900 * 1e3,
  Qg = 15 * 1e3;
function Gg({ storageKey: i, now: u = Date.now }) {
  const [l, d] = R.useState(() => cs(window.sessionStorage.getItem(i))),
    [p, y] = R.useState(u),
    [S, j] = R.useState(""),
    [k, F] = R.useState(null),
    [L, D] = R.useState(!1),
    O = R.useId();
  if (
    (R.useEffect(() => {
      const M = window.setInterval(() => {
        y(u());
        const B = cs(window.sessionStorage.getItem(i));
        B && d((V) => (V && V > B ? V : B));
      }, Qg);
      return () => window.clearInterval(M);
    }, [u, i]),
    fi() || !l || l - p > Kg)
  )
    return null;
  const K = Math.max(0, Math.ceil((l - p) / 6e4));
  async function Q(M) {
    if ((M.preventDefault(), !(!S.trim() || L))) {
      (D(!0), F(null));
      try {
        const B = await fetch(
            new URL(
              "/api/fallback-access",
              mn(window.location.hostname),
            ).toString(),
            {
              method: "POST",
              cache: "no-store",
              headers: {
                accept: "application/json",
                "content-type": "application/json",
              },
              body: JSON.stringify({ password: S }),
            },
          ),
          V = await B.json().catch(() => null),
          ie = cs(V?.grant);
        if (!B.ok || !V?.ok || !V.grant || !ie) {
          F(V?.message || "That did not work. Try again.");
          return;
        }
        (window.sessionStorage.setItem(i, V.grant), d(ie), j(""));
      } catch {
        F("No connection. Try again.");
      } finally {
        D(!1);
      }
    }
  }
  return s.jsx("div", {
    role: "dialog",
    "aria-labelledby": `${O}-title`,
    "data-testid": "fallback-renewal",
    style: fn.panel,
    children: s.jsxs("form", {
      onSubmit: (M) => void Q(M),
      style: fn.form,
      children: [
        s.jsx("p", {
          id: `${O}-title`,
          style: fn.title,
          children:
            K > 0
              ? `Your access ends in ${K} minute${K === 1 ? "" : "s"}.`
              : "Your access has ended.",
        }),
        s.jsx("label", {
          htmlFor: O,
          style: fn.label,
          children: "Class password",
        }),
        s.jsxs("div", {
          style: fn.row,
          children: [
            s.jsx("input", {
              id: O,
              type: "password",
              autoComplete: "off",
              value: S,
              onChange: (M) => j(M.target.value),
              style: fn.input,
            }),
            s.jsx("button", {
              type: "submit",
              disabled: L,
              style: fn.button,
              children: "Keep going",
            }),
          ],
        }),
        k ? s.jsx("p", { role: "alert", style: fn.error, children: k }) : null,
      ],
    }),
  });
}
const fn = {
    panel: {
      background: "var(--cs-surface, #ffffff)",
      border: "1px solid var(--cs-border, #cbd5e1)",
      borderRadius: "0.5rem",
      bottom: "1rem",
      boxShadow: "0 12px 24px -12px rgb(15 23 42 / 0.45)",
      boxSizing: "border-box",
      color: "var(--cs-text, #020617)",
      fontFamily:
        'Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
      left: "50%",
      maxWidth: "calc(100vw - 2rem)",
      padding: "1rem",
      position: "fixed",
      transform: "translateX(-50%)",
      width: "26rem",
      zIndex: 2147483001,
    },
    form: { display: "grid", gap: "0.5rem", margin: 0 },
    title: { fontSize: "1rem", fontWeight: 700, lineHeight: 1.4, margin: 0 },
    label: { fontSize: "0.875rem", fontWeight: 600 },
    row: { display: "flex", gap: "0.5rem", flexWrap: "wrap" },
    input: {
      border: "1px solid var(--cs-border, #94a3b8)",
      borderRadius: "0.375rem",
      boxSizing: "border-box",
      flex: "1 1 10rem",
      fontSize: "1rem",
      minHeight: "2.75rem",
      minWidth: 0,
      padding: "0.5rem 0.75rem",
    },
    button: {
      background: "var(--cs-primary-hover, #2563eb)",
      border: 0,
      borderRadius: "0.375rem",
      color: "#ffffff",
      cursor: "pointer",
      fontSize: "1rem",
      fontWeight: 700,
      minHeight: "2.75rem",
      padding: "0.5rem 1rem",
    },
    error: {
      color: "#b91c1c",
      fontSize: "0.875rem",
      fontWeight: 600,
      margin: 0,
    },
  },
  Zg = { BASE_URL: "/", DEV: !1, MODE: "production", PROD: !0, SSR: !1 },
  qg = R.createContext(null),
  Yg = R.createContext(null),
  Xg = R.createContext(null),
  ey = R.createContext(null),
  ty = R.createContext(null),
  ny = R.createContext(!1),
  Ln = "comp-school-fallback-access";
function Cd() {
  return typeof window > "u" || typeof document > "u"
    ? null
    : Td(document.cookie, window.location.hostname, Qs().DEV === !0);
}
function ry(i) {
  if (typeof window > "u" || typeof document > "u") return;
  const u = Em(i);
  Td(u, window.location.hostname, Qs().DEV === !0) && (document.cookie = u);
}
function oy() {
  typeof document > "u" || (document.cookie = Am());
}
function xs(i, u) {
  return (
    u &&
    i.role === "teacher" &&
    new URLSearchParams(window.location.search).get("preview") === "student"
  );
}
function of() {
  if (typeof window > "u") return null;
  const i = new URLSearchParams(window.location.hash.replace(/^#/, "")),
    u = i.get("fallback");
  if (u && Es(u)) {
    (window.sessionStorage.setItem(Ln, u), i.delete("fallback"));
    const d = i.toString();
    window.history.replaceState(
      {},
      "",
      `${window.location.pathname}${window.location.search}${d ? `#${d}` : ""}`,
    );
  }
  const l = u || window.sessionStorage.getItem(Ln);
  return Es(l) ? l : (window.sessionStorage.removeItem(Ln), null);
}
function iy() {
  const i = new URLSearchParams(window.location.hash.replace(/^#/, "")),
    u = i.get(_s);
  if (u !== null) {
    i.delete(_s);
    const l = i.toString();
    window.history.replaceState(
      {},
      "",
      `${window.location.pathname}${window.location.search}${l ? `#${l}` : ""}`,
    );
  }
  return Mm(window.sessionStorage, u);
}
function ks() {
  return of() ? (window.sessionStorage.removeItem(Ln), !0) : !1;
}
function ay() {
  const i = of();
  return i ? { [Cm]: i } : {};
}
function Ss(i) {
  (xm(i),
    vm(zn(i) && i.role === "student" ? (i.courses ?? ["j277"]) : []),
    i.role === "student" && i.aiAccess);
}
const st = {
  main: {
    alignItems: "center",
    background: "var(--cs-background, #020617)",
    color: "rgb(var(--slate-50, 255 255 255))",
    display: "flex",
    fontFamily:
      'Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
    justifyContent: "center",
    minHeight: "100vh",
    padding: "2.5rem 1rem",
  },
  panel: {
    background: "var(--cs-surface, #ffffff)",
    border: "1px solid var(--cs-border, rgba(255, 255, 255, 0.1))",
    borderRadius: "0.5rem",
    boxShadow:
      "0 25px 50px -12px rgb(var(--slate-900, 15 23 42) / 0.45), 0 12px 24px -16px rgb(var(--slate-900, 15 23 42) / 0.6)",
    color: "var(--cs-text, #020617)",
    maxWidth: "24rem",
    padding: "1.5rem",
    width: "100%",
  },
  title: {
    fontSize: "1.5rem",
    fontWeight: 700,
    lineHeight: 1.2,
    margin: "0.75rem 0 0",
  },
  copy: {
    color: "var(--cs-text-muted, #475569)",
    fontSize: "0.875rem",
    lineHeight: 1.6,
    margin: "0.5rem 0 0",
  },
  actions: { display: "grid", gap: "1rem", marginTop: "1.5rem" },
  error: { color: "#dc2626", fontSize: "0.875rem", fontWeight: 600, margin: 0 },
  link: {
    background: "var(--cs-primary-hover, #2563eb)",
    borderRadius: "0.375rem",
    color: "rgb(var(--slate-50, 255 255 255))",
    display: "block",
    fontSize: "0.875rem",
    fontWeight: 700,
    padding: "0.75rem 1rem",
    textAlign: "center",
    textDecoration: "none",
    width: "100%",
  },
};
function Qs() {
  return Zg || {};
}
function sy(i) {
  const u = Um(window.location.hostname, i, Qs().VITE_PLATFORM_URL),
    l = `${window.location.origin}${window.location.pathname}${window.location.search}`;
  if (Od(window.location.pathname) && Id(l)) {
    const d = new URL(u);
    return (d.searchParams.set("returnTo", l), d.toString());
  }
  return u;
}
function Cs(i) {
  if (i.role !== "student") return !1;
  const u = zn(i) ? "mock" : km(i),
    l = new URL(window.location.href);
  return Ad(l.searchParams) === u
    ? !1
    : (l.searchParams.set("sql", u),
      l.searchParams.delete("source"),
      window.location.replace(l.toString()),
      !0);
}
const ly = "signedOut";
function uy({
  appName: i,
  children: u,
  allowedRoles: l,
  navbarChildren: d,
  navbarLeading: p,
  navbarStyle: y,
  productionUrl: S,
  showNavbar: j = !0,
  laneMenuButton: k = !1,
  whileChecking: F,
  allowFallback: L = !1,
  allowTeacherStudentPreview: D = !1,
  prepare: O,
}) {
  const K = Ad(new URLSearchParams(window.location.search)),
    Q = R.useMemo(() => sy(S), [S]),
    M = R.useMemo(() => mn(window.location.hostname), []),
    B = R.useMemo(
      () => Zr(window.location.hostname, "https://issues.comp.school"),
      [],
    ),
    V = R.useMemo(() => {
      const Y = new URL(M);
      return (Y.searchParams.set("changeAvatar", "1"), Y.toString());
    }, [M]),
    ie = l ? l.join(",") : "",
    [J, ee] = R.useState(null),
    [ge, fe] = R.useState(!0),
    re = R.useRef(O);
  re.current = O;
  const ce = () => (re.current?.() ?? Promise.resolve()).catch(() => {}),
    [ke, ve] = R.useState(!1),
    [ne, Ce] = R.useState(null),
    [pe, Se] = R.useState(!1),
    [Ne, Ae] = R.useState(null),
    [he, N] = R.useState(null),
    [E, _] = R.useState(!1),
    [h, C] = R.useState(null),
    [G, te] = R.useState(null),
    ae = Tg(),
    le = R.useCallback((Y) => N(() => Y), []);
  async function we() {
    const Y = ne !== null;
    if (
      (zn(ne) && (await ah()),
      await fetch("/api/logout", {
        cache: "no-store",
        credentials: "same-origin",
        method: "POST",
      }).catch(() => {}),
      Ce(null),
      oy(),
      window.sessionStorage.removeItem(Ln),
      window.sessionStorage.removeItem(js),
      Se(!1),
      ve(!1),
      !Y)
    ) {
      window.location.assign(M);
      return;
    }
    const xe = new URL(M);
    (xe.searchParams.set(ly, "1"), window.location.assign(xe.toString()));
  }
  function ue(Y) {
    const xe = new URL(window.location.href);
    (xe.searchParams.set("sql", Y),
      xe.searchParams.delete("source"),
      xe.searchParams.delete("student"),
      window.location.assign(xe.toString()));
  }
  if (
    (R.useEffect(() => {
      let Y = !1,
        xe = !1;
      const qe = () => {
        xe = !0;
      };
      return (
        fetch("/api/session", {
          cache: "no-store",
          credentials: "same-origin",
          headers: { accept: "application/json", ...(L ? ay() : {}) },
        })
          .then(async (He) => {
            const Pe = await He.json().catch(() => null);
            if (Y) return;
            const Lt = L && Pe?.fallback === !0;
            if (
              (L && !Lt && window.sessionStorage.removeItem(Ln),
              He.ok &&
                Pe?.ok &&
                Pe.user &&
                (!l || l.includes(Pe.user.role) || xs(Pe.user, D)))
            ) {
              if (L && ks()) {
                (qe(), window.location.reload());
                return;
              }
              if (Cs(Pe.user)) {
                qe();
                return;
              }
              const Rt = L && zn(Pe.user);
              if (
                Rt &&
                Pe.user.role === "student" &&
                !(Pe.user.courses ?? ["j277"]).includes("j277")
              ) {
                (qe(), window.location.replace(M));
                return;
              }
              if (
                (Rt && (await oh(Pe.user)), Y || (Ss(Pe.user), await ce(), Y))
              )
                return;
              (ry(Pe.user), ee(null), Ce(Pe.user), Se(Rt), ve(!0));
              return;
            }
            He.status === 401 && Vs();
            const et = Cd();
            if (et && (!l || l.includes(et.role) || xs(et, D))) {
              if (L && ks()) {
                (qe(), window.location.reload());
                return;
              }
              if ((ee(null), Cs(et))) {
                qe();
                return;
              }
              if ((Ss(et), await ce(), Y)) return;
              (Ce(et), Se(L && zn(et)), ve(!0));
              return;
            }
            if (Lt) {
              if ((await ce(), Y)) return;
              (ee(null), Se(!0), ve(!0));
              return;
            }
            (ee(Pe?.message || null), Ce(null), ve(!1));
          })
          .catch(async () => {
            if (!Y) {
              const He = Cd();
              if (He && (!l || l.includes(He.role) || xs(He, D))) {
                if (L && ks()) {
                  (qe(), window.location.reload());
                  return;
                }
                if ((ee(null), Cs(He))) {
                  qe();
                  return;
                }
                if ((Ss(He), await ce(), Y)) return;
                (Ce(He), Se(L && zn(He)), ve(!0));
                return;
              }
              (ee("Unable to check platform access right now."),
                Ce(null),
                ve(!1));
            }
          })
          .finally(() => {
            !Y && !xe && fe(!1);
          }),
        () => {
          Y = !0;
        }
      );
    }, [ie, L, D]),
    !K)
  )
    return s.jsx("main", {
      style: st.main,
      children: s.jsxs("section", {
        style: st.panel,
        children: [
          s.jsx("h1", { style: st.title, children: "Database unavailable" }),
          s.jsx("p", {
            style: st.copy,
            children: "Choose Product, Mock, or Real to continue.",
          }),
          s.jsx("button", {
            style: st.link,
            onClick: () => ue("product"),
            children: "Open Product",
          }),
          s.jsx("button", {
            style: st.link,
            onClick: () => ue("mock"),
            children: "Open Mock",
          }),
          s.jsx("button", {
            style: st.link,
            onClick: () => ue("real"),
            children: "Open Real",
          }),
        ],
      }),
    });
  if (ge) return s.jsxs(s.Fragment, { children: [F, s.jsx(Dg, {})] });
  if (ke) {
    const Y = pe && !ne ? iy() : void 0,
      xe = ne?.role === "admin" || ne?.role === "teacher",
      qe = new URL(M);
    xe && qe.searchParams.set("sql", K);
    const He = {
        canChangeAvatar: ne?.role === "student" || !!Y,
        changeAvatarHref: Y ? zd(V, Y) : V,
        dataSource: xe ? K : void 0,
        feedbackWelcomeInstead: pe,
        onDataSourceChange: xe ? ue : void 0,
        onSignOut: we,
        profileAvatar: ne?.role === "student" ? (ne.avatar ?? Tm(ne.id)) : Y,
        profileName: ne?.name || "Anonymous",
        reportIssueHref: pe ? void 0 : B,
      },
      Pe = typeof p == "function",
      Lt = pe && Pe,
      et = !j && k && Pe,
      Rt = j || et,
      sr = Rt && (ne || pe) && !et && !(Lt && ae) ? G : null;
    return s.jsxs(s.Fragment, {
      children: [
        Rt && (ne || pe)
          ? s.jsx(Jg, {
              ...He,
              appName: i,
              backHref: qe.toString(),
              breadcrumbNavigation: E,
              contextLabel: Ne,
              hideAccountMenu: Pe,
              leading: typeof p == "function" ? p(He) : p,
              onBack: he ? () => he() : void 0,
              phoneBar: et ? "bare" : Lt ? "band" : void 0,
              phoneBarSlotRef: C,
              actionsSlotRef: te,
              style: y,
              children: d,
            })
          : null,
        pe && !ne ? s.jsx(Gg, { storageKey: Ln }) : null,
        zn(ne) ? s.jsx(Ug, {}) : null,
        s.jsx(ny.Provider, {
          value: pe,
          children: s.jsxs(ty.Provider, {
            value: ne,
            children: [
              s.jsx(Ih, { user: ne }),
              s.jsx(cg, { user: ne }),
              s.jsx(qg.Provider, {
                value: Ae,
                children: s.jsx(Yg.Provider, {
                  value: le,
                  children: s.jsx(Xg.Provider, {
                    value: _,
                    children: s.jsx(zg.Provider, {
                      value: h,
                      children: s.jsx(ey.Provider, { value: sr, children: u }),
                    }),
                  }),
                }),
              }),
            ],
          }),
        }),
      ],
    });
  }
  return s.jsx("main", {
    style: st.main,
    children: s.jsxs("section", {
      style: st.panel,
      children: [
        s.jsx(rf, {
          size: "small",
          style: { color: "rgb(var(--slate-900, 15 23 42))" },
        }),
        s.jsx("h1", { style: st.title, children: i }),
        s.jsx("p", {
          style: st.copy,
          children: "Open comp.school and sign in to continue.",
        }),
        s.jsxs("div", {
          style: st.actions,
          children: [
            J && s.jsx("p", { style: st.error, children: J }),
            s.jsx("a", {
              "aria-label": `Open comp.school to access ${i}`,
              href: Q,
              style: st.link,
              children: "Open comp.school",
            }),
          ],
        }),
      ],
    }),
  });
}
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const cy = (i) => i.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase(),
  af = (...i) =>
    i
      .filter((u, l, d) => !!u && u.trim() !== "" && d.indexOf(u) === l)
      .join(" ")
      .trim();
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ var dy = {
  xmlns: "http://www.w3.org/2000/svg",
  width: 24,
  height: 24,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 2,
  strokeLinecap: "round",
  strokeLinejoin: "round",
};
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const fy = R.forwardRef(
  (
    {
      color: i = "currentColor",
      size: u = 24,
      strokeWidth: l = 2,
      absoluteStrokeWidth: d,
      className: p = "",
      children: y,
      iconNode: S,
      ...j
    },
    k,
  ) =>
    R.createElement(
      "svg",
      {
        ref: k,
        ...dy,
        width: u,
        height: u,
        stroke: i,
        strokeWidth: d ? (Number(l) * 24) / Number(u) : l,
        className: af("lucide", p),
        ...j,
      },
      [
        ...S.map(([F, L]) => R.createElement(F, L)),
        ...(Array.isArray(y) ? y : [y]),
      ],
    ),
);
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const ar = (i, u) => {
  const l = R.forwardRef(({ className: d, ...p }, y) =>
    R.createElement(fy, {
      ref: y,
      iconNode: u,
      className: af(`lucide-${cy(i)}`, d),
      ...p,
    }),
  );
  return ((l.displayName = `${i}`), l);
};
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const py = ar("Crosshair", [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["line", { x1: "22", x2: "18", y1: "12", y2: "12", key: "l9bcsi" }],
  ["line", { x1: "6", x2: "2", y1: "12", y2: "12", key: "13hhkx" }],
  ["line", { x1: "12", x2: "12", y1: "6", y2: "2", key: "10w3f3" }],
  ["line", { x1: "12", x2: "12", y1: "22", y2: "18", key: "15g9kq" }],
]);
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const my = ar("FileText", [
  [
    "path",
    {
      d: "M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z",
      key: "1rqfz7",
    },
  ],
  ["path", { d: "M14 2v4a2 2 0 0 0 2 2h4", key: "tnqrlb" }],
  ["path", { d: "M10 9H8", key: "b1mrlr" }],
  ["path", { d: "M16 13H8", key: "t4e002" }],
  ["path", { d: "M16 17H8", key: "z1uh3a" }],
]);
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const hy = ar("GraduationCap", [
  [
    "path",
    {
      d: "M21.42 10.922a1 1 0 0 0-.019-1.838L12.83 5.18a2 2 0 0 0-1.66 0L2.6 9.08a1 1 0 0 0 0 1.832l8.57 3.908a2 2 0 0 0 1.66 0z",
      key: "j76jl0",
    },
  ],
  ["path", { d: "M22 10v6", key: "1lu8f3" }],
  ["path", { d: "M6 12.5V16a6 3 0 0 0 12 0v-3.5", key: "1r8lef" }],
]);
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const gy = ar("ListChecks", [
  ["path", { d: "m3 17 2 2 4-4", key: "1jhpwq" }],
  ["path", { d: "m3 7 2 2 4-4", key: "1obspn" }],
  ["path", { d: "M13 6h8", key: "15sg57" }],
  ["path", { d: "M13 12h8", key: "h98zly" }],
  ["path", { d: "M13 18h8", key: "oe0vm4" }],
]);
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const yy = ar("Trash2", [
  ["path", { d: "M3 6h18", key: "d0wm0j" }],
  ["path", { d: "M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6", key: "4alrt4" }],
  ["path", { d: "M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2", key: "v07s0e" }],
  ["line", { x1: "10", x2: "10", y1: "11", y2: "17", key: "1uufr5" }],
  ["line", { x1: "14", x2: "14", y1: "11", y2: "17", key: "xtxkd" }],
]);
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const vy = ar("X", [
    ["path", { d: "M18 6 6 18", key: "1bl5f8" }],
    ["path", { d: "m6 6 12 12", key: "d8bk6v" }],
  ]),
  wy = [
    {
      id: "1.1",
      name: "Systems architecture",
      menuName: "Systems architecture",
      paper: "paper-1",
    },
    {
      id: "1.2",
      name: "Memory and storage",
      menuName: "Memory and storage",
      paper: "paper-1",
    },
    {
      id: "1.3",
      name: "Computer networks, connections and protocols",
      menuName: "Networks and protocols",
      paper: "paper-1",
    },
    {
      id: "1.4",
      name: "Network security",
      menuName: "Network security",
      paper: "paper-1",
    },
    {
      id: "1.5",
      name: "Systems software",
      menuName: "Systems software",
      paper: "paper-1",
    },
    {
      id: "1.6",
      name: "Ethical, legal, cultural and environmental impacts",
      menuName: "Ethical, legal and environmental impacts",
      paper: "paper-1",
    },
    { id: "2.1", name: "Algorithms", menuName: "Algorithms", paper: "paper-2" },
    {
      id: "2.2",
      name: "Programming fundamentals",
      menuName: "Programming fundamentals",
      paper: "paper-2",
    },
    {
      id: "2.3",
      name: "Producing robust programs",
      menuName: "Producing robust programs",
      paper: "paper-2",
    },
    {
      id: "2.4",
      name: "Boolean logic",
      menuName: "Boolean logic",
      paper: "paper-2",
    },
    {
      id: "2.5",
      name: "Programming languages and IDEs",
      menuName: "Languages and IDEs",
      paper: "paper-2",
    },
  ],
  xy = [
    { id: "1.1.1", name: "Systems Architecture", paper: "paper-1" },
    { id: "1.1.2", name: "CPU Performance", paper: "paper-1" },
    { id: "1.1.3", name: "Embedded Systems", paper: "paper-1" },
    { id: "1.2.1", name: "Primary storage (Memory)", paper: "paper-1" },
    { id: "1.2.2", name: "Secondary storage", paper: "paper-1" },
    { id: "1.2.3", name: "Units", paper: "paper-1" },
    { id: "1.2.4", name: "Data storage", paper: "paper-1" },
    { id: "1.2.5", name: "Data storage: Numbers", paper: "paper-1" },
    { id: "1.2.6", name: "Data storage: Characters", paper: "paper-1" },
    { id: "1.2.7", name: "Data storage: Images", paper: "paper-1" },
    { id: "1.2.8", name: "Data storage: Sound", paper: "paper-1" },
    { id: "1.2.9", name: "Compression", paper: "paper-1" },
    {
      id: "1.2.10",
      name: "Data storage: Hex and binary arithmetic",
      paper: "paper-1",
    },
    { id: "1.3.1", name: "Networks and Topologies", paper: "paper-1" },
    {
      id: "1.3.2",
      name: "Wired and Wireless Networks, Protocols and Layers",
      paper: "paper-1",
    },
    { id: "1.4", name: "Network Security", paper: "paper-1" },
    {
      id: "1.4.2",
      name: "Identifying and preventing vulnerabilities (likely questions)",
      paper: "paper-1",
    },
    { id: "1.5.1", name: "Operating Systems", paper: "paper-1" },
    { id: "1.5.2", name: "Utility Software", paper: "paper-1" },
    {
      id: "1.6.1",
      name: "Ethical, Legal, Cultural and Environmental Impact",
      paper: "paper-1",
    },
    { id: "2.1.1", name: "Computational Thinking", paper: "paper-2" },
    {
      id: "2.1.2",
      name: "Designing, Creating and Refining Algorithms",
      paper: "paper-2",
    },
    { id: "2.1.3", name: "Searching and Sorting Algorithms", paper: "paper-2" },
    { id: "2.2.1", name: "Programming Fundamentals", paper: "paper-2" },
    {
      id: "2.2.3",
      name: "Additional Programming Techniques",
      paper: "paper-2",
    },
    { id: "2.3.2", name: "Testing", paper: "paper-2" },
    { id: "2.4.1", name: "Boolean Logic", paper: "paper-2" },
    { id: "2.5.1", name: "Languages", paper: "paper-2" },
    {
      id: "2.5.2",
      name: "The Integrated Development Environment (IDE)",
      paper: "paper-2",
    },
  ],
  ky = [
    {
      paperId: "J277-01-Specimen",
      sourceJsonFilename: "J27701_Computer_Systems_Specimen (2).json",
      sourceKind: "scanned",
      availability: { online: !0, selfAssess: !0, developerValidation: !0 },
      expectedQuestionCount: 29,
      expectedTotalMarks: 80,
      pdfPath:
        "data/pdf/j277/yearpapers/J27701_Computer_Systems_Specimen (2).pdf",
    },
    {
      paperId: "J277-01-2019-Practice",
      sourceJsonFilename: "J27701_Computer_Systems_Practice_2019 (1).json",
      sourceKind: "scanned",
      availability: { online: !0, selfAssess: !0, developerValidation: !0 },
      expectedQuestionCount: 29,
      expectedTotalMarks: 80,
      pdfPath:
        "data/pdf/j277/yearpapers/J27701_Computer_Systems_Practice_2019 (1).pdf",
    },
    {
      paperId: "J277-01-2022-June",
      sourceJsonFilename: "paper-1-2022-june.json",
      sourceKind: "scanned",
      availability: { online: !0, selfAssess: !0, developerValidation: !0 },
      expectedQuestionCount: 29,
      expectedTotalMarks: 80,
      pdfPath: "data/pdf/j277/yearpapers/J27701_Computer_Systems_June_2022.pdf",
    },
    {
      paperId: "J277-01-2023-June",
      sourceJsonFilename: "J27701_Computer_Systems_June_2023 (2).json",
      sourceKind: "scanned",
      availability: { online: !0, selfAssess: !0, developerValidation: !0 },
      expectedQuestionCount: 30,
      expectedTotalMarks: 80,
      pdfPath:
        "data/pdf/j277/yearpapers/J27701_Computer_Systems_June_2023 (2).pdf",
    },
    {
      paperId: "J277-01-2024-June",
      sourceJsonFilename: "J27701_Computer_systems_June_2024 (2).json",
      sourceKind: "scanned",
      availability: { online: !0, selfAssess: !0, developerValidation: !0 },
      expectedQuestionCount: 28,
      expectedTotalMarks: 80,
      pdfPath:
        "data/pdf/j277/yearpapers/J27701_Computer_systems_June_2024 (2).pdf",
    },
    {
      paperId: "J277-01-2025-June",
      sourceJsonFilename: "J27701_Computer_systems_June_2025 (1).json",
      sourceKind: "scanned",
      availability: { online: !0, selfAssess: !0, developerValidation: !0 },
      expectedQuestionCount: 27,
      expectedTotalMarks: 80,
      pdfPath:
        "data/pdf/j277/yearpapers/J27701_Computer_systems_June_2025 (1).pdf",
    },
    {
      paperId: "J277-01-2026-June",
      sourceJsonFilename: "J27701_Computer_systems_June_2026.json",
      sourceKind: "scanned",
      availability: { online: !0, selfAssess: !0, developerValidation: !0 },
      expectedQuestionCount: 35,
      expectedTotalMarks: 80,
      pdfPath: "data/pdf/j277/yearpapers/J27701_Computer_systems_June_2026.pdf",
    },
    {
      paperId: "J277-01-TeacherVariant-A",
      sourceJsonFilename: "J27701_Computer_Systems_TeacherVariant_A.json",
      sourceKind: "generated",
      availability: { online: !0, selfAssess: !1, developerValidation: !0 },
      expectedQuestionCount: 26,
      expectedTotalMarks: 80,
      pdfPath: null,
    },
    {
      paperId: "J277-01-TeacherVariant-B",
      sourceJsonFilename: "J27701_Computer_Systems_TeacherVariant_B.json",
      sourceKind: "generated",
      availability: { online: !0, selfAssess: !1, developerValidation: !0 },
      expectedQuestionCount: 26,
      expectedTotalMarks: 80,
      pdfPath: null,
    },
    {
      paperId: "J277-01-TeacherVariant-C",
      sourceJsonFilename: "J27701_Computer_Systems_TeacherVariant_C.json",
      sourceKind: "generated",
      availability: { online: !0, selfAssess: !1, developerValidation: !0 },
      expectedQuestionCount: 32,
      expectedTotalMarks: 80,
      pdfPath: null,
    },
    {
      paperId: "J277-01-TeacherVariant-D",
      sourceJsonFilename: "J27701_Computer_Systems_TeacherVariant_D.json",
      sourceKind: "generated",
      availability: { online: !0, selfAssess: !1, developerValidation: !0 },
      expectedQuestionCount: 23,
      expectedTotalMarks: 80,
      pdfPath: null,
    },
    {
      paperId: "J277-01-TeacherVariant-E",
      sourceJsonFilename: "J27701_Computer_Systems_TeacherVariant_E.json",
      sourceKind: "generated",
      availability: { online: !0, selfAssess: !1, developerValidation: !0 },
      expectedQuestionCount: 24,
      expectedTotalMarks: 80,
      pdfPath: null,
    },
    {
      paperId: "J277-02-Specimen",
      sourceJsonFilename: "paper-2-specimen.json",
      sourceKind: "scanned",
      availability: { online: !0, selfAssess: !0, developerValidation: !0 },
      expectedQuestionCount: 28,
      expectedTotalMarks: 80,
      pdfPath:
        "data/pdf/j277/yearpapers/J27702_Computational_thinking_algorithms_and_programming_Specimen (1).pdf",
    },
    {
      paperId: "J277-02-2019-Practice",
      sourceJsonFilename:
        "J27702_Computational_thinking_algorithms_and_programming_Practice_2019 (1).json",
      sourceKind: "scanned",
      availability: { online: !0, selfAssess: !0, developerValidation: !0 },
      expectedQuestionCount: 26,
      expectedTotalMarks: 80,
      pdfPath:
        "data/pdf/j277/yearpapers/J27702_Computational_thinking_algorithms_and_programming_Practice_2019 (1).pdf",
    },
    {
      paperId: "J277-02-2022-June",
      sourceJsonFilename:
        "J27702_Computational_thinking_algorithms_and_programming_June_2022 (3).json",
      sourceKind: "scanned",
      availability: { online: !0, selfAssess: !0, developerValidation: !0 },
      expectedQuestionCount: 26,
      expectedTotalMarks: 80,
      pdfPath:
        "data/pdf/j277/yearpapers/J27702_Computational_thinking_algorithms_and_programming_June_2022 (3).pdf",
    },
    {
      paperId: "J277-02-2023-June",
      sourceJsonFilename:
        "J27702_Computational_thinking_algorithms_and_programming_June_2023 (1).json",
      sourceKind: "scanned",
      availability: { online: !0, selfAssess: !0, developerValidation: !0 },
      expectedQuestionCount: 30,
      expectedTotalMarks: 80,
      pdfPath:
        "data/pdf/j277/yearpapers/J27702_Computational_thinking_algorithms_and_programming_June_2023 (1).pdf",
    },
    {
      paperId: "J277-02-2023-Practice",
      sourceJsonFilename:
        "J27702_Computational_thinking_algorithms_and_programming_Practice_2023 (2).json",
      sourceKind: "scanned",
      availability: { online: !0, selfAssess: !0, developerValidation: !0 },
      expectedQuestionCount: 29,
      expectedTotalMarks: 80,
      pdfPath:
        "data/pdf/j277/yearpapers/J27702_Computational_thinking_algorithms_and_programming_Practice_2023 (2).pdf",
    },
    {
      paperId: "J277-02-2024-June",
      sourceJsonFilename:
        "J27702_Computational_thinking_algorithms_and_programming_June_2024 (3).json",
      sourceKind: "scanned",
      availability: { online: !0, selfAssess: !0, developerValidation: !0 },
      expectedQuestionCount: 26,
      expectedTotalMarks: 80,
      pdfPath:
        "data/pdf/j277/yearpapers/J27702_Computational_thinking_algorithms_and_programming_June_2024 (3).pdf",
    },
    {
      paperId: "J277-02-2025-June",
      sourceJsonFilename:
        "J27702_Computational_thinking_algorithms_and_programming_June_2025 (5).json",
      sourceKind: "scanned",
      availability: { online: !0, selfAssess: !0, developerValidation: !0 },
      expectedQuestionCount: 29,
      expectedTotalMarks: 80,
      pdfPath:
        "data/pdf/j277/yearpapers/J27702_Computational_thinking_algorithms_and_programming_June_2025 (5).pdf",
    },
    {
      paperId: "J277-02-2026-June",
      sourceJsonFilename:
        "J27702_Computational_thinking_algorithms_and_programming_June_2026.json",
      sourceKind: "scanned",
      availability: { online: !0, selfAssess: !0, developerValidation: !0 },
      expectedQuestionCount: 29,
      expectedTotalMarks: 80,
      pdfPath:
        "data/pdf/j277/yearpapers/J27702_Computational_thinking_algorithms_and_programming_June_2026.pdf",
    },
    {
      paperId: "J277-02-Alpha",
      sourceJsonFilename:
        "J27702_Computational_thinking_algorithms_and_programming_Alpha.json",
      sourceKind: "generated",
      availability: { online: !0, selfAssess: !1, developerValidation: !0 },
      expectedQuestionCount: 26,
      expectedTotalMarks: 80,
      pdfPath: null,
    },
  ],
  Sy = { papers: ky },
  Cy = 120,
  by = 500,
  _y = { June: "June", Practice: "Practice", Specimen: "Specimen" };
function jy(i) {
  const u = i.replace(/^J277-0[12]-/, ""),
    l = u.match(/^(\d{4})-(\w+)$/);
  if (l) return `${_y[l[2]] ?? l[2]} ${l[1]}`;
  const d = u.match(/^TeacherVariant-([A-Z])$/);
  return d ? `Teacher variant ${d[1]}` : u.replace(/-/g, " ");
}
const Is = Sy.papers
  .filter((i) => i.availability?.online && /^J277-0[12]-/.test(i.paperId))
  .map((i) => ({
    paperId: i.paperId,
    paperNumber: i.paperId.startsWith("J277-01-") ? 1 : 2,
    label: jy(i.paperId),
  }))
  .sort(
    (i, u) => i.paperNumber - u.paperNumber || bd(u.paperId) - bd(i.paperId),
  );
function bd(i) {
  const u = i.match(/-(\d{4})-/)?.[1];
  return u
    ? Number(u) * 10 + (i.endsWith("-June") ? 1 : 0)
    : i.includes("Specimen")
      ? 1e3
      : 0;
}
const sf = wy.flatMap((i) => {
  const u = i.paper === "paper-1" ? 1 : 2;
  return [
    { code: i.id, name: i.menuName, paperNumber: u, topic: i.id },
    ...xy
      .filter((l) => l.id.startsWith(`${i.id}.`))
      .map((l) => ({ code: l.id, name: l.name, paperNumber: u, topic: i.id })),
  ];
});
function lf(i) {
  return sf.find((u) => u.code === i) ?? null;
}
function Ey(i) {
  return Is.find((u) => u.paperId === i) ?? null;
}
function Ay(i, u, l, d = null) {
  if (i === "topic" && d) {
    const p = lf(d);
    return p ? `${p.code} ${p.name}` : "Topic Drill";
  }
  if (i === "past-paper" && u) {
    const p = Ey(u);
    return p ? `Paper ${p.paperNumber} ${p.label}` : "Past paper";
  }
  return i === "any-past-paper"
    ? l
      ? `A Paper ${l} past paper`
      : "A past paper"
    : "";
}
const Py = 1440 * 60 * 1e3;
function Ty(i, u) {
  return Math.round(
    (Date.parse(`${i}T00:00:00Z`) - Date.parse(`${u}T00:00:00Z`)) / Py,
  );
}
function zy(i, u) {
  const l = Ty(i, u);
  return l === 0
    ? "Due today"
    : l === 1
      ? "Due tomorrow"
      : l > 1
        ? `Due in ${l} days`
        : l === -1
          ? "Overdue by 1 day"
          : `Overdue by ${-l} days`;
}
function _d(i = new Date()) {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: "Europe/London",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(i);
}
function jd(i) {
  return [...i].sort(
    (u, l) =>
      u.dueOn.localeCompare(l.dueOn) || u.createdAt.localeCompare(l.createdAt),
  );
}
const My = [
  {
    code: "1.1",
    paper: "1",
    name: "Systems architecture",
    keywords: ["cpu", "von neumann", "fetch execute", "embedded"],
  },
  {
    code: "1.2",
    paper: "1",
    name: "Memory and storage",
    keywords: ["ram", "rom", "binary", "hexadecimal", "compression", "units"],
  },
  {
    code: "1.3",
    paper: "1",
    name: "Networks and protocols",
    keywords: ["lan", "wan", "topology", "tcp", "internet"],
  },
  {
    code: "1.4",
    paper: "1",
    name: "Network security",
    keywords: ["malware", "phishing", "firewall", "encryption"],
  },
  {
    code: "1.5",
    paper: "1",
    name: "Systems software",
    keywords: ["operating system", "utility", "defragmentation"],
  },
  {
    code: "1.6",
    paper: "1",
    name: "Ethical, legal and environmental impacts",
    keywords: ["law", "privacy", "copyright", "ethics"],
  },
  {
    code: "2.1",
    paper: "2",
    name: "Algorithms",
    keywords: ["search", "sort", "trace table", "flowchart", "pseudocode"],
  },
  {
    code: "2.2",
    paper: "2",
    name: "Programming fundamentals",
    keywords: ["python", "variables", "loops", "arrays", "sql"],
  },
  {
    code: "2.3",
    paper: "2",
    name: "Producing robust programs",
    keywords: ["validation", "testing", "errors"],
  },
  {
    code: "2.4",
    paper: "2",
    name: "Boolean logic",
    keywords: ["logic gates", "truth table", "boolean"],
  },
  {
    code: "2.5",
    paper: "2",
    name: "Languages and IDEs",
    keywords: ["compiler", "interpreter", "translator"],
  },
];
function bs(i) {
  return i
    .toLowerCase()
    .replace(/[^a-z0-9.]+/g, " ")
    .trim();
}
function Ly(i, u, l = []) {
  const d = bs(i);
  if (!d) return 0;
  const p = bs(u);
  if (p.startsWith(d)) return 4;
  const y = p.split(" "),
    S = l.map(bs),
    j = S.flatMap((D) => D.split(" ")),
    k = d.split(" ");
  return k.every((D) => y.some((O) => O.startsWith(D)))
    ? 3
    : S.some((D) => D.startsWith(d))
      ? 2
      : k.every((D) => [...y, ...j].some((O) => O.startsWith(D)))
        ? 1
        : 0;
}
function Ry(i, u, l = 8) {
  return u
    .map((d, p) => ({ item: d, index: p, score: Ly(i, d.label, d.keywords) }))
    .filter((d) => d.score > 0)
    .sort((d, p) => p.score - d.score || d.index - p.index)
    .slice(0, l)
    .map((d) => d.item);
}
const Oy = new Map(My.map((i) => [i.code, i.keywords ?? []])),
  uf = sf.map((i) => ({
    ...i,
    label: `${i.code} ${i.name}`,
    keywords: [i.code, ...(i.code === i.topic ? (Oy.get(i.code) ?? []) : [])],
  })),
  Ny = uf.filter((i) => i.code === i.topic);
function Iy({
  className: i,
  inputClassName: u,
  labelClassName: l,
  onChange: d,
  value: p,
}) {
  const y = R.useId(),
    S = `${y}-topics`,
    j = R.useRef(null),
    k = p ? lf(p) : null,
    [F, L] = R.useState(k ? `${k.code} ${k.name}` : ""),
    [D, O] = R.useState(!1),
    [K, Q] = R.useState(0),
    M = R.useMemo(() => {
      const J = F.trim();
      return !J || (k && J === `${k.code} ${k.name}`) ? Ny : Ry(J, uf, 8);
    }, [F, k]);
  function B(J) {
    (d(J.code), L(J.label), O(!1));
  }
  function V() {
    (d(""), L(""), Q(0), O(!0), j.current?.focus());
  }
  function ie(J) {
    J.key === "ArrowDown"
      ? (J.preventDefault(), O(!0), Q((ee) => Math.min(ee + 1, M.length - 1)))
      : J.key === "ArrowUp"
        ? (J.preventDefault(), Q((ee) => Math.max(ee - 1, 0)))
        : J.key === "Enter" && D && M[K]
          ? (J.preventDefault(), B(M[K]))
          : J.key === "Escape" && D && (J.preventDefault(), O(!1));
  }
  return s.jsxs("div", {
    className: `relative ${i ?? ""}`,
    "data-topic-picker": "",
    children: [
      s.jsx("label", {
        className: l,
        htmlFor: `${y}-input`,
        children: "Topic",
      }),
      s.jsxs("div", {
        className: "relative",
        children: [
          s.jsx("input", {
            "aria-activedescendant": D && M[K] ? `${S}-${M[K].code}` : void 0,
            "aria-autocomplete": "list",
            "aria-controls": S,
            "aria-expanded": D,
            autoComplete: "off",
            className: `${u} pr-12`,
            id: `${y}-input`,
            onBlur: () => window.setTimeout(() => O(!1), 120),
            onChange: (J) => {
              (L(J.target.value), Q(0), O(!0), p && d(""));
            },
            onFocus: () => O(!0),
            onKeyDown: ie,
            placeholder: "Type a topic, a code or a keyword",
            ref: j,
            role: "combobox",
            spellCheck: !1,
            value: F,
          }),
          F
            ? s.jsx("button", {
                "aria-label": "Clear the topic",
                className:
                  "absolute inset-y-0 right-1 my-auto flex h-10 w-10 items-center justify-center rounded-md text-slate-500 hover:text-slate-950 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-600",
                "data-topic-clear": "",
                onClick: V,
                onMouseDown: (J) => J.preventDefault(),
                type: "button",
                children: s.jsx(vy, {
                  "aria-hidden": "true",
                  className: "h-4 w-4",
                }),
              })
            : null,
        ],
      }),
      D
        ? s.jsx("ul", {
            "aria-label": "Topics",
            className:
              "absolute left-0 right-0 z-20 mt-1 max-h-80 overflow-y-auto rounded-lg border border-slate-300 bg-white py-1 shadow-lg",
            id: S,
            role: "listbox",
            children:
              M.length === 0
                ? s.jsxs("li", {
                    className: "px-3 py-2.5 text-sm text-slate-600",
                    role: "presentation",
                    children: ["No topic matches “", F.trim(), "”."],
                  })
                : M.map((J, ee) =>
                    s.jsxs(
                      "li",
                      {
                        "aria-selected": ee === K,
                        className: `flex cursor-pointer items-baseline gap-3 px-3 py-2.5 ${ee === K ? "bg-slate-100" : ""}`,
                        "data-topic-option": J.code,
                        id: `${S}-${J.code}`,
                        onMouseDown: (ge) => ge.preventDefault(),
                        onClick: () => B(J),
                        onMouseEnter: () => Q(ee),
                        role: "option",
                        children: [
                          s.jsx("span", {
                            className:
                              "w-12 shrink-0 font-semibold tabular-nums text-slate-950",
                            children: J.code,
                          }),
                          s.jsx("span", {
                            className:
                              "min-w-0 flex-1 text-slate-950 [overflow-wrap:anywhere]",
                            children: J.name,
                          }),
                          s.jsxs("span", {
                            className: "shrink-0 text-xs text-slate-600",
                            children: ["Paper ", J.paperNumber],
                          }),
                        ],
                      },
                      J.code,
                    ),
                  ),
          })
        : null,
    ],
  });
}
const Dy = [
    { value: "past-paper", label: "Past paper" },
    { value: "any-past-paper", label: "Any past paper" },
    { value: "topic", label: "Topic" },
    { value: "task", label: "Task" },
    { value: "link", label: "Link" },
  ],
  Uy = new Intl.DateTimeFormat("en-GB", {
    weekday: "short",
    day: "numeric",
    month: "short",
    timeZone: "UTC",
  });
function $y(i, u) {
  const l = new Date(`${i}T00:00:00Z`);
  return (l.setUTCDate(l.getUTCDate() + u), l.toISOString().slice(0, 10));
}
function Fy() {
  const i = new URLSearchParams(window.location.search).get("sql");
  return i === "product" || i === "mock" || i === "real" ? i : "real";
}
const pn =
    "mt-1 block w-full min-w-0 rounded-lg border border-slate-300 bg-white px-3 py-2.5 text-base text-slate-950 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-600",
  Bt = "block text-sm font-semibold text-slate-700";
function Wy() {
  const i = `/api/homework?sql=${encodeURIComponent(Fy())}`,
    [u, l] = R.useState([]),
    [d, p] = R.useState([]),
    [y, S] = R.useState(() => _d()),
    [j, k] = R.useState(!0),
    [F, L] = R.useState(!1),
    [D, O] = R.useState(""),
    [K, Q] = R.useState(""),
    [M, B] = R.useState("past-paper"),
    [V, ie] = R.useState(Is[0]?.paperId ?? ""),
    [J, ee] = R.useState(""),
    [ge, fe] = R.useState(""),
    [re, ce] = R.useState(""),
    [ke, ve] = R.useState(""),
    [ne, Ce] = R.useState(() => $y(_d(), 7)),
    [pe, Se] = R.useState("");
  R.useEffect(() => {
    let E = !1;
    return (
      fetch(i, {
        cache: "no-store",
        credentials: "same-origin",
        headers: { accept: "application/json" },
      })
        .then(async (_) => {
          const h = await _.json().catch(() => null);
          if (!_.ok || !h?.ok)
            throw new Error(h?.message || "Homework could not be loaded.");
          if (E) return;
          const C = h.classes ?? [];
          (l(C),
            p(jd(h.homework ?? [])),
            h.today && S(h.today),
            Q((G) => (C.some((te) => te.id === G) ? G : (C[0]?.id ?? ""))));
        })
        .catch((_) => {
          E ||
            O(_ instanceof Error ? _.message : "Homework could not be loaded.");
        })
        .finally(() => {
          E || k(!1);
        }),
      () => {
        E = !0;
      }
    );
  }, [i]);
  const Ne = R.useMemo(
      () =>
        Ay(
          M,
          M === "past-paper" ? V : null,
          J ? Number(J) : null,
          (M === "topic" && ge) || null,
        ),
      [M, V, J, ge],
    ),
    Ae = R.useMemo(
      () =>
        u.map((E) => ({
          item: E,
          homework: d.filter((_) => _.classId === E.id),
        })),
      [u, d],
    );
  async function he(E) {
    (E.preventDefault(), L(!0), O(""));
    try {
      const _ = await fetch(i, {
          method: "POST",
          cache: "no-store",
          credentials: "same-origin",
          headers: {
            accept: "application/json",
            "content-type": "application/json",
          },
          body: JSON.stringify({
            classId: K,
            kind: M,
            paperId: V,
            paperNumber: J || null,
            topicCode: ge,
            url: re,
            title: ke,
            dueOn: ne,
            note: pe,
          }),
        }),
        h = await _.json().catch(() => null);
      if (!_.ok || !h?.ok || !h.homework) {
        O(h?.message || "The homework could not be saved.");
        return;
      }
      (p((C) => jd([...C, h.homework])),
        ve(""),
        ce(""),
        Se(""),
        O(`Set for ${h.homework.classCode}.`));
    } catch {
      O("The homework could not be saved.");
    } finally {
      L(!1);
    }
  }
  async function N(E) {
    if (
      (O(""),
      !(
        await fetch(`${i}&id=${encodeURIComponent(E.id)}`, {
          method: "DELETE",
          cache: "no-store",
          credentials: "same-origin",
          headers: { accept: "application/json" },
        }).catch(() => null)
      )?.ok)
    ) {
      O("The homework could not be removed.");
      return;
    }
    p((h) => h.filter((C) => C.id !== E.id));
  }
  return s.jsxs("main", {
    className: "mx-auto w-full max-w-3xl px-4 py-6 sm:px-6 sm:py-8",
    "data-teacher-homework": "",
    children: [
      s.jsx("h1", {
        className: "text-3xl font-bold text-slate-950 sm:text-4xl",
        id: "homework-page-heading",
        children: "Homework",
      }),
      j
        ? s.jsx("p", {
            className: "mt-6 text-sm text-slate-600",
            role: "status",
            children: "Loading…",
          })
        : null,
      !j && u.length === 0 && !D
        ? s.jsx("p", {
            className: "mt-6 text-slate-700",
            children: "You have no J277 classes in this database.",
          })
        : null,
      u.length > 0
        ? s.jsxs("form", {
            "aria-labelledby": "homework-page-heading",
            className:
              "mt-6 grid gap-4 rounded-xl border border-slate-200 bg-white p-4 shadow-sm sm:grid-cols-2 sm:p-5",
            "data-homework-form": "",
            onSubmit: he,
            children: [
              s.jsxs("label", {
                className: Bt,
                children: [
                  "Class",
                  s.jsx("select", {
                    className: pn,
                    name: "classId",
                    onChange: (E) => Q(E.target.value),
                    value: K,
                    children: u.map((E) =>
                      s.jsx("option", { value: E.id, children: E.code }, E.id),
                    ),
                  }),
                ],
              }),
              s.jsxs("label", {
                className: Bt,
                children: [
                  "Due",
                  s.jsx("input", {
                    className: pn,
                    min: y,
                    name: "dueOn",
                    onChange: (E) => Ce(E.target.value),
                    required: !0,
                    type: "date",
                    value: ne,
                  }),
                ],
              }),
              s.jsxs("div", {
                className: "sm:col-span-2",
                children: [
                  s.jsx("span", {
                    className: Bt,
                    id: "homework-kind-label",
                    children: "Task",
                  }),
                  s.jsx("div", {
                    "aria-labelledby": "homework-kind-label",
                    className:
                      "mt-1 inline-grid w-full grid-cols-3 rounded-xl border border-slate-300 bg-slate-100 p-1 sm:w-auto sm:grid-cols-5",
                    role: "radiogroup",
                    children: Dy.map((E) =>
                      s.jsx(
                        "button",
                        {
                          "aria-checked": M === E.value,
                          className: `min-h-11 rounded-lg px-3 py-2 text-sm font-semibold transition focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-600 ${M === E.value ? "bg-slate-950 text-white shadow-sm" : "text-slate-700 hover:bg-white"}`,
                          "data-homework-kind-option": E.value,
                          onClick: () => B(E.value),
                          role: "radio",
                          type: "button",
                          children: E.label,
                        },
                        E.value,
                      ),
                    ),
                  }),
                ],
              }),
              M === "past-paper"
                ? s.jsxs("label", {
                    className: `${Bt} sm:col-span-2`,
                    children: [
                      "Paper",
                      s.jsx("select", {
                        className: pn,
                        name: "paperId",
                        onChange: (E) => ie(E.target.value),
                        value: V,
                        children: [1, 2].map((E) =>
                          s.jsx(
                            "optgroup",
                            {
                              label: `Paper ${E}`,
                              children: Is.filter(
                                (_) => _.paperNumber === E,
                              ).map((_) =>
                                s.jsx(
                                  "option",
                                  {
                                    value: _.paperId,
                                    children: `Paper ${E} ${_.label}`,
                                  },
                                  _.paperId,
                                ),
                              ),
                            },
                            E,
                          ),
                        ),
                      }),
                    ],
                  })
                : null,
              M === "any-past-paper"
                ? s.jsxs("label", {
                    className: `${Bt} sm:col-span-2`,
                    children: [
                      "Paper",
                      s.jsxs("select", {
                        className: pn,
                        name: "paperNumber",
                        onChange: (E) => ee(E.target.value),
                        value: J,
                        children: [
                          s.jsx("option", {
                            value: "",
                            children: "Paper 1 or Paper 2",
                          }),
                          s.jsx("option", { value: "1", children: "Paper 1" }),
                          s.jsx("option", { value: "2", children: "Paper 2" }),
                        ],
                      }),
                    ],
                  })
                : null,
              M === "topic"
                ? s.jsx(Iy, {
                    className: "sm:col-span-2",
                    inputClassName: pn,
                    labelClassName: Bt,
                    onChange: fe,
                    value: ge,
                  })
                : null,
              M === "link"
                ? s.jsxs("label", {
                    className: `${Bt} sm:col-span-2`,
                    children: [
                      "Link",
                      s.jsx("input", {
                        className: pn,
                        inputMode: "url",
                        name: "url",
                        onChange: (E) => ce(E.target.value),
                        placeholder: "https://",
                        required: !0,
                        type: "url",
                        value: re,
                      }),
                    ],
                  })
                : null,
              s.jsxs("label", {
                className: `${Bt} sm:col-span-2`,
                children: [
                  "Title",
                  s.jsx("input", {
                    className: pn,
                    maxLength: Cy,
                    name: "title",
                    onChange: (E) => ve(E.target.value),
                    placeholder:
                      M === "task" ? "Make notes on 1.2.4 Data storage" : Ne,
                    required: M === "link" || M === "task",
                    value: ke,
                  }),
                ],
              }),
              s.jsxs("label", {
                className: `${Bt} sm:col-span-2`,
                children: [
                  "Note",
                  s.jsx("textarea", {
                    className: `${pn} min-h-20`,
                    maxLength: by,
                    name: "note",
                    onChange: (E) => Se(E.target.value),
                    value: pe,
                  }),
                ],
              }),
              s.jsx("div", {
                className: "sm:col-span-2",
                children: s.jsx("button", {
                  className:
                    "min-h-11 rounded-lg bg-slate-950 px-5 py-2.5 text-sm font-semibold text-white hover:bg-slate-800 disabled:bg-slate-400",
                  disabled: F || !K || (M === "topic" && !ge),
                  type: "submit",
                  children: F ? "Setting…" : "Set homework",
                }),
              }),
            ],
          })
        : null,
      D
        ? s.jsx("p", {
            className: "mt-4 text-sm font-semibold text-slate-700",
            role: "status",
            children: D,
          })
        : null,
      Ae.filter((E) => E.homework.length > 0).map((E) =>
        s.jsxs(
          "section",
          {
            "aria-label": `${E.item.code} homework`,
            className: "mt-8",
            "data-homework-class": E.item.code,
            children: [
              s.jsx("h2", {
                className: "text-lg font-bold text-slate-950",
                children: E.item.code,
              }),
              s.jsx("ul", {
                className: "mt-3 rounded-xl border border-slate-200 bg-white",
                children: E.homework.map((_) => {
                  const h =
                    _.kind === "link"
                      ? my
                      : _.kind === "topic"
                        ? py
                        : _.kind === "task"
                          ? gy
                          : hy;
                  return s.jsxs(
                    "li",
                    {
                      className:
                        "flex items-center gap-3 border-slate-200 px-4 py-3 [&+&]:border-t",
                      "data-homework-row": _.id,
                      children: [
                        s.jsx(h, {
                          "aria-hidden": "true",
                          className: "h-5 w-5 shrink-0 text-slate-500",
                        }),
                        s.jsxs("span", {
                          className: "min-w-0 flex-1",
                          children: [
                            s.jsx("span", {
                              className:
                                "block font-semibold text-slate-950 [overflow-wrap:anywhere]",
                              children: _.title,
                            }),
                            s.jsxs("span", {
                              className: "block text-sm text-slate-600",
                              children: [
                                Uy.format(new Date(`${_.dueOn}T00:00:00Z`)),
                                " · ",
                                zy(_.dueOn, y),
                              ],
                            }),
                          ],
                        }),
                        s.jsx("button", {
                          "aria-label": `Remove ${_.title} from ${E.item.code}`,
                          className:
                            "flex h-11 w-11 shrink-0 items-center justify-center rounded-lg text-slate-500 hover:bg-slate-100 hover:text-red-700 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-600",
                          "data-homework-remove": _.id,
                          onClick: () => void N(_),
                          type: "button",
                          children: s.jsx(yy, {
                            "aria-hidden": "true",
                            className: "h-4 w-4",
                          }),
                        }),
                      ],
                    },
                    _.id,
                  );
                }),
              }),
            ],
          },
          E.item.id,
        ),
      ),
    ],
  });
}
gm.createRoot(document.getElementById("root")).render(
  s.jsx(um.StrictMode, {
    children: s.jsx(uy, {
      appName: "Homework",
      allowedRoles: ["admin", "teacher"],
      productionUrl: "https://homework.comp.school",
      children: s.jsx(Wy, {}),
    }),
  }),
);
