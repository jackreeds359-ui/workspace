import {
  W as J,
  Y as Z,
  Z as ce,
  $ as F,
  a0 as G,
  r as f,
  a1 as ne,
  a2 as le,
  j as e,
  a3 as ie,
  a4 as re,
  a5 as de,
  a6 as oe,
  a7 as he,
  a8 as ue,
  a9 as K,
  e as me,
  X as q,
  aa as xe,
  ab as pe,
  ac as je,
  ad as we,
  ae as X,
  af as ee,
  w as ge,
  ag as fe,
  ah as be,
  ai as Ne,
  aj as ke,
  ak as ve,
  al as ye,
} from "./index-CHiQZc8e.js";
const M = 1200,
  L = 56,
  O = "#17203a",
  $e = "#5a6585",
  Q = "#2346c8",
  Ce = "#1d7a4a",
  Se = "#a8501a",
  Re = "#d3d9e6",
  S = 'ui-rounded, "Segoe UI", system-ui, sans-serif',
  B = 'ui-monospace, Consolas, "Courier New", monospace';
function Te(c, s, t) {
  const a = [];
  for (const l of s.split(/\n/u)) {
    let n = "";
    for (const x of l.split(/\s+/u).filter(Boolean)) {
      const i = n ? `${n} ${x}` : x;
      c.measureText(i).width > t && n ? (a.push(n), (n = x)) : (n = i);
    }
    a.push(n);
  }
  return a;
}
const A = (c) => c.replace(/^Student /u, "");
function Ee(c, s, t, a, l = new Date()) {
  const n = [],
    x = M - L * 2;
  let i = 0;
  const r = (h, d, p, b) => {
    c.font = d;
    for (const k of Te(c, h, x))
      (n.push({
        kind: "text",
        text: k,
        font: d,
        color: p,
        x: L,
        y: i + b * 0.78,
      }),
        (i += b));
  };
  (n.push({ kind: "rect", x: 0, y: 0, width: M, height: 150, color: Q }),
    n.push({
      kind: "text",
      text: s.save.heading,
      font: `700 16px ${B}`,
      color: "#c9d4ff",
      x: L,
      y: 52,
    }),
    n.push({
      kind: "text",
      text: `${a.name.trim()}${a.className.trim() ? `  ·  ${a.className.trim()}` : ""}`,
      font: `800 40px ${S}`,
      color: "#ffffff",
      x: L,
      y: 100,
    }),
    n.push({
      kind: "text",
      text: `${s.save.sources}  ·  ${l.toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric" })}`,
      font: `400 18px ${S}`,
      color: "#dfe6ff",
      x: L,
      y: 132,
    }),
    (i = 182));
  let u = 0,
    g = 0;
  for (const h of s.rounds) {
    const d = t[h.id] ?? J(h);
    if ((r(h.title, `800 28px ${S}`, O, 36), !d.checked)) {
      (r("Not attempted", `400 18px ${S}`, Se, 26), (i += 20));
      continue;
    }
    const p = Z(h, d);
    ((u += p.total), (g += p.max));
    const b = new Map(h.exemplars.map((m) => [m.id, m])),
      k = d.order.map((m) => A(b.get(m)?.label ?? m)).join(" > "),
      y = ce(h)
        .map((m) => A(b.get(m)?.label ?? m))
        .join(" > ");
    (r(
      `My ranking: ${k}  |  Pearson: ${y}  |  Crit score: ${p.total}/${p.max}`,
      `700 17px ${B}`,
      Q,
      26,
    ),
      r(
        `${h.scale.kind === "band" ? "Band" : "Mark"} guesses: ${h.exemplars.map((m) => `${A(m.label)} ${F(h, d.guesses[m.id])} (real ${F(h, G(h, m))})`).join(" | ")}`,
        `500 16px ${B}`,
        $e,
        26,
      ),
      (i += 10));
    const $ = (m, N) => {
      (r(m, `700 17px ${S}`, O, 24),
        r(N.trim() || "(blank)", `400 18px ${S}`, O, 27),
        (i += 8));
    };
    ($(h.firstQuestion, d.first),
      $(h.secondQuestion, d.second),
      h.upgrade &&
        $(
          `Upgrade challenge, Student ${h.upgrade.student} rewritten to Band 4:`,
          d.upgrade,
        ),
      (i += 10),
      n.push({ kind: "rect", x: L, y: i, width: x, height: 2, color: Re }),
      (i += 24));
  }
  return (
    r(s.save.targetLabel, `800 24px ${S}`, O, 32),
    r(a.target.trim() || "(blank)", `400 19px ${S}`, O, 28),
    (i += 24),
    r(`Total crit score: ${u} / ${g || "-"}`, `700 18px ${B}`, Ce, 26),
    (i += 36),
    { ops: n, height: Math.ceil(i) }
  );
}
async function Pe(c, s, t) {
  const a = document.createElement("canvas"),
    l = a.getContext("2d");
  if (!l) return null;
  const { ops: n, height: x } = Ee(l, c, s, t);
  ((a.width = M), (a.height = x));
  const i = a.getContext("2d");
  if (!i) return null;
  ((i.fillStyle = "#ffffff"), i.fillRect(0, 0, M, x));
  for (const r of n)
    r.kind === "rect"
      ? ((i.fillStyle = r.color), i.fillRect(r.x, r.y, r.width, r.height))
      : ((i.font = r.font),
        (i.fillStyle = r.color),
        i.fillText(r.text, r.x, r.y));
  return new Promise((r) => a.toBlob((u) => r(u), "image/png"));
}
function De(c, s) {
  const t =
    s
      .trim()
      .replace(/[^a-z0-9]+/giu, "-")
      .replace(/^-|-$/gu, "") || "student";
  return `${c.save.filePrefix}-${t}.png`;
}
async function Le(c, s, t) {
  const a = await Pe(c, s, t);
  if (!a) return !1;
  const l = URL.createObjectURL(a),
    n = document.createElement("a");
  return (
    (n.href = l),
    (n.download = De(c, t.name)),
    document.body.append(n),
    n.click(),
    n.remove(),
    window.setTimeout(() => URL.revokeObjectURL(l), 4e3),
    !0
  );
}
function Oe({ source: c, round: s, exemplar: t }) {
  const [a, l] = f.useState("idle"),
    n = t.document;
  if (!n || !c.document) return null;
  const x = c.document.bind(c),
    i = n.endsWith(".pdf") ? "pdf" : "docx",
    r = `${t.label}, ${s.step} (Pearson exemplar).${i}`,
    u = async () => {
      l("working");
      const g = await x(n).catch(() => null);
      if (!g) {
        l("failed");
        return;
      }
      const h = URL.createObjectURL(g),
        d = document.createElement("a");
      ((d.href = h),
        (d.download = r),
        document.body.append(d),
        d.click(),
        d.remove(),
        window.setTimeout(() => URL.revokeObjectURL(h), 1e3),
        l("idle"));
    };
  return e.jsxs("p", {
    className: "cw-document",
    children: [
      e.jsxs("button", {
        type: "button",
        className: "cw-button-ghost",
        "data-crit-document": t.id,
        "aria-label": `Download ${t.label}'s work (.${i})`,
        disabled: a === "working",
        onClick: () => void u(),
        children: [
          e.jsx(ge, { "aria-hidden": "true", className: "h-5 w-5" }),
          a === "working" ? "Downloading..." : `Download .${i}`,
        ],
      }),
      a === "failed"
        ? e.jsx("span", { role: "status", children: "Not available" })
        : null,
    ],
  });
}
function R({ value: c }) {
  return e.jsx(e.Fragment, {
    children: c.map((s, t) =>
      typeof s == "string"
        ? e.jsx(f.Fragment, { children: s }, t)
        : "b" in s
          ? e.jsx("strong", { children: s.b }, t)
          : "mark" in s
            ? e.jsx("mark", { children: s.mark }, t)
            : e.jsx("em", { children: s.em }, t),
    ),
  });
}
function Fe({ line: c, band: s }) {
  const t = ye[s - 1] ?? [];
  if (!t.length) return e.jsx(e.Fragment, { children: c });
  const a = new RegExp(
    `\\b(${t.map((l) => l.replace(/[.*+?^${}()|[\]\\]/gu, "\\$&")).join("|")})\\b`,
    "gu",
  );
  return e.jsx(e.Fragment, {
    children: c
      .split(a)
      .map((l, n) =>
        n % 2
          ? e.jsx("strong", { children: l }, n)
          : e.jsx(f.Fragment, { children: l }, n),
      ),
  });
}
function se(c, s) {
  const [t, a] = f.useState(void 0);
  return (
    f.useEffect(() => {
      let l = !0;
      return (
        a(void 0),
        c.image(s).then(
          (n) => {
            l && a(n);
          },
          () => {
            l && a(null);
          },
        ),
        () => {
          l = !1;
        }
      );
    }, [c, s]),
    t
  );
}
function Be({ source: c, image: s, onOpen: t }) {
  const a = se(c, s.key);
  return a === void 0
    ? e.jsx("div", {
        className: "cw-shot cw-shot-wait",
        "aria-label": `${s.alt}, loading`,
        role: "img",
      })
    : a === null
      ? e.jsx("div", {
          className: "cw-shot cw-shot-missing",
          role: "img",
          "aria-label": `${s.alt}, not available`,
          children: e.jsx(q, { "aria-hidden": "true", className: "h-6 w-6" }),
        })
      : e.jsxs("button", {
          type: "button",
          className: "cw-shot",
          onClick: t,
          "aria-label": `Open ${s.alt}`,
          children: [
            e.jsx("img", {
              src: a,
              alt: s.alt,
              draggable: !1,
              loading: "lazy",
            }),
            s.caption
              ? e.jsx("span", {
                  className: "cw-shot-caption",
                  children: s.caption,
                })
              : null,
          ],
        });
}
function Me({ source: c, images: s, index: t, onIndex: a, onClose: l }) {
  const n = s[t],
    x = se(c, n.key),
    i = f.useCallback(
      (r) => a((t + r + s.length) % s.length),
      [s.length, t, a],
    );
  return (
    f.useEffect(() => {
      const r = (u) => {
        (u.key === "Escape" && l(),
          u.key === "ArrowLeft" && i(-1),
          u.key === "ArrowRight" && i(1));
      };
      return (
        window.addEventListener("keydown", r),
        () => window.removeEventListener("keydown", r)
      );
    }, [l, i]),
    e.jsxs("div", {
      className: "cw-zoom",
      role: "dialog",
      "aria-modal": "true",
      "aria-label": n.alt,
      children: [
        e.jsxs("div", {
          className: "cw-zoom-bar",
          children: [
            s.length > 1
              ? e.jsx("button", {
                  type: "button",
                  className: "cw-icon",
                  "aria-label": "Previous",
                  onClick: () => i(-1),
                  children: e.jsx(ke, {
                    "aria-hidden": "true",
                    className: "h-6 w-6",
                  }),
                })
              : null,
            e.jsxs("span", {
              className: "cw-zoom-caption",
              children: [n.caption ? `${n.alt}  ` : "", t + 1, " / ", s.length],
            }),
            s.length > 1
              ? e.jsx("button", {
                  type: "button",
                  className: "cw-icon",
                  "aria-label": "Next",
                  onClick: () => i(1),
                  children: e.jsx(ve, {
                    "aria-hidden": "true",
                    className: "h-6 w-6",
                  }),
                })
              : null,
            e.jsx("button", {
              type: "button",
              className: "cw-icon",
              "aria-label": "Close",
              onClick: l,
              autoFocus: !0,
              children: e.jsx(q, {
                "aria-hidden": "true",
                className: "h-6 w-6",
              }),
            }),
          ],
        }),
        x
          ? e.jsx("img", { src: x, alt: n.alt })
          : e.jsx("p", {
              className: "cw-zoom-wait",
              children: x === null ? "Not available" : "Loading...",
            }),
      ],
    })
  );
}
function U({ source: c, round: s, exemplar: t, onOpen: a }) {
  return e.jsxs("div", {
    className: "cw-body",
    children: [
      t.images
        ? e.jsx("div", {
            className: "cw-shots",
            children: t.images.map((l, n) =>
              e.jsx(
                Be,
                { source: c, image: l, onOpen: () => a(t.images ?? [], n) },
                l.key,
              ),
            ),
          })
        : null,
      t.parts || t.text
        ? e.jsxs("div", {
            className: "cw-text",
            "data-tall": s.scale.kind === "mark" ? "true" : void 0,
            tabIndex: 0,
            role: "region",
            "aria-label": `${t.label}'s work`,
            children: [
              t.parts?.map((l, n) =>
                e.jsxs(
                  f.Fragment,
                  {
                    children: [
                      l.heading ? e.jsx("h4", { children: l.heading }) : null,
                      e.jsx("p", { children: l.text }),
                    ],
                  },
                  n,
                ),
              ),
              t.text
                ?.split(/\n+/u)
                .map((l, n) => e.jsx("p", { children: l }, `t${n}`)),
            ],
          })
        : null,
    ],
  });
}
function I({ exemplar: c }) {
  return e.jsx("span", {
    className: "cw-disc",
    "aria-hidden": "true",
    "data-crit-letter": "",
    children: X(c),
  });
}
function H({ exemplar: c }) {
  return e.jsx("p", {
    className: "cw-excerpt",
    "data-crit-excerpt": c.id,
    children: c.excerpt,
  });
}
function V({ blocks: c }) {
  return e.jsx(e.Fragment, {
    children: c.map((s, t) =>
      "p" in s
        ? e.jsx("p", { children: e.jsx(R, { value: s.p }) }, t)
        : e.jsx(
            "ul",
            {
              children: s.ul.map((a, l) =>
                e.jsx("li", { children: e.jsx(R, { value: a }) }, l),
              ),
            },
            t,
          ),
    ),
  });
}
const We = "(min-width: 1024px)";
function Ae() {
  const c = () =>
      typeof window < "u" && typeof window.matchMedia == "function"
        ? window.matchMedia(We)
        : null,
    [s, t] = f.useState(() => c()?.matches ?? !1);
  return (
    f.useEffect(() => {
      const a = c();
      if (!a) return;
      const l = () => t(a.matches);
      return (
        l(),
        a.addEventListener?.("change", l),
        () => a.removeEventListener?.("change", l)
      );
    }, []),
    s
  );
}
function Ue({ round: c, exemplar: s, value: t, disabled: a, onChange: l }) {
  if (c.scale.kind === "band")
    return e.jsx("div", {
      className: "cw-guess",
      children: e.jsx("div", {
        className: "cw-bands",
        role: "radiogroup",
        "aria-label": `${s.label}'s band`,
        children: Array.from({ length: ee }, (x, i) =>
          e.jsxs(
            "button",
            {
              type: "button",
              role: "radio",
              "aria-checked": t === i + 1,
              className: "cw-band",
              disabled: a,
              onClick: () => l(i + 1),
              children: ["Band ", i + 1],
            },
            i,
          ),
        ),
      }),
    });
  const n = c.scale.max;
  return e.jsxs("div", {
    className: "cw-guess cw-mark",
    children: [
      e.jsx("input", {
        type: "range",
        min: 0,
        max: n,
        step: 1,
        "aria-label": `${s.label}'s mark out of ${n}`,
        "aria-valuetext": t === void 0 ? "Not guessed" : `${t} out of ${n}`,
        value: t ?? Math.round(n / 2),
        disabled: a,
        onChange: (x) => l(Number(x.target.value)),
        onPointerUp: (x) => t === void 0 && l(Number(x.currentTarget.value)),
        onKeyUp: (x) => t === void 0 && l(Number(x.currentTarget.value)),
      }),
      e.jsxs("span", {
        className: "cw-mark-value",
        "data-crit-mark": s.id,
        children: [t ?? "?", e.jsxs("small", { children: ["/", n] })],
      }),
    ],
  });
}
function Ie({ wall: c, round: s, answer: t }) {
  const a = fe(s),
    l = t.checked
      ? new Set(s.exemplars.map((u) => u.judgement.band))
      : new Set(),
    n = (u) => {
      const g = [];
      return u.map(({ letter: h, value: d }) => {
        const p = g.filter(
          (k) => Math.abs(k - d) < (s.scale.kind === "band" ? 0.5 : 1),
        ).length;
        g.push(d);
        const b = ((Math.max(Math.min(d, a), 0.5) - 0.5) / a) * 100;
        return e.jsxs(
          "span",
          {
            className: "cw-pin",
            "data-stack": p ? String((p % 2) + 1) : void 0,
            style: { left: `${b}%` },
            title: `Student ${h}: ${F(s, d)}`,
            children: [
              h,
              s.scale.kind === "mark" ? e.jsx("small", { children: d }) : null,
            ],
          },
          h,
        );
      });
    },
    x = X,
    i = s.exemplars
      .filter((u) => t.guesses[u.id] !== void 0)
      .map((u) => ({ letter: x(u), value: t.guesses[u.id] })),
    r = s.exemplars.map((u) => ({ letter: x(u), value: G(s, u) }));
  return e.jsxs("section", {
    className: "cw-panel cw-rubric",
    "aria-labelledby": `crit-rubric-${s.id}`,
    children: [
      e.jsx("p", { className: "cw-grid-label", children: c.grid.label }),
      e.jsx("h3", {
        id: `crit-rubric-${s.id}`,
        children: "Where does each student land?",
      }),
      s.focus
        ? e.jsx("p", {
            className: "cw-focus",
            children: e.jsx(R, { value: s.focus }),
          })
        : null,
      e.jsx("div", {
        className: "cw-bandgrid",
        children: Array.from({ length: ee }, (u, g) => {
          const h = g + 1,
            [d, p] = c.grid.lead.split("{L}");
          return e.jsxs(
            "div",
            {
              className: "cw-bandcol",
              "data-band": h,
              "data-hit": l.has(h) ? "true" : void 0,
              children: [
                e.jsxs("p", {
                  className: "cw-bandcol-head",
                  children: [
                    e.jsxs("strong", { children: ["Band ", h] }),
                    e.jsx("span", {
                      children:
                        s.scale.kind === "band"
                          ? c.grid.bandNames[g]
                          : `${be(s, h)} marks`,
                    }),
                  ],
                }),
                e.jsxs("p", {
                  className: "cw-bandcol-lead",
                  children: [
                    d,
                    e.jsx("strong", { children: c.grid.bandNames[g] }),
                    p ?? "",
                  ],
                }),
                e.jsx("ul", {
                  children: s.grid.map((b) =>
                    e.jsx(
                      "li",
                      {
                        children: e.jsx(Fe, {
                          line: c.grid.lines[b][g],
                          band: h,
                        }),
                      },
                      b,
                    ),
                  ),
                }),
              ],
            },
            h,
          );
        }),
      }),
      e.jsxs("div", {
        className: "cw-strip",
        "aria-hidden": "true",
        children: [
          e.jsx("span", {
            className: "cw-strip-label",
            children: "Your guesses",
          }),
          e.jsx("div", {
            className: "cw-track",
            "data-track": "guesses",
            children: n(i),
          }),
          e.jsx("span", {
            className: "cw-strip-label",
            children: s.scale.kind === "band" ? "Pearson band" : "Pearson mark",
          }),
          e.jsx("div", {
            className: "cw-track",
            "data-track": "pearson",
            children: t.checked
              ? n(r)
              : e.jsx("span", {
                  className: "cw-track-wait",
                  children: "Revealed when you check",
                }),
          }),
          e.jsx("span", {}),
          e.jsx("div", {
            className: "cw-ticks",
            style: { gridTemplateColumns: `repeat(${a}, minmax(0, 1fr))` },
            children: Array.from({ length: a }, (u, g) =>
              e.jsx(
                "span",
                { children: s.scale.kind === "band" ? `Band ${g + 1}` : g + 1 },
                g,
              ),
            ),
          }),
        ],
      }),
    ],
  });
}
function _({
  id: c,
  label: s,
  value: t,
  need: a,
  readOnly: l,
  onChange: n,
  onFocus: x,
  children: i,
}) {
  const r = Ne(t);
  return e.jsxs("div", {
    className: "cw-field",
    children: [
      e.jsx("label", { htmlFor: c, children: s }),
      i,
      e.jsx("textarea", {
        id: c,
        className: "cw-textarea",
        rows: 4,
        value: t,
        readOnly: l,
        onFocus: (u) => x(u.currentTarget),
        onChange: (u) => n(u.target.value),
      }),
      e.jsx("span", {
        className: "cw-words",
        "data-ok": r >= a && r > 0 ? "true" : void 0,
        children: a ? `${r} / ${a} words` : `${r} words`,
      }),
    ],
  });
}
function _e({
  wall: c,
  round: s,
  source: t,
  answer: a,
  onAnswer: l,
  onNext: n,
  nextLabel: x,
}) {
  const i = f.useRef(null),
    [r, u] = f.useState(null),
    [g, h] = f.useState(""),
    d = f.useMemo(() => new Map(s.exemplars.map((o) => [o.id, o])), [s]),
    { checked: p } = a,
    b = p ? Z(s, a) : null,
    k = ie(s, a),
    y = re(`${a.first} ${a.second} ${a.upgrade}`, s.keyTerms),
    $ = f.useMemo(() => de(s), [s]),
    m = oe(s),
    C = (p ? null : he($, a.picks))?.pair ?? null,
    ae = C
      ? [...C].sort((o, j) =>
          (d.get(o)?.label ?? o).localeCompare(d.get(j)?.label ?? j),
        )
      : [],
    z = (o) => {
      if (!C) return;
      const j = we(s, a, o === C[0]);
      l(j);
      const w = d.get(o)?.label ?? o;
      h(
        j.ranked
          ? `${w} is stronger. All ranked.`
          : `${w} is stronger. Pair ${j.picks.length + 1}.`,
      );
    },
    te = () => {
      (l({ ...a, picks: [], order: $, ranked: !1 }),
        h("Ranking cleared. Pair 1."));
    },
    Y = (o) => {
      if (p) return;
      const j = i.current ?? {
          field: "first",
          element: document.getElementById(`crit-${s.id}-first`),
        },
        w = a[j.field],
        v = j.element?.selectionStart ?? w.length,
        E = j.element?.selectionEnd ?? v,
        P = v > 0 && !/\s$/u.test(w.slice(0, v)) ? " " : "",
        T = `${w.slice(0, v)}${P}${o}${w.slice(E)}`;
      l({ ...a, [j.field]: T });
      const D = v + P.length + o.length;
      window.requestAnimationFrame(() => {
        (j.element?.focus(), j.element?.setSelectionRange(D, D));
      });
    },
    W = (o) => ({
      value: a[o],
      readOnly: p,
      onChange: (j) => l({ ...a, [o]: j }),
      onFocus: (j) => {
        i.current = { field: o, element: j };
      },
    });
  return e.jsxs("div", {
    className: "cw-round",
    "data-crit-round": s.id,
    "data-crit-checked": p ? "true" : void 0,
    children: [
      e.jsxs("header", {
        className: "cw-round-head",
        children: [
          e.jsx("h2", { className: "cw-title", children: s.title }),
          e.jsxs("p", {
            className: "cw-tags",
            children: [
              e.jsx("span", {
                className: "cw-tag",
                children: s.series ?? c.series,
              }),
              s.scale.kind === "band"
                ? e.jsxs(e.Fragment, {
                    children: [
                      e.jsx("span", {
                        className: "cw-tag",
                        children: "Judge this part only",
                      }),
                      e.jsx("span", {
                        className: "cw-tag",
                        children: "Bands 1 to 4",
                      }),
                    ],
                  })
                : e.jsxs("span", {
                    className: "cw-tag",
                    children: ["Marked out of ", s.scale.max],
                  }),
            ],
          }),
          e.jsx("p", {
            className: "cw-intro",
            children: e.jsx(R, { value: s.intro }),
          }),
        ],
      }),
      e.jsx("p", { className: "sr-only", "aria-live": "polite", children: g }),
      C
        ? e.jsxs("section", {
            className: "cw-pair-wrap",
            "aria-labelledby": `crit-pair-${s.id}`,
            "data-crit-pair-step": a.picks.length + 1,
            children: [
              e.jsxs("div", {
                className: "cw-pair-head",
                children: [
                  e.jsx("h3", {
                    id: `crit-pair-${s.id}`,
                    children: "Which is stronger?",
                  }),
                  e.jsx("span", {
                    className: "cw-pair-dots",
                    "aria-hidden": "true",
                    "data-crit-pair-progress": "",
                    children: Array.from({ length: ue($.length) }, (o, j) =>
                      e.jsx(
                        "span",
                        { "data-done": j < a.picks.length ? "true" : void 0 },
                        j,
                      ),
                    ),
                  }),
                ],
              }),
              e.jsx("ul", {
                className: "cw-pair",
                "data-wide": s.wide ? "true" : void 0,
                "data-excerpt": m ? "true" : void 0,
                "aria-label": "Pick the stronger student",
                children: ae.map((o) => {
                  const j = d.get(o);
                  return j
                    ? m
                      ? e.jsx(
                          "li",
                          {
                            className: "cw-pair-item",
                            "data-crit-pair-answer": o,
                            children: e.jsxs("button", {
                              type: "button",
                              className: "cw-card cw-card-pick",
                              "aria-label": `${j.label} is stronger`,
                              onClick: () => z(o),
                              children: [
                                e.jsx(I, { exemplar: j }),
                                e.jsx(H, { exemplar: j }),
                              ],
                            }),
                          },
                          o,
                        )
                      : e.jsxs(
                          "li",
                          {
                            className: "cw-card cw-card-whole",
                            "data-crit-pair-answer": o,
                            children: [
                              e.jsx(I, { exemplar: j }),
                              e.jsx(U, {
                                source: t,
                                round: s,
                                exemplar: j,
                                onOpen: (w, v) => u({ images: w, index: v }),
                              }),
                              e.jsx("div", {
                                className: "cw-pick",
                                children: e.jsx("button", {
                                  type: "button",
                                  className: "cw-button",
                                  "aria-label": `${j.label} is stronger`,
                                  onClick: () => z(o),
                                  children: "Stronger",
                                }),
                              }),
                            ],
                          },
                          o,
                        )
                    : null;
                }),
              }),
            ],
          })
        : e.jsxs(e.Fragment, {
            children: [
              p
                ? null
                : e.jsx("div", {
                    className: "cw-keep",
                    children: e.jsx("button", {
                      type: "button",
                      className: "cw-button-ghost",
                      onClick: te,
                      children: "Rank again",
                    }),
                  }),
              e.jsx("ol", {
                className: "cw-cards",
                "data-wide": s.wide ? "true" : void 0,
                "data-excerpt": m ? "true" : void 0,
                "aria-label": "Your ranking, best first",
                children: a.order.map((o, j) => {
                  const w = d.get(o);
                  if (!w) return null;
                  const v = a.guesses[o],
                    E = j + 1 === w.judgement.rank,
                    P = G(s, w);
                  return e.jsxs(
                    "li",
                    {
                      className: "cw-card",
                      "data-crit-card": o,
                      "data-place": String(j + 1),
                      "data-placed": p ? String(E) : void 0,
                      children: [
                        e.jsx(I, { exemplar: w }),
                        e.jsxs("div", {
                          className: "cw-card-head",
                          children: [
                            e.jsx("h3", {
                              className: "cw-label sr-only",
                              children: w.label,
                            }),
                            e.jsx("span", {
                              className: "cw-medal",
                              "data-crit-place": "",
                              children: K(j + 1),
                            }),
                          ],
                        }),
                        m
                          ? e.jsx("div", {
                              className: "cw-body",
                              children: e.jsx(H, { exemplar: w }),
                            })
                          : e.jsx(U, {
                              source: t,
                              round: s,
                              exemplar: w,
                              onOpen: (T, D) => u({ images: T, index: D }),
                            }),
                        e.jsx(Ue, {
                          round: s,
                          exemplar: w,
                          value: v,
                          disabled: p,
                          onChange: (T) =>
                            l({ ...a, guesses: { ...a.guesses, [o]: T } }),
                        }),
                        p
                          ? e.jsxs("div", {
                              className: "cw-verdict",
                              "data-crit-verdict": o,
                              children: [
                                e.jsxs("p", {
                                  className: "cw-pills",
                                  children: [
                                    e.jsx("span", {
                                      className: "cw-pill",
                                      children:
                                        s.scale.kind === "band"
                                          ? `Band ${w.judgement.band}`
                                          : `Pearson: ${F(s, P)} · Band ${w.judgement.band}`,
                                    }),
                                    e.jsxs("span", {
                                      className: "cw-pill",
                                      "data-ok": E ? "true" : "false",
                                      children: [
                                        E
                                          ? e.jsx(me, {
                                              "aria-hidden": "true",
                                              className: "h-4 w-4",
                                            })
                                          : e.jsx(q, {
                                              "aria-hidden": "true",
                                              className: "h-4 w-4",
                                            }),
                                        E
                                          ? "Rank correct"
                                          : `Should be ${K(w.judgement.rank)}`,
                                      ],
                                    }),
                                    e.jsxs("span", {
                                      className: "cw-pill",
                                      "data-ok": xe(s, v, P) ? "true" : "false",
                                      children: [
                                        "You said ",
                                        F(s, v),
                                        v === P ? ", exact" : "",
                                      ],
                                    }),
                                  ],
                                }),
                                e.jsx("p", {
                                  className: "cw-commentary",
                                  children: w.judgement.commentary,
                                }),
                                m
                                  ? e.jsxs("details", {
                                      className: "cw-whole",
                                      "data-crit-whole": o,
                                      children: [
                                        e.jsx("summary", {
                                          children: "Read the whole piece",
                                        }),
                                        e.jsx(U, {
                                          source: t,
                                          round: s,
                                          exemplar: w,
                                          onOpen: (T, D) =>
                                            u({ images: T, index: D }),
                                        }),
                                      ],
                                    })
                                  : null,
                                e.jsx(Oe, { source: t, round: s, exemplar: w }),
                              ],
                            })
                          : null,
                      ],
                    },
                    o,
                  );
                }),
              }),
            ],
          }),
      e.jsx(Ie, { wall: c, round: s, answer: a }),
      e.jsxs("section", {
        className: "cw-panel cw-justify",
        "aria-labelledby": `crit-justify-${s.id}`,
        children: [
          e.jsx("h3", {
            id: `crit-justify-${s.id}`,
            children: "Justify your ranking",
          }),
          e.jsx("div", {
            className: "cw-chips",
            role: "group",
            "aria-label": "Key terms",
            children: s.keyTerms.map((o) =>
              e.jsxs(
                "button",
                {
                  type: "button",
                  className: "cw-chip",
                  "data-used": y.includes(o) ? "true" : void 0,
                  disabled: p,
                  onClick: () => Y(o),
                  children: [
                    o,
                    y.includes(o)
                      ? e.jsx("span", {
                          className: "sr-only",
                          children: " (used)",
                        })
                      : null,
                  ],
                },
                o,
              ),
            ),
          }),
          e.jsx("div", {
            className: "cw-chips",
            role: "group",
            "aria-label": "Sentence starters",
            children: c.starters.map((o) =>
              e.jsxs(
                "button",
                {
                  type: "button",
                  className: "cw-chip cw-chip-starter",
                  disabled: p,
                  onClick: () => Y(o),
                  children: [o.trim(), "..."],
                },
                o,
              ),
            ),
          }),
          e.jsx(_, {
            id: `crit-${s.id}-first`,
            label: s.firstQuestion,
            need: pe,
            ...W("first"),
          }),
          e.jsx(_, {
            id: `crit-${s.id}-second`,
            label: s.secondQuestion,
            need: je,
            ...W("second"),
          }),
          s.upgrade
            ? e.jsxs(_, {
                id: `crit-${s.id}-upgrade`,
                label: `Upgrade challenge: rewrite Student ${s.upgrade.student}'s ${s.upgrade.what ?? "line"} so it would reach Band 4`,
                need: 0,
                ...W("upgrade"),
                children: [
                  e.jsxs("blockquote", {
                    className: "cw-quote",
                    children: ['"', s.upgrade.quote, '"'],
                  }),
                  e.jsx("p", {
                    className: "cw-hint",
                    children: s.upgrade.hint,
                  }),
                ],
              })
            : null,
          p && b
            ? e.jsxs("div", {
                className: "cw-result",
                "data-crit-result": "",
                children: [
                  e.jsxs("p", {
                    className: "cw-score",
                    "data-crit-score": "",
                    children: ["Crit score: ", b.total, " / ", b.max],
                  }),
                  e.jsxs("p", {
                    className: "cw-breakdown",
                    children: [
                      "Ranking ",
                      b.rankPoints,
                      " · ",
                      s.scale.kind === "band" ? "Band" : "Mark",
                      " guesses ",
                      b.guessPoints,
                      " · Key terms used ",
                      b.termPoints,
                    ],
                  }),
                  e.jsx("p", {
                    className: "cw-takeaway",
                    children: s.takeaway,
                  }),
                  e.jsx("button", {
                    type: "button",
                    className: "cw-button",
                    onClick: n,
                    children: x,
                  }),
                ],
              })
            : e.jsxs("div", {
                className: "cw-actions",
                children: [
                  e.jsx("button", {
                    type: "button",
                    className: "cw-button",
                    disabled: k.length > 0,
                    onClick: () => l({ ...a, checked: !0 }),
                    children: "Check my answers",
                  }),
                  e.jsx("p", {
                    className: "cw-todo",
                    role: "status",
                    children: k.length ? `To check: ${k.join(", ")}.` : "",
                  }),
                ],
              }),
        ],
      }),
      r
        ? e.jsx(Me, {
            source: t,
            images: r.images,
            index: r.index,
            onIndex: (o) => u({ ...r, index: o }),
            onClose: () => u(null),
          })
        : null,
    ],
  });
}
function Ge({ wall: c, answers: s, details: t, onDetails: a }) {
  const [l, n] = f.useState(""),
    x = async () => {
      if (!t.name.trim()) {
        n("Add your name first so your teacher knows whose crit this is.");
        return;
      }
      const i = await Le(c, s, t);
      n(
        i
          ? "Downloaded. Now hand it in on Teams."
          : "This browser could not draw the PNG.",
      );
    };
  return e.jsxs("div", {
    className: "cw-round",
    "data-crit-round": "save",
    children: [
      e.jsx("header", {
        className: "cw-round-head",
        children: e.jsx("h2", {
          className: "cw-title",
          children: "Save your crit and hand it in",
        }),
      }),
      e.jsxs("div", {
        className: "cw-save",
        children: [
          e.jsxs("section", {
            className: "cw-panel",
            children: [
              e.jsxs("div", {
                className: "cw-field",
                children: [
                  e.jsx("label", {
                    htmlFor: "crit-save-name",
                    children: "Your name",
                  }),
                  e.jsx("input", {
                    id: "crit-save-name",
                    className: "cw-input",
                    autoComplete: "name",
                    value: t.name,
                    onChange: (i) => a({ ...t, name: i.target.value }),
                  }),
                ],
              }),
              e.jsxs("div", {
                className: "cw-field",
                children: [
                  e.jsx("label", {
                    htmlFor: "crit-save-class",
                    children: "Class",
                  }),
                  e.jsx("input", {
                    id: "crit-save-class",
                    className: "cw-input",
                    value: t.className,
                    onChange: (i) => a({ ...t, className: i.target.value }),
                  }),
                ],
              }),
              e.jsxs("div", {
                className: "cw-field",
                children: [
                  e.jsx("label", {
                    htmlFor: "crit-save-target",
                    children: c.save.targetLabel,
                  }),
                  e.jsx("p", {
                    className: "cw-hint",
                    children: c.save.targetHint,
                  }),
                  e.jsx("textarea", {
                    id: "crit-save-target",
                    className: "cw-textarea",
                    rows: 4,
                    placeholder: c.save.targetPlaceholder,
                    value: t.target,
                    onChange: (i) => a({ ...t, target: i.target.value }),
                  }),
                ],
              }),
              e.jsxs("div", {
                className: "cw-actions",
                children: [
                  e.jsx("button", {
                    type: "button",
                    className: "cw-button",
                    onClick: x,
                    children: "Download PNG",
                  }),
                  e.jsx("p", {
                    className: "cw-todo",
                    role: "status",
                    children: l,
                  }),
                ],
              }),
            ],
          }),
          e.jsxs("section", {
            className: "cw-panel",
            "aria-labelledby": "crit-teams",
            children: [
              e.jsx("h3", {
                id: "crit-teams",
                children: "Hand it in on Teams",
              }),
              e.jsxs("ol", {
                className: "cw-teams",
                children: [
                  e.jsxs("li", {
                    children: [
                      "Select ",
                      e.jsx("strong", { children: "Download PNG" }),
                      ". The file saves to your Downloads folder.",
                    ],
                  }),
                  e.jsxs("li", {
                    children: [
                      "Open ",
                      e.jsx("strong", { children: "Microsoft Teams" }),
                      " and go to your ",
                      e.jsx("strong", { children: "BTEC DIT" }),
                      " class team.",
                    ],
                  }),
                  e.jsxs("li", {
                    children: [
                      "Open ",
                      e.jsx("strong", { children: "Assignments" }),
                      " and choose the assignment your teacher has set for this crit.",
                    ],
                  }),
                  e.jsxs("li", {
                    children: [
                      "Select ",
                      e.jsx("strong", { children: "Add work" }),
                      ", then ",
                      e.jsx("strong", { children: "Upload from this device" }),
                      ", and pick your PNG.",
                    ],
                  }),
                  e.jsxs("li", {
                    children: [
                      "Select ",
                      e.jsx("strong", { children: "Hand in" }),
                      ".",
                    ],
                  }),
                ],
              }),
            ],
          }),
        ],
      }),
    ],
  });
}
function ze({ task: c, source: s, studentName: t = "" }) {
  const [a, l] = f.useState({ state: "loading" }),
    [n, x] = f.useState(0),
    [i, r] = f.useState({}),
    [u, g] = f.useState({ name: t, className: "", target: "" }),
    h = Ae();
  if (
    (f.useEffect(() => {
      let m = !0;
      return (
        l({ state: "loading" }),
        x(0),
        r({}),
        s.wall(ne(c)).then(
          (N) => {
            if (m) {
              if (N === null) {
                l({ state: "missing" });
                return;
              }
              try {
                l({ state: "ready", wall: le(N, c) });
              } catch {
                l({ state: "missing" });
              }
            }
          },
          () => {
            m && l({ state: "missing" });
          },
        ),
        () => {
          m = !1;
        }
      );
    }, [s, c]),
    a.state === "loading")
  )
    return e.jsx("p", {
      className: "text-sm font-medium text-slate-500",
      children: "Loading...",
    });
  if (a.state === "missing")
    return e.jsx("div", {
      className: "crit-wall",
      "data-crit-wall": c,
      "data-crit-state": "missing",
      children: e.jsx("p", {
        className: "cw-missing",
        children: "This crit wall is not available yet.",
      }),
    });
  const { wall: d } = a,
    p = d.rounds[n],
    b = (m) => i[m.id] ?? J(m),
    k = (m) => {
      (x(m), window.scrollTo?.({ top: 0 }));
    },
    y = p && !p.noBrief ? p.asks : void 0,
    $ = !p?.noBrief;
  return e.jsxs("div", {
    className: "crit-wall",
    "data-crit-wall": c,
    "data-crit-state": "ready",
    "data-crit-layout": h ? "side" : "stack",
    children: [
      h
        ? e.jsxs("aside", {
            className: "cw-side",
            "aria-label": "The brief",
            "data-crit-brief": "",
            children: [
              e.jsx("p", {
                className: "cw-lede",
                children: e.jsx(R, { value: d.lede }),
              }),
              $
                ? e.jsxs("section", {
                    className: "cw-side-brief",
                    children: [
                      e.jsx("h2", {
                        className: "cw-side-title",
                        children: d.title,
                      }),
                      e.jsx("div", {
                        className: "cw-brief-body",
                        children: e.jsx(V, { blocks: d.brief.blocks }),
                      }),
                    ],
                  })
                : null,
              y
                ? e.jsx("blockquote", {
                    className: "cw-asks",
                    "data-crit-asks": "",
                    children: e.jsx(R, { value: y }),
                  })
                : null,
            ],
          })
        : e.jsxs("div", {
            className: "cw-top",
            children: [
              e.jsx("p", {
                className: "cw-lede",
                children: e.jsx(R, { value: d.lede }),
              }),
              e.jsxs("details", {
                className: "cw-brief",
                "data-crit-brief": "",
                children: [
                  e.jsx("summary", { children: d.brief.summary }),
                  e.jsxs("div", {
                    className: "cw-brief-body",
                    children: [
                      e.jsx(V, { blocks: d.brief.blocks }),
                      y
                        ? e.jsx("blockquote", {
                            className: "cw-asks",
                            "data-crit-asks": "",
                            children: e.jsx(R, { value: y }),
                          })
                        : null,
                    ],
                  }),
                ],
              }),
            ],
          }),
      e.jsxs("div", {
        className: "cw-main",
        children: [
          e.jsx("nav", {
            className: "cw-steps",
            "aria-label": "Rounds",
            children: e.jsx("ol", {
              children: [...d.rounds.map((m) => m.step), "Save"].map((m, N) => {
                const C = N < d.rounds.length && b(d.rounds[N]).checked;
                return e.jsx(
                  "li",
                  {
                    children: e.jsxs("button", {
                      type: "button",
                      className: "cw-step",
                      "aria-current": N === n ? "step" : void 0,
                      "data-done": C ? "true" : void 0,
                      onClick: () => k(N),
                      children: [
                        e.jsx("span", {
                          className: "cw-step-number",
                          "aria-hidden": "true",
                          children: N + 1,
                        }),
                        m,
                        C
                          ? e.jsx("span", {
                              className: "sr-only",
                              children: " (checked)",
                            })
                          : null,
                      ],
                    }),
                  },
                  m,
                );
              }),
            }),
          }),
          p
            ? e.jsx(
                _e,
                {
                  wall: d,
                  round: p,
                  source: s,
                  answer: b(p),
                  onAnswer: (m) => r((N) => ({ ...N, [p.id]: m })),
                  onNext: () => k(n + 1),
                  nextLabel:
                    n + 1 < d.rounds.length
                      ? `Next: ${d.rounds[n + 1].title}`
                      : "Next: save your crit",
                },
                p.id,
              )
            : e.jsx(Ge, { wall: d, answers: i, details: u, onDetails: g }),
        ],
      }),
    ],
  });
}
export { ze as default };
