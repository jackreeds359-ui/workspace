import {
  i as Is,
  c1 as ba,
  R as Et,
  r as re,
  j as $,
  c2 as Od,
  c3 as Co,
} from "./index-CHiQZc8e.js";
import { O as Nd, R as Ci, a as rn, I as Dd } from "./OfficeChrome-BlQi-GP2.js";
import { B as Rd } from "./coursework-editors-DmNamGFm.js";
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const Id = Is("Heading", [
  ["path", { d: "M6 12h12", key: "8npq4p" }],
  ["path", { d: "M6 20V4", key: "1w1bmo" }],
  ["path", { d: "M18 20V4", key: "o2hl4u" }],
]);
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const Ld = Is("ListOrdered", [
  ["path", { d: "M10 12h11", key: "6m4ad9" }],
  ["path", { d: "M10 18h11", key: "11hvi2" }],
  ["path", { d: "M10 6h11", key: "c7qv1k" }],
  ["path", { d: "M4 10h2", key: "16xx2s" }],
  ["path", { d: "M4 6h1v4", key: "cnovpq" }],
  ["path", { d: "M6 18H4c0-1 2-2 2-3s-1-1.5-2-1", key: "m9a95d" }],
]);
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const Pd = Is("List", [
  ["path", { d: "M3 12h.01", key: "nlz23k" }],
  ["path", { d: "M3 18h.01", key: "1tta3j" }],
  ["path", { d: "M3 6h.01", key: "1rqtza" }],
  ["path", { d: "M8 12h13", key: "1za7za" }],
  ["path", { d: "M8 18h13", key: "1lx6n3" }],
  ["path", { d: "M8 6h13", key: "ik3vkj" }],
]);
function ee(n) {
  this.content = n;
}
ee.prototype = {
  constructor: ee,
  find: function (n) {
    for (var e = 0; e < this.content.length; e += 2)
      if (this.content[e] === n) return e;
    return -1;
  },
  get: function (n) {
    var e = this.find(n);
    return e == -1 ? void 0 : this.content[e + 1];
  },
  update: function (n, e, t) {
    var r = t && t != n ? this.remove(t) : this,
      i = r.find(n),
      s = r.content.slice();
    return (
      i == -1 ? s.push(t || n, e) : ((s[i + 1] = e), t && (s[i] = t)),
      new ee(s)
    );
  },
  remove: function (n) {
    var e = this.find(n);
    if (e == -1) return this;
    var t = this.content.slice();
    return (t.splice(e, 2), new ee(t));
  },
  addToStart: function (n, e) {
    return new ee([n, e].concat(this.remove(n).content));
  },
  addToEnd: function (n, e) {
    var t = this.remove(n).content.slice();
    return (t.push(n, e), new ee(t));
  },
  addBefore: function (n, e, t) {
    var r = this.remove(e),
      i = r.content.slice(),
      s = r.find(n);
    return (i.splice(s == -1 ? i.length : s, 0, e, t), new ee(i));
  },
  forEach: function (n) {
    for (var e = 0; e < this.content.length; e += 2)
      n(this.content[e], this.content[e + 1]);
  },
  prepend: function (n) {
    return (
      (n = ee.from(n)),
      n.size ? new ee(n.content.concat(this.subtract(n).content)) : this
    );
  },
  append: function (n) {
    return (
      (n = ee.from(n)),
      n.size ? new ee(this.subtract(n).content.concat(n.content)) : this
    );
  },
  subtract: function (n) {
    var e = this;
    n = ee.from(n);
    for (var t = 0; t < n.content.length; t += 2) e = e.remove(n.content[t]);
    return e;
  },
  toObject: function () {
    var n = {};
    return (
      this.forEach(function (e, t) {
        n[e] = t;
      }),
      n
    );
  },
  get size() {
    return this.content.length >> 1;
  },
};
ee.from = function (n) {
  if (n instanceof ee) return n;
  var e = [];
  if (n) for (var t in n) e.push(t, n[t]);
  return new ee(e);
};
function ka(n, e, t) {
  for (let r = 0; ; r++) {
    if (r == n.childCount || r == e.childCount)
      return n.childCount == e.childCount ? null : t;
    let i = n.child(r),
      s = e.child(r);
    if (i == s) {
      t += i.nodeSize;
      continue;
    }
    if (!i.sameMarkup(s)) return t;
    if (i.isText && i.text != s.text) {
      let o = i.text,
        l = s.text,
        a = 0;
      for (; o[a] == l[a]; a++) t++;
      return (
        a &&
          a < o.length &&
          a < l.length &&
          wa(o.charCodeAt(a - 1)) &&
          xa(o.charCodeAt(a)) &&
          t--,
        t
      );
    }
    if (i.content.size || s.content.size) {
      let o = ka(i.content, s.content, t + 1);
      if (o != null) return o;
    }
    t += i.nodeSize;
  }
}
function Sa(n, e, t, r) {
  for (let i = n.childCount, s = e.childCount; ;) {
    if (i == 0 || s == 0) return i == s ? null : { a: t, b: r };
    let o = n.child(--i),
      l = e.child(--s),
      a = o.nodeSize;
    if (o == l) {
      ((t -= a), (r -= a));
      continue;
    }
    if (!o.sameMarkup(l)) return { a: t, b: r };
    if (o.isText && o.text != l.text) {
      let c = o.text,
        u = l.text,
        d = c.length,
        f = u.length;
      for (; d > 0 && f > 0 && c[d - 1] == u[f - 1];) (d--, f--, t--, r--);
      return (
        d &&
          f &&
          d < c.length &&
          wa(c.charCodeAt(d - 1)) &&
          xa(c.charCodeAt(d)) &&
          (t++, r++),
        { a: t, b: r }
      );
    }
    if (o.content.size || l.content.size) {
      let c = Sa(o.content, l.content, t - 1, r - 1);
      if (c) return c;
    }
    ((t -= a), (r -= a));
  }
}
function xa(n) {
  return n >= 56320 && n < 57344;
}
function wa(n) {
  return n >= 55296 && n < 56320;
}
class b {
  constructor(e, t) {
    if (((this.content = e), (this.size = t || 0), t == null))
      for (let r = 0; r < e.length; r++) this.size += e[r].nodeSize;
  }
  nodesBetween(e, t, r, i = 0, s) {
    for (let o = 0, l = 0; l < t; o++) {
      let a = this.content[o],
        c = l + a.nodeSize;
      if (c > e && r(a, i + l, s || null, o) !== !1 && a.content.size) {
        let u = l + 1;
        a.nodesBetween(
          Math.max(0, e - u),
          Math.min(a.content.size, t - u),
          r,
          i + u,
        );
      }
      l = c;
    }
  }
  descendants(e) {
    this.nodesBetween(0, this.size, e);
  }
  textBetween(e, t, r, i) {
    let s = "",
      o = !0;
    return (
      this.nodesBetween(
        e,
        t,
        (l, a) => {
          let c = l.isText
            ? l.text.slice(Math.max(e, a) - a, t - a)
            : l.isLeaf
              ? i
                ? typeof i == "function"
                  ? i(l)
                  : i
                : l.type.spec.leafText
                  ? l.type.spec.leafText(l)
                  : ""
              : "";
          (l.isBlock &&
            ((l.isLeaf && c) || l.isTextblock) &&
            r &&
            (o ? (o = !1) : (s += r)),
            (s += c));
        },
        0,
      ),
      s
    );
  }
  append(e) {
    if (!e.size) return this;
    if (!this.size) return e;
    let t = this.lastChild,
      r = e.firstChild,
      i = this.content.slice(),
      s = 0;
    for (
      t.isText &&
      t.sameMarkup(r) &&
      ((i[i.length - 1] = t.withText(t.text + r.text)), (s = 1));
      s < e.content.length;
      s++
    )
      i.push(e.content[s]);
    return new b(i, this.size + e.size);
  }
  cut(e, t = this.size) {
    if (e == 0 && t == this.size) return this;
    let r = [],
      i = 0;
    if (t > e)
      for (let s = 0, o = 0; o < t; s++) {
        let l = this.content[s],
          a = o + l.nodeSize;
        (a > e &&
          ((o < e || a > t) &&
            (l.isText
              ? (l = l.cut(Math.max(0, e - o), Math.min(l.text.length, t - o)))
              : (l = l.cut(
                  Math.max(0, e - o - 1),
                  Math.min(l.content.size, t - o - 1),
                ))),
          r.push(l),
          (i += l.nodeSize)),
          (o = a));
      }
    return new b(r, i);
  }
  cutByIndex(e, t) {
    return e == t
      ? b.empty
      : e == 0 && t == this.content.length
        ? this
        : new b(this.content.slice(e, t));
  }
  replaceChild(e, t) {
    let r = this.content[e];
    if (r == t) return this;
    let i = this.content.slice(),
      s = this.size + t.nodeSize - r.nodeSize;
    return ((i[e] = t), new b(i, s));
  }
  addToStart(e) {
    return new b([e].concat(this.content), this.size + e.nodeSize);
  }
  addToEnd(e) {
    return new b(this.content.concat(e), this.size + e.nodeSize);
  }
  eq(e) {
    if (this.content.length != e.content.length) return !1;
    for (let t = 0; t < this.content.length; t++)
      if (!this.content[t].eq(e.content[t])) return !1;
    return !0;
  }
  get firstChild() {
    return this.content.length ? this.content[0] : null;
  }
  get lastChild() {
    return this.content.length ? this.content[this.content.length - 1] : null;
  }
  get childCount() {
    return this.content.length;
  }
  child(e) {
    let t = this.content[e];
    if (!t) throw new RangeError("Index " + e + " out of range for " + this);
    return t;
  }
  maybeChild(e) {
    return this.content[e] || null;
  }
  forEach(e) {
    for (let t = 0, r = 0; t < this.content.length; t++) {
      let i = this.content[t];
      (e(i, r, t), (r += i.nodeSize));
    }
  }
  findDiffStart(e, t = 0) {
    return ka(this, e, t);
  }
  findDiffEnd(e, t = this.size, r = e.size) {
    return Sa(this, e, t, r);
  }
  findIndex(e) {
    if (e == 0) return Kn(0, e);
    if (e == this.size) return Kn(this.content.length, e);
    if (e > this.size || e < 0)
      throw new RangeError(`Position ${e} outside of fragment (${this})`);
    for (let t = 0, r = 0; ; t++) {
      let i = this.child(t),
        s = r + i.nodeSize;
      if (s >= e) return s == e ? Kn(t + 1, s) : Kn(t, r);
      r = s;
    }
  }
  toString() {
    return "<" + this.toStringInner() + ">";
  }
  toStringInner() {
    return this.content.join(", ");
  }
  toJSON() {
    return this.content.length ? this.content.map((e) => e.toJSON()) : null;
  }
  static fromJSON(e, t) {
    if (!t) return b.empty;
    if (!Array.isArray(t))
      throw new RangeError("Invalid input for Fragment.fromJSON");
    return b.fromArray(t.map(e.nodeFromJSON));
  }
  static fromArray(e) {
    if (!e.length) return b.empty;
    let t,
      r = 0;
    for (let i = 0; i < e.length; i++) {
      let s = e[i];
      ((r += s.nodeSize),
        i && s.isText && e[i - 1].sameMarkup(s)
          ? (t || (t = e.slice(0, i)),
            (t[t.length - 1] = s.withText(t[t.length - 1].text + s.text)))
          : t && t.push(s));
    }
    return new b(t || e, r);
  }
  static from(e) {
    if (!e) return b.empty;
    if (e instanceof b) return e;
    if (Array.isArray(e)) return this.fromArray(e);
    if (e.attrs) return new b([e], e.nodeSize);
    throw new RangeError(
      "Can not convert " +
        e +
        " to a Fragment" +
        (e.nodesBetween
          ? " (looks like multiple versions of prosemirror-model were loaded)"
          : ""),
    );
  }
}
b.empty = new b([], 0);
const vi = { index: 0, offset: 0 };
function Kn(n, e) {
  return ((vi.index = n), (vi.offset = e), vi);
}
function gr(n, e) {
  if (n === e) return !0;
  if (!(n && typeof n == "object") || !(e && typeof e == "object")) return !1;
  let t = Array.isArray(n);
  if (Array.isArray(e) != t) return !1;
  if (t) {
    if (n.length != e.length) return !1;
    for (let r = 0; r < n.length; r++) if (!gr(n[r], e[r])) return !1;
  } else {
    for (let r in n) if (!(r in e) || !gr(n[r], e[r])) return !1;
    for (let r in e) if (!(r in n)) return !1;
  }
  return !0;
}
let z = class Yi {
  constructor(e, t) {
    ((this.type = e), (this.attrs = t));
  }
  addToSet(e) {
    let t,
      r = !1;
    for (let i = 0; i < e.length; i++) {
      let s = e[i];
      if (this.eq(s)) return e;
      if (this.type.excludes(s.type)) t || (t = e.slice(0, i));
      else {
        if (s.type.excludes(this.type)) return e;
        (!r &&
          s.type.rank > this.type.rank &&
          (t || (t = e.slice(0, i)), t.push(this), (r = !0)),
          t && t.push(s));
      }
    }
    return (t || (t = e.slice()), r || t.push(this), t);
  }
  removeFromSet(e) {
    for (let t = 0; t < e.length; t++)
      if (this.eq(e[t])) return e.slice(0, t).concat(e.slice(t + 1));
    return e;
  }
  isInSet(e) {
    for (let t = 0; t < e.length; t++) if (this.eq(e[t])) return !0;
    return !1;
  }
  eq(e) {
    return this == e || (this.type == e.type && gr(this.attrs, e.attrs));
  }
  toJSON() {
    let e = { type: this.type.name };
    for (let t in this.attrs) {
      e.attrs = this.attrs;
      break;
    }
    return e;
  }
  static fromJSON(e, t) {
    if (!t) throw new RangeError("Invalid input for Mark.fromJSON");
    let r = e.marks[t.type];
    if (!r)
      throw new RangeError(`There is no mark type ${t.type} in this schema`);
    return r.create(t.attrs);
  }
  static sameSet(e, t) {
    if (e == t) return !0;
    if (e.length != t.length) return !1;
    for (let r = 0; r < e.length; r++) if (!e[r].eq(t[r])) return !1;
    return !0;
  }
  static setFrom(e) {
    if (!e || (Array.isArray(e) && e.length == 0)) return Yi.none;
    if (e instanceof Yi) return [e];
    let t = e.slice();
    return (t.sort((r, i) => r.type.rank - i.type.rank), t);
  }
};
z.none = [];
class Tn extends Error {}
class C {
  constructor(e, t, r) {
    ((this.content = e), (this.openStart = t), (this.openEnd = r));
  }
  get size() {
    return this.content.size - this.openStart - this.openEnd;
  }
  insertAt(e, t) {
    let r = va(
      this.content,
      e + this.openStart,
      t,
      this.openStart + 1,
      this.openEnd + 1,
    );
    return r && new C(r, this.openStart, this.openEnd);
  }
  removeBetween(e, t) {
    return new C(
      Ca(this.content, e + this.openStart, t + this.openStart),
      this.openStart,
      this.openEnd,
    );
  }
  eq(e) {
    return (
      this.content.eq(e.content) &&
      this.openStart == e.openStart &&
      this.openEnd == e.openEnd
    );
  }
  toString() {
    return this.content + "(" + this.openStart + "," + this.openEnd + ")";
  }
  toJSON() {
    if (!this.content.size) return null;
    let e = { content: this.content.toJSON() };
    return (
      this.openStart > 0 && (e.openStart = this.openStart),
      this.openEnd > 0 && (e.openEnd = this.openEnd),
      e
    );
  }
  static fromJSON(e, t) {
    if (!t) return C.empty;
    let r = t.openStart || 0,
      i = t.openEnd || 0;
    if (typeof r != "number" || typeof i != "number")
      throw new RangeError("Invalid input for Slice.fromJSON");
    return new C(b.fromJSON(e, t.content), r, i);
  }
  static maxOpen(e, t = !0) {
    let r = 0,
      i = 0;
    for (
      let s = e.firstChild;
      s && !s.isLeaf && (t || !s.type.spec.isolating);
      s = s.firstChild
    )
      r++;
    for (
      let s = e.lastChild;
      s && !s.isLeaf && (t || !s.type.spec.isolating);
      s = s.lastChild
    )
      i++;
    return new C(e, r, i);
  }
}
C.empty = new C(b.empty, 0, 0);
function Ca(n, e, t) {
  let { index: r, offset: i } = n.findIndex(e),
    s = n.maybeChild(r),
    { index: o, offset: l } = n.findIndex(t);
  if (i == e || s.isText) {
    if (l != t && !n.child(o).isText)
      throw new RangeError("Removing non-flat range");
    return n.cut(0, e).append(n.cut(t));
  }
  if (r != o) throw new RangeError("Removing non-flat range");
  return n.replaceChild(r, s.copy(Ca(s.content, e - i - 1, t - i - 1)));
}
function va(n, e, t, r, i, s) {
  let { index: o, offset: l } = n.findIndex(e),
    a = n.maybeChild(o);
  if (l == e || a.isText)
    return s && r <= 0 && i <= 0 && !s.canReplace(o, o, t)
      ? null
      : n.cut(0, e).append(t).append(n.cut(e));
  let c = va(
    a.content,
    e - l - 1,
    t,
    o == 0 ? r - 1 : 0,
    o == n.childCount - 1 ? i - 1 : 0,
    a,
  );
  return c && n.replaceChild(o, a.copy(c));
}
function Bd(n, e, t) {
  if (t.openStart > n.depth)
    throw new Tn("Inserted content deeper than insertion position");
  if (n.depth - t.openStart != e.depth - t.openEnd)
    throw new Tn("Inconsistent open depths");
  return Ma(n, e, t, 0);
}
function Ma(n, e, t, r) {
  let i = n.index(r),
    s = n.node(r);
  if (i == e.index(r) && r < n.depth - t.openStart) {
    let o = Ma(n, e, t, r + 1);
    return s.copy(s.content.replaceChild(i, o));
  } else if (t.content.size)
    if (!t.openStart && !t.openEnd && n.depth == r && e.depth == r) {
      let o = n.parent,
        l = o.content;
      return xt(
        o,
        l
          .cut(0, n.parentOffset)
          .append(t.content)
          .append(l.cut(e.parentOffset)),
      );
    } else {
      let { start: o, end: l } = $d(t, n);
      return xt(s, Ta(n, o, l, e, r));
    }
  else return xt(s, yr(n, e, r));
}
function Ea(n, e) {
  if (!e.type.compatibleContent(n.type))
    throw new Tn("Cannot join " + e.type.name + " onto " + n.type.name);
}
function Xi(n, e, t) {
  let r = n.node(t);
  return (Ea(r, e.node(t)), r);
}
function St(n, e) {
  let t = e.length - 1;
  t >= 0 && n.isText && n.sameMarkup(e[t])
    ? (e[t] = n.withText(e[t].text + n.text))
    : e.push(n);
}
function mn(n, e, t, r) {
  let i = (e || n).node(t),
    s = 0,
    o = e ? e.index(t) : i.childCount;
  n &&
    ((s = n.index(t)),
    n.depth > t ? s++ : n.textOffset && (St(n.nodeAfter, r), s++));
  for (let l = s; l < o; l++) St(i.child(l), r);
  e && e.depth == t && e.textOffset && St(e.nodeBefore, r);
}
function xt(n, e) {
  if (!n.type.validContent(e))
    throw new Tn("Invalid content for node " + n.type.name);
  return n.copy(e);
}
function Ta(n, e, t, r, i) {
  let s = n.depth > i && Xi(n, e, i + 1),
    o = r.depth > i && Xi(t, r, i + 1),
    l = [];
  return (
    mn(null, n, i, l),
    s && o && e.index(i) == t.index(i)
      ? (Ea(s, o), St(xt(s, Ta(n, e, t, r, i + 1)), l))
      : (s && St(xt(s, yr(n, e, i + 1)), l),
        mn(e, t, i, l),
        o && St(xt(o, yr(t, r, i + 1)), l)),
    mn(r, null, i, l),
    new b(l)
  );
}
function yr(n, e, t) {
  let r = [];
  if ((mn(null, n, t, r), n.depth > t)) {
    let i = Xi(n, e, t + 1);
    St(xt(i, yr(n, e, t + 1)), r);
  }
  return (mn(e, null, t, r), new b(r));
}
function $d(n, e) {
  let t = e.depth - n.openStart,
    i = e.node(t).copy(n.content);
  for (let s = t - 1; s >= 0; s--) i = e.node(s).copy(b.from(i));
  return {
    start: i.resolveNoCache(n.openStart + t),
    end: i.resolveNoCache(i.content.size - n.openEnd - t),
  };
}
class An {
  constructor(e, t, r) {
    ((this.pos = e),
      (this.path = t),
      (this.parentOffset = r),
      (this.depth = t.length / 3 - 1));
  }
  resolveDepth(e) {
    return e == null ? this.depth : e < 0 ? this.depth + e : e;
  }
  get parent() {
    return this.node(this.depth);
  }
  get doc() {
    return this.node(0);
  }
  node(e) {
    return this.path[this.resolveDepth(e) * 3];
  }
  index(e) {
    return this.path[this.resolveDepth(e) * 3 + 1];
  }
  indexAfter(e) {
    return (
      (e = this.resolveDepth(e)),
      this.index(e) + (e == this.depth && !this.textOffset ? 0 : 1)
    );
  }
  start(e) {
    return ((e = this.resolveDepth(e)), e == 0 ? 0 : this.path[e * 3 - 1] + 1);
  }
  end(e) {
    return (
      (e = this.resolveDepth(e)),
      this.start(e) + this.node(e).content.size
    );
  }
  before(e) {
    if (((e = this.resolveDepth(e)), !e))
      throw new RangeError("There is no position before the top-level node");
    return e == this.depth + 1 ? this.pos : this.path[e * 3 - 1];
  }
  after(e) {
    if (((e = this.resolveDepth(e)), !e))
      throw new RangeError("There is no position after the top-level node");
    return e == this.depth + 1
      ? this.pos
      : this.path[e * 3 - 1] + this.path[e * 3].nodeSize;
  }
  get textOffset() {
    return this.pos - this.path[this.path.length - 1];
  }
  get nodeAfter() {
    let e = this.parent,
      t = this.index(this.depth);
    if (t == e.childCount) return null;
    let r = this.pos - this.path[this.path.length - 1],
      i = e.child(t);
    return r ? e.child(t).cut(r) : i;
  }
  get nodeBefore() {
    let e = this.index(this.depth),
      t = this.pos - this.path[this.path.length - 1];
    return t
      ? this.parent.child(e).cut(0, t)
      : e == 0
        ? null
        : this.parent.child(e - 1);
  }
  posAtIndex(e, t) {
    t = this.resolveDepth(t);
    let r = this.path[t * 3],
      i = t == 0 ? 0 : this.path[t * 3 - 1] + 1;
    for (let s = 0; s < e; s++) i += r.child(s).nodeSize;
    return i;
  }
  marks() {
    let e = this.parent,
      t = this.index();
    if (e.content.size == 0) return z.none;
    if (this.textOffset) return e.child(t).marks;
    let r = e.maybeChild(t - 1),
      i = e.maybeChild(t);
    if (!r) {
      let l = r;
      ((r = i), (i = l));
    }
    let s = r.marks;
    for (var o = 0; o < s.length; o++)
      s[o].type.spec.inclusive === !1 &&
        (!i || !s[o].isInSet(i.marks)) &&
        (s = s[o--].removeFromSet(s));
    return s;
  }
  marksAcross(e) {
    let t = this.parent.maybeChild(this.index());
    if (!t || !t.isInline) return null;
    let r = t.marks,
      i = e.parent.maybeChild(e.index());
    for (var s = 0; s < r.length; s++)
      r[s].type.spec.inclusive === !1 &&
        (!i || !r[s].isInSet(i.marks)) &&
        (r = r[s--].removeFromSet(r));
    return r;
  }
  sharedDepth(e) {
    for (let t = this.depth; t > 0; t--)
      if (this.start(t) <= e && this.end(t) >= e) return t;
    return 0;
  }
  blockRange(e = this, t) {
    if (e.pos < this.pos) return e.blockRange(this);
    for (
      let r =
        this.depth - (this.parent.inlineContent || this.pos == e.pos ? 1 : 0);
      r >= 0;
      r--
    )
      if (e.pos <= this.end(r) && (!t || t(this.node(r))))
        return new br(this, e, r);
    return null;
  }
  sameParent(e) {
    return this.pos - this.parentOffset == e.pos - e.parentOffset;
  }
  max(e) {
    return e.pos > this.pos ? e : this;
  }
  min(e) {
    return e.pos < this.pos ? e : this;
  }
  toString() {
    let e = "";
    for (let t = 1; t <= this.depth; t++)
      e += (e ? "/" : "") + this.node(t).type.name + "_" + this.index(t - 1);
    return e + ":" + this.parentOffset;
  }
  static resolve(e, t) {
    if (!(t >= 0 && t <= e.content.size))
      throw new RangeError("Position " + t + " out of range");
    let r = [],
      i = 0,
      s = t;
    for (let o = e; ;) {
      let { index: l, offset: a } = o.content.findIndex(s),
        c = s - a;
      if ((r.push(o, l, i + a), !c || ((o = o.child(l)), o.isText))) break;
      ((s = c - 1), (i += a + 1));
    }
    return new An(t, r, s);
  }
  static resolveCached(e, t) {
    let r = vo.get(e);
    if (r)
      for (let s = 0; s < r.elts.length; s++) {
        let o = r.elts[s];
        if (o.pos == t) return o;
      }
    else vo.set(e, (r = new zd()));
    let i = (r.elts[r.i] = An.resolve(e, t));
    return ((r.i = (r.i + 1) % Fd), i);
  }
}
class zd {
  constructor() {
    ((this.elts = []), (this.i = 0));
  }
}
const Fd = 12,
  vo = new WeakMap();
class br {
  constructor(e, t, r) {
    ((this.$from = e), (this.$to = t), (this.depth = r));
  }
  get start() {
    return this.$from.before(this.depth + 1);
  }
  get end() {
    return this.$to.after(this.depth + 1);
  }
  get parent() {
    return this.$from.node(this.depth);
  }
  get startIndex() {
    return this.$from.index(this.depth);
  }
  get endIndex() {
    return this.$to.indexAfter(this.depth);
  }
}
const Vd = Object.create(null);
let wt = class Qi {
  constructor(e, t, r, i = z.none) {
    ((this.type = e),
      (this.attrs = t),
      (this.marks = i),
      (this.content = r || b.empty));
  }
  get children() {
    return this.content.content;
  }
  get nodeSize() {
    return this.isLeaf ? 1 : 2 + this.content.size;
  }
  get childCount() {
    return this.content.childCount;
  }
  child(e) {
    return this.content.child(e);
  }
  maybeChild(e) {
    return this.content.maybeChild(e);
  }
  forEach(e) {
    this.content.forEach(e);
  }
  nodesBetween(e, t, r, i = 0) {
    this.content.nodesBetween(e, t, r, i, this);
  }
  descendants(e) {
    this.nodesBetween(0, this.content.size, e);
  }
  get textContent() {
    return this.isLeaf && this.type.spec.leafText
      ? this.type.spec.leafText(this)
      : this.textBetween(0, this.content.size, "");
  }
  textBetween(e, t, r, i) {
    return this.content.textBetween(e, t, r, i);
  }
  get firstChild() {
    return this.content.firstChild;
  }
  get lastChild() {
    return this.content.lastChild;
  }
  eq(e) {
    return this == e || (this.sameMarkup(e) && this.content.eq(e.content));
  }
  sameMarkup(e) {
    return this.hasMarkup(e.type, e.attrs, e.marks);
  }
  hasMarkup(e, t, r) {
    return (
      this.type == e &&
      gr(this.attrs, t || e.defaultAttrs || Vd) &&
      z.sameSet(this.marks, r || z.none)
    );
  }
  copy(e = null) {
    return e == this.content
      ? this
      : new Qi(this.type, this.attrs, e, this.marks);
  }
  mark(e) {
    return e == this.marks
      ? this
      : new Qi(this.type, this.attrs, this.content, e);
  }
  cut(e, t = this.content.size) {
    return e == 0 && t == this.content.size
      ? this
      : this.copy(this.content.cut(e, t));
  }
  slice(e, t = this.content.size, r = !1) {
    if (e == t) return C.empty;
    let i = this.resolve(e),
      s = this.resolve(t),
      o = r ? 0 : i.sharedDepth(t),
      l = i.start(o),
      c = i.node(o).content.cut(i.pos - l, s.pos - l);
    return new C(c, i.depth - o, s.depth - o);
  }
  replace(e, t, r) {
    return Bd(this.resolve(e), this.resolve(t), r);
  }
  nodeAt(e) {
    for (let t = this; ;) {
      let { index: r, offset: i } = t.content.findIndex(e);
      if (((t = t.maybeChild(r)), !t)) return null;
      if (i == e || t.isText) return t;
      e -= i + 1;
    }
  }
  childAfter(e) {
    let { index: t, offset: r } = this.content.findIndex(e);
    return { node: this.content.maybeChild(t), index: t, offset: r };
  }
  childBefore(e) {
    if (e == 0) return { node: null, index: 0, offset: 0 };
    let { index: t, offset: r } = this.content.findIndex(e);
    if (r < e) return { node: this.content.child(t), index: t, offset: r };
    let i = this.content.child(t - 1);
    return { node: i, index: t - 1, offset: r - i.nodeSize };
  }
  resolve(e) {
    return An.resolveCached(this, e);
  }
  resolveNoCache(e) {
    return An.resolve(this, e);
  }
  rangeHasMark(e, t, r) {
    let i = !1;
    return (
      t > e &&
        this.nodesBetween(e, t, (s) => (r.isInSet(s.marks) && (i = !0), !i)),
      i
    );
  }
  get isBlock() {
    return this.type.isBlock;
  }
  get isTextblock() {
    return this.type.isTextblock;
  }
  get inlineContent() {
    return this.type.inlineContent;
  }
  get isInline() {
    return this.type.isInline;
  }
  get isText() {
    return this.type.isText;
  }
  get isLeaf() {
    return this.type.isLeaf;
  }
  get isAtom() {
    return this.type.isAtom;
  }
  toString() {
    if (this.type.spec.toDebugString) return this.type.spec.toDebugString(this);
    let e = this.type.name;
    return (
      this.content.size && (e += "(" + this.content.toStringInner() + ")"),
      Aa(this.marks, e)
    );
  }
  contentMatchAt(e) {
    let t = this.type.contentMatch.matchFragment(this.content, 0, e);
    if (!t)
      throw new Error("Called contentMatchAt on a node with invalid content");
    return t;
  }
  canReplace(e, t, r = b.empty, i = 0, s = r.childCount) {
    let o = this.contentMatchAt(e).matchFragment(r, i, s),
      l = o && o.matchFragment(this.content, t);
    if (!l || !l.validEnd) return !1;
    for (let a = i; a < s; a++)
      if (!this.type.allowsMarks(r.child(a).marks)) return !1;
    return !0;
  }
  canReplaceWith(e, t, r, i) {
    if (i && !this.type.allowsMarks(i)) return !1;
    let s = this.contentMatchAt(e).matchType(r),
      o = s && s.matchFragment(this.content, t);
    return o ? o.validEnd : !1;
  }
  canAppend(e) {
    return e.content.size
      ? this.canReplace(this.childCount, this.childCount, e.content)
      : this.type.compatibleContent(e.type);
  }
  check() {
    (this.type.checkContent(this.content),
      Mo(this.type.attrs, this.attrs, "node", this.type.name));
    let e = z.none;
    for (let t = 0; t < this.marks.length; t++) {
      let r = this.marks[t];
      (Mo(r.type.attrs, r.attrs, "mark", r.type.name), (e = r.addToSet(e)));
    }
    if (!z.sameSet(e, this.marks))
      throw new RangeError(
        `Invalid collection of marks for node ${this.type.name}: ${this.marks.map((t) => t.type.name)}`,
      );
    this.content.forEach((t) => t.check());
  }
  toJSON() {
    let e = { type: this.type.name };
    for (let t in this.attrs) {
      e.attrs = this.attrs;
      break;
    }
    return (
      this.content.size && (e.content = this.content.toJSON()),
      this.marks.length && (e.marks = this.marks.map((t) => t.toJSON())),
      e
    );
  }
  static fromJSON(e, t) {
    if (!t) throw new RangeError("Invalid input for Node.fromJSON");
    let r;
    if (t.marks) {
      if (!Array.isArray(t.marks))
        throw new RangeError("Invalid mark data for Node.fromJSON");
      r = t.marks.map(e.markFromJSON);
    }
    if (t.type == "text") {
      if (typeof t.text != "string")
        throw new RangeError("Invalid text node in JSON");
      return e.text(t.text, r);
    }
    let i = b.fromJSON(e, t.content);
    return e.nodeType(t.type).create(t.attrs, i, r);
  }
};
wt.prototype.text = void 0;
class kr extends wt {
  constructor(e, t, r, i) {
    if ((super(e, t, null, i), !r))
      throw new RangeError("Empty text nodes are not allowed");
    this.text = r;
  }
  toString() {
    return this.type.spec.toDebugString
      ? this.type.spec.toDebugString(this)
      : Aa(this.marks, JSON.stringify(this.text));
  }
  get textContent() {
    return this.text;
  }
  textBetween(e, t) {
    return this.text.slice(e, t);
  }
  get nodeSize() {
    return this.text.length;
  }
  mark(e) {
    return e == this.marks ? this : new kr(this.type, this.attrs, this.text, e);
  }
  withText(e) {
    return e == this.text ? this : new kr(this.type, this.attrs, e, this.marks);
  }
  cut(e = 0, t = this.text.length) {
    return e == 0 && t == this.text.length
      ? this
      : this.withText(this.text.slice(e, t));
  }
  eq(e) {
    return this.sameMarkup(e) && this.text == e.text;
  }
  toJSON() {
    let e = super.toJSON();
    return ((e.text = this.text), e);
  }
}
function Aa(n, e) {
  for (let t = n.length - 1; t >= 0; t--) e = n[t].type.name + "(" + e + ")";
  return e;
}
function Mo(n, e, t, r) {
  for (let i in e)
    if (!(i in n))
      throw new RangeError(`Unsupported attribute ${i} for ${t} of type ${r}`);
  for (let i in n) n[i].validate && n[i].validate(e[i]);
}
class Tt {
  constructor(e) {
    ((this.validEnd = e), (this.next = []), (this.wrapCache = []));
  }
  static parse(e, t) {
    let r = new jd(e, t);
    if (r.next == null) return Tt.empty;
    let i = Oa(r);
    r.next && r.err("Unexpected trailing text");
    let s = Jd(Kd(i));
    return (Gd(s, r), s);
  }
  matchType(e) {
    for (let t = 0; t < this.next.length; t++)
      if (this.next[t].type == e) return this.next[t].next;
    return null;
  }
  matchFragment(e, t = 0, r = e.childCount) {
    let i = this;
    for (let s = t; i && s < r; s++) i = i.matchType(e.child(s).type);
    return i;
  }
  get inlineContent() {
    return this.next.length != 0 && this.next[0].type.isInline;
  }
  get defaultType() {
    for (let e = 0; e < this.next.length; e++) {
      let { type: t } = this.next[e];
      if (!(t.isText || t.hasRequiredAttrs())) return t;
    }
    return null;
  }
  compatible(e) {
    for (let t = 0; t < this.next.length; t++)
      for (let r = 0; r < e.next.length; r++)
        if (this.next[t].type == e.next[r].type) return !0;
    return !1;
  }
  fillBefore(e, t = !1, r = 0) {
    let i = [this];
    function s(o, l) {
      let a = o.matchFragment(e, r);
      if (a && (!t || a.validEnd))
        return b.from(l.map((c) => c.createAndFill()));
      for (let c = 0; c < o.next.length; c++) {
        let { type: u, next: d } = o.next[c];
        if (!(u.isText || u.hasRequiredAttrs()) && i.indexOf(d) == -1) {
          i.push(d);
          let f = s(d, l.concat(u));
          if (f) return f;
        }
      }
      return null;
    }
    return s(this, []);
  }
  findWrapping(e) {
    for (let r = 0; r < this.wrapCache.length; r += 2)
      if (this.wrapCache[r] == e) return this.wrapCache[r + 1];
    let t = this.computeWrapping(e);
    return (this.wrapCache.push(e, t), t);
  }
  computeWrapping(e) {
    let t = Object.create(null),
      r = [{ match: this, type: null, via: null }];
    for (; r.length;) {
      let i = r.shift(),
        s = i.match;
      if (s.matchType(e)) {
        let o = [];
        for (let l = i; l.type; l = l.via) o.push(l.type);
        return o.reverse();
      }
      for (let o = 0; o < s.next.length; o++) {
        let { type: l, next: a } = s.next[o];
        !l.isLeaf &&
          !l.hasRequiredAttrs() &&
          !(l.name in t) &&
          (!i.type || a.validEnd) &&
          (r.push({ match: l.contentMatch, type: l, via: i }),
          (t[l.name] = !0));
      }
    }
    return null;
  }
  get edgeCount() {
    return this.next.length;
  }
  edge(e) {
    if (e >= this.next.length)
      throw new RangeError(`There's no ${e}th edge in this content match`);
    return this.next[e];
  }
  toString() {
    let e = [];
    function t(r) {
      e.push(r);
      for (let i = 0; i < r.next.length; i++)
        e.indexOf(r.next[i].next) == -1 && t(r.next[i].next);
    }
    return (
      t(this),
      e.map((r, i) => {
        let s = i + (r.validEnd ? "*" : " ") + " ";
        for (let o = 0; o < r.next.length; o++)
          s +=
            (o ? ", " : "") +
            r.next[o].type.name +
            "->" +
            e.indexOf(r.next[o].next);
        return s;
      }).join(`
`)
    );
  }
}
Tt.empty = new Tt(!0);
class jd {
  constructor(e, t) {
    ((this.string = e),
      (this.nodeTypes = t),
      (this.inline = null),
      (this.pos = 0),
      (this.tokens = e.split(/\s*(?=\b|\W|$)/)),
      this.tokens[this.tokens.length - 1] == "" && this.tokens.pop(),
      this.tokens[0] == "" && this.tokens.shift());
  }
  get next() {
    return this.tokens[this.pos];
  }
  eat(e) {
    return this.next == e && (this.pos++ || !0);
  }
  err(e) {
    throw new SyntaxError(e + " (in content expression '" + this.string + "')");
  }
}
function Oa(n) {
  let e = [];
  do e.push(Hd(n));
  while (n.eat("|"));
  return e.length == 1 ? e[0] : { type: "choice", exprs: e };
}
function Hd(n) {
  let e = [];
  do e.push(_d(n));
  while (n.next && n.next != ")" && n.next != "|");
  return e.length == 1 ? e[0] : { type: "seq", exprs: e };
}
function _d(n) {
  let e = Ud(n);
  for (;;)
    if (n.eat("+")) e = { type: "plus", expr: e };
    else if (n.eat("*")) e = { type: "star", expr: e };
    else if (n.eat("?")) e = { type: "opt", expr: e };
    else if (n.eat("{")) e = Wd(n, e);
    else break;
  return e;
}
function Eo(n) {
  /\D/.test(n.next) && n.err("Expected number, got '" + n.next + "'");
  let e = Number(n.next);
  return (n.pos++, e);
}
function Wd(n, e) {
  let t = Eo(n),
    r = t;
  return (
    n.eat(",") && (n.next != "}" ? (r = Eo(n)) : (r = -1)),
    n.eat("}") || n.err("Unclosed braced range"),
    { type: "range", min: t, max: r, expr: e }
  );
}
function qd(n, e) {
  let t = n.nodeTypes,
    r = t[e];
  if (r) return [r];
  let i = [];
  for (let s in t) {
    let o = t[s];
    o.isInGroup(e) && i.push(o);
  }
  return (i.length == 0 && n.err("No node type or group '" + e + "' found"), i);
}
function Ud(n) {
  if (n.eat("(")) {
    let e = Oa(n);
    return (n.eat(")") || n.err("Missing closing paren"), e);
  } else if (/\W/.test(n.next)) n.err("Unexpected token '" + n.next + "'");
  else {
    let e = qd(n, n.next).map(
      (t) => (
        n.inline == null
          ? (n.inline = t.isInline)
          : n.inline != t.isInline && n.err("Mixing inline and block content"),
        { type: "name", value: t }
      ),
    );
    return (n.pos++, e.length == 1 ? e[0] : { type: "choice", exprs: e });
  }
}
function Kd(n) {
  let e = [[]];
  return (i(s(n, 0), t()), e);
  function t() {
    return e.push([]) - 1;
  }
  function r(o, l, a) {
    let c = { term: a, to: l };
    return (e[o].push(c), c);
  }
  function i(o, l) {
    o.forEach((a) => (a.to = l));
  }
  function s(o, l) {
    if (o.type == "choice")
      return o.exprs.reduce((a, c) => a.concat(s(c, l)), []);
    if (o.type == "seq")
      for (let a = 0; ; a++) {
        let c = s(o.exprs[a], l);
        if (a == o.exprs.length - 1) return c;
        i(c, (l = t()));
      }
    else if (o.type == "star") {
      let a = t();
      return (r(l, a), i(s(o.expr, a), a), [r(a)]);
    } else if (o.type == "plus") {
      let a = t();
      return (i(s(o.expr, l), a), i(s(o.expr, a), a), [r(a)]);
    } else {
      if (o.type == "opt") return [r(l)].concat(s(o.expr, l));
      if (o.type == "range") {
        let a = l;
        for (let c = 0; c < o.min; c++) {
          let u = t();
          (i(s(o.expr, a), u), (a = u));
        }
        if (o.max == -1) i(s(o.expr, a), a);
        else
          for (let c = o.min; c < o.max; c++) {
            let u = t();
            (r(a, u), i(s(o.expr, a), u), (a = u));
          }
        return [r(a)];
      } else {
        if (o.type == "name") return [r(l, void 0, o.value)];
        throw new Error("Unknown expr type");
      }
    }
  }
}
function Na(n, e) {
  return e - n;
}
function To(n, e) {
  let t = [];
  return (r(e), t.sort(Na));
  function r(i) {
    let s = n[i];
    if (s.length == 1 && !s[0].term) return r(s[0].to);
    t.push(i);
    for (let o = 0; o < s.length; o++) {
      let { term: l, to: a } = s[o];
      !l && t.indexOf(a) == -1 && r(a);
    }
  }
}
function Jd(n) {
  let e = Object.create(null);
  return t(To(n, 0));
  function t(r) {
    let i = [];
    r.forEach((o) => {
      n[o].forEach(({ term: l, to: a }) => {
        if (!l) return;
        let c;
        for (let u = 0; u < i.length; u++) i[u][0] == l && (c = i[u][1]);
        To(n, a).forEach((u) => {
          (c || i.push([l, (c = [])]), c.indexOf(u) == -1 && c.push(u));
        });
      });
    });
    let s = (e[r.join(",")] = new Tt(r.indexOf(n.length - 1) > -1));
    for (let o = 0; o < i.length; o++) {
      let l = i[o][1].sort(Na);
      s.next.push({ type: i[o][0], next: e[l.join(",")] || t(l) });
    }
    return s;
  }
}
function Gd(n, e) {
  for (let t = 0, r = [n]; t < r.length; t++) {
    let i = r[t],
      s = !i.validEnd,
      o = [];
    for (let l = 0; l < i.next.length; l++) {
      let { type: a, next: c } = i.next[l];
      (o.push(a.name),
        s && !(a.isText || a.hasRequiredAttrs()) && (s = !1),
        r.indexOf(c) == -1 && r.push(c));
    }
    s &&
      e.err(
        "Only non-generatable nodes (" +
          o.join(", ") +
          ") in a required position (see https://prosemirror.net/docs/guide/#generatable)",
      );
  }
}
function Da(n) {
  let e = Object.create(null);
  for (let t in n) {
    let r = n[t];
    if (!r.hasDefault) return null;
    e[t] = r.default;
  }
  return e;
}
function Ra(n, e) {
  let t = Object.create(null);
  for (let r in n) {
    let i = n[r],
      s = e && e[r];
    if (s === void 0)
      if (i.hasDefault) s = i.default;
      else throw new RangeError("No value supplied for attribute " + r);
    else i.validate && i.validate(s);
    t[r] = s;
  }
  return t;
}
function Ia(n, e) {
  let t = Object.create(null);
  if (e) for (let r in e) t[r] = new Xd(n, r, e[r]);
  return t;
}
let Zi = class La {
  constructor(e, t, r) {
    ((this.name = e),
      (this.schema = t),
      (this.spec = r),
      (this.markSet = null),
      (this.groups = r.group ? r.group.split(" ") : []),
      (this.attrs = Ia(e, r.attrs)),
      (this.defaultAttrs = Da(this.attrs)),
      (this.contentMatch = null),
      (this.inlineContent = null),
      (this.isBlock = !(r.inline || e == "text")),
      (this.isText = e == "text"));
  }
  get isInline() {
    return !this.isBlock;
  }
  get isTextblock() {
    return this.isBlock && this.inlineContent;
  }
  get isLeaf() {
    return this.contentMatch == Tt.empty;
  }
  get isAtom() {
    return this.isLeaf || !!this.spec.atom;
  }
  isInGroup(e) {
    return this.groups.indexOf(e) > -1;
  }
  get whitespace() {
    return this.spec.whitespace || (this.spec.code ? "pre" : "normal");
  }
  hasRequiredAttrs() {
    for (let e in this.attrs) if (this.attrs[e].isRequired) return !0;
    return !1;
  }
  compatibleContent(e) {
    return this == e || this.contentMatch.compatible(e.contentMatch);
  }
  computeAttrs(e) {
    return !e && this.defaultAttrs ? this.defaultAttrs : Ra(this.attrs, e);
  }
  create(e = null, t, r) {
    if (this.isText)
      throw new Error("NodeType.create can't construct text nodes");
    return new wt(this, this.computeAttrs(e), b.from(t), z.setFrom(r));
  }
  createChecked(e = null, t, r) {
    return (
      (t = b.from(t)),
      this.checkContent(t),
      new wt(this, this.computeAttrs(e), t, z.setFrom(r))
    );
  }
  createAndFill(e = null, t, r) {
    if (((e = this.computeAttrs(e)), (t = b.from(t)), t.size)) {
      let o = this.contentMatch.fillBefore(t);
      if (!o) return null;
      t = o.append(t);
    }
    let i = this.contentMatch.matchFragment(t),
      s = i && i.fillBefore(b.empty, !0);
    return s ? new wt(this, e, t.append(s), z.setFrom(r)) : null;
  }
  validContent(e) {
    let t = this.contentMatch.matchFragment(e);
    if (!t || !t.validEnd) return !1;
    for (let r = 0; r < e.childCount; r++)
      if (!this.allowsMarks(e.child(r).marks)) return !1;
    return !0;
  }
  checkContent(e) {
    if (!this.validContent(e))
      throw new RangeError(
        `Invalid content for node ${this.name}: ${e.toString().slice(0, 50)}`,
      );
  }
  checkAttrs(e) {}
  allowsMarkType(e) {
    return this.markSet == null || this.markSet.indexOf(e) > -1;
  }
  allowsMarks(e) {
    if (this.markSet == null) return !0;
    for (let t = 0; t < e.length; t++)
      if (!this.allowsMarkType(e[t].type)) return !1;
    return !0;
  }
  allowedMarks(e) {
    if (this.markSet == null) return e;
    let t;
    for (let r = 0; r < e.length; r++)
      this.allowsMarkType(e[r].type)
        ? t && t.push(e[r])
        : t || (t = e.slice(0, r));
    return t ? (t.length ? t : z.none) : e;
  }
  static compile(e, t) {
    let r = Object.create(null);
    e.forEach((s, o) => (r[s] = new La(s, t, o)));
    let i = t.spec.topNode || "doc";
    if (!r[i])
      throw new RangeError("Schema is missing its top node type ('" + i + "')");
    if (!r.text) throw new RangeError("Every schema needs a 'text' type");
    for (let s in r.text.attrs)
      throw new RangeError("The text node type should not have attributes");
    return r;
  }
};
function Yd(n, e, t) {
  let r = t.split("|");
  return (i) => {
    let s = i === null ? "null" : typeof i;
    if (r.indexOf(s) < 0)
      throw new RangeError(
        `Expected value of type ${r} for attribute ${e} on type ${n}, got ${s}`,
      );
  };
}
class Xd {
  constructor(e, t, r) {
    ((this.hasDefault = Object.prototype.hasOwnProperty.call(r, "default")),
      (this.default = r.default),
      (this.validate =
        typeof r.validate == "string" ? Yd(e, t, r.validate) : r.validate));
  }
  get isRequired() {
    return !this.hasDefault;
  }
}
class oi {
  constructor(e, t, r, i) {
    ((this.name = e),
      (this.rank = t),
      (this.schema = r),
      (this.spec = i),
      (this.attrs = Ia(e, i.attrs)),
      (this.excluded = null));
    let s = Da(this.attrs);
    this.instance = s ? new z(this, s) : null;
  }
  create(e = null) {
    return !e && this.instance ? this.instance : new z(this, Ra(this.attrs, e));
  }
  static compile(e, t) {
    let r = Object.create(null),
      i = 0;
    return (e.forEach((s, o) => (r[s] = new oi(s, i++, t, o))), r);
  }
  removeFromSet(e) {
    for (var t = 0; t < e.length; t++)
      e[t].type == this && ((e = e.slice(0, t).concat(e.slice(t + 1))), t--);
    return e;
  }
  isInSet(e) {
    for (let t = 0; t < e.length; t++) if (e[t].type == this) return e[t];
  }
  excludes(e) {
    return this.excluded.indexOf(e) > -1;
  }
}
class ar {
  constructor(e) {
    ((this.linebreakReplacement = null), (this.cached = Object.create(null)));
    let t = (this.spec = {});
    for (let i in e) t[i] = e[i];
    ((t.nodes = ee.from(e.nodes)),
      (t.marks = ee.from(e.marks || {})),
      (this.nodes = Zi.compile(this.spec.nodes, this)),
      (this.marks = oi.compile(this.spec.marks, this)));
    let r = Object.create(null);
    for (let i in this.nodes) {
      if (i in this.marks)
        throw new RangeError(i + " can not be both a node and a mark");
      let s = this.nodes[i],
        o = s.spec.content || "",
        l = s.spec.marks;
      if (
        ((s.contentMatch = r[o] || (r[o] = Tt.parse(o, this.nodes))),
        (s.inlineContent = s.contentMatch.inlineContent),
        s.spec.linebreakReplacement)
      ) {
        if (this.linebreakReplacement)
          throw new RangeError("Multiple linebreak nodes defined");
        if (!s.isInline || !s.isLeaf)
          throw new RangeError(
            "Linebreak replacement nodes must be inline leaf nodes",
          );
        this.linebreakReplacement = s;
      }
      s.markSet =
        l == "_"
          ? null
          : l
            ? Ao(this, l.split(" "))
            : l == "" || !s.inlineContent
              ? []
              : null;
    }
    for (let i in this.marks) {
      let s = this.marks[i],
        o = s.spec.excludes;
      s.excluded = o == null ? [s] : o == "" ? [] : Ao(this, o.split(" "));
    }
    ((this.nodeFromJSON = (i) => wt.fromJSON(this, i)),
      (this.markFromJSON = (i) => z.fromJSON(this, i)),
      (this.topNodeType = this.nodes[this.spec.topNode || "doc"]),
      (this.cached.wrappings = Object.create(null)));
  }
  node(e, t = null, r, i) {
    if (typeof e == "string") e = this.nodeType(e);
    else if (e instanceof Zi) {
      if (e.schema != this)
        throw new RangeError(
          "Node type from different schema used (" + e.name + ")",
        );
    } else throw new RangeError("Invalid node type: " + e);
    return e.createChecked(t, r, i);
  }
  text(e, t) {
    let r = this.nodes.text;
    return new kr(r, r.defaultAttrs, e, z.setFrom(t));
  }
  mark(e, t) {
    return (typeof e == "string" && (e = this.marks[e]), e.create(t));
  }
  nodeType(e) {
    let t = this.nodes[e];
    if (!t) throw new RangeError("Unknown node type: " + e);
    return t;
  }
}
function Ao(n, e) {
  let t = [];
  for (let r = 0; r < e.length; r++) {
    let i = e[r],
      s = n.marks[i],
      o = s;
    if (s) t.push(s);
    else
      for (let l in n.marks) {
        let a = n.marks[l];
        (i == "_" ||
          (a.spec.group && a.spec.group.split(" ").indexOf(i) > -1)) &&
          t.push((o = a));
      }
    if (!o) throw new SyntaxError("Unknown mark type: '" + e[r] + "'");
  }
  return t;
}
function Qd(n) {
  return n.tag != null;
}
function Zd(n) {
  return n.style != null;
}
class et {
  constructor(e, t) {
    ((this.schema = e), (this.rules = t), (this.tags = []), (this.styles = []));
    let r = (this.matchedStyles = []);
    (t.forEach((i) => {
      if (Qd(i)) this.tags.push(i);
      else if (Zd(i)) {
        let s = /[^=]*/.exec(i.style)[0];
        (r.indexOf(s) < 0 && r.push(s), this.styles.push(i));
      }
    }),
      (this.normalizeLists = !this.tags.some((i) => {
        if (!/^(ul|ol)\b/.test(i.tag) || !i.node) return !1;
        let s = e.nodes[i.node];
        return s.contentMatch.matchType(s);
      })));
  }
  parse(e, t = {}) {
    let r = new No(this, t, !1);
    return (r.addAll(e, z.none, t.from, t.to), r.finish());
  }
  parseSlice(e, t = {}) {
    let r = new No(this, t, !0);
    return (r.addAll(e, z.none, t.from, t.to), C.maxOpen(r.finish()));
  }
  matchTag(e, t, r) {
    for (let i = r ? this.tags.indexOf(r) + 1 : 0; i < this.tags.length; i++) {
      let s = this.tags[i];
      if (
        nf(e, s.tag) &&
        (s.namespace === void 0 || e.namespaceURI == s.namespace) &&
        (!s.context || t.matchesContext(s.context))
      ) {
        if (s.getAttrs) {
          let o = s.getAttrs(e);
          if (o === !1) continue;
          s.attrs = o || void 0;
        }
        return s;
      }
    }
  }
  matchStyle(e, t, r, i) {
    for (
      let s = i ? this.styles.indexOf(i) + 1 : 0;
      s < this.styles.length;
      s++
    ) {
      let o = this.styles[s],
        l = o.style;
      if (!(
        l.indexOf(e) != 0 ||
        (o.context && !r.matchesContext(o.context)) ||
        (l.length > e.length &&
          (l.charCodeAt(e.length) != 61 || l.slice(e.length + 1) != t))
      )) {
        if (o.getAttrs) {
          let a = o.getAttrs(t);
          if (a === !1) continue;
          o.attrs = a || void 0;
        }
        return o;
      }
    }
  }
  static schemaRules(e) {
    let t = [];
    function r(i) {
      let s = i.priority == null ? 50 : i.priority,
        o = 0;
      for (; o < t.length; o++) {
        let l = t[o];
        if ((l.priority == null ? 50 : l.priority) < s) break;
      }
      t.splice(o, 0, i);
    }
    for (let i in e.marks) {
      let s = e.marks[i].spec.parseDOM;
      s &&
        s.forEach((o) => {
          (r((o = Do(o))), o.mark || o.ignore || o.clearMark || (o.mark = i));
        });
    }
    for (let i in e.nodes) {
      let s = e.nodes[i].spec.parseDOM;
      s &&
        s.forEach((o) => {
          (r((o = Do(o))), o.node || o.ignore || o.mark || (o.node = i));
        });
    }
    return t;
  }
  static fromSchema(e) {
    return (
      e.cached.domParser || (e.cached.domParser = new et(e, et.schemaRules(e)))
    );
  }
}
const Pa = {
    address: !0,
    article: !0,
    aside: !0,
    blockquote: !0,
    body: !0,
    canvas: !0,
    dd: !0,
    div: !0,
    dl: !0,
    fieldset: !0,
    figcaption: !0,
    figure: !0,
    footer: !0,
    form: !0,
    h1: !0,
    h2: !0,
    h3: !0,
    h4: !0,
    h5: !0,
    h6: !0,
    header: !0,
    hgroup: !0,
    hr: !0,
    li: !0,
    noscript: !0,
    ol: !0,
    output: !0,
    p: !0,
    pre: !0,
    section: !0,
    table: !0,
    tfoot: !0,
    ul: !0,
  },
  ef = { head: !0, noscript: !0, object: !0, script: !0, style: !0, title: !0 },
  Ba = { ol: !0, ul: !0 },
  On = 1,
  es = 2,
  gn = 4;
function Oo(n, e, t) {
  return e != null
    ? (e ? On : 0) | (e === "full" ? es : 0)
    : n && n.whitespace == "pre"
      ? On | es
      : t & ~gn;
}
class Jn {
  constructor(e, t, r, i, s, o) {
    ((this.type = e),
      (this.attrs = t),
      (this.marks = r),
      (this.solid = i),
      (this.options = o),
      (this.content = []),
      (this.activeMarks = z.none),
      (this.match = s || (o & gn ? null : e.contentMatch)));
  }
  findWrapping(e) {
    if (!this.match) {
      if (!this.type) return [];
      let t = this.type.contentMatch.fillBefore(b.from(e));
      if (t) this.match = this.type.contentMatch.matchFragment(t);
      else {
        let r = this.type.contentMatch,
          i;
        return (i = r.findWrapping(e.type)) ? ((this.match = r), i) : null;
      }
    }
    return this.match.findWrapping(e.type);
  }
  finish(e) {
    if (!(this.options & On)) {
      let r = this.content[this.content.length - 1],
        i;
      if (r && r.isText && (i = /[ \t\r\n\u000c]+$/.exec(r.text))) {
        let s = r;
        r.text.length == i[0].length
          ? this.content.pop()
          : (this.content[this.content.length - 1] = s.withText(
              s.text.slice(0, s.text.length - i[0].length),
            ));
      }
    }
    let t = b.from(this.content);
    return (
      !e && this.match && (t = t.append(this.match.fillBefore(b.empty, !0))),
      this.type ? this.type.create(this.attrs, t, this.marks) : t
    );
  }
  inlineContext(e) {
    return this.type
      ? this.type.inlineContent
      : this.content.length
        ? this.content[0].isInline
        : e.parentNode &&
          !Pa.hasOwnProperty(e.parentNode.nodeName.toLowerCase());
  }
}
class No {
  constructor(e, t, r) {
    ((this.parser = e),
      (this.options = t),
      (this.isOpen = r),
      (this.open = 0),
      (this.localPreserveWS = !1));
    let i = t.topNode,
      s,
      o = Oo(null, t.preserveWhitespace, 0) | (r ? gn : 0);
    (i
      ? (s = new Jn(
          i.type,
          i.attrs,
          z.none,
          !0,
          t.topMatch || i.type.contentMatch,
          o,
        ))
      : r
        ? (s = new Jn(null, null, z.none, !0, null, o))
        : (s = new Jn(e.schema.topNodeType, null, z.none, !0, null, o)),
      (this.nodes = [s]),
      (this.find = t.findPositions),
      (this.needsBlock = !1));
  }
  get top() {
    return this.nodes[this.open];
  }
  addDOM(e, t) {
    e.nodeType == 3
      ? this.addTextNode(e, t)
      : e.nodeType == 1 && this.addElement(e, t);
  }
  addTextNode(e, t) {
    let r = e.nodeValue,
      i = this.top,
      s =
        i.options & es ? "full" : this.localPreserveWS || (i.options & On) > 0,
      { schema: o } = this.parser;
    if (s === "full" || i.inlineContext(e) || /[^ \t\r\n\u000c]/.test(r)) {
      if (s)
        if (s === "full")
          r = r.replace(
            /\r\n?/g,
            `
`,
          );
        else if (
          o.linebreakReplacement &&
          /[\r\n]/.test(r) &&
          this.top.findWrapping(o.linebreakReplacement.create())
        ) {
          let l = r.split(/\r?\n|\r/);
          for (let a = 0; a < l.length; a++)
            (a && this.insertNode(o.linebreakReplacement.create(), t, !0),
              l[a] && this.insertNode(o.text(l[a]), t, !/\S/.test(l[a])));
          r = "";
        } else r = r.replace(/\r?\n|\r/g, " ");
      else if (
        ((r = r.replace(/[ \t\r\n\u000c]+/g, " ")),
        /^[ \t\r\n\u000c]/.test(r) && this.open == this.nodes.length - 1)
      ) {
        let l = i.content[i.content.length - 1],
          a = e.previousSibling;
        (!l ||
          (a && a.nodeName == "BR") ||
          (l.isText && /[ \t\r\n\u000c]$/.test(l.text))) &&
          (r = r.slice(1));
      }
      (r && this.insertNode(o.text(r), t, !/\S/.test(r)), this.findInText(e));
    } else this.findInside(e);
  }
  addElement(e, t, r) {
    let i = this.localPreserveWS,
      s = this.top;
    (e.tagName == "PRE" || /pre/.test(e.style && e.style.whiteSpace)) &&
      (this.localPreserveWS = !0);
    let o = e.nodeName.toLowerCase(),
      l;
    Ba.hasOwnProperty(o) && this.parser.normalizeLists && tf(e);
    let a =
      (this.options.ruleFromNode && this.options.ruleFromNode(e)) ||
      (l = this.parser.matchTag(e, this, r));
    e: if (a ? a.ignore : ef.hasOwnProperty(o))
      (this.findInside(e), this.ignoreFallback(e, t));
    else if (!a || a.skip || a.closeParent) {
      a && a.closeParent
        ? (this.open = Math.max(0, this.open - 1))
        : a && a.skip.nodeType && (e = a.skip);
      let c,
        u = this.needsBlock;
      if (Pa.hasOwnProperty(o))
        (s.content.length &&
          s.content[0].isInline &&
          this.open &&
          (this.open--, (s = this.top)),
          (c = !0),
          s.type || (this.needsBlock = !0));
      else if (!e.firstChild) {
        this.leafFallback(e, t);
        break e;
      }
      let d = a && a.skip ? t : this.readStyles(e, t);
      (d && this.addAll(e, d), c && this.sync(s), (this.needsBlock = u));
    } else {
      let c = this.readStyles(e, t);
      c && this.addElementByRule(e, a, c, a.consuming === !1 ? l : void 0);
    }
    this.localPreserveWS = i;
  }
  leafFallback(e, t) {
    e.nodeName == "BR" &&
      this.top.type &&
      this.top.type.inlineContent &&
      this.addTextNode(
        e.ownerDocument.createTextNode(`
`),
        t,
      );
  }
  ignoreFallback(e, t) {
    e.nodeName == "BR" &&
      (!this.top.type || !this.top.type.inlineContent) &&
      this.findPlace(this.parser.schema.text("-"), t, !0);
  }
  readStyles(e, t) {
    let r = e.style;
    if (r && r.length)
      for (let i = 0; i < this.parser.matchedStyles.length; i++) {
        let s = this.parser.matchedStyles[i],
          o = r.getPropertyValue(s);
        if (o)
          for (let l = void 0; ;) {
            let a = this.parser.matchStyle(s, o, this, l);
            if (!a) break;
            if (a.ignore) return null;
            if (
              (a.clearMark
                ? (t = t.filter((c) => !a.clearMark(c)))
                : (t = t.concat(
                    this.parser.schema.marks[a.mark].create(a.attrs),
                  )),
              a.consuming === !1)
            )
              l = a;
            else break;
          }
      }
    return t;
  }
  addElementByRule(e, t, r, i) {
    let s, o;
    if (t.node)
      if (((o = this.parser.schema.nodes[t.node]), o.isLeaf))
        this.insertNode(o.create(t.attrs), r, e.nodeName == "BR") ||
          this.leafFallback(e, r);
      else {
        let a = this.enter(o, t.attrs || null, r, t.preserveWhitespace);
        a && ((s = !0), (r = a));
      }
    else {
      let a = this.parser.schema.marks[t.mark];
      r = r.concat(a.create(t.attrs));
    }
    let l = this.top;
    if (o && o.isLeaf) this.findInside(e);
    else if (i) this.addElement(e, r, i);
    else if (t.getContent)
      (this.findInside(e),
        t
          .getContent(e, this.parser.schema)
          .forEach((a) => this.insertNode(a, r, !1)));
    else {
      let a = e;
      (typeof t.contentElement == "string"
        ? (a = e.querySelector(t.contentElement))
        : typeof t.contentElement == "function"
          ? (a = t.contentElement(e))
          : t.contentElement && (a = t.contentElement),
        this.findAround(e, a, !0),
        this.addAll(a, r),
        this.findAround(e, a, !1));
    }
    s && this.sync(l) && this.open--;
  }
  addAll(e, t, r, i) {
    let s = r || 0;
    for (
      let o = r ? e.childNodes[r] : e.firstChild,
        l = i == null ? null : e.childNodes[i];
      o != l;
      o = o.nextSibling, ++s
    )
      (this.findAtPoint(e, s), this.addDOM(o, t));
    this.findAtPoint(e, s);
  }
  findPlace(e, t, r) {
    let i, s;
    for (let o = this.open, l = 0; o >= 0; o--) {
      let a = this.nodes[o],
        c = a.findWrapping(e);
      if (c && (!i || i.length > c.length + l) && ((i = c), (s = a), !c.length))
        break;
      if (a.solid) {
        if (r) break;
        l += 2;
      }
    }
    if (!i) return null;
    this.sync(s);
    for (let o = 0; o < i.length; o++) t = this.enterInner(i[o], null, t, !1);
    return t;
  }
  insertNode(e, t, r) {
    if (e.isInline && this.needsBlock && !this.top.type) {
      let s = this.textblockFromContext();
      s && (t = this.enterInner(s, null, t));
    }
    let i = this.findPlace(e, t, r);
    if (i) {
      this.closeExtra();
      let s = this.top;
      s.match && (s.match = s.match.matchType(e.type));
      let o = z.none;
      for (let l of i.concat(e.marks))
        (s.type ? s.type.allowsMarkType(l.type) : Ro(l.type, e.type)) &&
          (o = l.addToSet(o));
      return (s.content.push(e.mark(o)), !0);
    }
    return !1;
  }
  enter(e, t, r, i) {
    let s = this.findPlace(e.create(t), r, !1);
    return (s && (s = this.enterInner(e, t, r, !0, i)), s);
  }
  enterInner(e, t, r, i = !1, s) {
    this.closeExtra();
    let o = this.top;
    o.match = o.match && o.match.matchType(e);
    let l = Oo(e, s, o.options);
    o.options & gn && o.content.length == 0 && (l |= gn);
    let a = z.none;
    return (
      (r = r.filter((c) =>
        (o.type ? o.type.allowsMarkType(c.type) : Ro(c.type, e))
          ? ((a = c.addToSet(a)), !1)
          : !0,
      )),
      this.nodes.push(new Jn(e, t, a, i, null, l)),
      this.open++,
      r
    );
  }
  closeExtra(e = !1) {
    let t = this.nodes.length - 1;
    if (t > this.open) {
      for (; t > this.open; t--)
        this.nodes[t - 1].content.push(this.nodes[t].finish(e));
      this.nodes.length = this.open + 1;
    }
  }
  finish() {
    return (
      (this.open = 0),
      this.closeExtra(this.isOpen),
      this.nodes[0].finish(!!(this.isOpen || this.options.topOpen))
    );
  }
  sync(e) {
    for (let t = this.open; t >= 0; t--) {
      if (this.nodes[t] == e) return ((this.open = t), !0);
      this.localPreserveWS && (this.nodes[t].options |= On);
    }
    return !1;
  }
  get currentPos() {
    this.closeExtra();
    let e = 0;
    for (let t = this.open; t >= 0; t--) {
      let r = this.nodes[t].content;
      for (let i = r.length - 1; i >= 0; i--) e += r[i].nodeSize;
      t && e++;
    }
    return e;
  }
  findAtPoint(e, t) {
    if (this.find)
      for (let r = 0; r < this.find.length; r++)
        this.find[r].node == e &&
          this.find[r].offset == t &&
          (this.find[r].pos = this.currentPos);
  }
  findInside(e) {
    if (this.find)
      for (let t = 0; t < this.find.length; t++)
        this.find[t].pos == null &&
          e.nodeType == 1 &&
          e.contains(this.find[t].node) &&
          (this.find[t].pos = this.currentPos);
  }
  findAround(e, t, r) {
    if (e != t && this.find)
      for (let i = 0; i < this.find.length; i++)
        this.find[i].pos == null &&
          e.nodeType == 1 &&
          e.contains(this.find[i].node) &&
          t.compareDocumentPosition(this.find[i].node) & (r ? 2 : 4) &&
          (this.find[i].pos = this.currentPos);
  }
  findInText(e) {
    if (this.find)
      for (let t = 0; t < this.find.length; t++)
        this.find[t].node == e &&
          (this.find[t].pos =
            this.currentPos - (e.nodeValue.length - this.find[t].offset));
  }
  matchesContext(e) {
    if (e.indexOf("|") > -1)
      return e.split(/\s*\|\s*/).some(this.matchesContext, this);
    let t = e.split("/"),
      r = this.options.context,
      i = !this.isOpen && (!r || r.parent.type == this.nodes[0].type),
      s = -(r ? r.depth + 1 : 0) + (i ? 0 : 1),
      o = (l, a) => {
        for (; l >= 0; l--) {
          let c = t[l];
          if (c == "") {
            if (l == t.length - 1 || l == 0) continue;
            for (; a >= s; a--) if (o(l - 1, a)) return !0;
            return !1;
          } else {
            let u =
              a > 0 || (a == 0 && i)
                ? this.nodes[a].type
                : r && a >= s
                  ? r.node(a - s).type
                  : null;
            if (!u || (u.name != c && !u.isInGroup(c))) return !1;
            a--;
          }
        }
        return !0;
      };
    return o(t.length - 1, this.open);
  }
  textblockFromContext() {
    let e = this.options.context;
    if (e)
      for (let t = e.depth; t >= 0; t--) {
        let r = e.node(t).contentMatchAt(e.indexAfter(t)).defaultType;
        if (r && r.isTextblock && r.defaultAttrs) return r;
      }
    for (let t in this.parser.schema.nodes) {
      let r = this.parser.schema.nodes[t];
      if (r.isTextblock && r.defaultAttrs) return r;
    }
  }
}
function tf(n) {
  for (let e = n.firstChild, t = null; e; e = e.nextSibling) {
    let r = e.nodeType == 1 ? e.nodeName.toLowerCase() : null;
    r && Ba.hasOwnProperty(r) && t
      ? (t.appendChild(e), (e = t))
      : r == "li"
        ? (t = e)
        : r && (t = null);
  }
}
function nf(n, e) {
  return (
    n.matches ||
    n.msMatchesSelector ||
    n.webkitMatchesSelector ||
    n.mozMatchesSelector
  ).call(n, e);
}
function Do(n) {
  let e = {};
  for (let t in n) e[t] = n[t];
  return e;
}
function Ro(n, e) {
  let t = e.schema.nodes;
  for (let r in t) {
    let i = t[r];
    if (!i.allowsMarkType(n)) continue;
    let s = [],
      o = (l) => {
        s.push(l);
        for (let a = 0; a < l.edgeCount; a++) {
          let { type: c, next: u } = l.edge(a);
          if (c == e || (s.indexOf(u) < 0 && o(u))) return !0;
        }
      };
    if (o(i.contentMatch)) return !0;
  }
}
class Rt {
  constructor(e, t) {
    ((this.nodes = e), (this.marks = t));
  }
  serializeFragment(e, t = {}, r) {
    r || (r = Gn(t).createDocumentFragment());
    let i = r,
      s = [];
    return (
      e.forEach((o) => {
        if (s.length || o.marks.length) {
          let l = 0,
            a = 0;
          for (; l < s.length && a < o.marks.length;) {
            let c = o.marks[a];
            if (!this.marks[c.type.name]) {
              a++;
              continue;
            }
            if (!c.eq(s[l][0]) || c.type.spec.spanning === !1) break;
            (l++, a++);
          }
          for (; l < s.length;) i = s.pop()[1];
          for (; a < o.marks.length;) {
            let c = o.marks[a++],
              u = this.serializeMark(c, o.isInline, t);
            u &&
              (s.push([c, i]),
              i.appendChild(u.dom),
              (i = u.contentDOM || u.dom));
          }
        }
        i.appendChild(this.serializeNodeInner(o, t));
      }),
      r
    );
  }
  serializeNodeInner(e, t) {
    if (e.isText) return Gn(t).createTextNode(e.text);
    let { dom: r, contentDOM: i } = cr(
      Gn(t),
      this.nodes[e.type.name](e),
      null,
      e.attrs,
    );
    if (i) {
      if (e.isLeaf)
        throw new RangeError("Content hole not allowed in a leaf node spec");
      this.serializeFragment(e.content, t, i);
    }
    return r;
  }
  serializeNode(e, t = {}) {
    let r = this.serializeNodeInner(e, t);
    for (let i = e.marks.length - 1; i >= 0; i--) {
      let s = this.serializeMark(e.marks[i], e.isInline, t);
      s && ((s.contentDOM || s.dom).appendChild(r), (r = s.dom));
    }
    return r;
  }
  serializeMark(e, t, r = {}) {
    let i = this.marks[e.type.name];
    return i && cr(Gn(r), i(e, t), null, e.attrs);
  }
  static renderSpec(e, t, r = null, i) {
    return typeof t == "string" ? { dom: e.createTextNode(t) } : cr(e, t, r, i);
  }
  static fromSchema(e) {
    return (
      e.cached.domSerializer ||
      (e.cached.domSerializer = new Rt(
        this.nodesFromSchema(e),
        this.marksFromSchema(e),
      ))
    );
  }
  static nodesFromSchema(e) {
    let t = Io(e.nodes);
    return (t.text || (t.text = (r) => r.text), t);
  }
  static marksFromSchema(e) {
    return Io(e.marks);
  }
}
function Io(n) {
  let e = {};
  for (let t in n) {
    let r = n[t].spec.toDOM;
    r && (e[t] = r);
  }
  return e;
}
function Gn(n) {
  return n.document || window.document;
}
const Lo = new WeakMap();
function rf(n) {
  let e = Lo.get(n);
  return (e === void 0 && Lo.set(n, (e = sf(n))), e);
}
function sf(n) {
  let e = null;
  function t(r) {
    if (r && typeof r == "object")
      if (Array.isArray(r))
        if (typeof r[0] == "string") (e || (e = []), e.push(r));
        else for (let i = 0; i < r.length; i++) t(r[i]);
      else for (let i in r) t(r[i]);
  }
  return (t(n), e);
}
function cr(n, e, t, r) {
  if (e.nodeType == 1) return { dom: e };
  if (e.dom && e.dom.nodeType == 1) return e;
  let i = e[0],
    s;
  if (typeof i != "string")
    throw new RangeError("Invalid array passed to renderSpec");
  if (r && (s = rf(r)) && s.indexOf(e) > -1)
    throw new RangeError(
      "Using an array from an attribute object as a DOM spec. This may be an attempted cross site scripting attack.",
    );
  let o = i.indexOf(" ");
  o > 0 && ((t = i.slice(0, o)), (i = i.slice(o + 1)));
  let l,
    a = t ? n.createElementNS(t, i) : n.createElement(i),
    c = e[1],
    u = 1;
  if (c && typeof c == "object" && c.nodeType == null && !Array.isArray(c)) {
    u = 2;
    for (let d in c)
      if (c[d] != null) {
        let f = d.indexOf(" ");
        f > 0
          ? a.setAttributeNS(d.slice(0, f), d.slice(f + 1), c[d])
          : d == "style" && a.style
            ? (a.style.cssText = c[d])
            : a.setAttribute(d, c[d]);
      }
  }
  for (let d = u; d < e.length; d++) {
    let f = e[d];
    if (f === 0) {
      if (d < e.length - 1 || d > u)
        throw new RangeError(
          "Content hole must be the only child of its parent node",
        );
      return { dom: a, contentDOM: a };
    } else if (typeof f == "string") a.appendChild(n.createTextNode(f));
    else {
      let { dom: h, contentDOM: p } = cr(n, f, t, r);
      if ((a.appendChild(h), p)) {
        if (l) throw new RangeError("Multiple content holes");
        l = p;
      }
    }
  }
  return { dom: a, contentDOM: l };
}
const $a = 65535,
  za = Math.pow(2, 16);
function of(n, e) {
  return n + e * za;
}
function Po(n) {
  return n & $a;
}
function lf(n) {
  return (n - (n & $a)) / za;
}
const Fa = 1,
  Va = 2,
  ur = 4,
  ja = 8;
class ts {
  constructor(e, t, r) {
    ((this.pos = e), (this.delInfo = t), (this.recover = r));
  }
  get deleted() {
    return (this.delInfo & ja) > 0;
  }
  get deletedBefore() {
    return (this.delInfo & (Fa | ur)) > 0;
  }
  get deletedAfter() {
    return (this.delInfo & (Va | ur)) > 0;
  }
  get deletedAcross() {
    return (this.delInfo & ur) > 0;
  }
}
class ge {
  constructor(e, t = !1) {
    if (((this.ranges = e), (this.inverted = t), !e.length && ge.empty))
      return ge.empty;
  }
  recover(e) {
    let t = 0,
      r = Po(e);
    if (!this.inverted)
      for (let i = 0; i < r; i++)
        t += this.ranges[i * 3 + 2] - this.ranges[i * 3 + 1];
    return this.ranges[r * 3] + t + lf(e);
  }
  mapResult(e, t = 1) {
    return this._map(e, t, !1);
  }
  map(e, t = 1) {
    return this._map(e, t, !0);
  }
  _map(e, t, r) {
    let i = 0,
      s = this.inverted ? 2 : 1,
      o = this.inverted ? 1 : 2;
    for (let l = 0; l < this.ranges.length; l += 3) {
      let a = this.ranges[l] - (this.inverted ? i : 0);
      if (a > e) break;
      let c = this.ranges[l + s],
        u = this.ranges[l + o],
        d = a + c;
      if (e <= d) {
        let f = c ? (e == a ? -1 : e == d ? 1 : t) : t,
          h = a + i + (f < 0 ? 0 : u);
        if (r) return h;
        let p = e == (t < 0 ? a : d) ? null : of(l / 3, e - a),
          g = 0;
        return (
          c &&
            ((g |= e == a ? Va : e == d ? Fa : ur),
            (t < 0 ? e != a : e != d) && (g |= ja)),
          new ts(h, g, p)
        );
      }
      i += u - c;
    }
    return r ? e + i : new ts(e + i, 0, null);
  }
  touches(e, t) {
    let r = 0,
      i = Po(t),
      s = this.inverted ? 2 : 1,
      o = this.inverted ? 1 : 2;
    for (let l = 0; l < this.ranges.length; l += 3) {
      let a = this.ranges[l] - (this.inverted ? r : 0);
      if (a > e) break;
      let c = this.ranges[l + s],
        u = a + c;
      if (e <= u && l == i * 3) return !0;
      r += this.ranges[l + o] - c;
    }
    return !1;
  }
  forEach(e) {
    let t = this.inverted ? 2 : 1,
      r = this.inverted ? 1 : 2;
    for (let i = 0, s = 0; i < this.ranges.length; i += 3) {
      let o = this.ranges[i],
        l = o - (this.inverted ? s : 0),
        a = o + (this.inverted ? 0 : s),
        c = this.ranges[i + t],
        u = this.ranges[i + r];
      (e(l, l + c, a, a + u), (s += u - c));
    }
  }
  invert() {
    return new ge(this.ranges, !this.inverted);
  }
  toString() {
    return (this.inverted ? "-" : "") + JSON.stringify(this.ranges);
  }
  static offset(e) {
    return e == 0 ? ge.empty : new ge(e < 0 ? [0, -e, 0] : [0, 0, e]);
  }
}
ge.empty = new ge([]);
class Nn {
  constructor(e, t, r = 0, i = e ? e.length : 0) {
    ((this.mirror = t),
      (this.from = r),
      (this.to = i),
      (this._maps = e || []),
      (this.ownData = !(e || t)));
  }
  get maps() {
    return this._maps;
  }
  slice(e = 0, t = this.maps.length) {
    return new Nn(this._maps, this.mirror, e, t);
  }
  appendMap(e, t) {
    (this.ownData ||
      ((this._maps = this._maps.slice()),
      (this.mirror = this.mirror && this.mirror.slice()),
      (this.ownData = !0)),
      (this.to = this._maps.push(e)),
      t != null && this.setMirror(this._maps.length - 1, t));
  }
  appendMapping(e) {
    for (let t = 0, r = this._maps.length; t < e._maps.length; t++) {
      let i = e.getMirror(t);
      this.appendMap(e._maps[t], i != null && i < t ? r + i : void 0);
    }
  }
  getMirror(e) {
    if (this.mirror) {
      for (let t = 0; t < this.mirror.length; t++)
        if (this.mirror[t] == e) return this.mirror[t + (t % 2 ? -1 : 1)];
    }
  }
  setMirror(e, t) {
    (this.mirror || (this.mirror = []), this.mirror.push(e, t));
  }
  appendMappingInverted(e) {
    for (
      let t = e.maps.length - 1, r = this._maps.length + e._maps.length;
      t >= 0;
      t--
    ) {
      let i = e.getMirror(t);
      this.appendMap(
        e._maps[t].invert(),
        i != null && i > t ? r - i - 1 : void 0,
      );
    }
  }
  invert() {
    let e = new Nn();
    return (e.appendMappingInverted(this), e);
  }
  map(e, t = 1) {
    if (this.mirror) return this._map(e, t, !0);
    for (let r = this.from; r < this.to; r++) e = this._maps[r].map(e, t);
    return e;
  }
  mapResult(e, t = 1) {
    return this._map(e, t, !1);
  }
  _map(e, t, r) {
    let i = 0;
    for (let s = this.from; s < this.to; s++) {
      let o = this._maps[s],
        l = o.mapResult(e, t);
      if (l.recover != null) {
        let a = this.getMirror(s);
        if (a != null && a > s && a < this.to) {
          ((s = a), (e = this._maps[a].recover(l.recover)));
          continue;
        }
      }
      ((i |= l.delInfo), (e = l.pos));
    }
    return r ? e : new ts(e, i, null);
  }
}
const Mi = Object.create(null);
class G {
  getMap() {
    return ge.empty;
  }
  merge(e) {
    return null;
  }
  static fromJSON(e, t) {
    if (!t || !t.stepType)
      throw new RangeError("Invalid input for Step.fromJSON");
    let r = Mi[t.stepType];
    if (!r) throw new RangeError(`No step type ${t.stepType} defined`);
    return r.fromJSON(e, t);
  }
  static jsonID(e, t) {
    if (e in Mi) throw new RangeError("Duplicate use of step JSON ID " + e);
    return ((Mi[e] = t), (t.prototype.jsonID = e), t);
  }
}
class U {
  constructor(e, t) {
    ((this.doc = e), (this.failed = t));
  }
  static ok(e) {
    return new U(e, null);
  }
  static fail(e) {
    return new U(null, e);
  }
  static fromReplace(e, t, r, i) {
    try {
      return U.ok(e.replace(t, r, i));
    } catch (s) {
      if (s instanceof Tn) return U.fail(s.message);
      throw s;
    }
  }
}
function Ls(n, e, t) {
  let r = [];
  for (let i = 0; i < n.childCount; i++) {
    let s = n.child(i);
    (s.content.size && (s = s.copy(Ls(s.content, e, s))),
      s.isInline && (s = e(s, t, i)),
      r.push(s));
  }
  return b.fromArray(r);
}
class ze extends G {
  constructor(e, t, r) {
    (super(), (this.from = e), (this.to = t), (this.mark = r));
  }
  apply(e) {
    let t = e.slice(this.from, this.to),
      r = e.resolve(this.from),
      i = r.node(r.sharedDepth(this.to)),
      s = new C(
        Ls(
          t.content,
          (o, l) =>
            !o.isAtom || !l.type.allowsMarkType(this.mark.type)
              ? o
              : o.mark(this.mark.addToSet(o.marks)),
          i,
        ),
        t.openStart,
        t.openEnd,
      );
    return U.fromReplace(e, this.from, this.to, s);
  }
  invert(e) {
    let t = [];
    return (
      e.nodesBetween(this.from, this.to, (r, i) => {
        if (r.isInline && r.isAtom) {
          let s = this.mark.addToSet(r.marks);
          if (!z.sameSet(s, r.marks)) {
            let o = Math.max(this.from, i),
              l = Math.min(this.to, i + r.nodeSize);
            Sr(Ne, o, l, this.mark, t);
            for (let a of r.marks) a.isInSet(s) || Sr(ze, o, l, a, t);
          }
        }
      }),
      t.length == 1 ? t[0] : new Ct(t)
    );
  }
  map(e) {
    let t = e.map(this.from, 1),
      r = e.map(this.to, -1);
    return t >= r ? null : new ze(t, r, this.mark);
  }
  merge(e) {
    return e instanceof ze &&
      e.mark.eq(this.mark) &&
      this.from <= e.to &&
      this.to >= e.from
      ? new ze(Math.min(this.from, e.from), Math.max(this.to, e.to), this.mark)
      : null;
  }
  toJSON() {
    return {
      stepType: "addMark",
      mark: this.mark.toJSON(),
      from: this.from,
      to: this.to,
    };
  }
  static fromJSON(e, t) {
    if (typeof t.from != "number" || typeof t.to != "number")
      throw new RangeError("Invalid input for AddMarkStep.fromJSON");
    return new ze(t.from, t.to, e.markFromJSON(t.mark));
  }
}
G.jsonID("addMark", ze);
class Ne extends G {
  constructor(e, t, r) {
    (super(), (this.from = e), (this.to = t), (this.mark = r));
  }
  apply(e) {
    let t = e.slice(this.from, this.to),
      r = new C(
        Ls(t.content, (i) => i.mark(this.mark.removeFromSet(i.marks)), e),
        t.openStart,
        t.openEnd,
      );
    return U.fromReplace(e, this.from, this.to, r);
  }
  invert(e) {
    let t = [];
    return (
      e.nodesBetween(this.from, this.to, (r, i) => {
        r.isInline &&
          r.isAtom &&
          this.mark.isInSet(r.marks) &&
          Sr(
            ze,
            Math.max(this.from, i),
            Math.min(this.to, i + r.nodeSize),
            this.mark,
            t,
          );
      }),
      t.length == 1 ? t[0] : new Ct(t)
    );
  }
  map(e) {
    let t = e.map(this.from, 1),
      r = e.map(this.to, -1);
    return t >= r ? null : new Ne(t, r, this.mark);
  }
  merge(e) {
    return e instanceof Ne &&
      e.mark.eq(this.mark) &&
      this.from <= e.to &&
      this.to >= e.from
      ? new Ne(Math.min(this.from, e.from), Math.max(this.to, e.to), this.mark)
      : null;
  }
  toJSON() {
    return {
      stepType: "removeMark",
      mark: this.mark.toJSON(),
      from: this.from,
      to: this.to,
    };
  }
  static fromJSON(e, t) {
    if (typeof t.from != "number" || typeof t.to != "number")
      throw new RangeError("Invalid input for RemoveMarkStep.fromJSON");
    return new Ne(t.from, t.to, e.markFromJSON(t.mark));
  }
}
G.jsonID("removeMark", Ne);
function Sr(n, e, t, r, i) {
  let s = i.length ? i[i.length - 1] : null;
  s && s instanceof n && s.to == e && s.mark.eq(r)
    ? (i[i.length - 1] = new n(s.from, t, r))
    : i.push(new n(e, t, r));
}
class Ct extends G {
  constructor(e) {
    (super(), (this.steps = e));
  }
  apply(e) {
    for (let t of this.steps) {
      let r = t.apply(e);
      if (!r.doc) return r;
      e = r.doc;
    }
    return new U(e, null);
  }
  invert(e) {
    return new Ct(this.steps.map((t) => t.invert(e)));
  }
  map(e) {
    let t = [];
    for (let r of this.steps) {
      let i = r.map(e);
      i && t.push(i);
    }
    return t.length ? new Ct(t) : null;
  }
  toJSON() {
    return { stepType: "markSet", steps: this.steps.map((e) => e.toJSON()) };
  }
  static fromJSON(e, t) {
    if (
      !Array.isArray(t.steps) ||
      !t.steps.every(
        (r) => r.stepType == "addMark" || r.stepType == "removeMark",
      )
    )
      throw new RangeError("Invalid JSON for MarkSetStep");
    return new Ct(t.steps.map((r) => G.fromJSON(e, r)));
  }
}
G.jsonID("markSet", Ct);
class Ze extends G {
  constructor(e, t) {
    (super(), (this.pos = e), (this.mark = t));
  }
  apply(e) {
    let t = e.nodeAt(this.pos);
    if (!t) return U.fail("No node at mark step's position");
    let r = t.type.create(t.attrs, null, this.mark.addToSet(t.marks));
    return U.fromReplace(
      e,
      this.pos,
      this.pos + 1,
      new C(b.from(r), 0, t.isLeaf ? 0 : 1),
    );
  }
  invert(e) {
    let t = e.nodeAt(this.pos);
    if (t) {
      let r = this.mark.addToSet(t.marks);
      if (r.length == t.marks.length) {
        for (let i = 0; i < t.marks.length; i++)
          if (!t.marks[i].isInSet(r)) return new Ze(this.pos, t.marks[i]);
        return new Ze(this.pos, this.mark);
      }
    }
    return new At(this.pos, this.mark);
  }
  map(e) {
    let t = e.mapResult(this.pos, 1);
    return t.deletedAfter ? null : new Ze(t.pos, this.mark);
  }
  toJSON() {
    return { stepType: "addNodeMark", pos: this.pos, mark: this.mark.toJSON() };
  }
  static fromJSON(e, t) {
    if (typeof t.pos != "number")
      throw new RangeError("Invalid input for AddNodeMarkStep.fromJSON");
    return new Ze(t.pos, e.markFromJSON(t.mark));
  }
}
G.jsonID("addNodeMark", Ze);
class At extends G {
  constructor(e, t) {
    (super(), (this.pos = e), (this.mark = t));
  }
  apply(e) {
    let t = e.nodeAt(this.pos);
    if (!t) return U.fail("No node at mark step's position");
    let r = t.type.create(t.attrs, null, this.mark.removeFromSet(t.marks));
    return U.fromReplace(
      e,
      this.pos,
      this.pos + 1,
      new C(b.from(r), 0, t.isLeaf ? 0 : 1),
    );
  }
  invert(e) {
    let t = e.nodeAt(this.pos);
    return !t || !this.mark.isInSet(t.marks)
      ? this
      : new Ze(this.pos, this.mark);
  }
  map(e) {
    let t = e.mapResult(this.pos, 1);
    return t.deletedAfter ? null : new At(t.pos, this.mark);
  }
  toJSON() {
    return {
      stepType: "removeNodeMark",
      pos: this.pos,
      mark: this.mark.toJSON(),
    };
  }
  static fromJSON(e, t) {
    if (typeof t.pos != "number")
      throw new RangeError("Invalid input for RemoveNodeMarkStep.fromJSON");
    return new At(t.pos, e.markFromJSON(t.mark));
  }
}
G.jsonID("removeNodeMark", At);
class _ extends G {
  constructor(e, t, r, i = !1) {
    (super(),
      (this.from = e),
      (this.to = t),
      (this.slice = r),
      (this.structure = i));
  }
  apply(e) {
    return this.structure && ns(e, this.from, this.to)
      ? U.fail("Structure replace would overwrite content")
      : U.fromReplace(e, this.from, this.to, this.slice);
  }
  getMap() {
    return new ge([this.from, this.to - this.from, this.slice.size]);
  }
  invert(e) {
    return new _(
      this.from,
      this.from + this.slice.size,
      e.slice(this.from, this.to),
    );
  }
  map(e) {
    let t = e.mapResult(this.to, -1),
      r =
        this.from == this.to && _.MAP_BIAS < 0 ? t : e.mapResult(this.from, 1);
    return r.deletedAcross && t.deletedAcross
      ? null
      : new _(r.pos, Math.max(r.pos, t.pos), this.slice, this.structure);
  }
  merge(e) {
    if (!(e instanceof _) || e.structure || this.structure) return null;
    if (
      this.from + this.slice.size == e.from &&
      !this.slice.openEnd &&
      !e.slice.openStart
    ) {
      let t =
        this.slice.size + e.slice.size == 0
          ? C.empty
          : new C(
              this.slice.content.append(e.slice.content),
              this.slice.openStart,
              e.slice.openEnd,
            );
      return new _(this.from, this.to + (e.to - e.from), t, this.structure);
    } else if (e.to == this.from && !this.slice.openStart && !e.slice.openEnd) {
      let t =
        this.slice.size + e.slice.size == 0
          ? C.empty
          : new C(
              e.slice.content.append(this.slice.content),
              e.slice.openStart,
              this.slice.openEnd,
            );
      return new _(e.from, this.to, t, this.structure);
    } else return null;
  }
  toJSON() {
    let e = { stepType: "replace", from: this.from, to: this.to };
    return (
      this.slice.size && (e.slice = this.slice.toJSON()),
      this.structure && (e.structure = !0),
      e
    );
  }
  static fromJSON(e, t) {
    if (typeof t.from != "number" || typeof t.to != "number")
      throw new RangeError("Invalid input for ReplaceStep.fromJSON");
    return new _(t.from, t.to, C.fromJSON(e, t.slice), !!t.structure);
  }
}
_.MAP_BIAS = 1;
G.jsonID("replace", _);
class Q extends G {
  constructor(e, t, r, i, s, o, l = !1) {
    (super(),
      (this.from = e),
      (this.to = t),
      (this.gapFrom = r),
      (this.gapTo = i),
      (this.slice = s),
      (this.insert = o),
      (this.structure = l));
  }
  apply(e) {
    if (
      this.structure &&
      (ns(e, this.from, this.gapFrom) || ns(e, this.gapTo, this.to))
    )
      return U.fail("Structure gap-replace would overwrite content");
    let t = e.slice(this.gapFrom, this.gapTo);
    if (t.openStart || t.openEnd) return U.fail("Gap is not a flat range");
    let r = this.slice.insertAt(this.insert, t.content);
    return r
      ? U.fromReplace(e, this.from, this.to, r)
      : U.fail("Content does not fit in gap");
  }
  getMap() {
    return new ge([
      this.from,
      this.gapFrom - this.from,
      this.insert,
      this.gapTo,
      this.to - this.gapTo,
      this.slice.size - this.insert,
    ]);
  }
  invert(e) {
    let t = this.gapTo - this.gapFrom;
    return new Q(
      this.from,
      this.from + this.slice.size + t,
      this.from + this.insert,
      this.from + this.insert + t,
      e
        .slice(this.from, this.to)
        .removeBetween(this.gapFrom - this.from, this.gapTo - this.from),
      this.gapFrom - this.from,
      this.structure,
    );
  }
  map(e) {
    let t = e.mapResult(this.from, 1),
      r = e.mapResult(this.to, -1),
      i = this.from == this.gapFrom ? t.pos : e.map(this.gapFrom, -1),
      s = this.to == this.gapTo ? r.pos : e.map(this.gapTo, 1);
    return (t.deletedAcross && r.deletedAcross) ||
      i < t.pos ||
      s > r.pos ||
      i > s
      ? null
      : new Q(t.pos, r.pos, i, s, this.slice, this.insert, this.structure);
  }
  toJSON() {
    let e = {
      stepType: "replaceAround",
      from: this.from,
      to: this.to,
      gapFrom: this.gapFrom,
      gapTo: this.gapTo,
      insert: this.insert,
    };
    return (
      this.slice.size && (e.slice = this.slice.toJSON()),
      this.structure && (e.structure = !0),
      e
    );
  }
  static fromJSON(e, t) {
    if (
      typeof t.from != "number" ||
      typeof t.to != "number" ||
      typeof t.gapFrom != "number" ||
      typeof t.gapTo != "number" ||
      typeof t.insert != "number"
    )
      throw new RangeError("Invalid input for ReplaceAroundStep.fromJSON");
    return new Q(
      t.from,
      t.to,
      t.gapFrom,
      t.gapTo,
      C.fromJSON(e, t.slice),
      t.insert,
      !!t.structure,
    );
  }
}
G.jsonID("replaceAround", Q);
function ns(n, e, t) {
  let r = n.resolve(e),
    i = t - e,
    s = r.depth;
  for (; i > 0 && s > 0 && r.indexAfter(s) == r.node(s).childCount;) (s--, i--);
  if (i > 0) {
    let o = r.node(s).maybeChild(r.indexAfter(s));
    for (; i > 0;) {
      if (!o || o.isLeaf) return !0;
      ((o = o.firstChild), i--);
    }
  }
  return !1;
}
function af(n, e, t, r) {
  let i = [];
  (n.doc.nodesBetween(e, t, (s, o, l) => {
    if (!s.isInline) return;
    let a = s.marks;
    if (!r.isInSet(a) && l.type.allowsMarkType(r.type)) {
      let c = Math.max(o, e),
        u = Math.min(o + s.nodeSize, t);
      Sr(ze, c, u, r, i);
    }
  }),
    i.forEach((s) => n.step(s)));
}
function cf(n, e, t, r) {
  let i = [],
    s = 0;
  (n.doc.nodesBetween(e, t, (o, l) => {
    if (!o.isInline || !o.isAtom) return;
    s++;
    let a = null;
    if (r instanceof oi) {
      let c = o.marks,
        u;
      for (; (u = r.isInSet(c));)
        ((a || (a = [])).push(u), (c = u.removeFromSet(c)));
    } else r ? r.isInSet(o.marks) && (a = [r]) : (a = o.marks);
    if (a && a.length) {
      let c = Math.min(l + o.nodeSize, t);
      for (let u = 0; u < a.length; u++) {
        let d = a[u],
          f;
        for (let h = 0; h < i.length; h++) {
          let p = i[h];
          p.step == s - 1 && d.eq(i[h].style) && (f = p);
        }
        f
          ? ((f.to = c), (f.step = s))
          : i.push({ style: d, from: Math.max(l, e), to: c, step: s });
      }
    }
  }),
    i.forEach((o) => n.step(new Ne(o.from, o.to, o.style))));
}
function Ps(n, e, t, r = t.contentMatch, i = !0) {
  let s = n.doc.nodeAt(e),
    o = [],
    l = e + 1;
  for (let a = 0; a < s.childCount; a++) {
    let c = s.child(a),
      u = l + c.nodeSize,
      d = r.matchType(c.type);
    if (!d) o.push(new _(l, u, C.empty));
    else {
      r = d;
      for (let f = 0; f < c.marks.length; f++)
        t.allowsMarkType(c.marks[f].type) || n.step(new Ne(l, u, c.marks[f]));
      if (i && c.isText && t.whitespace != "pre") {
        let f,
          h = /\r?\n|\r/g,
          p;
        for (; (f = h.exec(c.text));)
          (p ||
            (p = new C(
              b.from(t.schema.text(" ", t.allowedMarks(c.marks))),
              0,
              0,
            )),
            o.push(new _(l + f.index, l + f.index + f[0].length, p)));
      }
    }
    l = u;
  }
  if (!r.validEnd) {
    let a = r.fillBefore(b.empty, !0);
    n.replace(l, l, new C(a, 0, 0));
  }
  for (let a = o.length - 1; a >= 0; a--) n.step(o[a]);
}
function uf(n, e, t) {
  return (
    (e == 0 || n.canReplace(e, n.childCount)) &&
    (t == n.childCount || n.canReplace(0, t))
  );
}
function nn(n) {
  let t = n.parent.content.cutByIndex(n.startIndex, n.endIndex);
  for (let r = n.depth, i = 0, s = 0; ; --r) {
    let o = n.$from.node(r),
      l = n.$from.index(r) + i,
      a = n.$to.indexAfter(r) - s;
    if (r < n.depth && o.canReplace(l, a, t)) return r;
    if (r == 0 || o.type.spec.isolating || !uf(o, l, a)) break;
    (l && (i = 1), a < o.childCount && (s = 1));
  }
  return null;
}
function df(n, e, t) {
  let { $from: r, $to: i, depth: s } = e,
    o = r.before(s + 1),
    l = i.after(s + 1),
    a = o,
    c = l,
    u = b.empty,
    d = 0;
  for (let p = s, g = !1; p > t; p--)
    g || r.index(p) > 0
      ? ((g = !0), (u = b.from(r.node(p).copy(u))), d++)
      : a--;
  let f = b.empty,
    h = 0;
  for (let p = s, g = !1; p > t; p--)
    g || i.after(p + 1) < i.end(p)
      ? ((g = !0), (f = b.from(i.node(p).copy(f))), h++)
      : c++;
  n.step(new Q(a, c, o, l, new C(u.append(f), d, h), u.size - d, !0));
}
function Bs(n, e, t = null, r = n) {
  let i = ff(n, e),
    s = i && hf(r, e);
  return s ? i.map(Bo).concat({ type: e, attrs: t }).concat(s.map(Bo)) : null;
}
function Bo(n) {
  return { type: n, attrs: null };
}
function ff(n, e) {
  let { parent: t, startIndex: r, endIndex: i } = n,
    s = t.contentMatchAt(r).findWrapping(e);
  if (!s) return null;
  let o = s.length ? s[0] : e;
  return t.canReplaceWith(r, i, o) ? s : null;
}
function hf(n, e) {
  let { parent: t, startIndex: r, endIndex: i } = n,
    s = t.child(r),
    o = e.contentMatch.findWrapping(s.type);
  if (!o) return null;
  let a = (o.length ? o[o.length - 1] : e).contentMatch;
  for (let c = r; a && c < i; c++) a = a.matchType(t.child(c).type);
  return !a || !a.validEnd ? null : o;
}
function pf(n, e, t) {
  let r = b.empty;
  for (let o = t.length - 1; o >= 0; o--) {
    if (r.size) {
      let l = t[o].type.contentMatch.matchFragment(r);
      if (!l || !l.validEnd)
        throw new RangeError(
          "Wrapper type given to Transform.wrap does not form valid content of its parent wrapper",
        );
    }
    r = b.from(t[o].type.create(t[o].attrs, r));
  }
  let i = e.start,
    s = e.end;
  n.step(new Q(i, s, i, s, new C(r, 0, 0), t.length, !0));
}
function mf(n, e, t, r, i) {
  if (!r.isTextblock)
    throw new RangeError("Type given to setBlockType should be a textblock");
  let s = n.steps.length;
  n.doc.nodesBetween(e, t, (o, l) => {
    let a = typeof i == "function" ? i(o) : i;
    if (
      o.isTextblock &&
      !o.hasMarkup(r, a) &&
      gf(n.doc, n.mapping.slice(s).map(l), r)
    ) {
      let c = null;
      if (r.schema.linebreakReplacement) {
        let h = r.whitespace == "pre",
          p = !!r.contentMatch.matchType(r.schema.linebreakReplacement);
        h && !p ? (c = !1) : !h && p && (c = !0);
      }
      (c === !1 && _a(n, o, l, s),
        Ps(n, n.mapping.slice(s).map(l, 1), r, void 0, c === null));
      let u = n.mapping.slice(s),
        d = u.map(l, 1),
        f = u.map(l + o.nodeSize, 1);
      return (
        n.step(
          new Q(
            d,
            f,
            d + 1,
            f - 1,
            new C(b.from(r.create(a, null, o.marks)), 0, 0),
            1,
            !0,
          ),
        ),
        c === !0 && Ha(n, o, l, s),
        !1
      );
    }
  });
}
function Ha(n, e, t, r) {
  e.forEach((i, s) => {
    if (i.isText) {
      let o,
        l = /\r?\n|\r/g;
      for (; (o = l.exec(i.text));) {
        let a = n.mapping.slice(r).map(t + 1 + s + o.index);
        n.replaceWith(a, a + 1, e.type.schema.linebreakReplacement.create());
      }
    }
  });
}
function _a(n, e, t, r) {
  e.forEach((i, s) => {
    if (i.type == i.type.schema.linebreakReplacement) {
      let o = n.mapping.slice(r).map(t + 1 + s);
      n.replaceWith(
        o,
        o + 1,
        e.type.schema.text(`
`),
      );
    }
  });
}
function gf(n, e, t) {
  let r = n.resolve(e),
    i = r.index();
  return r.parent.canReplaceWith(i, i + 1, t);
}
function yf(n, e, t, r, i) {
  let s = n.doc.nodeAt(e);
  if (!s) throw new RangeError("No node at given position");
  t || (t = s.type);
  let o = t.create(r, null, i || s.marks);
  if (s.isLeaf) return n.replaceWith(e, e + s.nodeSize, o);
  if (!t.validContent(s.content))
    throw new RangeError("Invalid content for node type " + t.name);
  n.step(
    new Q(
      e,
      e + s.nodeSize,
      e + 1,
      e + s.nodeSize - 1,
      new C(b.from(o), 0, 0),
      1,
      !0,
    ),
  );
}
function He(n, e, t = 1, r) {
  let i = n.resolve(e),
    s = i.depth - t,
    o = (r && r[r.length - 1]) || i.parent;
  if (
    s < 0 ||
    i.parent.type.spec.isolating ||
    !i.parent.canReplace(i.index(), i.parent.childCount) ||
    !o.type.validContent(
      i.parent.content.cutByIndex(i.index(), i.parent.childCount),
    )
  )
    return !1;
  for (let c = i.depth - 1, u = t - 2; c > s; c--, u--) {
    let d = i.node(c),
      f = i.index(c);
    if (d.type.spec.isolating) return !1;
    let h = d.content.cutByIndex(f, d.childCount),
      p = r && r[u + 1];
    p && (h = h.replaceChild(0, p.type.create(p.attrs)));
    let g = (r && r[u]) || d;
    if (!d.canReplace(f + 1, d.childCount) || !g.type.validContent(h))
      return !1;
  }
  let l = i.indexAfter(s),
    a = r && r[0];
  return i.node(s).canReplaceWith(l, l, a ? a.type : i.node(s + 1).type);
}
function bf(n, e, t = 1, r) {
  let i = n.doc.resolve(e),
    s = b.empty,
    o = b.empty;
  for (let l = i.depth, a = i.depth - t, c = t - 1; l > a; l--, c--) {
    s = b.from(i.node(l).copy(s));
    let u = r && r[c];
    o = b.from(u ? u.type.create(u.attrs, o) : i.node(l).copy(o));
  }
  n.step(new _(e, e, new C(s.append(o), t, t), !0));
}
function at(n, e) {
  let t = n.resolve(e),
    r = t.index();
  return Wa(t.nodeBefore, t.nodeAfter) && t.parent.canReplace(r, r + 1);
}
function kf(n, e) {
  e.content.size || n.type.compatibleContent(e.type);
  let t = n.contentMatchAt(n.childCount),
    { linebreakReplacement: r } = n.type.schema;
  for (let i = 0; i < e.childCount; i++) {
    let s = e.child(i),
      o = s.type == r ? n.type.schema.nodes.text : s.type;
    if (((t = t.matchType(o)), !t || !n.type.allowsMarks(s.marks))) return !1;
  }
  return t.validEnd;
}
function Wa(n, e) {
  return !!(n && e && !n.isLeaf && kf(n, e));
}
function li(n, e, t = -1) {
  let r = n.resolve(e);
  for (let i = r.depth; ; i--) {
    let s,
      o,
      l = r.index(i);
    if (
      (i == r.depth
        ? ((s = r.nodeBefore), (o = r.nodeAfter))
        : t > 0
          ? ((s = r.node(i + 1)), l++, (o = r.node(i).maybeChild(l)))
          : ((s = r.node(i).maybeChild(l - 1)), (o = r.node(i + 1))),
      s && !s.isTextblock && Wa(s, o) && r.node(i).canReplace(l, l + 1))
    )
      return e;
    if (i == 0) break;
    e = t < 0 ? r.before(i) : r.after(i);
  }
}
function Sf(n, e, t) {
  let r = null,
    { linebreakReplacement: i } = n.doc.type.schema,
    s = n.doc.resolve(e - t),
    o = s.node().type;
  if (i && o.inlineContent) {
    let u = o.whitespace == "pre",
      d = !!o.contentMatch.matchType(i);
    u && !d ? (r = !1) : !u && d && (r = !0);
  }
  let l = n.steps.length;
  if (r === !1) {
    let u = n.doc.resolve(e + t);
    _a(n, u.node(), u.before(), l);
  }
  o.inlineContent &&
    Ps(n, e + t - 1, o, s.node().contentMatchAt(s.index()), r == null);
  let a = n.mapping.slice(l),
    c = a.map(e - t);
  if ((n.step(new _(c, a.map(e + t, -1), C.empty, !0)), r === !0)) {
    let u = n.doc.resolve(c);
    Ha(n, u.node(), u.before(), n.steps.length);
  }
  return n;
}
function xf(n, e, t) {
  let r = n.resolve(e);
  if (r.parent.canReplaceWith(r.index(), r.index(), t)) return e;
  if (r.parentOffset == 0)
    for (let i = r.depth - 1; i >= 0; i--) {
      let s = r.index(i);
      if (r.node(i).canReplaceWith(s, s, t)) return r.before(i + 1);
      if (s > 0) return null;
    }
  if (r.parentOffset == r.parent.content.size)
    for (let i = r.depth - 1; i >= 0; i--) {
      let s = r.indexAfter(i);
      if (r.node(i).canReplaceWith(s, s, t)) return r.after(i + 1);
      if (s < r.node(i).childCount) return null;
    }
  return null;
}
function qa(n, e, t) {
  let r = n.resolve(e);
  if (!t.content.size) return e;
  let i = t.content;
  for (let s = 0; s < t.openStart; s++) i = i.firstChild.content;
  for (let s = 1; s <= (t.openStart == 0 && t.size ? 2 : 1); s++)
    for (let o = r.depth; o >= 0; o--) {
      let l =
          o == r.depth
            ? 0
            : r.pos <= (r.start(o + 1) + r.end(o + 1)) / 2
              ? -1
              : 1,
        a = r.index(o) + (l > 0 ? 1 : 0),
        c = r.node(o),
        u = !1;
      if (s == 1) u = c.canReplace(a, a, i);
      else {
        let d = c.contentMatchAt(a).findWrapping(i.firstChild.type);
        u = d && c.canReplaceWith(a, a, d[0]);
      }
      if (u) return l == 0 ? r.pos : l < 0 ? r.before(o + 1) : r.after(o + 1);
    }
  return null;
}
function ai(n, e, t = e, r = C.empty) {
  if (e == t && !r.size) return null;
  let i = n.resolve(e),
    s = n.resolve(t);
  return Ua(i, s, r) ? new _(e, t, r) : new wf(i, s, r).fit();
}
function Ua(n, e, t) {
  return (
    !t.openStart &&
    !t.openEnd &&
    n.start() == e.start() &&
    n.parent.canReplace(n.index(), e.index(), t.content)
  );
}
class wf {
  constructor(e, t, r) {
    ((this.$from = e),
      (this.$to = t),
      (this.unplaced = r),
      (this.frontier = []),
      (this.placed = b.empty));
    for (let i = 0; i <= e.depth; i++) {
      let s = e.node(i);
      this.frontier.push({
        type: s.type,
        match: s.contentMatchAt(e.indexAfter(i)),
      });
    }
    for (let i = e.depth; i > 0; i--)
      this.placed = b.from(e.node(i).copy(this.placed));
  }
  get depth() {
    return this.frontier.length - 1;
  }
  fit() {
    for (; this.unplaced.size;) {
      let c = this.findFittable();
      c ? this.placeNodes(c) : this.openMore() || this.dropNode();
    }
    let e = this.mustMoveInline(),
      t = this.placed.size - this.depth - this.$from.depth,
      r = this.$from,
      i = this.close(e < 0 ? this.$to : r.doc.resolve(e));
    if (!i) return null;
    let s = this.placed,
      o = r.depth,
      l = i.depth;
    for (; o && l && s.childCount == 1;) ((s = s.firstChild.content), o--, l--);
    let a = new C(s, o, l);
    return e > -1
      ? new Q(r.pos, e, this.$to.pos, this.$to.end(), a, t)
      : a.size || r.pos != this.$to.pos
        ? new _(r.pos, i.pos, a)
        : null;
  }
  findFittable() {
    let e = this.unplaced.openStart;
    for (
      let t = this.unplaced.content, r = 0, i = this.unplaced.openEnd;
      r < e;
      r++
    ) {
      let s = t.firstChild;
      if ((t.childCount > 1 && (i = 0), s.type.spec.isolating && i <= r)) {
        e = r;
        break;
      }
      t = s.content;
    }
    for (let t = 1; t <= 2; t++)
      for (let r = t == 1 ? e : this.unplaced.openStart; r >= 0; r--) {
        let i,
          s = null;
        r
          ? ((s = $o(this.unplaced.content, r - 1).firstChild), (i = s.content))
          : (i = this.unplaced.content);
        let o = i.firstChild;
        for (let l = this.depth; l >= 0; l--) {
          let { type: a, match: c } = this.frontier[l],
            u,
            d = null;
          if (
            t == 1 &&
            (o
              ? c.matchType(o.type) || (d = c.fillBefore(b.from(o), !1))
              : s && a.compatibleContent(s.type))
          )
            return { sliceDepth: r, frontierDepth: l, parent: s, inject: d };
          if (t == 2 && o && (u = c.findWrapping(o.type)))
            return { sliceDepth: r, frontierDepth: l, parent: s, wrap: u };
          if (s && c.matchType(s.type)) break;
        }
      }
  }
  openMore() {
    let { content: e, openStart: t, openEnd: r } = this.unplaced;
    return zo(e, -1) <= t
      ? !1
      : (this.unplaced.size > 1 && zo(e, 1) > r && r++,
        (this.unplaced = new C(e, t + 1, r)),
        !0);
  }
  dropNode() {
    let { content: e, openStart: t, openEnd: r } = this.unplaced,
      i = $o(e, t);
    if (i.childCount <= 1 && t > 0) {
      let s = e.size - t <= t + i.size;
      this.unplaced = new C(un(e, t - 1, 1), t - 1, s ? t - 1 : r);
    } else this.unplaced = new C(un(e, t, 1), t, r);
  }
  placeNodes({
    sliceDepth: e,
    frontierDepth: t,
    parent: r,
    inject: i,
    wrap: s,
  }) {
    for (; this.depth > t;) this.closeFrontierNode();
    if (s) for (let g = 0; g < s.length; g++) this.openFrontierNode(s[g]);
    let o = this.unplaced,
      l = r ? r.content : o.content,
      a = o.openStart - e,
      c = 0,
      u = [],
      { match: d, type: f } = this.frontier[t];
    if (i) {
      for (let g = 0; g < i.childCount; g++) u.push(i.child(g));
      d = d.matchFragment(i);
    }
    let h = l.size + e - (o.content.size - o.openEnd);
    for (; c < l.childCount;) {
      let g = l.child(c),
        m = d.matchType(g.type);
      if (!m) break;
      (c++,
        (c > 1 || a == 0 || g.content.size) &&
          ((d = m),
          u.push(
            Ka(
              g.mark(f.allowedMarks(g.marks)),
              c == 1 ? a : 0,
              c == l.childCount ? h : -1,
            ),
          )));
    }
    let p = c == l.childCount;
    (p || (h = -1),
      (this.placed = dn(this.placed, t, b.from(u))),
      (this.frontier[t].match = d),
      p &&
        h < 0 &&
        r &&
        r.type == this.frontier[this.depth].type &&
        this.frontier.length > 1 &&
        this.closeFrontierNode());
    for (let g = 0, m = u[u.length - 1]; m && g < h; g++)
      (this.frontier.push({
        type: m.type,
        match: m.contentMatchAt(m.childCount),
      }),
        (m = m.lastChild));
    this.unplaced = p
      ? e == 0
        ? C.empty
        : new C(un(o.content, e - 1, 1), e - 1, h < 0 ? o.openEnd : e - 1)
      : new C(un(o.content, e, c), e, o.openEnd);
  }
  mustMoveInline() {
    if (!this.$to.parent.isTextblock) return -1;
    let e = this.frontier[this.depth],
      t;
    if (
      !e.type.isTextblock ||
      !Ei(this.$to, this.$to.depth, e.type, e.match, !1) ||
      (this.$to.depth == this.depth &&
        (t = this.findCloseLevel(this.$to)) &&
        t.depth == this.depth)
    )
      return -1;
    let { depth: r } = this.$to,
      i = this.$to.after(r);
    for (; r > 1 && i == this.$to.end(--r);) ++i;
    return i;
  }
  findCloseLevel(e) {
    e: for (let t = Math.min(this.depth, e.depth); t >= 0; t--) {
      let { match: r, type: i } = this.frontier[t],
        s = t < e.depth && e.end(t + 1) == e.pos + (e.depth - (t + 1)),
        o = Ei(e, t, i, r, s);
      if (o) {
        for (let l = t - 1; l >= 0; l--) {
          let { match: a, type: c } = this.frontier[l],
            u = Ei(e, l, c, a, !0);
          if (!u || u.childCount) continue e;
        }
        return {
          depth: t,
          fit: o,
          move: s ? e.doc.resolve(e.after(t + 1)) : e,
        };
      }
    }
  }
  close(e) {
    let t = this.findCloseLevel(e);
    if (!t) return null;
    for (; this.depth > t.depth;) this.closeFrontierNode();
    (t.fit.childCount && (this.placed = dn(this.placed, t.depth, t.fit)),
      (e = t.move));
    for (let r = t.depth + 1; r <= e.depth; r++) {
      let i = e.node(r),
        s = i.type.contentMatch.fillBefore(i.content, !0, e.index(r));
      this.openFrontierNode(i.type, i.attrs, s);
    }
    return e;
  }
  openFrontierNode(e, t = null, r) {
    let i = this.frontier[this.depth];
    ((i.match = i.match.matchType(e)),
      (this.placed = dn(this.placed, this.depth, b.from(e.create(t, r)))),
      this.frontier.push({ type: e, match: e.contentMatch }));
  }
  closeFrontierNode() {
    let t = this.frontier.pop().match.fillBefore(b.empty, !0);
    t.childCount && (this.placed = dn(this.placed, this.frontier.length, t));
  }
}
function un(n, e, t) {
  return e == 0
    ? n.cutByIndex(t, n.childCount)
    : n.replaceChild(0, n.firstChild.copy(un(n.firstChild.content, e - 1, t)));
}
function dn(n, e, t) {
  return e == 0
    ? n.append(t)
    : n.replaceChild(
        n.childCount - 1,
        n.lastChild.copy(dn(n.lastChild.content, e - 1, t)),
      );
}
function $o(n, e) {
  for (let t = 0; t < e; t++) n = n.firstChild.content;
  return n;
}
function Ka(n, e, t) {
  if (e <= 0) return n;
  let r = n.content;
  return (
    e > 1 &&
      (r = r.replaceChild(
        0,
        Ka(r.firstChild, e - 1, r.childCount == 1 ? t - 1 : 0),
      )),
    e > 0 &&
      ((r = n.type.contentMatch.fillBefore(r).append(r)),
      t <= 0 &&
        (r = r.append(
          n.type.contentMatch.matchFragment(r).fillBefore(b.empty, !0),
        ))),
    n.copy(r)
  );
}
function Ei(n, e, t, r, i) {
  let s = n.node(e),
    o = i ? n.indexAfter(e) : n.index(e);
  if (o == s.childCount && !t.compatibleContent(s.type)) return null;
  let l = r.fillBefore(s.content, !0, o);
  return l && !Cf(t, s.content, o) ? l : null;
}
function Cf(n, e, t) {
  for (let r = t; r < e.childCount; r++)
    if (!n.allowsMarks(e.child(r).marks)) return !0;
  return !1;
}
function vf(n) {
  return n.spec.defining || n.spec.definingForContent;
}
function zo(n, e) {
  for (let t = 0; ; t++) {
    let r = e < 0 ? n.firstChild : n.lastChild;
    if (!r || r.isAtom) return t;
    n = r.content;
  }
}
function Mf(n, e, t, r) {
  if (!r.size) return n.deleteRange(e, t);
  let i = n.doc.resolve(e),
    s = n.doc.resolve(t);
  if (Ua(i, s, r)) return n.step(new _(e, t, r));
  let o = Ga(i, s);
  o[o.length - 1] == 0 && o.pop();
  let l = -(i.depth + 1);
  o.unshift(l);
  for (let f = i.depth, h = i.pos - 1; f > 0; f--, h--) {
    let p = i.node(f).type.spec;
    if (p.defining || p.definingAsContext || p.isolating) break;
    o.indexOf(f) > -1 ? (l = f) : i.before(f) == h && o.splice(1, 0, -f);
  }
  let a = o.indexOf(l),
    c = [],
    u = r.openStart;
  for (let f = r.content, h = 0; ; h++) {
    let p = f.firstChild;
    if ((c.push(p), h == r.openStart)) break;
    f = p.content;
  }
  for (let f = u - 1; f >= 0; f--) {
    let h = c[f],
      p = vf(h.type);
    if (p && !h.sameMarkup(i.node(Math.abs(l) - 1))) u = f;
    else if (p || !h.type.isTextblock) break;
  }
  for (let f = r.openStart; f >= 0; f--) {
    let h = (f + u + 1) % (r.openStart + 1),
      p = c[h];
    if (p)
      for (let g = 0; g < o.length; g++) {
        let m = o[(g + a) % o.length],
          y = !0;
        m < 0 && ((y = !1), (m = -m));
        let k = i.node(m - 1),
          x = i.index(m - 1);
        if (k.canReplaceWith(x, x, p.type, p.marks))
          return n.replace(
            i.before(m),
            y ? s.after(m) : t,
            new C(Ja(r.content, 0, r.openStart, h), h, r.openEnd),
          );
      }
  }
  let d = n.steps.length;
  for (
    let f = o.length - 1;
    f >= 0 && (n.replace(e, t, r), !(n.steps.length > d));
    f--
  ) {
    let h = o[f];
    h < 0 || ((e = i.before(h)), (t = s.after(h)));
  }
}
function Ja(n, e, t, r, i) {
  if (e < t) {
    let s = n.firstChild;
    n = n.replaceChild(0, s.copy(Ja(s.content, e + 1, t, r, s)));
  }
  if (e > r) {
    let s = i.contentMatchAt(0),
      o = s.fillBefore(n).append(n);
    n = o.append(s.matchFragment(o).fillBefore(b.empty, !0));
  }
  return n;
}
function Ef(n, e, t, r) {
  if (!r.isInline && e == t && n.doc.resolve(e).parent.content.size) {
    let i = xf(n.doc, e, r.type);
    i != null && (e = t = i);
  }
  n.replaceRange(e, t, new C(b.from(r), 0, 0));
}
function Tf(n, e, t) {
  let r = n.doc.resolve(e),
    i = n.doc.resolve(t);
  if (
    r.parent.isTextblock &&
    i.parent.isTextblock &&
    r.start() != i.start() &&
    r.parentOffset == 0 &&
    i.parentOffset == 0
  ) {
    let o = r.sharedDepth(t),
      l = !1;
    for (let a = r.depth; a > o; a--) r.node(a).type.spec.isolating && (l = !0);
    for (let a = i.depth; a > o; a--) i.node(a).type.spec.isolating && (l = !0);
    if (!l) {
      for (let a = r.depth; a > 0 && e == r.start(a); a--) e = r.before(a);
      for (let a = i.depth; a > 0 && t == i.start(a); a--) t = i.before(a);
      ((r = n.doc.resolve(e)), (i = n.doc.resolve(t)));
    }
  }
  let s = Ga(r, i);
  for (let o = 0; o < s.length; o++) {
    let l = s[o],
      a = o == s.length - 1;
    if ((a && l == 0) || r.node(l).type.contentMatch.validEnd)
      return n.delete(r.start(l), i.end(l));
    if (
      l > 0 &&
      (a || r.node(l - 1).canReplace(r.index(l - 1), i.indexAfter(l - 1)))
    )
      return n.delete(r.before(l), i.after(l));
  }
  for (let o = 1; o <= r.depth && o <= i.depth; o++)
    if (
      e - r.start(o) == r.depth - o &&
      t > r.end(o) &&
      i.end(o) - t != i.depth - o &&
      r.start(o - 1) == i.start(o - 1) &&
      r.node(o - 1).canReplace(r.index(o - 1), i.index(o - 1))
    )
      return n.delete(r.before(o), t);
  n.delete(e, t);
}
function Ga(n, e) {
  let t = [],
    r = Math.min(n.depth, e.depth);
  for (let i = r; i >= 0; i--) {
    let s = n.start(i);
    if (
      s < n.pos - (n.depth - i) ||
      e.end(i) > e.pos + (e.depth - i) ||
      n.node(i).type.spec.isolating ||
      e.node(i).type.spec.isolating
    )
      break;
    (s == e.start(i) ||
      (i == n.depth &&
        i == e.depth &&
        n.parent.inlineContent &&
        e.parent.inlineContent &&
        i &&
        e.start(i - 1) == s - 1)) &&
      t.push(i);
  }
  return t;
}
class Kt extends G {
  constructor(e, t, r) {
    (super(), (this.pos = e), (this.attr = t), (this.value = r));
  }
  apply(e) {
    let t = e.nodeAt(this.pos);
    if (!t) return U.fail("No node at attribute step's position");
    let r = Object.create(null);
    for (let s in t.attrs) r[s] = t.attrs[s];
    r[this.attr] = this.value;
    let i = t.type.create(r, null, t.marks);
    return U.fromReplace(
      e,
      this.pos,
      this.pos + 1,
      new C(b.from(i), 0, t.isLeaf ? 0 : 1),
    );
  }
  getMap() {
    return ge.empty;
  }
  invert(e) {
    return new Kt(this.pos, this.attr, e.nodeAt(this.pos).attrs[this.attr]);
  }
  map(e) {
    let t = e.mapResult(this.pos, 1);
    return t.deletedAfter ? null : new Kt(t.pos, this.attr, this.value);
  }
  toJSON() {
    return {
      stepType: "attr",
      pos: this.pos,
      attr: this.attr,
      value: this.value,
    };
  }
  static fromJSON(e, t) {
    if (typeof t.pos != "number" || typeof t.attr != "string")
      throw new RangeError("Invalid input for AttrStep.fromJSON");
    return new Kt(t.pos, t.attr, t.value);
  }
}
G.jsonID("attr", Kt);
class Dn extends G {
  constructor(e, t) {
    (super(), (this.attr = e), (this.value = t));
  }
  apply(e) {
    let t = Object.create(null);
    for (let i in e.attrs) t[i] = e.attrs[i];
    t[this.attr] = this.value;
    let r = e.type.create(t, e.content, e.marks);
    return U.ok(r);
  }
  getMap() {
    return ge.empty;
  }
  invert(e) {
    return new Dn(this.attr, e.attrs[this.attr]);
  }
  map(e) {
    return this;
  }
  toJSON() {
    return { stepType: "docAttr", attr: this.attr, value: this.value };
  }
  static fromJSON(e, t) {
    if (typeof t.attr != "string")
      throw new RangeError("Invalid input for DocAttrStep.fromJSON");
    return new Dn(t.attr, t.value);
  }
}
G.jsonID("docAttr", Dn);
let Gt = class extends Error {};
Gt = function n(e) {
  let t = Error.call(this, e);
  return ((t.__proto__ = n.prototype), t);
};
Gt.prototype = Object.create(Error.prototype);
Gt.prototype.constructor = Gt;
Gt.prototype.name = "TransformError";
class Ya {
  constructor(e) {
    ((this.doc = e),
      (this.steps = []),
      (this.docs = []),
      (this.mapping = new Nn()));
  }
  get before() {
    return this.docs.length ? this.docs[0] : this.doc;
  }
  step(e) {
    let t = this.maybeStep(e);
    if (t.failed) throw new Gt(t.failed);
    return this;
  }
  maybeStep(e) {
    let t = e.apply(this.doc);
    return (t.failed || this.addStep(e, t.doc), t);
  }
  get docChanged() {
    return this.steps.length > 0;
  }
  changedRange() {
    let e = 1e9,
      t = -1e9;
    for (let r = 0; r < this.mapping.maps.length; r++) {
      let i = this.mapping.maps[r];
      (r && ((e = i.map(e, 1)), (t = i.map(t, -1))),
        i.forEach((s, o, l, a) => {
          ((e = Math.min(e, l)), (t = Math.max(t, a)));
        }));
    }
    return e == 1e9 ? null : { from: e, to: t };
  }
  addStep(e, t) {
    (this.docs.push(this.doc),
      this.steps.push(e),
      this.mapping.appendMap(e.getMap()),
      (this.doc = t));
  }
  replace(e, t = e, r = C.empty) {
    let i = ai(this.doc, e, t, r);
    return (i && this.step(i), this);
  }
  replaceWith(e, t, r) {
    return this.replace(e, t, new C(b.from(r), 0, 0));
  }
  delete(e, t) {
    return this.replace(e, t, C.empty);
  }
  insert(e, t) {
    return this.replaceWith(e, e, t);
  }
  replaceRange(e, t, r) {
    return (Mf(this, e, t, r), this);
  }
  replaceRangeWith(e, t, r) {
    return (Ef(this, e, t, r), this);
  }
  deleteRange(e, t) {
    return (Tf(this, e, t), this);
  }
  lift(e, t) {
    return (df(this, e, t), this);
  }
  join(e, t = 1) {
    return (Sf(this, e, t), this);
  }
  wrap(e, t) {
    return (pf(this, e, t), this);
  }
  setBlockType(e, t = e, r, i = null) {
    return (mf(this, e, t, r, i), this);
  }
  setNodeMarkup(e, t, r = null, i) {
    return (yf(this, e, t, r, i), this);
  }
  setNodeAttribute(e, t, r) {
    return (this.step(new Kt(e, t, r)), this);
  }
  setDocAttribute(e, t) {
    return (this.step(new Dn(e, t)), this);
  }
  addNodeMark(e, t) {
    return (this.step(new Ze(e, t)), this);
  }
  removeNodeMark(e, t) {
    let r = this.doc.nodeAt(e);
    if (!r) throw new RangeError("No node at position " + e);
    if (t instanceof z) t.isInSet(r.marks) && this.step(new At(e, t));
    else {
      let i = r.marks,
        s,
        o = [];
      for (; (s = t.isInSet(i));)
        (o.push(new At(e, s)), (i = s.removeFromSet(i)));
      for (let l = o.length - 1; l >= 0; l--) this.step(o[l]);
    }
    return this;
  }
  split(e, t = 1, r) {
    return (bf(this, e, t, r), this);
  }
  addMark(e, t, r) {
    return (af(this, e, t, r), this);
  }
  removeMark(e, t, r) {
    return (cf(this, e, t, r), this);
  }
  clearIncompatible(e, t, r) {
    return (Ps(this, e, t, r), this);
  }
}
const Ti = Object.create(null);
class N {
  constructor(e, t, r) {
    ((this.$anchor = e),
      (this.$head = t),
      (this.ranges = r || [new Af(e.min(t), e.max(t))]));
  }
  get anchor() {
    return this.$anchor.pos;
  }
  get head() {
    return this.$head.pos;
  }
  get from() {
    return this.$from.pos;
  }
  get to() {
    return this.$to.pos;
  }
  get $from() {
    return this.ranges[0].$from;
  }
  get $to() {
    return this.ranges[0].$to;
  }
  get empty() {
    let e = this.ranges;
    for (let t = 0; t < e.length; t++)
      if (e[t].$from.pos != e[t].$to.pos) return !1;
    return !0;
  }
  content() {
    return this.$from.doc.slice(this.from, this.to, !0);
  }
  replace(e, t = C.empty) {
    let r = t.content.lastChild,
      i = null;
    for (let l = 0; l < t.openEnd; l++) ((i = r), (r = r.lastChild));
    let s = e.steps.length,
      o = this.ranges;
    for (let l = 0; l < o.length; l++) {
      let { $from: a, $to: c } = o[l],
        u = e.mapping.slice(s);
      (e.replaceRange(u.map(a.pos), u.map(c.pos), l ? C.empty : t),
        l == 0 && jo(e, s, (r ? r.isInline : i && i.isTextblock) ? -1 : 1));
    }
  }
  replaceWith(e, t) {
    let r = e.steps.length,
      i = this.ranges;
    for (let s = 0; s < i.length; s++) {
      let { $from: o, $to: l } = i[s],
        a = e.mapping.slice(r),
        c = a.map(o.pos),
        u = a.map(l.pos);
      s
        ? e.deleteRange(c, u)
        : (e.replaceRangeWith(c, u, t), jo(e, r, t.isInline ? -1 : 1));
    }
  }
  static findFrom(e, t, r = !1) {
    let i = e.parent.inlineContent
      ? new T(e)
      : Ft(e.node(0), e.parent, e.pos, e.index(), t, r);
    if (i) return i;
    for (let s = e.depth - 1; s >= 0; s--) {
      let o =
        t < 0
          ? Ft(e.node(0), e.node(s), e.before(s + 1), e.index(s), t, r)
          : Ft(e.node(0), e.node(s), e.after(s + 1), e.index(s) + 1, t, r);
      if (o) return o;
    }
    return null;
  }
  static near(e, t = 1) {
    return this.findFrom(e, t) || this.findFrom(e, -t) || new ye(e.node(0));
  }
  static atStart(e) {
    return Ft(e, e, 0, 0, 1) || new ye(e);
  }
  static atEnd(e) {
    return Ft(e, e, e.content.size, e.childCount, -1) || new ye(e);
  }
  static fromJSON(e, t) {
    if (!t || !t.type)
      throw new RangeError("Invalid input for Selection.fromJSON");
    let r = Ti[t.type];
    if (!r) throw new RangeError(`No selection type ${t.type} defined`);
    return r.fromJSON(e, t);
  }
  static jsonID(e, t) {
    if (e in Ti)
      throw new RangeError("Duplicate use of selection JSON ID " + e);
    return ((Ti[e] = t), (t.prototype.jsonID = e), t);
  }
  getBookmark() {
    return T.between(this.$anchor, this.$head).getBookmark();
  }
}
N.prototype.visible = !0;
class Af {
  constructor(e, t) {
    ((this.$from = e), (this.$to = t));
  }
}
let Fo = !1;
function Vo(n) {
  !Fo &&
    !n.parent.inlineContent &&
    ((Fo = !0),
    console.warn(
      "TextSelection endpoint not pointing into a node with inline content (" +
        n.parent.type.name +
        ")",
    ));
}
class T extends N {
  constructor(e, t = e) {
    (Vo(e), Vo(t), super(e, t));
  }
  get $cursor() {
    return this.$anchor.pos == this.$head.pos ? this.$head : null;
  }
  map(e, t) {
    let r = e.resolve(t.map(this.head));
    if (!r.parent.inlineContent) return N.near(r);
    let i = e.resolve(t.map(this.anchor));
    return new T(i.parent.inlineContent ? i : r, r);
  }
  replace(e, t = C.empty) {
    if ((super.replace(e, t), t == C.empty)) {
      let r = this.$from.marksAcross(this.$to);
      r && e.ensureMarks(r);
    }
  }
  eq(e) {
    return e instanceof T && e.anchor == this.anchor && e.head == this.head;
  }
  getBookmark() {
    return new ci(this.anchor, this.head);
  }
  toJSON() {
    return { type: "text", anchor: this.anchor, head: this.head };
  }
  static fromJSON(e, t) {
    if (typeof t.anchor != "number" || typeof t.head != "number")
      throw new RangeError("Invalid input for TextSelection.fromJSON");
    return new T(e.resolve(t.anchor), e.resolve(t.head));
  }
  static create(e, t, r = t) {
    let i = e.resolve(t);
    return new this(i, r == t ? i : e.resolve(r));
  }
  static between(e, t, r) {
    let i = e.pos - t.pos;
    if (((!r || i) && (r = i >= 0 ? 1 : -1), !t.parent.inlineContent)) {
      let s = N.findFrom(t, r, !0) || N.findFrom(t, -r, !0);
      if (s) t = s.$head;
      else return N.near(t, r);
    }
    return (
      e.parent.inlineContent ||
        (i == 0
          ? (e = t)
          : ((e = (N.findFrom(e, -r, !0) || N.findFrom(e, r, !0)).$anchor),
            e.pos < t.pos != i < 0 && (e = t))),
      new T(e, t)
    );
  }
}
N.jsonID("text", T);
class ci {
  constructor(e, t) {
    ((this.anchor = e), (this.head = t));
  }
  map(e) {
    return new ci(e.map(this.anchor), e.map(this.head));
  }
  resolve(e) {
    return T.between(e.resolve(this.anchor), e.resolve(this.head));
  }
}
class O extends N {
  constructor(e) {
    let t = e.nodeAfter,
      r = e.node(0).resolve(e.pos + t.nodeSize);
    (super(e, r), (this.node = t));
  }
  map(e, t) {
    let { deleted: r, pos: i } = t.mapResult(this.anchor),
      s = e.resolve(i);
    return r ? N.near(s) : new O(s);
  }
  content() {
    return new C(b.from(this.node), 0, 0);
  }
  eq(e) {
    return e instanceof O && e.anchor == this.anchor;
  }
  toJSON() {
    return { type: "node", anchor: this.anchor };
  }
  getBookmark() {
    return new $s(this.anchor);
  }
  static fromJSON(e, t) {
    if (typeof t.anchor != "number")
      throw new RangeError("Invalid input for NodeSelection.fromJSON");
    return new O(e.resolve(t.anchor));
  }
  static create(e, t) {
    return new O(e.resolve(t));
  }
  static isSelectable(e) {
    return !e.isText && e.type.spec.selectable !== !1;
  }
}
O.prototype.visible = !1;
N.jsonID("node", O);
class $s {
  constructor(e) {
    this.anchor = e;
  }
  map(e) {
    let { deleted: t, pos: r } = e.mapResult(this.anchor);
    return t ? new ci(r, r) : new $s(r);
  }
  resolve(e) {
    let t = e.resolve(this.anchor),
      r = t.nodeAfter;
    return r && O.isSelectable(r) ? new O(t) : N.near(t);
  }
}
class ye extends N {
  constructor(e) {
    super(e.resolve(0), e.resolve(e.content.size));
  }
  replace(e, t = C.empty) {
    if (t == C.empty) {
      e.delete(0, e.doc.content.size);
      let r = N.atStart(e.doc);
      r.eq(e.selection) || e.setSelection(r);
    } else super.replace(e, t);
  }
  toJSON() {
    return { type: "all" };
  }
  static fromJSON(e) {
    return new ye(e);
  }
  map(e) {
    return new ye(e);
  }
  eq(e) {
    return e instanceof ye;
  }
  getBookmark() {
    return Of;
  }
}
N.jsonID("all", ye);
const Of = {
  map() {
    return this;
  },
  resolve(n) {
    return new ye(n);
  },
};
function Ft(n, e, t, r, i, s = !1) {
  if (e.inlineContent) return T.create(n, t);
  for (let o = r - (i > 0 ? 0 : 1); i > 0 ? o < e.childCount : o >= 0; o += i) {
    let l = e.child(o);
    if (l.isAtom) {
      if (!s && O.isSelectable(l))
        return O.create(n, t - (i < 0 ? l.nodeSize : 0));
    } else {
      let a = Ft(n, l, t + i, i < 0 ? l.childCount : 0, i, s);
      if (a) return a;
    }
    t += l.nodeSize * i;
  }
  return null;
}
function jo(n, e, t) {
  let r = n.steps.length - 1;
  if (r < e) return;
  let i = n.steps[r];
  if (!(i instanceof _ || i instanceof Q)) return;
  let s = n.mapping.maps[r],
    o;
  (s.forEach((l, a, c, u) => {
    o == null && (o = u);
  }),
    n.setSelection(N.near(n.doc.resolve(o), t)));
}
const Ho = 1,
  Yn = 2,
  _o = 4;
class Nf extends Ya {
  constructor(e) {
    (super(e.doc),
      (this.curSelectionFor = 0),
      (this.updated = 0),
      (this.meta = Object.create(null)),
      (this.time = Date.now()),
      (this.curSelection = e.selection),
      (this.storedMarks = e.storedMarks));
  }
  get selection() {
    return (
      this.curSelectionFor < this.steps.length &&
        ((this.curSelection = this.curSelection.map(
          this.doc,
          this.mapping.slice(this.curSelectionFor),
        )),
        (this.curSelectionFor = this.steps.length)),
      this.curSelection
    );
  }
  setSelection(e) {
    if (e.$from.doc != this.doc)
      throw new RangeError(
        "Selection passed to setSelection must point at the current document",
      );
    return (
      (this.curSelection = e),
      (this.curSelectionFor = this.steps.length),
      (this.updated = (this.updated | Ho) & ~Yn),
      (this.storedMarks = null),
      this
    );
  }
  get selectionSet() {
    return (this.updated & Ho) > 0;
  }
  setStoredMarks(e) {
    return ((this.storedMarks = e), (this.updated |= Yn), this);
  }
  ensureMarks(e) {
    return (
      z.sameSet(this.storedMarks || this.selection.$from.marks(), e) ||
        this.setStoredMarks(e),
      this
    );
  }
  addStoredMark(e) {
    return this.ensureMarks(
      e.addToSet(this.storedMarks || this.selection.$head.marks()),
    );
  }
  removeStoredMark(e) {
    return this.ensureMarks(
      e.removeFromSet(this.storedMarks || this.selection.$head.marks()),
    );
  }
  get storedMarksSet() {
    return (this.updated & Yn) > 0;
  }
  addStep(e, t) {
    (super.addStep(e, t),
      (this.updated = this.updated & ~Yn),
      (this.storedMarks = null));
  }
  setTime(e) {
    return ((this.time = e), this);
  }
  replaceSelection(e) {
    return (this.selection.replace(this, e), this);
  }
  replaceSelectionWith(e, t = !0) {
    let r = this.selection;
    return (
      t &&
        (e = e.mark(
          this.storedMarks ||
            (r.empty ? r.$from.marks() : r.$from.marksAcross(r.$to) || z.none),
        )),
      r.replaceWith(this, e),
      this
    );
  }
  deleteSelection() {
    return (this.selection.replace(this), this);
  }
  insertText(e, t, r) {
    let i = this.doc.type.schema;
    if (t == null)
      return e
        ? this.replaceSelectionWith(i.text(e), !0)
        : this.deleteSelection();
    {
      if ((r == null && (r = t), !e)) return this.deleteRange(t, r);
      let s = this.storedMarks;
      if (!s) {
        let o = this.doc.resolve(t);
        s = r == t ? o.marks() : o.marksAcross(this.doc.resolve(r));
      }
      return (
        this.replaceRangeWith(t, r, i.text(e, s)),
        !this.selection.empty &&
          this.selection.to == t + e.length &&
          this.setSelection(N.near(this.selection.$to)),
        this
      );
    }
  }
  setMeta(e, t) {
    return ((this.meta[typeof e == "string" ? e : e.key] = t), this);
  }
  getMeta(e) {
    return this.meta[typeof e == "string" ? e : e.key];
  }
  get isGeneric() {
    for (let e in this.meta) return !1;
    return !0;
  }
  scrollIntoView() {
    return ((this.updated |= _o), this);
  }
  get scrolledIntoView() {
    return (this.updated & _o) > 0;
  }
}
function Wo(n, e) {
  return !e || !n ? n : n.bind(e);
}
class fn {
  constructor(e, t, r) {
    ((this.name = e),
      (this.init = Wo(t.init, r)),
      (this.apply = Wo(t.apply, r)));
  }
}
const Df = [
  new fn("doc", {
    init(n) {
      return n.doc || n.schema.topNodeType.createAndFill();
    },
    apply(n) {
      return n.doc;
    },
  }),
  new fn("selection", {
    init(n, e) {
      return n.selection || N.atStart(e.doc);
    },
    apply(n) {
      return n.selection;
    },
  }),
  new fn("storedMarks", {
    init(n) {
      return n.storedMarks || null;
    },
    apply(n, e, t, r) {
      return r.selection.$cursor ? n.storedMarks : null;
    },
  }),
  new fn("scrollToSelection", {
    init() {
      return 0;
    },
    apply(n, e) {
      return n.scrolledIntoView ? e + 1 : e;
    },
  }),
];
class Ai {
  constructor(e, t) {
    ((this.schema = e),
      (this.plugins = []),
      (this.pluginsByKey = Object.create(null)),
      (this.fields = Df.slice()),
      t &&
        t.forEach((r) => {
          if (this.pluginsByKey[r.key])
            throw new RangeError(
              "Adding different instances of a keyed plugin (" + r.key + ")",
            );
          (this.plugins.push(r),
            (this.pluginsByKey[r.key] = r),
            r.spec.state && this.fields.push(new fn(r.key, r.spec.state, r)));
        }));
  }
}
class Fe {
  constructor(e) {
    this.config = e;
  }
  get schema() {
    return this.config.schema;
  }
  get plugins() {
    return this.config.plugins;
  }
  apply(e) {
    return this.applyTransaction(e).state;
  }
  filterTransaction(e, t = -1) {
    for (let r = 0; r < this.config.plugins.length; r++)
      if (r != t) {
        let i = this.config.plugins[r];
        if (
          i.spec.filterTransaction &&
          !i.spec.filterTransaction.call(i, e, this)
        )
          return !1;
      }
    return !0;
  }
  applyTransaction(e) {
    if (!this.filterTransaction(e)) return { state: this, transactions: [] };
    let t = [e],
      r = this.applyInner(e),
      i = null;
    for (;;) {
      let s = !1;
      for (let o = 0; o < this.config.plugins.length; o++) {
        let l = this.config.plugins[o];
        if (l.spec.appendTransaction) {
          let a = i ? i[o].n : 0,
            c = i ? i[o].state : this,
            u =
              a < t.length &&
              l.spec.appendTransaction.call(l, a ? t.slice(a) : t, c, r);
          if (u && r.filterTransaction(u, o)) {
            if ((u.setMeta("appendedTransaction", e), !i)) {
              i = [];
              for (let d = 0; d < this.config.plugins.length; d++)
                i.push(
                  d < o ? { state: r, n: t.length } : { state: this, n: 0 },
                );
            }
            (t.push(u), (r = r.applyInner(u)), (s = !0));
          }
          i && (i[o] = { state: r, n: t.length });
        }
      }
      if (!s) return { state: r, transactions: t };
    }
  }
  applyInner(e) {
    if (!e.before.eq(this.doc))
      throw new RangeError("Applying a mismatched transaction");
    let t = new Fe(this.config),
      r = this.config.fields;
    for (let i = 0; i < r.length; i++) {
      let s = r[i];
      t[s.name] = s.apply(e, this[s.name], this, t);
    }
    return t;
  }
  get tr() {
    return new Nf(this);
  }
  static create(e) {
    let t = new Ai(e.doc ? e.doc.type.schema : e.schema, e.plugins),
      r = new Fe(t);
    for (let i = 0; i < t.fields.length; i++)
      r[t.fields[i].name] = t.fields[i].init(e, r);
    return r;
  }
  reconfigure(e) {
    let t = new Ai(this.schema, e.plugins),
      r = t.fields,
      i = new Fe(t);
    for (let s = 0; s < r.length; s++) {
      let o = r[s].name;
      i[o] = this.hasOwnProperty(o) ? this[o] : r[s].init(e, i);
    }
    return i;
  }
  toJSON(e) {
    let t = { doc: this.doc.toJSON(), selection: this.selection.toJSON() };
    if (
      (this.storedMarks &&
        (t.storedMarks = this.storedMarks.map((r) => r.toJSON())),
      e && typeof e == "object")
    )
      for (let r in e) {
        if (r == "doc" || r == "selection")
          throw new RangeError(
            "The JSON fields `doc` and `selection` are reserved",
          );
        let i = e[r],
          s = i.spec.state;
        s && s.toJSON && (t[r] = s.toJSON.call(i, this[i.key]));
      }
    return t;
  }
  static fromJSON(e, t, r) {
    if (!t) throw new RangeError("Invalid input for EditorState.fromJSON");
    if (!e.schema)
      throw new RangeError("Required config field 'schema' missing");
    let i = new Ai(e.schema, e.plugins),
      s = new Fe(i);
    return (
      i.fields.forEach((o) => {
        if (o.name == "doc") s.doc = wt.fromJSON(e.schema, t.doc);
        else if (o.name == "selection")
          s.selection = N.fromJSON(s.doc, t.selection);
        else if (o.name == "storedMarks")
          t.storedMarks &&
            (s.storedMarks = t.storedMarks.map(e.schema.markFromJSON));
        else {
          if (r)
            for (let l in r) {
              let a = r[l],
                c = a.spec.state;
              if (
                a.key == o.name &&
                c &&
                c.fromJSON &&
                Object.prototype.hasOwnProperty.call(t, l)
              ) {
                s[o.name] = c.fromJSON.call(a, e, t[l], s);
                return;
              }
            }
          s[o.name] = o.init(e, s);
        }
      }),
      s
    );
  }
}
function Xa(n, e, t) {
  for (let r in n) {
    let i = n[r];
    (i instanceof Function
      ? (i = i.bind(e))
      : r == "handleDOMEvents" && (i = Xa(i, e, {})),
      (t[r] = i));
  }
  return t;
}
class V {
  constructor(e) {
    ((this.spec = e),
      (this.props = {}),
      e.props && Xa(e.props, this, this.props),
      (this.key = e.key ? e.key.key : Qa("plugin")));
  }
  getState(e) {
    return e[this.key];
  }
}
const Oi = Object.create(null);
function Qa(n) {
  return n in Oi ? n + "$" + ++Oi[n] : ((Oi[n] = 0), n + "$");
}
class K {
  constructor(e = "key") {
    this.key = Qa(e);
  }
  get(e) {
    return e.config.pluginsByKey[this.key];
  }
  getState(e) {
    return e[this.key];
  }
}
var Ni = { exports: {} },
  Di = {};
/**
 * @license React
 * use-sync-external-store-shim.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var qo;
function Rf() {
  if (qo) return Di;
  qo = 1;
  var n = ba();
  function e(d, f) {
    return (d === f && (d !== 0 || 1 / d === 1 / f)) || (d !== d && f !== f);
  }
  var t = typeof Object.is == "function" ? Object.is : e,
    r = n.useState,
    i = n.useEffect,
    s = n.useLayoutEffect,
    o = n.useDebugValue;
  function l(d, f) {
    var h = f(),
      p = r({ inst: { value: h, getSnapshot: f } }),
      g = p[0].inst,
      m = p[1];
    return (
      s(
        function () {
          ((g.value = h), (g.getSnapshot = f), a(g) && m({ inst: g }));
        },
        [d, h, f],
      ),
      i(
        function () {
          return (
            a(g) && m({ inst: g }),
            d(function () {
              a(g) && m({ inst: g });
            })
          );
        },
        [d],
      ),
      o(h),
      h
    );
  }
  function a(d) {
    var f = d.getSnapshot;
    d = d.value;
    try {
      var h = f();
      return !t(d, h);
    } catch {
      return !0;
    }
  }
  function c(d, f) {
    return f();
  }
  var u =
    typeof window > "u" ||
    typeof window.document > "u" ||
    typeof window.document.createElement > "u"
      ? c
      : l;
  return (
    (Di.useSyncExternalStore =
      n.useSyncExternalStore !== void 0 ? n.useSyncExternalStore : u),
    Di
  );
}
var Uo;
function Za() {
  return (Uo || ((Uo = 1), (Ni.exports = Rf())), Ni.exports);
}
var ec = Za(),
  Ko = Object.defineProperty,
  If = (n, e) => {
    let t = {};
    for (var r in n) Ko(t, r, { get: n[r], enumerable: !0 });
    return (Ko(t, Symbol.toStringTag, { value: "Module" }), t);
  };
const tc = (n, e) =>
  n.selection.empty
    ? !1
    : (e && e(n.tr.deleteSelection().scrollIntoView()), !0);
function nc(n, e) {
  let { $cursor: t } = n.selection;
  return !t || (e ? !e.endOfTextblock("backward", n) : t.parentOffset > 0)
    ? null
    : t;
}
const rc = (n, e, t) => {
    let r = nc(n, t);
    if (!r) return !1;
    let i = zs(r);
    if (!i) {
      let o = r.blockRange(),
        l = o && nn(o);
      return l == null ? !1 : (e && e(n.tr.lift(o, l).scrollIntoView()), !0);
    }
    let s = i.nodeBefore;
    if (pc(n, i, e, -1)) return !0;
    if (r.parent.content.size == 0 && (Yt(s, "end") || O.isSelectable(s)))
      for (let o = r.depth; ; o--) {
        let l = ai(n.doc, r.before(o), r.after(o), C.empty);
        if (l && l.slice.size < l.to - l.from) {
          if (e) {
            let a = n.tr.step(l);
            (a.setSelection(
              Yt(s, "end")
                ? N.findFrom(a.doc.resolve(a.mapping.map(i.pos, -1)), -1)
                : O.create(a.doc, i.pos - s.nodeSize),
            ),
              e(a.scrollIntoView()));
          }
          return !0;
        }
        if (o == 1 || r.node(o - 1).childCount > 1) break;
      }
    return s.isAtom && i.depth == r.depth - 1
      ? (e && e(n.tr.delete(i.pos - s.nodeSize, i.pos).scrollIntoView()), !0)
      : !1;
  },
  ic = (n, e, t) => {
    let r = nc(n, t);
    if (!r) return !1;
    let i = zs(r);
    return i ? oc(n, i, e) : !1;
  },
  sc = (n, e, t) => {
    let r = ac(n, t);
    if (!r) return !1;
    let i = Fs(r);
    return i ? oc(n, i, e) : !1;
  };
function oc(n, e, t) {
  let r = e.nodeBefore,
    i = r,
    s = e.pos - 1;
  for (; !i.isTextblock; s--) {
    if (i.type.spec.isolating) return !1;
    let u = i.lastChild;
    if (!u) return !1;
    i = u;
  }
  let o = e.nodeAfter,
    l = o,
    a = e.pos + 1;
  for (; !l.isTextblock; a++) {
    if (l.type.spec.isolating) return !1;
    let u = l.firstChild;
    if (!u) return !1;
    l = u;
  }
  let c = ai(n.doc, s, a, C.empty);
  if (!c || c.from != s || (c instanceof _ && c.slice.size >= a - s)) return !1;
  if (t) {
    let u = n.tr.step(c);
    (u.setSelection(T.create(u.doc, s)), t(u.scrollIntoView()));
  }
  return !0;
}
function Yt(n, e, t = !1) {
  for (let r = n; r; r = e == "start" ? r.firstChild : r.lastChild) {
    if (r.isTextblock) return !0;
    if (t && r.childCount != 1) return !1;
  }
  return !1;
}
const lc = (n, e, t) => {
  let { $head: r, empty: i } = n.selection,
    s = r;
  if (!i) return !1;
  if (r.parent.isTextblock) {
    if (t ? !t.endOfTextblock("backward", n) : r.parentOffset > 0) return !1;
    s = zs(r);
  }
  let o = s && s.nodeBefore;
  return !o || !O.isSelectable(o)
    ? !1
    : (e &&
        e(
          n.tr
            .setSelection(O.create(n.doc, s.pos - o.nodeSize))
            .scrollIntoView(),
        ),
      !0);
};
function zs(n) {
  if (!n.parent.type.spec.isolating)
    for (let e = n.depth - 1; e >= 0; e--) {
      if (n.index(e) > 0) return n.doc.resolve(n.before(e + 1));
      if (n.node(e).type.spec.isolating) break;
    }
  return null;
}
function ac(n, e) {
  let { $cursor: t } = n.selection;
  return !t ||
    (e
      ? !e.endOfTextblock("forward", n)
      : t.parentOffset < t.parent.content.size)
    ? null
    : t;
}
const cc = (n, e, t) => {
    let r = ac(n, t);
    if (!r) return !1;
    let i = Fs(r);
    if (!i) return !1;
    let s = i.nodeAfter;
    if (pc(n, i, e, 1)) return !0;
    if (r.parent.content.size == 0 && (Yt(s, "start") || O.isSelectable(s))) {
      let o = ai(n.doc, r.before(), r.after(), C.empty);
      if (o && o.slice.size < o.to - o.from) {
        if (e) {
          let l = n.tr.step(o);
          (l.setSelection(
            Yt(s, "start")
              ? N.findFrom(l.doc.resolve(l.mapping.map(i.pos)), 1)
              : O.create(l.doc, l.mapping.map(i.pos)),
          ),
            e(l.scrollIntoView()));
        }
        return !0;
      }
    }
    return s.isAtom && i.depth == r.depth - 1
      ? (e && e(n.tr.delete(i.pos, i.pos + s.nodeSize).scrollIntoView()), !0)
      : !1;
  },
  uc = (n, e, t) => {
    let { $head: r, empty: i } = n.selection,
      s = r;
    if (!i) return !1;
    if (r.parent.isTextblock) {
      if (
        t
          ? !t.endOfTextblock("forward", n)
          : r.parentOffset < r.parent.content.size
      )
        return !1;
      s = Fs(r);
    }
    let o = s && s.nodeAfter;
    return !o || !O.isSelectable(o)
      ? !1
      : (e && e(n.tr.setSelection(O.create(n.doc, s.pos)).scrollIntoView()),
        !0);
  };
function Fs(n) {
  if (!n.parent.type.spec.isolating)
    for (let e = n.depth - 1; e >= 0; e--) {
      let t = n.node(e);
      if (n.index(e) + 1 < t.childCount) return n.doc.resolve(n.after(e + 1));
      if (t.type.spec.isolating) break;
    }
  return null;
}
const Lf = (n, e) => {
    let t = n.selection,
      r = t instanceof O,
      i;
    if (r) {
      if (t.node.isTextblock || !at(n.doc, t.from)) return !1;
      i = t.from;
    } else if (((i = li(n.doc, t.from, -1)), i == null)) return !1;
    if (e) {
      let s = n.tr.join(i);
      (r &&
        s.setSelection(
          O.create(s.doc, i - n.doc.resolve(i).nodeBefore.nodeSize),
        ),
        e(s.scrollIntoView()));
    }
    return !0;
  },
  Pf = (n, e) => {
    let t = n.selection,
      r;
    if (t instanceof O) {
      if (t.node.isTextblock || !at(n.doc, t.to)) return !1;
      r = t.to;
    } else if (((r = li(n.doc, t.to, 1)), r == null)) return !1;
    return (e && e(n.tr.join(r).scrollIntoView()), !0);
  },
  Bf = (n, e) => {
    let { $from: t, $to: r } = n.selection,
      i = t.blockRange(r),
      s = i && nn(i);
    return s == null ? !1 : (e && e(n.tr.lift(i, s).scrollIntoView()), !0);
  },
  dc = (n, e) => {
    let { $head: t, $anchor: r } = n.selection;
    return !t.parent.type.spec.code || !t.sameParent(r)
      ? !1
      : (e &&
          e(
            n.tr
              .insertText(
                `
`,
              )
              .scrollIntoView(),
          ),
        !0);
  };
function Vs(n) {
  for (let e = 0; e < n.edgeCount; e++) {
    let { type: t } = n.edge(e);
    if (t.isTextblock && !t.hasRequiredAttrs()) return t;
  }
  return null;
}
const $f = (n, e) => {
    let { $head: t, $anchor: r } = n.selection;
    if (!t.parent.type.spec.code || !t.sameParent(r)) return !1;
    let i = t.node(-1),
      s = t.indexAfter(-1),
      o = Vs(i.contentMatchAt(s));
    if (!o || !i.canReplaceWith(s, s, o)) return !1;
    if (e) {
      let l = t.after(),
        a = n.tr.replaceWith(l, l, o.createAndFill());
      (a.setSelection(N.near(a.doc.resolve(l), 1)), e(a.scrollIntoView()));
    }
    return !0;
  },
  fc = (n, e) => {
    let t = n.selection,
      { $from: r, $to: i } = t;
    if (t instanceof ye || r.parent.inlineContent || i.parent.inlineContent)
      return !1;
    let s = Vs(i.parent.contentMatchAt(i.indexAfter()));
    if (!s || !s.isTextblock) return !1;
    if (e) {
      let o = (!r.parentOffset && i.index() < i.parent.childCount ? r : i).pos,
        l = n.tr.insert(o, s.createAndFill());
      (l.setSelection(T.create(l.doc, o + 1)), e(l.scrollIntoView()));
    }
    return !0;
  },
  hc = (n, e) => {
    let { $cursor: t } = n.selection;
    if (!t || t.parent.content.size) return !1;
    if (t.depth > 1 && t.after() != t.end(-1)) {
      let s = t.before();
      if (He(n.doc, s)) return (e && e(n.tr.split(s).scrollIntoView()), !0);
    }
    let r = t.blockRange(),
      i = r && nn(r);
    return i == null ? !1 : (e && e(n.tr.lift(r, i).scrollIntoView()), !0);
  };
function zf(n) {
  return (e, t) => {
    if (e.selection instanceof O && e.selection.node.isBlock) {
      let { $from: h } = e.selection;
      return !h.parentOffset || !He(e.doc, h.pos)
        ? !1
        : (t && t(e.tr.split(h.pos).scrollIntoView()), !0);
    }
    if (!e.selection.$from.depth) return !1;
    let r = e.tr;
    !e.selection.empty &&
      (e.selection instanceof T || e.selection instanceof ye) &&
      r.deleteSelection();
    let { $from: i } = r.selection,
      s = r.steps.length,
      o = [],
      l,
      a,
      c = !1,
      u = !1;
    for (let h = i.depth; ; h--)
      if (i.node(h).isBlock) {
        ((c = i.end(h) == i.pos + (i.depth - h)),
          (u = i.start(h) == i.pos - (i.depth - h)),
          (a = Vs(i.node(h - 1).contentMatchAt(i.indexAfter(h - 1)))),
          o.unshift(c && a ? { type: a } : null),
          (l = h));
        break;
      } else {
        if (h == 1) return !1;
        o.unshift(null);
      }
    let d = i.pos,
      f = He(r.doc, d, o.length, o);
    if (
      (f || ((o[0] = a ? { type: a } : null), (f = He(r.doc, d, o.length, o))),
      !f)
    )
      return !1;
    if ((r.split(d, o.length, o), !c && u && i.node(l).type != a)) {
      let h = r.mapping.slice(s),
        p = h.map(i.before(l)),
        g = r.doc.resolve(p);
      a &&
        i.node(l - 1).canReplaceWith(g.index(), g.index() + 1, a) &&
        r.setNodeMarkup(h.map(i.before(l)), a);
    }
    return (t && t(r.scrollIntoView()), !0);
  };
}
const Ff = zf(),
  Vf = (n, e) => {
    let { $from: t, to: r } = n.selection,
      i,
      s = t.sharedDepth(r);
    return s == 0
      ? !1
      : ((i = t.before(s)), e && e(n.tr.setSelection(O.create(n.doc, i))), !0);
  };
function jf(n, e, t) {
  let r = e.nodeBefore,
    i = e.nodeAfter,
    s = e.index();
  return !r || !i || !r.type.compatibleContent(i.type)
    ? !1
    : !r.content.size && e.parent.canReplace(s - 1, s)
      ? (t && t(n.tr.delete(e.pos - r.nodeSize, e.pos).scrollIntoView()), !0)
      : !e.parent.canReplace(s, s + 1) || !(i.isTextblock || at(n.doc, e.pos))
        ? !1
        : (t && t(n.tr.join(e.pos).scrollIntoView()), !0);
}
function pc(n, e, t, r) {
  let i = e.nodeBefore,
    s = e.nodeAfter,
    o,
    l,
    a = i.type.spec.isolating || s.type.spec.isolating;
  if (!a && jf(n, e, t)) return !0;
  let c = !a && e.parent.canReplace(e.index(), e.index() + 1);
  if (
    c &&
    (o = (l = i.contentMatchAt(i.childCount)).findWrapping(s.type)) &&
    l.matchType(o[0] || s.type).validEnd
  ) {
    if (t) {
      let h = e.pos + s.nodeSize,
        p = b.empty;
      for (let y = o.length - 1; y >= 0; y--) p = b.from(o[y].create(null, p));
      p = b.from(i.copy(p));
      let g = n.tr.step(
          new Q(e.pos - 1, h, e.pos, h, new C(p, 1, 0), o.length, !0),
        ),
        m = g.doc.resolve(h + 2 * o.length);
      (m.nodeAfter &&
        m.nodeAfter.type == i.type &&
        at(g.doc, m.pos) &&
        g.join(m.pos),
        t(g.scrollIntoView()));
    }
    return !0;
  }
  let u = s.type.spec.isolating || (r > 0 && a) ? null : N.findFrom(e, 1),
    d = u && u.$from.blockRange(u.$to),
    f = d && nn(d);
  if (f != null && f >= e.depth)
    return (t && t(n.tr.lift(d, f).scrollIntoView()), !0);
  if (c && Yt(s, "start", !0) && Yt(i, "end")) {
    let h = i,
      p = [];
    for (; p.push(h), !h.isTextblock;) h = h.lastChild;
    let g = s,
      m = 1;
    for (; !g.isTextblock; g = g.firstChild) m++;
    if (h.canReplace(h.childCount, h.childCount, g.content)) {
      if (t) {
        let y = b.empty;
        for (let x = p.length - 1; x >= 0; x--) y = b.from(p[x].copy(y));
        let k = n.tr.step(
          new Q(
            e.pos - p.length,
            e.pos + s.nodeSize,
            e.pos + m,
            e.pos + s.nodeSize - m,
            new C(y, p.length, 0),
            0,
            !0,
          ),
        );
        t(k.scrollIntoView());
      }
      return !0;
    }
  }
  return !1;
}
function mc(n) {
  return function (e, t) {
    let r = e.selection,
      i = n < 0 ? r.$from : r.$to,
      s = i.depth;
    for (; i.node(s).isInline;) {
      if (!s) return !1;
      s--;
    }
    return i.node(s).isTextblock
      ? (t &&
          t(e.tr.setSelection(T.create(e.doc, n < 0 ? i.start(s) : i.end(s)))),
        !0)
      : !1;
  };
}
const Hf = mc(-1),
  _f = mc(1);
function Wf(n, e = null) {
  return function (t, r) {
    let { $from: i, $to: s } = t.selection,
      o = i.blockRange(s),
      l = o && Bs(o, n, e);
    return l ? (r && r(t.tr.wrap(o, l).scrollIntoView()), !0) : !1;
  };
}
function Jo(n, e = null) {
  return function (t, r) {
    let i = !1;
    for (let s = 0; s < t.selection.ranges.length && !i; s++) {
      let {
        $from: { pos: o },
        $to: { pos: l },
      } = t.selection.ranges[s];
      t.doc.nodesBetween(o, l, (a, c) => {
        if (i) return !1;
        if (!(!a.isTextblock || a.hasMarkup(n, e)))
          if (a.type == n) i = !0;
          else {
            let u = t.doc.resolve(c),
              d = u.index();
            i = u.parent.canReplaceWith(d, d + 1, n);
          }
      });
    }
    if (!i) return !1;
    if (r) {
      let s = t.tr;
      for (let o = 0; o < t.selection.ranges.length; o++) {
        let {
          $from: { pos: l },
          $to: { pos: a },
        } = t.selection.ranges[o];
        s.setBlockType(l, a, n, e);
      }
      r(s.scrollIntoView());
    }
    return !0;
  };
}
function js(...n) {
  return function (e, t, r) {
    for (let i = 0; i < n.length; i++) if (n[i](e, t, r)) return !0;
    return !1;
  };
}
js(tc, rc, lc);
js(tc, cc, uc);
js(dc, fc, hc, Ff);
typeof navigator < "u"
  ? /Mac|iP(hone|[oa]d)/.test(navigator.platform)
  : typeof os < "u" && os.platform && os.platform() == "darwin";
function qf(n, e = null) {
  return function (t, r) {
    let { $from: i, $to: s } = t.selection,
      o = i.blockRange(s);
    if (!o) return !1;
    let l = r ? t.tr : null;
    return Uf(l, o, n, e) ? (r && r(l.scrollIntoView()), !0) : !1;
  };
}
function Uf(n, e, t, r = null) {
  let i = !1,
    s = e,
    o = e.$from.doc;
  if (
    e.depth >= 2 &&
    e.$from.node(e.depth - 1).type.compatibleContent(t) &&
    e.startIndex == 0
  ) {
    if (e.$from.index(e.depth - 1) == 0) return !1;
    let a = o.resolve(e.start - 2);
    ((s = new br(a, a, e.depth)),
      e.endIndex < e.parent.childCount &&
        (e = new br(e.$from, o.resolve(e.$to.end(e.depth)), e.depth)),
      (i = !0));
  }
  let l = Bs(s, t, r, e);
  return l ? (n && Kf(n, e, l, i, t), !0) : !1;
}
function Kf(n, e, t, r, i) {
  let s = b.empty;
  for (let u = t.length - 1; u >= 0; u--)
    s = b.from(t[u].type.create(t[u].attrs, s));
  n.step(
    new Q(
      e.start - (r ? 2 : 0),
      e.end,
      e.start,
      e.end,
      new C(s, 0, 0),
      t.length,
      !0,
    ),
  );
  let o = 0;
  for (let u = 0; u < t.length; u++) t[u].type == i && (o = u + 1);
  let l = t.length - o,
    a = e.start + t.length - (r ? 2 : 0),
    c = e.parent;
  for (let u = e.startIndex, d = e.endIndex, f = !0; u < d; u++, f = !1)
    (!f && l && He(n.doc, a, l) && (n.split(a, l), (a += 2 * l)),
      (a += c.child(u).nodeSize));
  return n;
}
function xr(n, e) {
  return n instanceof Zi ? e == n : n.indexOf(e) > -1;
}
function Jf(n) {
  return function (e, t) {
    let { $from: r, $to: i } = e.selection,
      s = r.blockRange(i, (o) => o.childCount > 0 && xr(n, o.firstChild.type));
    return s
      ? t
        ? xr(n, r.node(s.depth - 1).type)
          ? Gf(e, t, s)
          : Yf(e, t, s)
        : !0
      : !1;
  };
}
function Gf(n, e, t) {
  let r = n.tr,
    i = t.end,
    s = t.$to.end(t.depth),
    o = t.parent.child(t.endIndex - 1).type;
  i < s &&
    (r.step(
      new Q(
        i - 1,
        s,
        i,
        s,
        new C(b.from(o.create(null, t.parent.copy())), 1, 0),
        1,
        !0,
      ),
    ),
    (t = new br(r.doc.resolve(t.$from.pos), r.doc.resolve(s), t.depth)));
  const l = nn(t);
  if (l == null) return !1;
  r.lift(t, l);
  let a = r.doc.resolve(r.mapping.map(i, -1) - 1);
  return (
    at(r.doc, a.pos) && a.nodeBefore.type == a.nodeAfter.type && r.join(a.pos),
    e(r.scrollIntoView()),
    !0
  );
}
function Yf(n, e, t) {
  let r = n.tr,
    i = t.parent;
  for (let h = t.end, p = t.endIndex - 1, g = t.startIndex; p > g; p--)
    ((h -= i.child(p).nodeSize), r.delete(h - 1, h + 1));
  let s = r.doc.resolve(t.start),
    o = s.nodeAfter;
  if (r.mapping.map(t.end) != t.start + s.nodeAfter.nodeSize) return !1;
  let l = t.startIndex == 0,
    a = t.endIndex == i.childCount,
    c = s.node(-1),
    u = s.index(-1);
  if (
    !c.canReplace(
      u + (l ? 0 : 1),
      u + 1,
      o.content.append(a ? b.empty : b.from(i)),
    )
  )
    return !1;
  let d = s.pos,
    f = d + o.nodeSize;
  return (
    r.step(
      new Q(
        d - (l ? 1 : 0),
        f + (a ? 1 : 0),
        d + 1,
        f - 1,
        new C(
          (l ? b.empty : b.from(i.copy(b.empty))).append(
            a ? b.empty : b.from(i.copy(b.empty)),
          ),
          l ? 0 : 1,
          a ? 0 : 1,
        ),
        l ? 0 : 1,
      ),
    ),
    e(r.scrollIntoView()),
    !0
  );
}
function Xf(n) {
  return function (e, t) {
    let { $from: r, $to: i } = e.selection,
      s = r.blockRange(i, (c) => c.childCount > 0 && xr(n, c.firstChild.type));
    if (!s) return !1;
    let o = s.startIndex;
    if (o == 0) return !1;
    let l = s.parent,
      a = l.child(o - 1);
    if (!xr(n, a.type)) return !1;
    if (t) {
      let c = a.lastChild && a.lastChild.type == l.type,
        u = b.from(c ? a.lastChild.lastChild.type.create() : null),
        d = new C(
          b.from(a.type.create(null, b.from(l.type.create(null, u)))),
          c ? 3 : 1,
          0,
        ),
        f = s.start,
        h = s.end;
      t(e.tr.step(new Q(f - (c ? 3 : 1), h, f, h, d, 1, !0)).scrollIntoView());
    }
    return !0;
  };
}
const te = function (n) {
    for (var e = 0; ; e++) if (((n = n.previousSibling), !n)) return e;
  },
  Xt = function (n) {
    let e = n.assignedSlot || n.parentNode;
    return e && e.nodeType == 11 ? e.host : e;
  };
let rs = null;
const $e = function (n, e, t) {
    let r = rs || (rs = document.createRange());
    return (r.setEnd(n, t ?? n.nodeValue.length), r.setStart(n, e || 0), r);
  },
  Qf = function () {
    rs = null;
  },
  Ot = function (n, e, t, r) {
    return t && (Go(n, e, t, r, -1) || Go(n, e, t, r, 1));
  },
  Zf = /^(img|br|input|textarea|hr)$/i;
function Go(n, e, t, r, i) {
  for (var s; ;) {
    if (n == t && e == r) return !0;
    if (e == (i < 0 ? 0 : oe(n))) {
      let o = n.parentNode;
      if (
        !o ||
        !A(o) ||
        Fn(n) ||
        Zf.test(n.nodeName) ||
        n.contentEditable == "false"
      )
        return !1;
      ((e = te(n) + (i < 0 ? 0 : 1)), (n = o));
    } else if (A(n)) {
      let o = n.childNodes[e + (i < 0 ? -1 : 0)];
      if (A(o) && o.contentEditable == "false")
        if (
          !((s = o.pmViewDesc) === null || s === void 0) &&
          s.ignoreForSelection
        )
          e += i;
        else return !1;
      else ((n = o), (e = i < 0 ? oe(n) : 0));
    } else return !1;
  }
}
function oe(n) {
  return n.nodeType == 3 ? n.nodeValue.length : n.childNodes.length;
}
function A(n) {
  return n.nodeType == 1;
}
function J(n) {
  return n.nodeType == 3;
}
function Nt(n, e) {
  return e ? n.contains(A(e) ? e : e.parentNode) : !1;
}
function eh(n, e) {
  for (;;) {
    if (J(n) && e) return n;
    if (A(n) && e > 0) {
      if (n.contentEditable == "false") return null;
      ((n = n.childNodes[e - 1]), (e = oe(n)));
    } else if (n.parentNode && !Fn(n)) ((e = te(n)), (n = n.parentNode));
    else return null;
  }
}
function th(n, e) {
  for (;;) {
    if (J(n) && e < n.nodeValue.length) return n;
    if (A(n) && e < n.childNodes.length) {
      if (n.contentEditable == "false") return null;
      ((n = n.childNodes[e]), (e = 0));
    } else if (n.parentNode && !Fn(n)) ((e = te(n) + 1), (n = n.parentNode));
    else return null;
  }
}
function nh(n, e, t) {
  for (let r = e == 0, i = e == oe(n); r || i;) {
    if (n == t) return !0;
    let s = te(n);
    if (((n = n.parentNode), !n)) return !1;
    ((r = r && s == 0), (i = i && s == oe(n)));
  }
}
function Fn(n) {
  let e;
  for (let t = n; t && !(e = t.pmViewDesc); t = t.parentNode);
  return e && e.node && e.node.isBlock && (e.dom == n || e.contentDOM == n);
}
const ui = function (n) {
  return (
    n.focusNode && Ot(n.focusNode, n.focusOffset, n.anchorNode, n.anchorOffset)
  );
};
function rh(n, e) {
  let t = document.createEvent("Event");
  return (
    t.initEvent("keydown", !0, !0),
    (t.keyCode = n),
    (t.key = t.code = e),
    t
  );
}
function ih(n) {
  let e = n.activeElement;
  for (; e && e.shadowRoot;) e = e.shadowRoot.activeElement;
  return e;
}
function sh(n, e, t) {
  if (n.caretPositionFromPoint)
    try {
      let r = n.caretPositionFromPoint(e, t);
      if (r)
        return {
          node: r.offsetNode,
          offset: Math.min(oe(r.offsetNode), r.offset),
        };
    } catch {}
  if (n.caretRangeFromPoint) {
    let r = n.caretRangeFromPoint(e, t);
    if (r)
      return {
        node: r.startContainer,
        offset: Math.min(oe(r.startContainer), r.startOffset),
      };
  }
}
const De = typeof navigator < "u" ? navigator : null,
  Yo = typeof document < "u" ? document : null,
  ct = (De && De.userAgent) || "",
  is = /Edge\/(\d+)/.exec(ct),
  gc = /MSIE \d/.exec(ct),
  ss = /Trident\/(?:[7-9]|\d{2,})\..*rv:(\d+)/.exec(ct),
  me = !!(gc || ss || is),
  tt = gc ? document.documentMode : ss ? +ss[1] : is ? +is[1] : 0,
  be = !me && /gecko\/(\d+)/i.test(ct);
be && +(/Firefox\/(\d+)/.exec(ct) || [0, 0])[1];
const ls = !me && /Chrome\/(\d+)/.exec(ct),
  ie = !!ls,
  yc = ls ? +ls[1] : 0,
  le = !me && !!De && /Apple Computer/.test(De.vendor),
  Qt = le && (/Mobile\/\w+/.test(ct) || (!!De && De.maxTouchPoints > 2)),
  Ce = Qt || (De ? /Mac/.test(De.platform) : !1),
  bc = De ? /Win/.test(De.platform) : !1,
  Ve = /Android \d/.test(ct),
  di = !!Yo && "webkitFontSmoothing" in Yo.documentElement.style,
  oh = di
    ? +(/\bAppleWebKit\/(\d+)/.exec(navigator.userAgent) || [0, 0])[1]
    : 0;
function lh(n) {
  let e = n.defaultView && n.defaultView.visualViewport;
  return e
    ? { left: 0, right: e.width, top: 0, bottom: e.height }
    : {
        left: 0,
        right: n.documentElement.clientWidth,
        top: 0,
        bottom: n.documentElement.clientHeight,
      };
}
function Re(n, e) {
  return typeof n == "number" ? n : n[e];
}
function ah(n) {
  let e = n.getBoundingClientRect(),
    t = e.width / n.offsetWidth || 1,
    r = e.height / n.offsetHeight || 1;
  return {
    left: e.left,
    right: e.left + n.clientWidth * t,
    top: e.top,
    bottom: e.top + n.clientHeight * r,
  };
}
function Xo(n, e, t) {
  if (!as(e) && e.left == 0) return;
  let r = n.someProp("scrollThreshold") || 0,
    i = n.someProp("scrollMargin") || 5,
    s = n.dom.ownerDocument;
  for (let o = t || n.dom; o;) {
    if (!A(o)) {
      o = Xt(o);
      continue;
    }
    let l = o == s.body,
      a = l ? lh(s) : ah(o),
      c = 0,
      u = 0;
    if (
      (e.top < a.top + Re(r, "top")
        ? (u = -(a.top - e.top + Re(i, "top")))
        : e.bottom > a.bottom - Re(r, "bottom") &&
          (u =
            e.bottom - e.top > a.bottom - a.top
              ? e.top + Re(i, "top") - a.top
              : e.bottom - a.bottom + Re(i, "bottom")),
      e.left < a.left + Re(r, "left")
        ? (c = -(a.left - e.left + Re(i, "left")))
        : e.right > a.right - Re(r, "right") &&
          (c = e.right - a.right + Re(i, "right")),
      c || u)
    )
      if (l) s.defaultView.scrollBy(c, u);
      else {
        let f = o.scrollLeft,
          h = o.scrollTop;
        (u && (o.scrollTop += u), c && (o.scrollLeft += c));
        let p = o.scrollLeft - f,
          g = o.scrollTop - h;
        e = {
          left: e.left - p,
          top: e.top - g,
          right: e.right - p,
          bottom: e.bottom - g,
        };
      }
    let d = l ? "fixed" : getComputedStyle(o).position;
    if (/^(fixed|sticky)$/.test(d)) break;
    o = d == "absolute" ? o.offsetParent : Xt(o);
  }
}
function ch(n) {
  let e = n.dom.getBoundingClientRect(),
    t = Math.max(0, e.top),
    r,
    i;
  for (
    let s = (e.left + e.right) / 2, o = t + 1;
    o < Math.min(innerHeight, e.bottom);
    o += 5
  ) {
    let l = n.root.elementFromPoint(s, o);
    if (!l || l == n.dom || !n.dom.contains(l)) continue;
    let a = l.getBoundingClientRect();
    if (a.top >= t - 20) {
      ((r = l), (i = a.top));
      break;
    }
  }
  return { refDOM: r, refTop: i, stack: kc(n.dom) };
}
function kc(n) {
  let e = [],
    t = n.ownerDocument;
  for (
    let r = n;
    r && (e.push({ dom: r, top: r.scrollTop, left: r.scrollLeft }), n != t);
    r = Xt(r)
  );
  return e;
}
function uh({ refDOM: n, refTop: e, stack: t }) {
  let r = n ? n.getBoundingClientRect().top : 0;
  Sc(t, r == 0 ? 0 : r - e);
}
function Sc(n, e) {
  for (let t = 0; t < n.length; t++) {
    let { dom: r, top: i, left: s } = n[t];
    (r.scrollTop != i + e && (r.scrollTop = i + e),
      r.scrollLeft != s && (r.scrollLeft = s));
  }
}
let Pt = null;
function dh(n) {
  if (n.setActive) return n.setActive();
  if (Pt) return n.focus(Pt);
  let e = kc(n);
  (n.focus(
    Pt == null
      ? {
          get preventScroll() {
            return ((Pt = { preventScroll: !0 }), !0);
          },
        }
      : void 0,
  ),
    Pt || ((Pt = !1), Sc(e, 0)));
}
function xc(n, e) {
  let t,
    r = 2e8,
    i,
    s = 0,
    o = e.top,
    l = e.top,
    a,
    c;
  for (let u = n.firstChild, d = 0; u; u = u.nextSibling, d++) {
    let f;
    if (A(u)) f = u.getClientRects();
    else if (J(u)) f = $e(u).getClientRects();
    else continue;
    for (let h = 0; h < f.length; h++) {
      let p = f[h];
      if (p.top <= o && p.bottom >= l) {
        ((o = Math.max(p.bottom, o)), (l = Math.min(p.top, l)));
        let g =
          p.left > e.left
            ? p.left - e.left
            : p.right < e.left
              ? e.left - p.right
              : 0;
        if (g < r) {
          ((t = u),
            (r = g),
            (i =
              g && J(t)
                ? { left: p.right < e.left ? p.right : p.left, top: e.top }
                : e),
            A(u) && g && (s = d + (e.left >= (p.left + p.right) / 2 ? 1 : 0)));
          continue;
        }
      } else
        p.top > e.top &&
          !a &&
          p.left <= e.left &&
          p.right >= e.left &&
          ((a = u),
          (c = {
            left: Math.max(p.left, Math.min(p.right, e.left)),
            top: p.top,
          }));
      !t &&
        ((e.left >= p.right && e.top >= p.top) ||
          (e.left >= p.left && e.top >= p.bottom)) &&
        (s = d + 1);
    }
  }
  return (
    !t && a && ((t = a), (i = c), (r = 0)),
    t && J(t) ? fh(t, i) : !t || r ? { node: n, offset: s } : xc(t, i)
  );
}
function fh(n, e) {
  let t = n.nodeValue.length,
    r = document.createRange(),
    i;
  for (let s = 0; s < t; s++) {
    (r.setEnd(n, s + 1), r.setStart(n, s));
    let o = Ke(r, 1);
    if (o.top != o.bottom && Hs(e, o)) {
      i = { node: n, offset: s + (e.left >= (o.left + o.right) / 2 ? 1 : 0) };
      break;
    }
  }
  return (r.detach(), i || { node: n, offset: 0 });
}
function Hs(n, e) {
  return (
    n.left >= e.left - 1 &&
    n.left <= e.right + 1 &&
    n.top >= e.top - 1 &&
    n.top <= e.bottom + 1
  );
}
function hh(n, e) {
  let t = n.parentNode;
  return t &&
    /^li$/i.test(t.nodeName) &&
    e.left < n.getBoundingClientRect().left
    ? t
    : n;
}
function ph(n, e, t) {
  let { node: r, offset: i } = xc(e, t),
    s = -1;
  if (A(r) && !r.firstChild) {
    let o = r.getBoundingClientRect();
    s = o.left != o.right && t.left > (o.left + o.right) / 2 ? 1 : -1;
  }
  return n.docView.posFromDOM(r, i, s);
}
function mh(n, e, t, r) {
  let i = -1;
  for (let s = e, o = !1; s != n.dom;) {
    let l = n.docView.nearestDesc(s, !0),
      a;
    if (!l) return null;
    if (
      A(l.dom) &&
      ((l.node.isBlock && l.parent) || !l.contentDOM) &&
      ((a = l.dom.getBoundingClientRect()).width || a.height) &&
      (l.node.isBlock &&
        l.parent &&
        !/^T(R|BODY|HEAD|FOOT)$/.test(l.dom.nodeName) &&
        ((!o && a.left > r.left) || a.top > r.top
          ? (i = l.posBefore)
          : ((!o && a.right < r.left) || a.bottom < r.top) && (i = l.posAfter),
        (o = !0)),
      !l.contentDOM && i < 0 && !l.node.isText)
    )
      return (
        l.node.isBlock
          ? r.top < (a.top + a.bottom) / 2
          : r.left < (a.left + a.right) / 2
      )
        ? l.posBefore
        : l.posAfter;
    s = l.dom.parentNode;
  }
  return i > -1 ? i : n.docView.posFromDOM(e, t, -1);
}
function wc(n, e, t) {
  let r = n.childNodes.length;
  if (r && t.top < t.bottom)
    for (
      let i = Math.max(
          0,
          Math.min(
            r - 1,
            Math.floor((r * (e.top - t.top)) / (t.bottom - t.top)) - 2,
          ),
        ),
        s = i;
      ;
    ) {
      let o = n.childNodes[s];
      if (A(o)) {
        let l = o.getClientRects();
        for (let a = 0; a < l.length; a++) {
          let c = l[a];
          if (Hs(e, c)) return wc(o, e, c);
        }
      }
      if ((s = (s + 1) % r) == i) break;
    }
  return n;
}
function gh(n, e) {
  let t = n.dom.ownerDocument,
    r,
    i = 0,
    s = sh(t, e.left, e.top);
  s && ({ node: r, offset: i } = s);
  let o = (n.root.elementFromPoint ? n.root : t).elementFromPoint(
      e.left,
      e.top,
    ),
    l;
  if (!o || !n.dom.contains(o)) {
    let c = n.dom.getBoundingClientRect();
    if (!Hs(e, c) || ((o = wc(n.dom, e, c)), !o)) return null;
  }
  if (le) for (let c = o; r && c; c = Xt(c)) c.draggable && (r = void 0);
  if (((o = hh(o, e)), r)) {
    if (
      be &&
      A(r) &&
      ((i = Math.min(i, r.childNodes.length)), i < r.childNodes.length)
    ) {
      let u = r.childNodes[i],
        d;
      u.nodeName == "IMG" &&
        (d = u.getBoundingClientRect()).right <= e.left &&
        d.bottom > e.top &&
        i++;
    }
    let c;
    (di &&
      i &&
      A(r) &&
      A((c = r.childNodes[i - 1])) &&
      c.contentEditable == "false" &&
      c.getBoundingClientRect().top >= e.top &&
      i--,
      r == n.dom &&
      i == r.childNodes.length - 1 &&
      A(r.lastChild) &&
      e.top > r.lastChild.getBoundingClientRect().bottom
        ? (l = n.state.doc.content.size)
        : (i == 0 || !A(r) || r.childNodes[i - 1].nodeName != "BR") &&
          (l = mh(n, r, i, e)));
  }
  l == null && (l = ph(n, o, e));
  let a = n.docView.nearestDesc(o, !0);
  return { pos: l, inside: a ? a.posAtStart - a.border : -1 };
}
function as(n) {
  return n.top < n.bottom || n.left < n.right;
}
function Ke(n, e) {
  let t = n.getClientRects();
  if (t.length) {
    let r = t[e < 0 ? 0 : t.length - 1];
    if (as(r)) return r;
  }
  return Array.prototype.find.call(t, as) || n.getBoundingClientRect();
}
const yh = /[\u0590-\u05f4\u0600-\u06ff\u0700-\u08ac]/;
function Cc(n, e, t) {
  let { node: r, offset: i, atom: s } = n.docView.domFromPos(e, t < 0 ? -1 : 1),
    o = di || be;
  if (J(r))
    if (o && (yh.test(r.nodeValue) || (t < 0 ? !i : i == r.nodeValue.length))) {
      let a = Ke($e(r, i, i), t);
      if (be && i && /\s/.test(r.nodeValue[i - 1]) && i < r.nodeValue.length) {
        let c = Ke($e(r, i - 1, i - 1), -1);
        if (c.top == a.top) {
          let u = Ke($e(r, i, i + 1), -1);
          if (u.top != a.top) return sn(u, u.left < c.left);
        }
      }
      return a;
    } else {
      let a = i,
        c = i,
        u = t < 0 ? 1 : -1;
      return (
        t < 0 && !i
          ? (c++, (u = -1))
          : t >= 0 && i == r.nodeValue.length
            ? (a--, (u = 1))
            : t < 0
              ? a--
              : c++,
        sn(Ke($e(r, a, c), u), u < 0)
      );
    }
  if (!n.state.doc.resolve(e - (s || 0)).parent.inlineContent) {
    if (s == null && i && (t < 0 || i == oe(r))) {
      let a = r.childNodes[i - 1];
      if (A(a)) return Ri(a.getBoundingClientRect(), !1);
    }
    if (s == null && i < oe(r)) {
      let a = r.childNodes[i];
      if (A(a)) return Ri(a.getBoundingClientRect(), !0);
    }
    return Ri(r.getBoundingClientRect(), t >= 0);
  }
  if (s == null && i && (t < 0 || i == oe(r))) {
    let a = r.childNodes[i - 1],
      c = J(a)
        ? $e(a, oe(a) - (o ? 0 : 1))
        : A(a) && (a.nodeName != "BR" || !a.nextSibling)
          ? a
          : null;
    if (c) return sn(Ke(c, 1), !1);
  }
  if (s == null && i < oe(r)) {
    let a = r.childNodes[i];
    for (; a.pmViewDesc && a.pmViewDesc.ignoreForCoords;) a = a.nextSibling;
    let c = a ? (J(a) ? $e(a, 0, o ? 0 : 1) : A(a) ? a : null) : null;
    if (c) return sn(Ke(c, -1), !0);
  }
  return sn(Ke(J(r) ? $e(r) : r, -t), t >= 0);
}
function sn(n, e) {
  if (n.width == 0) return n;
  let t = e ? n.left : n.right;
  return { top: n.top, bottom: n.bottom, left: t, right: t };
}
function Ri(n, e) {
  if (n.height == 0) return n;
  let t = e ? n.top : n.bottom;
  return { top: t, bottom: t, left: n.left, right: n.right };
}
function vc(n, e, t) {
  let r = n.state,
    i = n.root.activeElement;
  (r != e && n.updateState(e), i != n.dom && n.focus());
  try {
    return t();
  } finally {
    (r != e && n.updateState(r), i != n.dom && i && i.focus());
  }
}
function bh(n, e, t) {
  let r = e.selection,
    i = t == "up" ? r.$from : r.$to;
  return vc(n, e, () => {
    let { node: s } = n.docView.domFromPos(i.pos, t == "up" ? -1 : 1);
    for (;;) {
      let l = n.docView.nearestDesc(s, !0);
      if (!l) break;
      if (l.node.isBlock) {
        s = l.contentDOM || l.dom;
        break;
      }
      s = l.dom.parentNode;
    }
    let o = Cc(n, i.pos, 1);
    for (let l = s.firstChild; l; l = l.nextSibling) {
      let a;
      if (A(l)) a = l.getClientRects();
      else if (J(l)) a = $e(l, 0, l.nodeValue.length).getClientRects();
      else continue;
      for (let c = 0; c < a.length; c++) {
        let u = a[c];
        if (
          u.bottom > u.top + 1 &&
          (t == "up"
            ? o.top - u.top > (u.bottom - o.top) * 2
            : u.bottom - o.bottom > (o.bottom - u.top) * 2)
        )
          return !1;
      }
    }
    return !0;
  });
}
const kh = /[\u0590-\u08ac]/;
function Sh(n, e, t) {
  let { $head: r } = e.selection;
  if (!r.parent.isTextblock) return !1;
  let i = r.parentOffset,
    s = !i,
    o = i == r.parent.content.size,
    l = n.domSelection();
  return l
    ? !kh.test(r.parent.textContent) || !l.modify
      ? t == "left" || t == "backward"
        ? s
        : o
      : vc(n, e, () => {
          let {
              focusNode: a,
              focusOffset: c,
              anchorNode: u,
              anchorOffset: d,
            } = n.domSelectionRange(),
            f = l.caretBidiLevel;
          l.modify("move", t, "character");
          let h = r.depth ? n.docView.domAfterPos(r.before()) : n.dom,
            { focusNode: p, focusOffset: g } = n.domSelectionRange(),
            m = (p && !Nt(h, p)) || (a == p && c == g);
          try {
            (l.collapse(u, d),
              a && (a != u || c != d) && l.extend && l.extend(a, c));
          } catch {}
          return (f != null && (l.caretBidiLevel = f), m);
        })
    : r.pos == r.start() || r.pos == r.end();
}
let Qo = null,
  Zo = null,
  el = !1;
function xh(n, e, t) {
  return Qo == e && Zo == t
    ? el
    : ((Qo = e),
      (Zo = t),
      (el = t == "up" || t == "down" ? bh(n, e, t) : Sh(n, e, t)));
}
const ve = 0,
  tl = 1,
  mt = 2,
  Ee = 3;
class Vn {
  constructor(e, t, r, i) {
    ((this.parent = e),
      (this.children = t),
      (this.dom = r),
      (this.contentDOM = i),
      (this.dirty = ve),
      (r.pmViewDesc = this));
  }
  matchesWidget(e) {
    return !1;
  }
  matchesMark(e) {
    return !1;
  }
  matchesNode(e, t, r) {
    return !1;
  }
  matchesHack(e) {
    return !1;
  }
  parseRule(e) {
    return null;
  }
  stopEvent(e) {
    return !1;
  }
  get size() {
    let e = 0;
    for (let t = 0; t < this.children.length; t++) e += this.children[t].size;
    return e;
  }
  get border() {
    return 0;
  }
  destroy() {
    ((this.parent = void 0),
      this.dom.pmViewDesc == this && (this.dom.pmViewDesc = void 0));
    for (let e = 0; e < this.children.length; e++) this.children[e].destroy();
  }
  posBeforeChild(e) {
    for (let t = 0, r = this.posAtStart; ; t++) {
      let i = this.children[t];
      if (i == e) return r;
      r += i.size;
    }
  }
  get posBefore() {
    return this.parent.posBeforeChild(this);
  }
  get posAtStart() {
    return this.parent ? this.parent.posBeforeChild(this) + this.border : 0;
  }
  get posAfter() {
    return this.posBefore + this.size;
  }
  get posAtEnd() {
    return this.posAtStart + this.size - 2 * this.border;
  }
  localPosFromDOM(e, t, r) {
    if (this.contentDOM && Nt(this.contentDOM, e))
      if (r < 0) {
        let s, o;
        if (e == this.contentDOM) s = e.childNodes[t - 1];
        else {
          for (; e.parentNode != this.contentDOM;) e = e.parentNode;
          s = e.previousSibling;
        }
        for (; s && !((o = s.pmViewDesc) && o.parent == this);)
          s = s.previousSibling;
        return s ? this.posBeforeChild(o) + o.size : this.posAtStart;
      } else {
        let s, o;
        if (e == this.contentDOM) s = e.childNodes[t];
        else {
          for (; e.parentNode != this.contentDOM;) e = e.parentNode;
          s = e.nextSibling;
        }
        for (; s && !((o = s.pmViewDesc) && o.parent == this);)
          s = s.nextSibling;
        return s ? this.posBeforeChild(o) : this.posAtEnd;
      }
    let i;
    if (e == this.dom && this.contentDOM) i = t > te(this.contentDOM);
    else if (
      this.contentDOM &&
      this.contentDOM != this.dom &&
      this.dom.contains(this.contentDOM)
    ) {
      let s = e.compareDocumentPosition(this.contentDOM);
      s & 16
        ? (i =
            t >
            Array.from(e.childNodes).findIndex((o) =>
              o.contains(this.contentDOM),
            ))
        : (i = !(s & 4));
    } else if (this.dom.firstChild) {
      if (t == 0)
        for (let s = e; ; s = s.parentNode) {
          if (s == this.dom) {
            i = !1;
            break;
          }
          if (s.previousSibling) break;
        }
      if (i == null && t == e.childNodes.length)
        for (let s = e; ; s = s.parentNode) {
          if (s == this.dom) {
            i = !0;
            break;
          }
          if (s.nextSibling) break;
        }
    }
    return (i ?? r > 0) ? this.posAtEnd : this.posAtStart;
  }
  nearestDesc(e, t = !1) {
    for (let r = !0, i = e; i; i = i.parentNode) {
      let s = this.getDesc(i),
        o;
      if (s && (!t || s.node))
        if (r && (o = s.nodeDOM) && !(A(o) ? Nt(o, e) : o == e)) r = !1;
        else return s;
    }
  }
  getDesc(e) {
    let t = e.pmViewDesc;
    for (let r = t; r; r = r.parent) if (r == this) return t;
  }
  posFromDOM(e, t, r) {
    for (let i = e; i; i = i.parentNode) {
      let s = this.getDesc(i);
      if (s) return s.localPosFromDOM(e, t, r);
    }
    return -1;
  }
  descAt(e) {
    for (let t = 0, r = 0; t < this.children.length; t++) {
      let i = this.children[t],
        s = r + i.size;
      if (r == e && s != r) {
        for (; !i.border && i.children.length;)
          for (let o = 0; o < i.children.length; o++) {
            let l = i.children[o];
            if (l.size) {
              i = l;
              break;
            }
          }
        return i;
      }
      if (e < s) return i.descAt(e - r - i.border);
      r = s;
    }
  }
  domFromPos(e, t) {
    if (!this.contentDOM) return { node: this.dom, offset: 0, atom: e + 1 };
    let r = 0,
      i = 0;
    for (let s = 0; r < this.children.length; r++) {
      let o = this.children[r],
        l = s + o.size;
      if (l > e) {
        i = e - s;
        break;
      }
      s = l;
    }
    if (i) return this.children[r].domFromPos(i - this.children[r].border, t);
    for (; r > 0; r--) {
      let s = this.children[r - 1];
      if (s.size || !(s instanceof Ec || (s instanceof Mc && s.side >= 0)))
        break;
    }
    if (t <= 0) {
      let s,
        o = !0;
      for (
        ;
        (s = r ? this.children[r - 1] : null),
          !(!s || s.dom.parentNode == this.contentDOM);
        r--, o = !1
      );
      return s && t && o && !s.border && !s.domAtom
        ? s.domFromPos(s.size, t)
        : { node: this.contentDOM, offset: s ? te(s.dom) + 1 : 0 };
    } else {
      let s,
        o = !0;
      for (
        ;
        (s = r < this.children.length ? this.children[r] : null),
          !(!s || s.dom.parentNode == this.contentDOM);
        r++, o = !1
      );
      return s && o && !s.border && !s.domAtom
        ? s.domFromPos(0, t)
        : {
            node: this.contentDOM,
            offset: s ? te(s.dom) : this.contentDOM.childNodes.length,
          };
    }
  }
  parseRange(e, t, r = 0) {
    if (this.children.length == 0)
      return {
        node: this.contentDOM,
        from: e,
        to: t,
        fromOffset: 0,
        toOffset: this.contentDOM.childNodes.length,
      };
    let i = -1,
      s = -1;
    for (let o = r, l = 0; ; l++) {
      let a = this.children[l],
        c = o + a.size;
      if (i == -1 && e <= c) {
        let u = o + a.border;
        if (
          e >= u &&
          t <= c - a.border &&
          a.node &&
          a.contentDOM &&
          this.contentDOM.contains(a.contentDOM)
        )
          return a.parseRange(e, t, u);
        e = o;
        for (let d = l; d > 0; d--) {
          let f = this.children[d - 1];
          if (
            f.size &&
            f.dom.parentNode == this.contentDOM &&
            !f.emptyChildAt(1)
          ) {
            i = te(f.dom) + 1;
            break;
          }
          e -= f.size;
        }
        i == -1 && (i = 0);
      }
      if (i > -1 && (c > t || l == this.children.length - 1)) {
        t = c;
        for (let u = l + 1; u < this.children.length; u++) {
          let d = this.children[u];
          if (
            d.size &&
            d.dom.parentNode == this.contentDOM &&
            !d.emptyChildAt(-1)
          ) {
            s = te(d.dom);
            break;
          }
          t += d.size;
        }
        s == -1 && (s = this.contentDOM.childNodes.length);
        break;
      }
      o = c;
    }
    return {
      node: this.contentDOM,
      from: e,
      to: t,
      fromOffset: i,
      toOffset: s,
    };
  }
  emptyChildAt(e) {
    if (this.border || !this.contentDOM || !this.children.length) return !1;
    let t = this.children[e < 0 ? 0 : this.children.length - 1];
    return t.size == 0 || t.emptyChildAt(e);
  }
  domAfterPos(e) {
    let { node: t, offset: r } = this.domFromPos(e, 0);
    if (!A(t) || r == t.childNodes.length)
      throw new RangeError("No node after pos " + e);
    return t.childNodes[r];
  }
  setSelection(e, t, r, i = !1) {
    let s = Math.min(e, t),
      o = Math.max(e, t);
    for (let h = 0, p = 0; h < this.children.length; h++) {
      let g = this.children[h],
        m = p + g.size;
      if (s > p && o < m)
        return g.setSelection(e - p - g.border, t - p - g.border, r, i);
      p = m;
    }
    let l = this.domFromPos(e, e ? -1 : 1),
      a = t == e ? l : this.domFromPos(t, t ? -1 : 1),
      c = r.root.getSelection(),
      u = r.domSelectionRange(),
      d = !1;
    if ((be || le) && e == t) {
      let { node: h, offset: p } = l;
      if (J(h)) {
        if (
          ((d = !!(
            p &&
            h.nodeValue[p - 1] ==
              `
`
          )),
          d && p == h.nodeValue.length)
        )
          for (let g = h, m; g; g = g.parentNode) {
            if ((m = g.nextSibling)) {
              m.nodeName == "BR" &&
                (l = a = { node: m.parentNode, offset: te(m) + 1 });
              break;
            }
            let y = g.pmViewDesc;
            if (y && y.node && y.node.isBlock) break;
          }
      } else {
        let g = h.childNodes[p - 1];
        d = g && (g.nodeName == "BR" || g.contentEditable == "false");
      }
    }
    if (be && u.focusNode && u.focusNode != a.node && A(u.focusNode)) {
      let h = u.focusNode.childNodes[u.focusOffset];
      h && h.contentEditable == "false" && (i = !0);
    }
    if (
      !(i || (d && le)) &&
      Ot(l.node, l.offset, u.anchorNode, u.anchorOffset) &&
      Ot(a.node, a.offset, u.focusNode, u.focusOffset)
    )
      return;
    let f = !1;
    if ((c.extend || e == t) && !(d && be)) {
      c.collapse(l.node, l.offset);
      try {
        (e != t && c.extend(a.node, a.offset), (f = !0));
      } catch {}
    }
    if (!f) {
      if (e > t) {
        let p = l;
        ((l = a), (a = p));
      }
      let h = document.createRange();
      (h.setEnd(a.node, a.offset),
        h.setStart(l.node, l.offset),
        c.removeAllRanges(),
        c.addRange(h));
    }
  }
  ignoreMutation(e) {
    return !this.contentDOM && e.type != "selection";
  }
  get contentLost() {
    return (
      this.contentDOM &&
      this.contentDOM != this.dom &&
      !this.dom.contains(this.contentDOM)
    );
  }
  markDirty(e, t) {
    for (let r = 0, i = 0; i < this.children.length; i++) {
      let s = this.children[i],
        o = r + s.size;
      if (r == o ? e <= o && t >= r : e < o && t > r) {
        let l = r + s.border,
          a = o - s.border;
        if (e >= l && t <= a) {
          ((this.dirty = e == r || t == o ? mt : tl),
            e == l &&
            t == a &&
            (s.contentLost || s.dom.parentNode != this.contentDOM)
              ? (s.dirty = Ee)
              : s.markDirty(e - l, t - l));
          return;
        } else
          s.dirty =
            s.dom == s.contentDOM &&
            s.dom.parentNode == this.contentDOM &&
            !s.children.length
              ? mt
              : Ee;
      }
      r = o;
    }
    this.dirty = mt;
  }
  markParentsDirty() {
    let e = 1;
    for (let t = this.parent; t; t = t.parent, e++) {
      let r = e == 1 ? mt : tl;
      t.dirty < r && (t.dirty = r);
    }
  }
  get domAtom() {
    return !1;
  }
  get ignoreForCoords() {
    return !1;
  }
  get ignoreForSelection() {
    return !1;
  }
  isText(e) {
    return !1;
  }
}
class Mc extends Vn {
  constructor(e, t, r, i) {
    let s,
      o = t.type.toDOM;
    if (
      (typeof o == "function" &&
        (o = o(r, () => {
          if (!s) return i;
          if (s.parent) return s.parent.posBeforeChild(s);
        })),
      !t.type.spec.raw)
    ) {
      let l = A(o) ? o : document.createElement("span");
      (l != o && (l.appendChild(o), (o = l)),
        l.hasAttribute("contenteditable") || (l.contentEditable = "false"),
        l.classList.add("ProseMirror-widget"));
    }
    (super(e, [], o, null), (this.widget = t), (this.widget = t), (s = this));
  }
  matchesWidget(e) {
    return this.dirty == ve && e.type.eq(this.widget.type);
  }
  parseRule() {
    return { ignore: !0 };
  }
  stopEvent(e) {
    let t = this.widget.spec.stopEvent;
    return t ? t(e) : !1;
  }
  ignoreMutation(e) {
    return e.type != "selection" || this.widget.spec.ignoreSelection;
  }
  destroy() {
    (this.widget.type.destroy(this.dom), super.destroy());
  }
  get domAtom() {
    return !0;
  }
  get ignoreForSelection() {
    return !!this.widget.type.spec.relaxedSide;
  }
  get side() {
    return this.widget.type.side;
  }
}
class wh extends Vn {
  constructor(e, t, r, i) {
    (super(e, [], t, null), (this.textDOM = r), (this.text = i));
  }
  get size() {
    return this.text.length;
  }
  localPosFromDOM(e, t) {
    return e != this.textDOM
      ? this.posAtStart + (t ? this.size : 0)
      : this.posAtStart + t;
  }
  domFromPos(e) {
    return { node: this.textDOM, offset: e };
  }
  ignoreMutation(e) {
    return e.type === "characterData" && e.target.nodeValue == e.oldValue;
  }
}
class nt extends Vn {
  constructor(e, t, r, i, s) {
    (super(e, [], r, i), (this.mark = t), (this.spec = s));
  }
  static create(e, t, r, i) {
    let s = i.nodeViews[t.type.name],
      o = s && s(t, i, r);
    return (
      (!o || !o.dom) &&
        (o = Rt.renderSpec(document, t.type.spec.toDOM(t, r), null, t.attrs)),
      new nt(e, t, o.dom, o.contentDOM || o.dom, o)
    );
  }
  parseRule() {
    return this.dirty & Ee || this.mark.type.spec.reparseInView
      ? null
      : {
          mark: this.mark.type.name,
          attrs: this.mark.attrs,
          contentElement: this.contentDOM,
        };
  }
  matchesMark(e) {
    return this.dirty != Ee && this.mark.eq(e);
  }
  markDirty(e, t) {
    if ((super.markDirty(e, t), this.dirty != ve)) {
      let r = this.parent;
      for (; !r.node;) r = r.parent;
      (r.dirty < this.dirty && (r.dirty = this.dirty), (this.dirty = ve));
    }
  }
  slice(e, t, r) {
    let i = nt.create(this.parent, this.mark, !0, r),
      s = this.children,
      o = this.size;
    (t < o && (s = us(s, t, o, r)), e > 0 && (s = us(s, 0, e, r)));
    for (let l = 0; l < s.length; l++) s[l].parent = i;
    return ((i.children = s), i);
  }
  ignoreMutation(e) {
    return this.spec.ignoreMutation
      ? this.spec.ignoreMutation(e)
      : super.ignoreMutation(e);
  }
  destroy() {
    (this.spec.destroy && this.spec.destroy(), super.destroy());
  }
}
class rt extends Vn {
  constructor(e, t, r, i, s, o, l) {
    (super(e, [], s, o),
      (this.node = t),
      (this.outerDeco = r),
      (this.innerDeco = i),
      (this.nodeDOM = l));
  }
  static create(e, t, r, i, s, o) {
    let l = s.nodeViews[t.type.name],
      a,
      c =
        l &&
        l(
          t,
          s,
          () => {
            if (!a) return o;
            if (a.parent) return a.parent.posBeforeChild(a);
          },
          r,
          i,
        ),
      u = c && c.dom,
      d = c && c.contentDOM;
    if (t.isText) {
      if (!u) u = document.createTextNode(t.text);
      else if (!J(u))
        throw new RangeError("Text must be rendered as a DOM text node");
    } else
      u ||
        ({ dom: u, contentDOM: d } = Rt.renderSpec(
          document,
          t.type.spec.toDOM(t),
          null,
          t.attrs,
        ));
    !d &&
      !t.isText &&
      u.nodeName != "BR" &&
      (u.hasAttribute("contenteditable") || (u.contentEditable = "false"),
      t.type.spec.draggable && (u.draggable = !0));
    let f = u;
    return (
      (u = Oc(u, r, t)),
      c
        ? (a = new Ch(e, t, r, i, u, d || null, f, c))
        : t.isText
          ? new fi(e, t, r, i, u, f)
          : new rt(e, t, r, i, u, d || null, f)
    );
  }
  parseRule(e) {
    if (this.node.type.spec.reparseInView) return null;
    let t = { node: this.node.type.name, attrs: this.node.attrs };
    if (
      (this.node.type.whitespace == "pre" && (t.preserveWhitespace = "full"),
      !this.contentDOM)
    )
      t.getContent = () => this.node.content;
    else if (!this.contentLost) t.contentElement = this.contentDOM;
    else {
      for (let r = this.children.length - 1; r >= 0; r--) {
        let i = this.children[r];
        if (this.dom.contains(i.dom.parentNode)) {
          t.contentElement = i.dom.parentNode;
          break;
        }
      }
      if (!t.contentElement) {
        let r =
          e &&
          e.find(
            (i) => A(i) && e.indexOf(i.parentNode) < 0 && this.dom.contains(i),
          );
        r ? (t.contentElement = r) : (t.getContent = () => b.empty);
      }
    }
    return t;
  }
  matchesNode(e, t, r) {
    return (
      this.dirty == ve &&
      e.eq(this.node) &&
      wr(t, this.outerDeco) &&
      r.eq(this.innerDeco)
    );
  }
  get size() {
    return this.node.nodeSize;
  }
  get border() {
    return this.node.isLeaf ? 0 : 1;
  }
  updateChildren(e, t) {
    let r = this.node.inlineContent,
      i = t,
      s = e.composing ? this.localCompositionInfo(e, t) : null,
      o = s && s.pos > -1 ? s : null,
      l = s && s.pos < 0,
      a = new Mh(this, o && o.node, e),
      c = this.node.inlineContent,
      u = c && this.node.isBlock;
    (Ah(
      this.node,
      this.innerDeco,
      (d, f, h) => {
        (d.spec.marks
          ? a.syncToMarks(d.spec.marks, r, e, f)
          : d.type.side >= 0 &&
            !h &&
            a.syncToMarks(
              f == this.node.childCount ? z.none : this.node.child(f).marks,
              r,
              e,
              f,
            ),
          a.placeWidget(d, e, i));
      },
      (d, f, h, p) => {
        (a.syncToMarks(d.marks, r, e, p),
          u && d.isAtom && !d.isText && a.addHackNode("IMG", a.top));
        let g;
        (a.findNodeMatch(d, f, h, p) ||
          (l &&
            e.state.selection.from > i &&
            e.state.selection.to < i + d.nodeSize &&
            (g = a.findIndexWithChild(s.node)) > -1 &&
            a.updateNodeAt(d, f, h, g, e)) ||
          a.updateNextNode(d, f, h, e, p, i) ||
          a.addNode(d, f, h, e, i),
          (i += d.nodeSize),
          c && (u = d.isAtom && !d.isText));
      },
    ),
      a.syncToMarks([], r, e, 0),
      this.node.isTextblock && a.addTextblockHacks(),
      a.destroyRest(),
      (a.changed || this.dirty == mt) &&
        (o && this.protectLocalComposition(e, o),
        Tc(this.contentDOM, this.children, e),
        Qt && Oh(this.dom)));
  }
  localCompositionInfo(e, t) {
    let { from: r, to: i } = e.state.selection;
    if (
      !(e.state.selection instanceof T) ||
      r < t ||
      i > t + this.node.content.size
    )
      return null;
    let s = e.input.compositionNode;
    if (!s || !this.dom.contains(s.parentNode)) return null;
    if (this.node.inlineContent) {
      let o = s.nodeValue,
        l = Nh(this.node.content, o, r - t, i - t);
      return l < 0 ? null : { node: s, pos: l, text: o };
    } else return { node: s, pos: -1, text: "" };
  }
  protectLocalComposition(e, { node: t, pos: r, text: i }) {
    if (this.getDesc(t)) return;
    let s = t;
    for (; s.parentNode != this.contentDOM; s = s.parentNode) {
      for (; s.previousSibling;) s.parentNode.removeChild(s.previousSibling);
      for (; s.nextSibling;) s.parentNode.removeChild(s.nextSibling);
      s.pmViewDesc && (s.pmViewDesc = void 0);
    }
    let o = new wh(this, s, t, i);
    (e.input.compositionNodes.push(o),
      (this.children = us(this.children, r, r + i.length, e, o)));
  }
  update(e, t, r, i) {
    return this.dirty == Ee || !e.sameMarkup(this.node)
      ? !1
      : (this.updateInner(e, t, r, i), !0);
  }
  updateInner(e, t, r, i) {
    (this.updateOuterDeco(t),
      (this.node = e),
      (this.innerDeco = r),
      this.contentDOM && this.updateChildren(i, this.posAtStart),
      (this.dirty = ve));
  }
  updateOuterDeco(e) {
    if (wr(e, this.outerDeco)) return;
    let t = !A(this.nodeDOM),
      r = this.dom;
    ((this.dom = Ac(
      this.dom,
      this.nodeDOM,
      cs(this.outerDeco, this.node, t),
      cs(e, this.node, t),
    )),
      this.dom != r && ((r.pmViewDesc = void 0), (this.dom.pmViewDesc = this)),
      (this.outerDeco = e));
  }
  selectNode() {
    A(this.nodeDOM) &&
      (this.nodeDOM.classList.add("ProseMirror-selectednode"),
      (this.contentDOM || !this.node.type.spec.draggable) &&
        (this.nodeDOM.draggable = !0));
  }
  deselectNode() {
    A(this.nodeDOM) &&
      (this.nodeDOM.classList.remove("ProseMirror-selectednode"),
      (this.contentDOM || !this.node.type.spec.draggable) &&
        this.nodeDOM.removeAttribute("draggable"));
  }
  get domAtom() {
    return this.node.isAtom;
  }
}
function nl(n, e, t, r, i) {
  Oc(r, e, n);
  let s = new rt(void 0, n, e, t, r, r, r);
  return (s.contentDOM && s.updateChildren(i, 0), s);
}
class fi extends rt {
  constructor(e, t, r, i, s, o) {
    super(e, t, r, i, s, null, o);
  }
  parseRule() {
    let e = this.nodeDOM.parentNode;
    for (; e && e != this.dom && !e.pmIsDeco;) e = e.parentNode;
    return { skip: e || !0 };
  }
  update(e, t, r, i) {
    return this.dirty == Ee ||
      (this.dirty != ve && !this.inParent()) ||
      !e.sameMarkup(this.node)
      ? !1
      : (this.updateOuterDeco(t),
        (this.dirty != ve || e.text != this.node.text) &&
          e.text != this.nodeDOM.nodeValue &&
          ((this.nodeDOM.nodeValue = e.text),
          i.trackWrites == this.nodeDOM && (i.trackWrites = null)),
        (this.node = e),
        (this.dirty = ve),
        !0);
  }
  inParent() {
    let e = this.parent.contentDOM;
    for (let t = this.nodeDOM; t; t = t.parentNode) if (t == e) return !0;
    return !1;
  }
  domFromPos(e) {
    return { node: this.nodeDOM, offset: e };
  }
  localPosFromDOM(e, t, r) {
    return e == this.nodeDOM
      ? this.posAtStart + Math.min(t, this.node.text.length)
      : super.localPosFromDOM(e, t, r);
  }
  ignoreMutation(e) {
    return e.type != "characterData" && e.type != "selection";
  }
  slice(e, t, r) {
    let i = this.node.cut(e, t),
      s = document.createTextNode(i.text);
    return new fi(this.parent, i, this.outerDeco, this.innerDeco, s, s);
  }
  markDirty(e, t) {
    (super.markDirty(e, t),
      this.dom != this.nodeDOM &&
        (e == 0 || t == this.nodeDOM.nodeValue.length) &&
        (this.dirty = Ee));
  }
  get domAtom() {
    return !1;
  }
  isText(e) {
    return this.node.text == e;
  }
}
class Ec extends Vn {
  parseRule() {
    return { ignore: !0 };
  }
  matchesHack(e) {
    return this.dirty == ve && this.dom.nodeName == e;
  }
  get domAtom() {
    return !0;
  }
  get ignoreForCoords() {
    return this.dom.nodeName == "IMG";
  }
}
class Ch extends rt {
  constructor(e, t, r, i, s, o, l, a) {
    (super(e, t, r, i, s, o, l), (this.spec = a));
  }
  update(e, t, r, i) {
    if (this.dirty == Ee) return !1;
    if (this.spec.update && (this.node.type == e.type || this.spec.multiType)) {
      let s = this.spec.update(e, t, r);
      return (s && this.updateInner(e, t, r, i), s);
    } else return !this.contentDOM && !e.isLeaf ? !1 : super.update(e, t, r, i);
  }
  selectNode() {
    this.spec.selectNode ? this.spec.selectNode() : super.selectNode();
  }
  deselectNode() {
    this.spec.deselectNode ? this.spec.deselectNode() : super.deselectNode();
  }
  setSelection(e, t, r, i) {
    this.spec.setSelection
      ? this.spec.setSelection(e, t, r.root)
      : super.setSelection(e, t, r, i);
  }
  destroy() {
    (this.spec.destroy && this.spec.destroy(), super.destroy());
  }
  stopEvent(e) {
    return this.spec.stopEvent ? this.spec.stopEvent(e) : !1;
  }
  ignoreMutation(e) {
    return this.spec.ignoreMutation
      ? this.spec.ignoreMutation(e)
      : super.ignoreMutation(e);
  }
}
function Tc(n, e, t) {
  let r = n.firstChild,
    i = !1;
  for (let s = 0; s < e.length; s++) {
    let o = e[s],
      l = o.dom;
    if (l.parentNode == n) {
      for (; l != r;) ((r = rl(r)), (i = !0));
      r = r.nextSibling;
    } else ((i = !0), n.insertBefore(l, r));
    if (o instanceof nt) {
      let a = r ? r.previousSibling : n.lastChild;
      (Tc(o.contentDOM, o.children, t), (r = a ? a.nextSibling : n.firstChild));
    }
  }
  for (; r;) ((r = rl(r)), (i = !0));
  i && t.trackWrites == n && (t.trackWrites = null);
}
const yn = function (n) {
  n && (this.nodeName = n);
};
yn.prototype = Object.create(null);
const gt = [new yn()];
function cs(n, e, t) {
  if (n.length == 0) return gt;
  let r = t ? gt[0] : new yn(),
    i = [r];
  for (let s = 0; s < n.length; s++) {
    let o = n[s].type.attrs;
    if (o) {
      o.nodeName && i.push((r = new yn(o.nodeName)));
      for (let l in o) {
        let a = o[l];
        a != null &&
          (t &&
            i.length == 1 &&
            i.push((r = new yn(e.isInline ? "span" : "div"))),
          l == "class"
            ? (r.class = (r.class ? r.class + " " : "") + a)
            : l == "style"
              ? (r.style = (r.style ? r.style + ";" : "") + a)
              : l != "nodeName" && (r[l] = a));
      }
    }
  }
  return i;
}
function Ac(n, e, t, r) {
  if (t == gt && r == gt) return e;
  let i = e;
  for (let s = 0; s < r.length; s++) {
    let o = r[s],
      l = t[s];
    if (s) {
      let a;
      ((l &&
        l.nodeName == o.nodeName &&
        i != n &&
        (a = i.parentNode) &&
        a.nodeName.toLowerCase() == o.nodeName) ||
        ((a = document.createElement(o.nodeName)),
        (a.pmIsDeco = !0),
        a.appendChild(i),
        (l = gt[0])),
        (i = a));
    }
    vh(i, l || gt[0], o);
  }
  return i;
}
function vh(n, e, t) {
  for (let r in e)
    r != "class" &&
      r != "style" &&
      r != "nodeName" &&
      !(r in t) &&
      n.removeAttribute(r);
  for (let r in t)
    r != "class" &&
      r != "style" &&
      r != "nodeName" &&
      t[r] != e[r] &&
      n.setAttribute(r, t[r]);
  if (e.class != t.class) {
    let r = e.class ? e.class.split(" ").filter(Boolean) : [],
      i = t.class ? t.class.split(" ").filter(Boolean) : [];
    for (let s = 0; s < r.length; s++)
      i.indexOf(r[s]) == -1 && n.classList.remove(r[s]);
    for (let s = 0; s < i.length; s++)
      r.indexOf(i[s]) == -1 && n.classList.add(i[s]);
    n.classList.length == 0 && n.removeAttribute("class");
  }
  if (e.style != t.style) {
    if (e.style) {
      let r =
          /\s*([\w\-\xa1-\uffff]+)\s*:(?:"(?:\\.|[^"])*"|'(?:\\.|[^'])*'|\(.*?\)|[^;])*/g,
        i;
      for (; (i = r.exec(e.style));) n.style.removeProperty(i[1]);
    }
    t.style && (n.style.cssText += t.style);
  }
}
function Oc(n, e, t) {
  return Ac(n, n, gt, cs(e, t, !A(n)));
}
function wr(n, e) {
  if (n.length != e.length) return !1;
  for (let t = 0; t < n.length; t++) if (!n[t].type.eq(e[t].type)) return !1;
  return !0;
}
function rl(n) {
  let e = n.nextSibling;
  return (n.parentNode.removeChild(n), e);
}
class Mh {
  constructor(e, t, r) {
    ((this.lock = t),
      (this.view = r),
      (this.index = 0),
      (this.stack = []),
      (this.changed = !1),
      (this.top = e),
      (this.preMatch = Eh(e.node.content, e)));
  }
  destroyBetween(e, t) {
    if (e != t) {
      for (let r = e; r < t; r++) this.top.children[r].destroy();
      (this.top.children.splice(e, t - e), (this.changed = !0));
    }
  }
  destroyRest() {
    this.destroyBetween(this.index, this.top.children.length);
  }
  syncToMarks(e, t, r, i) {
    let s = 0,
      o = this.stack.length >> 1,
      l = Math.min(o, e.length);
    for (
      ;
      s < l &&
      (s == o - 1 ? this.top : this.stack[(s + 1) << 1]).matchesMark(e[s]) &&
      e[s].type.spec.spanning !== !1;
    )
      s++;
    for (; s < o;)
      (this.destroyRest(),
        (this.top.dirty = ve),
        (this.index = this.stack.pop()),
        (this.top = this.stack.pop()),
        o--);
    for (; o < e.length;) {
      this.stack.push(this.top, this.index + 1);
      let a = -1,
        c = this.top.children.length;
      i < this.preMatch.index && (c = Math.min(this.index + 3, c));
      for (let u = this.index; u < c; u++) {
        let d = this.top.children[u];
        if (d.matchesMark(e[o]) && !this.isLocked(d.dom)) {
          a = u;
          break;
        }
      }
      if (a < 0 && this.index < this.top.children.length) {
        let u = this.top.children[this.index];
        u instanceof nt &&
          u.dirty != Ee &&
          u.mark.type == e[o].type &&
          u.spec.update &&
          !this.isLocked(u.dom) &&
          u.spec.update(e[o]) &&
          ((u.mark = e[o]), (a = this.index), (this.changed = !0));
      }
      if (a > -1)
        (a > this.index &&
          ((this.changed = !0), this.destroyBetween(this.index, a)),
          (this.top = this.top.children[this.index]));
      else {
        let u = nt.create(this.top, e[o], t, r);
        (this.top.children.splice(this.index, 0, u),
          (this.top = u),
          (this.changed = !0));
      }
      ((this.index = 0), o++);
    }
  }
  findNodeMatch(e, t, r, i) {
    let s = -1,
      o;
    if (
      i >= this.preMatch.index &&
      (o = this.preMatch.matches[i - this.preMatch.index]).parent == this.top &&
      o.matchesNode(e, t, r)
    )
      s = this.top.children.indexOf(o, this.index);
    else
      for (
        let l = this.index, a = Math.min(this.top.children.length, l + 5);
        l < a;
        l++
      ) {
        let c = this.top.children[l];
        if (c.matchesNode(e, t, r) && !this.preMatch.matched.has(c)) {
          s = l;
          break;
        }
      }
    return s < 0 ? !1 : (this.destroyBetween(this.index, s), this.index++, !0);
  }
  updateNodeAt(e, t, r, i, s) {
    let o = this.top.children[i];
    return (
      o.dirty == Ee && o.dom == o.contentDOM && (o.dirty = mt),
      o.update(e, t, r, s)
        ? (this.destroyBetween(this.index, i), this.index++, !0)
        : !1
    );
  }
  findIndexWithChild(e) {
    for (;;) {
      let t = e.parentNode;
      if (!t) return -1;
      if (t == this.top.contentDOM) {
        let r = e.pmViewDesc;
        if (r) {
          for (let i = this.index; i < this.top.children.length; i++)
            if (this.top.children[i] == r) return i;
        }
        return -1;
      }
      e = t;
    }
  }
  updateNextNode(e, t, r, i, s, o) {
    for (let l = this.index; l < this.top.children.length; l++) {
      let a = this.top.children[l];
      if (a instanceof rt) {
        let c = this.preMatch.matched.get(a);
        if (c != null && c != s) return !1;
        let u = a.dom,
          d,
          f =
            this.isLocked(u) &&
            !(
              e.isText &&
              a.node &&
              a.node.isText &&
              a.nodeDOM.nodeValue == e.text &&
              a.dirty != Ee &&
              wr(t, a.outerDeco)
            );
        if (!f && a.update(e, t, r, i))
          return (
            this.destroyBetween(this.index, l),
            a.dom != u && (this.changed = !0),
            this.index++,
            !0
          );
        if (!f && (d = this.recreateWrapper(a, e, t, r, i, o)))
          return (
            this.destroyBetween(this.index, l),
            (this.top.children[this.index] = d),
            d.contentDOM &&
              ((d.dirty = mt), d.updateChildren(i, o + 1), (d.dirty = ve)),
            (this.changed = !0),
            this.index++,
            !0
          );
        break;
      }
    }
    return !1;
  }
  recreateWrapper(e, t, r, i, s, o) {
    if (
      e.dirty ||
      t.isAtom ||
      !e.children.length ||
      !e.node.content.eq(t.content) ||
      !wr(r, e.outerDeco) ||
      !i.eq(e.innerDeco)
    )
      return null;
    let l = rt.create(this.top, t, r, i, s, o);
    if (l.contentDOM) {
      ((l.children = e.children), (e.children = []));
      for (let a of l.children) a.parent = l;
    }
    return (e.destroy(), l);
  }
  addNode(e, t, r, i, s) {
    let o = rt.create(this.top, e, t, r, i, s);
    (o.contentDOM && o.updateChildren(i, s + 1),
      this.top.children.splice(this.index++, 0, o),
      (this.changed = !0));
  }
  placeWidget(e, t, r) {
    let i =
      this.index < this.top.children.length
        ? this.top.children[this.index]
        : null;
    if (
      i &&
      i.matchesWidget(e) &&
      (e == i.widget || !i.widget.type.toDOM.parentNode)
    )
      this.index++;
    else {
      let s = new Mc(this.top, e, t, r);
      (this.top.children.splice(this.index++, 0, s), (this.changed = !0));
    }
  }
  addTextblockHacks() {
    let e = this.top.children[this.index - 1],
      t = this.top;
    for (; e instanceof nt;) ((t = e), (e = t.children[t.children.length - 1]));
    (!e ||
      !(e instanceof fi) ||
      /\n$/.test(e.node.text) ||
      (this.view.requiresGeckoHackNode && /\s$/.test(e.node.text))) &&
      ((le || ie) &&
        e &&
        e.dom.contentEditable == "false" &&
        this.addHackNode("IMG", t),
      this.addHackNode("BR", this.top));
  }
  addHackNode(e, t) {
    if (
      t == this.top &&
      this.index < t.children.length &&
      t.children[this.index].matchesHack(e)
    )
      this.index++;
    else {
      let r = document.createElement(e);
      (e == "IMG" && ((r.className = "ProseMirror-separator"), (r.alt = "")),
        e == "BR" && (r.className = "ProseMirror-trailingBreak"));
      let i = new Ec(this.top, [], r, null);
      (t != this.top
        ? t.children.push(i)
        : t.children.splice(this.index++, 0, i),
        (this.changed = !0));
    }
  }
  isLocked(e) {
    return (
      this.lock &&
      (e == this.lock || (A(e) && e.contains(this.lock.parentNode)))
    );
  }
}
function Eh(n, e) {
  let t = e,
    r = t.children.length,
    i = n.childCount,
    s = new Map(),
    o = [];
  e: for (; i > 0;) {
    let l;
    for (;;)
      if (r) {
        let c = t.children[r - 1];
        if (c instanceof nt) ((t = c), (r = c.children.length));
        else {
          ((l = c), r--);
          break;
        }
      } else {
        if (t == e) break e;
        ((r = t.parent.children.indexOf(t)), (t = t.parent));
      }
    let a = l.node;
    if (a) {
      if (a != n.child(i - 1)) break;
      (--i, s.set(l, i), o.push(l));
    }
  }
  return { index: i, matched: s, matches: o.reverse() };
}
function Th(n, e) {
  return n.type.side - e.type.side;
}
function Ah(n, e, t, r) {
  let i = e.locals(n),
    s = 0;
  if (i.length == 0) {
    for (let c = 0; c < n.childCount; c++) {
      let u = n.child(c);
      (r(u, i, e.forChild(s, u), c), (s += u.nodeSize));
    }
    return;
  }
  let o = 0,
    l = [],
    a = null;
  for (let c = 0; ;) {
    let u, d;
    for (; o < i.length && i[o].to == s;) {
      let m = i[o++];
      m.widget && (u ? (d || (d = [u])).push(m) : (u = m));
    }
    if (u)
      if (d) {
        d.sort(Th);
        for (let m = 0; m < d.length; m++) t(d[m], c, !!a);
      } else t(u, c, !!a);
    let f, h;
    if (a) ((h = -1), (f = a), (a = null));
    else if (c < n.childCount) ((h = c), (f = n.child(c++)));
    else break;
    for (let m = 0; m < l.length; m++) l[m].to <= s && l.splice(m--, 1);
    for (; o < i.length && i[o].from <= s && i[o].to > s;) l.push(i[o++]);
    let p = s + f.nodeSize;
    if (f.isText) {
      let m = p;
      o < i.length && i[o].from < m && (m = i[o].from);
      for (let y = 0; y < l.length; y++) l[y].to < m && (m = l[y].to);
      m < p && ((a = f.cut(m - s)), (f = f.cut(0, m - s)), (p = m), (h = -1));
    } else for (; o < i.length && i[o].to < p;) o++;
    let g = f.isInline && !f.isLeaf ? l.filter((m) => !m.inline) : l.slice();
    (r(f, g, e.forChild(s, f), h), (s = p));
  }
}
function Oh(n) {
  if (n.nodeName == "UL" || n.nodeName == "OL") {
    let e = n.style.cssText;
    ((n.style.cssText = e + "; list-style: square !important"),
      window.getComputedStyle(n).listStyle,
      (n.style.cssText = e));
  }
}
function Nh(n, e, t, r) {
  for (let i = 0, s = 0; i < n.childCount && s <= r;) {
    let o = n.child(i++),
      l = s;
    if (((s += o.nodeSize), !o.isText)) continue;
    let a = o.text;
    for (; i < n.childCount;) {
      let c = n.child(i++);
      if (((s += c.nodeSize), !c.isText)) break;
      a += c.text;
    }
    if (s >= t) {
      if (s >= r && a.slice(r - e.length - l, r - l) == e) return r - e.length;
      let c = l < r ? a.lastIndexOf(e, r - l - 1) : -1;
      if (c >= 0 && c + e.length + l >= t) return l + c;
      if (
        t == r &&
        a.length >= r + e.length - l &&
        a.slice(r - l, r - l + e.length) == e
      )
        return r;
    }
  }
  return -1;
}
function us(n, e, t, r, i) {
  let s = [];
  for (let o = 0, l = 0; o < n.length; o++) {
    let a = n[o],
      c = l,
      u = (l += a.size);
    c >= t || u <= e
      ? s.push(a)
      : (c < e && s.push(a.slice(0, e - c, r)),
        i && (s.push(i), (i = void 0)),
        u > t && s.push(a.slice(t - c, a.size, r)));
  }
  return s;
}
function _s(n, e = null) {
  let t = n.domSelectionRange(),
    r = n.state.doc;
  if (!t.focusNode) return null;
  let i = n.docView.nearestDesc(t.focusNode),
    s = i && i.size == 0,
    o = n.docView.posFromDOM(t.focusNode, t.focusOffset, 1);
  if (o < 0) return null;
  let l = r.resolve(o),
    a,
    c;
  if (ui(t)) {
    for (a = o; i && !i.node;) i = i.parent;
    if (
      i &&
      i.node.isAtom &&
      O.isSelectable(i.node) &&
      i.parent &&
      !(i.node.isInline && nh(t.focusNode, t.focusOffset, i.dom))
    ) {
      let d = i.posBefore;
      c = new O(o == d ? l : r.resolve(d));
    } else if (
      be &&
      e == "key" &&
      o > n.state.selection.to &&
      A(t.focusNode) &&
      t.focusOffset == t.focusNode.childNodes.length &&
      i &&
      i.posAtStart > n.state.selection.to
    )
      for (let d = t.focusNode; ; d = d.parentNode) {
        if (getComputedStyle(d).overflow != "visible") {
          c = N.findFrom(r.resolve(i.posAtStart), 1);
          break;
        }
        if (d == i.dom || d.nextSibling || !d.parentNode || !A(d.parentNode))
          break;
      }
  } else {
    if (
      t instanceof n.dom.ownerDocument.defaultView.Selection &&
      t.rangeCount > 1
    ) {
      let d = o,
        f = o;
      for (let h = 0; h < t.rangeCount; h++) {
        let p = t.getRangeAt(h);
        ((d = Math.min(
          d,
          n.docView.posFromDOM(p.startContainer, p.startOffset, 1),
        )),
          (f = Math.max(
            f,
            n.docView.posFromDOM(p.endContainer, p.endOffset, -1),
          )));
      }
      if (d < 0) return null;
      (([a, o] = f == n.state.selection.anchor ? [f, d] : [d, f]),
        (l = r.resolve(o)));
    } else a = n.docView.posFromDOM(t.anchorNode, t.anchorOffset, 1);
    if (a < 0) return null;
  }
  let u = r.resolve(a);
  if (!c) {
    let d = e == "pointer" || (n.state.selection.head < l.pos && !s) ? 1 : -1;
    c = Ws(n, u, l, d);
  }
  return c;
}
function Nc(n) {
  return n.editable
    ? n.hasFocus()
    : Rc(n) && document.activeElement && document.activeElement.contains(n.dom);
}
function _e(n, e = !1) {
  let t = n.state.selection;
  if ((Dc(n, t), !Nc(n))) return;
  let r = n.input.mouseDown;
  if (!e && ie && r) {
    let i = n.domSelectionRange(),
      s = n.domObserver.currentSelection;
    if (
      i.anchorNode &&
      s.anchorNode &&
      Ot(i.anchorNode, i.anchorOffset, s.anchorNode, s.anchorOffset) &&
      r.delaySelUpdate()
    ) {
      n.domObserver.setCurSelection();
      return;
    }
  }
  if ((n.domObserver.disconnectSelection(), n.cursorWrapper)) Rh(n);
  else {
    let { anchor: i, head: s } = t,
      o,
      l;
    (il &&
      !(t instanceof T) &&
      (t.$from.parent.inlineContent || (o = sl(n, t.from)),
      !t.empty && !t.$from.parent.inlineContent && (l = sl(n, t.to))),
      n.docView.setSelection(i, s, n, e),
      il && (o && ol(o), l && ol(l)),
      t.visible
        ? n.dom.classList.remove("ProseMirror-hideselection")
        : (n.dom.classList.add("ProseMirror-hideselection"),
          "onselectionchange" in document && Dh(n)));
  }
  (n.domObserver.setCurSelection(), n.domObserver.connectSelection());
}
const il = le || (ie && yc < 63);
function sl(n, e) {
  let { node: t, offset: r } = n.docView.domFromPos(e, 0),
    i = r < t.childNodes.length ? t.childNodes[r] : null,
    s = r ? t.childNodes[r - 1] : null;
  if (le && i && i.contentEditable == "false") return Ii(i);
  if (
    (!i || i.contentEditable == "false") &&
    (!s || s.contentEditable == "false")
  ) {
    if (i) return Ii(i);
    if (s) return Ii(s);
  }
}
function Ii(n) {
  return (
    (n.contentEditable = "true"),
    le && n.draggable && ((n.draggable = !1), (n.wasDraggable = !0)),
    n
  );
}
function ol(n) {
  ((n.contentEditable = "false"),
    n.wasDraggable && ((n.draggable = !0), (n.wasDraggable = null)));
}
function Dh(n) {
  let e = n.dom.ownerDocument;
  e.removeEventListener("selectionchange", n.input.hideSelectionGuard);
  let t = n.domSelectionRange(),
    r = t.anchorNode,
    i = t.anchorOffset;
  e.addEventListener(
    "selectionchange",
    (n.input.hideSelectionGuard = () => {
      (t.anchorNode != r || t.anchorOffset != i) &&
        (e.removeEventListener("selectionchange", n.input.hideSelectionGuard),
        setTimeout(() => {
          (!Nc(n) || n.state.selection.visible) &&
            n.dom.classList.remove("ProseMirror-hideselection");
        }, 20));
    }),
  );
}
function Rh(n) {
  let e = n.domSelection();
  if (!e) return;
  let t = n.cursorWrapper.dom,
    r = t.nodeName == "IMG";
  (r ? e.collapse(t.parentNode, te(t) + 1) : e.collapse(t, 0),
    !r &&
      !n.state.selection.visible &&
      me &&
      tt <= 11 &&
      ((t.disabled = !0), (t.disabled = !1)));
}
function Dc(n, e) {
  if (e instanceof O) {
    let t = n.docView.descAt(e.from);
    t != n.lastSelectedViewDesc &&
      (ll(n), t && t.selectNode(), (n.lastSelectedViewDesc = t));
  } else ll(n);
}
function ll(n) {
  n.lastSelectedViewDesc &&
    (n.lastSelectedViewDesc.parent && n.lastSelectedViewDesc.deselectNode(),
    (n.lastSelectedViewDesc = void 0));
}
function Ws(n, e, t, r) {
  return (
    n.someProp("createSelectionBetween", (i) => i(n, e, t)) ||
    T.between(e, t, r)
  );
}
function al(n) {
  return n.editable && !n.hasFocus() ? !1 : Rc(n);
}
function Rc(n) {
  let e = n.domSelectionRange();
  if (!e.anchorNode) return !1;
  try {
    return Nt(n.dom, e.anchorNode) && (n.editable || Nt(n.dom, e.focusNode));
  } catch {
    return !1;
  }
}
function Ih(n) {
  let e = n.docView.domFromPos(n.state.selection.anchor, 0),
    t = n.domSelectionRange();
  return Ot(e.node, e.offset, t.anchorNode, t.anchorOffset);
}
function ds(n, e) {
  let { $anchor: t, $head: r } = n.selection,
    i = e > 0 ? t.max(r) : t.min(r),
    s = i.parent.inlineContent
      ? i.depth
        ? n.doc.resolve(e > 0 ? i.after() : i.before())
        : null
      : i;
  return s && N.findFrom(s, e);
}
function Je(n, e) {
  return (n.dispatch(n.state.tr.setSelection(e).scrollIntoView()), !0);
}
function cl(n, e, t) {
  let r = n.state.selection;
  if (r instanceof T)
    if (t.indexOf("s") > -1) {
      let { $head: i } = r,
        s = i.textOffset ? null : e < 0 ? i.nodeBefore : i.nodeAfter;
      if (!s || s.isText || !s.isLeaf) return !1;
      let o = n.state.doc.resolve(i.pos + s.nodeSize * (e < 0 ? -1 : 1));
      return Je(n, new T(r.$anchor, o));
    } else if (r.empty) {
      if (n.endOfTextblock(e > 0 ? "forward" : "backward")) {
        let i = ds(n.state, e);
        return i && i instanceof O ? Je(n, i) : !1;
      } else if (!Ce || t.indexOf("m") < 0) {
        let i = r.$head,
          s = i.textOffset ? null : e < 0 ? i.nodeBefore : i.nodeAfter,
          o;
        if (!s || s.isText) return !1;
        let l = e < 0 ? i.pos - s.nodeSize : i.pos;
        return s.isAtom || ((o = n.docView.descAt(l)) && !o.contentDOM)
          ? O.isSelectable(s)
            ? Je(n, new O(e < 0 ? n.state.doc.resolve(i.pos - s.nodeSize) : i))
            : Je(n, new T(n.state.doc.resolve(e < 0 ? l : l + s.nodeSize)))
          : !1;
      }
    } else return !1;
  else {
    if (r instanceof O && r.node.isInline)
      return Je(n, new T(e > 0 ? r.$to : r.$from));
    {
      let i = ds(n.state, e);
      return i ? Je(n, i) : !1;
    }
  }
}
function bn(n, e) {
  let t = n.pmViewDesc;
  return t
    ? t.size == 0 && (e < 0 || n.nextSibling || n.nodeName != "BR")
    : A(n) && n.contentEditable == "false";
}
function Bt(n, e) {
  return e < 0 ? Lh(n) : Ph(n);
}
function Lh(n) {
  let e = n.domSelectionRange(),
    t = e.focusNode,
    r = e.focusOffset;
  if (!t) return;
  let i,
    s,
    o = !1;
  for (be && A(t) && r < oe(t) && bn(t.childNodes[r], -1) && (o = !0); ;)
    if (r > 0) {
      if (!A(t)) break;
      let l = t.childNodes[r - 1];
      if (bn(l, -1)) ((i = t), (s = --r));
      else if (J(l)) ((t = l), (r = t.nodeValue.length));
      else break;
    } else {
      if (Ic(t)) break;
      {
        let l = t.previousSibling;
        for (; l && bn(l, -1);)
          ((i = t.parentNode), (s = te(l)), (l = l.previousSibling));
        if (l) ((t = l), (r = oe(t)));
        else {
          if (((t = t.parentNode), t == n.dom)) break;
          r = 0;
        }
      }
    }
  o ? fs(n, t, r) : i && fs(n, i, s);
}
function Ph(n) {
  let e = n.domSelectionRange(),
    t = e.focusNode,
    r = e.focusOffset;
  if (!t) return;
  let i = oe(t),
    s,
    o;
  for (;;)
    if (r < i) {
      if (!A(t)) break;
      let l = t.childNodes[r];
      if (bn(l, 1)) ((s = t), (o = ++r));
      else break;
    } else {
      if (Ic(t)) break;
      {
        let l = t.nextSibling;
        for (; l && bn(l, 1);)
          ((s = l.parentNode), (o = te(l) + 1), (l = l.nextSibling));
        if (l) ((t = l), (r = 0), (i = oe(t)));
        else {
          if (((t = t.parentNode), t == n.dom)) break;
          r = i = 0;
        }
      }
    }
  s && fs(n, s, o);
}
function Ic(n) {
  let e = n.pmViewDesc;
  return e && e.node && e.node.isBlock;
}
function Bh(n, e) {
  for (; n && e == n.childNodes.length && !Fn(n);)
    ((e = te(n) + 1), (n = n.parentNode));
  for (; n && e < n.childNodes.length;) {
    let t = n.childNodes[e];
    if (J(t)) return t;
    if (A(t) && t.contentEditable == "false") break;
    ((n = t), (e = 0));
  }
}
function $h(n, e) {
  for (; n && !e && !Fn(n);) ((e = te(n)), (n = n.parentNode));
  for (; n && e;) {
    let t = n.childNodes[e - 1];
    if (J(t)) return t;
    if (A(t) && t.contentEditable == "false") break;
    ((n = t), (e = n.childNodes.length));
  }
}
function fs(n, e, t) {
  if (!J(e)) {
    let o, l;
    (l = Bh(e, t))
      ? ((e = l), (t = 0))
      : (o = $h(e, t)) && ((e = o), (t = o.nodeValue.length));
  }
  let r = n.domSelection(),
    i = n.domSelectionRange();
  if (!r) return;
  (ui(i)
    ? r.collapse(e, t)
    : r.extend && (r.collapse(i.anchorNode, i.anchorOffset), r.extend(e, t)),
    n.domObserver.setCurSelection());
  let { state: s } = n;
  setTimeout(() => {
    n.state == s && _e(n);
  }, 50);
}
function ul(n, e) {
  let t = n.state.doc.resolve(e);
  if (!(ie || bc) && t.parent.inlineContent) {
    let s = n.coordsAtPos(e);
    if (e > t.start()) {
      let o = n.coordsAtPos(e - 1),
        l = (o.top + o.bottom) / 2;
      if (l > s.top && l < s.bottom && Math.abs(o.left - s.left) > 1)
        return o.left < s.left ? "ltr" : "rtl";
    }
    if (e < t.end()) {
      let o = n.coordsAtPos(e + 1),
        l = (o.top + o.bottom) / 2;
      if (l > s.top && l < s.bottom && Math.abs(o.left - s.left) > 1)
        return o.left > s.left ? "ltr" : "rtl";
    }
  }
  let r = n.dom;
  for (let s = t.depth; s > 0; s--)
    if (t.node(s).isBlock) {
      r = n.nodeDOM(t.before(s)) || r;
      break;
    }
  return getComputedStyle(r).direction == "rtl" ? "rtl" : "ltr";
}
function dl(n, e, t) {
  let r = n.state.selection;
  if (
    (r instanceof T && !r.empty) ||
    t.indexOf("s") > -1 ||
    (Ce && t.indexOf("m") > -1)
  )
    return !1;
  let { $from: i, $to: s } = r;
  if (!i.parent.inlineContent || n.endOfTextblock(e < 0 ? "up" : "down")) {
    let o = ds(n.state, e);
    if (o && o instanceof O) return Je(n, o);
  }
  if (!i.parent.inlineContent) {
    let o = e < 0 ? i : s,
      l = r instanceof ye ? N.near(o, e) : N.findFrom(o, e);
    return l ? Je(n, l) : !1;
  }
  return !1;
}
function fl(n, e) {
  if (!(n.state.selection instanceof T)) return !0;
  let { $head: t, $anchor: r, empty: i } = n.state.selection;
  if (!t.sameParent(r)) return !0;
  if (!i) return !1;
  if (n.endOfTextblock(e > 0 ? "forward" : "backward")) return !0;
  let s = !t.textOffset && (e < 0 ? t.nodeBefore : t.nodeAfter);
  if (s && !s.isText) {
    let o = n.state.tr;
    return (
      e < 0
        ? o.delete(t.pos - s.nodeSize, t.pos)
        : o.delete(t.pos, t.pos + s.nodeSize),
      n.dispatch(o),
      !0
    );
  }
  return !1;
}
function hl(n, e, t) {
  (n.domObserver.stop(), (e.contentEditable = t), n.domObserver.start());
}
function zh(n) {
  if (!le || n.state.selection.$head.parentOffset > 0) return !1;
  let { focusNode: e, focusOffset: t } = n.domSelectionRange();
  if (
    e &&
    A(e) &&
    t == 0 &&
    e.firstChild &&
    A(e.firstChild) &&
    e.firstChild.contentEditable == "false"
  ) {
    let r = e.firstChild;
    (hl(n, r, "true"), setTimeout(() => hl(n, r, "false"), 20));
  }
  return !1;
}
function Fh(n) {
  let e = "";
  return (
    n.ctrlKey && (e += "c"),
    n.metaKey && (e += "m"),
    n.altKey && (e += "a"),
    n.shiftKey && (e += "s"),
    e
  );
}
function Vh(n, e) {
  let t = e.keyCode,
    r = Fh(e);
  if (t == 8 || (Ce && t == 72 && r == "c")) return fl(n, -1) || Bt(n, -1);
  if ((t == 46 && !e.shiftKey) || (Ce && t == 68 && r == "c"))
    return fl(n, 1) || Bt(n, 1);
  if (t == 13 || t == 27) return !0;
  if (t == 37 || (Ce && t == 66 && r == "c")) {
    let i = t == 37 ? (ul(n, n.state.selection.from) == "ltr" ? -1 : 1) : -1;
    return cl(n, i, r) || Bt(n, i);
  } else if (t == 39 || (Ce && t == 70 && r == "c")) {
    let i = t == 39 ? (ul(n, n.state.selection.from) == "ltr" ? 1 : -1) : 1;
    return cl(n, i, r) || Bt(n, i);
  } else {
    if (t == 38 || (Ce && t == 80 && r == "c"))
      return dl(n, -1, r) || Bt(n, -1);
    if (t == 40 || (Ce && t == 78 && r == "c"))
      return zh(n) || dl(n, 1, r) || Bt(n, 1);
    if (r == (Ce ? "m" : "c") && (t == 66 || t == 73 || t == 89 || t == 90))
      return !0;
  }
  return !1;
}
function qs(n, e) {
  n.someProp("transformCopied", (h) => {
    e = h(e, n);
  });
  let t = [],
    { content: r, openStart: i, openEnd: s } = e;
  for (; i > 1 && s > 1 && r.childCount == 1 && r.firstChild.childCount == 1;) {
    (i--, s--);
    let h = r.firstChild;
    (t.push(h.type.name, h.attrs != h.type.defaultAttrs ? h.attrs : null),
      (r = h.content));
  }
  let o = n.someProp("clipboardSerializer") || Rt.fromSchema(n.state.schema),
    l = Fc(),
    a = l.createElement("div");
  a.appendChild(o.serializeFragment(r, { document: l }));
  let c = a.firstChild,
    u,
    d = 0;
  for (; c && A(c) && (u = zc[c.nodeName.toLowerCase()]);) {
    for (let h = u.length - 1; h >= 0; h--) {
      let p = l.createElement(u[h]);
      for (; a.firstChild;) p.appendChild(a.firstChild);
      (a.appendChild(p), d++);
    }
    c = a.firstChild;
  }
  c &&
    A(c) &&
    c.setAttribute(
      "data-pm-slice",
      `${i} ${s}${d ? ` -${d}` : ""} ${JSON.stringify(t)}`,
    );
  let f =
    n.someProp("clipboardTextSerializer", (h) => h(e, n)) ||
    e.content.textBetween(
      0,
      e.content.size,
      `

`,
    );
  return { dom: a, text: f, slice: e };
}
function Lc(n, e, t, r, i) {
  let s = i.parent.type.spec.code,
    o,
    l;
  if (!t && !e) return null;
  let a = !!e && (r || s || !t);
  if (a) {
    if (
      (n.someProp("transformPastedText", (f) => {
        e = f(e, s || r, n);
      }),
      s)
    )
      return (
        (l = new C(
          b.from(
            n.state.schema.text(
              e.replace(
                /\r\n?/g,
                `
`,
              ),
            ),
          ),
          0,
          0,
        )),
        n.someProp("transformPasted", (f) => {
          l = f(l, n, !0);
        }),
        l
      );
    let d = n.someProp("clipboardTextParser", (f) => f(e, i, r, n));
    if (d) l = d;
    else {
      let f = i.marks(),
        { schema: h } = n.state,
        p = Rt.fromSchema(h);
      ((o = document.createElement("div")),
        e.split(/(?:\r\n?|\n)+/).forEach((g) => {
          let m = o.appendChild(document.createElement("p"));
          g && m.appendChild(p.serializeNode(h.text(g, f)));
        }));
    }
  } else
    (n.someProp("transformPastedHTML", (d) => {
      t = d(t, n);
    }),
      (o = Wh(t)),
      di && qh(o));
  let c = o && o.querySelector("[data-pm-slice]"),
    u =
      c &&
      /^(\d+) (\d+)(?: -(\d+))? (.*)/.exec(
        c.getAttribute("data-pm-slice") || "",
      );
  if (u && u[3])
    for (let d = +u[3]; d > 0; d--) {
      let f = o.firstChild;
      for (; f && !A(f);) f = f.nextSibling;
      if (!f) break;
      o = f;
    }
  if (
    (l ||
      (l = (
        n.someProp("clipboardParser") ||
        n.someProp("domParser") ||
        et.fromSchema(n.state.schema)
      ).parseSlice(o, {
        preserveWhitespace: !!(a || u),
        context: i,
        ruleFromNode(f) {
          return f.nodeName == "BR" &&
            !f.nextSibling &&
            f.parentNode &&
            !jh.test(f.parentNode.nodeName)
            ? { ignore: !0 }
            : null;
        },
      })),
    u)
  )
    l = Uh(pl(l, +u[1], +u[2]), u[4]);
  else if (((l = C.maxOpen(Hh(l.content, i), !0)), l.openStart || l.openEnd)) {
    let d = 0,
      f = 0;
    for (
      let h = l.content.firstChild;
      d < l.openStart && !h.type.spec.isolating;
      d++, h = h.firstChild
    );
    for (
      let h = l.content.lastChild;
      f < l.openEnd && !h.type.spec.isolating;
      f++, h = h.lastChild
    );
    l = pl(l, d, f);
  }
  return (
    n.someProp("transformPasted", (d) => {
      l = d(l, n, a);
    }),
    l
  );
}
const jh =
  /^(a|abbr|acronym|b|cite|code|del|em|i|ins|kbd|label|output|q|ruby|s|samp|span|strong|sub|sup|time|u|tt|var)$/i;
function Hh(n, e) {
  if (n.childCount < 2) return n;
  for (let t = e.depth; t >= 0; t--) {
    let i = e.node(t).contentMatchAt(e.index(t)),
      s,
      o = [];
    if (
      (n.forEach((l) => {
        if (!o) return;
        let a = i.findWrapping(l.type),
          c;
        if (!a) return (o = null);
        if ((c = o.length && s.length && Bc(a, s, l, o[o.length - 1], 0)))
          o[o.length - 1] = c;
        else {
          o.length && (o[o.length - 1] = $c(o[o.length - 1], s.length));
          let u = Pc(l, a);
          (o.push(u), (i = i.matchType(u.type)), (s = a));
        }
      }),
      o)
    )
      return b.from(o);
  }
  return n;
}
function Pc(n, e, t = 0) {
  for (let r = e.length - 1; r >= t; r--) n = e[r].create(null, b.from(n));
  return n;
}
function Bc(n, e, t, r, i) {
  if (i < n.length && i < e.length && n[i] == e[i]) {
    let s = Bc(n, e, t, r.lastChild, i + 1);
    if (s) return r.copy(r.content.replaceChild(r.childCount - 1, s));
    if (
      r
        .contentMatchAt(r.childCount)
        .matchType(i == n.length - 1 ? t.type : n[i + 1])
    )
      return r.copy(r.content.append(b.from(Pc(t, n, i + 1))));
  }
}
function $c(n, e) {
  if (e == 0) return n;
  let t = n.content.replaceChild(n.childCount - 1, $c(n.lastChild, e - 1)),
    r = n.contentMatchAt(n.childCount).fillBefore(b.empty, !0);
  return n.copy(t.append(r));
}
function hs(n, e, t, r, i, s) {
  let o = e < 0 ? n.firstChild : n.lastChild,
    l = o.content;
  return (
    n.childCount > 1 && (s = 0),
    i < r - 1 && (l = hs(l, e, t, r, i + 1, s)),
    i >= t &&
      (l =
        e < 0
          ? o
              .contentMatchAt(0)
              .fillBefore(l, s <= i)
              .append(l)
          : l.append(o.contentMatchAt(o.childCount).fillBefore(b.empty, !0))),
    n.replaceChild(e < 0 ? 0 : n.childCount - 1, o.copy(l))
  );
}
function pl(n, e, t) {
  return (
    e < n.openStart &&
      (n = new C(
        hs(n.content, -1, e, n.openStart, 0, n.openEnd),
        e,
        n.openEnd,
      )),
    t < n.openEnd &&
      (n = new C(hs(n.content, 1, t, n.openEnd, 0, 0), n.openStart, t)),
    n
  );
}
const zc = {
  thead: ["table"],
  tbody: ["table"],
  tfoot: ["table"],
  caption: ["table"],
  colgroup: ["table"],
  col: ["table", "colgroup"],
  tr: ["table", "tbody"],
  td: ["table", "tbody", "tr"],
  th: ["table", "tbody", "tr"],
};
function Fc() {
  return document.implementation.createHTMLDocument("title");
}
let on = null;
function _h(n) {
  let e = window.trustedTypes;
  if (!e) return n;
  if (!on) {
    if ((on = e.defaultPolicy))
      try {
        return on.createHTML(n);
      } catch {}
    on = e.createPolicy("ProseMirrorClipboard", { createHTML: (t) => t });
  }
  return on.createHTML(n);
}
function Wh(n) {
  let e = /^(\s*<meta [^>]*>)*/.exec(n);
  e && (n = n.slice(e[0].length));
  let t = Fc(),
    r = t.body,
    i = /<([a-z][^>\s]+)/i.exec(n),
    s;
  if (
    ((s = i && zc[i[1].toLowerCase()]) &&
      (n =
        s.map((o) => "<" + o + ">").join("") +
        n +
        s
          .map((o) => "</" + o + ">")
          .reverse()
          .join("")),
    (r.innerHTML = _h(n)),
    s)
  )
    for (let o = 0; o < s.length; o++) r = r.querySelector(s[o]) || r;
  for (let o = 0; o < t.styleSheets.length; o++) {
    let l = t.styleSheets[o];
    for (let a = 0; a < l.rules.length; a++) {
      let c = l.rules[a];
      if (c instanceof CSSStyleRule) {
        let u = r.querySelectorAll(c.selectorText);
        for (let d = 0; d < u.length; d++)
          u[d].style.cssText += c.style.cssText;
      }
    }
  }
  return r;
}
function qh(n) {
  let e = n.querySelectorAll(
    ie ? "span:not([class]):not([style])" : "span.Apple-converted-space",
  );
  for (let t = 0; t < e.length; t++) {
    let r = e[t];
    r.childNodes.length == 1 &&
      r.textContent == " " &&
      r.parentNode &&
      r.parentNode.replaceChild(n.ownerDocument.createTextNode(" "), r);
  }
}
function Uh(n, e) {
  if (!n.size) return n;
  let t = n.content.firstChild.type.schema,
    r;
  try {
    r = JSON.parse(e);
  } catch {
    return n;
  }
  let { content: i, openStart: s, openEnd: o } = n;
  for (let l = r.length - 2; l >= 0; l -= 2) {
    let a = t.nodes[r[l]];
    if (!a || a.hasRequiredAttrs()) break;
    try {
      i = b.from(a.create(r[l + 1], i));
    } catch {
      break;
    }
    (s++, o++);
  }
  return new C(i, s, o);
}
const de = {},
  fe = {},
  Kh = { touchstart: !0, touchmove: !0 };
class Jh {
  constructor() {
    ((this.shiftKey = !1),
      (this.mouseDown = null),
      (this.lastKeyCode = null),
      (this.lastKeyCodeTime = 0),
      (this.lastKeyDispatched = !1),
      (this.lastClick = { time: 0, x: 0, y: 0, type: "", button: 0 }),
      (this.lastSelectionOrigin = null),
      (this.lastSelectionTime = 0),
      (this.lastIOSEnter = 0),
      (this.lastIOSEnterFallbackTimeout = -1),
      (this.lastFocus = 0),
      (this.lastTouch = 0),
      (this.lastChromeDelete = 0),
      (this.composing = !1),
      (this.compositionNode = null),
      (this.composingTimeout = -1),
      (this.compositionNodes = []),
      (this.compositionEndedAt = -2e8),
      (this.compositionID = 1),
      (this.badSafariComposition = !1),
      (this.compositionPendingChanges = 0),
      (this.domChangeCount = 0),
      (this.eventHandlers = Object.create(null)),
      (this.hideSelectionGuard = null));
  }
}
function Gh(n) {
  for (let e in de) {
    let t = de[e];
    n.dom.addEventListener(
      e,
      (n.input.eventHandlers[e] = (r) => {
        Xh(n, r) && !Us(n, r) && (n.editable || !(r.type in fe)) && t(n, r);
      }),
      Kh[e] ? { passive: !0 } : void 0,
    );
  }
  (le && n.dom.addEventListener("input", () => null), ps(n));
}
function je(n, e) {
  ((n.input.lastSelectionOrigin = e), (n.input.lastSelectionTime = Date.now()));
}
function Yh(n) {
  (n.input.mouseDown && n.input.mouseDown.done(), n.domObserver.stop());
  for (let e in n.input.eventHandlers)
    n.dom.removeEventListener(e, n.input.eventHandlers[e]);
  (clearTimeout(n.input.composingTimeout),
    clearTimeout(n.input.lastIOSEnterFallbackTimeout));
}
function ps(n) {
  n.someProp("handleDOMEvents", (e) => {
    for (let t in e)
      n.input.eventHandlers[t] ||
        n.dom.addEventListener(t, (n.input.eventHandlers[t] = (r) => Us(n, r)));
  });
}
function Us(n, e) {
  return n.someProp("handleDOMEvents", (t) => {
    let r = t[e.type];
    return r ? r(n, e) || e.defaultPrevented : !1;
  });
}
function Xh(n, e) {
  if (!e.bubbles) return !0;
  if (e.defaultPrevented) return !1;
  for (let t = e.target; t != n.dom; t = t.parentNode)
    if (!t || t.nodeType == 11 || (t.pmViewDesc && t.pmViewDesc.stopEvent(e)))
      return !1;
  return !0;
}
function Qh(n, e) {
  !Us(n, e) &&
    de[e.type] &&
    (n.editable || !(e.type in fe)) &&
    de[e.type](n, e);
}
function Xe(n, e) {
  let { input: t } = n;
  return t.lastKeyDispatched || n.composing
    ? !1
    : ((t.lastKeyDispatched = !0),
      typeof e == "string" && (e = rh(e == "Backspace" ? 8 : 13, e)),
      n.someProp("handleKeyDown", (r) => r(n, e)));
}
fe.keydown = (n, e) => {
  let t = e;
  if (
    ((n.input.shiftKey = t.keyCode == 16 || t.shiftKey),
    !_c(n) &&
      ((n.input.lastKeyCode = t.keyCode),
      (n.input.lastKeyCodeTime = Date.now()),
      (n.input.lastKeyDispatched = !1),
      !(Ve && ie && t.keyCode == 13)))
  )
    if (
      (t.keyCode != 229 && n.domObserver.forceFlush(),
      Qt && t.keyCode == 13 && !t.ctrlKey && !t.altKey && !t.metaKey)
    ) {
      let r = Date.now();
      ((n.input.lastIOSEnter = r),
        (n.input.lastIOSEnterFallbackTimeout = setTimeout(() => {
          n.input.lastIOSEnter == r &&
            (Xe(n, "Enter"), (n.input.lastIOSEnter = 0));
        }, 200)));
    } else Xe(n, t) || Vh(n, t) ? t.preventDefault() : je(n, "key");
};
fe.keyup = (n, e) => {
  e.keyCode == 16 && (n.input.shiftKey = !1);
};
fe.keypress = (n, e) => {
  let t = e;
  if (_c(n) || !t.charCode || (t.ctrlKey && !t.altKey) || (Ce && t.metaKey))
    return;
  if (n.someProp("handleKeyPress", (i) => i(n, t))) {
    t.preventDefault();
    return;
  }
  let r = n.state.selection;
  if (!(r instanceof T) || !r.$from.sameParent(r.$to)) {
    let i = String.fromCharCode(t.charCode),
      s = () => n.state.tr.insertText(i).scrollIntoView();
    (!/[\r\n]/.test(i) &&
      !n.someProp("handleTextInput", (o) =>
        o(n, r.$from.pos, r.$to.pos, i, s),
      ) &&
      n.dispatch(s()),
      t.preventDefault());
  }
};
function jn(n) {
  return { left: n.clientX, top: n.clientY };
}
function Zh(n, e) {
  let t = e.x - n.clientX,
    r = e.y - n.clientY;
  return t * t + r * r < 100;
}
function Ks(n, e, t, r, i) {
  if (r == -1) return !1;
  let s = n.state.doc.resolve(r);
  for (let o = s.depth + 1; o > 0; o--)
    if (
      n.someProp(e, (l) =>
        o > s.depth
          ? l(n, t, s.nodeAfter, s.before(o), i, !0)
          : l(n, t, s.node(o), s.before(o), i, !1),
      )
    )
      return !0;
  return !1;
}
function Hn(n, e, t) {
  if ((n.focused || n.focus(), n.state.selection.eq(e))) return;
  let r = n.state.tr.setSelection(e);
  (r.setMeta("pointer", !0), n.dispatch(r));
}
function ep(n, e) {
  if (e == -1) return !1;
  let t = n.state.doc.resolve(e),
    r = t.nodeAfter;
  return r && r.isAtom && O.isSelectable(r) ? (Hn(n, new O(t)), !0) : !1;
}
function tp(n, e) {
  if (e == -1) return !1;
  let t = n.state.selection,
    r,
    i;
  t instanceof O && (r = t.node);
  let s = n.state.doc.resolve(e);
  for (let o = s.depth + 1; o > 0; o--) {
    let l = o > s.depth ? s.nodeAfter : s.node(o);
    if (O.isSelectable(l)) {
      r &&
      t.$from.depth > 0 &&
      o >= t.$from.depth &&
      s.before(t.$from.depth + 1) == t.$from.pos
        ? (i = s.before(t.$from.depth))
        : (i = s.before(o));
      break;
    }
  }
  return i != null ? (Hn(n, O.create(n.state.doc, i)), !0) : !1;
}
function np(n, e, t, r, i) {
  return (
    Ks(n, "handleClickOn", e, t, r) ||
    n.someProp("handleClick", (s) => s(n, e, r)) ||
    (i ? tp(n, t) : ep(n, t))
  );
}
function rp(n, e, t, r) {
  return (
    Ks(n, "handleDoubleClickOn", e, t, r) ||
    n.someProp("handleDoubleClick", (i) => i(n, e, r))
  );
}
function ip(n, e, t, r) {
  return (
    Ks(n, "handleTripleClickOn", e, t, r) ||
    n.someProp("handleTripleClick", (i) => i(n, e, r)) ||
    sp(n, t, r)
  );
}
function sp(n, e, t) {
  if (t.button != 0) return !1;
  let r = Vc(n, e, !0),
    i = n.state.doc;
  return r
    ? (Hn(n, r),
      r instanceof T && i.eq(n.state.doc) && (n.input.mouseDown = new lp(n, r)),
      !0)
    : !1;
}
function Vc(n, e, t) {
  let r = n.state.doc;
  if (e == -1) return r.inlineContent ? T.create(r, 0, r.content.size) : null;
  let i = r.resolve(e);
  for (let s = i.depth + 1; s > 0; s--) {
    let o = s > i.depth ? i.nodeAfter : i.node(s),
      l = i.before(s);
    if (o.inlineContent) return T.create(r, l + 1, l + 1 + o.content.size);
    if (t && O.isSelectable(o)) return O.create(r, l);
  }
  return null;
}
function Js(n) {
  return Cr(n);
}
const jc = Ce ? "metaKey" : "ctrlKey";
de.mousedown = (n, e) => {
  let t = e;
  n.input.shiftKey = t.shiftKey;
  let r = Js(n),
    i = Date.now(),
    s = "singleClick";
  (i - n.input.lastClick.time < 500 &&
    Zh(t, n.input.lastClick) &&
    !t[jc] &&
    n.input.lastClick.button == t.button &&
    (n.input.lastClick.type == "singleClick"
      ? (s = "doubleClick")
      : n.input.lastClick.type == "doubleClick" && (s = "tripleClick")),
    (n.input.lastClick = {
      time: i,
      x: t.clientX,
      y: t.clientY,
      type: s,
      button: t.button,
    }),
    n.input.mouseDown && n.input.mouseDown.done());
  let o = n.posAtCoords(jn(t));
  o &&
    (s == "singleClick"
      ? (n.input.mouseDown = new op(n, o, t, !!r))
      : (s == "doubleClick" ? rp : ip)(n, o.pos, o.inside, t)
        ? t.preventDefault()
        : je(n, "pointer"));
};
class Hc {
  constructor(e) {
    ((this.view = e),
      (this.mightDrag = null),
      e.root.addEventListener("mouseup", (this.up = this.up.bind(this))),
      e.root.addEventListener("mousemove", (this.move = this.move.bind(this))));
  }
  up(e) {
    this.done();
  }
  move(e) {
    e.buttons == 0 && this.done();
  }
  done() {
    (this.view.root.removeEventListener("mouseup", this.up),
      this.view.root.removeEventListener("mousemove", this.move),
      this.view.input.mouseDown == this && (this.view.input.mouseDown = null));
  }
  delaySelUpdate() {
    return !1;
  }
}
class op extends Hc {
  constructor(e, t, r, i) {
    (super(e),
      (this.pos = t),
      (this.event = r),
      (this.flushed = i),
      (this.delayedSelectionSync = !1),
      (this.startDoc = e.state.doc),
      (this.selectNode = !!r[jc]),
      (this.allowDefault = r.shiftKey));
    let s, o;
    if (t.inside > -1) ((s = e.state.doc.nodeAt(t.inside)), (o = t.inside));
    else {
      let u = e.state.doc.resolve(t.pos);
      ((s = u.parent), (o = u.depth ? u.before() : 0));
    }
    const l = i ? null : r.target,
      a = l ? e.docView.nearestDesc(l, !0) : null;
    this.target = a && A(a.nodeDOM) ? a.nodeDOM : null;
    let { selection: c } = e.state;
    (r.button == 0 &&
      ((s.type.spec.draggable && s.type.spec.selectable !== !1) ||
        (c instanceof O && c.from <= o && c.to > o)) &&
      (this.mightDrag = {
        node: s,
        pos: o,
        addAttr: !!(this.target && !this.target.draggable),
        setUneditable: !!(
          this.target &&
          be &&
          !this.target.hasAttribute("contentEditable")
        ),
      }),
      this.target &&
        this.mightDrag &&
        (this.mightDrag.addAttr || this.mightDrag.setUneditable) &&
        (this.view.domObserver.stop(),
        this.mightDrag.addAttr && (this.target.draggable = !0),
        this.mightDrag.setUneditable &&
          setTimeout(() => {
            this.view.input.mouseDown == this &&
              this.target.setAttribute("contentEditable", "false");
          }, 20),
        this.view.domObserver.start()),
      je(e, "pointer"));
  }
  done() {
    (super.done(),
      this.mightDrag &&
        this.target &&
        (this.view.domObserver.stop(),
        this.mightDrag.addAttr && this.target.removeAttribute("draggable"),
        this.mightDrag.setUneditable &&
          this.target.removeAttribute("contentEditable"),
        this.view.domObserver.start()),
      this.delayedSelectionSync &&
        setTimeout(() => {
          this.view.isDestroyed || _e(this.view);
        }));
  }
  up(e) {
    if ((this.done(), !this.view.dom.contains(e.target))) return;
    let t = this.pos;
    (this.view.state.doc != this.startDoc && (t = this.view.posAtCoords(jn(e))),
      this.updateAllowDefault(e),
      this.allowDefault || !t
        ? je(this.view, "pointer")
        : np(this.view, t.pos, t.inside, e, this.selectNode)
          ? e.preventDefault()
          : e.button == 0 &&
              (this.flushed ||
                (le && this.mightDrag && !this.mightDrag.node.isAtom) ||
                (ie &&
                  !this.view.state.selection.visible &&
                  Math.min(
                    Math.abs(t.pos - this.view.state.selection.from),
                    Math.abs(t.pos - this.view.state.selection.to),
                  ) <= 2))
            ? (Hn(this.view, N.near(this.view.state.doc.resolve(t.pos))),
              e.preventDefault())
            : je(this.view, "pointer"));
  }
  move(e) {
    (this.updateAllowDefault(e), je(this.view, "pointer"), super.move(e));
  }
  updateAllowDefault(e) {
    !this.allowDefault &&
      (Math.abs(this.event.x - e.clientX) > 4 ||
        Math.abs(this.event.y - e.clientY) > 4) &&
      (this.allowDefault = !0);
  }
  delaySelUpdate() {
    return this.allowDefault ? ((this.delayedSelectionSync = !0), !0) : !1;
  }
}
class lp extends Hc {
  constructor(e, t) {
    (super(e), (this.startSelection = t), (this.startDoc = e.state.doc));
  }
  move(e) {
    if (
      e.buttons == 0 ||
      this.view.isDestroyed ||
      !this.view.state.doc.eq(this.startDoc)
    ) {
      this.done();
      return;
    }
    (e.preventDefault(), je(this.view, "pointer"));
    let t = this.view.posAtCoords(jn(e)),
      r = t && Vc(this.view, t.inside, !1);
    if (!r) return;
    let { doc: i } = this.view.state,
      s = this.startSelection,
      [o, l] = r.from < s.from ? [s.to, r.from] : [s.from, r.to];
    Hn(this.view, T.create(i, o, l));
  }
}
de.touchstart = (n) => {
  ((n.input.lastTouch = Date.now()), Js(n), je(n, "pointer"));
};
de.touchmove = (n) => {
  ((n.input.lastTouch = Date.now()), je(n, "pointer"));
};
de.contextmenu = (n) => Js(n);
function _c(n, e) {
  return n.composing
    ? !0
    : le && Math.abs(Date.now() - n.input.compositionEndedAt) < 500
      ? ((n.input.compositionEndedAt = -2e8), !0)
      : !1;
}
const ap = Ve ? 5e3 : -1;
fe.compositionstart = fe.compositionupdate = (n) => {
  if (!n.composing) {
    n.domObserver.flush();
    let { state: e } = n,
      t = e.selection.$to;
    if (
      e.selection instanceof T &&
      e.selection.empty &&
      (e.storedMarks ||
        (!t.textOffset &&
          t.parentOffset &&
          t.nodeBefore.marks.some((r) => r.type.spec.inclusive === !1)) ||
        (ie && bc && cp(n)))
    )
      ((n.markCursor = n.state.storedMarks || t.marks()),
        Cr(n, !0),
        (n.markCursor = null));
    else if (
      (Cr(n, !e.selection.empty),
      be &&
        e.selection.empty &&
        t.parentOffset &&
        !t.textOffset &&
        t.nodeBefore.marks.length)
    ) {
      let r = n.domSelectionRange();
      for (let i = r.focusNode, s = r.focusOffset; i && A(i) && s != 0;) {
        let o = s < 0 ? i.lastChild : i.childNodes[s - 1];
        if (!o) break;
        if (J(o)) {
          let l = n.domSelection();
          l && l.collapse(o, o.nodeValue.length);
          break;
        } else ((i = o), (s = -1));
      }
    }
    n.input.composing = !0;
  }
  Wc(n, ap);
};
function cp(n) {
  let { focusNode: e, focusOffset: t } = n.domSelectionRange();
  if (!e || !A(e) || t >= e.childNodes.length) return !1;
  let r = e.childNodes[t];
  return A(r) && r.contentEditable == "false";
}
fe.compositionend = (n, e) => {
  n.composing &&
    ((n.input.composing = !1),
    (n.input.compositionEndedAt = Date.now()),
    (n.input.compositionPendingChanges = n.domObserver.pendingRecords().length
      ? n.input.compositionID
      : 0),
    (n.input.compositionNode = null),
    n.input.badSafariComposition
      ? n.domObserver.forceFlush()
      : n.input.compositionPendingChanges &&
        Promise.resolve().then(() => n.domObserver.flush()),
    n.input.compositionID++,
    Wc(n, 20));
};
function Wc(n, e) {
  (clearTimeout(n.input.composingTimeout),
    e > -1 && (n.input.composingTimeout = setTimeout(() => Cr(n), e)));
}
function qc(n) {
  for (
    n.composing &&
    ((n.input.composing = !1), (n.input.compositionEndedAt = Date.now()));
    n.input.compositionNodes.length > 0;
  )
    n.input.compositionNodes.pop().markParentsDirty();
}
function up(n) {
  let e = n.domSelectionRange();
  if (!e.focusNode) return null;
  let t = eh(e.focusNode, e.focusOffset),
    r = th(e.focusNode, e.focusOffset);
  if (t && r && t != r) {
    let i = r.pmViewDesc,
      s = n.domObserver.lastChangedTextNode;
    if (t == s || r == s) return s;
    if (!i || !i.isText(r.nodeValue)) return r;
    if (n.input.compositionNode == r) {
      let o = t.pmViewDesc;
      if (!(!o || !o.isText(t.nodeValue))) return r;
    }
  }
  return t || r;
}
function Cr(n, e = !1) {
  if (!(Ve && n.domObserver.flushingSoon >= 0)) {
    if (
      (n.domObserver.forceFlush(), qc(n), e || (n.docView && n.docView.dirty))
    ) {
      let t = _s(n),
        r = n.state.selection;
      return (
        t && !t.eq(r)
          ? n.dispatch(n.state.tr.setSelection(t))
          : (n.markCursor || e) &&
              !r.$from.node(r.$from.sharedDepth(r.to)).inlineContent
            ? n.dispatch(n.state.tr.deleteSelection())
            : n.updateState(n.state),
        !0
      );
    }
    return !1;
  }
}
function dp(n, e) {
  if (!n.dom.parentNode) return;
  let t = n.dom.parentNode.appendChild(document.createElement("div"));
  (t.appendChild(e),
    (t.style.cssText = "position: fixed; left: -10000px; top: 10px"));
  let r = getSelection(),
    i = document.createRange();
  (i.selectNodeContents(e),
    n.dom.blur(),
    r.removeAllRanges(),
    r.addRange(i),
    setTimeout(() => {
      (t.parentNode && t.parentNode.removeChild(t), n.focus());
    }, 50));
}
const Rn = (me && tt < 15) || (Qt && oh < 604);
de.copy = fe.cut = (n, e) => {
  let t = e,
    r = n.state.selection,
    i = t.type == "cut";
  if (r.empty) return;
  let s = Rn ? null : t.clipboardData,
    o = r.content(),
    { dom: l, text: a } = qs(n, o);
  (s
    ? (t.preventDefault(),
      s.clearData(),
      s.setData("text/html", l.innerHTML),
      s.setData("text/plain", a))
    : dp(n, l),
    i &&
      n.dispatch(
        n.state.tr.deleteSelection().scrollIntoView().setMeta("uiEvent", "cut"),
      ));
};
function fp(n) {
  return n.openStart == 0 && n.openEnd == 0 && n.content.childCount == 1
    ? n.content.firstChild
    : null;
}
function hp(n, e) {
  if (!n.dom.parentNode) return;
  let t = n.input.shiftKey || n.state.selection.$from.parent.type.spec.code,
    r = n.dom.parentNode.appendChild(
      document.createElement(t ? "textarea" : "div"),
    );
  (t || (r.contentEditable = "true"),
    (r.style.cssText = "position: fixed; left: -10000px; top: 10px"),
    r.focus());
  let i = n.input.shiftKey && n.input.lastKeyCode != 45;
  setTimeout(() => {
    (n.focus(),
      r.parentNode && r.parentNode.removeChild(r),
      t ? In(n, r.value, null, i, e) : In(n, r.textContent, r.innerHTML, i, e));
  }, 50);
}
function In(n, e, t, r, i) {
  let s = Lc(n, e, t, r, n.state.selection.$from);
  if (n.someProp("handlePaste", (a) => a(n, i, s || C.empty))) return !0;
  if (!s) return !1;
  let o = fp(s),
    l = o
      ? n.state.tr.replaceSelectionWith(o, r)
      : n.state.tr.replaceSelection(s);
  return (
    n.dispatch(
      l.scrollIntoView().setMeta("paste", !0).setMeta("uiEvent", "paste"),
    ),
    !0
  );
}
function Uc(n) {
  let e = n.getData("text/plain") || n.getData("Text");
  if (e) return e;
  let t = n.getData("text/uri-list");
  return t ? t.replace(/\r?\n/g, " ") : "";
}
fe.paste = (n, e) => {
  let t = e;
  if (n.composing && !Ve) return;
  let r = Rn ? null : t.clipboardData,
    i = n.input.shiftKey && n.input.lastKeyCode != 45;
  r && In(n, Uc(r), r.getData("text/html"), i, t)
    ? t.preventDefault()
    : hp(n, t);
};
class Kc {
  constructor(e, t, r) {
    ((this.slice = e), (this.move = t), (this.node = r));
  }
}
const pp = Ce ? "altKey" : "ctrlKey";
function Jc(n, e) {
  let t;
  return (
    n.someProp("dragCopies", (r) => {
      t = t || r(e);
    }),
    t != null ? !t : !e[pp]
  );
}
de.dragstart = (n, e) => {
  let t = e,
    r = n.input.mouseDown;
  if ((r && r.done(), !t.dataTransfer)) return;
  let i = n.state.selection,
    s = i.empty ? null : n.posAtCoords(jn(t)),
    o;
  if (!(s && s.pos >= i.from && s.pos <= (i instanceof O ? i.to - 1 : i.to))) {
    if (r && r.mightDrag) o = O.create(n.state.doc, r.mightDrag.pos);
    else if (t.target && A(t.target)) {
      let d = n.docView.nearestDesc(t.target, !0);
      d &&
        d.node.type.spec.draggable &&
        d != n.docView &&
        (o = O.create(n.state.doc, d.posBefore));
    }
  }
  let l = (o || n.state.selection).content(),
    { dom: a, text: c, slice: u } = qs(n, l);
  ((!t.dataTransfer.files.length || !ie || yc > 120) &&
    t.dataTransfer.clearData(),
    t.dataTransfer.setData(Rn ? "Text" : "text/html", a.innerHTML),
    (t.dataTransfer.effectAllowed = "copyMove"),
    Rn || t.dataTransfer.setData("text/plain", c),
    (n.dragging = new Kc(u, Jc(n, t), o)));
};
de.dragend = (n) => {
  let e = n.dragging;
  window.setTimeout(() => {
    n.dragging == e && (n.dragging = null);
  }, 50);
};
fe.dragover = fe.dragenter = (n, e) => e.preventDefault();
fe.drop = (n, e) => {
  try {
    mp(n, e, n.dragging);
  } finally {
    n.dragging = null;
  }
};
function mp(n, e, t) {
  if (!e.dataTransfer) return;
  let r = n.posAtCoords(jn(e));
  if (!r) return;
  let i = n.state.doc.resolve(r.pos),
    s = t && t.slice;
  s
    ? n.someProp("transformPasted", (h) => {
        s = h(s, n, !1);
      })
    : (s = Lc(
        n,
        Uc(e.dataTransfer),
        Rn ? null : e.dataTransfer.getData("text/html"),
        !1,
        i,
      ));
  let o = !!(t && Jc(n, e));
  if (n.someProp("handleDrop", (h) => h(n, e, s || C.empty, o))) {
    e.preventDefault();
    return;
  }
  if (!s) return;
  e.preventDefault();
  let l = s ? qa(n.state.doc, i.pos, s) : i.pos;
  l == null && (l = i.pos);
  let a = n.state.tr;
  if (o) {
    let { node: h } = t;
    h ? h.replace(a) : a.deleteSelection();
  }
  let c = a.mapping.map(l),
    u = s.openStart == 0 && s.openEnd == 0 && s.content.childCount == 1,
    d = a.doc;
  if (
    (u
      ? a.replaceRangeWith(c, c, s.content.firstChild)
      : a.replaceRange(c, c, s),
    a.doc.eq(d))
  )
    return;
  let f = a.doc.resolve(c);
  if (
    u &&
    O.isSelectable(s.content.firstChild) &&
    f.nodeAfter &&
    f.nodeAfter.sameMarkup(s.content.firstChild)
  )
    a.setSelection(new O(f));
  else {
    let h = a.mapping.map(l);
    (a.mapping.maps[a.mapping.maps.length - 1].forEach((p, g, m, y) => (h = y)),
      a.setSelection(Ws(n, f, a.doc.resolve(h))));
  }
  (n.focus(), n.dispatch(a.setMeta("uiEvent", "drop")));
}
de.focus = (n) => {
  if (((n.input.lastFocus = Date.now()), !n.focused)) {
    (n.domObserver.stop(),
      n.dom.classList.add("ProseMirror-focused"),
      n.domObserver.start(),
      (n.focused = !0));
    let e = n.domSelectionRange();
    if (!n.domObserver.currentSelection.eq(e)) {
      let { focusNode: t, focusOffset: r } = e;
      setTimeout(() => {
        let i = n.domSelectionRange();
        i.focusNode == t &&
          i.focusOffset == r &&
          n.docView &&
          n.hasFocus() &&
          _e(n);
      }, 20);
    }
  }
};
de.blur = (n, e) => {
  let t = e;
  n.focused &&
    (n.domObserver.stop(),
    n.dom.classList.remove("ProseMirror-focused"),
    n.domObserver.start(),
    t.relatedTarget &&
      n.dom.contains(t.relatedTarget) &&
      n.domObserver.currentSelection.clear(),
    (n.focused = !1));
};
de.beforeinput = (n, e) => {
  if (Ve && e.inputType == "deleteContentBackward") {
    n.domObserver.flushSoon();
    let { domChangeCount: r } = n.input;
    setTimeout(() => {
      if (
        n.input.domChangeCount != r ||
        n.domObserver.pendingRecords().length ||
        (n.dom.blur(), n.focus(), Xe(n, "Backspace"))
      )
        return;
      let { $cursor: i } = n.state.selection;
      i &&
        i.pos > 0 &&
        n.dispatch(n.state.tr.delete(i.pos - 1, i.pos).scrollIntoView());
    }, 50);
  }
};
for (let n in fe) de[n] = fe[n];
function Ln(n, e) {
  if (n == e) return !0;
  for (let t in n) if (n[t] !== e[t]) return !1;
  for (let t in e) if (!(t in n)) return !1;
  return !0;
}
class ms {
  constructor(e) {
    ((this.frag = e), (this.index = 0), (this.off = 0));
  }
  nodeAt(e) {
    for (; this.off <= e && this.index < this.frag.childCount;) {
      let t = this.frag.child(this.index);
      if (this.off == e) return t;
      ((this.off += t.nodeSize), this.index++);
    }
    return null;
  }
}
class vr {
  constructor(e, t) {
    ((this.toDOM = e),
      (this.spec = t || vt),
      (this.side = this.spec.side || 0));
  }
  map(e, t, r, i) {
    let { pos: s, deleted: o } = e.mapResult(
      t.from + i,
      this.side < 0 ? -1 : 1,
    );
    return o ? null : new ue(s - r, s - r, this);
  }
  valid() {
    return !0;
  }
  eq(e) {
    return (
      this == e ||
      (e instanceof vr &&
        ((this.spec.key && this.spec.key == e.spec.key) ||
          (this.toDOM == e.toDOM && Ln(this.spec, e.spec))))
    );
  }
  destroy(e) {
    this.spec.destroy && this.spec.destroy(e);
  }
}
class it {
  constructor(e, t) {
    ((this.attrs = e), (this.spec = t || vt));
  }
  map(e, t, r, i) {
    let s = e.map(t.from + i, this.spec.inclusiveStart ? -1 : 1) - r,
      o = e.map(t.to + i, this.spec.inclusiveEnd ? 1 : -1) - r;
    return s >= o ? null : new ue(s, o, this);
  }
  valid(e, t) {
    return t.from < t.to;
  }
  eq(e) {
    return (
      this == e ||
      (e instanceof it && Ln(this.attrs, e.attrs) && Ln(this.spec, e.spec))
    );
  }
  static is(e) {
    return e.type instanceof it;
  }
  destroy() {}
}
class Gs {
  constructor(e, t) {
    ((this.attrs = e), (this.spec = t || vt));
  }
  map(e, t, r, i) {
    let s = e.mapResult(t.from + i, 1);
    if (s.deleted) return null;
    let o = e.mapResult(t.to + i, -1);
    return o.deleted || o.pos <= s.pos
      ? null
      : new ue(s.pos - r, o.pos - r, this);
  }
  valid(e, t, r) {
    let i = r.nodeAt(t.from);
    return !!i && !i.isText && t.from + i.nodeSize == t.to;
  }
  eq(e) {
    return (
      this == e ||
      (e instanceof Gs && Ln(this.attrs, e.attrs) && Ln(this.spec, e.spec))
    );
  }
  destroy() {}
}
class ue {
  constructor(e, t, r) {
    ((this.from = e), (this.to = t), (this.type = r));
  }
  copy(e, t) {
    return new ue(e, t, this.type);
  }
  eq(e, t = 0) {
    return (
      this.type.eq(e.type) && this.from + t == e.from && this.to + t == e.to
    );
  }
  map(e, t, r) {
    return this.type.map(e, this, t, r);
  }
  static widget(e, t, r) {
    return new ue(e, e, new vr(t, r));
  }
  static inline(e, t, r, i) {
    return new ue(e, t, new it(r, i));
  }
  static node(e, t, r, i) {
    return new ue(e, t, new Gs(r, i));
  }
  get spec() {
    return this.type.spec;
  }
  get inline() {
    return this.type instanceof it;
  }
  get widget() {
    return this.type instanceof vr;
  }
}
const Vt = [],
  vt = {};
class P {
  constructor(e, t) {
    ((this.local = e.length ? e : Vt), (this.children = t.length ? t : Vt));
  }
  static create(e, t) {
    return t.length ? Mr(t, e, 0, vt) : se;
  }
  find(e, t, r) {
    let i = [];
    return (this.findInner(e ?? 0, t ?? 1e9, i, 0, r), i);
  }
  findInner(e, t, r, i, s) {
    for (let o = 0; o < this.local.length; o++) {
      let l = this.local[o];
      l.from <= t &&
        l.to >= e &&
        (!s || s(l.spec)) &&
        r.push(l.copy(l.from + i, l.to + i));
    }
    for (let o = 0; o < this.children.length; o += 3)
      if (this.children[o] < t && this.children[o + 1] > e) {
        let l = this.children[o] + 1;
        this.children[o + 2].findInner(e - l, t - l, r, i + l, s);
      }
  }
  map(e, t, r) {
    return this == se || e.maps.length == 0
      ? this
      : this.mapInner(e, t, 0, 0, r || vt);
  }
  mapInner(e, t, r, i, s) {
    let o;
    if (this.local.length) {
      let l = new ms(t.content);
      for (let a = 0; a < this.local.length; a++) {
        let c = this.local[a].map(e, r, i);
        c && c.type.valid(t, c, l)
          ? (o || (o = [])).push(c)
          : s.onRemove && s.onRemove(this.local[a].spec);
      }
    }
    return this.children.length
      ? gp(this.children, o || [], e, t, r, i, s)
      : o
        ? new P(o.sort(Mt), Vt)
        : se;
  }
  add(e, t) {
    return t.length
      ? this == se
        ? P.create(e, t)
        : this.addInner(e, t, 0)
      : this;
  }
  addInner(e, t, r) {
    let i,
      s = 0;
    e.forEach((l, a) => {
      let c = a + r,
        u;
      if ((u = Yc(t, l, c))) {
        for (i || (i = this.children.slice()); s < i.length && i[s] < a;)
          s += 3;
        (i[s] == a
          ? (i[s + 2] = i[s + 2].addInner(l, u, c + 1))
          : i.splice(s, 0, a, a + l.nodeSize, Mr(u, l, c + 1, vt)),
          (s += 3));
      }
    });
    let o = Gc(s ? Xc(t) : t, -r);
    if (o.length) {
      let l = new ms(e.content);
      for (let a = 0; a < o.length; a++)
        o[a].type.valid(e, o[a], l) || o.splice(a--, 1);
    }
    return new P(
      o.length ? this.local.concat(o).sort(Mt) : this.local,
      i || this.children,
    );
  }
  remove(e) {
    return e.length == 0 || this == se ? this : this.removeInner(e, 0);
  }
  removeInner(e, t) {
    let r = this.children,
      i = this.local;
    for (let s = 0; s < r.length; s += 3) {
      let o,
        l = r[s] + t,
        a = r[s + 1] + t;
      for (let u = 0, d; u < e.length; u++)
        (d = e[u]) &&
          d.from > l &&
          d.to < a &&
          ((e[u] = null), (o || (o = [])).push(d));
      if (!o) continue;
      r == this.children && (r = this.children.slice());
      let c = r[s + 2].removeInner(o, l + 1);
      c != se ? (r[s + 2] = c) : (r.splice(s, 3), (s -= 3));
    }
    if (i.length) {
      for (let s = 0, o; s < e.length; s++)
        if ((o = e[s]))
          for (let l = 0; l < i.length; l++)
            i[l].eq(o, t) &&
              (i == this.local && (i = this.local.slice()), i.splice(l--, 1));
    }
    return r == this.children && i == this.local
      ? this
      : i.length || r.length
        ? new P(i, r)
        : se;
  }
  forChild(e, t) {
    if (this == se) return this;
    if (t.isLeaf) return P.empty;
    let r, i;
    for (let l = 0; l < this.children.length; l += 3)
      if (this.children[l] >= e) {
        this.children[l] == e && (r = this.children[l + 2]);
        break;
      }
    let s = e + 1,
      o = s + t.content.size;
    for (let l = 0; l < this.local.length; l++) {
      let a = this.local[l];
      if (a.from < o && a.to > s && a.type instanceof it) {
        let c = Math.max(s, a.from) - s,
          u = Math.min(o, a.to) - s;
        c < u && (i || (i = [])).push(a.copy(c, u));
      }
    }
    if (i) {
      let l = new P(i.sort(Mt), Vt);
      return r ? new Qe([l, r]) : l;
    }
    return r || se;
  }
  eq(e) {
    if (this == e) return !0;
    if (
      !(e instanceof P) ||
      this.local.length != e.local.length ||
      this.children.length != e.children.length
    )
      return !1;
    for (let t = 0; t < this.local.length; t++)
      if (!this.local[t].eq(e.local[t])) return !1;
    for (let t = 0; t < this.children.length; t += 3)
      if (
        this.children[t] != e.children[t] ||
        this.children[t + 1] != e.children[t + 1] ||
        !this.children[t + 2].eq(e.children[t + 2])
      )
        return !1;
    return !0;
  }
  locals(e) {
    return Ys(this.localsInner(e));
  }
  localsInner(e) {
    if (this == se) return Vt;
    if (e.inlineContent || !this.local.some(it.is)) return this.local;
    let t = [];
    for (let r = 0; r < this.local.length; r++)
      this.local[r].type instanceof it || t.push(this.local[r]);
    return t;
  }
  forEachSet(e) {
    e(this);
  }
}
P.empty = new P([], []);
P.removeOverlap = Ys;
const se = P.empty;
class Qe {
  constructor(e) {
    this.members = e;
  }
  map(e, t) {
    const r = this.members.map((i) => i.map(e, t, vt));
    return Qe.from(r);
  }
  forChild(e, t) {
    if (t.isLeaf) return P.empty;
    let r = [];
    for (let i = 0; i < this.members.length; i++) {
      let s = this.members[i].forChild(e, t);
      s != se && (s instanceof Qe ? (r = r.concat(s.members)) : r.push(s));
    }
    return Qe.from(r);
  }
  eq(e) {
    if (!(e instanceof Qe) || e.members.length != this.members.length)
      return !1;
    for (let t = 0; t < this.members.length; t++)
      if (!this.members[t].eq(e.members[t])) return !1;
    return !0;
  }
  locals(e) {
    let t,
      r = !0;
    for (let i = 0; i < this.members.length; i++) {
      let s = this.members[i].localsInner(e);
      if (s.length)
        if (!t) t = s;
        else {
          r && ((t = t.slice()), (r = !1));
          for (let o = 0; o < s.length; o++) t.push(s[o]);
        }
    }
    return t ? Ys(r ? t : t.sort(Mt)) : Vt;
  }
  static from(e) {
    switch (e.length) {
      case 0:
        return se;
      case 1:
        return e[0];
      default:
        return new Qe(
          e.every((t) => t instanceof P)
            ? e
            : e.reduce((t, r) => t.concat(r instanceof P ? r : r.members), []),
        );
    }
  }
  forEachSet(e) {
    for (let t = 0; t < this.members.length; t++) this.members[t].forEachSet(e);
  }
}
function gp(n, e, t, r, i, s, o) {
  let l = n.slice();
  for (let c = 0, u = s; c < t.maps.length; c++) {
    let d = 0;
    (t.maps[c].forEach((f, h, p, g) => {
      let m = g - p - (h - f);
      for (let y = 0; y < l.length; y += 3) {
        let k = l[y + 1];
        if (k < 0 || f > k + u - d) continue;
        let x = l[y] + u - d;
        h >= x
          ? (l[y + 1] = f <= x ? -2 : -1)
          : f >= u && m && ((l[y] += m), (l[y + 1] += m));
      }
      d += m;
    }),
      (u = t.maps[c].map(u, -1)));
  }
  let a = !1;
  for (let c = 0; c < l.length; c += 3)
    if (l[c + 1] < 0) {
      if (l[c + 1] == -2) {
        ((a = !0), (l[c + 1] = -1));
        continue;
      }
      let u = t.map(n[c] + s),
        d = u - i;
      if (d < 0 || d >= r.content.size) {
        a = !0;
        continue;
      }
      let f = t.map(n[c + 1] + s, -1),
        h = f - i,
        { index: p, offset: g } = r.content.findIndex(d),
        m = r.maybeChild(p);
      if (m && g == d && g + m.nodeSize == h) {
        let y = l[c + 2].mapInner(t, m, u + 1, n[c] + s + 1, o);
        y != se
          ? ((l[c] = d), (l[c + 1] = h), (l[c + 2] = y))
          : ((l[c + 1] = -2), (a = !0));
      } else a = !0;
    }
  if (a) {
    let c = yp(l, n, e, t, i, s, o),
      u = Mr(c, r, 0, o);
    e = u.local;
    for (let d = 0; d < l.length; d += 3)
      l[d + 1] < 0 && (l.splice(d, 3), (d -= 3));
    for (let d = 0, f = 0; d < u.children.length; d += 3) {
      let h = u.children[d];
      for (; f < l.length && l[f] < h;) f += 3;
      l.splice(f, 0, u.children[d], u.children[d + 1], u.children[d + 2]);
    }
  }
  return new P(e.sort(Mt), l);
}
function Gc(n, e) {
  if (!e || !n.length) return n;
  let t = [];
  for (let r = 0; r < n.length; r++) {
    let i = n[r];
    t.push(new ue(i.from + e, i.to + e, i.type));
  }
  return t;
}
function yp(n, e, t, r, i, s, o) {
  function l(a, c) {
    for (let u = 0; u < a.local.length; u++) {
      let d = a.local[u].map(r, i, c);
      d ? t.push(d) : o.onRemove && o.onRemove(a.local[u].spec);
    }
    for (let u = 0; u < a.children.length; u += 3)
      l(a.children[u + 2], a.children[u] + c + 1);
  }
  for (let a = 0; a < n.length; a += 3)
    n[a + 1] == -1 && l(n[a + 2], e[a] + s + 1);
  return t;
}
function Yc(n, e, t) {
  if (e.isLeaf) return null;
  let r = t + e.nodeSize,
    i = null;
  for (let s = 0, o; s < n.length; s++)
    (o = n[s]) &&
      o.from > t &&
      o.to < r &&
      ((i || (i = [])).push(o), (n[s] = null));
  return i;
}
function Xc(n) {
  let e = [];
  for (let t = 0; t < n.length; t++) n[t] != null && e.push(n[t]);
  return e;
}
function Mr(n, e, t, r) {
  let i = [],
    s = !1;
  e.forEach((l, a) => {
    let c = Yc(n, l, a + t);
    if (c) {
      s = !0;
      let u = Mr(c, l, t + a + 1, r);
      u != se && i.push(a, a + l.nodeSize, u);
    }
  });
  let o = Gc(s ? Xc(n) : n, -t).sort(Mt);
  if (o.length) {
    let l = new ms(e.content);
    for (let a = 0; a < o.length; a++)
      o[a].type.valid(e, o[a], l) ||
        (r.onRemove && r.onRemove(o[a].spec), o.splice(a--, 1));
  }
  return o.length || i.length ? new P(o, i) : se;
}
function Mt(n, e) {
  return n.from - e.from || n.to - e.to;
}
function Ys(n) {
  let e = n;
  for (let t = 0; t < e.length - 1; t++) {
    let r = e[t];
    if (r.from != r.to)
      for (let i = t + 1; i < e.length; i++) {
        let s = e[i];
        if (s.from == r.from) {
          s.to != r.to &&
            (e == n && (e = n.slice()),
            (e[i] = s.copy(s.from, r.to)),
            ml(e, i + 1, s.copy(r.to, s.to)));
          continue;
        } else {
          s.from < r.to &&
            (e == n && (e = n.slice()),
            (e[t] = r.copy(r.from, s.from)),
            ml(e, i, r.copy(s.from, r.to)));
          break;
        }
      }
  }
  return e;
}
function ml(n, e, t) {
  for (; e < n.length && Mt(t, n[e]) > 0;) e++;
  n.splice(e, 0, t);
}
function Li(n) {
  let e = [];
  return (
    n.someProp("decorations", (t) => {
      let r = t(n.state);
      r && r != se && e.push(r);
    }),
    n.cursorWrapper && e.push(P.create(n.state.doc, [n.cursorWrapper.deco])),
    Qe.from(e)
  );
}
const bp = {
    childList: !0,
    characterData: !0,
    characterDataOldValue: !0,
    attributes: !0,
    attributeOldValue: !0,
    subtree: !0,
  },
  kp = me && tt <= 11;
class Sp {
  constructor() {
    ((this.anchorNode = null),
      (this.anchorOffset = 0),
      (this.focusNode = null),
      (this.focusOffset = 0));
  }
  set(e) {
    ((this.anchorNode = e.anchorNode),
      (this.anchorOffset = e.anchorOffset),
      (this.focusNode = e.focusNode),
      (this.focusOffset = e.focusOffset));
  }
  clear() {
    this.anchorNode = this.focusNode = null;
  }
  eq(e) {
    return (
      e.anchorNode == this.anchorNode &&
      e.anchorOffset == this.anchorOffset &&
      e.focusNode == this.focusNode &&
      e.focusOffset == this.focusOffset
    );
  }
}
class xp {
  constructor(e, t) {
    ((this.view = e),
      (this.handleDOMChange = t),
      (this.queue = []),
      (this.flushingSoon = -1),
      (this.observer = null),
      (this.currentSelection = new Sp()),
      (this.onCharData = null),
      (this.suppressingSelectionUpdates = !1),
      (this.lastChangedTextNode = null),
      (this.observer =
        window.MutationObserver &&
        new window.MutationObserver((r) => {
          for (let i = 0; i < r.length; i++) this.queue.push(r[i]);
          me &&
          tt <= 11 &&
          r.some(
            (i) =>
              (i.type == "childList" && i.removedNodes.length) ||
              (i.type == "characterData" &&
                i.oldValue.length > i.target.nodeValue.length),
          )
            ? this.flushSoon()
            : le &&
                e.composing &&
                r.some(
                  (i) => i.type == "childList" && i.target.nodeName == "TR",
                )
              ? ((e.input.badSafariComposition = !0), this.flushSoon())
              : this.flush();
        })),
      kp &&
        (this.onCharData = (r) => {
          (this.queue.push({
            target: r.target,
            type: "characterData",
            oldValue: r.prevValue,
          }),
            this.flushSoon());
        }),
      (this.onSelectionChange = this.onSelectionChange.bind(this)));
  }
  flushSoon() {
    this.flushingSoon < 0 &&
      (this.flushingSoon = window.setTimeout(() => {
        ((this.flushingSoon = -1), this.flush());
      }, 20));
  }
  forceFlush() {
    this.flushingSoon > -1 &&
      (window.clearTimeout(this.flushingSoon),
      (this.flushingSoon = -1),
      this.flush());
  }
  start() {
    (this.observer &&
      (this.observer.takeRecords(), this.observer.observe(this.view.dom, bp)),
      this.onCharData &&
        this.view.dom.addEventListener(
          "DOMCharacterDataModified",
          this.onCharData,
        ),
      this.connectSelection());
  }
  stop() {
    if (this.observer) {
      let e = this.observer.takeRecords();
      if (e.length) {
        for (let t = 0; t < e.length; t++) this.queue.push(e[t]);
        window.setTimeout(() => this.flush(), 20);
      }
      this.observer.disconnect();
    }
    (this.onCharData &&
      this.view.dom.removeEventListener(
        "DOMCharacterDataModified",
        this.onCharData,
      ),
      this.disconnectSelection());
  }
  connectSelection() {
    this.view.dom.ownerDocument.addEventListener(
      "selectionchange",
      this.onSelectionChange,
    );
  }
  disconnectSelection() {
    this.view.dom.ownerDocument.removeEventListener(
      "selectionchange",
      this.onSelectionChange,
    );
  }
  suppressSelectionUpdates() {
    ((this.suppressingSelectionUpdates = !0),
      setTimeout(() => (this.suppressingSelectionUpdates = !1), 50));
  }
  onSelectionChange() {
    if (al(this.view)) {
      if (this.suppressingSelectionUpdates) return _e(this.view);
      if (me && tt <= 11 && !this.view.state.selection.empty) {
        let e = this.view.domSelectionRange();
        if (
          e.focusNode &&
          Ot(e.focusNode, e.focusOffset, e.anchorNode, e.anchorOffset)
        )
          return this.flushSoon();
      }
      this.flush();
    }
  }
  setCurSelection() {
    this.currentSelection.set(this.view.domSelectionRange());
  }
  ignoreSelectionChange(e) {
    if (!e.focusNode) return !0;
    let t = new Set(),
      r;
    for (let s = e.focusNode; s; s = Xt(s)) t.add(s);
    for (let s = e.anchorNode; s; s = Xt(s))
      if (t.has(s)) {
        r = s;
        break;
      }
    let i = r && this.view.docView.nearestDesc(r);
    if (
      i &&
      i.ignoreMutation({ type: "selection", target: J(r) ? r.parentNode : r })
    )
      return (this.setCurSelection(), !0);
  }
  pendingRecords() {
    if (this.observer)
      for (let e of this.observer.takeRecords()) this.queue.push(e);
    return this.queue;
  }
  flush() {
    let { view: e } = this;
    if (!e.docView || this.flushingSoon > -1) return;
    let t = this.pendingRecords();
    t.length && (this.queue = []);
    let r,
      i = !1;
    !this.suppressingSelectionUpdates &&
      al(e) &&
      ((r = e.domSelectionRange()),
      (i = !this.currentSelection.eq(r) && !this.ignoreSelectionChange(r)));
    let s = -1,
      o = -1,
      l = !1,
      a = [];
    if (e.editable)
      for (let u = 0; u < t.length; u++) {
        let d = this.registerMutation(t[u], a);
        d &&
          ((s = s < 0 ? d.from : Math.min(d.from, s)),
          (o = o < 0 ? d.to : Math.max(d.to, o)),
          d.typeOver && (l = !0));
      }
    if (
      a.some((u) => u.nodeName == "BR") &&
      (e.input.lastKeyCode == 8 ||
        e.input.lastKeyCode == 46 ||
        (ie &&
          (e.composing || e.input.compositionEndedAt > Date.now() - 50) &&
          t.some((u) => u.type == "childList" && u.removedNodes.length)))
    ) {
      for (let u of a)
        if (u.nodeName == "BR" && u.parentNode) {
          let d = u.nextSibling;
          for (; d && A(d);) {
            if (d.contentEditable == "false") {
              u.parentNode.removeChild(u);
              break;
            }
            d = d.firstChild;
          }
        }
    } else if (be && a.length) {
      let u = a.filter((d) => d.nodeName == "BR");
      if (u.length == 2) {
        let [d, f] = u;
        d.parentNode && d.parentNode.parentNode == f.parentNode
          ? f.remove()
          : d.remove();
      } else {
        let { focusNode: d } = this.currentSelection;
        for (let f of u) {
          let h = f.parentNode;
          h && h.nodeName == "LI" && (!d || vp(e, d) != h) && f.remove();
        }
      }
    }
    let c = null;
    s < 0 &&
    i &&
    e.input.lastFocus > Date.now() - 200 &&
    Math.max(e.input.lastTouch, e.input.lastClick.time) < Date.now() - 300 &&
    ui(r) &&
    (c = _s(e)) &&
    c.eq(N.near(e.state.doc.resolve(0), 1))
      ? ((e.input.lastFocus = 0),
        _e(e),
        this.currentSelection.set(r),
        e.scrollToSelection())
      : (s > -1 || i) &&
        (s > -1 && (e.docView.markDirty(s, o), wp(e)),
        e.input.badSafariComposition &&
          ((e.input.badSafariComposition = !1), Mp(e, a)),
        this.handleDOMChange(s, o, l, a),
        e.docView && e.docView.dirty
          ? e.updateState(e.state)
          : r && !this.currentSelection.eq(r) && _e(e),
        r && this.currentSelection.set(r));
  }
  registerMutation(e, t) {
    if (t.indexOf(e.target) > -1) return null;
    let r = this.view.docView.nearestDesc(e.target);
    if (
      (e.type == "attributes" &&
        (r == this.view.docView ||
          e.attributeName == "contenteditable" ||
          (e.attributeName == "style" &&
            !e.oldValue &&
            !e.target.getAttribute("style")))) ||
      !r ||
      r.ignoreMutation(e)
    )
      return null;
    if (e.type == "childList") {
      for (let u = 0; u < e.addedNodes.length; u++) {
        let d = e.addedNodes[u];
        (t.push(d), J(d) && (this.lastChangedTextNode = d));
      }
      if (
        r.contentDOM &&
        r.contentDOM != r.dom &&
        !r.contentDOM.contains(e.target)
      )
        return { from: r.posBefore, to: r.posAfter };
      let i = e.previousSibling,
        s = e.nextSibling;
      if (me && tt <= 11 && e.addedNodes.length)
        for (let u = 0; u < e.addedNodes.length; u++) {
          let { previousSibling: d, nextSibling: f } = e.addedNodes[u];
          ((!d || Array.prototype.indexOf.call(e.addedNodes, d) < 0) && (i = d),
            (!f || Array.prototype.indexOf.call(e.addedNodes, f) < 0) &&
              (s = f));
        }
      let o = i && i.parentNode == e.target ? te(i) + 1 : 0,
        l = r.localPosFromDOM(e.target, o, -1),
        a = s && s.parentNode == e.target ? te(s) : e.target.childNodes.length,
        c = r.localPosFromDOM(e.target, a, 1);
      return { from: l, to: c };
    } else
      return e.type == "attributes"
        ? { from: r.posAtStart - r.border, to: r.posAtEnd + r.border }
        : ((this.lastChangedTextNode = e.target),
          {
            from: r.posAtStart,
            to: r.posAtEnd,
            typeOver: e.target.nodeValue == e.oldValue,
          });
  }
}
let gl = new WeakMap(),
  yl = !1;
function wp(n) {
  if (
    !gl.has(n) &&
    (gl.set(n, null),
    ["normal", "nowrap", "pre-line"].indexOf(
      getComputedStyle(n.dom).whiteSpace,
    ) !== -1)
  ) {
    if (((n.requiresGeckoHackNode = be), yl)) return;
    (console.warn(
      "ProseMirror expects the CSS white-space property to be set, preferably to 'pre-wrap'. It is recommended to load style/prosemirror.css from the prosemirror-view package.",
    ),
      (yl = !0));
  }
}
function bl(n, e) {
  let t = e.startContainer,
    r = e.startOffset,
    i = e.endContainer,
    s = e.endOffset,
    o = n.domAtPos(n.state.selection.anchor);
  return (
    Ot(o.node, o.offset, i, s) && ([t, r, i, s] = [i, s, t, r]),
    { anchorNode: t, anchorOffset: r, focusNode: i, focusOffset: s }
  );
}
function Cp(n, e) {
  if (e.getComposedRanges) {
    let i = e.getComposedRanges(n.root)[0];
    if (i) return bl(n, i);
  }
  let t;
  function r(i) {
    (i.preventDefault(),
      i.stopImmediatePropagation(),
      (t = i.getTargetRanges()[0]));
  }
  return (
    n.dom.addEventListener("beforeinput", r, !0),
    document.execCommand("indent"),
    n.dom.removeEventListener("beforeinput", r, !0),
    t ? bl(n, t) : null
  );
}
function vp(n, e) {
  for (let t = e.parentNode; t && t != n.dom; t = t.parentNode) {
    let r = n.docView.nearestDesc(t, !0);
    if (r && r.node.isBlock) return t;
  }
  return null;
}
function Mp(n, e) {
  var t;
  let { focusNode: r, focusOffset: i } = n.domSelectionRange();
  for (let s of e)
    if (
      ((t = s.parentNode) === null || t === void 0 ? void 0 : t.nodeName) ==
      "TR"
    ) {
      let o = s.nextSibling;
      for (; o && o.nodeName != "TD" && o.nodeName != "TH";) o = o.nextSibling;
      if (o) {
        let l = o;
        for (;;) {
          let a = l.firstChild;
          if (
            !a ||
            !A(a) ||
            a.contentEditable == "false" ||
            /^(BR|IMG)$/.test(a.nodeName)
          )
            break;
          l = a;
        }
        (l.insertBefore(s, l.firstChild),
          r == s && n.domSelection().collapse(s, i));
      } else s.parentNode.removeChild(s);
    }
}
function Ep(n, e, t, r) {
  let {
      node: i,
      fromOffset: s,
      toOffset: o,
      from: l,
      to: a,
    } = n.docView.parseRange(e, t),
    c = n.domSelectionRange(),
    u,
    d = c.anchorNode;
  if (
    (d &&
      Nt(n.dom, d) &&
      ((u = [{ node: d, offset: c.anchorOffset }]),
      ui(c) || u.push({ node: c.focusNode, offset: c.focusOffset })),
    ie && n.input.lastKeyCode === 8)
  )
    for (let y = o; y > s; y--) {
      let k = i.childNodes[y - 1],
        x = k.pmViewDesc;
      if (k.nodeName == "BR" && !x) {
        o = y;
        break;
      }
      if (!x || x.size) break;
    }
  let f = n.state.doc,
    h = n.someProp("domParser") || et.fromSchema(n.state.schema),
    p = f.resolve(l),
    g = null,
    m = h.parse(i, {
      topNode: p.parent,
      topMatch: p.parent.contentMatchAt(p.index()),
      topOpen: !0,
      from: s,
      to: o,
      preserveWhitespace: p.parent.type.whitespace == "pre" ? "full" : !0,
      findPositions: u,
      ruleFromNode: Tp(r),
      context: p,
    });
  if (u && u[0].pos != null) {
    let y = u[0].pos,
      k = u[1] && u[1].pos;
    (k == null && (k = y), (g = { anchor: y + l, head: k + l }));
  }
  return { doc: m, sel: g, from: l, to: a };
}
const Tp = (n) => (e) => {
    let t = e.pmViewDesc;
    if (t) return t.parseRule(n);
    if (e.nodeName == "BR" && e.parentNode) {
      if (le && /^(ul|ol)$/i.test(e.parentNode.nodeName)) {
        let r = document.createElement("div");
        return (r.appendChild(document.createElement("li")), { skip: r });
      } else if (
        e.parentNode.lastChild == e ||
        (le && /^(tr|table)$/i.test(e.parentNode.nodeName))
      )
        return { ignore: !0 };
    } else if (e.nodeName == "IMG" && e.getAttribute("mark-placeholder"))
      return { ignore: !0 };
    return null;
  },
  Ap =
    /^(a|abbr|acronym|b|bd[io]|big|br|button|cite|code|data(list)?|del|dfn|em|i|img|ins|kbd|label|map|mark|meter|output|q|ruby|s|samp|small|span|strong|su[bp]|time|u|tt|var)$/i;
function Op(n, e, t, r, i) {
  let s =
    n.input.compositionPendingChanges ||
    (n.composing ? n.input.compositionID : 0);
  if (((n.input.compositionPendingChanges = 0), e < 0)) {
    let E =
        n.input.lastSelectionTime > Date.now() - 50
          ? n.input.lastSelectionOrigin
          : null,
      I = _s(n, E);
    if (I && !n.state.selection.eq(I)) {
      if (
        ie &&
        Ve &&
        n.input.lastKeyCode === 13 &&
        Date.now() - 100 < n.input.lastKeyCodeTime &&
        Xe(n, "Enter")
      )
        return;
      let L = n.state.tr.setSelection(I);
      (E == "pointer"
        ? L.setMeta("pointer", !0)
        : E == "key" && L.scrollIntoView(),
        s && L.setMeta("composition", s),
        n.dispatch(L));
    }
    return;
  }
  let o = n.state.doc.resolve(e),
    l = o.sharedDepth(t);
  ((e = o.before(l + 1)), (t = n.state.doc.resolve(t).after(l + 1)));
  let a = n.state.selection,
    c = Ep(n, e, t, i),
    u = n.state.doc,
    d = u.slice(c.from, c.to),
    f,
    h;
  (n.input.lastKeyCode === 8 && Date.now() - 100 < n.input.lastKeyCodeTime
    ? ((f = n.state.selection.to), (h = "end"))
    : ((f = n.state.selection.from), (h = "start")),
    (n.input.lastKeyCode = null));
  let p = Ip(d.content, c.doc.content, c.from, f, h);
  if (
    (p && n.input.domChangeCount++,
    ((Qt && n.input.lastIOSEnter > Date.now() - 225) || Ve) &&
      i.some((E) => A(E) && !Ap.test(E.nodeName)) &&
      (!p || p.endA >= p.endB) &&
      Xe(n, "Enter"))
  ) {
    n.input.lastIOSEnter = 0;
    return;
  }
  if (!p)
    if (
      r &&
      a instanceof T &&
      !a.empty &&
      a.$head.sameParent(a.$anchor) &&
      !n.composing &&
      !(c.sel && c.sel.anchor != c.sel.head)
    )
      p = { start: a.from, endA: a.to, endB: a.to };
    else {
      if (c.sel) {
        let E = kl(n, n.state.doc, c.sel);
        if (E && !E.eq(n.state.selection)) {
          let I = n.state.tr.setSelection(E);
          (s && I.setMeta("composition", s), n.dispatch(I));
        }
      }
      return;
    }
  (n.state.selection.from < n.state.selection.to &&
    p.start == p.endB &&
    n.state.selection instanceof T &&
    (p.start > n.state.selection.from &&
    p.start <= n.state.selection.from + 2 &&
    n.state.selection.from >= c.from
      ? (p.start = n.state.selection.from)
      : p.endA < n.state.selection.to &&
        p.endA >= n.state.selection.to - 2 &&
        n.state.selection.to <= c.to &&
        ((p.endB += n.state.selection.to - p.endA),
        (p.endA = n.state.selection.to))),
    me &&
      tt <= 11 &&
      p.endB == p.start + 1 &&
      p.endA == p.start &&
      p.start > c.from &&
      c.doc.textBetween(p.start - c.from - 1, p.start - c.from + 1) == "  " &&
      (p.start--, p.endA--, p.endB--));
  let g = c.doc.resolveNoCache(p.start - c.from),
    m = c.doc.resolveNoCache(p.endB - c.from),
    y = u.resolve(p.start),
    k = g.sameParent(m) && g.parent.inlineContent && y.end() >= p.endA;
  if (
    ((Qt &&
      n.input.lastIOSEnter > Date.now() - 225 &&
      (!k || i.some((E) => E.nodeName == "DIV" || E.nodeName == "P"))) ||
      (!k && Rp(c.doc, g.pos, m.pos))) &&
    Xe(n, "Enter")
  ) {
    n.input.lastIOSEnter = 0;
    return;
  }
  if (
    n.state.selection.anchor > p.start &&
    (k
      ? p.endA > p.start && p.endB == p.start
      : Dp(u, p.start, p.endA, g, m)) &&
    Xe(n, "Backspace")
  ) {
    Ve && ie && n.domObserver.suppressSelectionUpdates();
    return;
  }
  (ie && p.endB == p.start && (n.input.lastChromeDelete = Date.now()),
    Ve &&
      !k &&
      g.start() != m.start() &&
      m.parentOffset == 0 &&
      g.depth == m.depth &&
      c.sel &&
      c.sel.anchor == c.sel.head &&
      c.sel.head == p.endA &&
      ((p.endB -= 2),
      (m = c.doc.resolveNoCache(p.endB - c.from)),
      setTimeout(() => Xe(n, "Enter"), 20)));
  let x = p.start,
    w = p.endA,
    M = (E) => {
      let I =
        E ||
        n.state.tr.replace(
          x,
          w,
          c.doc.slice(p.start - c.from, p.endB - c.from),
        );
      if (c.sel) {
        let L = kl(n, I.doc, c.sel);
        L &&
          !(
            (ie &&
              n.composing &&
              L.empty &&
              (p.start != p.endB ||
                n.input.lastChromeDelete < Date.now() - 100) &&
              (L.head == x || L.head == I.mapping.map(w) - 1)) ||
            (me && L.empty && L.head == x)
          ) &&
          I.setSelection(L);
      }
      return (s && I.setMeta("composition", s), I.scrollIntoView());
    },
    D;
  if (k)
    if (g.pos == m.pos) {
      me &&
        tt <= 11 &&
        g.parentOffset == 0 &&
        (n.domObserver.suppressSelectionUpdates(), setTimeout(() => _e(n), 20));
      let E = M(n.state.tr.delete(x, w)),
        I = u.resolve(p.start).marksAcross(u.resolve(p.endA));
      (I && E.ensureMarks(I), n.dispatch(E));
    } else if (
      p.endA == p.endB &&
      (D = Np(
        g.parent.content.cut(g.parentOffset, m.parentOffset),
        y.parent.content.cut(y.parentOffset, p.endA - y.start()),
      ))
    ) {
      let E = M(n.state.tr);
      (D.type == "add" ? E.addMark(x, w, D.mark) : E.removeMark(x, w, D.mark),
        n.dispatch(E));
    } else if (
      g.parent.child(g.index()).isText &&
      g.index() == m.index() - (m.textOffset ? 0 : 1)
    ) {
      let E = g.parent.textBetween(g.parentOffset, m.parentOffset),
        I = () => M(n.state.tr.insertText(E, x, w));
      n.someProp("handleTextInput", (L) => L(n, x, w, E, I)) || n.dispatch(I());
    } else n.dispatch(M());
  else n.dispatch(M());
}
function kl(n, e, t) {
  return Math.max(t.anchor, t.head) > e.content.size
    ? null
    : Ws(n, e.resolve(t.anchor), e.resolve(t.head));
}
function Np(n, e) {
  let t = n.firstChild.marks,
    r = e.firstChild.marks,
    i = t,
    s = r,
    o,
    l,
    a;
  for (let u = 0; u < r.length; u++) i = r[u].removeFromSet(i);
  for (let u = 0; u < t.length; u++) s = t[u].removeFromSet(s);
  if (i.length == 1 && s.length == 0)
    ((l = i[0]), (o = "add"), (a = (u) => u.mark(l.addToSet(u.marks))));
  else if (i.length == 0 && s.length == 1)
    ((l = s[0]), (o = "remove"), (a = (u) => u.mark(l.removeFromSet(u.marks))));
  else return null;
  let c = [];
  for (let u = 0; u < e.childCount; u++) c.push(a(e.child(u)));
  if (b.from(c).eq(n)) return { mark: l, type: o };
}
function Dp(n, e, t, r, i) {
  if (t - e <= i.pos - r.pos || Pi(r, !0, !1) < i.pos) return !1;
  let s = n.resolve(e);
  if (!r.parent.inlineContent) {
    let l = s.nodeAfter;
    return l != null && t == e + l.nodeSize;
  }
  if (s.parentOffset < s.parent.content.size || !s.parent.isTextblock)
    return !1;
  let o = n.resolve(Pi(s, !0, !0));
  return !o.parent.isTextblock || o.pos > t || Pi(o, !0, !1) < t
    ? !1
    : r.parent.content.cut(r.parentOffset).eq(o.parent.content);
}
function Rp(n, e, t) {
  let r = 0,
    i = 0;
  return (
    n.nodesBetween(e, t, (s, o) => {
      s.isTextblock && o >= e && o < t
        ? r++
        : (s.isText
            ? /\S/.test(
                s.text.slice(Math.max(0, e - o), Math.min(s.nodeSize, t - o)),
              )
            : s.isLeaf) && i++;
    }),
    i == 0 && r == 1
  );
}
function Pi(n, e, t) {
  let r = n.depth,
    i = e ? n.end() : n.pos;
  for (; r > 0 && (e || n.indexAfter(r) == n.node(r).childCount);)
    (r--, i++, (e = !1));
  if (t) {
    let s = n.node(r).maybeChild(n.indexAfter(r));
    for (; s && !s.isLeaf;) ((s = s.firstChild), i++);
  }
  return i;
}
function Ip(n, e, t, r, i) {
  let s = n.findDiffStart(e, t),
    o = t + n.size,
    l = t + e.size;
  if (s == null) return null;
  let { a, b: c } = n.findDiffEnd(e, o, l);
  if (i == "end") {
    let u = Math.max(0, s - Math.min(a, c));
    r -= a + u - s;
  }
  if (a < s && o < l) {
    let u = r <= s && r >= a ? s - r : 0;
    ((s -= u), (c = s + (c - a)), (a = s));
  } else if (c < s) {
    let u = r <= s && r >= c ? s - r : 0;
    ((s -= u), (a = s + (a - c)), (c = s));
  }
  return { start: s, endA: a, endB: c };
}
class Qc {
  constructor(e, t) {
    ((this._root = null),
      (this.focused = !1),
      (this.trackWrites = null),
      (this.mounted = !1),
      (this.markCursor = null),
      (this.cursorWrapper = null),
      (this.lastSelectedViewDesc = void 0),
      (this.input = new Jh()),
      (this.prevDirectPlugins = []),
      (this.pluginViews = []),
      (this.requiresGeckoHackNode = !1),
      (this.dragging = null),
      (this._props = t),
      (this.state = t.state),
      (this.directPlugins = t.plugins || []),
      this.directPlugins.forEach(vl),
      (this.dispatch = this.dispatch.bind(this)),
      (this.dom = (e && e.mount) || document.createElement("div")),
      e &&
        (e.appendChild
          ? e.appendChild(this.dom)
          : typeof e == "function"
            ? e(this.dom)
            : e.mount && (this.mounted = !0)),
      (this.editable = wl(this)),
      xl(this),
      (this.nodeViews = Cl(this)),
      (this.docView = nl(this.state.doc, Sl(this), Li(this), this.dom, this)),
      (this.domObserver = new xp(this, (r, i, s, o) => Op(this, r, i, s, o))),
      this.domObserver.start(),
      Gh(this),
      this.updatePluginViews());
  }
  get composing() {
    return this.input.composing;
  }
  get props() {
    if (this._props.state != this.state) {
      let e = this._props;
      this._props = {};
      for (let t in e) this._props[t] = e[t];
      this._props.state = this.state;
    }
    return this._props;
  }
  update(e) {
    e.handleDOMEvents != this._props.handleDOMEvents && ps(this);
    let t = this._props;
    ((this._props = e),
      e.plugins && (e.plugins.forEach(vl), (this.directPlugins = e.plugins)),
      this.updateStateInner(e.state, t));
  }
  setProps(e) {
    let t = {};
    for (let r in this._props) t[r] = this._props[r];
    t.state = this.state;
    for (let r in e) t[r] = e[r];
    this.update(t);
  }
  updateState(e) {
    this.updateStateInner(e, this._props);
  }
  updateStateInner(e, t) {
    var r;
    let i = this.state,
      s = !1,
      o = !1;
    (e.storedMarks && this.composing && (qc(this), (o = !0)), (this.state = e));
    let l = i.plugins != e.plugins || this._props.plugins != t.plugins;
    if (
      l ||
      this._props.plugins != t.plugins ||
      this._props.nodeViews != t.nodeViews
    ) {
      let h = Cl(this);
      Pp(h, this.nodeViews) && ((this.nodeViews = h), (s = !0));
    }
    ((l || t.handleDOMEvents != this._props.handleDOMEvents) && ps(this),
      (this.editable = wl(this)),
      xl(this));
    let a = Li(this),
      c = Sl(this),
      u =
        i.plugins != e.plugins && !i.doc.eq(e.doc)
          ? "reset"
          : e.scrollToSelection > i.scrollToSelection
            ? "to selection"
            : "preserve",
      d = s || !this.docView.matchesNode(e.doc, c, a);
    (d || !e.selection.eq(i.selection)) && (o = !0);
    let f =
      u == "preserve" && o && this.dom.style.overflowAnchor == null && ch(this);
    if (o) {
      this.domObserver.stop();
      let h =
        d &&
        (me || ie) &&
        !this.composing &&
        !i.selection.empty &&
        !e.selection.empty &&
        Lp(i.selection, e.selection);
      if (d) {
        let g = ie
          ? (this.trackWrites = this.domSelectionRange().focusNode)
          : null;
        (this.composing && (this.input.compositionNode = up(this)),
          (s || !this.docView.update(e.doc, c, a, this)) &&
            (this.docView.updateOuterDeco(c),
            this.docView.destroy(),
            (this.docView = nl(e.doc, c, a, this.dom, this))),
          g &&
            (!this.trackWrites || !this.dom.contains(this.trackWrites)) &&
            (h = !0));
      }
      let p = this.input.mouseDown;
      (h ||
      !(
        p &&
        this.domObserver.currentSelection.eq(this.domSelectionRange()) &&
        Ih(this) &&
        p.delaySelUpdate()
      )
        ? _e(this, h)
        : (Dc(this, e.selection), this.domObserver.setCurSelection()),
        this.domObserver.start());
    }
    (this.updatePluginViews(i),
      !((r = this.dragging) === null || r === void 0) &&
        r.node &&
        !i.doc.eq(e.doc) &&
        this.updateDraggedNode(this.dragging, i),
      u == "reset"
        ? (this.dom.scrollTop = 0)
        : u == "to selection"
          ? this.scrollToSelection()
          : f && uh(f));
  }
  scrollToSelection() {
    let e = this.domSelectionRange().focusNode;
    if (!(!e || !Nt(this.dom, e))) {
      if (!this.someProp("handleScrollToSelection", (t) => t(this)))
        if (this.state.selection instanceof O) {
          let t = this.docView.domAfterPos(this.state.selection.from);
          A(t) && Xo(this, t.getBoundingClientRect(), e);
        } else Xo(this, this.coordsAtPos(this.state.selection.head, 1), e);
    }
  }
  destroyPluginViews() {
    let e;
    for (; (e = this.pluginViews.pop());) e.destroy && e.destroy();
  }
  updatePluginViews(e) {
    if (
      !e ||
      e.plugins != this.state.plugins ||
      this.directPlugins != this.prevDirectPlugins
    ) {
      ((this.prevDirectPlugins = this.directPlugins),
        this.destroyPluginViews());
      for (let t = 0; t < this.directPlugins.length; t++) {
        let r = this.directPlugins[t];
        r.spec.view && this.pluginViews.push(r.spec.view(this));
      }
      for (let t = 0; t < this.state.plugins.length; t++) {
        let r = this.state.plugins[t];
        r.spec.view && this.pluginViews.push(r.spec.view(this));
      }
    } else
      for (let t = 0; t < this.pluginViews.length; t++) {
        let r = this.pluginViews[t];
        r.update && r.update(this, e);
      }
  }
  updateDraggedNode(e, t) {
    let r = e.node,
      i = -1;
    if (
      r.from < this.state.doc.content.size &&
      this.state.doc.nodeAt(r.from) == r.node
    )
      i = r.from;
    else {
      let s = r.from + (this.state.doc.content.size - t.doc.content.size);
      (s > 0 && s < this.state.doc.content.size && this.state.doc.nodeAt(s)) ==
        r.node && (i = s);
    }
    this.dragging = new Kc(
      e.slice,
      e.move,
      i < 0 ? void 0 : O.create(this.state.doc, i),
    );
  }
  someProp(e, t) {
    let r = this._props && this._props[e],
      i;
    if (r != null && (i = t ? t(r) : r)) return i;
    for (let o = 0; o < this.directPlugins.length; o++) {
      let l = this.directPlugins[o].props[e];
      if (l != null && (i = t ? t(l) : l)) return i;
    }
    let s = this.state.plugins;
    if (s)
      for (let o = 0; o < s.length; o++) {
        let l = s[o].props[e];
        if (l != null && (i = t ? t(l) : l)) return i;
      }
  }
  hasFocus() {
    if (me) {
      let e = this.root.activeElement;
      if (e == this.dom) return !0;
      if (!e || !this.dom.contains(e)) return !1;
      for (; e && this.dom != e && this.dom.contains(e);) {
        if (e.contentEditable == "false") return !1;
        e = e.parentElement;
      }
      return !0;
    }
    return this.root.activeElement == this.dom;
  }
  focus() {
    (this.domObserver.stop(),
      this.editable && dh(this.dom),
      _e(this),
      this.domObserver.start());
  }
  get root() {
    let e = this._root;
    if (e == null) {
      for (let t = this.dom.parentNode; t; t = t.parentNode)
        if (t.nodeType == 9 || (t.nodeType == 11 && t.host))
          return (
            t.getSelection ||
              (Object.getPrototypeOf(t).getSelection = () =>
                t.ownerDocument.getSelection()),
            (this._root = t)
          );
    }
    return e || document;
  }
  updateRoot() {
    this._root = null;
  }
  posAtCoords(e) {
    return gh(this, e);
  }
  coordsAtPos(e, t = 1) {
    return Cc(this, e, t);
  }
  domAtPos(e, t = 0) {
    return this.docView.domFromPos(e, t);
  }
  nodeDOM(e) {
    let t = this.docView.descAt(e);
    return t ? t.nodeDOM : null;
  }
  posAtDOM(e, t, r = -1) {
    let i = this.docView.posFromDOM(e, t, r);
    if (i == null) throw new RangeError("DOM position not inside the editor");
    return i;
  }
  endOfTextblock(e, t) {
    return xh(this, t || this.state, e);
  }
  pasteHTML(e, t) {
    return In(this, "", e, !1, t || new ClipboardEvent("paste"));
  }
  pasteText(e, t) {
    return In(this, e, null, !0, t || new ClipboardEvent("paste"));
  }
  serializeForClipboard(e) {
    return qs(this, e);
  }
  destroy() {
    this.docView &&
      (Yh(this),
      this.destroyPluginViews(),
      this.mounted
        ? (this.docView.update(this.state.doc, [], Li(this), this),
          (this.dom.textContent = ""))
        : this.dom.parentNode && this.dom.parentNode.removeChild(this.dom),
      this.docView.destroy(),
      (this.docView = null),
      Qf());
  }
  get isDestroyed() {
    return this.docView == null;
  }
  dispatchEvent(e) {
    return Qh(this, e);
  }
  domSelectionRange() {
    let e = this.dom.isConnected !== !1 && this.domSelection();
    return e
      ? (le &&
          this.root.nodeType === 11 &&
          ih(this.dom.ownerDocument) == this.dom &&
          Cp(this, e)) ||
          e
      : { focusNode: null, focusOffset: 0, anchorNode: null, anchorOffset: 0 };
  }
  domSelection() {
    return this.root.getSelection();
  }
}
Qc.prototype.dispatch = function (n) {
  let e = this._props.dispatchTransaction;
  e ? e.call(this, n) : this.updateState(this.state.apply(n));
};
function Sl(n) {
  let e = Object.create(null);
  return (
    (e.class = "ProseMirror"),
    (e.contenteditable = String(n.editable)),
    n.someProp("attributes", (t) => {
      if ((typeof t == "function" && (t = t(n.state)), t))
        for (let r in t)
          r == "class"
            ? (e.class += " " + t[r])
            : r == "style"
              ? (e.style = (e.style ? e.style + ";" : "") + t[r])
              : !e[r] &&
                r != "contenteditable" &&
                r != "nodeName" &&
                (e[r] = String(t[r]));
    }),
    e.translate || (e.translate = "no"),
    [ue.node(0, n.state.doc.content.size, e)]
  );
}
function xl(n) {
  if (n.markCursor) {
    let e = document.createElement("img");
    ((e.className = "ProseMirror-separator"),
      e.setAttribute("mark-placeholder", "true"),
      e.setAttribute("alt", ""),
      (n.cursorWrapper = {
        dom: e,
        deco: ue.widget(n.state.selection.from, e, {
          raw: !0,
          marks: n.markCursor,
        }),
      }));
  } else n.cursorWrapper = null;
}
function wl(n) {
  return !n.someProp("editable", (e) => e(n.state) === !1);
}
function Lp(n, e) {
  let t = Math.min(
    n.$anchor.sharedDepth(n.head),
    e.$anchor.sharedDepth(e.head),
  );
  return n.$anchor.start(t) != e.$anchor.start(t);
}
function Cl(n) {
  let e = Object.create(null);
  function t(r) {
    for (let i in r)
      Object.prototype.hasOwnProperty.call(e, i) || (e[i] = r[i]);
  }
  return (n.someProp("nodeViews", t), n.someProp("markViews", t), e);
}
function Pp(n, e) {
  let t = 0,
    r = 0;
  for (let i in n) {
    if (n[i] != e[i]) return !0;
    t++;
  }
  for (let i in e) r++;
  return t != r;
}
function vl(n) {
  if (n.spec.state || n.spec.filterTransaction || n.spec.appendTransaction)
    throw new RangeError(
      "Plugins passed directly to the view must not have a state component",
    );
}
var ot = {
    8: "Backspace",
    9: "Tab",
    10: "Enter",
    12: "NumLock",
    13: "Enter",
    16: "Shift",
    17: "Control",
    18: "Alt",
    20: "CapsLock",
    27: "Escape",
    32: " ",
    33: "PageUp",
    34: "PageDown",
    35: "End",
    36: "Home",
    37: "ArrowLeft",
    38: "ArrowUp",
    39: "ArrowRight",
    40: "ArrowDown",
    44: "PrintScreen",
    45: "Insert",
    46: "Delete",
    59: ";",
    61: "=",
    91: "Meta",
    92: "Meta",
    106: "*",
    107: "+",
    108: ",",
    109: "-",
    110: ".",
    111: "/",
    144: "NumLock",
    145: "ScrollLock",
    160: "Shift",
    161: "Shift",
    162: "Control",
    163: "Control",
    164: "Alt",
    165: "Alt",
    173: "-",
    186: ";",
    187: "=",
    188: ",",
    189: "-",
    190: ".",
    191: "/",
    192: "`",
    219: "[",
    220: "\\",
    221: "]",
    222: "'",
  },
  Er = {
    48: ")",
    49: "!",
    50: "@",
    51: "#",
    52: "$",
    53: "%",
    54: "^",
    55: "&",
    56: "*",
    57: "(",
    59: ":",
    61: "+",
    173: "_",
    186: ":",
    187: "+",
    188: "<",
    189: "_",
    190: ">",
    191: "?",
    192: "~",
    219: "{",
    220: "|",
    221: "}",
    222: '"',
  },
  Bp = typeof navigator < "u" && /Mac/.test(navigator.platform),
  $p =
    typeof navigator < "u" &&
    /MSIE \d|Trident\/(?:[7-9]|\d{2,})\..*rv:(\d+)/.exec(navigator.userAgent);
for (var ne = 0; ne < 10; ne++) ot[48 + ne] = ot[96 + ne] = String(ne);
for (var ne = 1; ne <= 24; ne++) ot[ne + 111] = "F" + ne;
for (var ne = 65; ne <= 90; ne++)
  ((ot[ne] = String.fromCharCode(ne + 32)), (Er[ne] = String.fromCharCode(ne)));
for (var Bi in ot) Er.hasOwnProperty(Bi) || (Er[Bi] = ot[Bi]);
function zp(n) {
  var e =
      (Bp && n.metaKey && n.shiftKey && !n.ctrlKey && !n.altKey) ||
      ($p && n.shiftKey && n.key && n.key.length == 1) ||
      n.key == "Unidentified",
    t =
      (!e && n.key) ||
      (n.shiftKey ? Er : ot)[n.keyCode] ||
      n.key ||
      "Unidentified";
  return (
    t == "Esc" && (t = "Escape"),
    t == "Del" && (t = "Delete"),
    t == "Left" && (t = "ArrowLeft"),
    t == "Up" && (t = "ArrowUp"),
    t == "Right" && (t = "ArrowRight"),
    t == "Down" && (t = "ArrowDown"),
    t
  );
}
const Fp =
    typeof navigator < "u" && /Mac|iP(hone|[oa]d)/.test(navigator.platform),
  Vp = typeof navigator < "u" && /Win/.test(navigator.platform);
function jp(n) {
  let e = n.split(/-(?!$)/),
    t = e[e.length - 1];
  t == "Space" && (t = " ");
  let r, i, s, o;
  for (let l = 0; l < e.length - 1; l++) {
    let a = e[l];
    if (/^(cmd|meta|m)$/i.test(a)) o = !0;
    else if (/^a(lt)?$/i.test(a)) r = !0;
    else if (/^(c|ctrl|control)$/i.test(a)) i = !0;
    else if (/^s(hift)?$/i.test(a)) s = !0;
    else if (/^mod$/i.test(a)) Fp ? (o = !0) : (i = !0);
    else throw new Error("Unrecognized modifier name: " + a);
  }
  return (
    r && (t = "Alt-" + t),
    i && (t = "Ctrl-" + t),
    o && (t = "Meta-" + t),
    s && (t = "Shift-" + t),
    t
  );
}
function Hp(n) {
  let e = Object.create(null);
  for (let t in n) e[jp(t)] = n[t];
  return e;
}
function $i(n, e, t = !0) {
  return (
    e.altKey && (n = "Alt-" + n),
    e.ctrlKey && (n = "Ctrl-" + n),
    e.metaKey && (n = "Meta-" + n),
    t && e.shiftKey && (n = "Shift-" + n),
    n
  );
}
function _p(n) {
  return new V({ props: { handleKeyDown: Zc(n) } });
}
function Zc(n) {
  let e = Hp(n);
  return function (t, r) {
    let i = zp(r),
      s,
      o = e[$i(i, r)];
    if (o && o(t.state, t.dispatch, t)) return !0;
    if (i.length == 1 && i != " ") {
      if (r.shiftKey) {
        let l = e[$i(i, r, !1)];
        if (l && l(t.state, t.dispatch, t)) return !0;
      }
      if (
        (r.altKey || r.metaKey || r.ctrlKey) &&
        !(Vp && r.ctrlKey && r.altKey) &&
        (s = ot[r.keyCode]) &&
        s != i
      ) {
        let l = e[$i(s, r)];
        if (l && l(t.state, t.dispatch, t)) return !0;
      }
    }
    return !1;
  };
}
var Tr = 200,
  Z = function () {};
Z.prototype.append = function (e) {
  return e.length
    ? ((e = Z.from(e)),
      (!this.length && e) ||
        (e.length < Tr && this.leafAppend(e)) ||
        (this.length < Tr && e.leafPrepend(this)) ||
        this.appendInner(e))
    : this;
};
Z.prototype.prepend = function (e) {
  return e.length ? Z.from(e).append(this) : this;
};
Z.prototype.appendInner = function (e) {
  return new Wp(this, e);
};
Z.prototype.slice = function (e, t) {
  return (
    e === void 0 && (e = 0),
    t === void 0 && (t = this.length),
    e >= t ? Z.empty : this.sliceInner(Math.max(0, e), Math.min(this.length, t))
  );
};
Z.prototype.get = function (e) {
  if (!(e < 0 || e >= this.length)) return this.getInner(e);
};
Z.prototype.forEach = function (e, t, r) {
  (t === void 0 && (t = 0),
    r === void 0 && (r = this.length),
    t <= r
      ? this.forEachInner(e, t, r, 0)
      : this.forEachInvertedInner(e, t, r, 0));
};
Z.prototype.map = function (e, t, r) {
  (t === void 0 && (t = 0), r === void 0 && (r = this.length));
  var i = [];
  return (
    this.forEach(
      function (s, o) {
        return i.push(e(s, o));
      },
      t,
      r,
    ),
    i
  );
};
Z.from = function (e) {
  return e instanceof Z ? e : e && e.length ? new eu(e) : Z.empty;
};
var eu = (function (n) {
  function e(r) {
    (n.call(this), (this.values = r));
  }
  (n && (e.__proto__ = n),
    (e.prototype = Object.create(n && n.prototype)),
    (e.prototype.constructor = e));
  var t = { length: { configurable: !0 }, depth: { configurable: !0 } };
  return (
    (e.prototype.flatten = function () {
      return this.values;
    }),
    (e.prototype.sliceInner = function (i, s) {
      return i == 0 && s == this.length ? this : new e(this.values.slice(i, s));
    }),
    (e.prototype.getInner = function (i) {
      return this.values[i];
    }),
    (e.prototype.forEachInner = function (i, s, o, l) {
      for (var a = s; a < o; a++)
        if (i(this.values[a], l + a) === !1) return !1;
    }),
    (e.prototype.forEachInvertedInner = function (i, s, o, l) {
      for (var a = s - 1; a >= o; a--)
        if (i(this.values[a], l + a) === !1) return !1;
    }),
    (e.prototype.leafAppend = function (i) {
      if (this.length + i.length <= Tr)
        return new e(this.values.concat(i.flatten()));
    }),
    (e.prototype.leafPrepend = function (i) {
      if (this.length + i.length <= Tr)
        return new e(i.flatten().concat(this.values));
    }),
    (t.length.get = function () {
      return this.values.length;
    }),
    (t.depth.get = function () {
      return 0;
    }),
    Object.defineProperties(e.prototype, t),
    e
  );
})(Z);
Z.empty = new eu([]);
var Wp = (function (n) {
  function e(t, r) {
    (n.call(this),
      (this.left = t),
      (this.right = r),
      (this.length = t.length + r.length),
      (this.depth = Math.max(t.depth, r.depth) + 1));
  }
  return (
    n && (e.__proto__ = n),
    (e.prototype = Object.create(n && n.prototype)),
    (e.prototype.constructor = e),
    (e.prototype.flatten = function () {
      return this.left.flatten().concat(this.right.flatten());
    }),
    (e.prototype.getInner = function (r) {
      return r < this.left.length
        ? this.left.get(r)
        : this.right.get(r - this.left.length);
    }),
    (e.prototype.forEachInner = function (r, i, s, o) {
      var l = this.left.length;
      if (
        (i < l && this.left.forEachInner(r, i, Math.min(s, l), o) === !1) ||
        (s > l &&
          this.right.forEachInner(
            r,
            Math.max(i - l, 0),
            Math.min(this.length, s) - l,
            o + l,
          ) === !1)
      )
        return !1;
    }),
    (e.prototype.forEachInvertedInner = function (r, i, s, o) {
      var l = this.left.length;
      if (
        (i > l &&
          this.right.forEachInvertedInner(
            r,
            i - l,
            Math.max(s, l) - l,
            o + l,
          ) === !1) ||
        (s < l &&
          this.left.forEachInvertedInner(r, Math.min(i, l), s, o) === !1)
      )
        return !1;
    }),
    (e.prototype.sliceInner = function (r, i) {
      if (r == 0 && i == this.length) return this;
      var s = this.left.length;
      return i <= s
        ? this.left.slice(r, i)
        : r >= s
          ? this.right.slice(r - s, i - s)
          : this.left.slice(r, s).append(this.right.slice(0, i - s));
    }),
    (e.prototype.leafAppend = function (r) {
      var i = this.right.leafAppend(r);
      if (i) return new e(this.left, i);
    }),
    (e.prototype.leafPrepend = function (r) {
      var i = this.left.leafPrepend(r);
      if (i) return new e(i, this.right);
    }),
    (e.prototype.appendInner = function (r) {
      return this.left.depth >= Math.max(this.right.depth, r.depth) + 1
        ? new e(this.left, new e(this.right, r))
        : new e(this, r);
    }),
    e
  );
})(Z);
const qp = 500;
class Me {
  constructor(e, t) {
    ((this.items = e), (this.eventCount = t));
  }
  popEvent(e, t) {
    if (this.eventCount == 0) return null;
    let r = this.items.length;
    for (; ; r--)
      if (this.items.get(r - 1).selection) {
        --r;
        break;
      }
    let i, s;
    t && ((i = this.remapping(r, this.items.length)), (s = i.maps.length));
    let o = e.tr,
      l,
      a,
      c = [],
      u = [];
    return (
      this.items.forEach(
        (d, f) => {
          if (!d.step) {
            (i || ((i = this.remapping(r, f + 1)), (s = i.maps.length)),
              s--,
              u.push(d));
            return;
          }
          if (i) {
            u.push(new Te(d.map));
            let h = d.step.map(i.slice(s)),
              p;
            (h &&
              o.maybeStep(h).doc &&
              ((p = o.mapping.maps[o.mapping.maps.length - 1]),
              c.push(new Te(p, void 0, void 0, c.length + u.length))),
              s--,
              p && i.appendMap(p, s));
          } else o.maybeStep(d.step);
          if (d.selection)
            return (
              (l = i ? d.selection.map(i.slice(s)) : d.selection),
              (a = new Me(
                this.items.slice(0, r).append(u.reverse().concat(c)),
                this.eventCount - 1,
              )),
              !1
            );
        },
        this.items.length,
        0,
      ),
      { remaining: a, transform: o, selection: l }
    );
  }
  addTransform(e, t, r, i) {
    let s = [],
      o = this.eventCount,
      l = this.items,
      a = !i && l.length ? l.get(l.length - 1) : null;
    for (let u = 0; u < e.steps.length; u++) {
      let d = e.steps[u].invert(e.docs[u]),
        f = new Te(e.mapping.maps[u], d, t),
        h;
      ((h = a && a.merge(f)) &&
        ((f = h), u ? s.pop() : (l = l.slice(0, l.length - 1))),
        s.push(f),
        t && (o++, (t = void 0)),
        i || (a = f));
    }
    let c = o - r.depth;
    return (c > Kp && ((l = Up(l, c)), (o -= c)), new Me(l.append(s), o));
  }
  remapping(e, t) {
    let r = new Nn();
    return (
      this.items.forEach(
        (i, s) => {
          let o =
            i.mirrorOffset != null && s - i.mirrorOffset >= e
              ? r.maps.length - i.mirrorOffset
              : void 0;
          r.appendMap(i.map, o);
        },
        e,
        t,
      ),
      r
    );
  }
  addMaps(e) {
    return this.eventCount == 0
      ? this
      : new Me(this.items.append(e.map((t) => new Te(t))), this.eventCount);
  }
  rebased(e, t) {
    if (!this.eventCount) return this;
    t = Math.min(this.items.length, t);
    let r = [],
      i = this.items.length - t,
      s = e.mapping,
      o = e.steps.length,
      l = this.eventCount;
    this.items.forEach((f) => {
      f.selection && l--;
    }, i);
    let a = t;
    this.items.forEach((f) => {
      let h = s.getMirror(--a);
      if (h == null) return;
      o = Math.min(o, h);
      let p = s.maps[h];
      if (f.step) {
        let g = e.steps[h].invert(e.docs[h]),
          m = f.selection && f.selection.map(s.slice(a + 1, h));
        (m && l++, r.push(new Te(p, g, m)));
      } else r.push(new Te(p));
    }, i);
    let c = [];
    for (let f = t; f < o; f++) c.push(new Te(s.maps[f]));
    let u = this.items.slice(0, i).append(c).append(r),
      d = new Me(u, l);
    return (
      d.emptyItemCount() > qp && (d = d.compress(this.items.length - r.length)),
      d
    );
  }
  emptyItemCount() {
    let e = 0;
    return (
      this.items.forEach((t) => {
        t.step || e++;
      }),
      e
    );
  }
  compress(e = this.items.length) {
    let t = this.remapping(0, e),
      r = t.maps.length,
      i = [],
      s = 0;
    return (
      this.items.forEach(
        (o, l) => {
          if (l >= e) (i.push(o), o.selection && s++);
          else if (o.step) {
            let a = o.step.map(t.slice(r)),
              c = a && a.getMap();
            if ((r--, c && t.appendMap(c, r), a)) {
              let u = o.selection && o.selection.map(t.slice(r));
              u && s++;
              let d = new Te(c.invert(), a, u),
                f,
                h = i.length - 1;
              (f = i.length && i[h].merge(d)) ? (i[h] = f) : i.push(d);
            }
          } else o.map && r--;
        },
        this.items.length,
        0,
      ),
      new Me(Z.from(i.reverse()), s)
    );
  }
}
Me.empty = new Me(Z.empty, 0);
function Up(n, e) {
  let t;
  return (
    n.forEach((r, i) => {
      if (r.selection && e-- == 0) return ((t = i), !1);
    }),
    n.slice(t)
  );
}
class Te {
  constructor(e, t, r, i) {
    ((this.map = e),
      (this.step = t),
      (this.selection = r),
      (this.mirrorOffset = i));
  }
  merge(e) {
    if (this.step && e.step && !e.selection) {
      let t = e.step.merge(this.step);
      if (t) return new Te(t.getMap().invert(), t, this.selection);
    }
  }
}
class Ge {
  constructor(e, t, r, i, s) {
    ((this.done = e),
      (this.undone = t),
      (this.prevRanges = r),
      (this.prevTime = i),
      (this.prevComposition = s));
  }
}
const Kp = 20;
function Jp(n, e, t, r) {
  let i = t.getMeta(st),
    s;
  if (i) return i.historyState;
  t.getMeta(tu) && (n = new Ge(n.done, n.undone, null, 0, -1));
  let o = t.getMeta("appendedTransaction");
  if (t.steps.length == 0) return n;
  if (o && o.getMeta(st))
    return o.getMeta(st).redo
      ? new Ge(
          n.done.addTransform(t, void 0, r, dr(e)),
          n.undone,
          Ml(t.mapping.maps),
          n.prevTime,
          n.prevComposition,
        )
      : new Ge(
          n.done,
          n.undone.addTransform(t, void 0, r, dr(e)),
          null,
          n.prevTime,
          n.prevComposition,
        );
  if (
    t.getMeta("addToHistory") !== !1 &&
    !(o && o.getMeta("addToHistory") === !1)
  ) {
    let l = t.getMeta("composition"),
      a =
        n.prevTime == 0 ||
        (!o &&
          n.prevComposition != l &&
          (n.prevTime < (t.time || 0) - r.newGroupDelay ||
            !Gp(t, n.prevRanges))),
      c = o ? zi(n.prevRanges, t.mapping) : Ml(t.mapping.maps);
    return new Ge(
      n.done.addTransform(t, a ? e.selection.getBookmark() : void 0, r, dr(e)),
      Me.empty,
      c,
      t.time,
      l ?? n.prevComposition,
    );
  } else
    return (s = t.getMeta("rebased"))
      ? new Ge(
          n.done.rebased(t, s),
          n.undone.rebased(t, s),
          zi(n.prevRanges, t.mapping),
          n.prevTime,
          n.prevComposition,
        )
      : new Ge(
          n.done.addMaps(t.mapping.maps),
          n.undone.addMaps(t.mapping.maps),
          zi(n.prevRanges, t.mapping),
          n.prevTime,
          n.prevComposition,
        );
}
function Gp(n, e) {
  if (!e) return !1;
  if (!n.docChanged) return !0;
  let t = !1;
  return (
    n.mapping.maps[0].forEach((r, i) => {
      for (let s = 0; s < e.length; s += 2)
        r <= e[s + 1] && i >= e[s] && (t = !0);
    }),
    t
  );
}
function Ml(n) {
  let e = [];
  for (let t = n.length - 1; t >= 0 && e.length == 0; t--)
    n[t].forEach((r, i, s, o) => e.push(s, o));
  return e;
}
function zi(n, e) {
  if (!n) return null;
  let t = [];
  for (let r = 0; r < n.length; r += 2) {
    let i = e.map(n[r], 1),
      s = e.map(n[r + 1], -1);
    i <= s && t.push(i, s);
  }
  return t;
}
function Yp(n, e, t) {
  let r = dr(e),
    i = st.get(e).spec.config,
    s = (t ? n.undone : n.done).popEvent(e, r);
  if (!s) return null;
  let o = s.selection.resolve(s.transform.doc),
    l = (t ? n.done : n.undone).addTransform(
      s.transform,
      e.selection.getBookmark(),
      i,
      r,
    ),
    a = new Ge(t ? l : s.remaining, t ? s.remaining : l, null, 0, -1);
  return s.transform.setSelection(o).setMeta(st, { redo: t, historyState: a });
}
let Fi = !1,
  El = null;
function dr(n) {
  let e = n.plugins;
  if (El != e) {
    ((Fi = !1), (El = e));
    for (let t = 0; t < e.length; t++)
      if (e[t].spec.historyPreserveItems) {
        Fi = !0;
        break;
      }
  }
  return Fi;
}
function Xp(n) {
  return n.setMeta(tu, !0);
}
const st = new K("history"),
  tu = new K("closeHistory");
function Qp(n = {}) {
  return (
    (n = { depth: n.depth || 100, newGroupDelay: n.newGroupDelay || 500 }),
    new V({
      key: st,
      state: {
        init() {
          return new Ge(Me.empty, Me.empty, null, 0, -1);
        },
        apply(e, t, r) {
          return Jp(t, r, e, n);
        },
      },
      config: n,
      props: {
        handleDOMEvents: {
          beforeinput(e, t) {
            let r = t.inputType,
              i = r == "historyUndo" ? ru : r == "historyRedo" ? iu : null;
            return !i || !e.editable
              ? !1
              : (t.preventDefault(), i(e.state, e.dispatch));
          },
        },
      },
    })
  );
}
function nu(n, e) {
  return (t, r) => {
    let i = st.getState(t);
    if (!i || (n ? i.undone : i.done).eventCount == 0) return !1;
    if (r) {
      let s = Yp(i, t, n);
      s && r(e ? s.scrollIntoView() : s);
    }
    return !0;
  };
}
const ru = nu(!1, !0),
  iu = nu(!0, !0);
function Zp(n) {
  return n.getMeta(st) != null;
}
function hi(n) {
  const { state: e, transaction: t } = n;
  let { selection: r } = t,
    { doc: i } = t,
    { storedMarks: s } = t;
  return {
    ...e,
    apply: e.apply.bind(e),
    applyTransaction: e.applyTransaction.bind(e),
    plugins: e.plugins,
    schema: e.schema,
    reconfigure: e.reconfigure.bind(e),
    toJSON: e.toJSON.bind(e),
    get storedMarks() {
      return s;
    },
    get selection() {
      return r;
    },
    get doc() {
      return i;
    },
    get tr() {
      return ((r = t.selection), (i = t.doc), (s = t.storedMarks), t);
    },
  };
}
var Jt = class su {
  constructor(e) {
    ((this.editor = e.editor),
      (this.rawCommands = this.editor.extensionManager.commands),
      (this.customState = e.state));
  }
  get hasCustomState() {
    return !!this.customState;
  }
  get state() {
    return this.customState || this.editor.state;
  }
  get commands() {
    const { rawCommands: e, editor: t, state: r } = this,
      { view: i } = t,
      { tr: s } = r,
      o = this.buildProps(s);
    return Object.fromEntries(
      Object.entries(e).map(([l, a]) => [
        l,
        (...u) => {
          const d = a(...u)(o);
          return (
            !s.getMeta("preventDispatch") &&
              !this.hasCustomState &&
              i.dispatch(s),
            d
          );
        },
      ]),
    );
  }
  get chain() {
    return () => this.createChain();
  }
  get can() {
    return () => this.createCan();
  }
  createChain(e, t = !0) {
    const { rawCommands: r, editor: i, state: s } = this,
      { view: o } = i,
      l = [],
      a = !!e,
      c = e || s.tr,
      u = () => (
        !a &&
          t &&
          !c.getMeta("preventDispatch") &&
          !this.hasCustomState &&
          o.dispatch(c),
        l.every((f) => f === !0)
      ),
      d = {
        ...Object.fromEntries(
          Object.entries(r).map(([f, h]) => [
            f,
            (...g) => {
              const m = this.buildProps(c, t),
                y = h(...g)(m);
              return (l.push(y), d);
            },
          ]),
        ),
        run: u,
      };
    return d;
  }
  static createFakeChain() {
    const e = new Proxy(
      {},
      {
        get: (t, r) => {
          if (r !== "then") return r === "run" ? () => !1 : () => e;
        },
      },
    );
    return e;
  }
  createCan(e) {
    const { rawCommands: t, state: r } = this,
      i = !1,
      s = e || r.tr,
      o = this.buildProps(s, i);
    return {
      ...Object.fromEntries(
        Object.entries(t).map(([l, a]) => [
          l,
          (...c) => a(...c)({ ...o, dispatch: void 0 }),
        ]),
      ),
      chain: () => this.createChain(s, i),
    };
  }
  static createFallbackCan() {
    const e = su.createFakeChain();
    return new Proxy(
      { chain: () => e },
      {
        get: (t, r) => {
          if (r !== "then") return r === "chain" ? t.chain : () => !1;
        },
      },
    );
  }
  buildProps(e, t = !0) {
    const { rawCommands: r, editor: i, state: s } = this,
      { view: o } = i,
      l = {
        tr: e,
        editor: i,
        view: o,
        state: hi({ state: s, transaction: e }),
        dispatch: t ? () => {} : void 0,
        chain: () => this.createChain(e, t),
        can: () => this.createCan(e),
        get commands() {
          return Object.fromEntries(
            Object.entries(r).map(([a, c]) => [a, (...u) => c(...u)(l)]),
          );
        },
      };
    return l;
  }
};
const em =
    () =>
    ({ editor: n, view: e }) => (
      requestAnimationFrame(() => {
        if (!n.isDestroyed) {
          var t;
          (e.dom.blur(),
            (t = window) === null ||
              t === void 0 ||
              (t = t.getSelection()) === null ||
              t === void 0 ||
              t.removeAllRanges());
        }
      }),
      !0
    ),
  tm =
    (n = !0) =>
    ({ commands: e }) =>
      e.setContent("", { emitUpdate: n }),
  nm =
    () =>
    ({ tr: n, dispatch: e }) => {
      const { selection: t } = n,
        { ranges: r } = t;
      if (!e) return !0;
      const i = n.mapping.maps.length;
      return (
        r.forEach(({ $from: s, $to: o }) => {
          const l = s.pos,
            a = o.pos,
            c = n.mapping.slice(i);
          let u = 1;
          n.doc.nodesBetween(c.map(l), c.map(a), (d, f) => {
            u = Math.max(u, n.doc.resolve(f).depth + 1);
          });
          for (let d = 0; d < u; d += 1) {
            const f = n.doc,
              h = n.mapping.maps.length,
              p = n.mapping.slice(i);
            let g = h,
              m = n.mapping.slice(h);
            const y = p.map(l),
              k = p.map(a);
            if (
              (f.nodesBetween(y, k, (x, w) => {
                if (x.type.isText) return;
                n.mapping.maps.length !== g &&
                  ((g = n.mapping.maps.length), (m = n.mapping.slice(h)));
                const M = n.doc.resolve(m.map(w)),
                  D = n.doc.resolve(m.map(w + x.nodeSize)),
                  E = M.blockRange(D);
                if (!E) return;
                const I = nn(E);
                if (x.type.isTextblock) {
                  const { defaultType: L } = M.parent.contentMatchAt(M.index()),
                    F = n.doc.nodeAt(E.start);
                  L &&
                    F &&
                    !F.hasMarkup(L) &&
                    L.validContent(F.content) &&
                    n.setNodeMarkup(E.start, L);
                }
                (I || I === 0) && n.lift(E, I);
              }),
              n.doc.eq(f))
            )
              break;
          }
        }),
        !0
      );
    },
  rm = (n) => (e) => n(e),
  im =
    () =>
    ({ state: n, dispatch: e }) =>
      fc(n, e),
  sm =
    (n, e) =>
    ({ editor: t, tr: r }) => {
      const { state: i } = t,
        s = i.doc.slice(n.from, n.to);
      r.deleteRange(n.from, n.to);
      const o = r.mapping.map(e);
      return (
        r.insert(o, s.content),
        r.setSelection(new T(r.doc.resolve(Math.max(o - 1, 0)))),
        !0
      );
    },
  om =
    () =>
    ({ tr: n, dispatch: e }) => {
      const { selection: t } = n,
        r = t.$anchor.node();
      if (r.content.size > 0) return !1;
      const i = n.selection.$anchor;
      for (let s = i.depth; s > 0; s -= 1)
        if (i.node(s).type === r.type) {
          if (e) {
            const o = i.before(s),
              l = i.after(s);
            n.delete(o, l).scrollIntoView();
          }
          return !0;
        }
      return !1;
    };
function Y(n, e) {
  if (typeof n == "string") {
    if (!e.nodes[n])
      throw Error(
        `There is no node type named '${n}'. Maybe you forgot to add the extension?`,
      );
    return e.nodes[n];
  }
  return n;
}
const lm =
    (n) =>
    ({ tr: e, state: t, dispatch: r }) => {
      const i = Y(n, t.schema),
        s = e.selection.$anchor;
      for (let o = s.depth; o > 0; o -= 1)
        if (s.node(o).type === i) {
          if (r) {
            const l = s.before(o),
              a = s.after(o);
            e.delete(l, a).scrollIntoView();
          }
          return !0;
        }
      return !1;
    },
  am =
    (n) =>
    ({ tr: e, dispatch: t }) => {
      const { from: r, to: i } = n;
      return (t && e.delete(r, i), !0);
    },
  cm = (n) => (n.content ? /^text(\*|\+)/.test(n.content) : !1),
  Tl = (n, e, t) => {
    if (
      !n.parent.isInline ||
      (t === "left" && n.pos > n.start()) ||
      (t === "right" && n.pos < n.end())
    )
      return n.pos;
    const r = e.nodes[n.parent.type.name].spec;
    return cm(r) ? (t === "left" ? n.start() - 1 : n.end() + 1) : n.pos;
  },
  um = (n, e, t) => ({ from: Tl(n, t, "left"), to: Tl(e, t, "right") }),
  dm =
    () =>
    ({ state: n, dispatch: e }) => {
      if (n.selection.empty) return !1;
      if (e) {
        const t = n.tr,
          { ranges: r } = n.selection,
          i =
            n.selection instanceof T
              ? n.selection.$from.marksAcross(n.selection.$to)
              : null,
          s = t.steps.length;
        (r.forEach((o) => {
          const l = t.mapping.slice(s),
            a = t.doc.resolve(l.map(o.$from.pos)),
            c = t.doc.resolve(l.map(o.$to.pos)),
            { from: u, to: d } = um(a, c, n.schema);
          t.deleteRange(u, d);
        }),
          t.selection.empty ||
            t.setSelection(T.near(t.doc.resolve(t.selection.from))),
          i && t.ensureMarks(i),
          t.scrollIntoView(),
          e(t));
      }
      return !0;
    },
  fm =
    () =>
    ({ commands: n }) =>
      n.keyboardShortcut("Enter"),
  hm =
    () =>
    ({ state: n, dispatch: e }) =>
      $f(n, e);
function Xs(n) {
  return Object.prototype.toString.call(n) === "[object RegExp]";
}
function Ar(n, e, t = { strict: !0 }) {
  const r = Object.keys(e);
  return r.length
    ? r.every((i) =>
        t.strict ? e[i] === n[i] : Xs(e[i]) ? e[i].test(n[i]) : e[i] === n[i],
      )
    : !0;
}
function ou(n, e, t = {}) {
  return n.find(
    (r) =>
      r.type === e &&
      Ar(Object.fromEntries(Object.keys(t).map((i) => [i, r.attrs[i]])), t),
  );
}
function Al(n, e, t = {}) {
  return !!ou(n, e, t);
}
function Qs(n, e, t) {
  if (!n || !e) return;
  let r = n.parent.childAfter(n.parentOffset);
  if (
    ((!r.node || !r.node.marks.some((a) => a.type === e)) &&
      (r = n.parent.childBefore(n.parentOffset)),
    !r.node || !r.node.marks.some((a) => a.type === e))
  )
    return;
  if (!t) {
    const a = r.node.marks.find((c) => c.type === e);
    a && (t = a.attrs);
  }
  if (!ou([...r.node.marks], e, t)) return;
  let i = r.index,
    s = n.start() + r.offset,
    o = i + 1,
    l = s + r.node.nodeSize;
  for (; i > 0 && Al([...n.parent.child(i - 1).marks], e, t);)
    ((i -= 1), (s -= n.parent.child(i).nodeSize));
  for (; o < n.parent.childCount && Al([...n.parent.child(o).marks], e, t);)
    ((l += n.parent.child(o).nodeSize), (o += 1));
  return { from: s, to: l };
}
function qe(n, e) {
  if (typeof n == "string") {
    if (!e.marks[n])
      throw Error(
        `There is no mark type named '${n}'. Maybe you forgot to add the extension?`,
      );
    return e.marks[n];
  }
  return n;
}
const pm =
    (n, e) =>
    ({ tr: t, state: r, dispatch: i }) => {
      const s = qe(n, r.schema),
        { doc: o, selection: l } = t,
        { $from: a, from: c, to: u } = l;
      if (i) {
        const d = Qs(a, s, e);
        if (d && d.from <= c && d.to >= u) {
          const f = T.create(o, d.from, d.to);
          t.setSelection(f);
        }
      }
      return !0;
    },
  mm = (n) => (e) => {
    const t = typeof n == "function" ? n(e) : n;
    for (let r = 0; r < t.length; r += 1) if (t[r](e)) return !0;
    return !1;
  };
function lu(n) {
  return n instanceof T;
}
function yt(n = 0, e = 0, t = 0) {
  return Math.min(Math.max(n, e), t);
}
function gs(n, e = null) {
  if (!e) return null;
  const t = N.atStart(n),
    r = N.atEnd(n);
  if (e === "start" || e === !0) return t;
  if (e === "end") return r;
  const i = t.from,
    s = r.to;
  return e === "all"
    ? T.create(n, yt(0, i, s), yt(n.content.size, i, s))
    : T.create(n, yt(e, i, s), yt(e, i, s));
}
function ys() {
  return (
    ["Android"].includes(navigator.platform) ||
    /android/i.test(navigator.userAgent)
  );
}
function Pn() {
  return (
    [
      "iPad Simulator",
      "iPhone Simulator",
      "iPod Simulator",
      "iPad",
      "iPhone",
      "iPod",
    ].includes(navigator.platform) ||
    (navigator.userAgent.includes("Mac") && "ontouchend" in document)
  );
}
function gm() {
  return typeof navigator < "u"
    ? /^((?!chrome|android).)*safari/i.test(navigator.userAgent)
    : !1;
}
const ym =
    (n = null, e = {}) =>
    ({ editor: t, view: r, tr: i, dispatch: s }) => {
      e = { scrollIntoView: !0, ...e };
      const o = () => {
        ((Pn() || ys()) && r.dom.focus(),
          gm() && !Pn() && !ys() && r.dom.focus({ preventScroll: !0 }),
          requestAnimationFrame(() => {
            t.isDestroyed ||
              (r.focus(), e?.scrollIntoView && t.commands.scrollIntoView());
          }));
      };
      try {
        if ((r.hasFocus() && n === null) || n === !1) return !0;
      } catch {
        return !1;
      }
      if (s && n === null && !lu(t.state.selection)) return (o(), !0);
      const l = gs(i.doc, n) || t.state.selection,
        a = t.state.selection.eq(l);
      return (
        s &&
          (a || i.setSelection(l),
          a && i.storedMarks && i.setStoredMarks(i.storedMarks),
          o()),
        !0
      );
    },
  bm = (n, e) => (t) => n.every((r, i) => e(r, { ...t, index: i })),
  km =
    (n, e) =>
    ({ tr: t, commands: r }) =>
      r.insertContentAt({ from: t.selection.from, to: t.selection.to }, n, e),
  au = (n) => {
    const e = n.childNodes;
    for (let t = e.length - 1; t >= 0; t -= 1) {
      const r = e[t];
      r.nodeType === 3 && r.nodeValue && /^(\n\s\s|\n)$/.test(r.nodeValue)
        ? n.removeChild(r)
        : r.nodeType === 1 && au(r);
    }
    return n;
  };
function Xn(n) {
  if (typeof window > "u")
    throw new Error(
      "[tiptap error]: there is no window object available, so this function cannot be used",
    );
  const e = `<body>${n}</body>`,
    t = new window.DOMParser().parseFromString(e, "text/html").body;
  return au(t);
}
function cu(n) {
  return typeof n?.nodesBetween == "function";
}
function Zt(n, e, t) {
  if (cu(n)) return n;
  const r = typeof n == "object" && n !== null;
  t = { slice: !0, parseOptions: {}, ...t };
  const i = typeof n == "string";
  if (r)
    try {
      if (Array.isArray(n) && n.length > 0)
        return b.fromArray(n.map((o) => e.nodeFromJSON(o)));
      const s = e.nodeFromJSON(n);
      return (t.errorOnInvalidContent && s.check(), s);
    } catch (s) {
      if (t.errorOnInvalidContent)
        throw new Error("[tiptap error]: Invalid JSON content", { cause: s });
      return (
        console.warn(
          "[tiptap warn]: Invalid content.",
          "Passed value:",
          n,
          "Error:",
          s,
        ),
        Zt("", e, t)
      );
    }
  if (i) {
    if (t.errorOnInvalidContent) {
      let o = !1,
        l = "";
      const a = new ar({
        topNode: e.spec.topNode,
        marks: e.spec.marks,
        nodes: e.spec.nodes.append({
          __tiptap__private__unknown__catch__all__node: {
            content: "inline*",
            group: "block",
            parseDOM: [
              {
                tag: "*",
                getAttrs: (c) => (
                  (o = !0),
                  (l = typeof c == "string" ? c : c.outerHTML),
                  null
                ),
              },
            ],
          },
        }),
      });
      if (
        (t.slice
          ? et.fromSchema(a).parseSlice(Xn(n), t.parseOptions)
          : et.fromSchema(a).parse(Xn(n), t.parseOptions),
        t.errorOnInvalidContent && o)
      )
        throw new Error("[tiptap error]: Invalid HTML content", {
          cause: new Error(`Invalid element found: ${l}`),
        });
    }
    const s = et.fromSchema(e);
    return t.slice
      ? s.parseSlice(Xn(n), t.parseOptions).content
      : s.parse(Xn(n), t.parseOptions);
  }
  return Zt("", e, t);
}
function uu(n) {
  return !("type" in n);
}
function du(n, e, t) {
  const r = n.steps.length - 1;
  if (r < e) return;
  const i = n.steps[r];
  if (!(i instanceof _ || i instanceof Q)) return;
  const s = n.mapping.maps[r];
  let o = 0;
  (s.forEach((l, a, c, u) => {
    o === 0 && (o = u);
  }),
    n.setSelection(N.near(n.doc.resolve(o), t)));
}
const Sm =
  (n, e, t) =>
  ({ tr: r, dispatch: i, editor: s }) => {
    if (i) {
      t = {
        parseOptions: s.options.parseOptions,
        updateSelection: !0,
        applyInputRules: !1,
        applyPasteRules: !1,
        ...t,
      };
      let l;
      const a = (m) => {
          s.emit("contentError", {
            editor: s,
            error: m,
            disableCollaboration: () => {
              "collaboration" in s.storage &&
                typeof s.storage.collaboration == "object" &&
                s.storage.collaboration &&
                (s.storage.collaboration.isDisabled = !0);
            },
          });
        },
        c = { preserveWhitespace: "full", ...t.parseOptions };
      if (
        !t.errorOnInvalidContent &&
        !s.options.enableContentCheck &&
        s.options.emitContentError
      )
        try {
          Zt(e, s.schema, { parseOptions: c, errorOnInvalidContent: !0 });
        } catch (m) {
          a(m);
        }
      try {
        var o;
        l = Zt(e, s.schema, {
          parseOptions: c,
          errorOnInvalidContent:
            (o = t.errorOnInvalidContent) !== null && o !== void 0
              ? o
              : s.options.enableContentCheck,
        });
      } catch (m) {
        return (a(m), !1);
      }
      let { from: u, to: d } =
          typeof n == "number"
            ? { from: n, to: n }
            : { from: n.from, to: n.to },
        f = !0,
        h = !0;
      const p = uu(l) ? l.content : [l];
      if (
        (p.forEach((m) => {
          (m.check(),
            (f = f ? m.isText && m.marks.length === 0 : !1),
            (h = h ? m.isBlock : !1));
        }),
        u === d && h)
      ) {
        const { parent: m } = r.doc.resolve(u);
        m.isTextblock &&
          !m.type.spec.code &&
          !m.childCount &&
          ((u -= 1), (d += 1));
      }
      let g;
      if (f)
        (Array.isArray(e)
          ? (g = e.map((m) => m.text || "").join(""))
          : cu(e)
            ? (g = p
                .map((m) => {
                  var y;
                  return (y = m.text) !== null && y !== void 0 ? y : "";
                })
                .join(""))
            : typeof e == "object" && e && e.text
              ? (g = e.text)
              : (g = e),
          r.insertText(g, u, d));
      else {
        g = b.from(p);
        const m = r.doc.resolve(u),
          y = m.node(),
          k = m.parentOffset === 0,
          x = y.isText || y.isTextblock,
          w = y.content.size > 0;
        (k && x && w && h && (u = Math.max(0, u - 1)), r.replaceWith(u, d, p));
      }
      (t.updateSelection && du(r, r.steps.length - 1, -1),
        t.applyInputRules && r.setMeta("applyInputRules", { from: u, text: g }),
        t.applyPasteRules &&
          r.setMeta("applyPasteRules", { from: u, text: g }));
    }
    return !0;
  };
function fu(n) {
  for (let e = 0; e < n.edgeCount; e += 1) {
    const { type: t } = n.edge(e);
    if (t.isTextblock && !t.hasRequiredAttrs()) return t;
  }
  return null;
}
const xm =
    (n = {}) =>
    ({ tr: e, dispatch: t, editor: r }) => {
      const { pos: i, attrs: s, content: o, updateSelection: l = !0 } = n;
      let a;
      typeof i == "number"
        ? (a = e.doc.resolve(i))
        : i
          ? (a = i)
          : (a = e.selection.$from);
      const c = fu(a.parent.contentMatchAt(a.index()));
      if (!c) return !1;
      const u = Object.keys(c.spec.attrs || {}),
        d = s
          ? Object.fromEntries(Object.entries(s).filter(([h]) => u.includes(h)))
          : {};
      let f;
      if (o) {
        const h = Zt(o, r.schema);
        f = c.createAndFill(d, h);
      } else f = c.createAndFill(d);
      return f
        ? (t && (e.insert(a.pos, f), l && du(e, e.steps.length - 1, -1)), !0)
        : !1;
    },
  wm =
    () =>
    ({ state: n, dispatch: e }) =>
      Lf(n, e),
  Cm =
    () =>
    ({ state: n, dispatch: e }) =>
      Pf(n, e),
  vm =
    () =>
    ({ state: n, dispatch: e }) =>
      rc(n, e),
  Mm =
    () =>
    ({ state: n, dispatch: e }) =>
      cc(n, e),
  hu = (n, e) => {
    const t = n.resolve(e),
      r = t.nodeBefore,
      i = t.nodeAfter;
    return !r || !i ? !1 : !r.type.spec.isolating && !i.type.spec.isolating;
  },
  Em =
    () =>
    ({ state: n, dispatch: e, tr: t }) => {
      try {
        const r = li(n.doc, n.selection.$from.pos, -1);
        return r == null || !hu(n.doc, r) ? !1 : (t.join(r, 2), e && e(t), !0);
      } catch {
        return !1;
      }
    },
  Tm =
    () =>
    ({ state: n, dispatch: e, tr: t }) => {
      try {
        const r = li(n.doc, n.selection.$from.pos, 1);
        return r == null || !hu(n.doc, r) ? !1 : (t.join(r, 2), e && e(t), !0);
      } catch {
        return !1;
      }
    },
  Am =
    () =>
    ({ state: n, dispatch: e }) =>
      ic(n, e),
  Om =
    () =>
    ({ state: n, dispatch: e }) =>
      sc(n, e);
function pu() {
  return typeof navigator < "u" ? /Mac/.test(navigator.platform) : !1;
}
function Nm(n) {
  const e = n.split(/-(?!$)/);
  let t = e[e.length - 1];
  t === "Space" && (t = " ");
  let r, i, s, o;
  for (let l = 0; l < e.length - 1; l += 1) {
    const a = e[l];
    if (/^(cmd|meta|m)$/i.test(a)) o = !0;
    else if (/^a(lt)?$/i.test(a)) r = !0;
    else if (/^(c|ctrl|control)$/i.test(a)) i = !0;
    else if (/^s(hift)?$/i.test(a)) s = !0;
    else if (/^mod$/i.test(a)) Pn() || pu() ? (o = !0) : (i = !0);
    else throw new Error(`Unrecognized modifier name: ${a}`);
  }
  return (
    r && (t = `Alt-${t}`),
    i && (t = `Ctrl-${t}`),
    o && (t = `Meta-${t}`),
    s && (t = `Shift-${t}`),
    t
  );
}
const Dm =
  (n) =>
  ({ editor: e, view: t, tr: r, dispatch: i }) => {
    const s = Nm(n).split(/-(?!$)/),
      o = s.find((c) => !["Alt", "Ctrl", "Meta", "Shift"].includes(c)),
      l = new KeyboardEvent("keydown", {
        key: o === "Space" ? " " : o,
        altKey: s.includes("Alt"),
        ctrlKey: s.includes("Ctrl"),
        metaKey: s.includes("Meta"),
        shiftKey: s.includes("Shift"),
        bubbles: !0,
        cancelable: !0,
      }),
      a = e.captureTransaction(() => {
        t.someProp("handleKeyDown", (c) => c(t, l));
      });
    return (
      a?.steps.forEach((c) => {
        const u = c.map(r.mapping);
        u && i && r.maybeStep(u);
      }),
      !0
    );
  };
function We(n, e, t = {}) {
  const { from: r, to: i, empty: s } = n.selection,
    o = e ? Y(e, n.schema) : null,
    l = [];
  n.doc.nodesBetween(r, i, (u, d) => {
    if (u.isText) return;
    const f = Math.max(r, d),
      h = Math.min(i, d + u.nodeSize);
    l.push({ node: u, from: f, to: h });
  });
  const a = i - r,
    c = l
      .filter((u) => (o ? o.name === u.node.type.name : !0))
      .filter((u) => Ar(u.node.attrs, t, { strict: !1 }));
  return s ? !!c.length : c.reduce((u, d) => u + d.to - d.from, 0) >= a;
}
const Rm =
    (n, e = {}) =>
    ({ state: t, dispatch: r }) =>
      We(t, Y(n, t.schema), e) ? Bf(t, r) : !1,
  Im =
    () =>
    ({ state: n, dispatch: e }) =>
      hc(n, e),
  Lm =
    (n) =>
    ({ state: e, dispatch: t }) => {
      const r = Y(n, e.schema);
      return Jf(r)(e, t);
    },
  Pm =
    () =>
    ({ state: n, dispatch: e }) =>
      dc(n, e);
function pi(n, e) {
  return e.nodes[n] ? "node" : e.marks[n] ? "mark" : null;
}
function Ol(n, e) {
  const t = typeof e == "string" ? [e] : e;
  return Object.keys(n).reduce(
    (r, i) => (t.includes(i) || (r[i] = n[i]), r),
    {},
  );
}
const Bm =
    (n, e) =>
    ({ tr: t, state: r, dispatch: i }) => {
      let s = null,
        o = null;
      const l = pi(typeof n == "string" ? n : n.name, r.schema);
      if (!l) return !1;
      (l === "node" && (s = Y(n, r.schema)),
        l === "mark" && (o = qe(n, r.schema)));
      let a = !1;
      return (
        t.selection.ranges.forEach((c) => {
          r.doc.nodesBetween(c.$from.pos, c.$to.pos, (u, d) => {
            (s &&
              s === u.type &&
              ((a = !0), i && t.setNodeMarkup(d, void 0, Ol(u.attrs, e))),
              o &&
                u.marks.length &&
                u.marks.forEach((f) => {
                  o === f.type &&
                    ((a = !0),
                    i &&
                      t.addMark(d, d + u.nodeSize, o.create(Ol(f.attrs, e))));
                }));
          });
        }),
        a
      );
    },
  $m =
    () =>
    ({ tr: n, dispatch: e }) => (e && n.scrollIntoView(), !0),
  zm =
    () =>
    ({ tr: n, dispatch: e }) => {
      if (e) {
        const t = new ye(n.doc);
        n.setSelection(t);
      }
      return !0;
    },
  Fm =
    () =>
    ({ state: n, dispatch: e }) =>
      lc(n, e),
  Vm =
    () =>
    ({ state: n, dispatch: e }) =>
      uc(n, e),
  jm =
    () =>
    ({ state: n, dispatch: e }) =>
      Vf(n, e),
  Hm =
    () =>
    ({ state: n, dispatch: e }) =>
      _f(n, e),
  _m =
    () =>
    ({ state: n, dispatch: e }) =>
      Hf(n, e);
function bs(n, e, t = {}, r = {}) {
  return Zt(n, e, {
    slice: !1,
    parseOptions: t,
    errorOnInvalidContent: r.errorOnInvalidContent,
  });
}
const Wm =
  (
    n,
    { errorOnInvalidContent: e, emitUpdate: t = !0, parseOptions: r = {} } = {},
  ) =>
  ({ editor: i, tr: s, dispatch: o, commands: l }) => {
    const { doc: a } = s;
    if (r.preserveWhitespace !== "full") {
      const c = bs(n, i.schema, r, {
        errorOnInvalidContent: e ?? i.options.enableContentCheck,
      });
      if (o) {
        const u = uu(c) ? c.content : [c];
        s.replaceWith(0, a.content.size, u).setMeta("preventUpdate", !t);
      }
      return !0;
    }
    return (
      o && s.setMeta("preventUpdate", !t),
      l.insertContentAt({ from: 0, to: a.content.size }, n, {
        parseOptions: r,
        errorOnInvalidContent: e ?? i.options.enableContentCheck,
      })
    );
  };
function mu(n, e) {
  const t = qe(e, n.schema),
    { from: r, to: i, empty: s } = n.selection,
    o = [];
  s
    ? (n.storedMarks && o.push(...n.storedMarks),
      o.push(...n.selection.$head.marks()))
    : n.doc.nodesBetween(r, i, (a) => {
        o.push(...a.marks);
      });
  const l = o.find((a) => a.type.name === t.name);
  return l ? { ...l.attrs } : {};
}
function gu(n, e) {
  const t = new Ya(n);
  return (
    e.forEach((r) => {
      r.steps.forEach((i) => {
        t.step(i);
      });
    }),
    t
  );
}
function qm(n, e, t) {
  const r = [];
  return (
    n.nodesBetween(e.from, e.to, (i, s) => {
      t(i) && r.push({ node: i, pos: s });
    }),
    r
  );
}
function Um(n, e) {
  for (let t = n.depth; t > 0; t -= 1) {
    const r = n.node(t);
    if (e(r))
      return {
        pos: t > 0 ? n.before(t) : 0,
        start: n.start(t),
        depth: t,
        node: r,
      };
  }
}
function mi(n) {
  return (e) => Um(e.$from, n);
}
function v(n, e, t) {
  return n.config[e] === void 0 && n.parent
    ? v(n.parent, e, t)
    : typeof n.config[e] == "function"
      ? n.config[e].bind({ ...t, parent: n.parent ? v(n.parent, e, t) : null })
      : n.config[e];
}
function Zs(n) {
  return n
    .map((e) => {
      const t = v(e, "addExtensions", {
        name: e.name,
        options: e.options,
        storage: e.storage,
      });
      return t ? [e, ...Zs(t())] : e;
    })
    .flat(10);
}
function eo(n, e) {
  const t = Rt.fromSchema(e).serializeFragment(n),
    r = document.implementation.createHTMLDocument().createElement("div");
  return (r.appendChild(t), r.innerHTML);
}
function yu(n, e) {
  const t = new Map();
  for (const i of n) {
    var r;
    const s = (r = t.get(i.type)) !== null && r !== void 0 ? r : new Map();
    (s.set(i.name, i), t.set(i.type, s));
  }
  return [...Object.values(e.nodes), ...Object.values(e.marks)].flatMap((i) => {
    var s;
    return Object.entries(
      (s = i.spec.attrs) !== null && s !== void 0 ? s : {},
    ).map(([o, l]) => {
      var a;
      const c =
          (a = t.get(i.name)) === null || a === void 0 ? void 0 : a.get(o),
        u = Object.hasOwn(l, "default");
      return {
        type: i.name,
        name: o,
        attribute: {
          rendered: !0,
          renderHTML: null,
          parseHTML: null,
          keepOnSplit: !0,
          ...c?.attribute,
          default: l.default,
          isRequired: !u,
          validate: l.validate,
        },
      };
    });
  });
}
const Km = {
    content: "string",
    marks: "string",
    group: "string",
    inline: "boolean",
    atom: "boolean",
    selectable: "boolean",
    draggable: "boolean",
    code: "boolean",
    whitespace: ["pre", "normal"],
    definingAsContext: "boolean",
    definingForContent: "boolean",
    defining: "boolean",
    isolating: "boolean",
    linebreakReplacement: "boolean",
  },
  Jm = {
    inclusive: "boolean",
    excludes: "string",
    group: "string",
    spanning: "boolean",
    code: "boolean",
  };
function Gm(n, e, t) {
  return Object.fromEntries(
    Object.entries(e).flatMap(([r, i]) => {
      const s = n[r];
      if (s === void 0) return [];
      if (
        !(typeof i == "string"
          ? typeof s === i
          : typeof s == "string" && i.includes(s))
      )
        throw new RangeError(`Invalid schemaSpec field '${t}.${r}'`);
      return [[r, s]];
    }),
  );
}
function Nl(n, e, t, r) {
  return {
    ...Object.fromEntries(
      Object.entries(e).filter(([i]) => i !== "attrs" && !Object.hasOwn(r, i)),
    ),
    ...Gm(t, r, n),
    attrs: t.attrs,
  };
}
function Dl(n, e, t) {
  for (const r of Object.keys(e))
    if (!Object.hasOwn(n, r))
      throw new RangeError(
        `schemaSpec requires a local ${t} extension named '${r}'`,
      );
  for (const r of Object.keys(n))
    if (!Object.hasOwn(e, r))
      throw new RangeError(`Local ${t} extension '${r}' is not in schemaSpec`);
}
function Ym(n, e) {
  (Dl(n.nodes, e.nodes, "node"), Dl(n.marks, e.marks, "mark"));
  let t = e.spec.nodes,
    r = e.spec.marks;
  return (
    e.spec.nodes.forEach((i, s) => {
      t = t.update(i, Nl(i, n.nodes[i], s, Km));
    }),
    e.spec.marks.forEach((i, s) => {
      r = r.update(i, Nl(i, n.marks[i], s, Jm));
    }),
    { topNode: e.topNodeType.name, nodes: t, marks: r }
  );
}
function bu(n) {
  const e = n.filter((t, r) => n.indexOf(t) !== r);
  return Array.from(new Set(e));
}
function en(n) {
  return {
    baseExtensions: n.filter((e) => e.type === "extension"),
    nodeExtensions: n.filter((e) => e.type === "node"),
    markExtensions: n.filter((e) => e.type === "mark"),
  };
}
function to(n) {
  const e = [],
    { nodeExtensions: t, markExtensions: r } = en(n),
    i = [...t, ...r],
    s = {
      default: null,
      validate: void 0,
      rendered: !0,
      renderHTML: null,
      parseHTML: null,
      keepOnSplit: !0,
      isRequired: !1,
    },
    o = t.filter((c) => c.name !== "text").map((c) => c.name),
    l = r.map((c) => c.name),
    a = [...o, ...l];
  return (
    n.forEach((c) => {
      const u = v(c, "addGlobalAttributes", {
        name: c.name,
        options: c.options,
        storage: c.storage,
        extensions: i,
      });
      u &&
        u().forEach((d) => {
          let f;
          (Array.isArray(d.types)
            ? (f = d.types)
            : d.types === "*"
              ? (f = a)
              : d.types === "nodes"
                ? (f = o)
                : d.types === "marks"
                  ? (f = l)
                  : (f = []),
            f.forEach((h) => {
              Object.entries(d.attributes).forEach(([p, g]) => {
                e.push({ type: h, name: p, attribute: { ...s, ...g } });
              });
            }));
        });
    }),
    i.forEach((c) => {
      const u = v(c, "addAttributes", {
        name: c.name,
        options: c.options,
        storage: c.storage,
      });
      if (!u) return;
      const d = u();
      Object.entries(d).forEach(([f, h]) => {
        const p = { ...s, ...h };
        (typeof p?.default == "function" && (p.default = p.default()),
          p?.isRequired && p?.default === void 0 && delete p.default,
          e.push({ type: c.name, name: f, attribute: p }));
      });
    }),
    e
  );
}
function ks(n) {
  return typeof n == "function";
}
function B(n, e = void 0, ...t) {
  return ks(n) ? (e ? n.bind(e)(...t) : n(...t)) : n;
}
function Xm(n = {}) {
  return Object.keys(n).length === 0 && n.constructor === Object;
}
function Qm(n) {
  const e = [];
  let t = "",
    r = !1,
    i = !1,
    s = 0;
  const o = n.length;
  for (let l = 0; l < o; l += 1) {
    const a = n[l];
    if (a === "'" && !i) {
      ((r = !r), (t += a));
      continue;
    }
    if (a === '"' && !r) {
      ((i = !i), (t += a));
      continue;
    }
    if (!r && !i) {
      if (a === "(") {
        ((s += 1), (t += a));
        continue;
      }
      if (a === ")" && s > 0) {
        ((s -= 1), (t += a));
        continue;
      }
      if (a === ";" && s === 0) {
        (e.push(t), (t = ""));
        continue;
      }
    }
    t += a;
  }
  return (t && e.push(t), e);
}
function Rl(n) {
  const e = [],
    t = Qm(n || ""),
    r = t.length;
  for (let i = 0; i < r; i += 1) {
    const s = t[i],
      o = s.indexOf(":");
    if (o === -1) continue;
    const l = s.slice(0, o).trim(),
      a = s.slice(o + 1).trim();
    l && a && e.push([l, a]);
  }
  return e;
}
function X(...n) {
  return n
    .filter((e) => !!e)
    .reduce((e, t) => {
      const r = { ...e };
      return (
        Object.entries(t).forEach(([i, s]) => {
          if (i === "__proto__") {
            Object.defineProperty(r, i, {
              configurable: !0,
              enumerable: !0,
              value: s,
              writable: !0,
            });
            return;
          }
          if (!r[i]) {
            r[i] = s;
            return;
          }
          if (i === "class") {
            const o = s ? String(s).split(" ") : [],
              l = r[i] ? r[i].split(" ") : [],
              a = o.filter((c) => !l.includes(c));
            r[i] = [...l, ...a].join(" ");
          } else if (i === "style") {
            const o = new Map([...Rl(r[i]), ...Rl(s)]);
            r[i] = Array.from(o.entries())
              .map(([l, a]) => `${l}: ${a}`)
              .join("; ");
          } else r[i] = s;
        }),
        r
      );
    }, {});
}
function Bn(n, e) {
  return e
    .filter((t) => t.type === n.type.name)
    .filter((t) => t.attribute.rendered)
    .map((t) =>
      t.attribute.renderHTML
        ? t.attribute.renderHTML(n.attrs) || {}
        : { [t.name]: n.attrs[t.name] },
    )
    .reduce((t, r) => X(t, r), {});
}
function Zm(n) {
  return typeof n != "string"
    ? n
    : n.match(/^[+-]?(?:\d*\.)?\d+$/)
      ? Number(n)
      : n === "true"
        ? !0
        : n === "false"
          ? !1
          : n;
}
function Il(n, e) {
  return "style" in n
    ? n
    : {
        ...n,
        getAttrs: (t) => {
          const r = n.getAttrs ? n.getAttrs(t) : n.attrs;
          if (r === !1) return !1;
          const i = e.reduce((s, o) => {
            const l = o.attribute.parseHTML
              ? o.attribute.parseHTML(t)
              : Zm(t.getAttribute(o.name));
            return l == null ? s : { ...s, [o.name]: l };
          }, {});
          return { ...r, ...i };
        },
      };
}
function Ll(n) {
  return Object.fromEntries(
    Object.entries(n).filter(([e, t]) =>
      e === "attrs" && Xm(t) ? !1 : t != null,
    ),
  );
}
function Pl(n) {
  var e, t;
  const r = {};
  return (
    !(
      !(n == null || (e = n.attribute) === null || e === void 0) && e.isRequired
    ) &&
      "default" in (n?.attribute || {}) &&
      (r.default = n.attribute.default),
    (n == null || (t = n.attribute) === null || t === void 0
      ? void 0
      : t.validate) !== void 0 && (r.validate = n.attribute.validate),
    [n.name, r]
  );
}
function Bl(n, e, t = to(n)) {
  var r;
  const { nodeExtensions: i, markExtensions: s } = en(n);
  return {
    topNode:
      (r = i.find((o) => v(o, "topNode"))) === null || r === void 0
        ? void 0
        : r.name,
    nodes: Object.fromEntries(
      i.map((o) => {
        const l = t.filter((h) => h.type === o.name),
          a = {
            name: o.name,
            options: o.options,
            storage: o.storage,
            editor: e,
          },
          c = Ll({
            ...n.reduce((h, p) => {
              const g = v(p, "extendNodeSchema", a);
              return { ...h, ...(g ? g(o) : {}) };
            }, {}),
            content: B(v(o, "content", a)),
            marks: B(v(o, "marks", a)),
            group: B(v(o, "group", a)),
            inline: B(v(o, "inline", a)),
            atom: B(v(o, "atom", a)),
            selectable: B(v(o, "selectable", a)),
            draggable: B(v(o, "draggable", a)),
            code: B(v(o, "code", a)),
            whitespace: B(v(o, "whitespace", a)),
            linebreakReplacement: B(v(o, "linebreakReplacement", a)),
            defining: B(v(o, "defining", a)),
            isolating: B(v(o, "isolating", a)),
            attrs: Object.fromEntries(l.map(Pl)),
          }),
          u = B(v(o, "parseHTML", a));
        u && (c.parseDOM = u.map((h) => Il(h, l)));
        const d = v(o, "renderHTML", a);
        d && (c.toDOM = (h) => d({ node: h, HTMLAttributes: Bn(h, l) }));
        const f = v(o, "renderText", a);
        return (f && (c.toText = f), [o.name, c]);
      }),
    ),
    marks: Object.fromEntries(
      s.map((o) => {
        const l = t.filter((f) => f.type === o.name),
          a = {
            name: o.name,
            options: o.options,
            storage: o.storage,
            editor: e,
          },
          c = Ll({
            ...n.reduce((f, h) => {
              const p = v(h, "extendMarkSchema", a);
              return { ...f, ...(p ? p(o) : {}) };
            }, {}),
            inclusive: B(v(o, "inclusive", a)),
            excludes: B(v(o, "excludes", a)),
            group: B(v(o, "group", a)),
            spanning: B(v(o, "spanning", a)),
            code: B(v(o, "code", a)),
            attrs: Object.fromEntries(l.map(Pl)),
          }),
          u = B(v(o, "parseHTML", a));
        u && (c.parseDOM = u.map((f) => Il(f, l)));
        const d = v(o, "renderHTML", a);
        return (
          d && (c.toDOM = (f) => d({ mark: f, HTMLAttributes: Bn(f, l) })),
          [o.name, c]
        );
      }),
    ),
  };
}
function eg(n, e, t) {
  if (t === void 0) return new ar(Bl(n, e));
  const r = bu(n.filter((o) => o.type !== "extension").map((o) => o.name));
  if (r.length)
    throw new RangeError(`Duplicate local schema types: ${r.join(", ")}`);
  const i = new ar(t),
    s = Bl(n, e, yu(to(n), i));
  return new ar(Ym(s, i));
}
function kn(n) {
  return n.sort((t, r) => {
    const i = v(t, "priority") || 100,
      s = v(r, "priority") || 100;
    return i > s ? -1 : i < s ? 1 : 0;
  });
}
function ku(n) {
  const e = kn(Zs(n)),
    t = bu(e.map((r) => r.name));
  return (
    t.length &&
      console.warn(
        `[tiptap warn]: Duplicate extension names found: [${t.map((r) => `'${r}'`).join(", ")}]. This can lead to issues.`,
      ),
    e
  );
}
function Su(n, e, t) {
  const { from: r, to: i } = e,
    {
      blockSeparator: s = `

`,
      textSerializers: o = {},
    } = t || {};
  let l = "";
  return (
    n.nodesBetween(r, i, (a, c, u, d) => {
      a.isBlock && c > r && (l += s);
      const f = o?.[a.type.name];
      if (f)
        return (
          u && (l += f({ node: a, pos: c, parent: u, index: d, range: e })),
          !1
        );
      if (a.isText) {
        var h;
        l +=
          a == null || (h = a.text) === null || h === void 0
            ? void 0
            : h.slice(Math.max(r, c) - c, i - c);
      }
    }),
    l
  );
}
function tg(n, e) {
  return Su(n, { from: 0, to: n.content.size }, e);
}
function xu(n) {
  return Object.fromEntries(
    Object.entries(n.nodes)
      .filter(([, e]) => e.spec.toText)
      .map(([e, t]) => [e, t.spec.toText]),
  );
}
function ng(n, e) {
  const t = Y(e, n.schema),
    { from: r, to: i } = n.selection,
    s = [];
  n.doc.nodesBetween(r, i, (l) => {
    s.push(l);
  });
  const o = s.reverse().find((l) => l.type.name === t.name);
  return o ? { ...o.attrs } : {};
}
function wu(n, e) {
  const t = pi(typeof e == "string" ? e : e.name, n.schema);
  return t === "node" ? ng(n, e) : t === "mark" ? mu(n, e) : {};
}
function rg(n, e = JSON.stringify) {
  const t = {};
  return n.filter((r) => {
    const i = e(r);
    return Object.prototype.hasOwnProperty.call(t, i) ? !1 : (t[i] = !0);
  });
}
function ig(n) {
  const e = rg(n);
  return e.length === 1
    ? e
    : e.filter(
        (t, r) =>
          !e
            .filter((i, s) => s !== r)
            .some(
              (i) =>
                t.oldRange.from >= i.oldRange.from &&
                t.oldRange.to <= i.oldRange.to &&
                t.newRange.from >= i.newRange.from &&
                t.newRange.to <= i.newRange.to,
            ),
      );
}
function gi(n) {
  const { mapping: e, steps: t } = n,
    r = [],
    i = e.invert();
  return (
    e.maps.forEach((s, o) => {
      const l = [];
      if (s.ranges.length)
        s.forEach((c, u) => {
          l.push({ from: c, to: u });
        });
      else {
        const { from: c, to: u } = t[o];
        if (c === void 0 || u === void 0) return;
        l.push({ from: c, to: u });
      }
      const a = e.slice(o);
      l.forEach(({ from: c, to: u }) => {
        const d = a.map(c, -1),
          f = a.map(u),
          h = i.map(d, -1),
          p = i.map(f);
        r.push({ oldRange: { from: h, to: p }, newRange: { from: d, to: f } });
      });
    }),
    ig(r)
  );
}
function yi(n, e, t) {
  const r = [];
  return (
    n === e
      ? t
          .resolve(n)
          .marks()
          .forEach((i) => {
            const s = Qs(t.resolve(n), i.type);
            s && r.push({ mark: i, ...s });
          })
      : t.nodesBetween(n, e, (i, s) => {
          !i ||
            i?.nodeSize === void 0 ||
            r.push(
              ...i.marks.map((o) => ({ from: s, to: s + i.nodeSize, mark: o })),
            );
        }),
    r
  );
}
const sg = (n, e, t, r = 20) => {
    const i = n.doc.resolve(t);
    let s = r,
      o = null;
    for (; s > 0 && o === null;) {
      const l = i.node(s);
      l?.type.name === e ? (o = l) : (s -= 1);
    }
    return [o, s];
  },
  og = (n) => {
    const e = n.depth - 1;
    if (e < 0) return null;
    const t = n.index(e);
    return t === 0 ? null : n.node(e).child(t - 1);
  };
function $t(n, e) {
  return e.nodes[n] || e.marks[n] || null;
}
function fr(n, e, t) {
  return Object.fromEntries(
    Object.entries(t).filter(([r]) => {
      const i = n.find((s) => s.type === e && s.name === r);
      return i ? i.attribute.keepOnSplit : !1;
    }),
  );
}
const lg = (n, e = 500) => {
  let t = "";
  const r = n.parentOffset;
  return (
    n.parent.nodesBetween(Math.max(0, r - e), r, (i, s, o, l) => {
      var a, c;
      const u =
        ((a = (c = i.type.spec).toText) === null || a === void 0
          ? void 0
          : a.call(c, { node: i, pos: s, parent: o, index: l })) ||
        i.textContent ||
        "%leaf%";
      t += i.isAtom && !i.isText ? u : u.slice(0, Math.max(0, r - s));
    }),
    t
  );
};
function Ss(n, e, t = {}) {
  const { empty: r, ranges: i } = n.selection,
    s = e ? qe(e, n.schema) : null;
  if (r)
    return !!(n.storedMarks || n.selection.$from.marks())
      .filter((u) => (s ? s.name === u.type.name : !0))
      .find((u) => Ar(u.attrs, t, { strict: !1 }));
  let o = 0;
  const l = [];
  if (
    (i.forEach(({ $from: u, $to: d }) => {
      const f = u.pos,
        h = d.pos;
      n.doc.nodesBetween(f, h, (p, g) => {
        if (s && p.inlineContent && !p.type.allowsMarkType(s)) return !1;
        if (!p.isText && !p.marks.length) return;
        const m = Math.max(f, g),
          y = Math.min(h, g + p.nodeSize),
          k = y - m;
        ((o += k),
          l.push(...p.marks.map((x) => ({ mark: x, from: m, to: y }))));
      });
    }),
    o === 0)
  )
    return !1;
  const a = l
      .filter((u) => (s ? s.name === u.mark.type.name : !0))
      .filter((u) => Ar(u.mark.attrs, t, { strict: !1 }))
      .reduce((u, d) => u + d.to - d.from, 0),
    c = l
      .filter((u) => (s ? u.mark.type !== s && u.mark.type.excludes(s) : !0))
      .reduce((u, d) => u + d.to - d.from, 0);
  return (a > 0 ? a + c : a) >= o;
}
function ag(n, e, t = {}) {
  if (!e) return We(n, null, t) || Ss(n, null, t);
  const r = pi(e, n.schema);
  return r === "node" ? We(n, e, t) : r === "mark" ? Ss(n, e, t) : !1;
}
const cg = (n, e) => {
    const { $from: t, $to: r, $anchor: i } = n.selection;
    if (e) {
      const s = mi((l) => l.type.name === e)(n.selection);
      if (!s) return !1;
      const o = n.doc.resolve(s.pos + 1);
      return i.pos + 1 === o.end();
    }
    return !(r.parentOffset < r.parent.nodeSize - 2 || t.pos !== r.pos);
  },
  ug = (n) => {
    const { $from: e, $to: t } = n.selection;
    return !(e.parentOffset > 0 || e.pos !== t.pos);
  };
function $l(n, e) {
  return Array.isArray(e)
    ? e.some((t) => (typeof t == "string" ? t : t.name) === n.name)
    : e;
}
function ln(n, e) {
  const { nodeExtensions: t } = en(e),
    r = t.find((s) => s.name === n);
  if (!r) return !1;
  const i = B(
    v(r, "group", { name: r.name, options: r.options, storage: r.storage }),
  );
  return typeof i != "string" ? !1 : i.split(" ").includes("list");
}
function _n(n, { checkChildren: e = !0, ignoreWhitespace: t = !1 } = {}) {
  if (t) {
    if (n.type.name === "hardBreak") return !0;
    if (n.isText) {
      var r;
      return !/\S/.test((r = n.text) !== null && r !== void 0 ? r : "");
    }
  }
  if (n.isText) return !n.text;
  if (n.isAtom || n.isLeaf) return !1;
  if (n.content.childCount === 0) return !0;
  if (e) {
    let i = !0;
    return (
      n.content.forEach((s) => {
        i !== !1 &&
          (_n(s, { ignoreWhitespace: t, checkChildren: e }) || (i = !1));
      }),
      i
    );
  }
  return !1;
}
function Cu(n) {
  return n instanceof O;
}
function dg(n) {
  if (n === null || typeof n != "object") return !1;
  const e = n;
  return !(
    typeof e.apply != "function" ||
    typeof e.getMap != "function" ||
    typeof e.invert != "function" ||
    typeof e.map != "function" ||
    typeof e.merge != "function" ||
    typeof e.toJSON != "function"
  );
}
function fg(n) {
  if (n === null || typeof n != "object") return !1;
  const e = n;
  if (!dg(e)) return !1;
  const t = e.toJSON();
  return !(t === null || typeof t != "object" || t.stepType !== "replace");
}
var vu = class Mu {
  constructor(e) {
    this.position = e;
  }
  static fromJSON(e) {
    return new Mu(e.position);
  }
  toJSON() {
    return { position: this.position };
  }
};
function hg(n, e) {
  const t = e.mapping.mapResult(n.position);
  return { position: new vu(t.pos), mapResult: t };
}
function pg(n) {
  return new vu(n);
}
function mg(n, e, t) {
  const { selection: r } = e;
  let i = null;
  if ((lu(r) && (i = r.$cursor), i)) {
    var s;
    const l = (s = n.storedMarks) !== null && s !== void 0 ? s : i.marks();
    return (
      i.parent.type.allowsMarkType(t) &&
      (!!t.isInSet(l) || !l.some((a) => a.type.excludes(t)))
    );
  }
  const { ranges: o } = r;
  return o.some(({ $from: l, $to: a }) => {
    let c =
      l.depth === 0 ? n.doc.inlineContent && n.doc.type.allowsMarkType(t) : !1;
    return (
      n.doc.nodesBetween(l.pos, a.pos, (u, d, f) => {
        if (c) return !1;
        if (u.isInline) {
          const h = !f || f.type.allowsMarkType(t),
            p =
              !!t.isInSet(u.marks) || !u.marks.some((g) => g.type.excludes(t));
          c = h && p;
        }
        return !c;
      }),
      c
    );
  });
}
const gg =
    (n, e = {}) =>
    ({ tr: t, state: r, dispatch: i }) => {
      const { selection: s } = t,
        { empty: o, ranges: l } = s,
        a = qe(n, r.schema);
      if (i)
        if (o) {
          const c = mu(r, a);
          t.addStoredMark(a.create({ ...c, ...e }));
        } else
          l.forEach((c) => {
            const u = c.$from.pos,
              d = c.$to.pos;
            r.doc.nodesBetween(u, d, (f, h) => {
              const p = Math.max(h, u),
                g = Math.min(h + f.nodeSize, d);
              f.marks.find((m) => m.type === a)
                ? f.marks.forEach((m) => {
                    a === m.type &&
                      t.addMark(p, g, a.create({ ...m.attrs, ...e }));
                  })
                : t.addMark(p, g, a.create(e));
            });
          });
      return mg(r, t, a);
    },
  yg =
    (n, e) =>
    ({ tr: t }) => (t.setMeta(n, e), !0),
  bg =
    (n, e = {}) =>
    ({ state: t, dispatch: r, chain: i }) => {
      const s = Y(n, t.schema);
      let o;
      return (
        t.selection.$anchor.sameParent(t.selection.$head) &&
          (o = t.selection.$anchor.parent.attrs),
        s.isTextblock
          ? i()
              .command(({ commands: l }) =>
                Jo(s, { ...o, ...e })(t) ? !0 : l.clearNodes(),
              )
              .command(({ state: l }) => Jo(s, { ...o, ...e })(l, r))
              .run()
          : (console.warn(
              '[tiptap warn]: Currently "setNode()" only supports text block nodes.',
            ),
            !1)
      );
    },
  kg =
    (n) =>
    ({ tr: e, dispatch: t }) => {
      if (t) {
        const { doc: r } = e,
          i = yt(n, 0, r.content.size),
          s = O.create(r, i);
        e.setSelection(s);
      }
      return !0;
    },
  Sg =
    (n, e) =>
    ({ tr: t, state: r, dispatch: i }) => {
      const { selection: s } = r;
      let o, l;
      return (
        typeof e == "number"
          ? ((o = e), (l = e))
          : e && "from" in e && "to" in e
            ? ((o = e.from), (l = e.to))
            : ((o = s.from), (l = s.to)),
        i &&
          t.doc.nodesBetween(o, l, (a, c) => {
            a.isText || t.setNodeMarkup(c, void 0, { ...a.attrs, dir: n });
          }),
        !0
      );
    },
  xg =
    (n) =>
    ({ tr: e, dispatch: t }) => {
      if (t) {
        const { doc: r } = e,
          { from: i, to: s } = typeof n == "number" ? { from: n, to: n } : n,
          o = T.atStart(r).from,
          l = T.atEnd(r).to,
          a = yt(i, o, l),
          c = yt(s, o, l),
          u = T.create(r, a, c);
        e.setSelection(u);
      }
      return !0;
    },
  wg =
    (n) =>
    ({ state: e, dispatch: t }) => {
      const r = Y(n, e.schema);
      return Xf(r)(e, t);
    };
function zl(n, e) {
  const t =
    n.storedMarks ||
    (n.selection.$to.parentOffset && n.selection.$from.marks());
  if (t) {
    const r = t.filter((i) => e?.includes(i.type.name));
    n.tr.ensureMarks(r);
  }
}
const Cg =
    ({ keepMarks: n = !0 } = {}) =>
    ({ tr: e, state: t, dispatch: r, editor: i }) => {
      const { selection: s, doc: o } = e,
        { $from: l, $to: a } = s,
        c = i.extensionManager.attributes,
        u = fr(c, l.node().type.name, l.node().attrs);
      if (s instanceof O && s.node.isBlock)
        return !l.parentOffset || !He(o, l.pos)
          ? !1
          : (r &&
              (n && zl(t, i.extensionManager.splittableMarks),
              e.split(l.pos).scrollIntoView()),
            !0);
      if (!l.parent.isBlock) return !1;
      const d = a.parentOffset === a.parent.content.size,
        f =
          l.depth === 0
            ? void 0
            : fu(l.node(-1).contentMatchAt(l.indexAfter(-1)));
      let h = d && f ? [{ type: f, attrs: u }] : void 0;
      const p =
          s instanceof T && !s.empty
            ? Fe.create({ doc: e.doc, selection: s }).tr.deleteSelection()
            : null,
        g = p ? p.doc : e.doc,
        m = p ? p.mapping.map(l.pos) : l.pos;
      let y = He(g, m, 1, h);
      if (
        (!h &&
          !y &&
          He(g, m, 1, f ? [{ type: f }] : void 0) &&
          ((y = !0), (h = f ? [{ type: f, attrs: u }] : void 0)),
        r)
      ) {
        if (y) {
          const k = e.steps.length;
          if (
            (s instanceof T && e.deleteSelection(),
            e.split(e.mapping.slice(k).map(l.pos), 1, h),
            f && !d && !l.parentOffset && l.parent.type !== f)
          ) {
            const x = e.mapping.slice(k).map(l.before()),
              w = e.doc.resolve(x);
            l.node(-1).canReplaceWith(w.index(), w.index() + 1, f) &&
              e.setNodeMarkup(e.mapping.slice(k).map(l.before()), f);
          }
        }
        (n && zl(t, i.extensionManager.splittableMarks), e.scrollIntoView());
      }
      return y;
    },
  vg =
    (n, e = {}) =>
    ({ tr: t, state: r, dispatch: i, editor: s }) => {
      const o = Y(n, r.schema),
        { $from: l, $to: a } = r.selection,
        c = r.selection.node;
      if ((c && c.isBlock) || l.depth < 2 || !l.sameParent(a)) return !1;
      const u = l.node(-1);
      if (u.type !== o) return !1;
      const d = s.extensionManager.attributes;
      if (
        l.parent.content.size === 0 &&
        l.node(-1).childCount === l.indexAfter(-1)
      ) {
        if (
          l.depth === 2 ||
          l.node(-3).type !== o ||
          l.index(-2) !== l.node(-2).childCount - 1
        )
          return !1;
        if (i) {
          var f;
          let w = b.empty;
          const M = l.index(-1) ? 1 : l.index(-2) ? 2 : 3;
          for (let Se = l.depth - M; Se >= l.depth - 3; Se -= 1)
            w = b.from(l.node(Se).copy(w));
          const D =
              l.indexAfter(-1) < l.node(-2).childCount
                ? 1
                : l.indexAfter(-2) < l.node(-3).childCount
                  ? 2
                  : 3,
            E = { ...fr(d, l.node().type.name, l.node().attrs), ...e },
            I =
              ((f = o.contentMatch.defaultType) === null || f === void 0
                ? void 0
                : f.createAndFill(E)) || void 0;
          w = w.append(b.from(o.createAndFill(null, I) || void 0));
          const L = l.before(l.depth - (M - 1));
          t.replace(L, l.after(-D), new C(w, 4 - M, 0));
          let F = -1;
          (t.doc.nodesBetween(L, t.doc.content.size, (Se, dt) => {
            if (F > -1) return !1;
            Se.isTextblock && Se.content.size === 0 && (F = dt + 1);
          }),
            F > -1 && t.setSelection(T.near(t.doc.resolve(F))),
            t.scrollIntoView());
        }
        return !0;
      }
      const h = a.pos === l.end() ? u.contentMatchAt(0).defaultType : null,
        p = { ...fr(d, u.type.name, u.attrs), ...e },
        g = { ...fr(d, l.node().type.name, l.node().attrs), ...e },
        m = l.parentOffset === 0 && l.index(-1) === 0,
        y = l.before(-1);
      t.delete(l.pos, a.pos);
      const k = m ? u.attrs : p,
        x = h
          ? [
              { type: o, attrs: k },
              { type: h, attrs: g },
            ]
          : [{ type: o, attrs: k }];
      if (!He(t.doc, l.pos, 2)) return !1;
      if (i) {
        const { selection: w, storedMarks: M } = r,
          { splittableMarks: D } = s.extensionManager,
          E = M || (w.$to.parentOffset && w.$from.marks());
        if (
          (t.split(l.pos, 2, x).scrollIntoView(),
          m && t.setNodeMarkup(y, void 0, p),
          !E || !i)
        )
          return !0;
        const I = E.filter((L) => D.includes(L.type.name));
        t.ensureMarks(I);
      }
      return !0;
    };
function Eu(n, e, t) {
  if (!n.validContent(e)) return null;
  try {
    return n.create(t, e);
  } catch {
    return null;
  }
}
function no(n, e) {
  if (n.pendingContent.length === 0) return !0;
  const t = Eu(e, b.from(n.pendingContent));
  return t ? (n.items.push(t), (n.pendingContent = []), !0) : !1;
}
function Mg(n, e, t) {
  return t.validContent(b.from([...e.pendingContent, n]))
    ? (e.pendingContent.push(n), !0)
    : !no(e, t) || !t.validContent(b.from(n))
      ? !1
      : (e.pendingContent.push(n), !0);
}
function Eg(n, e, t, r) {
  const i = r(n, t);
  if (!i) return !1;
  const s = Eu(t.listType, b.from(i), n.attrs);
  return s
    ? t.itemType.validContent(b.from([...e.pendingContent, s]))
      ? (e.pendingContent.push(s), !0)
      : no(e, t.itemType)
        ? (e.items.push(...i), !0)
        : !1
    : !1;
}
function Tg(n, e, t) {
  const r = { items: [], pendingContent: [] };
  for (let i = 0; i < n.childCount; i += 1) {
    const s = n.child(i);
    if (!(e.isListNode(s) ? Eg(s, r, e, t) : Mg(s, r, e.itemType))) return null;
  }
  return no(r, e.itemType) ? r.items : null;
}
function Tu(n, e) {
  const t = [];
  for (let r = 0; r < n.childCount; r += 1) {
    const i = Tg(n.child(r), e, Tu);
    if (!i) return null;
    t.push(...i);
  }
  return t;
}
function Fl(n, e) {
  let t = null;
  return (n.descendants((r, i) => (r !== e ? !0 : ((t = i), !1))), t);
}
function Vl(n) {
  return !n || n === "1" ? null : n;
}
function Au(n, e) {
  return Vl(n) === Vl(e);
}
const Qn = (n, e) => {
    const t = mi((s) => s.type === e)(n.selection);
    if (!t) return !0;
    const r = n.doc.resolve(Math.max(0, t.pos - 1)).before(t.depth);
    if (r === void 0) return !0;
    const i = n.doc.nodeAt(r);
    return (
      !(t.node.type === i?.type && at(n.doc, t.pos)) ||
        !Au(t.node.attrs.type, i?.attrs.type) ||
        n.join(t.pos),
      !0
    );
  },
  Zn = (n, e) => {
    const t = mi((s) => s.type === e)(n.selection);
    if (!t) return !0;
    const r = n.doc.resolve(t.start).after(t.depth);
    if (r === void 0) return !0;
    const i = n.doc.nodeAt(r);
    return (
      !(t.node.type === i?.type && at(n.doc, r)) ||
        !Au(t.node.attrs.type, i?.attrs.type) ||
        n.join(r),
      !0
    );
  };
function Ag(n) {
  const e = n.doc,
    t = e.firstChild;
  if (!t) return null;
  const r = e.resolve(1),
    i = e.resolve(t.nodeSize - 1);
  return T.between(r, i);
}
const Og =
    (n, e, t, r = {}) =>
    ({
      editor: i,
      tr: s,
      state: o,
      dispatch: l,
      chain: a,
      commands: c,
      can: u,
    }) => {
      const { extensions: d, splittableMarks: f } = i.extensionManager,
        h = Y(n, o.schema),
        p = Y(e, o.schema),
        { selection: g, storedMarks: m } = o,
        { $from: y, $to: k } = g,
        x = y.blockRange(k),
        w = m || (g.$to.parentOffset && g.$from.marks());
      if (!x) return !1;
      const M = mi((ae) => ln(ae.type.name, d))(g),
        D = g.from === 0 && g.to === o.doc.content.size,
        E = o.doc.content.content,
        I = E.length === 1 ? E[0] : null,
        L = D && I && ln(I.type.name, d) ? { node: I, pos: 0 } : null,
        F = M ?? L,
        Se = !!M && x.depth >= 1 && x.depth - M.depth <= 1,
        dt = !!L;
      if ((Se || dt) && F) {
        if (F.node.type === h)
          return D && dt
            ? a()
                .command(({ tr: ae, dispatch: he }) => {
                  const ce = Ag(ae);
                  return ce ? (ae.setSelection(ce), he && he(ae), !0) : !1;
                })
                .liftListItem(p)
                .run()
            : c.liftListItem(p);
        if (ln(F.node.type.name, d) && h.validContent(F.node.content))
          return a()
            .command(() => (s.setNodeMarkup(F.pos, h), !0))
            .command(() => Qn(s, h))
            .command(() => Zn(s, h))
            .run();
        if (ln(F.node.type.name, d)) {
          var ft;
          const ae =
            (ft = F.node.firstChild) === null || ft === void 0
              ? void 0
              : ft.type;
          if (ae && ae !== p) {
            const he = Tu(F.node, {
                listType: h,
                itemType: p,
                isListNode: (qn) => ln(qn.type.name, d),
              }),
              ce = he ? b.from(he) : null;
            return !ce || !h.validContent(ce)
              ? !1
              : a()
                  .command(() => {
                    const { $anchor: qn, $head: bo } = s.selection,
                      ko = qn.parent,
                      So = bo.parent,
                      Md = qn.parentOffset,
                      Ed = bo.parentOffset;
                    let Un;
                    try {
                      Un = h.create(r, ce);
                    } catch {
                      return !1;
                    }
                    if (
                      (s.replaceWith(F.pos, F.pos + F.node.nodeSize, Un),
                      ko.inlineContent && So.inlineContent)
                    ) {
                      const xo = Fl(Un, ko),
                        wo = Fl(Un, So);
                      if (xo !== null && wo !== null) {
                        const Td = F.pos + xo + 2 + Md,
                          Ad = F.pos + wo + 2 + Ed;
                        s.setSelection(T.create(s.doc, Td, Ad));
                      }
                    }
                    return !0;
                  })
                  .command(() => Qn(s, h))
                  .command(() => Zn(s, h))
                  .run();
          }
        }
      }
      return !t || !w || !l
        ? a()
            .command(() => (u().wrapInList(h, r) ? !0 : c.clearNodes()))
            .wrapInList(h, r)
            .command(() => Qn(s, h))
            .command(() => Zn(s, h))
            .run()
        : a()
            .command(() => {
              const ae = u().wrapInList(h, r),
                he = w.filter((ce) => f.includes(ce.type.name));
              return (s.ensureMarks(he), ae ? !0 : c.clearNodes());
            })
            .wrapInList(h, r)
            .command(() => Qn(s, h))
            .command(() => Zn(s, h))
            .run();
    },
  Ng =
    (n, e = {}, t = {}) =>
    ({ state: r, commands: i }) => {
      const { extendEmptyMarkRange: s = !1 } = t,
        o = qe(n, r.schema);
      return Ss(r, o, e)
        ? i.unsetMark(o, { extendEmptyMarkRange: s })
        : i.setMark(o, e);
    },
  Dg =
    (n, e, t = {}) =>
    ({ state: r, commands: i }) => {
      const s = Y(n, r.schema),
        o = Y(e, r.schema),
        l = We(r, s, t);
      let a;
      return (
        r.selection.$anchor.sameParent(r.selection.$head) &&
          (a = r.selection.$anchor.parent.attrs),
        l ? i.setNode(o, a) : i.setNode(s, { ...a, ...t })
      );
    },
  Rg =
    (n, e = {}) =>
    ({ state: t, commands: r }) => {
      const i = Y(n, t.schema);
      return We(t, i, e) ? r.lift(i) : r.wrapIn(i, e);
    },
  Ig =
    () =>
    ({ state: n, dispatch: e }) => {
      const t = n.plugins;
      for (let r = 0; r < t.length; r += 1) {
        const i = t[r];
        let s;
        if (i.spec.isInputRules && (s = i.getState(n))) {
          if (e) {
            const o = n.tr,
              l = s.transform;
            for (let a = l.steps.length - 1; a >= 0; a -= 1)
              o.step(l.steps[a].invert(l.docs[a]));
            if (s.text) {
              const a = o.doc.resolve(s.from).marks();
              o.replaceWith(s.from, s.to, n.schema.text(s.text, a));
            } else o.delete(s.from, s.to);
          }
          return !0;
        }
      }
      return !1;
    },
  Lg =
    (n = {}) =>
    ({ tr: e, dispatch: t, editor: r }) => {
      const { ignoreClearable: i = !1 } = n,
        { selection: s } = e,
        { empty: o, ranges: l } = s;
      if (o) return !0;
      const { nonClearableMarks: a } = r.extensionManager;
      if (t) {
        const c = Object.values(r.schema.marks).filter(
          (u) => i || !a.includes(u.name),
        );
        l.forEach((u) => {
          for (const d of c) e.removeMark(u.$from.pos, u.$to.pos, d);
        });
      }
      return !0;
    },
  Pg =
    (n, e = {}) =>
    ({ tr: t, state: r, dispatch: i }) => {
      const { extendEmptyMarkRange: s = !1 } = e,
        { selection: o } = t,
        l = qe(n, r.schema),
        { $from: a, empty: c, ranges: u } = o;
      if (!i) return !0;
      if (c && s) {
        var d;
        let { from: f, to: h } = o;
        const p = Qs(
          a,
          l,
          (d = a.marks().find((g) => g.type === l)) === null || d === void 0
            ? void 0
            : d.attrs,
        );
        (p && ((f = p.from), (h = p.to)), t.removeMark(f, h, l));
      } else
        u.forEach((f) => {
          t.removeMark(f.$from.pos, f.$to.pos, l);
        });
      return (t.removeStoredMark(l), !0);
    },
  Bg =
    (n) =>
    ({ tr: e, state: t, dispatch: r }) => {
      const { selection: i } = t;
      let s, o;
      return (
        typeof n == "number"
          ? ((s = n), (o = n))
          : n && "from" in n && "to" in n
            ? ((s = n.from), (o = n.to))
            : ((s = i.from), (o = i.to)),
        r &&
          e.doc.nodesBetween(s, o, (l, a) => {
            if (l.isText) return;
            const c = { ...l.attrs };
            (delete c.dir, e.setNodeMarkup(a, void 0, c));
          }),
        !0
      );
    },
  $g =
    (n, e = {}) =>
    ({ tr: t, state: r, dispatch: i }) => {
      let s = null,
        o = null;
      const l = pi(typeof n == "string" ? n : n.name, r.schema);
      if (!l) return !1;
      (l === "node" && (s = Y(n, r.schema)),
        l === "mark" && (o = qe(n, r.schema)));
      let a = !1;
      return (
        t.selection.ranges.forEach((c) => {
          const u = c.$from.pos,
            d = c.$to.pos;
          let f, h, p, g;
          (t.selection.empty
            ? r.doc.nodesBetween(u, d, (m, y) => {
                s &&
                  s === m.type &&
                  ((a = !0),
                  (p = Math.max(y, u)),
                  (g = Math.min(y + m.nodeSize, d)),
                  (f = y),
                  (h = m));
              })
            : r.doc.nodesBetween(u, d, (m, y) => {
                (y < u &&
                  s &&
                  s === m.type &&
                  ((a = !0),
                  (p = Math.max(y, u)),
                  (g = Math.min(y + m.nodeSize, d)),
                  (f = y),
                  (h = m)),
                  y >= u &&
                    y <= d &&
                    (s &&
                      s === m.type &&
                      ((a = !0),
                      i && t.setNodeMarkup(y, void 0, { ...m.attrs, ...e })),
                    o &&
                      m.marks.length &&
                      m.marks.forEach((k) => {
                        if (o === k.type && ((a = !0), i)) {
                          const x = Math.max(y, u),
                            w = Math.min(y + m.nodeSize, d);
                          t.addMark(x, w, o.create({ ...k.attrs, ...e }));
                        }
                      })));
              }),
            h &&
              (f !== void 0 &&
                i &&
                t.setNodeMarkup(f, void 0, { ...h.attrs, ...e }),
              o &&
                h.marks.length &&
                h.marks.forEach((m) => {
                  o === m.type &&
                    i &&
                    t.addMark(p, g, o.create({ ...m.attrs, ...e }));
                })));
        }),
        a
      );
    },
  jt = new K("__tiptap_decorations__"),
  zg =
    (n) =>
    ({ tr: e, dispatch: t }) => (
      t && e.setMeta(jt, { type: "force", name: n }),
      !0
    ),
  Fg =
    (n, e = {}) =>
    ({ state: t, dispatch: r }) => {
      const i = Y(n, t.schema);
      return Wf(i, e)(t, r);
    },
  Vg =
    (n, e = {}) =>
    ({ state: t, dispatch: r }) => {
      const i = Y(n, t.schema);
      return qf(i, e)(t, r);
    };
var jg = If({
  blur: () => em,
  clearContent: () => tm,
  clearNodes: () => nm,
  command: () => rm,
  createParagraphNear: () => im,
  cut: () => sm,
  deleteCurrentNode: () => om,
  deleteNode: () => lm,
  deleteRange: () => am,
  deleteSelection: () => dm,
  enter: () => fm,
  exitCode: () => hm,
  extendMarkRange: () => pm,
  first: () => mm,
  focus: () => ym,
  forEach: () => bm,
  insertContent: () => km,
  insertContentAt: () => Sm,
  insertDefaultBlock: () => xm,
  joinBackward: () => vm,
  joinDown: () => Cm,
  joinForward: () => Mm,
  joinItemBackward: () => Em,
  joinItemForward: () => Tm,
  joinTextblockBackward: () => Am,
  joinTextblockForward: () => Om,
  joinUp: () => wm,
  keyboardShortcut: () => Dm,
  lift: () => Rm,
  liftEmptyBlock: () => Im,
  liftListItem: () => Lm,
  newlineInCode: () => Pm,
  resetAttributes: () => Bm,
  scrollIntoView: () => $m,
  selectAll: () => zm,
  selectNodeBackward: () => Fm,
  selectNodeForward: () => Vm,
  selectParentNode: () => jm,
  selectTextblockEnd: () => Hm,
  selectTextblockStart: () => _m,
  setContent: () => Wm,
  setMark: () => gg,
  setMeta: () => yg,
  setNode: () => bg,
  setNodeSelection: () => kg,
  setTextDirection: () => Sg,
  setTextSelection: () => xg,
  sinkListItem: () => wg,
  splitBlock: () => Cg,
  splitListItem: () => vg,
  toggleList: () => Og,
  toggleMark: () => Ng,
  toggleNode: () => Dg,
  toggleWrap: () => Rg,
  undoInputRule: () => Ig,
  unsetAllMarks: () => Lg,
  unsetMark: () => Pg,
  unsetTextDirection: () => Bg,
  updateAttributes: () => $g,
  updateDecorations: () => zg,
  wrapIn: () => Fg,
  wrapInList: () => Vg,
});
const an = new WeakMap();
function Hg(n, e) {
  var t;
  an.set(n, ((t = an.get(n)) !== null && t !== void 0 ? t : 0) + 1);
  try {
    return e();
  } finally {
    var r;
    const i = ((r = an.get(n)) !== null && r !== void 0 ? r : 1) - 1;
    i > 0 ? an.set(n, i) : an.delete(n);
  }
}
var _g = class {
  constructor() {
    this.callbacks = {};
  }
  on(n, e) {
    return (
      this.callbacks[n] || (this.callbacks[n] = []),
      this.callbacks[n].push(e),
      this
    );
  }
  emit(n, ...e) {
    const t = this.callbacks[n];
    return (t && t.forEach((r) => r.apply(this, e)), this);
  }
  off(n, e) {
    const t = this.callbacks[n];
    return (
      t &&
        (e
          ? (this.callbacks[n] = t.filter((r) => r !== e))
          : delete this.callbacks[n]),
      this
    );
  }
  once(n, e) {
    const t = (...r) => {
      (this.off(n, t), e.apply(this, r));
    };
    return this.on(n, t);
  }
  removeAllListeners() {
    this.callbacks = {};
  }
};
function Wg(n) {
  return n.kind === "widget";
}
function Ou(n, e) {
  const t = [],
    r = new Set();
  for (const i of n)
    (i.kind === "widget" && Wg(i) && r.add(i.key), t.push(i.toPMDecoration(e)));
  return { decorations: t, widgetKeys: r };
}
function qg(n, e, t) {
  const { decorations: r, widgetKeys: i } = Ou(e, t);
  return { set: P.create(n, r), widgetKeys: i };
}
function Nu({ position: n, from: e, to: t, docSize: r }) {
  return n < e ? !1 : n < t ? !0 : n === t && t === r;
}
function Ug({
  decorations: n,
  from: e,
  to: t,
  docSize: r,
  extensionName: i,
  warnedExtensions: s,
}) {
  return n.filter((o) =>
    Nu({ position: o.anchor, from: e, to: t, docSize: r })
      ? !0
      : (o.anchor === t ||
          s.has(i) ||
          (s.add(i),
          console.warn(
            `[tiptap warn]: Extension "${i}" returned a decoration outside the requested range [${e}, ${t}). It was ignored.`,
          )),
        !1),
  );
}
function Kg(n) {
  var e;
  const t = (e = n.spec) === null || e === void 0 ? void 0 : e.key;
  return typeof t == "string" ? t : void 0;
}
function Du(n) {
  return n.jsonID === "attr";
}
function Jg(n) {
  let e = !1;
  if (
    (n.getMap().forEach(() => {
      e = !0;
    }),
    e || Du(n))
  )
    return !0;
  const t = n;
  return typeof t.from == "number" && typeof t.to == "number";
}
function Gg(n, e) {
  let t = null,
    r = 0,
    i = 0;
  for (let s = 0; s < n.childCount && !(i > e.to); s += 1) {
    const o = i + n.child(s).nodeSize;
    (o >= e.from && (t === null && (t = i), (r = o)), (i = o));
  }
  return t === null ? null : { from: t, to: r };
}
function Yg(n, e) {
  if (n.steps.some((s) => !Jg(s))) return { type: "full" };
  const t = gi(n).map(({ newRange: s }) => s);
  n.steps.forEach((s, o) => {
    if (!Du(s)) return;
    const l = n.mapping.slice(o);
    t.push({ from: l.map(s.pos, -1), to: l.map(s.pos + 1) });
  });
  const r = [];
  for (const s of t) {
    const o = Gg(e, s);
    o && r.push(o);
  }
  r.sort((s, o) => s.from - o.from);
  const i = [];
  for (const s of r) {
    const o = i[i.length - 1];
    o && s.from <= o.to ? (o.to = Math.max(o.to, s.to)) : i.push({ ...s });
  }
  return { type: "ranges", ranges: i };
}
function Ru(n, e, t, r) {
  return n.map(e, t, {
    onRemove: (i) => {
      const s = i?.key;
      typeof s == "string" && r.delete(s);
    },
  });
}
function Xg(n, e, t) {
  var r, i;
  const s =
      (r = e.decorationSetsByExtension[n]) !== null && r !== void 0
        ? r
        : P.empty,
    o = new Set(
      (i = e.widgetKeysByExtension[n]) !== null && i !== void 0 ? i : [],
    );
  return { set: Ru(s, t.mapping, t.doc, o), widgetKeys: o };
}
function jl(n, e) {
  const t = Object.values(e).flatMap((r) => r.find());
  return P.create(n, t);
}
function Hl(n) {
  const e = new Set();
  for (const t of Object.values(n)) for (const r of t) e.add(r);
  return e;
}
function Qg(n, e) {
  var t;
  switch ((t = e.update) !== null && t !== void 0 ? t : "document") {
    case "document":
      if (e.createInRange)
        throw new Error(
          `[tiptap error]: Extension "${n}" provides createInRange() but does not use the "changedRanges" decoration update strategy.`,
        );
      return;
    case "changedRanges":
      if (!e.createInRange)
        throw new Error(
          `[tiptap error]: Extension "${n}" uses the "changedRanges" decoration update strategy but does not provide createInRange().`,
        );
      return;
    case "manual":
      if (e.createInRange)
        throw new Error(
          `[tiptap error]: Extension "${n}" uses the "manual" decoration update strategy, which is not compatible with createInRange(). createInRange() requires the "changedRanges" strategy.`,
        );
      if (e.shouldUpdate)
        throw new Error(
          `[tiptap error]: Extension "${n}" cannot combine the "manual" decoration update strategy with shouldUpdate().`,
        );
      return;
    default:
      throw new Error(
        `[tiptap error]: Extension "${n}" uses an unknown decoration update strategy. Expected "document", "changedRanges", or "manual".`,
      );
  }
}
function Zg(n, e, t) {
  return t
    ? !0
    : n.update === "manual"
      ? !1
      : n.shouldUpdate
        ? n.shouldUpdate(e)
        : e.tr.docChanged;
}
const ey = new Set();
var ty = class {
  constructor(n) {
    ((this.warnedWidgetKeys = new Set()),
      (this.warnedOutOfRangeExtensions = new Set()),
      (this.handleBeforeTransaction = ({ nextState: e }) => {
        const t = jt.getState(e);
        t && this.warnDuplicateWidgetKeys(t);
      }),
      (this.editor = n.editor),
      (this.entries = this.resolveEntries(n.entries)),
      this.entries.forEach(({ name: e, spec: t }) => Qg(e, t)),
      (this.plugin = this.entries.length > 0 ? this.createPlugin() : null),
      this.editor.on("beforeTransaction", this.handleBeforeTransaction));
  }
  destroy() {
    this.editor.off("beforeTransaction", this.handleBeforeTransaction);
  }
  liveWidgetKeys() {
    var n, e;
    return (n =
      (e = jt.getState(this.editor.state)) === null || e === void 0
        ? void 0
        : e.widgetKeys) !== null && n !== void 0
      ? n
      : ey;
  }
  get mountedView() {
    return this.editor.isDestroyed ? null : this.editor.view;
  }
  resolveEntries(n) {
    const e = [];
    for (const { name: t, addDecorations: r } of n) {
      const i = r();
      i && e.push({ name: t, spec: i });
    }
    return e;
  }
  createPlugin() {
    const { editor: n, entries: e } = this;
    return new V({
      key: jt,
      state: {
        init: (t, r) => {
          const i = {},
            s = {};
          for (const { name: l, spec: a } of e) {
            const { set: c, widgetKeys: u } = this.buildFullSet(l, a, r);
            ((i[l] = c), (s[l] = u));
          }
          const o = {
            decorationSetsByExtension: i,
            widgetKeysByExtension: s,
            mergedDecorationSet: this.buildMergedSet(r.doc, i),
            widgetKeys: Hl(s),
          };
          return (this.warnDuplicateWidgetKeys(o), o);
        },
        apply: (t, r, i, s) => {
          const o = t.getMeta(jt),
            l = o?.type === "force" && !o.name,
            a = o?.type === "force" ? o.name : void 0,
            c = {},
            u = {},
            d = new Set();
          return (
            Hg(n, () => {
              for (const { name: f, spec: h } of e) {
                const p = l || a === f;
                if (Zg(h, { editor: n, tr: t, oldState: i, newState: s }, p))
                  if (h.update === "changedRanges" && t.docChanged && !p) {
                    const g = this.applyChangedRangesRecompute(f, h, r, t, s);
                    ((c[f] = g.set), (u[f] = g.widgetKeys), d.add(f));
                  } else {
                    const { set: g, widgetKeys: m } = this.buildFullSet(
                      f,
                      h,
                      s,
                    );
                    ((c[f] = g), (u[f] = m), d.add(f));
                  }
                else {
                  const g = Xg(f, r, t);
                  ((c[f] = g.set), (u[f] = g.widgetKeys));
                }
              }
            }),
            d.size === 0 && !t.docChanged
              ? r
              : {
                  decorationSetsByExtension: c,
                  widgetKeysByExtension: u,
                  mergedDecorationSet: this.mergeAfterApply({
                    entries: e,
                    previous: r,
                    tr: t,
                    decorationSetsByExtension: c,
                    recomputedNames: d,
                  }),
                  widgetKeys: Hl(u),
                }
          );
        },
      },
      props: {
        decorations(t) {
          var r, i;
          return (r =
            (i = jt.getState(t)) === null || i === void 0
              ? void 0
              : i.mergedDecorationSet) !== null && r !== void 0
            ? r
            : P.empty;
        },
      },
    });
  }
  applyChangedRangesRecompute(n, e, t, r, i) {
    const s = Yg(r, i.doc);
    return s.type === "full"
      ? this.buildFullSet(n, e, i)
      : this.rebuildRanges(n, e, t, r, i, s.ranges);
  }
  rebuildRanges(n, e, t, r, i, s) {
    var o, l;
    const a =
        (o = t.decorationSetsByExtension[n]) !== null && o !== void 0
          ? o
          : P.empty,
      c = new Set(
        (l = t.widgetKeysByExtension[n]) !== null && l !== void 0 ? l : [],
      );
    let u = Ru(a, r.mapping, r.doc, c);
    const d = i.doc.content.size;
    for (const { from: f, to: h } of s) {
      const p = u
        .find(f, h)
        .filter((y) => Nu({ position: y.from, from: f, to: h, docSize: d }));
      for (const y of p) {
        const k = Kg(y);
        k && c.delete(k);
      }
      u = u.remove(p);
      const { decorations: g, widgetKeys: m } = Ou(
        Ug({
          decorations: this.runCreate(n, "createInRange", () =>
            e.createInRange({
              editor: this.editor,
              state: i,
              view: this.mountedView,
              from: f,
              to: h,
            }),
          ),
          from: f,
          to: h,
          docSize: d,
          extensionName: n,
          warnedExtensions: this.warnedOutOfRangeExtensions,
        }),
        n,
      );
      u = u.add(i.doc, g);
      for (const y of m) c.add(y);
    }
    return { set: u, widgetKeys: c };
  }
  buildFullSet(n, e, t) {
    const r = this.runCreate(n, "create", () =>
      e.create({ editor: this.editor, state: t, view: this.mountedView }),
    );
    return qg(t.doc, r, n);
  }
  runCreate(n, e, t) {
    try {
      return t();
    } catch (r) {
      return (
        console.error(
          `[tiptap error]: Extension "${n}" threw in \`addDecorations().${e}()\`. Its decorations were dropped for this update.`,
          r,
        ),
        []
      );
    }
  }
  warnDuplicateWidgetKeys(n) {}
  buildMergedSet(n, e) {
    const t = Object.keys(e);
    return t.length === 1 ? e[t[0]] : jl(n, e);
  }
  mergeAfterApply({
    entries: n,
    previous: e,
    tr: t,
    decorationSetsByExtension: r,
    recomputedNames: i,
  }) {
    return n.length === 1
      ? r[n[0].name]
      : i.size === 0
        ? e.mergedDecorationSet.map(t.mapping, t.doc)
        : jl(t.doc, r);
  }
};
function ny(n, e) {
  const { selection: t } = n,
    { $from: r } = t;
  if (t instanceof O) {
    const s = r.index();
    return r.parent.canReplaceWith(s, s + 1, e);
  }
  let i = r.depth;
  for (; i >= 0;) {
    const s = r.index(i);
    if (r.node(i).contentMatchAt(s).matchType(e)) return !0;
    i -= 1;
  }
  return !1;
}
function ry(n, e, t) {
  const r = document.querySelector("style[data-tiptap-style]");
  if (r !== null) return r;
  const i = document.createElement("style");
  return (
    e && i.setAttribute("nonce", e),
    i.setAttribute("data-tiptap-style", ""),
    (i.innerHTML = n),
    document.getElementsByTagName("head")[0].appendChild(i),
    i
  );
}
function iy(n) {
  return typeof n == "number";
}
function sy(n) {
  return Object.prototype.toString.call(n).slice(8, -1);
}
function er(n) {
  return sy(n) !== "Object"
    ? !1
    : n.constructor === Object && Object.getPrototypeOf(n) === Object.prototype;
}
function oy(n, e) {
  return n.replace(/^[ \t]*/, (t) => {
    let i = 0;
    for (const s of t) i += s === "	" ? 4 - (i % 4) : 1;
    return " ".repeat(Math.max(0, i - e));
  });
}
function ly(n, e) {
  const t = `text
${n}
`,
    r = e(t)[0];
  return (r?.type === "paragraph" || r?.type === "text") && r.raw === t;
}
function ay(n, e, t) {
  var r;
  const i = e.split(`
`),
    s =
      (r = t.isParagraphContinuation) !== null && r !== void 0
        ? r
        : (l) => ly(l, t.blockTokens);
  let o = 0;
  for (const l of i) {
    if (!l.trim() || !s(l)) break;
    o += 1;
  }
  return {
    mainContent: [n, ...i.slice(0, o).map((l) => l.trimStart())].join(`
`),
    nestedContent: i.slice(o).join(`
`),
  };
}
function _l(n, e, t) {
  const r = n.split(`
`),
    i = [];
  let s = "",
    o = 0;
  const l = e.baseIndentSize || 2;
  for (; o < r.length;) {
    const u = r[o],
      d = u.match(e.itemPattern);
    if (!d) {
      if (i.length > 0) break;
      if (u.trim() === "") {
        ((o += 1),
          (s = `${s}${u}
`));
        continue;
      } else return;
    }
    const f = e.extractItemData(d),
      { indentLevel: h, mainContent: p } = f;
    s = `${s}${u}
`;
    const g = [p];
    for (o += 1; o < r.length;) {
      var a;
      const x = r[o];
      if (x.trim() === "") {
        var c;
        const w = r.slice(o + 1).findIndex((M) => M.trim() !== "");
        if (w === -1) break;
        if (
          (((c = r[o + 1 + w].match(/^(\s*)/)) === null ||
          c === void 0 ||
          (c = c[1]) === null ||
          c === void 0
            ? void 0
            : c.length) || 0) > h
        ) {
          (g.push(x),
            (s = `${s}${x}
`),
            (o += 1));
          continue;
        } else break;
      }
      if (
        (((a = x.match(/^(\s*)/)) === null ||
        a === void 0 ||
        (a = a[1]) === null ||
        a === void 0
          ? void 0
          : a.length) || 0) > h
      )
        (g.push(x),
          (s = `${s}${x}
`),
          (o += 1));
      else break;
    }
    let m;
    const y = g.slice(1);
    if (y.length > 0) {
      const x = ay(
        p,
        y.map((M) => oy(M, h + l)).join(`
`),
        t,
      );
      f.mainContent = x.mainContent;
      const w = x.nestedContent;
      w.trim() &&
        (e.customNestedParser
          ? (m = e.customNestedParser(w))
          : (m = t.blockTokens(w)));
    }
    const k = e.createToken(f, m);
    i.push(k);
  }
  if (i.length !== 0) return { items: i, raw: s.slice(0, n.length) };
}
const Wl = 4;
function ql(n) {
  let e = 0;
  for (const t of n) e = t === "	" ? e + Wl - (e % Wl) : e + 1;
  return e;
}
function Iu(n, e, t, r, i) {
  if (!n || !Array.isArray(n.content)) return "";
  const s = typeof t == "function" ? t(r) : t,
    [o, ...l] = n.content,
    a = e.renderChildren([o]);
  let c = `${s}${
    i?.indentMainContent
      ? a
          .split(
            `
`,
          )
          .map((u, d) => (d === 0 ? u : e.indent(u))).join(`
`)
      : a
  }`;
  return (
    l &&
      l.length > 0 &&
      l.forEach((u, d) => {
        var f, h;
        const p =
          (f =
            (h = e.renderChild) === null || h === void 0
              ? void 0
              : h.call(e, u, d + 1)) !== null && f !== void 0
            ? f
            : e.renderChildren([u]);
        if (p != null) {
          const g = (y) => {
              if (!i?.alignNestedToPrefix) return e.indent(y);
              const k = e.indent(""),
                x = ql(s);
              return (ql(k) >= x ? k : " ".repeat(x)) + y;
            },
            m = p
              .split(
                `
`,
              )
              .map((y) => g(y || "")).join(`
`);
          c +=
            u.type === "paragraph"
              ? `

${m}`
              : `
${m}`;
        }
      }),
    c
  );
}
function Lu(n, e) {
  const t = { ...n };
  return (
    er(n) &&
      er(e) &&
      Object.keys(e).forEach((r) => {
        er(e[r]) && er(n[r]) ? (t[r] = Lu(n[r], e[r])) : (t[r] = e[r]);
      }),
    t
  );
}
function cy(n, e, t = {}) {
  const { state: r } = e,
    { doc: i, tr: s } = r,
    o = n;
  (i.descendants((l, a) => {
    const c = s.mapping.map(a),
      u = s.mapping.map(a) + l.nodeSize;
    let d = null;
    if (
      (l.marks.forEach((h) => {
        if (h !== o) return !1;
        d = h;
      }),
      !d)
    )
      return;
    let f = !1;
    if (
      (Object.keys(t).forEach((h) => {
        t[h] !== d.attrs[h] && (f = !0);
      }),
      f)
    ) {
      const h = n.type.create({ ...n.attrs, ...t });
      (s.removeMark(c, u, n.type), s.addMark(c, u, h));
    }
  }),
    s.docChanged && e.view.dispatch(s));
}
var Wn = class {
  constructor(n) {
    var e;
    ((this.find = n.find),
      (this.handler = n.handler),
      (this.undoable = (e = n.undoable) !== null && e !== void 0 ? e : !0));
  }
};
const uy = (n, e) => {
  if (Xs(e)) return e.exec(n);
  const t = e(n);
  if (!t) return null;
  const r = [t.text];
  return (
    (r.index = t.index),
    (r.input = n),
    (r.data = t.data),
    t.replaceWith &&
      (t.text.includes(t.replaceWith) ||
        console.warn(
          '[tiptap warn]: "inputRuleMatch.replaceWith" must be part of "inputRuleMatch.text".',
        ),
      r.push(t.replaceWith)),
    r
  );
};
function dy(n) {
  const { editor: e, from: t, to: r, text: i, insertText: s } = n;
  if (!s) return { inputTransaction: null, tr: e.view.state.tr };
  const o = e.view.state.tr.insertText(i, t, r);
  return {
    inputTransaction: o,
    tr: Fe.create({
      doc: o.doc,
      selection: o.selection,
      storedMarks: o.storedMarks,
    }).tr,
  };
}
function fy(n) {
  const {
      editor: e,
      from: t,
      to: r,
      text: i,
      rule: s,
      match: o,
      plugin: l,
      insertText: a,
    } = n,
    { view: c } = e,
    { inputTransaction: u, tr: d } = dy({
      editor: e,
      from: t,
      to: r,
      text: i,
      insertText: a,
    }),
    f = u ? t + i.length : r,
    h = hi({ state: c.state, transaction: d }),
    p = { from: t - (o[0].length - i.length), to: f },
    { commands: g, chain: m, can: y } = new Jt({ editor: e, state: h });
  return s.handler({
    state: h,
    range: p,
    match: o,
    commands: g,
    chain: m,
    can: y,
  }) === null || !d.steps.length
    ? !1
    : ((u && (c.dispatch(u), !c.state.doc.eq(u.doc))) ||
        (Xp(d),
        d.setMeta("inputRule", !0),
        s.undoable && d.setMeta(l, { transform: d, from: t, to: f, text: i }),
        c.dispatch(d)),
      !0);
}
function hy(n, e, t) {
  const r = e[0].length - t.length;
  if (r <= 0) return !0;
  const i = n.parentOffset - r;
  return i >= 0 && n.parent.textBetween(i, n.parentOffset) === e[0].slice(0, r);
}
function tr(n) {
  var e;
  const {
      editor: t,
      from: r,
      to: i,
      text: s,
      rules: o,
      plugin: l,
      insertText: a,
    } = n,
    { view: c } = t;
  if (c.composing) return !1;
  const u = c.state.doc.resolve(r);
  if (
    u.parent.type.spec.code ||
    (!((e = u.nodeBefore || u.nodeAfter) === null || e === void 0) &&
      e.marks.find((f) => f.type.spec.code))
  )
    return !1;
  const d = lg(u) + s;
  for (const f of o) {
    const h = uy(d, f.find);
    if (
      !(!h || !hy(u, h, s)) &&
      fy({
        editor: t,
        from: r,
        to: i,
        text: s,
        rule: f,
        match: h,
        plugin: l,
        insertText: a,
      })
    )
      return !0;
  }
  return !1;
}
function py(n) {
  const { editor: e, rules: t } = n,
    r = new V({
      state: {
        init() {
          return null;
        },
        apply(i, s, o) {
          const l = i.getMeta(r);
          if (l) return l;
          const a = i.getMeta("applyInputRules");
          return (
            a &&
              setTimeout(() => {
                let { text: c } = a;
                typeof c == "string" ? (c = c) : (c = eo(b.from(c), o.schema));
                const { from: u } = a,
                  d = u + c.length;
                tr({ editor: e, from: u, to: d, text: c, rules: t, plugin: r });
              }),
            i.selectionSet || i.docChanged ? null : s
          );
        },
      },
      props: {
        handleTextInput(i, s, o, l) {
          return tr({
            editor: e,
            from: s,
            to: o,
            text: l,
            rules: t,
            plugin: r,
            insertText: !0,
          });
        },
        handleDOMEvents: {
          compositionend: (i) => (
            setTimeout(() => {
              const { $cursor: s } = i.state.selection;
              s &&
                tr({
                  editor: e,
                  from: s.pos,
                  to: s.pos,
                  text: "",
                  rules: t,
                  plugin: r,
                });
            }),
            !1
          ),
        },
        handleKeyDown(i, s) {
          if (s.key !== "Enter") return !1;
          const { $cursor: o } = i.state.selection;
          return o
            ? tr({
                editor: e,
                from: o.pos,
                to: o.pos,
                text: `
`,
                rules: t,
                plugin: r,
              })
            : !1;
        },
      },
      isInputRules: !0,
    });
  return r;
}
var ro = class {
    constructor(n = {}) {
      ((this.type = "extendable"),
        (this.parent = null),
        (this.child = null),
        (this.name = ""),
        (this.config = { name: this.name }),
        (this.config = { ...this.config, ...n }),
        (this.name = this.config.name));
    }
    get options() {
      return { ...B(v(this, "addOptions", { name: this.name })) };
    }
    get storage() {
      return {
        ...B(v(this, "addStorage", { name: this.name, options: this.options })),
      };
    }
    configure(n = {}) {
      const e = this.extend({
        ...this.config,
        addOptions: () => Lu(this.options, n),
      });
      return (
        (e.name = this.name),
        (e.parent = this.parent),
        (this.child = null),
        e
      );
    }
    extend(n = {}) {
      const e = new this.constructor({ ...this.config, ...n });
      return (
        (e.parent = this),
        (this.child = e),
        (e.name = "name" in n ? n.name : e.parent.name),
        e
      );
    }
  },
  It = class Pu extends ro {
    constructor(...e) {
      (super(...e), (this.type = "mark"));
    }
    static create(e = {}) {
      const t = typeof e == "function" ? e() : e;
      return new Pu(t);
    }
    static handleExit({ editor: e, mark: t }) {
      const { tr: r } = e.state,
        i = e.state.selection.$from;
      if (i.pos === i.end()) {
        const s = i.marks();
        if (!s.find((l) => l?.type.name === t.name)) return !1;
        const o = s.find((l) => l?.type.name === t.name);
        return (
          o && r.removeStoredMark(o),
          r.insertText(" ", i.pos),
          e.view.dispatch(r),
          !0
        );
      }
      return !1;
    }
    configure(e) {
      return super.configure(e);
    }
    extend(e) {
      const t = typeof e == "function" ? e() : e;
      return super.extend(t);
    }
  },
  Bu = class {
    constructor(n) {
      ((this.find = n.find), (this.handler = n.handler));
    }
  };
const my = (n, e, t) => {
  if (Xs(e)) return [...n.matchAll(e)];
  const r = e(n, t);
  return r
    ? r.map((i) => {
        const s = [i.text];
        return (
          (s.index = i.index),
          (s.input = n),
          (s.data = i.data),
          i.replaceWith &&
            (i.text.includes(i.replaceWith) ||
              console.warn(
                '[tiptap warn]: "pasteRuleMatch.replaceWith" must be part of "pasteRuleMatch.text".',
              ),
            s.push(i.replaceWith)),
          s
        );
      })
    : [];
};
function gy(n) {
  const {
      editor: e,
      state: t,
      from: r,
      to: i,
      rule: s,
      pasteEvent: o,
      dropEvent: l,
    } = n,
    { commands: a, chain: c, can: u } = new Jt({ editor: e, state: t }),
    d = [];
  return (
    t.doc.nodesBetween(r, i, (f, h) => {
      var p, g, m, y;
      if (
        (!(
          (p = f.type) === null ||
          p === void 0 ||
          (p = p.spec) === null ||
          p === void 0
        ) &&
          p.code) ||
        !(f.isText || f.isTextblock || f.isInline)
      )
        return;
      const k =
          (g =
            (m = (y = f.content) === null || y === void 0 ? void 0 : y.size) !==
              null && m !== void 0
              ? m
              : f.nodeSize) !== null && g !== void 0
            ? g
            : 0,
        x = Math.max(r, h),
        w = Math.min(i, h + k);
      if (x >= w) return;
      const M = f.isText
        ? f.text || ""
        : f.textBetween(x - h, w - h, void 0, "￼");
      my(M, s.find, o).forEach((D) => {
        if (D.index === void 0) return;
        const E = x + D.index + 1,
          I = E + D[0].length,
          L = { from: t.tr.mapping.map(E), to: t.tr.mapping.map(I) },
          F = s.handler({
            state: t,
            range: L,
            match: D,
            commands: a,
            chain: c,
            can: u,
            pasteEvent: o,
            dropEvent: l,
          });
        d.push(F);
      });
    }),
    d.every((f) => f !== null)
  );
}
let zt = null;
const yy = (n) => {
  var e;
  const t = new ClipboardEvent("paste", { clipboardData: new DataTransfer() });
  return (
    (e = t.clipboardData) === null || e === void 0 || e.setData("text/html", n),
    t
  );
};
function by(n) {
  const { editor: e, rules: t } = n;
  let r = null,
    i = !1,
    s = !1,
    o = typeof ClipboardEvent < "u" ? new ClipboardEvent("paste") : null,
    l;
  try {
    l = typeof DragEvent < "u" ? new DragEvent("drop") : null;
  } catch {
    l = null;
  }
  const a = ({ state: c, from: u, to: d, rule: f, pasteEvt: h }) => {
    const p = c.tr,
      g = hi({ state: c, transaction: p });
    if (!(
      !gy({
        editor: e,
        state: g,
        from: Math.max(u - 1, 0),
        to: d.b - 1,
        rule: f,
        pasteEvent: h,
        dropEvent: l,
      }) || !p.steps.length
    )) {
      try {
        l = typeof DragEvent < "u" ? new DragEvent("drop") : null;
      } catch {
        l = null;
      }
      return (
        (o = typeof ClipboardEvent < "u" ? new ClipboardEvent("paste") : null),
        p
      );
    }
  };
  return (
    e.on("destroy", () => {
      zt === e && (zt = null);
    }),
    t.map(
      (c) =>
        new V({
          view(u) {
            const d = (h) => {
                var p;
                ((r =
                  !((p = u.dom.parentElement) === null || p === void 0) &&
                  p.contains(h.target)
                    ? u.dom.parentElement
                    : null),
                  r && (zt = e));
              },
              f = () => {
                zt && (zt = null);
              };
            return (
              window.addEventListener("dragstart", d),
              window.addEventListener("dragend", f),
              {
                destroy() {
                  (window.removeEventListener("dragstart", d),
                    window.removeEventListener("dragend", f));
                },
              }
            );
          },
          props: {
            handleDOMEvents: {
              drop: (u, d) => {
                if (((s = r === u.dom.parentElement), (l = d), !s)) {
                  const f = zt;
                  f?.isEditable &&
                    setTimeout(() => {
                      if (f.isDestroyed) return;
                      const h = f.state.selection;
                      h && f.commands.deleteRange({ from: h.from, to: h.to });
                    }, 10);
                }
                return !1;
              },
              paste: (u, d) => {
                var f;
                const h =
                  (f = d.clipboardData) === null || f === void 0
                    ? void 0
                    : f.getData("text/html");
                return ((o = d), (i = !!h?.includes("data-pm-slice")), !1);
              },
            },
          },
          appendTransaction: (u, d, f) => {
            const h = u[0],
              p = h.getMeta("uiEvent") === "paste" && !i,
              g = h.getMeta("uiEvent") === "drop" && !s,
              m = h.getMeta("applyPasteRules"),
              y = !!m;
            if (!p && !g && !y) return;
            if (y) {
              let { text: w } = m;
              typeof w == "string" ? (w = w) : (w = eo(b.from(w), f.schema));
              const { from: M } = m,
                D = M + w.length,
                E = yy(w);
              return a({
                rule: c,
                state: f,
                from: M,
                to: { b: D },
                pasteEvt: E,
              });
            }
            const k = d.doc.content.findDiffStart(f.doc.content),
              x = d.doc.content.findDiffEnd(f.doc.content);
            if (!(!iy(k) || !x || k === x.b))
              return a({ rule: c, state: f, from: k, to: x, pasteEvt: o });
          },
        }),
    )
  );
}
var bi = class {
  constructor(n, e) {
    ((this.splittableMarks = []),
      (this.nonClearableMarks = []),
      (this.decorationManager = null),
      (this.editor = e),
      (this.baseExtensions = n),
      (this.extensions = ku(n)),
      (this.hasSchemaSpec = e.options.schemaSpec !== void 0),
      (this.schema = eg(this.extensions, e, e.options.schemaSpec)),
      this.setupExtensions());
  }
  get commands() {
    return this.extensions.reduce((n, e) => {
      const t = v(e, "addCommands", {
        name: e.name,
        options: e.options,
        storage: this.editor.extensionStorage[e.name],
        editor: this.editor,
        type: $t(e.name, this.schema),
      });
      return t ? { ...n, ...t() } : n;
    }, {});
  }
  get plugins() {
    const { editor: n } = this,
      e = kn([...this.extensions].reverse()).flatMap((r) => {
        const i = {
            name: r.name,
            options: r.options,
            storage: this.editor.extensionStorage[r.name],
            editor: n,
            type: $t(r.name, this.schema),
          },
          s = [],
          o = v(r, "addKeyboardShortcuts", i);
        let l = {};
        if (
          (r.type === "mark" &&
            v(r, "exitable", i) &&
            (l.ArrowRight = () => It.handleExit({ editor: n, mark: r })),
          o)
        ) {
          const f = Object.fromEntries(
            Object.entries(o()).map(([h, p]) => [h, () => p({ editor: n })]),
          );
          l = { ...l, ...f };
        }
        const a = _p(l);
        s.push(a);
        const c = v(r, "addInputRules", i);
        if ($l(r, n.options.enableInputRules) && c) {
          const f = c();
          if (f && f.length) {
            const h = py({ editor: n, rules: f }),
              p = Array.isArray(h) ? h : [h];
            s.push(...p);
          }
        }
        const u = v(r, "addPasteRules", i);
        if ($l(r, n.options.enablePasteRules) && u) {
          const f = u();
          if (f && f.length) {
            const h = by({ editor: n, rules: f });
            s.push(...h);
          }
        }
        const d = v(r, "addProseMirrorPlugins", i);
        if (d) {
          const f = d();
          s.push(...f);
        }
        return s;
      }),
      t = this.createDecorationPlugin();
    return (t && e.push(t), e);
  }
  createDecorationPlugin() {
    var n;
    const { editor: e } = this;
    (n = this.decorationManager) === null || n === void 0 || n.destroy();
    const t = [];
    return (
      this.extensions.forEach((r) => {
        const i = v(r, "addDecorations", {
          name: r.name,
          options: r.options,
          storage: this.editor.extensionStorage[r.name],
          editor: e,
          type: $t(r.name, this.schema),
        });
        i && t.push({ name: r.name, addDecorations: i });
      }),
      (this.decorationManager = new ty({ editor: e, entries: t })),
      this.decorationManager.plugin
    );
  }
  get attributes() {
    const n = to(this.extensions);
    return this.hasSchemaSpec ? yu(n, this.schema) : n;
  }
  get nodeViews() {
    const { editor: n } = this,
      { nodeExtensions: e } = en(this.extensions);
    return Object.fromEntries(
      e
        .filter((t) => !!v(t, "addNodeView"))
        .map((t) => {
          const r = this.attributes.filter((l) => l.type === t.name),
            i = v(t, "addNodeView", {
              name: t.name,
              options: t.options,
              storage: this.editor.extensionStorage[t.name],
              editor: n,
              type: Y(t.name, this.schema),
            });
          if (!i) return [];
          const s = i();
          if (!s) return [];
          const o = (l, a, c, u, d) => {
            const f = Bn(l, r);
            return s({
              node: l,
              view: a,
              getPos: c,
              decorations: u,
              innerDecorations: d,
              editor: n,
              extension: t,
              HTMLAttributes: f,
            });
          };
          return [t.name, o];
        }),
    );
  }
  dispatchTransaction(n) {
    const { editor: e } = this;
    return kn([...this.extensions].reverse()).reduceRight((t, r) => {
      const i = {
          name: r.name,
          options: r.options,
          storage: this.editor.extensionStorage[r.name],
          editor: e,
          type: $t(r.name, this.schema),
        },
        s = v(r, "dispatchTransaction", i);
      return s
        ? (o) => {
            s.call(i, { transaction: o, next: t });
          }
        : t;
    }, n);
  }
  transformPastedHTML(n) {
    const { editor: e } = this;
    return kn([...this.extensions]).reduce(
      (t, r) => {
        const i = {
            name: r.name,
            options: r.options,
            storage: this.editor.extensionStorage[r.name],
            editor: e,
            type: $t(r.name, this.schema),
          },
          s = v(r, "transformPastedHTML", i);
        return s
          ? (o, l) => {
              const a = t(o, l);
              return s.call(i, a);
            }
          : t;
      },
      n || ((t) => t),
    );
  }
  get markViews() {
    const { editor: n } = this,
      { markExtensions: e } = en(this.extensions);
    return Object.fromEntries(
      e
        .filter((t) => !!v(t, "addMarkView"))
        .map((t) => {
          const r = this.attributes.filter((o) => o.type === t.name),
            i = v(t, "addMarkView", {
              name: t.name,
              options: t.options,
              storage: this.editor.extensionStorage[t.name],
              editor: n,
              type: qe(t.name, this.schema),
            });
          if (!i) return [];
          const s = (o, l, a) => {
            const c = Bn(o, r);
            return i()({
              mark: o,
              view: l,
              inline: a,
              editor: n,
              extension: t,
              HTMLAttributes: c,
              updateAttributes: (u) => {
                cy(o, n, u);
              },
            });
          };
          return [t.name, s];
        }),
    );
  }
  destroy() {
    var n;
    ((n = this.decorationManager) === null || n === void 0 || n.destroy(),
      this.extensions.forEach((e) => {
        let t = e;
        for (; t.parent;) {
          const r = t.parent;
          (r.child === t && (r.child = null), (t = r));
        }
      }),
      (this.extensions = []),
      (this.baseExtensions = []),
      (this.decorationManager = null),
      (this.schema = null),
      (this.editor = null));
  }
  setupExtensions() {
    const n = this.extensions;
    ((this.editor.extensionStorage = Object.fromEntries(
      n.map((e) => [e.name, e.storage]),
    )),
      n.forEach((e) => {
        const t = {
          name: e.name,
          options: e.options,
          storage: this.editor.extensionStorage[e.name],
          editor: this.editor,
          type: $t(e.name, this.schema),
        };
        if (e.type === "mark") {
          var r, i;
          ((!((r = B(v(e, "keepOnSplit", t))) !== null && r !== void 0) || r) &&
            this.splittableMarks.push(e.name),
            !((i = B(v(e, "clearable", t))) !== null && i !== void 0) ||
              i ||
              this.nonClearableMarks.push(e.name));
        }
        const s = v(e, "onBeforeCreate", t),
          o = v(e, "onCreate", t),
          l = v(e, "onUpdate", t),
          a = v(e, "onSelectionUpdate", t),
          c = v(e, "onTransaction", t),
          u = v(e, "onFocus", t),
          d = v(e, "onBlur", t),
          f = v(e, "onDestroy", t);
        (s && this.editor.on("beforeCreate", s),
          o && this.editor.on("create", o),
          l && this.editor.on("update", l),
          a && this.editor.on("selectionUpdate", a),
          c && this.editor.on("transaction", c),
          u && this.editor.on("focus", u),
          d && this.editor.on("blur", d),
          f && this.editor.on("destroy", f));
      }));
  }
};
bi.resolve = ku;
bi.sort = kn;
bi.flatten = Zs;
var q = class $u extends ro {
  constructor(...e) {
    (super(...e), (this.type = "extension"));
  }
  static create(e = {}) {
    const t = typeof e == "function" ? e() : e;
    return new $u(t);
  }
  configure(e) {
    return super.configure(e);
  }
  extend(e) {
    const t = typeof e == "function" ? e() : e;
    return super.extend(t);
  }
};
const ky = q.create({
    name: "clipboardTextSerializer",
    addOptions() {
      return { blockSeparator: void 0 };
    },
    addProseMirrorPlugins() {
      return [
        new V({
          key: new K("clipboardTextSerializer"),
          props: {
            clipboardTextSerializer: () => {
              const { editor: n } = this,
                { state: e, schema: t } = n,
                { doc: r, selection: i } = e,
                s = xu(t),
                { blockSeparator: o } = this.options,
                l = {
                  ...(o !== void 0 ? { blockSeparator: o } : {}),
                  textSerializers: s,
                };
              return [...i.ranges]
                .sort((a, c) => a.$from.pos - c.$from.pos)
                .map(({ $from: a, $to: c }) =>
                  Su(r, { from: a.pos, to: c.pos }, l),
                )
                .join(
                  o ??
                    `

`,
                );
            },
          },
        }),
      ];
    },
  }),
  Sy = q.create({
    name: "commands",
    addCommands() {
      return { ...jg };
    },
  }),
  xy = q.create({
    name: "delete",
    onUpdate({ transaction: n, appendedTransactions: e }) {
      var t, r;
      const i = () => {
        var s, o, l;
        if (
          (s =
            (o = this.editor.options.coreExtensionOptions) === null ||
            o === void 0 ||
            (o = o.delete) === null ||
            o === void 0 ||
            (l = o.filterTransaction) === null ||
            l === void 0
              ? void 0
              : l.call(o, n)) !== null && s !== void 0
            ? s
            : n.getMeta("y-sync$")
        )
          return;
        const a = gu(n.before, [n, ...e]);
        gi(a).forEach((u) => {
          a.mapping.mapResult(u.oldRange.from).deletedAfter &&
            a.mapping.mapResult(u.oldRange.to).deletedBefore &&
            a.before.nodesBetween(u.oldRange.from, u.oldRange.to, (d, f) => {
              const h = f + d.nodeSize - 2,
                p = u.oldRange.from <= f && h <= u.oldRange.to;
              this.editor.emit("delete", {
                type: "node",
                node: d,
                from: f,
                to: h,
                newFrom: a.mapping.map(f),
                newTo: a.mapping.map(h),
                deletedRange: u.oldRange,
                newRange: u.newRange,
                partial: !p,
                editor: this.editor,
                transaction: n,
                combinedTransform: a,
              });
            });
        });
        const c = a.mapping;
        a.steps.forEach((u, d) => {
          if (u instanceof Ne) {
            var f, h;
            const p = c.slice(d).map(u.from, -1),
              g = c.slice(d).map(u.to),
              m = c.invert().map(p, -1),
              y = c.invert().map(g),
              k =
                p > 0
                  ? (f = a.doc.nodeAt(p - 1)) === null || f === void 0
                    ? void 0
                    : f.marks.some((w) => w.eq(u.mark))
                  : !1,
              x =
                (h = a.doc.nodeAt(g)) === null || h === void 0
                  ? void 0
                  : h.marks.some((w) => w.eq(u.mark));
            this.editor.emit("delete", {
              type: "mark",
              mark: u.mark,
              from: u.from,
              to: u.to,
              deletedRange: { from: m, to: y },
              newRange: { from: p, to: g },
              partial: !!(x || k),
              editor: this.editor,
              transaction: n,
              combinedTransform: a,
            });
          }
        });
      };
      !(
        (t =
          (r = this.editor.options.coreExtensionOptions) === null ||
          r === void 0 ||
          (r = r.delete) === null ||
          r === void 0
            ? void 0
            : r.async) !== null && t !== void 0
      ) || t
        ? setTimeout(i, 0)
        : i();
    },
  }),
  wy = q.create({
    name: "drop",
    addProseMirrorPlugins() {
      return [
        new V({
          key: new K("tiptapDrop"),
          props: {
            handleDrop: (n, e, t, r) => {
              this.editor.emit("drop", {
                editor: this.editor,
                event: e,
                slice: t,
                moved: r,
              });
            },
          },
        }),
      ];
    },
  }),
  Cy = q.create({
    name: "editable",
    addProseMirrorPlugins() {
      return [
        new V({
          key: new K("editable"),
          props: { editable: () => this.editor.options.editable },
        }),
      ];
    },
  }),
  vy = new K("focusEvents"),
  My = q.create({
    name: "focusEvents",
    addProseMirrorPlugins() {
      const { editor: n } = this;
      return [
        new V({
          key: vy,
          props: {
            handleDOMEvents: {
              focus: (e, t) => {
                n.isFocused = !0;
                const r = n.state.tr
                  .setMeta("focus", { event: t })
                  .setMeta("addToHistory", !1);
                return (e.dispatch(r), !1);
              },
              blur: (e, t) => {
                n.isFocused = !1;
                const r = n.state.tr
                  .setMeta("blur", { event: t })
                  .setMeta("addToHistory", !1);
                return (e.dispatch(r), !1);
              },
            },
          },
        }),
      ];
    },
  }),
  Ey = q.create({
    name: "keymap",
    addKeyboardShortcuts() {
      const n = () =>
          this.editor.commands.first(({ commands: o }) => [
            () => o.undoInputRule(),
            () =>
              o.command(({ tr: l }) => {
                const { selection: a, doc: c } = l,
                  { empty: u, $anchor: d } = a,
                  { pos: f, parent: h } = d,
                  p = d.parent.isTextblock && f > 0 ? l.doc.resolve(f - 1) : d,
                  g = p.parent.type.spec.isolating,
                  m = d.pos - d.parentOffset,
                  y =
                    g && p.parent.childCount === 1
                      ? m === d.pos
                      : N.atStart(c).from === f;
                return !u ||
                  !h.type.isTextblock ||
                  h.textContent.length ||
                  !y ||
                  (y && d.parent.type.name === "paragraph")
                  ? !1
                  : o.clearNodes();
              }),
            () => o.deleteSelection(),
            () => o.joinBackward(),
            () => o.selectNodeBackward(),
          ]),
        e = () =>
          this.editor.commands.first(({ commands: o }) => [
            () => o.deleteSelection(),
            () => o.deleteCurrentNode(),
            () => o.joinForward(),
            () => o.selectNodeForward(),
          ]),
        r = {
          Enter: () =>
            this.editor.commands.first(({ commands: o }) => [
              () => o.newlineInCode(),
              () => o.createParagraphNear(),
              () => o.liftEmptyBlock(),
              () => o.splitBlock(),
            ]),
          "Mod-Enter": () => this.editor.commands.exitCode(),
          Backspace: n,
          "Mod-Backspace": n,
          "Shift-Backspace": n,
          Delete: e,
          "Mod-Delete": e,
          "Mod-a": () => this.editor.commands.selectAll(),
        },
        i = { ...r },
        s = {
          ...r,
          "Ctrl-h": n,
          "Alt-Backspace": n,
          "Ctrl-d": e,
          "Ctrl-Alt-Backspace": e,
          "Alt-Delete": e,
          "Alt-d": e,
          "Ctrl-a": () => this.editor.commands.selectTextblockStart(),
          "Ctrl-e": () => this.editor.commands.selectTextblockEnd(),
        };
      return Pn() || pu() ? s : i;
    },
    addProseMirrorPlugins() {
      return [
        new V({
          key: new K("clearDocument"),
          appendTransaction: (n, e, t) => {
            if (n.some((h) => h.getMeta("composition"))) return;
            const r = n.some((h) => h.docChanged) && !e.doc.eq(t.doc),
              i = n.some((h) => h.getMeta("preventClearDocument"));
            if (!r || i) return;
            const { empty: s, from: o, to: l } = e.selection,
              a = N.atStart(e.doc).from,
              c = N.atEnd(e.doc).to;
            if (s || !(o === a && l === c) || !_n(t.doc)) return;
            const u = t.tr,
              d = hi({ state: t, transaction: u }),
              { commands: f } = new Jt({ editor: this.editor, state: d });
            if ((f.clearNodes(), !!u.steps.length)) return u;
          },
        }),
      ];
    },
  }),
  Ty = q.create({
    name: "paste",
    addProseMirrorPlugins() {
      return [
        new V({
          key: new K("tiptapPaste"),
          props: {
            handlePaste: (n, e, t) => {
              this.editor.emit("paste", {
                editor: this.editor,
                event: e,
                slice: t,
              });
            },
          },
        }),
      ];
    },
  }),
  Ay = q.create({
    name: "tabindex",
    addOptions() {
      return { value: void 0 };
    },
    addProseMirrorPlugins() {
      return [
        new V({
          key: new K("tabindex"),
          props: {
            attributes: () => {
              var n;
              return !this.editor.isEditable && this.options.value === void 0
                ? {}
                : {
                    tabindex:
                      (n = this.options.value) !== null && n !== void 0
                        ? n
                        : "0",
                  };
            },
          },
        }),
      ];
    },
  }),
  Oy = q.create({
    name: "textDirection",
    addOptions() {
      return { direction: void 0 };
    },
    addGlobalAttributes() {
      if (!this.options.direction) return [];
      const { nodeExtensions: n } = en(this.extensions);
      return [
        {
          types: n.filter((e) => e.name !== "text").map((e) => e.name),
          attributes: {
            dir: {
              default: this.options.direction,
              parseHTML: (e) => {
                const t = e.getAttribute("dir");
                return t && (t === "ltr" || t === "rtl" || t === "auto")
                  ? t
                  : this.options.direction;
              },
              renderHTML: (e) => (e.dir ? { dir: e.dir } : {}),
            },
          },
        },
      ];
    },
    addProseMirrorPlugins() {
      return [
        new V({
          key: new K("textDirection"),
          props: {
            attributes: () => {
              const n = this.options.direction;
              return n ? { dir: n } : {};
            },
          },
        }),
      ];
    },
  });
let Ul = !1;
function Ny(n) {
  if (Ul) return;
  Ul = !0;
  let e;
  try {
    const t = _.fromJSON(n, { from: 0, to: 0 });
    if (!fg(t)) return;
    e = t.slice.content;
  } catch {
    return;
  }
  e instanceof b ||
    console.warn(
      "[tiptap warn]: prosemirror-model is loaded more than once. Wrapping and splitting nodes will fail. Deduplicate it in your lock file, or alias it to a single copy in your bundler.",
    );
}
var Dy = class hn {
  get name() {
    return this.node.type.name;
  }
  constructor(e, t, r = !1, i = null) {
    ((this.currentNode = null),
      (this.actualDepth = null),
      (this.isBlock = r),
      (this.resolvedPos = e),
      (this.editor = t),
      (this.currentNode = i));
  }
  get node() {
    return this.currentNode || this.resolvedPos.node();
  }
  get element() {
    return this.editor.view.domAtPos(this.pos).node;
  }
  get depth() {
    var e;
    return (e = this.actualDepth) !== null && e !== void 0
      ? e
      : this.resolvedPos.depth;
  }
  get pos() {
    return this.resolvedPos.pos;
  }
  get content() {
    return this.node.content;
  }
  set content(e) {
    let t = this.from,
      r = this.to;
    if (this.isBlock) {
      if (this.content.size === 0) {
        console.error(
          `You can’t set content on a block node. Tried to set content on ${this.name} at ${this.pos}`,
        );
        return;
      }
      ((t = this.from + 1), (r = this.to - 1));
    }
    this.editor.commands.insertContentAt({ from: t, to: r }, e);
  }
  get attributes() {
    return this.node.attrs;
  }
  get textContent() {
    return this.node.textContent;
  }
  get size() {
    return this.node.nodeSize;
  }
  get from() {
    return this.isBlock
      ? this.pos
      : this.resolvedPos.start(this.resolvedPos.depth);
  }
  get range() {
    return { from: this.from, to: this.to };
  }
  get to() {
    return this.isBlock
      ? this.pos + this.size
      : this.resolvedPos.end(this.resolvedPos.depth) +
          (this.node.isText ? 0 : 1);
  }
  get parent() {
    if (this.depth === 0) return null;
    const e = this.resolvedPos.start(this.resolvedPos.depth - 1),
      t = this.resolvedPos.doc.resolve(e);
    return new hn(t, this.editor);
  }
  get before() {
    let e = this.resolvedPos.doc.resolve(this.from - (this.isBlock ? 1 : 2));
    return (
      e.depth !== this.depth &&
        (e = this.resolvedPos.doc.resolve(this.from - 3)),
      new hn(e, this.editor)
    );
  }
  get after() {
    let e = this.resolvedPos.doc.resolve(this.to + (this.isBlock ? 2 : 1));
    return (
      e.depth !== this.depth && (e = this.resolvedPos.doc.resolve(this.to + 3)),
      new hn(e, this.editor)
    );
  }
  get children() {
    const e = [];
    return (
      this.node.content.forEach((t, r) => {
        const i = t.isBlock && !t.isTextblock,
          s = t.isAtom && !t.isText,
          o = t.isInline,
          l = this.pos + r + (s ? 0 : 1);
        if (l < 0 || l > this.resolvedPos.doc.nodeSize - 2) return;
        const a = this.resolvedPos.doc.resolve(l);
        if (!i && !o && a.depth <= this.depth) return;
        const c = new hn(a, this.editor, i, i || o ? t : null);
        (i && (c.actualDepth = this.depth + 1), e.push(c));
      }),
      e
    );
  }
  get firstChild() {
    return this.children[0] || null;
  }
  get lastChild() {
    const e = this.children;
    return e[e.length - 1] || null;
  }
  closest(e, t = {}) {
    let r = null,
      i = this.parent;
    for (; i && !r;) {
      if (i.node.type.name === e)
        if (Object.keys(t).length > 0) {
          const s = i.node.attrs,
            o = Object.keys(t);
          for (let l = 0; l < o.length; l += 1) {
            const a = o[l];
            if (s[a] !== t[a]) break;
          }
        } else r = i;
      i = i.parent;
    }
    return r;
  }
  querySelector(e, t = {}) {
    return this.querySelectorAll(e, t, !0)[0] || null;
  }
  querySelectorAll(e, t = {}, r = !1) {
    let i = [];
    if (!this.children || this.children.length === 0) return i;
    const s = Object.keys(t);
    return (
      this.children.forEach((o) => {
        (r && i.length > 0) ||
          (o.node.type.name === e &&
            s.every((l) => t[l] === o.node.attrs[l]) &&
            i.push(o),
          !(r && i.length > 0) && (i = i.concat(o.querySelectorAll(e, t, r))));
      }),
      i
    );
  }
  setAttribute(e) {
    const { tr: t } = this.editor.state;
    (t.setNodeMarkup(this.from, void 0, { ...this.node.attrs, ...e }),
      this.editor.view.dispatch(t));
  }
};
const Ry = `.ProseMirror {
  position: relative;
}

.ProseMirror {
  word-wrap: break-word;
  white-space: pre-wrap;
  white-space: break-spaces;
  -webkit-font-variant-ligatures: none;
  font-variant-ligatures: none;
  font-feature-settings: "liga" 0; /* the above doesn't seem to work in Edge */
}

.ProseMirror [contenteditable="false"] {
  white-space: normal;
}

.ProseMirror [contenteditable="false"] [contenteditable="true"] {
  white-space: pre-wrap;
}

.ProseMirror pre {
  white-space: pre-wrap;
}

img.ProseMirror-separator {
  display: inline !important;
  border: none !important;
  margin: 0 !important;
  width: 0 !important;
  height: 0 !important;
}

.ProseMirror-gapcursor {
  display: none;
  pointer-events: none;
  position: absolute;
  margin: 0;
}

.ProseMirror-gapcursor:after {
  content: "";
  display: block;
  position: absolute;
  top: -2px;
  width: 20px;
  border-top: 1px solid black;
  animation: ProseMirror-cursor-blink 1.1s steps(2, start) infinite;
}

@keyframes ProseMirror-cursor-blink {
  to {
    visibility: hidden;
  }
}

.ProseMirror-hideselection *::selection {
  background: transparent;
}

.ProseMirror-hideselection *::-moz-selection {
  background: transparent;
}

.ProseMirror-hideselection * {
  caret-color: transparent;
}

.ProseMirror-focused .ProseMirror-gapcursor {
  display: block;
}`;
var Iy = class extends _g {
  constructor(n = {}) {
    (super(),
      (this.css = null),
      (this.className = "tiptap"),
      (this.editorView = null),
      (this.isFocused = !1),
      (this.destroyed = !1),
      (this.isInitialized = !1),
      (this.extensionStorage = {}),
      (this.instanceId = Math.random().toString(36).slice(2, 9)),
      (this.hasWarnedStaleDecorationRead = !1),
      (this.options = {
        element: typeof document < "u" ? document.createElement("div") : null,
        content: "",
        injectCSS: !0,
        injectNonce: void 0,
        extensions: [],
        autofocus: !1,
        editable: !0,
        textDirection: void 0,
        editorProps: {},
        parseOptions: {},
        coreExtensionOptions: {},
        enableInputRules: !0,
        enablePasteRules: !0,
        enableCoreExtensions: !0,
        enableContentCheck: !1,
        emitContentError: !1,
        onBeforeCreate: () => null,
        onCreate: () => null,
        onMount: () => null,
        onUnmount: () => null,
        onUpdate: () => null,
        onSelectionUpdate: () => null,
        onTransaction: () => null,
        onFocus: () => null,
        onBlur: () => null,
        onDestroy: () => null,
        onContentError: ({ error: t }) => {
          throw t;
        },
        onPaste: () => null,
        onDrop: () => null,
        onDelete: () => null,
        enableExtensionDispatchTransaction: !0,
      }),
      (this.isCapturingTransaction = !1),
      (this.capturedTransaction = null),
      (this.utils = { getUpdatedPosition: hg, createMappablePosition: pg }),
      this.setOptions(n),
      this.createExtensionManager(),
      this.createCommandManager(),
      this.createSchema(),
      this.on("beforeCreate", this.options.onBeforeCreate),
      this.emit("beforeCreate", { editor: this }),
      this.on("mount", this.options.onMount),
      this.on("unmount", this.options.onUnmount),
      this.on("contentError", this.options.onContentError),
      this.on("create", this.options.onCreate),
      this.on("update", this.options.onUpdate),
      this.on("selectionUpdate", this.options.onSelectionUpdate),
      this.on("transaction", this.options.onTransaction),
      this.on("focus", this.options.onFocus),
      this.on("blur", this.options.onBlur),
      this.on("destroy", this.options.onDestroy),
      this.on("drop", ({ event: t, slice: r, moved: i }) =>
        this.options.onDrop(t, r, i),
      ),
      this.on("paste", ({ event: t, slice: r }) => this.options.onPaste(t, r)),
      this.on("delete", this.options.onDelete));
    const e = this.createDoc();
    if (!this.editorState) {
      const t = gs(e, this.options.autofocus);
      this.editorState = Fe.create({
        doc: e,
        schema: this.schema,
        selection: t || void 0,
      });
    }
    (Ny(this.schema), this.options.element && this.mount(this.options.element));
  }
  mount(n) {
    if (typeof document > "u")
      throw new Error(
        "[tiptap error]: The editor cannot be mounted because there is no 'document' defined in this environment.",
      );
    (this.createView(n),
      this.emit("mount", { editor: this }),
      this.css &&
        !document.head.contains(this.css) &&
        document.head.appendChild(this.css),
      window.setTimeout(() => {
        this.isDestroyed ||
          (this.options.autofocus !== !1 &&
            this.options.autofocus !== null &&
            this.commands.focus(this.options.autofocus),
          this.emit("create", { editor: this }),
          (this.isInitialized = !0));
      }, 0));
  }
  unmount() {
    if (this.editorView) {
      this.editorState = this.editorView.state;
      const n = this.editorView.dom;
      (n?.editor && delete n.editor, this.editorView.destroy());
    }
    if (
      ((this.editorView = null),
      (this.isInitialized = !1),
      this.css && !document.querySelectorAll(`.${this.className}`).length)
    )
      try {
        typeof this.css.remove == "function"
          ? this.css.remove()
          : this.css.parentNode && this.css.parentNode.removeChild(this.css);
      } catch (n) {
        console.warn("Failed to remove CSS element:", n);
      }
    ((this.css = null), this.emit("unmount", { editor: this }));
  }
  get storage() {
    return this.extensionStorage;
  }
  get commands() {
    return this.commandManager.commands;
  }
  chain() {
    return this.commandManager
      ? this.commandManager.chain()
      : Jt.createFakeChain();
  }
  can() {
    return this.commandManager
      ? this.commandManager.can()
      : Jt.createFallbackCan();
  }
  injectCSS() {
    this.options.injectCSS &&
      typeof document < "u" &&
      (this.css = ry(Ry, this.options.injectNonce));
  }
  setOptions(n = {}) {
    ((this.options = { ...this.options, ...n }),
      !(!this.editorView || !this.state || this.isDestroyed) &&
        (this.options.editorProps &&
          this.view.setProps({
            ...this.options.editorProps,
            attributes: this.getEditorViewAttributes(),
          }),
        this.view.updateState(this.state)));
  }
  setEditable(n, e = !0) {
    (this.setOptions({ editable: n }),
      e &&
        this.emit("update", {
          editor: this,
          transaction: this.state.tr,
          appendedTransactions: [],
        }));
  }
  get isEditable() {
    return this.options.editable && this.view && this.view.editable;
  }
  get view() {
    return this.editorView
      ? this.editorView
      : new Proxy(
          {
            state: this.editorState,
            updateState: (n) => {
              this.editorState = n;
            },
            dispatch: (n) => {
              this.dispatchTransaction(n);
            },
            composing: !1,
            dragging: null,
            editable: !0,
            isDestroyed: !1,
          },
          {
            get: (n, e) => {
              if (this.editorView) return this.editorView[e];
              if (e === "state") return this.editorState;
              if (e in n) return Reflect.get(n, e);
              throw new Error(
                `[tiptap error]: The editor view is not available. Cannot access view['${e}']. The editor may not be mounted yet.`,
              );
            },
          },
        );
  }
  get state() {
    return (
      this.editorView && (this.editorState = this.view.state),
      this.editorState
    );
  }
  registerPlugin(n, e) {
    const t = ks(e)
        ? e(n, [...this.state.plugins])
        : [...this.state.plugins, n],
      r = this.state.reconfigure({ plugins: t });
    return (this.view.updateState(r), r);
  }
  unregisterPlugin(n) {
    if (this.isDestroyed) return;
    const e = this.state.plugins;
    let t = e;
    if (
      ([].concat(n).forEach((i) => {
        const s = typeof i == "string" ? `${i}$` : i.key;
        t = t.filter((o) => !o.key.startsWith(s));
      }),
      e.length === t.length)
    )
      return;
    const r = this.state.reconfigure({ plugins: t });
    return (this.view.updateState(r), r);
  }
  createExtensionManager() {
    var n, e;
    const t = [
      ...(this.options.enableCoreExtensions
        ? [
            Cy,
            ky.configure({
              blockSeparator:
                (n = this.options.coreExtensionOptions) === null ||
                n === void 0 ||
                (n = n.clipboardTextSerializer) === null ||
                n === void 0
                  ? void 0
                  : n.blockSeparator,
            }),
            Sy,
            My,
            Ey,
            Ay.configure({
              value:
                (e = this.options.coreExtensionOptions) === null ||
                e === void 0 ||
                (e = e.tabindex) === null ||
                e === void 0
                  ? void 0
                  : e.value,
            }),
            wy,
            Ty,
            xy,
            Oy.configure({ direction: this.options.textDirection }),
          ].filter((r) =>
            typeof this.options.enableCoreExtensions == "object"
              ? this.options.enableCoreExtensions[r.name] !== !1
              : !0,
          )
        : []),
      ...this.options.extensions,
    ].filter((r) => ["extension", "node", "mark"].includes(r?.type));
    this.extensionManager = new bi(t, this);
  }
  createCommandManager() {
    this.commandManager = new Jt({ editor: this });
  }
  createSchema() {
    this.schema = this.extensionManager.schema;
  }
  createDoc() {
    let n;
    try {
      n = bs(this.options.content, this.schema, this.options.parseOptions, {
        errorOnInvalidContent: this.options.enableContentCheck,
      });
    } catch (e) {
      if (
        !(e instanceof Error) ||
        ![
          "[tiptap error]: Invalid JSON content",
          "[tiptap error]: Invalid HTML content",
        ].includes(e.message)
      )
        throw e;
      const t = bs(
        this.options.content,
        this.schema,
        this.options.parseOptions,
        { errorOnInvalidContent: !1 },
      );
      return (
        (this.editorState = Fe.create({
          doc: t,
          schema: this.schema,
          selection: gs(t, this.options.autofocus) || void 0,
        })),
        this.emit("contentError", {
          editor: this,
          error: e,
          disableCollaboration: () => {
            ("collaboration" in this.storage &&
              typeof this.storage.collaboration == "object" &&
              this.storage.collaboration &&
              (this.storage.collaboration.isDisabled = !0),
              (this.options.extensions = this.options.extensions.filter(
                (r) => r.name !== "collaboration",
              )),
              this.createExtensionManager());
          },
        }),
        this.editorState.doc
      );
    }
    return n;
  }
  getEditorViewAttributes() {
    var n;
    const e =
      (n = this.options.editorProps) === null || n === void 0
        ? void 0
        : n.attributes;
    return ks(e)
      ? (t) => ({ role: "textbox", ...e(t) })
      : { role: "textbox", ...e };
  }
  createView(n) {
    const { editorProps: e, enableExtensionDispatchTransaction: t } =
        this.options,
      r = e.dispatchTransaction || this.dispatchTransaction.bind(this),
      i = t ? this.extensionManager.dispatchTransaction(r) : r,
      s = e.transformPastedHTML,
      o = this.extensionManager.transformPastedHTML(s);
    this.editorView = new Qc(n, {
      ...e,
      attributes: this.getEditorViewAttributes(),
      dispatchTransaction: i,
      transformPastedHTML: o,
      state: this.editorState,
      markViews: this.extensionManager.markViews,
      nodeViews: this.extensionManager.nodeViews,
    });
    const l = this.state.reconfigure({
      plugins: this.extensionManager.plugins,
    });
    (this.view.updateState(l), this.prependClass(), this.injectCSS());
    const a = this.view.dom;
    a.editor = this;
  }
  createNodeViews() {
    this.view.isDestroyed ||
      this.view.setProps({
        markViews: this.extensionManager.markViews,
        nodeViews: this.extensionManager.nodeViews,
      });
  }
  prependClass() {
    this.view.dom.className = `${this.className} ${this.view.dom.className}`;
  }
  captureTransaction(n) {
    ((this.isCapturingTransaction = !0),
      n(),
      (this.isCapturingTransaction = !1));
    const e = this.capturedTransaction;
    return ((this.capturedTransaction = null), e);
  }
  dispatchTransaction(n) {
    if (this.view.isDestroyed) return;
    if (this.isCapturingTransaction) {
      if (!this.capturedTransaction) {
        this.capturedTransaction = n;
        return;
      }
      n.steps.forEach((c) => {
        var u;
        return (u = this.capturedTransaction) === null || u === void 0
          ? void 0
          : u.step(c);
      });
      return;
    }
    const { state: e, transactions: t } = this.state.applyTransaction(n),
      r = !this.state.selection.eq(e.selection),
      i = t.includes(n),
      s = this.state;
    if (
      (this.emit("beforeTransaction", {
        editor: this,
        transaction: n,
        nextState: e,
      }),
      !i)
    )
      return;
    (this.view.updateState(e),
      this.emit("transaction", {
        editor: this,
        transaction: n,
        appendedTransactions: t.slice(1),
      }),
      r && this.emit("selectionUpdate", { editor: this, transaction: n }));
    const o = t.findLast((c) => c.getMeta("focus") || c.getMeta("blur")),
      l = o?.getMeta("focus"),
      a = o?.getMeta("blur");
    (l && this.emit("focus", { editor: this, event: l.event, transaction: o }),
      a && this.emit("blur", { editor: this, event: a.event, transaction: o }),
      !(
        n.getMeta("preventUpdate") ||
        !t.some((c) => c.docChanged) ||
        s.doc.eq(e.doc)
      ) &&
        this.emit("update", {
          editor: this,
          transaction: n,
          appendedTransactions: t.slice(1),
        }));
  }
  getAttributes(n) {
    return wu(this.state, n);
  }
  isActive(n, e) {
    const t = typeof n == "string" ? n : null,
      r = typeof n == "string" ? e : n;
    return ag(this.state, t, r);
  }
  getJSON() {
    return this.state.doc.toJSON();
  }
  getHTML() {
    return eo(this.state.doc.content, this.schema);
  }
  getText(n) {
    const {
      blockSeparator: e = `

`,
      textSerializers: t = {},
    } = n || {};
    return tg(this.state.doc, {
      blockSeparator: e,
      textSerializers: { ...xu(this.schema), ...t },
    });
  }
  get isEmpty() {
    return _n(this.state.doc);
  }
  destroy() {
    this.destroyed ||
      ((this.destroyed = !0),
      this.emit("destroy"),
      this.unmount(),
      this.removeAllListeners(),
      this.extensionManager.destroy(),
      (this.extensionManager = null),
      (this.schema = null),
      (this.commandManager = null),
      (this.extensionStorage = {}));
  }
  get isDestroyed() {
    var n, e;
    return (n =
      (e = this.editorView) === null || e === void 0
        ? void 0
        : e.isDestroyed) !== null && n !== void 0
      ? n
      : !0;
  }
  $node(n, e) {
    var t;
    return (
      ((t = this.$doc) === null || t === void 0
        ? void 0
        : t.querySelector(n, e)) || null
    );
  }
  $nodes(n, e) {
    var t;
    return (
      ((t = this.$doc) === null || t === void 0
        ? void 0
        : t.querySelectorAll(n, e)) || null
    );
  }
  $pos(n) {
    const e = this.state.doc.resolve(n),
      t =
        n > 0 && e.nodeAfter && !e.nodeAfter.isText && e.nodeAfter.isAtom
          ? e.nodeAfter
          : null;
    return new Dy(e, this, !1, t);
  }
  get $doc() {
    return this.$pos(0);
  }
};
function Dt(n) {
  return new Wn({
    find: n.find,
    handler: ({ state: e, range: t, match: r }) => {
      const i = B(n.getAttributes, void 0, r);
      if (i === !1 || i === null) return null;
      const { tr: s } = e,
        o = r[r.length - 1],
        l = r[0];
      if (o) {
        const a = l.search(/\S/),
          c = t.from + l.indexOf(o),
          u = c + o.length;
        if (
          yi(t.from, t.to, e.doc)
            .filter((f) =>
              f.mark.type.excluded.find(
                (h) => h === n.type && h !== f.mark.type,
              ),
            )
            .filter((f) => f.to > c).length
        )
          return null;
        (u < t.to && s.delete(u, t.to), c > t.from && s.delete(t.from + a, c));
        const d = t.from + a + o.length;
        (s.addMark(t.from + a, d, n.type.create(i || {})),
          s.removeStoredMark(n.type));
      }
    },
    undoable: n.undoable,
  });
}
function Ly(n) {
  return new Wn({
    find: n.find,
    handler: ({ state: e, range: t, match: r }) => {
      const i = B(n.getAttributes, void 0, r) || {},
        { tr: s } = e,
        o = t.from;
      let l = t.to;
      const a = n.type.create(i);
      if (r[1]) {
        let c = o + r[0].lastIndexOf(r[1]);
        c > l ? (c = l) : (l = c + r[1].length);
        const u = r[0][r[0].length - 1];
        (s.insertText(u, o + r[0].length - 1), s.replaceWith(c, l, a));
      } else if (r[0]) {
        const c = n.type.isInline ? o : o - 1;
        s.insert(c, n.type.create(i)).delete(
          s.mapping.map(o),
          s.mapping.map(l),
        );
      }
      s.scrollIntoView();
    },
    undoable: n.undoable,
  });
}
function xs(n) {
  return new Wn({
    find: n.find,
    handler: ({ state: e, range: t, match: r }) => {
      const i = e.doc.resolve(t.from),
        s = B(n.getAttributes, void 0, r) || {};
      if (!i.node(-1).canReplaceWith(i.index(-1), i.indexAfter(-1), n.type))
        return null;
      e.tr.delete(t.from, t.to).setBlockType(t.from, t.from, n.type, s);
    },
    undoable: n.undoable,
  });
}
function tn(n) {
  return new Wn({
    find: n.find,
    handler: ({ state: e, range: t, match: r, chain: i }) => {
      const s = B(n.getAttributes, void 0, r) || {},
        o = e.tr.delete(t.from, t.to),
        l = o.doc.resolve(t.from).blockRange(),
        a = l && Bs(l, n.type, s);
      if (!a) return null;
      if ((o.wrap(l, a), n.keepMarks && n.editor)) {
        const { selection: u, storedMarks: d } = e,
          { splittableMarks: f } = n.editor.extensionManager,
          h = d || (u.$to.parentOffset && u.$from.marks());
        if (h) {
          const p = h.filter((g) => f.includes(g.type.name));
          o.ensureMarks(p);
        }
      }
      if (n.keepAttributes) {
        const u =
          n.type.name === "bulletList" || n.type.name === "orderedList"
            ? "listItem"
            : "taskList";
        i().updateAttributes(u, s).run();
      }
      const c = o.doc.resolve(t.from - 1).nodeBefore;
      c &&
        c.type === n.type &&
        at(o.doc, t.from - 1) &&
        (!n.joinPredicate || n.joinPredicate(r, c)) &&
        o.join(t.from - 1);
    },
    undoable: n.undoable,
  });
}
var ke = class zu extends ro {
  constructor(...e) {
    (super(...e), (this.type = "node"));
  }
  static create(e = {}) {
    const t = typeof e == "function" ? e() : e;
    return new zu(t);
  }
  configure(e) {
    return super.configure(e);
  }
  extend(e) {
    const t = typeof e == "function" ? e() : e;
    return super.extend(t);
  }
};
function lt(n) {
  return new Bu({
    find: n.find,
    handler: ({ state: e, range: t, match: r, pasteEvent: i }) => {
      const s = B(n.getAttributes, void 0, r, i);
      if (s === !1 || s === null) return null;
      const { tr: o } = e,
        l = r[r.length - 1],
        a = r[0];
      let c = t.to;
      if (l) {
        const u = a.search(/\S/),
          d = t.from + a.indexOf(l),
          f = d + l.length;
        if (
          yi(t.from, t.to, e.doc)
            .filter((h) =>
              h.mark.type.excluded.find(
                (p) => p === n.type && p !== h.mark.type,
              ),
            )
            .filter((h) => h.to > d).length
        )
          return null;
        (f < t.to && o.delete(f, t.to),
          d > t.from && o.delete(t.from + u, d),
          (c = t.from + u + l.length),
          o.addMark(t.from + u, c, n.type.create(s || {})),
          (r.index !== void 0 &&
            r.input !== void 0 &&
            r.index + r[0].length >= r.input.length) ||
            o.removeStoredMark(n.type));
      }
    },
  });
}
const { getOwnPropertyNames: Py, getOwnPropertySymbols: By } = Object,
  { hasOwnProperty: $y } = Object.prototype;
function Vi(n, e) {
  return function (r, i, s) {
    return n(r, i, s) && e(r, i, s);
  };
}
function cn(n) {
  return function (t, r, i) {
    if (!t || !r || typeof t != "object" || typeof r != "object")
      return n(t, r, i);
    const { cache: s } = i,
      o = s.get(t),
      l = s.get(r);
    if (o && l) return o === r && l === t;
    (s.set(t, r), s.set(r, t));
    const a = n(t, r, i);
    return (s.delete(t), s.delete(r), a);
  };
}
function zy(n) {
  return n?.[Symbol.toStringTag];
}
function Kl(n) {
  return Py(n).concat(By(n));
}
const Fy = Object.hasOwn || ((n, e) => $y.call(n, e));
function Lt(n, e) {
  return n === e || (!n && !e && n !== n && e !== e);
}
const Vy = "__v",
  jy = "__o",
  Hy = "_owner",
  _y = 64,
  { getOwnPropertyDescriptor: ws, keys: Or } = Object,
  { propertyIsEnumerable: hr } = Object.prototype,
  Wy = ws(Object.getPrototypeOf(Int8Array.prototype), Symbol.toStringTag).get;
function qy(n, e) {
  return (
    n.byteLength === e.byteLength && Nr(new Uint8Array(n), new Uint8Array(e))
  );
}
function Uy(n, e, t) {
  let r = n.length;
  if (e.length !== r) return !1;
  for (; r-- > 0;) if (!t.equals(n[r], e[r], r, r, n, e, t)) return !1;
  return !0;
}
function Ky(n, e) {
  return (
    n.byteLength === e.byteLength &&
    Nr(
      new Uint8Array(n.buffer, n.byteOffset, n.byteLength),
      new Uint8Array(e.buffer, e.byteOffset, e.byteLength),
    )
  );
}
function Jy(n, e) {
  return Lt(n.getTime(), e.getTime());
}
function Gy(n, e, t) {
  if (n.name !== e.name || n.message !== e.message || n.stack !== e.stack)
    return !1;
  const r = n.cause,
    i = e.cause;
  if (r !== i && !t.equals(r, i, "cause", "cause", n, e, t)) return !1;
  const s = n.errors,
    o = e.errors;
  if (s !== o && !t.equals(s, o, "errors", "errors", n, e, t)) return !1;
  const l = Or(n),
    a = Or(e);
  let c = l.length;
  if (!c && !a.length) return !0;
  let u = 0,
    d;
  for (; c-- > 0;)
    if (((d = l[c]), !(d === "cause" || d === "errors"))) {
      if (
        (d !== a[c] && !hr.call(e, d)) ||
        !t.equals(n[d], e[d], d, d, n, e, t)
      )
        return !1;
      ++u;
    }
  const f = a.length - u;
  return (
    !f || f === (hr.call(e, "cause") ? 1 : 0) + (hr.call(e, "errors") ? 1 : 0)
  );
}
function Yy(n, e) {
  return n === e;
}
function Xy(n, e, t) {
  return (
    n.name === e.name &&
    n.message === e.message &&
    n.stack === e.stack &&
    Ht(n, e, t)
  );
}
function Jl(n, e, t) {
  const r = n.size;
  if (r !== e.size) return !1;
  if (!r) return !0;
  const i = new Array(r),
    s = n.entries();
  let o,
    l,
    a = 0;
  for (; (o = s.next()) && !o.done;) {
    const c = e.entries();
    let u = !1,
      d = 0;
    for (; (l = c.next()) && !l.done;) {
      if (i[d]) {
        d++;
        continue;
      }
      const f = o.value,
        h = l.value;
      if (
        t.equals(f[0], h[0], a, d, n, e, t) &&
        t.equals(f[1], h[1], f[0], h[0], n, e, t)
      ) {
        u = i[d] = !0;
        break;
      }
      d++;
    }
    if (!u) return !1;
    a++;
  }
  return !0;
}
const Qy = Lt;
function Zy(n, e, t) {
  const r = Or(n),
    i = Or(e);
  let s = r.length;
  if (i.length !== s) return !1;
  const o = s <= _y;
  let l;
  for (; s-- > 0;)
    if (
      ((l = r[s]),
      !Fu(n, e, l) &&
        ((l !== i[s] && !(o ? i.includes(l) : hr.call(e, l))) ||
          !t.equals(n[l], e[l], l, l, n, e, t)))
    )
      return !1;
  return !0;
}
function Ht(n, e, t) {
  const r = Kl(n);
  let i = r.length;
  if (Kl(e).length !== i) return !1;
  let s, o, l;
  for (; i-- > 0;)
    if (
      ((s = r[i]),
      (!Fu(n, e, s) && (!Fy(e, s) || !t.equals(n[s], e[s], s, s, n, e, t))) ||
        ((o = ws(n, s)),
        (l = ws(e, s)),
        (o || l) &&
          (!o ||
            !l ||
            o.configurable !== l.configurable ||
            o.enumerable !== l.enumerable ||
            o.writable !== l.writable)))
    )
      return !1;
  return !0;
}
function e0(n, e) {
  return Lt(n.valueOf(), e.valueOf());
}
function t0(n, e) {
  return n.source === e.source && n.flags === e.flags;
}
function Gl(n, e, t) {
  const r = n.size;
  if (r !== e.size) return !1;
  if (!r) return !0;
  const i = new Array(r),
    s = n.values();
  let o, l;
  for (; (o = s.next()) && !o.done;) {
    const a = e.values();
    let c = !1,
      u = 0;
    for (; (l = a.next()) && !l.done;) {
      if (!i[u] && t.equals(o.value, l.value, o.value, l.value, n, e, t)) {
        c = i[u] = !0;
        break;
      }
      u++;
    }
    if (!c) return !1;
  }
  return !0;
}
function Nr(n, e) {
  let t = n.length;
  if (e.length !== t || n.byteOffset !== e.byteOffset) return !1;
  const r = Wy.call(n);
  if (r === "Float64Array" || r === "Float32Array" || r === "Float16Array") {
    for (; t-- > 0;)
      if (n[t] !== e[t] && (n[t] === n[t] || e[t] === e[t])) return !1;
    return !0;
  }
  for (; t-- > 0;) if (n[t] !== e[t]) return !1;
  return !0;
}
function n0(n, e) {
  return n.href === e.href
    ? !0
    : n.protocol === e.protocol &&
        n.username === e.username &&
        n.password === e.password &&
        n.host === e.host &&
        n.pathname === e.pathname &&
        n.hash === e.hash &&
        r0(n.searchParams, e.searchParams);
}
function r0(n, e) {
  const t = n.toString(),
    r = e.toString();
  return t === r || Yl(t) === Yl(r);
}
function Yl(n) {
  return n.split("&").sort().join("&");
}
function Fu(n, e, t) {
  return (t === Hy || t === jy || t === Vy) && !!(n.$$typeof || e.$$typeof);
}
const i0 = "[object ArrayBuffer]",
  s0 = "[object Arguments]",
  o0 = "[object Boolean]",
  l0 = "[object DataView]",
  a0 = "[object Date]",
  c0 = "[object Error]",
  u0 = "[object Map]",
  d0 = "[object Number]",
  f0 = "[object Object]",
  h0 = "[object RegExp]",
  p0 = "[object Set]",
  m0 = "[object String]",
  g0 = {
    "[object Int8Array]": !0,
    "[object Uint8Array]": !0,
    "[object Uint8ClampedArray]": !0,
    "[object Int16Array]": !0,
    "[object Uint16Array]": !0,
    "[object Int32Array]": !0,
    "[object Uint32Array]": !0,
    "[object Float16Array]": !0,
    "[object Float32Array]": !0,
    "[object Float64Array]": !0,
    "[object BigInt64Array]": !0,
    "[object BigUint64Array]": !0,
  },
  y0 = "[object URL]",
  b0 = Object.prototype.toString;
function k0({
  areArrayBuffersEqual: n,
  areArraysEqual: e,
  areDataViewsEqual: t,
  areDatesEqual: r,
  areErrorsEqual: i,
  areFunctionsEqual: s,
  areMapsEqual: o,
  areNumbersEqual: l,
  areObjectsEqual: a,
  arePrimitiveWrappersEqual: c,
  areRegExpsEqual: u,
  areSetsEqual: d,
  areTypedArraysEqual: f,
  areUrlsEqual: h,
  unknownTagComparators: p,
}) {
  return function (m, y, k) {
    if (m === y) return !0;
    if (m == null || y == null) return !1;
    const x = typeof m;
    if (x !== typeof y) return !1;
    if (x !== "object")
      return x === "number" ? l(m, y, k) : x === "function" ? s(m, y, k) : !1;
    const w = m.constructor;
    if (w !== y.constructor) return !1;
    if (w === Object) return a(m, y, k);
    if (Array.isArray(m)) return e(m, y, k);
    if (w === Date) return r(m, y, k);
    if (w === RegExp) return u(m, y, k);
    if (w === Map) return o(m, y, k);
    if (w === Set) return d(m, y, k);
    if (w == null) return a(m, y, k);
    const M = b0.call(m);
    if (M === a0) return r(m, y, k);
    if (M === h0) return u(m, y, k);
    if (M === u0) return o(m, y, k);
    if (M === p0) return d(m, y, k);
    if (M === f0)
      return (
        typeof m.then != "function" && typeof y.then != "function" && a(m, y, k)
      );
    if (M === y0) return h(m, y, k);
    if (M === c0) return i(m, y, k);
    if (M === s0) return a(m, y, k);
    if (g0[M]) return f(m, y, k);
    if (M === i0) return n(m, y, k);
    if (M === l0) return t(m, y, k);
    if (M === o0 || M === d0 || M === m0) return c(m, y, k);
    if (p) {
      let D = p[M];
      if (!D) {
        const E = zy(m);
        E && (D = p[E]);
      }
      if (D) return D(m, y, k);
    }
    return !1;
  };
}
function S0({ circular: n, createCustomConfig: e, strict: t }) {
  let r = {
    areArrayBuffersEqual: qy,
    areArraysEqual: t ? Ht : Uy,
    areDataViewsEqual: Ky,
    areDatesEqual: Jy,
    areErrorsEqual: t ? Xy : Gy,
    areFunctionsEqual: Yy,
    areMapsEqual: t ? Vi(Jl, Ht) : Jl,
    areNumbersEqual: Qy,
    areObjectsEqual: t ? Ht : Zy,
    arePrimitiveWrappersEqual: e0,
    areRegExpsEqual: t0,
    areSetsEqual: t ? Vi(Gl, Ht) : Gl,
    areTypedArraysEqual: t ? Vi(Nr, Ht) : Nr,
    areUrlsEqual: n0,
    unknownTagComparators: void 0,
  };
  if ((e && (r = Object.assign({}, r, e(r))), n)) {
    const i = cn(r.areArraysEqual),
      s = cn(r.areErrorsEqual),
      o = cn(r.areMapsEqual),
      l = cn(r.areObjectsEqual),
      a = cn(r.areSetsEqual);
    r = Object.assign({}, r, {
      areArraysEqual: i,
      areErrorsEqual: s,
      areMapsEqual: o,
      areObjectsEqual: l,
      areSetsEqual: a,
    });
  }
  return r;
}
function x0(n) {
  return function (e, t, r, i, s, o, l) {
    return n(e, t, l);
  };
}
function w0({
  circular: n,
  comparator: e,
  createState: t,
  equals: r,
  strict: i,
}) {
  if (t)
    return function (l, a) {
      const { cache: c = n ? new WeakMap() : void 0, meta: u } = t();
      return e(l, a, { cache: c, equals: r, meta: u, strict: i });
    };
  if (n)
    return function (l, a) {
      return e(l, a, {
        cache: new WeakMap(),
        equals: r,
        meta: void 0,
        strict: i,
      });
    };
  const s = { cache: void 0, equals: r, meta: void 0, strict: i };
  return function (l, a) {
    return e(l, a, s);
  };
}
ut();
ut({ strict: !0 });
const C0 = ut({ circular: !0 });
ut({ circular: !0, strict: !0 });
ut({ createInternalComparator: () => Lt });
ut({ strict: !0, createInternalComparator: () => Lt });
ut({ circular: !0, createInternalComparator: () => Lt });
ut({ circular: !0, createInternalComparator: () => Lt, strict: !0 });
function ut(n = {}) {
  const {
      circular: e = !1,
      createInternalComparator: t,
      createState: r,
      strict: i = !1,
    } = n,
    s = S0(n),
    o = k0(s),
    l = t ? t(o) : x0(o);
  return w0({
    circular: e,
    comparator: o,
    createState: r,
    equals: l,
    strict: i,
  });
}
var ji = { exports: {} },
  Hi = {};
/**
 * @license React
 * use-sync-external-store-shim/with-selector.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var Xl;
function v0() {
  if (Xl) return Hi;
  Xl = 1;
  var n = ba(),
    e = Za();
  function t(c, u) {
    return (c === u && (c !== 0 || 1 / c === 1 / u)) || (c !== c && u !== u);
  }
  var r = typeof Object.is == "function" ? Object.is : t,
    i = e.useSyncExternalStore,
    s = n.useRef,
    o = n.useEffect,
    l = n.useMemo,
    a = n.useDebugValue;
  return (
    (Hi.useSyncExternalStoreWithSelector = function (c, u, d, f, h) {
      var p = s(null);
      if (p.current === null) {
        var g = { hasValue: !1, value: null };
        p.current = g;
      } else g = p.current;
      p = l(
        function () {
          function y(D) {
            if (!k) {
              if (((k = !0), (x = D), (D = f(D)), h !== void 0 && g.hasValue)) {
                var E = g.value;
                if (h(E, D)) return (w = E);
              }
              return (w = D);
            }
            if (((E = w), r(x, D))) return E;
            var I = f(D);
            return h !== void 0 && h(E, I) ? ((x = D), E) : ((x = D), (w = I));
          }
          var k = !1,
            x,
            w,
            M = d === void 0 ? null : d;
          return [
            function () {
              return y(u());
            },
            M === null
              ? void 0
              : function () {
                  return y(M());
                },
          ];
        },
        [u, d, f, h],
      );
      var m = i(c, p[0], p[1]);
      return (
        o(
          function () {
            ((g.hasValue = !0), (g.value = m));
          },
          [m],
        ),
        a(m),
        m
      );
    }),
    Hi
  );
}
var Ql;
function M0() {
  return (Ql || ((Ql = 1), (ji.exports = v0())), ji.exports);
}
var E0 = M0();
function T0(n, e) {
  var t, r;
  if (
    n.isDestroyed ||
    e.defaultPrevented ||
    !e.cancelable ||
    !n.isEditable ||
    (e.inputType !== "insertParagraph" && e.inputType !== "insertLineBreak") ||
    (!Pn() && !ys())
  )
    return;
  const i = n.view,
    s = i.root,
    o =
      (t =
        (r = s.getSelection) === null || r === void 0 ? void 0 : r.call(s)) !==
        null && t !== void 0
        ? t
        : i.dom.ownerDocument.getSelection(),
    l = o?.anchorNode,
    a = l?.nodeType === 1 ? l : l?.parentElement,
    c = a?.closest("[data-node-view-content-react]");
  if (!c || !i.dom.contains(c)) return;
  const u = i.input.lastKeyCode;
  (u === 13 && (i.input.lastKeyCode = null),
    i.domObserver.forceFlush(),
    i.domObserver.flush());
  const d = new KeyboardEvent("keydown", {
    key: "Enter",
    code: "Enter",
    keyCode: 13,
    shiftKey: e.inputType === "insertLineBreak",
    bubbles: !0,
    cancelable: !0,
  });
  i.someProp("handleKeyDown", (f) => f(i, d))
    ? (e.preventDefault(),
      (i.input.lastIOSEnter = 0),
      clearTimeout(i.input.lastIOSEnterFallbackTimeout))
    : u === 13 && (i.input.lastKeyCode = u);
}
const Zl = new K("reactMobileEnter"),
  A0 =
    (...n) =>
    (e) => {
      n.forEach((t) => {
        typeof t == "function" ? t(e) : t && (t.current = e);
      });
    },
  O0 = ({ contentComponent: n }) => {
    const e = ec.useSyncExternalStore(
      n.subscribe,
      n.getSnapshot,
      n.getServerSnapshot,
    );
    return $.jsx($.Fragment, { children: Object.values(e) });
  };
function N0() {
  const n = new Set();
  let e = {},
    t = !1;
  const r = () => {
    t ||
      !n.size ||
      ((t = !0),
      queueMicrotask(() => {
        ((t = !1), n.forEach((i) => i()));
      }));
  };
  return {
    subscribe(i) {
      return (
        n.add(i),
        () => {
          n.delete(i);
        }
      );
    },
    getSnapshot() {
      return e;
    },
    getServerSnapshot() {
      return e;
    },
    setRenderer(i, s) {
      ((e = { ...e, [i]: Od.createPortal(s.reactElement, s.element, i) }), r());
    },
    removeRenderer(i) {
      const s = { ...e };
      (delete s[i], (e = s), r());
    },
  };
}
var D0 = class extends Et.Component {
  constructor(n) {
    (super(n), (this.editorContentRef = Et.createRef()));
  }
  componentDidMount() {
    this.init();
  }
  componentDidUpdate() {
    this.init();
  }
  init() {
    var n;
    const e = this.props.editor;
    if (
      e &&
      !e.isDestroyed &&
      !((n = e.view.dom) === null || n === void 0) &&
      n.parentNode
    ) {
      if (e.contentComponent) return;
      const t = this.editorContentRef.current;
      (t.append(...e.view.dom.parentNode.childNodes),
        e.view.updateRoot(),
        e.setOptions({ element: t }),
        (e.contentComponent = N0()),
        e.createNodeViews(),
        e.registerPlugin(
          new V({
            key: Zl,
            props: { handleDOMEvents: { beforeinput: (r, i) => T0(e, i) } },
          }),
        ),
        (e.isEditorContentInitialized = !0),
        this.forceUpdate());
    }
  }
  componentWillUnmount() {
    const n = this.props.editor;
    if (n) {
      ((n.isEditorContentInitialized = !1),
        n.isDestroyed ||
          (n.unregisterPlugin(Zl), n.view.setProps({ nodeViews: {} })),
        (n.contentComponent = null));
      try {
        var e;
        if (!(!((e = n.view.dom) === null || e === void 0) && e.parentNode))
          return;
        const t = document.createElement("div");
        (t.append(...n.view.dom.parentNode.childNodes),
          n.setOptions({ element: t }));
      } catch {}
    }
  }
  render() {
    const { editor: n, innerRef: e, ...t } = this.props;
    return $.jsxs($.Fragment, {
      children: [
        $.jsx("div", { ref: A0(e, this.editorContentRef), ...t }),
        n?.contentComponent &&
          $.jsx(O0, { contentComponent: n.contentComponent }),
      ],
    });
  }
};
const R0 = re.forwardRef((n, e) => {
    const t = Et.useMemo(
      () => Math.floor(Math.random() * 4294967295).toString(),
      [n.editor],
    );
    return Et.createElement(D0, { key: t, innerRef: e, ...n });
  }),
  Vu = Et.memo(R0),
  I0 = typeof window < "u" ? re.useLayoutEffect : re.useEffect;
var L0 = class {
  constructor(n) {
    ((this.transactionNumber = 0),
      (this.lastTransactionNumber = 0),
      (this.subscribers = new Set()),
      (this.editor = n),
      (this.lastSnapshot = { editor: n, transactionNumber: 0 }),
      (this.getSnapshot = this.getSnapshot.bind(this)),
      (this.getServerSnapshot = this.getServerSnapshot.bind(this)),
      (this.watch = this.watch.bind(this)),
      (this.subscribe = this.subscribe.bind(this)));
  }
  getSnapshot() {
    return this.transactionNumber === this.lastTransactionNumber
      ? this.lastSnapshot
      : ((this.lastTransactionNumber = this.transactionNumber),
        (this.lastSnapshot = {
          editor: this.editor,
          transactionNumber: this.transactionNumber,
        }),
        this.lastSnapshot);
  }
  getServerSnapshot() {
    return { editor: null, transactionNumber: 0 };
  }
  subscribe(n) {
    return (
      this.subscribers.add(n),
      () => {
        this.subscribers.delete(n);
      }
    );
  }
  watch(n) {
    if (((this.editor = n), this.editor)) {
      let e;
      const t = (i) => {
          (i?.transaction !== void 0 && i.transaction === e) ||
            ((e = i?.transaction),
            (this.transactionNumber += 1),
            this.subscribers.forEach((s) => s()));
        },
        r = this.editor;
      return (
        r.on("transaction", t),
        r.on("update", t),
        () => {
          (r.off("transaction", t), r.off("update", t));
        }
      );
    }
  }
};
function ju(n) {
  var e;
  const [t] = re.useState(() => new L0(n.editor)),
    r = E0.useSyncExternalStoreWithSelector(
      t.subscribe,
      t.getSnapshot,
      t.getServerSnapshot,
      n.selector,
      (e = n.equalityFn) !== null && e !== void 0 ? e : C0,
    );
  return (I0(() => t.watch(n.editor), [n.editor, t]), re.useDebugValue(r), r);
}
const P0 = !1,
  Hu = typeof window > "u",
  B0 = Hu || !!(typeof window < "u" && window.next);
var $0 = class _u {
  constructor(e) {
    ((this.editor = null),
      (this.subscriptions = new Set()),
      (this.isComponentMounted = !1),
      (this.previousDeps = null),
      (this.instanceId = ""),
      (this.options = e),
      (this.subscriptions = new Set()),
      this.setEditor(this.getInitialEditor()),
      this.scheduleDestroy(),
      (this.getEditor = this.getEditor.bind(this)),
      (this.getServerSnapshot = this.getServerSnapshot.bind(this)),
      (this.subscribe = this.subscribe.bind(this)),
      (this.refreshEditorInstance = this.refreshEditorInstance.bind(this)),
      (this.scheduleDestroy = this.scheduleDestroy.bind(this)),
      (this.onRender = this.onRender.bind(this)),
      (this.createEditor = this.createEditor.bind(this)));
  }
  setEditor(e) {
    ((this.editor = e),
      (this.instanceId = Math.random().toString(36).slice(2, 9)),
      this.subscriptions.forEach((t) => t()));
  }
  getInitialEditor() {
    const e = this.options.current.immediatelyRender;
    let t = e ?? !0;
    return (
      Hu
        ? (t &&
            P0 &&
            console.warn(
              "SSR detected. `immediatelyRender` has been set to false to avoid hydration mismatches",
            ),
          (t = !1))
        : B0 && e === void 0 && (t = !1),
      t ? this.createEditor() : null
    );
  }
  createEditor() {
    const e = {
      ...this.options.current,
      onBeforeCreate: (...t) => {
        var r, i;
        return (r = (i = this.options.current).onBeforeCreate) === null ||
          r === void 0
          ? void 0
          : r.call(i, ...t);
      },
      onBlur: (...t) => {
        var r, i;
        return (r = (i = this.options.current).onBlur) === null || r === void 0
          ? void 0
          : r.call(i, ...t);
      },
      onCreate: (...t) => {
        var r, i;
        return (r = (i = this.options.current).onCreate) === null ||
          r === void 0
          ? void 0
          : r.call(i, ...t);
      },
      onDestroy: (...t) => {
        var r, i;
        return (r = (i = this.options.current).onDestroy) === null ||
          r === void 0
          ? void 0
          : r.call(i, ...t);
      },
      onFocus: (...t) => {
        var r, i;
        return (r = (i = this.options.current).onFocus) === null || r === void 0
          ? void 0
          : r.call(i, ...t);
      },
      onSelectionUpdate: (...t) => {
        var r, i;
        return (r = (i = this.options.current).onSelectionUpdate) === null ||
          r === void 0
          ? void 0
          : r.call(i, ...t);
      },
      onTransaction: (...t) => {
        var r, i;
        return (r = (i = this.options.current).onTransaction) === null ||
          r === void 0
          ? void 0
          : r.call(i, ...t);
      },
      onUpdate: (...t) => {
        var r, i;
        return (r = (i = this.options.current).onUpdate) === null ||
          r === void 0
          ? void 0
          : r.call(i, ...t);
      },
      onContentError: (...t) => {
        var r, i;
        return (r = (i = this.options.current).onContentError) === null ||
          r === void 0
          ? void 0
          : r.call(i, ...t);
      },
      onDrop: (...t) => {
        var r, i;
        return (r = (i = this.options.current).onDrop) === null || r === void 0
          ? void 0
          : r.call(i, ...t);
      },
      onPaste: (...t) => {
        var r, i;
        return (r = (i = this.options.current).onPaste) === null || r === void 0
          ? void 0
          : r.call(i, ...t);
      },
      onDelete: (...t) => {
        var r, i;
        return (r = (i = this.options.current).onDelete) === null ||
          r === void 0
          ? void 0
          : r.call(i, ...t);
      },
      onMount: (...t) => {
        var r, i;
        return (r = (i = this.options.current).onMount) === null || r === void 0
          ? void 0
          : r.call(i, ...t);
      },
      onUnmount: (...t) => {
        var r, i;
        return (r = (i = this.options.current).onUnmount) === null ||
          r === void 0
          ? void 0
          : r.call(i, ...t);
      },
    };
    return new Iy(e);
  }
  getEditor() {
    return this.editor;
  }
  getServerSnapshot() {
    return null;
  }
  subscribe(e) {
    return (
      this.subscriptions.add(e),
      () => {
        this.subscriptions.delete(e);
      }
    );
  }
  static compareOptions(e, t) {
    return Object.keys(e).every((r) =>
      [
        "onCreate",
        "onBeforeCreate",
        "onDestroy",
        "onUpdate",
        "onTransaction",
        "onFocus",
        "onBlur",
        "onSelectionUpdate",
        "onContentError",
        "onDrop",
        "onPaste",
      ].includes(r)
        ? !0
        : r === "extensions" && e.extensions && t.extensions
          ? e.extensions.length !== t.extensions.length
            ? !1
            : e.extensions.every((i, s) => {
                var o;
                return (
                  i ===
                  ((o = t.extensions) === null || o === void 0 ? void 0 : o[s])
                );
              })
          : e[r] === t[r],
    );
  }
  onRender(e) {
    return () => (
      (this.isComponentMounted = !0),
      clearTimeout(this.scheduledDestructionTimeout),
      this.editor && !this.editor.isDestroyed && e.length === 0
        ? _u.compareOptions(this.options.current, this.editor.options) ||
          this.editor.setOptions({
            ...this.options.current,
            editable: this.editor.isEditable,
          })
        : this.refreshEditorInstance(e),
      () => {
        ((this.isComponentMounted = !1), this.scheduleDestroy());
      }
    );
  }
  refreshEditorInstance(e) {
    if (this.editor && !this.editor.isDestroyed) {
      if (this.previousDeps === null) {
        this.previousDeps = e;
        return;
      }
      if (
        this.previousDeps.length === e.length &&
        this.previousDeps.every((t, r) => t === e[r])
      )
        return;
    }
    (this.editor && !this.editor.isDestroyed && this.editor.destroy(),
      this.setEditor(this.createEditor()),
      (this.previousDeps = e));
  }
  scheduleDestroy() {
    const e = this.instanceId,
      t = this.editor;
    this.scheduledDestructionTimeout = setTimeout(() => {
      if (this.isComponentMounted && this.instanceId === e) {
        t && t.setOptions(this.options.current);
        return;
      }
      t &&
        !t.isDestroyed &&
        (t.destroy(), this.instanceId === e && this.setEditor(null));
    }, 1);
  }
};
function z0(n = {}, e = []) {
  const t = re.useRef(n);
  t.current = n;
  const [r] = re.useState(() => new $0(t)),
    i = ec.useSyncExternalStore(r.subscribe, r.getEditor, r.getServerSnapshot);
  return (
    re.useDebugValue(i),
    re.useEffect(r.onRender(e)),
    ju({
      editor: i,
      selector: ({ transactionNumber: s }) =>
        n.shouldRerenderOnTransaction === !1 ||
        n.shouldRerenderOnTransaction === void 0
          ? null
          : n.immediatelyRender && s === 0
            ? 0
            : s + 1,
    }),
    i
  );
}
const Wu = re.createContext({ editor: null });
Wu.Consumer;
const F0 = re.createContext({
    onDragStart: () => {},
    nodeViewContentChildren: void 0,
    nodeViewContentRef: () => {},
  }),
  V0 = () => re.useContext(F0);
Et.forwardRef((n, e) => {
  const { onDragStart: t } = V0(),
    r = n.as || "div";
  return $.jsx(r, {
    ...n,
    ref: e,
    "data-node-view-wrapper": "",
    onDragStart: t,
    style: { whiteSpace: "normal", ...n.style },
  });
});
Et.createContext({ markViewContentRef: () => {} });
const io = re.createContext({
  get editor() {
    throw new Error("useTiptap must be used within a <Tiptap> provider");
  },
});
io.displayName = "TiptapContext";
const j0 = () => re.useContext(io);
function qu({ children: n, ...e }) {
  const t = "editor" in e ? e.editor : e.instance;
  if (!t)
    throw new Error(
      "Tiptap: An editor instance is required. Pass a non-null `editor` prop.",
    );
  const r = re.useMemo(() => ({ editor: t }), [t]),
    i = re.useMemo(() => ({ editor: t }), [t]);
  return $.jsx(Wu.Provider, {
    value: i,
    children: $.jsx(io.Provider, { value: r, children: n }),
  });
}
qu.displayName = "Tiptap";
function Uu({ ...n }) {
  const { editor: e } = j0();
  return $.jsx(Vu, { editor: e, ...n });
}
Uu.displayName = "Tiptap.Content";
Object.assign(qu, { Content: Uu });
const Ku = new WeakSet(),
  Ju = new WeakSet();
function ht(n) {
  const e = n;
  return (Ku.add(e), e);
}
function Cs(n) {
  return Array.isArray(n) && Ku.has(n);
}
function Gu(n) {
  return n.flatMap((e) =>
    e == null ? [] : Array.isArray(e) && Ju.has(e) && !Cs(e) ? Gu(e) : [e],
  );
}
function H0(n, e) {
  if (n === "slot") return 0;
  if (n instanceof Function) {
    const i = n(e);
    return Array.isArray(i) && !Cs(i) && !Ju.has(i) ? ht(i) : i;
  }
  const { children: t, ...r } = e ?? {};
  if (n === "svg")
    throw new Error(
      "SVG elements are not supported in the JSX syntax, use the array syntax instead",
    );
  if (Array.isArray(t)) {
    if (Cs(t)) return ht([n, r, t]);
    if (t.length === 0) return ht([n, r]);
    const i = Gu(t);
    return i.length === 0 ? ht([n, r]) : ht([n, r, ...i]);
  }
  return t != null ? ht([n, r, t]) : ht([n, r]);
}
const Dr = (n, e) => H0(n, e),
  _0 = (n, e) => {
    var t;
    const { state: r } = n,
      { selection: i } = r;
    if (!i.empty) return !1;
    const { $from: s } = i;
    if (s.parentOffset !== 0) return !1;
    const o = s.depth - 1;
    if (o < 0) return !1;
    const l = s.node(o),
      a = s.index(o);
    if (a === 0) return !1;
    if (l.type === e) return n.commands.lift(e.name);
    const c = l.child(a - 1);
    if (
      c.type !== e ||
      !(!((t = c.lastChild) === null || t === void 0) && t.isTextblock)
    )
      return !1;
    const u = s.before() - 1 - 1;
    return n.commands.command(({ tr: d, dispatch: f }) => {
      if (!f) return !0;
      const h = s.parent.content,
        p = new C(h, 0, 0);
      return (
        d.replace(u, s.after(), p),
        d.setSelection(T.create(d.doc, u + h.size)),
        d.scrollIntoView(),
        f(d),
        !0
      );
    });
  },
  W0 = /^\s*>\s$/,
  q0 = ke.create({
    name: "blockquote",
    addOptions() {
      return { HTMLAttributes: {} };
    },
    content: "block+",
    group: "block",
    defining: !0,
    parseHTML() {
      return [{ tag: "blockquote" }];
    },
    renderHTML({ HTMLAttributes: n }) {
      return Dr("blockquote", {
        ...X(this.options.HTMLAttributes, n),
        children: Dr("slot", {}),
      });
    },
    parseMarkdown: (n, e) => {
      var t;
      const r =
        (t = e.parseBlockChildren) !== null && t !== void 0
          ? t
          : e.parseChildren;
      return e.createNode("blockquote", void 0, r(n.tokens || []));
    },
    renderMarkdown: (n, e) => {
      if (!n.content) return "";
      const t = ">",
        r = [];
      return (
        n.content.forEach((i, s) => {
          var o, l;
          const a = (
            (o =
              (l = e.renderChild) === null || l === void 0
                ? void 0
                : l.call(e, i, s)) !== null && o !== void 0
              ? o
              : e.renderChildren([i])
          )
            .split(
              `
`,
            )
            .map((c) => (c.trim() === "" ? t : `${t} ${c}`));
          r.push(
            a.join(`
`),
          );
        }),
        r.join(`
${t}
`)
      );
    },
    addCommands() {
      return {
        setBlockquote:
          () =>
          ({ commands: n }) =>
            n.wrapIn(this.name),
        toggleBlockquote:
          () =>
          ({ commands: n }) =>
            n.toggleWrap(this.name),
        unsetBlockquote:
          () =>
          ({ commands: n }) =>
            n.lift(this.name),
      };
    },
    addKeyboardShortcuts() {
      return {
        "Mod-Shift-b": () => this.editor.commands.toggleBlockquote(),
        Backspace: () => _0(this.editor, this.type),
      };
    },
    addInputRules() {
      return [tn({ find: W0, type: this.type })];
    },
  }),
  U0 = /(?:^|\s)(\*\*(?!\s+\*\*)((?:[^*]+))\*\*(?!\s+\*\*))$/,
  K0 = /(?:^|\s)(\*\*(?!\s+\*\*)((?:[^*]+))\*\*(?!\s+\*\*))/g,
  J0 = /(?:^|\s)(__(?!\s+__)((?:[^_]+))__(?!\s+__))$/,
  G0 = /(?:^|\s)(__(?!\s+__)((?:[^_]+))__(?!\s+__))/g,
  Y0 = It.create({
    name: "bold",
    addOptions() {
      return { HTMLAttributes: {} };
    },
    parseHTML() {
      return [
        { tag: "strong" },
        { tag: "b", getAttrs: (n) => n.style.fontWeight !== "normal" && null },
        {
          style: "font-weight=400",
          clearMark: (n) => n.type.name === this.name,
        },
        {
          style: "font-weight",
          getAttrs: (n) => /^(bold(er)?|[5-9]\d{2,})$/.test(n) && null,
        },
      ];
    },
    renderHTML({ HTMLAttributes: n }) {
      return Dr("strong", {
        ...X(this.options.HTMLAttributes, n),
        children: Dr("slot", {}),
      });
    },
    markdownTokenName: "strong",
    parseMarkdown: (n, e) => e.applyMark("bold", e.parseInline(n.tokens || [])),
    markdownOptions: { htmlReopen: { open: "<strong>", close: "</strong>" } },
    renderMarkdown: (n, e) => `**${e.renderChildren(n)}**`,
    addCommands() {
      return {
        setBold:
          () =>
          ({ commands: n }) =>
            n.setMark(this.name),
        toggleBold:
          () =>
          ({ commands: n }) =>
            n.toggleMark(this.name),
        unsetBold:
          () =>
          ({ commands: n }) =>
            n.unsetMark(this.name),
      };
    },
    addKeyboardShortcuts() {
      return {
        "Mod-b": () => this.editor.commands.toggleBold(),
        "Mod-B": () => this.editor.commands.toggleBold(),
      };
    },
    addInputRules() {
      return [
        Dt({ find: U0, type: this.type }),
        Dt({ find: J0, type: this.type }),
      ];
    },
    addPasteRules() {
      return [
        lt({ find: K0, type: this.type }),
        lt({ find: G0, type: this.type }),
      ];
    },
  }),
  X0 = (n) => {
    const e = /`([^`]+)`(?!`)$/.exec(n);
    return !e || (e.index > 0 && n[e.index - 1] === "`")
      ? null
      : { index: e.index, text: e[0], replaceWith: e[1] };
  },
  Q0 = (n) => {
    const e = /`([^`]+)`(?!`)/g,
      t = [];
    let r;
    for (; (r = e.exec(n)) !== null;)
      (r.index > 0 && n[r.index - 1] === "`") ||
        t.push({ index: r.index, text: r[0], replaceWith: r[1] });
    return t;
  };
function Z0(n) {
  const e = new Set((n.match(/`+/g) || []).map((r) => r.length));
  let t = 1;
  for (; e.has(t);) t += 1;
  return t;
}
const eb = It.create({
    name: "code",
    addOptions() {
      return { HTMLAttributes: {} };
    },
    excludes: "_",
    code: !0,
    exitable: !0,
    parseHTML() {
      return [{ tag: "code" }];
    },
    renderHTML({ HTMLAttributes: n }) {
      return ["code", X(this.options.HTMLAttributes, n), 0];
    },
    markdownTokenName: "codespan",
    parseMarkdown: (n, e) =>
      e.applyMark("code", [{ type: "text", text: n.text || "" }]),
    renderMarkdown: (n, e, t) => {
      var r;
      if (!n.content) return "";
      const i =
          typeof (t == null || (r = t.meta) === null || r === void 0
            ? void 0
            : r.markText) == "string"
            ? t.meta.markText
            : "",
        s = "`".repeat(Z0(i)),
        o = i.startsWith("`") || i.endsWith("`") ? " " : "";
      return `${s}${o}${e.renderChildren(n.content)}${o}${s}`;
    },
    addCommands() {
      return {
        setCode:
          () =>
          ({ commands: n }) =>
            n.setMark(this.name),
        toggleCode:
          () =>
          ({ commands: n }) =>
            n.toggleMark(this.name),
        unsetCode:
          () =>
          ({ commands: n }) =>
            n.unsetMark(this.name),
      };
    },
    addKeyboardShortcuts() {
      return { "Mod-e": () => this.editor.commands.toggleCode() };
    },
    addInputRules() {
      return [Dt({ find: X0, type: this.type })];
    },
    addPasteRules() {
      return [lt({ find: Q0, type: this.type })];
    },
  }),
  _i = 4,
  tb = /^```([a-z]+)?[\s\n]$/,
  nb = /^~~~([a-z]+)?[\s\n]$/,
  rb = ke.create({
    name: "codeBlock",
    addOptions() {
      return {
        languageClassPrefix: "language-",
        exitOnTripleEnter: !0,
        exitOnArrowDown: !0,
        exitOnArrowUp: !0,
        defaultLanguage: null,
        enableTabIndentation: !1,
        tabSize: _i,
        HTMLAttributes: {},
      };
    },
    content: "text*",
    marks: "",
    group: "block",
    code: !0,
    defining: !0,
    addAttributes() {
      return {
        language: {
          default: this.options.defaultLanguage,
          parseHTML: (n) => {
            var e;
            const { languageClassPrefix: t } = this.options;
            if (!t) return null;
            const r = [
              ...(((e = n.firstElementChild) === null || e === void 0
                ? void 0
                : e.classList) || []),
            ]
              .filter((i) => i.startsWith(t))
              .map((i) => i.replace(t, ""))[0];
            return r || null;
          },
          rendered: !1,
        },
      };
    },
    parseHTML() {
      return [{ tag: "pre", preserveWhitespace: "full" }];
    },
    renderHTML({ node: n, HTMLAttributes: e }) {
      return [
        "pre",
        X(this.options.HTMLAttributes, e),
        [
          "code",
          {
            class: n.attrs.language
              ? this.options.languageClassPrefix + n.attrs.language
              : null,
          },
          0,
        ],
      ];
    },
    markdownTokenName: "code",
    parseMarkdown: (n, e) => {
      var t, r;
      return ((t = n.raw) === null || t === void 0
        ? void 0
        : t.startsWith("```")) === !1 &&
        ((r = n.raw) === null || r === void 0
          ? void 0
          : r.startsWith("~~~")) === !1 &&
        n.codeBlockStyle !== "indented"
        ? []
        : e.createNode(
            "codeBlock",
            { language: n.lang || null },
            n.text ? [e.createTextNode(n.text)] : [],
          );
    },
    renderMarkdown: (n, e) => {
      var t;
      let r = "";
      const i =
        ((t = n.attrs) === null || t === void 0 ? void 0 : t.language) || "";
      return (
        n.content
          ? (r = [`\`\`\`${i}`, e.renderChildren(n.content), "```"].join(`
`))
          : (r = `\`\`\`${i}

\`\`\``),
        r
      );
    },
    addCommands() {
      return {
        setCodeBlock:
          (n) =>
          ({ commands: e }) =>
            e.setNode(this.name, n),
        toggleCodeBlock:
          (n) =>
          ({ commands: e }) =>
            e.toggleNode(this.name, "paragraph", n),
      };
    },
    addKeyboardShortcuts() {
      return {
        "Mod-Alt-c": () => this.editor.commands.toggleCodeBlock(),
        Backspace: () => {
          const { empty: n, $anchor: e } = this.editor.state.selection,
            t = e.pos === 1;
          return !n || e.parent.type.name !== this.name
            ? !1
            : t || !e.parent.textContent.length
              ? this.editor.commands.clearNodes()
              : !1;
        },
        Tab: ({ editor: n }) => {
          var e;
          if (!this.options.enableTabIndentation) return !1;
          const t =
              (e = this.options.tabSize) !== null && e !== void 0 ? e : _i,
            { state: r } = n,
            { selection: i } = r,
            { $from: s, empty: o } = i;
          if (s.parent.type !== this.type) return !1;
          const l = " ".repeat(t);
          return o
            ? n.commands.insertContent(l)
            : n.commands.command(({ tr: a }) => {
                const { from: c, to: u } = i,
                  d = r.doc
                    .textBetween(
                      c,
                      u,
                      `
`,
                      `
`,
                    )
                    .split(
                      `
`,
                    )
                    .map((f) => l + f).join(`
`);
                return (a.replaceWith(c, u, r.schema.text(d)), !0);
              });
        },
        "Shift-Tab": ({ editor: n }) => {
          var e;
          if (!this.options.enableTabIndentation) return !1;
          const t =
              (e = this.options.tabSize) !== null && e !== void 0 ? e : _i,
            { state: r } = n,
            { selection: i } = r,
            { $from: s, empty: o } = i;
          return s.parent.type !== this.type
            ? !1
            : o
              ? n.commands.command(({ tr: l }) => {
                  var a;
                  const { pos: c } = s,
                    u = s.start(),
                    d = s.end(),
                    f = r.doc.textBetween(
                      u,
                      d,
                      `
`,
                      `
`,
                    ).split(`
`);
                  let h = 0,
                    p = 0;
                  const g = c - u;
                  for (let x = 0; x < f.length; x += 1) {
                    if (p + f[x].length >= g) {
                      h = x;
                      break;
                    }
                    p += f[x].length + 1;
                  }
                  const m =
                      ((a = f[h].match(/^ */)) === null || a === void 0
                        ? void 0
                        : a[0]) || "",
                    y = Math.min(m.length, t);
                  if (y === 0) return !0;
                  let k = u;
                  for (let x = 0; x < h; x += 1) k += f[x].length + 1;
                  return (
                    l.delete(k, k + y),
                    c - k <= y && l.setSelection(T.create(l.doc, k)),
                    !0
                  );
                })
              : n.commands.command(({ tr: l }) => {
                  const { from: a, to: c } = i,
                    u = r.doc
                      .textBetween(
                        a,
                        c,
                        `
`,
                        `
`,
                      )
                      .split(
                        `
`,
                      )
                      .map((d) => {
                        var f;
                        const h =
                            ((f = d.match(/^ */)) === null || f === void 0
                              ? void 0
                              : f[0]) || "",
                          p = Math.min(h.length, t);
                        return d.slice(p);
                      }).join(`
`);
                  return (l.replaceWith(a, c, r.schema.text(u)), !0);
                });
        },
        Enter: ({ editor: n }) => {
          if (!this.options.exitOnTripleEnter) return !1;
          const { state: e } = n,
            { selection: t } = e,
            { $from: r, empty: i } = t;
          if (!i || r.parent.type !== this.type) return !1;
          const s = r.parentOffset === r.parent.nodeSize - 2,
            o = r.parent.textContent.endsWith(`

`);
          return !s || !o
            ? !1
            : n
                .chain()
                .command(({ tr: l }) => (l.delete(r.pos - 2, r.pos), !0))
                .exitCode()
                .run();
        },
        ArrowUp: ({ editor: n }) => {
          if (!this.options.exitOnArrowUp) return !1;
          const { state: e } = n,
            { selection: t } = e,
            { $from: r, empty: i } = t;
          if (!i || r.parent.type !== this.type || r.parentOffset !== 0)
            return !1;
          const s = r.before();
          return s > 0 ? !1 : n.commands.insertDefaultBlock({ pos: s });
        },
        ArrowDown: ({ editor: n }) => {
          if (!this.options.exitOnArrowDown) return !1;
          const { state: e } = n,
            { selection: t, doc: r } = e,
            { $from: i, empty: s } = t;
          if (
            !s ||
            i.parent.type !== this.type ||
            i.parentOffset !== i.parent.nodeSize - 2
          )
            return !1;
          const o = i.after();
          return o === void 0
            ? !1
            : r.nodeAt(o)
              ? n.commands.command(
                  ({ tr: l }) => (l.setSelection(N.near(r.resolve(o))), !0),
                )
              : n.commands.exitCode();
        },
      };
    },
    addInputRules() {
      return [
        xs({
          find: tb,
          type: this.type,
          getAttributes: (n) => ({ language: n[1] }),
        }),
        xs({
          find: nb,
          type: this.type,
          getAttributes: (n) => ({ language: n[1] }),
        }),
      ];
    },
    addProseMirrorPlugins() {
      return [
        new V({
          key: new K("codeBlockVSCodeHandler"),
          props: {
            handlePaste: (n, e) => {
              if (!e.clipboardData || this.editor.isActive(this.type.name))
                return !1;
              const t = e.clipboardData.getData("text/plain"),
                r = e.clipboardData.getData("vscode-editor-data"),
                i = r ? JSON.parse(r) : void 0,
                s = i?.mode;
              if (!t || !s) return !1;
              const { tr: o, schema: l } = n.state,
                a = l.text(
                  t.replace(
                    /\r\n?/g,
                    `
`,
                  ),
                );
              return (
                o.replaceSelectionWith(this.type.create({ language: s }, a)),
                o.selection.$from.parent.type !== this.type &&
                  o.setSelection(
                    T.near(o.doc.resolve(Math.max(0, o.selection.from - 2))),
                  ),
                o.setMeta("paste", !0),
                n.dispatch(o),
                !0
              );
            },
          },
        }),
      ];
    },
  }),
  ib = ke.create({
    name: "doc",
    topNode: !0,
    content: "block+",
    renderMarkdown: (n, e) =>
      n.content
        ? e.renderChildren(
            n.content,
            `

`,
          )
        : "",
  }),
  sb = ke.create({
    name: "hardBreak",
    markdownTokenName: "br",
    addOptions() {
      return { keepMarks: !0, HTMLAttributes: {} };
    },
    inline: !0,
    group: "inline",
    selectable: !1,
    linebreakReplacement: !0,
    parseHTML() {
      return [{ tag: "br" }];
    },
    renderHTML({ HTMLAttributes: n }) {
      return ["br", X(this.options.HTMLAttributes, n)];
    },
    renderText() {
      return `
`;
    },
    renderMarkdown: () => `  
`,
    parseMarkdown: () => ({ type: "hardBreak" }),
    addCommands() {
      return {
        setHardBreak:
          () =>
          ({ commands: n, chain: e, state: t, editor: r }) =>
            n.first([
              () => n.exitCode(),
              () =>
                n.command(() => {
                  const { selection: i, storedMarks: s } = t;
                  if (i.$from.parent.type.spec.isolating) return !1;
                  const { keepMarks: o } = this.options,
                    { splittableMarks: l } = r.extensionManager,
                    a = s || (i.$to.parentOffset && i.$from.marks());
                  return e()
                    .insertContent({ type: this.name })
                    .command(({ tr: c, dispatch: u }) => {
                      if (u && a && o) {
                        const d = a.filter((f) => l.includes(f.type.name));
                        c.ensureMarks(d);
                      }
                      return !0;
                    })
                    .scrollIntoView()
                    .run();
                }),
            ]),
      };
    },
    addKeyboardShortcuts() {
      return {
        "Mod-Enter": () => this.editor.commands.setHardBreak(),
        "Shift-Enter": () => this.editor.commands.setHardBreak(),
      };
    },
  }),
  ob = ke.create({
    name: "heading",
    addOptions() {
      return { levels: [1, 2, 3, 4, 5, 6], HTMLAttributes: {} };
    },
    content: "inline*",
    group: "block",
    defining: !0,
    addAttributes() {
      return { level: { default: 1, rendered: !1 } };
    },
    parseHTML() {
      return this.options.levels.map((n) => ({
        tag: `h${n}`,
        attrs: { level: n },
      }));
    },
    renderHTML({ node: n, HTMLAttributes: e }) {
      return [
        `h${this.options.levels.includes(n.attrs.level) ? n.attrs.level : this.options.levels[0]}`,
        X(this.options.HTMLAttributes, e),
        0,
      ];
    },
    parseMarkdown(n, e) {
      const t = n.depth || 1;
      return this.options.levels.includes(t)
        ? e.createNode("heading", { level: t }, e.parseInline(n.tokens || []))
        : e.createNode("paragraph", void 0, e.parseInline(n.tokens || []));
    },
    renderMarkdown: (n, e) => {
      var t;
      const r =
          !((t = n.attrs) === null || t === void 0) && t.level
            ? parseInt(n.attrs.level, 10)
            : 1,
        i = "#".repeat(r);
      return n.content ? `${i} ${e.renderChildren(n.content)}` : "";
    },
    addCommands() {
      return {
        setHeading:
          (n) =>
          ({ commands: e }) =>
            this.options.levels.includes(n.level)
              ? e.setNode(this.name, n)
              : !1,
        toggleHeading:
          (n) =>
          ({ commands: e }) =>
            this.options.levels.includes(n.level)
              ? e.toggleNode(this.name, "paragraph", n)
              : !1,
      };
    },
    addKeyboardShortcuts() {
      return this.options.levels.reduce(
        (n, e) => ({
          ...n,
          [`Mod-Alt-${e}`]: () =>
            this.editor.commands.toggleHeading({ level: e }),
        }),
        {},
      );
    },
    addInputRules() {
      return this.options.levels.map((n) =>
        xs({
          find: new RegExp(
            `^(#{${Math.min(...this.options.levels)},${n}})\\s$`,
          ),
          type: this.type,
          getAttributes: { level: n },
        }),
      );
    },
  }),
  lb = ke.create({
    name: "horizontalRule",
    addOptions() {
      return { HTMLAttributes: {}, nextNodeType: "paragraph" };
    },
    group: "block",
    parseHTML() {
      return [{ tag: "hr" }];
    },
    renderHTML({ HTMLAttributes: n }) {
      return ["hr", X(this.options.HTMLAttributes, n)];
    },
    markdownTokenName: "hr",
    parseMarkdown: (n, e) => e.createNode("horizontalRule"),
    renderMarkdown: () => "---",
    addCommands() {
      return {
        setHorizontalRule:
          () =>
          ({ chain: n, state: e }) => {
            if (!ny(e, e.schema.nodes[this.name])) return !1;
            const { selection: t } = e,
              { $to: r } = t,
              i = n();
            return (
              Cu(t)
                ? i.insertContentAt(r.pos, { type: this.name })
                : i.insertContent({ type: this.name }),
              i
                .command(({ state: s, tr: o, dispatch: l }) => {
                  if (l) {
                    const { $to: a } = o.selection,
                      c = a.end();
                    if (a.nodeAfter)
                      a.nodeAfter.isTextblock
                        ? o.setSelection(T.create(o.doc, a.pos + 1))
                        : a.nodeAfter.isBlock
                          ? o.setSelection(O.create(o.doc, a.pos))
                          : o.setSelection(T.create(o.doc, a.pos));
                    else {
                      const u =
                          s.schema.nodes[this.options.nextNodeType] ||
                          a.parent.type.contentMatch.defaultType,
                        d = u?.create();
                      d &&
                        (o.insert(c, d),
                        o.setSelection(T.create(o.doc, c + 1)));
                    }
                    o.scrollIntoView();
                  }
                  return !0;
                })
                .run()
            );
          },
      };
    },
    addInputRules() {
      return [Ly({ find: /^(?:---|—-|___\s|\*\*\*\s)$/, type: this.type })];
    },
  }),
  ab = /(?:^|\s)(\*(?!\s+\*)((?:[^*]+))\*(?!\s+\*))$/,
  cb = /(?:^|\s)(\*(?!\s+\*)((?:[^*]+))\*(?!\s+\*))/g,
  ub = /(?:^|\s)(_(?!\s+_)((?:[^_]+))_(?!\s+_))$/,
  db = /(?:^|\s)(_(?!\s+_)((?:[^_]+))_(?!\s+_))/g,
  fb = It.create({
    name: "italic",
    addOptions() {
      return { HTMLAttributes: {} };
    },
    parseHTML() {
      return [
        { tag: "em" },
        { tag: "i", getAttrs: (n) => n.style.fontStyle !== "normal" && null },
        {
          style: "font-style=normal",
          clearMark: (n) => n.type.name === this.name,
        },
        { style: "font-style=italic" },
      ];
    },
    renderHTML({ HTMLAttributes: n }) {
      return ["em", X(this.options.HTMLAttributes, n), 0];
    },
    addCommands() {
      return {
        setItalic:
          () =>
          ({ commands: n }) =>
            n.setMark(this.name),
        toggleItalic:
          () =>
          ({ commands: n }) =>
            n.toggleMark(this.name),
        unsetItalic:
          () =>
          ({ commands: n }) =>
            n.unsetMark(this.name),
      };
    },
    markdownTokenName: "em",
    parseMarkdown: (n, e) =>
      e.applyMark("italic", e.parseInline(n.tokens || [])),
    markdownOptions: { htmlReopen: { open: "<em>", close: "</em>" } },
    renderMarkdown: (n, e) => `*${e.renderChildren(n)}*`,
    addKeyboardShortcuts() {
      return {
        "Mod-i": () => this.editor.commands.toggleItalic(),
        "Mod-I": () => this.editor.commands.toggleItalic(),
      };
    },
    addInputRules() {
      return [
        Dt({ find: ab, type: this.type }),
        Dt({ find: ub, type: this.type }),
      ];
    },
    addPasteRules() {
      return [
        lt({ find: cb, type: this.type }),
        lt({ find: db, type: this.type }),
      ];
    },
  }),
  hb =
    "aaa1rp3bb0ott3vie4c1le2ogado5udhabi7c0ademy5centure6ountant0s9o1tor4d0s1ult4e0g1ro2tna4f0l1rica5g0akhan5ency5i0g1rbus3force5tel5kdn3l0ibaba4pay4lfinanz6state5y2sace3tom5m0azon4ericanexpress7family11x2fam3ica3sterdam8nalytics7droid5quan4z2o0l2partments8p0le4q0uarelle8r0ab1mco4chi3my2pa2t0e3s0da2ia2sociates9t0hleta5torney7u0ction5di0ble3o3spost5thor3o0s4w0s2x0a2z0ure5ba0by2idu3namex4d1k2r0celona5laycard4s5efoot5gains6seball5ketball8uhaus5yern5b0c1t1va3cg1n2d1e0ats2uty4er2rlin4st0buy5t2f1g1h0arti5i0ble3d1ke2ng0o3o1z2j1lack0friday9ockbuster8g1omberg7ue3m0s1w2n0pparibas9o0ats3ehringer8fa2m1nd2o0k0ing5sch2tik2on4t1utique6x2r0adesco6idgestone9oadway5ker3ther5ussels7s1t1uild0ers6siness6y1zz3v1w1y1z0h3ca0b1fe2l0l1vinklein9m0era3p2non3petown5ital0one8r0avan4ds2e0er0s4s2sa1e1h1ino4t0ering5holic7ba1n1re3c1d1enter4o1rn3f0a1d2g1h0anel2nel4rity4se2t2eap3intai5ristmas6ome4urch5i0priani6rcle4sco3tadel4i0c2y3k1l0aims4eaning6ick2nic1que6othing5ud3ub0med6m1n1o0ach3des3ffee4llege4ogne5m0mbank4unity6pany2re3uter5sec4ndos3struction8ulting7tact3ractors9oking4l1p2rsica5untry4pon0s4rses6pa2r0edit0card4union9icket5own3s1uise0s6u0isinella9v1w1x1y0mru3ou3z2dad1nce3ta1e1ing3sun4y2clk3ds2e0al0er2s3gree4livery5l1oitte5ta3mocrat6ntal2ist5si0gn4v2hl2iamonds6et2gital5rect0ory7scount3ver5h2y2j1k1m1np2o0cs1tor4g1mains5t1wnload7rive4tv2ubai3pont4rban5vag2r2z2earth3t2c0o2deka3u0cation8e1g1mail3erck5nergy4gineer0ing9terprises10pson4quipment8r0icsson6ni3s0q1tate5t1u0rovision8s2vents5xchange6pert3osed4ress5traspace10fage2il1rwinds6th3mily4n0s2rm0ers5shion4t3edex3edback6rrari3ero6i0delity5o2lm2nal1nce1ial7re0stone6mdale6sh0ing5t0ness6j1k1lickr3ghts4r2orist4wers5y2m1o0o0d1tball6rd1ex2sale4um3undation8x2r0ee1senius7l1ogans4ntier7tr2ujitsu5n0d2rniture7tbol5yi3ga0l0lery3o1up4me0s3p1rden4y2b0iz3d0n2e0a1nt0ing5orge5f1g0ee3h1i0ft0s3ves2ing5l0ass3e1obal2o4m0ail3bh2o1x2n1odaddy5ld0point6f2odyear5g0le4p1t1v2p1q1r0ainger5phics5tis4een3ipe3ocery4up4s1t1u0cci3ge2ide2tars5ru3w1y2hair2mburg5ngout5us3bo2dfc0bank7ealth0care8lp1sinki6re1mes5iphop4samitsu7tachi5v2k0t2m1n1ockey4ldings5iday5medepot5goods5s0ense7nda3rse3spital5t0ing5t0els3mail5use3w2r1sbc3t1u0ghes5yatt3undai7ibm2cbc2e1u2d1e0ee3fm2kano4l1m0amat4db2mo0bilien9n0c1dustries8finiti5o2g1k1stitute6urance4e4t0ernational10uit4vestments10o1piranga7q1r0ish4s0maili5t0anbul7t0au2v3jaguar4va3cb2e0ep2tzt3welry6io2ll2m0p2nj2o0bs1urg4t1y2p0morgan6rs3uegos6kaufen5ddi3e0rryhotels6properties14fh2g1h1i0a1ds2m1ndle4tchen5wi3m1n1oeln3matsu5sher5p0mg2n2r0d1ed3uokgroup8w1y0oto4z2la0caixa5mborghini8er3nd0rover6xess5salle5t0ino3robe5w0yer5b1c1ds2ease3clerc5frak4gal2o2xus4gbt3i0dl2fe0insurance9style7ghting6ke2lly3mited4o2ncoln4k2ve1ing5k1lc1p2oan0s3cker3us3l1ndon4tte1o3ve3pl0financial11r1s1t0d0a3u0ndbeck6xe1ury5v1y2ma0drid4if1son4keup4n0agement7go3p1rket0ing3s4riott5shalls7ttel5ba2c0kinsey7d1e0d0ia3et2lbourne7me1orial6n0u2rck0msd7g1h1iami3crosoft7l1ni1t2t0subishi9k1l0b1s2m0a2n1o0bi0le4da2e1i1m1nash3ey2ster5rmon3tgage6scow4to0rcycles9v0ie4p1q1r1s0d2t0n1r2u0seum3ic4v1w1x1y1z2na0b1goya4me2vy3ba2c1e0c1t0bank4flix4work5ustar5w0s2xt0direct7us4f0l2g0o2hk2i0co2ke1on3nja3ssan1y5l1o0kia3rton4w0ruz3tv4p1r0a1w2tt2u1yc2z2obi1server7ffice5kinawa6layan0group9lo3m0ega4ne1g1l0ine5oo2pen3racle3nge4g0anic5igins6saka4tsuka4t2vh3pa0ge2nasonic7ris2s1tners4s1y3y2ccw3e0t2f0izer5g1h0armacy6d1ilips5one2to0graphy6s4ysio5ics1tet2ures6d1n0g1k2oneer5zza4k1l0ace2y0station9umbing5s3m1n0c2ohl2ker3litie5rn2st3r0axi3ess3ime3o0d0uctions8f1gressive8mo2perties3y5tection8u0dential9s1t1ub2w0c2y2qa1pon3uebec3st5racing4dio4e0ad1lestate6tor2y4cipes5d0umbrella9hab3ise0n3t2liance6n0t0als5pair3ort3ublican8st0aurant8view0s5xroth6ich0ardli6oh3l1o1p2o0cks3deo3gers4om3s0vp3u0gby3hr2n2w0e2yukyu6sa0arland6fe0ty4kura4le1on3msclub4ung5ndvik0coromant12ofi4p1rl2s1ve2xo3b0i1s2c0b1haeffler7midt4olarships8ol3ule3warz5ience5ot3d1e0arch3t2cure1ity6ek2lect4ner3rvices6ven3w1x0y3fr2g1h0angrila6rp3ell3ia1ksha5oes2p0ping5uji3w3i0lk2na1gles5te3j1k0i0n2y0pe4l0ing4m0art3ile4n0cf3o0ccer3ial4ftbank4ware6hu2lar2utions7ng1y2y2pa0ce3ort2t3r0l2s1t0ada2ples4r1tebank4farm7c0group6ockholm6rage3e3ream4udio2y3yle4u0cks3pplies3y2ort5rf1gery5zuki5v1watch4iss4x1y0dney4stems6z2tab1ipei4lk2obao4rget4tamotors6r2too4x0i3c0i2d0k2eam2ch0nology8l1masek5nnis4va3f1g1h0d1eater2re6iaa2ckets5enda4ps2res2ol4j0maxx4x2k0maxx5l1m0all4n1o0day3kyo3ols3p1ray3shiba5tal3urs3wn2yota3s3r0ade1ing4ining5vel0ers0insurance16ust3v2t1ube2i1nes3shu4v0s2w1z2ua1bank3s2g1k1nicom3versity8o2ol2ps2s1y1z2va0cations7na1guard7c1e0gas3ntures6risign5mögensberater2ung14sicherung10t2g1i0ajes4deo3g1king4llas4n1p1rgin4sa1ion4va1o3laanderen9n1odka3lvo3te1ing3o2yage5u2wales2mart4ter4ng0gou5tch0es6eather0channel12b0cam3er2site5d0ding5ibo2r3f1hoswho6ien2ki2lliamhill9n0dows4e1ners6me2oodside6rk0s2ld3w2s1tc1f3xbox3erox4ihuan4n2xx2yz3yachts4hoo3maxun5ndex5e1odobashi7ga2kohama6u0tube6t1un3za0ppos4ra3ero3ip2m1one3uerich6w2",
  pb =
    "ελ1υ2бг1ел3дети4ею2католик6ом3мкд2он1сква6онлайн5рг3рус2ф2сайт3рб3укр3қаз3հայ3ישראל5קום3ابوظبي5رامكو5لاردن4بحرين5جزائر5سعودية6عليان5مغرب5مارات5یران5بارت2زار4يتك3ھارت5تونس4سودان3رية5شبكة4عراق2ب2مان4فلسطين6قطر3كاثوليك6وم3مصر2ليسيا5وريتانيا7قع4همراه5پاکستان7ڀارت4कॉम3नेट3भारत0म्3ोत5संगठन5বাংলা5ভারত2ৰত4ਭਾਰਤ4ભારત4ଭାରତ4இந்தியா6லங்கை6சிங்கப்பூர்11భారత్5ಭಾರತ4ഭാരതം5ලංකා4คอม3ไทย3ລາວ3გე2みんな3アマゾン4クラウド4グーグル4コム2ストア3セール3ファッション6ポイント4世界2中信1国1國1文网3亚马逊3企业2佛山2信息2健康2八卦2公司1益2台湾1灣2商城1店1标2嘉里0大酒店5在线2大拿2天主教3娱乐2家電2广东2微博2慈善2我爱你3手机2招聘2政务1府2新加坡2闻2时尚2書籍2机构2淡马锡3游戏2澳門2点看2移动2组织机构4网址1店1站1络2联通2谷歌2购物2通販2集团2電訊盈科4飞利浦3食品2餐厅2香格里拉3港2닷넷1컴2삼성2한국2",
  vs = "numeric",
  Ms = "ascii",
  Es = "alpha",
  Sn = "asciinumeric",
  pn = "alphanumeric",
  Ts = "domain",
  Yu = "emoji",
  mb = "scheme",
  gb = "slashscheme",
  Wi = "whitespace";
function yb(n, e) {
  return (n in e || (e[n] = []), e[n]);
}
function bt(n, e, t) {
  (e[vs] && ((e[Sn] = !0), (e[pn] = !0)),
    e[Ms] && ((e[Sn] = !0), (e[Es] = !0)),
    e[Sn] && (e[pn] = !0),
    e[Es] && (e[pn] = !0),
    e[pn] && (e[Ts] = !0),
    e[Yu] && (e[Ts] = !0));
  for (const r in e) {
    const i = yb(r, t);
    i.indexOf(n) < 0 && i.push(n);
  }
}
function bb(n, e) {
  const t = {};
  for (const r in e) e[r].indexOf(n) >= 0 && (t[r] = !0);
  return t;
}
function pe(n = null) {
  ((this.j = {}), (this.jr = []), (this.jd = null), (this.t = n));
}
pe.groups = {};
pe.prototype = {
  accepts() {
    return !!this.t;
  },
  go(n) {
    const e = this,
      t = e.j[n];
    if (t) return t;
    for (let r = 0; r < e.jr.length; r++) {
      const i = e.jr[r][0],
        s = e.jr[r][1];
      if (s && i.test(n)) return s;
    }
    return e.jd;
  },
  has(n, e = !1) {
    return e ? n in this.j : !!this.go(n);
  },
  ta(n, e, t, r) {
    for (let i = 0; i < n.length; i++) this.tt(n[i], e, t, r);
  },
  tr(n, e, t, r) {
    r = r || pe.groups;
    let i;
    return (
      e && e.j ? (i = e) : ((i = new pe(e)), t && r && bt(e, t, r)),
      this.jr.push([n, i]),
      i
    );
  },
  ts(n, e, t, r) {
    let i = this;
    const s = n.length;
    if (!s) return i;
    for (let o = 0; o < s - 1; o++) i = i.tt(n[o]);
    return i.tt(n[s - 1], e, t, r);
  },
  tt(n, e, t, r) {
    r = r || pe.groups;
    const i = this;
    if (e && e.j) return ((i.j[n] = e), e);
    const s = e;
    let o,
      l = i.go(n);
    if (
      (l
        ? ((o = new pe()),
          Object.assign(o.j, l.j),
          o.jr.push.apply(o.jr, l.jr),
          (o.jd = l.jd),
          (o.t = l.t))
        : (o = new pe()),
      s)
    ) {
      if (r)
        if (o.t && typeof o.t == "string") {
          const a = Object.assign(bb(o.t, r), t);
          bt(s, a, r);
        } else t && bt(s, t, r);
      o.t = s;
    }
    return ((i.j[n] = o), o);
  },
};
const R = (n, e, t, r, i) => n.ta(e, t, r, i),
  H = (n, e, t, r, i) => n.tr(e, t, r, i),
  ea = (n, e, t, r, i) => n.ts(e, t, r, i),
  S = (n, e, t, r, i) => n.tt(e, t, r, i),
  Be = "WORD",
  As = "UWORD",
  Xu = "ASCIINUMERICAL",
  Qu = "ALPHANUMERICAL",
  $n = "LOCALHOST",
  Os = "TLD",
  Ns = "UTLD",
  pr = "SCHEME",
  _t = "SLASH_SCHEME",
  so = "NUM",
  Ds = "WS",
  oo = "NL",
  xn = "OPENBRACE",
  wn = "CLOSEBRACE",
  Rr = "OPENBRACKET",
  Ir = "CLOSEBRACKET",
  Lr = "OPENPAREN",
  Pr = "CLOSEPAREN",
  Br = "OPENANGLEBRACKET",
  $r = "CLOSEANGLEBRACKET",
  zr = "FULLWIDTHLEFTPAREN",
  Fr = "FULLWIDTHRIGHTPAREN",
  Vr = "LEFTCORNERBRACKET",
  jr = "RIGHTCORNERBRACKET",
  Hr = "LEFTWHITECORNERBRACKET",
  _r = "RIGHTWHITECORNERBRACKET",
  Wr = "FULLWIDTHLESSTHAN",
  qr = "FULLWIDTHGREATERTHAN",
  Ur = "AMPERSAND",
  Kr = "APOSTROPHE",
  Jr = "ASTERISK",
  Ye = "AT",
  Gr = "BACKSLASH",
  Yr = "BACKTICK",
  Xr = "CARET",
  kt = "COLON",
  lo = "COMMA",
  Qr = "DOLLAR",
  Ae = "DOT",
  Zr = "EQUALS",
  ao = "EXCLAMATION",
  we = "HYPHEN",
  Cn = "PERCENT",
  ei = "PIPE",
  ti = "PLUS",
  Ut = "POUND",
  pt = "QUERY",
  co = "QUOTE",
  Zu = "FULLWIDTHMIDDLEDOT",
  uo = "SEMI",
  Oe = "SLASH",
  vn = "TILDE",
  ni = "UNDERSCORE",
  ed = "EMOJI",
  ri = "SYM";
var td = Object.freeze({
  __proto__: null,
  ALPHANUMERICAL: Qu,
  AMPERSAND: Ur,
  APOSTROPHE: Kr,
  ASCIINUMERICAL: Xu,
  ASTERISK: Jr,
  AT: Ye,
  BACKSLASH: Gr,
  BACKTICK: Yr,
  CARET: Xr,
  CLOSEANGLEBRACKET: $r,
  CLOSEBRACE: wn,
  CLOSEBRACKET: Ir,
  CLOSEPAREN: Pr,
  COLON: kt,
  COMMA: lo,
  DOLLAR: Qr,
  DOT: Ae,
  EMOJI: ed,
  EQUALS: Zr,
  EXCLAMATION: ao,
  FULLWIDTHGREATERTHAN: qr,
  FULLWIDTHLEFTPAREN: zr,
  FULLWIDTHLESSTHAN: Wr,
  FULLWIDTHMIDDLEDOT: Zu,
  FULLWIDTHRIGHTPAREN: Fr,
  HYPHEN: we,
  LEFTCORNERBRACKET: Vr,
  LEFTWHITECORNERBRACKET: Hr,
  LOCALHOST: $n,
  NL: oo,
  NUM: so,
  OPENANGLEBRACKET: Br,
  OPENBRACE: xn,
  OPENBRACKET: Rr,
  OPENPAREN: Lr,
  PERCENT: Cn,
  PIPE: ei,
  PLUS: ti,
  POUND: Ut,
  QUERY: pt,
  QUOTE: co,
  RIGHTCORNERBRACKET: jr,
  RIGHTWHITECORNERBRACKET: _r,
  SCHEME: pr,
  SEMI: uo,
  SLASH: Oe,
  SLASH_SCHEME: _t,
  SYM: ri,
  TILDE: vn,
  TLD: Os,
  UNDERSCORE: ni,
  UTLD: Ns,
  UWORD: As,
  WORD: Be,
  WS: Ds,
});
const Ie = /[a-z]/;
let Wt = /[a-z]/i,
  mr = /[\u{1F000}-\u{1FAFF}\u{2600}-\u{27BF}]|\u{FE0F}/u;
try {
  ((Wt = new RegExp("\\p{L}", "u")), (mr = new RegExp("\\p{Emoji}", "u")));
} catch {}
const Le = /\d/,
  qi = /\s/,
  ta = "\r",
  Ui = `
`,
  kb = "️",
  Sb = "‍",
  Ki = "￼";
let nr = null,
  rr = null;
function xb(n = []) {
  const e = {};
  pe.groups = e;
  const t = new pe();
  (nr == null && (nr = na(hb)),
    rr == null && (rr = na(pb)),
    S(t, "'", Kr),
    S(t, "{", xn),
    S(t, "}", wn),
    S(t, "[", Rr),
    S(t, "]", Ir),
    S(t, "(", Lr),
    S(t, ")", Pr),
    S(t, "<", Br),
    S(t, ">", $r),
    S(t, "（", zr),
    S(t, "）", Fr),
    S(t, "「", Vr),
    S(t, "」", jr),
    S(t, "『", Hr),
    S(t, "』", _r),
    S(t, "＜", Wr),
    S(t, "＞", qr),
    S(t, "&", Ur),
    S(t, "*", Jr),
    S(t, "@", Ye),
    S(t, "`", Yr),
    S(t, "^", Xr),
    S(t, ":", kt),
    S(t, ",", lo),
    S(t, "$", Qr),
    S(t, ".", Ae),
    S(t, "=", Zr),
    S(t, "!", ao),
    S(t, "-", we),
    S(t, "%", Cn),
    S(t, "|", ei),
    S(t, "+", ti),
    S(t, "#", Ut),
    S(t, "?", pt),
    S(t, '"', co),
    S(t, "/", Oe),
    S(t, ";", uo),
    S(t, "~", vn),
    S(t, "_", ni),
    S(t, "\\", Gr),
    S(t, "・", Zu));
  const r = H(t, Le, so, { [vs]: !0 });
  H(r, Le, r);
  const i = H(r, Ie, Xu, { [Sn]: !0 }),
    s = H(r, Wt, Qu, { [pn]: !0 }),
    o = H(t, Ie, Be, { [Ms]: !0 });
  (H(o, Le, i), H(o, Ie, o), H(i, Le, i), H(i, Ie, i));
  const l = H(t, Wt, As, { [Es]: !0 });
  (H(l, Ie), H(l, Le, s), H(l, Wt, l), H(s, Le, s), H(s, Ie), H(s, Wt, s));
  const a = S(t, Ui, oo, { [Wi]: !0 }),
    c = S(t, ta, Ds, { [Wi]: !0 }),
    u = H(t, qi, Ds, { [Wi]: !0 });
  (S(t, Ki, u),
    S(c, Ui, a),
    S(c, Ki, u),
    H(c, qi, u),
    S(u, ta),
    S(u, Ui),
    H(u, qi, u),
    S(u, Ki, u));
  const d = H(t, mr, ed, { [Yu]: !0 });
  (S(d, "#"), H(d, mr, d), S(d, kb, d));
  const f = S(d, Sb);
  (S(f, "#"), H(f, mr, d));
  const h = [
      [Ie, o],
      [Le, i],
    ],
    p = [
      [Ie, null],
      [Wt, l],
      [Le, s],
    ];
  for (let g = 0; g < nr.length; g++) Ue(t, nr[g], Os, Be, h);
  for (let g = 0; g < rr.length; g++) Ue(t, rr[g], Ns, As, p);
  (bt(Os, { tld: !0, ascii: !0 }, e),
    bt(Ns, { utld: !0, alpha: !0 }, e),
    Ue(t, "file", pr, Be, h),
    Ue(t, "mailto", pr, Be, h),
    Ue(t, "http", _t, Be, h),
    Ue(t, "https", _t, Be, h),
    Ue(t, "ftp", _t, Be, h),
    Ue(t, "ftps", _t, Be, h),
    bt(pr, { scheme: !0, ascii: !0 }, e),
    bt(_t, { slashscheme: !0, ascii: !0 }, e),
    (n = n.sort((g, m) => (g[0] > m[0] ? 1 : -1))));
  for (let g = 0; g < n.length; g++) {
    const m = n[g][0],
      k = n[g][1] ? { [mb]: !0 } : { [gb]: !0 };
    (m.indexOf("-") >= 0
      ? (k[Ts] = !0)
      : Ie.test(m)
        ? Le.test(m)
          ? (k[Sn] = !0)
          : (k[Ms] = !0)
        : (k[vs] = !0),
      ea(t, m, m, k));
  }
  return (
    ea(t, "localhost", $n, { ascii: !0 }),
    (t.jd = new pe(ri)),
    { start: t, tokens: Object.assign({ groups: e }, td) }
  );
}
function nd(n, e) {
  const t = wb(e.replace(/[A-Z]/g, (l) => l.toLowerCase())),
    r = t.length,
    i = [];
  let s = 0,
    o = 0;
  for (; o < r;) {
    let l = n,
      a = null,
      c = 0,
      u = null,
      d = -1,
      f = -1;
    for (; o < r && (a = l.go(t[o]));)
      ((l = a),
        l.accepts()
          ? ((d = 0), (f = 0), (u = l))
          : d >= 0 && ((d += t[o].length), f++),
        (c += t[o].length),
        (s += t[o].length),
        o++);
    ((s -= d),
      (o -= f),
      (c -= d),
      i.push({ t: u.t, v: e.slice(s - c, s), s: s - c, e: s }));
  }
  return i;
}
function wb(n) {
  const e = [],
    t = n.length;
  let r = 0;
  for (; r < t;) {
    let i = n.charCodeAt(r),
      s,
      o =
        i < 55296 ||
        i > 56319 ||
        r + 1 === t ||
        (s = n.charCodeAt(r + 1)) < 56320 ||
        s > 57343
          ? n[r]
          : n.slice(r, r + 2);
    (e.push(o), (r += o.length));
  }
  return e;
}
function Ue(n, e, t, r, i) {
  let s;
  const o = e.length;
  for (let l = 0; l < o - 1; l++) {
    const a = e[l];
    (n.j[a]
      ? (s = n.j[a])
      : ((s = new pe(r)), (s.jr = i.slice()), (n.j[a] = s)),
      (n = s));
  }
  return ((s = new pe(t)), (s.jr = i.slice()), (n.j[e[o - 1]] = s), s);
}
function na(n) {
  const e = [],
    t = [];
  let r = 0,
    i = "0123456789";
  for (; r < n.length;) {
    let s = 0;
    for (; i.indexOf(n[r + s]) >= 0;) s++;
    if (s > 0) {
      e.push(t.join(""));
      for (let o = parseInt(n.substring(r, r + s), 10); o > 0; o--) t.pop();
      r += s;
    } else (t.push(n[r]), r++);
  }
  return e;
}
const zn = {
  defaultProtocol: "http",
  events: null,
  format: ra,
  formatHref: ra,
  nl2br: !1,
  tagName: "a",
  target: null,
  rel: null,
  validate: !0,
  truncate: 1 / 0,
  className: null,
  attributes: null,
  ignoreTags: [],
  ignoreClasses: [],
  render: null,
};
function fo(n, e = null) {
  let t = Object.assign({}, zn);
  n && (t = Object.assign(t, n instanceof fo ? n.o : n));
  const r = t.ignoreTags,
    i = [];
  for (let s = 0; s < r.length; s++) i.push(r[s].toUpperCase());
  ((this.o = t),
    e && (this.defaultRender = e),
    (this.ignoreTags = i),
    (this.ignoreClasses = t.ignoreClasses.slice()));
}
fo.prototype = {
  o: zn,
  ignoreTags: [],
  ignoreClasses: [],
  isIgnoredClass(n) {
    if (typeof n != "string" || this.ignoreClasses.length === 0) return !1;
    const e = n.split(/\s+/);
    for (let t = 0; t < e.length; t++)
      if (this.ignoreClasses.indexOf(e[t]) >= 0) return !0;
    return !1;
  },
  defaultRender(n) {
    return n;
  },
  check(n) {
    return this.get("validate", n.toString(), n);
  },
  get(n, e, t) {
    const r = e != null;
    let i = this.o[n];
    return (
      i &&
      (typeof i == "object"
        ? ((i = t.t in i ? i[t.t] : zn[n]),
          typeof i == "function" && r && (i = i(e, t)))
        : typeof i == "function" && r && (i = i(e, t.t, t)),
      i)
    );
  },
  getObj(n, e, t) {
    let r = this.o[n];
    return (typeof r == "function" && e != null && (r = r(e, t.t, t)), r);
  },
  render(n) {
    const e = n.render(this);
    return (this.get("render", null, n) || this.defaultRender)(e, n.t, n);
  },
};
function ra(n) {
  return n;
}
function rd(n, e) {
  ((this.t = "token"), (this.v = n), (this.tk = e));
}
rd.prototype = {
  isLink: !1,
  toString() {
    return this.v;
  },
  toHref(n) {
    return this.toString();
  },
  toFormattedString(n) {
    const e = this.toString(),
      t = n.get("truncate", e, this),
      r = n.get("format", e, this);
    return t && r.length > t ? r.substring(0, t) + "…" : r;
  },
  toFormattedHref(n) {
    return n.get("formatHref", this.toHref(n.get("defaultProtocol")), this);
  },
  startIndex() {
    return this.tk[0].s;
  },
  endIndex() {
    return this.tk[this.tk.length - 1].e;
  },
  toObject(n = zn.defaultProtocol) {
    return {
      type: this.t,
      value: this.toString(),
      isLink: this.isLink,
      href: this.toHref(n),
      start: this.startIndex(),
      end: this.endIndex(),
    };
  },
  toFormattedObject(n) {
    return {
      type: this.t,
      value: this.toFormattedString(n),
      isLink: this.isLink,
      href: this.toFormattedHref(n),
      start: this.startIndex(),
      end: this.endIndex(),
    };
  },
  validate(n) {
    return n.get("validate", this.toString(), this);
  },
  render(n) {
    const e = this,
      t = this.toHref(n.get("defaultProtocol")),
      r = n.get("formatHref", t, this),
      i = n.get("tagName", t, e),
      s = this.toFormattedString(n),
      o = {},
      l = n.get("className", t, e),
      a = n.get("target", t, e),
      c = n.get("rel", t, e),
      u = n.getObj("attributes", t, e),
      d = n.getObj("events", t, e);
    return (
      (o.href = r),
      l && (o.class = l),
      a && (o.target = a),
      c && (o.rel = c),
      u && Object.assign(o, u),
      { tagName: i, attributes: o, content: s, eventListeners: d }
    );
  },
};
function ki(n, e) {
  class t extends rd {
    constructor(i, s) {
      (super(i, s), (this.t = n));
    }
  }
  for (const r in e) t.prototype[r] = e[r];
  return ((t.t = n), t);
}
const Cb = ki("email", {
    isLink: !0,
    toHref() {
      return "mailto:" + this.toString();
    },
  }),
  ia = ki("text"),
  vb = ki("nl"),
  ir = ki("url", {
    isLink: !0,
    toHref(n = zn.defaultProtocol) {
      return this.hasProtocol() ? this.v : `${n}://${this.v}`;
    },
    hasProtocol() {
      const n = this.tk;
      return n.length >= 2 && n[0].t !== $n && n[1].t === kt;
    },
  }),
  xe = (n) => new pe(n);
function Mb({ groups: n }) {
  const e = n.domain.concat([
      Ur,
      Jr,
      Ye,
      Gr,
      Yr,
      Xr,
      Qr,
      Zr,
      we,
      so,
      Cn,
      ei,
      ti,
      Ut,
      Oe,
      ri,
      vn,
      ni,
    ]),
    t = [
      Kr,
      kt,
      lo,
      Ae,
      ao,
      Cn,
      pt,
      co,
      uo,
      Br,
      $r,
      xn,
      wn,
      Ir,
      Rr,
      Lr,
      Pr,
      zr,
      Fr,
      Vr,
      jr,
      Hr,
      _r,
      Wr,
      qr,
    ],
    r = [
      Ur,
      Kr,
      Jr,
      Gr,
      Yr,
      Xr,
      Qr,
      Zr,
      we,
      xn,
      wn,
      Cn,
      ei,
      ti,
      Ut,
      pt,
      Oe,
      ri,
      vn,
      ni,
    ],
    i = xe(),
    s = S(i, vn);
  (R(s, r, s), R(s, n.domain, s));
  const o = xe(),
    l = xe(),
    a = xe();
  (R(i, n.domain, o),
    R(i, n.scheme, l),
    R(i, n.slashscheme, a),
    R(o, r, s),
    R(o, n.domain, o));
  const c = S(o, Ye);
  (S(s, Ye, c), S(l, Ye, c), S(a, Ye, c));
  const u = S(s, Ae);
  (R(u, r, s), R(u, n.domain, s));
  const d = xe();
  (R(c, n.domain, d), R(d, n.domain, d));
  const f = S(d, Ae);
  R(f, n.domain, d);
  const h = xe(Cb);
  (R(f, n.tld, h), R(f, n.utld, h), S(c, $n, h));
  const p = S(d, we);
  (S(p, we, p), R(p, n.domain, d), R(h, n.domain, d), S(h, Ae, f), S(h, we, p));
  const g = S(o, we),
    m = S(o, Ae);
  (S(g, we, g), R(g, n.domain, o), R(m, r, s), R(m, n.domain, o));
  const y = xe(ir);
  (R(m, n.tld, y),
    R(m, n.utld, y),
    R(y, n.domain, o),
    R(y, r, s),
    S(y, Ae, m),
    S(y, we, g),
    S(y, Ye, c));
  const k = S(y, kt),
    x = xe(ir);
  R(k, n.numeric, x);
  const w = xe(ir),
    M = xe();
  (R(w, e, w),
    R(w, t, M),
    R(M, e, w),
    R(M, t, M),
    S(y, Oe, w),
    S(x, Oe, w),
    S(y, pt, M),
    S(y, Ut, w),
    S(x, pt, M),
    S(x, Ut, w));
  const D = S(l, kt),
    E = S(a, kt),
    I = S(E, Oe),
    L = S(I, Oe);
  (R(l, n.domain, o),
    S(l, Ae, m),
    S(l, we, g),
    R(a, n.domain, o),
    S(a, Ae, m),
    S(a, we, g),
    R(D, n.domain, w),
    S(D, Oe, w),
    S(D, pt, w),
    R(L, n.domain, w),
    R(L, e, w),
    S(L, Oe, w));
  const F = [
    [xn, wn],
    [Rr, Ir],
    [Lr, Pr],
    [Br, $r],
    [zr, Fr],
    [Vr, jr],
    [Hr, _r],
    [Wr, qr],
  ];
  for (let Se = 0; Se < F.length; Se++) {
    const [dt, ft] = F[Se],
      ae = S(w, dt);
    S(M, dt, ae);
    const he = xe(ir);
    R(ae, e, he);
    const ce = xe();
    (R(ae, t, ce),
      S(ae, ft, w),
      R(he, e, he),
      R(he, t, ce),
      R(ce, e, he),
      R(ce, t, ce),
      S(he, ft, w),
      S(ce, ft, w));
  }
  return (S(i, $n, y), S(i, oo, vb), { start: i, tokens: td });
}
function Eb(n, e, t) {
  let r = t.length,
    i = 0,
    s = [],
    o = [];
  const l = [];
  for (; i < r;) {
    let a = n,
      c = null,
      u = null,
      d = 0,
      f = null,
      h = -1,
      p = [];
    for (; i < r && !(c = a.go(t[i].t));) o.push(t[i++]);
    for (; i < r && (u = c || a.go(t[i].t));)
      if (((c = null), (a = u), i++, d++, a.accepts()))
        ((h = 0), (f = a), (p = []));
      else if ((h >= 0 && h++, p.push(a), l[i] && l[i].has(a))) break;
    for (let g = 0, m = i - p.length + 1; g < p.length; g++, m++)
      (l[m] || (l[m] = new Set())).add(p[g]);
    if (h < 0) ((i -= d), i < r && (o.push(t[i]), i++));
    else {
      (o.length > 0 && (s.push(Ji(ia, e, o)), (o = [])), (i -= h), (d -= h));
      const g = f.t,
        m = t.slice(i - d, i);
      s.push(Ji(g, e, m));
    }
  }
  return (o.length > 0 && s.push(Ji(ia, e, o)), s);
}
function Ji(n, e, t) {
  const r = t[0].s,
    i = t[t.length - 1].e,
    s = e.slice(r, i);
  return new n(s, t);
}
const Tb = (typeof console < "u" && console && console.warn) || (() => {}),
  Ab =
    "until manual call of linkify.init(). Register all schemes and plugins before invoking linkify the first time.",
  j = {
    scanner: null,
    parser: null,
    tokenQueue: [],
    pluginQueue: [],
    customSchemes: [],
    initialized: !1,
  };
function Ob() {
  return (
    (pe.groups = {}),
    (j.scanner = null),
    (j.parser = null),
    (j.tokenQueue = []),
    (j.pluginQueue = []),
    (j.customSchemes = []),
    (j.initialized = !1),
    j
  );
}
function sa(n, e = !1) {
  if (
    (j.initialized &&
      Tb(
        `linkifyjs: already initialized - will not register custom scheme "${n}" ${Ab}`,
      ),
    !/^[0-9a-z]+(-[0-9a-z]+)*$/.test(n))
  )
    throw new Error(`linkifyjs: incorrect scheme format.
1. Must only contain digits, lowercase ASCII letters or "-"
2. Cannot start or end with "-"
3. "-" cannot repeat`);
  j.customSchemes.push([n, e]);
}
function Nb() {
  j.scanner = xb(j.customSchemes);
  for (let n = 0; n < j.tokenQueue.length; n++)
    j.tokenQueue[n][1]({ scanner: j.scanner });
  j.parser = Mb(j.scanner.tokens);
  for (let n = 0; n < j.pluginQueue.length; n++)
    j.pluginQueue[n][1]({ scanner: j.scanner, parser: j.parser });
  return ((j.initialized = !0), j);
}
function ho(n) {
  return (j.initialized || Nb(), Eb(j.parser.start, n, nd(j.scanner.start, n)));
}
ho.scan = nd;
function id(n, e = null, t = null) {
  if (e && typeof e == "object") {
    if (t) throw Error(`linkifyjs: Invalid link type ${e}; must be a string`);
    ((t = e), (e = null));
  }
  const r = new fo(t),
    i = ho(n),
    s = [];
  for (let o = 0; o < i.length; o++) {
    const l = i[o];
    l.isLink &&
      (!e || l.t === e) &&
      r.check(l) &&
      s.push(l.toFormattedObject(r));
  }
  return s;
}
const Si = "[\0-   ᠎ -\u2029 　]",
  Db = new RegExp(Si),
  Rb = new RegExp(`${Si}$`),
  Ib = new RegExp(`${Si}+$`),
  Lb = new RegExp(Si, "g");
function Pb(n, e, t) {
  var r, i;
  const s = n.doc.resolve(e.to);
  if (!(!((r = s.nodeBefore) === null || r === void 0) && r.isText)) return;
  const o =
    (i = n.doc.textBetween(e.from, e.to, "￼", "￼").match(Ib)) === null ||
    i === void 0
      ? void 0
      : i[0];
  if (!o) return;
  const l = e.to - o.length,
    a = yi(l, e.to, n.doc).filter((d) => d.mark.type === t);
  if (!a.length) return;
  const { nodeAfter: c } = s;
  if (c && a.some((d) => d.mark.isInSet(c.marks))) return;
  const u = n.storedMarks;
  (n.removeMark(l, e.to, t),
    n.setStoredMarks(u),
    n.selection.empty && n.selection.from === e.to && n.removeStoredMark(t));
}
function Bb(n) {
  return n.length === 1
    ? n[0].isLink
    : n.length === 3 && n[1].isLink
      ? ["()", "[]"].includes(n[0].value + n[2].value)
      : !1;
}
function $b(n) {
  return new V({
    key: new K("autolink"),
    appendTransaction: (e, t, r) => {
      const i = e.some((a) => a.docChanged) && !t.doc.eq(r.doc),
        s = e.some((a) => a.getMeta("preventAutolink"));
      if (!i || s) return;
      const { tr: o } = r,
        l = gu(t.doc, [...e]);
      if (!e.some(Zp)) {
        const a = [];
        (l.steps.forEach((c, u) => {
          if (!(c instanceof _) || !c.slice.size) return;
          const d = l.mapping.slice(u + 1),
            f = d.map(c.from, 1),
            h = d.map(c.from + c.slice.size, -1);
          f < h && a.push({ from: f, to: h });
        }),
          a.sort((c, u) => u.to - c.to),
          a.forEach((c) => Pb(o, c, n.type)));
      }
      if (
        (gi(l).forEach(({ newRange: a }) => {
          const c = qm(r.doc, a, (f) => f.isTextblock);
          let u, d;
          if (c.length > 1)
            ((u = c[0]),
              (d = r.doc.textBetween(
                u.pos,
                u.pos + u.node.nodeSize,
                void 0,
                " ",
              )));
          else if (c.length) {
            const f = r.doc.textBetween(a.from, a.to, " ", " ");
            if (!Rb.test(f)) return;
            ((u = c[0]), (d = r.doc.textBetween(u.pos, a.to, void 0, " ")));
          }
          if (u && d) {
            const f = d.split(Db).filter(Boolean);
            if (f.length <= 0) return !1;
            const h = f[f.length - 1],
              p = u.pos + d.lastIndexOf(h);
            if (!h) return !1;
            const g = ho(h).map((m) => m.toObject(n.defaultProtocol));
            if (!Bb(g)) return !1;
            g.filter((m) => m.isLink)
              .map((m) => ({ ...m, from: p + m.start + 1, to: p + m.end + 1 }))
              .filter((m) =>
                r.schema.marks.code
                  ? !r.doc.rangeHasMark(m.from, m.to, r.schema.marks.code)
                  : !0,
              )
              .filter((m) => n.validate(m.value))
              .filter((m) => n.shouldAutoLink(m.value))
              .forEach((m) => {
                yi(m.from, m.to, r.doc).some((y) => y.mark.type === n.type) ||
                  o.addMark(m.from, m.to, n.type.create({ href: m.href }));
              });
          }
        }),
        !!o.steps.length)
      )
        return o;
    },
  });
}
function zb(n) {
  return new V({
    key: new K("handleClickLink"),
    props: {
      handleClick: (e, t, r) => {
        if (r.button !== 0 || !e.editable) return !1;
        let i = null;
        if (r.target instanceof HTMLAnchorElement) i = r.target;
        else {
          const a = r.target;
          if (!a) return !1;
          const c = n.editor.view.dom;
          ((i = a.closest("a")), i && !c.contains(i) && (i = null));
        }
        if (!i) return !1;
        let s = !1;
        if (
          (n.enableClickSelection &&
            (s = n.editor.commands.extendMarkRange(n.type.name)),
          n.openOnClick)
        ) {
          var o, l;
          const a = wu(e.state, n.type.name),
            c = (o = i.href) !== null && o !== void 0 ? o : a.href,
            u = (l = i.target) !== null && l !== void 0 ? l : a.target;
          c && (window.open(c, u), (s = !0));
        }
        return s;
      },
    },
  });
}
const Fb =
    /\[([^[\]]+)\]\(((?:[^\s()]|\([^\s()]*\))+)(?:\s+(?:(["'])(.*?)\3|“(.*?)”|‘(.*?)’))?\)$/,
  Vb =
    /\[([^[\]]+)\]\(((?:[^\s()]|\([^\s()]*\))+)(?:\s+(?:(["'])(.*?)\3|“(.*?)”|‘(.*?)’))?\)/g;
function sd(n, e) {
  let t = 0;
  for (let r = e - 1; r >= 0 && n[r] === "\\"; r -= 1) t += 1;
  return t % 2 === 1;
}
function jb(n, e) {
  let t = 0,
    r = 0;
  for (; r < e;) {
    if (n[r] !== "`") {
      r += 1;
      continue;
    }
    if (t === 0 && sd(n, r)) {
      r += 1;
      continue;
    }
    let i = 0;
    for (; r < e && n[r] === "`";) ((i += 1), (r += 1));
    t === 0 ? (t = i) : i === t && (t = 0);
  }
  return t > 0;
}
function od(n, e, t) {
  var r, i;
  const [, s, o] = e;
  return (e.index ? n[e.index - 1] : void 0) === "!" ||
    sd(n, (r = e.index) !== null && r !== void 0 ? r : 0) ||
    jb(n, (i = e.index) !== null && i !== void 0 ? i : 0)
    ? !1
    : !!s.trim() && t(o);
}
function ld(n) {
  var e, t;
  const [r, i, s, , o, l, a] = n,
    c = (e = o ?? l) !== null && e !== void 0 ? e : a;
  return {
    index: (t = n.index) !== null && t !== void 0 ? t : 0,
    text: r,
    replaceWith: i,
    data: { href: s, title: c || null, markdown: !0 },
  };
}
function Hb(n, e) {
  return n.index < e.index + e.text.length && e.index < n.index + n.text.length;
}
function ad(n) {
  var e, t, r;
  return {
    href: (e = n.data) === null || e === void 0 ? void 0 : e.href,
    title:
      (t = (r = n.data) === null || r === void 0 ? void 0 : r.title) !== null &&
      t !== void 0
        ? t
        : null,
  };
}
function _b(n) {
  const e = Dt({
    find: (t) => {
      const r = Fb.exec(t);
      return !r || !od(t, r, n.isAllowedHref) ? null : ld(r);
    },
    type: n.type,
    getAttributes: ad,
  });
  return new Wn({
    find: e.find,
    handler: (t) => {
      const r = e.handler(t);
      return (
        r !== null &&
          t.state.tr.steps.length &&
          t.state.tr.setMeta("preventAutolink", !0),
        r
      );
    },
  });
}
function Wb(n) {
  const e = lt({
    find: (t) => {
      var r, i;
      const s = [];
      for (const l of t.matchAll(Vb))
        od(t, l, n.isAllowedHref) && s.push(ld(l));
      const o = (
        (r =
          (i = n.findPlainUrls) === null || i === void 0
            ? void 0
            : i.call(n, t)) !== null && r !== void 0
          ? r
          : []
      ).filter((l) => !s.some((a) => Hb(a, l)));
      return [...s, ...o];
    },
    type: n.type,
    getAttributes: ad,
  });
  return new Bu({
    find: e.find,
    handler: (t) => {
      var r;
      const i = e.handler(t);
      return (
        i !== null &&
          t.state.tr.steps.length &&
          !((r = t.match.data) === null || r === void 0) &&
          r.markdown &&
          t.state.tr.setMeta("preventAutolink", !0),
        i
      );
    },
  });
}
function qb(n) {
  return new V({
    key: new K("handlePasteLink"),
    props: {
      handlePaste: (e, t, r) => {
        const { shouldAutoLink: i } = n,
          { state: s } = e,
          { selection: o } = s,
          { empty: l } = o;
        if (l) return !1;
        let a = "";
        r.content.forEach((u) => {
          a += u.textContent;
        });
        const c = id(a, { defaultProtocol: n.defaultProtocol }).find(
          (u) => u.isLink && u.value === a,
        );
        return !a || !c || (i !== void 0 && !i(c.value))
          ? !1
          : n.editor.commands.setMark(n.type, { href: c.href });
      },
    },
  });
}
function Pe(n, e) {
  const t = [
    "http",
    "https",
    "ftp",
    "ftps",
    "mailto",
    "tel",
    "callto",
    "sms",
    "cid",
    "xmpp",
  ];
  return (
    e &&
      e.forEach((r) => {
        const i = typeof r == "string" ? r : r.scheme;
        i && t.push(i);
      }),
    !n ||
      n
        .replace(Lb, "")
        .match(
          new RegExp(
            `^(?:(?:${t.map((r) => r.replace(/[-/\\^$*+?.()|[\]{}]/g, "\\$&")).join("|")}):|[^a-z]|[a-z0-9+.\\-]+(?:[^a-z+.\\-:]|$))`,
            "i",
          ),
        )
  );
}
const Ub = It.create({
    name: "link",
    priority: 1e3,
    keepOnSplit: !1,
    exitable: !0,
    onCreate() {
      (this.options.validate &&
        !this.options.shouldAutoLink &&
        ((this.options.shouldAutoLink = this.options.validate),
        console.warn(
          "The `validate` option is deprecated. Rename to the `shouldAutoLink` option instead.",
        )),
        this.options.protocols.forEach((n) => {
          if (typeof n == "string") {
            sa(n);
            return;
          }
          sa(n.scheme, n.optionalSlashes);
        }));
    },
    onDestroy() {
      Ob();
    },
    inclusive() {
      return this.options.autolink;
    },
    addOptions() {
      return {
        openOnClick: !0,
        enableClickSelection: !1,
        linkOnPaste: !0,
        markdownLinks: !1,
        autolink: !0,
        protocols: [],
        defaultProtocol: "http",
        HTMLAttributes: {
          target: "_blank",
          rel: "noopener noreferrer nofollow",
          class: null,
        },
        isAllowedUri: (n, e) => !!Pe(n, e.protocols),
        validate: (n) => !!n,
        shouldAutoLink: (n) => {
          const e = /^[a-z][a-z0-9+.-]*:\/\//i.test(n),
            t = /^[a-z][a-z0-9+.-]*:/i.test(n);
          if (e || (t && !n.includes("@"))) return !0;
          const r = (n.includes("@") ? n.split("@").pop() : n).split(
            /[/?#:]/,
          )[0];
          return !(/^\d{1,3}(\.\d{1,3}){3}$/.test(r) || !/\./.test(r));
        },
      };
    },
    addAttributes() {
      var n, e, t;
      return {
        href: {
          default: null,
          parseHTML(r) {
            return r.getAttribute("href");
          },
        },
        target: {
          default:
            (n = this.options.HTMLAttributes.target) !== null && n !== void 0
              ? n
              : null,
        },
        rel: {
          default:
            (e = this.options.HTMLAttributes.rel) !== null && e !== void 0
              ? e
              : null,
        },
        class: {
          default:
            (t = this.options.HTMLAttributes.class) !== null && t !== void 0
              ? t
              : null,
        },
        title: { default: null },
      };
    },
    parseHTML() {
      return [
        {
          tag: "a[href]",
          getAttrs: (n) => {
            const e = n.getAttribute("href");
            return !e ||
              !this.options.isAllowedUri(e, {
                defaultValidate: (t) => !!Pe(t, this.options.protocols),
                protocols: this.options.protocols,
                defaultProtocol: this.options.defaultProtocol,
              })
              ? !1
              : null;
          },
        },
      ];
    },
    renderHTML({ HTMLAttributes: n }) {
      return this.options.isAllowedUri(n.href, {
        defaultValidate: (e) => !!Pe(e, this.options.protocols),
        protocols: this.options.protocols,
        defaultProtocol: this.options.defaultProtocol,
      })
        ? ["a", X(this.options.HTMLAttributes, n), 0]
        : ["a", X(this.options.HTMLAttributes, { ...n, href: "" }), 0];
    },
    markdownTokenName: "link",
    parseMarkdown: (n, e) =>
      e.applyMark("link", e.parseInline(n.tokens || []), {
        href: n.href,
        title: n.title || null,
      }),
    renderMarkdown: (n, e) => {
      var t, r, i, s;
      const o =
          (t = (r = n.attrs) === null || r === void 0 ? void 0 : r.href) !==
            null && t !== void 0
            ? t
            : "",
        l =
          (i = (s = n.attrs) === null || s === void 0 ? void 0 : s.title) !==
            null && i !== void 0
            ? i
            : "",
        a = e.renderChildren(n);
      return l ? `[${a}](${o} "${l}")` : `[${a}](${o})`;
    },
    addCommands() {
      return {
        setLink:
          (n) =>
          ({ chain: e }) => {
            const { href: t } = n;
            return this.options.isAllowedUri(t, {
              defaultValidate: (r) => !!Pe(r, this.options.protocols),
              protocols: this.options.protocols,
              defaultProtocol: this.options.defaultProtocol,
            })
              ? e().setMark(this.name, n).setMeta("preventAutolink", !0).run()
              : !1;
          },
        toggleLink:
          (n) =>
          ({ chain: e }) => {
            const { href: t } = n || {};
            return t &&
              !this.options.isAllowedUri(t, {
                defaultValidate: (r) => !!Pe(r, this.options.protocols),
                protocols: this.options.protocols,
                defaultProtocol: this.options.defaultProtocol,
              })
              ? !1
              : e()
                  .toggleMark(this.name, n, { extendEmptyMarkRange: !0 })
                  .setMeta("preventAutolink", !0)
                  .run();
          },
        unsetLink:
          () =>
          ({ chain: n }) =>
            n()
              .unsetMark(this.name, { extendEmptyMarkRange: !0 })
              .setMeta("preventAutolink", !0)
              .run(),
      };
    },
    addInputRules() {
      return this.options.markdownLinks
        ? [
            _b({
              type: this.type,
              isAllowedHref: (n) =>
                this.options.isAllowedUri(n, {
                  defaultValidate: (e) => !!Pe(e, this.options.protocols),
                  protocols: this.options.protocols,
                  defaultProtocol: this.options.defaultProtocol,
                }),
            }),
          ]
        : [];
    },
    addPasteRules() {
      const n = (e) => {
        const t = [];
        if (e) {
          const { protocols: r, defaultProtocol: i } = this.options;
          id(e, { defaultProtocol: i })
            .filter(
              (s) =>
                s.isLink &&
                this.options.isAllowedUri(s.value, {
                  defaultValidate: (o) => !!Pe(o, r),
                  protocols: r,
                  defaultProtocol: i,
                }),
            )
            .forEach((s) => {
              this.options.shouldAutoLink(s.value) &&
                t.push({
                  text: s.value,
                  data: { href: s.href },
                  index: s.start,
                });
            });
        }
        return t;
      };
      return this.options.markdownLinks
        ? [
            Wb({
              type: this.type,
              isAllowedHref: (e) =>
                this.options.isAllowedUri(e, {
                  defaultValidate: (t) => !!Pe(t, this.options.protocols),
                  protocols: this.options.protocols,
                  defaultProtocol: this.options.defaultProtocol,
                }),
              findPlainUrls: n,
            }),
          ]
        : [
            lt({
              find: n,
              type: this.type,
              getAttributes: (e) => {
                var t;
                return {
                  href: (t = e.data) === null || t === void 0 ? void 0 : t.href,
                };
              },
            }),
          ];
    },
    addProseMirrorPlugins() {
      const n = [],
        { protocols: e, defaultProtocol: t } = this.options;
      return (
        this.options.autolink &&
          n.push(
            $b({
              type: this.type,
              defaultProtocol: this.options.defaultProtocol,
              validate: (r) =>
                this.options.isAllowedUri(r, {
                  defaultValidate: (i) => !!Pe(i, e),
                  protocols: e,
                  defaultProtocol: t,
                }),
              shouldAutoLink: this.options.shouldAutoLink,
            }),
          ),
        n.push(
          zb({
            type: this.type,
            editor: this.editor,
            openOnClick:
              this.options.openOnClick === "whenNotEditable"
                ? !0
                : this.options.openOnClick,
            enableClickSelection: this.options.enableClickSelection,
          }),
        ),
        this.options.linkOnPaste &&
          n.push(
            qb({
              editor: this.editor,
              defaultProtocol: this.options.defaultProtocol,
              type: this.type,
              shouldAutoLink: this.options.shouldAutoLink,
            }),
          ),
        n
      );
    },
  }),
  Kb = "listItem",
  oa = "textStyle",
  la = /^\s*([-+*])\s$/,
  cd = ke.create({
    name: "bulletList",
    addOptions() {
      return {
        itemTypeName: "listItem",
        HTMLAttributes: {},
        keepMarks: !1,
        keepAttributes: !1,
      };
    },
    group: "block list",
    content() {
      return `${this.options.itemTypeName}+`;
    },
    parseHTML() {
      return [{ tag: "ul" }];
    },
    renderHTML({ HTMLAttributes: n }) {
      return ["ul", X(this.options.HTMLAttributes, n), 0];
    },
    markdownTokenName: "list",
    parseMarkdown: (n, e) =>
      n.type !== "list" || n.ordered
        ? []
        : {
            type: "bulletList",
            content: n.items ? e.parseChildren(n.items) : [],
          },
    renderMarkdown: (n, e) =>
      n.content
        ? e.renderChildren(
            n.content,
            `
`,
          )
        : "",
    markdownOptions: { indentsContent: !0 },
    addCommands() {
      return {
        toggleBulletList:
          () =>
          ({ commands: n, chain: e }) =>
            this.options.keepAttributes
              ? e()
                  .toggleList(
                    this.name,
                    this.options.itemTypeName,
                    this.options.keepMarks,
                  )
                  .updateAttributes(Kb, this.editor.getAttributes(oa))
                  .run()
              : n.toggleList(
                  this.name,
                  this.options.itemTypeName,
                  this.options.keepMarks,
                ),
      };
    },
    addKeyboardShortcuts() {
      return { "Mod-Shift-8": () => this.editor.commands.toggleBulletList() };
    },
    addInputRules() {
      let n = tn({ find: la, type: this.type });
      return (
        (this.options.keepMarks || this.options.keepAttributes) &&
          (n = tn({
            find: la,
            type: this.type,
            keepMarks: this.options.keepMarks,
            keepAttributes: this.options.keepAttributes,
            getAttributes: () => this.editor.getAttributes(oa),
            editor: this.editor,
          })),
        [n]
      );
    },
  }),
  Jb = (n, e, t) => {
    const { selection: r } = n;
    if (!r.empty) return null;
    const { $from: i } = r;
    if (!i.parent.isTextblock || i.parentOffset !== i.parent.content.size)
      return null;
    let s = -1;
    for (let h = i.depth; h > 0; h -= 1)
      if (i.node(h).type.name === e) {
        s = h;
        break;
      }
    if (s < 0) return null;
    const o = i.node(s),
      l = i.index(s);
    if (l + 1 >= o.childCount) return null;
    const a = o.child(l + 1);
    if (!t.includes(a.type.name)) return null;
    const c = n.schema.nodes[e];
    let u = !1;
    if (
      (a.forEach((h) => {
        h.type === c && h.childCount > 1 && (u = !0);
      }),
      !u)
    )
      return null;
    const d = n.doc.resolve(i.after()).nodeAfter;
    if (!d || !t.includes(d.type.name)) return null;
    const f = [];
    return (
      d.forEach((h) => {
        f.push(h);
      }),
      f.length === 0
        ? null
        : {
            listItemDepth: s,
            nestedList: d,
            nestedListPos: i.after(),
            insertPos: i.after(s),
            items: f,
          }
    );
  },
  Gb = (n, e, t, r) => {
    const i = Jb(n, t, r);
    if (!i) return !1;
    const { selection: s } = n,
      { nestedList: o, nestedListPos: l, insertPos: a, items: c } = i,
      u = n.tr;
    u.delete(l, l + o.nodeSize);
    const d = u.mapping.map(a);
    return (
      u.insert(d, b.from(c)),
      u.setSelection(s.map(u.doc, u.mapping)),
      e && e(u),
      !0
    );
  },
  Yb = (n, e, t) => Gb(n.state, n.view.dispatch, e, t),
  ud = (n, e) =>
    q.create({
      name: `${n}BranchingDeleteKeymap`,
      priority: 101,
      addKeyboardShortcuts() {
        const t = () => Yb(this.editor, n, e);
        return { Delete: t, "Mod-Delete": t };
      },
    }),
  dd = [
    [1e3, "m"],
    [900, "cm"],
    [500, "d"],
    [400, "cd"],
    [100, "c"],
    [90, "xc"],
    [50, "l"],
    [40, "xl"],
    [10, "x"],
    [9, "ix"],
    [5, "v"],
    [4, "iv"],
    [1, "i"],
  ],
  sr = "abcdefghijklmnopqrstuvwxyz",
  fd = String.raw`\d+|[ivxlcdmIVXLCDM]+|${"[a-zA-Z]{1,2}"}`;
function xi(n) {
  let e = n,
    t = "";
  for (const [r, i] of dd) for (; e >= r;) ((t += i), (e -= r));
  return t;
}
function po(n) {
  return xi(n).toUpperCase();
}
function hd(n) {
  const e = n.toLowerCase();
  let t = 0,
    r = 0;
  for (; t < e.length;) {
    let i = !1;
    for (const [s, o] of dd)
      if (e.startsWith(o, t)) {
        ((r += s), (t += o.length), (i = !0));
        break;
      }
    if (!i) return 0;
  }
  return r;
}
function Xb(n) {
  if (!/^[ivxlcdmIVXLCDM]+$/.test(n)) return !1;
  const e = hd(n);
  return e <= 0 ? !1 : (n === n.toLowerCase() ? xi(e) : po(e)) === n;
}
function Qb(n) {
  const e = n.toLowerCase();
  if (e.length === 1) return e.charCodeAt(0) - 97 + 1;
  if (e.length === 2) {
    const t = e.charCodeAt(0) - 97,
      r = e.charCodeAt(1) - 97;
    return (t + 1) * 26 + r + 1;
  }
  return 0;
}
function ii(n) {
  if (n <= 26) return sr[n - 1];
  const e = Math.floor((n - 1) / 26) - 1,
    t = (n - 1) % 26;
  return e < 0 ? sr[t] : sr[e] + sr[t];
}
function wi(n) {
  if (!(!n || /^\d+$/.test(n))) {
    if (Xb(n)) return n === n.toLowerCase() ? "i" : "I";
    if (/^[a-z]{1,2}$/.test(n)) return "a";
    if (/^[A-Z]{1,2}$/.test(n)) return "A";
  }
}
function mo(n) {
  if (/^\d+$/.test(n)) return parseInt(n, 10);
  const e = wi(n);
  if (e === "i" || e === "I") return hd(n);
  if (e === "a" || e === "A") {
    const r = Qb(n);
    return r > 0 ? r : 1;
  }
  const t = parseInt(n, 10);
  return Number.isNaN(t) ? 1 : t;
}
function Zb(n, e) {
  if (n === "numeric") return String(e);
  switch (n) {
    case "a":
      return ii(e);
    case "A":
      return ii(e).toUpperCase();
    case "i":
      return xi(e);
    case "I":
      return po(e);
    default:
      return String(e);
  }
}
function ek(n) {
  var e;
  if (n.length === 0) return !1;
  const t = (e = wi(n[0])) !== null && e !== void 0 ? e : "numeric",
    r = mo(n[0]);
  if (r < 1) return !1;
  for (let i = 0; i < n.length; i++) {
    const s = Zb(t, r + i);
    if (n[i] !== s) return !1;
  }
  return !0;
}
function tk(n) {
  return { type: wi(n), start: mo(n) };
}
function nk(n) {
  const { type: e, start: t } = tk(n),
    r = {};
  return (e && (r.type = e), t !== 1 && (r.start = t), r);
}
function rk(n, e, t = ". ") {
  const r = e + 1;
  if (!n || n === "1") return `${r}${t}`;
  switch (n) {
    case "a":
      return `${ii(r)}${t}`;
    case "A":
      return `${ii(r).toUpperCase()}${t}`;
    case "i":
      return `${xi(r)}${t}`;
    case "I":
      return `${po(r)}${t}`;
    default:
      return `${r}${t}`;
  }
}
function ik(n) {
  return !n[0] || n[0].type === "paragraph"
    ? n
    : [{ type: "paragraph", content: [] }, ...n];
}
function sk(n) {
  var e, t;
  const r = (e = n.content) === null || e === void 0 ? void 0 : e[0];
  return (
    r?.type === "paragraph" &&
    !(!((t = r.content) === null || t === void 0) && t.length)
  );
}
const ok = "&nbsp;",
  aa = 1,
  lk = (n) => {
    var e;
    return ((e = n?.level) !== null && e !== void 0 ? e : aa) > aa;
  };
function ak(n) {
  var e, t;
  const r = (e = n.tokens) === null || e === void 0 ? void 0 : e[0];
  return !!(
    n.text &&
    ((t = n.tokens) === null || t === void 0 ? void 0 : t.length) === 1 &&
    r?.type === "list" &&
    r.ordered &&
    r.raw === n.text
  );
}
function ck(n, e) {
  return e.tokenizeInline
    ? e.parseInline(e.tokenizeInline(n))
    : e.parseInline([{ type: "text", raw: n, text: n }]);
}
const pd = ke.create({
    name: "listItem",
    addOptions() {
      return {
        HTMLAttributes: {},
        bulletListTypeName: "bulletList",
        orderedListTypeName: "orderedList",
      };
    },
    content: "paragraph block*",
    defining: !0,
    parseHTML() {
      return [{ tag: "li" }];
    },
    renderHTML({ HTMLAttributes: n }) {
      return ["li", X(this.options.HTMLAttributes, n), 0];
    },
    markdownTokenName: "list_item",
    parseMarkdown: (n, e) => {
      var t;
      if (n.type !== "list_item") return [];
      const r =
        (t = e.parseBlockChildren) !== null && t !== void 0
          ? t
          : e.parseChildren;
      let i = [];
      if (n.tokens && n.tokens.length > 0) {
        if (ak(n))
          return {
            type: "listItem",
            content: [{ type: "paragraph", content: ck(n.text || "", e) }],
          };
        const [o, ...l] = n.tokens;
        if (o.type === "heading") {
          var s;
          return {
            type: "listItem",
            content: [
              {
                type: "paragraph",
                content: e.parseInline(
                  (s = o.tokens) !== null && s !== void 0 ? s : [],
                ),
              },
              ...(l.length > 0 ? r(l) : []),
            ],
          };
        }
        if (n.tokens.some((a) => a.type === "paragraph")) i = r(n.tokens);
        else if (o.type === "text" && o.tokens && o.tokens.length > 0) {
          if (
            ((i = [{ type: "paragraph", content: e.parseInline(o.tokens) }]),
            n.tokens.length > 1)
          ) {
            const a = r(n.tokens.slice(1));
            i.push(...a);
          }
        } else i = r(n.tokens);
      }
      return (
        i.length === 0 && (i = [{ type: "paragraph", content: [] }]),
        { type: "listItem", content: ik(i) }
      );
    },
    renderMarkdown: (n, e, t) => {
      const r = (o) => {
          if (o.parentType === "bulletList") return "- ";
          if (o.parentType === "orderedList") {
            var l, a;
            const c =
              ((l = o.meta) === null ||
              l === void 0 ||
              (l = l.parentAttrs) === null ||
              l === void 0
                ? void 0
                : l.start) || 1;
            return rk(
              (a = o.meta) === null ||
                a === void 0 ||
                (a = a.parentAttrs) === null ||
                a === void 0
                ? void 0
                : a.type,
              c - 1 + (o.index || 0),
              ". ",
            );
          }
          return "- ";
        },
        i = Iu(n, e, r, t, {
          alignNestedToPrefix: t?.parentType === "orderedList",
        });
      if (!sk(n) || !lk(t)) return i;
      const s = r(t);
      return `${s}${ok}${i.slice(s.length)}`;
    },
    addExtensions() {
      return [
        ud(this.name, [
          this.options.bulletListTypeName,
          this.options.orderedListTypeName,
        ]),
      ];
    },
    addKeyboardShortcuts() {
      return {
        Enter: () => this.editor.commands.splitListItem(this.name),
        Tab: () => this.editor.commands.sinkListItem(this.name),
        "Shift-Tab": () => this.editor.commands.liftListItem(this.name),
      };
    },
  }),
  go = (n, e) => {
    const { $from: t } = e.selection,
      r = Y(n, e.schema);
    let i = null,
      s = t.depth,
      o = t.pos,
      l = null;
    for (; s > 0 && l === null;)
      ((i = t.node(s)), i.type === r ? (l = s) : ((s -= 1), (o -= 1)));
    return l === null ? null : { $pos: e.doc.resolve(o), depth: l };
  },
  md = (n, e) => {
    const t = go(n, e);
    if (!t) return !1;
    const [, r] = sg(e, n, t.$pos.pos + 4);
    return r;
  },
  uk = (n, e, t) => {
    const { $anchor: r } = n.selection,
      i = Math.max(0, r.pos - 2),
      s = n.doc.resolve(i).node();
    return !(!s || !t.includes(s.type.name));
  },
  ca = (n, e, t) => {
    if (n.commands.undoInputRule()) return !0;
    if (n.state.selection.from !== n.state.selection.to) return !1;
    if (!We(n.state, e) && uk(n.state, e, t)) {
      const { $anchor: s } = n.state.selection,
        o = n.state.doc.resolve(s.before() - 1),
        l = [];
      o.node().descendants((u, d) => {
        u.type.name === e && l.push({ node: u, pos: d });
      });
      const a = l.at(-1);
      if (!a) return !1;
      const c = n.state.doc.resolve(o.start() + a.pos + 1);
      return n
        .chain()
        .command(({ tr: u }) => {
          const d = c.end();
          return (
            u.delete(s.before(), s.after()).insert(d, s.parent),
            u.setSelection(T.create(u.doc, d + 1)),
            !0
          );
        })
        .command(({ state: u, dispatch: d }) => (ic(u, d), !0))
        .run();
    }
    if (!We(n.state, e) || !ug(n.state)) return !1;
    const { $from: r } = n.state.selection,
      i = r.depth - 1;
    return r.node(i).type !== n.schema.nodes[e] || r.index(i) !== 0
      ? !1
      : n.chain().liftListItem(e).run();
  },
  dk = (n, e) => {
    const t = md(n, e),
      r = go(n, e);
    return !r || !t ? !1 : t > r.depth;
  },
  fk = (n, e) => {
    const t = md(n, e),
      r = go(n, e);
    return !r || !t ? !1 : t < r.depth;
  },
  ua = (n, e) =>
    !We(n.state, e) || !cg(n.state, e) || !n.state.selection.empty
      ? !1
      : dk(e, n.state)
        ? n
            .chain()
            .focus(n.state.selection.from + 4)
            .lift(e)
            .joinBackward()
            .run()
        : fk(e, n.state)
          ? n.commands.command(({ state: t, dispatch: r }) => sc(t, r))
          : n.commands.joinItemForward(),
  hk = (n, e, t) => {
    const { state: r } = n,
      { selection: i } = r;
    if (!i.empty) return !1;
    const { $from: s } = i;
    if (s.parentOffset !== 0 || !s.parent.isTextblock || We(r, e)) return !1;
    const o = og(s);
    if (!o || !t.includes(o.type.name)) return !1;
    const l = o.lastChild;
    if (!l || l.type.name !== e) return !1;
    const a = s.parent;
    if (!l.canReplace(l.childCount, l.childCount, b.from(a))) return !1;
    const c = s.before(),
      u = s.after(),
      d = c - 2;
    return n.commands.command(
      ({ tr: f, dispatch: h }) => (
        h &&
          (f.delete(c, u).insert(d, b.from(a)),
          f.setSelection(T.create(f.doc, d + 1)),
          f.scrollIntoView()),
        !0
      ),
    );
  },
  gd = q.create({
    name: "listKeymap",
    addOptions() {
      return {
        listTypes: [
          { itemName: "listItem", wrapperNames: ["bulletList", "orderedList"] },
          { itemName: "taskItem", wrapperNames: ["taskList"] },
        ],
      };
    },
    addKeyboardShortcuts() {
      return {
        Delete: ({ editor: n }) => {
          let e = !1;
          return (
            this.options.listTypes.forEach(({ itemName: t }) => {
              n.state.schema.nodes[t] !== void 0 && ua(n, t) && (e = !0);
            }),
            e
          );
        },
        "Mod-Delete": ({ editor: n }) => {
          let e = !1;
          return (
            this.options.listTypes.forEach(({ itemName: t }) => {
              n.state.schema.nodes[t] !== void 0 && ua(n, t) && (e = !0);
            }),
            e
          );
        },
        Backspace: ({ editor: n }) => {
          let e = !1;
          return (
            this.options.listTypes.forEach(
              ({ itemName: t, wrapperNames: r }) => {
                n.state.schema.nodes[t] !== void 0 && ca(n, t, r) && (e = !0);
              },
            ),
            e
          );
        },
        "Mod-Backspace": ({ editor: n }) => {
          let e = !1;
          return (
            this.options.listTypes.forEach(
              ({ itemName: t, wrapperNames: r }) => {
                n.state.schema.nodes[t] !== void 0 && ca(n, t, r) && (e = !0);
              },
            ),
            e
          );
        },
        Tab: ({ editor: n }) => {
          for (const { itemName: e, wrapperNames: t } of this.options.listTypes)
            if (n.state.schema.nodes[e] !== void 0 && hk(n, e, t)) return !0;
          return !1;
        },
      };
    },
  }),
  si = new RegExp(`^(\\s*)(${fd})([.)])\\s+(.*)$`),
  pk = /^\s/,
  qt = {
    heading: /^#{1,6}(?:\s|$)/,
    bulletItem: /^[-+*]\s+/,
    codeFence: /^(?:```|~~~)/,
    blockMath: /^\$\$/,
    thematicBreak: /^(?:(?:-[ \t]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})$/,
  };
function mk(n) {
  return si.test(n.trimStart());
}
function gk(n) {
  const e = n.trimStart();
  return (
    qt.bulletItem.test(e) ||
    mk(e) ||
    qt.heading.test(e) ||
    (qt.thematicBreak.test(e) && !e.startsWith("-")) ||
    /^>\s?/.test(e) ||
    qt.codeFence.test(e) ||
    qt.blockMath.test(e)
  );
}
function yk(n) {
  return Object.values(qt).some((e) => e.test(n));
}
function bk(n) {
  const e = [],
    t = [];
  let r = !1;
  return (
    n.forEach((i) => {
      if (r) {
        t.push(i);
        return;
      }
      if (i.trim() === "") {
        ((r = !0), t.push(i));
        return;
      }
      if (e.length > 0 && gk(i)) {
        ((r = !0), t.push(i));
        return;
      }
      e.push(i);
    }),
    { paragraphLines: e, blockLines: t }
  );
}
function da(n) {
  const e = [];
  let t = 0,
    r = 0;
  for (; t < n.length;) {
    const i = n[t],
      s = i.match(si);
    if (!s) break;
    const [, o, l, a, c] = s,
      u = o.length,
      d = parseInt(l, 10),
      f = isNaN(d) ? wi(l) : void 0,
      h = isNaN(d) ? mo(l) : d,
      p = [c];
    let g = t + 1;
    const m = [i];
    let y = !1;
    for (; g < n.length;) {
      const k = n[g];
      if (k.match(si)) break;
      if (k.trim() === "") (m.push(k), p.push(""), (y = !0), (g += 1));
      else if (k.match(pk)) {
        const x = k.length - k.trimStart().length,
          w = u + l.length + 1;
        (m.push(k), p.push(k.slice(Math.min(x, w))), (g += 1));
      } else {
        if (y || yk(k)) break;
        (m.push(k), p.push(k), (g += 1));
      }
    }
    (e.push({
      indent: u,
      number: h,
      type: f,
      content: p
        .join(
          `
`,
        )
        .trim(),
      contentLines: p,
      raw: m.join(`
`),
    }),
      (r = g),
      (t = g));
  }
  return [e, r];
}
const kk = new RegExp(`^(${fd})([.)])\\s+(.+)$`);
function Sk(n) {
  const e = n
    .split(
      `
`,
    )
    .filter((r) => r.trim().length > 0);
  if (e.length === 0) return null;
  const t = [];
  for (const r of e) {
    const i = r.trim().match(kk);
    if (!i) return null;
    t.push({ marker: i[1], content: i[3] });
  }
  return ek(t.map((r) => r.marker))
    ? {
        type: "orderedList",
        attrs: nk(t[0].marker),
        content: t.map((r) => ({
          type: "listItem",
          content: [
            { type: "paragraph", content: [{ type: "text", text: r.content }] },
          ],
        })),
      }
    : null;
}
function yd(n, e, t) {
  const r = [];
  let i = 0;
  for (; i < n.length;) {
    const s = n[i];
    if (s.indent === e) {
      const { paragraphLines: o, blockLines: l } = bk(s.contentLines),
        a = o
          .join(
            `
`,
          )
          .trim(),
        c = [];
      a && c.push({ type: "paragraph", raw: a, tokens: t.inlineTokens(a) });
      const u = l
        .join(
          `
`,
        )
        .trim();
      if (u) {
        const h = t.blockTokens(u);
        c.push(...h);
      }
      let d = i + 1;
      const f = [];
      for (; d < n.length && n[d].indent > e;) (f.push(n[d]), (d += 1));
      if (f.length > 0) {
        const h = yd(f, Math.min(...f.map((p) => p.indent)), t);
        c.push({
          type: "list",
          ordered: !0,
          start: f[0].number,
          typeMarker: f[0].type,
          items: h,
          raw: f.map((p) => p.raw).join(`
`),
        });
      }
      (r.push({ type: "list_item", raw: s.raw, tokens: c }), (i = d));
    } else i += 1;
  }
  return r;
}
function xk(n, e) {
  return n.map((t) => {
    if (t.type !== "list_item") return e.parseChildren([t])[0];
    const r = [];
    return (
      t.tokens &&
        t.tokens.length > 0 &&
        t.tokens.forEach((i) => {
          if (
            i.type === "paragraph" ||
            i.type === "list" ||
            i.type === "blockquote" ||
            i.type === "code"
          )
            r.push(...e.parseChildren([i]));
          else if (i.type === "text" && i.tokens) {
            const s = e.parseChildren([i]);
            r.push({ type: "paragraph", content: s });
          } else {
            const s = e.parseChildren([i]);
            s.length > 0 && r.push(...s);
          }
        }),
      { type: "listItem", content: r }
    );
  });
}
const wk = 64;
function fa(n, e) {
  const t = [];
  let r = 0;
  for (; t.length < e;) {
    const i = n.indexOf(
      `
`,
      r,
    );
    if (i === -1) return (t.push(n.slice(r)), t);
    (t.push(n.slice(r, i)), (r = i + 1));
  }
  return t;
}
function Ck(n) {
  const e = n.indexOf(`
`),
    t = e === -1 ? n : n.slice(0, e);
  if (!si.test(t)) return [[], 0, []];
  let r = wk,
    i = fa(n, r),
    s = da(i);
  for (; s[1] === i.length && i.length === r;)
    ((r *= 2), (i = fa(n, r)), (s = da(i)));
  return [s[0], s[1], i];
}
const vk = "listItem",
  ha = "textStyle",
  pa = /^(\d+)\.\s$/;
function ma(n) {
  const e = n.match(/list-style-type\s*:\s*([^;]+)/i);
  if (!e) return null;
  switch (e[1].trim().toLowerCase()) {
    case "upper-roman":
      return "I";
    case "lower-roman":
      return "i";
    case "upper-alpha":
    case "upper-latin":
      return "A";
    case "lower-alpha":
    case "lower-latin":
      return "a";
    default:
      return null;
  }
}
const bd = ke.create({
    name: "orderedList",
    addOptions() {
      return {
        itemTypeName: "listItem",
        HTMLAttributes: {},
        keepMarks: !1,
        keepAttributes: !1,
      };
    },
    group: "block list",
    content() {
      return `${this.options.itemTypeName}+`;
    },
    addAttributes() {
      return {
        start: {
          default: 1,
          parseHTML: (n) =>
            n.hasAttribute("start")
              ? parseInt(n.getAttribute("start") || "", 10)
              : 1,
        },
        type: {
          default: null,
          parseHTML: (n) => {
            const e = n.getAttribute("type");
            if (e) return e;
            const t = n.getAttribute("style");
            if (t) {
              const i = ma(t);
              if (i) return i;
            }
            const r = n.querySelector("li");
            if (r) {
              const i = r.getAttribute("style");
              if (i) {
                const s = ma(i);
                if (s) return s;
              }
            }
            return null;
          },
        },
      };
    },
    parseHTML() {
      return [{ tag: "ol" }];
    },
    renderHTML({ HTMLAttributes: n }) {
      const { start: e, type: t, ...r } = n,
        i = X(this.options.HTMLAttributes, r);
      return (
        e !== 1 && (i.start = e),
        t && t !== "1" && (i.type = t),
        ["ol", i, 0]
      );
    },
    markdownTokenName: "list",
    parseMarkdown: (n, e) => {
      if (n.type !== "list" || !n.ordered) return [];
      const t = n.start || 1,
        r = n.typeMarker,
        i = n.items ? xk(n.items, e) : [],
        s = {};
      return (
        t !== 1 && (s.start = t),
        r && (s.type = r),
        Object.keys(s).length > 0
          ? { type: "orderedList", attrs: s, content: i }
          : { type: "orderedList", content: i }
      );
    },
    renderMarkdown: (n, e) =>
      n.content
        ? e.renderChildren(
            n.content,
            `
`,
          )
        : "",
    markdownTokenizer: {
      name: "orderedList",
      level: "block",
      start: () => -1,
      tokenize: (n, e, t) => {
        var r, i;
        const [s, o, l] = Ck(n);
        if (s.length === 0) return;
        const a = yd(s, s[0].indent, t);
        if (a.length !== 0)
          return {
            type: "list",
            ordered: !0,
            start:
              ((r = s[0]) === null || r === void 0 ? void 0 : r.number) || 1,
            typeMarker: (i = s[0]) === null || i === void 0 ? void 0 : i.type,
            items: a,
            raw: l.slice(0, o).join(`
`),
          };
      },
    },
    markdownOptions: { indentsContent: !0 },
    addCommands() {
      return {
        toggleOrderedList:
          () =>
          ({ commands: n, chain: e }) =>
            this.options.keepAttributes
              ? e()
                  .toggleList(
                    this.name,
                    this.options.itemTypeName,
                    this.options.keepMarks,
                  )
                  .updateAttributes(vk, this.editor.getAttributes(ha))
                  .run()
              : n.toggleList(
                  this.name,
                  this.options.itemTypeName,
                  this.options.keepMarks,
                ),
      };
    },
    addKeyboardShortcuts() {
      return { "Mod-Shift-7": () => this.editor.commands.toggleOrderedList() };
    },
    addProseMirrorPlugins() {
      return [
        new V({
          props: {
            handlePaste: (n, e) => {
              var t, r;
              const i =
                (t = e.clipboardData) === null || t === void 0
                  ? void 0
                  : t.getData("text/html");
              if (i?.trim()) return !1;
              const s =
                (r = e.clipboardData) === null || r === void 0
                  ? void 0
                  : r.getData("text/plain");
              if (!s) return !1;
              const o = Sk(s);
              if (!o) return !1;
              try {
                const l = n.state.schema.nodeFromJSON(o),
                  a = n.state.tr.replaceSelectionWith(l);
                return (n.dispatch(a), !0);
              } catch {
                return !1;
              }
            },
          },
        }),
      ];
    },
    addInputRules() {
      const n = (t, r) =>
        (!r.attrs.type || r.attrs.type === "1") &&
        r.childCount + r.attrs.start === +t[1];
      let e = tn({
        find: pa,
        type: this.type,
        getAttributes: (t) => ({ start: +t[1] }),
        joinPredicate: n,
      });
      return (
        (this.options.keepMarks || this.options.keepAttributes) &&
          (e = tn({
            find: pa,
            type: this.type,
            keepMarks: this.options.keepMarks,
            keepAttributes: this.options.keepAttributes,
            getAttributes: (t) => ({
              start: +t[1],
              ...this.editor.getAttributes(ha),
            }),
            joinPredicate: n,
            editor: this.editor,
          })),
        [e]
      );
    },
  }),
  Mk = /^\s*(\[([( |x])?\])\s$/,
  Ek =
    "position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0",
  Tk = (n, e, t) => {
    var r;
    return (
      (t == null || (r = t.checkboxLabel) === null || r === void 0
        ? void 0
        : r.call(t, n, e)) ||
      `Task item checkbox for ${n.textContent || "empty task item"}`
    );
  },
  Ak = ke.create({
    name: "taskItem",
    addOptions() {
      return {
        nested: !1,
        HTMLAttributes: {},
        taskListTypeName: "taskList",
        a11y: void 0,
      };
    },
    content() {
      return this.options.nested ? "paragraph block*" : "paragraph+";
    },
    defining: !0,
    addAttributes() {
      return {
        checked: {
          default: !1,
          keepOnSplit: !1,
          parseHTML: (n) => {
            const e = n.getAttribute("data-checked");
            return e === "" || e === "true";
          },
          renderHTML: (n) => ({ "data-checked": n.checked }),
        },
      };
    },
    parseHTML() {
      return [
        {
          tag: `li[data-type="${this.name}"]`,
          priority: 51,
          contentElement: (n) => {
            var e;
            return (e = n.querySelector("div")) !== null && e !== void 0
              ? e
              : n;
          },
        },
      ];
    },
    renderHTML({ node: n, HTMLAttributes: e }) {
      return [
        "li",
        X(this.options.HTMLAttributes, e, { "data-type": this.name }),
        [
          "label",
          [
            "input",
            { type: "checkbox", checked: n.attrs.checked ? "checked" : null },
          ],
          ["span"],
        ],
        ["div", 0],
      ];
    },
    parseMarkdown: (n, e) => {
      const t = [];
      if (
        (n.tokens && n.tokens.length > 0
          ? t.push(e.createNode("paragraph", {}, e.parseInline(n.tokens)))
          : n.text
            ? t.push(
                e.createNode("paragraph", {}, [
                  e.createNode("text", { text: n.text }),
                ]),
              )
            : t.push(e.createNode("paragraph", {}, [])),
        n.nestedTokens && n.nestedTokens.length > 0)
      ) {
        const r = e.parseChildren(n.nestedTokens);
        t.push(...r);
      }
      return e.createNode("taskItem", { checked: n.checked || !1 }, t);
    },
    renderMarkdown: (n, e) => {
      var t;
      const r = `- [${!((t = n.attrs) === null || t === void 0) && t.checked ? "x" : " "}] `;
      return Iu(n, e, r, void 0, { indentMainContent: !0 });
    },
    addExtensions() {
      return this.options.nested
        ? [ud(this.name, [this.options.taskListTypeName])]
        : [];
    },
    addKeyboardShortcuts() {
      const n = {
        Enter: () => this.editor.commands.splitListItem(this.name),
        "Shift-Tab": () => this.editor.commands.liftListItem(this.name),
      };
      return this.options.nested
        ? { ...n, Tab: () => this.editor.commands.sinkListItem(this.name) }
        : n;
    },
    addNodeView() {
      return ({ node: n, HTMLAttributes: e, getPos: t, editor: r }) => {
        const i = document.createElement("li"),
          s = document.createElement("label"),
          o = document.createElement("span"),
          l = document.createElement("input"),
          a = document.createElement("div");
        o.style.cssText = Ek;
        const c = (d) => {
          const f = Tk(d, d.attrs.checked, this.options.a11y);
          (l.setAttribute("aria-label", f), (o.textContent = f));
        };
        (c(n),
          (s.contentEditable = "false"),
          (l.type = "checkbox"),
          l.addEventListener("mousedown", (d) => d.preventDefault()),
          l.addEventListener("change", (d) => {
            if (!r.isEditable && !this.options.onReadOnlyChecked) {
              l.checked = !l.checked;
              return;
            }
            const { checked: f } = d.target;
            (r.isEditable &&
              typeof t == "function" &&
              r
                .chain()
                .focus(void 0, { scrollIntoView: !1 })
                .command(({ tr: h }) => {
                  const p = t();
                  if (typeof p != "number") return !1;
                  const g = h.doc.nodeAt(p);
                  return (
                    h.setNodeMarkup(p, void 0, { ...g?.attrs, checked: f }),
                    !0
                  );
                })
                .run(),
              !r.isEditable &&
                this.options.onReadOnlyChecked &&
                (this.options.onReadOnlyChecked(n, f) ||
                  (l.checked = !l.checked)));
          }),
          Object.entries(this.options.HTMLAttributes).forEach(([d, f]) => {
            i.setAttribute(d, f);
          }),
          (i.dataset.checked = n.attrs.checked),
          (l.checked = n.attrs.checked),
          s.append(l, o),
          i.append(s, a),
          Object.entries(e).forEach(([d, f]) => {
            i.setAttribute(d, f);
          }));
        let u = new Set(Object.keys(e));
        return {
          dom: i,
          contentDOM: a,
          update: (d) => {
            if (d.type !== this.type) return !1;
            ((i.dataset.checked = d.attrs.checked),
              (l.checked = d.attrs.checked),
              c(d));
            const f = r.extensionManager.attributes,
              h = Bn(d, f),
              p = new Set(Object.keys(h)),
              g = this.options.HTMLAttributes;
            return (
              u.forEach((m) => {
                p.has(m) ||
                  (m in g ? i.setAttribute(m, g[m]) : i.removeAttribute(m));
              }),
              Object.entries(h).forEach(([m, y]) => {
                y == null
                  ? m in g
                    ? i.setAttribute(m, g[m])
                    : i.removeAttribute(m)
                  : i.setAttribute(m, y);
              }),
              (u = p),
              !0
            );
          },
        };
      };
    },
    addInputRules() {
      return [
        tn({
          find: Mk,
          type: this.type,
          getAttributes: (n) => ({ checked: n[n.length - 1] === "x" }),
        }),
      ];
    },
  }),
  Ok = ke.create({
    name: "taskList",
    addOptions() {
      return { itemTypeName: "taskItem", HTMLAttributes: {} };
    },
    group: "block list",
    content() {
      return `${this.options.itemTypeName}+`;
    },
    parseHTML() {
      return [{ tag: `ul[data-type="${this.name}"]`, priority: 51 }];
    },
    renderHTML({ HTMLAttributes: n }) {
      return [
        "ul",
        X(this.options.HTMLAttributes, n, { "data-type": this.name }),
        0,
      ];
    },
    parseMarkdown: (n, e) =>
      e.createNode("taskList", {}, e.parseChildren(n.items || [])),
    renderMarkdown: (n, e) =>
      n.content
        ? e.renderChildren(
            n.content,
            `
`,
          )
        : "",
    markdownTokenizer: {
      name: "taskList",
      level: "block",
      start(n) {
        var e;
        const t =
          (e = n.match(/^\s*[-+*]\s+\[([ xX])\]\s+/)) === null || e === void 0
            ? void 0
            : e.index;
        return t !== void 0 ? t : -1;
      },
      tokenize(n, e, t) {
        const r = (s) => {
            const o = _l(
              s,
              {
                itemPattern: /^(\s*)([-+*])\s+\[([ xX])\]\s+(.*)$/,
                extractItemData: (l) => ({
                  indentLevel: l[1].length,
                  mainContent: l[4],
                  checked: l[3].toLowerCase() === "x",
                }),
                createToken: (l, a) => ({
                  type: "taskItem",
                  raw: "",
                  mainContent: l.mainContent,
                  indentLevel: l.indentLevel,
                  checked: l.checked,
                  text: l.mainContent,
                  tokens: t.inlineTokens(l.mainContent),
                  nestedTokens: a,
                }),
                customNestedParser: r,
              },
              t,
            );
            if (o) {
              const l = { type: "taskList", raw: o.raw, items: o.items },
                a = s.slice(o.raw.length);
              return a.trim() ? [l, ...t.blockTokens(a)] : [l];
            }
            return t.blockTokens(s);
          },
          i = _l(
            n,
            {
              itemPattern: /^(\s*)([-+*])\s+\[([ xX])\]\s+(.*)$/,
              extractItemData: (s) => ({
                indentLevel: s[1].length,
                mainContent: s[4],
                checked: s[3].toLowerCase() === "x",
              }),
              createToken: (s, o) => ({
                type: "taskItem",
                raw: "",
                mainContent: s.mainContent,
                indentLevel: s.indentLevel,
                checked: s.checked,
                text: s.mainContent,
                tokens: t.inlineTokens(s.mainContent),
                nestedTokens: o,
              }),
              customNestedParser: r,
            },
            t,
          );
        if (i) return { type: "taskList", raw: i.raw, items: i.items };
      },
    },
    markdownOptions: { indentsContent: !0 },
    addCommands() {
      return {
        toggleTaskList:
          () =>
          ({ commands: n }) =>
            n.toggleList(this.name, this.options.itemTypeName),
      };
    },
    addKeyboardShortcuts() {
      return { "Mod-Shift-9": () => this.editor.commands.toggleTaskList() };
    },
  });
q.create({
  name: "listKit",
  addExtensions() {
    const n = [];
    return (
      this.options.bulletList !== !1 &&
        n.push(cd.configure(this.options.bulletList)),
      this.options.listItem !== !1 &&
        n.push(pd.configure(this.options.listItem)),
      this.options.listKeymap !== !1 &&
        n.push(gd.configure(this.options.listKeymap)),
      this.options.orderedList !== !1 &&
        n.push(bd.configure(this.options.orderedList)),
      this.options.taskItem !== !1 &&
        n.push(Ak.configure(this.options.taskItem)),
      this.options.taskList !== !1 &&
        n.push(Ok.configure(this.options.taskList)),
      n
    );
  },
});
const or = "&nbsp;",
  Gi = " ",
  Nk = ke.create({
    name: "paragraph",
    priority: 1e3,
    addOptions() {
      return { HTMLAttributes: {} };
    },
    group: "block",
    content: "inline*",
    parseHTML() {
      return [{ tag: "p" }];
    },
    renderHTML({ HTMLAttributes: n }) {
      return ["p", X(this.options.HTMLAttributes, n), 0];
    },
    parseMarkdown: (n, e) => {
      const t = n.tokens || [];
      if (t.length === 1 && t[0].type === "image")
        return e.parseChildren([t[0]]);
      const r = e.parseInline(t);
      return t.length === 1 &&
        t[0].type === "text" &&
        (t[0].raw === or ||
          t[0].text === or ||
          t[0].raw === Gi ||
          t[0].text === Gi) &&
        r.length === 1 &&
        r[0].type === "text" &&
        (r[0].text === or || r[0].text === Gi)
        ? e.createNode("paragraph", void 0, [])
        : e.createNode("paragraph", void 0, r);
    },
    renderMarkdown: (n, e, t) => {
      if (!n) return "";
      const r = Array.isArray(n.content) ? n.content : [];
      if (r.length === 0) {
        var i, s;
        const o = Array.isArray(
          t == null || (i = t.previousNode) === null || i === void 0
            ? void 0
            : i.content,
        )
          ? t.previousNode.content
          : [];
        return (t == null || (s = t.previousNode) === null || s === void 0
          ? void 0
          : s.type) === "paragraph" && o.length === 0
          ? or
          : "";
      }
      return e.renderChildren(r);
    },
    addCommands() {
      return {
        setParagraph:
          () =>
          ({ commands: n }) =>
            n.setNode(this.name),
      };
    },
    addKeyboardShortcuts() {
      return { "Mod-Alt-0": () => this.editor.commands.setParagraph() };
    },
  }),
  Dk = /(?:^|\s)(~~(?!\s+~~)((?:[^~]+))~~(?!\s+~~))$/,
  Rk = /(?:^|\s)(~~(?!\s+~~)((?:[^~]+))~~(?!\s+~~))/g,
  Ik = It.create({
    name: "strike",
    addOptions() {
      return { HTMLAttributes: {} };
    },
    parseHTML() {
      return [
        { tag: "s" },
        { tag: "del" },
        { tag: "strike" },
        {
          style: "text-decoration",
          consuming: !1,
          getAttrs: (n) => (n.includes("line-through") ? {} : !1),
        },
      ];
    },
    renderHTML({ HTMLAttributes: n }) {
      return ["s", X(this.options.HTMLAttributes, n), 0];
    },
    markdownTokenName: "del",
    parseMarkdown: (n, e) =>
      e.applyMark("strike", e.parseInline(n.tokens || [])),
    renderMarkdown: (n, e) => `~~${e.renderChildren(n)}~~`,
    addCommands() {
      return {
        setStrike:
          () =>
          ({ commands: n }) =>
            n.setMark(this.name),
        toggleStrike:
          () =>
          ({ commands: n }) =>
            n.toggleMark(this.name),
        unsetStrike:
          () =>
          ({ commands: n }) =>
            n.unsetMark(this.name),
      };
    },
    addKeyboardShortcuts() {
      return { "Mod-Shift-s": () => this.editor.commands.toggleStrike() };
    },
    addInputRules() {
      return [Dt({ find: Dk, type: this.type })];
    },
    addPasteRules() {
      return [lt({ find: Rk, type: this.type })];
    },
  }),
  Lk = ke.create({
    name: "text",
    group: "inline",
    parseMarkdown: (n) => ({ type: "text", text: n.text || "" }),
    renderMarkdown: (n) => n.text || "",
  }),
  Pk = It.create({
    name: "underline",
    addOptions() {
      return { HTMLAttributes: {} };
    },
    parseHTML() {
      return [
        { tag: "u" },
        {
          style: "text-decoration",
          consuming: !1,
          getAttrs: (n) => (n.includes("underline") ? {} : !1),
        },
      ];
    },
    renderHTML({ HTMLAttributes: n }) {
      return ["u", X(this.options.HTMLAttributes, n), 0];
    },
    parseMarkdown(n, e) {
      return e.applyMark(
        this.name || "underline",
        e.parseInline(n.tokens || []),
      );
    },
    renderMarkdown(n, e) {
      return `<u>${e.renderChildren(n)}</u>`;
    },
    markdownTokenizer: {
      name: "underline",
      level: "inline",
      start(n) {
        return n.toLowerCase().indexOf("<u>");
      },
      tokenize(n, e, t) {
        if (!/^<u>/i.test(n)) return;
        const r = /\\[\s\S]|`+|<\/u>/gi;
        r.lastIndex = 3;
        let i = r.exec(n);
        for (; i;) {
          if (i[0].startsWith("`")) {
            const s = /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/.exec(
              n.slice(i.index),
            );
            s && (r.lastIndex = i.index + s[0].length);
          } else if (!i[0].startsWith("\\")) {
            const s = n.slice(3, i.index);
            return s
              ? {
                  type: "underline",
                  raw: n.slice(0, r.lastIndex),
                  text: s,
                  tokens: t.inlineTokens(s),
                }
              : void 0;
          }
          i = r.exec(n);
        }
      },
    },
    addCommands() {
      return {
        setUnderline:
          () =>
          ({ commands: n }) =>
            n.setMark(this.name),
        toggleUnderline:
          () =>
          ({ commands: n }) =>
            n.toggleMark(this.name),
        unsetUnderline:
          () =>
          ({ commands: n }) =>
            n.unsetMark(this.name),
      };
    },
    addKeyboardShortcuts() {
      return {
        "Mod-u": () => this.editor.commands.toggleUnderline(),
        "Mod-U": () => this.editor.commands.toggleUnderline(),
      };
    },
  });
function Bk(n = {}) {
  return new V({
    view(e) {
      return new $k(e, n);
    },
  });
}
class $k {
  constructor(e, t) {
    var r;
    ((this.editorView = e),
      (this.cursorPos = null),
      (this.element = null),
      (this.timeout = -1),
      (this.lastDragEvent = null),
      (this.width = (r = t.width) !== null && r !== void 0 ? r : 1),
      (this.color = t.color === !1 ? void 0 : t.color || "black"),
      (this.class = t.class),
      (this.handlers = ["dragover", "dragend", "drop", "dragleave"].map((i) => {
        let s = (o) => {
          this[i](o);
        };
        return (e.dom.addEventListener(i, s), { name: i, handler: s });
      })));
  }
  destroy() {
    (this.setCursor(null),
      this.handlers.forEach(({ name: e, handler: t }) =>
        this.editorView.dom.removeEventListener(e, t),
      ));
  }
  update(e, t) {
    if (this.cursorPos != null && t.doc != e.state.doc)
      if (this.lastDragEvent) {
        let r = this.computeTarget(this.lastDragEvent);
        r == this.cursorPos ? this.updateOverlay() : this.setCursor(r);
      } else this.updateOverlay();
  }
  setCursor(e) {
    e != this.cursorPos &&
      ((this.cursorPos = e),
      e == null
        ? (this.element.parentNode.removeChild(this.element),
          (this.element = null))
        : this.updateOverlay());
  }
  updateOverlay() {
    let e = this.editorView.state.doc.resolve(this.cursorPos),
      t = !e.parent.inlineContent,
      r,
      i = this.editorView.dom,
      s = i.getBoundingClientRect(),
      o = s.width / i.offsetWidth,
      l = s.height / i.offsetHeight;
    if (t) {
      let d = e.nodeBefore,
        f = e.nodeAfter;
      if (d || f) {
        let h = this.editorView.nodeDOM(this.cursorPos - (d ? d.nodeSize : 0));
        if (h) {
          let p = h.getBoundingClientRect(),
            g = d ? p.bottom : p.top;
          d &&
            f &&
            (g =
              (g +
                this.editorView.nodeDOM(this.cursorPos).getBoundingClientRect()
                  .top) /
              2);
          let m = (this.width / 2) * l;
          r = { left: p.left, right: p.right, top: g - m, bottom: g + m };
        }
      }
    }
    if (!r) {
      let d = this.editorView.coordsAtPos(this.cursorPos),
        f = (this.width / 2) * o;
      r = { left: d.left - f, right: d.left + f, top: d.top, bottom: d.bottom };
    }
    let a = this.editorView.dom.offsetParent;
    (this.element ||
      ((this.element = a.appendChild(document.createElement("div"))),
      this.class && (this.element.className = this.class),
      (this.element.style.cssText =
        "position: absolute; z-index: 50; pointer-events: none;"),
      this.color && (this.element.style.backgroundColor = this.color)),
      this.element.classList.toggle("prosemirror-dropcursor-block", t),
      this.element.classList.toggle("prosemirror-dropcursor-inline", !t));
    let c, u;
    if (!a || (a == document.body && getComputedStyle(a).position == "static"))
      ((c = -pageXOffset), (u = -pageYOffset));
    else {
      let d = a.getBoundingClientRect(),
        f = d.width / a.offsetWidth,
        h = d.height / a.offsetHeight;
      ((c = d.left - a.scrollLeft * f), (u = d.top - a.scrollTop * h));
    }
    ((this.element.style.left = (r.left - c) / o + "px"),
      (this.element.style.top = (r.top - u) / l + "px"),
      (this.element.style.width = (r.right - r.left) / o + "px"),
      (this.element.style.height = (r.bottom - r.top) / l + "px"));
  }
  scheduleRemoval(e) {
    (clearTimeout(this.timeout),
      (this.timeout = setTimeout(() => this.setCursor(null), e)));
  }
  computeTarget(e) {
    let t = this.editorView.posAtCoords({ left: e.clientX, top: e.clientY }),
      r = t && t.inside >= 0 && this.editorView.state.doc.nodeAt(t.inside),
      i = r && r.type.spec.disableDropCursor,
      s = typeof i == "function" ? i(this.editorView, t, e) : i;
    if (!t || s) return null;
    let o = t.pos;
    if (this.editorView.dragging && this.editorView.dragging.slice) {
      let l = qa(this.editorView.state.doc, o, this.editorView.dragging.slice);
      l != null && (o = l);
    }
    return o;
  }
  dragover(e) {
    if (!this.editorView.editable) return;
    this.lastDragEvent = e;
    let t = this.computeTarget(e);
    t != null && (this.setCursor(t), this.scheduleRemoval(5e3));
  }
  dragend() {
    this.scheduleRemoval(20);
  }
  drop() {
    this.scheduleRemoval(20);
  }
  dragleave(e) {
    this.editorView.dom.contains(e.relatedTarget) || this.setCursor(null);
  }
}
class W extends N {
  constructor(e) {
    super(e, e);
  }
  map(e, t) {
    let r = e.resolve(t.map(this.head));
    return W.valid(r) ? new W(r) : N.near(r);
  }
  content() {
    return C.empty;
  }
  eq(e) {
    return e instanceof W && e.head == this.head;
  }
  toJSON() {
    return { type: "gapcursor", pos: this.head };
  }
  static fromJSON(e, t) {
    if (typeof t.pos != "number")
      throw new RangeError("Invalid input for GapCursor.fromJSON");
    return new W(e.resolve(t.pos));
  }
  getBookmark() {
    return new yo(this.anchor);
  }
  static valid(e) {
    let t = e.parent;
    if (t.inlineContent || !zk(e) || !Fk(e)) return !1;
    let r = t.type.spec.allowGapCursor;
    if (r != null) return r;
    let i = t.contentMatchAt(e.index()).defaultType;
    return i && i.isTextblock;
  }
  static findGapCursorFrom(e, t, r = !1) {
    e: for (;;) {
      if (!r && W.valid(e)) return e;
      let i = e.pos,
        s = null;
      for (let o = e.depth; ; o--) {
        let l = e.node(o);
        if (t > 0 ? e.indexAfter(o) < l.childCount : e.index(o) > 0) {
          s = l.child(t > 0 ? e.indexAfter(o) : e.index(o) - 1);
          break;
        } else if (o == 0) return null;
        i += t;
        let a = e.doc.resolve(i);
        if (W.valid(a)) return a;
      }
      for (;;) {
        let o = t > 0 ? s.firstChild : s.lastChild;
        if (!o) {
          if (s.isAtom && !s.isText && !O.isSelectable(s)) {
            ((e = e.doc.resolve(i + s.nodeSize * t)), (r = !1));
            continue e;
          }
          break;
        }
        ((s = o), (i += t));
        let l = e.doc.resolve(i);
        if (W.valid(l)) return l;
      }
      return null;
    }
  }
}
W.prototype.visible = !1;
W.findFrom = W.findGapCursorFrom;
N.jsonID("gapcursor", W);
class yo {
  constructor(e) {
    this.pos = e;
  }
  map(e) {
    return new yo(e.map(this.pos));
  }
  resolve(e) {
    let t = e.resolve(this.pos);
    return W.valid(t) ? new W(t) : N.near(t);
  }
}
function kd(n) {
  return n.isAtom || n.spec.isolating || n.spec.createGapCursor;
}
function zk(n) {
  for (let e = n.depth; e >= 0; e--) {
    let t = n.index(e),
      r = n.node(e);
    if (t == 0) {
      if (r.type.spec.isolating) return !0;
      continue;
    }
    for (let i = r.child(t - 1); ; i = i.lastChild) {
      if ((i.childCount == 0 && !i.inlineContent) || kd(i.type)) return !0;
      if (i.inlineContent) return !1;
    }
  }
  return !0;
}
function Fk(n) {
  for (let e = n.depth; e >= 0; e--) {
    let t = n.indexAfter(e),
      r = n.node(e);
    if (t == r.childCount) {
      if (r.type.spec.isolating) return !0;
      continue;
    }
    for (let i = r.child(t); ; i = i.firstChild) {
      if ((i.childCount == 0 && !i.inlineContent) || kd(i.type)) return !0;
      if (i.inlineContent) return !1;
    }
  }
  return !0;
}
function Vk() {
  return new V({
    props: {
      decorations: Wk,
      createSelectionBetween(n, e, t) {
        return e.pos == t.pos && W.valid(t) ? new W(t) : null;
      },
      handleClick: Hk,
      handleKeyDown: jk,
      handleDOMEvents: { beforeinput: _k },
    },
  });
}
const jk = Zc({
  ArrowLeft: lr("horiz", -1),
  ArrowRight: lr("horiz", 1),
  ArrowUp: lr("vert", -1),
  ArrowDown: lr("vert", 1),
});
function lr(n, e) {
  const t = n == "vert" ? (e > 0 ? "down" : "up") : e > 0 ? "right" : "left";
  return function (r, i, s) {
    let o = r.selection,
      l = e > 0 ? o.$to : o.$from,
      a = o.empty;
    if (o instanceof T) {
      if (!s.endOfTextblock(t) || l.depth == 0) return !1;
      ((a = !1), (l = r.doc.resolve(e > 0 ? l.after() : l.before())));
    }
    let c = W.findGapCursorFrom(l, e, a);
    return c ? (i && i(r.tr.setSelection(new W(c))), !0) : !1;
  };
}
function Hk(n, e, t) {
  if (!n || !n.editable) return !1;
  let r = n.state.doc.resolve(e);
  if (!W.valid(r)) return !1;
  let i = n.posAtCoords({ left: t.clientX, top: t.clientY });
  return i && i.inside > -1 && O.isSelectable(n.state.doc.nodeAt(i.inside))
    ? !1
    : (n.dispatch(n.state.tr.setSelection(new W(r))), !0);
}
function _k(n, e) {
  if (
    e.inputType != "insertCompositionText" ||
    !(n.state.selection instanceof W)
  )
    return !1;
  let { $from: t } = n.state.selection,
    r = t.parent
      .contentMatchAt(t.index())
      .findWrapping(n.state.schema.nodes.text);
  if (!r) return !1;
  let i = b.empty;
  for (let o = r.length - 1; o >= 0; o--)
    i = b.from(r[o].createAndFill(null, i));
  let s = n.state.tr.replace(t.pos, t.pos, new C(i, 0, 0));
  return (s.setSelection(T.near(s.doc.resolve(t.pos + 1))), n.dispatch(s), !1);
}
function Wk(n) {
  if (!(n.selection instanceof W)) return null;
  let e = document.createElement("div");
  return (
    (e.className = "ProseMirror-gapcursor"),
    P.create(n.doc, [ue.widget(n.selection.head, e, { key: "gapcursor" })])
  );
}
q.create({
  name: "characterCount",
  addOptions() {
    return {
      limit: null,
      autoTrim: !0,
      mode: "textSize",
      textCounter: (n) => n.length,
      wordCounter: (n) => n.split(" ").filter((e) => e !== "").length,
    };
  },
  addStorage() {
    return { characters: () => 0, words: () => 0 };
  },
  onBeforeCreate() {
    ((this.storage.characters = (n) => {
      const e = n?.node || this.editor.state.doc;
      if ((n?.mode || this.options.mode) === "textSize") {
        const t = e.textBetween(0, e.content.size, void 0, " ");
        return this.options.textCounter(t);
      }
      return e.nodeSize;
    }),
      (this.storage.words = (n) => {
        const e = n?.node || this.editor.state.doc,
          t = e.textBetween(0, e.content.size, " ", " ");
        return this.options.wordCounter(t);
      }));
  },
  addProseMirrorPlugins() {
    let n = !1;
    return [
      new V({
        key: new K("characterCount"),
        appendTransaction: (e, t, r) => {
          if (n) return;
          const i = this.options.limit,
            s = this.options.autoTrim;
          if (i == null || i === 0 || s === !1) {
            n = !0;
            return;
          }
          const o = this.storage.characters({ node: r.doc });
          if (o > i) {
            const l = o - i,
              a = 0,
              c = l;
            console.warn(
              `[CharacterCount] Initial content exceeded limit of ${i} characters. Content was automatically trimmed.`,
            );
            const u = r.tr.deleteRange(a, c);
            return ((n = !0), u);
          }
          n = !0;
        },
        filterTransaction: (e, t) => {
          const r = this.options.limit;
          if (!e.docChanged || r === 0 || r === null || r === void 0) return !0;
          const i = this.storage.characters({ node: t.doc }),
            s = this.storage.characters({ node: e.doc });
          if (s <= r || (i > r && s > r && s <= i)) return !0;
          if ((i > r && s > r && s > i) || !e.getMeta("paste")) return !1;
          const o = e.selection.$head.pos,
            l = o - (s - r),
            a = o;
          return (
            e.deleteRange(l, a),
            !(this.storage.characters({ node: e.doc }) > r)
          );
        },
      }),
    ];
  },
});
const qk = q.create({
  name: "dropCursor",
  addOptions() {
    return { color: "currentColor", width: 1, class: void 0 };
  },
  addProseMirrorPlugins() {
    return [Bk(this.options)];
  },
});
q.create({
  name: "focus",
  addOptions() {
    return { className: "has-focus", mode: "all" };
  },
  addProseMirrorPlugins() {
    return [
      new V({
        key: new K("focus"),
        props: {
          decorations: ({ doc: n, selection: e }) => {
            const { isEditable: t, isFocused: r } = this.editor,
              { anchor: i } = e,
              s = [];
            if (!t || !r) return P.create(n, []);
            let o = 0;
            this.options.mode === "deepest" &&
              n.descendants((a, c) => {
                if (!a.isText) {
                  if (!(i >= c && i <= c + a.nodeSize - 1)) return !1;
                  o += 1;
                }
              });
            let l = 0;
            return (
              n.descendants((a, c) => {
                if (a.isText || !(i >= c && i <= c + a.nodeSize - 1)) return !1;
                if (
                  ((l += 1),
                  (this.options.mode === "deepest" && o - l > 0) ||
                    (this.options.mode === "shallowest" && l > 1))
                )
                  return this.options.mode === "deepest";
                s.push(
                  ue.node(c, c + a.nodeSize, { class: this.options.className }),
                );
              }),
              P.create(n, s)
            );
          },
        },
      }),
    ];
  },
});
const Uk = q.create({
    name: "gapCursor",
    addProseMirrorPlugins() {
      return [Vk()];
    },
    extendNodeSchema(n) {
      var e;
      const t = { name: n.name, options: n.options, storage: n.storage };
      return {
        allowGapCursor:
          (e = B(v(n, "allowGapCursor", t))) !== null && e !== void 0
            ? e
            : null,
      };
    },
  }),
  Sd = "placeholder",
  ga = new K("tiptap__placeholder");
function xd(n) {
  const {
      editor: e,
      placeholder: t,
      dataAttribute: r,
      pos: i,
      node: s,
      isEmptyDoc: o,
      hasAnchor: l,
      classes: { emptyNode: a, emptyEditor: c },
    } = n,
    u = [a];
  return (
    o && u.push(c),
    ue.node(i, i + s.nodeSize, {
      class: u.join(" "),
      [r]:
        typeof t == "function"
          ? t({ editor: e, node: s, pos: i, hasAnchor: l })
          : t,
    })
  );
}
function wd(n, e) {
  return typeof n == "function" ? n(e) : n;
}
function Cd({
  editor: n,
  options: e,
  dataAttribute: t,
  doc: r,
  selection: i,
  from: s,
  to: o,
}) {
  const { anchor: l } = i,
    a = [],
    c = n.isEmpty;
  return (
    r.nodesBetween(s, o, (u, d) => {
      const f = l >= d && l <= d + u.nodeSize,
        h = !u.isLeaf && _n(u);
      return (
        u.type.isTextblock &&
          (f || !e.showOnlyCurrent) &&
          h &&
          a.push(
            xd({
              editor: n,
              isEmptyDoc: c,
              dataAttribute: t,
              hasAnchor: f,
              placeholder: e.placeholder,
              classes: {
                emptyEditor: e.emptyEditorClass,
                emptyNode: wd(e.emptyNodeClass, {
                  editor: n,
                  node: u,
                  pos: d,
                  hasAnchor: f,
                }),
              },
              node: u,
              pos: d,
            }),
          ),
        e.includeChildren
      );
    }),
    a
  );
}
function vd({ editor: n, options: e, dataAttribute: t, doc: r, selection: i }) {
  if (!(n.isEditable || !e.showOnlyWhenEditable)) return null;
  const { anchor: s } = i,
    o = [],
    l = n.isEmpty;
  if (e.showOnlyCurrent && !e.includeChildren) {
    const a = r.resolve(s),
      c = a.depth > 0 ? a.node(1) : a.nodeAfter,
      u = a.depth > 0 ? a.before(1) : s;
    if (c && c.type.isTextblock && _n(c)) {
      const d = s >= u && s <= u + c.nodeSize;
      o.push(
        xd({
          editor: n,
          isEmptyDoc: l,
          dataAttribute: t,
          hasAnchor: d,
          placeholder: e.placeholder,
          classes: {
            emptyEditor: e.emptyEditorClass,
            emptyNode: wd(e.emptyNodeClass, {
              editor: n,
              node: c,
              pos: u,
              hasAnchor: d,
            }),
          },
          node: c,
          pos: u,
        }),
      );
    }
  } else
    o.push(
      ...Cd({
        editor: n,
        options: e,
        dataAttribute: t,
        doc: r,
        selection: i,
        from: 0,
        to: r.content.size,
      }),
    );
  return P.create(r, o);
}
function Mn(n, e) {
  const t = n.resolve(e);
  if (t.depth === 0) {
    var r;
    const s = (r = t.nodeAfter) !== null && r !== void 0 ? r : t.nodeBefore;
    if (!s) return { from: e, to: e };
    const o = t.nodeAfter ? e : e - s.nodeSize;
    return { from: o, to: o + s.nodeSize };
  }
  const i = t.before(1);
  return { from: i, to: i + t.node(1).nodeSize };
}
function En(n, e) {
  return { from: Math.max(0, e.from), to: Math.min(n.content.size, e.to) };
}
function Kk(n, e, t) {
  const r = [];
  return (
    n.forEach((i, s) => {
      const o = s,
        l = o + i.nodeSize,
        a = o + 1,
        c = l + 1;
      a < t && c > e && r.push({ from: o, to: l });
    }),
    r
  );
}
function Jk(n) {
  if (n.length === 0) return [];
  const e = [...n].sort((r, i) => r.from - i.from),
    t = [{ ...e[0] }];
  for (let r = 1; r < e.length; r += 1) {
    const i = t[t.length - 1],
      s = e[r];
    s.from <= i.to ? (i.to = Math.max(i.to, s.to)) : t.push({ ...s });
  }
  return t;
}
function Gk(n, e) {
  const t = Kk(n, e.from, e.to);
  return (
    t.push(En(n, Mn(n, e.from))),
    e.to > e.from
      ? t.push(En(n, Mn(n, Math.min(e.to, n.content.size + 1) - 1)))
      : e.from < n.content.size + 1 &&
        t.push(En(n, Mn(n, Math.min(e.from + 1, n.content.size)))),
    t
  );
}
function Yk(n, e, t) {
  const r = [];
  if (n.docChanged) {
    const i = gi(n);
    for (const s of i) r.push(...Gk(t.doc, s.newRange));
  }
  return (
    n.selectionSet &&
      (r.push(En(t.doc, Mn(t.doc, n.mapping.map(e.selection.anchor)))),
      r.push(En(t.doc, Mn(t.doc, t.selection.anchor)))),
    Jk(r)
  );
}
function Xk(n, e, t) {
  const r = Math.max(0, Math.min(n, t.content.size));
  return { from: r, to: Math.max(r, Math.min(e, t.content.size)) };
}
function Qk({
  decorations: n,
  ranges: e,
  editor: t,
  options: r,
  dataAttribute: i,
  doc: s,
  selection: o,
}) {
  let l = n;
  for (const a of e) {
    const { from: c, to: u } = Xk(a.from, a.to, s),
      d = l.find(c, u).filter((h) => h.from >= c && h.to <= u);
    d.length && (l = l.remove(d));
    const f = Cd({
      editor: t,
      options: r,
      dataAttribute: i,
      doc: s,
      selection: o,
      from: c,
      to: u,
    });
    f.length && (l = l.add(s, f));
  }
  return l;
}
function Zk({ editor: n, options: e, dataAttribute: t }) {
  return {
    init(r, i) {
      const s = vd({
        editor: n,
        options: e,
        dataAttribute: t,
        doc: i.doc,
        selection: i.selection,
      });
      return s ?? P.empty;
    },
    apply(r, i, s, o) {
      return !r.docChanged && !r.selectionSet
        ? i
        : Qk({
            decorations: i.map(r.mapping, r.doc),
            ranges: Yk(r, s, o),
            editor: n,
            options: e,
            dataAttribute: t,
            doc: o.doc,
            selection: o.selection,
          });
    },
  };
}
function e1(n) {
  return n
    .replace(/\s+/g, "-")
    .replace(/[^a-zA-Z0-9-]/g, "")
    .replace(/^[0-9-]+/, "")
    .replace(/^-+/, "")
    .toLowerCase();
}
function t1({ editor: n, options: e }) {
  const t = e.dataAttribute ? `data-${e1(e.dataAttribute)}` : `data-${Sd}`,
    r = e.showOnlyCurrent && !e.includeChildren;
  return new V({
    key: ga,
    ...(r ? {} : { state: Zk({ editor: n, options: e, dataAttribute: t }) }),
    props: {
      decorations: r
        ? ({ doc: i, selection: s }) =>
            vd({
              editor: n,
              options: e,
              dataAttribute: t,
              doc: i,
              selection: s,
            })
        : (i) => {
            var s;
            return e.showOnlyWhenEditable && !n.isEditable
              ? P.empty
              : (s = ga.getState(i)) !== null && s !== void 0
                ? s
                : P.empty;
          },
    },
  });
}
q.create({
  name: "placeholder",
  addOptions() {
    return {
      emptyEditorClass: "is-editor-empty",
      emptyNodeClass: "is-empty",
      dataAttribute: Sd,
      placeholder: "Write something …",
      showOnlyWhenEditable: !0,
      showOnlyCurrent: !0,
      includeChildren: !1,
    };
  },
  addProseMirrorPlugins() {
    return [t1({ editor: this.editor, options: this.options })];
  },
});
function Rs(n, e) {
  return !n.selection.empty && !Cu(n.selection) && e.isEditable;
}
function n1(n, e) {
  return Rs(n, e) && !e.isFocused && !e.view.dragging;
}
function r1() {
  var n;
  (n = window.getSelection()) === null || n === void 0 || n.removeAllRanges();
}
function i1(n) {
  n.focus();
}
q.create({
  name: "selection",
  addOptions() {
    return { className: "selection" };
  },
  addProseMirrorPlugins() {
    const { editor: n, options: e } = this;
    return [
      new V({
        key: new K("selection"),
        props: {
          decorations(t) {
            return n1(t, n)
              ? P.create(t.doc, [
                  ue.inline(t.selection.from, t.selection.to, {
                    class: e.className,
                  }),
                ])
              : null;
          },
          handleDOMEvents: {
            blur(t) {
              return (Rs(t.state, n) && r1(), !1);
            },
            focus(t) {
              return (
                Rs(t.state, n) &&
                  requestAnimationFrame(() => {
                    !n.isDestroyed && t.hasFocus() && i1(t);
                  }),
                !1
              );
            },
          },
        },
      }),
    ];
  },
});
function ya({ types: n, node: e }) {
  return (e && Array.isArray(n) && n.includes(e.type)) || e?.type === n;
}
const s1 = q.create({
    name: "trailingNode",
    addOptions() {
      return { node: void 0, notAfter: [] };
    },
    addProseMirrorPlugins() {
      var n;
      const e = new K(this.name),
        t =
          this.options.node ||
          ((n = this.editor.schema.topNodeType.contentMatch.defaultType) ===
            null || n === void 0
            ? void 0
            : n.name) ||
          "paragraph",
        r = Object.entries(this.editor.schema.nodes)
          .map(([, i]) => i)
          .filter((i) =>
            (this.options.notAfter || []).concat(t).includes(i.name),
          );
      return [
        new V({
          key: e,
          appendTransaction: (i, s, o) => {
            const { doc: l, tr: a, schema: c } = o,
              u = e.getState(o),
              d = l.content.size,
              f = c.nodes[t];
            if (!i.some((h) => h.getMeta("skipTrailingNode")) && u)
              return a.insert(d, f.create());
          },
          state: {
            init: (i, s) => {
              const o = s.tr.doc.lastChild;
              return !ya({ node: o, types: r });
            },
            apply: (i, s) => {
              if (!i.docChanged || i.getMeta("__uniqueIDTransaction")) return s;
              const o = i.doc.lastChild;
              return !ya({ node: o, types: r });
            },
          },
        }),
      ];
    },
  }),
  o1 = q.create({
    name: "undoRedo",
    addOptions() {
      return { depth: 100, newGroupDelay: 500 };
    },
    addCommands() {
      return {
        undo:
          () =>
          ({ state: n, dispatch: e }) =>
            ru(n, e),
        redo:
          () =>
          ({ state: n, dispatch: e }) =>
            iu(n, e),
      };
    },
    addProseMirrorPlugins() {
      return [Qp(this.options)];
    },
    addKeyboardShortcuts() {
      return {
        "Mod-z": () => this.editor.commands.undo(),
        "Shift-Mod-z": () => this.editor.commands.redo(),
        "Mod-y": () => this.editor.commands.redo(),
        "Mod-я": () => this.editor.commands.undo(),
        "Shift-Mod-я": () => this.editor.commands.redo(),
      };
    },
  }),
  l1 = q.create({
    name: "starterKit",
    addExtensions() {
      const n = [];
      if (
        (this.options.bold !== !1 && n.push(Y0.configure(this.options.bold)),
        this.options.blockquote !== !1 &&
          n.push(q0.configure(this.options.blockquote)),
        this.options.bulletList !== !1 &&
          n.push(cd.configure(this.options.bulletList)),
        this.options.code !== !1 && n.push(eb.configure(this.options.code)),
        this.options.codeBlock !== !1 &&
          n.push(rb.configure(this.options.codeBlock)),
        this.options.document !== !1 &&
          n.push(ib.configure(this.options.document)),
        this.options.dropcursor !== !1 &&
          n.push(qk.configure(this.options.dropcursor)),
        this.options.gapcursor !== !1 &&
          n.push(Uk.configure(this.options.gapcursor)),
        this.options.hardBreak !== !1 &&
          n.push(sb.configure(this.options.hardBreak)),
        this.options.heading !== !1 &&
          n.push(ob.configure(this.options.heading)),
        this.options.undoRedo !== !1 &&
          n.push(o1.configure(this.options.undoRedo)),
        this.options.horizontalRule !== !1 &&
          n.push(lb.configure(this.options.horizontalRule)),
        this.options.italic !== !1 && n.push(fb.configure(this.options.italic)),
        this.options.listItem !== !1 &&
          n.push(pd.configure(this.options.listItem)),
        this.options.listKeymap !== !1)
      ) {
        var e;
        n.push(
          gd.configure(
            (e = this.options) === null || e === void 0 ? void 0 : e.listKeymap,
          ),
        );
      }
      if (this.options.link !== !1) {
        var t;
        n.push(
          Ub.configure(
            (t = this.options) === null || t === void 0 ? void 0 : t.link,
          ),
        );
      }
      if (
        (this.options.orderedList !== !1 &&
          n.push(bd.configure(this.options.orderedList)),
        this.options.paragraph !== !1 &&
          n.push(Nk.configure(this.options.paragraph)),
        this.options.strike !== !1 && n.push(Ik.configure(this.options.strike)),
        this.options.text !== !1 && n.push(Lk.configure(this.options.text)),
        this.options.underline !== !1)
      ) {
        var r;
        n.push(
          Pk.configure(
            (r = this.options) === null || r === void 0 ? void 0 : r.underline,
          ),
        );
      }
      if (this.options.trailingNode !== !1) {
        var i;
        n.push(
          s1.configure(
            (i = this.options) === null || i === void 0
              ? void 0
              : i.trailingNode,
          ),
        );
      }
      return n;
    },
  });
var a1 = l1;
const c1 = [
  a1.configure({
    heading: { levels: [1, 2, 3] },
    blockquote: !1,
    code: !1,
    codeBlock: !1,
    horizontalRule: !1,
    strike: !1,
    link: !1,
    underline: !1,
  }),
];
function u1({ editor: n }) {
  const e = ju({
    editor: n,
    selector: ({ editor: t }) => ({
      bold: t.isActive("bold"),
      italic: t.isActive("italic"),
      bullets: t.isActive("bulletList"),
      numbers: t.isActive("orderedList"),
      heading: t.isActive("heading"),
    }),
  });
  return $.jsxs($.Fragment, {
    children: [
      $.jsxs(Ci, {
        label: "Font",
        children: [
          $.jsx(rn, {
            icon: $.jsx(Rd, {}),
            label: "Bold",
            onClick: () => n.chain().focus().toggleBold().run(),
            pressed: e.bold,
          }),
          $.jsx(rn, {
            icon: $.jsx(Dd, {}),
            label: "Italic",
            onClick: () => n.chain().focus().toggleItalic().run(),
            pressed: e.italic,
          }),
        ],
      }),
      $.jsxs(Ci, {
        label: "Paragraph",
        children: [
          $.jsx(rn, {
            icon: $.jsx(Pd, {}),
            label: "Bullets",
            onClick: () => n.chain().focus().toggleBulletList().run(),
            pressed: e.bullets,
          }),
          $.jsx(rn, {
            icon: $.jsx(Ld, {}),
            label: "Numbering",
            onClick: () => n.chain().focus().toggleOrderedList().run(),
            pressed: e.numbers,
          }),
        ],
      }),
      $.jsx(Ci, {
        label: "Styles",
        children: $.jsx(rn, {
          icon: $.jsx(Id, {}),
          label: "Heading",
          onClick: () => n.chain().focus().toggleHeading({ level: 2 }).run(),
          pressed: e.heading,
          wide: !0,
        }),
      }),
    ],
  });
}
function p1({ content: n, onChange: e, label: t, fileName: r }) {
  const i = z0({
    extensions: c1,
    content: n.doc,
    immediatelyRender: !0,
    editorProps: {
      attributes: {
        "aria-label": t,
        "aria-multiline": "true",
        role: "textbox",
        class: "coursework-doc",
        "data-coursework-doc": "",
      },
    },
    onUpdate: ({ editor: s }) => {
      const o = Co(s.getJSON());
      o && e({ kind: "doc", doc: o });
    },
  });
  return (
    re.useEffect(() => {
      i &&
        JSON.stringify(Co(i.getJSON())) !== JSON.stringify(n.doc) &&
        i.commands.setContent(n.doc, { emitUpdate: !1 });
    }, [i, n.doc]),
    i
      ? $.jsx(Nd, {
          app: "word",
          fileName: r,
          ribbon: $.jsx(u1, { editor: i }),
          children: $.jsx("div", {
            className: "office-page",
            children: $.jsx(Vu, { editor: i }),
          }),
        })
      : $.jsx("div", { className: "min-h-[60vh]" })
  );
}
export { p1 as DocEditor };
