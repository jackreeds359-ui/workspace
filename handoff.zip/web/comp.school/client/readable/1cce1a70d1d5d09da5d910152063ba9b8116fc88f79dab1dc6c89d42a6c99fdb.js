function Td(u, s) {
  for (var a = 0; a < s.length; a++) {
    const f = s[a];
    if (typeof f != "string" && !Array.isArray(f)) {
      for (const p in f)
        if (p !== "default" && !(p in u)) {
          const v = Object.getOwnPropertyDescriptor(f, p);
          v &&
            Object.defineProperty(
              u,
              p,
              v.get ? v : { enumerable: !0, get: () => f[p] },
            );
        }
    }
  }
  return Object.freeze(
    Object.defineProperty(u, Symbol.toStringTag, { value: "Module" }),
  );
}
function bu(u) {
  return u && u.__esModule && Object.prototype.hasOwnProperty.call(u, "default")
    ? u.default
    : u;
}
var Wu = { exports: {} },
  Rr = {},
  Vu = { exports: {} },
  q = {};
/**
 * @license React
 * react.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var rc;
function zd() {
  if (rc) return q;
  rc = 1;
  var u = Symbol.for("react.element"),
    s = Symbol.for("react.portal"),
    a = Symbol.for("react.fragment"),
    f = Symbol.for("react.strict_mode"),
    p = Symbol.for("react.profiler"),
    v = Symbol.for("react.provider"),
    S = Symbol.for("react.context"),
    E = Symbol.for("react.forward_ref"),
    k = Symbol.for("react.suspense"),
    x = Symbol.for("react.memo"),
    P = Symbol.for("react.lazy"),
    z = Symbol.iterator;
  function F(m) {
    return m === null || typeof m != "object"
      ? null
      : ((m = (z && m[z]) || m["@@iterator"]),
        typeof m == "function" ? m : null);
  }
  var V = {
      isMounted: function () {
        return !1;
      },
      enqueueForceUpdate: function () {},
      enqueueReplaceState: function () {},
      enqueueSetState: function () {},
    },
    Y = Object.assign,
    H = {};
  function O(m, R, J) {
    ((this.props = m),
      (this.context = R),
      (this.refs = H),
      (this.updater = J || V));
  }
  ((O.prototype.isReactComponent = {}),
    (O.prototype.setState = function (m, R) {
      if (typeof m != "object" && typeof m != "function" && m != null)
        throw Error(
          "setState(...): takes an object of state variables to update or a function which returns an object of state variables.",
        );
      this.updater.enqueueSetState(this, m, R, "setState");
    }),
    (O.prototype.forceUpdate = function (m) {
      this.updater.enqueueForceUpdate(this, m, "forceUpdate");
    }));
  function W() {}
  W.prototype = O.prototype;
  function A(m, R, J) {
    ((this.props = m),
      (this.context = R),
      (this.refs = H),
      (this.updater = J || V));
  }
  var Z = (A.prototype = new W());
  ((Z.constructor = A), Y(Z, O.prototype), (Z.isPureReactComponent = !0));
  var ue = Array.isArray,
    he = Object.prototype.hasOwnProperty,
    ke = { current: null },
    Ee = { key: !0, ref: !0, __self: !0, __source: !0 };
  function Te(m, R, J) {
    var b,
      te = {},
      ne = null,
      ie = null;
    if (R != null)
      for (b in (R.ref !== void 0 && (ie = R.ref),
      R.key !== void 0 && (ne = "" + R.key),
      R))
        he.call(R, b) && !Ee.hasOwnProperty(b) && (te[b] = R[b]);
    var le = arguments.length - 2;
    if (le === 1) te.children = J;
    else if (1 < le) {
      for (var fe = Array(le), Xe = 0; Xe < le; Xe++)
        fe[Xe] = arguments[Xe + 2];
      te.children = fe;
    }
    if (m && m.defaultProps)
      for (b in ((le = m.defaultProps), le))
        te[b] === void 0 && (te[b] = le[b]);
    return {
      $$typeof: u,
      type: m,
      key: ne,
      ref: ie,
      props: te,
      _owner: ke.current,
    };
  }
  function Ce(m, R) {
    return {
      $$typeof: u,
      type: m.type,
      key: R,
      ref: m.ref,
      props: m.props,
      _owner: m._owner,
    };
  }
  function De(m) {
    return typeof m == "object" && m !== null && m.$$typeof === u;
  }
  function vt(m) {
    var R = { "=": "=0", ":": "=2" };
    return (
      "$" +
      m.replace(/[=:]/g, function (J) {
        return R[J];
      })
    );
  }
  var yt = /\/+/g;
  function Ye(m, R) {
    return typeof m == "object" && m !== null && m.key != null
      ? vt("" + m.key)
      : R.toString(36);
  }
  function ut(m, R, J, b, te) {
    var ne = typeof m;
    (ne === "undefined" || ne === "boolean") && (m = null);
    var ie = !1;
    if (m === null) ie = !0;
    else
      switch (ne) {
        case "string":
        case "number":
          ie = !0;
          break;
        case "object":
          switch (m.$$typeof) {
            case u:
            case s:
              ie = !0;
          }
      }
    if (ie)
      return (
        (ie = m),
        (te = te(ie)),
        (m = b === "" ? "." + Ye(ie, 0) : b),
        ue(te)
          ? ((J = ""),
            m != null && (J = m.replace(yt, "$&/") + "/"),
            ut(te, R, J, "", function (Xe) {
              return Xe;
            }))
          : te != null &&
            (De(te) &&
              (te = Ce(
                te,
                J +
                  (!te.key || (ie && ie.key === te.key)
                    ? ""
                    : ("" + te.key).replace(yt, "$&/") + "/") +
                  m,
              )),
            R.push(te)),
        1
      );
    if (((ie = 0), (b = b === "" ? "." : b + ":"), ue(m)))
      for (var le = 0; le < m.length; le++) {
        ne = m[le];
        var fe = b + Ye(ne, le);
        ie += ut(ne, R, J, fe, te);
      }
    else if (((fe = F(m)), typeof fe == "function"))
      for (m = fe.call(m), le = 0; !(ne = m.next()).done;)
        ((ne = ne.value),
          (fe = b + Ye(ne, le++)),
          (ie += ut(ne, R, J, fe, te)));
    else if (ne === "object")
      throw (
        (R = String(m)),
        Error(
          "Objects are not valid as a React child (found: " +
            (R === "[object Object]"
              ? "object with keys {" + Object.keys(m).join(", ") + "}"
              : R) +
            "). If you meant to render a collection of children, use an array instead.",
        )
      );
    return ie;
  }
  function gt(m, R, J) {
    if (m == null) return m;
    var b = [],
      te = 0;
    return (
      ut(m, b, "", "", function (ne) {
        return R.call(J, ne, te++);
      }),
      b
    );
  }
  function Ae(m) {
    if (m._status === -1) {
      var R = m._result;
      ((R = R()),
        R.then(
          function (J) {
            (m._status === 0 || m._status === -1) &&
              ((m._status = 1), (m._result = J));
          },
          function (J) {
            (m._status === 0 || m._status === -1) &&
              ((m._status = 2), (m._result = J));
          },
        ),
        m._status === -1 && ((m._status = 0), (m._result = R)));
    }
    if (m._status === 1) return m._result.default;
    throw m._result;
  }
  var ye = { current: null },
    D = { transition: null },
    X = {
      ReactCurrentDispatcher: ye,
      ReactCurrentBatchConfig: D,
      ReactCurrentOwner: ke,
    };
  function j() {
    throw Error("act(...) is not supported in production builds of React.");
  }
  return (
    (q.Children = {
      map: gt,
      forEach: function (m, R, J) {
        gt(
          m,
          function () {
            R.apply(this, arguments);
          },
          J,
        );
      },
      count: function (m) {
        var R = 0;
        return (
          gt(m, function () {
            R++;
          }),
          R
        );
      },
      toArray: function (m) {
        return (
          gt(m, function (R) {
            return R;
          }) || []
        );
      },
      only: function (m) {
        if (!De(m))
          throw Error(
            "React.Children.only expected to receive a single React element child.",
          );
        return m;
      },
    }),
    (q.Component = O),
    (q.Fragment = a),
    (q.Profiler = p),
    (q.PureComponent = A),
    (q.StrictMode = f),
    (q.Suspense = k),
    (q.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = X),
    (q.act = j),
    (q.cloneElement = function (m, R, J) {
      if (m == null)
        throw Error(
          "React.cloneElement(...): The argument must be a React element, but you passed " +
            m +
            ".",
        );
      var b = Y({}, m.props),
        te = m.key,
        ne = m.ref,
        ie = m._owner;
      if (R != null) {
        if (
          (R.ref !== void 0 && ((ne = R.ref), (ie = ke.current)),
          R.key !== void 0 && (te = "" + R.key),
          m.type && m.type.defaultProps)
        )
          var le = m.type.defaultProps;
        for (fe in R)
          he.call(R, fe) &&
            !Ee.hasOwnProperty(fe) &&
            (b[fe] = R[fe] === void 0 && le !== void 0 ? le[fe] : R[fe]);
      }
      var fe = arguments.length - 2;
      if (fe === 1) b.children = J;
      else if (1 < fe) {
        le = Array(fe);
        for (var Xe = 0; Xe < fe; Xe++) le[Xe] = arguments[Xe + 2];
        b.children = le;
      }
      return {
        $$typeof: u,
        type: m.type,
        key: te,
        ref: ne,
        props: b,
        _owner: ie,
      };
    }),
    (q.createContext = function (m) {
      return (
        (m = {
          $$typeof: S,
          _currentValue: m,
          _currentValue2: m,
          _threadCount: 0,
          Provider: null,
          Consumer: null,
          _defaultValue: null,
          _globalName: null,
        }),
        (m.Provider = { $$typeof: v, _context: m }),
        (m.Consumer = m)
      );
    }),
    (q.createElement = Te),
    (q.createFactory = function (m) {
      var R = Te.bind(null, m);
      return ((R.type = m), R);
    }),
    (q.createRef = function () {
      return { current: null };
    }),
    (q.forwardRef = function (m) {
      return { $$typeof: E, render: m };
    }),
    (q.isValidElement = De),
    (q.lazy = function (m) {
      return { $$typeof: P, _payload: { _status: -1, _result: m }, _init: Ae };
    }),
    (q.memo = function (m, R) {
      return { $$typeof: x, type: m, compare: R === void 0 ? null : R };
    }),
    (q.startTransition = function (m) {
      var R = D.transition;
      D.transition = {};
      try {
        m();
      } finally {
        D.transition = R;
      }
    }),
    (q.unstable_act = j),
    (q.useCallback = function (m, R) {
      return ye.current.useCallback(m, R);
    }),
    (q.useContext = function (m) {
      return ye.current.useContext(m);
    }),
    (q.useDebugValue = function () {}),
    (q.useDeferredValue = function (m) {
      return ye.current.useDeferredValue(m);
    }),
    (q.useEffect = function (m, R) {
      return ye.current.useEffect(m, R);
    }),
    (q.useId = function () {
      return ye.current.useId();
    }),
    (q.useImperativeHandle = function (m, R, J) {
      return ye.current.useImperativeHandle(m, R, J);
    }),
    (q.useInsertionEffect = function (m, R) {
      return ye.current.useInsertionEffect(m, R);
    }),
    (q.useLayoutEffect = function (m, R) {
      return ye.current.useLayoutEffect(m, R);
    }),
    (q.useMemo = function (m, R) {
      return ye.current.useMemo(m, R);
    }),
    (q.useReducer = function (m, R, J) {
      return ye.current.useReducer(m, R, J);
    }),
    (q.useRef = function (m) {
      return ye.current.useRef(m);
    }),
    (q.useState = function (m) {
      return ye.current.useState(m);
    }),
    (q.useSyncExternalStore = function (m, R, J) {
      return ye.current.useSyncExternalStore(m, R, J);
    }),
    (q.useTransition = function () {
      return ye.current.useTransition();
    }),
    (q.version = "18.3.1"),
    q
  );
}
var lc;
function ei() {
  return (lc || ((lc = 1), (Vu.exports = zd())), Vu.exports);
}
/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var oc;
function Od() {
  if (oc) return Rr;
  oc = 1;
  var u = ei(),
    s = Symbol.for("react.element"),
    a = Symbol.for("react.fragment"),
    f = Object.prototype.hasOwnProperty,
    p = u.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,
    v = { key: !0, ref: !0, __self: !0, __source: !0 };
  function S(E, k, x) {
    var P,
      z = {},
      F = null,
      V = null;
    (x !== void 0 && (F = "" + x),
      k.key !== void 0 && (F = "" + k.key),
      k.ref !== void 0 && (V = k.ref));
    for (P in k) f.call(k, P) && !v.hasOwnProperty(P) && (z[P] = k[P]);
    if (E && E.defaultProps)
      for (P in ((k = E.defaultProps), k)) z[P] === void 0 && (z[P] = k[P]);
    return {
      $$typeof: s,
      type: E,
      key: F,
      ref: V,
      props: z,
      _owner: p.current,
    };
  }
  return ((Rr.Fragment = a), (Rr.jsx = S), (Rr.jsxs = S), Rr);
}
var uc;
function Dd() {
  return (uc || ((uc = 1), (Wu.exports = Od())), Wu.exports);
}
var sh = Dd(),
  C = ei();
const Md = bu(C),
  ch = Td({ __proto__: null, default: Md }, [C]);
var Hl = {},
  Qu = { exports: {} },
  Ke = {},
  Ku = { exports: {} },
  Yu = {};
/**
 * @license React
 * scheduler.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var ic;
function Fd() {
  return (
    ic ||
      ((ic = 1),
      (function (u) {
        function s(D, X) {
          var j = D.length;
          D.push(X);
          e: for (; 0 < j;) {
            var m = (j - 1) >>> 1,
              R = D[m];
            if (0 < p(R, X)) ((D[m] = X), (D[j] = R), (j = m));
            else break e;
          }
        }
        function a(D) {
          return D.length === 0 ? null : D[0];
        }
        function f(D) {
          if (D.length === 0) return null;
          var X = D[0],
            j = D.pop();
          if (j !== X) {
            D[0] = j;
            e: for (var m = 0, R = D.length, J = R >>> 1; m < J;) {
              var b = 2 * (m + 1) - 1,
                te = D[b],
                ne = b + 1,
                ie = D[ne];
              if (0 > p(te, j))
                ne < R && 0 > p(ie, te)
                  ? ((D[m] = ie), (D[ne] = j), (m = ne))
                  : ((D[m] = te), (D[b] = j), (m = b));
              else if (ne < R && 0 > p(ie, j))
                ((D[m] = ie), (D[ne] = j), (m = ne));
              else break e;
            }
          }
          return X;
        }
        function p(D, X) {
          var j = D.sortIndex - X.sortIndex;
          return j !== 0 ? j : D.id - X.id;
        }
        if (
          typeof performance == "object" &&
          typeof performance.now == "function"
        ) {
          var v = performance;
          u.unstable_now = function () {
            return v.now();
          };
        } else {
          var S = Date,
            E = S.now();
          u.unstable_now = function () {
            return S.now() - E;
          };
        }
        var k = [],
          x = [],
          P = 1,
          z = null,
          F = 3,
          V = !1,
          Y = !1,
          H = !1,
          O = typeof setTimeout == "function" ? setTimeout : null,
          W = typeof clearTimeout == "function" ? clearTimeout : null,
          A = typeof setImmediate < "u" ? setImmediate : null;
        typeof navigator < "u" &&
          navigator.scheduling !== void 0 &&
          navigator.scheduling.isInputPending !== void 0 &&
          navigator.scheduling.isInputPending.bind(navigator.scheduling);
        function Z(D) {
          for (var X = a(x); X !== null;) {
            if (X.callback === null) f(x);
            else if (X.startTime <= D)
              (f(x), (X.sortIndex = X.expirationTime), s(k, X));
            else break;
            X = a(x);
          }
        }
        function ue(D) {
          if (((H = !1), Z(D), !Y))
            if (a(k) !== null) ((Y = !0), Ae(he));
            else {
              var X = a(x);
              X !== null && ye(ue, X.startTime - D);
            }
        }
        function he(D, X) {
          ((Y = !1), H && ((H = !1), W(Te), (Te = -1)), (V = !0));
          var j = F;
          try {
            for (
              Z(X), z = a(k);
              z !== null && (!(z.expirationTime > X) || (D && !vt()));
            ) {
              var m = z.callback;
              if (typeof m == "function") {
                ((z.callback = null), (F = z.priorityLevel));
                var R = m(z.expirationTime <= X);
                ((X = u.unstable_now()),
                  typeof R == "function"
                    ? (z.callback = R)
                    : z === a(k) && f(k),
                  Z(X));
              } else f(k);
              z = a(k);
            }
            if (z !== null) var J = !0;
            else {
              var b = a(x);
              (b !== null && ye(ue, b.startTime - X), (J = !1));
            }
            return J;
          } finally {
            ((z = null), (F = j), (V = !1));
          }
        }
        var ke = !1,
          Ee = null,
          Te = -1,
          Ce = 5,
          De = -1;
        function vt() {
          return !(u.unstable_now() - De < Ce);
        }
        function yt() {
          if (Ee !== null) {
            var D = u.unstable_now();
            De = D;
            var X = !0;
            try {
              X = Ee(!0, D);
            } finally {
              X ? Ye() : ((ke = !1), (Ee = null));
            }
          } else ke = !1;
        }
        var Ye;
        if (typeof A == "function")
          Ye = function () {
            A(yt);
          };
        else if (typeof MessageChannel < "u") {
          var ut = new MessageChannel(),
            gt = ut.port2;
          ((ut.port1.onmessage = yt),
            (Ye = function () {
              gt.postMessage(null);
            }));
        } else
          Ye = function () {
            O(yt, 0);
          };
        function Ae(D) {
          ((Ee = D), ke || ((ke = !0), Ye()));
        }
        function ye(D, X) {
          Te = O(function () {
            D(u.unstable_now());
          }, X);
        }
        ((u.unstable_IdlePriority = 5),
          (u.unstable_ImmediatePriority = 1),
          (u.unstable_LowPriority = 4),
          (u.unstable_NormalPriority = 3),
          (u.unstable_Profiling = null),
          (u.unstable_UserBlockingPriority = 2),
          (u.unstable_cancelCallback = function (D) {
            D.callback = null;
          }),
          (u.unstable_continueExecution = function () {
            Y || V || ((Y = !0), Ae(he));
          }),
          (u.unstable_forceFrameRate = function (D) {
            0 > D || 125 < D
              ? console.error(
                  "forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported",
                )
              : (Ce = 0 < D ? Math.floor(1e3 / D) : 5);
          }),
          (u.unstable_getCurrentPriorityLevel = function () {
            return F;
          }),
          (u.unstable_getFirstCallbackNode = function () {
            return a(k);
          }),
          (u.unstable_next = function (D) {
            switch (F) {
              case 1:
              case 2:
              case 3:
                var X = 3;
                break;
              default:
                X = F;
            }
            var j = F;
            F = X;
            try {
              return D();
            } finally {
              F = j;
            }
          }),
          (u.unstable_pauseExecution = function () {}),
          (u.unstable_requestPaint = function () {}),
          (u.unstable_runWithPriority = function (D, X) {
            switch (D) {
              case 1:
              case 2:
              case 3:
              case 4:
              case 5:
                break;
              default:
                D = 3;
            }
            var j = F;
            F = D;
            try {
              return X();
            } finally {
              F = j;
            }
          }),
          (u.unstable_scheduleCallback = function (D, X, j) {
            var m = u.unstable_now();
            switch (
              (typeof j == "object" && j !== null
                ? ((j = j.delay),
                  (j = typeof j == "number" && 0 < j ? m + j : m))
                : (j = m),
              D)
            ) {
              case 1:
                var R = -1;
                break;
              case 2:
                R = 250;
                break;
              case 5:
                R = 1073741823;
                break;
              case 4:
                R = 1e4;
                break;
              default:
                R = 5e3;
            }
            return (
              (R = j + R),
              (D = {
                id: P++,
                callback: X,
                priorityLevel: D,
                startTime: j,
                expirationTime: R,
                sortIndex: -1,
              }),
              j > m
                ? ((D.sortIndex = j),
                  s(x, D),
                  a(k) === null &&
                    D === a(x) &&
                    (H ? (W(Te), (Te = -1)) : (H = !0), ye(ue, j - m)))
                : ((D.sortIndex = R), s(k, D), Y || V || ((Y = !0), Ae(he))),
              D
            );
          }),
          (u.unstable_shouldYield = vt),
          (u.unstable_wrapCallback = function (D) {
            var X = F;
            return function () {
              var j = F;
              F = X;
              try {
                return D.apply(this, arguments);
              } finally {
                F = j;
              }
            };
          }));
      })(Yu)),
    Yu
  );
}
var ac;
function Id() {
  return (ac || ((ac = 1), (Ku.exports = Fd())), Ku.exports);
}
/**
 * @license React
 * react-dom.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var sc;
function jd() {
  if (sc) return Ke;
  sc = 1;
  var u = ei(),
    s = Id();
  function a(e) {
    for (
      var t = "https://reactjs.org/docs/error-decoder.html?invariant=" + e,
        n = 1;
      n < arguments.length;
      n++
    )
      t += "&args[]=" + encodeURIComponent(arguments[n]);
    return (
      "Minified React error #" +
      e +
      "; visit " +
      t +
      " for the full message or use the non-minified dev environment for full errors and additional helpful warnings."
    );
  }
  var f = new Set(),
    p = {};
  function v(e, t) {
    (S(e, t), S(e + "Capture", t));
  }
  function S(e, t) {
    for (p[e] = t, e = 0; e < t.length; e++) f.add(t[e]);
  }
  var E = !(
      typeof window > "u" ||
      typeof window.document > "u" ||
      typeof window.document.createElement > "u"
    ),
    k = Object.prototype.hasOwnProperty,
    x =
      /^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/,
    P = {},
    z = {};
  function F(e) {
    return k.call(z, e)
      ? !0
      : k.call(P, e)
        ? !1
        : x.test(e)
          ? (z[e] = !0)
          : ((P[e] = !0), !1);
  }
  function V(e, t, n, r) {
    if (n !== null && n.type === 0) return !1;
    switch (typeof t) {
      case "function":
      case "symbol":
        return !0;
      case "boolean":
        return r
          ? !1
          : n !== null
            ? !n.acceptsBooleans
            : ((e = e.toLowerCase().slice(0, 5)),
              e !== "data-" && e !== "aria-");
      default:
        return !1;
    }
  }
  function Y(e, t, n, r) {
    if (t === null || typeof t > "u" || V(e, t, n, r)) return !0;
    if (r) return !1;
    if (n !== null)
      switch (n.type) {
        case 3:
          return !t;
        case 4:
          return t === !1;
        case 5:
          return isNaN(t);
        case 6:
          return isNaN(t) || 1 > t;
      }
    return !1;
  }
  function H(e, t, n, r, l, o, i) {
    ((this.acceptsBooleans = t === 2 || t === 3 || t === 4),
      (this.attributeName = r),
      (this.attributeNamespace = l),
      (this.mustUseProperty = n),
      (this.propertyName = e),
      (this.type = t),
      (this.sanitizeURL = o),
      (this.removeEmptyString = i));
  }
  var O = {};
  ("children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style"
    .split(" ")
    .forEach(function (e) {
      O[e] = new H(e, 0, !1, e, null, !1, !1);
    }),
    [
      ["acceptCharset", "accept-charset"],
      ["className", "class"],
      ["htmlFor", "for"],
      ["httpEquiv", "http-equiv"],
    ].forEach(function (e) {
      var t = e[0];
      O[t] = new H(t, 1, !1, e[1], null, !1, !1);
    }),
    ["contentEditable", "draggable", "spellCheck", "value"].forEach(
      function (e) {
        O[e] = new H(e, 2, !1, e.toLowerCase(), null, !1, !1);
      },
    ),
    [
      "autoReverse",
      "externalResourcesRequired",
      "focusable",
      "preserveAlpha",
    ].forEach(function (e) {
      O[e] = new H(e, 2, !1, e, null, !1, !1);
    }),
    "allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope"
      .split(" ")
      .forEach(function (e) {
        O[e] = new H(e, 3, !1, e.toLowerCase(), null, !1, !1);
      }),
    ["checked", "multiple", "muted", "selected"].forEach(function (e) {
      O[e] = new H(e, 3, !0, e, null, !1, !1);
    }),
    ["capture", "download"].forEach(function (e) {
      O[e] = new H(e, 4, !1, e, null, !1, !1);
    }),
    ["cols", "rows", "size", "span"].forEach(function (e) {
      O[e] = new H(e, 6, !1, e, null, !1, !1);
    }),
    ["rowSpan", "start"].forEach(function (e) {
      O[e] = new H(e, 5, !1, e.toLowerCase(), null, !1, !1);
    }));
  var W = /[\-:]([a-z])/g;
  function A(e) {
    return e[1].toUpperCase();
  }
  ("accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height"
    .split(" ")
    .forEach(function (e) {
      var t = e.replace(W, A);
      O[t] = new H(t, 1, !1, e, null, !1, !1);
    }),
    "xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type"
      .split(" ")
      .forEach(function (e) {
        var t = e.replace(W, A);
        O[t] = new H(t, 1, !1, e, "http://www.w3.org/1999/xlink", !1, !1);
      }),
    ["xml:base", "xml:lang", "xml:space"].forEach(function (e) {
      var t = e.replace(W, A);
      O[t] = new H(t, 1, !1, e, "http://www.w3.org/XML/1998/namespace", !1, !1);
    }),
    ["tabIndex", "crossOrigin"].forEach(function (e) {
      O[e] = new H(e, 1, !1, e.toLowerCase(), null, !1, !1);
    }),
    (O.xlinkHref = new H(
      "xlinkHref",
      1,
      !1,
      "xlink:href",
      "http://www.w3.org/1999/xlink",
      !0,
      !1,
    )),
    ["src", "href", "action", "formAction"].forEach(function (e) {
      O[e] = new H(e, 1, !1, e.toLowerCase(), null, !0, !0);
    }));
  function Z(e, t, n, r) {
    var l = O.hasOwnProperty(t) ? O[t] : null;
    (l !== null
      ? l.type !== 0
      : r ||
        !(2 < t.length) ||
        (t[0] !== "o" && t[0] !== "O") ||
        (t[1] !== "n" && t[1] !== "N")) &&
      (Y(t, n, l, r) && (n = null),
      r || l === null
        ? F(t) &&
          (n === null ? e.removeAttribute(t) : e.setAttribute(t, "" + n))
        : l.mustUseProperty
          ? (e[l.propertyName] = n === null ? (l.type === 3 ? !1 : "") : n)
          : ((t = l.attributeName),
            (r = l.attributeNamespace),
            n === null
              ? e.removeAttribute(t)
              : ((l = l.type),
                (n = l === 3 || (l === 4 && n === !0) ? "" : "" + n),
                r ? e.setAttributeNS(r, t, n) : e.setAttribute(t, n))));
  }
  var ue = u.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED,
    he = Symbol.for("react.element"),
    ke = Symbol.for("react.portal"),
    Ee = Symbol.for("react.fragment"),
    Te = Symbol.for("react.strict_mode"),
    Ce = Symbol.for("react.profiler"),
    De = Symbol.for("react.provider"),
    vt = Symbol.for("react.context"),
    yt = Symbol.for("react.forward_ref"),
    Ye = Symbol.for("react.suspense"),
    ut = Symbol.for("react.suspense_list"),
    gt = Symbol.for("react.memo"),
    Ae = Symbol.for("react.lazy"),
    ye = Symbol.for("react.offscreen"),
    D = Symbol.iterator;
  function X(e) {
    return e === null || typeof e != "object"
      ? null
      : ((e = (D && e[D]) || e["@@iterator"]),
        typeof e == "function" ? e : null);
  }
  var j = Object.assign,
    m;
  function R(e) {
    if (m === void 0)
      try {
        throw Error();
      } catch (n) {
        var t = n.stack.trim().match(/\n( *(at )?)/);
        m = (t && t[1]) || "";
      }
    return (
      `
` +
      m +
      e
    );
  }
  var J = !1;
  function b(e, t) {
    if (!e || J) return "";
    J = !0;
    var n = Error.prepareStackTrace;
    Error.prepareStackTrace = void 0;
    try {
      if (t)
        if (
          ((t = function () {
            throw Error();
          }),
          Object.defineProperty(t.prototype, "props", {
            set: function () {
              throw Error();
            },
          }),
          typeof Reflect == "object" && Reflect.construct)
        ) {
          try {
            Reflect.construct(t, []);
          } catch (w) {
            var r = w;
          }
          Reflect.construct(e, [], t);
        } else {
          try {
            t.call();
          } catch (w) {
            r = w;
          }
          e.call(t.prototype);
        }
      else {
        try {
          throw Error();
        } catch (w) {
          r = w;
        }
        e();
      }
    } catch (w) {
      if (w && r && typeof w.stack == "string") {
        for (
          var l = w.stack.split(`
`),
            o = r.stack.split(`
`),
            i = l.length - 1,
            c = o.length - 1;
          1 <= i && 0 <= c && l[i] !== o[c];
        )
          c--;
        for (; 1 <= i && 0 <= c; i--, c--)
          if (l[i] !== o[c]) {
            if (i !== 1 || c !== 1)
              do
                if ((i--, c--, 0 > c || l[i] !== o[c])) {
                  var d =
                    `
` + l[i].replace(" at new ", " at ");
                  return (
                    e.displayName &&
                      d.includes("<anonymous>") &&
                      (d = d.replace("<anonymous>", e.displayName)),
                    d
                  );
                }
              while (1 <= i && 0 <= c);
            break;
          }
      }
    } finally {
      ((J = !1), (Error.prepareStackTrace = n));
    }
    return (e = e ? e.displayName || e.name : "") ? R(e) : "";
  }
  function te(e) {
    switch (e.tag) {
      case 5:
        return R(e.type);
      case 16:
        return R("Lazy");
      case 13:
        return R("Suspense");
      case 19:
        return R("SuspenseList");
      case 0:
      case 2:
      case 15:
        return ((e = b(e.type, !1)), e);
      case 11:
        return ((e = b(e.type.render, !1)), e);
      case 1:
        return ((e = b(e.type, !0)), e);
      default:
        return "";
    }
  }
  function ne(e) {
    if (e == null) return null;
    if (typeof e == "function") return e.displayName || e.name || null;
    if (typeof e == "string") return e;
    switch (e) {
      case Ee:
        return "Fragment";
      case ke:
        return "Portal";
      case Ce:
        return "Profiler";
      case Te:
        return "StrictMode";
      case Ye:
        return "Suspense";
      case ut:
        return "SuspenseList";
    }
    if (typeof e == "object")
      switch (e.$$typeof) {
        case vt:
          return (e.displayName || "Context") + ".Consumer";
        case De:
          return (e._context.displayName || "Context") + ".Provider";
        case yt:
          var t = e.render;
          return (
            (e = e.displayName),
            e ||
              ((e = t.displayName || t.name || ""),
              (e = e !== "" ? "ForwardRef(" + e + ")" : "ForwardRef")),
            e
          );
        case gt:
          return (
            (t = e.displayName || null),
            t !== null ? t : ne(e.type) || "Memo"
          );
        case Ae:
          ((t = e._payload), (e = e._init));
          try {
            return ne(e(t));
          } catch {}
      }
    return null;
  }
  function ie(e) {
    var t = e.type;
    switch (e.tag) {
      case 24:
        return "Cache";
      case 9:
        return (t.displayName || "Context") + ".Consumer";
      case 10:
        return (t._context.displayName || "Context") + ".Provider";
      case 18:
        return "DehydratedFragment";
      case 11:
        return (
          (e = t.render),
          (e = e.displayName || e.name || ""),
          t.displayName || (e !== "" ? "ForwardRef(" + e + ")" : "ForwardRef")
        );
      case 7:
        return "Fragment";
      case 5:
        return t;
      case 4:
        return "Portal";
      case 3:
        return "Root";
      case 6:
        return "Text";
      case 16:
        return ne(t);
      case 8:
        return t === Te ? "StrictMode" : "Mode";
      case 22:
        return "Offscreen";
      case 12:
        return "Profiler";
      case 21:
        return "Scope";
      case 13:
        return "Suspense";
      case 19:
        return "SuspenseList";
      case 25:
        return "TracingMarker";
      case 1:
      case 0:
      case 17:
      case 2:
      case 14:
      case 15:
        if (typeof t == "function") return t.displayName || t.name || null;
        if (typeof t == "string") return t;
    }
    return null;
  }
  function le(e) {
    switch (typeof e) {
      case "boolean":
      case "number":
      case "string":
      case "undefined":
        return e;
      case "object":
        return e;
      default:
        return "";
    }
  }
  function fe(e) {
    var t = e.type;
    return (
      (e = e.nodeName) &&
      e.toLowerCase() === "input" &&
      (t === "checkbox" || t === "radio")
    );
  }
  function Xe(e) {
    var t = fe(e) ? "checked" : "value",
      n = Object.getOwnPropertyDescriptor(e.constructor.prototype, t),
      r = "" + e[t];
    if (
      !e.hasOwnProperty(t) &&
      typeof n < "u" &&
      typeof n.get == "function" &&
      typeof n.set == "function"
    ) {
      var l = n.get,
        o = n.set;
      return (
        Object.defineProperty(e, t, {
          configurable: !0,
          get: function () {
            return l.call(this);
          },
          set: function (i) {
            ((r = "" + i), o.call(this, i));
          },
        }),
        Object.defineProperty(e, t, { enumerable: n.enumerable }),
        {
          getValue: function () {
            return r;
          },
          setValue: function (i) {
            r = "" + i;
          },
          stopTracking: function () {
            ((e._valueTracker = null), delete e[t]);
          },
        }
      );
    }
  }
  function Or(e) {
    e._valueTracker || (e._valueTracker = Xe(e));
  }
  function si(e) {
    if (!e) return !1;
    var t = e._valueTracker;
    if (!t) return !0;
    var n = t.getValue(),
      r = "";
    return (
      e && (r = fe(e) ? (e.checked ? "true" : "false") : e.value),
      (e = r),
      e !== n ? (t.setValue(e), !0) : !1
    );
  }
  function Dr(e) {
    if (
      ((e = e || (typeof document < "u" ? document : void 0)), typeof e > "u")
    )
      return null;
    try {
      return e.activeElement || e.body;
    } catch {
      return e.body;
    }
  }
  function Gl(e, t) {
    var n = t.checked;
    return j({}, t, {
      defaultChecked: void 0,
      defaultValue: void 0,
      value: void 0,
      checked: n ?? e._wrapperState.initialChecked,
    });
  }
  function ci(e, t) {
    var n = t.defaultValue == null ? "" : t.defaultValue,
      r = t.checked != null ? t.checked : t.defaultChecked;
    ((n = le(t.value != null ? t.value : n)),
      (e._wrapperState = {
        initialChecked: r,
        initialValue: n,
        controlled:
          t.type === "checkbox" || t.type === "radio"
            ? t.checked != null
            : t.value != null,
      }));
  }
  function fi(e, t) {
    ((t = t.checked), t != null && Z(e, "checked", t, !1));
  }
  function Jl(e, t) {
    fi(e, t);
    var n = le(t.value),
      r = t.type;
    if (n != null)
      r === "number"
        ? ((n === 0 && e.value === "") || e.value != n) && (e.value = "" + n)
        : e.value !== "" + n && (e.value = "" + n);
    else if (r === "submit" || r === "reset") {
      e.removeAttribute("value");
      return;
    }
    (t.hasOwnProperty("value")
      ? Zl(e, t.type, n)
      : t.hasOwnProperty("defaultValue") && Zl(e, t.type, le(t.defaultValue)),
      t.checked == null &&
        t.defaultChecked != null &&
        (e.defaultChecked = !!t.defaultChecked));
  }
  function di(e, t, n) {
    if (t.hasOwnProperty("value") || t.hasOwnProperty("defaultValue")) {
      var r = t.type;
      if (!(
        (r !== "submit" && r !== "reset") ||
        (t.value !== void 0 && t.value !== null)
      ))
        return;
      ((t = "" + e._wrapperState.initialValue),
        n || t === e.value || (e.value = t),
        (e.defaultValue = t));
    }
    ((n = e.name),
      n !== "" && (e.name = ""),
      (e.defaultChecked = !!e._wrapperState.initialChecked),
      n !== "" && (e.name = n));
  }
  function Zl(e, t, n) {
    (t !== "number" || Dr(e.ownerDocument) !== e) &&
      (n == null
        ? (e.defaultValue = "" + e._wrapperState.initialValue)
        : e.defaultValue !== "" + n && (e.defaultValue = "" + n));
  }
  var Hn = Array.isArray;
  function hn(e, t, n, r) {
    if (((e = e.options), t)) {
      t = {};
      for (var l = 0; l < n.length; l++) t["$" + n[l]] = !0;
      for (n = 0; n < e.length; n++)
        ((l = t.hasOwnProperty("$" + e[n].value)),
          e[n].selected !== l && (e[n].selected = l),
          l && r && (e[n].defaultSelected = !0));
    } else {
      for (n = "" + le(n), t = null, l = 0; l < e.length; l++) {
        if (e[l].value === n) {
          ((e[l].selected = !0), r && (e[l].defaultSelected = !0));
          return;
        }
        t !== null || e[l].disabled || (t = e[l]);
      }
      t !== null && (t.selected = !0);
    }
  }
  function ql(e, t) {
    if (t.dangerouslySetInnerHTML != null) throw Error(a(91));
    return j({}, t, {
      value: void 0,
      defaultValue: void 0,
      children: "" + e._wrapperState.initialValue,
    });
  }
  function pi(e, t) {
    var n = t.value;
    if (n == null) {
      if (((n = t.children), (t = t.defaultValue), n != null)) {
        if (t != null) throw Error(a(92));
        if (Hn(n)) {
          if (1 < n.length) throw Error(a(93));
          n = n[0];
        }
        t = n;
      }
      (t == null && (t = ""), (n = t));
    }
    e._wrapperState = { initialValue: le(n) };
  }
  function hi(e, t) {
    var n = le(t.value),
      r = le(t.defaultValue);
    (n != null &&
      ((n = "" + n),
      n !== e.value && (e.value = n),
      t.defaultValue == null && e.defaultValue !== n && (e.defaultValue = n)),
      r != null && (e.defaultValue = "" + r));
  }
  function mi(e) {
    var t = e.textContent;
    t === e._wrapperState.initialValue &&
      t !== "" &&
      t !== null &&
      (e.value = t);
  }
  function vi(e) {
    switch (e) {
      case "svg":
        return "http://www.w3.org/2000/svg";
      case "math":
        return "http://www.w3.org/1998/Math/MathML";
      default:
        return "http://www.w3.org/1999/xhtml";
    }
  }
  function bl(e, t) {
    return e == null || e === "http://www.w3.org/1999/xhtml"
      ? vi(t)
      : e === "http://www.w3.org/2000/svg" && t === "foreignObject"
        ? "http://www.w3.org/1999/xhtml"
        : e;
  }
  var Mr,
    yi = (function (e) {
      return typeof MSApp < "u" && MSApp.execUnsafeLocalFunction
        ? function (t, n, r, l) {
            MSApp.execUnsafeLocalFunction(function () {
              return e(t, n, r, l);
            });
          }
        : e;
    })(function (e, t) {
      if (e.namespaceURI !== "http://www.w3.org/2000/svg" || "innerHTML" in e)
        e.innerHTML = t;
      else {
        for (
          Mr = Mr || document.createElement("div"),
            Mr.innerHTML = "<svg>" + t.valueOf().toString() + "</svg>",
            t = Mr.firstChild;
          e.firstChild;
        )
          e.removeChild(e.firstChild);
        for (; t.firstChild;) e.appendChild(t.firstChild);
      }
    });
  function Wn(e, t) {
    if (t) {
      var n = e.firstChild;
      if (n && n === e.lastChild && n.nodeType === 3) {
        n.nodeValue = t;
        return;
      }
    }
    e.textContent = t;
  }
  var Vn = {
      animationIterationCount: !0,
      aspectRatio: !0,
      borderImageOutset: !0,
      borderImageSlice: !0,
      borderImageWidth: !0,
      boxFlex: !0,
      boxFlexGroup: !0,
      boxOrdinalGroup: !0,
      columnCount: !0,
      columns: !0,
      flex: !0,
      flexGrow: !0,
      flexPositive: !0,
      flexShrink: !0,
      flexNegative: !0,
      flexOrder: !0,
      gridArea: !0,
      gridRow: !0,
      gridRowEnd: !0,
      gridRowSpan: !0,
      gridRowStart: !0,
      gridColumn: !0,
      gridColumnEnd: !0,
      gridColumnSpan: !0,
      gridColumnStart: !0,
      fontWeight: !0,
      lineClamp: !0,
      lineHeight: !0,
      opacity: !0,
      order: !0,
      orphans: !0,
      tabSize: !0,
      widows: !0,
      zIndex: !0,
      zoom: !0,
      fillOpacity: !0,
      floodOpacity: !0,
      stopOpacity: !0,
      strokeDasharray: !0,
      strokeDashoffset: !0,
      strokeMiterlimit: !0,
      strokeOpacity: !0,
      strokeWidth: !0,
    },
    Dc = ["Webkit", "ms", "Moz", "O"];
  Object.keys(Vn).forEach(function (e) {
    Dc.forEach(function (t) {
      ((t = t + e.charAt(0).toUpperCase() + e.substring(1)), (Vn[t] = Vn[e]));
    });
  });
  function gi(e, t, n) {
    return t == null || typeof t == "boolean" || t === ""
      ? ""
      : n || typeof t != "number" || t === 0 || (Vn.hasOwnProperty(e) && Vn[e])
        ? ("" + t).trim()
        : t + "px";
  }
  function wi(e, t) {
    e = e.style;
    for (var n in t)
      if (t.hasOwnProperty(n)) {
        var r = n.indexOf("--") === 0,
          l = gi(n, t[n], r);
        (n === "float" && (n = "cssFloat"),
          r ? e.setProperty(n, l) : (e[n] = l));
      }
  }
  var Mc = j(
    { menuitem: !0 },
    {
      area: !0,
      base: !0,
      br: !0,
      col: !0,
      embed: !0,
      hr: !0,
      img: !0,
      input: !0,
      keygen: !0,
      link: !0,
      meta: !0,
      param: !0,
      source: !0,
      track: !0,
      wbr: !0,
    },
  );
  function eo(e, t) {
    if (t) {
      if (Mc[e] && (t.children != null || t.dangerouslySetInnerHTML != null))
        throw Error(a(137, e));
      if (t.dangerouslySetInnerHTML != null) {
        if (t.children != null) throw Error(a(60));
        if (
          typeof t.dangerouslySetInnerHTML != "object" ||
          !("__html" in t.dangerouslySetInnerHTML)
        )
          throw Error(a(61));
      }
      if (t.style != null && typeof t.style != "object") throw Error(a(62));
    }
  }
  function to(e, t) {
    if (e.indexOf("-") === -1) return typeof t.is == "string";
    switch (e) {
      case "annotation-xml":
      case "color-profile":
      case "font-face":
      case "font-face-src":
      case "font-face-uri":
      case "font-face-format":
      case "font-face-name":
      case "missing-glyph":
        return !1;
      default:
        return !0;
    }
  }
  var no = null;
  function ro(e) {
    return (
      (e = e.target || e.srcElement || window),
      e.correspondingUseElement && (e = e.correspondingUseElement),
      e.nodeType === 3 ? e.parentNode : e
    );
  }
  var lo = null,
    mn = null,
    vn = null;
  function Si(e) {
    if ((e = dr(e))) {
      if (typeof lo != "function") throw Error(a(280));
      var t = e.stateNode;
      t && ((t = rl(t)), lo(e.stateNode, e.type, t));
    }
  }
  function ki(e) {
    mn ? (vn ? vn.push(e) : (vn = [e])) : (mn = e);
  }
  function Ei() {
    if (mn) {
      var e = mn,
        t = vn;
      if (((vn = mn = null), Si(e), t)) for (e = 0; e < t.length; e++) Si(t[e]);
    }
  }
  function Ci(e, t) {
    return e(t);
  }
  function xi() {}
  var oo = !1;
  function Pi(e, t, n) {
    if (oo) return e(t, n);
    oo = !0;
    try {
      return Ci(e, t, n);
    } finally {
      ((oo = !1), (mn !== null || vn !== null) && (xi(), Ei()));
    }
  }
  function Qn(e, t) {
    var n = e.stateNode;
    if (n === null) return null;
    var r = rl(n);
    if (r === null) return null;
    n = r[t];
    e: switch (t) {
      case "onClick":
      case "onClickCapture":
      case "onDoubleClick":
      case "onDoubleClickCapture":
      case "onMouseDown":
      case "onMouseDownCapture":
      case "onMouseMove":
      case "onMouseMoveCapture":
      case "onMouseUp":
      case "onMouseUpCapture":
      case "onMouseEnter":
        ((r = !r.disabled) ||
          ((e = e.type),
          (r = !(
            e === "button" ||
            e === "input" ||
            e === "select" ||
            e === "textarea"
          ))),
          (e = !r));
        break e;
      default:
        e = !1;
    }
    if (e) return null;
    if (n && typeof n != "function") throw Error(a(231, t, typeof n));
    return n;
  }
  var uo = !1;
  if (E)
    try {
      var Kn = {};
      (Object.defineProperty(Kn, "passive", {
        get: function () {
          uo = !0;
        },
      }),
        window.addEventListener("test", Kn, Kn),
        window.removeEventListener("test", Kn, Kn));
    } catch {
      uo = !1;
    }
  function Fc(e, t, n, r, l, o, i, c, d) {
    var w = Array.prototype.slice.call(arguments, 3);
    try {
      t.apply(n, w);
    } catch (L) {
      this.onError(L);
    }
  }
  var Yn = !1,
    Fr = null,
    Ir = !1,
    io = null,
    Ic = {
      onError: function (e) {
        ((Yn = !0), (Fr = e));
      },
    };
  function jc(e, t, n, r, l, o, i, c, d) {
    ((Yn = !1), (Fr = null), Fc.apply(Ic, arguments));
  }
  function Uc(e, t, n, r, l, o, i, c, d) {
    if ((jc.apply(this, arguments), Yn)) {
      if (Yn) {
        var w = Fr;
        ((Yn = !1), (Fr = null));
      } else throw Error(a(198));
      Ir || ((Ir = !0), (io = w));
    }
  }
  function en(e) {
    var t = e,
      n = e;
    if (e.alternate) for (; t.return;) t = t.return;
    else {
      e = t;
      do ((t = e), (t.flags & 4098) !== 0 && (n = t.return), (e = t.return));
      while (e);
    }
    return t.tag === 3 ? n : null;
  }
  function _i(e) {
    if (e.tag === 13) {
      var t = e.memoizedState;
      if (
        (t === null && ((e = e.alternate), e !== null && (t = e.memoizedState)),
        t !== null)
      )
        return t.dehydrated;
    }
    return null;
  }
  function Ri(e) {
    if (en(e) !== e) throw Error(a(188));
  }
  function $c(e) {
    var t = e.alternate;
    if (!t) {
      if (((t = en(e)), t === null)) throw Error(a(188));
      return t !== e ? null : e;
    }
    for (var n = e, r = t; ;) {
      var l = n.return;
      if (l === null) break;
      var o = l.alternate;
      if (o === null) {
        if (((r = l.return), r !== null)) {
          n = r;
          continue;
        }
        break;
      }
      if (l.child === o.child) {
        for (o = l.child; o;) {
          if (o === n) return (Ri(l), e);
          if (o === r) return (Ri(l), t);
          o = o.sibling;
        }
        throw Error(a(188));
      }
      if (n.return !== r.return) ((n = l), (r = o));
      else {
        for (var i = !1, c = l.child; c;) {
          if (c === n) {
            ((i = !0), (n = l), (r = o));
            break;
          }
          if (c === r) {
            ((i = !0), (r = l), (n = o));
            break;
          }
          c = c.sibling;
        }
        if (!i) {
          for (c = o.child; c;) {
            if (c === n) {
              ((i = !0), (n = o), (r = l));
              break;
            }
            if (c === r) {
              ((i = !0), (r = o), (n = l));
              break;
            }
            c = c.sibling;
          }
          if (!i) throw Error(a(189));
        }
      }
      if (n.alternate !== r) throw Error(a(190));
    }
    if (n.tag !== 3) throw Error(a(188));
    return n.stateNode.current === n ? e : t;
  }
  function Li(e) {
    return ((e = $c(e)), e !== null ? Ni(e) : null);
  }
  function Ni(e) {
    if (e.tag === 5 || e.tag === 6) return e;
    for (e = e.child; e !== null;) {
      var t = Ni(e);
      if (t !== null) return t;
      e = e.sibling;
    }
    return null;
  }
  var Ti = s.unstable_scheduleCallback,
    zi = s.unstable_cancelCallback,
    Ac = s.unstable_shouldYield,
    Bc = s.unstable_requestPaint,
    we = s.unstable_now,
    Hc = s.unstable_getCurrentPriorityLevel,
    ao = s.unstable_ImmediatePriority,
    Oi = s.unstable_UserBlockingPriority,
    jr = s.unstable_NormalPriority,
    Wc = s.unstable_LowPriority,
    Di = s.unstable_IdlePriority,
    Ur = null,
    wt = null;
  function Vc(e) {
    if (wt && typeof wt.onCommitFiberRoot == "function")
      try {
        wt.onCommitFiberRoot(Ur, e, void 0, (e.current.flags & 128) === 128);
      } catch {}
  }
  var it = Math.clz32 ? Math.clz32 : Yc,
    Qc = Math.log,
    Kc = Math.LN2;
  function Yc(e) {
    return ((e >>>= 0), e === 0 ? 32 : (31 - ((Qc(e) / Kc) | 0)) | 0);
  }
  var $r = 64,
    Ar = 4194304;
  function Xn(e) {
    switch (e & -e) {
      case 1:
        return 1;
      case 2:
        return 2;
      case 4:
        return 4;
      case 8:
        return 8;
      case 16:
        return 16;
      case 32:
        return 32;
      case 64:
      case 128:
      case 256:
      case 512:
      case 1024:
      case 2048:
      case 4096:
      case 8192:
      case 16384:
      case 32768:
      case 65536:
      case 131072:
      case 262144:
      case 524288:
      case 1048576:
      case 2097152:
        return e & 4194240;
      case 4194304:
      case 8388608:
      case 16777216:
      case 33554432:
      case 67108864:
        return e & 130023424;
      case 134217728:
        return 134217728;
      case 268435456:
        return 268435456;
      case 536870912:
        return 536870912;
      case 1073741824:
        return 1073741824;
      default:
        return e;
    }
  }
  function Br(e, t) {
    var n = e.pendingLanes;
    if (n === 0) return 0;
    var r = 0,
      l = e.suspendedLanes,
      o = e.pingedLanes,
      i = n & 268435455;
    if (i !== 0) {
      var c = i & ~l;
      c !== 0 ? (r = Xn(c)) : ((o &= i), o !== 0 && (r = Xn(o)));
    } else ((i = n & ~l), i !== 0 ? (r = Xn(i)) : o !== 0 && (r = Xn(o)));
    if (r === 0) return 0;
    if (
      t !== 0 &&
      t !== r &&
      (t & l) === 0 &&
      ((l = r & -r), (o = t & -t), l >= o || (l === 16 && (o & 4194240) !== 0))
    )
      return t;
    if (((r & 4) !== 0 && (r |= n & 16), (t = e.entangledLanes), t !== 0))
      for (e = e.entanglements, t &= r; 0 < t;)
        ((n = 31 - it(t)), (l = 1 << n), (r |= e[n]), (t &= ~l));
    return r;
  }
  function Xc(e, t) {
    switch (e) {
      case 1:
      case 2:
      case 4:
        return t + 250;
      case 8:
      case 16:
      case 32:
      case 64:
      case 128:
      case 256:
      case 512:
      case 1024:
      case 2048:
      case 4096:
      case 8192:
      case 16384:
      case 32768:
      case 65536:
      case 131072:
      case 262144:
      case 524288:
      case 1048576:
      case 2097152:
        return t + 5e3;
      case 4194304:
      case 8388608:
      case 16777216:
      case 33554432:
      case 67108864:
        return -1;
      case 134217728:
      case 268435456:
      case 536870912:
      case 1073741824:
        return -1;
      default:
        return -1;
    }
  }
  function Gc(e, t) {
    for (
      var n = e.suspendedLanes,
        r = e.pingedLanes,
        l = e.expirationTimes,
        o = e.pendingLanes;
      0 < o;
    ) {
      var i = 31 - it(o),
        c = 1 << i,
        d = l[i];
      (d === -1
        ? ((c & n) === 0 || (c & r) !== 0) && (l[i] = Xc(c, t))
        : d <= t && (e.expiredLanes |= c),
        (o &= ~c));
    }
  }
  function so(e) {
    return (
      (e = e.pendingLanes & -1073741825),
      e !== 0 ? e : e & 1073741824 ? 1073741824 : 0
    );
  }
  function Mi() {
    var e = $r;
    return (($r <<= 1), ($r & 4194240) === 0 && ($r = 64), e);
  }
  function co(e) {
    for (var t = [], n = 0; 31 > n; n++) t.push(e);
    return t;
  }
  function Gn(e, t, n) {
    ((e.pendingLanes |= t),
      t !== 536870912 && ((e.suspendedLanes = 0), (e.pingedLanes = 0)),
      (e = e.eventTimes),
      (t = 31 - it(t)),
      (e[t] = n));
  }
  function Jc(e, t) {
    var n = e.pendingLanes & ~t;
    ((e.pendingLanes = t),
      (e.suspendedLanes = 0),
      (e.pingedLanes = 0),
      (e.expiredLanes &= t),
      (e.mutableReadLanes &= t),
      (e.entangledLanes &= t),
      (t = e.entanglements));
    var r = e.eventTimes;
    for (e = e.expirationTimes; 0 < n;) {
      var l = 31 - it(n),
        o = 1 << l;
      ((t[l] = 0), (r[l] = -1), (e[l] = -1), (n &= ~o));
    }
  }
  function fo(e, t) {
    var n = (e.entangledLanes |= t);
    for (e = e.entanglements; n;) {
      var r = 31 - it(n),
        l = 1 << r;
      ((l & t) | (e[r] & t) && (e[r] |= t), (n &= ~l));
    }
  }
  var oe = 0;
  function Fi(e) {
    return (
      (e &= -e),
      1 < e ? (4 < e ? ((e & 268435455) !== 0 ? 16 : 536870912) : 4) : 1
    );
  }
  var Ii,
    po,
    ji,
    Ui,
    $i,
    ho = !1,
    Hr = [],
    Ft = null,
    It = null,
    jt = null,
    Jn = new Map(),
    Zn = new Map(),
    Ut = [],
    Zc =
      "mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(
        " ",
      );
  function Ai(e, t) {
    switch (e) {
      case "focusin":
      case "focusout":
        Ft = null;
        break;
      case "dragenter":
      case "dragleave":
        It = null;
        break;
      case "mouseover":
      case "mouseout":
        jt = null;
        break;
      case "pointerover":
      case "pointerout":
        Jn.delete(t.pointerId);
        break;
      case "gotpointercapture":
      case "lostpointercapture":
        Zn.delete(t.pointerId);
    }
  }
  function qn(e, t, n, r, l, o) {
    return e === null || e.nativeEvent !== o
      ? ((e = {
          blockedOn: t,
          domEventName: n,
          eventSystemFlags: r,
          nativeEvent: o,
          targetContainers: [l],
        }),
        t !== null && ((t = dr(t)), t !== null && po(t)),
        e)
      : ((e.eventSystemFlags |= r),
        (t = e.targetContainers),
        l !== null && t.indexOf(l) === -1 && t.push(l),
        e);
  }
  function qc(e, t, n, r, l) {
    switch (t) {
      case "focusin":
        return ((Ft = qn(Ft, e, t, n, r, l)), !0);
      case "dragenter":
        return ((It = qn(It, e, t, n, r, l)), !0);
      case "mouseover":
        return ((jt = qn(jt, e, t, n, r, l)), !0);
      case "pointerover":
        var o = l.pointerId;
        return (Jn.set(o, qn(Jn.get(o) || null, e, t, n, r, l)), !0);
      case "gotpointercapture":
        return (
          (o = l.pointerId),
          Zn.set(o, qn(Zn.get(o) || null, e, t, n, r, l)),
          !0
        );
    }
    return !1;
  }
  function Bi(e) {
    var t = tn(e.target);
    if (t !== null) {
      var n = en(t);
      if (n !== null) {
        if (((t = n.tag), t === 13)) {
          if (((t = _i(n)), t !== null)) {
            ((e.blockedOn = t),
              $i(e.priority, function () {
                ji(n);
              }));
            return;
          }
        } else if (t === 3 && n.stateNode.current.memoizedState.isDehydrated) {
          e.blockedOn = n.tag === 3 ? n.stateNode.containerInfo : null;
          return;
        }
      }
    }
    e.blockedOn = null;
  }
  function Wr(e) {
    if (e.blockedOn !== null) return !1;
    for (var t = e.targetContainers; 0 < t.length;) {
      var n = vo(e.domEventName, e.eventSystemFlags, t[0], e.nativeEvent);
      if (n === null) {
        n = e.nativeEvent;
        var r = new n.constructor(n.type, n);
        ((no = r), n.target.dispatchEvent(r), (no = null));
      } else return ((t = dr(n)), t !== null && po(t), (e.blockedOn = n), !1);
      t.shift();
    }
    return !0;
  }
  function Hi(e, t, n) {
    Wr(e) && n.delete(t);
  }
  function bc() {
    ((ho = !1),
      Ft !== null && Wr(Ft) && (Ft = null),
      It !== null && Wr(It) && (It = null),
      jt !== null && Wr(jt) && (jt = null),
      Jn.forEach(Hi),
      Zn.forEach(Hi));
  }
  function bn(e, t) {
    e.blockedOn === t &&
      ((e.blockedOn = null),
      ho ||
        ((ho = !0),
        s.unstable_scheduleCallback(s.unstable_NormalPriority, bc)));
  }
  function er(e) {
    function t(l) {
      return bn(l, e);
    }
    if (0 < Hr.length) {
      bn(Hr[0], e);
      for (var n = 1; n < Hr.length; n++) {
        var r = Hr[n];
        r.blockedOn === e && (r.blockedOn = null);
      }
    }
    for (
      Ft !== null && bn(Ft, e),
        It !== null && bn(It, e),
        jt !== null && bn(jt, e),
        Jn.forEach(t),
        Zn.forEach(t),
        n = 0;
      n < Ut.length;
      n++
    )
      ((r = Ut[n]), r.blockedOn === e && (r.blockedOn = null));
    for (; 0 < Ut.length && ((n = Ut[0]), n.blockedOn === null);)
      (Bi(n), n.blockedOn === null && Ut.shift());
  }
  var yn = ue.ReactCurrentBatchConfig,
    Vr = !0;
  function ef(e, t, n, r) {
    var l = oe,
      o = yn.transition;
    yn.transition = null;
    try {
      ((oe = 1), mo(e, t, n, r));
    } finally {
      ((oe = l), (yn.transition = o));
    }
  }
  function tf(e, t, n, r) {
    var l = oe,
      o = yn.transition;
    yn.transition = null;
    try {
      ((oe = 4), mo(e, t, n, r));
    } finally {
      ((oe = l), (yn.transition = o));
    }
  }
  function mo(e, t, n, r) {
    if (Vr) {
      var l = vo(e, t, n, r);
      if (l === null) (Do(e, t, r, Qr, n), Ai(e, r));
      else if (qc(l, e, t, n, r)) r.stopPropagation();
      else if ((Ai(e, r), t & 4 && -1 < Zc.indexOf(e))) {
        for (; l !== null;) {
          var o = dr(l);
          if (
            (o !== null && Ii(o),
            (o = vo(e, t, n, r)),
            o === null && Do(e, t, r, Qr, n),
            o === l)
          )
            break;
          l = o;
        }
        l !== null && r.stopPropagation();
      } else Do(e, t, r, null, n);
    }
  }
  var Qr = null;
  function vo(e, t, n, r) {
    if (((Qr = null), (e = ro(r)), (e = tn(e)), e !== null))
      if (((t = en(e)), t === null)) e = null;
      else if (((n = t.tag), n === 13)) {
        if (((e = _i(t)), e !== null)) return e;
        e = null;
      } else if (n === 3) {
        if (t.stateNode.current.memoizedState.isDehydrated)
          return t.tag === 3 ? t.stateNode.containerInfo : null;
        e = null;
      } else t !== e && (e = null);
    return ((Qr = e), null);
  }
  function Wi(e) {
    switch (e) {
      case "cancel":
      case "click":
      case "close":
      case "contextmenu":
      case "copy":
      case "cut":
      case "auxclick":
      case "dblclick":
      case "dragend":
      case "dragstart":
      case "drop":
      case "focusin":
      case "focusout":
      case "input":
      case "invalid":
      case "keydown":
      case "keypress":
      case "keyup":
      case "mousedown":
      case "mouseup":
      case "paste":
      case "pause":
      case "play":
      case "pointercancel":
      case "pointerdown":
      case "pointerup":
      case "ratechange":
      case "reset":
      case "resize":
      case "seeked":
      case "submit":
      case "touchcancel":
      case "touchend":
      case "touchstart":
      case "volumechange":
      case "change":
      case "selectionchange":
      case "textInput":
      case "compositionstart":
      case "compositionend":
      case "compositionupdate":
      case "beforeblur":
      case "afterblur":
      case "beforeinput":
      case "blur":
      case "fullscreenchange":
      case "focus":
      case "hashchange":
      case "popstate":
      case "select":
      case "selectstart":
        return 1;
      case "drag":
      case "dragenter":
      case "dragexit":
      case "dragleave":
      case "dragover":
      case "mousemove":
      case "mouseout":
      case "mouseover":
      case "pointermove":
      case "pointerout":
      case "pointerover":
      case "scroll":
      case "toggle":
      case "touchmove":
      case "wheel":
      case "mouseenter":
      case "mouseleave":
      case "pointerenter":
      case "pointerleave":
        return 4;
      case "message":
        switch (Hc()) {
          case ao:
            return 1;
          case Oi:
            return 4;
          case jr:
          case Wc:
            return 16;
          case Di:
            return 536870912;
          default:
            return 16;
        }
      default:
        return 16;
    }
  }
  var $t = null,
    yo = null,
    Kr = null;
  function Vi() {
    if (Kr) return Kr;
    var e,
      t = yo,
      n = t.length,
      r,
      l = "value" in $t ? $t.value : $t.textContent,
      o = l.length;
    for (e = 0; e < n && t[e] === l[e]; e++);
    var i = n - e;
    for (r = 1; r <= i && t[n - r] === l[o - r]; r++);
    return (Kr = l.slice(e, 1 < r ? 1 - r : void 0));
  }
  function Yr(e) {
    var t = e.keyCode;
    return (
      "charCode" in e
        ? ((e = e.charCode), e === 0 && t === 13 && (e = 13))
        : (e = t),
      e === 10 && (e = 13),
      32 <= e || e === 13 ? e : 0
    );
  }
  function Xr() {
    return !0;
  }
  function Qi() {
    return !1;
  }
  function Ge(e) {
    function t(n, r, l, o, i) {
      ((this._reactName = n),
        (this._targetInst = l),
        (this.type = r),
        (this.nativeEvent = o),
        (this.target = i),
        (this.currentTarget = null));
      for (var c in e)
        e.hasOwnProperty(c) && ((n = e[c]), (this[c] = n ? n(o) : o[c]));
      return (
        (this.isDefaultPrevented = (
          o.defaultPrevented != null ? o.defaultPrevented : o.returnValue === !1
        )
          ? Xr
          : Qi),
        (this.isPropagationStopped = Qi),
        this
      );
    }
    return (
      j(t.prototype, {
        preventDefault: function () {
          this.defaultPrevented = !0;
          var n = this.nativeEvent;
          n &&
            (n.preventDefault
              ? n.preventDefault()
              : typeof n.returnValue != "unknown" && (n.returnValue = !1),
            (this.isDefaultPrevented = Xr));
        },
        stopPropagation: function () {
          var n = this.nativeEvent;
          n &&
            (n.stopPropagation
              ? n.stopPropagation()
              : typeof n.cancelBubble != "unknown" && (n.cancelBubble = !0),
            (this.isPropagationStopped = Xr));
        },
        persist: function () {},
        isPersistent: Xr,
      }),
      t
    );
  }
  var gn = {
      eventPhase: 0,
      bubbles: 0,
      cancelable: 0,
      timeStamp: function (e) {
        return e.timeStamp || Date.now();
      },
      defaultPrevented: 0,
      isTrusted: 0,
    },
    go = Ge(gn),
    tr = j({}, gn, { view: 0, detail: 0 }),
    nf = Ge(tr),
    wo,
    So,
    nr,
    Gr = j({}, tr, {
      screenX: 0,
      screenY: 0,
      clientX: 0,
      clientY: 0,
      pageX: 0,
      pageY: 0,
      ctrlKey: 0,
      shiftKey: 0,
      altKey: 0,
      metaKey: 0,
      getModifierState: Eo,
      button: 0,
      buttons: 0,
      relatedTarget: function (e) {
        return e.relatedTarget === void 0
          ? e.fromElement === e.srcElement
            ? e.toElement
            : e.fromElement
          : e.relatedTarget;
      },
      movementX: function (e) {
        return "movementX" in e
          ? e.movementX
          : (e !== nr &&
              (nr && e.type === "mousemove"
                ? ((wo = e.screenX - nr.screenX), (So = e.screenY - nr.screenY))
                : (So = wo = 0),
              (nr = e)),
            wo);
      },
      movementY: function (e) {
        return "movementY" in e ? e.movementY : So;
      },
    }),
    Ki = Ge(Gr),
    rf = j({}, Gr, { dataTransfer: 0 }),
    lf = Ge(rf),
    of = j({}, tr, { relatedTarget: 0 }),
    ko = Ge(of),
    uf = j({}, gn, { animationName: 0, elapsedTime: 0, pseudoElement: 0 }),
    af = Ge(uf),
    sf = j({}, gn, {
      clipboardData: function (e) {
        return "clipboardData" in e ? e.clipboardData : window.clipboardData;
      },
    }),
    cf = Ge(sf),
    ff = j({}, gn, { data: 0 }),
    Yi = Ge(ff),
    df = {
      Esc: "Escape",
      Spacebar: " ",
      Left: "ArrowLeft",
      Up: "ArrowUp",
      Right: "ArrowRight",
      Down: "ArrowDown",
      Del: "Delete",
      Win: "OS",
      Menu: "ContextMenu",
      Apps: "ContextMenu",
      Scroll: "ScrollLock",
      MozPrintableKey: "Unidentified",
    },
    pf = {
      8: "Backspace",
      9: "Tab",
      12: "Clear",
      13: "Enter",
      16: "Shift",
      17: "Control",
      18: "Alt",
      19: "Pause",
      20: "CapsLock",
      27: "Escape",
      32: " ",
      33: "PageUp",
      34: "PageDown",
      35: "End",
      36: "Home",
      37: "ArrowLeft",
      38: "ArrowUp",
      39: "ArrowRight",
      40: "ArrowDown",
      45: "Insert",
      46: "Delete",
      112: "F1",
      113: "F2",
      114: "F3",
      115: "F4",
      116: "F5",
      117: "F6",
      118: "F7",
      119: "F8",
      120: "F9",
      121: "F10",
      122: "F11",
      123: "F12",
      144: "NumLock",
      145: "ScrollLock",
      224: "Meta",
    },
    hf = {
      Alt: "altKey",
      Control: "ctrlKey",
      Meta: "metaKey",
      Shift: "shiftKey",
    };
  function mf(e) {
    var t = this.nativeEvent;
    return t.getModifierState
      ? t.getModifierState(e)
      : (e = hf[e])
        ? !!t[e]
        : !1;
  }
  function Eo() {
    return mf;
  }
  var vf = j({}, tr, {
      key: function (e) {
        if (e.key) {
          var t = df[e.key] || e.key;
          if (t !== "Unidentified") return t;
        }
        return e.type === "keypress"
          ? ((e = Yr(e)), e === 13 ? "Enter" : String.fromCharCode(e))
          : e.type === "keydown" || e.type === "keyup"
            ? pf[e.keyCode] || "Unidentified"
            : "";
      },
      code: 0,
      location: 0,
      ctrlKey: 0,
      shiftKey: 0,
      altKey: 0,
      metaKey: 0,
      repeat: 0,
      locale: 0,
      getModifierState: Eo,
      charCode: function (e) {
        return e.type === "keypress" ? Yr(e) : 0;
      },
      keyCode: function (e) {
        return e.type === "keydown" || e.type === "keyup" ? e.keyCode : 0;
      },
      which: function (e) {
        return e.type === "keypress"
          ? Yr(e)
          : e.type === "keydown" || e.type === "keyup"
            ? e.keyCode
            : 0;
      },
    }),
    yf = Ge(vf),
    gf = j({}, Gr, {
      pointerId: 0,
      width: 0,
      height: 0,
      pressure: 0,
      tangentialPressure: 0,
      tiltX: 0,
      tiltY: 0,
      twist: 0,
      pointerType: 0,
      isPrimary: 0,
    }),
    Xi = Ge(gf),
    wf = j({}, tr, {
      touches: 0,
      targetTouches: 0,
      changedTouches: 0,
      altKey: 0,
      metaKey: 0,
      ctrlKey: 0,
      shiftKey: 0,
      getModifierState: Eo,
    }),
    Sf = Ge(wf),
    kf = j({}, gn, { propertyName: 0, elapsedTime: 0, pseudoElement: 0 }),
    Ef = Ge(kf),
    Cf = j({}, Gr, {
      deltaX: function (e) {
        return "deltaX" in e
          ? e.deltaX
          : "wheelDeltaX" in e
            ? -e.wheelDeltaX
            : 0;
      },
      deltaY: function (e) {
        return "deltaY" in e
          ? e.deltaY
          : "wheelDeltaY" in e
            ? -e.wheelDeltaY
            : "wheelDelta" in e
              ? -e.wheelDelta
              : 0;
      },
      deltaZ: 0,
      deltaMode: 0,
    }),
    xf = Ge(Cf),
    Pf = [9, 13, 27, 32],
    Co = E && "CompositionEvent" in window,
    rr = null;
  E && "documentMode" in document && (rr = document.documentMode);
  var _f = E && "TextEvent" in window && !rr,
    Gi = E && (!Co || (rr && 8 < rr && 11 >= rr)),
    Ji = " ",
    Zi = !1;
  function qi(e, t) {
    switch (e) {
      case "keyup":
        return Pf.indexOf(t.keyCode) !== -1;
      case "keydown":
        return t.keyCode !== 229;
      case "keypress":
      case "mousedown":
      case "focusout":
        return !0;
      default:
        return !1;
    }
  }
  function bi(e) {
    return (
      (e = e.detail),
      typeof e == "object" && "data" in e ? e.data : null
    );
  }
  var wn = !1;
  function Rf(e, t) {
    switch (e) {
      case "compositionend":
        return bi(t);
      case "keypress":
        return t.which !== 32 ? null : ((Zi = !0), Ji);
      case "textInput":
        return ((e = t.data), e === Ji && Zi ? null : e);
      default:
        return null;
    }
  }
  function Lf(e, t) {
    if (wn)
      return e === "compositionend" || (!Co && qi(e, t))
        ? ((e = Vi()), (Kr = yo = $t = null), (wn = !1), e)
        : null;
    switch (e) {
      case "paste":
        return null;
      case "keypress":
        if (!(t.ctrlKey || t.altKey || t.metaKey) || (t.ctrlKey && t.altKey)) {
          if (t.char && 1 < t.char.length) return t.char;
          if (t.which) return String.fromCharCode(t.which);
        }
        return null;
      case "compositionend":
        return Gi && t.locale !== "ko" ? null : t.data;
      default:
        return null;
    }
  }
  var Nf = {
    color: !0,
    date: !0,
    datetime: !0,
    "datetime-local": !0,
    email: !0,
    month: !0,
    number: !0,
    password: !0,
    range: !0,
    search: !0,
    tel: !0,
    text: !0,
    time: !0,
    url: !0,
    week: !0,
  };
  function ea(e) {
    var t = e && e.nodeName && e.nodeName.toLowerCase();
    return t === "input" ? !!Nf[e.type] : t === "textarea";
  }
  function ta(e, t, n, r) {
    (ki(r),
      (t = el(t, "onChange")),
      0 < t.length &&
        ((n = new go("onChange", "change", null, n, r)),
        e.push({ event: n, listeners: t })));
  }
  var lr = null,
    or = null;
  function Tf(e) {
    wa(e, 0);
  }
  function Jr(e) {
    var t = xn(e);
    if (si(t)) return e;
  }
  function zf(e, t) {
    if (e === "change") return t;
  }
  var na = !1;
  if (E) {
    var xo;
    if (E) {
      var Po = "oninput" in document;
      if (!Po) {
        var ra = document.createElement("div");
        (ra.setAttribute("oninput", "return;"),
          (Po = typeof ra.oninput == "function"));
      }
      xo = Po;
    } else xo = !1;
    na = xo && (!document.documentMode || 9 < document.documentMode);
  }
  function la() {
    lr && (lr.detachEvent("onpropertychange", oa), (or = lr = null));
  }
  function oa(e) {
    if (e.propertyName === "value" && Jr(or)) {
      var t = [];
      (ta(t, or, e, ro(e)), Pi(Tf, t));
    }
  }
  function Of(e, t, n) {
    e === "focusin"
      ? (la(), (lr = t), (or = n), lr.attachEvent("onpropertychange", oa))
      : e === "focusout" && la();
  }
  function Df(e) {
    if (e === "selectionchange" || e === "keyup" || e === "keydown")
      return Jr(or);
  }
  function Mf(e, t) {
    if (e === "click") return Jr(t);
  }
  function Ff(e, t) {
    if (e === "input" || e === "change") return Jr(t);
  }
  function If(e, t) {
    return (e === t && (e !== 0 || 1 / e === 1 / t)) || (e !== e && t !== t);
  }
  var at = typeof Object.is == "function" ? Object.is : If;
  function ur(e, t) {
    if (at(e, t)) return !0;
    if (
      typeof e != "object" ||
      e === null ||
      typeof t != "object" ||
      t === null
    )
      return !1;
    var n = Object.keys(e),
      r = Object.keys(t);
    if (n.length !== r.length) return !1;
    for (r = 0; r < n.length; r++) {
      var l = n[r];
      if (!k.call(t, l) || !at(e[l], t[l])) return !1;
    }
    return !0;
  }
  function ua(e) {
    for (; e && e.firstChild;) e = e.firstChild;
    return e;
  }
  function ia(e, t) {
    var n = ua(e);
    e = 0;
    for (var r; n;) {
      if (n.nodeType === 3) {
        if (((r = e + n.textContent.length), e <= t && r >= t))
          return { node: n, offset: t - e };
        e = r;
      }
      e: {
        for (; n;) {
          if (n.nextSibling) {
            n = n.nextSibling;
            break e;
          }
          n = n.parentNode;
        }
        n = void 0;
      }
      n = ua(n);
    }
  }
  function aa(e, t) {
    return e && t
      ? e === t
        ? !0
        : e && e.nodeType === 3
          ? !1
          : t && t.nodeType === 3
            ? aa(e, t.parentNode)
            : "contains" in e
              ? e.contains(t)
              : e.compareDocumentPosition
                ? !!(e.compareDocumentPosition(t) & 16)
                : !1
      : !1;
  }
  function sa() {
    for (var e = window, t = Dr(); t instanceof e.HTMLIFrameElement;) {
      try {
        var n = typeof t.contentWindow.location.href == "string";
      } catch {
        n = !1;
      }
      if (n) e = t.contentWindow;
      else break;
      t = Dr(e.document);
    }
    return t;
  }
  function _o(e) {
    var t = e && e.nodeName && e.nodeName.toLowerCase();
    return (
      t &&
      ((t === "input" &&
        (e.type === "text" ||
          e.type === "search" ||
          e.type === "tel" ||
          e.type === "url" ||
          e.type === "password")) ||
        t === "textarea" ||
        e.contentEditable === "true")
    );
  }
  function jf(e) {
    var t = sa(),
      n = e.focusedElem,
      r = e.selectionRange;
    if (
      t !== n &&
      n &&
      n.ownerDocument &&
      aa(n.ownerDocument.documentElement, n)
    ) {
      if (r !== null && _o(n)) {
        if (
          ((t = r.start),
          (e = r.end),
          e === void 0 && (e = t),
          "selectionStart" in n)
        )
          ((n.selectionStart = t),
            (n.selectionEnd = Math.min(e, n.value.length)));
        else if (
          ((e = ((t = n.ownerDocument || document) && t.defaultView) || window),
          e.getSelection)
        ) {
          e = e.getSelection();
          var l = n.textContent.length,
            o = Math.min(r.start, l);
          ((r = r.end === void 0 ? o : Math.min(r.end, l)),
            !e.extend && o > r && ((l = r), (r = o), (o = l)),
            (l = ia(n, o)));
          var i = ia(n, r);
          l &&
            i &&
            (e.rangeCount !== 1 ||
              e.anchorNode !== l.node ||
              e.anchorOffset !== l.offset ||
              e.focusNode !== i.node ||
              e.focusOffset !== i.offset) &&
            ((t = t.createRange()),
            t.setStart(l.node, l.offset),
            e.removeAllRanges(),
            o > r
              ? (e.addRange(t), e.extend(i.node, i.offset))
              : (t.setEnd(i.node, i.offset), e.addRange(t)));
        }
      }
      for (t = [], e = n; (e = e.parentNode);)
        e.nodeType === 1 &&
          t.push({ element: e, left: e.scrollLeft, top: e.scrollTop });
      for (typeof n.focus == "function" && n.focus(), n = 0; n < t.length; n++)
        ((e = t[n]),
          (e.element.scrollLeft = e.left),
          (e.element.scrollTop = e.top));
    }
  }
  var Uf = E && "documentMode" in document && 11 >= document.documentMode,
    Sn = null,
    Ro = null,
    ir = null,
    Lo = !1;
  function ca(e, t, n) {
    var r =
      n.window === n ? n.document : n.nodeType === 9 ? n : n.ownerDocument;
    Lo ||
      Sn == null ||
      Sn !== Dr(r) ||
      ((r = Sn),
      "selectionStart" in r && _o(r)
        ? (r = { start: r.selectionStart, end: r.selectionEnd })
        : ((r = (
            (r.ownerDocument && r.ownerDocument.defaultView) ||
            window
          ).getSelection()),
          (r = {
            anchorNode: r.anchorNode,
            anchorOffset: r.anchorOffset,
            focusNode: r.focusNode,
            focusOffset: r.focusOffset,
          })),
      (ir && ur(ir, r)) ||
        ((ir = r),
        (r = el(Ro, "onSelect")),
        0 < r.length &&
          ((t = new go("onSelect", "select", null, t, n)),
          e.push({ event: t, listeners: r }),
          (t.target = Sn))));
  }
  function Zr(e, t) {
    var n = {};
    return (
      (n[e.toLowerCase()] = t.toLowerCase()),
      (n["Webkit" + e] = "webkit" + t),
      (n["Moz" + e] = "moz" + t),
      n
    );
  }
  var kn = {
      animationend: Zr("Animation", "AnimationEnd"),
      animationiteration: Zr("Animation", "AnimationIteration"),
      animationstart: Zr("Animation", "AnimationStart"),
      transitionend: Zr("Transition", "TransitionEnd"),
    },
    No = {},
    fa = {};
  E &&
    ((fa = document.createElement("div").style),
    "AnimationEvent" in window ||
      (delete kn.animationend.animation,
      delete kn.animationiteration.animation,
      delete kn.animationstart.animation),
    "TransitionEvent" in window || delete kn.transitionend.transition);
  function qr(e) {
    if (No[e]) return No[e];
    if (!kn[e]) return e;
    var t = kn[e],
      n;
    for (n in t) if (t.hasOwnProperty(n) && n in fa) return (No[e] = t[n]);
    return e;
  }
  var da = qr("animationend"),
    pa = qr("animationiteration"),
    ha = qr("animationstart"),
    ma = qr("transitionend"),
    va = new Map(),
    ya =
      "abort auxClick cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(
        " ",
      );
  function At(e, t) {
    (va.set(e, t), v(t, [e]));
  }
  for (var To = 0; To < ya.length; To++) {
    var zo = ya[To],
      $f = zo.toLowerCase(),
      Af = zo[0].toUpperCase() + zo.slice(1);
    At($f, "on" + Af);
  }
  (At(da, "onAnimationEnd"),
    At(pa, "onAnimationIteration"),
    At(ha, "onAnimationStart"),
    At("dblclick", "onDoubleClick"),
    At("focusin", "onFocus"),
    At("focusout", "onBlur"),
    At(ma, "onTransitionEnd"),
    S("onMouseEnter", ["mouseout", "mouseover"]),
    S("onMouseLeave", ["mouseout", "mouseover"]),
    S("onPointerEnter", ["pointerout", "pointerover"]),
    S("onPointerLeave", ["pointerout", "pointerover"]),
    v(
      "onChange",
      "change click focusin focusout input keydown keyup selectionchange".split(
        " ",
      ),
    ),
    v(
      "onSelect",
      "focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(
        " ",
      ),
    ),
    v("onBeforeInput", ["compositionend", "keypress", "textInput", "paste"]),
    v(
      "onCompositionEnd",
      "compositionend focusout keydown keypress keyup mousedown".split(" "),
    ),
    v(
      "onCompositionStart",
      "compositionstart focusout keydown keypress keyup mousedown".split(" "),
    ),
    v(
      "onCompositionUpdate",
      "compositionupdate focusout keydown keypress keyup mousedown".split(" "),
    ));
  var ar =
      "abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(
        " ",
      ),
    Bf = new Set(
      "cancel close invalid load scroll toggle".split(" ").concat(ar),
    );
  function ga(e, t, n) {
    var r = e.type || "unknown-event";
    ((e.currentTarget = n), Uc(r, t, void 0, e), (e.currentTarget = null));
  }
  function wa(e, t) {
    t = (t & 4) !== 0;
    for (var n = 0; n < e.length; n++) {
      var r = e[n],
        l = r.event;
      r = r.listeners;
      e: {
        var o = void 0;
        if (t)
          for (var i = r.length - 1; 0 <= i; i--) {
            var c = r[i],
              d = c.instance,
              w = c.currentTarget;
            if (((c = c.listener), d !== o && l.isPropagationStopped()))
              break e;
            (ga(l, c, w), (o = d));
          }
        else
          for (i = 0; i < r.length; i++) {
            if (
              ((c = r[i]),
              (d = c.instance),
              (w = c.currentTarget),
              (c = c.listener),
              d !== o && l.isPropagationStopped())
            )
              break e;
            (ga(l, c, w), (o = d));
          }
      }
    }
    if (Ir) throw ((e = io), (Ir = !1), (io = null), e);
  }
  function se(e, t) {
    var n = t[$o];
    n === void 0 && (n = t[$o] = new Set());
    var r = e + "__bubble";
    n.has(r) || (Sa(t, e, 2, !1), n.add(r));
  }
  function Oo(e, t, n) {
    var r = 0;
    (t && (r |= 4), Sa(n, e, r, t));
  }
  var br = "_reactListening" + Math.random().toString(36).slice(2);
  function sr(e) {
    if (!e[br]) {
      ((e[br] = !0),
        f.forEach(function (n) {
          n !== "selectionchange" && (Bf.has(n) || Oo(n, !1, e), Oo(n, !0, e));
        }));
      var t = e.nodeType === 9 ? e : e.ownerDocument;
      t === null || t[br] || ((t[br] = !0), Oo("selectionchange", !1, t));
    }
  }
  function Sa(e, t, n, r) {
    switch (Wi(t)) {
      case 1:
        var l = ef;
        break;
      case 4:
        l = tf;
        break;
      default:
        l = mo;
    }
    ((n = l.bind(null, t, n, e)),
      (l = void 0),
      !uo ||
        (t !== "touchstart" && t !== "touchmove" && t !== "wheel") ||
        (l = !0),
      r
        ? l !== void 0
          ? e.addEventListener(t, n, { capture: !0, passive: l })
          : e.addEventListener(t, n, !0)
        : l !== void 0
          ? e.addEventListener(t, n, { passive: l })
          : e.addEventListener(t, n, !1));
  }
  function Do(e, t, n, r, l) {
    var o = r;
    if ((t & 1) === 0 && (t & 2) === 0 && r !== null)
      e: for (;;) {
        if (r === null) return;
        var i = r.tag;
        if (i === 3 || i === 4) {
          var c = r.stateNode.containerInfo;
          if (c === l || (c.nodeType === 8 && c.parentNode === l)) break;
          if (i === 4)
            for (i = r.return; i !== null;) {
              var d = i.tag;
              if (
                (d === 3 || d === 4) &&
                ((d = i.stateNode.containerInfo),
                d === l || (d.nodeType === 8 && d.parentNode === l))
              )
                return;
              i = i.return;
            }
          for (; c !== null;) {
            if (((i = tn(c)), i === null)) return;
            if (((d = i.tag), d === 5 || d === 6)) {
              r = o = i;
              continue e;
            }
            c = c.parentNode;
          }
        }
        r = r.return;
      }
    Pi(function () {
      var w = o,
        L = ro(n),
        N = [];
      e: {
        var _ = va.get(e);
        if (_ !== void 0) {
          var M = go,
            U = e;
          switch (e) {
            case "keypress":
              if (Yr(n) === 0) break e;
            case "keydown":
            case "keyup":
              M = yf;
              break;
            case "focusin":
              ((U = "focus"), (M = ko));
              break;
            case "focusout":
              ((U = "blur"), (M = ko));
              break;
            case "beforeblur":
            case "afterblur":
              M = ko;
              break;
            case "click":
              if (n.button === 2) break e;
            case "auxclick":
            case "dblclick":
            case "mousedown":
            case "mousemove":
            case "mouseup":
            case "mouseout":
            case "mouseover":
            case "contextmenu":
              M = Ki;
              break;
            case "drag":
            case "dragend":
            case "dragenter":
            case "dragexit":
            case "dragleave":
            case "dragover":
            case "dragstart":
            case "drop":
              M = lf;
              break;
            case "touchcancel":
            case "touchend":
            case "touchmove":
            case "touchstart":
              M = Sf;
              break;
            case da:
            case pa:
            case ha:
              M = af;
              break;
            case ma:
              M = Ef;
              break;
            case "scroll":
              M = nf;
              break;
            case "wheel":
              M = xf;
              break;
            case "copy":
            case "cut":
            case "paste":
              M = cf;
              break;
            case "gotpointercapture":
            case "lostpointercapture":
            case "pointercancel":
            case "pointerdown":
            case "pointermove":
            case "pointerout":
            case "pointerover":
            case "pointerup":
              M = Xi;
          }
          var $ = (t & 4) !== 0,
            Se = !$ && e === "scroll",
            y = $ ? (_ !== null ? _ + "Capture" : null) : _;
          $ = [];
          for (var h = w, g; h !== null;) {
            g = h;
            var T = g.stateNode;
            if (
              (g.tag === 5 &&
                T !== null &&
                ((g = T),
                y !== null &&
                  ((T = Qn(h, y)), T != null && $.push(cr(h, T, g)))),
              Se)
            )
              break;
            h = h.return;
          }
          0 < $.length &&
            ((_ = new M(_, U, null, n, L)), N.push({ event: _, listeners: $ }));
        }
      }
      if ((t & 7) === 0) {
        e: {
          if (
            ((_ = e === "mouseover" || e === "pointerover"),
            (M = e === "mouseout" || e === "pointerout"),
            _ &&
              n !== no &&
              (U = n.relatedTarget || n.fromElement) &&
              (tn(U) || U[xt]))
          )
            break e;
          if (
            (M || _) &&
            ((_ =
              L.window === L
                ? L
                : (_ = L.ownerDocument)
                  ? _.defaultView || _.parentWindow
                  : window),
            M
              ? ((U = n.relatedTarget || n.toElement),
                (M = w),
                (U = U ? tn(U) : null),
                U !== null &&
                  ((Se = en(U)), U !== Se || (U.tag !== 5 && U.tag !== 6)) &&
                  (U = null))
              : ((M = null), (U = w)),
            M !== U)
          ) {
            if (
              (($ = Ki),
              (T = "onMouseLeave"),
              (y = "onMouseEnter"),
              (h = "mouse"),
              (e === "pointerout" || e === "pointerover") &&
                (($ = Xi),
                (T = "onPointerLeave"),
                (y = "onPointerEnter"),
                (h = "pointer")),
              (Se = M == null ? _ : xn(M)),
              (g = U == null ? _ : xn(U)),
              (_ = new $(T, h + "leave", M, n, L)),
              (_.target = Se),
              (_.relatedTarget = g),
              (T = null),
              tn(L) === w &&
                (($ = new $(y, h + "enter", U, n, L)),
                ($.target = g),
                ($.relatedTarget = Se),
                (T = $)),
              (Se = T),
              M && U)
            )
              t: {
                for ($ = M, y = U, h = 0, g = $; g; g = En(g)) h++;
                for (g = 0, T = y; T; T = En(T)) g++;
                for (; 0 < h - g;) (($ = En($)), h--);
                for (; 0 < g - h;) ((y = En(y)), g--);
                for (; h--;) {
                  if ($ === y || (y !== null && $ === y.alternate)) break t;
                  (($ = En($)), (y = En(y)));
                }
                $ = null;
              }
            else $ = null;
            (M !== null && ka(N, _, M, $, !1),
              U !== null && Se !== null && ka(N, Se, U, $, !0));
          }
        }
        e: {
          if (
            ((_ = w ? xn(w) : window),
            (M = _.nodeName && _.nodeName.toLowerCase()),
            M === "select" || (M === "input" && _.type === "file"))
          )
            var B = zf;
          else if (ea(_))
            if (na) B = Ff;
            else {
              B = Df;
              var Q = Of;
            }
          else
            (M = _.nodeName) &&
              M.toLowerCase() === "input" &&
              (_.type === "checkbox" || _.type === "radio") &&
              (B = Mf);
          if (B && (B = B(e, w))) {
            ta(N, B, n, L);
            break e;
          }
          (Q && Q(e, _, w),
            e === "focusout" &&
              (Q = _._wrapperState) &&
              Q.controlled &&
              _.type === "number" &&
              Zl(_, "number", _.value));
        }
        switch (((Q = w ? xn(w) : window), e)) {
          case "focusin":
            (ea(Q) || Q.contentEditable === "true") &&
              ((Sn = Q), (Ro = w), (ir = null));
            break;
          case "focusout":
            ir = Ro = Sn = null;
            break;
          case "mousedown":
            Lo = !0;
            break;
          case "contextmenu":
          case "mouseup":
          case "dragend":
            ((Lo = !1), ca(N, n, L));
            break;
          case "selectionchange":
            if (Uf) break;
          case "keydown":
          case "keyup":
            ca(N, n, L);
        }
        var K;
        if (Co)
          e: {
            switch (e) {
              case "compositionstart":
                var G = "onCompositionStart";
                break e;
              case "compositionend":
                G = "onCompositionEnd";
                break e;
              case "compositionupdate":
                G = "onCompositionUpdate";
                break e;
            }
            G = void 0;
          }
        else
          wn
            ? qi(e, n) && (G = "onCompositionEnd")
            : e === "keydown" &&
              n.keyCode === 229 &&
              (G = "onCompositionStart");
        (G &&
          (Gi &&
            n.locale !== "ko" &&
            (wn || G !== "onCompositionStart"
              ? G === "onCompositionEnd" && wn && (K = Vi())
              : (($t = L),
                (yo = "value" in $t ? $t.value : $t.textContent),
                (wn = !0))),
          (Q = el(w, G)),
          0 < Q.length &&
            ((G = new Yi(G, e, null, n, L)),
            N.push({ event: G, listeners: Q }),
            K ? (G.data = K) : ((K = bi(n)), K !== null && (G.data = K)))),
          (K = _f ? Rf(e, n) : Lf(e, n)) &&
            ((w = el(w, "onBeforeInput")),
            0 < w.length &&
              ((L = new Yi("onBeforeInput", "beforeinput", null, n, L)),
              N.push({ event: L, listeners: w }),
              (L.data = K))));
      }
      wa(N, t);
    });
  }
  function cr(e, t, n) {
    return { instance: e, listener: t, currentTarget: n };
  }
  function el(e, t) {
    for (var n = t + "Capture", r = []; e !== null;) {
      var l = e,
        o = l.stateNode;
      (l.tag === 5 &&
        o !== null &&
        ((l = o),
        (o = Qn(e, n)),
        o != null && r.unshift(cr(e, o, l)),
        (o = Qn(e, t)),
        o != null && r.push(cr(e, o, l))),
        (e = e.return));
    }
    return r;
  }
  function En(e) {
    if (e === null) return null;
    do e = e.return;
    while (e && e.tag !== 5);
    return e || null;
  }
  function ka(e, t, n, r, l) {
    for (var o = t._reactName, i = []; n !== null && n !== r;) {
      var c = n,
        d = c.alternate,
        w = c.stateNode;
      if (d !== null && d === r) break;
      (c.tag === 5 &&
        w !== null &&
        ((c = w),
        l
          ? ((d = Qn(n, o)), d != null && i.unshift(cr(n, d, c)))
          : l || ((d = Qn(n, o)), d != null && i.push(cr(n, d, c)))),
        (n = n.return));
    }
    i.length !== 0 && e.push({ event: t, listeners: i });
  }
  var Hf = /\r\n?/g,
    Wf = /\u0000|\uFFFD/g;
  function Ea(e) {
    return (typeof e == "string" ? e : "" + e)
      .replace(
        Hf,
        `
`,
      )
      .replace(Wf, "");
  }
  function tl(e, t, n) {
    if (((t = Ea(t)), Ea(e) !== t && n)) throw Error(a(425));
  }
  function nl() {}
  var Mo = null,
    Fo = null;
  function Io(e, t) {
    return (
      e === "textarea" ||
      e === "noscript" ||
      typeof t.children == "string" ||
      typeof t.children == "number" ||
      (typeof t.dangerouslySetInnerHTML == "object" &&
        t.dangerouslySetInnerHTML !== null &&
        t.dangerouslySetInnerHTML.__html != null)
    );
  }
  var jo = typeof setTimeout == "function" ? setTimeout : void 0,
    Vf = typeof clearTimeout == "function" ? clearTimeout : void 0,
    Ca = typeof Promise == "function" ? Promise : void 0,
    Qf =
      typeof queueMicrotask == "function"
        ? queueMicrotask
        : typeof Ca < "u"
          ? function (e) {
              return Ca.resolve(null).then(e).catch(Kf);
            }
          : jo;
  function Kf(e) {
    setTimeout(function () {
      throw e;
    });
  }
  function Uo(e, t) {
    var n = t,
      r = 0;
    do {
      var l = n.nextSibling;
      if ((e.removeChild(n), l && l.nodeType === 8))
        if (((n = l.data), n === "/$")) {
          if (r === 0) {
            (e.removeChild(l), er(t));
            return;
          }
          r--;
        } else (n !== "$" && n !== "$?" && n !== "$!") || r++;
      n = l;
    } while (n);
    er(t);
  }
  function Bt(e) {
    for (; e != null; e = e.nextSibling) {
      var t = e.nodeType;
      if (t === 1 || t === 3) break;
      if (t === 8) {
        if (((t = e.data), t === "$" || t === "$!" || t === "$?")) break;
        if (t === "/$") return null;
      }
    }
    return e;
  }
  function xa(e) {
    e = e.previousSibling;
    for (var t = 0; e;) {
      if (e.nodeType === 8) {
        var n = e.data;
        if (n === "$" || n === "$!" || n === "$?") {
          if (t === 0) return e;
          t--;
        } else n === "/$" && t++;
      }
      e = e.previousSibling;
    }
    return null;
  }
  var Cn = Math.random().toString(36).slice(2),
    St = "__reactFiber$" + Cn,
    fr = "__reactProps$" + Cn,
    xt = "__reactContainer$" + Cn,
    $o = "__reactEvents$" + Cn,
    Yf = "__reactListeners$" + Cn,
    Xf = "__reactHandles$" + Cn;
  function tn(e) {
    var t = e[St];
    if (t) return t;
    for (var n = e.parentNode; n;) {
      if ((t = n[xt] || n[St])) {
        if (
          ((n = t.alternate),
          t.child !== null || (n !== null && n.child !== null))
        )
          for (e = xa(e); e !== null;) {
            if ((n = e[St])) return n;
            e = xa(e);
          }
        return t;
      }
      ((e = n), (n = e.parentNode));
    }
    return null;
  }
  function dr(e) {
    return (
      (e = e[St] || e[xt]),
      !e || (e.tag !== 5 && e.tag !== 6 && e.tag !== 13 && e.tag !== 3)
        ? null
        : e
    );
  }
  function xn(e) {
    if (e.tag === 5 || e.tag === 6) return e.stateNode;
    throw Error(a(33));
  }
  function rl(e) {
    return e[fr] || null;
  }
  var Ao = [],
    Pn = -1;
  function Ht(e) {
    return { current: e };
  }
  function ce(e) {
    0 > Pn || ((e.current = Ao[Pn]), (Ao[Pn] = null), Pn--);
  }
  function ae(e, t) {
    (Pn++, (Ao[Pn] = e.current), (e.current = t));
  }
  var Wt = {},
    Me = Ht(Wt),
    Be = Ht(!1),
    nn = Wt;
  function _n(e, t) {
    var n = e.type.contextTypes;
    if (!n) return Wt;
    var r = e.stateNode;
    if (r && r.__reactInternalMemoizedUnmaskedChildContext === t)
      return r.__reactInternalMemoizedMaskedChildContext;
    var l = {},
      o;
    for (o in n) l[o] = t[o];
    return (
      r &&
        ((e = e.stateNode),
        (e.__reactInternalMemoizedUnmaskedChildContext = t),
        (e.__reactInternalMemoizedMaskedChildContext = l)),
      l
    );
  }
  function He(e) {
    return ((e = e.childContextTypes), e != null);
  }
  function ll() {
    (ce(Be), ce(Me));
  }
  function Pa(e, t, n) {
    if (Me.current !== Wt) throw Error(a(168));
    (ae(Me, t), ae(Be, n));
  }
  function _a(e, t, n) {
    var r = e.stateNode;
    if (((t = t.childContextTypes), typeof r.getChildContext != "function"))
      return n;
    r = r.getChildContext();
    for (var l in r) if (!(l in t)) throw Error(a(108, ie(e) || "Unknown", l));
    return j({}, n, r);
  }
  function ol(e) {
    return (
      (e =
        ((e = e.stateNode) && e.__reactInternalMemoizedMergedChildContext) ||
        Wt),
      (nn = Me.current),
      ae(Me, e),
      ae(Be, Be.current),
      !0
    );
  }
  function Ra(e, t, n) {
    var r = e.stateNode;
    if (!r) throw Error(a(169));
    (n
      ? ((e = _a(e, t, nn)),
        (r.__reactInternalMemoizedMergedChildContext = e),
        ce(Be),
        ce(Me),
        ae(Me, e))
      : ce(Be),
      ae(Be, n));
  }
  var Pt = null,
    ul = !1,
    Bo = !1;
  function La(e) {
    Pt === null ? (Pt = [e]) : Pt.push(e);
  }
  function Gf(e) {
    ((ul = !0), La(e));
  }
  function Vt() {
    if (!Bo && Pt !== null) {
      Bo = !0;
      var e = 0,
        t = oe;
      try {
        var n = Pt;
        for (oe = 1; e < n.length; e++) {
          var r = n[e];
          do r = r(!0);
          while (r !== null);
        }
        ((Pt = null), (ul = !1));
      } catch (l) {
        throw (Pt !== null && (Pt = Pt.slice(e + 1)), Ti(ao, Vt), l);
      } finally {
        ((oe = t), (Bo = !1));
      }
    }
    return null;
  }
  var Rn = [],
    Ln = 0,
    il = null,
    al = 0,
    be = [],
    et = 0,
    rn = null,
    _t = 1,
    Rt = "";
  function ln(e, t) {
    ((Rn[Ln++] = al), (Rn[Ln++] = il), (il = e), (al = t));
  }
  function Na(e, t, n) {
    ((be[et++] = _t), (be[et++] = Rt), (be[et++] = rn), (rn = e));
    var r = _t;
    e = Rt;
    var l = 32 - it(r) - 1;
    ((r &= ~(1 << l)), (n += 1));
    var o = 32 - it(t) + l;
    if (30 < o) {
      var i = l - (l % 5);
      ((o = (r & ((1 << i) - 1)).toString(32)),
        (r >>= i),
        (l -= i),
        (_t = (1 << (32 - it(t) + l)) | (n << l) | r),
        (Rt = o + e));
    } else ((_t = (1 << o) | (n << l) | r), (Rt = e));
  }
  function Ho(e) {
    e.return !== null && (ln(e, 1), Na(e, 1, 0));
  }
  function Wo(e) {
    for (; e === il;)
      ((il = Rn[--Ln]), (Rn[Ln] = null), (al = Rn[--Ln]), (Rn[Ln] = null));
    for (; e === rn;)
      ((rn = be[--et]),
        (be[et] = null),
        (Rt = be[--et]),
        (be[et] = null),
        (_t = be[--et]),
        (be[et] = null));
  }
  var Je = null,
    Ze = null,
    de = !1,
    st = null;
  function Ta(e, t) {
    var n = lt(5, null, null, 0);
    ((n.elementType = "DELETED"),
      (n.stateNode = t),
      (n.return = e),
      (t = e.deletions),
      t === null ? ((e.deletions = [n]), (e.flags |= 16)) : t.push(n));
  }
  function za(e, t) {
    switch (e.tag) {
      case 5:
        var n = e.type;
        return (
          (t =
            t.nodeType !== 1 || n.toLowerCase() !== t.nodeName.toLowerCase()
              ? null
              : t),
          t !== null
            ? ((e.stateNode = t), (Je = e), (Ze = Bt(t.firstChild)), !0)
            : !1
        );
      case 6:
        return (
          (t = e.pendingProps === "" || t.nodeType !== 3 ? null : t),
          t !== null ? ((e.stateNode = t), (Je = e), (Ze = null), !0) : !1
        );
      case 13:
        return (
          (t = t.nodeType !== 8 ? null : t),
          t !== null
            ? ((n = rn !== null ? { id: _t, overflow: Rt } : null),
              (e.memoizedState = {
                dehydrated: t,
                treeContext: n,
                retryLane: 1073741824,
              }),
              (n = lt(18, null, null, 0)),
              (n.stateNode = t),
              (n.return = e),
              (e.child = n),
              (Je = e),
              (Ze = null),
              !0)
            : !1
        );
      default:
        return !1;
    }
  }
  function Vo(e) {
    return (e.mode & 1) !== 0 && (e.flags & 128) === 0;
  }
  function Qo(e) {
    if (de) {
      var t = Ze;
      if (t) {
        var n = t;
        if (!za(e, t)) {
          if (Vo(e)) throw Error(a(418));
          t = Bt(n.nextSibling);
          var r = Je;
          t && za(e, t)
            ? Ta(r, n)
            : ((e.flags = (e.flags & -4097) | 2), (de = !1), (Je = e));
        }
      } else {
        if (Vo(e)) throw Error(a(418));
        ((e.flags = (e.flags & -4097) | 2), (de = !1), (Je = e));
      }
    }
  }
  function Oa(e) {
    for (
      e = e.return;
      e !== null && e.tag !== 5 && e.tag !== 3 && e.tag !== 13;
    )
      e = e.return;
    Je = e;
  }
  function sl(e) {
    if (e !== Je) return !1;
    if (!de) return (Oa(e), (de = !0), !1);
    var t;
    if (
      ((t = e.tag !== 3) &&
        !(t = e.tag !== 5) &&
        ((t = e.type),
        (t = t !== "head" && t !== "body" && !Io(e.type, e.memoizedProps))),
      t && (t = Ze))
    ) {
      if (Vo(e)) throw (Da(), Error(a(418)));
      for (; t;) (Ta(e, t), (t = Bt(t.nextSibling)));
    }
    if ((Oa(e), e.tag === 13)) {
      if (((e = e.memoizedState), (e = e !== null ? e.dehydrated : null), !e))
        throw Error(a(317));
      e: {
        for (e = e.nextSibling, t = 0; e;) {
          if (e.nodeType === 8) {
            var n = e.data;
            if (n === "/$") {
              if (t === 0) {
                Ze = Bt(e.nextSibling);
                break e;
              }
              t--;
            } else (n !== "$" && n !== "$!" && n !== "$?") || t++;
          }
          e = e.nextSibling;
        }
        Ze = null;
      }
    } else Ze = Je ? Bt(e.stateNode.nextSibling) : null;
    return !0;
  }
  function Da() {
    for (var e = Ze; e;) e = Bt(e.nextSibling);
  }
  function Nn() {
    ((Ze = Je = null), (de = !1));
  }
  function Ko(e) {
    st === null ? (st = [e]) : st.push(e);
  }
  var Jf = ue.ReactCurrentBatchConfig;
  function pr(e, t, n) {
    if (
      ((e = n.ref),
      e !== null && typeof e != "function" && typeof e != "object")
    ) {
      if (n._owner) {
        if (((n = n._owner), n)) {
          if (n.tag !== 1) throw Error(a(309));
          var r = n.stateNode;
        }
        if (!r) throw Error(a(147, e));
        var l = r,
          o = "" + e;
        return t !== null &&
          t.ref !== null &&
          typeof t.ref == "function" &&
          t.ref._stringRef === o
          ? t.ref
          : ((t = function (i) {
              var c = l.refs;
              i === null ? delete c[o] : (c[o] = i);
            }),
            (t._stringRef = o),
            t);
      }
      if (typeof e != "string") throw Error(a(284));
      if (!n._owner) throw Error(a(290, e));
    }
    return e;
  }
  function cl(e, t) {
    throw (
      (e = Object.prototype.toString.call(t)),
      Error(
        a(
          31,
          e === "[object Object]"
            ? "object with keys {" + Object.keys(t).join(", ") + "}"
            : e,
        ),
      )
    );
  }
  function Ma(e) {
    var t = e._init;
    return t(e._payload);
  }
  function Fa(e) {
    function t(y, h) {
      if (e) {
        var g = y.deletions;
        g === null ? ((y.deletions = [h]), (y.flags |= 16)) : g.push(h);
      }
    }
    function n(y, h) {
      if (!e) return null;
      for (; h !== null;) (t(y, h), (h = h.sibling));
      return null;
    }
    function r(y, h) {
      for (y = new Map(); h !== null;)
        (h.key !== null ? y.set(h.key, h) : y.set(h.index, h), (h = h.sibling));
      return y;
    }
    function l(y, h) {
      return ((y = qt(y, h)), (y.index = 0), (y.sibling = null), y);
    }
    function o(y, h, g) {
      return (
        (y.index = g),
        e
          ? ((g = y.alternate),
            g !== null
              ? ((g = g.index), g < h ? ((y.flags |= 2), h) : g)
              : ((y.flags |= 2), h))
          : ((y.flags |= 1048576), h)
      );
    }
    function i(y) {
      return (e && y.alternate === null && (y.flags |= 2), y);
    }
    function c(y, h, g, T) {
      return h === null || h.tag !== 6
        ? ((h = ju(g, y.mode, T)), (h.return = y), h)
        : ((h = l(h, g)), (h.return = y), h);
    }
    function d(y, h, g, T) {
      var B = g.type;
      return B === Ee
        ? L(y, h, g.props.children, T, g.key)
        : h !== null &&
            (h.elementType === B ||
              (typeof B == "object" &&
                B !== null &&
                B.$$typeof === Ae &&
                Ma(B) === h.type))
          ? ((T = l(h, g.props)), (T.ref = pr(y, h, g)), (T.return = y), T)
          : ((T = Ml(g.type, g.key, g.props, null, y.mode, T)),
            (T.ref = pr(y, h, g)),
            (T.return = y),
            T);
    }
    function w(y, h, g, T) {
      return h === null ||
        h.tag !== 4 ||
        h.stateNode.containerInfo !== g.containerInfo ||
        h.stateNode.implementation !== g.implementation
        ? ((h = Uu(g, y.mode, T)), (h.return = y), h)
        : ((h = l(h, g.children || [])), (h.return = y), h);
    }
    function L(y, h, g, T, B) {
      return h === null || h.tag !== 7
        ? ((h = pn(g, y.mode, T, B)), (h.return = y), h)
        : ((h = l(h, g)), (h.return = y), h);
    }
    function N(y, h, g) {
      if ((typeof h == "string" && h !== "") || typeof h == "number")
        return ((h = ju("" + h, y.mode, g)), (h.return = y), h);
      if (typeof h == "object" && h !== null) {
        switch (h.$$typeof) {
          case he:
            return (
              (g = Ml(h.type, h.key, h.props, null, y.mode, g)),
              (g.ref = pr(y, null, h)),
              (g.return = y),
              g
            );
          case ke:
            return ((h = Uu(h, y.mode, g)), (h.return = y), h);
          case Ae:
            var T = h._init;
            return N(y, T(h._payload), g);
        }
        if (Hn(h) || X(h))
          return ((h = pn(h, y.mode, g, null)), (h.return = y), h);
        cl(y, h);
      }
      return null;
    }
    function _(y, h, g, T) {
      var B = h !== null ? h.key : null;
      if ((typeof g == "string" && g !== "") || typeof g == "number")
        return B !== null ? null : c(y, h, "" + g, T);
      if (typeof g == "object" && g !== null) {
        switch (g.$$typeof) {
          case he:
            return g.key === B ? d(y, h, g, T) : null;
          case ke:
            return g.key === B ? w(y, h, g, T) : null;
          case Ae:
            return ((B = g._init), _(y, h, B(g._payload), T));
        }
        if (Hn(g) || X(g)) return B !== null ? null : L(y, h, g, T, null);
        cl(y, g);
      }
      return null;
    }
    function M(y, h, g, T, B) {
      if ((typeof T == "string" && T !== "") || typeof T == "number")
        return ((y = y.get(g) || null), c(h, y, "" + T, B));
      if (typeof T == "object" && T !== null) {
        switch (T.$$typeof) {
          case he:
            return (
              (y = y.get(T.key === null ? g : T.key) || null),
              d(h, y, T, B)
            );
          case ke:
            return (
              (y = y.get(T.key === null ? g : T.key) || null),
              w(h, y, T, B)
            );
          case Ae:
            var Q = T._init;
            return M(y, h, g, Q(T._payload), B);
        }
        if (Hn(T) || X(T)) return ((y = y.get(g) || null), L(h, y, T, B, null));
        cl(h, T);
      }
      return null;
    }
    function U(y, h, g, T) {
      for (
        var B = null, Q = null, K = h, G = (h = 0), Ne = null;
        K !== null && G < g.length;
        G++
      ) {
        K.index > G ? ((Ne = K), (K = null)) : (Ne = K.sibling);
        var re = _(y, K, g[G], T);
        if (re === null) {
          K === null && (K = Ne);
          break;
        }
        (e && K && re.alternate === null && t(y, K),
          (h = o(re, h, G)),
          Q === null ? (B = re) : (Q.sibling = re),
          (Q = re),
          (K = Ne));
      }
      if (G === g.length) return (n(y, K), de && ln(y, G), B);
      if (K === null) {
        for (; G < g.length; G++)
          ((K = N(y, g[G], T)),
            K !== null &&
              ((h = o(K, h, G)),
              Q === null ? (B = K) : (Q.sibling = K),
              (Q = K)));
        return (de && ln(y, G), B);
      }
      for (K = r(y, K); G < g.length; G++)
        ((Ne = M(K, y, G, g[G], T)),
          Ne !== null &&
            (e &&
              Ne.alternate !== null &&
              K.delete(Ne.key === null ? G : Ne.key),
            (h = o(Ne, h, G)),
            Q === null ? (B = Ne) : (Q.sibling = Ne),
            (Q = Ne)));
      return (
        e &&
          K.forEach(function (bt) {
            return t(y, bt);
          }),
        de && ln(y, G),
        B
      );
    }
    function $(y, h, g, T) {
      var B = X(g);
      if (typeof B != "function") throw Error(a(150));
      if (((g = B.call(g)), g == null)) throw Error(a(151));
      for (
        var Q = (B = null), K = h, G = (h = 0), Ne = null, re = g.next();
        K !== null && !re.done;
        G++, re = g.next()
      ) {
        K.index > G ? ((Ne = K), (K = null)) : (Ne = K.sibling);
        var bt = _(y, K, re.value, T);
        if (bt === null) {
          K === null && (K = Ne);
          break;
        }
        (e && K && bt.alternate === null && t(y, K),
          (h = o(bt, h, G)),
          Q === null ? (B = bt) : (Q.sibling = bt),
          (Q = bt),
          (K = Ne));
      }
      if (re.done) return (n(y, K), de && ln(y, G), B);
      if (K === null) {
        for (; !re.done; G++, re = g.next())
          ((re = N(y, re.value, T)),
            re !== null &&
              ((h = o(re, h, G)),
              Q === null ? (B = re) : (Q.sibling = re),
              (Q = re)));
        return (de && ln(y, G), B);
      }
      for (K = r(y, K); !re.done; G++, re = g.next())
        ((re = M(K, y, G, re.value, T)),
          re !== null &&
            (e &&
              re.alternate !== null &&
              K.delete(re.key === null ? G : re.key),
            (h = o(re, h, G)),
            Q === null ? (B = re) : (Q.sibling = re),
            (Q = re)));
      return (
        e &&
          K.forEach(function (Nd) {
            return t(y, Nd);
          }),
        de && ln(y, G),
        B
      );
    }
    function Se(y, h, g, T) {
      if (
        (typeof g == "object" &&
          g !== null &&
          g.type === Ee &&
          g.key === null &&
          (g = g.props.children),
        typeof g == "object" && g !== null)
      ) {
        switch (g.$$typeof) {
          case he:
            e: {
              for (var B = g.key, Q = h; Q !== null;) {
                if (Q.key === B) {
                  if (((B = g.type), B === Ee)) {
                    if (Q.tag === 7) {
                      (n(y, Q.sibling),
                        (h = l(Q, g.props.children)),
                        (h.return = y),
                        (y = h));
                      break e;
                    }
                  } else if (
                    Q.elementType === B ||
                    (typeof B == "object" &&
                      B !== null &&
                      B.$$typeof === Ae &&
                      Ma(B) === Q.type)
                  ) {
                    (n(y, Q.sibling),
                      (h = l(Q, g.props)),
                      (h.ref = pr(y, Q, g)),
                      (h.return = y),
                      (y = h));
                    break e;
                  }
                  n(y, Q);
                  break;
                } else t(y, Q);
                Q = Q.sibling;
              }
              g.type === Ee
                ? ((h = pn(g.props.children, y.mode, T, g.key)),
                  (h.return = y),
                  (y = h))
                : ((T = Ml(g.type, g.key, g.props, null, y.mode, T)),
                  (T.ref = pr(y, h, g)),
                  (T.return = y),
                  (y = T));
            }
            return i(y);
          case ke:
            e: {
              for (Q = g.key; h !== null;) {
                if (h.key === Q)
                  if (
                    h.tag === 4 &&
                    h.stateNode.containerInfo === g.containerInfo &&
                    h.stateNode.implementation === g.implementation
                  ) {
                    (n(y, h.sibling),
                      (h = l(h, g.children || [])),
                      (h.return = y),
                      (y = h));
                    break e;
                  } else {
                    n(y, h);
                    break;
                  }
                else t(y, h);
                h = h.sibling;
              }
              ((h = Uu(g, y.mode, T)), (h.return = y), (y = h));
            }
            return i(y);
          case Ae:
            return ((Q = g._init), Se(y, h, Q(g._payload), T));
        }
        if (Hn(g)) return U(y, h, g, T);
        if (X(g)) return $(y, h, g, T);
        cl(y, g);
      }
      return (typeof g == "string" && g !== "") || typeof g == "number"
        ? ((g = "" + g),
          h !== null && h.tag === 6
            ? (n(y, h.sibling), (h = l(h, g)), (h.return = y), (y = h))
            : (n(y, h), (h = ju(g, y.mode, T)), (h.return = y), (y = h)),
          i(y))
        : n(y, h);
    }
    return Se;
  }
  var Tn = Fa(!0),
    Ia = Fa(!1),
    fl = Ht(null),
    dl = null,
    zn = null,
    Yo = null;
  function Xo() {
    Yo = zn = dl = null;
  }
  function Go(e) {
    var t = fl.current;
    (ce(fl), (e._currentValue = t));
  }
  function Jo(e, t, n) {
    for (; e !== null;) {
      var r = e.alternate;
      if (
        ((e.childLanes & t) !== t
          ? ((e.childLanes |= t), r !== null && (r.childLanes |= t))
          : r !== null && (r.childLanes & t) !== t && (r.childLanes |= t),
        e === n)
      )
        break;
      e = e.return;
    }
  }
  function On(e, t) {
    ((dl = e),
      (Yo = zn = null),
      (e = e.dependencies),
      e !== null &&
        e.firstContext !== null &&
        ((e.lanes & t) !== 0 && (We = !0), (e.firstContext = null)));
  }
  function tt(e) {
    var t = e._currentValue;
    if (Yo !== e)
      if (((e = { context: e, memoizedValue: t, next: null }), zn === null)) {
        if (dl === null) throw Error(a(308));
        ((zn = e), (dl.dependencies = { lanes: 0, firstContext: e }));
      } else zn = zn.next = e;
    return t;
  }
  var on = null;
  function Zo(e) {
    on === null ? (on = [e]) : on.push(e);
  }
  function ja(e, t, n, r) {
    var l = t.interleaved;
    return (
      l === null ? ((n.next = n), Zo(t)) : ((n.next = l.next), (l.next = n)),
      (t.interleaved = n),
      Lt(e, r)
    );
  }
  function Lt(e, t) {
    e.lanes |= t;
    var n = e.alternate;
    for (n !== null && (n.lanes |= t), n = e, e = e.return; e !== null;)
      ((e.childLanes |= t),
        (n = e.alternate),
        n !== null && (n.childLanes |= t),
        (n = e),
        (e = e.return));
    return n.tag === 3 ? n.stateNode : null;
  }
  var Qt = !1;
  function qo(e) {
    e.updateQueue = {
      baseState: e.memoizedState,
      firstBaseUpdate: null,
      lastBaseUpdate: null,
      shared: { pending: null, interleaved: null, lanes: 0 },
      effects: null,
    };
  }
  function Ua(e, t) {
    ((e = e.updateQueue),
      t.updateQueue === e &&
        (t.updateQueue = {
          baseState: e.baseState,
          firstBaseUpdate: e.firstBaseUpdate,
          lastBaseUpdate: e.lastBaseUpdate,
          shared: e.shared,
          effects: e.effects,
        }));
  }
  function Nt(e, t) {
    return {
      eventTime: e,
      lane: t,
      tag: 0,
      payload: null,
      callback: null,
      next: null,
    };
  }
  function Kt(e, t, n) {
    var r = e.updateQueue;
    if (r === null) return null;
    if (((r = r.shared), (ee & 2) !== 0)) {
      var l = r.pending;
      return (
        l === null ? (t.next = t) : ((t.next = l.next), (l.next = t)),
        (r.pending = t),
        Lt(e, n)
      );
    }
    return (
      (l = r.interleaved),
      l === null ? ((t.next = t), Zo(r)) : ((t.next = l.next), (l.next = t)),
      (r.interleaved = t),
      Lt(e, n)
    );
  }
  function pl(e, t, n) {
    if (
      ((t = t.updateQueue), t !== null && ((t = t.shared), (n & 4194240) !== 0))
    ) {
      var r = t.lanes;
      ((r &= e.pendingLanes), (n |= r), (t.lanes = n), fo(e, n));
    }
  }
  function $a(e, t) {
    var n = e.updateQueue,
      r = e.alternate;
    if (r !== null && ((r = r.updateQueue), n === r)) {
      var l = null,
        o = null;
      if (((n = n.firstBaseUpdate), n !== null)) {
        do {
          var i = {
            eventTime: n.eventTime,
            lane: n.lane,
            tag: n.tag,
            payload: n.payload,
            callback: n.callback,
            next: null,
          };
          (o === null ? (l = o = i) : (o = o.next = i), (n = n.next));
        } while (n !== null);
        o === null ? (l = o = t) : (o = o.next = t);
      } else l = o = t;
      ((n = {
        baseState: r.baseState,
        firstBaseUpdate: l,
        lastBaseUpdate: o,
        shared: r.shared,
        effects: r.effects,
      }),
        (e.updateQueue = n));
      return;
    }
    ((e = n.lastBaseUpdate),
      e === null ? (n.firstBaseUpdate = t) : (e.next = t),
      (n.lastBaseUpdate = t));
  }
  function hl(e, t, n, r) {
    var l = e.updateQueue;
    Qt = !1;
    var o = l.firstBaseUpdate,
      i = l.lastBaseUpdate,
      c = l.shared.pending;
    if (c !== null) {
      l.shared.pending = null;
      var d = c,
        w = d.next;
      ((d.next = null), i === null ? (o = w) : (i.next = w), (i = d));
      var L = e.alternate;
      L !== null &&
        ((L = L.updateQueue),
        (c = L.lastBaseUpdate),
        c !== i &&
          (c === null ? (L.firstBaseUpdate = w) : (c.next = w),
          (L.lastBaseUpdate = d)));
    }
    if (o !== null) {
      var N = l.baseState;
      ((i = 0), (L = w = d = null), (c = o));
      do {
        var _ = c.lane,
          M = c.eventTime;
        if ((r & _) === _) {
          L !== null &&
            (L = L.next =
              {
                eventTime: M,
                lane: 0,
                tag: c.tag,
                payload: c.payload,
                callback: c.callback,
                next: null,
              });
          e: {
            var U = e,
              $ = c;
            switch (((_ = t), (M = n), $.tag)) {
              case 1:
                if (((U = $.payload), typeof U == "function")) {
                  N = U.call(M, N, _);
                  break e;
                }
                N = U;
                break e;
              case 3:
                U.flags = (U.flags & -65537) | 128;
              case 0:
                if (
                  ((U = $.payload),
                  (_ = typeof U == "function" ? U.call(M, N, _) : U),
                  _ == null)
                )
                  break e;
                N = j({}, N, _);
                break e;
              case 2:
                Qt = !0;
            }
          }
          c.callback !== null &&
            c.lane !== 0 &&
            ((e.flags |= 64),
            (_ = l.effects),
            _ === null ? (l.effects = [c]) : _.push(c));
        } else
          ((M = {
            eventTime: M,
            lane: _,
            tag: c.tag,
            payload: c.payload,
            callback: c.callback,
            next: null,
          }),
            L === null ? ((w = L = M), (d = N)) : (L = L.next = M),
            (i |= _));
        if (((c = c.next), c === null)) {
          if (((c = l.shared.pending), c === null)) break;
          ((_ = c),
            (c = _.next),
            (_.next = null),
            (l.lastBaseUpdate = _),
            (l.shared.pending = null));
        }
      } while (!0);
      if (
        (L === null && (d = N),
        (l.baseState = d),
        (l.firstBaseUpdate = w),
        (l.lastBaseUpdate = L),
        (t = l.shared.interleaved),
        t !== null)
      ) {
        l = t;
        do ((i |= l.lane), (l = l.next));
        while (l !== t);
      } else o === null && (l.shared.lanes = 0);
      ((sn |= i), (e.lanes = i), (e.memoizedState = N));
    }
  }
  function Aa(e, t, n) {
    if (((e = t.effects), (t.effects = null), e !== null))
      for (t = 0; t < e.length; t++) {
        var r = e[t],
          l = r.callback;
        if (l !== null) {
          if (((r.callback = null), (r = n), typeof l != "function"))
            throw Error(a(191, l));
          l.call(r);
        }
      }
  }
  var hr = {},
    kt = Ht(hr),
    mr = Ht(hr),
    vr = Ht(hr);
  function un(e) {
    if (e === hr) throw Error(a(174));
    return e;
  }
  function bo(e, t) {
    switch ((ae(vr, t), ae(mr, e), ae(kt, hr), (e = t.nodeType), e)) {
      case 9:
      case 11:
        t = (t = t.documentElement) ? t.namespaceURI : bl(null, "");
        break;
      default:
        ((e = e === 8 ? t.parentNode : t),
          (t = e.namespaceURI || null),
          (e = e.tagName),
          (t = bl(t, e)));
    }
    (ce(kt), ae(kt, t));
  }
  function Dn() {
    (ce(kt), ce(mr), ce(vr));
  }
  function Ba(e) {
    un(vr.current);
    var t = un(kt.current),
      n = bl(t, e.type);
    t !== n && (ae(mr, e), ae(kt, n));
  }
  function eu(e) {
    mr.current === e && (ce(kt), ce(mr));
  }
  var me = Ht(0);
  function ml(e) {
    for (var t = e; t !== null;) {
      if (t.tag === 13) {
        var n = t.memoizedState;
        if (
          n !== null &&
          ((n = n.dehydrated), n === null || n.data === "$?" || n.data === "$!")
        )
          return t;
      } else if (t.tag === 19 && t.memoizedProps.revealOrder !== void 0) {
        if ((t.flags & 128) !== 0) return t;
      } else if (t.child !== null) {
        ((t.child.return = t), (t = t.child));
        continue;
      }
      if (t === e) break;
      for (; t.sibling === null;) {
        if (t.return === null || t.return === e) return null;
        t = t.return;
      }
      ((t.sibling.return = t.return), (t = t.sibling));
    }
    return null;
  }
  var tu = [];
  function nu() {
    for (var e = 0; e < tu.length; e++)
      tu[e]._workInProgressVersionPrimary = null;
    tu.length = 0;
  }
  var vl = ue.ReactCurrentDispatcher,
    ru = ue.ReactCurrentBatchConfig,
    an = 0,
    ve = null,
    Pe = null,
    Re = null,
    yl = !1,
    yr = !1,
    gr = 0,
    Zf = 0;
  function Fe() {
    throw Error(a(321));
  }
  function lu(e, t) {
    if (t === null) return !1;
    for (var n = 0; n < t.length && n < e.length; n++)
      if (!at(e[n], t[n])) return !1;
    return !0;
  }
  function ou(e, t, n, r, l, o) {
    if (
      ((an = o),
      (ve = t),
      (t.memoizedState = null),
      (t.updateQueue = null),
      (t.lanes = 0),
      (vl.current = e === null || e.memoizedState === null ? td : nd),
      (e = n(r, l)),
      yr)
    ) {
      o = 0;
      do {
        if (((yr = !1), (gr = 0), 25 <= o)) throw Error(a(301));
        ((o += 1),
          (Re = Pe = null),
          (t.updateQueue = null),
          (vl.current = rd),
          (e = n(r, l)));
      } while (yr);
    }
    if (
      ((vl.current = Sl),
      (t = Pe !== null && Pe.next !== null),
      (an = 0),
      (Re = Pe = ve = null),
      (yl = !1),
      t)
    )
      throw Error(a(300));
    return e;
  }
  function uu() {
    var e = gr !== 0;
    return ((gr = 0), e);
  }
  function Et() {
    var e = {
      memoizedState: null,
      baseState: null,
      baseQueue: null,
      queue: null,
      next: null,
    };
    return (Re === null ? (ve.memoizedState = Re = e) : (Re = Re.next = e), Re);
  }
  function nt() {
    if (Pe === null) {
      var e = ve.alternate;
      e = e !== null ? e.memoizedState : null;
    } else e = Pe.next;
    var t = Re === null ? ve.memoizedState : Re.next;
    if (t !== null) ((Re = t), (Pe = e));
    else {
      if (e === null) throw Error(a(310));
      ((Pe = e),
        (e = {
          memoizedState: Pe.memoizedState,
          baseState: Pe.baseState,
          baseQueue: Pe.baseQueue,
          queue: Pe.queue,
          next: null,
        }),
        Re === null ? (ve.memoizedState = Re = e) : (Re = Re.next = e));
    }
    return Re;
  }
  function wr(e, t) {
    return typeof t == "function" ? t(e) : t;
  }
  function iu(e) {
    var t = nt(),
      n = t.queue;
    if (n === null) throw Error(a(311));
    n.lastRenderedReducer = e;
    var r = Pe,
      l = r.baseQueue,
      o = n.pending;
    if (o !== null) {
      if (l !== null) {
        var i = l.next;
        ((l.next = o.next), (o.next = i));
      }
      ((r.baseQueue = l = o), (n.pending = null));
    }
    if (l !== null) {
      ((o = l.next), (r = r.baseState));
      var c = (i = null),
        d = null,
        w = o;
      do {
        var L = w.lane;
        if ((an & L) === L)
          (d !== null &&
            (d = d.next =
              {
                lane: 0,
                action: w.action,
                hasEagerState: w.hasEagerState,
                eagerState: w.eagerState,
                next: null,
              }),
            (r = w.hasEagerState ? w.eagerState : e(r, w.action)));
        else {
          var N = {
            lane: L,
            action: w.action,
            hasEagerState: w.hasEagerState,
            eagerState: w.eagerState,
            next: null,
          };
          (d === null ? ((c = d = N), (i = r)) : (d = d.next = N),
            (ve.lanes |= L),
            (sn |= L));
        }
        w = w.next;
      } while (w !== null && w !== o);
      (d === null ? (i = r) : (d.next = c),
        at(r, t.memoizedState) || (We = !0),
        (t.memoizedState = r),
        (t.baseState = i),
        (t.baseQueue = d),
        (n.lastRenderedState = r));
    }
    if (((e = n.interleaved), e !== null)) {
      l = e;
      do ((o = l.lane), (ve.lanes |= o), (sn |= o), (l = l.next));
      while (l !== e);
    } else l === null && (n.lanes = 0);
    return [t.memoizedState, n.dispatch];
  }
  function au(e) {
    var t = nt(),
      n = t.queue;
    if (n === null) throw Error(a(311));
    n.lastRenderedReducer = e;
    var r = n.dispatch,
      l = n.pending,
      o = t.memoizedState;
    if (l !== null) {
      n.pending = null;
      var i = (l = l.next);
      do ((o = e(o, i.action)), (i = i.next));
      while (i !== l);
      (at(o, t.memoizedState) || (We = !0),
        (t.memoizedState = o),
        t.baseQueue === null && (t.baseState = o),
        (n.lastRenderedState = o));
    }
    return [o, r];
  }
  function Ha() {}
  function Wa(e, t) {
    var n = ve,
      r = nt(),
      l = t(),
      o = !at(r.memoizedState, l);
    if (
      (o && ((r.memoizedState = l), (We = !0)),
      (r = r.queue),
      su(Ka.bind(null, n, r, e), [e]),
      r.getSnapshot !== t || o || (Re !== null && Re.memoizedState.tag & 1))
    ) {
      if (
        ((n.flags |= 2048),
        Sr(9, Qa.bind(null, n, r, l, t), void 0, null),
        Le === null)
      )
        throw Error(a(349));
      (an & 30) !== 0 || Va(n, t, l);
    }
    return l;
  }
  function Va(e, t, n) {
    ((e.flags |= 16384),
      (e = { getSnapshot: t, value: n }),
      (t = ve.updateQueue),
      t === null
        ? ((t = { lastEffect: null, stores: null }),
          (ve.updateQueue = t),
          (t.stores = [e]))
        : ((n = t.stores), n === null ? (t.stores = [e]) : n.push(e)));
  }
  function Qa(e, t, n, r) {
    ((t.value = n), (t.getSnapshot = r), Ya(t) && Xa(e));
  }
  function Ka(e, t, n) {
    return n(function () {
      Ya(t) && Xa(e);
    });
  }
  function Ya(e) {
    var t = e.getSnapshot;
    e = e.value;
    try {
      var n = t();
      return !at(e, n);
    } catch {
      return !0;
    }
  }
  function Xa(e) {
    var t = Lt(e, 1);
    t !== null && pt(t, e, 1, -1);
  }
  function Ga(e) {
    var t = Et();
    return (
      typeof e == "function" && (e = e()),
      (t.memoizedState = t.baseState = e),
      (e = {
        pending: null,
        interleaved: null,
        lanes: 0,
        dispatch: null,
        lastRenderedReducer: wr,
        lastRenderedState: e,
      }),
      (t.queue = e),
      (e = e.dispatch = ed.bind(null, ve, e)),
      [t.memoizedState, e]
    );
  }
  function Sr(e, t, n, r) {
    return (
      (e = { tag: e, create: t, destroy: n, deps: r, next: null }),
      (t = ve.updateQueue),
      t === null
        ? ((t = { lastEffect: null, stores: null }),
          (ve.updateQueue = t),
          (t.lastEffect = e.next = e))
        : ((n = t.lastEffect),
          n === null
            ? (t.lastEffect = e.next = e)
            : ((r = n.next), (n.next = e), (e.next = r), (t.lastEffect = e))),
      e
    );
  }
  function Ja() {
    return nt().memoizedState;
  }
  function gl(e, t, n, r) {
    var l = Et();
    ((ve.flags |= e),
      (l.memoizedState = Sr(1 | t, n, void 0, r === void 0 ? null : r)));
  }
  function wl(e, t, n, r) {
    var l = nt();
    r = r === void 0 ? null : r;
    var o = void 0;
    if (Pe !== null) {
      var i = Pe.memoizedState;
      if (((o = i.destroy), r !== null && lu(r, i.deps))) {
        l.memoizedState = Sr(t, n, o, r);
        return;
      }
    }
    ((ve.flags |= e), (l.memoizedState = Sr(1 | t, n, o, r)));
  }
  function Za(e, t) {
    return gl(8390656, 8, e, t);
  }
  function su(e, t) {
    return wl(2048, 8, e, t);
  }
  function qa(e, t) {
    return wl(4, 2, e, t);
  }
  function ba(e, t) {
    return wl(4, 4, e, t);
  }
  function es(e, t) {
    if (typeof t == "function")
      return (
        (e = e()),
        t(e),
        function () {
          t(null);
        }
      );
    if (t != null)
      return (
        (e = e()),
        (t.current = e),
        function () {
          t.current = null;
        }
      );
  }
  function ts(e, t, n) {
    return (
      (n = n != null ? n.concat([e]) : null),
      wl(4, 4, es.bind(null, t, e), n)
    );
  }
  function cu() {}
  function ns(e, t) {
    var n = nt();
    t = t === void 0 ? null : t;
    var r = n.memoizedState;
    return r !== null && t !== null && lu(t, r[1])
      ? r[0]
      : ((n.memoizedState = [e, t]), e);
  }
  function rs(e, t) {
    var n = nt();
    t = t === void 0 ? null : t;
    var r = n.memoizedState;
    return r !== null && t !== null && lu(t, r[1])
      ? r[0]
      : ((e = e()), (n.memoizedState = [e, t]), e);
  }
  function ls(e, t, n) {
    return (an & 21) === 0
      ? (e.baseState && ((e.baseState = !1), (We = !0)), (e.memoizedState = n))
      : (at(n, t) ||
          ((n = Mi()), (ve.lanes |= n), (sn |= n), (e.baseState = !0)),
        t);
  }
  function qf(e, t) {
    var n = oe;
    ((oe = n !== 0 && 4 > n ? n : 4), e(!0));
    var r = ru.transition;
    ru.transition = {};
    try {
      (e(!1), t());
    } finally {
      ((oe = n), (ru.transition = r));
    }
  }
  function os() {
    return nt().memoizedState;
  }
  function bf(e, t, n) {
    var r = Jt(e);
    if (
      ((n = {
        lane: r,
        action: n,
        hasEagerState: !1,
        eagerState: null,
        next: null,
      }),
      us(e))
    )
      is(t, n);
    else if (((n = ja(e, t, n, r)), n !== null)) {
      var l = $e();
      (pt(n, e, r, l), as(n, t, r));
    }
  }
  function ed(e, t, n) {
    var r = Jt(e),
      l = {
        lane: r,
        action: n,
        hasEagerState: !1,
        eagerState: null,
        next: null,
      };
    if (us(e)) is(t, l);
    else {
      var o = e.alternate;
      if (
        e.lanes === 0 &&
        (o === null || o.lanes === 0) &&
        ((o = t.lastRenderedReducer), o !== null)
      )
        try {
          var i = t.lastRenderedState,
            c = o(i, n);
          if (((l.hasEagerState = !0), (l.eagerState = c), at(c, i))) {
            var d = t.interleaved;
            (d === null
              ? ((l.next = l), Zo(t))
              : ((l.next = d.next), (d.next = l)),
              (t.interleaved = l));
            return;
          }
        } catch {
        } finally {
        }
      ((n = ja(e, t, l, r)),
        n !== null && ((l = $e()), pt(n, e, r, l), as(n, t, r)));
    }
  }
  function us(e) {
    var t = e.alternate;
    return e === ve || (t !== null && t === ve);
  }
  function is(e, t) {
    yr = yl = !0;
    var n = e.pending;
    (n === null ? (t.next = t) : ((t.next = n.next), (n.next = t)),
      (e.pending = t));
  }
  function as(e, t, n) {
    if ((n & 4194240) !== 0) {
      var r = t.lanes;
      ((r &= e.pendingLanes), (n |= r), (t.lanes = n), fo(e, n));
    }
  }
  var Sl = {
      readContext: tt,
      useCallback: Fe,
      useContext: Fe,
      useEffect: Fe,
      useImperativeHandle: Fe,
      useInsertionEffect: Fe,
      useLayoutEffect: Fe,
      useMemo: Fe,
      useReducer: Fe,
      useRef: Fe,
      useState: Fe,
      useDebugValue: Fe,
      useDeferredValue: Fe,
      useTransition: Fe,
      useMutableSource: Fe,
      useSyncExternalStore: Fe,
      useId: Fe,
      unstable_isNewReconciler: !1,
    },
    td = {
      readContext: tt,
      useCallback: function (e, t) {
        return ((Et().memoizedState = [e, t === void 0 ? null : t]), e);
      },
      useContext: tt,
      useEffect: Za,
      useImperativeHandle: function (e, t, n) {
        return (
          (n = n != null ? n.concat([e]) : null),
          gl(4194308, 4, es.bind(null, t, e), n)
        );
      },
      useLayoutEffect: function (e, t) {
        return gl(4194308, 4, e, t);
      },
      useInsertionEffect: function (e, t) {
        return gl(4, 2, e, t);
      },
      useMemo: function (e, t) {
        var n = Et();
        return (
          (t = t === void 0 ? null : t),
          (e = e()),
          (n.memoizedState = [e, t]),
          e
        );
      },
      useReducer: function (e, t, n) {
        var r = Et();
        return (
          (t = n !== void 0 ? n(t) : t),
          (r.memoizedState = r.baseState = t),
          (e = {
            pending: null,
            interleaved: null,
            lanes: 0,
            dispatch: null,
            lastRenderedReducer: e,
            lastRenderedState: t,
          }),
          (r.queue = e),
          (e = e.dispatch = bf.bind(null, ve, e)),
          [r.memoizedState, e]
        );
      },
      useRef: function (e) {
        var t = Et();
        return ((e = { current: e }), (t.memoizedState = e));
      },
      useState: Ga,
      useDebugValue: cu,
      useDeferredValue: function (e) {
        return (Et().memoizedState = e);
      },
      useTransition: function () {
        var e = Ga(!1),
          t = e[0];
        return ((e = qf.bind(null, e[1])), (Et().memoizedState = e), [t, e]);
      },
      useMutableSource: function () {},
      useSyncExternalStore: function (e, t, n) {
        var r = ve,
          l = Et();
        if (de) {
          if (n === void 0) throw Error(a(407));
          n = n();
        } else {
          if (((n = t()), Le === null)) throw Error(a(349));
          (an & 30) !== 0 || Va(r, t, n);
        }
        l.memoizedState = n;
        var o = { value: n, getSnapshot: t };
        return (
          (l.queue = o),
          Za(Ka.bind(null, r, o, e), [e]),
          (r.flags |= 2048),
          Sr(9, Qa.bind(null, r, o, n, t), void 0, null),
          n
        );
      },
      useId: function () {
        var e = Et(),
          t = Le.identifierPrefix;
        if (de) {
          var n = Rt,
            r = _t;
          ((n = (r & ~(1 << (32 - it(r) - 1))).toString(32) + n),
            (t = ":" + t + "R" + n),
            (n = gr++),
            0 < n && (t += "H" + n.toString(32)),
            (t += ":"));
        } else ((n = Zf++), (t = ":" + t + "r" + n.toString(32) + ":"));
        return (e.memoizedState = t);
      },
      unstable_isNewReconciler: !1,
    },
    nd = {
      readContext: tt,
      useCallback: ns,
      useContext: tt,
      useEffect: su,
      useImperativeHandle: ts,
      useInsertionEffect: qa,
      useLayoutEffect: ba,
      useMemo: rs,
      useReducer: iu,
      useRef: Ja,
      useState: function () {
        return iu(wr);
      },
      useDebugValue: cu,
      useDeferredValue: function (e) {
        var t = nt();
        return ls(t, Pe.memoizedState, e);
      },
      useTransition: function () {
        var e = iu(wr)[0],
          t = nt().memoizedState;
        return [e, t];
      },
      useMutableSource: Ha,
      useSyncExternalStore: Wa,
      useId: os,
      unstable_isNewReconciler: !1,
    },
    rd = {
      readContext: tt,
      useCallback: ns,
      useContext: tt,
      useEffect: su,
      useImperativeHandle: ts,
      useInsertionEffect: qa,
      useLayoutEffect: ba,
      useMemo: rs,
      useReducer: au,
      useRef: Ja,
      useState: function () {
        return au(wr);
      },
      useDebugValue: cu,
      useDeferredValue: function (e) {
        var t = nt();
        return Pe === null ? (t.memoizedState = e) : ls(t, Pe.memoizedState, e);
      },
      useTransition: function () {
        var e = au(wr)[0],
          t = nt().memoizedState;
        return [e, t];
      },
      useMutableSource: Ha,
      useSyncExternalStore: Wa,
      useId: os,
      unstable_isNewReconciler: !1,
    };
  function ct(e, t) {
    if (e && e.defaultProps) {
      ((t = j({}, t)), (e = e.defaultProps));
      for (var n in e) t[n] === void 0 && (t[n] = e[n]);
      return t;
    }
    return t;
  }
  function fu(e, t, n, r) {
    ((t = e.memoizedState),
      (n = n(r, t)),
      (n = n == null ? t : j({}, t, n)),
      (e.memoizedState = n),
      e.lanes === 0 && (e.updateQueue.baseState = n));
  }
  var kl = {
    isMounted: function (e) {
      return (e = e._reactInternals) ? en(e) === e : !1;
    },
    enqueueSetState: function (e, t, n) {
      e = e._reactInternals;
      var r = $e(),
        l = Jt(e),
        o = Nt(r, l);
      ((o.payload = t),
        n != null && (o.callback = n),
        (t = Kt(e, o, l)),
        t !== null && (pt(t, e, l, r), pl(t, e, l)));
    },
    enqueueReplaceState: function (e, t, n) {
      e = e._reactInternals;
      var r = $e(),
        l = Jt(e),
        o = Nt(r, l);
      ((o.tag = 1),
        (o.payload = t),
        n != null && (o.callback = n),
        (t = Kt(e, o, l)),
        t !== null && (pt(t, e, l, r), pl(t, e, l)));
    },
    enqueueForceUpdate: function (e, t) {
      e = e._reactInternals;
      var n = $e(),
        r = Jt(e),
        l = Nt(n, r);
      ((l.tag = 2),
        t != null && (l.callback = t),
        (t = Kt(e, l, r)),
        t !== null && (pt(t, e, r, n), pl(t, e, r)));
    },
  };
  function ss(e, t, n, r, l, o, i) {
    return (
      (e = e.stateNode),
      typeof e.shouldComponentUpdate == "function"
        ? e.shouldComponentUpdate(r, o, i)
        : t.prototype && t.prototype.isPureReactComponent
          ? !ur(n, r) || !ur(l, o)
          : !0
    );
  }
  function cs(e, t, n) {
    var r = !1,
      l = Wt,
      o = t.contextType;
    return (
      typeof o == "object" && o !== null
        ? (o = tt(o))
        : ((l = He(t) ? nn : Me.current),
          (r = t.contextTypes),
          (o = (r = r != null) ? _n(e, l) : Wt)),
      (t = new t(n, o)),
      (e.memoizedState =
        t.state !== null && t.state !== void 0 ? t.state : null),
      (t.updater = kl),
      (e.stateNode = t),
      (t._reactInternals = e),
      r &&
        ((e = e.stateNode),
        (e.__reactInternalMemoizedUnmaskedChildContext = l),
        (e.__reactInternalMemoizedMaskedChildContext = o)),
      t
    );
  }
  function fs(e, t, n, r) {
    ((e = t.state),
      typeof t.componentWillReceiveProps == "function" &&
        t.componentWillReceiveProps(n, r),
      typeof t.UNSAFE_componentWillReceiveProps == "function" &&
        t.UNSAFE_componentWillReceiveProps(n, r),
      t.state !== e && kl.enqueueReplaceState(t, t.state, null));
  }
  function du(e, t, n, r) {
    var l = e.stateNode;
    ((l.props = n), (l.state = e.memoizedState), (l.refs = {}), qo(e));
    var o = t.contextType;
    (typeof o == "object" && o !== null
      ? (l.context = tt(o))
      : ((o = He(t) ? nn : Me.current), (l.context = _n(e, o))),
      (l.state = e.memoizedState),
      (o = t.getDerivedStateFromProps),
      typeof o == "function" && (fu(e, t, o, n), (l.state = e.memoizedState)),
      typeof t.getDerivedStateFromProps == "function" ||
        typeof l.getSnapshotBeforeUpdate == "function" ||
        (typeof l.UNSAFE_componentWillMount != "function" &&
          typeof l.componentWillMount != "function") ||
        ((t = l.state),
        typeof l.componentWillMount == "function" && l.componentWillMount(),
        typeof l.UNSAFE_componentWillMount == "function" &&
          l.UNSAFE_componentWillMount(),
        t !== l.state && kl.enqueueReplaceState(l, l.state, null),
        hl(e, n, l, r),
        (l.state = e.memoizedState)),
      typeof l.componentDidMount == "function" && (e.flags |= 4194308));
  }
  function Mn(e, t) {
    try {
      var n = "",
        r = t;
      do ((n += te(r)), (r = r.return));
      while (r);
      var l = n;
    } catch (o) {
      l =
        `
Error generating stack: ` +
        o.message +
        `
` +
        o.stack;
    }
    return { value: e, source: t, stack: l, digest: null };
  }
  function pu(e, t, n) {
    return { value: e, source: null, stack: n ?? null, digest: t ?? null };
  }
  function hu(e, t) {
    try {
      console.error(t.value);
    } catch (n) {
      setTimeout(function () {
        throw n;
      });
    }
  }
  var ld = typeof WeakMap == "function" ? WeakMap : Map;
  function ds(e, t, n) {
    ((n = Nt(-1, n)), (n.tag = 3), (n.payload = { element: null }));
    var r = t.value;
    return (
      (n.callback = function () {
        (Ll || ((Ll = !0), (Nu = r)), hu(e, t));
      }),
      n
    );
  }
  function ps(e, t, n) {
    ((n = Nt(-1, n)), (n.tag = 3));
    var r = e.type.getDerivedStateFromError;
    if (typeof r == "function") {
      var l = t.value;
      ((n.payload = function () {
        return r(l);
      }),
        (n.callback = function () {
          hu(e, t);
        }));
    }
    var o = e.stateNode;
    return (
      o !== null &&
        typeof o.componentDidCatch == "function" &&
        (n.callback = function () {
          (hu(e, t),
            typeof r != "function" &&
              (Xt === null ? (Xt = new Set([this])) : Xt.add(this)));
          var i = t.stack;
          this.componentDidCatch(t.value, {
            componentStack: i !== null ? i : "",
          });
        }),
      n
    );
  }
  function hs(e, t, n) {
    var r = e.pingCache;
    if (r === null) {
      r = e.pingCache = new ld();
      var l = new Set();
      r.set(t, l);
    } else ((l = r.get(t)), l === void 0 && ((l = new Set()), r.set(t, l)));
    l.has(n) || (l.add(n), (e = gd.bind(null, e, t, n)), t.then(e, e));
  }
  function ms(e) {
    do {
      var t;
      if (
        ((t = e.tag === 13) &&
          ((t = e.memoizedState),
          (t = t !== null ? t.dehydrated !== null : !0)),
        t)
      )
        return e;
      e = e.return;
    } while (e !== null);
    return null;
  }
  function vs(e, t, n, r, l) {
    return (e.mode & 1) === 0
      ? (e === t
          ? (e.flags |= 65536)
          : ((e.flags |= 128),
            (n.flags |= 131072),
            (n.flags &= -52805),
            n.tag === 1 &&
              (n.alternate === null
                ? (n.tag = 17)
                : ((t = Nt(-1, 1)), (t.tag = 2), Kt(n, t, 1))),
            (n.lanes |= 1)),
        e)
      : ((e.flags |= 65536), (e.lanes = l), e);
  }
  var od = ue.ReactCurrentOwner,
    We = !1;
  function Ue(e, t, n, r) {
    t.child = e === null ? Ia(t, null, n, r) : Tn(t, e.child, n, r);
  }
  function ys(e, t, n, r, l) {
    n = n.render;
    var o = t.ref;
    return (
      On(t, l),
      (r = ou(e, t, n, r, o, l)),
      (n = uu()),
      e !== null && !We
        ? ((t.updateQueue = e.updateQueue),
          (t.flags &= -2053),
          (e.lanes &= ~l),
          Tt(e, t, l))
        : (de && n && Ho(t), (t.flags |= 1), Ue(e, t, r, l), t.child)
    );
  }
  function gs(e, t, n, r, l) {
    if (e === null) {
      var o = n.type;
      return typeof o == "function" &&
        !Iu(o) &&
        o.defaultProps === void 0 &&
        n.compare === null &&
        n.defaultProps === void 0
        ? ((t.tag = 15), (t.type = o), ws(e, t, o, r, l))
        : ((e = Ml(n.type, null, r, t, t.mode, l)),
          (e.ref = t.ref),
          (e.return = t),
          (t.child = e));
    }
    if (((o = e.child), (e.lanes & l) === 0)) {
      var i = o.memoizedProps;
      if (
        ((n = n.compare), (n = n !== null ? n : ur), n(i, r) && e.ref === t.ref)
      )
        return Tt(e, t, l);
    }
    return (
      (t.flags |= 1),
      (e = qt(o, r)),
      (e.ref = t.ref),
      (e.return = t),
      (t.child = e)
    );
  }
  function ws(e, t, n, r, l) {
    if (e !== null) {
      var o = e.memoizedProps;
      if (ur(o, r) && e.ref === t.ref)
        if (((We = !1), (t.pendingProps = r = o), (e.lanes & l) !== 0))
          (e.flags & 131072) !== 0 && (We = !0);
        else return ((t.lanes = e.lanes), Tt(e, t, l));
    }
    return mu(e, t, n, r, l);
  }
  function Ss(e, t, n) {
    var r = t.pendingProps,
      l = r.children,
      o = e !== null ? e.memoizedState : null;
    if (r.mode === "hidden")
      if ((t.mode & 1) === 0)
        ((t.memoizedState = {
          baseLanes: 0,
          cachePool: null,
          transitions: null,
        }),
          ae(In, qe),
          (qe |= n));
      else {
        if ((n & 1073741824) === 0)
          return (
            (e = o !== null ? o.baseLanes | n : n),
            (t.lanes = t.childLanes = 1073741824),
            (t.memoizedState = {
              baseLanes: e,
              cachePool: null,
              transitions: null,
            }),
            (t.updateQueue = null),
            ae(In, qe),
            (qe |= e),
            null
          );
        ((t.memoizedState = {
          baseLanes: 0,
          cachePool: null,
          transitions: null,
        }),
          (r = o !== null ? o.baseLanes : n),
          ae(In, qe),
          (qe |= r));
      }
    else
      (o !== null ? ((r = o.baseLanes | n), (t.memoizedState = null)) : (r = n),
        ae(In, qe),
        (qe |= r));
    return (Ue(e, t, l, n), t.child);
  }
  function ks(e, t) {
    var n = t.ref;
    ((e === null && n !== null) || (e !== null && e.ref !== n)) &&
      ((t.flags |= 512), (t.flags |= 2097152));
  }
  function mu(e, t, n, r, l) {
    var o = He(n) ? nn : Me.current;
    return (
      (o = _n(t, o)),
      On(t, l),
      (n = ou(e, t, n, r, o, l)),
      (r = uu()),
      e !== null && !We
        ? ((t.updateQueue = e.updateQueue),
          (t.flags &= -2053),
          (e.lanes &= ~l),
          Tt(e, t, l))
        : (de && r && Ho(t), (t.flags |= 1), Ue(e, t, n, l), t.child)
    );
  }
  function Es(e, t, n, r, l) {
    if (He(n)) {
      var o = !0;
      ol(t);
    } else o = !1;
    if ((On(t, l), t.stateNode === null))
      (Cl(e, t), cs(t, n, r), du(t, n, r, l), (r = !0));
    else if (e === null) {
      var i = t.stateNode,
        c = t.memoizedProps;
      i.props = c;
      var d = i.context,
        w = n.contextType;
      typeof w == "object" && w !== null
        ? (w = tt(w))
        : ((w = He(n) ? nn : Me.current), (w = _n(t, w)));
      var L = n.getDerivedStateFromProps,
        N =
          typeof L == "function" ||
          typeof i.getSnapshotBeforeUpdate == "function";
      (N ||
        (typeof i.UNSAFE_componentWillReceiveProps != "function" &&
          typeof i.componentWillReceiveProps != "function") ||
        ((c !== r || d !== w) && fs(t, i, r, w)),
        (Qt = !1));
      var _ = t.memoizedState;
      ((i.state = _),
        hl(t, r, i, l),
        (d = t.memoizedState),
        c !== r || _ !== d || Be.current || Qt
          ? (typeof L == "function" && (fu(t, n, L, r), (d = t.memoizedState)),
            (c = Qt || ss(t, n, c, r, _, d, w))
              ? (N ||
                  (typeof i.UNSAFE_componentWillMount != "function" &&
                    typeof i.componentWillMount != "function") ||
                  (typeof i.componentWillMount == "function" &&
                    i.componentWillMount(),
                  typeof i.UNSAFE_componentWillMount == "function" &&
                    i.UNSAFE_componentWillMount()),
                typeof i.componentDidMount == "function" &&
                  (t.flags |= 4194308))
              : (typeof i.componentDidMount == "function" &&
                  (t.flags |= 4194308),
                (t.memoizedProps = r),
                (t.memoizedState = d)),
            (i.props = r),
            (i.state = d),
            (i.context = w),
            (r = c))
          : (typeof i.componentDidMount == "function" && (t.flags |= 4194308),
            (r = !1)));
    } else {
      ((i = t.stateNode),
        Ua(e, t),
        (c = t.memoizedProps),
        (w = t.type === t.elementType ? c : ct(t.type, c)),
        (i.props = w),
        (N = t.pendingProps),
        (_ = i.context),
        (d = n.contextType),
        typeof d == "object" && d !== null
          ? (d = tt(d))
          : ((d = He(n) ? nn : Me.current), (d = _n(t, d))));
      var M = n.getDerivedStateFromProps;
      ((L =
        typeof M == "function" ||
        typeof i.getSnapshotBeforeUpdate == "function") ||
        (typeof i.UNSAFE_componentWillReceiveProps != "function" &&
          typeof i.componentWillReceiveProps != "function") ||
        ((c !== N || _ !== d) && fs(t, i, r, d)),
        (Qt = !1),
        (_ = t.memoizedState),
        (i.state = _),
        hl(t, r, i, l));
      var U = t.memoizedState;
      c !== N || _ !== U || Be.current || Qt
        ? (typeof M == "function" && (fu(t, n, M, r), (U = t.memoizedState)),
          (w = Qt || ss(t, n, w, r, _, U, d) || !1)
            ? (L ||
                (typeof i.UNSAFE_componentWillUpdate != "function" &&
                  typeof i.componentWillUpdate != "function") ||
                (typeof i.componentWillUpdate == "function" &&
                  i.componentWillUpdate(r, U, d),
                typeof i.UNSAFE_componentWillUpdate == "function" &&
                  i.UNSAFE_componentWillUpdate(r, U, d)),
              typeof i.componentDidUpdate == "function" && (t.flags |= 4),
              typeof i.getSnapshotBeforeUpdate == "function" &&
                (t.flags |= 1024))
            : (typeof i.componentDidUpdate != "function" ||
                (c === e.memoizedProps && _ === e.memoizedState) ||
                (t.flags |= 4),
              typeof i.getSnapshotBeforeUpdate != "function" ||
                (c === e.memoizedProps && _ === e.memoizedState) ||
                (t.flags |= 1024),
              (t.memoizedProps = r),
              (t.memoizedState = U)),
          (i.props = r),
          (i.state = U),
          (i.context = d),
          (r = w))
        : (typeof i.componentDidUpdate != "function" ||
            (c === e.memoizedProps && _ === e.memoizedState) ||
            (t.flags |= 4),
          typeof i.getSnapshotBeforeUpdate != "function" ||
            (c === e.memoizedProps && _ === e.memoizedState) ||
            (t.flags |= 1024),
          (r = !1));
    }
    return vu(e, t, n, r, o, l);
  }
  function vu(e, t, n, r, l, o) {
    ks(e, t);
    var i = (t.flags & 128) !== 0;
    if (!r && !i) return (l && Ra(t, n, !1), Tt(e, t, o));
    ((r = t.stateNode), (od.current = t));
    var c =
      i && typeof n.getDerivedStateFromError != "function" ? null : r.render();
    return (
      (t.flags |= 1),
      e !== null && i
        ? ((t.child = Tn(t, e.child, null, o)), (t.child = Tn(t, null, c, o)))
        : Ue(e, t, c, o),
      (t.memoizedState = r.state),
      l && Ra(t, n, !0),
      t.child
    );
  }
  function Cs(e) {
    var t = e.stateNode;
    (t.pendingContext
      ? Pa(e, t.pendingContext, t.pendingContext !== t.context)
      : t.context && Pa(e, t.context, !1),
      bo(e, t.containerInfo));
  }
  function xs(e, t, n, r, l) {
    return (Nn(), Ko(l), (t.flags |= 256), Ue(e, t, n, r), t.child);
  }
  var yu = { dehydrated: null, treeContext: null, retryLane: 0 };
  function gu(e) {
    return { baseLanes: e, cachePool: null, transitions: null };
  }
  function Ps(e, t, n) {
    var r = t.pendingProps,
      l = me.current,
      o = !1,
      i = (t.flags & 128) !== 0,
      c;
    if (
      ((c = i) ||
        (c = e !== null && e.memoizedState === null ? !1 : (l & 2) !== 0),
      c
        ? ((o = !0), (t.flags &= -129))
        : (e === null || e.memoizedState !== null) && (l |= 1),
      ae(me, l & 1),
      e === null)
    )
      return (
        Qo(t),
        (e = t.memoizedState),
        e !== null && ((e = e.dehydrated), e !== null)
          ? ((t.mode & 1) === 0
              ? (t.lanes = 1)
              : e.data === "$!"
                ? (t.lanes = 8)
                : (t.lanes = 1073741824),
            null)
          : ((i = r.children),
            (e = r.fallback),
            o
              ? ((r = t.mode),
                (o = t.child),
                (i = { mode: "hidden", children: i }),
                (r & 1) === 0 && o !== null
                  ? ((o.childLanes = 0), (o.pendingProps = i))
                  : (o = Fl(i, r, 0, null)),
                (e = pn(e, r, n, null)),
                (o.return = t),
                (e.return = t),
                (o.sibling = e),
                (t.child = o),
                (t.child.memoizedState = gu(n)),
                (t.memoizedState = yu),
                e)
              : wu(t, i))
      );
    if (((l = e.memoizedState), l !== null && ((c = l.dehydrated), c !== null)))
      return ud(e, t, i, r, c, l, n);
    if (o) {
      ((o = r.fallback), (i = t.mode), (l = e.child), (c = l.sibling));
      var d = { mode: "hidden", children: r.children };
      return (
        (i & 1) === 0 && t.child !== l
          ? ((r = t.child),
            (r.childLanes = 0),
            (r.pendingProps = d),
            (t.deletions = null))
          : ((r = qt(l, d)), (r.subtreeFlags = l.subtreeFlags & 14680064)),
        c !== null ? (o = qt(c, o)) : ((o = pn(o, i, n, null)), (o.flags |= 2)),
        (o.return = t),
        (r.return = t),
        (r.sibling = o),
        (t.child = r),
        (r = o),
        (o = t.child),
        (i = e.child.memoizedState),
        (i =
          i === null
            ? gu(n)
            : {
                baseLanes: i.baseLanes | n,
                cachePool: null,
                transitions: i.transitions,
              }),
        (o.memoizedState = i),
        (o.childLanes = e.childLanes & ~n),
        (t.memoizedState = yu),
        r
      );
    }
    return (
      (o = e.child),
      (e = o.sibling),
      (r = qt(o, { mode: "visible", children: r.children })),
      (t.mode & 1) === 0 && (r.lanes = n),
      (r.return = t),
      (r.sibling = null),
      e !== null &&
        ((n = t.deletions),
        n === null ? ((t.deletions = [e]), (t.flags |= 16)) : n.push(e)),
      (t.child = r),
      (t.memoizedState = null),
      r
    );
  }
  function wu(e, t) {
    return (
      (t = Fl({ mode: "visible", children: t }, e.mode, 0, null)),
      (t.return = e),
      (e.child = t)
    );
  }
  function El(e, t, n, r) {
    return (
      r !== null && Ko(r),
      Tn(t, e.child, null, n),
      (e = wu(t, t.pendingProps.children)),
      (e.flags |= 2),
      (t.memoizedState = null),
      e
    );
  }
  function ud(e, t, n, r, l, o, i) {
    if (n)
      return t.flags & 256
        ? ((t.flags &= -257), (r = pu(Error(a(422)))), El(e, t, i, r))
        : t.memoizedState !== null
          ? ((t.child = e.child), (t.flags |= 128), null)
          : ((o = r.fallback),
            (l = t.mode),
            (r = Fl({ mode: "visible", children: r.children }, l, 0, null)),
            (o = pn(o, l, i, null)),
            (o.flags |= 2),
            (r.return = t),
            (o.return = t),
            (r.sibling = o),
            (t.child = r),
            (t.mode & 1) !== 0 && Tn(t, e.child, null, i),
            (t.child.memoizedState = gu(i)),
            (t.memoizedState = yu),
            o);
    if ((t.mode & 1) === 0) return El(e, t, i, null);
    if (l.data === "$!") {
      if (((r = l.nextSibling && l.nextSibling.dataset), r)) var c = r.dgst;
      return (
        (r = c),
        (o = Error(a(419))),
        (r = pu(o, r, void 0)),
        El(e, t, i, r)
      );
    }
    if (((c = (i & e.childLanes) !== 0), We || c)) {
      if (((r = Le), r !== null)) {
        switch (i & -i) {
          case 4:
            l = 2;
            break;
          case 16:
            l = 8;
            break;
          case 64:
          case 128:
          case 256:
          case 512:
          case 1024:
          case 2048:
          case 4096:
          case 8192:
          case 16384:
          case 32768:
          case 65536:
          case 131072:
          case 262144:
          case 524288:
          case 1048576:
          case 2097152:
          case 4194304:
          case 8388608:
          case 16777216:
          case 33554432:
          case 67108864:
            l = 32;
            break;
          case 536870912:
            l = 268435456;
            break;
          default:
            l = 0;
        }
        ((l = (l & (r.suspendedLanes | i)) !== 0 ? 0 : l),
          l !== 0 &&
            l !== o.retryLane &&
            ((o.retryLane = l), Lt(e, l), pt(r, e, l, -1)));
      }
      return (Fu(), (r = pu(Error(a(421)))), El(e, t, i, r));
    }
    return l.data === "$?"
      ? ((t.flags |= 128),
        (t.child = e.child),
        (t = wd.bind(null, e)),
        (l._reactRetry = t),
        null)
      : ((e = o.treeContext),
        (Ze = Bt(l.nextSibling)),
        (Je = t),
        (de = !0),
        (st = null),
        e !== null &&
          ((be[et++] = _t),
          (be[et++] = Rt),
          (be[et++] = rn),
          (_t = e.id),
          (Rt = e.overflow),
          (rn = t)),
        (t = wu(t, r.children)),
        (t.flags |= 4096),
        t);
  }
  function _s(e, t, n) {
    e.lanes |= t;
    var r = e.alternate;
    (r !== null && (r.lanes |= t), Jo(e.return, t, n));
  }
  function Su(e, t, n, r, l) {
    var o = e.memoizedState;
    o === null
      ? (e.memoizedState = {
          isBackwards: t,
          rendering: null,
          renderingStartTime: 0,
          last: r,
          tail: n,
          tailMode: l,
        })
      : ((o.isBackwards = t),
        (o.rendering = null),
        (o.renderingStartTime = 0),
        (o.last = r),
        (o.tail = n),
        (o.tailMode = l));
  }
  function Rs(e, t, n) {
    var r = t.pendingProps,
      l = r.revealOrder,
      o = r.tail;
    if ((Ue(e, t, r.children, n), (r = me.current), (r & 2) !== 0))
      ((r = (r & 1) | 2), (t.flags |= 128));
    else {
      if (e !== null && (e.flags & 128) !== 0)
        e: for (e = t.child; e !== null;) {
          if (e.tag === 13) e.memoizedState !== null && _s(e, n, t);
          else if (e.tag === 19) _s(e, n, t);
          else if (e.child !== null) {
            ((e.child.return = e), (e = e.child));
            continue;
          }
          if (e === t) break e;
          for (; e.sibling === null;) {
            if (e.return === null || e.return === t) break e;
            e = e.return;
          }
          ((e.sibling.return = e.return), (e = e.sibling));
        }
      r &= 1;
    }
    if ((ae(me, r), (t.mode & 1) === 0)) t.memoizedState = null;
    else
      switch (l) {
        case "forwards":
          for (n = t.child, l = null; n !== null;)
            ((e = n.alternate),
              e !== null && ml(e) === null && (l = n),
              (n = n.sibling));
          ((n = l),
            n === null
              ? ((l = t.child), (t.child = null))
              : ((l = n.sibling), (n.sibling = null)),
            Su(t, !1, l, n, o));
          break;
        case "backwards":
          for (n = null, l = t.child, t.child = null; l !== null;) {
            if (((e = l.alternate), e !== null && ml(e) === null)) {
              t.child = l;
              break;
            }
            ((e = l.sibling), (l.sibling = n), (n = l), (l = e));
          }
          Su(t, !0, n, null, o);
          break;
        case "together":
          Su(t, !1, null, null, void 0);
          break;
        default:
          t.memoizedState = null;
      }
    return t.child;
  }
  function Cl(e, t) {
    (t.mode & 1) === 0 &&
      e !== null &&
      ((e.alternate = null), (t.alternate = null), (t.flags |= 2));
  }
  function Tt(e, t, n) {
    if (
      (e !== null && (t.dependencies = e.dependencies),
      (sn |= t.lanes),
      (n & t.childLanes) === 0)
    )
      return null;
    if (e !== null && t.child !== e.child) throw Error(a(153));
    if (t.child !== null) {
      for (
        e = t.child, n = qt(e, e.pendingProps), t.child = n, n.return = t;
        e.sibling !== null;
      )
        ((e = e.sibling),
          (n = n.sibling = qt(e, e.pendingProps)),
          (n.return = t));
      n.sibling = null;
    }
    return t.child;
  }
  function id(e, t, n) {
    switch (t.tag) {
      case 3:
        (Cs(t), Nn());
        break;
      case 5:
        Ba(t);
        break;
      case 1:
        He(t.type) && ol(t);
        break;
      case 4:
        bo(t, t.stateNode.containerInfo);
        break;
      case 10:
        var r = t.type._context,
          l = t.memoizedProps.value;
        (ae(fl, r._currentValue), (r._currentValue = l));
        break;
      case 13:
        if (((r = t.memoizedState), r !== null))
          return r.dehydrated !== null
            ? (ae(me, me.current & 1), (t.flags |= 128), null)
            : (n & t.child.childLanes) !== 0
              ? Ps(e, t, n)
              : (ae(me, me.current & 1),
                (e = Tt(e, t, n)),
                e !== null ? e.sibling : null);
        ae(me, me.current & 1);
        break;
      case 19:
        if (((r = (n & t.childLanes) !== 0), (e.flags & 128) !== 0)) {
          if (r) return Rs(e, t, n);
          t.flags |= 128;
        }
        if (
          ((l = t.memoizedState),
          l !== null &&
            ((l.rendering = null), (l.tail = null), (l.lastEffect = null)),
          ae(me, me.current),
          r)
        )
          break;
        return null;
      case 22:
      case 23:
        return ((t.lanes = 0), Ss(e, t, n));
    }
    return Tt(e, t, n);
  }
  var Ls, ku, Ns, Ts;
  ((Ls = function (e, t) {
    for (var n = t.child; n !== null;) {
      if (n.tag === 5 || n.tag === 6) e.appendChild(n.stateNode);
      else if (n.tag !== 4 && n.child !== null) {
        ((n.child.return = n), (n = n.child));
        continue;
      }
      if (n === t) break;
      for (; n.sibling === null;) {
        if (n.return === null || n.return === t) return;
        n = n.return;
      }
      ((n.sibling.return = n.return), (n = n.sibling));
    }
  }),
    (ku = function () {}),
    (Ns = function (e, t, n, r) {
      var l = e.memoizedProps;
      if (l !== r) {
        ((e = t.stateNode), un(kt.current));
        var o = null;
        switch (n) {
          case "input":
            ((l = Gl(e, l)), (r = Gl(e, r)), (o = []));
            break;
          case "select":
            ((l = j({}, l, { value: void 0 })),
              (r = j({}, r, { value: void 0 })),
              (o = []));
            break;
          case "textarea":
            ((l = ql(e, l)), (r = ql(e, r)), (o = []));
            break;
          default:
            typeof l.onClick != "function" &&
              typeof r.onClick == "function" &&
              (e.onclick = nl);
        }
        eo(n, r);
        var i;
        n = null;
        for (w in l)
          if (!r.hasOwnProperty(w) && l.hasOwnProperty(w) && l[w] != null)
            if (w === "style") {
              var c = l[w];
              for (i in c) c.hasOwnProperty(i) && (n || (n = {}), (n[i] = ""));
            } else
              w !== "dangerouslySetInnerHTML" &&
                w !== "children" &&
                w !== "suppressContentEditableWarning" &&
                w !== "suppressHydrationWarning" &&
                w !== "autoFocus" &&
                (p.hasOwnProperty(w)
                  ? o || (o = [])
                  : (o = o || []).push(w, null));
        for (w in r) {
          var d = r[w];
          if (
            ((c = l?.[w]),
            r.hasOwnProperty(w) && d !== c && (d != null || c != null))
          )
            if (w === "style")
              if (c) {
                for (i in c)
                  !c.hasOwnProperty(i) ||
                    (d && d.hasOwnProperty(i)) ||
                    (n || (n = {}), (n[i] = ""));
                for (i in d)
                  d.hasOwnProperty(i) &&
                    c[i] !== d[i] &&
                    (n || (n = {}), (n[i] = d[i]));
              } else (n || (o || (o = []), o.push(w, n)), (n = d));
            else
              w === "dangerouslySetInnerHTML"
                ? ((d = d ? d.__html : void 0),
                  (c = c ? c.__html : void 0),
                  d != null && c !== d && (o = o || []).push(w, d))
                : w === "children"
                  ? (typeof d != "string" && typeof d != "number") ||
                    (o = o || []).push(w, "" + d)
                  : w !== "suppressContentEditableWarning" &&
                    w !== "suppressHydrationWarning" &&
                    (p.hasOwnProperty(w)
                      ? (d != null && w === "onScroll" && se("scroll", e),
                        o || c === d || (o = []))
                      : (o = o || []).push(w, d));
        }
        n && (o = o || []).push("style", n);
        var w = o;
        (t.updateQueue = w) && (t.flags |= 4);
      }
    }),
    (Ts = function (e, t, n, r) {
      n !== r && (t.flags |= 4);
    }));
  function kr(e, t) {
    if (!de)
      switch (e.tailMode) {
        case "hidden":
          t = e.tail;
          for (var n = null; t !== null;)
            (t.alternate !== null && (n = t), (t = t.sibling));
          n === null ? (e.tail = null) : (n.sibling = null);
          break;
        case "collapsed":
          n = e.tail;
          for (var r = null; n !== null;)
            (n.alternate !== null && (r = n), (n = n.sibling));
          r === null
            ? t || e.tail === null
              ? (e.tail = null)
              : (e.tail.sibling = null)
            : (r.sibling = null);
      }
  }
  function Ie(e) {
    var t = e.alternate !== null && e.alternate.child === e.child,
      n = 0,
      r = 0;
    if (t)
      for (var l = e.child; l !== null;)
        ((n |= l.lanes | l.childLanes),
          (r |= l.subtreeFlags & 14680064),
          (r |= l.flags & 14680064),
          (l.return = e),
          (l = l.sibling));
    else
      for (l = e.child; l !== null;)
        ((n |= l.lanes | l.childLanes),
          (r |= l.subtreeFlags),
          (r |= l.flags),
          (l.return = e),
          (l = l.sibling));
    return ((e.subtreeFlags |= r), (e.childLanes = n), t);
  }
  function ad(e, t, n) {
    var r = t.pendingProps;
    switch ((Wo(t), t.tag)) {
      case 2:
      case 16:
      case 15:
      case 0:
      case 11:
      case 7:
      case 8:
      case 12:
      case 9:
      case 14:
        return (Ie(t), null);
      case 1:
        return (He(t.type) && ll(), Ie(t), null);
      case 3:
        return (
          (r = t.stateNode),
          Dn(),
          ce(Be),
          ce(Me),
          nu(),
          r.pendingContext &&
            ((r.context = r.pendingContext), (r.pendingContext = null)),
          (e === null || e.child === null) &&
            (sl(t)
              ? (t.flags |= 4)
              : e === null ||
                (e.memoizedState.isDehydrated && (t.flags & 256) === 0) ||
                ((t.flags |= 1024), st !== null && (Ou(st), (st = null)))),
          ku(e, t),
          Ie(t),
          null
        );
      case 5:
        eu(t);
        var l = un(vr.current);
        if (((n = t.type), e !== null && t.stateNode != null))
          (Ns(e, t, n, r, l),
            e.ref !== t.ref && ((t.flags |= 512), (t.flags |= 2097152)));
        else {
          if (!r) {
            if (t.stateNode === null) throw Error(a(166));
            return (Ie(t), null);
          }
          if (((e = un(kt.current)), sl(t))) {
            ((r = t.stateNode), (n = t.type));
            var o = t.memoizedProps;
            switch (((r[St] = t), (r[fr] = o), (e = (t.mode & 1) !== 0), n)) {
              case "dialog":
                (se("cancel", r), se("close", r));
                break;
              case "iframe":
              case "object":
              case "embed":
                se("load", r);
                break;
              case "video":
              case "audio":
                for (l = 0; l < ar.length; l++) se(ar[l], r);
                break;
              case "source":
                se("error", r);
                break;
              case "img":
              case "image":
              case "link":
                (se("error", r), se("load", r));
                break;
              case "details":
                se("toggle", r);
                break;
              case "input":
                (ci(r, o), se("invalid", r));
                break;
              case "select":
                ((r._wrapperState = { wasMultiple: !!o.multiple }),
                  se("invalid", r));
                break;
              case "textarea":
                (pi(r, o), se("invalid", r));
            }
            (eo(n, o), (l = null));
            for (var i in o)
              if (o.hasOwnProperty(i)) {
                var c = o[i];
                i === "children"
                  ? typeof c == "string"
                    ? r.textContent !== c &&
                      (o.suppressHydrationWarning !== !0 &&
                        tl(r.textContent, c, e),
                      (l = ["children", c]))
                    : typeof c == "number" &&
                      r.textContent !== "" + c &&
                      (o.suppressHydrationWarning !== !0 &&
                        tl(r.textContent, c, e),
                      (l = ["children", "" + c]))
                  : p.hasOwnProperty(i) &&
                    c != null &&
                    i === "onScroll" &&
                    se("scroll", r);
              }
            switch (n) {
              case "input":
                (Or(r), di(r, o, !0));
                break;
              case "textarea":
                (Or(r), mi(r));
                break;
              case "select":
              case "option":
                break;
              default:
                typeof o.onClick == "function" && (r.onclick = nl);
            }
            ((r = l), (t.updateQueue = r), r !== null && (t.flags |= 4));
          } else {
            ((i = l.nodeType === 9 ? l : l.ownerDocument),
              e === "http://www.w3.org/1999/xhtml" && (e = vi(n)),
              e === "http://www.w3.org/1999/xhtml"
                ? n === "script"
                  ? ((e = i.createElement("div")),
                    (e.innerHTML = "<script><\/script>"),
                    (e = e.removeChild(e.firstChild)))
                  : typeof r.is == "string"
                    ? (e = i.createElement(n, { is: r.is }))
                    : ((e = i.createElement(n)),
                      n === "select" &&
                        ((i = e),
                        r.multiple
                          ? (i.multiple = !0)
                          : r.size && (i.size = r.size)))
                : (e = i.createElementNS(e, n)),
              (e[St] = t),
              (e[fr] = r),
              Ls(e, t, !1, !1),
              (t.stateNode = e));
            e: {
              switch (((i = to(n, r)), n)) {
                case "dialog":
                  (se("cancel", e), se("close", e), (l = r));
                  break;
                case "iframe":
                case "object":
                case "embed":
                  (se("load", e), (l = r));
                  break;
                case "video":
                case "audio":
                  for (l = 0; l < ar.length; l++) se(ar[l], e);
                  l = r;
                  break;
                case "source":
                  (se("error", e), (l = r));
                  break;
                case "img":
                case "image":
                case "link":
                  (se("error", e), se("load", e), (l = r));
                  break;
                case "details":
                  (se("toggle", e), (l = r));
                  break;
                case "input":
                  (ci(e, r), (l = Gl(e, r)), se("invalid", e));
                  break;
                case "option":
                  l = r;
                  break;
                case "select":
                  ((e._wrapperState = { wasMultiple: !!r.multiple }),
                    (l = j({}, r, { value: void 0 })),
                    se("invalid", e));
                  break;
                case "textarea":
                  (pi(e, r), (l = ql(e, r)), se("invalid", e));
                  break;
                default:
                  l = r;
              }
              (eo(n, l), (c = l));
              for (o in c)
                if (c.hasOwnProperty(o)) {
                  var d = c[o];
                  o === "style"
                    ? wi(e, d)
                    : o === "dangerouslySetInnerHTML"
                      ? ((d = d ? d.__html : void 0), d != null && yi(e, d))
                      : o === "children"
                        ? typeof d == "string"
                          ? (n !== "textarea" || d !== "") && Wn(e, d)
                          : typeof d == "number" && Wn(e, "" + d)
                        : o !== "suppressContentEditableWarning" &&
                          o !== "suppressHydrationWarning" &&
                          o !== "autoFocus" &&
                          (p.hasOwnProperty(o)
                            ? d != null && o === "onScroll" && se("scroll", e)
                            : d != null && Z(e, o, d, i));
                }
              switch (n) {
                case "input":
                  (Or(e), di(e, r, !1));
                  break;
                case "textarea":
                  (Or(e), mi(e));
                  break;
                case "option":
                  r.value != null && e.setAttribute("value", "" + le(r.value));
                  break;
                case "select":
                  ((e.multiple = !!r.multiple),
                    (o = r.value),
                    o != null
                      ? hn(e, !!r.multiple, o, !1)
                      : r.defaultValue != null &&
                        hn(e, !!r.multiple, r.defaultValue, !0));
                  break;
                default:
                  typeof l.onClick == "function" && (e.onclick = nl);
              }
              switch (n) {
                case "button":
                case "input":
                case "select":
                case "textarea":
                  r = !!r.autoFocus;
                  break e;
                case "img":
                  r = !0;
                  break e;
                default:
                  r = !1;
              }
            }
            r && (t.flags |= 4);
          }
          t.ref !== null && ((t.flags |= 512), (t.flags |= 2097152));
        }
        return (Ie(t), null);
      case 6:
        if (e && t.stateNode != null) Ts(e, t, e.memoizedProps, r);
        else {
          if (typeof r != "string" && t.stateNode === null) throw Error(a(166));
          if (((n = un(vr.current)), un(kt.current), sl(t))) {
            if (
              ((r = t.stateNode),
              (n = t.memoizedProps),
              (r[St] = t),
              (o = r.nodeValue !== n) && ((e = Je), e !== null))
            )
              switch (e.tag) {
                case 3:
                  tl(r.nodeValue, n, (e.mode & 1) !== 0);
                  break;
                case 5:
                  e.memoizedProps.suppressHydrationWarning !== !0 &&
                    tl(r.nodeValue, n, (e.mode & 1) !== 0);
              }
            o && (t.flags |= 4);
          } else
            ((r = (n.nodeType === 9 ? n : n.ownerDocument).createTextNode(r)),
              (r[St] = t),
              (t.stateNode = r));
        }
        return (Ie(t), null);
      case 13:
        if (
          (ce(me),
          (r = t.memoizedState),
          e === null ||
            (e.memoizedState !== null && e.memoizedState.dehydrated !== null))
        ) {
          if (de && Ze !== null && (t.mode & 1) !== 0 && (t.flags & 128) === 0)
            (Da(), Nn(), (t.flags |= 98560), (o = !1));
          else if (((o = sl(t)), r !== null && r.dehydrated !== null)) {
            if (e === null) {
              if (!o) throw Error(a(318));
              if (
                ((o = t.memoizedState),
                (o = o !== null ? o.dehydrated : null),
                !o)
              )
                throw Error(a(317));
              o[St] = t;
            } else
              (Nn(),
                (t.flags & 128) === 0 && (t.memoizedState = null),
                (t.flags |= 4));
            (Ie(t), (o = !1));
          } else (st !== null && (Ou(st), (st = null)), (o = !0));
          if (!o) return t.flags & 65536 ? t : null;
        }
        return (t.flags & 128) !== 0
          ? ((t.lanes = n), t)
          : ((r = r !== null),
            r !== (e !== null && e.memoizedState !== null) &&
              r &&
              ((t.child.flags |= 8192),
              (t.mode & 1) !== 0 &&
                (e === null || (me.current & 1) !== 0
                  ? _e === 0 && (_e = 3)
                  : Fu())),
            t.updateQueue !== null && (t.flags |= 4),
            Ie(t),
            null);
      case 4:
        return (
          Dn(),
          ku(e, t),
          e === null && sr(t.stateNode.containerInfo),
          Ie(t),
          null
        );
      case 10:
        return (Go(t.type._context), Ie(t), null);
      case 17:
        return (He(t.type) && ll(), Ie(t), null);
      case 19:
        if ((ce(me), (o = t.memoizedState), o === null)) return (Ie(t), null);
        if (((r = (t.flags & 128) !== 0), (i = o.rendering), i === null))
          if (r) kr(o, !1);
          else {
            if (_e !== 0 || (e !== null && (e.flags & 128) !== 0))
              for (e = t.child; e !== null;) {
                if (((i = ml(e)), i !== null)) {
                  for (
                    t.flags |= 128,
                      kr(o, !1),
                      r = i.updateQueue,
                      r !== null && ((t.updateQueue = r), (t.flags |= 4)),
                      t.subtreeFlags = 0,
                      r = n,
                      n = t.child;
                    n !== null;
                  )
                    ((o = n),
                      (e = r),
                      (o.flags &= 14680066),
                      (i = o.alternate),
                      i === null
                        ? ((o.childLanes = 0),
                          (o.lanes = e),
                          (o.child = null),
                          (o.subtreeFlags = 0),
                          (o.memoizedProps = null),
                          (o.memoizedState = null),
                          (o.updateQueue = null),
                          (o.dependencies = null),
                          (o.stateNode = null))
                        : ((o.childLanes = i.childLanes),
                          (o.lanes = i.lanes),
                          (o.child = i.child),
                          (o.subtreeFlags = 0),
                          (o.deletions = null),
                          (o.memoizedProps = i.memoizedProps),
                          (o.memoizedState = i.memoizedState),
                          (o.updateQueue = i.updateQueue),
                          (o.type = i.type),
                          (e = i.dependencies),
                          (o.dependencies =
                            e === null
                              ? null
                              : {
                                  lanes: e.lanes,
                                  firstContext: e.firstContext,
                                })),
                      (n = n.sibling));
                  return (ae(me, (me.current & 1) | 2), t.child);
                }
                e = e.sibling;
              }
            o.tail !== null &&
              we() > jn &&
              ((t.flags |= 128), (r = !0), kr(o, !1), (t.lanes = 4194304));
          }
        else {
          if (!r)
            if (((e = ml(i)), e !== null)) {
              if (
                ((t.flags |= 128),
                (r = !0),
                (n = e.updateQueue),
                n !== null && ((t.updateQueue = n), (t.flags |= 4)),
                kr(o, !0),
                o.tail === null &&
                  o.tailMode === "hidden" &&
                  !i.alternate &&
                  !de)
              )
                return (Ie(t), null);
            } else
              2 * we() - o.renderingStartTime > jn &&
                n !== 1073741824 &&
                ((t.flags |= 128), (r = !0), kr(o, !1), (t.lanes = 4194304));
          o.isBackwards
            ? ((i.sibling = t.child), (t.child = i))
            : ((n = o.last),
              n !== null ? (n.sibling = i) : (t.child = i),
              (o.last = i));
        }
        return o.tail !== null
          ? ((t = o.tail),
            (o.rendering = t),
            (o.tail = t.sibling),
            (o.renderingStartTime = we()),
            (t.sibling = null),
            (n = me.current),
            ae(me, r ? (n & 1) | 2 : n & 1),
            t)
          : (Ie(t), null);
      case 22:
      case 23:
        return (
          Mu(),
          (r = t.memoizedState !== null),
          e !== null && (e.memoizedState !== null) !== r && (t.flags |= 8192),
          r && (t.mode & 1) !== 0
            ? (qe & 1073741824) !== 0 &&
              (Ie(t), t.subtreeFlags & 6 && (t.flags |= 8192))
            : Ie(t),
          null
        );
      case 24:
        return null;
      case 25:
        return null;
    }
    throw Error(a(156, t.tag));
  }
  function sd(e, t) {
    switch ((Wo(t), t.tag)) {
      case 1:
        return (
          He(t.type) && ll(),
          (e = t.flags),
          e & 65536 ? ((t.flags = (e & -65537) | 128), t) : null
        );
      case 3:
        return (
          Dn(),
          ce(Be),
          ce(Me),
          nu(),
          (e = t.flags),
          (e & 65536) !== 0 && (e & 128) === 0
            ? ((t.flags = (e & -65537) | 128), t)
            : null
        );
      case 5:
        return (eu(t), null);
      case 13:
        if (
          (ce(me), (e = t.memoizedState), e !== null && e.dehydrated !== null)
        ) {
          if (t.alternate === null) throw Error(a(340));
          Nn();
        }
        return (
          (e = t.flags),
          e & 65536 ? ((t.flags = (e & -65537) | 128), t) : null
        );
      case 19:
        return (ce(me), null);
      case 4:
        return (Dn(), null);
      case 10:
        return (Go(t.type._context), null);
      case 22:
      case 23:
        return (Mu(), null);
      case 24:
        return null;
      default:
        return null;
    }
  }
  var xl = !1,
    je = !1,
    cd = typeof WeakSet == "function" ? WeakSet : Set,
    I = null;
  function Fn(e, t) {
    var n = e.ref;
    if (n !== null)
      if (typeof n == "function")
        try {
          n(null);
        } catch (r) {
          ge(e, t, r);
        }
      else n.current = null;
  }
  function Eu(e, t, n) {
    try {
      n();
    } catch (r) {
      ge(e, t, r);
    }
  }
  var zs = !1;
  function fd(e, t) {
    if (((Mo = Vr), (e = sa()), _o(e))) {
      if ("selectionStart" in e)
        var n = { start: e.selectionStart, end: e.selectionEnd };
      else
        e: {
          n = ((n = e.ownerDocument) && n.defaultView) || window;
          var r = n.getSelection && n.getSelection();
          if (r && r.rangeCount !== 0) {
            n = r.anchorNode;
            var l = r.anchorOffset,
              o = r.focusNode;
            r = r.focusOffset;
            try {
              (n.nodeType, o.nodeType);
            } catch {
              n = null;
              break e;
            }
            var i = 0,
              c = -1,
              d = -1,
              w = 0,
              L = 0,
              N = e,
              _ = null;
            t: for (;;) {
              for (
                var M;
                N !== n || (l !== 0 && N.nodeType !== 3) || (c = i + l),
                  N !== o || (r !== 0 && N.nodeType !== 3) || (d = i + r),
                  N.nodeType === 3 && (i += N.nodeValue.length),
                  (M = N.firstChild) !== null;
              )
                ((_ = N), (N = M));
              for (;;) {
                if (N === e) break t;
                if (
                  (_ === n && ++w === l && (c = i),
                  _ === o && ++L === r && (d = i),
                  (M = N.nextSibling) !== null)
                )
                  break;
                ((N = _), (_ = N.parentNode));
              }
              N = M;
            }
            n = c === -1 || d === -1 ? null : { start: c, end: d };
          } else n = null;
        }
      n = n || { start: 0, end: 0 };
    } else n = null;
    for (
      Fo = { focusedElem: e, selectionRange: n }, Vr = !1, I = t;
      I !== null;
    )
      if (((t = I), (e = t.child), (t.subtreeFlags & 1028) !== 0 && e !== null))
        ((e.return = t), (I = e));
      else
        for (; I !== null;) {
          t = I;
          try {
            var U = t.alternate;
            if ((t.flags & 1024) !== 0)
              switch (t.tag) {
                case 0:
                case 11:
                case 15:
                  break;
                case 1:
                  if (U !== null) {
                    var $ = U.memoizedProps,
                      Se = U.memoizedState,
                      y = t.stateNode,
                      h = y.getSnapshotBeforeUpdate(
                        t.elementType === t.type ? $ : ct(t.type, $),
                        Se,
                      );
                    y.__reactInternalSnapshotBeforeUpdate = h;
                  }
                  break;
                case 3:
                  var g = t.stateNode.containerInfo;
                  g.nodeType === 1
                    ? (g.textContent = "")
                    : g.nodeType === 9 &&
                      g.documentElement &&
                      g.removeChild(g.documentElement);
                  break;
                case 5:
                case 6:
                case 4:
                case 17:
                  break;
                default:
                  throw Error(a(163));
              }
          } catch (T) {
            ge(t, t.return, T);
          }
          if (((e = t.sibling), e !== null)) {
            ((e.return = t.return), (I = e));
            break;
          }
          I = t.return;
        }
    return ((U = zs), (zs = !1), U);
  }
  function Er(e, t, n) {
    var r = t.updateQueue;
    if (((r = r !== null ? r.lastEffect : null), r !== null)) {
      var l = (r = r.next);
      do {
        if ((l.tag & e) === e) {
          var o = l.destroy;
          ((l.destroy = void 0), o !== void 0 && Eu(t, n, o));
        }
        l = l.next;
      } while (l !== r);
    }
  }
  function Pl(e, t) {
    if (
      ((t = t.updateQueue), (t = t !== null ? t.lastEffect : null), t !== null)
    ) {
      var n = (t = t.next);
      do {
        if ((n.tag & e) === e) {
          var r = n.create;
          n.destroy = r();
        }
        n = n.next;
      } while (n !== t);
    }
  }
  function Cu(e) {
    var t = e.ref;
    if (t !== null) {
      var n = e.stateNode;
      switch (e.tag) {
        case 5:
          e = n;
          break;
        default:
          e = n;
      }
      typeof t == "function" ? t(e) : (t.current = e);
    }
  }
  function Os(e) {
    var t = e.alternate;
    (t !== null && ((e.alternate = null), Os(t)),
      (e.child = null),
      (e.deletions = null),
      (e.sibling = null),
      e.tag === 5 &&
        ((t = e.stateNode),
        t !== null &&
          (delete t[St],
          delete t[fr],
          delete t[$o],
          delete t[Yf],
          delete t[Xf])),
      (e.stateNode = null),
      (e.return = null),
      (e.dependencies = null),
      (e.memoizedProps = null),
      (e.memoizedState = null),
      (e.pendingProps = null),
      (e.stateNode = null),
      (e.updateQueue = null));
  }
  function Ds(e) {
    return e.tag === 5 || e.tag === 3 || e.tag === 4;
  }
  function Ms(e) {
    e: for (;;) {
      for (; e.sibling === null;) {
        if (e.return === null || Ds(e.return)) return null;
        e = e.return;
      }
      for (
        e.sibling.return = e.return, e = e.sibling;
        e.tag !== 5 && e.tag !== 6 && e.tag !== 18;
      ) {
        if (e.flags & 2 || e.child === null || e.tag === 4) continue e;
        ((e.child.return = e), (e = e.child));
      }
      if (!(e.flags & 2)) return e.stateNode;
    }
  }
  function xu(e, t, n) {
    var r = e.tag;
    if (r === 5 || r === 6)
      ((e = e.stateNode),
        t
          ? n.nodeType === 8
            ? n.parentNode.insertBefore(e, t)
            : n.insertBefore(e, t)
          : (n.nodeType === 8
              ? ((t = n.parentNode), t.insertBefore(e, n))
              : ((t = n), t.appendChild(e)),
            (n = n._reactRootContainer),
            n != null || t.onclick !== null || (t.onclick = nl)));
    else if (r !== 4 && ((e = e.child), e !== null))
      for (xu(e, t, n), e = e.sibling; e !== null;)
        (xu(e, t, n), (e = e.sibling));
  }
  function Pu(e, t, n) {
    var r = e.tag;
    if (r === 5 || r === 6)
      ((e = e.stateNode), t ? n.insertBefore(e, t) : n.appendChild(e));
    else if (r !== 4 && ((e = e.child), e !== null))
      for (Pu(e, t, n), e = e.sibling; e !== null;)
        (Pu(e, t, n), (e = e.sibling));
  }
  var ze = null,
    ft = !1;
  function Yt(e, t, n) {
    for (n = n.child; n !== null;) (Fs(e, t, n), (n = n.sibling));
  }
  function Fs(e, t, n) {
    if (wt && typeof wt.onCommitFiberUnmount == "function")
      try {
        wt.onCommitFiberUnmount(Ur, n);
      } catch {}
    switch (n.tag) {
      case 5:
        je || Fn(n, t);
      case 6:
        var r = ze,
          l = ft;
        ((ze = null),
          Yt(e, t, n),
          (ze = r),
          (ft = l),
          ze !== null &&
            (ft
              ? ((e = ze),
                (n = n.stateNode),
                e.nodeType === 8
                  ? e.parentNode.removeChild(n)
                  : e.removeChild(n))
              : ze.removeChild(n.stateNode)));
        break;
      case 18:
        ze !== null &&
          (ft
            ? ((e = ze),
              (n = n.stateNode),
              e.nodeType === 8
                ? Uo(e.parentNode, n)
                : e.nodeType === 1 && Uo(e, n),
              er(e))
            : Uo(ze, n.stateNode));
        break;
      case 4:
        ((r = ze),
          (l = ft),
          (ze = n.stateNode.containerInfo),
          (ft = !0),
          Yt(e, t, n),
          (ze = r),
          (ft = l));
        break;
      case 0:
      case 11:
      case 14:
      case 15:
        if (
          !je &&
          ((r = n.updateQueue), r !== null && ((r = r.lastEffect), r !== null))
        ) {
          l = r = r.next;
          do {
            var o = l,
              i = o.destroy;
            ((o = o.tag),
              i !== void 0 && ((o & 2) !== 0 || (o & 4) !== 0) && Eu(n, t, i),
              (l = l.next));
          } while (l !== r);
        }
        Yt(e, t, n);
        break;
      case 1:
        if (
          !je &&
          (Fn(n, t),
          (r = n.stateNode),
          typeof r.componentWillUnmount == "function")
        )
          try {
            ((r.props = n.memoizedProps),
              (r.state = n.memoizedState),
              r.componentWillUnmount());
          } catch (c) {
            ge(n, t, c);
          }
        Yt(e, t, n);
        break;
      case 21:
        Yt(e, t, n);
        break;
      case 22:
        n.mode & 1
          ? ((je = (r = je) || n.memoizedState !== null), Yt(e, t, n), (je = r))
          : Yt(e, t, n);
        break;
      default:
        Yt(e, t, n);
    }
  }
  function Is(e) {
    var t = e.updateQueue;
    if (t !== null) {
      e.updateQueue = null;
      var n = e.stateNode;
      (n === null && (n = e.stateNode = new cd()),
        t.forEach(function (r) {
          var l = Sd.bind(null, e, r);
          n.has(r) || (n.add(r), r.then(l, l));
        }));
    }
  }
  function dt(e, t) {
    var n = t.deletions;
    if (n !== null)
      for (var r = 0; r < n.length; r++) {
        var l = n[r];
        try {
          var o = e,
            i = t,
            c = i;
          e: for (; c !== null;) {
            switch (c.tag) {
              case 5:
                ((ze = c.stateNode), (ft = !1));
                break e;
              case 3:
                ((ze = c.stateNode.containerInfo), (ft = !0));
                break e;
              case 4:
                ((ze = c.stateNode.containerInfo), (ft = !0));
                break e;
            }
            c = c.return;
          }
          if (ze === null) throw Error(a(160));
          (Fs(o, i, l), (ze = null), (ft = !1));
          var d = l.alternate;
          (d !== null && (d.return = null), (l.return = null));
        } catch (w) {
          ge(l, t, w);
        }
      }
    if (t.subtreeFlags & 12854)
      for (t = t.child; t !== null;) (js(t, e), (t = t.sibling));
  }
  function js(e, t) {
    var n = e.alternate,
      r = e.flags;
    switch (e.tag) {
      case 0:
      case 11:
      case 14:
      case 15:
        if ((dt(t, e), Ct(e), r & 4)) {
          try {
            (Er(3, e, e.return), Pl(3, e));
          } catch ($) {
            ge(e, e.return, $);
          }
          try {
            Er(5, e, e.return);
          } catch ($) {
            ge(e, e.return, $);
          }
        }
        break;
      case 1:
        (dt(t, e), Ct(e), r & 512 && n !== null && Fn(n, n.return));
        break;
      case 5:
        if (
          (dt(t, e),
          Ct(e),
          r & 512 && n !== null && Fn(n, n.return),
          e.flags & 32)
        ) {
          var l = e.stateNode;
          try {
            Wn(l, "");
          } catch ($) {
            ge(e, e.return, $);
          }
        }
        if (r & 4 && ((l = e.stateNode), l != null)) {
          var o = e.memoizedProps,
            i = n !== null ? n.memoizedProps : o,
            c = e.type,
            d = e.updateQueue;
          if (((e.updateQueue = null), d !== null))
            try {
              (c === "input" &&
                o.type === "radio" &&
                o.name != null &&
                fi(l, o),
                to(c, i));
              var w = to(c, o);
              for (i = 0; i < d.length; i += 2) {
                var L = d[i],
                  N = d[i + 1];
                L === "style"
                  ? wi(l, N)
                  : L === "dangerouslySetInnerHTML"
                    ? yi(l, N)
                    : L === "children"
                      ? Wn(l, N)
                      : Z(l, L, N, w);
              }
              switch (c) {
                case "input":
                  Jl(l, o);
                  break;
                case "textarea":
                  hi(l, o);
                  break;
                case "select":
                  var _ = l._wrapperState.wasMultiple;
                  l._wrapperState.wasMultiple = !!o.multiple;
                  var M = o.value;
                  M != null
                    ? hn(l, !!o.multiple, M, !1)
                    : _ !== !!o.multiple &&
                      (o.defaultValue != null
                        ? hn(l, !!o.multiple, o.defaultValue, !0)
                        : hn(l, !!o.multiple, o.multiple ? [] : "", !1));
              }
              l[fr] = o;
            } catch ($) {
              ge(e, e.return, $);
            }
        }
        break;
      case 6:
        if ((dt(t, e), Ct(e), r & 4)) {
          if (e.stateNode === null) throw Error(a(162));
          ((l = e.stateNode), (o = e.memoizedProps));
          try {
            l.nodeValue = o;
          } catch ($) {
            ge(e, e.return, $);
          }
        }
        break;
      case 3:
        if (
          (dt(t, e), Ct(e), r & 4 && n !== null && n.memoizedState.isDehydrated)
        )
          try {
            er(t.containerInfo);
          } catch ($) {
            ge(e, e.return, $);
          }
        break;
      case 4:
        (dt(t, e), Ct(e));
        break;
      case 13:
        (dt(t, e),
          Ct(e),
          (l = e.child),
          l.flags & 8192 &&
            ((o = l.memoizedState !== null),
            (l.stateNode.isHidden = o),
            !o ||
              (l.alternate !== null && l.alternate.memoizedState !== null) ||
              (Lu = we())),
          r & 4 && Is(e));
        break;
      case 22:
        if (
          ((L = n !== null && n.memoizedState !== null),
          e.mode & 1 ? ((je = (w = je) || L), dt(t, e), (je = w)) : dt(t, e),
          Ct(e),
          r & 8192)
        ) {
          if (
            ((w = e.memoizedState !== null),
            (e.stateNode.isHidden = w) && !L && (e.mode & 1) !== 0)
          )
            for (I = e, L = e.child; L !== null;) {
              for (N = I = L; I !== null;) {
                switch (((_ = I), (M = _.child), _.tag)) {
                  case 0:
                  case 11:
                  case 14:
                  case 15:
                    Er(4, _, _.return);
                    break;
                  case 1:
                    Fn(_, _.return);
                    var U = _.stateNode;
                    if (typeof U.componentWillUnmount == "function") {
                      ((r = _), (n = _.return));
                      try {
                        ((t = r),
                          (U.props = t.memoizedProps),
                          (U.state = t.memoizedState),
                          U.componentWillUnmount());
                      } catch ($) {
                        ge(r, n, $);
                      }
                    }
                    break;
                  case 5:
                    Fn(_, _.return);
                    break;
                  case 22:
                    if (_.memoizedState !== null) {
                      As(N);
                      continue;
                    }
                }
                M !== null ? ((M.return = _), (I = M)) : As(N);
              }
              L = L.sibling;
            }
          e: for (L = null, N = e; ;) {
            if (N.tag === 5) {
              if (L === null) {
                L = N;
                try {
                  ((l = N.stateNode),
                    w
                      ? ((o = l.style),
                        typeof o.setProperty == "function"
                          ? o.setProperty("display", "none", "important")
                          : (o.display = "none"))
                      : ((c = N.stateNode),
                        (d = N.memoizedProps.style),
                        (i =
                          d != null && d.hasOwnProperty("display")
                            ? d.display
                            : null),
                        (c.style.display = gi("display", i))));
                } catch ($) {
                  ge(e, e.return, $);
                }
              }
            } else if (N.tag === 6) {
              if (L === null)
                try {
                  N.stateNode.nodeValue = w ? "" : N.memoizedProps;
                } catch ($) {
                  ge(e, e.return, $);
                }
            } else if (
              ((N.tag !== 22 && N.tag !== 23) ||
                N.memoizedState === null ||
                N === e) &&
              N.child !== null
            ) {
              ((N.child.return = N), (N = N.child));
              continue;
            }
            if (N === e) break e;
            for (; N.sibling === null;) {
              if (N.return === null || N.return === e) break e;
              (L === N && (L = null), (N = N.return));
            }
            (L === N && (L = null),
              (N.sibling.return = N.return),
              (N = N.sibling));
          }
        }
        break;
      case 19:
        (dt(t, e), Ct(e), r & 4 && Is(e));
        break;
      case 21:
        break;
      default:
        (dt(t, e), Ct(e));
    }
  }
  function Ct(e) {
    var t = e.flags;
    if (t & 2) {
      try {
        e: {
          for (var n = e.return; n !== null;) {
            if (Ds(n)) {
              var r = n;
              break e;
            }
            n = n.return;
          }
          throw Error(a(160));
        }
        switch (r.tag) {
          case 5:
            var l = r.stateNode;
            r.flags & 32 && (Wn(l, ""), (r.flags &= -33));
            var o = Ms(e);
            Pu(e, o, l);
            break;
          case 3:
          case 4:
            var i = r.stateNode.containerInfo,
              c = Ms(e);
            xu(e, c, i);
            break;
          default:
            throw Error(a(161));
        }
      } catch (d) {
        ge(e, e.return, d);
      }
      e.flags &= -3;
    }
    t & 4096 && (e.flags &= -4097);
  }
  function dd(e, t, n) {
    ((I = e), Us(e));
  }
  function Us(e, t, n) {
    for (var r = (e.mode & 1) !== 0; I !== null;) {
      var l = I,
        o = l.child;
      if (l.tag === 22 && r) {
        var i = l.memoizedState !== null || xl;
        if (!i) {
          var c = l.alternate,
            d = (c !== null && c.memoizedState !== null) || je;
          c = xl;
          var w = je;
          if (((xl = i), (je = d) && !w))
            for (I = l; I !== null;)
              ((i = I),
                (d = i.child),
                i.tag === 22 && i.memoizedState !== null
                  ? Bs(l)
                  : d !== null
                    ? ((d.return = i), (I = d))
                    : Bs(l));
          for (; o !== null;) ((I = o), Us(o), (o = o.sibling));
          ((I = l), (xl = c), (je = w));
        }
        $s(e);
      } else
        (l.subtreeFlags & 8772) !== 0 && o !== null
          ? ((o.return = l), (I = o))
          : $s(e);
    }
  }
  function $s(e) {
    for (; I !== null;) {
      var t = I;
      if ((t.flags & 8772) !== 0) {
        var n = t.alternate;
        try {
          if ((t.flags & 8772) !== 0)
            switch (t.tag) {
              case 0:
              case 11:
              case 15:
                je || Pl(5, t);
                break;
              case 1:
                var r = t.stateNode;
                if (t.flags & 4 && !je)
                  if (n === null) r.componentDidMount();
                  else {
                    var l =
                      t.elementType === t.type
                        ? n.memoizedProps
                        : ct(t.type, n.memoizedProps);
                    r.componentDidUpdate(
                      l,
                      n.memoizedState,
                      r.__reactInternalSnapshotBeforeUpdate,
                    );
                  }
                var o = t.updateQueue;
                o !== null && Aa(t, o, r);
                break;
              case 3:
                var i = t.updateQueue;
                if (i !== null) {
                  if (((n = null), t.child !== null))
                    switch (t.child.tag) {
                      case 5:
                        n = t.child.stateNode;
                        break;
                      case 1:
                        n = t.child.stateNode;
                    }
                  Aa(t, i, n);
                }
                break;
              case 5:
                var c = t.stateNode;
                if (n === null && t.flags & 4) {
                  n = c;
                  var d = t.memoizedProps;
                  switch (t.type) {
                    case "button":
                    case "input":
                    case "select":
                    case "textarea":
                      d.autoFocus && n.focus();
                      break;
                    case "img":
                      d.src && (n.src = d.src);
                  }
                }
                break;
              case 6:
                break;
              case 4:
                break;
              case 12:
                break;
              case 13:
                if (t.memoizedState === null) {
                  var w = t.alternate;
                  if (w !== null) {
                    var L = w.memoizedState;
                    if (L !== null) {
                      var N = L.dehydrated;
                      N !== null && er(N);
                    }
                  }
                }
                break;
              case 19:
              case 17:
              case 21:
              case 22:
              case 23:
              case 25:
                break;
              default:
                throw Error(a(163));
            }
          je || (t.flags & 512 && Cu(t));
        } catch (_) {
          ge(t, t.return, _);
        }
      }
      if (t === e) {
        I = null;
        break;
      }
      if (((n = t.sibling), n !== null)) {
        ((n.return = t.return), (I = n));
        break;
      }
      I = t.return;
    }
  }
  function As(e) {
    for (; I !== null;) {
      var t = I;
      if (t === e) {
        I = null;
        break;
      }
      var n = t.sibling;
      if (n !== null) {
        ((n.return = t.return), (I = n));
        break;
      }
      I = t.return;
    }
  }
  function Bs(e) {
    for (; I !== null;) {
      var t = I;
      try {
        switch (t.tag) {
          case 0:
          case 11:
          case 15:
            var n = t.return;
            try {
              Pl(4, t);
            } catch (d) {
              ge(t, n, d);
            }
            break;
          case 1:
            var r = t.stateNode;
            if (typeof r.componentDidMount == "function") {
              var l = t.return;
              try {
                r.componentDidMount();
              } catch (d) {
                ge(t, l, d);
              }
            }
            var o = t.return;
            try {
              Cu(t);
            } catch (d) {
              ge(t, o, d);
            }
            break;
          case 5:
            var i = t.return;
            try {
              Cu(t);
            } catch (d) {
              ge(t, i, d);
            }
        }
      } catch (d) {
        ge(t, t.return, d);
      }
      if (t === e) {
        I = null;
        break;
      }
      var c = t.sibling;
      if (c !== null) {
        ((c.return = t.return), (I = c));
        break;
      }
      I = t.return;
    }
  }
  var pd = Math.ceil,
    _l = ue.ReactCurrentDispatcher,
    _u = ue.ReactCurrentOwner,
    rt = ue.ReactCurrentBatchConfig,
    ee = 0,
    Le = null,
    xe = null,
    Oe = 0,
    qe = 0,
    In = Ht(0),
    _e = 0,
    Cr = null,
    sn = 0,
    Rl = 0,
    Ru = 0,
    xr = null,
    Ve = null,
    Lu = 0,
    jn = 1 / 0,
    zt = null,
    Ll = !1,
    Nu = null,
    Xt = null,
    Nl = !1,
    Gt = null,
    Tl = 0,
    Pr = 0,
    Tu = null,
    zl = -1,
    Ol = 0;
  function $e() {
    return (ee & 6) !== 0 ? we() : zl !== -1 ? zl : (zl = we());
  }
  function Jt(e) {
    return (e.mode & 1) === 0
      ? 1
      : (ee & 2) !== 0 && Oe !== 0
        ? Oe & -Oe
        : Jf.transition !== null
          ? (Ol === 0 && (Ol = Mi()), Ol)
          : ((e = oe),
            e !== 0 ||
              ((e = window.event), (e = e === void 0 ? 16 : Wi(e.type))),
            e);
  }
  function pt(e, t, n, r) {
    if (50 < Pr) throw ((Pr = 0), (Tu = null), Error(a(185)));
    (Gn(e, n, r),
      ((ee & 2) === 0 || e !== Le) &&
        (e === Le && ((ee & 2) === 0 && (Rl |= n), _e === 4 && Zt(e, Oe)),
        Qe(e, r),
        n === 1 &&
          ee === 0 &&
          (t.mode & 1) === 0 &&
          ((jn = we() + 500), ul && Vt())));
  }
  function Qe(e, t) {
    var n = e.callbackNode;
    Gc(e, t);
    var r = Br(e, e === Le ? Oe : 0);
    if (r === 0)
      (n !== null && zi(n), (e.callbackNode = null), (e.callbackPriority = 0));
    else if (((t = r & -r), e.callbackPriority !== t)) {
      if ((n != null && zi(n), t === 1))
        (e.tag === 0 ? Gf(Ws.bind(null, e)) : La(Ws.bind(null, e)),
          Qf(function () {
            (ee & 6) === 0 && Vt();
          }),
          (n = null));
      else {
        switch (Fi(r)) {
          case 1:
            n = ao;
            break;
          case 4:
            n = Oi;
            break;
          case 16:
            n = jr;
            break;
          case 536870912:
            n = Di;
            break;
          default:
            n = jr;
        }
        n = Zs(n, Hs.bind(null, e));
      }
      ((e.callbackPriority = t), (e.callbackNode = n));
    }
  }
  function Hs(e, t) {
    if (((zl = -1), (Ol = 0), (ee & 6) !== 0)) throw Error(a(327));
    var n = e.callbackNode;
    if (Un() && e.callbackNode !== n) return null;
    var r = Br(e, e === Le ? Oe : 0);
    if (r === 0) return null;
    if ((r & 30) !== 0 || (r & e.expiredLanes) !== 0 || t) t = Dl(e, r);
    else {
      t = r;
      var l = ee;
      ee |= 2;
      var o = Qs();
      (Le !== e || Oe !== t) && ((zt = null), (jn = we() + 500), fn(e, t));
      do
        try {
          vd();
          break;
        } catch (c) {
          Vs(e, c);
        }
      while (!0);
      (Xo(),
        (_l.current = o),
        (ee = l),
        xe !== null ? (t = 0) : ((Le = null), (Oe = 0), (t = _e)));
    }
    if (t !== 0) {
      if (
        (t === 2 && ((l = so(e)), l !== 0 && ((r = l), (t = zu(e, l)))),
        t === 1)
      )
        throw ((n = Cr), fn(e, 0), Zt(e, r), Qe(e, we()), n);
      if (t === 6) Zt(e, r);
      else {
        if (
          ((l = e.current.alternate),
          (r & 30) === 0 &&
            !hd(l) &&
            ((t = Dl(e, r)),
            t === 2 && ((o = so(e)), o !== 0 && ((r = o), (t = zu(e, o)))),
            t === 1))
        )
          throw ((n = Cr), fn(e, 0), Zt(e, r), Qe(e, we()), n);
        switch (((e.finishedWork = l), (e.finishedLanes = r), t)) {
          case 0:
          case 1:
            throw Error(a(345));
          case 2:
            dn(e, Ve, zt);
            break;
          case 3:
            if (
              (Zt(e, r),
              (r & 130023424) === r && ((t = Lu + 500 - we()), 10 < t))
            ) {
              if (Br(e, 0) !== 0) break;
              if (((l = e.suspendedLanes), (l & r) !== r)) {
                ($e(), (e.pingedLanes |= e.suspendedLanes & l));
                break;
              }
              e.timeoutHandle = jo(dn.bind(null, e, Ve, zt), t);
              break;
            }
            dn(e, Ve, zt);
            break;
          case 4:
            if ((Zt(e, r), (r & 4194240) === r)) break;
            for (t = e.eventTimes, l = -1; 0 < r;) {
              var i = 31 - it(r);
              ((o = 1 << i), (i = t[i]), i > l && (l = i), (r &= ~o));
            }
            if (
              ((r = l),
              (r = we() - r),
              (r =
                (120 > r
                  ? 120
                  : 480 > r
                    ? 480
                    : 1080 > r
                      ? 1080
                      : 1920 > r
                        ? 1920
                        : 3e3 > r
                          ? 3e3
                          : 4320 > r
                            ? 4320
                            : 1960 * pd(r / 1960)) - r),
              10 < r)
            ) {
              e.timeoutHandle = jo(dn.bind(null, e, Ve, zt), r);
              break;
            }
            dn(e, Ve, zt);
            break;
          case 5:
            dn(e, Ve, zt);
            break;
          default:
            throw Error(a(329));
        }
      }
    }
    return (Qe(e, we()), e.callbackNode === n ? Hs.bind(null, e) : null);
  }
  function zu(e, t) {
    var n = xr;
    return (
      e.current.memoizedState.isDehydrated && (fn(e, t).flags |= 256),
      (e = Dl(e, t)),
      e !== 2 && ((t = Ve), (Ve = n), t !== null && Ou(t)),
      e
    );
  }
  function Ou(e) {
    Ve === null ? (Ve = e) : Ve.push.apply(Ve, e);
  }
  function hd(e) {
    for (var t = e; ;) {
      if (t.flags & 16384) {
        var n = t.updateQueue;
        if (n !== null && ((n = n.stores), n !== null))
          for (var r = 0; r < n.length; r++) {
            var l = n[r],
              o = l.getSnapshot;
            l = l.value;
            try {
              if (!at(o(), l)) return !1;
            } catch {
              return !1;
            }
          }
      }
      if (((n = t.child), t.subtreeFlags & 16384 && n !== null))
        ((n.return = t), (t = n));
      else {
        if (t === e) break;
        for (; t.sibling === null;) {
          if (t.return === null || t.return === e) return !0;
          t = t.return;
        }
        ((t.sibling.return = t.return), (t = t.sibling));
      }
    }
    return !0;
  }
  function Zt(e, t) {
    for (
      t &= ~Ru,
        t &= ~Rl,
        e.suspendedLanes |= t,
        e.pingedLanes &= ~t,
        e = e.expirationTimes;
      0 < t;
    ) {
      var n = 31 - it(t),
        r = 1 << n;
      ((e[n] = -1), (t &= ~r));
    }
  }
  function Ws(e) {
    if ((ee & 6) !== 0) throw Error(a(327));
    Un();
    var t = Br(e, 0);
    if ((t & 1) === 0) return (Qe(e, we()), null);
    var n = Dl(e, t);
    if (e.tag !== 0 && n === 2) {
      var r = so(e);
      r !== 0 && ((t = r), (n = zu(e, r)));
    }
    if (n === 1) throw ((n = Cr), fn(e, 0), Zt(e, t), Qe(e, we()), n);
    if (n === 6) throw Error(a(345));
    return (
      (e.finishedWork = e.current.alternate),
      (e.finishedLanes = t),
      dn(e, Ve, zt),
      Qe(e, we()),
      null
    );
  }
  function Du(e, t) {
    var n = ee;
    ee |= 1;
    try {
      return e(t);
    } finally {
      ((ee = n), ee === 0 && ((jn = we() + 500), ul && Vt()));
    }
  }
  function cn(e) {
    Gt !== null && Gt.tag === 0 && (ee & 6) === 0 && Un();
    var t = ee;
    ee |= 1;
    var n = rt.transition,
      r = oe;
    try {
      if (((rt.transition = null), (oe = 1), e)) return e();
    } finally {
      ((oe = r), (rt.transition = n), (ee = t), (ee & 6) === 0 && Vt());
    }
  }
  function Mu() {
    ((qe = In.current), ce(In));
  }
  function fn(e, t) {
    ((e.finishedWork = null), (e.finishedLanes = 0));
    var n = e.timeoutHandle;
    if ((n !== -1 && ((e.timeoutHandle = -1), Vf(n)), xe !== null))
      for (n = xe.return; n !== null;) {
        var r = n;
        switch ((Wo(r), r.tag)) {
          case 1:
            ((r = r.type.childContextTypes), r != null && ll());
            break;
          case 3:
            (Dn(), ce(Be), ce(Me), nu());
            break;
          case 5:
            eu(r);
            break;
          case 4:
            Dn();
            break;
          case 13:
            ce(me);
            break;
          case 19:
            ce(me);
            break;
          case 10:
            Go(r.type._context);
            break;
          case 22:
          case 23:
            Mu();
        }
        n = n.return;
      }
    if (
      ((Le = e),
      (xe = e = qt(e.current, null)),
      (Oe = qe = t),
      (_e = 0),
      (Cr = null),
      (Ru = Rl = sn = 0),
      (Ve = xr = null),
      on !== null)
    ) {
      for (t = 0; t < on.length; t++)
        if (((n = on[t]), (r = n.interleaved), r !== null)) {
          n.interleaved = null;
          var l = r.next,
            o = n.pending;
          if (o !== null) {
            var i = o.next;
            ((o.next = l), (r.next = i));
          }
          n.pending = r;
        }
      on = null;
    }
    return e;
  }
  function Vs(e, t) {
    do {
      var n = xe;
      try {
        if ((Xo(), (vl.current = Sl), yl)) {
          for (var r = ve.memoizedState; r !== null;) {
            var l = r.queue;
            (l !== null && (l.pending = null), (r = r.next));
          }
          yl = !1;
        }
        if (
          ((an = 0),
          (Re = Pe = ve = null),
          (yr = !1),
          (gr = 0),
          (_u.current = null),
          n === null || n.return === null)
        ) {
          ((_e = 1), (Cr = t), (xe = null));
          break;
        }
        e: {
          var o = e,
            i = n.return,
            c = n,
            d = t;
          if (
            ((t = Oe),
            (c.flags |= 32768),
            d !== null && typeof d == "object" && typeof d.then == "function")
          ) {
            var w = d,
              L = c,
              N = L.tag;
            if ((L.mode & 1) === 0 && (N === 0 || N === 11 || N === 15)) {
              var _ = L.alternate;
              _
                ? ((L.updateQueue = _.updateQueue),
                  (L.memoizedState = _.memoizedState),
                  (L.lanes = _.lanes))
                : ((L.updateQueue = null), (L.memoizedState = null));
            }
            var M = ms(i);
            if (M !== null) {
              ((M.flags &= -257),
                vs(M, i, c, o, t),
                M.mode & 1 && hs(o, w, t),
                (t = M),
                (d = w));
              var U = t.updateQueue;
              if (U === null) {
                var $ = new Set();
                ($.add(d), (t.updateQueue = $));
              } else U.add(d);
              break e;
            } else {
              if ((t & 1) === 0) {
                (hs(o, w, t), Fu());
                break e;
              }
              d = Error(a(426));
            }
          } else if (de && c.mode & 1) {
            var Se = ms(i);
            if (Se !== null) {
              ((Se.flags & 65536) === 0 && (Se.flags |= 256),
                vs(Se, i, c, o, t),
                Ko(Mn(d, c)));
              break e;
            }
          }
          ((o = d = Mn(d, c)),
            _e !== 4 && (_e = 2),
            xr === null ? (xr = [o]) : xr.push(o),
            (o = i));
          do {
            switch (o.tag) {
              case 3:
                ((o.flags |= 65536), (t &= -t), (o.lanes |= t));
                var y = ds(o, d, t);
                $a(o, y);
                break e;
              case 1:
                c = d;
                var h = o.type,
                  g = o.stateNode;
                if (
                  (o.flags & 128) === 0 &&
                  (typeof h.getDerivedStateFromError == "function" ||
                    (g !== null &&
                      typeof g.componentDidCatch == "function" &&
                      (Xt === null || !Xt.has(g))))
                ) {
                  ((o.flags |= 65536), (t &= -t), (o.lanes |= t));
                  var T = ps(o, c, t);
                  $a(o, T);
                  break e;
                }
            }
            o = o.return;
          } while (o !== null);
        }
        Ys(n);
      } catch (B) {
        ((t = B), xe === n && n !== null && (xe = n = n.return));
        continue;
      }
      break;
    } while (!0);
  }
  function Qs() {
    var e = _l.current;
    return ((_l.current = Sl), e === null ? Sl : e);
  }
  function Fu() {
    ((_e === 0 || _e === 3 || _e === 2) && (_e = 4),
      Le === null ||
        ((sn & 268435455) === 0 && (Rl & 268435455) === 0) ||
        Zt(Le, Oe));
  }
  function Dl(e, t) {
    var n = ee;
    ee |= 2;
    var r = Qs();
    (Le !== e || Oe !== t) && ((zt = null), fn(e, t));
    do
      try {
        md();
        break;
      } catch (l) {
        Vs(e, l);
      }
    while (!0);
    if ((Xo(), (ee = n), (_l.current = r), xe !== null)) throw Error(a(261));
    return ((Le = null), (Oe = 0), _e);
  }
  function md() {
    for (; xe !== null;) Ks(xe);
  }
  function vd() {
    for (; xe !== null && !Ac();) Ks(xe);
  }
  function Ks(e) {
    var t = Js(e.alternate, e, qe);
    ((e.memoizedProps = e.pendingProps),
      t === null ? Ys(e) : (xe = t),
      (_u.current = null));
  }
  function Ys(e) {
    var t = e;
    do {
      var n = t.alternate;
      if (((e = t.return), (t.flags & 32768) === 0)) {
        if (((n = ad(n, t, qe)), n !== null)) {
          xe = n;
          return;
        }
      } else {
        if (((n = sd(n, t)), n !== null)) {
          ((n.flags &= 32767), (xe = n));
          return;
        }
        if (e !== null)
          ((e.flags |= 32768), (e.subtreeFlags = 0), (e.deletions = null));
        else {
          ((_e = 6), (xe = null));
          return;
        }
      }
      if (((t = t.sibling), t !== null)) {
        xe = t;
        return;
      }
      xe = t = e;
    } while (t !== null);
    _e === 0 && (_e = 5);
  }
  function dn(e, t, n) {
    var r = oe,
      l = rt.transition;
    try {
      ((rt.transition = null), (oe = 1), yd(e, t, n, r));
    } finally {
      ((rt.transition = l), (oe = r));
    }
    return null;
  }
  function yd(e, t, n, r) {
    do Un();
    while (Gt !== null);
    if ((ee & 6) !== 0) throw Error(a(327));
    n = e.finishedWork;
    var l = e.finishedLanes;
    if (n === null) return null;
    if (((e.finishedWork = null), (e.finishedLanes = 0), n === e.current))
      throw Error(a(177));
    ((e.callbackNode = null), (e.callbackPriority = 0));
    var o = n.lanes | n.childLanes;
    if (
      (Jc(e, o),
      e === Le && ((xe = Le = null), (Oe = 0)),
      ((n.subtreeFlags & 2064) === 0 && (n.flags & 2064) === 0) ||
        Nl ||
        ((Nl = !0),
        Zs(jr, function () {
          return (Un(), null);
        })),
      (o = (n.flags & 15990) !== 0),
      (n.subtreeFlags & 15990) !== 0 || o)
    ) {
      ((o = rt.transition), (rt.transition = null));
      var i = oe;
      oe = 1;
      var c = ee;
      ((ee |= 4),
        (_u.current = null),
        fd(e, n),
        js(n, e),
        jf(Fo),
        (Vr = !!Mo),
        (Fo = Mo = null),
        (e.current = n),
        dd(n),
        Bc(),
        (ee = c),
        (oe = i),
        (rt.transition = o));
    } else e.current = n;
    if (
      (Nl && ((Nl = !1), (Gt = e), (Tl = l)),
      (o = e.pendingLanes),
      o === 0 && (Xt = null),
      Vc(n.stateNode),
      Qe(e, we()),
      t !== null)
    )
      for (r = e.onRecoverableError, n = 0; n < t.length; n++)
        ((l = t[n]), r(l.value, { componentStack: l.stack, digest: l.digest }));
    if (Ll) throw ((Ll = !1), (e = Nu), (Nu = null), e);
    return (
      (Tl & 1) !== 0 && e.tag !== 0 && Un(),
      (o = e.pendingLanes),
      (o & 1) !== 0 ? (e === Tu ? Pr++ : ((Pr = 0), (Tu = e))) : (Pr = 0),
      Vt(),
      null
    );
  }
  function Un() {
    if (Gt !== null) {
      var e = Fi(Tl),
        t = rt.transition,
        n = oe;
      try {
        if (((rt.transition = null), (oe = 16 > e ? 16 : e), Gt === null))
          var r = !1;
        else {
          if (((e = Gt), (Gt = null), (Tl = 0), (ee & 6) !== 0))
            throw Error(a(331));
          var l = ee;
          for (ee |= 4, I = e.current; I !== null;) {
            var o = I,
              i = o.child;
            if ((I.flags & 16) !== 0) {
              var c = o.deletions;
              if (c !== null) {
                for (var d = 0; d < c.length; d++) {
                  var w = c[d];
                  for (I = w; I !== null;) {
                    var L = I;
                    switch (L.tag) {
                      case 0:
                      case 11:
                      case 15:
                        Er(8, L, o);
                    }
                    var N = L.child;
                    if (N !== null) ((N.return = L), (I = N));
                    else
                      for (; I !== null;) {
                        L = I;
                        var _ = L.sibling,
                          M = L.return;
                        if ((Os(L), L === w)) {
                          I = null;
                          break;
                        }
                        if (_ !== null) {
                          ((_.return = M), (I = _));
                          break;
                        }
                        I = M;
                      }
                  }
                }
                var U = o.alternate;
                if (U !== null) {
                  var $ = U.child;
                  if ($ !== null) {
                    U.child = null;
                    do {
                      var Se = $.sibling;
                      (($.sibling = null), ($ = Se));
                    } while ($ !== null);
                  }
                }
                I = o;
              }
            }
            if ((o.subtreeFlags & 2064) !== 0 && i !== null)
              ((i.return = o), (I = i));
            else
              e: for (; I !== null;) {
                if (((o = I), (o.flags & 2048) !== 0))
                  switch (o.tag) {
                    case 0:
                    case 11:
                    case 15:
                      Er(9, o, o.return);
                  }
                var y = o.sibling;
                if (y !== null) {
                  ((y.return = o.return), (I = y));
                  break e;
                }
                I = o.return;
              }
          }
          var h = e.current;
          for (I = h; I !== null;) {
            i = I;
            var g = i.child;
            if ((i.subtreeFlags & 2064) !== 0 && g !== null)
              ((g.return = i), (I = g));
            else
              e: for (i = h; I !== null;) {
                if (((c = I), (c.flags & 2048) !== 0))
                  try {
                    switch (c.tag) {
                      case 0:
                      case 11:
                      case 15:
                        Pl(9, c);
                    }
                  } catch (B) {
                    ge(c, c.return, B);
                  }
                if (c === i) {
                  I = null;
                  break e;
                }
                var T = c.sibling;
                if (T !== null) {
                  ((T.return = c.return), (I = T));
                  break e;
                }
                I = c.return;
              }
          }
          if (
            ((ee = l),
            Vt(),
            wt && typeof wt.onPostCommitFiberRoot == "function")
          )
            try {
              wt.onPostCommitFiberRoot(Ur, e);
            } catch {}
          r = !0;
        }
        return r;
      } finally {
        ((oe = n), (rt.transition = t));
      }
    }
    return !1;
  }
  function Xs(e, t, n) {
    ((t = Mn(n, t)),
      (t = ds(e, t, 1)),
      (e = Kt(e, t, 1)),
      (t = $e()),
      e !== null && (Gn(e, 1, t), Qe(e, t)));
  }
  function ge(e, t, n) {
    if (e.tag === 3) Xs(e, e, n);
    else
      for (; t !== null;) {
        if (t.tag === 3) {
          Xs(t, e, n);
          break;
        } else if (t.tag === 1) {
          var r = t.stateNode;
          if (
            typeof t.type.getDerivedStateFromError == "function" ||
            (typeof r.componentDidCatch == "function" &&
              (Xt === null || !Xt.has(r)))
          ) {
            ((e = Mn(n, e)),
              (e = ps(t, e, 1)),
              (t = Kt(t, e, 1)),
              (e = $e()),
              t !== null && (Gn(t, 1, e), Qe(t, e)));
            break;
          }
        }
        t = t.return;
      }
  }
  function gd(e, t, n) {
    var r = e.pingCache;
    (r !== null && r.delete(t),
      (t = $e()),
      (e.pingedLanes |= e.suspendedLanes & n),
      Le === e &&
        (Oe & n) === n &&
        (_e === 4 || (_e === 3 && (Oe & 130023424) === Oe && 500 > we() - Lu)
          ? fn(e, 0)
          : (Ru |= n)),
      Qe(e, t));
  }
  function Gs(e, t) {
    t === 0 &&
      ((e.mode & 1) === 0
        ? (t = 1)
        : ((t = Ar), (Ar <<= 1), (Ar & 130023424) === 0 && (Ar = 4194304)));
    var n = $e();
    ((e = Lt(e, t)), e !== null && (Gn(e, t, n), Qe(e, n)));
  }
  function wd(e) {
    var t = e.memoizedState,
      n = 0;
    (t !== null && (n = t.retryLane), Gs(e, n));
  }
  function Sd(e, t) {
    var n = 0;
    switch (e.tag) {
      case 13:
        var r = e.stateNode,
          l = e.memoizedState;
        l !== null && (n = l.retryLane);
        break;
      case 19:
        r = e.stateNode;
        break;
      default:
        throw Error(a(314));
    }
    (r !== null && r.delete(t), Gs(e, n));
  }
  var Js;
  Js = function (e, t, n) {
    if (e !== null)
      if (e.memoizedProps !== t.pendingProps || Be.current) We = !0;
      else {
        if ((e.lanes & n) === 0 && (t.flags & 128) === 0)
          return ((We = !1), id(e, t, n));
        We = (e.flags & 131072) !== 0;
      }
    else ((We = !1), de && (t.flags & 1048576) !== 0 && Na(t, al, t.index));
    switch (((t.lanes = 0), t.tag)) {
      case 2:
        var r = t.type;
        (Cl(e, t), (e = t.pendingProps));
        var l = _n(t, Me.current);
        (On(t, n), (l = ou(null, t, r, e, l, n)));
        var o = uu();
        return (
          (t.flags |= 1),
          typeof l == "object" &&
          l !== null &&
          typeof l.render == "function" &&
          l.$$typeof === void 0
            ? ((t.tag = 1),
              (t.memoizedState = null),
              (t.updateQueue = null),
              He(r) ? ((o = !0), ol(t)) : (o = !1),
              (t.memoizedState =
                l.state !== null && l.state !== void 0 ? l.state : null),
              qo(t),
              (l.updater = kl),
              (t.stateNode = l),
              (l._reactInternals = t),
              du(t, r, e, n),
              (t = vu(null, t, r, !0, o, n)))
            : ((t.tag = 0), de && o && Ho(t), Ue(null, t, l, n), (t = t.child)),
          t
        );
      case 16:
        r = t.elementType;
        e: {
          switch (
            (Cl(e, t),
            (e = t.pendingProps),
            (l = r._init),
            (r = l(r._payload)),
            (t.type = r),
            (l = t.tag = Ed(r)),
            (e = ct(r, e)),
            l)
          ) {
            case 0:
              t = mu(null, t, r, e, n);
              break e;
            case 1:
              t = Es(null, t, r, e, n);
              break e;
            case 11:
              t = ys(null, t, r, e, n);
              break e;
            case 14:
              t = gs(null, t, r, ct(r.type, e), n);
              break e;
          }
          throw Error(a(306, r, ""));
        }
        return t;
      case 0:
        return (
          (r = t.type),
          (l = t.pendingProps),
          (l = t.elementType === r ? l : ct(r, l)),
          mu(e, t, r, l, n)
        );
      case 1:
        return (
          (r = t.type),
          (l = t.pendingProps),
          (l = t.elementType === r ? l : ct(r, l)),
          Es(e, t, r, l, n)
        );
      case 3:
        e: {
          if ((Cs(t), e === null)) throw Error(a(387));
          ((r = t.pendingProps),
            (o = t.memoizedState),
            (l = o.element),
            Ua(e, t),
            hl(t, r, null, n));
          var i = t.memoizedState;
          if (((r = i.element), o.isDehydrated))
            if (
              ((o = {
                element: r,
                isDehydrated: !1,
                cache: i.cache,
                pendingSuspenseBoundaries: i.pendingSuspenseBoundaries,
                transitions: i.transitions,
              }),
              (t.updateQueue.baseState = o),
              (t.memoizedState = o),
              t.flags & 256)
            ) {
              ((l = Mn(Error(a(423)), t)), (t = xs(e, t, r, n, l)));
              break e;
            } else if (r !== l) {
              ((l = Mn(Error(a(424)), t)), (t = xs(e, t, r, n, l)));
              break e;
            } else
              for (
                Ze = Bt(t.stateNode.containerInfo.firstChild),
                  Je = t,
                  de = !0,
                  st = null,
                  n = Ia(t, null, r, n),
                  t.child = n;
                n;
              )
                ((n.flags = (n.flags & -3) | 4096), (n = n.sibling));
          else {
            if ((Nn(), r === l)) {
              t = Tt(e, t, n);
              break e;
            }
            Ue(e, t, r, n);
          }
          t = t.child;
        }
        return t;
      case 5:
        return (
          Ba(t),
          e === null && Qo(t),
          (r = t.type),
          (l = t.pendingProps),
          (o = e !== null ? e.memoizedProps : null),
          (i = l.children),
          Io(r, l) ? (i = null) : o !== null && Io(r, o) && (t.flags |= 32),
          ks(e, t),
          Ue(e, t, i, n),
          t.child
        );
      case 6:
        return (e === null && Qo(t), null);
      case 13:
        return Ps(e, t, n);
      case 4:
        return (
          bo(t, t.stateNode.containerInfo),
          (r = t.pendingProps),
          e === null ? (t.child = Tn(t, null, r, n)) : Ue(e, t, r, n),
          t.child
        );
      case 11:
        return (
          (r = t.type),
          (l = t.pendingProps),
          (l = t.elementType === r ? l : ct(r, l)),
          ys(e, t, r, l, n)
        );
      case 7:
        return (Ue(e, t, t.pendingProps, n), t.child);
      case 8:
        return (Ue(e, t, t.pendingProps.children, n), t.child);
      case 12:
        return (Ue(e, t, t.pendingProps.children, n), t.child);
      case 10:
        e: {
          if (
            ((r = t.type._context),
            (l = t.pendingProps),
            (o = t.memoizedProps),
            (i = l.value),
            ae(fl, r._currentValue),
            (r._currentValue = i),
            o !== null)
          )
            if (at(o.value, i)) {
              if (o.children === l.children && !Be.current) {
                t = Tt(e, t, n);
                break e;
              }
            } else
              for (o = t.child, o !== null && (o.return = t); o !== null;) {
                var c = o.dependencies;
                if (c !== null) {
                  i = o.child;
                  for (var d = c.firstContext; d !== null;) {
                    if (d.context === r) {
                      if (o.tag === 1) {
                        ((d = Nt(-1, n & -n)), (d.tag = 2));
                        var w = o.updateQueue;
                        if (w !== null) {
                          w = w.shared;
                          var L = w.pending;
                          (L === null
                            ? (d.next = d)
                            : ((d.next = L.next), (L.next = d)),
                            (w.pending = d));
                        }
                      }
                      ((o.lanes |= n),
                        (d = o.alternate),
                        d !== null && (d.lanes |= n),
                        Jo(o.return, n, t),
                        (c.lanes |= n));
                      break;
                    }
                    d = d.next;
                  }
                } else if (o.tag === 10) i = o.type === t.type ? null : o.child;
                else if (o.tag === 18) {
                  if (((i = o.return), i === null)) throw Error(a(341));
                  ((i.lanes |= n),
                    (c = i.alternate),
                    c !== null && (c.lanes |= n),
                    Jo(i, n, t),
                    (i = o.sibling));
                } else i = o.child;
                if (i !== null) i.return = o;
                else
                  for (i = o; i !== null;) {
                    if (i === t) {
                      i = null;
                      break;
                    }
                    if (((o = i.sibling), o !== null)) {
                      ((o.return = i.return), (i = o));
                      break;
                    }
                    i = i.return;
                  }
                o = i;
              }
          (Ue(e, t, l.children, n), (t = t.child));
        }
        return t;
      case 9:
        return (
          (l = t.type),
          (r = t.pendingProps.children),
          On(t, n),
          (l = tt(l)),
          (r = r(l)),
          (t.flags |= 1),
          Ue(e, t, r, n),
          t.child
        );
      case 14:
        return (
          (r = t.type),
          (l = ct(r, t.pendingProps)),
          (l = ct(r.type, l)),
          gs(e, t, r, l, n)
        );
      case 15:
        return ws(e, t, t.type, t.pendingProps, n);
      case 17:
        return (
          (r = t.type),
          (l = t.pendingProps),
          (l = t.elementType === r ? l : ct(r, l)),
          Cl(e, t),
          (t.tag = 1),
          He(r) ? ((e = !0), ol(t)) : (e = !1),
          On(t, n),
          cs(t, r, l),
          du(t, r, l, n),
          vu(null, t, r, !0, e, n)
        );
      case 19:
        return Rs(e, t, n);
      case 22:
        return Ss(e, t, n);
    }
    throw Error(a(156, t.tag));
  };
  function Zs(e, t) {
    return Ti(e, t);
  }
  function kd(e, t, n, r) {
    ((this.tag = e),
      (this.key = n),
      (this.sibling =
        this.child =
        this.return =
        this.stateNode =
        this.type =
        this.elementType =
          null),
      (this.index = 0),
      (this.ref = null),
      (this.pendingProps = t),
      (this.dependencies =
        this.memoizedState =
        this.updateQueue =
        this.memoizedProps =
          null),
      (this.mode = r),
      (this.subtreeFlags = this.flags = 0),
      (this.deletions = null),
      (this.childLanes = this.lanes = 0),
      (this.alternate = null));
  }
  function lt(e, t, n, r) {
    return new kd(e, t, n, r);
  }
  function Iu(e) {
    return ((e = e.prototype), !(!e || !e.isReactComponent));
  }
  function Ed(e) {
    if (typeof e == "function") return Iu(e) ? 1 : 0;
    if (e != null) {
      if (((e = e.$$typeof), e === yt)) return 11;
      if (e === gt) return 14;
    }
    return 2;
  }
  function qt(e, t) {
    var n = e.alternate;
    return (
      n === null
        ? ((n = lt(e.tag, t, e.key, e.mode)),
          (n.elementType = e.elementType),
          (n.type = e.type),
          (n.stateNode = e.stateNode),
          (n.alternate = e),
          (e.alternate = n))
        : ((n.pendingProps = t),
          (n.type = e.type),
          (n.flags = 0),
          (n.subtreeFlags = 0),
          (n.deletions = null)),
      (n.flags = e.flags & 14680064),
      (n.childLanes = e.childLanes),
      (n.lanes = e.lanes),
      (n.child = e.child),
      (n.memoizedProps = e.memoizedProps),
      (n.memoizedState = e.memoizedState),
      (n.updateQueue = e.updateQueue),
      (t = e.dependencies),
      (n.dependencies =
        t === null ? null : { lanes: t.lanes, firstContext: t.firstContext }),
      (n.sibling = e.sibling),
      (n.index = e.index),
      (n.ref = e.ref),
      n
    );
  }
  function Ml(e, t, n, r, l, o) {
    var i = 2;
    if (((r = e), typeof e == "function")) Iu(e) && (i = 1);
    else if (typeof e == "string") i = 5;
    else
      e: switch (e) {
        case Ee:
          return pn(n.children, l, o, t);
        case Te:
          ((i = 8), (l |= 8));
          break;
        case Ce:
          return (
            (e = lt(12, n, t, l | 2)),
            (e.elementType = Ce),
            (e.lanes = o),
            e
          );
        case Ye:
          return (
            (e = lt(13, n, t, l)),
            (e.elementType = Ye),
            (e.lanes = o),
            e
          );
        case ut:
          return (
            (e = lt(19, n, t, l)),
            (e.elementType = ut),
            (e.lanes = o),
            e
          );
        case ye:
          return Fl(n, l, o, t);
        default:
          if (typeof e == "object" && e !== null)
            switch (e.$$typeof) {
              case De:
                i = 10;
                break e;
              case vt:
                i = 9;
                break e;
              case yt:
                i = 11;
                break e;
              case gt:
                i = 14;
                break e;
              case Ae:
                ((i = 16), (r = null));
                break e;
            }
          throw Error(a(130, e == null ? e : typeof e, ""));
      }
    return (
      (t = lt(i, n, t, l)),
      (t.elementType = e),
      (t.type = r),
      (t.lanes = o),
      t
    );
  }
  function pn(e, t, n, r) {
    return ((e = lt(7, e, r, t)), (e.lanes = n), e);
  }
  function Fl(e, t, n, r) {
    return (
      (e = lt(22, e, r, t)),
      (e.elementType = ye),
      (e.lanes = n),
      (e.stateNode = { isHidden: !1 }),
      e
    );
  }
  function ju(e, t, n) {
    return ((e = lt(6, e, null, t)), (e.lanes = n), e);
  }
  function Uu(e, t, n) {
    return (
      (t = lt(4, e.children !== null ? e.children : [], e.key, t)),
      (t.lanes = n),
      (t.stateNode = {
        containerInfo: e.containerInfo,
        pendingChildren: null,
        implementation: e.implementation,
      }),
      t
    );
  }
  function Cd(e, t, n, r, l) {
    ((this.tag = t),
      (this.containerInfo = e),
      (this.finishedWork =
        this.pingCache =
        this.current =
        this.pendingChildren =
          null),
      (this.timeoutHandle = -1),
      (this.callbackNode = this.pendingContext = this.context = null),
      (this.callbackPriority = 0),
      (this.eventTimes = co(0)),
      (this.expirationTimes = co(-1)),
      (this.entangledLanes =
        this.finishedLanes =
        this.mutableReadLanes =
        this.expiredLanes =
        this.pingedLanes =
        this.suspendedLanes =
        this.pendingLanes =
          0),
      (this.entanglements = co(0)),
      (this.identifierPrefix = r),
      (this.onRecoverableError = l),
      (this.mutableSourceEagerHydrationData = null));
  }
  function $u(e, t, n, r, l, o, i, c, d) {
    return (
      (e = new Cd(e, t, n, c, d)),
      t === 1 ? ((t = 1), o === !0 && (t |= 8)) : (t = 0),
      (o = lt(3, null, null, t)),
      (e.current = o),
      (o.stateNode = e),
      (o.memoizedState = {
        element: r,
        isDehydrated: n,
        cache: null,
        transitions: null,
        pendingSuspenseBoundaries: null,
      }),
      qo(o),
      e
    );
  }
  function xd(e, t, n) {
    var r =
      3 < arguments.length && arguments[3] !== void 0 ? arguments[3] : null;
    return {
      $$typeof: ke,
      key: r == null ? null : "" + r,
      children: e,
      containerInfo: t,
      implementation: n,
    };
  }
  function qs(e) {
    if (!e) return Wt;
    e = e._reactInternals;
    e: {
      if (en(e) !== e || e.tag !== 1) throw Error(a(170));
      var t = e;
      do {
        switch (t.tag) {
          case 3:
            t = t.stateNode.context;
            break e;
          case 1:
            if (He(t.type)) {
              t = t.stateNode.__reactInternalMemoizedMergedChildContext;
              break e;
            }
        }
        t = t.return;
      } while (t !== null);
      throw Error(a(171));
    }
    if (e.tag === 1) {
      var n = e.type;
      if (He(n)) return _a(e, n, t);
    }
    return t;
  }
  function bs(e, t, n, r, l, o, i, c, d) {
    return (
      (e = $u(n, r, !0, e, l, o, i, c, d)),
      (e.context = qs(null)),
      (n = e.current),
      (r = $e()),
      (l = Jt(n)),
      (o = Nt(r, l)),
      (o.callback = t ?? null),
      Kt(n, o, l),
      (e.current.lanes = l),
      Gn(e, l, r),
      Qe(e, r),
      e
    );
  }
  function Il(e, t, n, r) {
    var l = t.current,
      o = $e(),
      i = Jt(l);
    return (
      (n = qs(n)),
      t.context === null ? (t.context = n) : (t.pendingContext = n),
      (t = Nt(o, i)),
      (t.payload = { element: e }),
      (r = r === void 0 ? null : r),
      r !== null && (t.callback = r),
      (e = Kt(l, t, i)),
      e !== null && (pt(e, l, i, o), pl(e, l, i)),
      i
    );
  }
  function jl(e) {
    if (((e = e.current), !e.child)) return null;
    switch (e.child.tag) {
      case 5:
        return e.child.stateNode;
      default:
        return e.child.stateNode;
    }
  }
  function ec(e, t) {
    if (((e = e.memoizedState), e !== null && e.dehydrated !== null)) {
      var n = e.retryLane;
      e.retryLane = n !== 0 && n < t ? n : t;
    }
  }
  function Au(e, t) {
    (ec(e, t), (e = e.alternate) && ec(e, t));
  }
  function Pd() {
    return null;
  }
  var tc =
    typeof reportError == "function"
      ? reportError
      : function (e) {
          console.error(e);
        };
  function Bu(e) {
    this._internalRoot = e;
  }
  ((Ul.prototype.render = Bu.prototype.render =
    function (e) {
      var t = this._internalRoot;
      if (t === null) throw Error(a(409));
      Il(e, t, null, null);
    }),
    (Ul.prototype.unmount = Bu.prototype.unmount =
      function () {
        var e = this._internalRoot;
        if (e !== null) {
          this._internalRoot = null;
          var t = e.containerInfo;
          (cn(function () {
            Il(null, e, null, null);
          }),
            (t[xt] = null));
        }
      }));
  function Ul(e) {
    this._internalRoot = e;
  }
  Ul.prototype.unstable_scheduleHydration = function (e) {
    if (e) {
      var t = Ui();
      e = { blockedOn: null, target: e, priority: t };
      for (var n = 0; n < Ut.length && t !== 0 && t < Ut[n].priority; n++);
      (Ut.splice(n, 0, e), n === 0 && Bi(e));
    }
  };
  function Hu(e) {
    return !(!e || (e.nodeType !== 1 && e.nodeType !== 9 && e.nodeType !== 11));
  }
  function $l(e) {
    return !(
      !e ||
      (e.nodeType !== 1 &&
        e.nodeType !== 9 &&
        e.nodeType !== 11 &&
        (e.nodeType !== 8 || e.nodeValue !== " react-mount-point-unstable "))
    );
  }
  function nc() {}
  function _d(e, t, n, r, l) {
    if (l) {
      if (typeof r == "function") {
        var o = r;
        r = function () {
          var w = jl(i);
          o.call(w);
        };
      }
      var i = bs(t, r, e, 0, null, !1, !1, "", nc);
      return (
        (e._reactRootContainer = i),
        (e[xt] = i.current),
        sr(e.nodeType === 8 ? e.parentNode : e),
        cn(),
        i
      );
    }
    for (; (l = e.lastChild);) e.removeChild(l);
    if (typeof r == "function") {
      var c = r;
      r = function () {
        var w = jl(d);
        c.call(w);
      };
    }
    var d = $u(e, 0, !1, null, null, !1, !1, "", nc);
    return (
      (e._reactRootContainer = d),
      (e[xt] = d.current),
      sr(e.nodeType === 8 ? e.parentNode : e),
      cn(function () {
        Il(t, d, n, r);
      }),
      d
    );
  }
  function Al(e, t, n, r, l) {
    var o = n._reactRootContainer;
    if (o) {
      var i = o;
      if (typeof l == "function") {
        var c = l;
        l = function () {
          var d = jl(i);
          c.call(d);
        };
      }
      Il(t, i, e, l);
    } else i = _d(n, t, e, l, r);
    return jl(i);
  }
  ((Ii = function (e) {
    switch (e.tag) {
      case 3:
        var t = e.stateNode;
        if (t.current.memoizedState.isDehydrated) {
          var n = Xn(t.pendingLanes);
          n !== 0 &&
            (fo(t, n | 1),
            Qe(t, we()),
            (ee & 6) === 0 && ((jn = we() + 500), Vt()));
        }
        break;
      case 13:
        (cn(function () {
          var r = Lt(e, 1);
          if (r !== null) {
            var l = $e();
            pt(r, e, 1, l);
          }
        }),
          Au(e, 1));
    }
  }),
    (po = function (e) {
      if (e.tag === 13) {
        var t = Lt(e, 134217728);
        if (t !== null) {
          var n = $e();
          pt(t, e, 134217728, n);
        }
        Au(e, 134217728);
      }
    }),
    (ji = function (e) {
      if (e.tag === 13) {
        var t = Jt(e),
          n = Lt(e, t);
        if (n !== null) {
          var r = $e();
          pt(n, e, t, r);
        }
        Au(e, t);
      }
    }),
    (Ui = function () {
      return oe;
    }),
    ($i = function (e, t) {
      var n = oe;
      try {
        return ((oe = e), t());
      } finally {
        oe = n;
      }
    }),
    (lo = function (e, t, n) {
      switch (t) {
        case "input":
          if ((Jl(e, n), (t = n.name), n.type === "radio" && t != null)) {
            for (n = e; n.parentNode;) n = n.parentNode;
            for (
              n = n.querySelectorAll(
                "input[name=" + JSON.stringify("" + t) + '][type="radio"]',
              ),
                t = 0;
              t < n.length;
              t++
            ) {
              var r = n[t];
              if (r !== e && r.form === e.form) {
                var l = rl(r);
                if (!l) throw Error(a(90));
                (si(r), Jl(r, l));
              }
            }
          }
          break;
        case "textarea":
          hi(e, n);
          break;
        case "select":
          ((t = n.value), t != null && hn(e, !!n.multiple, t, !1));
      }
    }),
    (Ci = Du),
    (xi = cn));
  var Rd = { usingClientEntryPoint: !1, Events: [dr, xn, rl, ki, Ei, Du] },
    _r = {
      findFiberByHostInstance: tn,
      bundleType: 0,
      version: "18.3.1",
      rendererPackageName: "react-dom",
    },
    Ld = {
      bundleType: _r.bundleType,
      version: _r.version,
      rendererPackageName: _r.rendererPackageName,
      rendererConfig: _r.rendererConfig,
      overrideHookState: null,
      overrideHookStateDeletePath: null,
      overrideHookStateRenamePath: null,
      overrideProps: null,
      overridePropsDeletePath: null,
      overridePropsRenamePath: null,
      setErrorHandler: null,
      setSuspenseHandler: null,
      scheduleUpdate: null,
      currentDispatcherRef: ue.ReactCurrentDispatcher,
      findHostInstanceByFiber: function (e) {
        return ((e = Li(e)), e === null ? null : e.stateNode);
      },
      findFiberByHostInstance: _r.findFiberByHostInstance || Pd,
      findHostInstancesForRefresh: null,
      scheduleRefresh: null,
      scheduleRoot: null,
      setRefreshHandler: null,
      getCurrentFiber: null,
      reconcilerVersion: "18.3.1-next-f1338f8080-20240426",
    };
  if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u") {
    var Bl = __REACT_DEVTOOLS_GLOBAL_HOOK__;
    if (!Bl.isDisabled && Bl.supportsFiber)
      try {
        ((Ur = Bl.inject(Ld)), (wt = Bl));
      } catch {}
  }
  return (
    (Ke.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = Rd),
    (Ke.createPortal = function (e, t) {
      var n =
        2 < arguments.length && arguments[2] !== void 0 ? arguments[2] : null;
      if (!Hu(t)) throw Error(a(200));
      return xd(e, t, null, n);
    }),
    (Ke.createRoot = function (e, t) {
      if (!Hu(e)) throw Error(a(299));
      var n = !1,
        r = "",
        l = tc;
      return (
        t != null &&
          (t.unstable_strictMode === !0 && (n = !0),
          t.identifierPrefix !== void 0 && (r = t.identifierPrefix),
          t.onRecoverableError !== void 0 && (l = t.onRecoverableError)),
        (t = $u(e, 1, !1, null, null, n, !1, r, l)),
        (e[xt] = t.current),
        sr(e.nodeType === 8 ? e.parentNode : e),
        new Bu(t)
      );
    }),
    (Ke.findDOMNode = function (e) {
      if (e == null) return null;
      if (e.nodeType === 1) return e;
      var t = e._reactInternals;
      if (t === void 0)
        throw typeof e.render == "function"
          ? Error(a(188))
          : ((e = Object.keys(e).join(",")), Error(a(268, e)));
      return ((e = Li(t)), (e = e === null ? null : e.stateNode), e);
    }),
    (Ke.flushSync = function (e) {
      return cn(e);
    }),
    (Ke.hydrate = function (e, t, n) {
      if (!$l(t)) throw Error(a(200));
      return Al(null, e, t, !0, n);
    }),
    (Ke.hydrateRoot = function (e, t, n) {
      if (!Hu(e)) throw Error(a(405));
      var r = (n != null && n.hydratedSources) || null,
        l = !1,
        o = "",
        i = tc;
      if (
        (n != null &&
          (n.unstable_strictMode === !0 && (l = !0),
          n.identifierPrefix !== void 0 && (o = n.identifierPrefix),
          n.onRecoverableError !== void 0 && (i = n.onRecoverableError)),
        (t = bs(t, null, e, 1, n ?? null, l, !1, o, i)),
        (e[xt] = t.current),
        sr(e),
        r)
      )
        for (e = 0; e < r.length; e++)
          ((n = r[e]),
            (l = n._getVersion),
            (l = l(n._source)),
            t.mutableSourceEagerHydrationData == null
              ? (t.mutableSourceEagerHydrationData = [n, l])
              : t.mutableSourceEagerHydrationData.push(n, l));
      return new Ul(t);
    }),
    (Ke.render = function (e, t, n) {
      if (!$l(t)) throw Error(a(200));
      return Al(null, e, t, !1, n);
    }),
    (Ke.unmountComponentAtNode = function (e) {
      if (!$l(e)) throw Error(a(40));
      return e._reactRootContainer
        ? (cn(function () {
            Al(null, null, e, !1, function () {
              ((e._reactRootContainer = null), (e[xt] = null));
            });
          }),
          !0)
        : !1;
    }),
    (Ke.unstable_batchedUpdates = Du),
    (Ke.unstable_renderSubtreeIntoContainer = function (e, t, n, r) {
      if (!$l(n)) throw Error(a(200));
      if (e == null || e._reactInternals === void 0) throw Error(a(38));
      return Al(e, t, n, !1, r);
    }),
    (Ke.version = "18.3.1-next-f1338f8080-20240426"),
    Ke
  );
}
var cc;
function yc() {
  if (cc) return Qu.exports;
  cc = 1;
  function u() {
    if (!(
      typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > "u" ||
      typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != "function"
    ))
      try {
        __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(u);
      } catch (s) {
        console.error(s);
      }
  }
  return (u(), (Qu.exports = jd()), Qu.exports);
}
var fc;
function Ud() {
  if (fc) return Hl;
  fc = 1;
  var u = yc();
  return ((Hl.createRoot = u.createRoot), (Hl.hydrateRoot = u.hydrateRoot), Hl);
}
var $d = Ud();
const fh = bu($d);
var Ad = yc();
const dh = bu(Ad);
/**
 * react-router v7.9.5
 *
 * Copyright (c) Remix Software Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.md file in the root directory of this source tree.
 *
 * @license MIT
 */ var dc = "popstate";
function Bd(u = {}) {
  function s(f, p) {
    let { pathname: v, search: S, hash: E } = f.location;
    return Ju(
      "",
      { pathname: v, search: S, hash: E },
      (p.state && p.state.usr) || null,
      (p.state && p.state.key) || "default",
    );
  }
  function a(f, p) {
    return typeof p == "string" ? p : Nr(p);
  }
  return Wd(s, a, null, u);
}
function pe(u, s) {
  if (u === !1 || u === null || typeof u > "u") throw new Error(s);
}
function ot(u, s) {
  if (!u) {
    typeof console < "u" && console.warn(s);
    try {
      throw new Error(s);
    } catch {}
  }
}
function Hd() {
  return Math.random().toString(36).substring(2, 10);
}
function pc(u, s) {
  return { usr: u.state, key: u.key, idx: s };
}
function Ju(u, s, a = null, f) {
  return {
    pathname: typeof u == "string" ? u : u.pathname,
    search: "",
    hash: "",
    ...(typeof s == "string" ? $n(s) : s),
    state: a,
    key: (s && s.key) || f || Hd(),
  };
}
function Nr({ pathname: u = "/", search: s = "", hash: a = "" }) {
  return (
    s && s !== "?" && (u += s.charAt(0) === "?" ? s : "?" + s),
    a && a !== "#" && (u += a.charAt(0) === "#" ? a : "#" + a),
    u
  );
}
function $n(u) {
  let s = {};
  if (u) {
    let a = u.indexOf("#");
    a >= 0 && ((s.hash = u.substring(a)), (u = u.substring(0, a)));
    let f = u.indexOf("?");
    (f >= 0 && ((s.search = u.substring(f)), (u = u.substring(0, f))),
      u && (s.pathname = u));
  }
  return s;
}
function Wd(u, s, a, f = {}) {
  let { window: p = document.defaultView, v5Compat: v = !1 } = f,
    S = p.history,
    E = "POP",
    k = null,
    x = P();
  x == null && ((x = 0), S.replaceState({ ...S.state, idx: x }, ""));
  function P() {
    return (S.state || { idx: null }).idx;
  }
  function z() {
    E = "POP";
    let O = P(),
      W = O == null ? null : O - x;
    ((x = O), k && k({ action: E, location: H.location, delta: W }));
  }
  function F(O, W) {
    E = "PUSH";
    let A = Ju(H.location, O, W);
    x = P() + 1;
    let Z = pc(A, x),
      ue = H.createHref(A);
    try {
      S.pushState(Z, "", ue);
    } catch (he) {
      if (he instanceof DOMException && he.name === "DataCloneError") throw he;
      p.location.assign(ue);
    }
    v && k && k({ action: E, location: H.location, delta: 1 });
  }
  function V(O, W) {
    E = "REPLACE";
    let A = Ju(H.location, O, W);
    x = P();
    let Z = pc(A, x),
      ue = H.createHref(A);
    (S.replaceState(Z, "", ue),
      v && k && k({ action: E, location: H.location, delta: 0 }));
  }
  function Y(O) {
    return Vd(O);
  }
  let H = {
    get action() {
      return E;
    },
    get location() {
      return u(p, S);
    },
    listen(O) {
      if (k) throw new Error("A history only accepts one active listener");
      return (
        p.addEventListener(dc, z),
        (k = O),
        () => {
          (p.removeEventListener(dc, z), (k = null));
        }
      );
    },
    createHref(O) {
      return s(p, O);
    },
    createURL: Y,
    encodeLocation(O) {
      let W = Y(O);
      return { pathname: W.pathname, search: W.search, hash: W.hash };
    },
    push: F,
    replace: V,
    go(O) {
      return S.go(O);
    },
  };
  return H;
}
function Vd(u, s = !1) {
  let a = "http://localhost";
  (typeof window < "u" &&
    (a =
      window.location.origin !== "null"
        ? window.location.origin
        : window.location.href),
    pe(a, "No window.location.(origin|href) available to create URL"));
  let f = typeof u == "string" ? u : Nr(u);
  return (
    (f = f.replace(/ $/, "%20")),
    !s && f.startsWith("//") && (f = a + f),
    new URL(f, a)
  );
}
function gc(u, s, a = "/") {
  return Qd(u, s, a, !1);
}
function Qd(u, s, a, f) {
  let p = typeof s == "string" ? $n(s) : s,
    v = Dt(p.pathname || "/", a);
  if (v == null) return null;
  let S = wc(u);
  Kd(S);
  let E = null;
  for (let k = 0; E == null && k < S.length; ++k) {
    let x = rp(v);
    E = tp(S[k], x, f);
  }
  return E;
}
function wc(u, s = [], a = [], f = "", p = !1) {
  let v = (S, E, k = p, x) => {
    let P = {
      relativePath: x === void 0 ? S.path || "" : x,
      caseSensitive: S.caseSensitive === !0,
      childrenIndex: E,
      route: S,
    };
    if (P.relativePath.startsWith("/")) {
      if (!P.relativePath.startsWith(f) && k) return;
      (pe(
        P.relativePath.startsWith(f),
        `Absolute route path "${P.relativePath}" nested under path "${f}" is not valid. An absolute child route path must start with the combined path of all its parent routes.`,
      ),
        (P.relativePath = P.relativePath.slice(f.length)));
    }
    let z = Ot([f, P.relativePath]),
      F = a.concat(P);
    (S.children &&
      S.children.length > 0 &&
      (pe(
        S.index !== !0,
        `Index routes must not have child routes. Please remove all child routes from route path "${z}".`,
      ),
      wc(S.children, s, F, z, k)),
      !(S.path == null && !S.index) &&
        s.push({ path: z, score: bd(z, S.index), routesMeta: F }));
  };
  return (
    u.forEach((S, E) => {
      if (S.path === "" || !S.path?.includes("?")) v(S, E);
      else for (let k of Sc(S.path)) v(S, E, !0, k);
    }),
    s
  );
}
function Sc(u) {
  let s = u.split("/");
  if (s.length === 0) return [];
  let [a, ...f] = s,
    p = a.endsWith("?"),
    v = a.replace(/\?$/, "");
  if (f.length === 0) return p ? [v, ""] : [v];
  let S = Sc(f.join("/")),
    E = [];
  return (
    E.push(...S.map((k) => (k === "" ? v : [v, k].join("/")))),
    p && E.push(...S),
    E.map((k) => (u.startsWith("/") && k === "" ? "/" : k))
  );
}
function Kd(u) {
  u.sort((s, a) =>
    s.score !== a.score
      ? a.score - s.score
      : ep(
          s.routesMeta.map((f) => f.childrenIndex),
          a.routesMeta.map((f) => f.childrenIndex),
        ),
  );
}
var Yd = /^:[\w-]+$/,
  Xd = 3,
  Gd = 2,
  Jd = 1,
  Zd = 10,
  qd = -2,
  hc = (u) => u === "*";
function bd(u, s) {
  let a = u.split("/"),
    f = a.length;
  return (
    a.some(hc) && (f += qd),
    s && (f += Gd),
    a
      .filter((p) => !hc(p))
      .reduce((p, v) => p + (Yd.test(v) ? Xd : v === "" ? Jd : Zd), f)
  );
}
function ep(u, s) {
  return u.length === s.length && u.slice(0, -1).every((f, p) => f === s[p])
    ? u[u.length - 1] - s[s.length - 1]
    : 0;
}
function tp(u, s, a = !1) {
  let { routesMeta: f } = u,
    p = {},
    v = "/",
    S = [];
  for (let E = 0; E < f.length; ++E) {
    let k = f[E],
      x = E === f.length - 1,
      P = v === "/" ? s : s.slice(v.length) || "/",
      z = Kl(
        { path: k.relativePath, caseSensitive: k.caseSensitive, end: x },
        P,
      ),
      F = k.route;
    if (
      (!z &&
        x &&
        a &&
        !f[f.length - 1].route.index &&
        (z = Kl(
          { path: k.relativePath, caseSensitive: k.caseSensitive, end: !1 },
          P,
        )),
      !z)
    )
      return null;
    (Object.assign(p, z.params),
      S.push({
        params: p,
        pathname: Ot([v, z.pathname]),
        pathnameBase: ip(Ot([v, z.pathnameBase])),
        route: F,
      }),
      z.pathnameBase !== "/" && (v = Ot([v, z.pathnameBase])));
  }
  return S;
}
function Kl(u, s) {
  typeof u == "string" && (u = { path: u, caseSensitive: !1, end: !0 });
  let [a, f] = np(u.path, u.caseSensitive, u.end),
    p = s.match(a);
  if (!p) return null;
  let v = p[0],
    S = v.replace(/(.)\/+$/, "$1"),
    E = p.slice(1);
  return {
    params: f.reduce((x, { paramName: P, isOptional: z }, F) => {
      if (P === "*") {
        let Y = E[F] || "";
        S = v.slice(0, v.length - Y.length).replace(/(.)\/+$/, "$1");
      }
      const V = E[F];
      return (
        z && !V ? (x[P] = void 0) : (x[P] = (V || "").replace(/%2F/g, "/")),
        x
      );
    }, {}),
    pathname: v,
    pathnameBase: S,
    pattern: u,
  };
}
function np(u, s = !1, a = !0) {
  ot(
    u === "*" || !u.endsWith("*") || u.endsWith("/*"),
    `Route path "${u}" will be treated as if it were "${u.replace(/\*$/, "/*")}" because the \`*\` character must always follow a \`/\` in the pattern. To get rid of this warning, please change the route path to "${u.replace(/\*$/, "/*")}".`,
  );
  let f = [],
    p =
      "^" +
      u
        .replace(/\/*\*?$/, "")
        .replace(/^\/*/, "/")
        .replace(/[\\.*+^${}|()[\]]/g, "\\$&")
        .replace(
          /\/:([\w-]+)(\?)?/g,
          (S, E, k) => (
            f.push({ paramName: E, isOptional: k != null }),
            k ? "/?([^\\/]+)?" : "/([^\\/]+)"
          ),
        )
        .replace(/\/([\w-]+)\?(\/|$)/g, "(/$1)?$2");
  return (
    u.endsWith("*")
      ? (f.push({ paramName: "*" }),
        (p += u === "*" || u === "/*" ? "(.*)$" : "(?:\\/(.+)|\\/*)$"))
      : a
        ? (p += "\\/*$")
        : u !== "" && u !== "/" && (p += "(?:(?=\\/|$))"),
    [new RegExp(p, s ? void 0 : "i"), f]
  );
}
function rp(u) {
  try {
    return u
      .split("/")
      .map((s) => decodeURIComponent(s).replace(/\//g, "%2F"))
      .join("/");
  } catch (s) {
    return (
      ot(
        !1,
        `The URL path "${u}" could not be decoded because it is a malformed URL segment. This is probably due to a bad percent encoding (${s}).`,
      ),
      u
    );
  }
}
function Dt(u, s) {
  if (s === "/") return u;
  if (!u.toLowerCase().startsWith(s.toLowerCase())) return null;
  let a = s.endsWith("/") ? s.length - 1 : s.length,
    f = u.charAt(a);
  return f && f !== "/" ? null : u.slice(a) || "/";
}
function lp(u, s = "/") {
  let {
    pathname: a,
    search: f = "",
    hash: p = "",
  } = typeof u == "string" ? $n(u) : u;
  return {
    pathname: a ? (a.startsWith("/") ? a : op(a, s)) : s,
    search: ap(f),
    hash: sp(p),
  };
}
function op(u, s) {
  let a = s.replace(/\/+$/, "").split("/");
  return (
    u.split("/").forEach((p) => {
      p === ".." ? a.length > 1 && a.pop() : p !== "." && a.push(p);
    }),
    a.length > 1 ? a.join("/") : "/"
  );
}
function Xu(u, s, a, f) {
  return `Cannot include a '${u}' character in a manually specified \`to.${s}\` field [${JSON.stringify(f)}].  Please separate it out to the \`to.${a}\` field. Alternatively you may provide the full path as a string in <Link to="..."> and the router will parse it for you.`;
}
function up(u) {
  return u.filter(
    (s, a) => a === 0 || (s.route.path && s.route.path.length > 0),
  );
}
function ti(u) {
  let s = up(u);
  return s.map((a, f) => (f === s.length - 1 ? a.pathname : a.pathnameBase));
}
function ni(u, s, a, f = !1) {
  let p;
  typeof u == "string"
    ? (p = $n(u))
    : ((p = { ...u }),
      pe(
        !p.pathname || !p.pathname.includes("?"),
        Xu("?", "pathname", "search", p),
      ),
      pe(
        !p.pathname || !p.pathname.includes("#"),
        Xu("#", "pathname", "hash", p),
      ),
      pe(!p.search || !p.search.includes("#"), Xu("#", "search", "hash", p)));
  let v = u === "" || p.pathname === "",
    S = v ? "/" : p.pathname,
    E;
  if (S == null) E = a;
  else {
    let z = s.length - 1;
    if (!f && S.startsWith("..")) {
      let F = S.split("/");
      for (; F[0] === "..";) (F.shift(), (z -= 1));
      p.pathname = F.join("/");
    }
    E = z >= 0 ? s[z] : "/";
  }
  let k = lp(p, E),
    x = S && S !== "/" && S.endsWith("/"),
    P = (v || S === ".") && a.endsWith("/");
  return (!k.pathname.endsWith("/") && (x || P) && (k.pathname += "/"), k);
}
var Ot = (u) => u.join("/").replace(/\/\/+/g, "/"),
  ip = (u) => u.replace(/\/+$/, "").replace(/^\/*/, "/"),
  ap = (u) => (!u || u === "?" ? "" : u.startsWith("?") ? u : "?" + u),
  sp = (u) => (!u || u === "#" ? "" : u.startsWith("#") ? u : "#" + u);
function cp(u) {
  return (
    u != null &&
    typeof u.status == "number" &&
    typeof u.statusText == "string" &&
    typeof u.internal == "boolean" &&
    "data" in u
  );
}
Object.getOwnPropertyNames(Object.prototype).sort().join("\0");
var kc = ["POST", "PUT", "PATCH", "DELETE"];
new Set(kc);
var fp = ["GET", ...kc];
new Set(fp);
var An = C.createContext(null);
An.displayName = "DataRouter";
var Yl = C.createContext(null);
Yl.displayName = "DataRouterState";
C.createContext(!1);
var Ec = C.createContext({ isTransitioning: !1 });
Ec.displayName = "ViewTransition";
var dp = C.createContext(new Map());
dp.displayName = "Fetchers";
var pp = C.createContext(null);
pp.displayName = "Await";
var ht = C.createContext(null);
ht.displayName = "Navigation";
var Tr = C.createContext(null);
Tr.displayName = "Location";
var mt = C.createContext({ outlet: null, matches: [], isDataRoute: !1 });
mt.displayName = "Route";
var ri = C.createContext(null);
ri.displayName = "RouteError";
function hp(u, { relative: s } = {}) {
  pe(
    Bn(),
    "useHref() may be used only in the context of a <Router> component.",
  );
  let { basename: a, navigator: f } = C.useContext(ht),
    { hash: p, pathname: v, search: S } = zr(u, { relative: s }),
    E = v;
  return (
    a !== "/" && (E = v === "/" ? a : Ot([a, v])),
    f.createHref({ pathname: E, search: S, hash: p })
  );
}
function Bn() {
  return C.useContext(Tr) != null;
}
function Mt() {
  return (
    pe(
      Bn(),
      "useLocation() may be used only in the context of a <Router> component.",
    ),
    C.useContext(Tr).location
  );
}
var Cc =
  "You should call navigate() in a React.useEffect(), not when your component is first rendered.";
function xc(u) {
  C.useContext(ht).static || C.useLayoutEffect(u);
}
function li() {
  let { isDataRoute: u } = C.useContext(mt);
  return u ? Rp() : mp();
}
function mp() {
  pe(
    Bn(),
    "useNavigate() may be used only in the context of a <Router> component.",
  );
  let u = C.useContext(An),
    { basename: s, navigator: a } = C.useContext(ht),
    { matches: f } = C.useContext(mt),
    { pathname: p } = Mt(),
    v = JSON.stringify(ti(f)),
    S = C.useRef(!1);
  return (
    xc(() => {
      S.current = !0;
    }),
    C.useCallback(
      (k, x = {}) => {
        if ((ot(S.current, Cc), !S.current)) return;
        if (typeof k == "number") {
          a.go(k);
          return;
        }
        let P = ni(k, JSON.parse(v), p, x.relative === "path");
        (u == null &&
          s !== "/" &&
          (P.pathname = P.pathname === "/" ? s : Ot([s, P.pathname])),
          (x.replace ? a.replace : a.push)(P, x.state, x));
      },
      [s, a, v, p, u],
    )
  );
}
C.createContext(null);
function ph() {
  let { matches: u } = C.useContext(mt),
    s = u[u.length - 1];
  return s ? s.params : {};
}
function zr(u, { relative: s } = {}) {
  let { matches: a } = C.useContext(mt),
    { pathname: f } = Mt(),
    p = JSON.stringify(ti(a));
  return C.useMemo(() => ni(u, JSON.parse(p), f, s === "path"), [u, p, f, s]);
}
function vp(u, s) {
  return Pc(u, s);
}
function Pc(u, s, a, f, p) {
  pe(
    Bn(),
    "useRoutes() may be used only in the context of a <Router> component.",
  );
  let { navigator: v } = C.useContext(ht),
    { matches: S } = C.useContext(mt),
    E = S[S.length - 1],
    k = E ? E.params : {},
    x = E ? E.pathname : "/",
    P = E ? E.pathnameBase : "/",
    z = E && E.route;
  {
    let A = (z && z.path) || "";
    _c(
      x,
      !z || A.endsWith("*") || A.endsWith("*?"),
      `You rendered descendant <Routes> (or called \`useRoutes()\`) at "${x}" (under <Route path="${A}">) but the parent route path has no trailing "*". This means if you navigate deeper, the parent won't match anymore and therefore the child routes will never render.

Please change the parent <Route path="${A}"> to <Route path="${A === "/" ? "*" : `${A}/*`}">.`,
    );
  }
  let F = Mt(),
    V;
  if (s) {
    let A = typeof s == "string" ? $n(s) : s;
    (pe(
      P === "/" || A.pathname?.startsWith(P),
      `When overriding the location using \`<Routes location>\` or \`useRoutes(routes, location)\`, the location pathname must begin with the portion of the URL pathname that was matched by all parent routes. The current pathname base is "${P}" but pathname "${A.pathname}" was given in the \`location\` prop.`,
    ),
      (V = A));
  } else V = F;
  let Y = V.pathname || "/",
    H = Y;
  if (P !== "/") {
    let A = P.replace(/^\//, "").split("/");
    H = "/" + Y.replace(/^\//, "").split("/").slice(A.length).join("/");
  }
  let O = gc(u, { pathname: H });
  (ot(
    z || O != null,
    `No routes matched location "${V.pathname}${V.search}${V.hash}" `,
  ),
    ot(
      O == null ||
        O[O.length - 1].route.element !== void 0 ||
        O[O.length - 1].route.Component !== void 0 ||
        O[O.length - 1].route.lazy !== void 0,
      `Matched leaf route at location "${V.pathname}${V.search}${V.hash}" does not have an element or Component. This means it will render an <Outlet /> with a null value by default resulting in an "empty" page.`,
    ));
  let W = kp(
    O &&
      O.map((A) =>
        Object.assign({}, A, {
          params: Object.assign({}, k, A.params),
          pathname: Ot([
            P,
            v.encodeLocation
              ? v.encodeLocation(
                  A.pathname.replace(/\?/g, "%3F").replace(/#/g, "%23"),
                ).pathname
              : A.pathname,
          ]),
          pathnameBase:
            A.pathnameBase === "/"
              ? P
              : Ot([
                  P,
                  v.encodeLocation
                    ? v.encodeLocation(
                        A.pathnameBase
                          .replace(/\?/g, "%3F")
                          .replace(/#/g, "%23"),
                      ).pathname
                    : A.pathnameBase,
                ]),
        }),
      ),
    S,
    a,
    f,
    p,
  );
  return s && W
    ? C.createElement(
        Tr.Provider,
        {
          value: {
            location: {
              pathname: "/",
              search: "",
              hash: "",
              state: null,
              key: "default",
              ...V,
            },
            navigationType: "POP",
          },
        },
        W,
      )
    : W;
}
function yp() {
  let u = _p(),
    s = cp(u)
      ? `${u.status} ${u.statusText}`
      : u instanceof Error
        ? u.message
        : JSON.stringify(u),
    a = u instanceof Error ? u.stack : null,
    f = "rgba(200,200,200, 0.5)",
    p = { padding: "0.5rem", backgroundColor: f },
    v = { padding: "2px 4px", backgroundColor: f },
    S = null;
  return (
    console.error("Error handled by React Router default ErrorBoundary:", u),
    (S = C.createElement(
      C.Fragment,
      null,
      C.createElement("p", null, "💿 Hey developer 👋"),
      C.createElement(
        "p",
        null,
        "You can provide a way better UX than this when your app throws errors by providing your own ",
        C.createElement("code", { style: v }, "ErrorBoundary"),
        " or",
        " ",
        C.createElement("code", { style: v }, "errorElement"),
        " prop on your route.",
      ),
    )),
    C.createElement(
      C.Fragment,
      null,
      C.createElement("h2", null, "Unexpected Application Error!"),
      C.createElement("h3", { style: { fontStyle: "italic" } }, s),
      a ? C.createElement("pre", { style: p }, a) : null,
      S,
    )
  );
}
var gp = C.createElement(yp, null),
  wp = class extends C.Component {
    constructor(u) {
      (super(u),
        (this.state = {
          location: u.location,
          revalidation: u.revalidation,
          error: u.error,
        }));
    }
    static getDerivedStateFromError(u) {
      return { error: u };
    }
    static getDerivedStateFromProps(u, s) {
      return s.location !== u.location ||
        (s.revalidation !== "idle" && u.revalidation === "idle")
        ? { error: u.error, location: u.location, revalidation: u.revalidation }
        : {
            error: u.error !== void 0 ? u.error : s.error,
            location: s.location,
            revalidation: u.revalidation || s.revalidation,
          };
    }
    componentDidCatch(u, s) {
      this.props.unstable_onError
        ? this.props.unstable_onError(u, s)
        : console.error(
            "React Router caught the following error during render",
            u,
          );
    }
    render() {
      return this.state.error !== void 0
        ? C.createElement(
            mt.Provider,
            { value: this.props.routeContext },
            C.createElement(ri.Provider, {
              value: this.state.error,
              children: this.props.component,
            }),
          )
        : this.props.children;
    }
  };
function Sp({ routeContext: u, match: s, children: a }) {
  let f = C.useContext(An);
  return (
    f &&
      f.static &&
      f.staticContext &&
      (s.route.errorElement || s.route.ErrorBoundary) &&
      (f.staticContext._deepestRenderedBoundaryId = s.route.id),
    C.createElement(mt.Provider, { value: u }, a)
  );
}
function kp(u, s = [], a = null, f = null, p = null) {
  if (u == null) {
    if (!a) return null;
    if (a.errors) u = a.matches;
    else if (s.length === 0 && !a.initialized && a.matches.length > 0)
      u = a.matches;
    else return null;
  }
  let v = u,
    S = a?.errors;
  if (S != null) {
    let x = v.findIndex((P) => P.route.id && S?.[P.route.id] !== void 0);
    (pe(
      x >= 0,
      `Could not find a matching route for errors on route IDs: ${Object.keys(S).join(",")}`,
    ),
      (v = v.slice(0, Math.min(v.length, x + 1))));
  }
  let E = !1,
    k = -1;
  if (a)
    for (let x = 0; x < v.length; x++) {
      let P = v[x];
      if (
        ((P.route.HydrateFallback || P.route.hydrateFallbackElement) && (k = x),
        P.route.id)
      ) {
        let { loaderData: z, errors: F } = a,
          V =
            P.route.loader &&
            !z.hasOwnProperty(P.route.id) &&
            (!F || F[P.route.id] === void 0);
        if (P.route.lazy || V) {
          ((E = !0), k >= 0 ? (v = v.slice(0, k + 1)) : (v = [v[0]]));
          break;
        }
      }
    }
  return v.reduceRight((x, P, z) => {
    let F,
      V = !1,
      Y = null,
      H = null;
    a &&
      ((F = S && P.route.id ? S[P.route.id] : void 0),
      (Y = P.route.errorElement || gp),
      E &&
        (k < 0 && z === 0
          ? (_c(
              "route-fallback",
              !1,
              "No `HydrateFallback` element provided to render during initial hydration",
            ),
            (V = !0),
            (H = null))
          : k === z &&
            ((V = !0), (H = P.route.hydrateFallbackElement || null))));
    let O = s.concat(v.slice(0, z + 1)),
      W = () => {
        let A;
        return (
          F
            ? (A = Y)
            : V
              ? (A = H)
              : P.route.Component
                ? (A = C.createElement(P.route.Component, null))
                : P.route.element
                  ? (A = P.route.element)
                  : (A = x),
          C.createElement(Sp, {
            match: P,
            routeContext: { outlet: x, matches: O, isDataRoute: a != null },
            children: A,
          })
        );
      };
    return a && (P.route.ErrorBoundary || P.route.errorElement || z === 0)
      ? C.createElement(wp, {
          location: a.location,
          revalidation: a.revalidation,
          component: Y,
          error: F,
          children: W(),
          routeContext: { outlet: null, matches: O, isDataRoute: !0 },
          unstable_onError: f,
        })
      : W();
  }, null);
}
function oi(u) {
  return `${u} must be used within a data router.  See https://reactrouter.com/en/main/routers/picking-a-router.`;
}
function Ep(u) {
  let s = C.useContext(An);
  return (pe(s, oi(u)), s);
}
function Cp(u) {
  let s = C.useContext(Yl);
  return (pe(s, oi(u)), s);
}
function xp(u) {
  let s = C.useContext(mt);
  return (pe(s, oi(u)), s);
}
function ui(u) {
  let s = xp(u),
    a = s.matches[s.matches.length - 1];
  return (
    pe(
      a.route.id,
      `${u} can only be used on routes that contain a unique "id"`,
    ),
    a.route.id
  );
}
function Pp() {
  return ui("useRouteId");
}
function _p() {
  let u = C.useContext(ri),
    s = Cp("useRouteError"),
    a = ui("useRouteError");
  return u !== void 0 ? u : s.errors?.[a];
}
function Rp() {
  let { router: u } = Ep("useNavigate"),
    s = ui("useNavigate"),
    a = C.useRef(!1);
  return (
    xc(() => {
      a.current = !0;
    }),
    C.useCallback(
      async (p, v = {}) => {
        (ot(a.current, Cc),
          a.current &&
            (typeof p == "number"
              ? u.navigate(p)
              : await u.navigate(p, { fromRouteId: s, ...v })));
      },
      [u, s],
    )
  );
}
var mc = {};
function _c(u, s, a) {
  !s && !mc[u] && ((mc[u] = !0), ot(!1, a));
}
C.memo(Lp);
function Lp({ routes: u, future: s, state: a, unstable_onError: f }) {
  return Pc(u, void 0, a, f, s);
}
function hh({ to: u, replace: s, state: a, relative: f }) {
  pe(
    Bn(),
    "<Navigate> may be used only in the context of a <Router> component.",
  );
  let { static: p } = C.useContext(ht);
  ot(
    !p,
    "<Navigate> must not be used on the initial render in a <StaticRouter>. This is a no-op, but you should modify your code so the <Navigate> is only ever rendered in response to some user interaction or state change.",
  );
  let { matches: v } = C.useContext(mt),
    { pathname: S } = Mt(),
    E = li(),
    k = ni(u, ti(v), S, f === "path"),
    x = JSON.stringify(k);
  return (
    C.useEffect(() => {
      E(JSON.parse(x), { replace: s, state: a, relative: f });
    }, [E, x, f, s, a]),
    null
  );
}
function Np(u) {
  pe(
    !1,
    "A <Route> is only ever to be used as the child of <Routes> element, never rendered directly. Please wrap your <Route> in a <Routes>.",
  );
}
function Tp({
  basename: u = "/",
  children: s = null,
  location: a,
  navigationType: f = "POP",
  navigator: p,
  static: v = !1,
}) {
  pe(
    !Bn(),
    "You cannot render a <Router> inside another <Router>. You should never have more than one in your app.",
  );
  let S = u.replace(/^\/*/, "/"),
    E = C.useMemo(
      () => ({ basename: S, navigator: p, static: v, future: {} }),
      [S, p, v],
    );
  typeof a == "string" && (a = $n(a));
  let {
      pathname: k = "/",
      search: x = "",
      hash: P = "",
      state: z = null,
      key: F = "default",
    } = a,
    V = C.useMemo(() => {
      let Y = Dt(k, S);
      return Y == null
        ? null
        : {
            location: { pathname: Y, search: x, hash: P, state: z, key: F },
            navigationType: f,
          };
    }, [S, k, x, P, z, F, f]);
  return (
    ot(
      V != null,
      `<Router basename="${S}"> is not able to match the URL "${k}${x}${P}" because it does not start with the basename, so the <Router> won't render anything.`,
    ),
    V == null
      ? null
      : C.createElement(
          ht.Provider,
          { value: E },
          C.createElement(Tr.Provider, { children: s, value: V }),
        )
  );
}
function mh({ children: u, location: s }) {
  return vp(Zu(u), s);
}
function Zu(u, s = []) {
  let a = [];
  return (
    C.Children.forEach(u, (f, p) => {
      if (!C.isValidElement(f)) return;
      let v = [...s, p];
      if (f.type === C.Fragment) {
        a.push.apply(a, Zu(f.props.children, v));
        return;
      }
      (pe(
        f.type === Np,
        `[${typeof f.type == "string" ? f.type : f.type.name}] is not a <Route> component. All component children of <Routes> must be a <Route> or <React.Fragment>`,
      ),
        pe(
          !f.props.index || !f.props.children,
          "An index route cannot have child routes.",
        ));
      let S = {
        id: f.props.id || v.join("-"),
        caseSensitive: f.props.caseSensitive,
        element: f.props.element,
        Component: f.props.Component,
        index: f.props.index,
        path: f.props.path,
        middleware: f.props.middleware,
        loader: f.props.loader,
        action: f.props.action,
        hydrateFallbackElement: f.props.hydrateFallbackElement,
        HydrateFallback: f.props.HydrateFallback,
        errorElement: f.props.errorElement,
        ErrorBoundary: f.props.ErrorBoundary,
        hasErrorBoundary:
          f.props.hasErrorBoundary === !0 ||
          f.props.ErrorBoundary != null ||
          f.props.errorElement != null,
        shouldRevalidate: f.props.shouldRevalidate,
        handle: f.props.handle,
        lazy: f.props.lazy,
      };
      (f.props.children && (S.children = Zu(f.props.children, v)), a.push(S));
    }),
    a
  );
}
var Vl = "get",
  Ql = "application/x-www-form-urlencoded";
function Xl(u) {
  return u != null && typeof u.tagName == "string";
}
function zp(u) {
  return Xl(u) && u.tagName.toLowerCase() === "button";
}
function Op(u) {
  return Xl(u) && u.tagName.toLowerCase() === "form";
}
function Dp(u) {
  return Xl(u) && u.tagName.toLowerCase() === "input";
}
function Mp(u) {
  return !!(u.metaKey || u.altKey || u.ctrlKey || u.shiftKey);
}
function Fp(u, s) {
  return u.button === 0 && (!s || s === "_self") && !Mp(u);
}
function qu(u = "") {
  return new URLSearchParams(
    typeof u == "string" || Array.isArray(u) || u instanceof URLSearchParams
      ? u
      : Object.keys(u).reduce((s, a) => {
          let f = u[a];
          return s.concat(Array.isArray(f) ? f.map((p) => [a, p]) : [[a, f]]);
        }, []),
  );
}
function Ip(u, s) {
  let a = qu(u);
  return (
    s &&
      s.forEach((f, p) => {
        a.has(p) ||
          s.getAll(p).forEach((v) => {
            a.append(p, v);
          });
      }),
    a
  );
}
var Wl = null;
function jp() {
  if (Wl === null)
    try {
      (new FormData(document.createElement("form"), 0), (Wl = !1));
    } catch {
      Wl = !0;
    }
  return Wl;
}
var Up = new Set([
  "application/x-www-form-urlencoded",
  "multipart/form-data",
  "text/plain",
]);
function Gu(u) {
  return u != null && !Up.has(u)
    ? (ot(
        !1,
        `"${u}" is not a valid \`encType\` for \`<Form>\`/\`<fetcher.Form>\` and will default to "${Ql}"`,
      ),
      null)
    : u;
}
function $p(u, s) {
  let a, f, p, v, S;
  if (Op(u)) {
    let E = u.getAttribute("action");
    ((f = E ? Dt(E, s) : null),
      (a = u.getAttribute("method") || Vl),
      (p = Gu(u.getAttribute("enctype")) || Ql),
      (v = new FormData(u)));
  } else if (zp(u) || (Dp(u) && (u.type === "submit" || u.type === "image"))) {
    let E = u.form;
    if (E == null)
      throw new Error(
        'Cannot submit a <button> or <input type="submit"> without a <form>',
      );
    let k = u.getAttribute("formaction") || E.getAttribute("action");
    if (
      ((f = k ? Dt(k, s) : null),
      (a = u.getAttribute("formmethod") || E.getAttribute("method") || Vl),
      (p =
        Gu(u.getAttribute("formenctype")) ||
        Gu(E.getAttribute("enctype")) ||
        Ql),
      (v = new FormData(E, u)),
      !jp())
    ) {
      let { name: x, type: P, value: z } = u;
      if (P === "image") {
        let F = x ? `${x}.` : "";
        (v.append(`${F}x`, "0"), v.append(`${F}y`, "0"));
      } else x && v.append(x, z);
    }
  } else {
    if (Xl(u))
      throw new Error(
        'Cannot submit element that is not <form>, <button>, or <input type="submit|image">',
      );
    ((a = Vl), (f = null), (p = Ql), (S = u));
  }
  return (
    v && p === "text/plain" && ((S = v), (v = void 0)),
    { action: f, method: a.toLowerCase(), encType: p, formData: v, body: S }
  );
}
Object.getOwnPropertyNames(Object.prototype).sort().join("\0");
function ii(u, s) {
  if (u === !1 || u === null || typeof u > "u") throw new Error(s);
}
function Ap(u, s, a) {
  let f =
    typeof u == "string"
      ? new URL(
          u,
          typeof window > "u"
            ? "server://singlefetch/"
            : window.location.origin,
        )
      : u;
  return (
    f.pathname === "/"
      ? (f.pathname = `_root.${a}`)
      : s && Dt(f.pathname, s) === "/"
        ? (f.pathname = `${s.replace(/\/$/, "")}/_root.${a}`)
        : (f.pathname = `${f.pathname.replace(/\/$/, "")}.${a}`),
    f
  );
}
async function Bp(u, s) {
  if (u.id in s) return s[u.id];
  try {
    let a = await import(u.module);
    return ((s[u.id] = a), a);
  } catch (a) {
    return (
      console.error(
        `Error loading route module \`${u.module}\`, reloading page...`,
      ),
      console.error(a),
      window.__reactRouterContext && window.__reactRouterContext.isSpaMode,
      window.location.reload(),
      new Promise(() => {})
    );
  }
}
function Hp(u) {
  return u == null
    ? !1
    : u.href == null
      ? u.rel === "preload" &&
        typeof u.imageSrcSet == "string" &&
        typeof u.imageSizes == "string"
      : typeof u.rel == "string" && typeof u.href == "string";
}
async function Wp(u, s, a) {
  let f = await Promise.all(
    u.map(async (p) => {
      let v = s.routes[p.route.id];
      if (v) {
        let S = await Bp(v, a);
        return S.links ? S.links() : [];
      }
      return [];
    }),
  );
  return Yp(
    f
      .flat(1)
      .filter(Hp)
      .filter((p) => p.rel === "stylesheet" || p.rel === "preload")
      .map((p) =>
        p.rel === "stylesheet"
          ? { ...p, rel: "prefetch", as: "style" }
          : { ...p, rel: "prefetch" },
      ),
  );
}
function vc(u, s, a, f, p, v) {
  let S = (k, x) => (a[x] ? k.route.id !== a[x].route.id : !0),
    E = (k, x) =>
      a[x].pathname !== k.pathname ||
      (a[x].route.path?.endsWith("*") && a[x].params["*"] !== k.params["*"]);
  return v === "assets"
    ? s.filter((k, x) => S(k, x) || E(k, x))
    : v === "data"
      ? s.filter((k, x) => {
          let P = f.routes[k.route.id];
          if (!P || !P.hasLoader) return !1;
          if (S(k, x) || E(k, x)) return !0;
          if (k.route.shouldRevalidate) {
            let z = k.route.shouldRevalidate({
              currentUrl: new URL(
                p.pathname + p.search + p.hash,
                window.origin,
              ),
              currentParams: a[0]?.params || {},
              nextUrl: new URL(u, window.origin),
              nextParams: k.params,
              defaultShouldRevalidate: !0,
            });
            if (typeof z == "boolean") return z;
          }
          return !0;
        })
      : [];
}
function Vp(u, s, { includeHydrateFallback: a } = {}) {
  return Qp(
    u
      .map((f) => {
        let p = s.routes[f.route.id];
        if (!p) return [];
        let v = [p.module];
        return (
          p.clientActionModule && (v = v.concat(p.clientActionModule)),
          p.clientLoaderModule && (v = v.concat(p.clientLoaderModule)),
          a &&
            p.hydrateFallbackModule &&
            (v = v.concat(p.hydrateFallbackModule)),
          p.imports && (v = v.concat(p.imports)),
          v
        );
      })
      .flat(1),
  );
}
function Qp(u) {
  return [...new Set(u)];
}
function Kp(u) {
  let s = {},
    a = Object.keys(u).sort();
  for (let f of a) s[f] = u[f];
  return s;
}
function Yp(u, s) {
  let a = new Set();
  return (
    new Set(s),
    u.reduce((f, p) => {
      let v = JSON.stringify(Kp(p));
      return (a.has(v) || (a.add(v), f.push({ key: v, link: p })), f);
    }, [])
  );
}
function Rc() {
  let u = C.useContext(An);
  return (
    ii(
      u,
      "You must render this element inside a <DataRouterContext.Provider> element",
    ),
    u
  );
}
function Xp() {
  let u = C.useContext(Yl);
  return (
    ii(
      u,
      "You must render this element inside a <DataRouterStateContext.Provider> element",
    ),
    u
  );
}
var ai = C.createContext(void 0);
ai.displayName = "FrameworkContext";
function Lc() {
  let u = C.useContext(ai);
  return (
    ii(u, "You must render this element inside a <HydratedRouter> element"),
    u
  );
}
function Gp(u, s) {
  let a = C.useContext(ai),
    [f, p] = C.useState(!1),
    [v, S] = C.useState(!1),
    {
      onFocus: E,
      onBlur: k,
      onMouseEnter: x,
      onMouseLeave: P,
      onTouchStart: z,
    } = s,
    F = C.useRef(null);
  (C.useEffect(() => {
    if ((u === "render" && S(!0), u === "viewport")) {
      let H = (W) => {
          W.forEach((A) => {
            S(A.isIntersecting);
          });
        },
        O = new IntersectionObserver(H, { threshold: 0.5 });
      return (
        F.current && O.observe(F.current),
        () => {
          O.disconnect();
        }
      );
    }
  }, [u]),
    C.useEffect(() => {
      if (f) {
        let H = setTimeout(() => {
          S(!0);
        }, 100);
        return () => {
          clearTimeout(H);
        };
      }
    }, [f]));
  let V = () => {
      p(!0);
    },
    Y = () => {
      (p(!1), S(!1));
    };
  return a
    ? u !== "intent"
      ? [v, F, {}]
      : [
          v,
          F,
          {
            onFocus: Lr(E, V),
            onBlur: Lr(k, Y),
            onMouseEnter: Lr(x, V),
            onMouseLeave: Lr(P, Y),
            onTouchStart: Lr(z, V),
          },
        ]
    : [!1, F, {}];
}
function Lr(u, s) {
  return (a) => {
    (u && u(a), a.defaultPrevented || s(a));
  };
}
function Jp({ page: u, ...s }) {
  let { router: a } = Rc(),
    f = C.useMemo(() => gc(a.routes, u, a.basename), [a.routes, u, a.basename]);
  return f ? C.createElement(qp, { page: u, matches: f, ...s }) : null;
}
function Zp(u) {
  let { manifest: s, routeModules: a } = Lc(),
    [f, p] = C.useState([]);
  return (
    C.useEffect(() => {
      let v = !1;
      return (
        Wp(u, s, a).then((S) => {
          v || p(S);
        }),
        () => {
          v = !0;
        }
      );
    }, [u, s, a]),
    f
  );
}
function qp({ page: u, matches: s, ...a }) {
  let f = Mt(),
    { manifest: p, routeModules: v } = Lc(),
    { basename: S } = Rc(),
    { loaderData: E, matches: k } = Xp(),
    x = C.useMemo(() => vc(u, s, k, p, f, "data"), [u, s, k, p, f]),
    P = C.useMemo(() => vc(u, s, k, p, f, "assets"), [u, s, k, p, f]),
    z = C.useMemo(() => {
      if (u === f.pathname + f.search + f.hash) return [];
      let Y = new Set(),
        H = !1;
      if (
        (s.forEach((W) => {
          let A = p.routes[W.route.id];
          !A ||
            !A.hasLoader ||
            ((!x.some((Z) => Z.route.id === W.route.id) &&
              W.route.id in E &&
              v[W.route.id]?.shouldRevalidate) ||
            A.hasClientLoader
              ? (H = !0)
              : Y.add(W.route.id));
        }),
        Y.size === 0)
      )
        return [];
      let O = Ap(u, S, "data");
      return (
        H &&
          Y.size > 0 &&
          O.searchParams.set(
            "_routes",
            s
              .filter((W) => Y.has(W.route.id))
              .map((W) => W.route.id)
              .join(","),
          ),
        [O.pathname + O.search]
      );
    }, [S, E, f, p, x, s, u, v]),
    F = C.useMemo(() => Vp(P, p), [P, p]),
    V = Zp(P);
  return C.createElement(
    C.Fragment,
    null,
    z.map((Y) =>
      C.createElement("link", {
        key: Y,
        rel: "prefetch",
        as: "fetch",
        href: Y,
        ...a,
      }),
    ),
    F.map((Y) =>
      C.createElement("link", { key: Y, rel: "modulepreload", href: Y, ...a }),
    ),
    V.map(({ key: Y, link: H }) =>
      C.createElement("link", { key: Y, nonce: a.nonce, ...H }),
    ),
  );
}
function bp(...u) {
  return (s) => {
    u.forEach((a) => {
      typeof a == "function" ? a(s) : a != null && (a.current = s);
    });
  };
}
var Nc =
  typeof window < "u" &&
  typeof window.document < "u" &&
  typeof window.document.createElement < "u";
try {
  Nc && (window.__reactRouterVersion = "7.9.5");
} catch {}
function vh({ basename: u, children: s, window: a }) {
  let f = C.useRef();
  f.current == null && (f.current = Bd({ window: a, v5Compat: !0 }));
  let p = f.current,
    [v, S] = C.useState({ action: p.action, location: p.location }),
    E = C.useCallback(
      (k) => {
        C.startTransition(() => S(k));
      },
      [S],
    );
  return (
    C.useLayoutEffect(() => p.listen(E), [p, E]),
    C.createElement(Tp, {
      basename: u,
      children: s,
      location: v.location,
      navigationType: v.action,
      navigator: p,
    })
  );
}
var Tc = /^(?:[a-z][a-z0-9+.-]*:|\/\/)/i,
  zc = C.forwardRef(function (
    {
      onClick: s,
      discover: a = "render",
      prefetch: f = "none",
      relative: p,
      reloadDocument: v,
      replace: S,
      state: E,
      target: k,
      to: x,
      preventScrollReset: P,
      viewTransition: z,
      ...F
    },
    V,
  ) {
    let { basename: Y } = C.useContext(ht),
      H = typeof x == "string" && Tc.test(x),
      O,
      W = !1;
    if (typeof x == "string" && H && ((O = x), Nc))
      try {
        let Ce = new URL(window.location.href),
          De = x.startsWith("//") ? new URL(Ce.protocol + x) : new URL(x),
          vt = Dt(De.pathname, Y);
        De.origin === Ce.origin && vt != null
          ? (x = vt + De.search + De.hash)
          : (W = !0);
      } catch {
        ot(
          !1,
          `<Link to="${x}"> contains an invalid URL which will probably break when clicked - please update to a valid URL path.`,
        );
      }
    let A = hp(x, { relative: p }),
      [Z, ue, he] = Gp(f, F),
      ke = rh(x, {
        replace: S,
        state: E,
        target: k,
        preventScrollReset: P,
        relative: p,
        viewTransition: z,
      });
    function Ee(Ce) {
      (s && s(Ce), Ce.defaultPrevented || ke(Ce));
    }
    let Te = C.createElement("a", {
      ...F,
      ...he,
      href: O || A,
      onClick: W || v ? s : Ee,
      ref: bp(V, ue),
      target: k,
      "data-discover": !H && a === "render" ? "true" : void 0,
    });
    return Z && !H
      ? C.createElement(C.Fragment, null, Te, C.createElement(Jp, { page: A }))
      : Te;
  });
zc.displayName = "Link";
var eh = C.forwardRef(function (
  {
    "aria-current": s = "page",
    caseSensitive: a = !1,
    className: f = "",
    end: p = !1,
    style: v,
    to: S,
    viewTransition: E,
    children: k,
    ...x
  },
  P,
) {
  let z = zr(S, { relative: x.relative }),
    F = Mt(),
    V = C.useContext(Yl),
    { navigator: Y, basename: H } = C.useContext(ht),
    O = V != null && ah(z) && E === !0,
    W = Y.encodeLocation ? Y.encodeLocation(z).pathname : z.pathname,
    A = F.pathname,
    Z =
      V && V.navigation && V.navigation.location
        ? V.navigation.location.pathname
        : null;
  (a ||
    ((A = A.toLowerCase()),
    (Z = Z ? Z.toLowerCase() : null),
    (W = W.toLowerCase())),
    Z && H && (Z = Dt(Z, H) || Z));
  const ue = W !== "/" && W.endsWith("/") ? W.length - 1 : W.length;
  let he = A === W || (!p && A.startsWith(W) && A.charAt(ue) === "/"),
    ke =
      Z != null &&
      (Z === W || (!p && Z.startsWith(W) && Z.charAt(W.length) === "/")),
    Ee = { isActive: he, isPending: ke, isTransitioning: O },
    Te = he ? s : void 0,
    Ce;
  typeof f == "function"
    ? (Ce = f(Ee))
    : (Ce = [
        f,
        he ? "active" : null,
        ke ? "pending" : null,
        O ? "transitioning" : null,
      ]
        .filter(Boolean)
        .join(" "));
  let De = typeof v == "function" ? v(Ee) : v;
  return C.createElement(
    zc,
    {
      ...x,
      "aria-current": Te,
      className: Ce,
      ref: P,
      style: De,
      to: S,
      viewTransition: E,
    },
    typeof k == "function" ? k(Ee) : k,
  );
});
eh.displayName = "NavLink";
var th = C.forwardRef(
  (
    {
      discover: u = "render",
      fetcherKey: s,
      navigate: a,
      reloadDocument: f,
      replace: p,
      state: v,
      method: S = Vl,
      action: E,
      onSubmit: k,
      relative: x,
      preventScrollReset: P,
      viewTransition: z,
      ...F
    },
    V,
  ) => {
    let Y = uh(),
      H = ih(E, { relative: x }),
      O = S.toLowerCase() === "get" ? "get" : "post",
      W = typeof E == "string" && Tc.test(E),
      A = (Z) => {
        if ((k && k(Z), Z.defaultPrevented)) return;
        Z.preventDefault();
        let ue = Z.nativeEvent.submitter,
          he = ue?.getAttribute("formmethod") || S;
        Y(ue || Z.currentTarget, {
          fetcherKey: s,
          method: he,
          navigate: a,
          replace: p,
          state: v,
          relative: x,
          preventScrollReset: P,
          viewTransition: z,
        });
      };
    return C.createElement("form", {
      ref: V,
      method: O,
      action: H,
      onSubmit: f ? k : A,
      ...F,
      "data-discover": !W && u === "render" ? "true" : void 0,
    });
  },
);
th.displayName = "Form";
function nh(u) {
  return `${u} must be used within a data router.  See https://reactrouter.com/en/main/routers/picking-a-router.`;
}
function Oc(u) {
  let s = C.useContext(An);
  return (pe(s, nh(u)), s);
}
function rh(
  u,
  {
    target: s,
    replace: a,
    state: f,
    preventScrollReset: p,
    relative: v,
    viewTransition: S,
  } = {},
) {
  let E = li(),
    k = Mt(),
    x = zr(u, { relative: v });
  return C.useCallback(
    (P) => {
      if (Fp(P, s)) {
        P.preventDefault();
        let z = a !== void 0 ? a : Nr(k) === Nr(x);
        E(u, {
          replace: z,
          state: f,
          preventScrollReset: p,
          relative: v,
          viewTransition: S,
        });
      }
    },
    [k, E, x, a, f, s, u, p, v, S],
  );
}
function yh(u) {
  ot(
    typeof URLSearchParams < "u",
    "You cannot use the `useSearchParams` hook in a browser that does not support the URLSearchParams API. If you need to support Internet Explorer 11, we recommend you load a polyfill such as https://github.com/ungap/url-search-params.",
  );
  let s = C.useRef(qu(u)),
    a = C.useRef(!1),
    f = Mt(),
    p = C.useMemo(() => Ip(f.search, a.current ? null : s.current), [f.search]),
    v = li(),
    S = C.useCallback(
      (E, k) => {
        const x = qu(typeof E == "function" ? E(new URLSearchParams(p)) : E);
        ((a.current = !0), v("?" + x, k));
      },
      [v, p],
    );
  return [p, S];
}
var lh = 0,
  oh = () => `__${String(++lh)}__`;
function uh() {
  let { router: u } = Oc("useSubmit"),
    { basename: s } = C.useContext(ht),
    a = Pp();
  return C.useCallback(
    async (f, p = {}) => {
      let { action: v, method: S, encType: E, formData: k, body: x } = $p(f, s);
      if (p.navigate === !1) {
        let P = p.fetcherKey || oh();
        await u.fetch(P, a, p.action || v, {
          preventScrollReset: p.preventScrollReset,
          formData: k,
          body: x,
          formMethod: p.method || S,
          formEncType: p.encType || E,
          flushSync: p.flushSync,
        });
      } else
        await u.navigate(p.action || v, {
          preventScrollReset: p.preventScrollReset,
          formData: k,
          body: x,
          formMethod: p.method || S,
          formEncType: p.encType || E,
          replace: p.replace,
          state: p.state,
          fromRouteId: a,
          flushSync: p.flushSync,
          viewTransition: p.viewTransition,
        });
    },
    [u, s, a],
  );
}
function ih(u, { relative: s } = {}) {
  let { basename: a } = C.useContext(ht),
    f = C.useContext(mt);
  pe(f, "useFormAction must be used inside a RouteContext");
  let [p] = f.matches.slice(-1),
    v = { ...zr(u || ".", { relative: s }) },
    S = Mt();
  if (u == null) {
    v.search = S.search;
    let E = new URLSearchParams(v.search),
      k = E.getAll("index");
    if (k.some((P) => P === "")) {
      (E.delete("index"),
        k.filter((z) => z).forEach((z) => E.append("index", z)));
      let P = E.toString();
      v.search = P ? `?${P}` : "";
    }
  }
  return (
    (!u || u === ".") &&
      p.route.index &&
      (v.search = v.search ? v.search.replace(/^\?/, "?index&") : "?index"),
    a !== "/" && (v.pathname = v.pathname === "/" ? a : Ot([a, v.pathname])),
    Nr(v)
  );
}
function ah(u, { relative: s } = {}) {
  let a = C.useContext(Ec);
  pe(
    a != null,
    "`useViewTransitionState` must be used within `react-router-dom`'s `RouterProvider`.  Did you accidentally import `RouterProvider` from `react-router`?",
  );
  let { basename: f } = Oc("useViewTransitionState"),
    p = zr(u, { relative: s });
  if (!a.isTransitioning) return !1;
  let v = Dt(a.currentLocation.pathname, f) || a.currentLocation.pathname,
    S = Dt(a.nextLocation.pathname, f) || a.nextLocation.pathname;
  return Kl(p.pathname, S) != null || Kl(p.pathname, v) != null;
}
export {
  vh as B,
  zc as L,
  hh as N,
  ch as R,
  Ad as a,
  dh as b,
  Mt as c,
  fh as d,
  li as e,
  ph as f,
  bu as g,
  mh as h,
  Np as i,
  sh as j,
  yh as k,
  Md as o,
  C as r,
  Bn as u,
};
