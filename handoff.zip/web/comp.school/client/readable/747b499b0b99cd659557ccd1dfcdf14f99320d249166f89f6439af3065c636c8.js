(function () {
  const u = document.createElement("link").relList;
  if (u && u.supports && u.supports("modulepreload")) return;
  for (const f of document.querySelectorAll('link[rel="modulepreload"]')) d(f);
  new MutationObserver((f) => {
    for (const m of f)
      if (m.type === "childList")
        for (const v of m.addedNodes)
          v.tagName === "LINK" && v.rel === "modulepreload" && d(v);
  }).observe(document, { childList: !0, subtree: !0 });
  function a(f) {
    const m = {};
    return (
      f.integrity && (m.integrity = f.integrity),
      f.referrerPolicy && (m.referrerPolicy = f.referrerPolicy),
      f.crossOrigin === "use-credentials"
        ? (m.credentials = "include")
        : f.crossOrigin === "anonymous"
          ? (m.credentials = "omit")
          : (m.credentials = "same-origin"),
      m
    );
  }
  function d(f) {
    if (f.ep) return;
    f.ep = !0;
    const m = a(f);
    fetch(f.href, m);
  }
})();
function Uc(l) {
  return l && l.__esModule && Object.prototype.hasOwnProperty.call(l, "default")
    ? l.default
    : l;
}
var qi = { exports: {} },
  Br = {},
  eo = { exports: {} },
  ee = {};
/**
 * @license React
 * react.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var pc;
function dp() {
  if (pc) return ee;
  pc = 1;
  var l = Symbol.for("react.element"),
    u = Symbol.for("react.portal"),
    a = Symbol.for("react.fragment"),
    d = Symbol.for("react.strict_mode"),
    f = Symbol.for("react.profiler"),
    m = Symbol.for("react.provider"),
    v = Symbol.for("react.context"),
    E = Symbol.for("react.forward_ref"),
    j = Symbol.for("react.suspense"),
    _ = Symbol.for("react.memo"),
    P = Symbol.for("react.lazy"),
    U = Symbol.iterator;
  function W(x) {
    return x === null || typeof x != "object"
      ? null
      : ((x = (U && x[U]) || x["@@iterator"]),
        typeof x == "function" ? x : null);
  }
  var xe = {
      isMounted: function () {
        return !1;
      },
      enqueueForceUpdate: function () {},
      enqueueReplaceState: function () {},
      enqueueSetState: function () {},
    },
    ue = Object.assign,
    $ = {};
  function G(x, N, Z) {
    ((this.props = x),
      (this.context = N),
      (this.refs = $),
      (this.updater = Z || xe));
  }
  ((G.prototype.isReactComponent = {}),
    (G.prototype.setState = function (x, N) {
      if (typeof x != "object" && typeof x != "function" && x != null)
        throw Error(
          "setState(...): takes an object of state variables to update or a function which returns an object of state variables.",
        );
      this.updater.enqueueSetState(this, x, N, "setState");
    }),
    (G.prototype.forceUpdate = function (x) {
      this.updater.enqueueForceUpdate(this, x, "forceUpdate");
    }));
  function le() {}
  le.prototype = G.prototype;
  function ve(x, N, Z) {
    ((this.props = x),
      (this.context = N),
      (this.refs = $),
      (this.updater = Z || xe));
  }
  var Ce = (ve.prototype = new le());
  ((Ce.constructor = ve), ue(Ce, G.prototype), (Ce.isPureReactComponent = !0));
  var J = Array.isArray,
    ce = Object.prototype.hasOwnProperty,
    oe = { current: null },
    he = { key: !0, ref: !0, __self: !0, __source: !0 };
  function de(x, N, Z) {
    var q,
      re = {},
      te = null,
      ge = null;
    if (N != null)
      for (q in (N.ref !== void 0 && (ge = N.ref),
      N.key !== void 0 && (te = "" + N.key),
      N))
        ce.call(N, q) && !he.hasOwnProperty(q) && (re[q] = N[q]);
    var ae = arguments.length - 2;
    if (ae === 1) re.children = Z;
    else if (1 < ae) {
      for (var ke = Array(ae), et = 0; et < ae; et++)
        ke[et] = arguments[et + 2];
      re.children = ke;
    }
    if (x && x.defaultProps)
      for (q in ((ae = x.defaultProps), ae))
        re[q] === void 0 && (re[q] = ae[q]);
    return {
      $$typeof: l,
      type: x,
      key: te,
      ref: ge,
      props: re,
      _owner: oe.current,
    };
  }
  function He(x, N) {
    return {
      $$typeof: l,
      type: x.type,
      key: N,
      ref: x.ref,
      props: x.props,
      _owner: x._owner,
    };
  }
  function Ie(x) {
    return typeof x == "object" && x !== null && x.$$typeof === l;
  }
  function _e(x) {
    var N = { "=": "=0", ":": "=2" };
    return (
      "$" +
      x.replace(/[=:]/g, function (Z) {
        return N[Z];
      })
    );
  }
  var $e = /\/+/g;
  function Re(x, N) {
    return typeof x == "object" && x !== null && x.key != null
      ? _e("" + x.key)
      : N.toString(36);
  }
  function pe(x, N, Z, q, re) {
    var te = typeof x;
    (te === "undefined" || te === "boolean") && (x = null);
    var ge = !1;
    if (x === null) ge = !0;
    else
      switch (te) {
        case "string":
        case "number":
          ge = !0;
          break;
        case "object":
          switch (x.$$typeof) {
            case l:
            case u:
              ge = !0;
          }
      }
    if (ge)
      return (
        (ge = x),
        (re = re(ge)),
        (x = q === "" ? "." + Re(ge, 0) : q),
        J(re)
          ? ((Z = ""),
            x != null && (Z = x.replace($e, "$&/") + "/"),
            pe(re, N, Z, "", function (et) {
              return et;
            }))
          : re != null &&
            (Ie(re) &&
              (re = He(
                re,
                Z +
                  (!re.key || (ge && ge.key === re.key)
                    ? ""
                    : ("" + re.key).replace($e, "$&/") + "/") +
                  x,
              )),
            N.push(re)),
        1
      );
    if (((ge = 0), (q = q === "" ? "." : q + ":"), J(x)))
      for (var ae = 0; ae < x.length; ae++) {
        te = x[ae];
        var ke = q + Re(te, ae);
        ge += pe(te, N, Z, ke, re);
      }
    else if (((ke = W(x)), typeof ke == "function"))
      for (x = ke.call(x), ae = 0; !(te = x.next()).done;)
        ((te = te.value),
          (ke = q + Re(te, ae++)),
          (ge += pe(te, N, Z, ke, re)));
    else if (te === "object")
      throw (
        (N = String(x)),
        Error(
          "Objects are not valid as a React child (found: " +
            (N === "[object Object]"
              ? "object with keys {" + Object.keys(x).join(", ") + "}"
              : N) +
            "). If you meant to render a collection of children, use an array instead.",
        )
      );
    return ge;
  }
  function ye(x, N, Z) {
    if (x == null) return x;
    var q = [],
      re = 0;
    return (
      pe(x, q, "", "", function (te) {
        return N.call(Z, te, re++);
      }),
      q
    );
  }
  function we(x) {
    if (x._status === -1) {
      var N = x._result;
      ((N = N()),
        N.then(
          function (Z) {
            (x._status === 0 || x._status === -1) &&
              ((x._status = 1), (x._result = Z));
          },
          function (Z) {
            (x._status === 0 || x._status === -1) &&
              ((x._status = 2), (x._result = Z));
          },
        ),
        x._status === -1 && ((x._status = 0), (x._result = N)));
    }
    if (x._status === 1) return x._result.default;
    throw x._result;
  }
  var fe = { current: null },
    L = { transition: null },
    B = {
      ReactCurrentDispatcher: fe,
      ReactCurrentBatchConfig: L,
      ReactCurrentOwner: oe,
    };
  function A() {
    throw Error("act(...) is not supported in production builds of React.");
  }
  return (
    (ee.Children = {
      map: ye,
      forEach: function (x, N, Z) {
        ye(
          x,
          function () {
            N.apply(this, arguments);
          },
          Z,
        );
      },
      count: function (x) {
        var N = 0;
        return (
          ye(x, function () {
            N++;
          }),
          N
        );
      },
      toArray: function (x) {
        return (
          ye(x, function (N) {
            return N;
          }) || []
        );
      },
      only: function (x) {
        if (!Ie(x))
          throw Error(
            "React.Children.only expected to receive a single React element child.",
          );
        return x;
      },
    }),
    (ee.Component = G),
    (ee.Fragment = a),
    (ee.Profiler = f),
    (ee.PureComponent = ve),
    (ee.StrictMode = d),
    (ee.Suspense = j),
    (ee.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = B),
    (ee.act = A),
    (ee.cloneElement = function (x, N, Z) {
      if (x == null)
        throw Error(
          "React.cloneElement(...): The argument must be a React element, but you passed " +
            x +
            ".",
        );
      var q = ue({}, x.props),
        re = x.key,
        te = x.ref,
        ge = x._owner;
      if (N != null) {
        if (
          (N.ref !== void 0 && ((te = N.ref), (ge = oe.current)),
          N.key !== void 0 && (re = "" + N.key),
          x.type && x.type.defaultProps)
        )
          var ae = x.type.defaultProps;
        for (ke in N)
          ce.call(N, ke) &&
            !he.hasOwnProperty(ke) &&
            (q[ke] = N[ke] === void 0 && ae !== void 0 ? ae[ke] : N[ke]);
      }
      var ke = arguments.length - 2;
      if (ke === 1) q.children = Z;
      else if (1 < ke) {
        ae = Array(ke);
        for (var et = 0; et < ke; et++) ae[et] = arguments[et + 2];
        q.children = ae;
      }
      return {
        $$typeof: l,
        type: x.type,
        key: re,
        ref: te,
        props: q,
        _owner: ge,
      };
    }),
    (ee.createContext = function (x) {
      return (
        (x = {
          $$typeof: v,
          _currentValue: x,
          _currentValue2: x,
          _threadCount: 0,
          Provider: null,
          Consumer: null,
          _defaultValue: null,
          _globalName: null,
        }),
        (x.Provider = { $$typeof: m, _context: x }),
        (x.Consumer = x)
      );
    }),
    (ee.createElement = de),
    (ee.createFactory = function (x) {
      var N = de.bind(null, x);
      return ((N.type = x), N);
    }),
    (ee.createRef = function () {
      return { current: null };
    }),
    (ee.forwardRef = function (x) {
      return { $$typeof: E, render: x };
    }),
    (ee.isValidElement = Ie),
    (ee.lazy = function (x) {
      return { $$typeof: P, _payload: { _status: -1, _result: x }, _init: we };
    }),
    (ee.memo = function (x, N) {
      return { $$typeof: _, type: x, compare: N === void 0 ? null : N };
    }),
    (ee.startTransition = function (x) {
      var N = L.transition;
      L.transition = {};
      try {
        x();
      } finally {
        L.transition = N;
      }
    }),
    (ee.unstable_act = A),
    (ee.useCallback = function (x, N) {
      return fe.current.useCallback(x, N);
    }),
    (ee.useContext = function (x) {
      return fe.current.useContext(x);
    }),
    (ee.useDebugValue = function () {}),
    (ee.useDeferredValue = function (x) {
      return fe.current.useDeferredValue(x);
    }),
    (ee.useEffect = function (x, N) {
      return fe.current.useEffect(x, N);
    }),
    (ee.useId = function () {
      return fe.current.useId();
    }),
    (ee.useImperativeHandle = function (x, N, Z) {
      return fe.current.useImperativeHandle(x, N, Z);
    }),
    (ee.useInsertionEffect = function (x, N) {
      return fe.current.useInsertionEffect(x, N);
    }),
    (ee.useLayoutEffect = function (x, N) {
      return fe.current.useLayoutEffect(x, N);
    }),
    (ee.useMemo = function (x, N) {
      return fe.current.useMemo(x, N);
    }),
    (ee.useReducer = function (x, N, Z) {
      return fe.current.useReducer(x, N, Z);
    }),
    (ee.useRef = function (x) {
      return fe.current.useRef(x);
    }),
    (ee.useState = function (x) {
      return fe.current.useState(x);
    }),
    (ee.useSyncExternalStore = function (x, N, Z) {
      return fe.current.useSyncExternalStore(x, N, Z);
    }),
    (ee.useTransition = function () {
      return fe.current.useTransition();
    }),
    (ee.version = "18.3.1"),
    ee
  );
}
var mc;
function ho() {
  return (mc || ((mc = 1), (eo.exports = dp())), eo.exports);
}
/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var hc;
function fp() {
  if (hc) return Br;
  hc = 1;
  var l = ho(),
    u = Symbol.for("react.element"),
    a = Symbol.for("react.fragment"),
    d = Object.prototype.hasOwnProperty,
    f = l.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,
    m = { key: !0, ref: !0, __self: !0, __source: !0 };
  function v(E, j, _) {
    var P,
      U = {},
      W = null,
      xe = null;
    (_ !== void 0 && (W = "" + _),
      j.key !== void 0 && (W = "" + j.key),
      j.ref !== void 0 && (xe = j.ref));
    for (P in j) d.call(j, P) && !m.hasOwnProperty(P) && (U[P] = j[P]);
    if (E && E.defaultProps)
      for (P in ((j = E.defaultProps), j)) U[P] === void 0 && (U[P] = j[P]);
    return {
      $$typeof: u,
      type: E,
      key: W,
      ref: xe,
      props: U,
      _owner: f.current,
    };
  }
  return ((Br.Fragment = a), (Br.jsx = v), (Br.jsxs = v), Br);
}
var gc;
function pp() {
  return (gc || ((gc = 1), (qi.exports = fp())), qi.exports);
}
var s = pp(),
  X = ho();
const mp = Uc(X);
var ts = {},
  to = { exports: {} },
  at = {},
  no = { exports: {} },
  ro = {};
/**
 * @license React
 * scheduler.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var xc;
function hp() {
  return (
    xc ||
      ((xc = 1),
      (function (l) {
        function u(L, B) {
          var A = L.length;
          L.push(B);
          e: for (; 0 < A;) {
            var x = (A - 1) >>> 1,
              N = L[x];
            if (0 < f(N, B)) ((L[x] = B), (L[A] = N), (A = x));
            else break e;
          }
        }
        function a(L) {
          return L.length === 0 ? null : L[0];
        }
        function d(L) {
          if (L.length === 0) return null;
          var B = L[0],
            A = L.pop();
          if (A !== B) {
            L[0] = A;
            e: for (var x = 0, N = L.length, Z = N >>> 1; x < Z;) {
              var q = 2 * (x + 1) - 1,
                re = L[q],
                te = q + 1,
                ge = L[te];
              if (0 > f(re, A))
                te < N && 0 > f(ge, re)
                  ? ((L[x] = ge), (L[te] = A), (x = te))
                  : ((L[x] = re), (L[q] = A), (x = q));
              else if (te < N && 0 > f(ge, A))
                ((L[x] = ge), (L[te] = A), (x = te));
              else break e;
            }
          }
          return B;
        }
        function f(L, B) {
          var A = L.sortIndex - B.sortIndex;
          return A !== 0 ? A : L.id - B.id;
        }
        if (
          typeof performance == "object" &&
          typeof performance.now == "function"
        ) {
          var m = performance;
          l.unstable_now = function () {
            return m.now();
          };
        } else {
          var v = Date,
            E = v.now();
          l.unstable_now = function () {
            return v.now() - E;
          };
        }
        var j = [],
          _ = [],
          P = 1,
          U = null,
          W = 3,
          xe = !1,
          ue = !1,
          $ = !1,
          G = typeof setTimeout == "function" ? setTimeout : null,
          le = typeof clearTimeout == "function" ? clearTimeout : null,
          ve = typeof setImmediate < "u" ? setImmediate : null;
        typeof navigator < "u" &&
          navigator.scheduling !== void 0 &&
          navigator.scheduling.isInputPending !== void 0 &&
          navigator.scheduling.isInputPending.bind(navigator.scheduling);
        function Ce(L) {
          for (var B = a(_); B !== null;) {
            if (B.callback === null) d(_);
            else if (B.startTime <= L)
              (d(_), (B.sortIndex = B.expirationTime), u(j, B));
            else break;
            B = a(_);
          }
        }
        function J(L) {
          if ((($ = !1), Ce(L), !ue))
            if (a(j) !== null) ((ue = !0), we(ce));
            else {
              var B = a(_);
              B !== null && fe(J, B.startTime - L);
            }
        }
        function ce(L, B) {
          ((ue = !1), $ && (($ = !1), le(de), (de = -1)), (xe = !0));
          var A = W;
          try {
            for (
              Ce(B), U = a(j);
              U !== null && (!(U.expirationTime > B) || (L && !_e()));
            ) {
              var x = U.callback;
              if (typeof x == "function") {
                ((U.callback = null), (W = U.priorityLevel));
                var N = x(U.expirationTime <= B);
                ((B = l.unstable_now()),
                  typeof N == "function"
                    ? (U.callback = N)
                    : U === a(j) && d(j),
                  Ce(B));
              } else d(j);
              U = a(j);
            }
            if (U !== null) var Z = !0;
            else {
              var q = a(_);
              (q !== null && fe(J, q.startTime - B), (Z = !1));
            }
            return Z;
          } finally {
            ((U = null), (W = A), (xe = !1));
          }
        }
        var oe = !1,
          he = null,
          de = -1,
          He = 5,
          Ie = -1;
        function _e() {
          return !(l.unstable_now() - Ie < He);
        }
        function $e() {
          if (he !== null) {
            var L = l.unstable_now();
            Ie = L;
            var B = !0;
            try {
              B = he(!0, L);
            } finally {
              B ? Re() : ((oe = !1), (he = null));
            }
          } else oe = !1;
        }
        var Re;
        if (typeof ve == "function")
          Re = function () {
            ve($e);
          };
        else if (typeof MessageChannel < "u") {
          var pe = new MessageChannel(),
            ye = pe.port2;
          ((pe.port1.onmessage = $e),
            (Re = function () {
              ye.postMessage(null);
            }));
        } else
          Re = function () {
            G($e, 0);
          };
        function we(L) {
          ((he = L), oe || ((oe = !0), Re()));
        }
        function fe(L, B) {
          de = G(function () {
            L(l.unstable_now());
          }, B);
        }
        ((l.unstable_IdlePriority = 5),
          (l.unstable_ImmediatePriority = 1),
          (l.unstable_LowPriority = 4),
          (l.unstable_NormalPriority = 3),
          (l.unstable_Profiling = null),
          (l.unstable_UserBlockingPriority = 2),
          (l.unstable_cancelCallback = function (L) {
            L.callback = null;
          }),
          (l.unstable_continueExecution = function () {
            ue || xe || ((ue = !0), we(ce));
          }),
          (l.unstable_forceFrameRate = function (L) {
            0 > L || 125 < L
              ? console.error(
                  "forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported",
                )
              : (He = 0 < L ? Math.floor(1e3 / L) : 5);
          }),
          (l.unstable_getCurrentPriorityLevel = function () {
            return W;
          }),
          (l.unstable_getFirstCallbackNode = function () {
            return a(j);
          }),
          (l.unstable_next = function (L) {
            switch (W) {
              case 1:
              case 2:
              case 3:
                var B = 3;
                break;
              default:
                B = W;
            }
            var A = W;
            W = B;
            try {
              return L();
            } finally {
              W = A;
            }
          }),
          (l.unstable_pauseExecution = function () {}),
          (l.unstable_requestPaint = function () {}),
          (l.unstable_runWithPriority = function (L, B) {
            switch (L) {
              case 1:
              case 2:
              case 3:
              case 4:
              case 5:
                break;
              default:
                L = 3;
            }
            var A = W;
            W = L;
            try {
              return B();
            } finally {
              W = A;
            }
          }),
          (l.unstable_scheduleCallback = function (L, B, A) {
            var x = l.unstable_now();
            switch (
              (typeof A == "object" && A !== null
                ? ((A = A.delay),
                  (A = typeof A == "number" && 0 < A ? x + A : x))
                : (A = x),
              L)
            ) {
              case 1:
                var N = -1;
                break;
              case 2:
                N = 250;
                break;
              case 5:
                N = 1073741823;
                break;
              case 4:
                N = 1e4;
                break;
              default:
                N = 5e3;
            }
            return (
              (N = A + N),
              (L = {
                id: P++,
                callback: B,
                priorityLevel: L,
                startTime: A,
                expirationTime: N,
                sortIndex: -1,
              }),
              A > x
                ? ((L.sortIndex = A),
                  u(_, L),
                  a(j) === null &&
                    L === a(_) &&
                    ($ ? (le(de), (de = -1)) : ($ = !0), fe(J, A - x)))
                : ((L.sortIndex = N), u(j, L), ue || xe || ((ue = !0), we(ce))),
              L
            );
          }),
          (l.unstable_shouldYield = _e),
          (l.unstable_wrapCallback = function (L) {
            var B = W;
            return function () {
              var A = W;
              W = B;
              try {
                return L.apply(this, arguments);
              } finally {
                W = A;
              }
            };
          }));
      })(ro)),
    ro
  );
}
var yc;
function gp() {
  return (yc || ((yc = 1), (no.exports = hp())), no.exports);
}
/**
 * @license React
 * react-dom.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var vc;
function xp() {
  if (vc) return at;
  vc = 1;
  var l = ho(),
    u = gp();
  function a(e) {
    for (
      var t = "https://reactjs.org/docs/error-decoder.html?invariant=" + e,
        n = 1;
      n < arguments.length;
      n++
    )
      t += "&args[]=" + encodeURIComponent(arguments[n]);
    return (
      "Minified React error #" +
      e +
      "; visit " +
      t +
      " for the full message or use the non-minified dev environment for full errors and additional helpful warnings."
    );
  }
  var d = new Set(),
    f = {};
  function m(e, t) {
    (v(e, t), v(e + "Capture", t));
  }
  function v(e, t) {
    for (f[e] = t, e = 0; e < t.length; e++) d.add(t[e]);
  }
  var E = !(
      typeof window > "u" ||
      typeof window.document > "u" ||
      typeof window.document.createElement > "u"
    ),
    j = Object.prototype.hasOwnProperty,
    _ =
      /^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/,
    P = {},
    U = {};
  function W(e) {
    return j.call(U, e)
      ? !0
      : j.call(P, e)
        ? !1
        : _.test(e)
          ? (U[e] = !0)
          : ((P[e] = !0), !1);
  }
  function xe(e, t, n, r) {
    if (n !== null && n.type === 0) return !1;
    switch (typeof t) {
      case "function":
      case "symbol":
        return !0;
      case "boolean":
        return r
          ? !1
          : n !== null
            ? !n.acceptsBooleans
            : ((e = e.toLowerCase().slice(0, 5)),
              e !== "data-" && e !== "aria-");
      default:
        return !1;
    }
  }
  function ue(e, t, n, r) {
    if (t === null || typeof t > "u" || xe(e, t, n, r)) return !0;
    if (r) return !1;
    if (n !== null)
      switch (n.type) {
        case 3:
          return !t;
        case 4:
          return t === !1;
        case 5:
          return isNaN(t);
        case 6:
          return isNaN(t) || 1 > t;
      }
    return !1;
  }
  function $(e, t, n, r, i, o, c) {
    ((this.acceptsBooleans = t === 2 || t === 3 || t === 4),
      (this.attributeName = r),
      (this.attributeNamespace = i),
      (this.mustUseProperty = n),
      (this.propertyName = e),
      (this.type = t),
      (this.sanitizeURL = o),
      (this.removeEmptyString = c));
  }
  var G = {};
  ("children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style"
    .split(" ")
    .forEach(function (e) {
      G[e] = new $(e, 0, !1, e, null, !1, !1);
    }),
    [
      ["acceptCharset", "accept-charset"],
      ["className", "class"],
      ["htmlFor", "for"],
      ["httpEquiv", "http-equiv"],
    ].forEach(function (e) {
      var t = e[0];
      G[t] = new $(t, 1, !1, e[1], null, !1, !1);
    }),
    ["contentEditable", "draggable", "spellCheck", "value"].forEach(
      function (e) {
        G[e] = new $(e, 2, !1, e.toLowerCase(), null, !1, !1);
      },
    ),
    [
      "autoReverse",
      "externalResourcesRequired",
      "focusable",
      "preserveAlpha",
    ].forEach(function (e) {
      G[e] = new $(e, 2, !1, e, null, !1, !1);
    }),
    "allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope"
      .split(" ")
      .forEach(function (e) {
        G[e] = new $(e, 3, !1, e.toLowerCase(), null, !1, !1);
      }),
    ["checked", "multiple", "muted", "selected"].forEach(function (e) {
      G[e] = new $(e, 3, !0, e, null, !1, !1);
    }),
    ["capture", "download"].forEach(function (e) {
      G[e] = new $(e, 4, !1, e, null, !1, !1);
    }),
    ["cols", "rows", "size", "span"].forEach(function (e) {
      G[e] = new $(e, 6, !1, e, null, !1, !1);
    }),
    ["rowSpan", "start"].forEach(function (e) {
      G[e] = new $(e, 5, !1, e.toLowerCase(), null, !1, !1);
    }));
  var le = /[\-:]([a-z])/g;
  function ve(e) {
    return e[1].toUpperCase();
  }
  ("accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height"
    .split(" ")
    .forEach(function (e) {
      var t = e.replace(le, ve);
      G[t] = new $(t, 1, !1, e, null, !1, !1);
    }),
    "xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type"
      .split(" ")
      .forEach(function (e) {
        var t = e.replace(le, ve);
        G[t] = new $(t, 1, !1, e, "http://www.w3.org/1999/xlink", !1, !1);
      }),
    ["xml:base", "xml:lang", "xml:space"].forEach(function (e) {
      var t = e.replace(le, ve);
      G[t] = new $(t, 1, !1, e, "http://www.w3.org/XML/1998/namespace", !1, !1);
    }),
    ["tabIndex", "crossOrigin"].forEach(function (e) {
      G[e] = new $(e, 1, !1, e.toLowerCase(), null, !1, !1);
    }),
    (G.xlinkHref = new $(
      "xlinkHref",
      1,
      !1,
      "xlink:href",
      "http://www.w3.org/1999/xlink",
      !0,
      !1,
    )),
    ["src", "href", "action", "formAction"].forEach(function (e) {
      G[e] = new $(e, 1, !1, e.toLowerCase(), null, !0, !0);
    }));
  function Ce(e, t, n, r) {
    var i = G.hasOwnProperty(t) ? G[t] : null;
    (i !== null
      ? i.type !== 0
      : r ||
        !(2 < t.length) ||
        (t[0] !== "o" && t[0] !== "O") ||
        (t[1] !== "n" && t[1] !== "N")) &&
      (ue(t, n, i, r) && (n = null),
      r || i === null
        ? W(t) &&
          (n === null ? e.removeAttribute(t) : e.setAttribute(t, "" + n))
        : i.mustUseProperty
          ? (e[i.propertyName] = n === null ? (i.type === 3 ? !1 : "") : n)
          : ((t = i.attributeName),
            (r = i.attributeNamespace),
            n === null
              ? e.removeAttribute(t)
              : ((i = i.type),
                (n = i === 3 || (i === 4 && n === !0) ? "" : "" + n),
                r ? e.setAttributeNS(r, t, n) : e.setAttribute(t, n))));
  }
  var J = l.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED,
    ce = Symbol.for("react.element"),
    oe = Symbol.for("react.portal"),
    he = Symbol.for("react.fragment"),
    de = Symbol.for("react.strict_mode"),
    He = Symbol.for("react.profiler"),
    Ie = Symbol.for("react.provider"),
    _e = Symbol.for("react.context"),
    $e = Symbol.for("react.forward_ref"),
    Re = Symbol.for("react.suspense"),
    pe = Symbol.for("react.suspense_list"),
    ye = Symbol.for("react.memo"),
    we = Symbol.for("react.lazy"),
    fe = Symbol.for("react.offscreen"),
    L = Symbol.iterator;
  function B(e) {
    return e === null || typeof e != "object"
      ? null
      : ((e = (L && e[L]) || e["@@iterator"]),
        typeof e == "function" ? e : null);
  }
  var A = Object.assign,
    x;
  function N(e) {
    if (x === void 0)
      try {
        throw Error();
      } catch (n) {
        var t = n.stack.trim().match(/\n( *(at )?)/);
        x = (t && t[1]) || "";
      }
    return (
      `
` +
      x +
      e
    );
  }
  var Z = !1;
  function q(e, t) {
    if (!e || Z) return "";
    Z = !0;
    var n = Error.prepareStackTrace;
    Error.prepareStackTrace = void 0;
    try {
      if (t)
        if (
          ((t = function () {
            throw Error();
          }),
          Object.defineProperty(t.prototype, "props", {
            set: function () {
              throw Error();
            },
          }),
          typeof Reflect == "object" && Reflect.construct)
        ) {
          try {
            Reflect.construct(t, []);
          } catch (k) {
            var r = k;
          }
          Reflect.construct(e, [], t);
        } else {
          try {
            t.call();
          } catch (k) {
            r = k;
          }
          e.call(t.prototype);
        }
      else {
        try {
          throw Error();
        } catch (k) {
          r = k;
        }
        e();
      }
    } catch (k) {
      if (k && r && typeof k.stack == "string") {
        for (
          var i = k.stack.split(`
`),
            o = r.stack.split(`
`),
            c = i.length - 1,
            p = o.length - 1;
          1 <= c && 0 <= p && i[c] !== o[p];
        )
          p--;
        for (; 1 <= c && 0 <= p; c--, p--)
          if (i[c] !== o[p]) {
            if (c !== 1 || p !== 1)
              do
                if ((c--, p--, 0 > p || i[c] !== o[p])) {
                  var h =
                    `
` + i[c].replace(" at new ", " at ");
                  return (
                    e.displayName &&
                      h.includes("<anonymous>") &&
                      (h = h.replace("<anonymous>", e.displayName)),
                    h
                  );
                }
              while (1 <= c && 0 <= p);
            break;
          }
      }
    } finally {
      ((Z = !1), (Error.prepareStackTrace = n));
    }
    return (e = e ? e.displayName || e.name : "") ? N(e) : "";
  }
  function re(e) {
    switch (e.tag) {
      case 5:
        return N(e.type);
      case 16:
        return N("Lazy");
      case 13:
        return N("Suspense");
      case 19:
        return N("SuspenseList");
      case 0:
      case 2:
      case 15:
        return ((e = q(e.type, !1)), e);
      case 11:
        return ((e = q(e.type.render, !1)), e);
      case 1:
        return ((e = q(e.type, !0)), e);
      default:
        return "";
    }
  }
  function te(e) {
    if (e == null) return null;
    if (typeof e == "function") return e.displayName || e.name || null;
    if (typeof e == "string") return e;
    switch (e) {
      case he:
        return "Fragment";
      case oe:
        return "Portal";
      case He:
        return "Profiler";
      case de:
        return "StrictMode";
      case Re:
        return "Suspense";
      case pe:
        return "SuspenseList";
    }
    if (typeof e == "object")
      switch (e.$$typeof) {
        case _e:
          return (e.displayName || "Context") + ".Consumer";
        case Ie:
          return (e._context.displayName || "Context") + ".Provider";
        case $e:
          var t = e.render;
          return (
            (e = e.displayName),
            e ||
              ((e = t.displayName || t.name || ""),
              (e = e !== "" ? "ForwardRef(" + e + ")" : "ForwardRef")),
            e
          );
        case ye:
          return (
            (t = e.displayName || null),
            t !== null ? t : te(e.type) || "Memo"
          );
        case we:
          ((t = e._payload), (e = e._init));
          try {
            return te(e(t));
          } catch {}
      }
    return null;
  }
  function ge(e) {
    var t = e.type;
    switch (e.tag) {
      case 24:
        return "Cache";
      case 9:
        return (t.displayName || "Context") + ".Consumer";
      case 10:
        return (t._context.displayName || "Context") + ".Provider";
      case 18:
        return "DehydratedFragment";
      case 11:
        return (
          (e = t.render),
          (e = e.displayName || e.name || ""),
          t.displayName || (e !== "" ? "ForwardRef(" + e + ")" : "ForwardRef")
        );
      case 7:
        return "Fragment";
      case 5:
        return t;
      case 4:
        return "Portal";
      case 3:
        return "Root";
      case 6:
        return "Text";
      case 16:
        return te(t);
      case 8:
        return t === de ? "StrictMode" : "Mode";
      case 22:
        return "Offscreen";
      case 12:
        return "Profiler";
      case 21:
        return "Scope";
      case 13:
        return "Suspense";
      case 19:
        return "SuspenseList";
      case 25:
        return "TracingMarker";
      case 1:
      case 0:
      case 17:
      case 2:
      case 14:
      case 15:
        if (typeof t == "function") return t.displayName || t.name || null;
        if (typeof t == "string") return t;
    }
    return null;
  }
  function ae(e) {
    switch (typeof e) {
      case "boolean":
      case "number":
      case "string":
      case "undefined":
        return e;
      case "object":
        return e;
      default:
        return "";
    }
  }
  function ke(e) {
    var t = e.type;
    return (
      (e = e.nodeName) &&
      e.toLowerCase() === "input" &&
      (t === "checkbox" || t === "radio")
    );
  }
  function et(e) {
    var t = ke(e) ? "checked" : "value",
      n = Object.getOwnPropertyDescriptor(e.constructor.prototype, t),
      r = "" + e[t];
    if (
      !e.hasOwnProperty(t) &&
      typeof n < "u" &&
      typeof n.get == "function" &&
      typeof n.set == "function"
    ) {
      var i = n.get,
        o = n.set;
      return (
        Object.defineProperty(e, t, {
          configurable: !0,
          get: function () {
            return i.call(this);
          },
          set: function (c) {
            ((r = "" + c), o.call(this, c));
          },
        }),
        Object.defineProperty(e, t, { enumerable: n.enumerable }),
        {
          getValue: function () {
            return r;
          },
          setValue: function (c) {
            r = "" + c;
          },
          stopTracking: function () {
            ((e._valueTracker = null), delete e[t]);
          },
        }
      );
    }
  }
  function dn(e) {
    e._valueTracker || (e._valueTracker = et(e));
  }
  function nr(e) {
    if (!e) return !1;
    var t = e._valueTracker;
    if (!t) return !0;
    var n = t.getValue(),
      r = "";
    return (
      e && (r = ke(e) ? (e.checked ? "true" : "false") : e.value),
      (e = r),
      e !== n ? (t.setValue(e), !0) : !1
    );
  }
  function Rn(e) {
    if (
      ((e = e || (typeof document < "u" ? document : void 0)), typeof e > "u")
    )
      return null;
    try {
      return e.activeElement || e.body;
    } catch {
      return e.body;
    }
  }
  function rr(e, t) {
    var n = t.checked;
    return A({}, t, {
      defaultChecked: void 0,
      defaultValue: void 0,
      value: void 0,
      checked: n ?? e._wrapperState.initialChecked,
    });
  }
  function R(e, t) {
    var n = t.defaultValue == null ? "" : t.defaultValue,
      r = t.checked != null ? t.checked : t.defaultChecked;
    ((n = ae(t.value != null ? t.value : n)),
      (e._wrapperState = {
        initialChecked: r,
        initialValue: n,
        controlled:
          t.type === "checkbox" || t.type === "radio"
            ? t.checked != null
            : t.value != null,
      }));
  }
  function Y(e, t) {
    ((t = t.checked), t != null && Ce(e, "checked", t, !1));
  }
  function K(e, t) {
    Y(e, t);
    var n = ae(t.value),
      r = t.type;
    if (n != null)
      r === "number"
        ? ((n === 0 && e.value === "") || e.value != n) && (e.value = "" + n)
        : e.value !== "" + n && (e.value = "" + n);
    else if (r === "submit" || r === "reset") {
      e.removeAttribute("value");
      return;
    }
    (t.hasOwnProperty("value")
      ? Ze(e, t.type, n)
      : t.hasOwnProperty("defaultValue") && Ze(e, t.type, ae(t.defaultValue)),
      t.checked == null &&
        t.defaultChecked != null &&
        (e.defaultChecked = !!t.defaultChecked));
  }
  function Le(e, t, n) {
    if (t.hasOwnProperty("value") || t.hasOwnProperty("defaultValue")) {
      var r = t.type;
      if (!(
        (r !== "submit" && r !== "reset") ||
        (t.value !== void 0 && t.value !== null)
      ))
        return;
      ((t = "" + e._wrapperState.initialValue),
        n || t === e.value || (e.value = t),
        (e.defaultValue = t));
    }
    ((n = e.name),
      n !== "" && (e.name = ""),
      (e.defaultChecked = !!e._wrapperState.initialChecked),
      n !== "" && (e.name = n));
  }
  function Ze(e, t, n) {
    (t !== "number" || Rn(e.ownerDocument) !== e) &&
      (n == null
        ? (e.defaultValue = "" + e._wrapperState.initialValue)
        : e.defaultValue !== "" + n && (e.defaultValue = "" + n));
  }
  var lr = Array.isArray;
  function Mn(e, t, n, r) {
    if (((e = e.options), t)) {
      t = {};
      for (var i = 0; i < n.length; i++) t["$" + n[i]] = !0;
      for (n = 0; n < e.length; n++)
        ((i = t.hasOwnProperty("$" + e[n].value)),
          e[n].selected !== i && (e[n].selected = i),
          i && r && (e[n].defaultSelected = !0));
    } else {
      for (n = "" + ae(n), t = null, i = 0; i < e.length; i++) {
        if (e[i].value === n) {
          ((e[i].selected = !0), r && (e[i].defaultSelected = !0));
          return;
        }
        t !== null || e[i].disabled || (t = e[i]);
      }
      t !== null && (t.selected = !0);
    }
  }
  function us(e, t) {
    if (t.dangerouslySetInnerHTML != null) throw Error(a(91));
    return A({}, t, {
      value: void 0,
      defaultValue: void 0,
      children: "" + e._wrapperState.initialValue,
    });
  }
  function So(e, t) {
    var n = t.value;
    if (n == null) {
      if (((n = t.children), (t = t.defaultValue), n != null)) {
        if (t != null) throw Error(a(92));
        if (lr(n)) {
          if (1 < n.length) throw Error(a(93));
          n = n[0];
        }
        t = n;
      }
      (t == null && (t = ""), (n = t));
    }
    e._wrapperState = { initialValue: ae(n) };
  }
  function No(e, t) {
    var n = ae(t.value),
      r = ae(t.defaultValue);
    (n != null &&
      ((n = "" + n),
      n !== e.value && (e.value = n),
      t.defaultValue == null && e.defaultValue !== n && (e.defaultValue = n)),
      r != null && (e.defaultValue = "" + r));
  }
  function Co(e) {
    var t = e.textContent;
    t === e._wrapperState.initialValue &&
      t !== "" &&
      t !== null &&
      (e.value = t);
  }
  function bo(e) {
    switch (e) {
      case "svg":
        return "http://www.w3.org/2000/svg";
      case "math":
        return "http://www.w3.org/1998/Math/MathML";
      default:
        return "http://www.w3.org/1999/xhtml";
    }
  }
  function cs(e, t) {
    return e == null || e === "http://www.w3.org/1999/xhtml"
      ? bo(t)
      : e === "http://www.w3.org/2000/svg" && t === "foreignObject"
        ? "http://www.w3.org/1999/xhtml"
        : e;
  }
  var Gr,
    zo = (function (e) {
      return typeof MSApp < "u" && MSApp.execUnsafeLocalFunction
        ? function (t, n, r, i) {
            MSApp.execUnsafeLocalFunction(function () {
              return e(t, n, r, i);
            });
          }
        : e;
    })(function (e, t) {
      if (e.namespaceURI !== "http://www.w3.org/2000/svg" || "innerHTML" in e)
        e.innerHTML = t;
      else {
        for (
          Gr = Gr || document.createElement("div"),
            Gr.innerHTML = "<svg>" + t.valueOf().toString() + "</svg>",
            t = Gr.firstChild;
          e.firstChild;
        )
          e.removeChild(e.firstChild);
        for (; t.firstChild;) e.appendChild(t.firstChild);
      }
    });
  function sr(e, t) {
    if (t) {
      var n = e.firstChild;
      if (n && n === e.lastChild && n.nodeType === 3) {
        n.nodeValue = t;
        return;
      }
    }
    e.textContent = t;
  }
  var ir = {
      animationIterationCount: !0,
      aspectRatio: !0,
      borderImageOutset: !0,
      borderImageSlice: !0,
      borderImageWidth: !0,
      boxFlex: !0,
      boxFlexGroup: !0,
      boxOrdinalGroup: !0,
      columnCount: !0,
      columns: !0,
      flex: !0,
      flexGrow: !0,
      flexPositive: !0,
      flexShrink: !0,
      flexNegative: !0,
      flexOrder: !0,
      gridArea: !0,
      gridRow: !0,
      gridRowEnd: !0,
      gridRowSpan: !0,
      gridRowStart: !0,
      gridColumn: !0,
      gridColumnEnd: !0,
      gridColumnSpan: !0,
      gridColumnStart: !0,
      fontWeight: !0,
      lineClamp: !0,
      lineHeight: !0,
      opacity: !0,
      order: !0,
      orphans: !0,
      tabSize: !0,
      widows: !0,
      zIndex: !0,
      zoom: !0,
      fillOpacity: !0,
      floodOpacity: !0,
      stopOpacity: !0,
      strokeDasharray: !0,
      strokeDashoffset: !0,
      strokeMiterlimit: !0,
      strokeOpacity: !0,
      strokeWidth: !0,
    },
    md = ["Webkit", "ms", "Moz", "O"];
  Object.keys(ir).forEach(function (e) {
    md.forEach(function (t) {
      ((t = t + e.charAt(0).toUpperCase() + e.substring(1)), (ir[t] = ir[e]));
    });
  });
  function Eo(e, t, n) {
    return t == null || typeof t == "boolean" || t === ""
      ? ""
      : n || typeof t != "number" || t === 0 || (ir.hasOwnProperty(e) && ir[e])
        ? ("" + t).trim()
        : t + "px";
  }
  function Ro(e, t) {
    e = e.style;
    for (var n in t)
      if (t.hasOwnProperty(n)) {
        var r = n.indexOf("--") === 0,
          i = Eo(n, t[n], r);
        (n === "float" && (n = "cssFloat"),
          r ? e.setProperty(n, i) : (e[n] = i));
      }
  }
  var hd = A(
    { menuitem: !0 },
    {
      area: !0,
      base: !0,
      br: !0,
      col: !0,
      embed: !0,
      hr: !0,
      img: !0,
      input: !0,
      keygen: !0,
      link: !0,
      meta: !0,
      param: !0,
      source: !0,
      track: !0,
      wbr: !0,
    },
  );
  function ds(e, t) {
    if (t) {
      if (hd[e] && (t.children != null || t.dangerouslySetInnerHTML != null))
        throw Error(a(137, e));
      if (t.dangerouslySetInnerHTML != null) {
        if (t.children != null) throw Error(a(60));
        if (
          typeof t.dangerouslySetInnerHTML != "object" ||
          !("__html" in t.dangerouslySetInnerHTML)
        )
          throw Error(a(61));
      }
      if (t.style != null && typeof t.style != "object") throw Error(a(62));
    }
  }
  function fs(e, t) {
    if (e.indexOf("-") === -1) return typeof t.is == "string";
    switch (e) {
      case "annotation-xml":
      case "color-profile":
      case "font-face":
      case "font-face-src":
      case "font-face-uri":
      case "font-face-format":
      case "font-face-name":
      case "missing-glyph":
        return !1;
      default:
        return !0;
    }
  }
  var ps = null;
  function ms(e) {
    return (
      (e = e.target || e.srcElement || window),
      e.correspondingUseElement && (e = e.correspondingUseElement),
      e.nodeType === 3 ? e.parentNode : e
    );
  }
  var hs = null,
    Pn = null,
    _n = null;
  function Mo(e) {
    if ((e = Er(e))) {
      if (typeof hs != "function") throw Error(a(280));
      var t = e.stateNode;
      t && ((t = gl(t)), hs(e.stateNode, e.type, t));
    }
  }
  function Po(e) {
    Pn ? (_n ? _n.push(e) : (_n = [e])) : (Pn = e);
  }
  function _o() {
    if (Pn) {
      var e = Pn,
        t = _n;
      if (((_n = Pn = null), Mo(e), t)) for (e = 0; e < t.length; e++) Mo(t[e]);
    }
  }
  function Lo(e, t) {
    return e(t);
  }
  function To() {}
  var gs = !1;
  function Ao(e, t, n) {
    if (gs) return e(t, n);
    gs = !0;
    try {
      return Lo(e, t, n);
    } finally {
      ((gs = !1), (Pn !== null || _n !== null) && (To(), _o()));
    }
  }
  function or(e, t) {
    var n = e.stateNode;
    if (n === null) return null;
    var r = gl(n);
    if (r === null) return null;
    n = r[t];
    e: switch (t) {
      case "onClick":
      case "onClickCapture":
      case "onDoubleClick":
      case "onDoubleClickCapture":
      case "onMouseDown":
      case "onMouseDownCapture":
      case "onMouseMove":
      case "onMouseMoveCapture":
      case "onMouseUp":
      case "onMouseUpCapture":
      case "onMouseEnter":
        ((r = !r.disabled) ||
          ((e = e.type),
          (r = !(
            e === "button" ||
            e === "input" ||
            e === "select" ||
            e === "textarea"
          ))),
          (e = !r));
        break e;
      default:
        e = !1;
    }
    if (e) return null;
    if (n && typeof n != "function") throw Error(a(231, t, typeof n));
    return n;
  }
  var xs = !1;
  if (E)
    try {
      var ar = {};
      (Object.defineProperty(ar, "passive", {
        get: function () {
          xs = !0;
        },
      }),
        window.addEventListener("test", ar, ar),
        window.removeEventListener("test", ar, ar));
    } catch {
      xs = !1;
    }
  function gd(e, t, n, r, i, o, c, p, h) {
    var k = Array.prototype.slice.call(arguments, 3);
    try {
      t.apply(n, k);
    } catch (b) {
      this.onError(b);
    }
  }
  var ur = !1,
    Kr = null,
    Zr = !1,
    ys = null,
    xd = {
      onError: function (e) {
        ((ur = !0), (Kr = e));
      },
    };
  function yd(e, t, n, r, i, o, c, p, h) {
    ((ur = !1), (Kr = null), gd.apply(xd, arguments));
  }
  function vd(e, t, n, r, i, o, c, p, h) {
    if ((yd.apply(this, arguments), ur)) {
      if (ur) {
        var k = Kr;
        ((ur = !1), (Kr = null));
      } else throw Error(a(198));
      Zr || ((Zr = !0), (ys = k));
    }
  }
  function fn(e) {
    var t = e,
      n = e;
    if (e.alternate) for (; t.return;) t = t.return;
    else {
      e = t;
      do ((t = e), (t.flags & 4098) !== 0 && (n = t.return), (e = t.return));
      while (e);
    }
    return t.tag === 3 ? n : null;
  }
  function Io(e) {
    if (e.tag === 13) {
      var t = e.memoizedState;
      if (
        (t === null && ((e = e.alternate), e !== null && (t = e.memoizedState)),
        t !== null)
      )
        return t.dehydrated;
    }
    return null;
  }
  function Oo(e) {
    if (fn(e) !== e) throw Error(a(188));
  }
  function wd(e) {
    var t = e.alternate;
    if (!t) {
      if (((t = fn(e)), t === null)) throw Error(a(188));
      return t !== e ? null : e;
    }
    for (var n = e, r = t; ;) {
      var i = n.return;
      if (i === null) break;
      var o = i.alternate;
      if (o === null) {
        if (((r = i.return), r !== null)) {
          n = r;
          continue;
        }
        break;
      }
      if (i.child === o.child) {
        for (o = i.child; o;) {
          if (o === n) return (Oo(i), e);
          if (o === r) return (Oo(i), t);
          o = o.sibling;
        }
        throw Error(a(188));
      }
      if (n.return !== r.return) ((n = i), (r = o));
      else {
        for (var c = !1, p = i.child; p;) {
          if (p === n) {
            ((c = !0), (n = i), (r = o));
            break;
          }
          if (p === r) {
            ((c = !0), (r = i), (n = o));
            break;
          }
          p = p.sibling;
        }
        if (!c) {
          for (p = o.child; p;) {
            if (p === n) {
              ((c = !0), (n = o), (r = i));
              break;
            }
            if (p === r) {
              ((c = !0), (r = o), (n = i));
              break;
            }
            p = p.sibling;
          }
          if (!c) throw Error(a(189));
        }
      }
      if (n.alternate !== r) throw Error(a(190));
    }
    if (n.tag !== 3) throw Error(a(188));
    return n.stateNode.current === n ? e : t;
  }
  function Fo(e) {
    return ((e = wd(e)), e !== null ? Do(e) : null);
  }
  function Do(e) {
    if (e.tag === 5 || e.tag === 6) return e;
    for (e = e.child; e !== null;) {
      var t = Do(e);
      if (t !== null) return t;
      e = e.sibling;
    }
    return null;
  }
  var Uo = u.unstable_scheduleCallback,
    $o = u.unstable_cancelCallback,
    kd = u.unstable_shouldYield,
    jd = u.unstable_requestPaint,
    Te = u.unstable_now,
    Sd = u.unstable_getCurrentPriorityLevel,
    vs = u.unstable_ImmediatePriority,
    Wo = u.unstable_UserBlockingPriority,
    Yr = u.unstable_NormalPriority,
    Nd = u.unstable_LowPriority,
    Bo = u.unstable_IdlePriority,
    Xr = null,
    bt = null;
  function Cd(e) {
    if (bt && typeof bt.onCommitFiberRoot == "function")
      try {
        bt.onCommitFiberRoot(Xr, e, void 0, (e.current.flags & 128) === 128);
      } catch {}
  }
  var vt = Math.clz32 ? Math.clz32 : Ed,
    bd = Math.log,
    zd = Math.LN2;
  function Ed(e) {
    return ((e >>>= 0), e === 0 ? 32 : (31 - ((bd(e) / zd) | 0)) | 0);
  }
  var Jr = 64,
    qr = 4194304;
  function cr(e) {
    switch (e & -e) {
      case 1:
        return 1;
      case 2:
        return 2;
      case 4:
        return 4;
      case 8:
        return 8;
      case 16:
        return 16;
      case 32:
        return 32;
      case 64:
      case 128:
      case 256:
      case 512:
      case 1024:
      case 2048:
      case 4096:
      case 8192:
      case 16384:
      case 32768:
      case 65536:
      case 131072:
      case 262144:
      case 524288:
      case 1048576:
      case 2097152:
        return e & 4194240;
      case 4194304:
      case 8388608:
      case 16777216:
      case 33554432:
      case 67108864:
        return e & 130023424;
      case 134217728:
        return 134217728;
      case 268435456:
        return 268435456;
      case 536870912:
        return 536870912;
      case 1073741824:
        return 1073741824;
      default:
        return e;
    }
  }
  function el(e, t) {
    var n = e.pendingLanes;
    if (n === 0) return 0;
    var r = 0,
      i = e.suspendedLanes,
      o = e.pingedLanes,
      c = n & 268435455;
    if (c !== 0) {
      var p = c & ~i;
      p !== 0 ? (r = cr(p)) : ((o &= c), o !== 0 && (r = cr(o)));
    } else ((c = n & ~i), c !== 0 ? (r = cr(c)) : o !== 0 && (r = cr(o)));
    if (r === 0) return 0;
    if (
      t !== 0 &&
      t !== r &&
      (t & i) === 0 &&
      ((i = r & -r), (o = t & -t), i >= o || (i === 16 && (o & 4194240) !== 0))
    )
      return t;
    if (((r & 4) !== 0 && (r |= n & 16), (t = e.entangledLanes), t !== 0))
      for (e = e.entanglements, t &= r; 0 < t;)
        ((n = 31 - vt(t)), (i = 1 << n), (r |= e[n]), (t &= ~i));
    return r;
  }
  function Rd(e, t) {
    switch (e) {
      case 1:
      case 2:
      case 4:
        return t + 250;
      case 8:
      case 16:
      case 32:
      case 64:
      case 128:
      case 256:
      case 512:
      case 1024:
      case 2048:
      case 4096:
      case 8192:
      case 16384:
      case 32768:
      case 65536:
      case 131072:
      case 262144:
      case 524288:
      case 1048576:
      case 2097152:
        return t + 5e3;
      case 4194304:
      case 8388608:
      case 16777216:
      case 33554432:
      case 67108864:
        return -1;
      case 134217728:
      case 268435456:
      case 536870912:
      case 1073741824:
        return -1;
      default:
        return -1;
    }
  }
  function Md(e, t) {
    for (
      var n = e.suspendedLanes,
        r = e.pingedLanes,
        i = e.expirationTimes,
        o = e.pendingLanes;
      0 < o;
    ) {
      var c = 31 - vt(o),
        p = 1 << c,
        h = i[c];
      (h === -1
        ? ((p & n) === 0 || (p & r) !== 0) && (i[c] = Rd(p, t))
        : h <= t && (e.expiredLanes |= p),
        (o &= ~p));
    }
  }
  function ws(e) {
    return (
      (e = e.pendingLanes & -1073741825),
      e !== 0 ? e : e & 1073741824 ? 1073741824 : 0
    );
  }
  function Vo() {
    var e = Jr;
    return ((Jr <<= 1), (Jr & 4194240) === 0 && (Jr = 64), e);
  }
  function ks(e) {
    for (var t = [], n = 0; 31 > n; n++) t.push(e);
    return t;
  }
  function dr(e, t, n) {
    ((e.pendingLanes |= t),
      t !== 536870912 && ((e.suspendedLanes = 0), (e.pingedLanes = 0)),
      (e = e.eventTimes),
      (t = 31 - vt(t)),
      (e[t] = n));
  }
  function Pd(e, t) {
    var n = e.pendingLanes & ~t;
    ((e.pendingLanes = t),
      (e.suspendedLanes = 0),
      (e.pingedLanes = 0),
      (e.expiredLanes &= t),
      (e.mutableReadLanes &= t),
      (e.entangledLanes &= t),
      (t = e.entanglements));
    var r = e.eventTimes;
    for (e = e.expirationTimes; 0 < n;) {
      var i = 31 - vt(n),
        o = 1 << i;
      ((t[i] = 0), (r[i] = -1), (e[i] = -1), (n &= ~o));
    }
  }
  function js(e, t) {
    var n = (e.entangledLanes |= t);
    for (e = e.entanglements; n;) {
      var r = 31 - vt(n),
        i = 1 << r;
      ((i & t) | (e[r] & t) && (e[r] |= t), (n &= ~i));
    }
  }
  var me = 0;
  function Ho(e) {
    return (
      (e &= -e),
      1 < e ? (4 < e ? ((e & 268435455) !== 0 ? 16 : 536870912) : 4) : 1
    );
  }
  var Qo,
    Ss,
    Go,
    Ko,
    Zo,
    Ns = !1,
    tl = [],
    Bt = null,
    Vt = null,
    Ht = null,
    fr = new Map(),
    pr = new Map(),
    Qt = [],
    _d =
      "mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(
        " ",
      );
  function Yo(e, t) {
    switch (e) {
      case "focusin":
      case "focusout":
        Bt = null;
        break;
      case "dragenter":
      case "dragleave":
        Vt = null;
        break;
      case "mouseover":
      case "mouseout":
        Ht = null;
        break;
      case "pointerover":
      case "pointerout":
        fr.delete(t.pointerId);
        break;
      case "gotpointercapture":
      case "lostpointercapture":
        pr.delete(t.pointerId);
    }
  }
  function mr(e, t, n, r, i, o) {
    return e === null || e.nativeEvent !== o
      ? ((e = {
          blockedOn: t,
          domEventName: n,
          eventSystemFlags: r,
          nativeEvent: o,
          targetContainers: [i],
        }),
        t !== null && ((t = Er(t)), t !== null && Ss(t)),
        e)
      : ((e.eventSystemFlags |= r),
        (t = e.targetContainers),
        i !== null && t.indexOf(i) === -1 && t.push(i),
        e);
  }
  function Ld(e, t, n, r, i) {
    switch (t) {
      case "focusin":
        return ((Bt = mr(Bt, e, t, n, r, i)), !0);
      case "dragenter":
        return ((Vt = mr(Vt, e, t, n, r, i)), !0);
      case "mouseover":
        return ((Ht = mr(Ht, e, t, n, r, i)), !0);
      case "pointerover":
        var o = i.pointerId;
        return (fr.set(o, mr(fr.get(o) || null, e, t, n, r, i)), !0);
      case "gotpointercapture":
        return (
          (o = i.pointerId),
          pr.set(o, mr(pr.get(o) || null, e, t, n, r, i)),
          !0
        );
    }
    return !1;
  }
  function Xo(e) {
    var t = pn(e.target);
    if (t !== null) {
      var n = fn(t);
      if (n !== null) {
        if (((t = n.tag), t === 13)) {
          if (((t = Io(n)), t !== null)) {
            ((e.blockedOn = t),
              Zo(e.priority, function () {
                Go(n);
              }));
            return;
          }
        } else if (t === 3 && n.stateNode.current.memoizedState.isDehydrated) {
          e.blockedOn = n.tag === 3 ? n.stateNode.containerInfo : null;
          return;
        }
      }
    }
    e.blockedOn = null;
  }
  function nl(e) {
    if (e.blockedOn !== null) return !1;
    for (var t = e.targetContainers; 0 < t.length;) {
      var n = bs(e.domEventName, e.eventSystemFlags, t[0], e.nativeEvent);
      if (n === null) {
        n = e.nativeEvent;
        var r = new n.constructor(n.type, n);
        ((ps = r), n.target.dispatchEvent(r), (ps = null));
      } else return ((t = Er(n)), t !== null && Ss(t), (e.blockedOn = n), !1);
      t.shift();
    }
    return !0;
  }
  function Jo(e, t, n) {
    nl(e) && n.delete(t);
  }
  function Td() {
    ((Ns = !1),
      Bt !== null && nl(Bt) && (Bt = null),
      Vt !== null && nl(Vt) && (Vt = null),
      Ht !== null && nl(Ht) && (Ht = null),
      fr.forEach(Jo),
      pr.forEach(Jo));
  }
  function hr(e, t) {
    e.blockedOn === t &&
      ((e.blockedOn = null),
      Ns ||
        ((Ns = !0),
        u.unstable_scheduleCallback(u.unstable_NormalPriority, Td)));
  }
  function gr(e) {
    function t(i) {
      return hr(i, e);
    }
    if (0 < tl.length) {
      hr(tl[0], e);
      for (var n = 1; n < tl.length; n++) {
        var r = tl[n];
        r.blockedOn === e && (r.blockedOn = null);
      }
    }
    for (
      Bt !== null && hr(Bt, e),
        Vt !== null && hr(Vt, e),
        Ht !== null && hr(Ht, e),
        fr.forEach(t),
        pr.forEach(t),
        n = 0;
      n < Qt.length;
      n++
    )
      ((r = Qt[n]), r.blockedOn === e && (r.blockedOn = null));
    for (; 0 < Qt.length && ((n = Qt[0]), n.blockedOn === null);)
      (Xo(n), n.blockedOn === null && Qt.shift());
  }
  var Ln = J.ReactCurrentBatchConfig,
    rl = !0;
  function Ad(e, t, n, r) {
    var i = me,
      o = Ln.transition;
    Ln.transition = null;
    try {
      ((me = 1), Cs(e, t, n, r));
    } finally {
      ((me = i), (Ln.transition = o));
    }
  }
  function Id(e, t, n, r) {
    var i = me,
      o = Ln.transition;
    Ln.transition = null;
    try {
      ((me = 4), Cs(e, t, n, r));
    } finally {
      ((me = i), (Ln.transition = o));
    }
  }
  function Cs(e, t, n, r) {
    if (rl) {
      var i = bs(e, t, n, r);
      if (i === null) (Bs(e, t, r, ll, n), Yo(e, r));
      else if (Ld(i, e, t, n, r)) r.stopPropagation();
      else if ((Yo(e, r), t & 4 && -1 < _d.indexOf(e))) {
        for (; i !== null;) {
          var o = Er(i);
          if (
            (o !== null && Qo(o),
            (o = bs(e, t, n, r)),
            o === null && Bs(e, t, r, ll, n),
            o === i)
          )
            break;
          i = o;
        }
        i !== null && r.stopPropagation();
      } else Bs(e, t, r, null, n);
    }
  }
  var ll = null;
  function bs(e, t, n, r) {
    if (((ll = null), (e = ms(r)), (e = pn(e)), e !== null))
      if (((t = fn(e)), t === null)) e = null;
      else if (((n = t.tag), n === 13)) {
        if (((e = Io(t)), e !== null)) return e;
        e = null;
      } else if (n === 3) {
        if (t.stateNode.current.memoizedState.isDehydrated)
          return t.tag === 3 ? t.stateNode.containerInfo : null;
        e = null;
      } else t !== e && (e = null);
    return ((ll = e), null);
  }
  function qo(e) {
    switch (e) {
      case "cancel":
      case "click":
      case "close":
      case "contextmenu":
      case "copy":
      case "cut":
      case "auxclick":
      case "dblclick":
      case "dragend":
      case "dragstart":
      case "drop":
      case "focusin":
      case "focusout":
      case "input":
      case "invalid":
      case "keydown":
      case "keypress":
      case "keyup":
      case "mousedown":
      case "mouseup":
      case "paste":
      case "pause":
      case "play":
      case "pointercancel":
      case "pointerdown":
      case "pointerup":
      case "ratechange":
      case "reset":
      case "resize":
      case "seeked":
      case "submit":
      case "touchcancel":
      case "touchend":
      case "touchstart":
      case "volumechange":
      case "change":
      case "selectionchange":
      case "textInput":
      case "compositionstart":
      case "compositionend":
      case "compositionupdate":
      case "beforeblur":
      case "afterblur":
      case "beforeinput":
      case "blur":
      case "fullscreenchange":
      case "focus":
      case "hashchange":
      case "popstate":
      case "select":
      case "selectstart":
        return 1;
      case "drag":
      case "dragenter":
      case "dragexit":
      case "dragleave":
      case "dragover":
      case "mousemove":
      case "mouseout":
      case "mouseover":
      case "pointermove":
      case "pointerout":
      case "pointerover":
      case "scroll":
      case "toggle":
      case "touchmove":
      case "wheel":
      case "mouseenter":
      case "mouseleave":
      case "pointerenter":
      case "pointerleave":
        return 4;
      case "message":
        switch (Sd()) {
          case vs:
            return 1;
          case Wo:
            return 4;
          case Yr:
          case Nd:
            return 16;
          case Bo:
            return 536870912;
          default:
            return 16;
        }
      default:
        return 16;
    }
  }
  var Gt = null,
    zs = null,
    sl = null;
  function ea() {
    if (sl) return sl;
    var e,
      t = zs,
      n = t.length,
      r,
      i = "value" in Gt ? Gt.value : Gt.textContent,
      o = i.length;
    for (e = 0; e < n && t[e] === i[e]; e++);
    var c = n - e;
    for (r = 1; r <= c && t[n - r] === i[o - r]; r++);
    return (sl = i.slice(e, 1 < r ? 1 - r : void 0));
  }
  function il(e) {
    var t = e.keyCode;
    return (
      "charCode" in e
        ? ((e = e.charCode), e === 0 && t === 13 && (e = 13))
        : (e = t),
      e === 10 && (e = 13),
      32 <= e || e === 13 ? e : 0
    );
  }
  function ol() {
    return !0;
  }
  function ta() {
    return !1;
  }
  function ut(e) {
    function t(n, r, i, o, c) {
      ((this._reactName = n),
        (this._targetInst = i),
        (this.type = r),
        (this.nativeEvent = o),
        (this.target = c),
        (this.currentTarget = null));
      for (var p in e)
        e.hasOwnProperty(p) && ((n = e[p]), (this[p] = n ? n(o) : o[p]));
      return (
        (this.isDefaultPrevented = (
          o.defaultPrevented != null ? o.defaultPrevented : o.returnValue === !1
        )
          ? ol
          : ta),
        (this.isPropagationStopped = ta),
        this
      );
    }
    return (
      A(t.prototype, {
        preventDefault: function () {
          this.defaultPrevented = !0;
          var n = this.nativeEvent;
          n &&
            (n.preventDefault
              ? n.preventDefault()
              : typeof n.returnValue != "unknown" && (n.returnValue = !1),
            (this.isDefaultPrevented = ol));
        },
        stopPropagation: function () {
          var n = this.nativeEvent;
          n &&
            (n.stopPropagation
              ? n.stopPropagation()
              : typeof n.cancelBubble != "unknown" && (n.cancelBubble = !0),
            (this.isPropagationStopped = ol));
        },
        persist: function () {},
        isPersistent: ol,
      }),
      t
    );
  }
  var Tn = {
      eventPhase: 0,
      bubbles: 0,
      cancelable: 0,
      timeStamp: function (e) {
        return e.timeStamp || Date.now();
      },
      defaultPrevented: 0,
      isTrusted: 0,
    },
    Es = ut(Tn),
    xr = A({}, Tn, { view: 0, detail: 0 }),
    Od = ut(xr),
    Rs,
    Ms,
    yr,
    al = A({}, xr, {
      screenX: 0,
      screenY: 0,
      clientX: 0,
      clientY: 0,
      pageX: 0,
      pageY: 0,
      ctrlKey: 0,
      shiftKey: 0,
      altKey: 0,
      metaKey: 0,
      getModifierState: _s,
      button: 0,
      buttons: 0,
      relatedTarget: function (e) {
        return e.relatedTarget === void 0
          ? e.fromElement === e.srcElement
            ? e.toElement
            : e.fromElement
          : e.relatedTarget;
      },
      movementX: function (e) {
        return "movementX" in e
          ? e.movementX
          : (e !== yr &&
              (yr && e.type === "mousemove"
                ? ((Rs = e.screenX - yr.screenX), (Ms = e.screenY - yr.screenY))
                : (Ms = Rs = 0),
              (yr = e)),
            Rs);
      },
      movementY: function (e) {
        return "movementY" in e ? e.movementY : Ms;
      },
    }),
    na = ut(al),
    Fd = A({}, al, { dataTransfer: 0 }),
    Dd = ut(Fd),
    Ud = A({}, xr, { relatedTarget: 0 }),
    Ps = ut(Ud),
    $d = A({}, Tn, { animationName: 0, elapsedTime: 0, pseudoElement: 0 }),
    Wd = ut($d),
    Bd = A({}, Tn, {
      clipboardData: function (e) {
        return "clipboardData" in e ? e.clipboardData : window.clipboardData;
      },
    }),
    Vd = ut(Bd),
    Hd = A({}, Tn, { data: 0 }),
    ra = ut(Hd),
    Qd = {
      Esc: "Escape",
      Spacebar: " ",
      Left: "ArrowLeft",
      Up: "ArrowUp",
      Right: "ArrowRight",
      Down: "ArrowDown",
      Del: "Delete",
      Win: "OS",
      Menu: "ContextMenu",
      Apps: "ContextMenu",
      Scroll: "ScrollLock",
      MozPrintableKey: "Unidentified",
    },
    Gd = {
      8: "Backspace",
      9: "Tab",
      12: "Clear",
      13: "Enter",
      16: "Shift",
      17: "Control",
      18: "Alt",
      19: "Pause",
      20: "CapsLock",
      27: "Escape",
      32: " ",
      33: "PageUp",
      34: "PageDown",
      35: "End",
      36: "Home",
      37: "ArrowLeft",
      38: "ArrowUp",
      39: "ArrowRight",
      40: "ArrowDown",
      45: "Insert",
      46: "Delete",
      112: "F1",
      113: "F2",
      114: "F3",
      115: "F4",
      116: "F5",
      117: "F6",
      118: "F7",
      119: "F8",
      120: "F9",
      121: "F10",
      122: "F11",
      123: "F12",
      144: "NumLock",
      145: "ScrollLock",
      224: "Meta",
    },
    Kd = {
      Alt: "altKey",
      Control: "ctrlKey",
      Meta: "metaKey",
      Shift: "shiftKey",
    };
  function Zd(e) {
    var t = this.nativeEvent;
    return t.getModifierState
      ? t.getModifierState(e)
      : (e = Kd[e])
        ? !!t[e]
        : !1;
  }
  function _s() {
    return Zd;
  }
  var Yd = A({}, xr, {
      key: function (e) {
        if (e.key) {
          var t = Qd[e.key] || e.key;
          if (t !== "Unidentified") return t;
        }
        return e.type === "keypress"
          ? ((e = il(e)), e === 13 ? "Enter" : String.fromCharCode(e))
          : e.type === "keydown" || e.type === "keyup"
            ? Gd[e.keyCode] || "Unidentified"
            : "";
      },
      code: 0,
      location: 0,
      ctrlKey: 0,
      shiftKey: 0,
      altKey: 0,
      metaKey: 0,
      repeat: 0,
      locale: 0,
      getModifierState: _s,
      charCode: function (e) {
        return e.type === "keypress" ? il(e) : 0;
      },
      keyCode: function (e) {
        return e.type === "keydown" || e.type === "keyup" ? e.keyCode : 0;
      },
      which: function (e) {
        return e.type === "keypress"
          ? il(e)
          : e.type === "keydown" || e.type === "keyup"
            ? e.keyCode
            : 0;
      },
    }),
    Xd = ut(Yd),
    Jd = A({}, al, {
      pointerId: 0,
      width: 0,
      height: 0,
      pressure: 0,
      tangentialPressure: 0,
      tiltX: 0,
      tiltY: 0,
      twist: 0,
      pointerType: 0,
      isPrimary: 0,
    }),
    la = ut(Jd),
    qd = A({}, xr, {
      touches: 0,
      targetTouches: 0,
      changedTouches: 0,
      altKey: 0,
      metaKey: 0,
      ctrlKey: 0,
      shiftKey: 0,
      getModifierState: _s,
    }),
    ef = ut(qd),
    tf = A({}, Tn, { propertyName: 0, elapsedTime: 0, pseudoElement: 0 }),
    nf = ut(tf),
    rf = A({}, al, {
      deltaX: function (e) {
        return "deltaX" in e
          ? e.deltaX
          : "wheelDeltaX" in e
            ? -e.wheelDeltaX
            : 0;
      },
      deltaY: function (e) {
        return "deltaY" in e
          ? e.deltaY
          : "wheelDeltaY" in e
            ? -e.wheelDeltaY
            : "wheelDelta" in e
              ? -e.wheelDelta
              : 0;
      },
      deltaZ: 0,
      deltaMode: 0,
    }),
    lf = ut(rf),
    sf = [9, 13, 27, 32],
    Ls = E && "CompositionEvent" in window,
    vr = null;
  E && "documentMode" in document && (vr = document.documentMode);
  var of = E && "TextEvent" in window && !vr,
    sa = E && (!Ls || (vr && 8 < vr && 11 >= vr)),
    ia = " ",
    oa = !1;
  function aa(e, t) {
    switch (e) {
      case "keyup":
        return sf.indexOf(t.keyCode) !== -1;
      case "keydown":
        return t.keyCode !== 229;
      case "keypress":
      case "mousedown":
      case "focusout":
        return !0;
      default:
        return !1;
    }
  }
  function ua(e) {
    return (
      (e = e.detail),
      typeof e == "object" && "data" in e ? e.data : null
    );
  }
  var An = !1;
  function af(e, t) {
    switch (e) {
      case "compositionend":
        return ua(t);
      case "keypress":
        return t.which !== 32 ? null : ((oa = !0), ia);
      case "textInput":
        return ((e = t.data), e === ia && oa ? null : e);
      default:
        return null;
    }
  }
  function uf(e, t) {
    if (An)
      return e === "compositionend" || (!Ls && aa(e, t))
        ? ((e = ea()), (sl = zs = Gt = null), (An = !1), e)
        : null;
    switch (e) {
      case "paste":
        return null;
      case "keypress":
        if (!(t.ctrlKey || t.altKey || t.metaKey) || (t.ctrlKey && t.altKey)) {
          if (t.char && 1 < t.char.length) return t.char;
          if (t.which) return String.fromCharCode(t.which);
        }
        return null;
      case "compositionend":
        return sa && t.locale !== "ko" ? null : t.data;
      default:
        return null;
    }
  }
  var cf = {
    color: !0,
    date: !0,
    datetime: !0,
    "datetime-local": !0,
    email: !0,
    month: !0,
    number: !0,
    password: !0,
    range: !0,
    search: !0,
    tel: !0,
    text: !0,
    time: !0,
    url: !0,
    week: !0,
  };
  function ca(e) {
    var t = e && e.nodeName && e.nodeName.toLowerCase();
    return t === "input" ? !!cf[e.type] : t === "textarea";
  }
  function da(e, t, n, r) {
    (Po(r),
      (t = pl(t, "onChange")),
      0 < t.length &&
        ((n = new Es("onChange", "change", null, n, r)),
        e.push({ event: n, listeners: t })));
  }
  var wr = null,
    kr = null;
  function df(e) {
    Ra(e, 0);
  }
  function ul(e) {
    var t = Un(e);
    if (nr(t)) return e;
  }
  function ff(e, t) {
    if (e === "change") return t;
  }
  var fa = !1;
  if (E) {
    var Ts;
    if (E) {
      var As = "oninput" in document;
      if (!As) {
        var pa = document.createElement("div");
        (pa.setAttribute("oninput", "return;"),
          (As = typeof pa.oninput == "function"));
      }
      Ts = As;
    } else Ts = !1;
    fa = Ts && (!document.documentMode || 9 < document.documentMode);
  }
  function ma() {
    wr && (wr.detachEvent("onpropertychange", ha), (kr = wr = null));
  }
  function ha(e) {
    if (e.propertyName === "value" && ul(kr)) {
      var t = [];
      (da(t, kr, e, ms(e)), Ao(df, t));
    }
  }
  function pf(e, t, n) {
    e === "focusin"
      ? (ma(), (wr = t), (kr = n), wr.attachEvent("onpropertychange", ha))
      : e === "focusout" && ma();
  }
  function mf(e) {
    if (e === "selectionchange" || e === "keyup" || e === "keydown")
      return ul(kr);
  }
  function hf(e, t) {
    if (e === "click") return ul(t);
  }
  function gf(e, t) {
    if (e === "input" || e === "change") return ul(t);
  }
  function xf(e, t) {
    return (e === t && (e !== 0 || 1 / e === 1 / t)) || (e !== e && t !== t);
  }
  var wt = typeof Object.is == "function" ? Object.is : xf;
  function jr(e, t) {
    if (wt(e, t)) return !0;
    if (
      typeof e != "object" ||
      e === null ||
      typeof t != "object" ||
      t === null
    )
      return !1;
    var n = Object.keys(e),
      r = Object.keys(t);
    if (n.length !== r.length) return !1;
    for (r = 0; r < n.length; r++) {
      var i = n[r];
      if (!j.call(t, i) || !wt(e[i], t[i])) return !1;
    }
    return !0;
  }
  function ga(e) {
    for (; e && e.firstChild;) e = e.firstChild;
    return e;
  }
  function xa(e, t) {
    var n = ga(e);
    e = 0;
    for (var r; n;) {
      if (n.nodeType === 3) {
        if (((r = e + n.textContent.length), e <= t && r >= t))
          return { node: n, offset: t - e };
        e = r;
      }
      e: {
        for (; n;) {
          if (n.nextSibling) {
            n = n.nextSibling;
            break e;
          }
          n = n.parentNode;
        }
        n = void 0;
      }
      n = ga(n);
    }
  }
  function ya(e, t) {
    return e && t
      ? e === t
        ? !0
        : e && e.nodeType === 3
          ? !1
          : t && t.nodeType === 3
            ? ya(e, t.parentNode)
            : "contains" in e
              ? e.contains(t)
              : e.compareDocumentPosition
                ? !!(e.compareDocumentPosition(t) & 16)
                : !1
      : !1;
  }
  function va() {
    for (var e = window, t = Rn(); t instanceof e.HTMLIFrameElement;) {
      try {
        var n = typeof t.contentWindow.location.href == "string";
      } catch {
        n = !1;
      }
      if (n) e = t.contentWindow;
      else break;
      t = Rn(e.document);
    }
    return t;
  }
  function Is(e) {
    var t = e && e.nodeName && e.nodeName.toLowerCase();
    return (
      t &&
      ((t === "input" &&
        (e.type === "text" ||
          e.type === "search" ||
          e.type === "tel" ||
          e.type === "url" ||
          e.type === "password")) ||
        t === "textarea" ||
        e.contentEditable === "true")
    );
  }
  function yf(e) {
    var t = va(),
      n = e.focusedElem,
      r = e.selectionRange;
    if (
      t !== n &&
      n &&
      n.ownerDocument &&
      ya(n.ownerDocument.documentElement, n)
    ) {
      if (r !== null && Is(n)) {
        if (
          ((t = r.start),
          (e = r.end),
          e === void 0 && (e = t),
          "selectionStart" in n)
        )
          ((n.selectionStart = t),
            (n.selectionEnd = Math.min(e, n.value.length)));
        else if (
          ((e = ((t = n.ownerDocument || document) && t.defaultView) || window),
          e.getSelection)
        ) {
          e = e.getSelection();
          var i = n.textContent.length,
            o = Math.min(r.start, i);
          ((r = r.end === void 0 ? o : Math.min(r.end, i)),
            !e.extend && o > r && ((i = r), (r = o), (o = i)),
            (i = xa(n, o)));
          var c = xa(n, r);
          i &&
            c &&
            (e.rangeCount !== 1 ||
              e.anchorNode !== i.node ||
              e.anchorOffset !== i.offset ||
              e.focusNode !== c.node ||
              e.focusOffset !== c.offset) &&
            ((t = t.createRange()),
            t.setStart(i.node, i.offset),
            e.removeAllRanges(),
            o > r
              ? (e.addRange(t), e.extend(c.node, c.offset))
              : (t.setEnd(c.node, c.offset), e.addRange(t)));
        }
      }
      for (t = [], e = n; (e = e.parentNode);)
        e.nodeType === 1 &&
          t.push({ element: e, left: e.scrollLeft, top: e.scrollTop });
      for (typeof n.focus == "function" && n.focus(), n = 0; n < t.length; n++)
        ((e = t[n]),
          (e.element.scrollLeft = e.left),
          (e.element.scrollTop = e.top));
    }
  }
  var vf = E && "documentMode" in document && 11 >= document.documentMode,
    In = null,
    Os = null,
    Sr = null,
    Fs = !1;
  function wa(e, t, n) {
    var r =
      n.window === n ? n.document : n.nodeType === 9 ? n : n.ownerDocument;
    Fs ||
      In == null ||
      In !== Rn(r) ||
      ((r = In),
      "selectionStart" in r && Is(r)
        ? (r = { start: r.selectionStart, end: r.selectionEnd })
        : ((r = (
            (r.ownerDocument && r.ownerDocument.defaultView) ||
            window
          ).getSelection()),
          (r = {
            anchorNode: r.anchorNode,
            anchorOffset: r.anchorOffset,
            focusNode: r.focusNode,
            focusOffset: r.focusOffset,
          })),
      (Sr && jr(Sr, r)) ||
        ((Sr = r),
        (r = pl(Os, "onSelect")),
        0 < r.length &&
          ((t = new Es("onSelect", "select", null, t, n)),
          e.push({ event: t, listeners: r }),
          (t.target = In))));
  }
  function cl(e, t) {
    var n = {};
    return (
      (n[e.toLowerCase()] = t.toLowerCase()),
      (n["Webkit" + e] = "webkit" + t),
      (n["Moz" + e] = "moz" + t),
      n
    );
  }
  var On = {
      animationend: cl("Animation", "AnimationEnd"),
      animationiteration: cl("Animation", "AnimationIteration"),
      animationstart: cl("Animation", "AnimationStart"),
      transitionend: cl("Transition", "TransitionEnd"),
    },
    Ds = {},
    ka = {};
  E &&
    ((ka = document.createElement("div").style),
    "AnimationEvent" in window ||
      (delete On.animationend.animation,
      delete On.animationiteration.animation,
      delete On.animationstart.animation),
    "TransitionEvent" in window || delete On.transitionend.transition);
  function dl(e) {
    if (Ds[e]) return Ds[e];
    if (!On[e]) return e;
    var t = On[e],
      n;
    for (n in t) if (t.hasOwnProperty(n) && n in ka) return (Ds[e] = t[n]);
    return e;
  }
  var ja = dl("animationend"),
    Sa = dl("animationiteration"),
    Na = dl("animationstart"),
    Ca = dl("transitionend"),
    ba = new Map(),
    za =
      "abort auxClick cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(
        " ",
      );
  function Kt(e, t) {
    (ba.set(e, t), m(t, [e]));
  }
  for (var Us = 0; Us < za.length; Us++) {
    var $s = za[Us],
      wf = $s.toLowerCase(),
      kf = $s[0].toUpperCase() + $s.slice(1);
    Kt(wf, "on" + kf);
  }
  (Kt(ja, "onAnimationEnd"),
    Kt(Sa, "onAnimationIteration"),
    Kt(Na, "onAnimationStart"),
    Kt("dblclick", "onDoubleClick"),
    Kt("focusin", "onFocus"),
    Kt("focusout", "onBlur"),
    Kt(Ca, "onTransitionEnd"),
    v("onMouseEnter", ["mouseout", "mouseover"]),
    v("onMouseLeave", ["mouseout", "mouseover"]),
    v("onPointerEnter", ["pointerout", "pointerover"]),
    v("onPointerLeave", ["pointerout", "pointerover"]),
    m(
      "onChange",
      "change click focusin focusout input keydown keyup selectionchange".split(
        " ",
      ),
    ),
    m(
      "onSelect",
      "focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(
        " ",
      ),
    ),
    m("onBeforeInput", ["compositionend", "keypress", "textInput", "paste"]),
    m(
      "onCompositionEnd",
      "compositionend focusout keydown keypress keyup mousedown".split(" "),
    ),
    m(
      "onCompositionStart",
      "compositionstart focusout keydown keypress keyup mousedown".split(" "),
    ),
    m(
      "onCompositionUpdate",
      "compositionupdate focusout keydown keypress keyup mousedown".split(" "),
    ));
  var Nr =
      "abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(
        " ",
      ),
    jf = new Set(
      "cancel close invalid load scroll toggle".split(" ").concat(Nr),
    );
  function Ea(e, t, n) {
    var r = e.type || "unknown-event";
    ((e.currentTarget = n), vd(r, t, void 0, e), (e.currentTarget = null));
  }
  function Ra(e, t) {
    t = (t & 4) !== 0;
    for (var n = 0; n < e.length; n++) {
      var r = e[n],
        i = r.event;
      r = r.listeners;
      e: {
        var o = void 0;
        if (t)
          for (var c = r.length - 1; 0 <= c; c--) {
            var p = r[c],
              h = p.instance,
              k = p.currentTarget;
            if (((p = p.listener), h !== o && i.isPropagationStopped()))
              break e;
            (Ea(i, p, k), (o = h));
          }
        else
          for (c = 0; c < r.length; c++) {
            if (
              ((p = r[c]),
              (h = p.instance),
              (k = p.currentTarget),
              (p = p.listener),
              h !== o && i.isPropagationStopped())
            )
              break e;
            (Ea(i, p, k), (o = h));
          }
      }
    }
    if (Zr) throw ((e = ys), (Zr = !1), (ys = null), e);
  }
  function Se(e, t) {
    var n = t[Zs];
    n === void 0 && (n = t[Zs] = new Set());
    var r = e + "__bubble";
    n.has(r) || (Ma(t, e, 2, !1), n.add(r));
  }
  function Ws(e, t, n) {
    var r = 0;
    (t && (r |= 4), Ma(n, e, r, t));
  }
  var fl = "_reactListening" + Math.random().toString(36).slice(2);
  function Cr(e) {
    if (!e[fl]) {
      ((e[fl] = !0),
        d.forEach(function (n) {
          n !== "selectionchange" && (jf.has(n) || Ws(n, !1, e), Ws(n, !0, e));
        }));
      var t = e.nodeType === 9 ? e : e.ownerDocument;
      t === null || t[fl] || ((t[fl] = !0), Ws("selectionchange", !1, t));
    }
  }
  function Ma(e, t, n, r) {
    switch (qo(t)) {
      case 1:
        var i = Ad;
        break;
      case 4:
        i = Id;
        break;
      default:
        i = Cs;
    }
    ((n = i.bind(null, t, n, e)),
      (i = void 0),
      !xs ||
        (t !== "touchstart" && t !== "touchmove" && t !== "wheel") ||
        (i = !0),
      r
        ? i !== void 0
          ? e.addEventListener(t, n, { capture: !0, passive: i })
          : e.addEventListener(t, n, !0)
        : i !== void 0
          ? e.addEventListener(t, n, { passive: i })
          : e.addEventListener(t, n, !1));
  }
  function Bs(e, t, n, r, i) {
    var o = r;
    if ((t & 1) === 0 && (t & 2) === 0 && r !== null)
      e: for (;;) {
        if (r === null) return;
        var c = r.tag;
        if (c === 3 || c === 4) {
          var p = r.stateNode.containerInfo;
          if (p === i || (p.nodeType === 8 && p.parentNode === i)) break;
          if (c === 4)
            for (c = r.return; c !== null;) {
              var h = c.tag;
              if (
                (h === 3 || h === 4) &&
                ((h = c.stateNode.containerInfo),
                h === i || (h.nodeType === 8 && h.parentNode === i))
              )
                return;
              c = c.return;
            }
          for (; p !== null;) {
            if (((c = pn(p)), c === null)) return;
            if (((h = c.tag), h === 5 || h === 6)) {
              r = o = c;
              continue e;
            }
            p = p.parentNode;
          }
        }
        r = r.return;
      }
    Ao(function () {
      var k = o,
        b = ms(n),
        z = [];
      e: {
        var C = ba.get(e);
        if (C !== void 0) {
          var T = Es,
            O = e;
          switch (e) {
            case "keypress":
              if (il(n) === 0) break e;
            case "keydown":
            case "keyup":
              T = Xd;
              break;
            case "focusin":
              ((O = "focus"), (T = Ps));
              break;
            case "focusout":
              ((O = "blur"), (T = Ps));
              break;
            case "beforeblur":
            case "afterblur":
              T = Ps;
              break;
            case "click":
              if (n.button === 2) break e;
            case "auxclick":
            case "dblclick":
            case "mousedown":
            case "mousemove":
            case "mouseup":
            case "mouseout":
            case "mouseover":
            case "contextmenu":
              T = na;
              break;
            case "drag":
            case "dragend":
            case "dragenter":
            case "dragexit":
            case "dragleave":
            case "dragover":
            case "dragstart":
            case "drop":
              T = Dd;
              break;
            case "touchcancel":
            case "touchend":
            case "touchmove":
            case "touchstart":
              T = ef;
              break;
            case ja:
            case Sa:
            case Na:
              T = Wd;
              break;
            case Ca:
              T = nf;
              break;
            case "scroll":
              T = Od;
              break;
            case "wheel":
              T = lf;
              break;
            case "copy":
            case "cut":
            case "paste":
              T = Vd;
              break;
            case "gotpointercapture":
            case "lostpointercapture":
            case "pointercancel":
            case "pointerdown":
            case "pointermove":
            case "pointerout":
            case "pointerover":
            case "pointerup":
              T = la;
          }
          var F = (t & 4) !== 0,
            Ae = !F && e === "scroll",
            y = F ? (C !== null ? C + "Capture" : null) : C;
          F = [];
          for (var g = k, w; g !== null;) {
            w = g;
            var M = w.stateNode;
            if (
              (w.tag === 5 &&
                M !== null &&
                ((w = M),
                y !== null &&
                  ((M = or(g, y)), M != null && F.push(br(g, M, w)))),
              Ae)
            )
              break;
            g = g.return;
          }
          0 < F.length &&
            ((C = new T(C, O, null, n, b)), z.push({ event: C, listeners: F }));
        }
      }
      if ((t & 7) === 0) {
        e: {
          if (
            ((C = e === "mouseover" || e === "pointerover"),
            (T = e === "mouseout" || e === "pointerout"),
            C &&
              n !== ps &&
              (O = n.relatedTarget || n.fromElement) &&
              (pn(O) || O[Pt]))
          )
            break e;
          if (
            (T || C) &&
            ((C =
              b.window === b
                ? b
                : (C = b.ownerDocument)
                  ? C.defaultView || C.parentWindow
                  : window),
            T
              ? ((O = n.relatedTarget || n.toElement),
                (T = k),
                (O = O ? pn(O) : null),
                O !== null &&
                  ((Ae = fn(O)), O !== Ae || (O.tag !== 5 && O.tag !== 6)) &&
                  (O = null))
              : ((T = null), (O = k)),
            T !== O)
          ) {
            if (
              ((F = na),
              (M = "onMouseLeave"),
              (y = "onMouseEnter"),
              (g = "mouse"),
              (e === "pointerout" || e === "pointerover") &&
                ((F = la),
                (M = "onPointerLeave"),
                (y = "onPointerEnter"),
                (g = "pointer")),
              (Ae = T == null ? C : Un(T)),
              (w = O == null ? C : Un(O)),
              (C = new F(M, g + "leave", T, n, b)),
              (C.target = Ae),
              (C.relatedTarget = w),
              (M = null),
              pn(b) === k &&
                ((F = new F(y, g + "enter", O, n, b)),
                (F.target = w),
                (F.relatedTarget = Ae),
                (M = F)),
              (Ae = M),
              T && O)
            )
              t: {
                for (F = T, y = O, g = 0, w = F; w; w = Fn(w)) g++;
                for (w = 0, M = y; M; M = Fn(M)) w++;
                for (; 0 < g - w;) ((F = Fn(F)), g--);
                for (; 0 < w - g;) ((y = Fn(y)), w--);
                for (; g--;) {
                  if (F === y || (y !== null && F === y.alternate)) break t;
                  ((F = Fn(F)), (y = Fn(y)));
                }
                F = null;
              }
            else F = null;
            (T !== null && Pa(z, C, T, F, !1),
              O !== null && Ae !== null && Pa(z, Ae, O, F, !0));
          }
        }
        e: {
          if (
            ((C = k ? Un(k) : window),
            (T = C.nodeName && C.nodeName.toLowerCase()),
            T === "select" || (T === "input" && C.type === "file"))
          )
            var D = ff;
          else if (ca(C))
            if (fa) D = gf;
            else {
              D = mf;
              var V = pf;
            }
          else
            (T = C.nodeName) &&
              T.toLowerCase() === "input" &&
              (C.type === "checkbox" || C.type === "radio") &&
              (D = hf);
          if (D && (D = D(e, k))) {
            da(z, D, n, b);
            break e;
          }
          (V && V(e, C, k),
            e === "focusout" &&
              (V = C._wrapperState) &&
              V.controlled &&
              C.type === "number" &&
              Ze(C, "number", C.value));
        }
        switch (((V = k ? Un(k) : window), e)) {
          case "focusin":
            (ca(V) || V.contentEditable === "true") &&
              ((In = V), (Os = k), (Sr = null));
            break;
          case "focusout":
            Sr = Os = In = null;
            break;
          case "mousedown":
            Fs = !0;
            break;
          case "contextmenu":
          case "mouseup":
          case "dragend":
            ((Fs = !1), wa(z, n, b));
            break;
          case "selectionchange":
            if (vf) break;
          case "keydown":
          case "keyup":
            wa(z, n, b);
        }
        var H;
        if (Ls)
          e: {
            switch (e) {
              case "compositionstart":
                var Q = "onCompositionStart";
                break e;
              case "compositionend":
                Q = "onCompositionEnd";
                break e;
              case "compositionupdate":
                Q = "onCompositionUpdate";
                break e;
            }
            Q = void 0;
          }
        else
          An
            ? aa(e, n) && (Q = "onCompositionEnd")
            : e === "keydown" &&
              n.keyCode === 229 &&
              (Q = "onCompositionStart");
        (Q &&
          (sa &&
            n.locale !== "ko" &&
            (An || Q !== "onCompositionStart"
              ? Q === "onCompositionEnd" && An && (H = ea())
              : ((Gt = b),
                (zs = "value" in Gt ? Gt.value : Gt.textContent),
                (An = !0))),
          (V = pl(k, Q)),
          0 < V.length &&
            ((Q = new ra(Q, e, null, n, b)),
            z.push({ event: Q, listeners: V }),
            H ? (Q.data = H) : ((H = ua(n)), H !== null && (Q.data = H)))),
          (H = of ? af(e, n) : uf(e, n)) &&
            ((k = pl(k, "onBeforeInput")),
            0 < k.length &&
              ((b = new ra("onBeforeInput", "beforeinput", null, n, b)),
              z.push({ event: b, listeners: k }),
              (b.data = H))));
      }
      Ra(z, t);
    });
  }
  function br(e, t, n) {
    return { instance: e, listener: t, currentTarget: n };
  }
  function pl(e, t) {
    for (var n = t + "Capture", r = []; e !== null;) {
      var i = e,
        o = i.stateNode;
      (i.tag === 5 &&
        o !== null &&
        ((i = o),
        (o = or(e, n)),
        o != null && r.unshift(br(e, o, i)),
        (o = or(e, t)),
        o != null && r.push(br(e, o, i))),
        (e = e.return));
    }
    return r;
  }
  function Fn(e) {
    if (e === null) return null;
    do e = e.return;
    while (e && e.tag !== 5);
    return e || null;
  }
  function Pa(e, t, n, r, i) {
    for (var o = t._reactName, c = []; n !== null && n !== r;) {
      var p = n,
        h = p.alternate,
        k = p.stateNode;
      if (h !== null && h === r) break;
      (p.tag === 5 &&
        k !== null &&
        ((p = k),
        i
          ? ((h = or(n, o)), h != null && c.unshift(br(n, h, p)))
          : i || ((h = or(n, o)), h != null && c.push(br(n, h, p)))),
        (n = n.return));
    }
    c.length !== 0 && e.push({ event: t, listeners: c });
  }
  var Sf = /\r\n?/g,
    Nf = /\u0000|\uFFFD/g;
  function _a(e) {
    return (typeof e == "string" ? e : "" + e)
      .replace(
        Sf,
        `
`,
      )
      .replace(Nf, "");
  }
  function ml(e, t, n) {
    if (((t = _a(t)), _a(e) !== t && n)) throw Error(a(425));
  }
  function hl() {}
  var Vs = null,
    Hs = null;
  function Qs(e, t) {
    return (
      e === "textarea" ||
      e === "noscript" ||
      typeof t.children == "string" ||
      typeof t.children == "number" ||
      (typeof t.dangerouslySetInnerHTML == "object" &&
        t.dangerouslySetInnerHTML !== null &&
        t.dangerouslySetInnerHTML.__html != null)
    );
  }
  var Gs = typeof setTimeout == "function" ? setTimeout : void 0,
    Cf = typeof clearTimeout == "function" ? clearTimeout : void 0,
    La = typeof Promise == "function" ? Promise : void 0,
    bf =
      typeof queueMicrotask == "function"
        ? queueMicrotask
        : typeof La < "u"
          ? function (e) {
              return La.resolve(null).then(e).catch(zf);
            }
          : Gs;
  function zf(e) {
    setTimeout(function () {
      throw e;
    });
  }
  function Ks(e, t) {
    var n = t,
      r = 0;
    do {
      var i = n.nextSibling;
      if ((e.removeChild(n), i && i.nodeType === 8))
        if (((n = i.data), n === "/$")) {
          if (r === 0) {
            (e.removeChild(i), gr(t));
            return;
          }
          r--;
        } else (n !== "$" && n !== "$?" && n !== "$!") || r++;
      n = i;
    } while (n);
    gr(t);
  }
  function Zt(e) {
    for (; e != null; e = e.nextSibling) {
      var t = e.nodeType;
      if (t === 1 || t === 3) break;
      if (t === 8) {
        if (((t = e.data), t === "$" || t === "$!" || t === "$?")) break;
        if (t === "/$") return null;
      }
    }
    return e;
  }
  function Ta(e) {
    e = e.previousSibling;
    for (var t = 0; e;) {
      if (e.nodeType === 8) {
        var n = e.data;
        if (n === "$" || n === "$!" || n === "$?") {
          if (t === 0) return e;
          t--;
        } else n === "/$" && t++;
      }
      e = e.previousSibling;
    }
    return null;
  }
  var Dn = Math.random().toString(36).slice(2),
    zt = "__reactFiber$" + Dn,
    zr = "__reactProps$" + Dn,
    Pt = "__reactContainer$" + Dn,
    Zs = "__reactEvents$" + Dn,
    Ef = "__reactListeners$" + Dn,
    Rf = "__reactHandles$" + Dn;
  function pn(e) {
    var t = e[zt];
    if (t) return t;
    for (var n = e.parentNode; n;) {
      if ((t = n[Pt] || n[zt])) {
        if (
          ((n = t.alternate),
          t.child !== null || (n !== null && n.child !== null))
        )
          for (e = Ta(e); e !== null;) {
            if ((n = e[zt])) return n;
            e = Ta(e);
          }
        return t;
      }
      ((e = n), (n = e.parentNode));
    }
    return null;
  }
  function Er(e) {
    return (
      (e = e[zt] || e[Pt]),
      !e || (e.tag !== 5 && e.tag !== 6 && e.tag !== 13 && e.tag !== 3)
        ? null
        : e
    );
  }
  function Un(e) {
    if (e.tag === 5 || e.tag === 6) return e.stateNode;
    throw Error(a(33));
  }
  function gl(e) {
    return e[zr] || null;
  }
  var Ys = [],
    $n = -1;
  function Yt(e) {
    return { current: e };
  }
  function Ne(e) {
    0 > $n || ((e.current = Ys[$n]), (Ys[$n] = null), $n--);
  }
  function je(e, t) {
    ($n++, (Ys[$n] = e.current), (e.current = t));
  }
  var Xt = {},
    Ye = Yt(Xt),
    rt = Yt(!1),
    mn = Xt;
  function Wn(e, t) {
    var n = e.type.contextTypes;
    if (!n) return Xt;
    var r = e.stateNode;
    if (r && r.__reactInternalMemoizedUnmaskedChildContext === t)
      return r.__reactInternalMemoizedMaskedChildContext;
    var i = {},
      o;
    for (o in n) i[o] = t[o];
    return (
      r &&
        ((e = e.stateNode),
        (e.__reactInternalMemoizedUnmaskedChildContext = t),
        (e.__reactInternalMemoizedMaskedChildContext = i)),
      i
    );
  }
  function lt(e) {
    return ((e = e.childContextTypes), e != null);
  }
  function xl() {
    (Ne(rt), Ne(Ye));
  }
  function Aa(e, t, n) {
    if (Ye.current !== Xt) throw Error(a(168));
    (je(Ye, t), je(rt, n));
  }
  function Ia(e, t, n) {
    var r = e.stateNode;
    if (((t = t.childContextTypes), typeof r.getChildContext != "function"))
      return n;
    r = r.getChildContext();
    for (var i in r) if (!(i in t)) throw Error(a(108, ge(e) || "Unknown", i));
    return A({}, n, r);
  }
  function yl(e) {
    return (
      (e =
        ((e = e.stateNode) && e.__reactInternalMemoizedMergedChildContext) ||
        Xt),
      (mn = Ye.current),
      je(Ye, e),
      je(rt, rt.current),
      !0
    );
  }
  function Oa(e, t, n) {
    var r = e.stateNode;
    if (!r) throw Error(a(169));
    (n
      ? ((e = Ia(e, t, mn)),
        (r.__reactInternalMemoizedMergedChildContext = e),
        Ne(rt),
        Ne(Ye),
        je(Ye, e))
      : Ne(rt),
      je(rt, n));
  }
  var _t = null,
    vl = !1,
    Xs = !1;
  function Fa(e) {
    _t === null ? (_t = [e]) : _t.push(e);
  }
  function Mf(e) {
    ((vl = !0), Fa(e));
  }
  function Jt() {
    if (!Xs && _t !== null) {
      Xs = !0;
      var e = 0,
        t = me;
      try {
        var n = _t;
        for (me = 1; e < n.length; e++) {
          var r = n[e];
          do r = r(!0);
          while (r !== null);
        }
        ((_t = null), (vl = !1));
      } catch (i) {
        throw (_t !== null && (_t = _t.slice(e + 1)), Uo(vs, Jt), i);
      } finally {
        ((me = t), (Xs = !1));
      }
    }
    return null;
  }
  var Bn = [],
    Vn = 0,
    wl = null,
    kl = 0,
    pt = [],
    mt = 0,
    hn = null,
    Lt = 1,
    Tt = "";
  function gn(e, t) {
    ((Bn[Vn++] = kl), (Bn[Vn++] = wl), (wl = e), (kl = t));
  }
  function Da(e, t, n) {
    ((pt[mt++] = Lt), (pt[mt++] = Tt), (pt[mt++] = hn), (hn = e));
    var r = Lt;
    e = Tt;
    var i = 32 - vt(r) - 1;
    ((r &= ~(1 << i)), (n += 1));
    var o = 32 - vt(t) + i;
    if (30 < o) {
      var c = i - (i % 5);
      ((o = (r & ((1 << c) - 1)).toString(32)),
        (r >>= c),
        (i -= c),
        (Lt = (1 << (32 - vt(t) + i)) | (n << i) | r),
        (Tt = o + e));
    } else ((Lt = (1 << o) | (n << i) | r), (Tt = e));
  }
  function Js(e) {
    e.return !== null && (gn(e, 1), Da(e, 1, 0));
  }
  function qs(e) {
    for (; e === wl;)
      ((wl = Bn[--Vn]), (Bn[Vn] = null), (kl = Bn[--Vn]), (Bn[Vn] = null));
    for (; e === hn;)
      ((hn = pt[--mt]),
        (pt[mt] = null),
        (Tt = pt[--mt]),
        (pt[mt] = null),
        (Lt = pt[--mt]),
        (pt[mt] = null));
  }
  var ct = null,
    dt = null,
    be = !1,
    kt = null;
  function Ua(e, t) {
    var n = yt(5, null, null, 0);
    ((n.elementType = "DELETED"),
      (n.stateNode = t),
      (n.return = e),
      (t = e.deletions),
      t === null ? ((e.deletions = [n]), (e.flags |= 16)) : t.push(n));
  }
  function $a(e, t) {
    switch (e.tag) {
      case 5:
        var n = e.type;
        return (
          (t =
            t.nodeType !== 1 || n.toLowerCase() !== t.nodeName.toLowerCase()
              ? null
              : t),
          t !== null
            ? ((e.stateNode = t), (ct = e), (dt = Zt(t.firstChild)), !0)
            : !1
        );
      case 6:
        return (
          (t = e.pendingProps === "" || t.nodeType !== 3 ? null : t),
          t !== null ? ((e.stateNode = t), (ct = e), (dt = null), !0) : !1
        );
      case 13:
        return (
          (t = t.nodeType !== 8 ? null : t),
          t !== null
            ? ((n = hn !== null ? { id: Lt, overflow: Tt } : null),
              (e.memoizedState = {
                dehydrated: t,
                treeContext: n,
                retryLane: 1073741824,
              }),
              (n = yt(18, null, null, 0)),
              (n.stateNode = t),
              (n.return = e),
              (e.child = n),
              (ct = e),
              (dt = null),
              !0)
            : !1
        );
      default:
        return !1;
    }
  }
  function ei(e) {
    return (e.mode & 1) !== 0 && (e.flags & 128) === 0;
  }
  function ti(e) {
    if (be) {
      var t = dt;
      if (t) {
        var n = t;
        if (!$a(e, t)) {
          if (ei(e)) throw Error(a(418));
          t = Zt(n.nextSibling);
          var r = ct;
          t && $a(e, t)
            ? Ua(r, n)
            : ((e.flags = (e.flags & -4097) | 2), (be = !1), (ct = e));
        }
      } else {
        if (ei(e)) throw Error(a(418));
        ((e.flags = (e.flags & -4097) | 2), (be = !1), (ct = e));
      }
    }
  }
  function Wa(e) {
    for (
      e = e.return;
      e !== null && e.tag !== 5 && e.tag !== 3 && e.tag !== 13;
    )
      e = e.return;
    ct = e;
  }
  function jl(e) {
    if (e !== ct) return !1;
    if (!be) return (Wa(e), (be = !0), !1);
    var t;
    if (
      ((t = e.tag !== 3) &&
        !(t = e.tag !== 5) &&
        ((t = e.type),
        (t = t !== "head" && t !== "body" && !Qs(e.type, e.memoizedProps))),
      t && (t = dt))
    ) {
      if (ei(e)) throw (Ba(), Error(a(418)));
      for (; t;) (Ua(e, t), (t = Zt(t.nextSibling)));
    }
    if ((Wa(e), e.tag === 13)) {
      if (((e = e.memoizedState), (e = e !== null ? e.dehydrated : null), !e))
        throw Error(a(317));
      e: {
        for (e = e.nextSibling, t = 0; e;) {
          if (e.nodeType === 8) {
            var n = e.data;
            if (n === "/$") {
              if (t === 0) {
                dt = Zt(e.nextSibling);
                break e;
              }
              t--;
            } else (n !== "$" && n !== "$!" && n !== "$?") || t++;
          }
          e = e.nextSibling;
        }
        dt = null;
      }
    } else dt = ct ? Zt(e.stateNode.nextSibling) : null;
    return !0;
  }
  function Ba() {
    for (var e = dt; e;) e = Zt(e.nextSibling);
  }
  function Hn() {
    ((dt = ct = null), (be = !1));
  }
  function ni(e) {
    kt === null ? (kt = [e]) : kt.push(e);
  }
  var Pf = J.ReactCurrentBatchConfig;
  function Rr(e, t, n) {
    if (
      ((e = n.ref),
      e !== null && typeof e != "function" && typeof e != "object")
    ) {
      if (n._owner) {
        if (((n = n._owner), n)) {
          if (n.tag !== 1) throw Error(a(309));
          var r = n.stateNode;
        }
        if (!r) throw Error(a(147, e));
        var i = r,
          o = "" + e;
        return t !== null &&
          t.ref !== null &&
          typeof t.ref == "function" &&
          t.ref._stringRef === o
          ? t.ref
          : ((t = function (c) {
              var p = i.refs;
              c === null ? delete p[o] : (p[o] = c);
            }),
            (t._stringRef = o),
            t);
      }
      if (typeof e != "string") throw Error(a(284));
      if (!n._owner) throw Error(a(290, e));
    }
    return e;
  }
  function Sl(e, t) {
    throw (
      (e = Object.prototype.toString.call(t)),
      Error(
        a(
          31,
          e === "[object Object]"
            ? "object with keys {" + Object.keys(t).join(", ") + "}"
            : e,
        ),
      )
    );
  }
  function Va(e) {
    var t = e._init;
    return t(e._payload);
  }
  function Ha(e) {
    function t(y, g) {
      if (e) {
        var w = y.deletions;
        w === null ? ((y.deletions = [g]), (y.flags |= 16)) : w.push(g);
      }
    }
    function n(y, g) {
      if (!e) return null;
      for (; g !== null;) (t(y, g), (g = g.sibling));
      return null;
    }
    function r(y, g) {
      for (y = new Map(); g !== null;)
        (g.key !== null ? y.set(g.key, g) : y.set(g.index, g), (g = g.sibling));
      return y;
    }
    function i(y, g) {
      return ((y = on(y, g)), (y.index = 0), (y.sibling = null), y);
    }
    function o(y, g, w) {
      return (
        (y.index = w),
        e
          ? ((w = y.alternate),
            w !== null
              ? ((w = w.index), w < g ? ((y.flags |= 2), g) : w)
              : ((y.flags |= 2), g))
          : ((y.flags |= 1048576), g)
      );
    }
    function c(y) {
      return (e && y.alternate === null && (y.flags |= 2), y);
    }
    function p(y, g, w, M) {
      return g === null || g.tag !== 6
        ? ((g = Gi(w, y.mode, M)), (g.return = y), g)
        : ((g = i(g, w)), (g.return = y), g);
    }
    function h(y, g, w, M) {
      var D = w.type;
      return D === he
        ? b(y, g, w.props.children, M, w.key)
        : g !== null &&
            (g.elementType === D ||
              (typeof D == "object" &&
                D !== null &&
                D.$$typeof === we &&
                Va(D) === g.type))
          ? ((M = i(g, w.props)), (M.ref = Rr(y, g, w)), (M.return = y), M)
          : ((M = Gl(w.type, w.key, w.props, null, y.mode, M)),
            (M.ref = Rr(y, g, w)),
            (M.return = y),
            M);
    }
    function k(y, g, w, M) {
      return g === null ||
        g.tag !== 4 ||
        g.stateNode.containerInfo !== w.containerInfo ||
        g.stateNode.implementation !== w.implementation
        ? ((g = Ki(w, y.mode, M)), (g.return = y), g)
        : ((g = i(g, w.children || [])), (g.return = y), g);
    }
    function b(y, g, w, M, D) {
      return g === null || g.tag !== 7
        ? ((g = Nn(w, y.mode, M, D)), (g.return = y), g)
        : ((g = i(g, w)), (g.return = y), g);
    }
    function z(y, g, w) {
      if ((typeof g == "string" && g !== "") || typeof g == "number")
        return ((g = Gi("" + g, y.mode, w)), (g.return = y), g);
      if (typeof g == "object" && g !== null) {
        switch (g.$$typeof) {
          case ce:
            return (
              (w = Gl(g.type, g.key, g.props, null, y.mode, w)),
              (w.ref = Rr(y, null, g)),
              (w.return = y),
              w
            );
          case oe:
            return ((g = Ki(g, y.mode, w)), (g.return = y), g);
          case we:
            var M = g._init;
            return z(y, M(g._payload), w);
        }
        if (lr(g) || B(g))
          return ((g = Nn(g, y.mode, w, null)), (g.return = y), g);
        Sl(y, g);
      }
      return null;
    }
    function C(y, g, w, M) {
      var D = g !== null ? g.key : null;
      if ((typeof w == "string" && w !== "") || typeof w == "number")
        return D !== null ? null : p(y, g, "" + w, M);
      if (typeof w == "object" && w !== null) {
        switch (w.$$typeof) {
          case ce:
            return w.key === D ? h(y, g, w, M) : null;
          case oe:
            return w.key === D ? k(y, g, w, M) : null;
          case we:
            return ((D = w._init), C(y, g, D(w._payload), M));
        }
        if (lr(w) || B(w)) return D !== null ? null : b(y, g, w, M, null);
        Sl(y, w);
      }
      return null;
    }
    function T(y, g, w, M, D) {
      if ((typeof M == "string" && M !== "") || typeof M == "number")
        return ((y = y.get(w) || null), p(g, y, "" + M, D));
      if (typeof M == "object" && M !== null) {
        switch (M.$$typeof) {
          case ce:
            return (
              (y = y.get(M.key === null ? w : M.key) || null),
              h(g, y, M, D)
            );
          case oe:
            return (
              (y = y.get(M.key === null ? w : M.key) || null),
              k(g, y, M, D)
            );
          case we:
            var V = M._init;
            return T(y, g, w, V(M._payload), D);
        }
        if (lr(M) || B(M)) return ((y = y.get(w) || null), b(g, y, M, D, null));
        Sl(g, M);
      }
      return null;
    }
    function O(y, g, w, M) {
      for (
        var D = null, V = null, H = g, Q = (g = 0), Ve = null;
        H !== null && Q < w.length;
        Q++
      ) {
        H.index > Q ? ((Ve = H), (H = null)) : (Ve = H.sibling);
        var ie = C(y, H, w[Q], M);
        if (ie === null) {
          H === null && (H = Ve);
          break;
        }
        (e && H && ie.alternate === null && t(y, H),
          (g = o(ie, g, Q)),
          V === null ? (D = ie) : (V.sibling = ie),
          (V = ie),
          (H = Ve));
      }
      if (Q === w.length) return (n(y, H), be && gn(y, Q), D);
      if (H === null) {
        for (; Q < w.length; Q++)
          ((H = z(y, w[Q], M)),
            H !== null &&
              ((g = o(H, g, Q)),
              V === null ? (D = H) : (V.sibling = H),
              (V = H)));
        return (be && gn(y, Q), D);
      }
      for (H = r(y, H); Q < w.length; Q++)
        ((Ve = T(H, y, Q, w[Q], M)),
          Ve !== null &&
            (e &&
              Ve.alternate !== null &&
              H.delete(Ve.key === null ? Q : Ve.key),
            (g = o(Ve, g, Q)),
            V === null ? (D = Ve) : (V.sibling = Ve),
            (V = Ve)));
      return (
        e &&
          H.forEach(function (an) {
            return t(y, an);
          }),
        be && gn(y, Q),
        D
      );
    }
    function F(y, g, w, M) {
      var D = B(w);
      if (typeof D != "function") throw Error(a(150));
      if (((w = D.call(w)), w == null)) throw Error(a(151));
      for (
        var V = (D = null), H = g, Q = (g = 0), Ve = null, ie = w.next();
        H !== null && !ie.done;
        Q++, ie = w.next()
      ) {
        H.index > Q ? ((Ve = H), (H = null)) : (Ve = H.sibling);
        var an = C(y, H, ie.value, M);
        if (an === null) {
          H === null && (H = Ve);
          break;
        }
        (e && H && an.alternate === null && t(y, H),
          (g = o(an, g, Q)),
          V === null ? (D = an) : (V.sibling = an),
          (V = an),
          (H = Ve));
      }
      if (ie.done) return (n(y, H), be && gn(y, Q), D);
      if (H === null) {
        for (; !ie.done; Q++, ie = w.next())
          ((ie = z(y, ie.value, M)),
            ie !== null &&
              ((g = o(ie, g, Q)),
              V === null ? (D = ie) : (V.sibling = ie),
              (V = ie)));
        return (be && gn(y, Q), D);
      }
      for (H = r(y, H); !ie.done; Q++, ie = w.next())
        ((ie = T(H, y, Q, ie.value, M)),
          ie !== null &&
            (e &&
              ie.alternate !== null &&
              H.delete(ie.key === null ? Q : ie.key),
            (g = o(ie, g, Q)),
            V === null ? (D = ie) : (V.sibling = ie),
            (V = ie)));
      return (
        e &&
          H.forEach(function (cp) {
            return t(y, cp);
          }),
        be && gn(y, Q),
        D
      );
    }
    function Ae(y, g, w, M) {
      if (
        (typeof w == "object" &&
          w !== null &&
          w.type === he &&
          w.key === null &&
          (w = w.props.children),
        typeof w == "object" && w !== null)
      ) {
        switch (w.$$typeof) {
          case ce:
            e: {
              for (var D = w.key, V = g; V !== null;) {
                if (V.key === D) {
                  if (((D = w.type), D === he)) {
                    if (V.tag === 7) {
                      (n(y, V.sibling),
                        (g = i(V, w.props.children)),
                        (g.return = y),
                        (y = g));
                      break e;
                    }
                  } else if (
                    V.elementType === D ||
                    (typeof D == "object" &&
                      D !== null &&
                      D.$$typeof === we &&
                      Va(D) === V.type)
                  ) {
                    (n(y, V.sibling),
                      (g = i(V, w.props)),
                      (g.ref = Rr(y, V, w)),
                      (g.return = y),
                      (y = g));
                    break e;
                  }
                  n(y, V);
                  break;
                } else t(y, V);
                V = V.sibling;
              }
              w.type === he
                ? ((g = Nn(w.props.children, y.mode, M, w.key)),
                  (g.return = y),
                  (y = g))
                : ((M = Gl(w.type, w.key, w.props, null, y.mode, M)),
                  (M.ref = Rr(y, g, w)),
                  (M.return = y),
                  (y = M));
            }
            return c(y);
          case oe:
            e: {
              for (V = w.key; g !== null;) {
                if (g.key === V)
                  if (
                    g.tag === 4 &&
                    g.stateNode.containerInfo === w.containerInfo &&
                    g.stateNode.implementation === w.implementation
                  ) {
                    (n(y, g.sibling),
                      (g = i(g, w.children || [])),
                      (g.return = y),
                      (y = g));
                    break e;
                  } else {
                    n(y, g);
                    break;
                  }
                else t(y, g);
                g = g.sibling;
              }
              ((g = Ki(w, y.mode, M)), (g.return = y), (y = g));
            }
            return c(y);
          case we:
            return ((V = w._init), Ae(y, g, V(w._payload), M));
        }
        if (lr(w)) return O(y, g, w, M);
        if (B(w)) return F(y, g, w, M);
        Sl(y, w);
      }
      return (typeof w == "string" && w !== "") || typeof w == "number"
        ? ((w = "" + w),
          g !== null && g.tag === 6
            ? (n(y, g.sibling), (g = i(g, w)), (g.return = y), (y = g))
            : (n(y, g), (g = Gi(w, y.mode, M)), (g.return = y), (y = g)),
          c(y))
        : n(y, g);
    }
    return Ae;
  }
  var Qn = Ha(!0),
    Qa = Ha(!1),
    Nl = Yt(null),
    Cl = null,
    Gn = null,
    ri = null;
  function li() {
    ri = Gn = Cl = null;
  }
  function si(e) {
    var t = Nl.current;
    (Ne(Nl), (e._currentValue = t));
  }
  function ii(e, t, n) {
    for (; e !== null;) {
      var r = e.alternate;
      if (
        ((e.childLanes & t) !== t
          ? ((e.childLanes |= t), r !== null && (r.childLanes |= t))
          : r !== null && (r.childLanes & t) !== t && (r.childLanes |= t),
        e === n)
      )
        break;
      e = e.return;
    }
  }
  function Kn(e, t) {
    ((Cl = e),
      (ri = Gn = null),
      (e = e.dependencies),
      e !== null &&
        e.firstContext !== null &&
        ((e.lanes & t) !== 0 && (st = !0), (e.firstContext = null)));
  }
  function ht(e) {
    var t = e._currentValue;
    if (ri !== e)
      if (((e = { context: e, memoizedValue: t, next: null }), Gn === null)) {
        if (Cl === null) throw Error(a(308));
        ((Gn = e), (Cl.dependencies = { lanes: 0, firstContext: e }));
      } else Gn = Gn.next = e;
    return t;
  }
  var xn = null;
  function oi(e) {
    xn === null ? (xn = [e]) : xn.push(e);
  }
  function Ga(e, t, n, r) {
    var i = t.interleaved;
    return (
      i === null ? ((n.next = n), oi(t)) : ((n.next = i.next), (i.next = n)),
      (t.interleaved = n),
      At(e, r)
    );
  }
  function At(e, t) {
    e.lanes |= t;
    var n = e.alternate;
    for (n !== null && (n.lanes |= t), n = e, e = e.return; e !== null;)
      ((e.childLanes |= t),
        (n = e.alternate),
        n !== null && (n.childLanes |= t),
        (n = e),
        (e = e.return));
    return n.tag === 3 ? n.stateNode : null;
  }
  var qt = !1;
  function ai(e) {
    e.updateQueue = {
      baseState: e.memoizedState,
      firstBaseUpdate: null,
      lastBaseUpdate: null,
      shared: { pending: null, interleaved: null, lanes: 0 },
      effects: null,
    };
  }
  function Ka(e, t) {
    ((e = e.updateQueue),
      t.updateQueue === e &&
        (t.updateQueue = {
          baseState: e.baseState,
          firstBaseUpdate: e.firstBaseUpdate,
          lastBaseUpdate: e.lastBaseUpdate,
          shared: e.shared,
          effects: e.effects,
        }));
  }
  function It(e, t) {
    return {
      eventTime: e,
      lane: t,
      tag: 0,
      payload: null,
      callback: null,
      next: null,
    };
  }
  function en(e, t, n) {
    var r = e.updateQueue;
    if (r === null) return null;
    if (((r = r.shared), (se & 2) !== 0)) {
      var i = r.pending;
      return (
        i === null ? (t.next = t) : ((t.next = i.next), (i.next = t)),
        (r.pending = t),
        At(e, n)
      );
    }
    return (
      (i = r.interleaved),
      i === null ? ((t.next = t), oi(r)) : ((t.next = i.next), (i.next = t)),
      (r.interleaved = t),
      At(e, n)
    );
  }
  function bl(e, t, n) {
    if (
      ((t = t.updateQueue), t !== null && ((t = t.shared), (n & 4194240) !== 0))
    ) {
      var r = t.lanes;
      ((r &= e.pendingLanes), (n |= r), (t.lanes = n), js(e, n));
    }
  }
  function Za(e, t) {
    var n = e.updateQueue,
      r = e.alternate;
    if (r !== null && ((r = r.updateQueue), n === r)) {
      var i = null,
        o = null;
      if (((n = n.firstBaseUpdate), n !== null)) {
        do {
          var c = {
            eventTime: n.eventTime,
            lane: n.lane,
            tag: n.tag,
            payload: n.payload,
            callback: n.callback,
            next: null,
          };
          (o === null ? (i = o = c) : (o = o.next = c), (n = n.next));
        } while (n !== null);
        o === null ? (i = o = t) : (o = o.next = t);
      } else i = o = t;
      ((n = {
        baseState: r.baseState,
        firstBaseUpdate: i,
        lastBaseUpdate: o,
        shared: r.shared,
        effects: r.effects,
      }),
        (e.updateQueue = n));
      return;
    }
    ((e = n.lastBaseUpdate),
      e === null ? (n.firstBaseUpdate = t) : (e.next = t),
      (n.lastBaseUpdate = t));
  }
  function zl(e, t, n, r) {
    var i = e.updateQueue;
    qt = !1;
    var o = i.firstBaseUpdate,
      c = i.lastBaseUpdate,
      p = i.shared.pending;
    if (p !== null) {
      i.shared.pending = null;
      var h = p,
        k = h.next;
      ((h.next = null), c === null ? (o = k) : (c.next = k), (c = h));
      var b = e.alternate;
      b !== null &&
        ((b = b.updateQueue),
        (p = b.lastBaseUpdate),
        p !== c &&
          (p === null ? (b.firstBaseUpdate = k) : (p.next = k),
          (b.lastBaseUpdate = h)));
    }
    if (o !== null) {
      var z = i.baseState;
      ((c = 0), (b = k = h = null), (p = o));
      do {
        var C = p.lane,
          T = p.eventTime;
        if ((r & C) === C) {
          b !== null &&
            (b = b.next =
              {
                eventTime: T,
                lane: 0,
                tag: p.tag,
                payload: p.payload,
                callback: p.callback,
                next: null,
              });
          e: {
            var O = e,
              F = p;
            switch (((C = t), (T = n), F.tag)) {
              case 1:
                if (((O = F.payload), typeof O == "function")) {
                  z = O.call(T, z, C);
                  break e;
                }
                z = O;
                break e;
              case 3:
                O.flags = (O.flags & -65537) | 128;
              case 0:
                if (
                  ((O = F.payload),
                  (C = typeof O == "function" ? O.call(T, z, C) : O),
                  C == null)
                )
                  break e;
                z = A({}, z, C);
                break e;
              case 2:
                qt = !0;
            }
          }
          p.callback !== null &&
            p.lane !== 0 &&
            ((e.flags |= 64),
            (C = i.effects),
            C === null ? (i.effects = [p]) : C.push(p));
        } else
          ((T = {
            eventTime: T,
            lane: C,
            tag: p.tag,
            payload: p.payload,
            callback: p.callback,
            next: null,
          }),
            b === null ? ((k = b = T), (h = z)) : (b = b.next = T),
            (c |= C));
        if (((p = p.next), p === null)) {
          if (((p = i.shared.pending), p === null)) break;
          ((C = p),
            (p = C.next),
            (C.next = null),
            (i.lastBaseUpdate = C),
            (i.shared.pending = null));
        }
      } while (!0);
      if (
        (b === null && (h = z),
        (i.baseState = h),
        (i.firstBaseUpdate = k),
        (i.lastBaseUpdate = b),
        (t = i.shared.interleaved),
        t !== null)
      ) {
        i = t;
        do ((c |= i.lane), (i = i.next));
        while (i !== t);
      } else o === null && (i.shared.lanes = 0);
      ((wn |= c), (e.lanes = c), (e.memoizedState = z));
    }
  }
  function Ya(e, t, n) {
    if (((e = t.effects), (t.effects = null), e !== null))
      for (t = 0; t < e.length; t++) {
        var r = e[t],
          i = r.callback;
        if (i !== null) {
          if (((r.callback = null), (r = n), typeof i != "function"))
            throw Error(a(191, i));
          i.call(r);
        }
      }
  }
  var Mr = {},
    Et = Yt(Mr),
    Pr = Yt(Mr),
    _r = Yt(Mr);
  function yn(e) {
    if (e === Mr) throw Error(a(174));
    return e;
  }
  function ui(e, t) {
    switch ((je(_r, t), je(Pr, e), je(Et, Mr), (e = t.nodeType), e)) {
      case 9:
      case 11:
        t = (t = t.documentElement) ? t.namespaceURI : cs(null, "");
        break;
      default:
        ((e = e === 8 ? t.parentNode : t),
          (t = e.namespaceURI || null),
          (e = e.tagName),
          (t = cs(t, e)));
    }
    (Ne(Et), je(Et, t));
  }
  function Zn() {
    (Ne(Et), Ne(Pr), Ne(_r));
  }
  function Xa(e) {
    yn(_r.current);
    var t = yn(Et.current),
      n = cs(t, e.type);
    t !== n && (je(Pr, e), je(Et, n));
  }
  function ci(e) {
    Pr.current === e && (Ne(Et), Ne(Pr));
  }
  var ze = Yt(0);
  function El(e) {
    for (var t = e; t !== null;) {
      if (t.tag === 13) {
        var n = t.memoizedState;
        if (
          n !== null &&
          ((n = n.dehydrated), n === null || n.data === "$?" || n.data === "$!")
        )
          return t;
      } else if (t.tag === 19 && t.memoizedProps.revealOrder !== void 0) {
        if ((t.flags & 128) !== 0) return t;
      } else if (t.child !== null) {
        ((t.child.return = t), (t = t.child));
        continue;
      }
      if (t === e) break;
      for (; t.sibling === null;) {
        if (t.return === null || t.return === e) return null;
        t = t.return;
      }
      ((t.sibling.return = t.return), (t = t.sibling));
    }
    return null;
  }
  var di = [];
  function fi() {
    for (var e = 0; e < di.length; e++)
      di[e]._workInProgressVersionPrimary = null;
    di.length = 0;
  }
  var Rl = J.ReactCurrentDispatcher,
    pi = J.ReactCurrentBatchConfig,
    vn = 0,
    Ee = null,
    Fe = null,
    We = null,
    Ml = !1,
    Lr = !1,
    Tr = 0,
    _f = 0;
  function Xe() {
    throw Error(a(321));
  }
  function mi(e, t) {
    if (t === null) return !1;
    for (var n = 0; n < t.length && n < e.length; n++)
      if (!wt(e[n], t[n])) return !1;
    return !0;
  }
  function hi(e, t, n, r, i, o) {
    if (
      ((vn = o),
      (Ee = t),
      (t.memoizedState = null),
      (t.updateQueue = null),
      (t.lanes = 0),
      (Rl.current = e === null || e.memoizedState === null ? If : Of),
      (e = n(r, i)),
      Lr)
    ) {
      o = 0;
      do {
        if (((Lr = !1), (Tr = 0), 25 <= o)) throw Error(a(301));
        ((o += 1),
          (We = Fe = null),
          (t.updateQueue = null),
          (Rl.current = Ff),
          (e = n(r, i)));
      } while (Lr);
    }
    if (
      ((Rl.current = Ll),
      (t = Fe !== null && Fe.next !== null),
      (vn = 0),
      (We = Fe = Ee = null),
      (Ml = !1),
      t)
    )
      throw Error(a(300));
    return e;
  }
  function gi() {
    var e = Tr !== 0;
    return ((Tr = 0), e);
  }
  function Rt() {
    var e = {
      memoizedState: null,
      baseState: null,
      baseQueue: null,
      queue: null,
      next: null,
    };
    return (We === null ? (Ee.memoizedState = We = e) : (We = We.next = e), We);
  }
  function gt() {
    if (Fe === null) {
      var e = Ee.alternate;
      e = e !== null ? e.memoizedState : null;
    } else e = Fe.next;
    var t = We === null ? Ee.memoizedState : We.next;
    if (t !== null) ((We = t), (Fe = e));
    else {
      if (e === null) throw Error(a(310));
      ((Fe = e),
        (e = {
          memoizedState: Fe.memoizedState,
          baseState: Fe.baseState,
          baseQueue: Fe.baseQueue,
          queue: Fe.queue,
          next: null,
        }),
        We === null ? (Ee.memoizedState = We = e) : (We = We.next = e));
    }
    return We;
  }
  function Ar(e, t) {
    return typeof t == "function" ? t(e) : t;
  }
  function xi(e) {
    var t = gt(),
      n = t.queue;
    if (n === null) throw Error(a(311));
    n.lastRenderedReducer = e;
    var r = Fe,
      i = r.baseQueue,
      o = n.pending;
    if (o !== null) {
      if (i !== null) {
        var c = i.next;
        ((i.next = o.next), (o.next = c));
      }
      ((r.baseQueue = i = o), (n.pending = null));
    }
    if (i !== null) {
      ((o = i.next), (r = r.baseState));
      var p = (c = null),
        h = null,
        k = o;
      do {
        var b = k.lane;
        if ((vn & b) === b)
          (h !== null &&
            (h = h.next =
              {
                lane: 0,
                action: k.action,
                hasEagerState: k.hasEagerState,
                eagerState: k.eagerState,
                next: null,
              }),
            (r = k.hasEagerState ? k.eagerState : e(r, k.action)));
        else {
          var z = {
            lane: b,
            action: k.action,
            hasEagerState: k.hasEagerState,
            eagerState: k.eagerState,
            next: null,
          };
          (h === null ? ((p = h = z), (c = r)) : (h = h.next = z),
            (Ee.lanes |= b),
            (wn |= b));
        }
        k = k.next;
      } while (k !== null && k !== o);
      (h === null ? (c = r) : (h.next = p),
        wt(r, t.memoizedState) || (st = !0),
        (t.memoizedState = r),
        (t.baseState = c),
        (t.baseQueue = h),
        (n.lastRenderedState = r));
    }
    if (((e = n.interleaved), e !== null)) {
      i = e;
      do ((o = i.lane), (Ee.lanes |= o), (wn |= o), (i = i.next));
      while (i !== e);
    } else i === null && (n.lanes = 0);
    return [t.memoizedState, n.dispatch];
  }
  function yi(e) {
    var t = gt(),
      n = t.queue;
    if (n === null) throw Error(a(311));
    n.lastRenderedReducer = e;
    var r = n.dispatch,
      i = n.pending,
      o = t.memoizedState;
    if (i !== null) {
      n.pending = null;
      var c = (i = i.next);
      do ((o = e(o, c.action)), (c = c.next));
      while (c !== i);
      (wt(o, t.memoizedState) || (st = !0),
        (t.memoizedState = o),
        t.baseQueue === null && (t.baseState = o),
        (n.lastRenderedState = o));
    }
    return [o, r];
  }
  function Ja() {}
  function qa(e, t) {
    var n = Ee,
      r = gt(),
      i = t(),
      o = !wt(r.memoizedState, i);
    if (
      (o && ((r.memoizedState = i), (st = !0)),
      (r = r.queue),
      vi(nu.bind(null, n, r, e), [e]),
      r.getSnapshot !== t || o || (We !== null && We.memoizedState.tag & 1))
    ) {
      if (
        ((n.flags |= 2048),
        Ir(9, tu.bind(null, n, r, i, t), void 0, null),
        Be === null)
      )
        throw Error(a(349));
      (vn & 30) !== 0 || eu(n, t, i);
    }
    return i;
  }
  function eu(e, t, n) {
    ((e.flags |= 16384),
      (e = { getSnapshot: t, value: n }),
      (t = Ee.updateQueue),
      t === null
        ? ((t = { lastEffect: null, stores: null }),
          (Ee.updateQueue = t),
          (t.stores = [e]))
        : ((n = t.stores), n === null ? (t.stores = [e]) : n.push(e)));
  }
  function tu(e, t, n, r) {
    ((t.value = n), (t.getSnapshot = r), ru(t) && lu(e));
  }
  function nu(e, t, n) {
    return n(function () {
      ru(t) && lu(e);
    });
  }
  function ru(e) {
    var t = e.getSnapshot;
    e = e.value;
    try {
      var n = t();
      return !wt(e, n);
    } catch {
      return !0;
    }
  }
  function lu(e) {
    var t = At(e, 1);
    t !== null && Ct(t, e, 1, -1);
  }
  function su(e) {
    var t = Rt();
    return (
      typeof e == "function" && (e = e()),
      (t.memoizedState = t.baseState = e),
      (e = {
        pending: null,
        interleaved: null,
        lanes: 0,
        dispatch: null,
        lastRenderedReducer: Ar,
        lastRenderedState: e,
      }),
      (t.queue = e),
      (e = e.dispatch = Af.bind(null, Ee, e)),
      [t.memoizedState, e]
    );
  }
  function Ir(e, t, n, r) {
    return (
      (e = { tag: e, create: t, destroy: n, deps: r, next: null }),
      (t = Ee.updateQueue),
      t === null
        ? ((t = { lastEffect: null, stores: null }),
          (Ee.updateQueue = t),
          (t.lastEffect = e.next = e))
        : ((n = t.lastEffect),
          n === null
            ? (t.lastEffect = e.next = e)
            : ((r = n.next), (n.next = e), (e.next = r), (t.lastEffect = e))),
      e
    );
  }
  function iu() {
    return gt().memoizedState;
  }
  function Pl(e, t, n, r) {
    var i = Rt();
    ((Ee.flags |= e),
      (i.memoizedState = Ir(1 | t, n, void 0, r === void 0 ? null : r)));
  }
  function _l(e, t, n, r) {
    var i = gt();
    r = r === void 0 ? null : r;
    var o = void 0;
    if (Fe !== null) {
      var c = Fe.memoizedState;
      if (((o = c.destroy), r !== null && mi(r, c.deps))) {
        i.memoizedState = Ir(t, n, o, r);
        return;
      }
    }
    ((Ee.flags |= e), (i.memoizedState = Ir(1 | t, n, o, r)));
  }
  function ou(e, t) {
    return Pl(8390656, 8, e, t);
  }
  function vi(e, t) {
    return _l(2048, 8, e, t);
  }
  function au(e, t) {
    return _l(4, 2, e, t);
  }
  function uu(e, t) {
    return _l(4, 4, e, t);
  }
  function cu(e, t) {
    if (typeof t == "function")
      return (
        (e = e()),
        t(e),
        function () {
          t(null);
        }
      );
    if (t != null)
      return (
        (e = e()),
        (t.current = e),
        function () {
          t.current = null;
        }
      );
  }
  function du(e, t, n) {
    return (
      (n = n != null ? n.concat([e]) : null),
      _l(4, 4, cu.bind(null, t, e), n)
    );
  }
  function wi() {}
  function fu(e, t) {
    var n = gt();
    t = t === void 0 ? null : t;
    var r = n.memoizedState;
    return r !== null && t !== null && mi(t, r[1])
      ? r[0]
      : ((n.memoizedState = [e, t]), e);
  }
  function pu(e, t) {
    var n = gt();
    t = t === void 0 ? null : t;
    var r = n.memoizedState;
    return r !== null && t !== null && mi(t, r[1])
      ? r[0]
      : ((e = e()), (n.memoizedState = [e, t]), e);
  }
  function mu(e, t, n) {
    return (vn & 21) === 0
      ? (e.baseState && ((e.baseState = !1), (st = !0)), (e.memoizedState = n))
      : (wt(n, t) ||
          ((n = Vo()), (Ee.lanes |= n), (wn |= n), (e.baseState = !0)),
        t);
  }
  function Lf(e, t) {
    var n = me;
    ((me = n !== 0 && 4 > n ? n : 4), e(!0));
    var r = pi.transition;
    pi.transition = {};
    try {
      (e(!1), t());
    } finally {
      ((me = n), (pi.transition = r));
    }
  }
  function hu() {
    return gt().memoizedState;
  }
  function Tf(e, t, n) {
    var r = ln(e);
    if (
      ((n = {
        lane: r,
        action: n,
        hasEagerState: !1,
        eagerState: null,
        next: null,
      }),
      gu(e))
    )
      xu(t, n);
    else if (((n = Ga(e, t, n, r)), n !== null)) {
      var i = nt();
      (Ct(n, e, r, i), yu(n, t, r));
    }
  }
  function Af(e, t, n) {
    var r = ln(e),
      i = {
        lane: r,
        action: n,
        hasEagerState: !1,
        eagerState: null,
        next: null,
      };
    if (gu(e)) xu(t, i);
    else {
      var o = e.alternate;
      if (
        e.lanes === 0 &&
        (o === null || o.lanes === 0) &&
        ((o = t.lastRenderedReducer), o !== null)
      )
        try {
          var c = t.lastRenderedState,
            p = o(c, n);
          if (((i.hasEagerState = !0), (i.eagerState = p), wt(p, c))) {
            var h = t.interleaved;
            (h === null
              ? ((i.next = i), oi(t))
              : ((i.next = h.next), (h.next = i)),
              (t.interleaved = i));
            return;
          }
        } catch {
        } finally {
        }
      ((n = Ga(e, t, i, r)),
        n !== null && ((i = nt()), Ct(n, e, r, i), yu(n, t, r)));
    }
  }
  function gu(e) {
    var t = e.alternate;
    return e === Ee || (t !== null && t === Ee);
  }
  function xu(e, t) {
    Lr = Ml = !0;
    var n = e.pending;
    (n === null ? (t.next = t) : ((t.next = n.next), (n.next = t)),
      (e.pending = t));
  }
  function yu(e, t, n) {
    if ((n & 4194240) !== 0) {
      var r = t.lanes;
      ((r &= e.pendingLanes), (n |= r), (t.lanes = n), js(e, n));
    }
  }
  var Ll = {
      readContext: ht,
      useCallback: Xe,
      useContext: Xe,
      useEffect: Xe,
      useImperativeHandle: Xe,
      useInsertionEffect: Xe,
      useLayoutEffect: Xe,
      useMemo: Xe,
      useReducer: Xe,
      useRef: Xe,
      useState: Xe,
      useDebugValue: Xe,
      useDeferredValue: Xe,
      useTransition: Xe,
      useMutableSource: Xe,
      useSyncExternalStore: Xe,
      useId: Xe,
      unstable_isNewReconciler: !1,
    },
    If = {
      readContext: ht,
      useCallback: function (e, t) {
        return ((Rt().memoizedState = [e, t === void 0 ? null : t]), e);
      },
      useContext: ht,
      useEffect: ou,
      useImperativeHandle: function (e, t, n) {
        return (
          (n = n != null ? n.concat([e]) : null),
          Pl(4194308, 4, cu.bind(null, t, e), n)
        );
      },
      useLayoutEffect: function (e, t) {
        return Pl(4194308, 4, e, t);
      },
      useInsertionEffect: function (e, t) {
        return Pl(4, 2, e, t);
      },
      useMemo: function (e, t) {
        var n = Rt();
        return (
          (t = t === void 0 ? null : t),
          (e = e()),
          (n.memoizedState = [e, t]),
          e
        );
      },
      useReducer: function (e, t, n) {
        var r = Rt();
        return (
          (t = n !== void 0 ? n(t) : t),
          (r.memoizedState = r.baseState = t),
          (e = {
            pending: null,
            interleaved: null,
            lanes: 0,
            dispatch: null,
            lastRenderedReducer: e,
            lastRenderedState: t,
          }),
          (r.queue = e),
          (e = e.dispatch = Tf.bind(null, Ee, e)),
          [r.memoizedState, e]
        );
      },
      useRef: function (e) {
        var t = Rt();
        return ((e = { current: e }), (t.memoizedState = e));
      },
      useState: su,
      useDebugValue: wi,
      useDeferredValue: function (e) {
        return (Rt().memoizedState = e);
      },
      useTransition: function () {
        var e = su(!1),
          t = e[0];
        return ((e = Lf.bind(null, e[1])), (Rt().memoizedState = e), [t, e]);
      },
      useMutableSource: function () {},
      useSyncExternalStore: function (e, t, n) {
        var r = Ee,
          i = Rt();
        if (be) {
          if (n === void 0) throw Error(a(407));
          n = n();
        } else {
          if (((n = t()), Be === null)) throw Error(a(349));
          (vn & 30) !== 0 || eu(r, t, n);
        }
        i.memoizedState = n;
        var o = { value: n, getSnapshot: t };
        return (
          (i.queue = o),
          ou(nu.bind(null, r, o, e), [e]),
          (r.flags |= 2048),
          Ir(9, tu.bind(null, r, o, n, t), void 0, null),
          n
        );
      },
      useId: function () {
        var e = Rt(),
          t = Be.identifierPrefix;
        if (be) {
          var n = Tt,
            r = Lt;
          ((n = (r & ~(1 << (32 - vt(r) - 1))).toString(32) + n),
            (t = ":" + t + "R" + n),
            (n = Tr++),
            0 < n && (t += "H" + n.toString(32)),
            (t += ":"));
        } else ((n = _f++), (t = ":" + t + "r" + n.toString(32) + ":"));
        return (e.memoizedState = t);
      },
      unstable_isNewReconciler: !1,
    },
    Of = {
      readContext: ht,
      useCallback: fu,
      useContext: ht,
      useEffect: vi,
      useImperativeHandle: du,
      useInsertionEffect: au,
      useLayoutEffect: uu,
      useMemo: pu,
      useReducer: xi,
      useRef: iu,
      useState: function () {
        return xi(Ar);
      },
      useDebugValue: wi,
      useDeferredValue: function (e) {
        var t = gt();
        return mu(t, Fe.memoizedState, e);
      },
      useTransition: function () {
        var e = xi(Ar)[0],
          t = gt().memoizedState;
        return [e, t];
      },
      useMutableSource: Ja,
      useSyncExternalStore: qa,
      useId: hu,
      unstable_isNewReconciler: !1,
    },
    Ff = {
      readContext: ht,
      useCallback: fu,
      useContext: ht,
      useEffect: vi,
      useImperativeHandle: du,
      useInsertionEffect: au,
      useLayoutEffect: uu,
      useMemo: pu,
      useReducer: yi,
      useRef: iu,
      useState: function () {
        return yi(Ar);
      },
      useDebugValue: wi,
      useDeferredValue: function (e) {
        var t = gt();
        return Fe === null ? (t.memoizedState = e) : mu(t, Fe.memoizedState, e);
      },
      useTransition: function () {
        var e = yi(Ar)[0],
          t = gt().memoizedState;
        return [e, t];
      },
      useMutableSource: Ja,
      useSyncExternalStore: qa,
      useId: hu,
      unstable_isNewReconciler: !1,
    };
  function jt(e, t) {
    if (e && e.defaultProps) {
      ((t = A({}, t)), (e = e.defaultProps));
      for (var n in e) t[n] === void 0 && (t[n] = e[n]);
      return t;
    }
    return t;
  }
  function ki(e, t, n, r) {
    ((t = e.memoizedState),
      (n = n(r, t)),
      (n = n == null ? t : A({}, t, n)),
      (e.memoizedState = n),
      e.lanes === 0 && (e.updateQueue.baseState = n));
  }
  var Tl = {
    isMounted: function (e) {
      return (e = e._reactInternals) ? fn(e) === e : !1;
    },
    enqueueSetState: function (e, t, n) {
      e = e._reactInternals;
      var r = nt(),
        i = ln(e),
        o = It(r, i);
      ((o.payload = t),
        n != null && (o.callback = n),
        (t = en(e, o, i)),
        t !== null && (Ct(t, e, i, r), bl(t, e, i)));
    },
    enqueueReplaceState: function (e, t, n) {
      e = e._reactInternals;
      var r = nt(),
        i = ln(e),
        o = It(r, i);
      ((o.tag = 1),
        (o.payload = t),
        n != null && (o.callback = n),
        (t = en(e, o, i)),
        t !== null && (Ct(t, e, i, r), bl(t, e, i)));
    },
    enqueueForceUpdate: function (e, t) {
      e = e._reactInternals;
      var n = nt(),
        r = ln(e),
        i = It(n, r);
      ((i.tag = 2),
        t != null && (i.callback = t),
        (t = en(e, i, r)),
        t !== null && (Ct(t, e, r, n), bl(t, e, r)));
    },
  };
  function vu(e, t, n, r, i, o, c) {
    return (
      (e = e.stateNode),
      typeof e.shouldComponentUpdate == "function"
        ? e.shouldComponentUpdate(r, o, c)
        : t.prototype && t.prototype.isPureReactComponent
          ? !jr(n, r) || !jr(i, o)
          : !0
    );
  }
  function wu(e, t, n) {
    var r = !1,
      i = Xt,
      o = t.contextType;
    return (
      typeof o == "object" && o !== null
        ? (o = ht(o))
        : ((i = lt(t) ? mn : Ye.current),
          (r = t.contextTypes),
          (o = (r = r != null) ? Wn(e, i) : Xt)),
      (t = new t(n, o)),
      (e.memoizedState =
        t.state !== null && t.state !== void 0 ? t.state : null),
      (t.updater = Tl),
      (e.stateNode = t),
      (t._reactInternals = e),
      r &&
        ((e = e.stateNode),
        (e.__reactInternalMemoizedUnmaskedChildContext = i),
        (e.__reactInternalMemoizedMaskedChildContext = o)),
      t
    );
  }
  function ku(e, t, n, r) {
    ((e = t.state),
      typeof t.componentWillReceiveProps == "function" &&
        t.componentWillReceiveProps(n, r),
      typeof t.UNSAFE_componentWillReceiveProps == "function" &&
        t.UNSAFE_componentWillReceiveProps(n, r),
      t.state !== e && Tl.enqueueReplaceState(t, t.state, null));
  }
  function ji(e, t, n, r) {
    var i = e.stateNode;
    ((i.props = n), (i.state = e.memoizedState), (i.refs = {}), ai(e));
    var o = t.contextType;
    (typeof o == "object" && o !== null
      ? (i.context = ht(o))
      : ((o = lt(t) ? mn : Ye.current), (i.context = Wn(e, o))),
      (i.state = e.memoizedState),
      (o = t.getDerivedStateFromProps),
      typeof o == "function" && (ki(e, t, o, n), (i.state = e.memoizedState)),
      typeof t.getDerivedStateFromProps == "function" ||
        typeof i.getSnapshotBeforeUpdate == "function" ||
        (typeof i.UNSAFE_componentWillMount != "function" &&
          typeof i.componentWillMount != "function") ||
        ((t = i.state),
        typeof i.componentWillMount == "function" && i.componentWillMount(),
        typeof i.UNSAFE_componentWillMount == "function" &&
          i.UNSAFE_componentWillMount(),
        t !== i.state && Tl.enqueueReplaceState(i, i.state, null),
        zl(e, n, i, r),
        (i.state = e.memoizedState)),
      typeof i.componentDidMount == "function" && (e.flags |= 4194308));
  }
  function Yn(e, t) {
    try {
      var n = "",
        r = t;
      do ((n += re(r)), (r = r.return));
      while (r);
      var i = n;
    } catch (o) {
      i =
        `
Error generating stack: ` +
        o.message +
        `
` +
        o.stack;
    }
    return { value: e, source: t, stack: i, digest: null };
  }
  function Si(e, t, n) {
    return { value: e, source: null, stack: n ?? null, digest: t ?? null };
  }
  function Ni(e, t) {
    try {
      console.error(t.value);
    } catch (n) {
      setTimeout(function () {
        throw n;
      });
    }
  }
  var Df = typeof WeakMap == "function" ? WeakMap : Map;
  function ju(e, t, n) {
    ((n = It(-1, n)), (n.tag = 3), (n.payload = { element: null }));
    var r = t.value;
    return (
      (n.callback = function () {
        ($l || (($l = !0), (Di = r)), Ni(e, t));
      }),
      n
    );
  }
  function Su(e, t, n) {
    ((n = It(-1, n)), (n.tag = 3));
    var r = e.type.getDerivedStateFromError;
    if (typeof r == "function") {
      var i = t.value;
      ((n.payload = function () {
        return r(i);
      }),
        (n.callback = function () {
          Ni(e, t);
        }));
    }
    var o = e.stateNode;
    return (
      o !== null &&
        typeof o.componentDidCatch == "function" &&
        (n.callback = function () {
          (Ni(e, t),
            typeof r != "function" &&
              (nn === null ? (nn = new Set([this])) : nn.add(this)));
          var c = t.stack;
          this.componentDidCatch(t.value, {
            componentStack: c !== null ? c : "",
          });
        }),
      n
    );
  }
  function Nu(e, t, n) {
    var r = e.pingCache;
    if (r === null) {
      r = e.pingCache = new Df();
      var i = new Set();
      r.set(t, i);
    } else ((i = r.get(t)), i === void 0 && ((i = new Set()), r.set(t, i)));
    i.has(n) || (i.add(n), (e = qf.bind(null, e, t, n)), t.then(e, e));
  }
  function Cu(e) {
    do {
      var t;
      if (
        ((t = e.tag === 13) &&
          ((t = e.memoizedState),
          (t = t !== null ? t.dehydrated !== null : !0)),
        t)
      )
        return e;
      e = e.return;
    } while (e !== null);
    return null;
  }
  function bu(e, t, n, r, i) {
    return (e.mode & 1) === 0
      ? (e === t
          ? (e.flags |= 65536)
          : ((e.flags |= 128),
            (n.flags |= 131072),
            (n.flags &= -52805),
            n.tag === 1 &&
              (n.alternate === null
                ? (n.tag = 17)
                : ((t = It(-1, 1)), (t.tag = 2), en(n, t, 1))),
            (n.lanes |= 1)),
        e)
      : ((e.flags |= 65536), (e.lanes = i), e);
  }
  var Uf = J.ReactCurrentOwner,
    st = !1;
  function tt(e, t, n, r) {
    t.child = e === null ? Qa(t, null, n, r) : Qn(t, e.child, n, r);
  }
  function zu(e, t, n, r, i) {
    n = n.render;
    var o = t.ref;
    return (
      Kn(t, i),
      (r = hi(e, t, n, r, o, i)),
      (n = gi()),
      e !== null && !st
        ? ((t.updateQueue = e.updateQueue),
          (t.flags &= -2053),
          (e.lanes &= ~i),
          Ot(e, t, i))
        : (be && n && Js(t), (t.flags |= 1), tt(e, t, r, i), t.child)
    );
  }
  function Eu(e, t, n, r, i) {
    if (e === null) {
      var o = n.type;
      return typeof o == "function" &&
        !Qi(o) &&
        o.defaultProps === void 0 &&
        n.compare === null &&
        n.defaultProps === void 0
        ? ((t.tag = 15), (t.type = o), Ru(e, t, o, r, i))
        : ((e = Gl(n.type, null, r, t, t.mode, i)),
          (e.ref = t.ref),
          (e.return = t),
          (t.child = e));
    }
    if (((o = e.child), (e.lanes & i) === 0)) {
      var c = o.memoizedProps;
      if (
        ((n = n.compare), (n = n !== null ? n : jr), n(c, r) && e.ref === t.ref)
      )
        return Ot(e, t, i);
    }
    return (
      (t.flags |= 1),
      (e = on(o, r)),
      (e.ref = t.ref),
      (e.return = t),
      (t.child = e)
    );
  }
  function Ru(e, t, n, r, i) {
    if (e !== null) {
      var o = e.memoizedProps;
      if (jr(o, r) && e.ref === t.ref)
        if (((st = !1), (t.pendingProps = r = o), (e.lanes & i) !== 0))
          (e.flags & 131072) !== 0 && (st = !0);
        else return ((t.lanes = e.lanes), Ot(e, t, i));
    }
    return Ci(e, t, n, r, i);
  }
  function Mu(e, t, n) {
    var r = t.pendingProps,
      i = r.children,
      o = e !== null ? e.memoizedState : null;
    if (r.mode === "hidden")
      if ((t.mode & 1) === 0)
        ((t.memoizedState = {
          baseLanes: 0,
          cachePool: null,
          transitions: null,
        }),
          je(Jn, ft),
          (ft |= n));
      else {
        if ((n & 1073741824) === 0)
          return (
            (e = o !== null ? o.baseLanes | n : n),
            (t.lanes = t.childLanes = 1073741824),
            (t.memoizedState = {
              baseLanes: e,
              cachePool: null,
              transitions: null,
            }),
            (t.updateQueue = null),
            je(Jn, ft),
            (ft |= e),
            null
          );
        ((t.memoizedState = {
          baseLanes: 0,
          cachePool: null,
          transitions: null,
        }),
          (r = o !== null ? o.baseLanes : n),
          je(Jn, ft),
          (ft |= r));
      }
    else
      (o !== null ? ((r = o.baseLanes | n), (t.memoizedState = null)) : (r = n),
        je(Jn, ft),
        (ft |= r));
    return (tt(e, t, i, n), t.child);
  }
  function Pu(e, t) {
    var n = t.ref;
    ((e === null && n !== null) || (e !== null && e.ref !== n)) &&
      ((t.flags |= 512), (t.flags |= 2097152));
  }
  function Ci(e, t, n, r, i) {
    var o = lt(n) ? mn : Ye.current;
    return (
      (o = Wn(t, o)),
      Kn(t, i),
      (n = hi(e, t, n, r, o, i)),
      (r = gi()),
      e !== null && !st
        ? ((t.updateQueue = e.updateQueue),
          (t.flags &= -2053),
          (e.lanes &= ~i),
          Ot(e, t, i))
        : (be && r && Js(t), (t.flags |= 1), tt(e, t, n, i), t.child)
    );
  }
  function _u(e, t, n, r, i) {
    if (lt(n)) {
      var o = !0;
      yl(t);
    } else o = !1;
    if ((Kn(t, i), t.stateNode === null))
      (Il(e, t), wu(t, n, r), ji(t, n, r, i), (r = !0));
    else if (e === null) {
      var c = t.stateNode,
        p = t.memoizedProps;
      c.props = p;
      var h = c.context,
        k = n.contextType;
      typeof k == "object" && k !== null
        ? (k = ht(k))
        : ((k = lt(n) ? mn : Ye.current), (k = Wn(t, k)));
      var b = n.getDerivedStateFromProps,
        z =
          typeof b == "function" ||
          typeof c.getSnapshotBeforeUpdate == "function";
      (z ||
        (typeof c.UNSAFE_componentWillReceiveProps != "function" &&
          typeof c.componentWillReceiveProps != "function") ||
        ((p !== r || h !== k) && ku(t, c, r, k)),
        (qt = !1));
      var C = t.memoizedState;
      ((c.state = C),
        zl(t, r, c, i),
        (h = t.memoizedState),
        p !== r || C !== h || rt.current || qt
          ? (typeof b == "function" && (ki(t, n, b, r), (h = t.memoizedState)),
            (p = qt || vu(t, n, p, r, C, h, k))
              ? (z ||
                  (typeof c.UNSAFE_componentWillMount != "function" &&
                    typeof c.componentWillMount != "function") ||
                  (typeof c.componentWillMount == "function" &&
                    c.componentWillMount(),
                  typeof c.UNSAFE_componentWillMount == "function" &&
                    c.UNSAFE_componentWillMount()),
                typeof c.componentDidMount == "function" &&
                  (t.flags |= 4194308))
              : (typeof c.componentDidMount == "function" &&
                  (t.flags |= 4194308),
                (t.memoizedProps = r),
                (t.memoizedState = h)),
            (c.props = r),
            (c.state = h),
            (c.context = k),
            (r = p))
          : (typeof c.componentDidMount == "function" && (t.flags |= 4194308),
            (r = !1)));
    } else {
      ((c = t.stateNode),
        Ka(e, t),
        (p = t.memoizedProps),
        (k = t.type === t.elementType ? p : jt(t.type, p)),
        (c.props = k),
        (z = t.pendingProps),
        (C = c.context),
        (h = n.contextType),
        typeof h == "object" && h !== null
          ? (h = ht(h))
          : ((h = lt(n) ? mn : Ye.current), (h = Wn(t, h))));
      var T = n.getDerivedStateFromProps;
      ((b =
        typeof T == "function" ||
        typeof c.getSnapshotBeforeUpdate == "function") ||
        (typeof c.UNSAFE_componentWillReceiveProps != "function" &&
          typeof c.componentWillReceiveProps != "function") ||
        ((p !== z || C !== h) && ku(t, c, r, h)),
        (qt = !1),
        (C = t.memoizedState),
        (c.state = C),
        zl(t, r, c, i));
      var O = t.memoizedState;
      p !== z || C !== O || rt.current || qt
        ? (typeof T == "function" && (ki(t, n, T, r), (O = t.memoizedState)),
          (k = qt || vu(t, n, k, r, C, O, h) || !1)
            ? (b ||
                (typeof c.UNSAFE_componentWillUpdate != "function" &&
                  typeof c.componentWillUpdate != "function") ||
                (typeof c.componentWillUpdate == "function" &&
                  c.componentWillUpdate(r, O, h),
                typeof c.UNSAFE_componentWillUpdate == "function" &&
                  c.UNSAFE_componentWillUpdate(r, O, h)),
              typeof c.componentDidUpdate == "function" && (t.flags |= 4),
              typeof c.getSnapshotBeforeUpdate == "function" &&
                (t.flags |= 1024))
            : (typeof c.componentDidUpdate != "function" ||
                (p === e.memoizedProps && C === e.memoizedState) ||
                (t.flags |= 4),
              typeof c.getSnapshotBeforeUpdate != "function" ||
                (p === e.memoizedProps && C === e.memoizedState) ||
                (t.flags |= 1024),
              (t.memoizedProps = r),
              (t.memoizedState = O)),
          (c.props = r),
          (c.state = O),
          (c.context = h),
          (r = k))
        : (typeof c.componentDidUpdate != "function" ||
            (p === e.memoizedProps && C === e.memoizedState) ||
            (t.flags |= 4),
          typeof c.getSnapshotBeforeUpdate != "function" ||
            (p === e.memoizedProps && C === e.memoizedState) ||
            (t.flags |= 1024),
          (r = !1));
    }
    return bi(e, t, n, r, o, i);
  }
  function bi(e, t, n, r, i, o) {
    Pu(e, t);
    var c = (t.flags & 128) !== 0;
    if (!r && !c) return (i && Oa(t, n, !1), Ot(e, t, o));
    ((r = t.stateNode), (Uf.current = t));
    var p =
      c && typeof n.getDerivedStateFromError != "function" ? null : r.render();
    return (
      (t.flags |= 1),
      e !== null && c
        ? ((t.child = Qn(t, e.child, null, o)), (t.child = Qn(t, null, p, o)))
        : tt(e, t, p, o),
      (t.memoizedState = r.state),
      i && Oa(t, n, !0),
      t.child
    );
  }
  function Lu(e) {
    var t = e.stateNode;
    (t.pendingContext
      ? Aa(e, t.pendingContext, t.pendingContext !== t.context)
      : t.context && Aa(e, t.context, !1),
      ui(e, t.containerInfo));
  }
  function Tu(e, t, n, r, i) {
    return (Hn(), ni(i), (t.flags |= 256), tt(e, t, n, r), t.child);
  }
  var zi = { dehydrated: null, treeContext: null, retryLane: 0 };
  function Ei(e) {
    return { baseLanes: e, cachePool: null, transitions: null };
  }
  function Au(e, t, n) {
    var r = t.pendingProps,
      i = ze.current,
      o = !1,
      c = (t.flags & 128) !== 0,
      p;
    if (
      ((p = c) ||
        (p = e !== null && e.memoizedState === null ? !1 : (i & 2) !== 0),
      p
        ? ((o = !0), (t.flags &= -129))
        : (e === null || e.memoizedState !== null) && (i |= 1),
      je(ze, i & 1),
      e === null)
    )
      return (
        ti(t),
        (e = t.memoizedState),
        e !== null && ((e = e.dehydrated), e !== null)
          ? ((t.mode & 1) === 0
              ? (t.lanes = 1)
              : e.data === "$!"
                ? (t.lanes = 8)
                : (t.lanes = 1073741824),
            null)
          : ((c = r.children),
            (e = r.fallback),
            o
              ? ((r = t.mode),
                (o = t.child),
                (c = { mode: "hidden", children: c }),
                (r & 1) === 0 && o !== null
                  ? ((o.childLanes = 0), (o.pendingProps = c))
                  : (o = Kl(c, r, 0, null)),
                (e = Nn(e, r, n, null)),
                (o.return = t),
                (e.return = t),
                (o.sibling = e),
                (t.child = o),
                (t.child.memoizedState = Ei(n)),
                (t.memoizedState = zi),
                e)
              : Ri(t, c))
      );
    if (((i = e.memoizedState), i !== null && ((p = i.dehydrated), p !== null)))
      return $f(e, t, c, r, p, i, n);
    if (o) {
      ((o = r.fallback), (c = t.mode), (i = e.child), (p = i.sibling));
      var h = { mode: "hidden", children: r.children };
      return (
        (c & 1) === 0 && t.child !== i
          ? ((r = t.child),
            (r.childLanes = 0),
            (r.pendingProps = h),
            (t.deletions = null))
          : ((r = on(i, h)), (r.subtreeFlags = i.subtreeFlags & 14680064)),
        p !== null ? (o = on(p, o)) : ((o = Nn(o, c, n, null)), (o.flags |= 2)),
        (o.return = t),
        (r.return = t),
        (r.sibling = o),
        (t.child = r),
        (r = o),
        (o = t.child),
        (c = e.child.memoizedState),
        (c =
          c === null
            ? Ei(n)
            : {
                baseLanes: c.baseLanes | n,
                cachePool: null,
                transitions: c.transitions,
              }),
        (o.memoizedState = c),
        (o.childLanes = e.childLanes & ~n),
        (t.memoizedState = zi),
        r
      );
    }
    return (
      (o = e.child),
      (e = o.sibling),
      (r = on(o, { mode: "visible", children: r.children })),
      (t.mode & 1) === 0 && (r.lanes = n),
      (r.return = t),
      (r.sibling = null),
      e !== null &&
        ((n = t.deletions),
        n === null ? ((t.deletions = [e]), (t.flags |= 16)) : n.push(e)),
      (t.child = r),
      (t.memoizedState = null),
      r
    );
  }
  function Ri(e, t) {
    return (
      (t = Kl({ mode: "visible", children: t }, e.mode, 0, null)),
      (t.return = e),
      (e.child = t)
    );
  }
  function Al(e, t, n, r) {
    return (
      r !== null && ni(r),
      Qn(t, e.child, null, n),
      (e = Ri(t, t.pendingProps.children)),
      (e.flags |= 2),
      (t.memoizedState = null),
      e
    );
  }
  function $f(e, t, n, r, i, o, c) {
    if (n)
      return t.flags & 256
        ? ((t.flags &= -257), (r = Si(Error(a(422)))), Al(e, t, c, r))
        : t.memoizedState !== null
          ? ((t.child = e.child), (t.flags |= 128), null)
          : ((o = r.fallback),
            (i = t.mode),
            (r = Kl({ mode: "visible", children: r.children }, i, 0, null)),
            (o = Nn(o, i, c, null)),
            (o.flags |= 2),
            (r.return = t),
            (o.return = t),
            (r.sibling = o),
            (t.child = r),
            (t.mode & 1) !== 0 && Qn(t, e.child, null, c),
            (t.child.memoizedState = Ei(c)),
            (t.memoizedState = zi),
            o);
    if ((t.mode & 1) === 0) return Al(e, t, c, null);
    if (i.data === "$!") {
      if (((r = i.nextSibling && i.nextSibling.dataset), r)) var p = r.dgst;
      return (
        (r = p),
        (o = Error(a(419))),
        (r = Si(o, r, void 0)),
        Al(e, t, c, r)
      );
    }
    if (((p = (c & e.childLanes) !== 0), st || p)) {
      if (((r = Be), r !== null)) {
        switch (c & -c) {
          case 4:
            i = 2;
            break;
          case 16:
            i = 8;
            break;
          case 64:
          case 128:
          case 256:
          case 512:
          case 1024:
          case 2048:
          case 4096:
          case 8192:
          case 16384:
          case 32768:
          case 65536:
          case 131072:
          case 262144:
          case 524288:
          case 1048576:
          case 2097152:
          case 4194304:
          case 8388608:
          case 16777216:
          case 33554432:
          case 67108864:
            i = 32;
            break;
          case 536870912:
            i = 268435456;
            break;
          default:
            i = 0;
        }
        ((i = (i & (r.suspendedLanes | c)) !== 0 ? 0 : i),
          i !== 0 &&
            i !== o.retryLane &&
            ((o.retryLane = i), At(e, i), Ct(r, e, i, -1)));
      }
      return (Hi(), (r = Si(Error(a(421)))), Al(e, t, c, r));
    }
    return i.data === "$?"
      ? ((t.flags |= 128),
        (t.child = e.child),
        (t = ep.bind(null, e)),
        (i._reactRetry = t),
        null)
      : ((e = o.treeContext),
        (dt = Zt(i.nextSibling)),
        (ct = t),
        (be = !0),
        (kt = null),
        e !== null &&
          ((pt[mt++] = Lt),
          (pt[mt++] = Tt),
          (pt[mt++] = hn),
          (Lt = e.id),
          (Tt = e.overflow),
          (hn = t)),
        (t = Ri(t, r.children)),
        (t.flags |= 4096),
        t);
  }
  function Iu(e, t, n) {
    e.lanes |= t;
    var r = e.alternate;
    (r !== null && (r.lanes |= t), ii(e.return, t, n));
  }
  function Mi(e, t, n, r, i) {
    var o = e.memoizedState;
    o === null
      ? (e.memoizedState = {
          isBackwards: t,
          rendering: null,
          renderingStartTime: 0,
          last: r,
          tail: n,
          tailMode: i,
        })
      : ((o.isBackwards = t),
        (o.rendering = null),
        (o.renderingStartTime = 0),
        (o.last = r),
        (o.tail = n),
        (o.tailMode = i));
  }
  function Ou(e, t, n) {
    var r = t.pendingProps,
      i = r.revealOrder,
      o = r.tail;
    if ((tt(e, t, r.children, n), (r = ze.current), (r & 2) !== 0))
      ((r = (r & 1) | 2), (t.flags |= 128));
    else {
      if (e !== null && (e.flags & 128) !== 0)
        e: for (e = t.child; e !== null;) {
          if (e.tag === 13) e.memoizedState !== null && Iu(e, n, t);
          else if (e.tag === 19) Iu(e, n, t);
          else if (e.child !== null) {
            ((e.child.return = e), (e = e.child));
            continue;
          }
          if (e === t) break e;
          for (; e.sibling === null;) {
            if (e.return === null || e.return === t) break e;
            e = e.return;
          }
          ((e.sibling.return = e.return), (e = e.sibling));
        }
      r &= 1;
    }
    if ((je(ze, r), (t.mode & 1) === 0)) t.memoizedState = null;
    else
      switch (i) {
        case "forwards":
          for (n = t.child, i = null; n !== null;)
            ((e = n.alternate),
              e !== null && El(e) === null && (i = n),
              (n = n.sibling));
          ((n = i),
            n === null
              ? ((i = t.child), (t.child = null))
              : ((i = n.sibling), (n.sibling = null)),
            Mi(t, !1, i, n, o));
          break;
        case "backwards":
          for (n = null, i = t.child, t.child = null; i !== null;) {
            if (((e = i.alternate), e !== null && El(e) === null)) {
              t.child = i;
              break;
            }
            ((e = i.sibling), (i.sibling = n), (n = i), (i = e));
          }
          Mi(t, !0, n, null, o);
          break;
        case "together":
          Mi(t, !1, null, null, void 0);
          break;
        default:
          t.memoizedState = null;
      }
    return t.child;
  }
  function Il(e, t) {
    (t.mode & 1) === 0 &&
      e !== null &&
      ((e.alternate = null), (t.alternate = null), (t.flags |= 2));
  }
  function Ot(e, t, n) {
    if (
      (e !== null && (t.dependencies = e.dependencies),
      (wn |= t.lanes),
      (n & t.childLanes) === 0)
    )
      return null;
    if (e !== null && t.child !== e.child) throw Error(a(153));
    if (t.child !== null) {
      for (
        e = t.child, n = on(e, e.pendingProps), t.child = n, n.return = t;
        e.sibling !== null;
      )
        ((e = e.sibling),
          (n = n.sibling = on(e, e.pendingProps)),
          (n.return = t));
      n.sibling = null;
    }
    return t.child;
  }
  function Wf(e, t, n) {
    switch (t.tag) {
      case 3:
        (Lu(t), Hn());
        break;
      case 5:
        Xa(t);
        break;
      case 1:
        lt(t.type) && yl(t);
        break;
      case 4:
        ui(t, t.stateNode.containerInfo);
        break;
      case 10:
        var r = t.type._context,
          i = t.memoizedProps.value;
        (je(Nl, r._currentValue), (r._currentValue = i));
        break;
      case 13:
        if (((r = t.memoizedState), r !== null))
          return r.dehydrated !== null
            ? (je(ze, ze.current & 1), (t.flags |= 128), null)
            : (n & t.child.childLanes) !== 0
              ? Au(e, t, n)
              : (je(ze, ze.current & 1),
                (e = Ot(e, t, n)),
                e !== null ? e.sibling : null);
        je(ze, ze.current & 1);
        break;
      case 19:
        if (((r = (n & t.childLanes) !== 0), (e.flags & 128) !== 0)) {
          if (r) return Ou(e, t, n);
          t.flags |= 128;
        }
        if (
          ((i = t.memoizedState),
          i !== null &&
            ((i.rendering = null), (i.tail = null), (i.lastEffect = null)),
          je(ze, ze.current),
          r)
        )
          break;
        return null;
      case 22:
      case 23:
        return ((t.lanes = 0), Mu(e, t, n));
    }
    return Ot(e, t, n);
  }
  var Fu, Pi, Du, Uu;
  ((Fu = function (e, t) {
    for (var n = t.child; n !== null;) {
      if (n.tag === 5 || n.tag === 6) e.appendChild(n.stateNode);
      else if (n.tag !== 4 && n.child !== null) {
        ((n.child.return = n), (n = n.child));
        continue;
      }
      if (n === t) break;
      for (; n.sibling === null;) {
        if (n.return === null || n.return === t) return;
        n = n.return;
      }
      ((n.sibling.return = n.return), (n = n.sibling));
    }
  }),
    (Pi = function () {}),
    (Du = function (e, t, n, r) {
      var i = e.memoizedProps;
      if (i !== r) {
        ((e = t.stateNode), yn(Et.current));
        var o = null;
        switch (n) {
          case "input":
            ((i = rr(e, i)), (r = rr(e, r)), (o = []));
            break;
          case "select":
            ((i = A({}, i, { value: void 0 })),
              (r = A({}, r, { value: void 0 })),
              (o = []));
            break;
          case "textarea":
            ((i = us(e, i)), (r = us(e, r)), (o = []));
            break;
          default:
            typeof i.onClick != "function" &&
              typeof r.onClick == "function" &&
              (e.onclick = hl);
        }
        ds(n, r);
        var c;
        n = null;
        for (k in i)
          if (!r.hasOwnProperty(k) && i.hasOwnProperty(k) && i[k] != null)
            if (k === "style") {
              var p = i[k];
              for (c in p) p.hasOwnProperty(c) && (n || (n = {}), (n[c] = ""));
            } else
              k !== "dangerouslySetInnerHTML" &&
                k !== "children" &&
                k !== "suppressContentEditableWarning" &&
                k !== "suppressHydrationWarning" &&
                k !== "autoFocus" &&
                (f.hasOwnProperty(k)
                  ? o || (o = [])
                  : (o = o || []).push(k, null));
        for (k in r) {
          var h = r[k];
          if (
            ((p = i?.[k]),
            r.hasOwnProperty(k) && h !== p && (h != null || p != null))
          )
            if (k === "style")
              if (p) {
                for (c in p)
                  !p.hasOwnProperty(c) ||
                    (h && h.hasOwnProperty(c)) ||
                    (n || (n = {}), (n[c] = ""));
                for (c in h)
                  h.hasOwnProperty(c) &&
                    p[c] !== h[c] &&
                    (n || (n = {}), (n[c] = h[c]));
              } else (n || (o || (o = []), o.push(k, n)), (n = h));
            else
              k === "dangerouslySetInnerHTML"
                ? ((h = h ? h.__html : void 0),
                  (p = p ? p.__html : void 0),
                  h != null && p !== h && (o = o || []).push(k, h))
                : k === "children"
                  ? (typeof h != "string" && typeof h != "number") ||
                    (o = o || []).push(k, "" + h)
                  : k !== "suppressContentEditableWarning" &&
                    k !== "suppressHydrationWarning" &&
                    (f.hasOwnProperty(k)
                      ? (h != null && k === "onScroll" && Se("scroll", e),
                        o || p === h || (o = []))
                      : (o = o || []).push(k, h));
        }
        n && (o = o || []).push("style", n);
        var k = o;
        (t.updateQueue = k) && (t.flags |= 4);
      }
    }),
    (Uu = function (e, t, n, r) {
      n !== r && (t.flags |= 4);
    }));
  function Or(e, t) {
    if (!be)
      switch (e.tailMode) {
        case "hidden":
          t = e.tail;
          for (var n = null; t !== null;)
            (t.alternate !== null && (n = t), (t = t.sibling));
          n === null ? (e.tail = null) : (n.sibling = null);
          break;
        case "collapsed":
          n = e.tail;
          for (var r = null; n !== null;)
            (n.alternate !== null && (r = n), (n = n.sibling));
          r === null
            ? t || e.tail === null
              ? (e.tail = null)
              : (e.tail.sibling = null)
            : (r.sibling = null);
      }
  }
  function Je(e) {
    var t = e.alternate !== null && e.alternate.child === e.child,
      n = 0,
      r = 0;
    if (t)
      for (var i = e.child; i !== null;)
        ((n |= i.lanes | i.childLanes),
          (r |= i.subtreeFlags & 14680064),
          (r |= i.flags & 14680064),
          (i.return = e),
          (i = i.sibling));
    else
      for (i = e.child; i !== null;)
        ((n |= i.lanes | i.childLanes),
          (r |= i.subtreeFlags),
          (r |= i.flags),
          (i.return = e),
          (i = i.sibling));
    return ((e.subtreeFlags |= r), (e.childLanes = n), t);
  }
  function Bf(e, t, n) {
    var r = t.pendingProps;
    switch ((qs(t), t.tag)) {
      case 2:
      case 16:
      case 15:
      case 0:
      case 11:
      case 7:
      case 8:
      case 12:
      case 9:
      case 14:
        return (Je(t), null);
      case 1:
        return (lt(t.type) && xl(), Je(t), null);
      case 3:
        return (
          (r = t.stateNode),
          Zn(),
          Ne(rt),
          Ne(Ye),
          fi(),
          r.pendingContext &&
            ((r.context = r.pendingContext), (r.pendingContext = null)),
          (e === null || e.child === null) &&
            (jl(t)
              ? (t.flags |= 4)
              : e === null ||
                (e.memoizedState.isDehydrated && (t.flags & 256) === 0) ||
                ((t.flags |= 1024), kt !== null && (Wi(kt), (kt = null)))),
          Pi(e, t),
          Je(t),
          null
        );
      case 5:
        ci(t);
        var i = yn(_r.current);
        if (((n = t.type), e !== null && t.stateNode != null))
          (Du(e, t, n, r, i),
            e.ref !== t.ref && ((t.flags |= 512), (t.flags |= 2097152)));
        else {
          if (!r) {
            if (t.stateNode === null) throw Error(a(166));
            return (Je(t), null);
          }
          if (((e = yn(Et.current)), jl(t))) {
            ((r = t.stateNode), (n = t.type));
            var o = t.memoizedProps;
            switch (((r[zt] = t), (r[zr] = o), (e = (t.mode & 1) !== 0), n)) {
              case "dialog":
                (Se("cancel", r), Se("close", r));
                break;
              case "iframe":
              case "object":
              case "embed":
                Se("load", r);
                break;
              case "video":
              case "audio":
                for (i = 0; i < Nr.length; i++) Se(Nr[i], r);
                break;
              case "source":
                Se("error", r);
                break;
              case "img":
              case "image":
              case "link":
                (Se("error", r), Se("load", r));
                break;
              case "details":
                Se("toggle", r);
                break;
              case "input":
                (R(r, o), Se("invalid", r));
                break;
              case "select":
                ((r._wrapperState = { wasMultiple: !!o.multiple }),
                  Se("invalid", r));
                break;
              case "textarea":
                (So(r, o), Se("invalid", r));
            }
            (ds(n, o), (i = null));
            for (var c in o)
              if (o.hasOwnProperty(c)) {
                var p = o[c];
                c === "children"
                  ? typeof p == "string"
                    ? r.textContent !== p &&
                      (o.suppressHydrationWarning !== !0 &&
                        ml(r.textContent, p, e),
                      (i = ["children", p]))
                    : typeof p == "number" &&
                      r.textContent !== "" + p &&
                      (o.suppressHydrationWarning !== !0 &&
                        ml(r.textContent, p, e),
                      (i = ["children", "" + p]))
                  : f.hasOwnProperty(c) &&
                    p != null &&
                    c === "onScroll" &&
                    Se("scroll", r);
              }
            switch (n) {
              case "input":
                (dn(r), Le(r, o, !0));
                break;
              case "textarea":
                (dn(r), Co(r));
                break;
              case "select":
              case "option":
                break;
              default:
                typeof o.onClick == "function" && (r.onclick = hl);
            }
            ((r = i), (t.updateQueue = r), r !== null && (t.flags |= 4));
          } else {
            ((c = i.nodeType === 9 ? i : i.ownerDocument),
              e === "http://www.w3.org/1999/xhtml" && (e = bo(n)),
              e === "http://www.w3.org/1999/xhtml"
                ? n === "script"
                  ? ((e = c.createElement("div")),
                    (e.innerHTML = "<script><\/script>"),
                    (e = e.removeChild(e.firstChild)))
                  : typeof r.is == "string"
                    ? (e = c.createElement(n, { is: r.is }))
                    : ((e = c.createElement(n)),
                      n === "select" &&
                        ((c = e),
                        r.multiple
                          ? (c.multiple = !0)
                          : r.size && (c.size = r.size)))
                : (e = c.createElementNS(e, n)),
              (e[zt] = t),
              (e[zr] = r),
              Fu(e, t, !1, !1),
              (t.stateNode = e));
            e: {
              switch (((c = fs(n, r)), n)) {
                case "dialog":
                  (Se("cancel", e), Se("close", e), (i = r));
                  break;
                case "iframe":
                case "object":
                case "embed":
                  (Se("load", e), (i = r));
                  break;
                case "video":
                case "audio":
                  for (i = 0; i < Nr.length; i++) Se(Nr[i], e);
                  i = r;
                  break;
                case "source":
                  (Se("error", e), (i = r));
                  break;
                case "img":
                case "image":
                case "link":
                  (Se("error", e), Se("load", e), (i = r));
                  break;
                case "details":
                  (Se("toggle", e), (i = r));
                  break;
                case "input":
                  (R(e, r), (i = rr(e, r)), Se("invalid", e));
                  break;
                case "option":
                  i = r;
                  break;
                case "select":
                  ((e._wrapperState = { wasMultiple: !!r.multiple }),
                    (i = A({}, r, { value: void 0 })),
                    Se("invalid", e));
                  break;
                case "textarea":
                  (So(e, r), (i = us(e, r)), Se("invalid", e));
                  break;
                default:
                  i = r;
              }
              (ds(n, i), (p = i));
              for (o in p)
                if (p.hasOwnProperty(o)) {
                  var h = p[o];
                  o === "style"
                    ? Ro(e, h)
                    : o === "dangerouslySetInnerHTML"
                      ? ((h = h ? h.__html : void 0), h != null && zo(e, h))
                      : o === "children"
                        ? typeof h == "string"
                          ? (n !== "textarea" || h !== "") && sr(e, h)
                          : typeof h == "number" && sr(e, "" + h)
                        : o !== "suppressContentEditableWarning" &&
                          o !== "suppressHydrationWarning" &&
                          o !== "autoFocus" &&
                          (f.hasOwnProperty(o)
                            ? h != null && o === "onScroll" && Se("scroll", e)
                            : h != null && Ce(e, o, h, c));
                }
              switch (n) {
                case "input":
                  (dn(e), Le(e, r, !1));
                  break;
                case "textarea":
                  (dn(e), Co(e));
                  break;
                case "option":
                  r.value != null && e.setAttribute("value", "" + ae(r.value));
                  break;
                case "select":
                  ((e.multiple = !!r.multiple),
                    (o = r.value),
                    o != null
                      ? Mn(e, !!r.multiple, o, !1)
                      : r.defaultValue != null &&
                        Mn(e, !!r.multiple, r.defaultValue, !0));
                  break;
                default:
                  typeof i.onClick == "function" && (e.onclick = hl);
              }
              switch (n) {
                case "button":
                case "input":
                case "select":
                case "textarea":
                  r = !!r.autoFocus;
                  break e;
                case "img":
                  r = !0;
                  break e;
                default:
                  r = !1;
              }
            }
            r && (t.flags |= 4);
          }
          t.ref !== null && ((t.flags |= 512), (t.flags |= 2097152));
        }
        return (Je(t), null);
      case 6:
        if (e && t.stateNode != null) Uu(e, t, e.memoizedProps, r);
        else {
          if (typeof r != "string" && t.stateNode === null) throw Error(a(166));
          if (((n = yn(_r.current)), yn(Et.current), jl(t))) {
            if (
              ((r = t.stateNode),
              (n = t.memoizedProps),
              (r[zt] = t),
              (o = r.nodeValue !== n) && ((e = ct), e !== null))
            )
              switch (e.tag) {
                case 3:
                  ml(r.nodeValue, n, (e.mode & 1) !== 0);
                  break;
                case 5:
                  e.memoizedProps.suppressHydrationWarning !== !0 &&
                    ml(r.nodeValue, n, (e.mode & 1) !== 0);
              }
            o && (t.flags |= 4);
          } else
            ((r = (n.nodeType === 9 ? n : n.ownerDocument).createTextNode(r)),
              (r[zt] = t),
              (t.stateNode = r));
        }
        return (Je(t), null);
      case 13:
        if (
          (Ne(ze),
          (r = t.memoizedState),
          e === null ||
            (e.memoizedState !== null && e.memoizedState.dehydrated !== null))
        ) {
          if (be && dt !== null && (t.mode & 1) !== 0 && (t.flags & 128) === 0)
            (Ba(), Hn(), (t.flags |= 98560), (o = !1));
          else if (((o = jl(t)), r !== null && r.dehydrated !== null)) {
            if (e === null) {
              if (!o) throw Error(a(318));
              if (
                ((o = t.memoizedState),
                (o = o !== null ? o.dehydrated : null),
                !o)
              )
                throw Error(a(317));
              o[zt] = t;
            } else
              (Hn(),
                (t.flags & 128) === 0 && (t.memoizedState = null),
                (t.flags |= 4));
            (Je(t), (o = !1));
          } else (kt !== null && (Wi(kt), (kt = null)), (o = !0));
          if (!o) return t.flags & 65536 ? t : null;
        }
        return (t.flags & 128) !== 0
          ? ((t.lanes = n), t)
          : ((r = r !== null),
            r !== (e !== null && e.memoizedState !== null) &&
              r &&
              ((t.child.flags |= 8192),
              (t.mode & 1) !== 0 &&
                (e === null || (ze.current & 1) !== 0
                  ? De === 0 && (De = 3)
                  : Hi())),
            t.updateQueue !== null && (t.flags |= 4),
            Je(t),
            null);
      case 4:
        return (
          Zn(),
          Pi(e, t),
          e === null && Cr(t.stateNode.containerInfo),
          Je(t),
          null
        );
      case 10:
        return (si(t.type._context), Je(t), null);
      case 17:
        return (lt(t.type) && xl(), Je(t), null);
      case 19:
        if ((Ne(ze), (o = t.memoizedState), o === null)) return (Je(t), null);
        if (((r = (t.flags & 128) !== 0), (c = o.rendering), c === null))
          if (r) Or(o, !1);
          else {
            if (De !== 0 || (e !== null && (e.flags & 128) !== 0))
              for (e = t.child; e !== null;) {
                if (((c = El(e)), c !== null)) {
                  for (
                    t.flags |= 128,
                      Or(o, !1),
                      r = c.updateQueue,
                      r !== null && ((t.updateQueue = r), (t.flags |= 4)),
                      t.subtreeFlags = 0,
                      r = n,
                      n = t.child;
                    n !== null;
                  )
                    ((o = n),
                      (e = r),
                      (o.flags &= 14680066),
                      (c = o.alternate),
                      c === null
                        ? ((o.childLanes = 0),
                          (o.lanes = e),
                          (o.child = null),
                          (o.subtreeFlags = 0),
                          (o.memoizedProps = null),
                          (o.memoizedState = null),
                          (o.updateQueue = null),
                          (o.dependencies = null),
                          (o.stateNode = null))
                        : ((o.childLanes = c.childLanes),
                          (o.lanes = c.lanes),
                          (o.child = c.child),
                          (o.subtreeFlags = 0),
                          (o.deletions = null),
                          (o.memoizedProps = c.memoizedProps),
                          (o.memoizedState = c.memoizedState),
                          (o.updateQueue = c.updateQueue),
                          (o.type = c.type),
                          (e = c.dependencies),
                          (o.dependencies =
                            e === null
                              ? null
                              : {
                                  lanes: e.lanes,
                                  firstContext: e.firstContext,
                                })),
                      (n = n.sibling));
                  return (je(ze, (ze.current & 1) | 2), t.child);
                }
                e = e.sibling;
              }
            o.tail !== null &&
              Te() > qn &&
              ((t.flags |= 128), (r = !0), Or(o, !1), (t.lanes = 4194304));
          }
        else {
          if (!r)
            if (((e = El(c)), e !== null)) {
              if (
                ((t.flags |= 128),
                (r = !0),
                (n = e.updateQueue),
                n !== null && ((t.updateQueue = n), (t.flags |= 4)),
                Or(o, !0),
                o.tail === null &&
                  o.tailMode === "hidden" &&
                  !c.alternate &&
                  !be)
              )
                return (Je(t), null);
            } else
              2 * Te() - o.renderingStartTime > qn &&
                n !== 1073741824 &&
                ((t.flags |= 128), (r = !0), Or(o, !1), (t.lanes = 4194304));
          o.isBackwards
            ? ((c.sibling = t.child), (t.child = c))
            : ((n = o.last),
              n !== null ? (n.sibling = c) : (t.child = c),
              (o.last = c));
        }
        return o.tail !== null
          ? ((t = o.tail),
            (o.rendering = t),
            (o.tail = t.sibling),
            (o.renderingStartTime = Te()),
            (t.sibling = null),
            (n = ze.current),
            je(ze, r ? (n & 1) | 2 : n & 1),
            t)
          : (Je(t), null);
      case 22:
      case 23:
        return (
          Vi(),
          (r = t.memoizedState !== null),
          e !== null && (e.memoizedState !== null) !== r && (t.flags |= 8192),
          r && (t.mode & 1) !== 0
            ? (ft & 1073741824) !== 0 &&
              (Je(t), t.subtreeFlags & 6 && (t.flags |= 8192))
            : Je(t),
          null
        );
      case 24:
        return null;
      case 25:
        return null;
    }
    throw Error(a(156, t.tag));
  }
  function Vf(e, t) {
    switch ((qs(t), t.tag)) {
      case 1:
        return (
          lt(t.type) && xl(),
          (e = t.flags),
          e & 65536 ? ((t.flags = (e & -65537) | 128), t) : null
        );
      case 3:
        return (
          Zn(),
          Ne(rt),
          Ne(Ye),
          fi(),
          (e = t.flags),
          (e & 65536) !== 0 && (e & 128) === 0
            ? ((t.flags = (e & -65537) | 128), t)
            : null
        );
      case 5:
        return (ci(t), null);
      case 13:
        if (
          (Ne(ze), (e = t.memoizedState), e !== null && e.dehydrated !== null)
        ) {
          if (t.alternate === null) throw Error(a(340));
          Hn();
        }
        return (
          (e = t.flags),
          e & 65536 ? ((t.flags = (e & -65537) | 128), t) : null
        );
      case 19:
        return (Ne(ze), null);
      case 4:
        return (Zn(), null);
      case 10:
        return (si(t.type._context), null);
      case 22:
      case 23:
        return (Vi(), null);
      case 24:
        return null;
      default:
        return null;
    }
  }
  var Ol = !1,
    qe = !1,
    Hf = typeof WeakSet == "function" ? WeakSet : Set,
    I = null;
  function Xn(e, t) {
    var n = e.ref;
    if (n !== null)
      if (typeof n == "function")
        try {
          n(null);
        } catch (r) {
          Me(e, t, r);
        }
      else n.current = null;
  }
  function _i(e, t, n) {
    try {
      n();
    } catch (r) {
      Me(e, t, r);
    }
  }
  var $u = !1;
  function Qf(e, t) {
    if (((Vs = rl), (e = va()), Is(e))) {
      if ("selectionStart" in e)
        var n = { start: e.selectionStart, end: e.selectionEnd };
      else
        e: {
          n = ((n = e.ownerDocument) && n.defaultView) || window;
          var r = n.getSelection && n.getSelection();
          if (r && r.rangeCount !== 0) {
            n = r.anchorNode;
            var i = r.anchorOffset,
              o = r.focusNode;
            r = r.focusOffset;
            try {
              (n.nodeType, o.nodeType);
            } catch {
              n = null;
              break e;
            }
            var c = 0,
              p = -1,
              h = -1,
              k = 0,
              b = 0,
              z = e,
              C = null;
            t: for (;;) {
              for (
                var T;
                z !== n || (i !== 0 && z.nodeType !== 3) || (p = c + i),
                  z !== o || (r !== 0 && z.nodeType !== 3) || (h = c + r),
                  z.nodeType === 3 && (c += z.nodeValue.length),
                  (T = z.firstChild) !== null;
              )
                ((C = z), (z = T));
              for (;;) {
                if (z === e) break t;
                if (
                  (C === n && ++k === i && (p = c),
                  C === o && ++b === r && (h = c),
                  (T = z.nextSibling) !== null)
                )
                  break;
                ((z = C), (C = z.parentNode));
              }
              z = T;
            }
            n = p === -1 || h === -1 ? null : { start: p, end: h };
          } else n = null;
        }
      n = n || { start: 0, end: 0 };
    } else n = null;
    for (
      Hs = { focusedElem: e, selectionRange: n }, rl = !1, I = t;
      I !== null;
    )
      if (((t = I), (e = t.child), (t.subtreeFlags & 1028) !== 0 && e !== null))
        ((e.return = t), (I = e));
      else
        for (; I !== null;) {
          t = I;
          try {
            var O = t.alternate;
            if ((t.flags & 1024) !== 0)
              switch (t.tag) {
                case 0:
                case 11:
                case 15:
                  break;
                case 1:
                  if (O !== null) {
                    var F = O.memoizedProps,
                      Ae = O.memoizedState,
                      y = t.stateNode,
                      g = y.getSnapshotBeforeUpdate(
                        t.elementType === t.type ? F : jt(t.type, F),
                        Ae,
                      );
                    y.__reactInternalSnapshotBeforeUpdate = g;
                  }
                  break;
                case 3:
                  var w = t.stateNode.containerInfo;
                  w.nodeType === 1
                    ? (w.textContent = "")
                    : w.nodeType === 9 &&
                      w.documentElement &&
                      w.removeChild(w.documentElement);
                  break;
                case 5:
                case 6:
                case 4:
                case 17:
                  break;
                default:
                  throw Error(a(163));
              }
          } catch (M) {
            Me(t, t.return, M);
          }
          if (((e = t.sibling), e !== null)) {
            ((e.return = t.return), (I = e));
            break;
          }
          I = t.return;
        }
    return ((O = $u), ($u = !1), O);
  }
  function Fr(e, t, n) {
    var r = t.updateQueue;
    if (((r = r !== null ? r.lastEffect : null), r !== null)) {
      var i = (r = r.next);
      do {
        if ((i.tag & e) === e) {
          var o = i.destroy;
          ((i.destroy = void 0), o !== void 0 && _i(t, n, o));
        }
        i = i.next;
      } while (i !== r);
    }
  }
  function Fl(e, t) {
    if (
      ((t = t.updateQueue), (t = t !== null ? t.lastEffect : null), t !== null)
    ) {
      var n = (t = t.next);
      do {
        if ((n.tag & e) === e) {
          var r = n.create;
          n.destroy = r();
        }
        n = n.next;
      } while (n !== t);
    }
  }
  function Li(e) {
    var t = e.ref;
    if (t !== null) {
      var n = e.stateNode;
      switch (e.tag) {
        case 5:
          e = n;
          break;
        default:
          e = n;
      }
      typeof t == "function" ? t(e) : (t.current = e);
    }
  }
  function Wu(e) {
    var t = e.alternate;
    (t !== null && ((e.alternate = null), Wu(t)),
      (e.child = null),
      (e.deletions = null),
      (e.sibling = null),
      e.tag === 5 &&
        ((t = e.stateNode),
        t !== null &&
          (delete t[zt],
          delete t[zr],
          delete t[Zs],
          delete t[Ef],
          delete t[Rf])),
      (e.stateNode = null),
      (e.return = null),
      (e.dependencies = null),
      (e.memoizedProps = null),
      (e.memoizedState = null),
      (e.pendingProps = null),
      (e.stateNode = null),
      (e.updateQueue = null));
  }
  function Bu(e) {
    return e.tag === 5 || e.tag === 3 || e.tag === 4;
  }
  function Vu(e) {
    e: for (;;) {
      for (; e.sibling === null;) {
        if (e.return === null || Bu(e.return)) return null;
        e = e.return;
      }
      for (
        e.sibling.return = e.return, e = e.sibling;
        e.tag !== 5 && e.tag !== 6 && e.tag !== 18;
      ) {
        if (e.flags & 2 || e.child === null || e.tag === 4) continue e;
        ((e.child.return = e), (e = e.child));
      }
      if (!(e.flags & 2)) return e.stateNode;
    }
  }
  function Ti(e, t, n) {
    var r = e.tag;
    if (r === 5 || r === 6)
      ((e = e.stateNode),
        t
          ? n.nodeType === 8
            ? n.parentNode.insertBefore(e, t)
            : n.insertBefore(e, t)
          : (n.nodeType === 8
              ? ((t = n.parentNode), t.insertBefore(e, n))
              : ((t = n), t.appendChild(e)),
            (n = n._reactRootContainer),
            n != null || t.onclick !== null || (t.onclick = hl)));
    else if (r !== 4 && ((e = e.child), e !== null))
      for (Ti(e, t, n), e = e.sibling; e !== null;)
        (Ti(e, t, n), (e = e.sibling));
  }
  function Ai(e, t, n) {
    var r = e.tag;
    if (r === 5 || r === 6)
      ((e = e.stateNode), t ? n.insertBefore(e, t) : n.appendChild(e));
    else if (r !== 4 && ((e = e.child), e !== null))
      for (Ai(e, t, n), e = e.sibling; e !== null;)
        (Ai(e, t, n), (e = e.sibling));
  }
  var Qe = null,
    St = !1;
  function tn(e, t, n) {
    for (n = n.child; n !== null;) (Hu(e, t, n), (n = n.sibling));
  }
  function Hu(e, t, n) {
    if (bt && typeof bt.onCommitFiberUnmount == "function")
      try {
        bt.onCommitFiberUnmount(Xr, n);
      } catch {}
    switch (n.tag) {
      case 5:
        qe || Xn(n, t);
      case 6:
        var r = Qe,
          i = St;
        ((Qe = null),
          tn(e, t, n),
          (Qe = r),
          (St = i),
          Qe !== null &&
            (St
              ? ((e = Qe),
                (n = n.stateNode),
                e.nodeType === 8
                  ? e.parentNode.removeChild(n)
                  : e.removeChild(n))
              : Qe.removeChild(n.stateNode)));
        break;
      case 18:
        Qe !== null &&
          (St
            ? ((e = Qe),
              (n = n.stateNode),
              e.nodeType === 8
                ? Ks(e.parentNode, n)
                : e.nodeType === 1 && Ks(e, n),
              gr(e))
            : Ks(Qe, n.stateNode));
        break;
      case 4:
        ((r = Qe),
          (i = St),
          (Qe = n.stateNode.containerInfo),
          (St = !0),
          tn(e, t, n),
          (Qe = r),
          (St = i));
        break;
      case 0:
      case 11:
      case 14:
      case 15:
        if (
          !qe &&
          ((r = n.updateQueue), r !== null && ((r = r.lastEffect), r !== null))
        ) {
          i = r = r.next;
          do {
            var o = i,
              c = o.destroy;
            ((o = o.tag),
              c !== void 0 && ((o & 2) !== 0 || (o & 4) !== 0) && _i(n, t, c),
              (i = i.next));
          } while (i !== r);
        }
        tn(e, t, n);
        break;
      case 1:
        if (
          !qe &&
          (Xn(n, t),
          (r = n.stateNode),
          typeof r.componentWillUnmount == "function")
        )
          try {
            ((r.props = n.memoizedProps),
              (r.state = n.memoizedState),
              r.componentWillUnmount());
          } catch (p) {
            Me(n, t, p);
          }
        tn(e, t, n);
        break;
      case 21:
        tn(e, t, n);
        break;
      case 22:
        n.mode & 1
          ? ((qe = (r = qe) || n.memoizedState !== null), tn(e, t, n), (qe = r))
          : tn(e, t, n);
        break;
      default:
        tn(e, t, n);
    }
  }
  function Qu(e) {
    var t = e.updateQueue;
    if (t !== null) {
      e.updateQueue = null;
      var n = e.stateNode;
      (n === null && (n = e.stateNode = new Hf()),
        t.forEach(function (r) {
          var i = tp.bind(null, e, r);
          n.has(r) || (n.add(r), r.then(i, i));
        }));
    }
  }
  function Nt(e, t) {
    var n = t.deletions;
    if (n !== null)
      for (var r = 0; r < n.length; r++) {
        var i = n[r];
        try {
          var o = e,
            c = t,
            p = c;
          e: for (; p !== null;) {
            switch (p.tag) {
              case 5:
                ((Qe = p.stateNode), (St = !1));
                break e;
              case 3:
                ((Qe = p.stateNode.containerInfo), (St = !0));
                break e;
              case 4:
                ((Qe = p.stateNode.containerInfo), (St = !0));
                break e;
            }
            p = p.return;
          }
          if (Qe === null) throw Error(a(160));
          (Hu(o, c, i), (Qe = null), (St = !1));
          var h = i.alternate;
          (h !== null && (h.return = null), (i.return = null));
        } catch (k) {
          Me(i, t, k);
        }
      }
    if (t.subtreeFlags & 12854)
      for (t = t.child; t !== null;) (Gu(t, e), (t = t.sibling));
  }
  function Gu(e, t) {
    var n = e.alternate,
      r = e.flags;
    switch (e.tag) {
      case 0:
      case 11:
      case 14:
      case 15:
        if ((Nt(t, e), Mt(e), r & 4)) {
          try {
            (Fr(3, e, e.return), Fl(3, e));
          } catch (F) {
            Me(e, e.return, F);
          }
          try {
            Fr(5, e, e.return);
          } catch (F) {
            Me(e, e.return, F);
          }
        }
        break;
      case 1:
        (Nt(t, e), Mt(e), r & 512 && n !== null && Xn(n, n.return));
        break;
      case 5:
        if (
          (Nt(t, e),
          Mt(e),
          r & 512 && n !== null && Xn(n, n.return),
          e.flags & 32)
        ) {
          var i = e.stateNode;
          try {
            sr(i, "");
          } catch (F) {
            Me(e, e.return, F);
          }
        }
        if (r & 4 && ((i = e.stateNode), i != null)) {
          var o = e.memoizedProps,
            c = n !== null ? n.memoizedProps : o,
            p = e.type,
            h = e.updateQueue;
          if (((e.updateQueue = null), h !== null))
            try {
              (p === "input" && o.type === "radio" && o.name != null && Y(i, o),
                fs(p, c));
              var k = fs(p, o);
              for (c = 0; c < h.length; c += 2) {
                var b = h[c],
                  z = h[c + 1];
                b === "style"
                  ? Ro(i, z)
                  : b === "dangerouslySetInnerHTML"
                    ? zo(i, z)
                    : b === "children"
                      ? sr(i, z)
                      : Ce(i, b, z, k);
              }
              switch (p) {
                case "input":
                  K(i, o);
                  break;
                case "textarea":
                  No(i, o);
                  break;
                case "select":
                  var C = i._wrapperState.wasMultiple;
                  i._wrapperState.wasMultiple = !!o.multiple;
                  var T = o.value;
                  T != null
                    ? Mn(i, !!o.multiple, T, !1)
                    : C !== !!o.multiple &&
                      (o.defaultValue != null
                        ? Mn(i, !!o.multiple, o.defaultValue, !0)
                        : Mn(i, !!o.multiple, o.multiple ? [] : "", !1));
              }
              i[zr] = o;
            } catch (F) {
              Me(e, e.return, F);
            }
        }
        break;
      case 6:
        if ((Nt(t, e), Mt(e), r & 4)) {
          if (e.stateNode === null) throw Error(a(162));
          ((i = e.stateNode), (o = e.memoizedProps));
          try {
            i.nodeValue = o;
          } catch (F) {
            Me(e, e.return, F);
          }
        }
        break;
      case 3:
        if (
          (Nt(t, e), Mt(e), r & 4 && n !== null && n.memoizedState.isDehydrated)
        )
          try {
            gr(t.containerInfo);
          } catch (F) {
            Me(e, e.return, F);
          }
        break;
      case 4:
        (Nt(t, e), Mt(e));
        break;
      case 13:
        (Nt(t, e),
          Mt(e),
          (i = e.child),
          i.flags & 8192 &&
            ((o = i.memoizedState !== null),
            (i.stateNode.isHidden = o),
            !o ||
              (i.alternate !== null && i.alternate.memoizedState !== null) ||
              (Fi = Te())),
          r & 4 && Qu(e));
        break;
      case 22:
        if (
          ((b = n !== null && n.memoizedState !== null),
          e.mode & 1 ? ((qe = (k = qe) || b), Nt(t, e), (qe = k)) : Nt(t, e),
          Mt(e),
          r & 8192)
        ) {
          if (
            ((k = e.memoizedState !== null),
            (e.stateNode.isHidden = k) && !b && (e.mode & 1) !== 0)
          )
            for (I = e, b = e.child; b !== null;) {
              for (z = I = b; I !== null;) {
                switch (((C = I), (T = C.child), C.tag)) {
                  case 0:
                  case 11:
                  case 14:
                  case 15:
                    Fr(4, C, C.return);
                    break;
                  case 1:
                    Xn(C, C.return);
                    var O = C.stateNode;
                    if (typeof O.componentWillUnmount == "function") {
                      ((r = C), (n = C.return));
                      try {
                        ((t = r),
                          (O.props = t.memoizedProps),
                          (O.state = t.memoizedState),
                          O.componentWillUnmount());
                      } catch (F) {
                        Me(r, n, F);
                      }
                    }
                    break;
                  case 5:
                    Xn(C, C.return);
                    break;
                  case 22:
                    if (C.memoizedState !== null) {
                      Yu(z);
                      continue;
                    }
                }
                T !== null ? ((T.return = C), (I = T)) : Yu(z);
              }
              b = b.sibling;
            }
          e: for (b = null, z = e; ;) {
            if (z.tag === 5) {
              if (b === null) {
                b = z;
                try {
                  ((i = z.stateNode),
                    k
                      ? ((o = i.style),
                        typeof o.setProperty == "function"
                          ? o.setProperty("display", "none", "important")
                          : (o.display = "none"))
                      : ((p = z.stateNode),
                        (h = z.memoizedProps.style),
                        (c =
                          h != null && h.hasOwnProperty("display")
                            ? h.display
                            : null),
                        (p.style.display = Eo("display", c))));
                } catch (F) {
                  Me(e, e.return, F);
                }
              }
            } else if (z.tag === 6) {
              if (b === null)
                try {
                  z.stateNode.nodeValue = k ? "" : z.memoizedProps;
                } catch (F) {
                  Me(e, e.return, F);
                }
            } else if (
              ((z.tag !== 22 && z.tag !== 23) ||
                z.memoizedState === null ||
                z === e) &&
              z.child !== null
            ) {
              ((z.child.return = z), (z = z.child));
              continue;
            }
            if (z === e) break e;
            for (; z.sibling === null;) {
              if (z.return === null || z.return === e) break e;
              (b === z && (b = null), (z = z.return));
            }
            (b === z && (b = null),
              (z.sibling.return = z.return),
              (z = z.sibling));
          }
        }
        break;
      case 19:
        (Nt(t, e), Mt(e), r & 4 && Qu(e));
        break;
      case 21:
        break;
      default:
        (Nt(t, e), Mt(e));
    }
  }
  function Mt(e) {
    var t = e.flags;
    if (t & 2) {
      try {
        e: {
          for (var n = e.return; n !== null;) {
            if (Bu(n)) {
              var r = n;
              break e;
            }
            n = n.return;
          }
          throw Error(a(160));
        }
        switch (r.tag) {
          case 5:
            var i = r.stateNode;
            r.flags & 32 && (sr(i, ""), (r.flags &= -33));
            var o = Vu(e);
            Ai(e, o, i);
            break;
          case 3:
          case 4:
            var c = r.stateNode.containerInfo,
              p = Vu(e);
            Ti(e, p, c);
            break;
          default:
            throw Error(a(161));
        }
      } catch (h) {
        Me(e, e.return, h);
      }
      e.flags &= -3;
    }
    t & 4096 && (e.flags &= -4097);
  }
  function Gf(e, t, n) {
    ((I = e), Ku(e));
  }
  function Ku(e, t, n) {
    for (var r = (e.mode & 1) !== 0; I !== null;) {
      var i = I,
        o = i.child;
      if (i.tag === 22 && r) {
        var c = i.memoizedState !== null || Ol;
        if (!c) {
          var p = i.alternate,
            h = (p !== null && p.memoizedState !== null) || qe;
          p = Ol;
          var k = qe;
          if (((Ol = c), (qe = h) && !k))
            for (I = i; I !== null;)
              ((c = I),
                (h = c.child),
                c.tag === 22 && c.memoizedState !== null
                  ? Xu(i)
                  : h !== null
                    ? ((h.return = c), (I = h))
                    : Xu(i));
          for (; o !== null;) ((I = o), Ku(o), (o = o.sibling));
          ((I = i), (Ol = p), (qe = k));
        }
        Zu(e);
      } else
        (i.subtreeFlags & 8772) !== 0 && o !== null
          ? ((o.return = i), (I = o))
          : Zu(e);
    }
  }
  function Zu(e) {
    for (; I !== null;) {
      var t = I;
      if ((t.flags & 8772) !== 0) {
        var n = t.alternate;
        try {
          if ((t.flags & 8772) !== 0)
            switch (t.tag) {
              case 0:
              case 11:
              case 15:
                qe || Fl(5, t);
                break;
              case 1:
                var r = t.stateNode;
                if (t.flags & 4 && !qe)
                  if (n === null) r.componentDidMount();
                  else {
                    var i =
                      t.elementType === t.type
                        ? n.memoizedProps
                        : jt(t.type, n.memoizedProps);
                    r.componentDidUpdate(
                      i,
                      n.memoizedState,
                      r.__reactInternalSnapshotBeforeUpdate,
                    );
                  }
                var o = t.updateQueue;
                o !== null && Ya(t, o, r);
                break;
              case 3:
                var c = t.updateQueue;
                if (c !== null) {
                  if (((n = null), t.child !== null))
                    switch (t.child.tag) {
                      case 5:
                        n = t.child.stateNode;
                        break;
                      case 1:
                        n = t.child.stateNode;
                    }
                  Ya(t, c, n);
                }
                break;
              case 5:
                var p = t.stateNode;
                if (n === null && t.flags & 4) {
                  n = p;
                  var h = t.memoizedProps;
                  switch (t.type) {
                    case "button":
                    case "input":
                    case "select":
                    case "textarea":
                      h.autoFocus && n.focus();
                      break;
                    case "img":
                      h.src && (n.src = h.src);
                  }
                }
                break;
              case 6:
                break;
              case 4:
                break;
              case 12:
                break;
              case 13:
                if (t.memoizedState === null) {
                  var k = t.alternate;
                  if (k !== null) {
                    var b = k.memoizedState;
                    if (b !== null) {
                      var z = b.dehydrated;
                      z !== null && gr(z);
                    }
                  }
                }
                break;
              case 19:
              case 17:
              case 21:
              case 22:
              case 23:
              case 25:
                break;
              default:
                throw Error(a(163));
            }
          qe || (t.flags & 512 && Li(t));
        } catch (C) {
          Me(t, t.return, C);
        }
      }
      if (t === e) {
        I = null;
        break;
      }
      if (((n = t.sibling), n !== null)) {
        ((n.return = t.return), (I = n));
        break;
      }
      I = t.return;
    }
  }
  function Yu(e) {
    for (; I !== null;) {
      var t = I;
      if (t === e) {
        I = null;
        break;
      }
      var n = t.sibling;
      if (n !== null) {
        ((n.return = t.return), (I = n));
        break;
      }
      I = t.return;
    }
  }
  function Xu(e) {
    for (; I !== null;) {
      var t = I;
      try {
        switch (t.tag) {
          case 0:
          case 11:
          case 15:
            var n = t.return;
            try {
              Fl(4, t);
            } catch (h) {
              Me(t, n, h);
            }
            break;
          case 1:
            var r = t.stateNode;
            if (typeof r.componentDidMount == "function") {
              var i = t.return;
              try {
                r.componentDidMount();
              } catch (h) {
                Me(t, i, h);
              }
            }
            var o = t.return;
            try {
              Li(t);
            } catch (h) {
              Me(t, o, h);
            }
            break;
          case 5:
            var c = t.return;
            try {
              Li(t);
            } catch (h) {
              Me(t, c, h);
            }
        }
      } catch (h) {
        Me(t, t.return, h);
      }
      if (t === e) {
        I = null;
        break;
      }
      var p = t.sibling;
      if (p !== null) {
        ((p.return = t.return), (I = p));
        break;
      }
      I = t.return;
    }
  }
  var Kf = Math.ceil,
    Dl = J.ReactCurrentDispatcher,
    Ii = J.ReactCurrentOwner,
    xt = J.ReactCurrentBatchConfig,
    se = 0,
    Be = null,
    Oe = null,
    Ge = 0,
    ft = 0,
    Jn = Yt(0),
    De = 0,
    Dr = null,
    wn = 0,
    Ul = 0,
    Oi = 0,
    Ur = null,
    it = null,
    Fi = 0,
    qn = 1 / 0,
    Ft = null,
    $l = !1,
    Di = null,
    nn = null,
    Wl = !1,
    rn = null,
    Bl = 0,
    $r = 0,
    Ui = null,
    Vl = -1,
    Hl = 0;
  function nt() {
    return (se & 6) !== 0 ? Te() : Vl !== -1 ? Vl : (Vl = Te());
  }
  function ln(e) {
    return (e.mode & 1) === 0
      ? 1
      : (se & 2) !== 0 && Ge !== 0
        ? Ge & -Ge
        : Pf.transition !== null
          ? (Hl === 0 && (Hl = Vo()), Hl)
          : ((e = me),
            e !== 0 ||
              ((e = window.event), (e = e === void 0 ? 16 : qo(e.type))),
            e);
  }
  function Ct(e, t, n, r) {
    if (50 < $r) throw (($r = 0), (Ui = null), Error(a(185)));
    (dr(e, n, r),
      ((se & 2) === 0 || e !== Be) &&
        (e === Be && ((se & 2) === 0 && (Ul |= n), De === 4 && sn(e, Ge)),
        ot(e, r),
        n === 1 &&
          se === 0 &&
          (t.mode & 1) === 0 &&
          ((qn = Te() + 500), vl && Jt())));
  }
  function ot(e, t) {
    var n = e.callbackNode;
    Md(e, t);
    var r = el(e, e === Be ? Ge : 0);
    if (r === 0)
      (n !== null && $o(n), (e.callbackNode = null), (e.callbackPriority = 0));
    else if (((t = r & -r), e.callbackPriority !== t)) {
      if ((n != null && $o(n), t === 1))
        (e.tag === 0 ? Mf(qu.bind(null, e)) : Fa(qu.bind(null, e)),
          bf(function () {
            (se & 6) === 0 && Jt();
          }),
          (n = null));
      else {
        switch (Ho(r)) {
          case 1:
            n = vs;
            break;
          case 4:
            n = Wo;
            break;
          case 16:
            n = Yr;
            break;
          case 536870912:
            n = Bo;
            break;
          default:
            n = Yr;
        }
        n = oc(n, Ju.bind(null, e));
      }
      ((e.callbackPriority = t), (e.callbackNode = n));
    }
  }
  function Ju(e, t) {
    if (((Vl = -1), (Hl = 0), (se & 6) !== 0)) throw Error(a(327));
    var n = e.callbackNode;
    if (er() && e.callbackNode !== n) return null;
    var r = el(e, e === Be ? Ge : 0);
    if (r === 0) return null;
    if ((r & 30) !== 0 || (r & e.expiredLanes) !== 0 || t) t = Ql(e, r);
    else {
      t = r;
      var i = se;
      se |= 2;
      var o = tc();
      (Be !== e || Ge !== t) && ((Ft = null), (qn = Te() + 500), jn(e, t));
      do
        try {
          Xf();
          break;
        } catch (p) {
          ec(e, p);
        }
      while (!0);
      (li(),
        (Dl.current = o),
        (se = i),
        Oe !== null ? (t = 0) : ((Be = null), (Ge = 0), (t = De)));
    }
    if (t !== 0) {
      if (
        (t === 2 && ((i = ws(e)), i !== 0 && ((r = i), (t = $i(e, i)))),
        t === 1)
      )
        throw ((n = Dr), jn(e, 0), sn(e, r), ot(e, Te()), n);
      if (t === 6) sn(e, r);
      else {
        if (
          ((i = e.current.alternate),
          (r & 30) === 0 &&
            !Zf(i) &&
            ((t = Ql(e, r)),
            t === 2 && ((o = ws(e)), o !== 0 && ((r = o), (t = $i(e, o)))),
            t === 1))
        )
          throw ((n = Dr), jn(e, 0), sn(e, r), ot(e, Te()), n);
        switch (((e.finishedWork = i), (e.finishedLanes = r), t)) {
          case 0:
          case 1:
            throw Error(a(345));
          case 2:
            Sn(e, it, Ft);
            break;
          case 3:
            if (
              (sn(e, r),
              (r & 130023424) === r && ((t = Fi + 500 - Te()), 10 < t))
            ) {
              if (el(e, 0) !== 0) break;
              if (((i = e.suspendedLanes), (i & r) !== r)) {
                (nt(), (e.pingedLanes |= e.suspendedLanes & i));
                break;
              }
              e.timeoutHandle = Gs(Sn.bind(null, e, it, Ft), t);
              break;
            }
            Sn(e, it, Ft);
            break;
          case 4:
            if ((sn(e, r), (r & 4194240) === r)) break;
            for (t = e.eventTimes, i = -1; 0 < r;) {
              var c = 31 - vt(r);
              ((o = 1 << c), (c = t[c]), c > i && (i = c), (r &= ~o));
            }
            if (
              ((r = i),
              (r = Te() - r),
              (r =
                (120 > r
                  ? 120
                  : 480 > r
                    ? 480
                    : 1080 > r
                      ? 1080
                      : 1920 > r
                        ? 1920
                        : 3e3 > r
                          ? 3e3
                          : 4320 > r
                            ? 4320
                            : 1960 * Kf(r / 1960)) - r),
              10 < r)
            ) {
              e.timeoutHandle = Gs(Sn.bind(null, e, it, Ft), r);
              break;
            }
            Sn(e, it, Ft);
            break;
          case 5:
            Sn(e, it, Ft);
            break;
          default:
            throw Error(a(329));
        }
      }
    }
    return (ot(e, Te()), e.callbackNode === n ? Ju.bind(null, e) : null);
  }
  function $i(e, t) {
    var n = Ur;
    return (
      e.current.memoizedState.isDehydrated && (jn(e, t).flags |= 256),
      (e = Ql(e, t)),
      e !== 2 && ((t = it), (it = n), t !== null && Wi(t)),
      e
    );
  }
  function Wi(e) {
    it === null ? (it = e) : it.push.apply(it, e);
  }
  function Zf(e) {
    for (var t = e; ;) {
      if (t.flags & 16384) {
        var n = t.updateQueue;
        if (n !== null && ((n = n.stores), n !== null))
          for (var r = 0; r < n.length; r++) {
            var i = n[r],
              o = i.getSnapshot;
            i = i.value;
            try {
              if (!wt(o(), i)) return !1;
            } catch {
              return !1;
            }
          }
      }
      if (((n = t.child), t.subtreeFlags & 16384 && n !== null))
        ((n.return = t), (t = n));
      else {
        if (t === e) break;
        for (; t.sibling === null;) {
          if (t.return === null || t.return === e) return !0;
          t = t.return;
        }
        ((t.sibling.return = t.return), (t = t.sibling));
      }
    }
    return !0;
  }
  function sn(e, t) {
    for (
      t &= ~Oi,
        t &= ~Ul,
        e.suspendedLanes |= t,
        e.pingedLanes &= ~t,
        e = e.expirationTimes;
      0 < t;
    ) {
      var n = 31 - vt(t),
        r = 1 << n;
      ((e[n] = -1), (t &= ~r));
    }
  }
  function qu(e) {
    if ((se & 6) !== 0) throw Error(a(327));
    er();
    var t = el(e, 0);
    if ((t & 1) === 0) return (ot(e, Te()), null);
    var n = Ql(e, t);
    if (e.tag !== 0 && n === 2) {
      var r = ws(e);
      r !== 0 && ((t = r), (n = $i(e, r)));
    }
    if (n === 1) throw ((n = Dr), jn(e, 0), sn(e, t), ot(e, Te()), n);
    if (n === 6) throw Error(a(345));
    return (
      (e.finishedWork = e.current.alternate),
      (e.finishedLanes = t),
      Sn(e, it, Ft),
      ot(e, Te()),
      null
    );
  }
  function Bi(e, t) {
    var n = se;
    se |= 1;
    try {
      return e(t);
    } finally {
      ((se = n), se === 0 && ((qn = Te() + 500), vl && Jt()));
    }
  }
  function kn(e) {
    rn !== null && rn.tag === 0 && (se & 6) === 0 && er();
    var t = se;
    se |= 1;
    var n = xt.transition,
      r = me;
    try {
      if (((xt.transition = null), (me = 1), e)) return e();
    } finally {
      ((me = r), (xt.transition = n), (se = t), (se & 6) === 0 && Jt());
    }
  }
  function Vi() {
    ((ft = Jn.current), Ne(Jn));
  }
  function jn(e, t) {
    ((e.finishedWork = null), (e.finishedLanes = 0));
    var n = e.timeoutHandle;
    if ((n !== -1 && ((e.timeoutHandle = -1), Cf(n)), Oe !== null))
      for (n = Oe.return; n !== null;) {
        var r = n;
        switch ((qs(r), r.tag)) {
          case 1:
            ((r = r.type.childContextTypes), r != null && xl());
            break;
          case 3:
            (Zn(), Ne(rt), Ne(Ye), fi());
            break;
          case 5:
            ci(r);
            break;
          case 4:
            Zn();
            break;
          case 13:
            Ne(ze);
            break;
          case 19:
            Ne(ze);
            break;
          case 10:
            si(r.type._context);
            break;
          case 22:
          case 23:
            Vi();
        }
        n = n.return;
      }
    if (
      ((Be = e),
      (Oe = e = on(e.current, null)),
      (Ge = ft = t),
      (De = 0),
      (Dr = null),
      (Oi = Ul = wn = 0),
      (it = Ur = null),
      xn !== null)
    ) {
      for (t = 0; t < xn.length; t++)
        if (((n = xn[t]), (r = n.interleaved), r !== null)) {
          n.interleaved = null;
          var i = r.next,
            o = n.pending;
          if (o !== null) {
            var c = o.next;
            ((o.next = i), (r.next = c));
          }
          n.pending = r;
        }
      xn = null;
    }
    return e;
  }
  function ec(e, t) {
    do {
      var n = Oe;
      try {
        if ((li(), (Rl.current = Ll), Ml)) {
          for (var r = Ee.memoizedState; r !== null;) {
            var i = r.queue;
            (i !== null && (i.pending = null), (r = r.next));
          }
          Ml = !1;
        }
        if (
          ((vn = 0),
          (We = Fe = Ee = null),
          (Lr = !1),
          (Tr = 0),
          (Ii.current = null),
          n === null || n.return === null)
        ) {
          ((De = 1), (Dr = t), (Oe = null));
          break;
        }
        e: {
          var o = e,
            c = n.return,
            p = n,
            h = t;
          if (
            ((t = Ge),
            (p.flags |= 32768),
            h !== null && typeof h == "object" && typeof h.then == "function")
          ) {
            var k = h,
              b = p,
              z = b.tag;
            if ((b.mode & 1) === 0 && (z === 0 || z === 11 || z === 15)) {
              var C = b.alternate;
              C
                ? ((b.updateQueue = C.updateQueue),
                  (b.memoizedState = C.memoizedState),
                  (b.lanes = C.lanes))
                : ((b.updateQueue = null), (b.memoizedState = null));
            }
            var T = Cu(c);
            if (T !== null) {
              ((T.flags &= -257),
                bu(T, c, p, o, t),
                T.mode & 1 && Nu(o, k, t),
                (t = T),
                (h = k));
              var O = t.updateQueue;
              if (O === null) {
                var F = new Set();
                (F.add(h), (t.updateQueue = F));
              } else O.add(h);
              break e;
            } else {
              if ((t & 1) === 0) {
                (Nu(o, k, t), Hi());
                break e;
              }
              h = Error(a(426));
            }
          } else if (be && p.mode & 1) {
            var Ae = Cu(c);
            if (Ae !== null) {
              ((Ae.flags & 65536) === 0 && (Ae.flags |= 256),
                bu(Ae, c, p, o, t),
                ni(Yn(h, p)));
              break e;
            }
          }
          ((o = h = Yn(h, p)),
            De !== 4 && (De = 2),
            Ur === null ? (Ur = [o]) : Ur.push(o),
            (o = c));
          do {
            switch (o.tag) {
              case 3:
                ((o.flags |= 65536), (t &= -t), (o.lanes |= t));
                var y = ju(o, h, t);
                Za(o, y);
                break e;
              case 1:
                p = h;
                var g = o.type,
                  w = o.stateNode;
                if (
                  (o.flags & 128) === 0 &&
                  (typeof g.getDerivedStateFromError == "function" ||
                    (w !== null &&
                      typeof w.componentDidCatch == "function" &&
                      (nn === null || !nn.has(w))))
                ) {
                  ((o.flags |= 65536), (t &= -t), (o.lanes |= t));
                  var M = Su(o, p, t);
                  Za(o, M);
                  break e;
                }
            }
            o = o.return;
          } while (o !== null);
        }
        rc(n);
      } catch (D) {
        ((t = D), Oe === n && n !== null && (Oe = n = n.return));
        continue;
      }
      break;
    } while (!0);
  }
  function tc() {
    var e = Dl.current;
    return ((Dl.current = Ll), e === null ? Ll : e);
  }
  function Hi() {
    ((De === 0 || De === 3 || De === 2) && (De = 4),
      Be === null ||
        ((wn & 268435455) === 0 && (Ul & 268435455) === 0) ||
        sn(Be, Ge));
  }
  function Ql(e, t) {
    var n = se;
    se |= 2;
    var r = tc();
    (Be !== e || Ge !== t) && ((Ft = null), jn(e, t));
    do
      try {
        Yf();
        break;
      } catch (i) {
        ec(e, i);
      }
    while (!0);
    if ((li(), (se = n), (Dl.current = r), Oe !== null)) throw Error(a(261));
    return ((Be = null), (Ge = 0), De);
  }
  function Yf() {
    for (; Oe !== null;) nc(Oe);
  }
  function Xf() {
    for (; Oe !== null && !kd();) nc(Oe);
  }
  function nc(e) {
    var t = ic(e.alternate, e, ft);
    ((e.memoizedProps = e.pendingProps),
      t === null ? rc(e) : (Oe = t),
      (Ii.current = null));
  }
  function rc(e) {
    var t = e;
    do {
      var n = t.alternate;
      if (((e = t.return), (t.flags & 32768) === 0)) {
        if (((n = Bf(n, t, ft)), n !== null)) {
          Oe = n;
          return;
        }
      } else {
        if (((n = Vf(n, t)), n !== null)) {
          ((n.flags &= 32767), (Oe = n));
          return;
        }
        if (e !== null)
          ((e.flags |= 32768), (e.subtreeFlags = 0), (e.deletions = null));
        else {
          ((De = 6), (Oe = null));
          return;
        }
      }
      if (((t = t.sibling), t !== null)) {
        Oe = t;
        return;
      }
      Oe = t = e;
    } while (t !== null);
    De === 0 && (De = 5);
  }
  function Sn(e, t, n) {
    var r = me,
      i = xt.transition;
    try {
      ((xt.transition = null), (me = 1), Jf(e, t, n, r));
    } finally {
      ((xt.transition = i), (me = r));
    }
    return null;
  }
  function Jf(e, t, n, r) {
    do er();
    while (rn !== null);
    if ((se & 6) !== 0) throw Error(a(327));
    n = e.finishedWork;
    var i = e.finishedLanes;
    if (n === null) return null;
    if (((e.finishedWork = null), (e.finishedLanes = 0), n === e.current))
      throw Error(a(177));
    ((e.callbackNode = null), (e.callbackPriority = 0));
    var o = n.lanes | n.childLanes;
    if (
      (Pd(e, o),
      e === Be && ((Oe = Be = null), (Ge = 0)),
      ((n.subtreeFlags & 2064) === 0 && (n.flags & 2064) === 0) ||
        Wl ||
        ((Wl = !0),
        oc(Yr, function () {
          return (er(), null);
        })),
      (o = (n.flags & 15990) !== 0),
      (n.subtreeFlags & 15990) !== 0 || o)
    ) {
      ((o = xt.transition), (xt.transition = null));
      var c = me;
      me = 1;
      var p = se;
      ((se |= 4),
        (Ii.current = null),
        Qf(e, n),
        Gu(n, e),
        yf(Hs),
        (rl = !!Vs),
        (Hs = Vs = null),
        (e.current = n),
        Gf(n),
        jd(),
        (se = p),
        (me = c),
        (xt.transition = o));
    } else e.current = n;
    if (
      (Wl && ((Wl = !1), (rn = e), (Bl = i)),
      (o = e.pendingLanes),
      o === 0 && (nn = null),
      Cd(n.stateNode),
      ot(e, Te()),
      t !== null)
    )
      for (r = e.onRecoverableError, n = 0; n < t.length; n++)
        ((i = t[n]), r(i.value, { componentStack: i.stack, digest: i.digest }));
    if ($l) throw (($l = !1), (e = Di), (Di = null), e);
    return (
      (Bl & 1) !== 0 && e.tag !== 0 && er(),
      (o = e.pendingLanes),
      (o & 1) !== 0 ? (e === Ui ? $r++ : (($r = 0), (Ui = e))) : ($r = 0),
      Jt(),
      null
    );
  }
  function er() {
    if (rn !== null) {
      var e = Ho(Bl),
        t = xt.transition,
        n = me;
      try {
        if (((xt.transition = null), (me = 16 > e ? 16 : e), rn === null))
          var r = !1;
        else {
          if (((e = rn), (rn = null), (Bl = 0), (se & 6) !== 0))
            throw Error(a(331));
          var i = se;
          for (se |= 4, I = e.current; I !== null;) {
            var o = I,
              c = o.child;
            if ((I.flags & 16) !== 0) {
              var p = o.deletions;
              if (p !== null) {
                for (var h = 0; h < p.length; h++) {
                  var k = p[h];
                  for (I = k; I !== null;) {
                    var b = I;
                    switch (b.tag) {
                      case 0:
                      case 11:
                      case 15:
                        Fr(8, b, o);
                    }
                    var z = b.child;
                    if (z !== null) ((z.return = b), (I = z));
                    else
                      for (; I !== null;) {
                        b = I;
                        var C = b.sibling,
                          T = b.return;
                        if ((Wu(b), b === k)) {
                          I = null;
                          break;
                        }
                        if (C !== null) {
                          ((C.return = T), (I = C));
                          break;
                        }
                        I = T;
                      }
                  }
                }
                var O = o.alternate;
                if (O !== null) {
                  var F = O.child;
                  if (F !== null) {
                    O.child = null;
                    do {
                      var Ae = F.sibling;
                      ((F.sibling = null), (F = Ae));
                    } while (F !== null);
                  }
                }
                I = o;
              }
            }
            if ((o.subtreeFlags & 2064) !== 0 && c !== null)
              ((c.return = o), (I = c));
            else
              e: for (; I !== null;) {
                if (((o = I), (o.flags & 2048) !== 0))
                  switch (o.tag) {
                    case 0:
                    case 11:
                    case 15:
                      Fr(9, o, o.return);
                  }
                var y = o.sibling;
                if (y !== null) {
                  ((y.return = o.return), (I = y));
                  break e;
                }
                I = o.return;
              }
          }
          var g = e.current;
          for (I = g; I !== null;) {
            c = I;
            var w = c.child;
            if ((c.subtreeFlags & 2064) !== 0 && w !== null)
              ((w.return = c), (I = w));
            else
              e: for (c = g; I !== null;) {
                if (((p = I), (p.flags & 2048) !== 0))
                  try {
                    switch (p.tag) {
                      case 0:
                      case 11:
                      case 15:
                        Fl(9, p);
                    }
                  } catch (D) {
                    Me(p, p.return, D);
                  }
                if (p === c) {
                  I = null;
                  break e;
                }
                var M = p.sibling;
                if (M !== null) {
                  ((M.return = p.return), (I = M));
                  break e;
                }
                I = p.return;
              }
          }
          if (
            ((se = i),
            Jt(),
            bt && typeof bt.onPostCommitFiberRoot == "function")
          )
            try {
              bt.onPostCommitFiberRoot(Xr, e);
            } catch {}
          r = !0;
        }
        return r;
      } finally {
        ((me = n), (xt.transition = t));
      }
    }
    return !1;
  }
  function lc(e, t, n) {
    ((t = Yn(n, t)),
      (t = ju(e, t, 1)),
      (e = en(e, t, 1)),
      (t = nt()),
      e !== null && (dr(e, 1, t), ot(e, t)));
  }
  function Me(e, t, n) {
    if (e.tag === 3) lc(e, e, n);
    else
      for (; t !== null;) {
        if (t.tag === 3) {
          lc(t, e, n);
          break;
        } else if (t.tag === 1) {
          var r = t.stateNode;
          if (
            typeof t.type.getDerivedStateFromError == "function" ||
            (typeof r.componentDidCatch == "function" &&
              (nn === null || !nn.has(r)))
          ) {
            ((e = Yn(n, e)),
              (e = Su(t, e, 1)),
              (t = en(t, e, 1)),
              (e = nt()),
              t !== null && (dr(t, 1, e), ot(t, e)));
            break;
          }
        }
        t = t.return;
      }
  }
  function qf(e, t, n) {
    var r = e.pingCache;
    (r !== null && r.delete(t),
      (t = nt()),
      (e.pingedLanes |= e.suspendedLanes & n),
      Be === e &&
        (Ge & n) === n &&
        (De === 4 || (De === 3 && (Ge & 130023424) === Ge && 500 > Te() - Fi)
          ? jn(e, 0)
          : (Oi |= n)),
      ot(e, t));
  }
  function sc(e, t) {
    t === 0 &&
      ((e.mode & 1) === 0
        ? (t = 1)
        : ((t = qr), (qr <<= 1), (qr & 130023424) === 0 && (qr = 4194304)));
    var n = nt();
    ((e = At(e, t)), e !== null && (dr(e, t, n), ot(e, n)));
  }
  function ep(e) {
    var t = e.memoizedState,
      n = 0;
    (t !== null && (n = t.retryLane), sc(e, n));
  }
  function tp(e, t) {
    var n = 0;
    switch (e.tag) {
      case 13:
        var r = e.stateNode,
          i = e.memoizedState;
        i !== null && (n = i.retryLane);
        break;
      case 19:
        r = e.stateNode;
        break;
      default:
        throw Error(a(314));
    }
    (r !== null && r.delete(t), sc(e, n));
  }
  var ic;
  ic = function (e, t, n) {
    if (e !== null)
      if (e.memoizedProps !== t.pendingProps || rt.current) st = !0;
      else {
        if ((e.lanes & n) === 0 && (t.flags & 128) === 0)
          return ((st = !1), Wf(e, t, n));
        st = (e.flags & 131072) !== 0;
      }
    else ((st = !1), be && (t.flags & 1048576) !== 0 && Da(t, kl, t.index));
    switch (((t.lanes = 0), t.tag)) {
      case 2:
        var r = t.type;
        (Il(e, t), (e = t.pendingProps));
        var i = Wn(t, Ye.current);
        (Kn(t, n), (i = hi(null, t, r, e, i, n)));
        var o = gi();
        return (
          (t.flags |= 1),
          typeof i == "object" &&
          i !== null &&
          typeof i.render == "function" &&
          i.$$typeof === void 0
            ? ((t.tag = 1),
              (t.memoizedState = null),
              (t.updateQueue = null),
              lt(r) ? ((o = !0), yl(t)) : (o = !1),
              (t.memoizedState =
                i.state !== null && i.state !== void 0 ? i.state : null),
              ai(t),
              (i.updater = Tl),
              (t.stateNode = i),
              (i._reactInternals = t),
              ji(t, r, e, n),
              (t = bi(null, t, r, !0, o, n)))
            : ((t.tag = 0), be && o && Js(t), tt(null, t, i, n), (t = t.child)),
          t
        );
      case 16:
        r = t.elementType;
        e: {
          switch (
            (Il(e, t),
            (e = t.pendingProps),
            (i = r._init),
            (r = i(r._payload)),
            (t.type = r),
            (i = t.tag = rp(r)),
            (e = jt(r, e)),
            i)
          ) {
            case 0:
              t = Ci(null, t, r, e, n);
              break e;
            case 1:
              t = _u(null, t, r, e, n);
              break e;
            case 11:
              t = zu(null, t, r, e, n);
              break e;
            case 14:
              t = Eu(null, t, r, jt(r.type, e), n);
              break e;
          }
          throw Error(a(306, r, ""));
        }
        return t;
      case 0:
        return (
          (r = t.type),
          (i = t.pendingProps),
          (i = t.elementType === r ? i : jt(r, i)),
          Ci(e, t, r, i, n)
        );
      case 1:
        return (
          (r = t.type),
          (i = t.pendingProps),
          (i = t.elementType === r ? i : jt(r, i)),
          _u(e, t, r, i, n)
        );
      case 3:
        e: {
          if ((Lu(t), e === null)) throw Error(a(387));
          ((r = t.pendingProps),
            (o = t.memoizedState),
            (i = o.element),
            Ka(e, t),
            zl(t, r, null, n));
          var c = t.memoizedState;
          if (((r = c.element), o.isDehydrated))
            if (
              ((o = {
                element: r,
                isDehydrated: !1,
                cache: c.cache,
                pendingSuspenseBoundaries: c.pendingSuspenseBoundaries,
                transitions: c.transitions,
              }),
              (t.updateQueue.baseState = o),
              (t.memoizedState = o),
              t.flags & 256)
            ) {
              ((i = Yn(Error(a(423)), t)), (t = Tu(e, t, r, n, i)));
              break e;
            } else if (r !== i) {
              ((i = Yn(Error(a(424)), t)), (t = Tu(e, t, r, n, i)));
              break e;
            } else
              for (
                dt = Zt(t.stateNode.containerInfo.firstChild),
                  ct = t,
                  be = !0,
                  kt = null,
                  n = Qa(t, null, r, n),
                  t.child = n;
                n;
              )
                ((n.flags = (n.flags & -3) | 4096), (n = n.sibling));
          else {
            if ((Hn(), r === i)) {
              t = Ot(e, t, n);
              break e;
            }
            tt(e, t, r, n);
          }
          t = t.child;
        }
        return t;
      case 5:
        return (
          Xa(t),
          e === null && ti(t),
          (r = t.type),
          (i = t.pendingProps),
          (o = e !== null ? e.memoizedProps : null),
          (c = i.children),
          Qs(r, i) ? (c = null) : o !== null && Qs(r, o) && (t.flags |= 32),
          Pu(e, t),
          tt(e, t, c, n),
          t.child
        );
      case 6:
        return (e === null && ti(t), null);
      case 13:
        return Au(e, t, n);
      case 4:
        return (
          ui(t, t.stateNode.containerInfo),
          (r = t.pendingProps),
          e === null ? (t.child = Qn(t, null, r, n)) : tt(e, t, r, n),
          t.child
        );
      case 11:
        return (
          (r = t.type),
          (i = t.pendingProps),
          (i = t.elementType === r ? i : jt(r, i)),
          zu(e, t, r, i, n)
        );
      case 7:
        return (tt(e, t, t.pendingProps, n), t.child);
      case 8:
        return (tt(e, t, t.pendingProps.children, n), t.child);
      case 12:
        return (tt(e, t, t.pendingProps.children, n), t.child);
      case 10:
        e: {
          if (
            ((r = t.type._context),
            (i = t.pendingProps),
            (o = t.memoizedProps),
            (c = i.value),
            je(Nl, r._currentValue),
            (r._currentValue = c),
            o !== null)
          )
            if (wt(o.value, c)) {
              if (o.children === i.children && !rt.current) {
                t = Ot(e, t, n);
                break e;
              }
            } else
              for (o = t.child, o !== null && (o.return = t); o !== null;) {
                var p = o.dependencies;
                if (p !== null) {
                  c = o.child;
                  for (var h = p.firstContext; h !== null;) {
                    if (h.context === r) {
                      if (o.tag === 1) {
                        ((h = It(-1, n & -n)), (h.tag = 2));
                        var k = o.updateQueue;
                        if (k !== null) {
                          k = k.shared;
                          var b = k.pending;
                          (b === null
                            ? (h.next = h)
                            : ((h.next = b.next), (b.next = h)),
                            (k.pending = h));
                        }
                      }
                      ((o.lanes |= n),
                        (h = o.alternate),
                        h !== null && (h.lanes |= n),
                        ii(o.return, n, t),
                        (p.lanes |= n));
                      break;
                    }
                    h = h.next;
                  }
                } else if (o.tag === 10) c = o.type === t.type ? null : o.child;
                else if (o.tag === 18) {
                  if (((c = o.return), c === null)) throw Error(a(341));
                  ((c.lanes |= n),
                    (p = c.alternate),
                    p !== null && (p.lanes |= n),
                    ii(c, n, t),
                    (c = o.sibling));
                } else c = o.child;
                if (c !== null) c.return = o;
                else
                  for (c = o; c !== null;) {
                    if (c === t) {
                      c = null;
                      break;
                    }
                    if (((o = c.sibling), o !== null)) {
                      ((o.return = c.return), (c = o));
                      break;
                    }
                    c = c.return;
                  }
                o = c;
              }
          (tt(e, t, i.children, n), (t = t.child));
        }
        return t;
      case 9:
        return (
          (i = t.type),
          (r = t.pendingProps.children),
          Kn(t, n),
          (i = ht(i)),
          (r = r(i)),
          (t.flags |= 1),
          tt(e, t, r, n),
          t.child
        );
      case 14:
        return (
          (r = t.type),
          (i = jt(r, t.pendingProps)),
          (i = jt(r.type, i)),
          Eu(e, t, r, i, n)
        );
      case 15:
        return Ru(e, t, t.type, t.pendingProps, n);
      case 17:
        return (
          (r = t.type),
          (i = t.pendingProps),
          (i = t.elementType === r ? i : jt(r, i)),
          Il(e, t),
          (t.tag = 1),
          lt(r) ? ((e = !0), yl(t)) : (e = !1),
          Kn(t, n),
          wu(t, r, i),
          ji(t, r, i, n),
          bi(null, t, r, !0, e, n)
        );
      case 19:
        return Ou(e, t, n);
      case 22:
        return Mu(e, t, n);
    }
    throw Error(a(156, t.tag));
  };
  function oc(e, t) {
    return Uo(e, t);
  }
  function np(e, t, n, r) {
    ((this.tag = e),
      (this.key = n),
      (this.sibling =
        this.child =
        this.return =
        this.stateNode =
        this.type =
        this.elementType =
          null),
      (this.index = 0),
      (this.ref = null),
      (this.pendingProps = t),
      (this.dependencies =
        this.memoizedState =
        this.updateQueue =
        this.memoizedProps =
          null),
      (this.mode = r),
      (this.subtreeFlags = this.flags = 0),
      (this.deletions = null),
      (this.childLanes = this.lanes = 0),
      (this.alternate = null));
  }
  function yt(e, t, n, r) {
    return new np(e, t, n, r);
  }
  function Qi(e) {
    return ((e = e.prototype), !(!e || !e.isReactComponent));
  }
  function rp(e) {
    if (typeof e == "function") return Qi(e) ? 1 : 0;
    if (e != null) {
      if (((e = e.$$typeof), e === $e)) return 11;
      if (e === ye) return 14;
    }
    return 2;
  }
  function on(e, t) {
    var n = e.alternate;
    return (
      n === null
        ? ((n = yt(e.tag, t, e.key, e.mode)),
          (n.elementType = e.elementType),
          (n.type = e.type),
          (n.stateNode = e.stateNode),
          (n.alternate = e),
          (e.alternate = n))
        : ((n.pendingProps = t),
          (n.type = e.type),
          (n.flags = 0),
          (n.subtreeFlags = 0),
          (n.deletions = null)),
      (n.flags = e.flags & 14680064),
      (n.childLanes = e.childLanes),
      (n.lanes = e.lanes),
      (n.child = e.child),
      (n.memoizedProps = e.memoizedProps),
      (n.memoizedState = e.memoizedState),
      (n.updateQueue = e.updateQueue),
      (t = e.dependencies),
      (n.dependencies =
        t === null ? null : { lanes: t.lanes, firstContext: t.firstContext }),
      (n.sibling = e.sibling),
      (n.index = e.index),
      (n.ref = e.ref),
      n
    );
  }
  function Gl(e, t, n, r, i, o) {
    var c = 2;
    if (((r = e), typeof e == "function")) Qi(e) && (c = 1);
    else if (typeof e == "string") c = 5;
    else
      e: switch (e) {
        case he:
          return Nn(n.children, i, o, t);
        case de:
          ((c = 8), (i |= 8));
          break;
        case He:
          return (
            (e = yt(12, n, t, i | 2)),
            (e.elementType = He),
            (e.lanes = o),
            e
          );
        case Re:
          return (
            (e = yt(13, n, t, i)),
            (e.elementType = Re),
            (e.lanes = o),
            e
          );
        case pe:
          return (
            (e = yt(19, n, t, i)),
            (e.elementType = pe),
            (e.lanes = o),
            e
          );
        case fe:
          return Kl(n, i, o, t);
        default:
          if (typeof e == "object" && e !== null)
            switch (e.$$typeof) {
              case Ie:
                c = 10;
                break e;
              case _e:
                c = 9;
                break e;
              case $e:
                c = 11;
                break e;
              case ye:
                c = 14;
                break e;
              case we:
                ((c = 16), (r = null));
                break e;
            }
          throw Error(a(130, e == null ? e : typeof e, ""));
      }
    return (
      (t = yt(c, n, t, i)),
      (t.elementType = e),
      (t.type = r),
      (t.lanes = o),
      t
    );
  }
  function Nn(e, t, n, r) {
    return ((e = yt(7, e, r, t)), (e.lanes = n), e);
  }
  function Kl(e, t, n, r) {
    return (
      (e = yt(22, e, r, t)),
      (e.elementType = fe),
      (e.lanes = n),
      (e.stateNode = { isHidden: !1 }),
      e
    );
  }
  function Gi(e, t, n) {
    return ((e = yt(6, e, null, t)), (e.lanes = n), e);
  }
  function Ki(e, t, n) {
    return (
      (t = yt(4, e.children !== null ? e.children : [], e.key, t)),
      (t.lanes = n),
      (t.stateNode = {
        containerInfo: e.containerInfo,
        pendingChildren: null,
        implementation: e.implementation,
      }),
      t
    );
  }
  function lp(e, t, n, r, i) {
    ((this.tag = t),
      (this.containerInfo = e),
      (this.finishedWork =
        this.pingCache =
        this.current =
        this.pendingChildren =
          null),
      (this.timeoutHandle = -1),
      (this.callbackNode = this.pendingContext = this.context = null),
      (this.callbackPriority = 0),
      (this.eventTimes = ks(0)),
      (this.expirationTimes = ks(-1)),
      (this.entangledLanes =
        this.finishedLanes =
        this.mutableReadLanes =
        this.expiredLanes =
        this.pingedLanes =
        this.suspendedLanes =
        this.pendingLanes =
          0),
      (this.entanglements = ks(0)),
      (this.identifierPrefix = r),
      (this.onRecoverableError = i),
      (this.mutableSourceEagerHydrationData = null));
  }
  function Zi(e, t, n, r, i, o, c, p, h) {
    return (
      (e = new lp(e, t, n, p, h)),
      t === 1 ? ((t = 1), o === !0 && (t |= 8)) : (t = 0),
      (o = yt(3, null, null, t)),
      (e.current = o),
      (o.stateNode = e),
      (o.memoizedState = {
        element: r,
        isDehydrated: n,
        cache: null,
        transitions: null,
        pendingSuspenseBoundaries: null,
      }),
      ai(o),
      e
    );
  }
  function sp(e, t, n) {
    var r =
      3 < arguments.length && arguments[3] !== void 0 ? arguments[3] : null;
    return {
      $$typeof: oe,
      key: r == null ? null : "" + r,
      children: e,
      containerInfo: t,
      implementation: n,
    };
  }
  function ac(e) {
    if (!e) return Xt;
    e = e._reactInternals;
    e: {
      if (fn(e) !== e || e.tag !== 1) throw Error(a(170));
      var t = e;
      do {
        switch (t.tag) {
          case 3:
            t = t.stateNode.context;
            break e;
          case 1:
            if (lt(t.type)) {
              t = t.stateNode.__reactInternalMemoizedMergedChildContext;
              break e;
            }
        }
        t = t.return;
      } while (t !== null);
      throw Error(a(171));
    }
    if (e.tag === 1) {
      var n = e.type;
      if (lt(n)) return Ia(e, n, t);
    }
    return t;
  }
  function uc(e, t, n, r, i, o, c, p, h) {
    return (
      (e = Zi(n, r, !0, e, i, o, c, p, h)),
      (e.context = ac(null)),
      (n = e.current),
      (r = nt()),
      (i = ln(n)),
      (o = It(r, i)),
      (o.callback = t ?? null),
      en(n, o, i),
      (e.current.lanes = i),
      dr(e, i, r),
      ot(e, r),
      e
    );
  }
  function Zl(e, t, n, r) {
    var i = t.current,
      o = nt(),
      c = ln(i);
    return (
      (n = ac(n)),
      t.context === null ? (t.context = n) : (t.pendingContext = n),
      (t = It(o, c)),
      (t.payload = { element: e }),
      (r = r === void 0 ? null : r),
      r !== null && (t.callback = r),
      (e = en(i, t, c)),
      e !== null && (Ct(e, i, c, o), bl(e, i, c)),
      c
    );
  }
  function Yl(e) {
    if (((e = e.current), !e.child)) return null;
    switch (e.child.tag) {
      case 5:
        return e.child.stateNode;
      default:
        return e.child.stateNode;
    }
  }
  function cc(e, t) {
    if (((e = e.memoizedState), e !== null && e.dehydrated !== null)) {
      var n = e.retryLane;
      e.retryLane = n !== 0 && n < t ? n : t;
    }
  }
  function Yi(e, t) {
    (cc(e, t), (e = e.alternate) && cc(e, t));
  }
  function ip() {
    return null;
  }
  var dc =
    typeof reportError == "function"
      ? reportError
      : function (e) {
          console.error(e);
        };
  function Xi(e) {
    this._internalRoot = e;
  }
  ((Xl.prototype.render = Xi.prototype.render =
    function (e) {
      var t = this._internalRoot;
      if (t === null) throw Error(a(409));
      Zl(e, t, null, null);
    }),
    (Xl.prototype.unmount = Xi.prototype.unmount =
      function () {
        var e = this._internalRoot;
        if (e !== null) {
          this._internalRoot = null;
          var t = e.containerInfo;
          (kn(function () {
            Zl(null, e, null, null);
          }),
            (t[Pt] = null));
        }
      }));
  function Xl(e) {
    this._internalRoot = e;
  }
  Xl.prototype.unstable_scheduleHydration = function (e) {
    if (e) {
      var t = Ko();
      e = { blockedOn: null, target: e, priority: t };
      for (var n = 0; n < Qt.length && t !== 0 && t < Qt[n].priority; n++);
      (Qt.splice(n, 0, e), n === 0 && Xo(e));
    }
  };
  function Ji(e) {
    return !(!e || (e.nodeType !== 1 && e.nodeType !== 9 && e.nodeType !== 11));
  }
  function Jl(e) {
    return !(
      !e ||
      (e.nodeType !== 1 &&
        e.nodeType !== 9 &&
        e.nodeType !== 11 &&
        (e.nodeType !== 8 || e.nodeValue !== " react-mount-point-unstable "))
    );
  }
  function fc() {}
  function op(e, t, n, r, i) {
    if (i) {
      if (typeof r == "function") {
        var o = r;
        r = function () {
          var k = Yl(c);
          o.call(k);
        };
      }
      var c = uc(t, r, e, 0, null, !1, !1, "", fc);
      return (
        (e._reactRootContainer = c),
        (e[Pt] = c.current),
        Cr(e.nodeType === 8 ? e.parentNode : e),
        kn(),
        c
      );
    }
    for (; (i = e.lastChild);) e.removeChild(i);
    if (typeof r == "function") {
      var p = r;
      r = function () {
        var k = Yl(h);
        p.call(k);
      };
    }
    var h = Zi(e, 0, !1, null, null, !1, !1, "", fc);
    return (
      (e._reactRootContainer = h),
      (e[Pt] = h.current),
      Cr(e.nodeType === 8 ? e.parentNode : e),
      kn(function () {
        Zl(t, h, n, r);
      }),
      h
    );
  }
  function ql(e, t, n, r, i) {
    var o = n._reactRootContainer;
    if (o) {
      var c = o;
      if (typeof i == "function") {
        var p = i;
        i = function () {
          var h = Yl(c);
          p.call(h);
        };
      }
      Zl(t, c, e, i);
    } else c = op(n, t, e, i, r);
    return Yl(c);
  }
  ((Qo = function (e) {
    switch (e.tag) {
      case 3:
        var t = e.stateNode;
        if (t.current.memoizedState.isDehydrated) {
          var n = cr(t.pendingLanes);
          n !== 0 &&
            (js(t, n | 1),
            ot(t, Te()),
            (se & 6) === 0 && ((qn = Te() + 500), Jt()));
        }
        break;
      case 13:
        (kn(function () {
          var r = At(e, 1);
          if (r !== null) {
            var i = nt();
            Ct(r, e, 1, i);
          }
        }),
          Yi(e, 1));
    }
  }),
    (Ss = function (e) {
      if (e.tag === 13) {
        var t = At(e, 134217728);
        if (t !== null) {
          var n = nt();
          Ct(t, e, 134217728, n);
        }
        Yi(e, 134217728);
      }
    }),
    (Go = function (e) {
      if (e.tag === 13) {
        var t = ln(e),
          n = At(e, t);
        if (n !== null) {
          var r = nt();
          Ct(n, e, t, r);
        }
        Yi(e, t);
      }
    }),
    (Ko = function () {
      return me;
    }),
    (Zo = function (e, t) {
      var n = me;
      try {
        return ((me = e), t());
      } finally {
        me = n;
      }
    }),
    (hs = function (e, t, n) {
      switch (t) {
        case "input":
          if ((K(e, n), (t = n.name), n.type === "radio" && t != null)) {
            for (n = e; n.parentNode;) n = n.parentNode;
            for (
              n = n.querySelectorAll(
                "input[name=" + JSON.stringify("" + t) + '][type="radio"]',
              ),
                t = 0;
              t < n.length;
              t++
            ) {
              var r = n[t];
              if (r !== e && r.form === e.form) {
                var i = gl(r);
                if (!i) throw Error(a(90));
                (nr(r), K(r, i));
              }
            }
          }
          break;
        case "textarea":
          No(e, n);
          break;
        case "select":
          ((t = n.value), t != null && Mn(e, !!n.multiple, t, !1));
      }
    }),
    (Lo = Bi),
    (To = kn));
  var ap = { usingClientEntryPoint: !1, Events: [Er, Un, gl, Po, _o, Bi] },
    Wr = {
      findFiberByHostInstance: pn,
      bundleType: 0,
      version: "18.3.1",
      rendererPackageName: "react-dom",
    },
    up = {
      bundleType: Wr.bundleType,
      version: Wr.version,
      rendererPackageName: Wr.rendererPackageName,
      rendererConfig: Wr.rendererConfig,
      overrideHookState: null,
      overrideHookStateDeletePath: null,
      overrideHookStateRenamePath: null,
      overrideProps: null,
      overridePropsDeletePath: null,
      overridePropsRenamePath: null,
      setErrorHandler: null,
      setSuspenseHandler: null,
      scheduleUpdate: null,
      currentDispatcherRef: J.ReactCurrentDispatcher,
      findHostInstanceByFiber: function (e) {
        return ((e = Fo(e)), e === null ? null : e.stateNode);
      },
      findFiberByHostInstance: Wr.findFiberByHostInstance || ip,
      findHostInstancesForRefresh: null,
      scheduleRefresh: null,
      scheduleRoot: null,
      setRefreshHandler: null,
      getCurrentFiber: null,
      reconcilerVersion: "18.3.1-next-f1338f8080-20240426",
    };
  if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u") {
    var es = __REACT_DEVTOOLS_GLOBAL_HOOK__;
    if (!es.isDisabled && es.supportsFiber)
      try {
        ((Xr = es.inject(up)), (bt = es));
      } catch {}
  }
  return (
    (at.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = ap),
    (at.createPortal = function (e, t) {
      var n =
        2 < arguments.length && arguments[2] !== void 0 ? arguments[2] : null;
      if (!Ji(t)) throw Error(a(200));
      return sp(e, t, null, n);
    }),
    (at.createRoot = function (e, t) {
      if (!Ji(e)) throw Error(a(299));
      var n = !1,
        r = "",
        i = dc;
      return (
        t != null &&
          (t.unstable_strictMode === !0 && (n = !0),
          t.identifierPrefix !== void 0 && (r = t.identifierPrefix),
          t.onRecoverableError !== void 0 && (i = t.onRecoverableError)),
        (t = Zi(e, 1, !1, null, null, n, !1, r, i)),
        (e[Pt] = t.current),
        Cr(e.nodeType === 8 ? e.parentNode : e),
        new Xi(t)
      );
    }),
    (at.findDOMNode = function (e) {
      if (e == null) return null;
      if (e.nodeType === 1) return e;
      var t = e._reactInternals;
      if (t === void 0)
        throw typeof e.render == "function"
          ? Error(a(188))
          : ((e = Object.keys(e).join(",")), Error(a(268, e)));
      return ((e = Fo(t)), (e = e === null ? null : e.stateNode), e);
    }),
    (at.flushSync = function (e) {
      return kn(e);
    }),
    (at.hydrate = function (e, t, n) {
      if (!Jl(t)) throw Error(a(200));
      return ql(null, e, t, !0, n);
    }),
    (at.hydrateRoot = function (e, t, n) {
      if (!Ji(e)) throw Error(a(405));
      var r = (n != null && n.hydratedSources) || null,
        i = !1,
        o = "",
        c = dc;
      if (
        (n != null &&
          (n.unstable_strictMode === !0 && (i = !0),
          n.identifierPrefix !== void 0 && (o = n.identifierPrefix),
          n.onRecoverableError !== void 0 && (c = n.onRecoverableError)),
        (t = uc(t, null, e, 1, n ?? null, i, !1, o, c)),
        (e[Pt] = t.current),
        Cr(e),
        r)
      )
        for (e = 0; e < r.length; e++)
          ((n = r[e]),
            (i = n._getVersion),
            (i = i(n._source)),
            t.mutableSourceEagerHydrationData == null
              ? (t.mutableSourceEagerHydrationData = [n, i])
              : t.mutableSourceEagerHydrationData.push(n, i));
      return new Xl(t);
    }),
    (at.render = function (e, t, n) {
      if (!Jl(t)) throw Error(a(200));
      return ql(null, e, t, !1, n);
    }),
    (at.unmountComponentAtNode = function (e) {
      if (!Jl(e)) throw Error(a(40));
      return e._reactRootContainer
        ? (kn(function () {
            ql(null, null, e, !1, function () {
              ((e._reactRootContainer = null), (e[Pt] = null));
            });
          }),
          !0)
        : !1;
    }),
    (at.unstable_batchedUpdates = Bi),
    (at.unstable_renderSubtreeIntoContainer = function (e, t, n, r) {
      if (!Jl(n)) throw Error(a(200));
      if (e == null || e._reactInternals === void 0) throw Error(a(38));
      return ql(e, t, n, !1, r);
    }),
    (at.version = "18.3.1-next-f1338f8080-20240426"),
    at
  );
}
var wc;
function yp() {
  if (wc) return to.exports;
  wc = 1;
  function l() {
    if (!(
      typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > "u" ||
      typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != "function"
    ))
      try {
        __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(l);
      } catch (u) {
        console.error(u);
      }
  }
  return (l(), (to.exports = xp()), to.exports);
}
var kc;
function vp() {
  if (kc) return ts;
  kc = 1;
  var l = yp();
  return ((ts.createRoot = l.createRoot), (ts.hydrateRoot = l.hydrateRoot), ts);
}
var wp = vp();
const kp = Uc(wp),
  jp = 3600 * 12,
  go = "comp_school_local_development_session",
  Sp = "https://comp.school/fallback",
  cn = "comp.school",
  Np = /^(preview-[a-z0-9-]+)(?:\.[a-z0-9-]+)?\.comp\.school$/i,
  Cp = /^(preview-[a-z0-9-]+)\.[a-z0-9-]+\.pages\.dev$/i,
  bp = Object.freeze({
    "comp.school": 3e3,
    "code.comp.school": 3001,
    "admin.comp.school": 3002,
    "exams.comp.school": 3010,
    "recall.comp.school": 3011,
    "forms.comp.school": 3012,
    "mark.comp.school": 3013,
    "games.comp.school": 3014,
    "self-assess.comp.school": 3015,
    "issues.comp.school": 3016,
    "printouts.comp.school": 3017,
    "docs.comp.school": 3018,
  });
function xo(l) {
  const u = l
    .trim()
    .toLowerCase()
    .replace(/^\[|\]$/g, "");
  return u === "localhost" || u === "127.0.0.1" || u === "::1";
}
function zp(l) {
  return [
    `${go}=${encodeURIComponent(JSON.stringify({ version: 1, user: l }))}`,
    "Path=/",
    `Max-Age=${jp}`,
    "SameSite=Lax",
  ].join("; ");
}
function Ep() {
  return [`${go}=`, "Path=/", "Max-Age=0", "SameSite=Lax"].join("; ");
}
function $c(l, u, a) {
  if (!a || !xo(u)) return null;
  const d = Op(l)[go];
  if (!d) return null;
  try {
    const f = JSON.parse(d),
      m = f.user;
    return f.version !== 1 ||
      !m ||
      typeof m.id != "string" ||
      typeof m.name != "string" ||
      !["admin", "teacher", "student"].includes(m.role)
      ? null
      : m;
  } catch {
    return null;
  }
}
function Rp(l) {
  return btoa(l).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}
function Mp(l) {
  let u = "";
  for (const a of l) u += String.fromCharCode(a);
  return Rp(u);
}
function Pp(l) {
  if (!l || !/^[A-Za-z0-9_-]+$/.test(l))
    throw new Error("Invalid base64url value");
  const u = l
      .replace(/-/g, "+")
      .replace(/_/g, "/")
      .padEnd(Math.ceil(l.length / 4) * 4, "="),
    a = atob(u),
    d = new Uint8Array(a.length);
  for (let f = 0; f < a.length; f += 1) d[f] = a.charCodeAt(f);
  if (Mp(d) !== l) throw new Error("Non-canonical base64url value");
  return d;
}
function _p(l) {
  const u = Pp(l);
  return new TextDecoder("utf-8", { fatal: !0 }).decode(u);
}
function Lp(l) {
  return !!l && typeof l == "object" && !Array.isArray(l);
}
function Tp(l) {
  const u = JSON.parse(l);
  if (!Lp(u)) throw new Error("Expected a JSON object");
  return u;
}
function Wc(l) {
  const u = l.trim().toLowerCase();
  return (u.match(Np) || u.match(Cp))?.[1] || null;
}
function Bc(l) {
  if (xo(l))
    return `http://${l.replace(/^\[|\]$/g, "") === "::1" ? "[::1]" : l}:3000`;
  const u = Wc(l);
  return u ? `https://${u}.${cn}` : `https://${cn}`;
}
function Vc(l, u) {
  if (xo(l))
    try {
      const d = new URL(u),
        f = bp[d.hostname.toLowerCase()];
      if (f)
        return (
          (d.protocol = "http:"),
          (d.hostname = l),
          (d.port = String(f)),
          d.toString()
        );
    } catch {
      return u;
    }
  const a = Wc(l);
  if (!a) return u;
  try {
    const d = new URL(u),
      f = d.hostname.toLowerCase();
    if (f === cn || f.endsWith(`.${cn}`))
      return (
        (d.hostname = f === cn ? `${a}.${cn}` : `${a}.${f}`),
        d.toString()
      );
  } catch {
    return u;
  }
  return u;
}
function Ap(l) {
  if (!l?.trim()) return null;
  try {
    const u = new URL(l),
      a = u.hostname.toLowerCase();
    return u.protocol !== "https:" ||
      u.username ||
      u.password ||
      u.port ||
      a === cn ||
      !a.endsWith(`.${cn}`)
      ? null
      : u.toString();
  } catch {
    return null;
  }
}
function Ip(l, u, a) {
  const d = a?.trim() || Bc(l),
    f = Ap(Vc(l, u));
  if (!f) return d;
  try {
    const m = new URL(d);
    return (m.searchParams.set("returnTo", f), m.toString());
  } catch {
    return d;
  }
}
function Op(l) {
  return l
    ? l.split(";").reduce((u, a) => {
        const [d, ...f] = a.trim().split("=");
        if (!d) return u;
        const m = f.join("=");
        try {
          u[d] = decodeURIComponent(m);
        } catch {
          u[d] = m;
        }
        return u;
      }, {})
    : {};
}
function jc(l, u = new Date()) {
  if (!l) return !1;
  try {
    const [a] = l.split("."),
      d = Tp(_p(a));
    return (
      d.iss === Sp &&
      typeof d.exp == "number" &&
      Number.isInteger(d.exp) &&
      d.exp > Math.floor(u.getTime() / 1e3)
    );
  } catch {
    return !1;
  }
}
const Sc = 64,
  Nc = { x: 9, y: 12, width: 46, height: 44, rx: 13 },
  ne = "#1f2937",
  Ue = "#ffffff",
  Pe = 33,
  Ut = 24,
  $t = 40,
  Cc = new Set(["shell"]);
function os(l) {
  return l.detail || l.shade;
}
function Fp(l) {
  const { shade: u, accent: a } = l,
    d = os(l);
  switch (l.ears) {
    case "pointed":
      return s.jsxs("g", {
        children: [
          s.jsx("path", { d: "M11 26 17 3 30 17Z", fill: u }),
          s.jsx("path", { d: "M53 26 47 3 34 17Z", fill: u }),
          s.jsx("path", { d: "M16.5 22 19 9.5 26 17Z", fill: a }),
          s.jsx("path", { d: "M47.5 22 45 9.5 38 17Z", fill: a }),
        ],
      });
    case "round":
      return s.jsxs("g", {
        children: [
          s.jsx("circle", { cx: "17", cy: "14", r: "8.5", fill: u }),
          s.jsx("circle", { cx: "47", cy: "14", r: "8.5", fill: u }),
          s.jsx("circle", { cx: "17", cy: "14", r: "4", fill: a }),
          s.jsx("circle", { cx: "47", cy: "14", r: "4", fill: a }),
        ],
      });
    case "tall":
      return s.jsxs("g", {
        children: [
          s.jsxs("g", {
            transform: "rotate(-9 20.5 9)",
            children: [
              s.jsx("rect", {
                x: "15",
                y: "-5",
                width: "11",
                height: "27",
                rx: "5.5",
                fill: u,
              }),
              s.jsx("rect", {
                x: "18",
                y: "0",
                width: "5",
                height: "18",
                rx: "2.5",
                fill: a,
              }),
            ],
          }),
          s.jsxs("g", {
            transform: "rotate(9 43.5 9)",
            children: [
              s.jsx("rect", {
                x: "38",
                y: "-5",
                width: "11",
                height: "27",
                rx: "5.5",
                fill: u,
              }),
              s.jsx("rect", {
                x: "41",
                y: "0",
                width: "5",
                height: "18",
                rx: "2.5",
                fill: a,
              }),
            ],
          }),
        ],
      });
    case "floppy":
      return s.jsxs("g", {
        fill: u,
        children: [
          s.jsx("path", { d: "M15 16C5 18 3 34 9 41c5 4 9-2 9-11Z" }),
          s.jsx("path", { d: "M49 16c10 2 12 18 6 25-5 4-9-2-9-11Z" }),
        ],
      });
    case "tuft":
      return s.jsxs("g", {
        fill: u,
        children: [
          s.jsx("path", { d: "M12 19 15.5 5 24 15.5Z" }),
          s.jsx("path", { d: "M52 19 48.5 5 40 15.5Z" }),
        ],
      });
    case "horns":
      return s.jsxs("g", {
        fill: d,
        children: [
          s.jsx("path", {
            d: "M17.5 13C10 11 6 5 10.5 1.5c2.5 3.5 6.5 6.5 10.5 8.5Z",
          }),
          s.jsx("path", {
            d: "M46.5 13C54 11 58 5 53.5 1.5c-2.5 3.5-6.5 6.5-10.5 8.5Z",
          }),
        ],
      });
    case "antlers":
      return s.jsxs("g", {
        stroke: d,
        strokeWidth: "3",
        strokeLinecap: "round",
        fill: "none",
        children: [
          s.jsx("path", { d: "M21 14 16 3" }),
          s.jsx("path", { d: "M17.6 8 10 5" }),
          s.jsx("path", { d: "M43 14 48 3" }),
          s.jsx("path", { d: "M46.4 8 54 5" }),
        ],
      });
    case "flap":
      return s.jsxs("g", {
        children: [
          s.jsx("ellipse", { cx: "10", cy: "32", rx: "10", ry: "15", fill: u }),
          s.jsx("ellipse", { cx: "54", cy: "32", rx: "10", ry: "15", fill: u }),
          s.jsx("ellipse", { cx: "11", cy: "32", rx: "5", ry: "9", fill: a }),
          s.jsx("ellipse", { cx: "53", cy: "32", rx: "5", ry: "9", fill: a }),
        ],
      });
    case "spikes":
      return s.jsx("path", {
        d: "M8 22 13 3 20 18 26 1 32 17 38 1 44 18 51 3 56 22Z",
        fill: u,
      });
    case "crest":
      return s.jsxs("g", {
        fill: d,
        children: [
          s.jsx("circle", { cx: "25", cy: "10", r: "5" }),
          s.jsx("circle", { cx: "32", cy: "5.5", r: "5.5" }),
          s.jsx("circle", { cx: "39", cy: "10", r: "5" }),
        ],
      });
    case "fins":
      return s.jsxs("g", {
        fill: u,
        children: [
          s.jsx("path", { d: "M12 26 1 19 4 37Z" }),
          s.jsx("path", { d: "M52 26 63 19 60 37Z" }),
          s.jsx("path", { d: "M25 13 32 1 39 13Z" }),
        ],
      });
    case "antennae":
      return s.jsxs("g", {
        children: [
          s.jsxs("g", {
            stroke: u,
            strokeWidth: "2.6",
            strokeLinecap: "round",
            fill: "none",
            children: [
              s.jsx("path", { d: "M23 14C20 7 17 4 13.5 3" }),
              s.jsx("path", { d: "M41 14c3-7 6-10 9.5-11" }),
            ],
          }),
          s.jsx("circle", { cx: "12.5", cy: "3", r: "3", fill: u }),
          s.jsx("circle", { cx: "51.5", cy: "3", r: "3", fill: u }),
        ],
      });
    case "mane":
      return s.jsx("g", {
        fill: d,
        children: Array.from({ length: 12 }, (f, m) => {
          const v = (m / 12) * Math.PI * 2;
          return s.jsx(
            "circle",
            { cx: 32 + Math.cos(v) * 25, cy: 34 + Math.sin(v) * 23, r: "8.5" },
            m,
          );
        }),
      });
    case "wool":
      return s.jsxs("g", {
        fill: a,
        children: [
          s.jsx("circle", { cx: "15", cy: "17", r: "8" }),
          s.jsx("circle", { cx: "26", cy: "10", r: "9" }),
          s.jsx("circle", { cx: "38", cy: "10", r: "9" }),
          s.jsx("circle", { cx: "49", cy: "17", r: "8" }),
        ],
      });
    case "wings":
      return s.jsxs("g", {
        fill: d,
        children: [
          s.jsx("path", { d: "M13 22C-1 16 0 42 12 46Z" }),
          s.jsx("path", { d: "M51 22c14-6 13 20 1 24Z" }),
        ],
      });
    case "tentacles":
      return s.jsxs("g", {
        fill: u,
        children: [
          s.jsx("path", { d: "M12 44c-6 4-8 12-6 18 4 1 7-5 9-11Z" }),
          s.jsx("path", { d: "M52 44c6 4 8 12 6 18-4 1-7-5-9-11Z" }),
          s.jsx("path", { d: "M25 50c-3 6-3 12-1 14 3 0 5-6 5-12Z" }),
          s.jsx("path", { d: "M39 50c3 6 3 12 1 14-3 0-5-6-5-12Z" }),
        ],
      });
    case "dome":
      return s.jsx("path", { d: "M11 22a21 21 0 0 1 42 0Z", fill: u });
    case "frill":
      return s.jsxs("g", {
        children: [
          s.jsx("path", { d: "M1 42C1 16 14 1 32 1s31 15 31 41Z", fill: u }),
          s.jsx("g", {
            fill: a,
            children: Array.from({ length: 9 }, (f, m) => {
              const v = Math.PI + (m + 0.5) * (Math.PI / 9);
              return s.jsx(
                "circle",
                {
                  cx: 32 + Math.cos(v) * 27,
                  cy: 40 + Math.sin(v) * 33,
                  r: "3.2",
                },
                m,
              );
            }),
          }),
        ],
      });
    case "rays":
      return s.jsx("g", {
        fill: d,
        children: Array.from({ length: 12 }, (f, m) => {
          const v = (m / 12) * 360;
          return s.jsx(
            "path",
            { d: "M32 2 27 12h10Z", transform: `rotate(${v} 32 34)` },
            m,
          );
        }),
      });
    case "points":
      return s.jsxs("g", {
        fill: u,
        children: [
          s.jsx("path", { d: "M32 0 24 16h16Z" }),
          s.jsx("path", { d: "M6 14 12 30l12-9Z" }),
          s.jsx("path", { d: "M58 14 52 30l-12-9Z" }),
          s.jsx("path", { d: "M8 56 4 42l14 4Z" }),
          s.jsx("path", { d: "M56 56l4-14-14 4Z" }),
        ],
      });
    case "none":
    default:
      return null;
  }
}
function Dp(l) {
  const { base: u, shade: a } = l,
    d = os(l);
  switch (l.eyes) {
    case "round":
      return s.jsxs("g", {
        children: [
          s.jsx("circle", { cx: Ut, cy: Pe, r: "6.5", fill: Ue }),
          s.jsx("circle", { cx: $t, cy: Pe, r: "6.5", fill: Ue }),
          s.jsx("circle", { cx: Ut, cy: Pe, r: "3.4", fill: ne }),
          s.jsx("circle", { cx: $t, cy: Pe, r: "3.4", fill: ne }),
          s.jsx("circle", { cx: Ut + 1.4, cy: Pe - 1.6, r: "1.3", fill: Ue }),
          s.jsx("circle", { cx: $t + 1.4, cy: Pe - 1.6, r: "1.3", fill: Ue }),
        ],
      });
    case "big":
      return s.jsxs("g", {
        children: [
          s.jsx("circle", { cx: "23", cy: "32", r: "9.5", fill: Ue }),
          s.jsx("circle", { cx: "41", cy: "32", r: "9.5", fill: Ue }),
          s.jsx("circle", { cx: "23", cy: "32", r: "5", fill: ne }),
          s.jsx("circle", { cx: "41", cy: "32", r: "5", fill: ne }),
          s.jsx("circle", { cx: "24.6", cy: "30.2", r: "1.9", fill: Ue }),
          s.jsx("circle", { cx: "42.6", cy: "30.2", r: "1.9", fill: Ue }),
        ],
      });
    case "bulge":
      return s.jsxs("g", {
        children: [
          s.jsx("circle", {
            cx: "20",
            cy: "14",
            r: "9",
            fill: u,
            stroke: a,
            strokeWidth: "1.6",
          }),
          s.jsx("circle", {
            cx: "44",
            cy: "14",
            r: "9",
            fill: u,
            stroke: a,
            strokeWidth: "1.6",
          }),
          s.jsx("circle", { cx: "20", cy: "13.5", r: "4.8", fill: Ue }),
          s.jsx("circle", { cx: "44", cy: "13.5", r: "4.8", fill: Ue }),
          s.jsx("circle", { cx: "20", cy: "13.5", r: "2.6", fill: ne }),
          s.jsx("circle", { cx: "44", cy: "13.5", r: "2.6", fill: ne }),
        ],
      });
    case "slit":
      return s.jsxs("g", {
        children: [
          s.jsx("ellipse", { cx: Ut, cy: Pe, rx: "5.4", ry: "6", fill: d }),
          s.jsx("ellipse", { cx: $t, cy: Pe, rx: "5.4", ry: "6", fill: d }),
          s.jsx("ellipse", { cx: Ut, cy: Pe, rx: "1.8", ry: "5", fill: ne }),
          s.jsx("ellipse", { cx: $t, cy: Pe, rx: "1.8", ry: "5", fill: ne }),
        ],
      });
    case "sleepy":
      return s.jsxs("g", {
        stroke: ne,
        strokeWidth: "3",
        strokeLinecap: "round",
        fill: "none",
        children: [
          s.jsx("path", { d: "M18.5 31.5q5.5 5 11 0" }),
          s.jsx("path", { d: "M34.5 31.5q5.5 5 11 0" }),
        ],
      });
    case "wide":
      return s.jsxs("g", {
        children: [
          s.jsx("circle", { cx: "20", cy: Pe, r: "3.8", fill: ne }),
          s.jsx("circle", { cx: "44", cy: Pe, r: "3.8", fill: ne }),
          s.jsx("circle", { cx: "21.3", cy: Pe - 1.4, r: "1.3", fill: Ue }),
          s.jsx("circle", { cx: "45.3", cy: Pe - 1.4, r: "1.3", fill: Ue }),
        ],
      });
    case "turret":
      return s.jsxs("g", {
        children: [
          s.jsx("circle", { cx: "21", cy: "31", r: "7.5", fill: a }),
          s.jsx("circle", { cx: "43", cy: "31", r: "7.5", fill: a }),
          s.jsx("circle", { cx: "21", cy: "31", r: "3.6", fill: d }),
          s.jsx("circle", { cx: "43", cy: "31", r: "3.6", fill: d }),
          s.jsx("circle", { cx: "21", cy: "31", r: "1.7", fill: ne }),
          s.jsx("circle", { cx: "43", cy: "31", r: "1.7", fill: ne }),
        ],
      });
    case "compound":
      return s.jsxs("g", {
        children: [
          s.jsx("ellipse", {
            cx: "22",
            cy: "31",
            rx: "7.5",
            ry: "9",
            fill: ne,
            transform: "rotate(-12 22 31)",
          }),
          s.jsx("ellipse", {
            cx: "42",
            cy: "31",
            rx: "7.5",
            ry: "9",
            fill: ne,
            transform: "rotate(12 42 31)",
          }),
          s.jsx("ellipse", {
            cx: "20.5",
            cy: "28",
            rx: "2.2",
            ry: "3",
            fill: Ue,
            opacity: "0.75",
          }),
          s.jsx("ellipse", {
            cx: "43.5",
            cy: "28",
            rx: "2.2",
            ry: "3",
            fill: Ue,
            opacity: "0.75",
          }),
        ],
      });
    case "stalk":
      return s.jsxs("g", {
        children: [
          s.jsxs("g", {
            stroke: a,
            strokeWidth: "2.8",
            strokeLinecap: "round",
            fill: "none",
            children: [
              s.jsx("path", { d: "M23 16 19.5 5" }),
              s.jsx("path", { d: "M41 16 44.5 5" }),
            ],
          }),
          s.jsx("circle", {
            cx: "19",
            cy: "4",
            r: "3.8",
            fill: Ue,
            stroke: a,
            strokeWidth: "1.2",
          }),
          s.jsx("circle", {
            cx: "45",
            cy: "4",
            r: "3.8",
            fill: Ue,
            stroke: a,
            strokeWidth: "1.2",
          }),
          s.jsx("circle", { cx: "19", cy: "4", r: "1.8", fill: ne }),
          s.jsx("circle", { cx: "45", cy: "4", r: "1.8", fill: ne }),
        ],
      });
    case "visor":
      return s.jsxs("g", {
        children: [
          s.jsx("rect", {
            x: "14",
            y: "26.5",
            width: "36",
            height: "13",
            rx: "6.5",
            fill: ne,
          }),
          s.jsx("circle", { cx: Ut, cy: Pe, r: "3.2", fill: d }),
          s.jsx("circle", { cx: $t, cy: Pe, r: "3.2", fill: d }),
        ],
      });
    case "dot":
    default:
      return s.jsxs("g", {
        children: [
          s.jsx("circle", { cx: Ut, cy: Pe, r: "4.2", fill: ne }),
          s.jsx("circle", { cx: $t, cy: Pe, r: "4.2", fill: ne }),
          s.jsx("circle", { cx: Ut + 1.4, cy: Pe - 1.5, r: "1.4", fill: Ue }),
          s.jsx("circle", { cx: $t + 1.4, cy: Pe - 1.5, r: "1.4", fill: Ue }),
        ],
      });
  }
}
function bc() {
  return s.jsxs("g", {
    children: [
      s.jsx("path", { d: "M27.5 39q4.5-3.4 9 0Q32 44.6 27.5 39Z", fill: ne }),
      s.jsx("path", {
        d: "M32 43.5v2.4M32 45.9q-2.4 2.6-4.6.4M32 45.9q2.4 2.6 4.6.4",
        stroke: ne,
        strokeWidth: "2",
        strokeLinecap: "round",
        fill: "none",
      }),
    ],
  });
}
function Up(l) {
  const { accent: u, shade: a } = l,
    d = os(l);
  switch (l.muzzle) {
    case "nose":
      return bc();
    case "snout":
      return s.jsxs("g", {
        children: [
          s.jsx("ellipse", { cx: "32", cy: "43", rx: "13", ry: "9", fill: u }),
          bc(),
        ],
      });
    case "beak":
      return s.jsxs("g", {
        children: [
          s.jsx("path", { d: "M23 38h18l-9 11Z", fill: d }),
          s.jsx("path", {
            d: "M23 38h18",
            stroke: ne,
            strokeWidth: "1.4",
            opacity: "0.35",
          }),
        ],
      });
    case "bill":
      return s.jsxs("g", {
        children: [
          s.jsx("rect", {
            x: "19",
            y: "37.5",
            width: "26",
            height: "11.5",
            rx: "5.75",
            fill: d,
          }),
          s.jsx("circle", { cx: "26", cy: "41.5", r: "1.3", fill: ne }),
          s.jsx("circle", { cx: "38", cy: "41.5", r: "1.3", fill: ne }),
        ],
      });
    case "pig":
      return s.jsxs("g", {
        children: [
          s.jsx("ellipse", { cx: "32", cy: "43", rx: "11", ry: "8", fill: u }),
          s.jsx("ellipse", {
            cx: "28",
            cy: "43",
            rx: "2.2",
            ry: "3",
            fill: ne,
          }),
          s.jsx("ellipse", {
            cx: "36",
            cy: "43",
            rx: "2.2",
            ry: "3",
            fill: ne,
          }),
        ],
      });
    case "wide":
      return s.jsx("path", {
        d: "M16 41q16 11 32 0",
        stroke: ne,
        strokeWidth: "3",
        strokeLinecap: "round",
        fill: "none",
      });
    case "tusks":
      return s.jsxs("g", {
        children: [
          s.jsx("ellipse", {
            cx: "32",
            cy: "42",
            rx: "13",
            ry: "8.5",
            fill: u,
          }),
          s.jsx("ellipse", {
            cx: "32",
            cy: "38.5",
            rx: "3.4",
            ry: "2.6",
            fill: ne,
          }),
          s.jsx("path", {
            d: "M27 45q-1.6 8-3.6 12M37 45q1.6 8 3.6 12",
            stroke: "#f8fafc",
            strokeWidth: "3.6",
            strokeLinecap: "round",
            fill: "none",
          }),
        ],
      });
    case "trunk":
      return s.jsx("path", {
        d: "M32 36q0 10-3 14t2 10",
        stroke: a,
        strokeWidth: "7.5",
        strokeLinecap: "round",
        fill: "none",
      });
    case "mandibles":
      return s.jsxs("g", {
        stroke: ne,
        strokeWidth: "2.6",
        strokeLinecap: "round",
        fill: "none",
        children: [
          s.jsx("path", { d: "M26 43q6 6 12 0" }),
          s.jsx("path", { d: "M24.5 41q-3.5 4.5 0 8" }),
          s.jsx("path", { d: "M39.5 41q3.5 4.5 0 8" }),
        ],
      });
    case "grill":
      return s.jsxs("g", {
        children: [
          s.jsx("rect", {
            x: "23",
            y: "41",
            width: "18",
            height: "8",
            rx: "4",
            fill: ne,
          }),
          s.jsx("path", {
            d: "M28 41v8M32 41v8M36 41v8",
            stroke: d,
            strokeWidth: "1.4",
            opacity: "0.8",
          }),
        ],
      });
    case "smile":
    default:
      return s.jsx("path", {
        d: "M26.5 42.5q5.5 5 11 0",
        stroke: ne,
        strokeWidth: "2.8",
        strokeLinecap: "round",
        fill: "none",
      });
  }
}
function lo(l, u, a) {
  const { shade: d, accent: f } = u,
    m = os(u);
  switch (l) {
    case "mask":
      return s.jsxs(
        "g",
        {
          clipPath: `url(#${a})`,
          fill: d,
          children: [
            s.jsx("ellipse", { cx: Ut, cy: Pe - 0.5, rx: "9", ry: "8.5" }),
            s.jsx("ellipse", { cx: $t, cy: Pe - 0.5, rx: "9", ry: "8.5" }),
          ],
        },
        l,
      );
    case "stripes":
      return s.jsxs(
        "g",
        {
          clipPath: `url(#${a})`,
          stroke: d,
          strokeWidth: "3.4",
          strokeLinecap: "round",
          fill: "none",
          children: [
            s.jsx("path", { d: "M19 11q3 8-2 14" }),
            s.jsx("path", { d: "M32 10v10" }),
            s.jsx("path", { d: "M45 11q-3 8 2 14" }),
          ],
        },
        l,
      );
    case "spots":
      return s.jsxs(
        "g",
        {
          clipPath: `url(#${a})`,
          fill: d,
          opacity: "0.8",
          children: [
            s.jsx("circle", { cx: "16", cy: "24", r: "4" }),
            s.jsx("circle", { cx: "48", cy: "24", r: "4" }),
            s.jsx("circle", { cx: "14", cy: "42", r: "3.4" }),
            s.jsx("circle", { cx: "50", cy: "42", r: "3.4" }),
            s.jsx("circle", { cx: "32", cy: "18", r: "3.4" }),
          ],
        },
        l,
      );
    case "blush":
      return s.jsxs(
        "g",
        {
          clipPath: `url(#${a})`,
          fill: "#f87171",
          opacity: "0.35",
          children: [
            s.jsx("ellipse", { cx: "15", cy: "40", rx: "5.5", ry: "3.6" }),
            s.jsx("ellipse", { cx: "49", cy: "40", rx: "5.5", ry: "3.6" }),
          ],
        },
        l,
      );
    case "patch":
      return s.jsx(
        "g",
        {
          clipPath: `url(#${a})`,
          children: s.jsx("rect", {
            x: "15",
            y: "37",
            width: "34",
            height: "21",
            rx: "11",
            fill: f,
            opacity: "0.9",
          }),
        },
        l,
      );
    case "whiskers":
      return s.jsx(
        "g",
        {
          stroke: ne,
          strokeWidth: "1.7",
          strokeLinecap: "round",
          opacity: "0.65",
          fill: "none",
          children: s.jsx("path", {
            d: "M18 40 6 37M18 43.5 6 44M46 40l12-3M46 43.5l12 .5",
          }),
        },
        l,
      );
    case "brows":
      return s.jsxs(
        "g",
        {
          stroke: ne,
          strokeWidth: "3",
          strokeLinecap: "round",
          fill: "none",
          children: [
            s.jsx("path", { d: "M17.5 24.5 29 28.5" }),
            s.jsx("path", { d: "M46.5 24.5 35 28.5" }),
          ],
        },
        l,
      );
    case "horn":
      return s.jsxs(
        "g",
        {
          children: [
            s.jsx("path", { d: "M28 15 32-2l4 17Z", fill: m }),
            s.jsx("path", {
              d: "M29.4 10.5h5.2M30.4 6h3.2",
              stroke: ne,
              strokeWidth: "1.3",
              opacity: "0.35",
            }),
          ],
        },
        l,
      );
    case "tongue":
      return s.jsx("path", { d: "M28.5 45q3.5 9 7 0Z", fill: "#f472b6" }, l);
    case "fangs":
      return s.jsxs(
        "g",
        {
          fill: Ue,
          children: [
            s.jsx("path", { d: "M26.5 42 29 48l2.5-6Z" }),
            s.jsx("path", { d: "M32.5 42 35 48l2.5-6Z" }),
          ],
        },
        l,
      );
    case "sparkle":
      return s.jsxs(
        "g",
        {
          fill: m,
          children: [
            s.jsx("path", {
              d: "M53 8 54.4 12 58 13.4 54.4 14.8 53 18.6 51.6 14.8 48 13.4 51.6 12Z",
            }),
            s.jsx("path", {
              d: "M10 44 11 47 14 48 11 49 10 52 9 49 6 48 9 47Z",
            }),
          ],
        },
        l,
      );
    case "crown":
      return s.jsxs(
        "g",
        {
          children: [
            s.jsx("path", {
              d: "M19 13 23 3l5 6 5-8 5 8 5-6 4 10Z",
              fill: "#fbbf24",
            }),
            s.jsx("circle", { cx: "32", cy: "6", r: "1.8", fill: "#fde68a" }),
          ],
        },
        l,
      );
    case "shell":
      return s.jsxs(
        "g",
        {
          children: [
            s.jsx("path", { d: "M0 61q0-27 32-27t32 27Z", fill: m }),
            s.jsxs("g", {
              fill: d,
              opacity: "0.55",
              children: [
                s.jsx("circle", { cx: "5.5", cy: "52", r: "3" }),
                s.jsx("circle", { cx: "58.5", cy: "52", r: "3" }),
                s.jsx("circle", { cx: "20", cy: "59", r: "3" }),
                s.jsx("circle", { cx: "44", cy: "59", r: "3" }),
                s.jsx("circle", { cx: "32", cy: "60", r: "3" }),
              ],
            }),
          ],
        },
        l,
      );
    case "stitches":
      return s.jsxs(
        "g",
        {
          clipPath: `url(#${a})`,
          stroke: d,
          strokeWidth: "1.8",
          strokeLinecap: "round",
          children: [
            s.jsx("path", { d: "M45 12v14" }),
            s.jsx("path", { d: "M41.5 16h7M41.5 21h7" }),
            s.jsx("path", { d: "M14 44h9" }),
            s.jsx("path", { d: "M17 41.5v5M21 41.5v5" }),
          ],
        },
        l,
      );
    case "bolt":
      return s.jsx(
        "path",
        { d: "M49 2 39 18h6l-8 14 20-20h-7l6-10Z", fill: m },
        l,
      );
    case "bandage":
      return s.jsxs(
        "g",
        {
          clipPath: `url(#${a})`,
          fill: f,
          opacity: "0.9",
          children: [
            s.jsx("path", { d: "M2 20 62 12v7L2 27Z" }),
            s.jsx("path", { d: "M2 44 62 36v7L2 51Z" }),
            s.jsx("path", { d: "M6 56 58 48v6H6Z" }),
          ],
        },
        l,
      );
    case "visorGlow":
      return s.jsx(
        "g",
        {
          opacity: "0.75",
          children: s.jsx("path", {
            d: "M18 27q14-6 28 0",
            stroke: m,
            strokeWidth: "2",
            fill: "none",
            strokeLinecap: "round",
          }),
        },
        l,
      );
    default:
      return null;
  }
}
function $p({ features: l, idSuffix: u, className: a, title: d }) {
  const f = `cs-avatar-head-${u}`,
    m = l.marks || [],
    v = m.filter((j) => Cc.has(j)),
    E = m.filter((j) => !Cc.has(j));
  return s.jsxs("svg", {
    className: a,
    viewBox: `0 0 ${Sc} ${Sc}`,
    width: "100%",
    height: "100%",
    role: d ? "img" : "presentation",
    "aria-label": d,
    "aria-hidden": d ? void 0 : !0,
    focusable: "false",
    children: [
      s.jsx("defs", {
        children: s.jsx("clipPath", {
          id: f,
          children: s.jsx("rect", { ...Nc }),
        }),
      }),
      v.map((j) => lo(j, l, f)),
      Fp(l),
      s.jsx("rect", { ...Nc, fill: l.base }),
      E.filter(
        (j) =>
          j === "mask" ||
          j === "stripes" ||
          j === "spots" ||
          j === "patch" ||
          j === "bandage",
      ).map((j) => lo(j, l, f)),
      Up(l),
      Dp(l),
      E.filter(
        (j) =>
          !(
            j === "mask" ||
            j === "stripes" ||
            j === "spots" ||
            j === "patch" ||
            j === "bandage"
          ),
      ).map((j) => lo(j, l, f)),
    ],
  });
}
const Wp = {
  rust: ["#ef8043", "#cd5f27", "#ffe0c6"],
  amber: ["#f0993f", "#cb7220", "#ffe8cd"],
  brown: ["#a97551", "#7d5133", "#f2ddc8"],
  cocoa: ["#8b5e3c", "#5d3c23", "#ebd6c1"],
  sand: ["#e6c48b", "#c39a55", "#fdf1da"],
  cream: ["#f3e3c3", "#d6b988", "#fff8ea"],
  grey: ["#9aa8bb", "#6b7c93", "#e6edf5"],
  slate: ["#7c8ba1", "#4f5d74", "#dde5ef"],
  charcoal: ["#4d5765", "#2e3641", "#c6cedb"],
  snow: ["#eef3f9", "#c0cbd9", "#ffffff"],
  pink: ["#f5a6ba", "#da7c92", "#ffe4ec"],
  rose: ["#ef8ba2", "#cd6079", "#ffdde5"],
  green: ["#5fba70", "#3d9350", "#d9f2dd"],
  moss: ["#7fbc5a", "#5d9639", "#e4f5d5"],
  lime: ["#95cf57", "#6da733", "#eafada"],
  teal: ["#42b5a8", "#2a8a80", "#d3f1ed"],
  blue: ["#5c9cd6", "#3c74a7", "#dceaf8"],
  sky: ["#7cc4ef", "#4d9acb", "#e3f3fd"],
  navy: ["#41628f", "#2b4568", "#d0dcec"],
  yellow: ["#f3c552", "#d09c2c", "#fff3d0"],
  gold: ["#e9aa3c", "#c1811d", "#ffeecb"],
  purple: ["#a68bf5", "#7c5cef", "#e9e3ff"],
  violet: ["#8a6fd4", "#63499f", "#e0d8f6"],
  red: ["#e15c4f", "#b73e33", "#fbdad5"],
  stone: ["#98a0a8", "#6a737c", "#dfe4e8"],
};
function S(l, u, a, d, f) {
  const [m, v, E] = Wp[d];
  return { id: l, label: u, group: a, base: m, shade: v, accent: E, ...f };
}
const Bp = Object.freeze([
    S("fox", "Fox", "woodland", "rust", {
      ears: "pointed",
      eyes: "round",
      muzzle: "snout",
      marks: ["whiskers"],
    }),
    S("owl", "Owl", "woodland", "cocoa", {
      ears: "tuft",
      eyes: "big",
      muzzle: "beak",
      detail: "#f3c552",
    }),
    S("bear", "Bear", "woodland", "brown", {
      ears: "round",
      eyes: "dot",
      muzzle: "snout",
    }),
    S("panda", "Panda", "woodland", "snow", {
      ears: "round",
      eyes: "dot",
      muzzle: "snout",
      marks: ["mask"],
      shade: "#39414d",
    }),
    S("wolf", "Wolf", "woodland", "slate", {
      ears: "pointed",
      eyes: "round",
      muzzle: "snout",
    }),
    S("badger", "Badger", "woodland", "snow", {
      ears: "round",
      eyes: "dot",
      muzzle: "snout",
      marks: ["mask"],
      shade: "#3b4553",
    }),
    S("hedgehog", "Hedgehog", "woodland", "sand", {
      ears: "spikes",
      eyes: "dot",
      muzzle: "nose",
    }),
    S("squirrel", "Squirrel", "woodland", "amber", {
      ears: "tuft",
      eyes: "round",
      muzzle: "nose",
      marks: ["patch"],
    }),
    S("deer", "Deer", "woodland", "sand", {
      ears: "antlers",
      eyes: "round",
      muzzle: "snout",
      marks: ["spots"],
      detail: "#8b5e3c",
    }),
    S("raccoon", "Raccoon", "woodland", "grey", {
      ears: "round",
      eyes: "dot",
      muzzle: "snout",
      marks: ["mask"],
      shade: "#3e4756",
    }),
    S("cat", "Cat", "pets", "amber", {
      ears: "pointed",
      eyes: "slit",
      muzzle: "nose",
      marks: ["stripes", "whiskers"],
      detail: "#5fba70",
    }),
    S("dog", "Dog", "pets", "brown", {
      ears: "floppy",
      eyes: "round",
      muzzle: "snout",
    }),
    S("rabbit", "Rabbit", "pets", "cream", {
      ears: "tall",
      eyes: "round",
      muzzle: "nose",
      marks: ["blush"],
    }),
    S("hamster", "Hamster", "pets", "sand", {
      ears: "round",
      eyes: "dot",
      muzzle: "nose",
      marks: ["patch", "blush"],
    }),
    S("guineapig", "Guinea pig", "pets", "cocoa", {
      ears: "round",
      eyes: "dot",
      muzzle: "nose",
      marks: ["patch"],
    }),
    S("ferret", "Ferret", "pets", "cream", {
      ears: "round",
      eyes: "dot",
      muzzle: "nose",
      marks: ["mask"],
      shade: "#a97551",
    }),
    S("budgie", "Budgie", "pets", "lime", {
      ears: "crest",
      eyes: "dot",
      muzzle: "beak",
      marks: ["blush"],
      detail: "#f3c552",
    }),
    S("goldfish", "Goldfish", "pets", "gold", {
      ears: "fins",
      eyes: "wide",
      muzzle: "smile",
    }),
    S("pony", "Pony", "pets", "sand", {
      ears: "pointed",
      eyes: "round",
      muzzle: "snout",
      marks: ["patch"],
    }),
    S("mouse", "Mouse", "pets", "grey", {
      ears: "round",
      eyes: "dot",
      muzzle: "nose",
      marks: ["whiskers", "blush"],
    }),
    S("cow", "Cow", "farm", "snow", {
      ears: "horns",
      eyes: "round",
      muzzle: "pig",
      marks: ["spots"],
      shade: "#39414d",
      detail: "#e6c48b",
    }),
    S("pig", "Pig", "farm", "pink", {
      ears: "floppy",
      eyes: "dot",
      muzzle: "pig",
      marks: ["blush"],
    }),
    S("sheep", "Sheep", "farm", "cream", {
      ears: "wool",
      eyes: "dot",
      muzzle: "nose",
    }),
    S("goat", "Goat", "farm", "cream", {
      ears: "horns",
      eyes: "slit",
      muzzle: "nose",
      marks: ["patch"],
      detail: "#a97551",
    }),
    S("horse", "Horse", "farm", "cocoa", {
      ears: "pointed",
      eyes: "round",
      muzzle: "snout",
      marks: ["patch"],
    }),
    S("donkey", "Donkey", "farm", "grey", {
      ears: "tall",
      eyes: "sleepy",
      muzzle: "snout",
    }),
    S("chicken", "Chicken", "farm", "snow", {
      ears: "crest",
      eyes: "dot",
      muzzle: "beak",
      detail: "#e15c4f",
    }),
    S("duck", "Duck", "farm", "yellow", {
      ears: "none",
      eyes: "dot",
      muzzle: "bill",
      detail: "#f0993f",
    }),
    S("goose", "Goose", "farm", "snow", {
      ears: "none",
      eyes: "dot",
      muzzle: "bill",
      detail: "#f0993f",
    }),
    S("bull", "Bull", "farm", "charcoal", {
      ears: "horns",
      eyes: "round",
      muzzle: "pig",
      marks: ["brows"],
      detail: "#e6c48b",
    }),
    S("lion", "Lion", "savanna", "gold", {
      ears: "mane",
      eyes: "round",
      muzzle: "snout",
      marks: ["whiskers"],
      detail: "#b9762a",
    }),
    S("tiger", "Tiger", "savanna", "amber", {
      ears: "pointed",
      eyes: "round",
      muzzle: "snout",
      marks: ["stripes", "whiskers"],
      shade: "#8a4a17",
    }),
    S("elephant", "Elephant", "savanna", "grey", {
      ears: "flap",
      eyes: "dot",
      muzzle: "trunk",
    }),
    S("giraffe", "Giraffe", "savanna", "sand", {
      ears: "horns",
      eyes: "round",
      muzzle: "snout",
      marks: ["spots"],
      detail: "#8b5e3c",
    }),
    S("zebra", "Zebra", "savanna", "snow", {
      ears: "round",
      eyes: "round",
      muzzle: "snout",
      marks: ["stripes"],
      shade: "#39414d",
    }),
    S("rhino", "Rhino", "savanna", "stone", {
      ears: "round",
      eyes: "dot",
      muzzle: "pig",
      marks: ["horn"],
      detail: "#dfe4e8",
    }),
    S("hippo", "Hippo", "savanna", "violet", {
      ears: "round",
      eyes: "wide",
      muzzle: "pig",
    }),
    S("cheetah", "Cheetah", "savanna", "sand", {
      ears: "round",
      eyes: "round",
      muzzle: "nose",
      marks: ["spots", "whiskers"],
    }),
    S("meerkat", "Meerkat", "savanna", "cream", {
      ears: "round",
      eyes: "dot",
      muzzle: "nose",
      marks: ["mask"],
      shade: "#8b5e3c",
    }),
    S("monkey", "Monkey", "savanna", "cocoa", {
      ears: "round",
      eyes: "round",
      muzzle: "snout",
      marks: ["patch"],
    }),
    S("polarbear", "Polar bear", "polar", "snow", {
      ears: "round",
      eyes: "dot",
      muzzle: "snout",
    }),
    S("penguin", "Penguin", "polar", "charcoal", {
      ears: "none",
      eyes: "round",
      muzzle: "beak",
      marks: ["patch"],
      accent: "#ffffff",
      detail: "#f0993f",
    }),
    S("seal", "Seal", "polar", "slate", {
      ears: "none",
      eyes: "sleepy",
      muzzle: "nose",
      marks: ["whiskers"],
    }),
    S("arcticfox", "Arctic fox", "polar", "snow", {
      ears: "pointed",
      eyes: "round",
      muzzle: "snout",
      marks: ["whiskers"],
    }),
    S("snowleopard", "Snow leopard", "polar", "snow", {
      ears: "tuft",
      eyes: "slit",
      muzzle: "nose",
      marks: ["spots", "whiskers"],
      detail: "#5fba70",
    }),
    S("walrus", "Walrus", "polar", "brown", {
      ears: "none",
      eyes: "dot",
      muzzle: "tusks",
      marks: ["whiskers"],
    }),
    S("reindeer", "Reindeer", "polar", "cocoa", {
      ears: "antlers",
      eyes: "round",
      muzzle: "snout",
      detail: "#c39a55",
    }),
    S("husky", "Husky", "polar", "slate", {
      ears: "pointed",
      eyes: "slit",
      muzzle: "snout",
      marks: ["mask"],
      detail: "#7cc4ef",
    }),
    S("puffin", "Puffin", "polar", "charcoal", {
      ears: "none",
      eyes: "dot",
      muzzle: "beak",
      marks: ["patch"],
      accent: "#ffffff",
      detail: "#f0993f",
    }),
    S("yak", "Yak", "polar", "cocoa", {
      ears: "horns",
      eyes: "sleepy",
      muzzle: "nose",
      marks: ["patch"],
      detail: "#e6c48b",
    }),
    S("whale", "Whale", "ocean", "navy", {
      ears: "fins",
      eyes: "wide",
      muzzle: "smile",
      marks: ["patch"],
    }),
    S("dolphin", "Dolphin", "ocean", "sky", {
      ears: "fins",
      eyes: "dot",
      muzzle: "smile",
      marks: ["patch"],
    }),
    S("shark", "Shark", "ocean", "slate", {
      ears: "fins",
      eyes: "round",
      muzzle: "wide",
      marks: ["brows", "fangs"],
    }),
    S("octopus", "Octopus", "ocean", "purple", {
      ears: "tentacles",
      eyes: "round",
      muzzle: "smile",
    }),
    S("crab", "Crab", "ocean", "red", {
      ears: "none",
      eyes: "stalk",
      muzzle: "mandibles",
    }),
    S("jellyfish", "Jellyfish", "ocean", "rose", {
      ears: "tentacles",
      eyes: "dot",
      muzzle: "smile",
    }),
    S("seahorse", "Seahorse", "ocean", "yellow", {
      ears: "crest",
      eyes: "wide",
      muzzle: "beak",
      detail: "#d09c2c",
    }),
    S("pufferfish", "Pufferfish", "ocean", "amber", {
      ears: "spikes",
      eyes: "wide",
      muzzle: "smile",
    }),
    S("narwhal", "Narwhal", "ocean", "sky", {
      ears: "fins",
      eyes: "dot",
      muzzle: "smile",
      marks: ["horn"],
      detail: "#eef3f9",
    }),
    S("otter", "Otter", "ocean", "brown", {
      ears: "round",
      eyes: "round",
      muzzle: "snout",
      marks: ["whiskers"],
    }),
    S("frog", "Frog", "creatures", "green", {
      ears: "none",
      eyes: "bulge",
      muzzle: "wide",
      marks: ["tongue"],
    }),
    S("turtle", "Turtle", "creatures", "moss", {
      ears: "none",
      eyes: "round",
      muzzle: "smile",
      marks: ["shell"],
      detail: "#3f7a2a",
    }),
    S("gecko", "Gecko", "creatures", "lime", {
      ears: "none",
      eyes: "round",
      muzzle: "smile",
      marks: ["spots"],
    }),
    S("chameleon", "Chameleon", "creatures", "teal", {
      ears: "crest",
      eyes: "turret",
      muzzle: "smile",
      marks: ["spots"],
      detail: "#f3c552",
    }),
    S("snake", "Snake", "creatures", "moss", {
      ears: "none",
      eyes: "slit",
      muzzle: "smile",
      marks: ["stripes"],
      detail: "#f3c552",
    }),
    S("crocodile", "Crocodile", "creatures", "green", {
      ears: "none",
      eyes: "wide",
      muzzle: "wide",
      marks: ["brows", "fangs"],
    }),
    S("bee", "Bee", "creatures", "yellow", {
      ears: "antennae",
      eyes: "compound",
      muzzle: "mandibles",
      marks: ["stripes"],
      shade: "#39414d",
    }),
    S("ladybird", "Ladybird", "creatures", "red", {
      ears: "antennae",
      eyes: "dot",
      muzzle: "smile",
      marks: ["spots"],
      shade: "#39414d",
    }),
    S("butterfly", "Butterfly", "creatures", "purple", {
      ears: "wings",
      eyes: "compound",
      muzzle: "smile",
      marks: ["sparkle"],
      detail: "#f3c552",
    }),
    S("snail", "Snail", "creatures", "cream", {
      ears: "none",
      eyes: "stalk",
      muzzle: "smile",
      marks: ["shell"],
      detail: "#c39a55",
    }),
    S("dragon", "Dragon", "mythical", "green", {
      ears: "spikes",
      eyes: "slit",
      muzzle: "wide",
      marks: ["fangs", "brows"],
      detail: "#f3c552",
    }),
    S("unicorn", "Unicorn", "mythical", "snow", {
      ears: "pointed",
      eyes: "round",
      muzzle: "snout",
      marks: ["horn", "sparkle"],
      detail: "#a68bf5",
    }),
    S("phoenix", "Phoenix", "mythical", "red", {
      ears: "crest",
      eyes: "round",
      muzzle: "beak",
      marks: ["sparkle"],
      detail: "#f3c552",
    }),
    S("griffin", "Griffin", "mythical", "gold", {
      ears: "wings",
      eyes: "big",
      muzzle: "beak",
      marks: ["brows"],
      detail: "#c1811d",
    }),
    S("yeti", "Yeti", "mythical", "snow", {
      ears: "wool",
      eyes: "round",
      muzzle: "snout",
      marks: ["fangs"],
      accent: "#dcecfb",
    }),
    S("pegasus", "Pegasus", "mythical", "snow", {
      ears: "wings",
      eyes: "round",
      muzzle: "snout",
      marks: ["sparkle"],
      detail: "#7cc4ef",
    }),
    S("kraken", "Kraken", "mythical", "violet", {
      ears: "tentacles",
      eyes: "slit",
      muzzle: "smile",
      marks: ["brows"],
      detail: "#42b5a8",
    }),
    S("sphinx", "Sphinx", "mythical", "sand", {
      ears: "pointed",
      eyes: "round",
      muzzle: "nose",
      marks: ["crown"],
    }),
    S("wyvern", "Wyvern", "mythical", "red", {
      ears: "wings",
      eyes: "slit",
      muzzle: "wide",
      marks: ["horn", "fangs"],
      detail: "#f3c552",
    }),
    S("golem", "Golem", "mythical", "stone", {
      ears: "dome",
      eyes: "visor",
      muzzle: "grill",
      marks: ["sparkle"],
      detail: "#7cc4ef",
    }),
    S("trex", "T. rex", "dinosaurs", "moss", {
      ears: "none",
      eyes: "slit",
      muzzle: "wide",
      marks: ["brows", "fangs"],
      detail: "#f3c552",
    }),
    S("triceratops", "Triceratops", "dinosaurs", "teal", {
      ears: "frill",
      eyes: "round",
      muzzle: "beak",
      marks: ["horn"],
      detail: "#e6c48b",
    }),
    S("stegosaurus", "Stegosaurus", "dinosaurs", "violet", {
      ears: "spikes",
      eyes: "dot",
      muzzle: "smile",
      marks: ["spots"],
    }),
    S("raptor", "Raptor", "dinosaurs", "amber", {
      ears: "none",
      eyes: "slit",
      muzzle: "wide",
      marks: ["stripes", "fangs"],
      detail: "#5fba70",
    }),
    S("pterodactyl", "Pterodactyl", "dinosaurs", "rust", {
      ears: "wings",
      eyes: "round",
      muzzle: "beak",
      detail: "#cd5f27",
    }),
    S("brachiosaurus", "Brachiosaurus", "dinosaurs", "sky", {
      ears: "none",
      eyes: "dot",
      muzzle: "smile",
      marks: ["spots"],
    }),
    S("ankylosaurus", "Ankylosaurus", "dinosaurs", "stone", {
      ears: "points",
      eyes: "dot",
      muzzle: "smile",
      marks: ["spots"],
    }),
    S("spinosaurus", "Spinosaurus", "dinosaurs", "navy", {
      ears: "spikes",
      eyes: "slit",
      muzzle: "wide",
      marks: ["fangs"],
      detail: "#f3c552",
    }),
    S("dilophosaurus", "Dilophosaurus", "dinosaurs", "lime", {
      ears: "crest",
      eyes: "round",
      muzzle: "wide",
      marks: ["tongue"],
      detail: "#e15c4f",
    }),
    S("mosasaurus", "Mosasaurus", "dinosaurs", "teal", {
      ears: "fins",
      eyes: "wide",
      muzzle: "wide",
      marks: ["fangs"],
    }),
    S("astronaut", "Astronaut", "space", "snow", {
      ears: "dome",
      eyes: "visor",
      muzzle: "smile",
      marks: ["visorGlow"],
      detail: "#7cc4ef",
    }),
    S("alien", "Alien", "space", "lime", {
      ears: "antennae",
      eyes: "compound",
      muzzle: "smile",
      detail: "#6da733",
    }),
    S("martian", "Martian", "space", "red", {
      ears: "antennae",
      eyes: "big",
      muzzle: "smile",
      marks: ["blush"],
    }),
    S("moon", "Moon", "space", "snow", {
      ears: "none",
      eyes: "sleepy",
      muzzle: "smile",
      marks: ["spots"],
    }),
    S("sun", "Sun", "space", "yellow", {
      ears: "rays",
      eyes: "dot",
      muzzle: "smile",
      marks: ["blush"],
      detail: "#e9aa3c",
    }),
    S("star", "Star", "space", "yellow", {
      ears: "points",
      eyes: "dot",
      muzzle: "smile",
      marks: ["sparkle"],
      shade: "#e9aa3c",
      detail: "#fff3d0",
    }),
    S("comet", "Comet", "space", "sky", {
      ears: "points",
      eyes: "wide",
      muzzle: "smile",
      marks: ["sparkle", "bolt"],
      detail: "#f3c552",
    }),
    S("satellite", "Satellite", "space", "slate", {
      ears: "antennae",
      eyes: "visor",
      muzzle: "grill",
      marks: ["bolt"],
      detail: "#f3c552",
    }),
    S("ufo", "UFO", "space", "teal", {
      ears: "dome",
      eyes: "big",
      muzzle: "smile",
      marks: ["visorGlow"],
      detail: "#95cf57",
    }),
    S("rover", "Rover", "space", "stone", {
      ears: "antennae",
      eyes: "visor",
      muzzle: "grill",
      marks: ["spots"],
      detail: "#f0993f",
    }),
    S("robot", "Robot", "robots", "stone", {
      ears: "antennae",
      eyes: "visor",
      muzzle: "grill",
      marks: ["bolt"],
      detail: "#7cc4ef",
    }),
    S("android", "Android", "robots", "snow", {
      ears: "none",
      eyes: "round",
      muzzle: "smile",
      marks: ["visorGlow"],
      detail: "#42b5a8",
    }),
    S("cyborg", "Cyborg", "robots", "charcoal", {
      ears: "none",
      eyes: "slit",
      muzzle: "grill",
      marks: ["stitches"],
      detail: "#e15c4f",
    }),
    S("drone", "Drone", "robots", "slate", {
      ears: "fins",
      eyes: "big",
      muzzle: "smile",
      detail: "#95cf57",
    }),
    S("mecha", "Mecha", "robots", "navy", {
      ears: "horns",
      eyes: "visor",
      muzzle: "grill",
      marks: ["bolt"],
      detail: "#f3c552",
    }),
    S("servo", "Servo", "robots", "gold", {
      ears: "antennae",
      eyes: "dot",
      muzzle: "smile",
      marks: ["blush"],
    }),
    S("glitch", "Glitch", "robots", "purple", {
      ears: "points",
      eyes: "compound",
      muzzle: "grill",
      marks: ["sparkle"],
      detail: "#95cf57",
    }),
    S("pixel", "Pixel", "robots", "lime", {
      ears: "none",
      eyes: "dot",
      muzzle: "grill",
      marks: ["spots"],
      detail: "#f3c552",
    }),
    S("sentry", "Sentry", "robots", "red", {
      ears: "dome",
      eyes: "visor",
      muzzle: "grill",
      marks: ["visorGlow"],
      detail: "#f3c552",
    }),
    S("beacon", "Beacon", "robots", "sky", {
      ears: "rays",
      eyes: "dot",
      muzzle: "smile",
      marks: ["sparkle"],
      detail: "#f3c552",
    }),
    S("vampire", "Vampire", "monsters", "snow", {
      ears: "pointed",
      eyes: "slit",
      muzzle: "smile",
      marks: ["brows", "fangs"],
      detail: "#e15c4f",
    }),
    S("werewolf", "Werewolf", "monsters", "charcoal", {
      ears: "pointed",
      eyes: "round",
      muzzle: "snout",
      marks: ["brows", "fangs"],
    }),
    S("zombie", "Zombie", "monsters", "moss", {
      ears: "round",
      eyes: "round",
      muzzle: "smile",
      marks: ["stitches", "fangs"],
    }),
    S("ghost", "Ghost", "monsters", "snow", {
      ears: "none",
      eyes: "big",
      muzzle: "wide",
      marks: ["sparkle"],
      detail: "#a68bf5",
    }),
    S("mummy", "Mummy", "monsters", "cream", {
      ears: "none",
      eyes: "dot",
      muzzle: "smile",
      marks: ["bandage"],
      accent: "#fffaf0",
    }),
    S("frankenstein", "Frankenstein", "monsters", "lime", {
      ears: "none",
      eyes: "sleepy",
      muzzle: "smile",
      marks: ["brows", "stitches", "bolt"],
      detail: "#f3c552",
    }),
    S("goblin", "Goblin", "monsters", "moss", {
      ears: "pointed",
      eyes: "slit",
      muzzle: "wide",
      marks: ["brows", "fangs"],
      detail: "#f3c552",
    }),
    S("ogre", "Ogre", "monsters", "brown", {
      ears: "round",
      eyes: "dot",
      muzzle: "tusks",
      marks: ["brows"],
    }),
    S("slime", "Slime", "monsters", "teal", {
      ears: "none",
      eyes: "round",
      muzzle: "smile",
      marks: ["blush", "sparkle"],
    }),
    S("gargoyle", "Gargoyle", "monsters", "stone", {
      ears: "wings",
      eyes: "slit",
      muzzle: "wide",
      marks: ["brows", "fangs"],
      detail: "#6a737c",
    }),
  ]),
  Vp = new Map(Bp.map((l) => [l.id, l]));
function Hc(l) {
  return l ? Vp.get(l) : void 0;
}
const Hp = { small: "1.25rem", medium: "1.75rem", large: "2.5rem" },
  zc = "#f8fafc",
  Qp = "#60a5fa",
  Ec = [
    { value: "product", label: "Product" },
    { value: "mock", label: "Mock" },
    { value: "real", label: "Real", locked: !0 },
  ];
function Gp({ dataSource: l, onDataSourceChange: u, tone: a = "light" }) {
  const [d, f] = X.useState(!1),
    m = a === "dark",
    v = Ec.find((P) => P.value === l)?.label || "Product",
    E = m ? "#e2e8f0" : "#334155",
    j = m ? "#94a3b8" : "#64748b",
    _ = m ? "#f8fafc" : "#0f172a";
  return s.jsxs("div", {
    "data-profile-database-row": !0,
    style: { marginBottom: "0.25rem" },
    children: [
      s.jsxs("button", {
        "aria-controls": "profile-database-options",
        "aria-expanded": d,
        "data-profile-database-trigger": !0,
        onClick: () => f((P) => !P),
        style: {
          alignItems: "center",
          background: "transparent",
          border: 0,
          borderRadius: "0.5rem",
          color: E,
          cursor: "pointer",
          display: "flex",
          fontFamily: "inherit",
          fontSize: "0.875rem",
          fontWeight: 650,
          gap: "0.5rem",
          minHeight: "2.25rem",
          padding: "0.5rem",
          textAlign: "left",
          width: "100%",
        },
        type: "button",
        children: [
          s.jsxs("svg", {
            "aria-hidden": "true",
            fill: "none",
            height: "16",
            viewBox: "0 0 24 24",
            width: "16",
            children: [
              s.jsx("ellipse", {
                cx: "12",
                cy: "5",
                rx: "8",
                ry: "3",
                stroke: "currentColor",
                strokeWidth: "1.8",
              }),
              s.jsx("path", {
                d: "M4 5v7c0 1.7 3.6 3 8 3s8-1.3 8-3V5M4 12v7c0 1.7 3.6 3 8 3s8-1.3 8-3v-7",
                stroke: "currentColor",
                strokeWidth: "1.8",
              }),
            ],
          }),
          s.jsx("span", { style: { flex: 1 }, children: "Database" }),
          s.jsx("span", {
            style: { color: j, fontSize: "0.75rem", fontWeight: 600 },
            children: v,
          }),
          s.jsx("svg", {
            "aria-hidden": "true",
            fill: "none",
            height: "15",
            style: { transform: d ? "rotate(180deg)" : void 0 },
            viewBox: "0 0 24 24",
            width: "15",
            children: s.jsx("path", {
              d: "m6 9 6 6 6-6",
              stroke: "currentColor",
              strokeLinecap: "round",
              strokeLinejoin: "round",
              strokeWidth: "2",
            }),
          }),
        ],
      }),
      d
        ? s.jsx("div", {
            "aria-label": "Database",
            id: "profile-database-options",
            role: "radiogroup",
            style: {
              display: "grid",
              gap: "0.125rem",
              gridTemplateColumns: "repeat(3, minmax(0, 1fr))",
              padding: "0.125rem 0.5rem 0.5rem 2rem",
            },
            children: Ec.map((P) =>
              s.jsxs(
                "button",
                {
                  "aria-checked": l === P.value,
                  "aria-label": P.locked ? `${P.label}, locked` : P.label,
                  "data-database-source": P.value,
                  disabled: P.locked,
                  onClick: () => u(P.value),
                  role: "radio",
                  style: {
                    background: l === P.value ? _ : "transparent",
                    border: `1px solid ${l === P.value ? _ : m ? "#475569" : "#cbd5e1"}`,
                    borderRadius: "9999px",
                    color: P.locked
                      ? j
                      : l === P.value
                        ? m
                          ? "#0f172a"
                          : "#ffffff"
                        : E,
                    cursor: P.locked ? "not-allowed" : "pointer",
                    display: "inline-flex",
                    fontFamily: "inherit",
                    fontSize: "0.75rem",
                    fontWeight: 700,
                    minHeight: "1.875rem",
                    opacity: P.locked ? 0.62 : 1,
                    padding: "0.25rem 0.45rem",
                    alignItems: "center",
                    justifyContent: "center",
                    gap: "0.2rem",
                  },
                  title: P.locked ? "Locked" : P.label,
                  type: "button",
                  children: [
                    P.locked
                      ? s.jsxs("svg", {
                          "aria-hidden": "true",
                          fill: "none",
                          height: "11",
                          viewBox: "0 0 24 24",
                          width: "11",
                          children: [
                            s.jsx("rect", {
                              height: "10",
                              rx: "2",
                              stroke: "currentColor",
                              strokeWidth: "2",
                              width: "14",
                              x: "5",
                              y: "11",
                            }),
                            s.jsx("path", {
                              d: "M8 11V8a4 4 0 0 1 8 0v3",
                              stroke: "currentColor",
                              strokeLinecap: "round",
                              strokeWidth: "2",
                            }),
                          ],
                        })
                      : null,
                    P.label,
                  ],
                },
                P.value,
              ),
            ),
          })
        : null,
    ],
  });
}
function Kp({ className: l, size: u = "medium", style: a }) {
  return s.jsxs("span", {
    "aria-label": "comp.school",
    className: l,
    style: {
      alignItems: "baseline",
      color: "inherit",
      display: "inline-flex",
      fontSize: Hp[u],
      lineHeight: 1,
      textTransform: "none",
      whiteSpace: "nowrap",
      ...a,
    },
    children: [
      s.jsxs("span", {
        "aria-hidden": "true",
        "data-comp-school-wordmark-part": "comp-dot",
        style: {
          color: zc,
          fontFamily:
            "Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
          fontSize: "0.88em",
          fontStyle: "normal",
          fontWeight: 650,
          letterSpacing: "-0.035em",
        },
        children: [
          "comp",
          s.jsx("span", { style: { color: zc }, children: "." }),
        ],
      }),
      s.jsx("span", {
        "aria-hidden": "true",
        "data-comp-school-wordmark-part": "school",
        style: {
          color: Qp,
          fontFamily: "'Caveat', 'Segoe Print', cursive",
          fontSize: "1.2em",
          fontStyle: "italic",
          fontWeight: 700,
          letterSpacing: "-0.04em",
          transform: "rotate(-2deg)",
        },
        children: "school",
      }),
    ],
  });
}
function Zp(l) {
  switch (l.trim().toLocaleLowerCase()) {
    case "exams":
      return s.jsxs(s.Fragment, {
        children: [
          s.jsx("path", { d: "m2 9 10-5 10 5-10 5Z" }),
          s.jsx("path", { d: "M6 11.5V16c3.5 2.7 8.5 2.7 12 0v-4.5M22 9v6" }),
        ],
      });
    case "analytics":
      return s.jsx(s.Fragment, {
        children: s.jsx("path", { d: "M4 20V10M10 20V4M16 20v-7M22 20H2" }),
      });
    case "printouts":
      return s.jsxs(s.Fragment, {
        children: [
          s.jsx("path", { d: "M7 8V3h10v5" }),
          s.jsx("path", {
            d: "M7 17H5a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2",
          }),
          s.jsx("path", { d: "M7 14h10v7H7z" }),
          s.jsx("path", { d: "M17 11h.01" }),
        ],
      });
    case "mark":
    case "marking":
      return s.jsxs(s.Fragment, {
        children: [
          s.jsx("path", { d: "M4 3h13a3 3 0 0 1 3 3v15H7a3 3 0 0 1-3-3Z" }),
          s.jsx("path", { d: "M7 17h13M8 8h8M8 12h5" }),
        ],
      });
    case "recall":
    case "topic drills":
      return s.jsxs(s.Fragment, {
        children: [
          s.jsx("circle", { cx: "12", cy: "12", r: "8" }),
          s.jsx("circle", { cx: "12", cy: "12", r: "3" }),
          s.jsx("path", { d: "M12 2v3M22 12h-3M12 22v-3M2 12h3" }),
        ],
      });
    case "coding playground":
      return s.jsx("path", { d: "m8 9-3 3 3 3M16 9l3 3-3 3M14 5l-4 14" });
    case "forms":
    case "self assess":
      return s.jsxs(s.Fragment, {
        children: [
          s.jsx("rect", { height: "18", rx: "2", width: "14", x: "5", y: "4" }),
          s.jsx("path", { d: "M9 4V2h6v2M8.5 13l2 2 5-5" }),
        ],
      });
    case "games":
      return s.jsxs(s.Fragment, {
        children: [
          s.jsx("path", {
            d: "M7.5 8h9a4.5 4.5 0 0 1 4.2 6.1l-1 2.7a2.5 2.5 0 0 1-4.1 1l-1.4-1.3H9.8l-1.4 1.3a2.5 2.5 0 0 1-4.1-1l-1-2.7A4.5 4.5 0 0 1 7.5 8Z",
          }),
          s.jsx("path", { d: "M8 11v4M6 13h4M16.5 12h.01M18.5 14h.01" }),
        ],
      });
    case "admin":
      return s.jsxs(s.Fragment, {
        children: [
          s.jsx("rect", { height: "7", rx: "1", width: "7", x: "3", y: "3" }),
          s.jsx("rect", { height: "7", rx: "1", width: "7", x: "14", y: "3" }),
          s.jsx("rect", { height: "7", rx: "1", width: "7", x: "3", y: "14" }),
          s.jsx("rect", { height: "7", rx: "1", width: "7", x: "14", y: "14" }),
        ],
      });
    case "docs":
      return s.jsxs(s.Fragment, {
        children: [
          s.jsx("path", {
            d: "M4 5.5A3.5 3.5 0 0 1 7.5 2H11v17H7.5A3.5 3.5 0 0 0 4 22Z",
          }),
          s.jsx("path", {
            d: "M20 5.5A3.5 3.5 0 0 0 16.5 2H13v17h3.5A3.5 3.5 0 0 1 20 22Z",
          }),
        ],
      });
    case "issues":
      return s.jsxs(s.Fragment, {
        children: [
          s.jsx("circle", { cx: "12", cy: "12", r: "9" }),
          s.jsx("path", { d: "M12 7v6M12 17h.01" }),
        ],
      });
    default:
      return s.jsxs(s.Fragment, {
        children: [
          s.jsx("rect", { height: "7", rx: "1", width: "7", x: "3", y: "3" }),
          s.jsx("rect", { height: "7", rx: "1", width: "7", x: "14", y: "3" }),
          s.jsx("rect", { height: "7", rx: "1", width: "7", x: "3", y: "14" }),
          s.jsx("rect", { height: "7", rx: "1", width: "7", x: "14", y: "14" }),
        ],
      });
  }
}
function Yp({ appName: l, className: u, style: a }) {
  return s.jsx("svg", {
    "aria-hidden": "true",
    className: u,
    "data-comp-school-app-icon": l,
    fill: "none",
    focusable: "false",
    height: "24",
    stroke: "currentColor",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    strokeWidth: "1.9",
    style: {
      color: "#14b8a6",
      flex: "0 0 auto",
      height: "1.5rem",
      width: "1.5rem",
      ...a,
    },
    viewBox: "0 0 24 24",
    width: "24",
    children: Zp(l),
  });
}
function Xp(l) {
  return l.trim().charAt(0).toLocaleUpperCase() || "U";
}
function Rc({ avatar: l, instanceId: u, profileName: a, style: d }) {
  const f = Hc(l);
  return f
    ? s.jsx("span", {
        "aria-hidden": "true",
        "data-student-avatar": f.id,
        style: {
          display: "block",
          height: "100%",
          lineHeight: 0,
          width: "100%",
          ...d,
        },
        children: s.jsx($p, {
          features: f,
          idSuffix: u ? `${u}-${f.id}` : f.id,
        }),
      })
    : s.jsx("span", {
        "aria-hidden": "true",
        style: { lineHeight: 1, ...d },
        children: Xp(a),
      });
}
function Jp({
  appName: l,
  appIcon: u,
  backHref: a,
  profileName: d,
  backLabel: f = "Back",
  canChangeAvatar: m = !1,
  changeAvatarHref: v,
  children: E,
  className: j,
  contextLabel: _,
  dataSource: P,
  logoSrc: U = "/favicon/favicon.svg",
  logoTone: W = "brand",
  onBack: xe,
  onDataSourceChange: ue,
  onSignOut: $,
  profileAvatar: G,
  reportIssueHref: le,
  style: ve,
  tone: Ce = "dark",
}) {
  const J = Ce === "dark",
    ce = !!Hc(G),
    oe = J ? "#f8fafc" : "#0f172a",
    he = J ? "#cbd5e1" : "#475569",
    de = J ? "#334155" : "#e2e8f0",
    He = J ? "#0f172a" : "#ffffff",
    Ie = J ? "#1e293b" : "#f8fafc",
    _e = s.jsxs(s.Fragment, {
      children: [
        s.jsx("svg", {
          "aria-hidden": "true",
          fill: "none",
          height: "16",
          viewBox: "0 0 24 24",
          width: "16",
          children: s.jsx("path", {
            d: "M19 12H5m7 7-7-7 7-7",
            stroke: "currentColor",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "2",
          }),
        }),
        s.jsx("span", { children: f }),
      ],
    }),
    $e = {
      alignItems: "center",
      background: Ie,
      border: `1px solid ${de}`,
      borderRadius: "0.625rem",
      color: he,
      cursor: "pointer",
      display: "inline-flex",
      fontFamily: "inherit",
      fontSize: "0.875rem",
      fontWeight: 700,
      gap: "0.375rem",
      minHeight: "2.5rem",
      padding: "0.5rem 0.75rem",
      textDecoration: "none",
      whiteSpace: "nowrap",
    },
    Re = {
      ...$e,
      background: "transparent",
      border: 0,
      color: oe,
      justifyContent: "flex-start",
      width: "100%",
    };
  return s.jsx("header", {
    "aria-label": `${l} navigation`,
    className: j,
    "data-comp-school-navbar": "standard",
    style: {
      background: He,
      borderBottom: `1px solid ${de}`,
      color: oe,
      fontFamily:
        "Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
      position: "relative",
      zIndex: 30,
      ...ve,
    },
    children: s.jsxs("div", {
      style: {
        alignItems: "center",
        display: "flex",
        gap: "0.75rem",
        justifyContent: "space-between",
        margin: "0 auto",
        maxWidth: "80rem",
        minHeight: "4rem",
        padding: "0.625rem clamp(1rem, 3vw, 2rem)",
        width: "100%",
      },
      children: [
        s.jsxs("div", {
          style: {
            alignItems: "center",
            display: "flex",
            gap: "0.625rem",
            minWidth: 0,
          },
          children: [
            s.jsx("img", {
              alt: "",
              "aria-hidden": "true",
              src: U,
              style: {
                filter: W === "grayscale" ? "grayscale(1)" : void 0,
                height: "2rem",
                objectFit: "contain",
                opacity: W === "grayscale" ? 0.58 : 1,
                width: "2rem",
              },
            }),
            u === void 0 ? s.jsx(Yp, { appName: l }) : u,
            s.jsx("strong", {
              style: {
                color: oe,
                fontSize: "1rem",
                fontWeight: 750,
                lineHeight: 1.2,
                overflow: "hidden",
                textOverflow: "ellipsis",
                whiteSpace: "nowrap",
              },
              children: l,
            }),
            _
              ? s.jsx("span", {
                  style: {
                    borderLeft: `1px solid ${de}`,
                    color: he,
                    fontSize: "0.875rem",
                    fontWeight: 650,
                    lineHeight: 1.2,
                    minWidth: 0,
                    overflow: "hidden",
                    paddingLeft: "0.625rem",
                    textOverflow: "ellipsis",
                    whiteSpace: "nowrap",
                  },
                  children: _,
                })
              : null,
          ],
        }),
        s.jsxs("div", {
          style: { alignItems: "center", display: "flex", gap: "0.625rem" },
          children: [
            xe
              ? s.jsx("button", {
                  "aria-label": f,
                  onClick: xe,
                  style: $e,
                  type: "button",
                  children: _e,
                })
              : s.jsx("a", {
                  "aria-label": f,
                  href: a,
                  style: $e,
                  children: _e,
                }),
            E,
            le && $
              ? s.jsxs("details", {
                  "data-comp-school-account-menu": !0,
                  style: { position: "relative" },
                  children: [
                    s.jsx("summary", {
                      "aria-label": `${d} account menu`,
                      title: `${d} account`,
                      style: {
                        alignItems: "center",
                        background: ce
                          ? "transparent"
                          : J
                            ? "#e2e8f0"
                            : "#0f172a",
                        borderRadius: ce ? "0.8rem" : "9999px",
                        color: J ? "#0f172a" : "#ffffff",
                        cursor: "pointer",
                        display: "inline-flex",
                        flex: "0 0 auto",
                        fontSize: "0.875rem",
                        fontWeight: 800,
                        height: "2.5rem",
                        justifyContent: "center",
                        listStyle: "none",
                        overflow: "hidden",
                        width: "2.5rem",
                      },
                      children: s.jsx(Rc, { avatar: G, profileName: d }),
                    }),
                    s.jsxs("div", {
                      style: {
                        background: He,
                        border: `1px solid ${de}`,
                        borderRadius: "0.75rem",
                        boxShadow: "0 20px 25px -5px rgba(2, 6, 23, 0.35)",
                        minWidth: "15rem",
                        padding: "0.5rem",
                        position: "absolute",
                        right: 0,
                        top: "calc(100% + 0.5rem)",
                        zIndex: 40,
                      },
                      children: [
                        s.jsx("p", {
                          style: {
                            color: he,
                            fontSize: "0.75rem",
                            fontWeight: 700,
                            letterSpacing: "0.05em",
                            margin: 0,
                            padding: "0.375rem 0.5rem",
                            textTransform: "uppercase",
                          },
                          children: d.split(" ")[0] || d,
                        }),
                        P && ue
                          ? s.jsx(Gp, {
                              dataSource: P,
                              onDataSourceChange: ue,
                              tone: Ce,
                            })
                          : null,
                        m && v
                          ? s.jsxs("a", {
                              href: v,
                              style: Re,
                              children: [
                                s.jsxs("svg", {
                                  "aria-hidden": "true",
                                  fill: "none",
                                  height: "16",
                                  viewBox: "0 0 24 24",
                                  width: "16",
                                  children: [
                                    s.jsx("path", {
                                      d: "M12 4c-4.4 0-8 3.1-8 7 0 2.9 2 5.4 4.9 6.5L8 21l3.4-2.8H12c4.4 0 8-3.1 8-7s-3.6-7.2-8-7.2Z",
                                      stroke: "currentColor",
                                      strokeLinejoin: "round",
                                      strokeWidth: "1.8",
                                    }),
                                    s.jsx("circle", {
                                      cx: "9",
                                      cy: "10",
                                      fill: "currentColor",
                                      r: "1",
                                    }),
                                    s.jsx("circle", {
                                      cx: "15",
                                      cy: "10",
                                      fill: "currentColor",
                                      r: "1",
                                    }),
                                  ],
                                }),
                                s.jsx("span", { children: "Change avatar" }),
                              ],
                            })
                          : null,
                        s.jsxs("a", {
                          href: le,
                          style: Re,
                          children: [
                            s.jsxs("svg", {
                              "aria-hidden": "true",
                              fill: "none",
                              height: "16",
                              viewBox: "0 0 24 24",
                              width: "16",
                              children: [
                                s.jsx("path", {
                                  d: "M8 2 6.5 5M16 2l1.5 3M4 9H2M22 9h-2M5 19l2.5-2.5M19 19l-2.5-2.5M9 5h6a4 4 0 0 1 4 4v4a7 7 0 0 1-14 0V9a4 4 0 0 1 4-4Z",
                                  stroke: "currentColor",
                                  strokeLinecap: "round",
                                  strokeLinejoin: "round",
                                  strokeWidth: "1.8",
                                }),
                                s.jsx("path", {
                                  d: "M8 12h8M12 8v8",
                                  stroke: "currentColor",
                                  strokeLinecap: "round",
                                  strokeWidth: "1.8",
                                }),
                              ],
                            }),
                            s.jsx("span", { children: "Report an issue" }),
                          ],
                        }),
                        s.jsxs("button", {
                          onClick: $,
                          style: { ...Re, marginTop: "0.25rem" },
                          type: "button",
                          children: [
                            s.jsx("svg", {
                              "aria-hidden": "true",
                              fill: "none",
                              height: "16",
                              viewBox: "0 0 24 24",
                              width: "16",
                              children: s.jsx("path", {
                                d: "M10 17l5-5-5-5M15 12H3M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4",
                                stroke: "currentColor",
                                strokeLinecap: "round",
                                strokeLinejoin: "round",
                                strokeWidth: "1.8",
                              }),
                            }),
                            s.jsx("span", { children: "Sign out" }),
                          ],
                        }),
                      ],
                    }),
                  ],
                })
              : s.jsx("span", {
                  "aria-label": `${d} profile`,
                  title: d,
                  style: {
                    alignItems: "center",
                    background: ce ? "transparent" : J ? "#e2e8f0" : "#0f172a",
                    borderRadius: ce ? "0.8rem" : "9999px",
                    color: J ? "#0f172a" : "#ffffff",
                    display: "inline-flex",
                    flex: "0 0 auto",
                    fontSize: "0.875rem",
                    fontWeight: 800,
                    height: "2.5rem",
                    justifyContent: "center",
                    overflow: "hidden",
                    width: "2.5rem",
                  },
                  children: s.jsx(Rc, { avatar: G, profileName: d }),
                }),
          ],
        }),
      ],
    }),
  });
}
const qp = { BASE_URL: "/", DEV: !1, MODE: "production", PROD: !0, SSR: !1 },
  em = X.createContext(null),
  tm = X.createContext(null),
  nm = X.createContext(!1),
  ls = "comp-school-fallback-access";
function Mc() {
  return typeof window > "u" || typeof document > "u"
    ? null
    : $c(document.cookie, window.location.hostname, yo().DEV === !0);
}
function rm(l) {
  if (typeof window > "u" || typeof document > "u") return;
  const u = zp(l);
  $c(u, window.location.hostname, yo().DEV === !0) && (document.cookie = u);
}
function lm() {
  typeof document > "u" || (document.cookie = Ep());
}
function so(l, u) {
  return (
    u &&
    l.role === "teacher" &&
    new URLSearchParams(window.location.search).get("preview") === "student"
  );
}
function sm() {
  if (typeof window > "u") return null;
  const l = new URLSearchParams(window.location.hash.replace(/^#/, "")),
    u = l.get("fallback");
  if (u && jc(u)) {
    (window.sessionStorage.setItem(ls, u), l.delete("fallback"));
    const d = l.toString();
    window.history.replaceState(
      {},
      "",
      `${window.location.pathname}${window.location.search}${d ? `#${d}` : ""}`,
    );
  }
  const a = u || window.sessionStorage.getItem(ls);
  return jc(a) ? a : (window.sessionStorage.removeItem(ls), null);
}
const Dt = {
  loadingMain: {
    alignItems: "center",
    background: "#020617",
    color: "#ffffff",
    display: "grid",
    fontFamily:
      'Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
    minHeight: "100vh",
    padding: "1rem",
    placeItems: "center",
  },
  loadingText: {
    color: "#cbd5e1",
    fontSize: "0.875rem",
    fontWeight: 500,
    margin: 0,
  },
  main: {
    alignItems: "center",
    background: "#020617",
    color: "#ffffff",
    display: "flex",
    fontFamily:
      'Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
    justifyContent: "center",
    minHeight: "100vh",
    padding: "2.5rem 1rem",
  },
  panel: {
    background: "var(--cs-surface, #ffffff)",
    border: "1px solid var(--cs-border, rgba(255, 255, 255, 0.1))",
    borderRadius: "0.5rem",
    boxShadow:
      "0 25px 50px -12px rgba(15, 23, 42, 0.45), 0 12px 24px -16px rgba(15, 23, 42, 0.6)",
    color: "var(--cs-text, #020617)",
    maxWidth: "24rem",
    padding: "1.5rem",
    width: "100%",
  },
  title: {
    fontSize: "1.5rem",
    fontWeight: 700,
    lineHeight: 1.2,
    margin: "0.75rem 0 0",
  },
  copy: {
    color: "var(--cs-text-muted, #475569)",
    fontSize: "0.875rem",
    lineHeight: 1.6,
    margin: "0.5rem 0 0",
  },
  actions: { display: "grid", gap: "1rem", marginTop: "1.5rem" },
  error: { color: "#dc2626", fontSize: "0.875rem", fontWeight: 600, margin: 0 },
  link: {
    background: "var(--cs-primary-hover, #2563eb)",
    borderRadius: "0.375rem",
    color: "#ffffff",
    display: "block",
    fontSize: "0.875rem",
    fontWeight: 700,
    padding: "0.75rem 1rem",
    textAlign: "center",
    textDecoration: "none",
    width: "100%",
  },
};
function yo() {
  return qp || {};
}
function im(l) {
  return Ip(window.location.hostname, l, yo().VITE_PLATFORM_URL);
}
function om({
  appName: l,
  children: u,
  allowedRoles: a,
  navbarChildren: d,
  navbarStyle: f,
  productionUrl: m,
  showNavbar: v = !0,
  allowFallback: E = !1,
  allowTeacherStudentPreview: j = !1,
}) {
  const P =
      new URLSearchParams(window.location.search).get("sql") === "mock"
        ? "mock"
        : "product",
    U = X.useMemo(() => im(m), [m]),
    W = X.useMemo(() => Bc(window.location.hostname), []),
    xe = X.useMemo(
      () => Vc(window.location.hostname, "https://issues.comp.school"),
      [],
    ),
    ue = X.useMemo(() => {
      const pe = new URL(W);
      return (pe.searchParams.set("changeAvatar", "1"), pe.toString());
    }, [W]),
    $ = a ? a.join(",") : "",
    [G, le] = X.useState(null),
    [ve, Ce] = X.useState(!0),
    [J, ce] = X.useState(!1),
    [oe, he] = X.useState(null),
    [de, He] = X.useState(!1),
    [Ie, _e] = X.useState(null);
  async function $e() {
    (await fetch("/api/logout", {
      cache: "no-store",
      credentials: "same-origin",
      method: "POST",
    }).catch(() => {}),
      he(null),
      lm(),
      window.sessionStorage.removeItem(ls),
      He(!1),
      ce(!1),
      window.location.assign(W));
  }
  function Re(pe) {
    if (pe === "real") return;
    const ye = new URL(window.location.href);
    (ye.searchParams.set("sql", pe), window.location.assign(ye.toString()));
  }
  if (
    (X.useEffect(() => {
      let pe = !1;
      return (
        fetch("/api/session", {
          cache: "no-store",
          credentials: "same-origin",
          headers: { accept: "application/json" },
        })
          .then(async (ye) => {
            const we = await ye.json().catch(() => null);
            if (pe) return;
            if (
              ye.ok &&
              we?.ok &&
              we.user &&
              (!a || a.includes(we.user.role) || so(we.user, j))
            ) {
              (rm(we.user), le(null), he(we.user), ce(!0));
              return;
            }
            const fe = Mc();
            if (fe && (!a || a.includes(fe.role) || so(fe, j))) {
              (le(null), he(fe), ce(!0));
              return;
            }
            if (E && sm()) {
              (le(null), He(!0), ce(!0));
              return;
            }
            (le(we?.message || null), he(null), ce(!1));
          })
          .catch(() => {
            if (!pe) {
              const ye = Mc();
              if (ye && (!a || a.includes(ye.role) || so(ye, j))) {
                (le(null), he(ye), ce(!0));
                return;
              }
              (le("Unable to check platform access right now."),
                he(null),
                ce(!1));
            }
          })
          .finally(() => {
            pe || Ce(!1);
          }),
        () => {
          pe = !0;
        }
      );
    }, [$, E, j]),
    ve)
  )
    return s.jsx("main", {
      style: Dt.loadingMain,
      children: s.jsx("p", {
        style: Dt.loadingText,
        children: "Checking platform access...",
      }),
    });
  if (J) {
    const pe = oe?.role === "admin" || oe?.role === "teacher",
      ye = new URL(W);
    return (
      pe && ye.searchParams.set("sql", P),
      s.jsxs(s.Fragment, {
        children: [
          v && (oe || de)
            ? s.jsx(Jp, {
                appName: l,
                backHref: ye.toString(),
                canChangeAvatar: oe?.role === "student",
                changeAvatarHref: ue,
                contextLabel: Ie,
                dataSource: pe ? P : void 0,
                onDataSourceChange: pe ? Re : void 0,
                onSignOut: $e,
                profileAvatar: oe?.role === "student" ? oe.avatar : void 0,
                profileName: oe?.name || "Fallback",
                reportIssueHref: xe,
                style: f,
                children: d,
              })
            : null,
          s.jsx(nm.Provider, {
            value: de,
            children: s.jsx(tm.Provider, {
              value: oe,
              children: s.jsx(em.Provider, { value: _e, children: u }),
            }),
          }),
        ],
      })
    );
  }
  return s.jsx("main", {
    style: Dt.main,
    children: s.jsxs("section", {
      style: Dt.panel,
      children: [
        s.jsx(Kp, { size: "small", style: { color: "#0f172a" } }),
        s.jsx("h1", { style: Dt.title, children: l }),
        s.jsx("p", {
          style: Dt.copy,
          children: "Open comp.school and enter your access code to continue.",
        }),
        s.jsxs("div", {
          style: Dt.actions,
          children: [
            G && s.jsx("p", { style: Dt.error, children: G }),
            s.jsx("a", {
              "aria-label": `Open comp.school to access ${l}`,
              href: U,
              style: Dt.link,
              children: "Open comp.school",
            }),
          ],
        }),
      ],
    }),
  });
}
const Qc = [
    "Short answer",
    "Paragraph",
    "Multiple choice",
    "Checkboxes",
    "Dropdown",
    "File upload",
    "Linear scale",
    "Rating",
    "Multiple choice grid",
    "Checkbox grid",
    "Date",
    "Time",
  ],
  am = [2, 3, 4, 5, 6, 7, 8, 9, 10],
  um = [3, 4, 5, 6, 7, 8, 9, 10],
  cm = [
    "document",
    "spreadsheet",
    "pdf",
    "video",
    "presentation",
    "drawing",
    "image",
    "audio",
  ],
  fo = 1024 * 1024,
  Gc = {
    document: [
      ".doc",
      ".docx",
      ".odt",
      ".rtf",
      ".txt",
      "application/msword",
      "application/rtf",
      "text/plain",
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      "application/vnd.oasis.opendocument.text",
    ],
    spreadsheet: [
      ".csv",
      ".ods",
      ".xls",
      ".xlsx",
      "text/csv",
      "application/vnd.ms-excel",
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      "application/vnd.oasis.opendocument.spreadsheet",
    ],
    pdf: [".pdf", "application/pdf"],
    video: ["video/*"],
    presentation: [
      ".odp",
      ".ppt",
      ".pptx",
      "application/vnd.ms-powerpoint",
      "application/vnd.openxmlformats-officedocument.presentationml.presentation",
      "application/vnd.oasis.opendocument.presentation",
    ],
    drawing: [".drawio", ".fig", ".svg", "image/svg+xml"],
    image: ["image/*"],
    audio: ["audio/*"],
  };
function dm({
  question: l,
  index: u,
  selected: a = !1,
  quizEnabled: d = !0,
  onChange: f,
  onDuplicate: m,
  onDelete: v,
}) {
  const E = typeof u == "number" ? u + 1 : void 0;
  return s.jsxs("article", {
    className: `bg-white p-5 shadow-sm ${a ? "border-l-4 border-[#673ab7]" : "border-l-4 border-transparent"}`,
    children: [
      s.jsxs("div", {
        className: "flex flex-wrap items-start gap-3",
        children: [
          E
            ? s.jsx("span", {
                className: "mt-2 text-sm font-medium text-[#5f6368]",
                children: E,
              })
            : null,
          s.jsxs("label", {
            className: "min-w-[220px] flex-1",
            children: [
              s.jsx("span", {
                className: "sr-only",
                children: "Question title",
              }),
              s.jsx("input", {
                className:
                  "w-full border-b border-[#dadce0] bg-transparent pb-2 text-lg outline-none focus:border-[#673ab7]",
                value: l.title,
                onChange: (j) => f({ title: j.target.value }),
                placeholder: "Question",
              }),
            ],
          }),
          s.jsxs("label", {
            className: "min-w-[190px]",
            children: [
              s.jsx("span", {
                className: "sr-only",
                children: "Question type",
              }),
              s.jsx("select", {
                className:
                  "w-full rounded border border-[#dadce0] bg-white px-3 py-2 text-sm",
                value: l.type,
                onChange: (j) => f({ type: j.target.value }),
                children: Qc.map((j) =>
                  s.jsx("option", { value: j, children: j }, j),
                ),
              }),
            ],
          }),
        ],
      }),
      s.jsxs("label", {
        className: "mt-3 block",
        children: [
          s.jsx("span", {
            className: "sr-only",
            children: "Question description",
          }),
          s.jsx("input", {
            className:
              "w-full border-b border-[#dadce0] bg-transparent py-2 text-sm outline-none focus:border-[#673ab7]",
            value: l.description ?? "",
            onChange: (j) => f({ description: j.target.value }),
            placeholder: "Description",
          }),
        ],
      }),
      s.jsx(pm, { question: l, onChange: f }),
      s.jsx(gm, { question: l, onChange: f }),
      d ? s.jsx(hm, { question: l, onChange: f }) : null,
      s.jsxs("div", {
        className:
          "mt-5 flex flex-wrap items-center justify-between gap-3 border-t border-[#dadce0] pt-4",
        children: [
          s.jsxs("div", {
            className: "flex flex-wrap gap-2",
            children: [
              s.jsx("button", {
                type: "button",
                className:
                  "rounded border border-[#dadce0] px-3 py-2 text-sm font-medium hover:border-[#673ab7]",
                onClick: m,
                disabled: !m,
                children: "Duplicate",
              }),
              s.jsx("button", {
                type: "button",
                className:
                  "rounded border border-[#dadce0] px-3 py-2 text-sm font-medium hover:border-[#d93025] disabled:text-[#9aa0a6]",
                onClick: v,
                disabled: !v,
                children: "Delete",
              }),
            ],
          }),
          s.jsxs("label", {
            className: "flex items-center gap-2 text-sm",
            children: [
              s.jsx("span", { children: "Required" }),
              s.jsx("input", {
                type: "checkbox",
                checked: !!l.required,
                onChange: (j) => f({ required: j.target.checked }),
              }),
            ],
          }),
        ],
      }),
    ],
  });
}
function fm({ question: l, value: u, readonly: a = !1, onChange: d }) {
  const f = Zc(l),
    m = a || !d;
  return s.jsxs("article", {
    className: "bg-white p-5 shadow-sm",
    children: [
      s.jsxs("h3", {
        className: "text-lg font-medium",
        children: [
          l.title,
          l.required
            ? s.jsx("span", { className: "ml-1 text-[#d93025]", children: "*" })
            : null,
        ],
      }),
      l.description
        ? s.jsx("p", {
            className: "mt-1 text-sm text-[#5f6368]",
            children: l.description,
          })
        : null,
      s.jsx(mm, { mediaPrompt: f }),
      s.jsx(jm, { question: l, value: u, disabled: m, onChange: d ?? Fm }),
    ],
  });
}
function pm({ question: l, onChange: u }) {
  const a = Zc(l);
  function d(f) {
    const m = { ...a, ...f };
    u({ media: m.kind, mediaPrompt: m });
  }
  return s.jsx("div", {
    className:
      "mt-4 rounded border border-dashed border-[#dadce0] bg-[#f8fafd] p-4",
    children: s.jsxs("div", {
      className: "grid gap-3 sm:grid-cols-[180px_minmax(0,1fr)]",
      children: [
        s.jsxs("label", {
          className: "text-sm",
          children: [
            s.jsx("span", {
              className: "block text-xs font-medium uppercase text-[#5f6368]",
              children: "Media prompt",
            }),
            s.jsxs("select", {
              className:
                "mt-1 w-full rounded border border-[#dadce0] bg-white px-3 py-2",
              value: a.kind,
              onChange: (f) => d({ kind: f.target.value }),
              children: [
                s.jsx("option", { value: "none", children: "None" }),
                s.jsx("option", { value: "image", children: "Image" }),
                s.jsx("option", { value: "video", children: "Video" }),
              ],
            }),
          ],
        }),
        a.kind !== "none"
          ? s.jsxs("div", {
              className: "grid gap-3 sm:grid-cols-2",
              children: [
                s.jsxs("label", {
                  className: "text-sm",
                  children: [
                    s.jsx("span", {
                      className:
                        "block text-xs font-medium uppercase text-[#5f6368]",
                      children: "URL",
                    }),
                    s.jsx("input", {
                      className:
                        "mt-1 w-full rounded border border-[#dadce0] bg-white px-3 py-2",
                      value: a.url ?? "",
                      onChange: (f) => d({ url: f.target.value }),
                      placeholder:
                        a.kind === "image" ? "Image URL" : "Video URL",
                    }),
                  ],
                }),
                s.jsxs("label", {
                  className: "text-sm",
                  children: [
                    s.jsx("span", {
                      className:
                        "block text-xs font-medium uppercase text-[#5f6368]",
                      children: "Label",
                    }),
                    s.jsx("input", {
                      className:
                        "mt-1 w-full rounded border border-[#dadce0] bg-white px-3 py-2",
                      value: a.label ?? "",
                      onChange: (f) => d({ label: f.target.value }),
                      placeholder:
                        a.kind === "image" ? "Image label" : "Video label",
                    }),
                  ],
                }),
              ],
            })
          : null,
      ],
    }),
  });
}
function mm({ mediaPrompt: l }) {
  if (l.kind === "none") return null;
  const u = l.label || (l.kind === "image" ? "Image prompt" : "Video prompt");
  return l.kind === "image" && l.url
    ? s.jsxs("figure", {
        className: "mt-4 overflow-hidden rounded border border-[#dadce0]",
        children: [
          s.jsx("img", {
            className: "max-h-72 w-full object-contain bg-[#f8fafd]",
            src: l.url,
            alt: u,
          }),
          s.jsx("figcaption", {
            className:
              "border-t border-[#dadce0] px-3 py-2 text-sm text-[#5f6368]",
            children: u,
          }),
        ],
      })
    : l.kind === "video" && l.url
      ? s.jsxs("div", {
          className: "mt-4 overflow-hidden rounded border border-[#dadce0]",
          children: [
            s.jsx("div", {
              className: "aspect-video bg-[#202124]",
              children: s.jsx("iframe", {
                className: "h-full w-full",
                src: l.url,
                title: u,
                allowFullScreen: !0,
              }),
            }),
            s.jsx("p", {
              className:
                "border-t border-[#dadce0] px-3 py-2 text-sm text-[#5f6368]",
              children: u,
            }),
          ],
        })
      : s.jsx("div", {
          className:
            "mt-4 flex min-h-28 items-center justify-center rounded border border-dashed border-[#dadce0] bg-[#f8fafd] px-4 py-6 text-sm text-[#5f6368]",
          children: u,
        });
}
function hm({ question: l, onChange: u }) {
  const a = Bm(l.answerKey);
  return s.jsxs("section", {
    className: "mt-4 rounded border border-[#dadce0] p-4",
    children: [
      s.jsxs("div", {
        className: "grid gap-3 sm:grid-cols-[120px_minmax(0,1fr)]",
        children: [
          s.jsxs("label", {
            className: "text-sm",
            children: [
              s.jsx("span", {
                className: "block text-xs font-medium uppercase text-[#5f6368]",
                children: "Points",
              }),
              s.jsx("input", {
                type: "number",
                min: 0,
                className:
                  "mt-1 w-full rounded border border-[#dadce0] px-3 py-2",
                value: l.points ?? 0,
                onChange: (d) => u({ points: Number(d.target.value) }),
              }),
            ],
          }),
          s.jsxs("label", {
            className: "text-sm",
            children: [
              s.jsx("span", {
                className: "block text-xs font-medium uppercase text-[#5f6368]",
                children: "Answer key",
              }),
              s.jsx("input", {
                className:
                  "mt-1 w-full rounded border border-[#dadce0] px-3 py-2",
                value: a,
                onChange: (d) => u({ answerKey: d.target.value }),
                placeholder: "Correct answer or rubric notes",
              }),
            ],
          }),
        ],
      }),
      s.jsxs("label", {
        className: "mt-3 block text-sm",
        children: [
          s.jsx("span", {
            className: "block text-xs font-medium uppercase text-[#5f6368]",
            children: "Feedback",
          }),
          s.jsx("textarea", {
            className:
              "mt-1 min-h-20 w-full rounded border border-[#dadce0] px-3 py-2",
            value: l.feedback ?? "",
            onChange: (d) => u({ feedback: d.target.value }),
            placeholder: "Feedback shown after marking",
          }),
        ],
      }),
    ],
  });
}
function gm({ question: l, onChange: u }) {
  return Wm(l.type)
    ? s.jsx(io, {
        label: "Options",
        values: l.options ?? [],
        fallbackPrefix: "Option",
        onChange: (a) => u({ options: a }),
      })
    : Xc(l.type)
      ? s.jsxs("div", {
          className: "mt-4 space-y-4 rounded border border-[#dadce0] p-4",
          children: [
            s.jsxs("div", {
              className: "grid gap-4 lg:grid-cols-2",
              children: [
                s.jsx(io, {
                  label: "Rows",
                  values: l.rows ?? [],
                  fallbackPrefix: "Row",
                  onChange: (a) => u({ rows: a }),
                }),
                s.jsx(io, {
                  label: "Columns",
                  values: l.columns ?? [],
                  fallbackPrefix: "Column",
                  onChange: (a) => u({ columns: a }),
                }),
              ],
            }),
            s.jsxs("div", {
              className: "grid gap-3 sm:grid-cols-2",
              children: [
                s.jsxs("label", {
                  className: "flex items-center gap-2 text-sm",
                  children: [
                    s.jsx("input", {
                      type: "checkbox",
                      checked: !!l.gridRequireResponsePerRow,
                      onChange: (a) =>
                        u({ gridRequireResponsePerRow: a.target.checked }),
                    }),
                    s.jsx("span", {
                      children: "Require a response in each row",
                    }),
                  ],
                }),
                s.jsxs("label", {
                  className: "flex items-center gap-2 text-sm",
                  children: [
                    s.jsx("input", {
                      type: "checkbox",
                      checked: !!l.gridLimitOneResponsePerColumn,
                      onChange: (a) =>
                        u({ gridLimitOneResponsePerColumn: a.target.checked }),
                    }),
                    s.jsx("span", {
                      children: "Limit to one response per column",
                    }),
                  ],
                }),
              ],
            }),
          ],
        })
      : l.type === "Linear scale"
        ? s.jsx(xm, { question: l, onChange: u })
        : l.type === "Rating"
          ? s.jsx(ym, { question: l, onChange: u })
          : l.type === "Date"
            ? s.jsx(vm, { question: l, onChange: u })
            : l.type === "Time"
              ? s.jsx(wm, { question: l, onChange: u })
              : l.type === "File upload"
                ? s.jsx(km, { question: l, onChange: u })
                : null;
}
function io({ label: l, values: u, fallbackPrefix: a, onChange: d }) {
  const f = u.length > 0 ? u : [`${a} 1`];
  function m(j, _) {
    d(f.map((P, U) => (U === j ? Dm(P, _) : P)));
  }
  function v(j) {
    const _ = f.filter((P, U) => U !== j);
    d(_.length > 0 ? _ : [`${a} 1`]);
  }
  function E() {
    d([...f, Um(f, `${a} ${f.length + 1}`)]);
  }
  return s.jsxs("section", {
    className: "mt-4 rounded border border-[#dadce0] p-4",
    children: [
      s.jsxs("div", {
        className: "mb-3 flex items-center justify-between gap-3",
        children: [
          s.jsx("h4", { className: "text-sm font-medium", children: l }),
          s.jsx("button", {
            type: "button",
            className: "text-sm font-medium text-[#673ab7]",
            onClick: E,
            children: "Add",
          }),
        ],
      }),
      s.jsx("div", {
        className: "space-y-2",
        children: f.map((j, _) =>
          s.jsxs(
            "div",
            {
              className: "grid grid-cols-[minmax(0,1fr)_auto] gap-2",
              children: [
                s.jsxs("label", {
                  children: [
                    s.jsxs("span", {
                      className: "sr-only",
                      children: [l, " ", _ + 1],
                    }),
                    s.jsx("input", {
                      className:
                        "w-full rounded border border-[#dadce0] px-3 py-2 text-sm",
                      value: Yc(j),
                      onChange: (P) => m(_, P.target.value),
                    }),
                  ],
                }),
                s.jsx("button", {
                  type: "button",
                  className:
                    "rounded border border-[#dadce0] px-3 py-2 text-sm text-[#5f6368] hover:border-[#d93025]",
                  onClick: () => v(_),
                  "aria-label": `Remove ${l} ${_ + 1}`,
                  children: "Remove",
                }),
              ],
            },
            `${l}-${_}`,
          ),
        ),
      }),
    ],
  });
}
function xm({ question: l, onChange: u }) {
  const a = l.scaleStart ?? 1,
    d = Jc(l.scaleEnd ?? 5, a);
  return s.jsx("section", {
    className: "mt-4 rounded border border-[#dadce0] p-4",
    children: s.jsxs("div", {
      className: "grid gap-3 sm:grid-cols-2",
      children: [
        s.jsxs("label", {
          className: "text-sm",
          children: [
            s.jsx("span", {
              className: "block text-xs font-medium uppercase text-[#5f6368]",
              children: "Scale starts at",
            }),
            s.jsxs("select", {
              className:
                "mt-1 w-full rounded border border-[#dadce0] bg-white px-3 py-2",
              value: a,
              onChange: (f) => u({ scaleStart: Number(f.target.value) }),
              children: [
                s.jsx("option", { value: 0, children: "0" }),
                s.jsx("option", { value: 1, children: "1" }),
              ],
            }),
          ],
        }),
        s.jsxs("label", {
          className: "text-sm",
          children: [
            s.jsx("span", {
              className: "block text-xs font-medium uppercase text-[#5f6368]",
              children: "Scale ends at",
            }),
            s.jsx("select", {
              className:
                "mt-1 w-full rounded border border-[#dadce0] bg-white px-3 py-2",
              value: d,
              onChange: (f) => u({ scaleEnd: Number(f.target.value) }),
              children: am.map((f) =>
                s.jsx("option", { value: f, children: f }, f),
              ),
            }),
          ],
        }),
        s.jsxs("label", {
          className: "text-sm",
          children: [
            s.jsx("span", {
              className: "block text-xs font-medium uppercase text-[#5f6368]",
              children: "Low label",
            }),
            s.jsx("input", {
              className:
                "mt-1 w-full rounded border border-[#dadce0] px-3 py-2",
              value: l.scaleLowLabel ?? "",
              onChange: (f) => u({ scaleLowLabel: f.target.value }),
              placeholder: "Low",
            }),
          ],
        }),
        s.jsxs("label", {
          className: "text-sm",
          children: [
            s.jsx("span", {
              className: "block text-xs font-medium uppercase text-[#5f6368]",
              children: "High label",
            }),
            s.jsx("input", {
              className:
                "mt-1 w-full rounded border border-[#dadce0] px-3 py-2",
              value: l.scaleHighLabel ?? "",
              onChange: (f) => u({ scaleHighLabel: f.target.value }),
              placeholder: "High",
            }),
          ],
        }),
      ],
    }),
  });
}
function ym({ question: l, onChange: u }) {
  return s.jsx("section", {
    className: "mt-4 rounded border border-[#dadce0] p-4",
    children: s.jsxs("div", {
      className: "grid gap-3 sm:grid-cols-2",
      children: [
        s.jsxs("label", {
          className: "text-sm",
          children: [
            s.jsx("span", {
              className: "block text-xs font-medium uppercase text-[#5f6368]",
              children: "Rating count",
            }),
            s.jsx("select", {
              className:
                "mt-1 w-full rounded border border-[#dadce0] bg-white px-3 py-2",
              value: l.ratingCount ?? 5,
              onChange: (a) => u({ ratingCount: Number(a.target.value) }),
              children: um.map((a) =>
                s.jsx("option", { value: a, children: a }, a),
              ),
            }),
          ],
        }),
        s.jsxs("label", {
          className: "text-sm",
          children: [
            s.jsx("span", {
              className: "block text-xs font-medium uppercase text-[#5f6368]",
              children: "Icon",
            }),
            s.jsxs("select", {
              className:
                "mt-1 w-full rounded border border-[#dadce0] bg-white px-3 py-2",
              value: l.ratingIcon ?? "star",
              onChange: (a) => u({ ratingIcon: a.target.value }),
              children: [
                s.jsx("option", { value: "star", children: "Star" }),
                s.jsx("option", { value: "heart", children: "Heart" }),
                s.jsx("option", { value: "thumb", children: "Thumb" }),
              ],
            }),
          ],
        }),
      ],
    }),
  });
}
function vm({ question: l, onChange: u }) {
  return s.jsx("section", {
    className: "mt-4 rounded border border-[#dadce0] p-4",
    children: s.jsxs("div", {
      className: "grid gap-3 sm:grid-cols-2",
      children: [
        s.jsxs("label", {
          className: "flex items-center gap-2 text-sm",
          children: [
            s.jsx("input", {
              type: "checkbox",
              checked: l.dateIncludeYear ?? !0,
              onChange: (a) => u({ dateIncludeYear: a.target.checked }),
            }),
            s.jsx("span", { children: "Include year" }),
          ],
        }),
        s.jsxs("label", {
          className: "flex items-center gap-2 text-sm",
          children: [
            s.jsx("input", {
              type: "checkbox",
              checked: !!l.dateIncludeTime,
              onChange: (a) => u({ dateIncludeTime: a.target.checked }),
            }),
            s.jsx("span", { children: "Include time" }),
          ],
        }),
      ],
    }),
  });
}
function wm({ question: l, onChange: u }) {
  return s.jsx("section", {
    className: "mt-4 rounded border border-[#dadce0] p-4",
    children: s.jsxs("label", {
      className: "flex items-center gap-2 text-sm",
      children: [
        s.jsx("input", {
          type: "checkbox",
          checked: !!l.timeDuration,
          onChange: (a) => u({ timeDuration: a.target.checked }),
        }),
        s.jsx("span", { children: "Duration" }),
      ],
    }),
  });
}
function km({ question: l, onChange: u }) {
  const a = l.fileUpload ?? {},
    d = a.allowedTypes ?? [];
  function f(v) {
    u({ fileUpload: { ...a, ...v } });
  }
  function m(v) {
    const E = d.includes(v) ? d.filter((j) => j !== v) : [...d, v];
    f({ allowedTypes: E });
  }
  return s.jsxs("section", {
    className: "mt-4 rounded border border-[#dadce0] p-4",
    children: [
      s.jsxs("div", {
        className: "grid gap-3 sm:grid-cols-2",
        children: [
          s.jsxs("label", {
            className: "text-sm",
            children: [
              s.jsx("span", {
                className: "block text-xs font-medium uppercase text-[#5f6368]",
                children: "Max files",
              }),
              s.jsx("input", {
                type: "number",
                min: 1,
                max: 10,
                className:
                  "mt-1 w-full rounded border border-[#dadce0] px-3 py-2",
                value: a.maxFiles ?? 1,
                onChange: (v) => f({ maxFiles: Number(v.target.value) }),
              }),
            ],
          }),
          s.jsxs("label", {
            className: "text-sm",
            children: [
              s.jsx("span", {
                className: "block text-xs font-medium uppercase text-[#5f6368]",
                children: "Max file size MB",
              }),
              s.jsx("input", {
                type: "number",
                min: 1,
                className:
                  "mt-1 w-full rounded border border-[#dadce0] px-3 py-2",
                value: a.maxFileSizeMb ?? 10,
                onChange: (v) => f({ maxFileSizeMb: Number(v.target.value) }),
              }),
            ],
          }),
        ],
      }),
      s.jsx("div", {
        className: "mt-3 grid gap-2 sm:grid-cols-2",
        children: cm.map((v) =>
          s.jsxs(
            "label",
            {
              className: "flex items-center gap-2 text-sm capitalize",
              children: [
                s.jsx("input", {
                  type: "checkbox",
                  checked: d.includes(v),
                  onChange: () => m(v),
                }),
                s.jsx("span", { children: v }),
              ],
            },
            v,
          ),
        ),
      }),
    ],
  });
}
function jm({ question: l, value: u, disabled: a, onChange: d }) {
  if (l.type === "Short answer")
    return s.jsx("input", {
      className: rs,
      value: un(u),
      onChange: (f) => d(f.target.value),
      disabled: a,
      placeholder: "Short answer text",
    });
  if (l.type === "Paragraph")
    return s.jsx("textarea", {
      className: rs,
      value: un(u),
      onChange: (f) => d(f.target.value),
      disabled: a,
      placeholder: "Long answer text",
    });
  if (l.type === "Multiple choice")
    return s.jsx(Sm, {
      question: l,
      value: un(u),
      disabled: a,
      type: "radio",
      onChange: d,
    });
  if (l.type === "Checkboxes")
    return s.jsx(Nm, { question: l, value: po(u), disabled: a, onChange: d });
  if (l.type === "Dropdown")
    return s.jsxs("select", {
      className:
        "mt-4 w-full rounded border border-[#dadce0] bg-white px-3 py-2 text-sm",
      value: un(u),
      onChange: (f) => d(f.target.value),
      disabled: a,
      children: [
        s.jsx("option", { value: "", children: "Choose" }),
        Vr(l.options).map((f) => s.jsx("option", { value: f, children: f }, f)),
      ],
    });
  if (l.type === "File upload")
    return s.jsx(Cm, { question: l, disabled: a, onChange: d });
  if (l.type === "Linear scale")
    return s.jsx(bm, { question: l, value: un(u), disabled: a, onChange: d });
  if (l.type === "Rating")
    return s.jsx(zm, { question: l, value: un(u), disabled: a, onChange: d });
  if (Xc(l.type))
    return s.jsx(Em, { question: l, value: Vm(u), disabled: a, onChange: d });
  if (l.type === "Date") {
    const f = l.dateIncludeTime ? "datetime-local" : "date";
    return s.jsx("input", {
      className: rs,
      type: f,
      value: un(u),
      onChange: (m) => d(m.target.value),
      disabled: a,
    });
  }
  return s.jsx("input", {
    className: rs,
    type: l.timeDuration ? "text" : "time",
    value: un(u),
    onChange: (f) => d(f.target.value),
    disabled: a,
    placeholder: l.timeDuration ? "HH:MM:SS" : void 0,
  });
}
function Sm({ question: l, value: u, disabled: a, type: d, onChange: f }) {
  return s.jsx("div", {
    className: "mt-4 space-y-3",
    children: Vr(l.options).map((m) =>
      s.jsxs(
        "label",
        {
          className: "flex items-center gap-3 text-sm",
          children: [
            s.jsx("input", {
              type: d,
              name: `question-${l.id}`,
              checked: u === m,
              onChange: () => f(m),
              disabled: a,
            }),
            s.jsx("span", { children: m }),
          ],
        },
        m,
      ),
    ),
  });
}
function Nm({ question: l, value: u, disabled: a, onChange: d }) {
  function f(m) {
    d(u.includes(m) ? u.filter((v) => v !== m) : [...u, m]);
  }
  return s.jsx("div", {
    className: "mt-4 space-y-3",
    children: Vr(l.options).map((m) =>
      s.jsxs(
        "label",
        {
          className: "flex items-center gap-3 text-sm",
          children: [
            s.jsx("input", {
              type: "checkbox",
              checked: u.includes(m),
              onChange: () => f(m),
              disabled: a,
            }),
            s.jsx("span", { children: m }),
          ],
        },
        m,
      ),
    ),
  });
}
function Cm({ question: l, disabled: u, onChange: a }) {
  const d = l.fileUpload ?? {},
    f = d.allowedTypes ?? [],
    m = Tm(d.maxFiles),
    v = Am(d.maxFileSizeMb),
    E = Rm(f),
    j = f.length > 0 ? f.map(Im).join(", ") : "any file type",
    [_, P] = X.useState(""),
    [U, W] = X.useState([]);
  function xe(ue) {
    const $ = Array.from(ue.currentTarget.files ?? []),
      G = $.slice(0, m),
      le = [],
      ve = [],
      Ce = [];
    if ($.length > m) {
      const J = $.length - m;
      le.push(
        `Selection was limited to ${ns(m)}; ${J} extra ${Kc("file", J)} were ignored.`,
      );
    }
    (G.forEach((J) => {
      const ce = Mm(J, f, v);
      if (ce.length > 0) {
        Ce.push(`${J.name} (${ce.join(", ")})`);
        return;
      }
      ve.push(Lm(J));
    }),
      Ce.length > 0 && le.push(`Rejected ${ns(Ce.length)}: ${Ce.join("; ")}.`),
      $.length === 0
        ? le.push("No files selected.")
        : ve.length === 0
          ? le.push("No file metadata was recorded.")
          : le.push(`${ns(ve.length)} recorded locally as metadata.`),
      W(ve),
      P(le.join(" ")),
      a({ files: ve.map((J) => J.name), fileDetails: ve }),
      (ue.currentTarget.value = ""));
  }
  return s.jsxs("div", {
    className: "mt-4 rounded border border-[#dadce0] p-4 text-sm",
    children: [
      s.jsx("input", {
        type: "file",
        multiple: m > 1,
        accept: E,
        onChange: xe,
        disabled: u,
        "aria-label": "Choose files for metadata-only upload prototype",
      }),
      s.jsxs("p", {
        className: "mt-2 text-[#5f6368]",
        children: [ns(m), " limit, ", v, " MB each, accepts ", j, "."],
      }),
      s.jsx("p", {
        className: "mt-1 text-[#5f6368]",
        children:
          "Prototype only: files are recorded locally as name, size, and MIME type metadata. No file content is uploaded or stored.",
      }),
      _
        ? s.jsx("p", {
            className:
              "mt-2 rounded border border-[#fbbc04] bg-[#fff8e1] px-3 py-2 text-[#8a5a00]",
            role: "status",
            children: _,
          })
        : null,
      U.length > 0
        ? s.jsx("ul", {
            className: "mt-3 space-y-1 text-[#3c4043]",
            children: U.map((ue) =>
              s.jsxs(
                "li",
                {
                  children: [
                    ue.name,
                    " (",
                    Om(ue.sizeBytes),
                    ", ",
                    ue.mimeType || "MIME type unavailable",
                    ")",
                  ],
                },
                `${ue.name}-${ue.sizeBytes ?? "unknown"}`,
              ),
            ),
          })
        : null,
    ],
  });
}
function bm({ question: l, value: u, disabled: a, onChange: d }) {
  const f = l.scaleStart ?? 1,
    m = Jc(l.scaleEnd ?? 5, f);
  return s.jsxs("div", {
    className: "mt-4",
    children: [
      s.jsx("div", {
        className: "grid auto-cols-fr grid-flow-col gap-2 text-center text-sm",
        children: qc(f, m).map((v) =>
          s.jsxs(
            "label",
            {
              className: "rounded border border-[#dadce0] px-2 py-3",
              children: [
                s.jsx("input", {
                  className: "sr-only",
                  type: "radio",
                  name: `question-${l.id}`,
                  checked: u === String(v),
                  onChange: () => d(String(v)),
                  disabled: a,
                }),
                s.jsx("span", {
                  className:
                    u === String(v) ? "font-semibold text-[#673ab7]" : "",
                  children: v,
                }),
              ],
            },
            v,
          ),
        ),
      }),
      s.jsxs("div", {
        className: "mt-2 flex justify-between gap-3 text-xs text-[#5f6368]",
        children: [
          s.jsx("span", { children: l.scaleLowLabel ?? "" }),
          s.jsx("span", { children: l.scaleHighLabel ?? "" }),
        ],
      }),
    ],
  });
}
function zm({ question: l, value: u, disabled: a, onChange: d }) {
  const f = Hm(l.ratingIcon ?? "star");
  return s.jsx("div", {
    className: "mt-4 flex flex-wrap gap-2",
    children: qc(1, l.ratingCount ?? 5).map((m) =>
      s.jsx(
        "button",
        {
          type: "button",
          className: `h-10 w-10 rounded-full border text-sm font-medium ${u === String(m) ? "border-[#673ab7] bg-[#f3e8fd] text-[#673ab7]" : "border-[#dadce0]"}`,
          onClick: () => d(String(m)),
          disabled: a,
          "aria-label": `Rating ${m}`,
          children: f,
        },
        m,
      ),
    ),
  });
}
function Em({ question: l, value: u, disabled: a, onChange: d }) {
  const f = Vr(l.rows),
    m = Vr(l.columns),
    v = l.type === "Checkbox grid";
  function E(j, _) {
    if (!v) {
      const xe = Pc({ ...u, [j]: _ }, j, _, l);
      d(xe);
      return;
    }
    const P = po(u[j]),
      U = P.includes(_) ? P.filter((xe) => xe !== _) : [...P, _],
      W = Pc({ ...u, [j]: U }, j, _, l);
    d(W);
  }
  return s.jsx("div", {
    className: "mt-4 overflow-x-auto",
    children: s.jsxs("table", {
      className: "min-w-full border-collapse text-sm",
      children: [
        s.jsx("thead", {
          children: s.jsxs("tr", {
            children: [
              s.jsx("th", { className: "w-32 px-3 py-2" }),
              m.map((j) =>
                s.jsx(
                  "th",
                  {
                    className:
                      "px-3 py-2 text-center font-medium text-[#5f6368]",
                    children: j,
                  },
                  j,
                ),
              ),
            ],
          }),
        }),
        s.jsx("tbody", {
          children: f.map((j) =>
            s.jsxs(
              "tr",
              {
                className: "border-t border-[#f1f3f4]",
                children: [
                  s.jsx("td", {
                    className: "py-3 pr-3 font-medium",
                    children: j,
                  }),
                  m.map((_) => {
                    const P = u[j],
                      U = v ? po(P).includes(_) : P === _;
                    return s.jsx(
                      "td",
                      {
                        className: "px-3 py-3 text-center",
                        children: s.jsx("input", {
                          type: v ? "checkbox" : "radio",
                          name: `${l.id}-${j}`,
                          checked: U,
                          onChange: () => E(j, _),
                          disabled: a,
                          "aria-label": `${j} ${_}`,
                        }),
                      },
                      _,
                    );
                  }),
                ],
              },
              j,
            ),
          ),
        }),
      ],
    }),
  });
}
function Rm(l) {
  if (l.length !== 0) return l.flatMap((u) => Gc[u]).join(",");
}
function Mm(l, u, a) {
  const d = [];
  return (
    Pm(l, u) || d.push("type not allowed"),
    l.size > a * fo && d.push(`larger than ${a} MB`),
    d
  );
}
function Pm(l, u) {
  return u.length === 0 ? !0 : u.some((a) => Gc[a].some((d) => _m(l, d)));
}
function _m(l, u) {
  const a = u.toLowerCase(),
    d = l.type.toLowerCase(),
    f = l.name.toLowerCase();
  return a.startsWith(".")
    ? f.endsWith(a)
    : a.endsWith("/*")
      ? d.startsWith(a.slice(0, -1))
      : !!d && d === a;
}
function Lm(l) {
  return { name: l.name, sizeBytes: l.size, mimeType: l.type || void 0 };
}
function Tm(l) {
  return Number.isFinite(l) ? Math.max(1, Math.floor(Number(l))) : 1;
}
function Am(l) {
  return Number.isFinite(l) ? Math.max(1, Number(l)) : 10;
}
function Im(l) {
  return l.charAt(0).toUpperCase() + l.slice(1);
}
function ns(l) {
  return `${l} ${Kc("file", l)}`;
}
function Kc(l, u) {
  return u === 1 ? l : `${l}s`;
}
function Om(l) {
  return typeof l != "number"
    ? "size unavailable"
    : l < 1024
      ? `${l} B`
      : l < fo
        ? `${(l / 1024).toFixed(1)} KB`
        : `${(l / fo).toFixed(1)} MB`;
}
function Fm() {}
function Zc(l) {
  return l.mediaPrompt
    ? l.mediaPrompt
    : typeof l.media == "object"
      ? l.media
      : { kind: l.media ?? "none" };
}
function Yc(l) {
  return typeof l == "string" ? l : l.label;
}
function Dm(l, u) {
  return typeof l == "string" ? u : { ...l, label: u };
}
function Um(l, u) {
  return l.some((a) => typeof a != "string") ? { id: $m(u), label: u } : u;
}
function Vr(l) {
  return (l && l.length > 0 ? l : ["Option 1"]).map(Yc);
}
function $m(l) {
  return (
    l
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-|-$/g, "") || "choice"
  );
}
function Wm(l) {
  return l === "Multiple choice" || l === "Checkboxes" || l === "Dropdown";
}
function Xc(l) {
  return l === "Multiple choice grid" || l === "Checkbox grid";
}
function Jc(l, u) {
  const a = Math.max(2, u + 1);
  return Math.min(10, Math.max(a, l));
}
function Bm(l) {
  return l === void 0
    ? ""
    : typeof l == "object"
      ? JSON.stringify(l)
      : String(l);
}
function un(l) {
  return typeof l == "string" || typeof l == "number" ? String(l) : "";
}
function po(l) {
  return Array.isArray(l) ? l : typeof l == "string" && l.length > 0 ? [l] : [];
}
function Vm(l) {
  return l && typeof l == "object" && !Array.isArray(l) && !("files" in l)
    ? l
    : {};
}
function Pc(l, u, a, d) {
  return d.gridLimitOneResponsePerColumn
    ? Object.fromEntries(
        Object.entries(l).map(([f, m]) =>
          f === u
            ? [f, m]
            : Array.isArray(m)
              ? [f, m.filter((v) => v !== a)]
              : [f, m === a ? "" : m],
        ),
      )
    : l;
}
function Hm(l) {
  return l === "heart" ? "<3" : l === "thumb" ? "+1" : "*";
}
function qc(l, u) {
  return Array.from({ length: Math.max(0, u - l + 1) }, (a, d) => l + d);
}
const rs =
    "mt-4 w-full border-b border-[#dadce0] bg-transparent py-2 text-sm outline-none focus:border-[#673ab7] disabled:text-[#5f6368]",
  ed = "submit",
  vo = "comp-school.forms.prototype",
  Wt = {
    id: "form-j277-exit-ticket",
    title: "J277 Lesson Exit Ticket",
    description:
      "A Google Forms-style classroom check with quiz scoring and media-rich prompts.",
    createdAt: "2026-07-03T08:00:00.000Z",
    updatedAt: "2026-07-03T08:00:00.000Z",
    settings: {
      quiz: {
        enabled: !0,
        releaseGrades: "immediate",
        showMissedQuestions: !0,
        showCorrectAnswers: !0,
        showPointValues: !0,
      },
      responses: {
        acceptingResponses: !0,
        allowEditAfterSubmit: !1,
        limitToOneResponse: !1,
        confirmationMessage: "Thanks. Your response has been recorded.",
      },
      presentation: { showProgressBar: !0, shuffleQuestionOrder: !1 },
    },
    sections: [
      {
        id: "section-knowledge",
        title: "Core knowledge",
        description: "Quick checks for definitions and core concepts.",
        questions: [
          {
            id: "q-short-answer",
            type: "Short answer",
            title: "Which data type is best for True or False?",
            description: "Use the exact data type name.",
            required: !0,
            points: 1,
            answerKey: { mode: "exact", acceptedAnswers: ["Boolean"] },
            feedback: {
              correct: "A Boolean stores one of two states.",
              incorrect:
                "Look for the data type with only true and false states.",
            },
            media: { type: "none" },
            validation: { type: "length", condition: "min", value: 3 },
          },
          {
            id: "q-paragraph",
            type: "Paragraph",
            title: "Explain why validation is not the same as verification.",
            description: "Write two or three sentences.",
            required: !0,
            points: 4,
            answerKey: { mode: "manual" },
            feedback: {
              general:
                "Strong answers distinguish rules-based validation from checking against the source.",
            },
            media: { type: "none" },
            validation: { type: "length", condition: "min", value: 40 },
          },
          {
            id: "q-multiple-choice",
            type: "Multiple choice",
            title: "Which data type stores whole numbers?",
            required: !0,
            points: 1,
            answerKey: { mode: "exact", acceptedAnswers: ["Integer"] },
            feedback: { correct: "Integers store whole numbers." },
            media: { type: "none" },
            options: [
              { id: "string", label: "String" },
              { id: "integer", label: "Integer" },
              { id: "real", label: "Real" },
              { id: "boolean", label: "Boolean" },
            ],
          },
          {
            id: "q-checkboxes",
            type: "Checkboxes",
            title: "Select the fetch-decode-execute cycle stages.",
            required: !0,
            points: 3,
            answerKey: {
              mode: "set",
              acceptedAnswers: ["Fetch", "Decode", "Execute"],
              partialCredit: !0,
            },
            feedback: {
              general: "The processor repeats fetch, decode, and execute.",
            },
            media: { type: "none" },
            options: [
              { id: "fetch", label: "Fetch" },
              { id: "decode", label: "Decode" },
              { id: "execute", label: "Execute" },
              { id: "store", label: "Store" },
            ],
          },
          {
            id: "q-dropdown",
            type: "Dropdown",
            title:
              "Which construct repeats instructions while a condition is true?",
            required: !0,
            points: 1,
            answerKey: { mode: "exact", acceptedAnswers: ["Iteration"] },
            media: { type: "none" },
            options: [
              { id: "sequence", label: "Sequence" },
              { id: "selection", label: "Selection" },
              { id: "iteration", label: "Iteration" },
            ],
          },
          {
            id: "q-file-upload",
            type: "File upload",
            title: "Upload your annotated trace table.",
            description:
              "Images or PDFs are accepted. This question needs teacher review.",
            required: !1,
            points: 2,
            answerKey: { mode: "manual" },
            media: { type: "none" },
            fileUpload: {
              maxFiles: 1,
              maxFileSizeMb: 10,
              acceptedTypes: ["image", "pdf"],
            },
          },
        ],
      },
      {
        id: "section-confidence",
        title: "Confidence and reflection",
        description: "Self-assessment questions.",
        questions: [
          {
            id: "q-linear-scale",
            type: "Linear scale",
            title: "How confident are you with binary addition?",
            required: !0,
            points: 1,
            answerKey: { mode: "exact", acceptedAnswers: [4, 5] },
            media: { type: "none" },
            scale: {
              start: 1,
              end: 5,
              lowLabel: "Not confident",
              highLabel: "Very confident",
            },
          },
          {
            id: "q-rating",
            type: "Rating",
            title: "Rate how useful today's worked example was.",
            required: !1,
            points: 1,
            answerKey: { mode: "exact", acceptedAnswers: [4, 5] },
            media: { type: "none" },
            rating: {
              max: 5,
              icon: "star",
              lowLabel: "Not useful",
              highLabel: "Very useful",
            },
          },
          {
            id: "q-date",
            type: "Date",
            title: "What is the deadline date for your revision task?",
            required: !0,
            points: 1,
            answerKey: { mode: "exact", acceptedAnswers: ["2026-07-10"] },
            media: { type: "none" },
            validation: { type: "none" },
            date: { includeYear: !0, includeTime: !1 },
          },
          {
            id: "q-time",
            type: "Time",
            title: "What time does the revision clinic start?",
            required: !0,
            points: 1,
            answerKey: { mode: "exact", acceptedAnswers: ["15:30"] },
            media: { type: "none" },
            validation: { type: "none" },
            time: { mode: "time" },
          },
        ],
      },
      {
        id: "section-grids",
        title: "Grid checks",
        description: "Matrix-style questions.",
        questions: [
          {
            id: "q-multiple-choice-grid",
            type: "Multiple choice grid",
            title: "Classify each storage example.",
            required: !0,
            points: 2,
            answerKey: {
              mode: "grid",
              expected: { RAM: "Volatile", ROM: "Non-volatile" },
              partialCredit: !0,
            },
            media: { type: "none" },
            grid: {
              rows: ["RAM", "ROM"],
              columns: ["Volatile", "Non-volatile"],
              requireOneResponsePerRow: !0,
            },
          },
          {
            id: "q-checkbox-grid",
            type: "Checkbox grid",
            title: "Match each check with the stage where it can be useful.",
            required: !1,
            points: 4,
            answerKey: {
              mode: "grid",
              expected: {
                "Presence check": ["Data entry", "Form submission"],
                "Range check": ["Data entry"],
                "Double entry": ["Verification"],
                Proofreading: ["Verification"],
              },
              partialCredit: !0,
            },
            feedback: {
              general:
                "Validation checks rules; verification checks against a source or duplicate entry.",
            },
            media: { type: "none" },
            grid: {
              rows: [
                "Presence check",
                "Range check",
                "Double entry",
                "Proofreading",
              ],
              columns: ["Data entry", "Form submission", "Verification"],
              requireOneResponsePerRow: !1,
              shuffleRows: !1,
            },
          },
        ],
      },
    ],
  };
[
  {
    id: "response-amira-001",
    formId: Wt.id,
    submittedAt: "2026-07-03T09:12:00.000Z",
    respondent: { name: "Amira" },
    answers: {
      "q-short-answer": "Boolean",
      "q-paragraph":
        "Validation checks whether data follows rules. Verification checks whether it matches the original source.",
      "q-multiple-choice": "Integer",
      "q-checkboxes": ["Fetch", "Decode", "Execute"],
      "q-dropdown": "Iteration",
      "q-file-upload": [
        {
          name: "trace-table.pdf",
          sizeBytes: 248912,
          mimeType: "application/pdf",
        },
      ],
      "q-linear-scale": 5,
      "q-rating": 4,
      "q-date": "2026-07-10",
      "q-time": "15:30",
      "q-multiple-choice-grid": { RAM: "Volatile", ROM: "Non-volatile" },
      "q-checkbox-grid": {
        "Presence check": ["Data entry", "Form submission"],
        "Range check": ["Data entry"],
        "Double entry": ["Verification"],
        Proofreading: ["Verification"],
      },
    },
    score: {
      pointsAwarded: 0,
      pointsPossible: 0,
      autoPointsPossible: 0,
      manualPointsPossible: 0,
      manualReviewRequired: !1,
      questionScores: [],
    },
  },
].map((l) => ({ ...l, score: ko(Wt, l.answers) }));
function En(l) {
  return l.sections.flatMap((u) => u.questions);
}
function td(l, u = l.sections[0]?.id, a = {}) {
  const d = new Map(l.sections.map((U) => [U.id, U])),
    f = [],
    m = new Set();
  let v = u,
    E = "end",
    j,
    _;
  for (; v;) {
    if (m.has(v)) {
      ((E = "cycle"), (_ = v));
      break;
    }
    const U = d.get(v);
    if (!U) {
      ((E = "missing-section"), (j = v));
      break;
    }
    (f.push(U), m.add(U.id));
    const W = rh(l, U, a);
    if (!W) {
      E = "end";
      break;
    }
    if (W === ed) {
      E = "submit";
      break;
    }
    v = W;
  }
  const P = f.flatMap((U) => U.questions);
  return {
    startSectionId: u,
    sections: f,
    questions: P,
    sectionIds: f.map((U) => U.id),
    questionIds: P.map((U) => U.id),
    terminal: E,
    missingSectionId: j,
    cycleSectionId: _,
  };
}
function Qm(l, u, a = {}) {
  return td(l, u, a).sections;
}
function wo(l, u, a = {}) {
  return td(l, u, a).questions;
}
function Gm(l, u) {
  const a = [],
    d = sh(l, u),
    f = ih(u);
  if (
    (l.required &&
      (f || d.length > 0) &&
      a.push(
        Ke(
          l,
          "required",
          d.length > 0
            ? "Answer every required row."
            : "This question is required.",
        ),
      ),
    f)
  )
    return a;
  l.type === "File upload" && a.push(...oh(l, u));
  const m = l.validation ?? { type: "none" };
  return (
    m.type === "none" ||
      (m.type === "text" && a.push(...ah(l, u, m)),
      m.type === "length" && a.push(...uh(l, u, m)),
      m.type === "number" && a.push(...ch(l, u, m)),
      m.type === "regex" && a.push(...dh(l, u, m)),
      m.type === "url" && a.push(...fh(l, u, m))),
    a
  );
}
function Km(l, u, a = {}) {
  const f = (a.includeUnreachable ? En(l) : wo(l, a.startSectionId, u)).reduce(
      (v, E) => {
        const j = Gm(E, u[E.id]);
        return (j.length > 0 && (v[E.id] = j), v);
      },
      {},
    ),
    m = Object.values(f).flatMap((v) => v ?? []);
  return { valid: m.length === 0, errors: f, questionErrors: m };
}
function ko(l, u, a = {}) {
  return !l.settings.quiz.enabled && a.scoreQuizDisabled === !1
    ? Zm(l)
    : (a.startSectionId ? wo(l, a.startSectionId, u) : En(l))
        .map((m) => jh(m, u[m.id]))
        .reduce(
          (m, v) => ({
            pointsAwarded: m.pointsAwarded + v.pointsAwarded,
            pointsPossible: m.pointsPossible + v.pointsPossible,
            autoPointsPossible:
              m.autoPointsPossible +
              (v.manualReviewRequired ? 0 : v.pointsPossible),
            manualPointsPossible:
              m.manualPointsPossible +
              (v.manualReviewRequired ? v.pointsPossible : 0),
            manualReviewRequired:
              m.manualReviewRequired || v.manualReviewRequired,
            questionScores: [...m.questionScores, v],
          }),
          {
            pointsAwarded: 0,
            pointsPossible: 0,
            autoPointsPossible: 0,
            manualPointsPossible: 0,
            manualReviewRequired: !1,
            questionScores: [],
          },
        );
}
function Zm(l) {
  return {
    pointsAwarded: 0,
    pointsPossible: 0,
    autoPointsPossible: 0,
    manualPointsPossible: 0,
    manualReviewRequired: !1,
    questionScores: En(l).map((u) => ({
      questionId: u.id,
      type: u.type,
      pointsAwarded: 0,
      pointsPossible: 0,
      correct: null,
      manualReviewRequired: !1,
      reason: "Quiz disabled",
    })),
  };
}
function Ym(l) {
  const u = l.questionScores.filter((v) => !v.manualReviewRequired),
    a = l.questionScores.filter((v) => v.manualReviewRequired),
    d = bn(u.reduce((v, E) => v + E.pointsAwarded, 0)),
    f = bn(u.reduce((v, E) => v + E.pointsPossible, 0)),
    m = bn(a.reduce((v, E) => v + E.pointsPossible, 0));
  return {
    pointsAwarded: d,
    pointsPossible: f,
    autoPointsPossible: f,
    manualPointsPossible: m,
    manualReviewRequired: l.manualReviewRequired || a.length > 0,
    questionCount: u.length,
  };
}
function nd(l) {
  const u = Ym(l),
    a =
      u.pointsPossible > 0
        ? bn((u.pointsAwarded / u.pointsPossible) * 100)
        : null;
  return {
    ...u,
    percentage: a,
    scoreLabel: `${ss(u.pointsAwarded)} / ${ss(u.pointsPossible)}`,
    percentageLabel: a === null ? "No auto-scored points" : `${ss(a)}%`,
  };
}
function Xm(l, u, a = {}) {
  const d = u.submittedAt ?? new Date().toISOString();
  return {
    id: Mh("response"),
    formId: l.id,
    submittedAt: d,
    respondent: u.respondent,
    answers: u.answers,
    score: ko(l, u.answers, a),
  };
}
function Jm(l, u, a = {}) {
  const d = Xm(l, u, a),
    m = [...(a.existingResponses ?? rd(l.id, a)), d];
  return (a.persist !== !1 && nh(l.id, m, a), { response: d, responses: m });
}
function qm(l, u = {}) {
  const a = Qr(u.storage);
  a && (a.setItem(id(l.id), JSON.stringify(l)), a.setItem(od(), l.id));
}
function eh(l = Wt.id, u = {}) {
  const a = Qr(u.storage);
  if (!a) return u.fallback ?? Wt;
  const d = a.getItem(id(l));
  return ud(d, u.fallback ?? Wt);
}
function th(l = {}) {
  const a = Qr(l.storage)?.getItem(od()) ?? Wt.id;
  return eh(a, l);
}
function nh(l, u, a = {}) {
  const d = Qr(a.storage);
  d && d.setItem(ad(l), JSON.stringify(u));
}
function rd(l = Wt.id, u = {}) {
  const a = Qr(u.storage);
  return a ? ud(a.getItem(ad(l)), []) : [];
}
function rh(l, u, a) {
  const d = lh(u, a);
  if (d) return d;
  if (u.nextSectionId) return u.nextSectionId;
  const f = l.sections.findIndex((m) => m.id === u.id);
  if (f !== -1) return l.sections[f + 1]?.id ?? ed;
}
function lh(l, u) {
  for (const a of l.questions) {
    if (a.type !== "Multiple choice" && a.type !== "Dropdown") continue;
    const d = u[a.id];
    if (typeof d != "string" && typeof d != "number") continue;
    const f = a.options?.find((m) => m.label === String(d));
    if (f?.nextSectionId) return f.nextSectionId;
  }
}
function Ke(l, u, a) {
  return { questionId: l.id, type: u, message: a };
}
function sh(l, u) {
  if (!l.grid?.requireOneResponsePerRow) return [];
  const a = sd(u);
  return l.grid.rows.filter((d) => ld(a?.[d]));
}
function ih(l) {
  if (l == null) return !0;
  if (typeof l == "string") return l.trim().length === 0;
  if (typeof l == "number") return !1;
  if (Array.isArray(l)) return l.length === 0;
  const u = Object.values(l);
  return u.length === 0 || u.every(ld);
}
function ld(l) {
  return l === void 0
    ? !0
    : Array.isArray(l)
      ? l.length === 0 || l.every(_c)
      : _c(l);
}
function _c(l) {
  return typeof l == "string" ? l.trim().length === 0 : !1;
}
function oh(l, u) {
  const a = l.fileUpload;
  if (!a) return [];
  if (!Array.isArray(u) || !u.every(hh))
    return [Ke(l, "file-count", "Upload files in a valid list.")];
  const d = [],
    f = Math.max(0, a.maxFiles);
  u.length > f &&
    d.push(Ke(l, "file-count", `Upload no more than ${f} file(s).`));
  const m =
    a.maxFileSizeMb > 0
      ? a.maxFileSizeMb * 1024 * 1024
      : Number.POSITIVE_INFINITY;
  return (
    u.forEach((v) => {
      (typeof v.sizeBytes == "number" &&
        v.sizeBytes > m &&
        d.push(
          Ke(
            l,
            "file-size",
            `${v.name} is larger than ${ss(a.maxFileSizeMb)} MB.`,
          ),
        ),
        gh(v, a.acceptedTypes) ||
          d.push(
            Ke(l, "file-type", `${v.name} is not an accepted file type.`),
          ));
    }),
    d
  );
}
function ah(l, u, a) {
  const d = as(u);
  if (d === null)
    return [Ke(l, "text", a.message ?? "Enter text for this question.")];
  const f = Lc(d),
    m = Lc(a.value),
    v = f.includes(m);
  return (a.condition === "contains" && !v) ||
    (a.condition === "does-not-contain" && v)
    ? [Ke(l, "text", a.message ?? "Answer does not match the text rule.")]
    : [];
}
function uh(l, u, a) {
  const d = as(u);
  if (d === null)
    return [Ke(l, "length", a.message ?? "Enter text for this question.")];
  const f = d.trim().length;
  if (!(
    (a.condition === "min" && f < a.value) ||
    (a.condition === "max" && f > a.value)
  ))
    return [];
  const v =
    a.condition === "min"
      ? `Use at least ${a.value} character(s).`
      : `Use no more than ${a.value} character(s).`;
  return [Ke(l, "length", a.message ?? v)];
}
function ch(l, u, a) {
  const d = mh(u);
  if (d === null)
    return [Ke(l, "number", a.message ?? "Enter a valid number.")];
  const f = typeof a.min == "number" && d < a.min,
    m = typeof a.max == "number" && d > a.max;
  return (a.condition === "min" && f) ||
    (a.condition === "max" && m) ||
    (a.condition === "between" && (f || m))
    ? [Ke(l, "number", a.message ?? ph(a))]
    : [];
}
function dh(l, u, a) {
  const d = as(u);
  if (d === null)
    return [Ke(l, "regex", a.message ?? "Use the required format.")];
  try {
    return new RegExp(a.pattern).test(d)
      ? []
      : [Ke(l, "regex", a.message ?? "Use the required format.")];
  } catch {
    return [Ke(l, "regex", a.message ?? "The validation pattern is invalid.")];
  }
}
function fh(l, u, a) {
  const d = as(u);
  if (d === null) return [Ke(l, "url", a.message ?? "Enter a valid URL.")];
  try {
    const f = new URL(d.trim());
    return f.protocol === "http:" || f.protocol === "https:"
      ? []
      : [Ke(l, "url", a.message ?? "Enter a valid URL.")];
  } catch {
    return [Ke(l, "url", a.message ?? "Enter a valid URL.")];
  }
}
function ph(l) {
  return l.condition === "min" && typeof l.min == "number"
    ? `Enter a number greater than or equal to ${l.min}.`
    : l.condition === "max" && typeof l.max == "number"
      ? `Enter a number less than or equal to ${l.max}.`
      : typeof l.min == "number" && typeof l.max == "number"
        ? `Enter a number between ${l.min} and ${l.max}.`
        : "Enter a valid number.";
}
function as(l) {
  return typeof l == "string" ? l : typeof l == "number" ? String(l) : null;
}
function mh(l) {
  const u =
    typeof l == "number" ? l : typeof l == "string" ? Number(l.trim()) : NaN;
  return Number.isFinite(u) ? u : null;
}
function Lc(l) {
  return l.trim().replace(/\s+/g, " ").toLocaleLowerCase("en-GB");
}
function hh(l) {
  return typeof l == "object" && l !== null && typeof l.name == "string";
}
function gh(l, u) {
  return u.length === 0 ? !0 : u.includes(xh(l));
}
function xh(l) {
  const u = l.mimeType?.toLocaleLowerCase("en-GB") ?? "",
    a = l.name.toLocaleLowerCase("en-GB");
  return u === "application/pdf" || a.endsWith(".pdf")
    ? "pdf"
    : u.startsWith("image/")
      ? "image"
      : u.startsWith("audio/")
        ? "audio"
        : u.startsWith("video/")
          ? "video"
          : yh(u, a)
            ? "document"
            : vh(u, a)
              ? "spreadsheet"
              : wh(u, a)
                ? "presentation"
                : kh(u, a)
                  ? "drawing"
                  : "other";
}
function yh(l, u) {
  return (
    l === "application/msword" ||
    l === "application/rtf" ||
    l === "application/vnd.oasis.opendocument.text" ||
    l ===
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document" ||
    l.startsWith("text/") ||
    [".doc", ".docx", ".odt", ".rtf", ".txt"].some((a) => u.endsWith(a))
  );
}
function vh(l, u) {
  return (
    l === "application/vnd.ms-excel" ||
    l === "application/vnd.oasis.opendocument.spreadsheet" ||
    l === "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" ||
    l === "text/csv" ||
    [".csv", ".ods", ".xls", ".xlsx"].some((a) => u.endsWith(a))
  );
}
function wh(l, u) {
  return (
    l === "application/vnd.ms-powerpoint" ||
    l === "application/vnd.oasis.opendocument.presentation" ||
    l ===
      "application/vnd.openxmlformats-officedocument.presentationml.presentation" ||
    [".odp", ".ppt", ".pptx"].some((a) => u.endsWith(a))
  );
}
function kh(l, u) {
  return (
    l === "application/vnd.google-apps.drawing" ||
    l === "application/vnd.visio" ||
    [".drawio", ".vsd", ".vsdx"].some((a) => u.endsWith(a))
  );
}
function jh(l, u) {
  const a = Math.max(0, l.points),
    d = l.answerKey ?? { mode: "none" };
  return a === 0
    ? {
        questionId: l.id,
        type: l.type,
        pointsAwarded: 0,
        pointsPossible: a,
        correct: null,
        manualReviewRequired: !1,
        reason: "No points available",
      }
    : l.type === "File upload" || d.mode === "manual"
      ? {
          questionId: l.id,
          type: l.type,
          pointsAwarded: 0,
          pointsPossible: a,
          correct: null,
          manualReviewRequired: !0,
          reason: "Manual review required",
        }
      : d.mode === "none"
        ? {
            questionId: l.id,
            type: l.type,
            pointsAwarded: 0,
            pointsPossible: a,
            correct: null,
            manualReviewRequired: !1,
            reason: "No answer key",
          }
        : d.mode === "exact"
          ? Sh(l, u, d, a)
          : d.mode === "set"
            ? Nh(l, u, d, a)
            : Ch(l, u, d, a);
}
function Sh(l, u, a, d) {
  const f = Eh(u),
    m = f !== null && a.acceptedAnswers.some((v) => bh(f, v, a.caseSensitive));
  return Cn(l, d, m ? d : 0, m);
}
function Nh(l, u, a, d) {
  const f = a.acceptedAnswers,
    m = Rh(u),
    v = f.map((P) => tr(P, a.caseSensitive)),
    E = m.map((P) => tr(P, a.caseSensitive));
  if (v.length === 0) return Cn(l, d, 0, !1);
  const j = v.filter((P) => E.includes(P)).length,
    _ = j === v.length && E.length === v.length && v.length > 0;
  return _ || !a.partialCredit
    ? Cn(l, d, _ ? d : 0, _)
    : Cn(l, d, bn((j / v.length) * d), j === v.length);
}
function Ch(l, u, a, d) {
  const f = sd(u),
    m = Object.entries(a.expected);
  if (!f || m.length === 0) return Cn(l, d, 0, !1);
  const v = m.filter(([j, _]) => {
      const P = f[j],
        U = Array.isArray(_) ? _ : [_],
        W = Array.isArray(P) ? P : [P];
      return zh(W, U, a.caseSensitive);
    }).length,
    E = v === m.length;
  return E || !a.partialCredit
    ? Cn(l, d, E ? d : 0, E)
    : Cn(l, d, bn((v / m.length) * d), E);
}
function Cn(l, u, a, d) {
  return {
    questionId: l.id,
    type: l.type,
    pointsAwarded: a,
    pointsPossible: u,
    correct: d,
    manualReviewRequired: !1,
  };
}
function bh(l, u, a = !1) {
  return tr(l, a) === tr(u, a);
}
function zh(l, u, a = !1) {
  if (l.length !== u.length) return !1;
  const d = l.map((m) => tr(m, a)).sort();
  return u
    .map((m) => tr(m, a))
    .sort()
    .every((m, v) => d[v] === m);
}
function tr(l, u = !1) {
  const a = String(l).trim().replace(/\s+/g, " ");
  return u ? a : a.toLocaleLowerCase("en-GB");
}
function Eh(l) {
  return typeof l == "string" || typeof l == "number" ? l : null;
}
function Rh(l) {
  return Array.isArray(l) &&
    l.every((u) => typeof u == "string" || typeof u == "number")
    ? l
    : typeof l == "string"
      ? l
          .split(/[;,]/)
          .map((u) => u.trim())
          .filter(Boolean)
      : [];
}
function sd(l) {
  return !l || Array.isArray(l) || typeof l != "object" ? null : l;
}
function bn(l) {
  return Math.round(l * 100) / 100;
}
function ss(l) {
  return Number.isInteger(l) ? String(l) : String(bn(l));
}
function id(l) {
  return `${vo}.form.${l}`;
}
function od() {
  return `${vo}.activeFormId`;
}
function ad(l) {
  return `${vo}.responses.${l}`;
}
function Qr(l) {
  if (l) return l;
  if (!(typeof localStorage > "u")) return localStorage;
}
function ud(l, u) {
  if (!l) return u;
  try {
    return JSON.parse(l);
  } catch {
    return u;
  }
}
function Mh(l) {
  const u =
    typeof globalThis.crypto?.randomUUID == "function"
      ? globalThis.crypto.randomUUID()
      : `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
  return `${l}-${u}`;
}
const Ph = {
    acceptResponses: !0,
    limitOneResponse: !0,
    allowEditAfterSubmit: !1,
    shuffleQuestions: !1,
  },
  jo = [
    {
      key: "acceptResponses",
      label: "Accept responses",
      detail: "Controls whether students can submit the live form.",
      teacherValue: "Close a quiz after the lesson without deleting the form.",
      studentValue:
        "Shows a clear closed message instead of a broken submission path.",
    },
    {
      key: "limitOneResponse",
      label: "Limit to one response",
      detail: "Prevents repeated submissions from the same signed-in student.",
      teacherValue:
        "Keeps marks and checks from being inflated by duplicate attempts.",
      studentValue:
        "Makes the expected attempt count explicit before submission.",
    },
    {
      key: "allowEditAfterSubmit",
      label: "Allow editing after submit",
      detail: "Lets students reopen and amend their submitted answers.",
      teacherValue:
        "Supports draft corrections and reflective improvement workflows.",
      studentValue:
        "Allows fixing mistakes without submitting a second response.",
    },
    {
      key: "shuffleQuestions",
      label: "Shuffle questions",
      detail: "Presents questions in a stable per-student order.",
      teacherValue: "Reduces copying during low-stakes checks.",
      studentValue:
        "Keeps the same required work while changing the order only.",
    },
  ];
function _h(l) {
  const u = { ...Ph, ...Ih(l) },
    a = Oh(l.baseUrl ?? "local://forms-preview"),
    d = encodeURIComponent(l.formId);
  return {
    ...u,
    formId: l.formId,
    formTitle: l.formTitle,
    previewUrl: Tc(a, l.previewPath ?? `/preview/${d}`),
    publishedUrl: Tc(a, l.publishedPath ?? `/forms/${d}`),
    isPublished: l.isPublished ?? !1,
    copyLinkState: l.copyLinkState ?? "idle",
    lastCopiedUrl: l.lastCopiedUrl,
  };
}
function Lh(l) {
  return l.isPublished ? l.publishedUrl : l.previewUrl;
}
function Th(l) {
  return l === "copied"
    ? "Link copied"
    : l === "failed"
      ? "Copy failed"
      : "Ready to copy";
}
function Ah(l) {
  return l.isPublished
    ? l.acceptResponses
      ? "Published and accepting responses"
      : "Published but closed to responses"
    : "Draft preview only";
}
function Ih(l) {
  return jo.reduce((u, a) => {
    const d = l[a.key];
    return (typeof d == "boolean" && (u[a.key] = d), u);
  }, {});
}
function Tc(l, u) {
  const a = u.startsWith("/") ? u : `/${u}`;
  return `${l}${a}`;
}
function Oh(l) {
  return l.endsWith("/") ? l.slice(0, -1) : l;
}
function Fh(l, u, a = Dh(l)) {
  const d = u.filter((m) => typeof m.score == "number"),
    f =
      d.length === 0
        ? null
        : mo(d.reduce((m, v) => m + Number(v.score), 0) / d.length);
  return {
    responseCount: u.length,
    scoredResponseCount: d.length,
    totalPossibleScore: a,
    averageScore: f,
    averageScorePercent: f === null || a === 0 ? null : mo((f / a) * 100),
    questionSummaries: Uh(l, u),
  };
}
function Dh(l) {
  return l.reduce((u, a) => u + (a.points ?? 0), 0);
}
function Uh(l, u) {
  return l.map((a) => {
    const d = new Map();
    let f = 0,
      m = 0,
      v = !1;
    for (const E of u) {
      const j = cd(E, a.id),
        _ = Hr(j);
      _ && ((f += 1), d.set(_, (d.get(_) ?? 0) + 1));
      const P =
        E.correctByQuestion?.[a.id] ??
        E.correctByQuestion?.[String(a.id)] ??
        Bh(a, j);
      P !== null && ((v = !0), P && (m += 1));
    }
    return {
      questionId: String(a.id),
      title: a.title,
      responseCount: f,
      skippedCount: u.length - f,
      correctCount: v ? m : null,
      correctRate: v && u.length > 0 ? mo((m / u.length) * 100) : null,
      topAnswers: Array.from(d.entries())
        .map(([E, j]) => ({ answer: E, count: j }))
        .sort((E, j) => j.count - E.count || E.answer.localeCompare(j.answer))
        .slice(0, 5),
    };
  });
}
function $h(l, u) {
  const a = [
      "Response ID",
      "Student",
      "Submitted At",
      "Score",
      ...l.map((f) => f.title || `Question ${f.id}`),
    ],
    d = u.map((f) => [
      f.id,
      f.respondentName ?? f.studentName ?? "",
      f.submittedAt ?? "",
      f.score ?? "",
      ...l.map((m) => Hr(cd(f, m.id))),
    ]);
  return [a, ...d].map((f) => f.map(Wh).join(",")).join(`\r
`);
}
function Wh(l) {
  const u = Hr(l);
  return /[",\r\n]/.test(u) ? `"${u.replace(/"/g, '""')}"` : u;
}
function cd(l, u) {
  return l.answers[u] ?? l.answers[String(u)];
}
function Bh(l, u) {
  const a = oo(Hr(u)),
    d = oo(Hr(l.answerKey));
  return !a || !d
    ? null
    : d
        .split(";")
        .map((m) => oo(m))
        .filter(Boolean)
        .some((m) => a === m || a.includes(m));
}
function Hr(l) {
  return Array.isArray(l)
    ? l.filter((u) => u.trim()).join("; ")
    : l === null || typeof l > "u"
      ? ""
      : String(l).trim();
}
function oo(l) {
  return l.toLowerCase().replace(/\s+/g, " ").trim();
}
function mo(l) {
  return Math.round(l * 10) / 10;
}
function Vh({
  model: l,
  className: u = "",
  onCopyLink: a,
  onPublishChange: d,
  onToggleSetting: f,
}) {
  const m = Lh(l);
  return s.jsxs("section", {
    className: `space-y-4 bg-white p-5 shadow-sm ${u}`,
    children: [
      s.jsxs("div", {
        className: "flex flex-wrap items-start justify-between gap-3",
        children: [
          s.jsxs("div", {
            children: [
              s.jsx("p", {
                className: "text-xs font-semibold uppercase text-[#5f6368]",
                children: "Share",
              }),
              s.jsx("h2", {
                className: "mt-1 text-xl font-semibold text-[#202124]",
                children: l.formTitle,
              }),
              s.jsx("p", {
                className: "mt-1 text-sm text-[#5f6368]",
                children: Ah(l),
              }),
            ],
          }),
          s.jsxs("label", {
            className:
              "flex items-center gap-2 text-sm font-medium text-[#202124]",
            children: [
              "Local publish preview",
              s.jsx("input", {
                type: "checkbox",
                checked: l.isPublished,
                onChange: (v) => d?.(v.target.checked),
              }),
            ],
          }),
        ],
      }),
      s.jsxs("div", {
        className: "grid gap-3 md:grid-cols-2",
        children: [
          s.jsx(Ac, { label: "Preview link", value: l.previewUrl }),
          s.jsx(Ac, {
            label: "Local student preview link",
            value: l.publishedUrl,
          }),
        ],
      }),
      s.jsxs("div", {
        className:
          "flex flex-wrap items-center gap-3 rounded border border-[#dadce0] p-3",
        children: [
          s.jsxs("div", {
            className: "min-w-0 flex-1",
            children: [
              s.jsx("p", {
                className: "truncate text-sm font-medium text-[#202124]",
                children: m,
              }),
              s.jsx("p", {
                className: "mt-1 text-xs text-[#5f6368]",
                children: Th(l.copyLinkState),
              }),
            ],
          }),
          s.jsx("button", {
            type: "button",
            onClick: () => a?.(m),
            className:
              "rounded bg-[#673ab7] px-4 py-2 text-sm font-medium text-white disabled:opacity-50",
            disabled: !a,
            children: l.copyLinkState === "copied" ? "Copied" : "Copy link",
          }),
        ],
      }),
      s.jsx("div", {
        className: "grid gap-3 md:grid-cols-2",
        children: jo.map((v) =>
          s.jsxs(
            "label",
            {
              className: "flex gap-3 rounded border border-[#dadce0] p-3",
              children: [
                s.jsx("input", {
                  type: "checkbox",
                  checked: l[v.key],
                  onChange: (E) => f?.(v.key, E.target.checked),
                }),
                s.jsxs("span", {
                  children: [
                    s.jsx("span", {
                      className: "block text-sm font-medium text-[#202124]",
                      children: v.label,
                    }),
                    s.jsx("span", {
                      className: "mt-1 block text-xs leading-5 text-[#5f6368]",
                      children: v.detail,
                    }),
                  ],
                }),
              ],
            },
            v.key,
          ),
        ),
      }),
    ],
  });
}
function Ac({ label: l, value: u }) {
  return s.jsxs("label", {
    className: "block text-sm",
    children: [
      s.jsx("span", { className: "font-medium text-[#202124]", children: l }),
      s.jsx("input", {
        className:
          "mt-1 w-full rounded border border-[#dadce0] px-3 py-2 text-sm text-[#5f6368]",
        value: u,
        readOnly: !0,
      }),
    ],
  });
}
function Hh({
  questions: l,
  responses: u,
  className: a = "",
  totalPossibleScore: d,
  onExportCsv: f,
}) {
  const m = Fh(l, u, d),
    v = $h(l, u);
  return s.jsxs("section", {
    className: `space-y-4 bg-white p-5 shadow-sm ${a}`,
    children: [
      s.jsxs("div", {
        className: "flex flex-wrap items-start justify-between gap-3",
        children: [
          s.jsxs("div", {
            children: [
              s.jsx("p", {
                className: "text-xs font-semibold uppercase text-[#5f6368]",
                children: "Responses",
              }),
              s.jsx("h2", {
                className: "mt-1 text-xl font-semibold text-[#202124]",
                children: "Dashboard summary",
              }),
            ],
          }),
          s.jsx("button", {
            type: "button",
            className:
              "rounded border border-[#dadce0] px-4 py-2 text-sm font-medium text-[#202124] disabled:opacity-50",
            disabled: !f,
            onClick: () => f?.(v),
            children: "Export CSV",
          }),
        ],
      }),
      s.jsxs("div", {
        className: "grid gap-3 sm:grid-cols-3",
        children: [
          s.jsx(ao, { label: "Responses", value: String(m.responseCount) }),
          s.jsx(ao, {
            label: "Average score",
            value: Qh(m.averageScore, m.totalPossibleScore),
          }),
          s.jsx(ao, {
            label: "Average percent",
            value: Gh(m.averageScorePercent),
          }),
        ],
      }),
      s.jsx("div", {
        className: "space-y-3",
        children: m.questionSummaries.map((E) =>
          s.jsxs(
            "article",
            {
              className: "rounded border border-[#dadce0] p-3",
              children: [
                s.jsxs("div", {
                  className: "flex flex-wrap items-start justify-between gap-3",
                  children: [
                    s.jsxs("div", {
                      children: [
                        s.jsx("h3", {
                          className: "text-sm font-semibold text-[#202124]",
                          children: E.title,
                        }),
                        s.jsxs("p", {
                          className: "mt-1 text-xs text-[#5f6368]",
                          children: [
                            E.responseCount,
                            " answered, ",
                            E.skippedCount,
                            " skipped",
                          ],
                        }),
                      ],
                    }),
                    s.jsx("span", {
                      className:
                        "rounded-full bg-[#e8f0fe] px-3 py-1 text-xs text-[#174ea6]",
                      children: Kh(E.correctRate),
                    }),
                  ],
                }),
                s.jsx("div", {
                  className: "mt-3 flex flex-wrap gap-2",
                  children:
                    E.topAnswers.length > 0
                      ? E.topAnswers.map((j) =>
                          s.jsxs(
                            "span",
                            {
                              className:
                                "rounded-full bg-[#f1f3f4] px-3 py-1 text-xs text-[#5f6368]",
                              children: [j.answer, ": ", j.count],
                            },
                            j.answer,
                          ),
                        )
                      : s.jsx("span", {
                          className: "text-xs text-[#5f6368]",
                          children: "No answers yet",
                        }),
                }),
              ],
            },
            E.questionId,
          ),
        ),
      }),
    ],
  });
}
function ao({ label: l, value: u }) {
  return s.jsxs("div", {
    className: "rounded border border-[#dadce0] p-4",
    children: [
      s.jsx("p", { className: "text-xs text-[#5f6368]", children: l }),
      s.jsx("p", {
        className: "mt-2 text-xl font-semibold text-[#202124]",
        children: u,
      }),
    ],
  });
}
function Qh(l, u) {
  return l === null ? "No scores" : `${is(l)} / ${is(u)}`;
}
function Gh(l) {
  return l === null ? "No scores" : `${is(l)}%`;
}
function Kh(l) {
  return l === null ? "No key" : `${is(l)}% correct`;
}
function is(l) {
  return Number.isInteger(l) ? String(l) : l.toFixed(1);
}
function Zh({
  settings: l,
  className: u = "",
  disabledKeys: a = [],
  onChange: d,
}) {
  return s.jsxs("section", {
    className: `space-y-4 bg-white p-5 shadow-sm ${u}`,
    children: [
      s.jsxs("div", {
        children: [
          s.jsx("p", {
            className: "text-xs font-semibold uppercase text-[#5f6368]",
            children: "Settings",
          }),
          s.jsx("h2", {
            className: "mt-1 text-xl font-semibold text-[#202124]",
            children: "Student and response controls",
          }),
        ],
      }),
      s.jsx("div", {
        className: "grid gap-3",
        children: jo.map((f) =>
          s.jsx(
            Yh,
            {
              label: f.label,
              detail: f.detail,
              checked: l[f.key],
              disabled: a.includes(f.key),
              onChange: (m) => d?.(f.key, m),
            },
            f.key,
          ),
        ),
      }),
      s.jsx("p", {
        className:
          "rounded border border-[#dadce0] bg-[#f8fafd] p-3 text-xs leading-5 text-[#5f6368]",
        children:
          "Local prototype status: accepting responses, one-response blocking, and shuffle preview are enforced in this browser. Edit-after-submit is tracked as a setting but needs a server update workflow before it is live.",
      }),
    ],
  });
}
function Yh({ label: l, detail: u, checked: a, disabled: d, onChange: f }) {
  return s.jsxs("label", {
    className: "flex gap-3 border-t border-[#dadce0] pt-3",
    children: [
      s.jsx("input", {
        type: "checkbox",
        checked: a,
        disabled: d,
        onChange: (m) => f(m.target.checked),
      }),
      s.jsxs("span", {
        children: [
          s.jsx("span", {
            className: "block text-sm font-medium text-[#202124]",
            children: l,
          }),
          s.jsx("span", {
            className: "mt-1 block text-xs leading-5 text-[#5f6368]",
            children: u,
          }),
        ],
      }),
    ],
  });
}
const dd = "comp-school.forms.prototype.published";
function Xh() {
  const [l, u] = X.useState(() => ig()),
    [a, d] = X.useState(() => og()),
    [f, m] = X.useState("questions"),
    [v, E] = X.useState(l.sections[0]?.id ?? ""),
    [j, _] = X.useState(l.sections[0]?.questions[0]?.id ?? ""),
    [P, U] = X.useState("Student"),
    [W, xe] = X.useState(() => cg(l)),
    [ue, $] = X.useState(l.sections[0]?.id ?? ""),
    [G, le] = X.useState("idle"),
    [ve, Ce] = X.useState(() => ag()),
    [J, ce] = X.useState("idle"),
    [oe, he] = X.useState(""),
    de = X.useMemo(() => En(l), [l]),
    He = l.sections.find((R) => R.id === v) ?? l.sections[0],
    Ie = de.find((R) => R.id === j) ?? de[0],
    _e = l.sections.find((R) => R.id === ue) ?? l.sections[0],
    $e = X.useMemo(() => Qm(l, _e?.id, W), [_e?.id, l, W]),
    Re = X.useMemo(() => wo(l, _e?.id, W), [_e?.id, l, W]),
    pe = X.useMemo(() => ko(l, W, { scoreQuizDisabled: !1 }), [l, W]),
    ye = X.useMemo(() => nd(pe), [pe]),
    we = Re.filter((R) => R.required && Ng(W[R.id])),
    fe = X.useMemo(
      () =>
        Km(l, W, { startSectionId: _e?.id }).questionErrors.map((R) => ({
          questionId: R.questionId,
          message: R.message,
        })),
      [_e?.id, l, W],
    ),
    L =
      l.settings.responses.limitToOneResponse &&
      a.some((R) => R.respondent?.name === P),
    B = X.useMemo(
      () =>
        _h({
          formId: l.id,
          formTitle: l.title,
          isPublished: ve,
          copyLinkState: J,
          acceptResponses: l.settings.responses.acceptingResponses,
          limitOneResponse: l.settings.responses.limitToOneResponse,
          allowEditAfterSubmit: l.settings.responses.allowEditAfterSubmit,
          shuffleQuestions: l.settings.presentation.shuffleQuestionOrder,
        }),
      [J, l, ve],
    ),
    A = X.useMemo(() => de.map(hg), [de]),
    x = X.useMemo(() => a.map((R) => gg(R, de)), [de, a]);
  (X.useEffect(() => {
    qm(l);
  }, [l]),
    X.useEffect(() => {
      localStorage.setItem(dd, String(ve));
    }, [ve]),
    X.useEffect(() => {
      (E((R) => R || l.sections[0]?.id || ""),
        _((R) => R || En(l)[0]?.id || ""),
        $((R) => R || l.sections[0]?.id || ""));
    }, [l]));
  function N(R) {
    u((Y) => ({ ...R(Y), updatedAt: new Date().toISOString() }));
  }
  function Z(R) {
    N((Y) => ({ ...Y, ...R }));
  }
  function q(R, Y) {
    N((K) => ({
      ...K,
      sections: K.sections.map((Le) => (Le.id === R ? { ...Le, ...Y } : Le)),
    }));
  }
  function re() {
    const R = {
      id: zn("section"),
      title: `Section ${l.sections.length + 1}`,
      description: "",
      questions: [],
    };
    (N((Y) => ({ ...Y, sections: [...Y.sections, R] })), E(R.id));
  }
  function te(R, Y) {
    N((K) => ({
      ...K,
      sections: K.sections.map((Le) => ({
        ...Le,
        questions: Le.questions.map((Ze) =>
          Ze.id === R ? { ...Ze, ...Y } : Ze,
        ),
      })),
    }));
  }
  function ge(R) {
    const Y = He?.id ?? l.sections[0]?.id;
    if (!Y) return;
    const K = mg(R);
    (N((Le) => ({
      ...Le,
      sections: Le.sections.map((Ze) =>
        Ze.id === Y ? { ...Ze, questions: [...Ze.questions, K] } : Ze,
      ),
    })),
      _(K.id));
  }
  function ae(R) {
    const Y = { ...R, id: zn("q"), title: `${R.title} copy` };
    (N((K) => ({
      ...K,
      sections: K.sections.map((Le) =>
        Le.questions.some((Ze) => Ze.id === R.id)
          ? { ...Le, questions: [...Le.questions, Y] }
          : Le,
      ),
    })),
      _(Y.id));
  }
  function ke(R) {
    de.length !== 1 &&
      (N((Y) => ({
        ...Y,
        sections: Y.sections.map((K) => ({
          ...K,
          questions: K.questions.filter((Le) => Le.id !== R),
        })),
      })),
      _(de.find((Y) => Y.id !== R)?.id ?? ""));
  }
  function et(R, Y) {
    te(R.id, dg(R, Y));
  }
  function dn(R, Y) {
    N((K) => ({
      ...K,
      settings: {
        ...K.settings,
        responses: {
          ...K.settings.responses,
          acceptingResponses:
            R === "acceptResponses"
              ? Y
              : K.settings.responses.acceptingResponses,
          limitToOneResponse:
            R === "limitOneResponse"
              ? Y
              : K.settings.responses.limitToOneResponse,
          allowEditAfterSubmit:
            R === "allowEditAfterSubmit"
              ? Y
              : K.settings.responses.allowEditAfterSubmit,
        },
        presentation: {
          ...K.settings.presentation,
          shuffleQuestionOrder:
            R === "shuffleQuestions"
              ? Y
              : K.settings.presentation.shuffleQuestionOrder,
        },
      },
    }));
  }
  function nr(R, Y) {
    N((K) => ({
      ...K,
      settings: { ...K.settings, quiz: { ...K.settings.quiz, [R]: Y } },
    }));
  }
  async function Rn(R) {
    try {
      (await navigator.clipboard.writeText(R), ce("copied"));
    } catch {
      ce("failed");
    }
  }
  function rr() {
    if (!l.settings.responses.acceptingResponses) {
      le("blocked");
      return;
    }
    if (L) {
      le("duplicate");
      return;
    }
    if (we.length > 0 || fe.length > 0) {
      le("blocked");
      return;
    }
    const R = Jm(
      l,
      {
        respondent: { name: P },
        answers: Object.fromEntries(Re.map((Y) => [Y.id, W[Y.id]])),
      },
      { existingResponses: a, scoreQuizDisabled: !1, startSectionId: _e?.id },
    );
    (d(R.responses), le("submitted"));
  }
  return s.jsxs("main", {
    className: "min-h-screen bg-[#f8fafd] text-[#202124]",
    children: [
      s.jsxs("header", {
        className: "sticky top-0 z-20 border-b border-[#dadce0] bg-white",
        children: [
          s.jsxs("div", {
            className: "mx-auto flex max-w-7xl items-center gap-4 px-4 py-3",
            children: [
              s.jsx("div", {
                className:
                  "flex h-10 w-10 items-center justify-center rounded bg-[#673ab7] text-lg font-semibold text-white",
                children: "F",
              }),
              s.jsxs("div", {
                className: "min-w-0 flex-1",
                children: [
                  s.jsx("input", {
                    className:
                      "w-full truncate border-0 bg-transparent text-lg font-medium outline-none",
                    value: l.title,
                    onChange: (R) => Z({ title: R.target.value }),
                    "aria-label": "Form title",
                  }),
                  s.jsxs("p", {
                    className: "text-xs text-[#5f6368]",
                    children: [
                      "Autosaved locally. ",
                      a.length,
                      " responses recorded.",
                    ],
                  }),
                ],
              }),
              s.jsx("button", {
                className:
                  "rounded border border-[#dadce0] px-4 py-2 text-sm font-medium",
                onClick: () => m("student"),
                children: "Preview",
              }),
              s.jsx("button", {
                className:
                  "rounded bg-[#673ab7] px-4 py-2 text-sm font-medium text-white",
                onClick: () => {
                  (Ce(!0), m("share"));
                },
                children: "Send",
              }),
            ],
          }),
          s.jsx("nav", {
            className:
              "mx-auto flex max-w-7xl gap-8 overflow-x-auto px-4 text-sm font-medium",
            children: [
              "questions",
              "student",
              "responses",
              "settings",
              "share",
            ].map((R) =>
              s.jsx(
                "button",
                {
                  onClick: () => m(R),
                  className: `border-b-2 px-1 py-3 capitalize ${f === R ? "border-[#673ab7] text-[#673ab7]" : "border-transparent text-[#5f6368]"}`,
                  children: R,
                },
                R,
              ),
            ),
          }),
        ],
      }),
      s.jsxs("div", {
        className:
          "mx-auto grid max-w-7xl gap-6 px-4 py-6 lg:grid-cols-[260px_minmax(0,1fr)_320px]",
        children: [
          s.jsxs("aside", {
            className: "space-y-4",
            children: [
              s.jsxs("section", {
                className: "space-y-3",
                children: [
                  s.jsx("p", {
                    className: "text-xs font-semibold uppercase text-[#5f6368]",
                    children: "Question types",
                  }),
                  s.jsx("div", {
                    className: "grid gap-2",
                    children: Qc.map((R) =>
                      s.jsxs(
                        "button",
                        {
                          onClick: () => ge(R),
                          className:
                            "rounded border border-[#dadce0] bg-white px-3 py-2 text-left text-sm hover:border-[#673ab7]",
                          children: ["+ ", R],
                        },
                        R,
                      ),
                    ),
                  }),
                ],
              }),
              s.jsxs("section", {
                className: "space-y-3",
                children: [
                  s.jsxs("div", {
                    className: "flex items-center justify-between",
                    children: [
                      s.jsx("p", {
                        className:
                          "text-xs font-semibold uppercase text-[#5f6368]",
                        children: "Sections",
                      }),
                      s.jsx("button", {
                        className: "text-sm font-medium text-[#673ab7]",
                        onClick: re,
                        children: "Add",
                      }),
                    ],
                  }),
                  s.jsx("div", {
                    className: "grid gap-2",
                    children: l.sections.map((R, Y) =>
                      s.jsxs(
                        "button",
                        {
                          onClick: () => E(R.id),
                          className: `rounded border px-3 py-2 text-left text-sm ${He?.id === R.id ? "border-[#673ab7] bg-[#f3e8fd]" : "border-[#dadce0] bg-white"}`,
                          children: [Y + 1, ". ", R.title],
                        },
                        R.id,
                      ),
                    ),
                  }),
                ],
              }),
            ],
          }),
          s.jsxs("section", {
            className: "min-w-0",
            children: [
              f === "questions" &&
                s.jsxs("div", {
                  className: "space-y-4",
                  children: [
                    s.jsx(Jh, { form: l, onChange: Z }),
                    l.sections.map((R, Y) =>
                      s.jsxs(
                        "section",
                        {
                          className: "space-y-4",
                          children: [
                            s.jsx(qh, {
                              section: R,
                              index: Y,
                              sections: l.sections,
                              onChange: (K) => q(R.id, K),
                            }),
                            R.questions.map((K, Le) =>
                              s.jsx(
                                "div",
                                {
                                  onClick: () => {
                                    (E(R.id), _(K.id));
                                  },
                                  children: s.jsx(dm, {
                                    question: fd(K),
                                    index: Le,
                                    selected: j === K.id,
                                    quizEnabled: l.settings.quiz.enabled,
                                    onChange: (Ze) => et(K, Ze),
                                    onDuplicate: () => ae(K),
                                    onDelete: () => ke(K.id),
                                  }),
                                },
                                K.id,
                              ),
                            ),
                          ],
                        },
                        R.id,
                      ),
                    ),
                  ],
                }),
              f === "student" &&
                s.jsx(eg, {
                  form: l,
                  responses: a,
                  answers: W,
                  activeSection: _e,
                  reachedSections: $e,
                  studentName: P,
                  scoreLabel: ye.scoreLabel,
                  submitState: G,
                  requiredMissingCount: we.length,
                  validationErrors: fe,
                  duplicateResponseBlocked: L,
                  onNameChange: U,
                  onSectionChange: $,
                  onAnswerChange: (R, Y) =>
                    xe((K) => ({ ...K, [R.id]: fg(R, Y) })),
                  onSubmit: rr,
                }),
              f === "responses" &&
                s.jsxs("div", {
                  className: "space-y-4",
                  children: [
                    s.jsx(Hh, {
                      questions: A,
                      responses: x,
                      totalPossibleScore: ye.pointsPossible,
                      onExportCsv: he,
                    }),
                    oe &&
                      s.jsxs("section", {
                        className: "bg-white p-5 shadow-sm",
                        children: [
                          s.jsxs("div", {
                            className:
                              "mb-2 flex items-center justify-between gap-3",
                            children: [
                              s.jsx("h2", {
                                className: "text-lg font-semibold",
                                children: "CSV export preview",
                              }),
                              s.jsx("button", {
                                className: "text-sm font-medium text-[#673ab7]",
                                onClick: () => he(""),
                                children: "Clear",
                              }),
                            ],
                          }),
                          s.jsx("textarea", {
                            className:
                              "h-44 w-full rounded border border-[#dadce0] p-3 text-xs",
                            value: oe,
                            readOnly: !0,
                          }),
                        ],
                      }),
                    s.jsx(tg, { responses: a, questions: de }),
                  ],
                }),
              f === "settings" &&
                s.jsxs("div", {
                  className: "space-y-4",
                  children: [
                    s.jsx(Zh, { settings: B, onChange: dn }),
                    s.jsxs("section", {
                      className: "space-y-4 bg-white p-5 shadow-sm",
                      children: [
                        s.jsxs("div", {
                          children: [
                            s.jsx("p", {
                              className:
                                "text-xs font-semibold uppercase text-[#5f6368]",
                              children: "Quiz",
                            }),
                            s.jsx("h2", {
                              className: "mt-1 text-xl font-semibold",
                              children: "Answer keys and grade release",
                            }),
                          ],
                        }),
                        s.jsxs("label", {
                          className:
                            "flex gap-3 border-t border-[#dadce0] pt-3",
                          children: [
                            s.jsx("input", {
                              type: "checkbox",
                              checked: l.settings.quiz.enabled,
                              onChange: (R) => nr("enabled", R.target.checked),
                            }),
                            s.jsxs("span", {
                              children: [
                                s.jsx("span", {
                                  className: "block text-sm font-medium",
                                  children: "Make this a quiz",
                                }),
                                s.jsx("span", {
                                  className:
                                    "mt-1 block text-xs text-[#5f6368]",
                                  children:
                                    "Enable points, answer keys, feedback, and auto scoring.",
                                }),
                              ],
                            }),
                          ],
                        }),
                        s.jsxs("label", {
                          className: "block text-sm",
                          children: [
                            "Release grades",
                            s.jsxs("select", {
                              className:
                                "mt-1 w-full rounded border border-[#dadce0] bg-white px-3 py-2",
                              value: l.settings.quiz.releaseGrades,
                              onChange: (R) =>
                                nr("releaseGrades", R.target.value),
                              children: [
                                s.jsx("option", {
                                  value: "immediate",
                                  children: "Immediately after submission",
                                }),
                                s.jsx("option", {
                                  value: "after-manual-review",
                                  children: "After manual review",
                                }),
                              ],
                            }),
                          ],
                        }),
                      ],
                    }),
                  ],
                }),
              f === "share" &&
                s.jsx(Vh, {
                  model: B,
                  onCopyLink: Rn,
                  onPublishChange: Ce,
                  onToggleSetting: dn,
                }),
            ],
          }),
          s.jsxs("aside", {
            className: "space-y-4",
            children: [
              s.jsx(ng, {
                form: l,
                selectedQuestion: Ie,
                responses: a,
                requiredMissingCount: we.length,
              }),
              Ie &&
                s.jsxs(s.Fragment, {
                  children: [
                    s.jsx(rg, {
                      form: l,
                      question: Ie,
                      onChange: (R) => te(Ie.id, R),
                    }),
                    s.jsx(lg, { question: Ie, onChange: (R) => te(Ie.id, R) }),
                  ],
                }),
              s.jsx(sg, {}),
            ],
          }),
        ],
      }),
    ],
  });
}
function Jh({ form: l, onChange: u }) {
  return s.jsxs("div", {
    className: "border-t-8 border-[#673ab7] bg-white p-6 shadow-sm",
    children: [
      s.jsx("input", {
        className:
          "w-full border-b border-[#dadce0] pb-2 text-3xl outline-none focus:border-[#673ab7]",
        value: l.title,
        onChange: (a) => u({ title: a.target.value }),
        "aria-label": "Editable form title",
      }),
      s.jsx("textarea", {
        className:
          "mt-4 w-full resize-none border-b border-[#dadce0] text-sm outline-none focus:border-[#673ab7]",
        value: l.description ?? "",
        onChange: (a) => u({ description: a.target.value }),
        "aria-label": "Form description",
      }),
    ],
  });
}
function qh({ section: l, index: u, sections: a, onChange: d }) {
  return s.jsxs("div", {
    className: "bg-white p-5 shadow-sm",
    children: [
      s.jsxs("p", {
        className: "text-xs font-semibold uppercase text-[#5f6368]",
        children: ["Section ", u + 1],
      }),
      s.jsx("input", {
        className:
          "mt-2 w-full border-b border-[#dadce0] pb-2 text-xl font-semibold outline-none focus:border-[#673ab7]",
        value: l.title,
        onChange: (f) => d({ title: f.target.value }),
      }),
      s.jsx("input", {
        className:
          "mt-3 w-full border-b border-[#dadce0] py-2 text-sm outline-none focus:border-[#673ab7]",
        value: l.description ?? "",
        onChange: (f) => d({ description: f.target.value }),
        placeholder: "Section description",
      }),
      s.jsxs("label", {
        className: "mt-4 block text-sm",
        children: [
          "After section",
          s.jsxs("select", {
            className:
              "mt-1 w-full rounded border border-[#dadce0] bg-white px-3 py-2",
            value: l.nextSectionId ?? "",
            onChange: (f) => d({ nextSectionId: f.target.value || void 0 }),
            children: [
              s.jsx("option", {
                value: "",
                children: "Continue to next section",
              }),
              a
                .filter((f) => f.id !== l.id)
                .map((f) =>
                  s.jsxs(
                    "option",
                    { value: f.id, children: ["Go to ", f.title] },
                    f.id,
                  ),
                ),
              s.jsx("option", { value: "submit", children: "Submit form" }),
            ],
          }),
        ],
      }),
    ],
  });
}
function eg({
  form: l,
  responses: u,
  answers: a,
  activeSection: d,
  reachedSections: f,
  studentName: m,
  scoreLabel: v,
  submitState: E,
  requiredMissingCount: j,
  validationErrors: _,
  duplicateResponseBlocked: P,
  onNameChange: U,
  onSectionChange: W,
  onAnswerChange: xe,
  onSubmit: ue,
}) {
  return l.settings.responses.acceptingResponses
    ? s.jsxs("div", {
        className: "space-y-4",
        children: [
          s.jsxs("div", {
            className: "border-t-8 border-[#673ab7] bg-white p-6 shadow-sm",
            children: [
              s.jsx("h2", {
                className: "text-3xl font-semibold",
                children: l.title,
              }),
              s.jsx("p", {
                className: "mt-3 text-sm text-[#5f6368]",
                children: l.description,
              }),
              s.jsx("div", {
                className: "mt-5 grid gap-3 sm:grid-cols-2",
                children: s.jsxs("label", {
                  className: "text-sm",
                  children: [
                    "Name",
                    s.jsx("input", {
                      className:
                        "mt-1 w-full rounded border border-[#dadce0] px-3 py-2",
                      value: m,
                      onChange: ($) => U($.target.value),
                    }),
                  ],
                }),
              }),
              s.jsxs("label", {
                className: "mt-4 block text-sm",
                children: [
                  "Start at section",
                  s.jsx("select", {
                    className:
                      "mt-1 w-full rounded border border-[#dadce0] bg-white px-3 py-2",
                    value: d?.id ?? "",
                    onChange: ($) => W($.target.value),
                    children: l.sections.map(($) =>
                      s.jsx("option", { value: $.id, children: $.title }, $.id),
                    ),
                  }),
                ],
              }),
              s.jsxs("p", {
                className: "mt-3 text-xs text-[#5f6368]",
                children: [
                  "Section routing preview: ",
                  f.map(($) => $.title).join(" -> "),
                  ".",
                ],
              }),
            ],
          }),
          f.map(($) =>
            s.jsxs(
              "section",
              {
                className: "space-y-4",
                children: [
                  s.jsxs("div", {
                    className: "bg-white p-5 shadow-sm",
                    children: [
                      s.jsx("h3", {
                        className: "text-xl font-semibold",
                        children: $.title,
                      }),
                      $.description &&
                        s.jsx("p", {
                          className: "mt-1 text-sm text-[#5f6368]",
                          children: $.description,
                        }),
                    ],
                  }),
                  ug($, l.settings.presentation.shuffleQuestionOrder, m).map(
                    (G) =>
                      s.jsx(
                        fm,
                        {
                          question: fd(G),
                          value: pg(a[G.id]),
                          onChange: (le) => xe(G, le),
                        },
                        G.id,
                      ),
                  ),
                ],
              },
              $.id,
            ),
          ),
          s.jsxs("div", {
            className: "space-y-3 bg-white p-5 shadow-sm",
            children: [
              E === "submitted" &&
                s.jsxs("p", {
                  className:
                    "rounded border border-[#34a853] bg-[#e6f4ea] p-3 text-sm text-[#137333]",
                  children: [
                    "Response recorded locally. Total responses: ",
                    u.length,
                    ".",
                  ],
                }),
              E === "blocked" &&
                s.jsxs("div", {
                  className:
                    "rounded border border-[#fbbc04] bg-[#fff8e1] p-3 text-sm text-[#5f6368]",
                  children: [
                    s.jsxs("p", {
                      children: [
                        "Complete ",
                        j,
                        " required question",
                        j === 1 ? "" : "s",
                        " and fix",
                        " ",
                        _.length,
                        " validation issue",
                        _.length === 1 ? "" : "s",
                        " before submitting.",
                      ],
                    }),
                    _.length > 0 &&
                      s.jsx("ul", {
                        className: "mt-2 list-disc pl-5",
                        children: _.map(($) =>
                          s.jsx(
                            "li",
                            { children: $.message },
                            `${$.questionId}-${$.message}`,
                          ),
                        ),
                      }),
                  ],
                }),
              E === "duplicate" &&
                s.jsx("p", {
                  className:
                    "rounded border border-[#fbbc04] bg-[#fff8e1] p-3 text-sm text-[#5f6368]",
                  children: "One response is already recorded for this name.",
                }),
              s.jsxs("div", {
                className: "flex flex-wrap items-center justify-between gap-3",
                children: [
                  s.jsx("button", {
                    className:
                      "rounded bg-[#673ab7] px-5 py-2 text-sm font-medium text-white disabled:opacity-50",
                    onClick: ue,
                    disabled: P,
                    children: "Submit",
                  }),
                  l.settings.quiz.enabled &&
                    s.jsxs("p", {
                      className: "text-sm text-[#5f6368]",
                      children: ["Auto score preview: ", v],
                    }),
                ],
              }),
            ],
          }),
        ],
      })
    : s.jsxs("div", {
        className: "border-t-8 border-[#d93025] bg-white p-6 shadow-sm",
        children: [
          s.jsx("h2", {
            className: "text-2xl font-semibold",
            children: l.title,
          }),
          s.jsx("p", {
            className: "mt-3 text-sm text-[#5f6368]",
            children: "This form is not accepting responses.",
          }),
        ],
      });
}
function tg({ responses: l, questions: u }) {
  return s.jsxs("section", {
    className: "overflow-x-auto bg-white p-5 shadow-sm",
    children: [
      s.jsx("h2", {
        className: "mb-3 text-lg font-semibold",
        children: "Individual responses",
      }),
      s.jsxs("table", {
        className: "w-full min-w-[720px] border-collapse text-left text-sm",
        children: [
          s.jsx("thead", {
            className: "border-b border-[#dadce0] text-[#5f6368]",
            children: s.jsxs("tr", {
              children: [
                s.jsx("th", { className: "py-3", children: "Student" }),
                s.jsx("th", { children: "Submitted" }),
                s.jsx("th", { children: "Score" }),
                s.jsx("th", { children: "Manual review" }),
                s.jsx("th", { children: "First answer" }),
              ],
            }),
          }),
          s.jsx("tbody", {
            children:
              l.length === 0
                ? s.jsx("tr", {
                    children: s.jsx("td", {
                      className: "py-4 text-[#5f6368]",
                      colSpan: 5,
                      children:
                        "No responses yet. Use the Student tab to submit one locally.",
                    }),
                  })
                : l.map((a) =>
                    s.jsxs(
                      "tr",
                      {
                        className: "border-b border-[#f1f3f4]",
                        children: [
                          s.jsx("td", {
                            className: "py-3 font-medium",
                            children: a.respondent?.name ?? "Anonymous",
                          }),
                          s.jsx("td", {
                            children: new Date(a.submittedAt).toLocaleString(
                              "en-GB",
                            ),
                          }),
                          s.jsx("td", { children: nd(a.score).scoreLabel }),
                          s.jsx("td", {
                            children: a.score.manualReviewRequired
                              ? "Yes"
                              : "No",
                          }),
                          s.jsx("td", {
                            children: pd(a.answers[u[0]?.id ?? ""]),
                          }),
                        ],
                      },
                      a.id,
                    ),
                  ),
          }),
        ],
      }),
    ],
  });
}
function ng({
  form: l,
  selectedQuestion: u,
  responses: a,
  requiredMissingCount: d,
}) {
  return s.jsxs("section", {
    className: "space-y-3 bg-white p-5 text-sm shadow-sm",
    children: [
      s.jsx("h2", { className: "font-semibold", children: "Form status" }),
      s.jsxs("p", {
        className: "text-[#5f6368]",
        children: [
          l.sections.length,
          " sections, ",
          En(l).length,
          " questions, ",
          a.length,
          " responses.",
        ],
      }),
      s.jsxs("p", {
        className: "text-[#5f6368]",
        children: [
          "Accepting responses: ",
          l.settings.responses.acceptingResponses ? "yes" : "no",
          ".",
        ],
      }),
      s.jsxs("p", {
        className: "text-[#5f6368]",
        children: ["Required missing in preview: ", d, "."],
      }),
      u &&
        s.jsxs("div", {
          className: "rounded border border-[#dadce0] p-3",
          children: [
            s.jsx("p", {
              className: "text-xs font-semibold uppercase text-[#5f6368]",
              children: "Selected",
            }),
            s.jsx("p", { className: "mt-1 font-medium", children: u.title }),
            s.jsx("p", { className: "mt-1 text-[#5f6368]", children: u.type }),
          ],
        }),
    ],
  });
}
function rg({ form: l, question: u, onChange: a }) {
  if (u.type !== "Multiple choice" && u.type !== "Dropdown")
    return s.jsxs("section", {
      className: "bg-white p-5 text-sm shadow-sm",
      children: [
        s.jsx("h2", { className: "font-semibold", children: "Answer routing" }),
        s.jsx("p", {
          className: "mt-2 text-[#5f6368]",
          children:
            "Answer-based section routing is available for multiple choice and dropdown questions.",
        }),
      ],
    });
  function d(f, m) {
    a({
      options: u.options?.map((v) =>
        v.id === f ? { ...v, nextSectionId: m || void 0 } : v,
      ),
    });
  }
  return s.jsxs("section", {
    className: "space-y-3 bg-white p-5 text-sm shadow-sm",
    children: [
      s.jsx("h2", { className: "font-semibold", children: "Answer routing" }),
      s.jsx("p", {
        className: "text-xs leading-5 text-[#5f6368]",
        children:
          "Send students to a section based on the answer they choose, matching Google Forms branch behavior.",
      }),
      (u.options ?? []).map((f) =>
        s.jsxs(
          "label",
          {
            className: "block",
            children: [
              f.label,
              s.jsxs("select", {
                className:
                  "mt-1 w-full rounded border border-[#dadce0] bg-white px-3 py-2",
                value: f.nextSectionId ?? "",
                onChange: (m) => d(f.id, m.target.value),
                children: [
                  s.jsx("option", {
                    value: "",
                    children: "Follow section default",
                  }),
                  l.sections.map((m) =>
                    s.jsxs(
                      "option",
                      { value: m.id, children: ["Go to ", m.title] },
                      m.id,
                    ),
                  ),
                  s.jsx("option", { value: "submit", children: "Submit form" }),
                ],
              }),
            ],
          },
          f.id,
        ),
      ),
    ],
  });
}
function lg({ question: l, onChange: u }) {
  const a = l.validation ?? { type: "none" },
    d = a.type;
  function f(m) {
    u({ validation: m });
  }
  return s.jsxs("section", {
    className: "space-y-3 bg-white p-5 text-sm shadow-sm",
    children: [
      s.jsx("h2", {
        className: "font-semibold",
        children: "Response validation",
      }),
      s.jsxs("label", {
        className: "block",
        children: [
          "Rule",
          s.jsxs("select", {
            className:
              "mt-1 w-full rounded border border-[#dadce0] bg-white px-3 py-2",
            value: d,
            onChange: (m) => f(zg(m.target.value)),
            children: [
              s.jsx("option", { value: "none", children: "None" }),
              s.jsx("option", { value: "length", children: "Text length" }),
              s.jsx("option", { value: "text", children: "Contains text" }),
              s.jsx("option", { value: "number", children: "Number range" }),
              s.jsx("option", {
                value: "regex",
                children: "Regular expression",
              }),
              s.jsx("option", { value: "url", children: "URL" }),
            ],
          }),
        ],
      }),
      d === "length" &&
        s.jsx(co, {
          label:
            a.condition === "max" ? "Maximum characters" : "Minimum characters",
          value: a.value,
          onChange: (m) => f({ ...a, value: m }),
        }),
      d === "text" &&
        s.jsx(uo, {
          label:
            a.condition === "does-not-contain"
              ? "Must not contain"
              : "Must contain",
          value: a.value,
          onChange: (m) => f({ ...a, value: m }),
        }),
      d === "number" &&
        s.jsxs("div", {
          className: "grid gap-2",
          children: [
            s.jsx(co, {
              label: "Minimum",
              value: a.min ?? 0,
              onChange: (m) => f({ ...a, min: m }),
            }),
            s.jsx(co, {
              label: "Maximum",
              value: a.max ?? 100,
              onChange: (m) => f({ ...a, max: m }),
            }),
          ],
        }),
      d === "regex" &&
        s.jsx(uo, {
          label: "Pattern",
          value: a.pattern,
          onChange: (m) => f({ ...a, pattern: m }),
        }),
      d !== "none" &&
        s.jsx(uo, {
          label: "Custom error message",
          value: "message" in a ? (a.message ?? "") : "",
          onChange: (m) => f({ ...a, message: m }),
        }),
    ],
  });
}
function uo({ label: l, value: u, onChange: a }) {
  return s.jsxs("label", {
    className: "block",
    children: [
      l,
      s.jsx("input", {
        className: "mt-1 w-full rounded border border-[#dadce0] px-3 py-2",
        value: u,
        onChange: (d) => a(d.target.value),
      }),
    ],
  });
}
function co({ label: l, value: u, onChange: a }) {
  return s.jsxs("label", {
    className: "block",
    children: [
      l,
      s.jsx("input", {
        type: "number",
        className: "mt-1 w-full rounded border border-[#dadce0] px-3 py-2",
        value: u,
        onChange: (d) => a(Number(d.target.value)),
      }),
    ],
  });
}
function sg() {
  return s.jsxs("section", {
    className: "bg-white p-5 text-sm shadow-sm",
    children: [
      s.jsx("h2", { className: "font-semibold", children: "Parity focus" }),
      s.jsx("p", {
        className: "mt-2 text-[#5f6368]",
        children:
          "This pass adds local persistence, submit-to-response flow, sections, share controls, CSV export, and Google Forms question settings. Share links are local preview records only; server auth, real file storage, and real Sheets sync remain outside this local prototype pass.",
      }),
    ],
  });
}
function ig() {
  return th({ fallback: Wt });
}
function og() {
  return rd(Wt.id);
}
function ag() {
  return localStorage.getItem(dd) === "true";
}
function ug(l, u, a) {
  return u
    ? [...l.questions].sort(
        (d, f) => Dc(`${a}:${l.id}:${d.id}`) - Dc(`${a}:${l.id}:${f.id}`),
      )
    : l.questions;
}
function cg(l) {
  return En(l).reduce(
    (u, a) => (
      a.type === "Short answer" && (u[a.id] = "Boolean"),
      a.type === "Paragraph" &&
        (u[a.id] =
          "Validation checks whether data follows rules. Verification checks whether it matches the original source."),
      a.type === "Multiple choice" && (u[a.id] = Ic(a, "Integer")),
      a.type === "Checkboxes" &&
        (u[a.id] =
          a.options?.map((d) => d.label).filter((d) => d !== "Store") ?? []),
      a.type === "Dropdown" && (u[a.id] = Ic(a, "Iteration")),
      a.type === "Linear scale" && (u[a.id] = a.scale?.end ?? 5),
      a.type === "Rating" && (u[a.id] = a.rating?.max ?? 5),
      a.type === "Date" && (u[a.id] = "2026-07-10"),
      a.type === "Time" && (u[a.id] = "15:30"),
      a.answerKey?.mode === "grid" && (u[a.id] = a.answerKey.expected),
      u
    ),
    {},
  );
}
function Ic(l, u) {
  return (
    l.options?.find((a) => a.label === u)?.label ?? l.options?.[0]?.label ?? ""
  );
}
function fd(l) {
  return {
    id: l.id,
    type: l.type,
    title: l.title,
    description: l.description,
    required: l.required,
    points: l.points,
    answerKey: yg(l.answerKey),
    feedback: wg(l.feedback),
    options: l.options,
    rows: l.grid?.rows ?? ["Row 1", "Row 2"],
    columns: l.grid?.columns ?? ["Column 1", "Column 2"],
    scaleStart: l.scale?.start === 0 ? 0 : 1,
    scaleEnd: Cg(l.scale?.end ?? 5),
    scaleLowLabel: l.scale?.lowLabel,
    scaleHighLabel: l.scale?.highLabel,
    ratingCount: bg(l.rating?.max ?? 5),
    ratingIcon: l.rating?.icon ?? "star",
    media: Oc(l.media).kind,
    mediaPrompt: Oc(l.media),
    gridRequireResponsePerRow: l.grid?.requireOneResponsePerRow,
    gridLimitOneResponsePerColumn: l.grid?.limitOneResponsePerColumn,
    dateIncludeYear: l.date?.includeYear ?? !0,
    dateIncludeTime: l.date?.includeTime ?? !1,
    timeDuration: l.time?.mode === "duration",
    fileUpload: l.fileUpload
      ? {
          maxFiles: l.fileUpload.maxFiles,
          maxFileSizeMb: l.fileUpload.maxFileSizeMb,
          allowedTypes: l.fileUpload.acceptedTypes.filter((u) => u !== "other"),
        }
      : void 0,
  };
}
function dg(l, u) {
  const a = {};
  return (
    u.type && (a.type = u.type),
    "title" in u && (a.title = u.title ?? l.title),
    "description" in u && (a.description = u.description),
    "required" in u && (a.required = !!u.required),
    "points" in u && (a.points = Number(u.points ?? 0)),
    "answerKey" in u && (a.answerKey = vg(l, u.answerKey)),
    "feedback" in u &&
      (a.feedback = { ...l.feedback, general: String(u.feedback ?? "") }),
    "options" in u && (a.options = jg(u.options)),
    "mediaPrompt" in u && u.mediaPrompt && (a.media = kg(u.mediaPrompt)),
    ("scaleStart" in u ||
      "scaleEnd" in u ||
      "scaleLowLabel" in u ||
      "scaleHighLabel" in u) &&
      (a.scale = {
        start: u.scaleStart ?? l.scale?.start ?? 1,
        end: u.scaleEnd ?? l.scale?.end ?? 5,
        lowLabel: u.scaleLowLabel ?? l.scale?.lowLabel,
        highLabel: u.scaleHighLabel ?? l.scale?.highLabel,
      }),
    ("ratingCount" in u || "ratingIcon" in u) &&
      (a.rating = {
        max: u.ratingCount ?? l.rating?.max ?? 5,
        icon: u.ratingIcon ?? l.rating?.icon ?? "star",
        lowLabel: l.rating?.lowLabel,
        highLabel: l.rating?.highLabel,
      }),
    ("rows" in u ||
      "columns" in u ||
      "gridRequireResponsePerRow" in u ||
      "gridLimitOneResponsePerColumn" in u) &&
      (a.grid = {
        rows: Fc(u.rows) ?? l.grid?.rows ?? ["Row 1", "Row 2"],
        columns: Fc(u.columns) ?? l.grid?.columns ?? ["Column 1", "Column 2"],
        requireOneResponsePerRow:
          u.gridRequireResponsePerRow ?? l.grid?.requireOneResponsePerRow ?? !1,
        limitOneResponsePerColumn:
          u.gridLimitOneResponsePerColumn ??
          l.grid?.limitOneResponsePerColumn ??
          !1,
        shuffleRows: l.grid?.shuffleRows,
      }),
    "fileUpload" in u &&
      u.fileUpload &&
      (a.fileUpload = {
        maxFiles: u.fileUpload.maxFiles ?? l.fileUpload?.maxFiles ?? 1,
        maxFileSizeMb:
          u.fileUpload.maxFileSizeMb ?? l.fileUpload?.maxFileSizeMb ?? 10,
        acceptedTypes: u.fileUpload.allowedTypes ?? ["pdf", "image"],
      }),
    ("dateIncludeYear" in u || "dateIncludeTime" in u) &&
      (a.date = {
        includeYear: u.dateIncludeYear ?? l.date?.includeYear ?? !0,
        includeTime: u.dateIncludeTime ?? l.date?.includeTime ?? !1,
      }),
    "timeDuration" in u &&
      (a.time = { mode: u.timeDuration ? "duration" : "time" }),
    a
  );
}
function fg(l, u) {
  if (typeof u == "object" && u && "files" in u)
    return Array.isArray(u.fileDetails) && u.fileDetails.length > 0
      ? u.fileDetails
          .filter((d) => typeof d != "string")
          .map((d) => ({
            name: d.name,
            sizeBytes: d.sizeBytes,
            mimeType: d.mimeType,
          }))
      : (Array.isArray(u.files) ? u.files : [u.files]).map((d) => ({
          name: d,
        }));
  if (
    (l.type === "Linear scale" || l.type === "Rating") &&
    typeof u == "string"
  ) {
    const a = Number(u);
    return Number.isFinite(a) ? a : u;
  }
  return u ?? null;
}
function pg(l) {
  return Array.isArray(l) &&
    l.every((u) => typeof u == "object" && u && "name" in u)
    ? { files: l.map((u) => u.name) }
    : (l ?? void 0);
}
function mg(l) {
  const u = {
    id: zn("q"),
    type: l,
    title: `${l} question`,
    description: "",
    required: !1,
    points: 1,
    answerKey:
      l === "Paragraph" || l === "File upload"
        ? { mode: "manual" }
        : { mode: "none" },
    feedback: {},
    media: { type: "none" },
  };
  return (
    (l === "Multiple choice" || l === "Checkboxes" || l === "Dropdown") &&
      (u.options = [
        { id: zn("option"), label: "Option 1" },
        { id: zn("option"), label: "Option 2" },
      ]),
    l === "Linear scale" &&
      (u.scale = { start: 1, end: 5, lowLabel: "Low", highLabel: "High" }),
    l === "Rating" && (u.rating = { max: 5, icon: "star" }),
    (l === "Multiple choice grid" || l === "Checkbox grid") &&
      (u.grid = {
        rows: ["Row 1", "Row 2"],
        columns: ["Column 1", "Column 2"],
        requireOneResponsePerRow: !1,
        limitOneResponsePerColumn: !1,
      }),
    l === "File upload" &&
      (u.fileUpload = {
        maxFiles: 1,
        maxFileSizeMb: 10,
        acceptedTypes: ["pdf", "image"],
      }),
    l === "Date" && (u.date = { includeYear: !0, includeTime: !1 }),
    l === "Time" && (u.time = { mode: "time" }),
    u
  );
}
function hg(l) {
  return {
    id: l.id,
    title: l.title,
    points: l.points,
    answerKey: Sg(l.answerKey),
    required: l.required,
  };
}
function gg(l, u) {
  return {
    id: l.id,
    respondentName: l.respondent?.name,
    submittedAt: l.submittedAt,
    score: l.score.autoPointsPossible > 0 ? l.score.pointsAwarded : void 0,
    correctByQuestion: Object.fromEntries(
      l.score.questionScores.map((a) => [a.questionId, a.correct]),
    ),
    answers: Object.fromEntries(u.map((a) => [a.id, xg(l.answers[a.id])])),
  };
}
function xg(l) {
  return pd(l);
}
function pd(l) {
  return l === null || typeof l > "u"
    ? ""
    : typeof l == "string" || typeof l == "number"
      ? String(l)
      : Array.isArray(l)
        ? l.every((u) => typeof u == "object" && u && "name" in u)
          ? l.map((u) => u.name).join("; ")
          : l.map(String).join("; ")
        : Object.entries(l)
            .map(([u, a]) => `${u}: ${Array.isArray(a) ? a.join("|") : a}`)
            .join("; ");
}
function yg(l) {
  return !l || l.mode === "none"
    ? ""
    : l.mode === "manual"
      ? "Manual review"
      : l.mode === "grid"
        ? JSON.stringify(l.expected)
        : l.acceptedAnswers.map(String).join("; ");
}
function vg(l, u) {
  const a = String(u ?? "").trim();
  if (!a) return { mode: "none" };
  if (
    l.type === "Paragraph" ||
    l.type === "File upload" ||
    a.toLowerCase() === "manual review"
  )
    return { mode: "manual" };
  if (l.type === "Multiple choice grid" || l.type === "Checkbox grid")
    try {
      return { mode: "grid", expected: JSON.parse(a), partialCredit: !0 };
    } catch {
      return { mode: "manual" };
    }
  const d = a
    .split(";")
    .map((f) => f.trim())
    .filter(Boolean);
  return l.type === "Checkboxes"
    ? { mode: "set", acceptedAnswers: d, partialCredit: !0 }
    : { mode: "exact", acceptedAnswers: d };
}
function wg(l) {
  return l?.general ?? l?.correct ?? l?.incorrect ?? "";
}
function Oc(l) {
  return !l || l.type === "none"
    ? { kind: "none" }
    : { kind: l.type, url: l.url, label: l.title ?? l.caption };
}
function kg(l) {
  return l.kind !== "image" && l.kind !== "video"
    ? { type: "none" }
    : { type: l.kind, url: l.url ?? "", title: l.label };
}
function jg(l) {
  return (Array.isArray(l) ? l : []).map((u) => {
    if (typeof u == "string") return { id: zn("option"), label: u };
    const a = u;
    return {
      id: a.id ?? zn("option"),
      label: a.label ?? "Option",
      nextSectionId: a.nextSectionId,
    };
  });
}
function Fc(l) {
  if (Array.isArray(l))
    return l.map((u) => (typeof u == "string" ? u : String(u.label ?? "")));
}
function Sg(l) {
  if (!(!l || l.mode === "none" || l.mode === "manual"))
    return l.mode === "grid"
      ? JSON.stringify(l.expected)
      : l.acceptedAnswers.map(String).join("; ");
}
function Ng(l) {
  return l === null || typeof l > "u"
    ? !0
    : typeof l == "string"
      ? l.trim() === ""
      : Array.isArray(l)
        ? l.length === 0
        : typeof l == "object"
          ? Object.keys(l).length === 0
          : !1;
}
function Cg(l) {
  return Math.min(10, Math.max(2, l));
}
function bg(l) {
  return Math.min(10, Math.max(3, l));
}
function zn(l) {
  return `${l}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}
function zg(l) {
  return l === "length"
    ? { type: "length", condition: "min", value: 1 }
    : l === "text"
      ? { type: "text", condition: "contains", value: "" }
      : l === "number"
        ? { type: "number", condition: "between", min: 0, max: 100 }
        : l === "regex"
          ? { type: "regex", pattern: "" }
          : l === "url"
            ? { type: "url" }
            : { type: "none" };
}
function Dc(l) {
  return Array.from(l).reduce(
    (u, a) => (u * 31 + a.charCodeAt(0)) >>> 0,
    2166136261,
  );
}
kp.createRoot(document.getElementById("root")).render(
  s.jsx(mp.StrictMode, {
    children: s.jsx(om, {
      appName: "Forms",
      allowedRoles: ["admin", "student"],
      productionUrl: "https://forms.comp.school",
      children: s.jsx(Xh, {}),
    }),
  }),
);
