import {
  r as i,
  R as we,
  j as v,
  a as ir,
  b as sr,
} from "./react-vendor-DDzPbSso.js";
function Oe(e, t) {
  if (typeof e == "function") return e(t);
  e != null && (e.current = t);
}
function xe(...e) {
  return (t) => {
    let r = !1;
    const n = e.map((o) => {
      const a = Oe(o, t);
      return (!r && typeof a == "function" && (r = !0), a);
    });
    if (r)
      return () => {
        for (let o = 0; o < n.length; o++) {
          const a = n[o];
          typeof a == "function" ? a() : Oe(e[o], null);
        }
      };
  };
}
function D(...e) {
  return i.useCallback(xe(...e), e);
}
var cr = Symbol.for("react.lazy"),
  ne = we[" use ".trim().toString()];
function lr(e) {
  return typeof e == "object" && e !== null && "then" in e;
}
function Ye(e) {
  return (
    e != null &&
    typeof e == "object" &&
    "$$typeof" in e &&
    e.$$typeof === cr &&
    "_payload" in e &&
    lr(e._payload)
  );
}
function Xe(e) {
  const t = ur(e),
    r = i.forwardRef((n, o) => {
      let { children: a, ...c } = n;
      Ye(a) && typeof ne == "function" && (a = ne(a._payload));
      const s = i.Children.toArray(a),
        l = s.find(fr);
      if (l) {
        const u = l.props.children,
          d = s.map((f) =>
            f === l
              ? i.Children.count(u) > 1
                ? i.Children.only(null)
                : i.isValidElement(u)
                  ? u.props.children
                  : null
              : f,
          );
        return v.jsx(t, {
          ...c,
          ref: o,
          children: i.isValidElement(u) ? i.cloneElement(u, void 0, d) : null,
        });
      }
      return v.jsx(t, { ...c, ref: o, children: a });
    });
  return ((r.displayName = `${e}.Slot`), r);
}
var Wo = Xe("Slot");
function ur(e) {
  const t = i.forwardRef((r, n) => {
    let { children: o, ...a } = r;
    if (
      (Ye(o) && typeof ne == "function" && (o = ne(o._payload)),
      i.isValidElement(o))
    ) {
      const c = pr(o),
        s = vr(a, o.props);
      return (
        o.type !== i.Fragment && (s.ref = n ? xe(n, c) : c),
        i.cloneElement(o, s)
      );
    }
    return i.Children.count(o) > 1 ? i.Children.only(null) : null;
  });
  return ((t.displayName = `${e}.SlotClone`), t);
}
var dr = Symbol("radix.slottable");
function fr(e) {
  return (
    i.isValidElement(e) &&
    typeof e.type == "function" &&
    "__radixId" in e.type &&
    e.type.__radixId === dr
  );
}
function vr(e, t) {
  const r = { ...t };
  for (const n in t) {
    const o = e[n],
      a = t[n];
    /^on[A-Z]/.test(n)
      ? o && a
        ? (r[n] = (...s) => {
            const l = a(...s);
            return (o(...s), l);
          })
        : o && (r[n] = o)
      : n === "style"
        ? (r[n] = { ...o, ...a })
        : n === "className" && (r[n] = [o, a].filter(Boolean).join(" "));
  }
  return { ...e, ...r };
}
function pr(e) {
  let t = Object.getOwnPropertyDescriptor(e.props, "ref")?.get,
    r = t && "isReactWarning" in t && t.isReactWarning;
  return r
    ? e.ref
    : ((t = Object.getOwnPropertyDescriptor(e, "ref")?.get),
      (r = t && "isReactWarning" in t && t.isReactWarning),
      r ? e.props.ref : e.props.ref || e.ref);
}
function hr(e, t) {
  const r = i.createContext(t),
    n = (a) => {
      const { children: c, ...s } = a,
        l = i.useMemo(() => s, Object.values(s));
      return v.jsx(r.Provider, { value: l, children: c });
    };
  n.displayName = e + "Provider";
  function o(a) {
    const c = i.useContext(r);
    if (c) return c;
    if (t !== void 0) return t;
    throw new Error(`\`${a}\` must be used within \`${e}\``);
  }
  return [n, o];
}
function se(e, t = []) {
  let r = [];
  function n(a, c) {
    const s = i.createContext(c),
      l = r.length;
    r = [...r, c];
    const u = (f) => {
      const { scope: p, children: m, ...S } = f,
        h = p?.[e]?.[l] || s,
        b = i.useMemo(() => S, Object.values(S));
      return v.jsx(h.Provider, { value: b, children: m });
    };
    u.displayName = a + "Provider";
    function d(f, p) {
      const m = p?.[e]?.[l] || s,
        S = i.useContext(m);
      if (S) return S;
      if (c !== void 0) return c;
      throw new Error(`\`${f}\` must be used within \`${a}\``);
    }
    return [u, d];
  }
  const o = () => {
    const a = r.map((c) => i.createContext(c));
    return function (s) {
      const l = s?.[e] || a;
      return i.useMemo(() => ({ [`__scope${e}`]: { ...s, [e]: l } }), [s, l]);
    };
  };
  return ((o.scopeName = e), [n, mr(o, ...t)]);
}
function mr(...e) {
  const t = e[0];
  if (e.length === 1) return t;
  const r = () => {
    const n = e.map((o) => ({ useScope: o(), scopeName: o.scopeName }));
    return function (a) {
      const c = n.reduce((s, { useScope: l, scopeName: u }) => {
        const f = l(a)[`__scope${u}`];
        return { ...s, ...f };
      }, {});
      return i.useMemo(() => ({ [`__scope${t.scopeName}`]: c }), [c]);
    };
  };
  return ((r.scopeName = t.scopeName), r);
}
function P(e, t, { checkForDefaultPrevented: r = !0 } = {}) {
  return function (o) {
    if ((e?.(o), r === !1 || !o.defaultPrevented)) return t?.(o);
  };
}
var $ = globalThis?.document ? i.useLayoutEffect : () => {},
  gr = we[" useId ".trim().toString()] || (() => {}),
  br = 0;
function ve(e) {
  const [t, r] = i.useState(gr());
  return (
    $(() => {
      r((n) => n ?? String(br++));
    }, [e]),
    e || (t ? `radix-${t}` : "")
  );
}
var yr = we[" useInsertionEffect ".trim().toString()] || $;
function Ke({ prop: e, defaultProp: t, onChange: r = () => {}, caller: n }) {
  const [o, a, c] = Sr({ defaultProp: t, onChange: r }),
    s = e !== void 0,
    l = s ? e : o;
  {
    const d = i.useRef(e !== void 0);
    i.useEffect(() => {
      const f = d.current;
      (f !== s &&
        console.warn(
          `${n} is changing from ${f ? "controlled" : "uncontrolled"} to ${s ? "controlled" : "uncontrolled"}. Components should not switch from controlled to uncontrolled (or vice versa). Decide between using a controlled or uncontrolled value for the lifetime of the component.`,
        ),
        (d.current = s));
    }, [s, n]);
  }
  const u = i.useCallback(
    (d) => {
      if (s) {
        const f = Er(d) ? d(e) : d;
        f !== e && c.current?.(f);
      } else a(d);
    },
    [s, e, a, c],
  );
  return [l, u];
}
function Sr({ defaultProp: e, onChange: t }) {
  const [r, n] = i.useState(e),
    o = i.useRef(r),
    a = i.useRef(t);
  return (
    yr(() => {
      a.current = t;
    }, [t]),
    i.useEffect(() => {
      o.current !== r && (a.current?.(r), (o.current = r));
    }, [r, o]),
    [r, n, a]
  );
}
function Er(e) {
  return typeof e == "function";
}
function Ge(e) {
  const t = Cr(e),
    r = i.forwardRef((n, o) => {
      const { children: a, ...c } = n,
        s = i.Children.toArray(a),
        l = s.find(xr);
      if (l) {
        const u = l.props.children,
          d = s.map((f) =>
            f === l
              ? i.Children.count(u) > 1
                ? i.Children.only(null)
                : i.isValidElement(u)
                  ? u.props.children
                  : null
              : f,
          );
        return v.jsx(t, {
          ...c,
          ref: o,
          children: i.isValidElement(u) ? i.cloneElement(u, void 0, d) : null,
        });
      }
      return v.jsx(t, { ...c, ref: o, children: a });
    });
  return ((r.displayName = `${e}.Slot`), r);
}
function Cr(e) {
  const t = i.forwardRef((r, n) => {
    const { children: o, ...a } = r;
    if (i.isValidElement(o)) {
      const c = Pr(o),
        s = Rr(a, o.props);
      return (
        o.type !== i.Fragment && (s.ref = n ? xe(n, c) : c),
        i.cloneElement(o, s)
      );
    }
    return i.Children.count(o) > 1 ? i.Children.only(null) : null;
  });
  return ((t.displayName = `${e}.SlotClone`), t);
}
var qe = Symbol("radix.slottable");
function wr(e) {
  const t = ({ children: r }) => v.jsx(v.Fragment, { children: r });
  return ((t.displayName = `${e}.Slottable`), (t.__radixId = qe), t);
}
function xr(e) {
  return (
    i.isValidElement(e) &&
    typeof e.type == "function" &&
    "__radixId" in e.type &&
    e.type.__radixId === qe
  );
}
function Rr(e, t) {
  const r = { ...t };
  for (const n in t) {
    const o = e[n],
      a = t[n];
    /^on[A-Z]/.test(n)
      ? o && a
        ? (r[n] = (...s) => {
            const l = a(...s);
            return (o(...s), l);
          })
        : o && (r[n] = o)
      : n === "style"
        ? (r[n] = { ...o, ...a })
        : n === "className" && (r[n] = [o, a].filter(Boolean).join(" "));
  }
  return { ...e, ...r };
}
function Pr(e) {
  let t = Object.getOwnPropertyDescriptor(e.props, "ref")?.get,
    r = t && "isReactWarning" in t && t.isReactWarning;
  return r
    ? e.ref
    : ((t = Object.getOwnPropertyDescriptor(e, "ref")?.get),
      (r = t && "isReactWarning" in t && t.isReactWarning),
      r ? e.props.ref : e.props.ref || e.ref);
}
var Ar = [
    "a",
    "button",
    "div",
    "form",
    "h2",
    "h3",
    "img",
    "input",
    "label",
    "li",
    "nav",
    "ol",
    "p",
    "select",
    "span",
    "svg",
    "ul",
  ],
  T = Ar.reduce((e, t) => {
    const r = Ge(`Primitive.${t}`),
      n = i.forwardRef((o, a) => {
        const { asChild: c, ...s } = o,
          l = c ? r : t;
        return (
          typeof window < "u" && (window[Symbol.for("radix-ui")] = !0),
          v.jsx(l, { ...s, ref: a })
        );
      });
    return ((n.displayName = `Primitive.${t}`), { ...e, [t]: n });
  }, {});
function Dr(e, t) {
  e && ir.flushSync(() => e.dispatchEvent(t));
}
function O(e) {
  const t = i.useRef(e);
  return (
    i.useEffect(() => {
      t.current = e;
    }),
    i.useMemo(
      () =>
        (...r) =>
          t.current?.(...r),
      [],
    )
  );
}
function Tr(e, t = globalThis?.document) {
  const r = O(e);
  i.useEffect(() => {
    const n = (o) => {
      o.key === "Escape" && r(o);
    };
    return (
      t.addEventListener("keydown", n, { capture: !0 }),
      () => t.removeEventListener("keydown", n, { capture: !0 })
    );
  }, [r, t]);
}
var Nr = "DismissableLayer",
  Ee = "dismissableLayer.update",
  _r = "dismissableLayer.pointerDownOutside",
  Or = "dismissableLayer.focusOutside",
  Ie,
  Ze = i.createContext({
    layers: new Set(),
    layersWithOutsidePointerEventsDisabled: new Set(),
    branches: new Set(),
  }),
  Qe = i.forwardRef((e, t) => {
    const {
        disableOutsidePointerEvents: r = !1,
        onEscapeKeyDown: n,
        onPointerDownOutside: o,
        onFocusOutside: a,
        onInteractOutside: c,
        onDismiss: s,
        ...l
      } = e,
      u = i.useContext(Ze),
      [d, f] = i.useState(null),
      p = d?.ownerDocument ?? globalThis?.document,
      [, m] = i.useState({}),
      S = D(t, (E) => f(E)),
      h = Array.from(u.layers),
      [b] = [...u.layersWithOutsidePointerEventsDisabled].slice(-1),
      g = h.indexOf(b),
      y = d ? h.indexOf(d) : -1,
      w = u.layersWithOutsidePointerEventsDisabled.size > 0,
      C = y >= g,
      x = Mr((E) => {
        const _ = E.target,
          R = [...u.branches].some((N) => N.contains(_));
        !C || R || (o?.(E), c?.(E), E.defaultPrevented || s?.());
      }, p),
      A = kr((E) => {
        const _ = E.target;
        [...u.branches].some((N) => N.contains(_)) ||
          (a?.(E), c?.(E), E.defaultPrevented || s?.());
      }, p);
    return (
      Tr((E) => {
        y === u.layers.size - 1 &&
          (n?.(E), !E.defaultPrevented && s && (E.preventDefault(), s()));
      }, p),
      i.useEffect(() => {
        if (d)
          return (
            r &&
              (u.layersWithOutsidePointerEventsDisabled.size === 0 &&
                ((Ie = p.body.style.pointerEvents),
                (p.body.style.pointerEvents = "none")),
              u.layersWithOutsidePointerEventsDisabled.add(d)),
            u.layers.add(d),
            Le(),
            () => {
              r &&
                u.layersWithOutsidePointerEventsDisabled.size === 1 &&
                (p.body.style.pointerEvents = Ie);
            }
          );
      }, [d, p, r, u]),
      i.useEffect(
        () => () => {
          d &&
            (u.layers.delete(d),
            u.layersWithOutsidePointerEventsDisabled.delete(d),
            Le());
        },
        [d, u],
      ),
      i.useEffect(() => {
        const E = () => m({});
        return (
          document.addEventListener(Ee, E),
          () => document.removeEventListener(Ee, E)
        );
      }, []),
      v.jsx(T.div, {
        ...l,
        ref: S,
        style: {
          pointerEvents: w ? (C ? "auto" : "none") : void 0,
          ...e.style,
        },
        onFocusCapture: P(e.onFocusCapture, A.onFocusCapture),
        onBlurCapture: P(e.onBlurCapture, A.onBlurCapture),
        onPointerDownCapture: P(e.onPointerDownCapture, x.onPointerDownCapture),
      })
    );
  });
Qe.displayName = Nr;
var Ir = "DismissableLayerBranch",
  Lr = i.forwardRef((e, t) => {
    const r = i.useContext(Ze),
      n = i.useRef(null),
      o = D(t, n);
    return (
      i.useEffect(() => {
        const a = n.current;
        if (a)
          return (
            r.branches.add(a),
            () => {
              r.branches.delete(a);
            }
          );
      }, [r.branches]),
      v.jsx(T.div, { ...e, ref: o })
    );
  });
Lr.displayName = Ir;
function Mr(e, t = globalThis?.document) {
  const r = O(e),
    n = i.useRef(!1),
    o = i.useRef(() => {});
  return (
    i.useEffect(() => {
      const a = (s) => {
          if (s.target && !n.current) {
            let l = function () {
              Je(_r, r, u, { discrete: !0 });
            };
            const u = { originalEvent: s };
            s.pointerType === "touch"
              ? (t.removeEventListener("click", o.current),
                (o.current = l),
                t.addEventListener("click", o.current, { once: !0 }))
              : l();
          } else t.removeEventListener("click", o.current);
          n.current = !1;
        },
        c = window.setTimeout(() => {
          t.addEventListener("pointerdown", a);
        }, 0);
      return () => {
        (window.clearTimeout(c),
          t.removeEventListener("pointerdown", a),
          t.removeEventListener("click", o.current));
      };
    }, [t, r]),
    { onPointerDownCapture: () => (n.current = !0) }
  );
}
function kr(e, t = globalThis?.document) {
  const r = O(e),
    n = i.useRef(!1);
  return (
    i.useEffect(() => {
      const o = (a) => {
        a.target &&
          !n.current &&
          Je(Or, r, { originalEvent: a }, { discrete: !1 });
      };
      return (
        t.addEventListener("focusin", o),
        () => t.removeEventListener("focusin", o)
      );
    }, [t, r]),
    {
      onFocusCapture: () => (n.current = !0),
      onBlurCapture: () => (n.current = !1),
    }
  );
}
function Le() {
  const e = new CustomEvent(Ee);
  document.dispatchEvent(e);
}
function Je(e, t, r, { discrete: n }) {
  const o = r.originalEvent.target,
    a = new CustomEvent(e, { bubbles: !1, cancelable: !0, detail: r });
  (t && o.addEventListener(e, t, { once: !0 }),
    n ? Dr(o, a) : o.dispatchEvent(a));
}
var pe = "focusScope.autoFocusOnMount",
  he = "focusScope.autoFocusOnUnmount",
  Me = { bubbles: !1, cancelable: !0 },
  jr = "FocusScope",
  et = i.forwardRef((e, t) => {
    const {
        loop: r = !1,
        trapped: n = !1,
        onMountAutoFocus: o,
        onUnmountAutoFocus: a,
        ...c
      } = e,
      [s, l] = i.useState(null),
      u = O(o),
      d = O(a),
      f = i.useRef(null),
      p = D(t, (h) => l(h)),
      m = i.useRef({
        paused: !1,
        pause() {
          this.paused = !0;
        },
        resume() {
          this.paused = !1;
        },
      }).current;
    (i.useEffect(() => {
      if (n) {
        let h = function (w) {
            if (m.paused || !s) return;
            const C = w.target;
            s.contains(C) ? (f.current = C) : W(f.current, { select: !0 });
          },
          b = function (w) {
            if (m.paused || !s) return;
            const C = w.relatedTarget;
            C !== null && (s.contains(C) || W(f.current, { select: !0 }));
          },
          g = function (w) {
            if (document.activeElement === document.body)
              for (const x of w) x.removedNodes.length > 0 && W(s);
          };
        (document.addEventListener("focusin", h),
          document.addEventListener("focusout", b));
        const y = new MutationObserver(g);
        return (
          s && y.observe(s, { childList: !0, subtree: !0 }),
          () => {
            (document.removeEventListener("focusin", h),
              document.removeEventListener("focusout", b),
              y.disconnect());
          }
        );
      }
    }, [n, s, m.paused]),
      i.useEffect(() => {
        if (s) {
          je.add(m);
          const h = document.activeElement;
          if (!s.contains(h)) {
            const g = new CustomEvent(pe, Me);
            (s.addEventListener(pe, u),
              s.dispatchEvent(g),
              g.defaultPrevented ||
                (Fr(Hr(tt(s)), { select: !0 }),
                document.activeElement === h && W(s)));
          }
          return () => {
            (s.removeEventListener(pe, u),
              setTimeout(() => {
                const g = new CustomEvent(he, Me);
                (s.addEventListener(he, d),
                  s.dispatchEvent(g),
                  g.defaultPrevented || W(h ?? document.body, { select: !0 }),
                  s.removeEventListener(he, d),
                  je.remove(m));
              }, 0));
          };
        }
      }, [s, u, d, m]));
    const S = i.useCallback(
      (h) => {
        if ((!r && !n) || m.paused) return;
        const b = h.key === "Tab" && !h.altKey && !h.ctrlKey && !h.metaKey,
          g = document.activeElement;
        if (b && g) {
          const y = h.currentTarget,
            [w, C] = Wr(y);
          w && C
            ? !h.shiftKey && g === C
              ? (h.preventDefault(), r && W(w, { select: !0 }))
              : h.shiftKey &&
                g === w &&
                (h.preventDefault(), r && W(C, { select: !0 }))
            : g === y && h.preventDefault();
        }
      },
      [r, n, m.paused],
    );
    return v.jsx(T.div, { tabIndex: -1, ...c, ref: p, onKeyDown: S });
  });
et.displayName = jr;
function Fr(e, { select: t = !1 } = {}) {
  const r = document.activeElement;
  for (const n of e)
    if ((W(n, { select: t }), document.activeElement !== r)) return;
}
function Wr(e) {
  const t = tt(e),
    r = ke(t, e),
    n = ke(t.reverse(), e);
  return [r, n];
}
function tt(e) {
  const t = [],
    r = document.createTreeWalker(e, NodeFilter.SHOW_ELEMENT, {
      acceptNode: (n) => {
        const o = n.tagName === "INPUT" && n.type === "hidden";
        return n.disabled || n.hidden || o
          ? NodeFilter.FILTER_SKIP
          : n.tabIndex >= 0
            ? NodeFilter.FILTER_ACCEPT
            : NodeFilter.FILTER_SKIP;
      },
    });
  for (; r.nextNode();) t.push(r.currentNode);
  return t;
}
function ke(e, t) {
  for (const r of e) if (!Br(r, { upTo: t })) return r;
}
function Br(e, { upTo: t }) {
  if (getComputedStyle(e).visibility === "hidden") return !0;
  for (; e;) {
    if (t !== void 0 && e === t) return !1;
    if (getComputedStyle(e).display === "none") return !0;
    e = e.parentElement;
  }
  return !1;
}
function $r(e) {
  return e instanceof HTMLInputElement && "select" in e;
}
function W(e, { select: t = !1 } = {}) {
  if (e && e.focus) {
    const r = document.activeElement;
    (e.focus({ preventScroll: !0 }), e !== r && $r(e) && t && e.select());
  }
}
var je = Ur();
function Ur() {
  let e = [];
  return {
    add(t) {
      const r = e[0];
      (t !== r && r?.pause(), (e = Fe(e, t)), e.unshift(t));
    },
    remove(t) {
      ((e = Fe(e, t)), e[0]?.resume());
    },
  };
}
function Fe(e, t) {
  const r = [...e],
    n = r.indexOf(t);
  return (n !== -1 && r.splice(n, 1), r);
}
function Hr(e) {
  return e.filter((t) => t.tagName !== "A");
}
var zr = "Portal",
  rt = i.forwardRef((e, t) => {
    const { container: r, ...n } = e,
      [o, a] = i.useState(!1);
    $(() => a(!0), []);
    const c = r || (o && globalThis?.document?.body);
    return c ? sr.createPortal(v.jsx(T.div, { ...n, ref: t }), c) : null;
  });
rt.displayName = zr;
function Vr(e, t) {
  return i.useReducer((r, n) => t[r][n] ?? r, e);
}
var j = (e) => {
  const { present: t, children: r } = e,
    n = Yr(t),
    o =
      typeof r == "function" ? r({ present: n.isPresent }) : i.Children.only(r),
    a = D(n.ref, Xr(o));
  return typeof r == "function" || n.isPresent
    ? i.cloneElement(o, { ref: a })
    : null;
};
j.displayName = "Presence";
function Yr(e) {
  const [t, r] = i.useState(),
    n = i.useRef(null),
    o = i.useRef(e),
    a = i.useRef("none"),
    c = e ? "mounted" : "unmounted",
    [s, l] = Vr(c, {
      mounted: { UNMOUNT: "unmounted", ANIMATION_OUT: "unmountSuspended" },
      unmountSuspended: { MOUNT: "mounted", ANIMATION_END: "unmounted" },
      unmounted: { MOUNT: "mounted" },
    });
  return (
    i.useEffect(() => {
      const u = q(n.current);
      a.current = s === "mounted" ? u : "none";
    }, [s]),
    $(() => {
      const u = n.current,
        d = o.current;
      if (d !== e) {
        const p = a.current,
          m = q(u);
        (e
          ? l("MOUNT")
          : m === "none" || u?.display === "none"
            ? l("UNMOUNT")
            : l(d && p !== m ? "ANIMATION_OUT" : "UNMOUNT"),
          (o.current = e));
      }
    }, [e, l]),
    $(() => {
      if (t) {
        let u;
        const d = t.ownerDocument.defaultView ?? window,
          f = (m) => {
            const h = q(n.current).includes(CSS.escape(m.animationName));
            if (m.target === t && h && (l("ANIMATION_END"), !o.current)) {
              const b = t.style.animationFillMode;
              ((t.style.animationFillMode = "forwards"),
                (u = d.setTimeout(() => {
                  t.style.animationFillMode === "forwards" &&
                    (t.style.animationFillMode = b);
                })));
            }
          },
          p = (m) => {
            m.target === t && (a.current = q(n.current));
          };
        return (
          t.addEventListener("animationstart", p),
          t.addEventListener("animationcancel", f),
          t.addEventListener("animationend", f),
          () => {
            (d.clearTimeout(u),
              t.removeEventListener("animationstart", p),
              t.removeEventListener("animationcancel", f),
              t.removeEventListener("animationend", f));
          }
        );
      } else l("ANIMATION_END");
    }, [t, l]),
    {
      isPresent: ["mounted", "unmountSuspended"].includes(s),
      ref: i.useCallback((u) => {
        ((n.current = u ? getComputedStyle(u) : null), r(u));
      }, []),
    }
  );
}
function q(e) {
  return e?.animationName || "none";
}
function Xr(e) {
  let t = Object.getOwnPropertyDescriptor(e.props, "ref")?.get,
    r = t && "isReactWarning" in t && t.isReactWarning;
  return r
    ? e.ref
    : ((t = Object.getOwnPropertyDescriptor(e, "ref")?.get),
      (r = t && "isReactWarning" in t && t.isReactWarning),
      r ? e.props.ref : e.props.ref || e.ref);
}
var me = 0;
function Kr() {
  i.useEffect(() => {
    const e = document.querySelectorAll("[data-radix-focus-guard]");
    return (
      document.body.insertAdjacentElement("afterbegin", e[0] ?? We()),
      document.body.insertAdjacentElement("beforeend", e[1] ?? We()),
      me++,
      () => {
        (me === 1 &&
          document
            .querySelectorAll("[data-radix-focus-guard]")
            .forEach((t) => t.remove()),
          me--);
      }
    );
  }, []);
}
function We() {
  const e = document.createElement("span");
  return (
    e.setAttribute("data-radix-focus-guard", ""),
    (e.tabIndex = 0),
    (e.style.outline = "none"),
    (e.style.opacity = "0"),
    (e.style.position = "fixed"),
    (e.style.pointerEvents = "none"),
    e
  );
}
var M = function () {
  return (
    (M =
      Object.assign ||
      function (t) {
        for (var r, n = 1, o = arguments.length; n < o; n++) {
          r = arguments[n];
          for (var a in r)
            Object.prototype.hasOwnProperty.call(r, a) && (t[a] = r[a]);
        }
        return t;
      }),
    M.apply(this, arguments)
  );
};
function nt(e, t) {
  var r = {};
  for (var n in e)
    Object.prototype.hasOwnProperty.call(e, n) &&
      t.indexOf(n) < 0 &&
      (r[n] = e[n]);
  if (e != null && typeof Object.getOwnPropertySymbols == "function")
    for (var o = 0, n = Object.getOwnPropertySymbols(e); o < n.length; o++)
      t.indexOf(n[o]) < 0 &&
        Object.prototype.propertyIsEnumerable.call(e, n[o]) &&
        (r[n[o]] = e[n[o]]);
  return r;
}
function Gr(e, t, r) {
  if (r || arguments.length === 2)
    for (var n = 0, o = t.length, a; n < o; n++)
      (a || !(n in t)) &&
        (a || (a = Array.prototype.slice.call(t, 0, n)), (a[n] = t[n]));
  return e.concat(a || Array.prototype.slice.call(t));
}
var te = "right-scroll-bar-position",
  re = "width-before-scroll-bar",
  qr = "with-scroll-bars-hidden",
  Zr = "--removed-body-scroll-bar-size";
function ge(e, t) {
  return (typeof e == "function" ? e(t) : e && (e.current = t), e);
}
function Qr(e, t) {
  var r = i.useState(function () {
    return {
      value: e,
      callback: t,
      facade: {
        get current() {
          return r.value;
        },
        set current(n) {
          var o = r.value;
          o !== n && ((r.value = n), r.callback(n, o));
        },
      },
    };
  })[0];
  return ((r.callback = t), r.facade);
}
var Jr = typeof window < "u" ? i.useLayoutEffect : i.useEffect,
  Be = new WeakMap();
function en(e, t) {
  var r = Qr(null, function (n) {
    return e.forEach(function (o) {
      return ge(o, n);
    });
  });
  return (
    Jr(
      function () {
        var n = Be.get(r);
        if (n) {
          var o = new Set(n),
            a = new Set(e),
            c = r.current;
          (o.forEach(function (s) {
            a.has(s) || ge(s, null);
          }),
            a.forEach(function (s) {
              o.has(s) || ge(s, c);
            }));
        }
        Be.set(r, e);
      },
      [e],
    ),
    r
  );
}
function tn(e) {
  return e;
}
function rn(e, t) {
  t === void 0 && (t = tn);
  var r = [],
    n = !1,
    o = {
      read: function () {
        if (n)
          throw new Error(
            "Sidecar: could not `read` from an `assigned` medium. `read` could be used only with `useMedium`.",
          );
        return r.length ? r[r.length - 1] : e;
      },
      useMedium: function (a) {
        var c = t(a, n);
        return (
          r.push(c),
          function () {
            r = r.filter(function (s) {
              return s !== c;
            });
          }
        );
      },
      assignSyncMedium: function (a) {
        for (n = !0; r.length;) {
          var c = r;
          ((r = []), c.forEach(a));
        }
        r = {
          push: function (s) {
            return a(s);
          },
          filter: function () {
            return r;
          },
        };
      },
      assignMedium: function (a) {
        n = !0;
        var c = [];
        if (r.length) {
          var s = r;
          ((r = []), s.forEach(a), (c = r));
        }
        var l = function () {
            var d = c;
            ((c = []), d.forEach(a));
          },
          u = function () {
            return Promise.resolve().then(l);
          };
        (u(),
          (r = {
            push: function (d) {
              (c.push(d), u());
            },
            filter: function (d) {
              return ((c = c.filter(d)), r);
            },
          }));
      },
    };
  return o;
}
function nn(e) {
  e === void 0 && (e = {});
  var t = rn(null);
  return ((t.options = M({ async: !0, ssr: !1 }, e)), t);
}
var ot = function (e) {
  var t = e.sideCar,
    r = nt(e, ["sideCar"]);
  if (!t)
    throw new Error(
      "Sidecar: please provide `sideCar` property to import the right car",
    );
  var n = t.read();
  if (!n) throw new Error("Sidecar medium not found");
  return i.createElement(n, M({}, r));
};
ot.isSideCarExport = !0;
function on(e, t) {
  return (e.useMedium(t), ot);
}
var at = nn(),
  be = function () {},
  ce = i.forwardRef(function (e, t) {
    var r = i.useRef(null),
      n = i.useState({
        onScrollCapture: be,
        onWheelCapture: be,
        onTouchMoveCapture: be,
      }),
      o = n[0],
      a = n[1],
      c = e.forwardProps,
      s = e.children,
      l = e.className,
      u = e.removeScrollBar,
      d = e.enabled,
      f = e.shards,
      p = e.sideCar,
      m = e.noRelative,
      S = e.noIsolation,
      h = e.inert,
      b = e.allowPinchZoom,
      g = e.as,
      y = g === void 0 ? "div" : g,
      w = e.gapMode,
      C = nt(e, [
        "forwardProps",
        "children",
        "className",
        "removeScrollBar",
        "enabled",
        "shards",
        "sideCar",
        "noRelative",
        "noIsolation",
        "inert",
        "allowPinchZoom",
        "as",
        "gapMode",
      ]),
      x = p,
      A = en([r, t]),
      E = M(M({}, C), o);
    return i.createElement(
      i.Fragment,
      null,
      d &&
        i.createElement(x, {
          sideCar: at,
          removeScrollBar: u,
          shards: f,
          noRelative: m,
          noIsolation: S,
          inert: h,
          setCallbacks: a,
          allowPinchZoom: !!b,
          lockRef: r,
          gapMode: w,
        }),
      c
        ? i.cloneElement(i.Children.only(s), M(M({}, E), { ref: A }))
        : i.createElement(y, M({}, E, { className: l, ref: A }), s),
    );
  });
ce.defaultProps = { enabled: !0, removeScrollBar: !0, inert: !1 };
ce.classNames = { fullWidth: re, zeroRight: te };
var an = function () {
  if (typeof __webpack_nonce__ < "u") return __webpack_nonce__;
};
function sn() {
  if (!document) return null;
  var e = document.createElement("style");
  e.type = "text/css";
  var t = an();
  return (t && e.setAttribute("nonce", t), e);
}
function cn(e, t) {
  e.styleSheet
    ? (e.styleSheet.cssText = t)
    : e.appendChild(document.createTextNode(t));
}
function ln(e) {
  var t = document.head || document.getElementsByTagName("head")[0];
  t.appendChild(e);
}
var un = function () {
    var e = 0,
      t = null;
    return {
      add: function (r) {
        (e == 0 && (t = sn()) && (cn(t, r), ln(t)), e++);
      },
      remove: function () {
        (e--,
          !e && t && (t.parentNode && t.parentNode.removeChild(t), (t = null)));
      },
    };
  },
  dn = function () {
    var e = un();
    return function (t, r) {
      i.useEffect(
        function () {
          return (
            e.add(t),
            function () {
              e.remove();
            }
          );
        },
        [t && r],
      );
    };
  },
  it = function () {
    var e = dn(),
      t = function (r) {
        var n = r.styles,
          o = r.dynamic;
        return (e(n, o), null);
      };
    return t;
  },
  fn = { left: 0, top: 0, right: 0, gap: 0 },
  ye = function (e) {
    return parseInt(e || "", 10) || 0;
  },
  vn = function (e) {
    var t = window.getComputedStyle(document.body),
      r = t[e === "padding" ? "paddingLeft" : "marginLeft"],
      n = t[e === "padding" ? "paddingTop" : "marginTop"],
      o = t[e === "padding" ? "paddingRight" : "marginRight"];
    return [ye(r), ye(n), ye(o)];
  },
  pn = function (e) {
    if ((e === void 0 && (e = "margin"), typeof window > "u")) return fn;
    var t = vn(e),
      r = document.documentElement.clientWidth,
      n = window.innerWidth;
    return {
      left: t[0],
      top: t[1],
      right: t[2],
      gap: Math.max(0, n - r + t[2] - t[0]),
    };
  },
  hn = it(),
  X = "data-scroll-locked",
  mn = function (e, t, r, n) {
    var o = e.left,
      a = e.top,
      c = e.right,
      s = e.gap;
    return (
      r === void 0 && (r = "margin"),
      `
  .`
        .concat(
          qr,
          ` {
   overflow: hidden `,
        )
        .concat(
          n,
          `;
   padding-right: `,
        )
        .concat(s, "px ")
        .concat(
          n,
          `;
  }
  body[`,
        )
        .concat(
          X,
          `] {
    overflow: hidden `,
        )
        .concat(
          n,
          `;
    overscroll-behavior: contain;
    `,
        )
        .concat(
          [
            t && "position: relative ".concat(n, ";"),
            r === "margin" &&
              `
    padding-left: `
                .concat(
                  o,
                  `px;
    padding-top: `,
                )
                .concat(
                  a,
                  `px;
    padding-right: `,
                )
                .concat(
                  c,
                  `px;
    margin-left:0;
    margin-top:0;
    margin-right: `,
                )
                .concat(s, "px ")
                .concat(
                  n,
                  `;
    `,
                ),
            r === "padding" &&
              "padding-right: ".concat(s, "px ").concat(n, ";"),
          ]
            .filter(Boolean)
            .join(""),
          `
  }
  
  .`,
        )
        .concat(
          te,
          ` {
    right: `,
        )
        .concat(s, "px ")
        .concat(
          n,
          `;
  }
  
  .`,
        )
        .concat(
          re,
          ` {
    margin-right: `,
        )
        .concat(s, "px ")
        .concat(
          n,
          `;
  }
  
  .`,
        )
        .concat(te, " .")
        .concat(
          te,
          ` {
    right: 0 `,
        )
        .concat(
          n,
          `;
  }
  
  .`,
        )
        .concat(re, " .")
        .concat(
          re,
          ` {
    margin-right: 0 `,
        )
        .concat(
          n,
          `;
  }
  
  body[`,
        )
        .concat(
          X,
          `] {
    `,
        )
        .concat(Zr, ": ")
        .concat(
          s,
          `px;
  }
`,
        )
    );
  },
  $e = function () {
    var e = parseInt(document.body.getAttribute(X) || "0", 10);
    return isFinite(e) ? e : 0;
  },
  gn = function () {
    i.useEffect(function () {
      return (
        document.body.setAttribute(X, ($e() + 1).toString()),
        function () {
          var e = $e() - 1;
          e <= 0
            ? document.body.removeAttribute(X)
            : document.body.setAttribute(X, e.toString());
        }
      );
    }, []);
  },
  bn = function (e) {
    var t = e.noRelative,
      r = e.noImportant,
      n = e.gapMode,
      o = n === void 0 ? "margin" : n;
    gn();
    var a = i.useMemo(
      function () {
        return pn(o);
      },
      [o],
    );
    return i.createElement(hn, { styles: mn(a, !t, o, r ? "" : "!important") });
  },
  Ce = !1;
if (typeof window < "u")
  try {
    var Z = Object.defineProperty({}, "passive", {
      get: function () {
        return ((Ce = !0), !0);
      },
    });
    (window.addEventListener("test", Z, Z),
      window.removeEventListener("test", Z, Z));
  } catch {
    Ce = !1;
  }
var z = Ce ? { passive: !1 } : !1,
  yn = function (e) {
    return e.tagName === "TEXTAREA";
  },
  st = function (e, t) {
    if (!(e instanceof Element)) return !1;
    var r = window.getComputedStyle(e);
    return (
      r[t] !== "hidden" &&
      !(r.overflowY === r.overflowX && !yn(e) && r[t] === "visible")
    );
  },
  Sn = function (e) {
    return st(e, "overflowY");
  },
  En = function (e) {
    return st(e, "overflowX");
  },
  Ue = function (e, t) {
    var r = t.ownerDocument,
      n = t;
    do {
      typeof ShadowRoot < "u" && n instanceof ShadowRoot && (n = n.host);
      var o = ct(e, n);
      if (o) {
        var a = lt(e, n),
          c = a[1],
          s = a[2];
        if (c > s) return !0;
      }
      n = n.parentNode;
    } while (n && n !== r.body);
    return !1;
  },
  Cn = function (e) {
    var t = e.scrollTop,
      r = e.scrollHeight,
      n = e.clientHeight;
    return [t, r, n];
  },
  wn = function (e) {
    var t = e.scrollLeft,
      r = e.scrollWidth,
      n = e.clientWidth;
    return [t, r, n];
  },
  ct = function (e, t) {
    return e === "v" ? Sn(t) : En(t);
  },
  lt = function (e, t) {
    return e === "v" ? Cn(t) : wn(t);
  },
  xn = function (e, t) {
    return e === "h" && t === "rtl" ? -1 : 1;
  },
  Rn = function (e, t, r, n, o) {
    var a = xn(e, window.getComputedStyle(t).direction),
      c = a * n,
      s = r.target,
      l = t.contains(s),
      u = !1,
      d = c > 0,
      f = 0,
      p = 0;
    do {
      if (!s) break;
      var m = lt(e, s),
        S = m[0],
        h = m[1],
        b = m[2],
        g = h - b - a * S;
      (S || g) && ct(e, s) && ((f += g), (p += S));
      var y = s.parentNode;
      s = y && y.nodeType === Node.DOCUMENT_FRAGMENT_NODE ? y.host : y;
    } while ((!l && s !== document.body) || (l && (t.contains(s) || t === s)));
    return (((d && Math.abs(f) < 1) || (!d && Math.abs(p) < 1)) && (u = !0), u);
  },
  Q = function (e) {
    return "changedTouches" in e
      ? [e.changedTouches[0].clientX, e.changedTouches[0].clientY]
      : [0, 0];
  },
  He = function (e) {
    return [e.deltaX, e.deltaY];
  },
  ze = function (e) {
    return e && "current" in e ? e.current : e;
  },
  Pn = function (e, t) {
    return e[0] === t[0] && e[1] === t[1];
  },
  An = function (e) {
    return `
  .block-interactivity-`
      .concat(
        e,
        ` {pointer-events: none;}
  .allow-interactivity-`,
      )
      .concat(
        e,
        ` {pointer-events: all;}
`,
      );
  },
  Dn = 0,
  V = [];
function Tn(e) {
  var t = i.useRef([]),
    r = i.useRef([0, 0]),
    n = i.useRef(),
    o = i.useState(Dn++)[0],
    a = i.useState(it)[0],
    c = i.useRef(e);
  (i.useEffect(
    function () {
      c.current = e;
    },
    [e],
  ),
    i.useEffect(
      function () {
        if (e.inert) {
          document.body.classList.add("block-interactivity-".concat(o));
          var h = Gr([e.lockRef.current], (e.shards || []).map(ze), !0).filter(
            Boolean,
          );
          return (
            h.forEach(function (b) {
              return b.classList.add("allow-interactivity-".concat(o));
            }),
            function () {
              (document.body.classList.remove("block-interactivity-".concat(o)),
                h.forEach(function (b) {
                  return b.classList.remove("allow-interactivity-".concat(o));
                }));
            }
          );
        }
      },
      [e.inert, e.lockRef.current, e.shards],
    ));
  var s = i.useCallback(function (h, b) {
      if (
        ("touches" in h && h.touches.length === 2) ||
        (h.type === "wheel" && h.ctrlKey)
      )
        return !c.current.allowPinchZoom;
      var g = Q(h),
        y = r.current,
        w = "deltaX" in h ? h.deltaX : y[0] - g[0],
        C = "deltaY" in h ? h.deltaY : y[1] - g[1],
        x,
        A = h.target,
        E = Math.abs(w) > Math.abs(C) ? "h" : "v";
      if ("touches" in h && E === "h" && A.type === "range") return !1;
      var _ = Ue(E, A);
      if (!_) return !0;
      if ((_ ? (x = E) : ((x = E === "v" ? "h" : "v"), (_ = Ue(E, A))), !_))
        return !1;
      if (
        (!n.current && "changedTouches" in h && (w || C) && (n.current = x), !x)
      )
        return !0;
      var R = n.current || x;
      return Rn(R, b, h, R === "h" ? w : C);
    }, []),
    l = i.useCallback(function (h) {
      var b = h;
      if (!(!V.length || V[V.length - 1] !== a)) {
        var g = "deltaY" in b ? He(b) : Q(b),
          y = t.current.filter(function (x) {
            return (
              x.name === b.type &&
              (x.target === b.target || b.target === x.shadowParent) &&
              Pn(x.delta, g)
            );
          })[0];
        if (y && y.should) {
          b.cancelable && b.preventDefault();
          return;
        }
        if (!y) {
          var w = (c.current.shards || [])
              .map(ze)
              .filter(Boolean)
              .filter(function (x) {
                return x.contains(b.target);
              }),
            C = w.length > 0 ? s(b, w[0]) : !c.current.noIsolation;
          C && b.cancelable && b.preventDefault();
        }
      }
    }, []),
    u = i.useCallback(function (h, b, g, y) {
      var w = { name: h, delta: b, target: g, should: y, shadowParent: Nn(g) };
      (t.current.push(w),
        setTimeout(function () {
          t.current = t.current.filter(function (C) {
            return C !== w;
          });
        }, 1));
    }, []),
    d = i.useCallback(function (h) {
      ((r.current = Q(h)), (n.current = void 0));
    }, []),
    f = i.useCallback(function (h) {
      u(h.type, He(h), h.target, s(h, e.lockRef.current));
    }, []),
    p = i.useCallback(function (h) {
      u(h.type, Q(h), h.target, s(h, e.lockRef.current));
    }, []);
  i.useEffect(function () {
    return (
      V.push(a),
      e.setCallbacks({
        onScrollCapture: f,
        onWheelCapture: f,
        onTouchMoveCapture: p,
      }),
      document.addEventListener("wheel", l, z),
      document.addEventListener("touchmove", l, z),
      document.addEventListener("touchstart", d, z),
      function () {
        ((V = V.filter(function (h) {
          return h !== a;
        })),
          document.removeEventListener("wheel", l, z),
          document.removeEventListener("touchmove", l, z),
          document.removeEventListener("touchstart", d, z));
      }
    );
  }, []);
  var m = e.removeScrollBar,
    S = e.inert;
  return i.createElement(
    i.Fragment,
    null,
    S ? i.createElement(a, { styles: An(o) }) : null,
    m
      ? i.createElement(bn, { noRelative: e.noRelative, gapMode: e.gapMode })
      : null,
  );
}
function Nn(e) {
  for (var t = null; e !== null;)
    (e instanceof ShadowRoot && ((t = e.host), (e = e.host)),
      (e = e.parentNode));
  return t;
}
const _n = on(at, Tn);
var ut = i.forwardRef(function (e, t) {
  return i.createElement(ce, M({}, e, { ref: t, sideCar: _n }));
});
ut.classNames = ce.classNames;
var On = function (e) {
    if (typeof document > "u") return null;
    var t = Array.isArray(e) ? e[0] : e;
    return t.ownerDocument.body;
  },
  Y = new WeakMap(),
  J = new WeakMap(),
  ee = {},
  Se = 0,
  dt = function (e) {
    return e && (e.host || dt(e.parentNode));
  },
  In = function (e, t) {
    return t
      .map(function (r) {
        if (e.contains(r)) return r;
        var n = dt(r);
        return n && e.contains(n)
          ? n
          : (console.error(
              "aria-hidden",
              r,
              "in not contained inside",
              e,
              ". Doing nothing",
            ),
            null);
      })
      .filter(function (r) {
        return !!r;
      });
  },
  Ln = function (e, t, r, n) {
    var o = In(t, Array.isArray(e) ? e : [e]);
    ee[r] || (ee[r] = new WeakMap());
    var a = ee[r],
      c = [],
      s = new Set(),
      l = new Set(o),
      u = function (f) {
        !f || s.has(f) || (s.add(f), u(f.parentNode));
      };
    o.forEach(u);
    var d = function (f) {
      !f ||
        l.has(f) ||
        Array.prototype.forEach.call(f.children, function (p) {
          if (s.has(p)) d(p);
          else
            try {
              var m = p.getAttribute(n),
                S = m !== null && m !== "false",
                h = (Y.get(p) || 0) + 1,
                b = (a.get(p) || 0) + 1;
              (Y.set(p, h),
                a.set(p, b),
                c.push(p),
                h === 1 && S && J.set(p, !0),
                b === 1 && p.setAttribute(r, "true"),
                S || p.setAttribute(n, "true"));
            } catch (g) {
              console.error("aria-hidden: cannot operate on ", p, g);
            }
        });
    };
    return (
      d(t),
      s.clear(),
      Se++,
      function () {
        (c.forEach(function (f) {
          var p = Y.get(f) - 1,
            m = a.get(f) - 1;
          (Y.set(f, p),
            a.set(f, m),
            p || (J.has(f) || f.removeAttribute(n), J.delete(f)),
            m || f.removeAttribute(r));
        }),
          Se--,
          Se ||
            ((Y = new WeakMap()),
            (Y = new WeakMap()),
            (J = new WeakMap()),
            (ee = {})));
      }
    );
  },
  Mn = function (e, t, r) {
    r === void 0 && (r = "data-aria-hidden");
    var n = Array.from(Array.isArray(e) ? e : [e]),
      o = On(e);
    return o
      ? (n.push.apply(n, Array.from(o.querySelectorAll("[aria-live], script"))),
        Ln(n, o, r, "aria-hidden"))
      : function () {
          return null;
        };
  },
  le = "Dialog",
  [ft, vt] = se(le),
  [kn, L] = ft(le),
  pt = (e) => {
    const {
        __scopeDialog: t,
        children: r,
        open: n,
        defaultOpen: o,
        onOpenChange: a,
        modal: c = !0,
      } = e,
      s = i.useRef(null),
      l = i.useRef(null),
      [u, d] = Ke({ prop: n, defaultProp: o ?? !1, onChange: a, caller: le });
    return v.jsx(kn, {
      scope: t,
      triggerRef: s,
      contentRef: l,
      contentId: ve(),
      titleId: ve(),
      descriptionId: ve(),
      open: u,
      onOpenChange: d,
      onOpenToggle: i.useCallback(() => d((f) => !f), [d]),
      modal: c,
      children: r,
    });
  };
pt.displayName = le;
var ht = "DialogTrigger",
  mt = i.forwardRef((e, t) => {
    const { __scopeDialog: r, ...n } = e,
      o = L(ht, r),
      a = D(t, o.triggerRef);
    return v.jsx(T.button, {
      type: "button",
      "aria-haspopup": "dialog",
      "aria-expanded": o.open,
      "aria-controls": o.contentId,
      "data-state": Ae(o.open),
      ...n,
      ref: a,
      onClick: P(e.onClick, o.onOpenToggle),
    });
  });
mt.displayName = ht;
var Re = "DialogPortal",
  [jn, gt] = ft(Re, { forceMount: void 0 }),
  bt = (e) => {
    const { __scopeDialog: t, forceMount: r, children: n, container: o } = e,
      a = L(Re, t);
    return v.jsx(jn, {
      scope: t,
      forceMount: r,
      children: i.Children.map(n, (c) =>
        v.jsx(j, {
          present: r || a.open,
          children: v.jsx(rt, { asChild: !0, container: o, children: c }),
        }),
      ),
    });
  };
bt.displayName = Re;
var oe = "DialogOverlay",
  yt = i.forwardRef((e, t) => {
    const r = gt(oe, e.__scopeDialog),
      { forceMount: n = r.forceMount, ...o } = e,
      a = L(oe, e.__scopeDialog);
    return a.modal
      ? v.jsx(j, {
          present: n || a.open,
          children: v.jsx(Wn, { ...o, ref: t }),
        })
      : null;
  });
yt.displayName = oe;
var Fn = Ge("DialogOverlay.RemoveScroll"),
  Wn = i.forwardRef((e, t) => {
    const { __scopeDialog: r, ...n } = e,
      o = L(oe, r);
    return v.jsx(ut, {
      as: Fn,
      allowPinchZoom: !0,
      shards: [o.contentRef],
      children: v.jsx(T.div, {
        "data-state": Ae(o.open),
        ...n,
        ref: t,
        style: { pointerEvents: "auto", ...n.style },
      }),
    });
  }),
  U = "DialogContent",
  St = i.forwardRef((e, t) => {
    const r = gt(U, e.__scopeDialog),
      { forceMount: n = r.forceMount, ...o } = e,
      a = L(U, e.__scopeDialog);
    return v.jsx(j, {
      present: n || a.open,
      children: a.modal
        ? v.jsx(Bn, { ...o, ref: t })
        : v.jsx($n, { ...o, ref: t }),
    });
  });
St.displayName = U;
var Bn = i.forwardRef((e, t) => {
    const r = L(U, e.__scopeDialog),
      n = i.useRef(null),
      o = D(t, r.contentRef, n);
    return (
      i.useEffect(() => {
        const a = n.current;
        if (a) return Mn(a);
      }, []),
      v.jsx(Et, {
        ...e,
        ref: o,
        trapFocus: r.open,
        disableOutsidePointerEvents: !0,
        onCloseAutoFocus: P(e.onCloseAutoFocus, (a) => {
          (a.preventDefault(), r.triggerRef.current?.focus());
        }),
        onPointerDownOutside: P(e.onPointerDownOutside, (a) => {
          const c = a.detail.originalEvent,
            s = c.button === 0 && c.ctrlKey === !0;
          (c.button === 2 || s) && a.preventDefault();
        }),
        onFocusOutside: P(e.onFocusOutside, (a) => a.preventDefault()),
      })
    );
  }),
  $n = i.forwardRef((e, t) => {
    const r = L(U, e.__scopeDialog),
      n = i.useRef(!1),
      o = i.useRef(!1);
    return v.jsx(Et, {
      ...e,
      ref: t,
      trapFocus: !1,
      disableOutsidePointerEvents: !1,
      onCloseAutoFocus: (a) => {
        (e.onCloseAutoFocus?.(a),
          a.defaultPrevented ||
            (n.current || r.triggerRef.current?.focus(), a.preventDefault()),
          (n.current = !1),
          (o.current = !1));
      },
      onInteractOutside: (a) => {
        (e.onInteractOutside?.(a),
          a.defaultPrevented ||
            ((n.current = !0),
            a.detail.originalEvent.type === "pointerdown" && (o.current = !0)));
        const c = a.target;
        (r.triggerRef.current?.contains(c) && a.preventDefault(),
          a.detail.originalEvent.type === "focusin" &&
            o.current &&
            a.preventDefault());
      },
    });
  }),
  Et = i.forwardRef((e, t) => {
    const {
        __scopeDialog: r,
        trapFocus: n,
        onOpenAutoFocus: o,
        onCloseAutoFocus: a,
        ...c
      } = e,
      s = L(U, r),
      l = i.useRef(null),
      u = D(t, l);
    return (
      Kr(),
      v.jsxs(v.Fragment, {
        children: [
          v.jsx(et, {
            asChild: !0,
            loop: !0,
            trapped: n,
            onMountAutoFocus: o,
            onUnmountAutoFocus: a,
            children: v.jsx(Qe, {
              role: "dialog",
              id: s.contentId,
              "aria-describedby": s.descriptionId,
              "aria-labelledby": s.titleId,
              "data-state": Ae(s.open),
              ...c,
              ref: u,
              onDismiss: () => s.onOpenChange(!1),
            }),
          }),
          v.jsxs(v.Fragment, {
            children: [
              v.jsx(Hn, { titleId: s.titleId }),
              v.jsx(Vn, { contentRef: l, descriptionId: s.descriptionId }),
            ],
          }),
        ],
      })
    );
  }),
  Pe = "DialogTitle",
  Ct = i.forwardRef((e, t) => {
    const { __scopeDialog: r, ...n } = e,
      o = L(Pe, r);
    return v.jsx(T.h2, { id: o.titleId, ...n, ref: t });
  });
Ct.displayName = Pe;
var wt = "DialogDescription",
  xt = i.forwardRef((e, t) => {
    const { __scopeDialog: r, ...n } = e,
      o = L(wt, r);
    return v.jsx(T.p, { id: o.descriptionId, ...n, ref: t });
  });
xt.displayName = wt;
var Rt = "DialogClose",
  Pt = i.forwardRef((e, t) => {
    const { __scopeDialog: r, ...n } = e,
      o = L(Rt, r);
    return v.jsx(T.button, {
      type: "button",
      ...n,
      ref: t,
      onClick: P(e.onClick, () => o.onOpenChange(!1)),
    });
  });
Pt.displayName = Rt;
function Ae(e) {
  return e ? "open" : "closed";
}
var At = "DialogTitleWarning",
  [Un, Dt] = hr(At, { contentName: U, titleName: Pe, docsSlug: "dialog" }),
  Hn = ({ titleId: e }) => {
    const t = Dt(At),
      r = `\`${t.contentName}\` requires a \`${t.titleName}\` for the component to be accessible for screen reader users.

If you want to hide the \`${t.titleName}\`, you can wrap it with our VisuallyHidden component.

For more information, see https://radix-ui.com/primitives/docs/components/${t.docsSlug}`;
    return (
      i.useEffect(() => {
        e && (document.getElementById(e) || console.error(r));
      }, [r, e]),
      null
    );
  },
  zn = "DialogDescriptionWarning",
  Vn = ({ contentRef: e, descriptionId: t }) => {
    const n = `Warning: Missing \`Description\` or \`aria-describedby={undefined}\` for {${Dt(zn).contentName}}.`;
    return (
      i.useEffect(() => {
        const o = e.current?.getAttribute("aria-describedby");
        t && o && (document.getElementById(t) || console.warn(n));
      }, [n, e, t]),
      null
    );
  },
  Yn = pt,
  Xn = mt,
  Kn = bt,
  Gn = yt,
  qn = St,
  Zn = Ct,
  Qn = xt,
  Tt = Pt,
  Nt = "AlertDialog",
  [Jn] = se(Nt, [vt]),
  F = vt(),
  _t = (e) => {
    const { __scopeAlertDialog: t, ...r } = e,
      n = F(t);
    return v.jsx(Yn, { ...n, ...r, modal: !0 });
  };
_t.displayName = Nt;
var eo = "AlertDialogTrigger",
  to = i.forwardRef((e, t) => {
    const { __scopeAlertDialog: r, ...n } = e,
      o = F(r);
    return v.jsx(Xn, { ...o, ...n, ref: t });
  });
to.displayName = eo;
var ro = "AlertDialogPortal",
  Ot = (e) => {
    const { __scopeAlertDialog: t, ...r } = e,
      n = F(t);
    return v.jsx(Kn, { ...n, ...r });
  };
Ot.displayName = ro;
var no = "AlertDialogOverlay",
  It = i.forwardRef((e, t) => {
    const { __scopeAlertDialog: r, ...n } = e,
      o = F(r);
    return v.jsx(Gn, { ...o, ...n, ref: t });
  });
It.displayName = no;
var K = "AlertDialogContent",
  [oo, ao] = Jn(K),
  io = wr("AlertDialogContent"),
  Lt = i.forwardRef((e, t) => {
    const { __scopeAlertDialog: r, children: n, ...o } = e,
      a = F(r),
      c = i.useRef(null),
      s = D(t, c),
      l = i.useRef(null);
    return v.jsx(Un, {
      contentName: K,
      titleName: Mt,
      docsSlug: "alert-dialog",
      children: v.jsx(oo, {
        scope: r,
        cancelRef: l,
        children: v.jsxs(qn, {
          role: "alertdialog",
          ...a,
          ...o,
          ref: s,
          onOpenAutoFocus: P(o.onOpenAutoFocus, (u) => {
            (u.preventDefault(), l.current?.focus({ preventScroll: !0 }));
          }),
          onPointerDownOutside: (u) => u.preventDefault(),
          onInteractOutside: (u) => u.preventDefault(),
          children: [v.jsx(io, { children: n }), v.jsx(co, { contentRef: c })],
        }),
      }),
    });
  });
Lt.displayName = K;
var Mt = "AlertDialogTitle",
  kt = i.forwardRef((e, t) => {
    const { __scopeAlertDialog: r, ...n } = e,
      o = F(r);
    return v.jsx(Zn, { ...o, ...n, ref: t });
  });
kt.displayName = Mt;
var jt = "AlertDialogDescription",
  Ft = i.forwardRef((e, t) => {
    const { __scopeAlertDialog: r, ...n } = e,
      o = F(r);
    return v.jsx(Qn, { ...o, ...n, ref: t });
  });
Ft.displayName = jt;
var so = "AlertDialogAction",
  Wt = i.forwardRef((e, t) => {
    const { __scopeAlertDialog: r, ...n } = e,
      o = F(r);
    return v.jsx(Tt, { ...o, ...n, ref: t });
  });
Wt.displayName = so;
var Bt = "AlertDialogCancel",
  $t = i.forwardRef((e, t) => {
    const { __scopeAlertDialog: r, ...n } = e,
      { cancelRef: o } = ao(Bt, r),
      a = F(r),
      c = D(t, o);
    return v.jsx(Tt, { ...a, ...n, ref: c });
  });
$t.displayName = Bt;
var co = ({ contentRef: e }) => {
    const t = `\`${K}\` requires a description for the component to be accessible for screen reader users.

You can add a description to the \`${K}\` by passing a \`${jt}\` component as a child, which also benefits sighted users by adding visible context to the dialog.

Alternatively, you can use your own component as a description by assigning it an \`id\` and passing the same value to the \`aria-describedby\` prop in \`${K}\`. If the description is confusing or duplicative for sighted users, you can use the \`@radix-ui/react-visually-hidden\` primitive as a wrapper around your description component.

For more information, see https://radix-ui.com/primitives/docs/components/alert-dialog`;
    return (
      i.useEffect(() => {
        document.getElementById(e.current?.getAttribute("aria-describedby")) ||
          console.warn(t);
      }, [t, e]),
      null
    );
  },
  Bo = _t,
  $o = Ot,
  Uo = It,
  Ho = Lt,
  zo = Wt,
  Vo = $t,
  Yo = kt,
  Xo = Ft,
  lo = i.createContext(void 0);
function uo(e) {
  const t = i.useContext(lo);
  return e || t || "ltr";
}
function fo(e, [t, r]) {
  return Math.min(r, Math.max(t, e));
}
function vo(e, t) {
  return i.useReducer((r, n) => t[r][n] ?? r, e);
}
var De = "ScrollArea",
  [Ut] = se(De),
  [po, I] = Ut(De),
  Ht = i.forwardRef((e, t) => {
    const {
        __scopeScrollArea: r,
        type: n = "hover",
        dir: o,
        scrollHideDelay: a = 600,
        ...c
      } = e,
      [s, l] = i.useState(null),
      [u, d] = i.useState(null),
      [f, p] = i.useState(null),
      [m, S] = i.useState(null),
      [h, b] = i.useState(null),
      [g, y] = i.useState(0),
      [w, C] = i.useState(0),
      [x, A] = i.useState(!1),
      [E, _] = i.useState(!1),
      R = D(t, (H) => l(H)),
      N = uo(o);
    return v.jsx(po, {
      scope: r,
      type: n,
      dir: N,
      scrollHideDelay: a,
      scrollArea: s,
      viewport: u,
      onViewportChange: d,
      content: f,
      onContentChange: p,
      scrollbarX: m,
      onScrollbarXChange: S,
      scrollbarXEnabled: x,
      onScrollbarXEnabledChange: A,
      scrollbarY: h,
      onScrollbarYChange: b,
      scrollbarYEnabled: E,
      onScrollbarYEnabledChange: _,
      onCornerWidthChange: y,
      onCornerHeightChange: C,
      children: v.jsx(T.div, {
        dir: N,
        ...c,
        ref: R,
        style: {
          position: "relative",
          "--radix-scroll-area-corner-width": g + "px",
          "--radix-scroll-area-corner-height": w + "px",
          ...e.style,
        },
      }),
    });
  });
Ht.displayName = De;
var zt = "ScrollAreaViewport",
  Vt = i.forwardRef((e, t) => {
    const { __scopeScrollArea: r, children: n, nonce: o, ...a } = e,
      c = I(zt, r),
      s = i.useRef(null),
      l = D(t, s, c.onViewportChange);
    return v.jsxs(v.Fragment, {
      children: [
        v.jsx("style", {
          dangerouslySetInnerHTML: {
            __html:
              "[data-radix-scroll-area-viewport]{scrollbar-width:none;-ms-overflow-style:none;-webkit-overflow-scrolling:touch;}[data-radix-scroll-area-viewport]::-webkit-scrollbar{display:none}",
          },
          nonce: o,
        }),
        v.jsx(T.div, {
          "data-radix-scroll-area-viewport": "",
          ...a,
          ref: l,
          style: {
            overflowX: c.scrollbarXEnabled ? "scroll" : "hidden",
            overflowY: c.scrollbarYEnabled ? "scroll" : "hidden",
            ...e.style,
          },
          children: v.jsx("div", {
            ref: c.onContentChange,
            style: { minWidth: "100%", display: "table" },
            children: n,
          }),
        }),
      ],
    });
  });
Vt.displayName = zt;
var k = "ScrollAreaScrollbar",
  ho = i.forwardRef((e, t) => {
    const { forceMount: r, ...n } = e,
      o = I(k, e.__scopeScrollArea),
      { onScrollbarXEnabledChange: a, onScrollbarYEnabledChange: c } = o,
      s = e.orientation === "horizontal";
    return (
      i.useEffect(
        () => (
          s ? a(!0) : c(!0),
          () => {
            s ? a(!1) : c(!1);
          }
        ),
        [s, a, c],
      ),
      o.type === "hover"
        ? v.jsx(mo, { ...n, ref: t, forceMount: r })
        : o.type === "scroll"
          ? v.jsx(go, { ...n, ref: t, forceMount: r })
          : o.type === "auto"
            ? v.jsx(Yt, { ...n, ref: t, forceMount: r })
            : o.type === "always"
              ? v.jsx(Te, { ...n, ref: t })
              : null
    );
  });
ho.displayName = k;
var mo = i.forwardRef((e, t) => {
    const { forceMount: r, ...n } = e,
      o = I(k, e.__scopeScrollArea),
      [a, c] = i.useState(!1);
    return (
      i.useEffect(() => {
        const s = o.scrollArea;
        let l = 0;
        if (s) {
          const u = () => {
              (window.clearTimeout(l), c(!0));
            },
            d = () => {
              l = window.setTimeout(() => c(!1), o.scrollHideDelay);
            };
          return (
            s.addEventListener("pointerenter", u),
            s.addEventListener("pointerleave", d),
            () => {
              (window.clearTimeout(l),
                s.removeEventListener("pointerenter", u),
                s.removeEventListener("pointerleave", d));
            }
          );
        }
      }, [o.scrollArea, o.scrollHideDelay]),
      v.jsx(j, {
        present: r || a,
        children: v.jsx(Yt, {
          "data-state": a ? "visible" : "hidden",
          ...n,
          ref: t,
        }),
      })
    );
  }),
  go = i.forwardRef((e, t) => {
    const { forceMount: r, ...n } = e,
      o = I(k, e.__scopeScrollArea),
      a = e.orientation === "horizontal",
      c = de(() => l("SCROLL_END"), 100),
      [s, l] = vo("hidden", {
        hidden: { SCROLL: "scrolling" },
        scrolling: { SCROLL_END: "idle", POINTER_ENTER: "interacting" },
        interacting: { SCROLL: "interacting", POINTER_LEAVE: "idle" },
        idle: {
          HIDE: "hidden",
          SCROLL: "scrolling",
          POINTER_ENTER: "interacting",
        },
      });
    return (
      i.useEffect(() => {
        if (s === "idle") {
          const u = window.setTimeout(() => l("HIDE"), o.scrollHideDelay);
          return () => window.clearTimeout(u);
        }
      }, [s, o.scrollHideDelay, l]),
      i.useEffect(() => {
        const u = o.viewport,
          d = a ? "scrollLeft" : "scrollTop";
        if (u) {
          let f = u[d];
          const p = () => {
            const m = u[d];
            (f !== m && (l("SCROLL"), c()), (f = m));
          };
          return (
            u.addEventListener("scroll", p),
            () => u.removeEventListener("scroll", p)
          );
        }
      }, [o.viewport, a, l, c]),
      v.jsx(j, {
        present: r || s !== "hidden",
        children: v.jsx(Te, {
          "data-state": s === "hidden" ? "hidden" : "visible",
          ...n,
          ref: t,
          onPointerEnter: P(e.onPointerEnter, () => l("POINTER_ENTER")),
          onPointerLeave: P(e.onPointerLeave, () => l("POINTER_LEAVE")),
        }),
      })
    );
  }),
  Yt = i.forwardRef((e, t) => {
    const r = I(k, e.__scopeScrollArea),
      { forceMount: n, ...o } = e,
      [a, c] = i.useState(!1),
      s = e.orientation === "horizontal",
      l = de(() => {
        if (r.viewport) {
          const u = r.viewport.offsetWidth < r.viewport.scrollWidth,
            d = r.viewport.offsetHeight < r.viewport.scrollHeight;
          c(s ? u : d);
        }
      }, 10);
    return (
      G(r.viewport, l),
      G(r.content, l),
      v.jsx(j, {
        present: n || a,
        children: v.jsx(Te, {
          "data-state": a ? "visible" : "hidden",
          ...o,
          ref: t,
        }),
      })
    );
  }),
  Te = i.forwardRef((e, t) => {
    const { orientation: r = "vertical", ...n } = e,
      o = I(k, e.__scopeScrollArea),
      a = i.useRef(null),
      c = i.useRef(0),
      [s, l] = i.useState({
        content: 0,
        viewport: 0,
        scrollbar: { size: 0, paddingStart: 0, paddingEnd: 0 },
      }),
      u = qt(s.viewport, s.content),
      d = {
        ...n,
        sizes: s,
        onSizesChange: l,
        hasThumb: u > 0 && u < 1,
        onThumbChange: (p) => (a.current = p),
        onThumbPointerUp: () => (c.current = 0),
        onThumbPointerDown: (p) => (c.current = p),
      };
    function f(p, m) {
      return xo(p, c.current, s, m);
    }
    return r === "horizontal"
      ? v.jsx(bo, {
          ...d,
          ref: t,
          onThumbPositionChange: () => {
            if (o.viewport && a.current) {
              const p = o.viewport.scrollLeft,
                m = Ve(p, s, o.dir);
              a.current.style.transform = `translate3d(${m}px, 0, 0)`;
            }
          },
          onWheelScroll: (p) => {
            o.viewport && (o.viewport.scrollLeft = p);
          },
          onDragScroll: (p) => {
            o.viewport && (o.viewport.scrollLeft = f(p, o.dir));
          },
        })
      : r === "vertical"
        ? v.jsx(yo, {
            ...d,
            ref: t,
            onThumbPositionChange: () => {
              if (o.viewport && a.current) {
                const p = o.viewport.scrollTop,
                  m = Ve(p, s);
                a.current.style.transform = `translate3d(0, ${m}px, 0)`;
              }
            },
            onWheelScroll: (p) => {
              o.viewport && (o.viewport.scrollTop = p);
            },
            onDragScroll: (p) => {
              o.viewport && (o.viewport.scrollTop = f(p));
            },
          })
        : null;
  }),
  bo = i.forwardRef((e, t) => {
    const { sizes: r, onSizesChange: n, ...o } = e,
      a = I(k, e.__scopeScrollArea),
      [c, s] = i.useState(),
      l = i.useRef(null),
      u = D(t, l, a.onScrollbarXChange);
    return (
      i.useEffect(() => {
        l.current && s(getComputedStyle(l.current));
      }, [l]),
      v.jsx(Kt, {
        "data-orientation": "horizontal",
        ...o,
        ref: u,
        sizes: r,
        style: {
          bottom: 0,
          left: a.dir === "rtl" ? "var(--radix-scroll-area-corner-width)" : 0,
          right: a.dir === "ltr" ? "var(--radix-scroll-area-corner-width)" : 0,
          "--radix-scroll-area-thumb-width": ue(r) + "px",
          ...e.style,
        },
        onThumbPointerDown: (d) => e.onThumbPointerDown(d.x),
        onDragScroll: (d) => e.onDragScroll(d.x),
        onWheelScroll: (d, f) => {
          if (a.viewport) {
            const p = a.viewport.scrollLeft + d.deltaX;
            (e.onWheelScroll(p), Qt(p, f) && d.preventDefault());
          }
        },
        onResize: () => {
          l.current &&
            a.viewport &&
            c &&
            n({
              content: a.viewport.scrollWidth,
              viewport: a.viewport.offsetWidth,
              scrollbar: {
                size: l.current.clientWidth,
                paddingStart: ie(c.paddingLeft),
                paddingEnd: ie(c.paddingRight),
              },
            });
        },
      })
    );
  }),
  yo = i.forwardRef((e, t) => {
    const { sizes: r, onSizesChange: n, ...o } = e,
      a = I(k, e.__scopeScrollArea),
      [c, s] = i.useState(),
      l = i.useRef(null),
      u = D(t, l, a.onScrollbarYChange);
    return (
      i.useEffect(() => {
        l.current && s(getComputedStyle(l.current));
      }, [l]),
      v.jsx(Kt, {
        "data-orientation": "vertical",
        ...o,
        ref: u,
        sizes: r,
        style: {
          top: 0,
          right: a.dir === "ltr" ? 0 : void 0,
          left: a.dir === "rtl" ? 0 : void 0,
          bottom: "var(--radix-scroll-area-corner-height)",
          "--radix-scroll-area-thumb-height": ue(r) + "px",
          ...e.style,
        },
        onThumbPointerDown: (d) => e.onThumbPointerDown(d.y),
        onDragScroll: (d) => e.onDragScroll(d.y),
        onWheelScroll: (d, f) => {
          if (a.viewport) {
            const p = a.viewport.scrollTop + d.deltaY;
            (e.onWheelScroll(p), Qt(p, f) && d.preventDefault());
          }
        },
        onResize: () => {
          l.current &&
            a.viewport &&
            c &&
            n({
              content: a.viewport.scrollHeight,
              viewport: a.viewport.offsetHeight,
              scrollbar: {
                size: l.current.clientHeight,
                paddingStart: ie(c.paddingTop),
                paddingEnd: ie(c.paddingBottom),
              },
            });
        },
      })
    );
  }),
  [So, Xt] = Ut(k),
  Kt = i.forwardRef((e, t) => {
    const {
        __scopeScrollArea: r,
        sizes: n,
        hasThumb: o,
        onThumbChange: a,
        onThumbPointerUp: c,
        onThumbPointerDown: s,
        onThumbPositionChange: l,
        onDragScroll: u,
        onWheelScroll: d,
        onResize: f,
        ...p
      } = e,
      m = I(k, r),
      [S, h] = i.useState(null),
      b = D(t, (R) => h(R)),
      g = i.useRef(null),
      y = i.useRef(""),
      w = m.viewport,
      C = n.content - n.viewport,
      x = O(d),
      A = O(l),
      E = de(f, 10);
    function _(R) {
      if (g.current) {
        const N = R.clientX - g.current.left,
          H = R.clientY - g.current.top;
        u({ x: N, y: H });
      }
    }
    return (
      i.useEffect(() => {
        const R = (N) => {
          const H = N.target;
          S?.contains(H) && x(N, C);
        };
        return (
          document.addEventListener("wheel", R, { passive: !1 }),
          () => document.removeEventListener("wheel", R, { passive: !1 })
        );
      }, [w, S, C, x]),
      i.useEffect(A, [n, A]),
      G(S, E),
      G(m.content, E),
      v.jsx(So, {
        scope: r,
        scrollbar: S,
        hasThumb: o,
        onThumbChange: O(a),
        onThumbPointerUp: O(c),
        onThumbPositionChange: A,
        onThumbPointerDown: O(s),
        children: v.jsx(T.div, {
          ...p,
          ref: b,
          style: { position: "absolute", ...p.style },
          onPointerDown: P(e.onPointerDown, (R) => {
            R.button === 0 &&
              (R.target.setPointerCapture(R.pointerId),
              (g.current = S.getBoundingClientRect()),
              (y.current = document.body.style.webkitUserSelect),
              (document.body.style.webkitUserSelect = "none"),
              m.viewport && (m.viewport.style.scrollBehavior = "auto"),
              _(R));
          }),
          onPointerMove: P(e.onPointerMove, _),
          onPointerUp: P(e.onPointerUp, (R) => {
            const N = R.target;
            (N.hasPointerCapture(R.pointerId) &&
              N.releasePointerCapture(R.pointerId),
              (document.body.style.webkitUserSelect = y.current),
              m.viewport && (m.viewport.style.scrollBehavior = ""),
              (g.current = null));
          }),
        }),
      })
    );
  }),
  ae = "ScrollAreaThumb",
  Eo = i.forwardRef((e, t) => {
    const { forceMount: r, ...n } = e,
      o = Xt(ae, e.__scopeScrollArea);
    return v.jsx(j, {
      present: r || o.hasThumb,
      children: v.jsx(Co, { ref: t, ...n }),
    });
  }),
  Co = i.forwardRef((e, t) => {
    const { __scopeScrollArea: r, style: n, ...o } = e,
      a = I(ae, r),
      c = Xt(ae, r),
      { onThumbPositionChange: s } = c,
      l = D(t, (f) => c.onThumbChange(f)),
      u = i.useRef(void 0),
      d = de(() => {
        u.current && (u.current(), (u.current = void 0));
      }, 100);
    return (
      i.useEffect(() => {
        const f = a.viewport;
        if (f) {
          const p = () => {
            if ((d(), !u.current)) {
              const m = Ro(f, s);
              ((u.current = m), s());
            }
          };
          return (
            s(),
            f.addEventListener("scroll", p),
            () => f.removeEventListener("scroll", p)
          );
        }
      }, [a.viewport, d, s]),
      v.jsx(T.div, {
        "data-state": c.hasThumb ? "visible" : "hidden",
        ...o,
        ref: l,
        style: {
          width: "var(--radix-scroll-area-thumb-width)",
          height: "var(--radix-scroll-area-thumb-height)",
          ...n,
        },
        onPointerDownCapture: P(e.onPointerDownCapture, (f) => {
          const m = f.target.getBoundingClientRect(),
            S = f.clientX - m.left,
            h = f.clientY - m.top;
          c.onThumbPointerDown({ x: S, y: h });
        }),
        onPointerUp: P(e.onPointerUp, c.onThumbPointerUp),
      })
    );
  });
Eo.displayName = ae;
var Ne = "ScrollAreaCorner",
  Gt = i.forwardRef((e, t) => {
    const r = I(Ne, e.__scopeScrollArea),
      n = !!(r.scrollbarX && r.scrollbarY);
    return r.type !== "scroll" && n ? v.jsx(wo, { ...e, ref: t }) : null;
  });
Gt.displayName = Ne;
var wo = i.forwardRef((e, t) => {
  const { __scopeScrollArea: r, ...n } = e,
    o = I(Ne, r),
    [a, c] = i.useState(0),
    [s, l] = i.useState(0),
    u = !!(a && s);
  return (
    G(o.scrollbarX, () => {
      const d = o.scrollbarX?.offsetHeight || 0;
      (o.onCornerHeightChange(d), l(d));
    }),
    G(o.scrollbarY, () => {
      const d = o.scrollbarY?.offsetWidth || 0;
      (o.onCornerWidthChange(d), c(d));
    }),
    u
      ? v.jsx(T.div, {
          ...n,
          ref: t,
          style: {
            width: a,
            height: s,
            position: "absolute",
            right: o.dir === "ltr" ? 0 : void 0,
            left: o.dir === "rtl" ? 0 : void 0,
            bottom: 0,
            ...e.style,
          },
        })
      : null
  );
});
function ie(e) {
  return e ? parseInt(e, 10) : 0;
}
function qt(e, t) {
  const r = e / t;
  return isNaN(r) ? 0 : r;
}
function ue(e) {
  const t = qt(e.viewport, e.content),
    r = e.scrollbar.paddingStart + e.scrollbar.paddingEnd,
    n = (e.scrollbar.size - r) * t;
  return Math.max(n, 18);
}
function xo(e, t, r, n = "ltr") {
  const o = ue(r),
    a = o / 2,
    c = t || a,
    s = o - c,
    l = r.scrollbar.paddingStart + c,
    u = r.scrollbar.size - r.scrollbar.paddingEnd - s,
    d = r.content - r.viewport,
    f = n === "ltr" ? [0, d] : [d * -1, 0];
  return Zt([l, u], f)(e);
}
function Ve(e, t, r = "ltr") {
  const n = ue(t),
    o = t.scrollbar.paddingStart + t.scrollbar.paddingEnd,
    a = t.scrollbar.size - o,
    c = t.content - t.viewport,
    s = a - n,
    l = r === "ltr" ? [0, c] : [c * -1, 0],
    u = fo(e, l);
  return Zt([0, c], [0, s])(u);
}
function Zt(e, t) {
  return (r) => {
    if (e[0] === e[1] || t[0] === t[1]) return t[0];
    const n = (t[1] - t[0]) / (e[1] - e[0]);
    return t[0] + n * (r - e[0]);
  };
}
function Qt(e, t) {
  return e > 0 && e < t;
}
var Ro = (e, t = () => {}) => {
  let r = { left: e.scrollLeft, top: e.scrollTop },
    n = 0;
  return (
    (function o() {
      const a = { left: e.scrollLeft, top: e.scrollTop },
        c = r.left !== a.left,
        s = r.top !== a.top;
      ((c || s) && t(), (r = a), (n = window.requestAnimationFrame(o)));
    })(),
    () => window.cancelAnimationFrame(n)
  );
};
function de(e, t) {
  const r = O(e),
    n = i.useRef(0);
  return (
    i.useEffect(() => () => window.clearTimeout(n.current), []),
    i.useCallback(() => {
      (window.clearTimeout(n.current), (n.current = window.setTimeout(r, t)));
    }, [r, t])
  );
}
function G(e, t) {
  const r = O(t);
  $(() => {
    let n = 0;
    if (e) {
      const o = new ResizeObserver(() => {
        (cancelAnimationFrame(n), (n = window.requestAnimationFrame(r)));
      });
      return (
        o.observe(e),
        () => {
          (window.cancelAnimationFrame(n), o.unobserve(e));
        }
      );
    }
  }, [e, r]);
}
var Ko = Ht,
  Go = Vt,
  qo = Gt,
  Po = [
    "a",
    "button",
    "div",
    "form",
    "h2",
    "h3",
    "img",
    "input",
    "label",
    "li",
    "nav",
    "ol",
    "p",
    "select",
    "span",
    "svg",
    "ul",
  ],
  Ao = Po.reduce((e, t) => {
    const r = Xe(`Primitive.${t}`),
      n = i.forwardRef((o, a) => {
        const { asChild: c, ...s } = o,
          l = c ? r : t;
        return (
          typeof window < "u" && (window[Symbol.for("radix-ui")] = !0),
          v.jsx(l, { ...s, ref: a })
        );
      });
    return ((n.displayName = `Primitive.${t}`), { ...e, [t]: n });
  }, {}),
  Do = "Label",
  Jt = i.forwardRef((e, t) =>
    v.jsx(Ao.label, {
      ...e,
      ref: t,
      onMouseDown: (r) => {
        r.target.closest("button, input, select, textarea") ||
          (e.onMouseDown?.(r),
          !r.defaultPrevented && r.detail > 1 && r.preventDefault());
      },
    }),
  );
Jt.displayName = Do;
var Zo = Jt;
function To(e) {
  const t = i.useRef({ value: e, previous: e });
  return i.useMemo(
    () => (
      t.current.value !== e &&
        ((t.current.previous = t.current.value), (t.current.value = e)),
      t.current.previous
    ),
    [e],
  );
}
function No(e) {
  const [t, r] = i.useState(void 0);
  return (
    $(() => {
      if (e) {
        r({ width: e.offsetWidth, height: e.offsetHeight });
        const n = new ResizeObserver((o) => {
          if (!Array.isArray(o) || !o.length) return;
          const a = o[0];
          let c, s;
          if ("borderBoxSize" in a) {
            const l = a.borderBoxSize,
              u = Array.isArray(l) ? l[0] : l;
            ((c = u.inlineSize), (s = u.blockSize));
          } else ((c = e.offsetWidth), (s = e.offsetHeight));
          r({ width: c, height: s });
        });
        return (n.observe(e, { box: "border-box" }), () => n.unobserve(e));
      } else r(void 0);
    }, [e]),
    t
  );
}
var fe = "Checkbox",
  [_o] = se(fe),
  [Oo, _e] = _o(fe);
function Io(e) {
  const {
      __scopeCheckbox: t,
      checked: r,
      children: n,
      defaultChecked: o,
      disabled: a,
      form: c,
      name: s,
      onCheckedChange: l,
      required: u,
      value: d = "on",
      internal_do_not_use_render: f,
    } = e,
    [p, m] = Ke({ prop: r, defaultProp: o ?? !1, onChange: l, caller: fe }),
    [S, h] = i.useState(null),
    [b, g] = i.useState(null),
    y = i.useRef(!1),
    w = S ? !!c || !!S.closest("form") : !0,
    C = {
      checked: p,
      disabled: a,
      setChecked: m,
      control: S,
      setControl: h,
      name: s,
      form: c,
      value: d,
      hasConsumerStoppedPropagationRef: y,
      required: u,
      defaultChecked: B(o) ? !1 : o,
      isFormControl: w,
      bubbleInput: b,
      setBubbleInput: g,
    };
  return v.jsx(Oo, { scope: t, ...C, children: ko(f) ? f(C) : n });
}
var er = "CheckboxTrigger",
  tr = i.forwardRef(
    ({ __scopeCheckbox: e, onKeyDown: t, onClick: r, ...n }, o) => {
      const {
          control: a,
          value: c,
          disabled: s,
          checked: l,
          required: u,
          setControl: d,
          setChecked: f,
          hasConsumerStoppedPropagationRef: p,
          isFormControl: m,
          bubbleInput: S,
        } = _e(er, e),
        h = D(o, d),
        b = i.useRef(l);
      return (
        i.useEffect(() => {
          const g = a?.form;
          if (g) {
            const y = () => f(b.current);
            return (
              g.addEventListener("reset", y),
              () => g.removeEventListener("reset", y)
            );
          }
        }, [a, f]),
        v.jsx(T.button, {
          type: "button",
          role: "checkbox",
          "aria-checked": B(l) ? "mixed" : l,
          "aria-required": u,
          "data-state": ar(l),
          "data-disabled": s ? "" : void 0,
          disabled: s,
          value: c,
          ...n,
          ref: h,
          onKeyDown: P(t, (g) => {
            g.key === "Enter" && g.preventDefault();
          }),
          onClick: P(r, (g) => {
            (f((y) => (B(y) ? !0 : !y)),
              S &&
                m &&
                ((p.current = g.isPropagationStopped()),
                p.current || g.stopPropagation()));
          }),
        })
      );
    },
  );
tr.displayName = er;
var Lo = i.forwardRef((e, t) => {
  const {
    __scopeCheckbox: r,
    name: n,
    checked: o,
    defaultChecked: a,
    required: c,
    disabled: s,
    value: l,
    onCheckedChange: u,
    form: d,
    ...f
  } = e;
  return v.jsx(Io, {
    __scopeCheckbox: r,
    checked: o,
    defaultChecked: a,
    disabled: s,
    required: c,
    onCheckedChange: u,
    name: n,
    form: d,
    value: l,
    internal_do_not_use_render: ({ isFormControl: p }) =>
      v.jsxs(v.Fragment, {
        children: [
          v.jsx(tr, { ...f, ref: t, __scopeCheckbox: r }),
          p && v.jsx(or, { __scopeCheckbox: r }),
        ],
      }),
  });
});
Lo.displayName = fe;
var rr = "CheckboxIndicator",
  Mo = i.forwardRef((e, t) => {
    const { __scopeCheckbox: r, forceMount: n, ...o } = e,
      a = _e(rr, r);
    return v.jsx(j, {
      present: n || B(a.checked) || a.checked === !0,
      children: v.jsx(T.span, {
        "data-state": ar(a.checked),
        "data-disabled": a.disabled ? "" : void 0,
        ...o,
        ref: t,
        style: { pointerEvents: "none", ...e.style },
      }),
    });
  });
Mo.displayName = rr;
var nr = "CheckboxBubbleInput",
  or = i.forwardRef(({ __scopeCheckbox: e, ...t }, r) => {
    const {
        control: n,
        hasConsumerStoppedPropagationRef: o,
        checked: a,
        defaultChecked: c,
        required: s,
        disabled: l,
        name: u,
        value: d,
        form: f,
        bubbleInput: p,
        setBubbleInput: m,
      } = _e(nr, e),
      S = D(r, m),
      h = To(a),
      b = No(n);
    i.useEffect(() => {
      const y = p;
      if (!y) return;
      const w = window.HTMLInputElement.prototype,
        x = Object.getOwnPropertyDescriptor(w, "checked").set,
        A = !o.current;
      if (h !== a && x) {
        const E = new Event("click", { bubbles: A });
        ((y.indeterminate = B(a)),
          x.call(y, B(a) ? !1 : a),
          y.dispatchEvent(E));
      }
    }, [p, h, a, o]);
    const g = i.useRef(B(a) ? !1 : a);
    return v.jsx(T.input, {
      type: "checkbox",
      "aria-hidden": !0,
      defaultChecked: c ?? g.current,
      required: s,
      disabled: l,
      name: u,
      value: d,
      form: f,
      ...t,
      tabIndex: -1,
      ref: S,
      style: {
        ...t.style,
        ...b,
        position: "absolute",
        pointerEvents: "none",
        opacity: 0,
        margin: 0,
        transform: "translateX(-100%)",
      },
    });
  });
or.displayName = nr;
function ko(e) {
  return typeof e == "function";
}
function B(e) {
  return e === "indeterminate";
}
function ar(e) {
  return B(e) ? "indeterminate" : e ? "checked" : "unchecked";
}
export {
  zo as A,
  Ho as C,
  Xo as D,
  Uo as O,
  $o as P,
  Bo as R,
  Wo as S,
  Yo as T,
  Go as V,
  Vo as a,
  Ko as b,
  qo as c,
  ho as d,
  Eo as e,
  Kn as f,
  Gn as g,
  qn as h,
  Zn as i,
  Qn as j,
  Yn as k,
  Zo as l,
  Lo as m,
  Mo as n,
};
