import { c as La, g as tl } from "./index-CYincVF4.js";
var hn = {},
  fn = {},
  cr,
  cn;
function Q() {
  if (cn) return cr;
  cn = 1;
  var n = function (e) {
    return e && e.Math === Math && e;
  };
  return (
    (cr =
      n(typeof globalThis == "object" && globalThis) ||
      n(typeof window == "object" && window) ||
      n(typeof self == "object" && self) ||
      n(typeof La == "object" && La) ||
      n(typeof cr == "object" && cr) ||
      (function () {
        return this;
      })() ||
      Function("return this")()),
    cr
  );
}
var Jr = {},
  et,
  vn;
function Z() {
  return (
    vn ||
      ((vn = 1),
      (et = function (n) {
        try {
          return !!n();
        } catch {
          return !0;
        }
      })),
    et
  );
}
var rt, gn;
function we() {
  if (gn) return rt;
  gn = 1;
  var n = Z();
  return (
    (rt = !n(function () {
      return (
        Object.defineProperty({}, 1, {
          get: function () {
            return 7;
          },
        })[1] !== 7
      );
    })),
    rt
  );
}
var tt, dn;
function Ar() {
  if (dn) return tt;
  dn = 1;
  var n = Z();
  return (
    (tt = !n(function () {
      var e = function () {}.bind();
      return typeof e != "function" || e.hasOwnProperty("prototype");
    })),
    tt
  );
}
var it, pn;
function se() {
  if (pn) return it;
  pn = 1;
  var n = Ar(),
    e = Function.prototype.call;
  return (
    (it = n
      ? e.bind(e)
      : function () {
          return e.apply(e, arguments);
        }),
    it
  );
}
var at = {},
  yn;
function Yl() {
  if (yn) return at;
  yn = 1;
  var n = {}.propertyIsEnumerable,
    e = Object.getOwnPropertyDescriptor,
    r = e && !n.call({ 1: 2 }, 1);
  return (
    (at.f = r
      ? function (i) {
          var a = e(this, i);
          return !!a && a.enumerable;
        }
      : n),
    at
  );
}
var nt, mn;
function Ua() {
  return (
    mn ||
      ((mn = 1),
      (nt = function (n, e) {
        return {
          enumerable: !(n & 1),
          configurable: !(n & 2),
          writable: !(n & 4),
          value: e,
        };
      })),
    nt
  );
}
var st, bn;
function J() {
  if (bn) return st;
  bn = 1;
  var n = Ar(),
    e = Function.prototype,
    r = e.call,
    t = n && e.bind.bind(r, r);
  return (
    (st = n
      ? t
      : function (i) {
          return function () {
            return r.apply(i, arguments);
          };
        }),
    st
  );
}
var ot, xn;
function We() {
  if (xn) return ot;
  xn = 1;
  var n = J(),
    e = n({}.toString),
    r = n("".slice);
  return (
    (ot = function (t) {
      return r(e(t), 8, -1);
    }),
    ot
  );
}
var ut, On;
function il() {
  if (On) return ut;
  On = 1;
  var n = J(),
    e = Z(),
    r = We(),
    t = Object,
    i = n("".split);
  return (
    (ut = e(function () {
      return !t("z").propertyIsEnumerable(0);
    })
      ? function (a) {
          return r(a) === "String" ? i(a, "") : t(a);
        }
      : t),
    ut
  );
}
var lt, Tn;
function Ir() {
  return (
    Tn ||
      ((Tn = 1),
      (lt = function (n) {
        return n == null;
      })),
    lt
  );
}
var ht, Sn;
function Pe() {
  if (Sn) return ht;
  Sn = 1;
  var n = Ir(),
    e = TypeError;
  return (
    (ht = function (r) {
      if (n(r)) throw new e("Can't call method on " + r);
      return r;
    }),
    ht
  );
}
var ft, En;
function pr() {
  if (En) return ft;
  En = 1;
  var n = il(),
    e = Pe();
  return (
    (ft = function (r) {
      return n(e(r));
    }),
    ft
  );
}
var ct, Rn;
function ee() {
  if (Rn) return ct;
  Rn = 1;
  var n = typeof document == "object" && document.all;
  return (
    (ct =
      typeof n > "u" && n !== void 0
        ? function (e) {
            return typeof e == "function" || e === n;
          }
        : function (e) {
            return typeof e == "function";
          }),
    ct
  );
}
var vt, Cn;
function ye() {
  if (Cn) return vt;
  Cn = 1;
  var n = ee();
  return (
    (vt = function (e) {
      return typeof e == "object" ? e !== null : n(e);
    }),
    vt
  );
}
var gt, wn;
function rr() {
  if (wn) return gt;
  wn = 1;
  var n = Q(),
    e = ee(),
    r = function (t) {
      return e(t) ? t : void 0;
    };
  return (
    (gt = function (t, i) {
      return arguments.length < 2 ? r(n[t]) : n[t] && n[t][i];
    }),
    gt
  );
}
var dt, Pn;
function Nr() {
  if (Pn) return dt;
  Pn = 1;
  var n = J();
  return ((dt = n({}.isPrototypeOf)), dt);
}
var pt, An;
function yr() {
  if (An) return pt;
  An = 1;
  var n = Q(),
    e = n.navigator,
    r = e && e.userAgent;
  return ((pt = r ? String(r) : ""), pt);
}
var yt, In;
function Ga() {
  if (In) return yt;
  In = 1;
  var n = Q(),
    e = yr(),
    r = n.process,
    t = n.Deno,
    i = (r && r.versions) || (t && t.version),
    a = i && i.v8,
    s,
    o;
  return (
    a && ((s = a.split(".")), (o = s[0] > 0 && s[0] < 4 ? 1 : +(s[0] + s[1]))),
    !o &&
      e &&
      ((s = e.match(/Edge\/(\d+)/)),
      (!s || s[1] >= 74) && ((s = e.match(/Chrome\/(\d+)/)), s && (o = +s[1]))),
    (yt = o),
    yt
  );
}
var mt, Nn;
function al() {
  if (Nn) return mt;
  Nn = 1;
  var n = Ga(),
    e = Z(),
    r = Q(),
    t = r.String;
  return (
    (mt =
      !!Object.getOwnPropertySymbols &&
      !e(function () {
        var i = Symbol("symbol detection");
        return (
          !t(i) ||
          !(Object(i) instanceof Symbol) ||
          (!Symbol.sham && n && n < 41)
        );
      })),
    mt
  );
}
var bt, _n;
function nl() {
  if (_n) return bt;
  _n = 1;
  var n = al();
  return ((bt = n && !Symbol.sham && typeof Symbol.iterator == "symbol"), bt);
}
var xt, Mn;
function sl() {
  if (Mn) return xt;
  Mn = 1;
  var n = rr(),
    e = ee(),
    r = Nr(),
    t = nl(),
    i = Object;
  return (
    (xt = t
      ? function (a) {
          return typeof a == "symbol";
        }
      : function (a) {
          var s = n("Symbol");
          return e(s) && r(s.prototype, i(a));
        }),
    xt
  );
}
var Ot, qn;
function _r() {
  if (qn) return Ot;
  qn = 1;
  var n = String;
  return (
    (Ot = function (e) {
      try {
        return n(e);
      } catch {
        return "Object";
      }
    }),
    Ot
  );
}
var Tt, Dn;
function Ye() {
  if (Dn) return Tt;
  Dn = 1;
  var n = ee(),
    e = _r(),
    r = TypeError;
  return (
    (Tt = function (t) {
      if (n(t)) return t;
      throw new r(e(t) + " is not a function");
    }),
    Tt
  );
}
var St, Vn;
function nr() {
  if (Vn) return St;
  Vn = 1;
  var n = Ye(),
    e = Ir();
  return (
    (St = function (r, t) {
      var i = r[t];
      return e(i) ? void 0 : n(i);
    }),
    St
  );
}
var Et, Ln;
function Xl() {
  if (Ln) return Et;
  Ln = 1;
  var n = se(),
    e = ee(),
    r = ye(),
    t = TypeError;
  return (
    (Et = function (i, a) {
      var s, o;
      if (
        (a === "string" && e((s = i.toString)) && !r((o = n(s, i)))) ||
        (e((s = i.valueOf)) && !r((o = n(s, i)))) ||
        (a !== "string" && e((s = i.toString)) && !r((o = n(s, i))))
      )
        return o;
      throw new t("Can't convert object to primitive value");
    }),
    Et
  );
}
var Rt = { exports: {} },
  Ct,
  kn;
function Me() {
  return (kn || ((kn = 1), (Ct = !1)), Ct);
}
var wt, jn;
function $a() {
  if (jn) return wt;
  jn = 1;
  var n = Q(),
    e = Object.defineProperty;
  return (
    (wt = function (r, t) {
      try {
        e(n, r, { value: t, configurable: !0, writable: !0 });
      } catch {
        n[r] = t;
      }
      return t;
    }),
    wt
  );
}
var Bn;
function za() {
  if (Bn) return Rt.exports;
  Bn = 1;
  var n = Me(),
    e = Q(),
    r = $a(),
    t = "__core-js_shared__",
    i = (Rt.exports = e[t] || r(t, {}));
  return (
    (i.versions || (i.versions = [])).push({
      version: "3.50.0",
      mode: n ? "pure" : "global",
      copyright:
        "© 2013–2025 Denis Pushkarev (zloirock.ru), 2025–2026 CoreJS Company (core-js.io). All rights reserved.",
      license: "https://github.com/zloirock/core-js/blob/v3.50.0/LICENSE",
      source: "https://github.com/zloirock/core-js",
    }),
    Rt.exports
  );
}
var Pt, Fn;
function Ha() {
  if (Fn) return Pt;
  Fn = 1;
  var n = za(),
    e = Object.create || Object;
  return (
    (Pt = function (r, t) {
      return n[r] || (n[r] = t || e(null));
    }),
    Pt
  );
}
var At, Un;
function Mr() {
  if (Un) return At;
  Un = 1;
  var n = Pe(),
    e = Object;
  return (
    (At = function (r) {
      return e(n(r));
    }),
    At
  );
}
var It, Gn;
function Ae() {
  if (Gn) return It;
  Gn = 1;
  var n = J(),
    e = Mr(),
    r = n({}.hasOwnProperty);
  return (
    (It =
      Object.hasOwn ||
      function (i, a) {
        return r(e(i), a);
      }),
    It
  );
}
var Nt, $n;
function ol() {
  if ($n) return Nt;
  $n = 1;
  var n = J(),
    e = 0,
    r = Math.random(),
    t = n((1.1).toString);
  return (
    (Nt = function (i) {
      return "Symbol(" + (i === void 0 ? "" : i) + ")_" + t(++e + r, 36);
    }),
    Nt
  );
}
var _t, zn;
function ne() {
  if (zn) return _t;
  zn = 1;
  var n = Q(),
    e = Ha(),
    r = Ae(),
    t = ol(),
    i = al(),
    a = nl(),
    s = n.Symbol,
    o = e("wks"),
    u = a ? s.for || s : (s && s.withoutSetter) || t;
  return (
    (_t = function (l) {
      return (r(o, l) || (o[l] = i && r(s, l) ? s[l] : u("Symbol." + l)), o[l]);
    }),
    _t
  );
}
var Mt, Hn;
function Kl() {
  if (Hn) return Mt;
  Hn = 1;
  var n = se(),
    e = ye(),
    r = sl(),
    t = nr(),
    i = Xl(),
    a = ne(),
    s = TypeError,
    o = a("toPrimitive");
  return (
    (Mt = function (u, l) {
      if (!e(u) || r(u)) return u;
      var h = t(u, o),
        c;
      if (h) {
        if ((l === void 0 && (l = "default"), (c = n(h, u, l)), !e(c) || r(c)))
          return c;
        throw new s("Can't convert object to primitive value");
      }
      return (l === void 0 && (l = "number"), i(u, l));
    }),
    Mt
  );
}
var qt, Wn;
function ul() {
  if (Wn) return qt;
  Wn = 1;
  var n = Kl(),
    e = sl();
  return (
    (qt = function (r) {
      var t = n(r, "string");
      return e(t) ? t : t + "";
    }),
    qt
  );
}
var Dt, Yn;
function qr() {
  if (Yn) return Dt;
  Yn = 1;
  var n = Q(),
    e = ye(),
    r = n.document,
    t = e(r) && e(r.createElement);
  return (
    (Dt = function (i) {
      return t ? r.createElement(i) : {};
    }),
    Dt
  );
}
var Vt, Xn;
function ll() {
  if (Xn) return Vt;
  Xn = 1;
  var n = we(),
    e = Z(),
    r = qr();
  return (
    (Vt =
      !n &&
      !e(function () {
        return (
          Object.defineProperty(r("div"), "a", {
            get: function () {
              return 7;
            },
          }).a !== 7
        );
      })),
    Vt
  );
}
var Kn;
function Dr() {
  if (Kn) return Jr;
  Kn = 1;
  var n = we(),
    e = se(),
    r = Yl(),
    t = Ua(),
    i = pr(),
    a = ul(),
    s = Ae(),
    o = ll(),
    u = Object.getOwnPropertyDescriptor;
  return (
    (Jr.f = n
      ? u
      : function (h, c) {
          if (((h = i(h)), (c = a(c)), o))
            try {
              return u(h, c);
            } catch {}
          if (s(h, c)) return t(!e(r.f, h, c), h[c]);
        }),
    Jr
  );
}
var Lt = {},
  kt,
  Qn;
function hl() {
  if (Qn) return kt;
  Qn = 1;
  var n = we(),
    e = Z();
  return (
    (kt =
      n &&
      e(function () {
        return (
          Object.defineProperty(function () {}, "prototype", {
            value: 42,
            writable: !1,
          }).prototype !== 42
        );
      })),
    kt
  );
}
var jt, Zn;
function he() {
  if (Zn) return jt;
  Zn = 1;
  var n = ye(),
    e = String,
    r = TypeError;
  return (
    (jt = function (t) {
      if (n(t)) return t;
      throw new r(e(t) + " is not an object");
    }),
    jt
  );
}
var Jn;
function Xe() {
  if (Jn) return Lt;
  Jn = 1;
  var n = we(),
    e = ll(),
    r = hl(),
    t = he(),
    i = ul(),
    a = TypeError,
    s = Object.defineProperty,
    o = Object.getOwnPropertyDescriptor,
    u = "enumerable",
    l = "configurable",
    h = "writable";
  return (
    (Lt.f = n
      ? r
        ? function (v, f, g) {
            if (
              (t(v),
              (f = i(f)),
              t(g),
              typeof v == "function" &&
                f === "prototype" &&
                "value" in g &&
                h in g &&
                !g[h])
            ) {
              var d = o(v, f);
              d &&
                d[h] &&
                ((v[f] = g.value),
                (g = {
                  configurable: l in g ? g[l] : d[l],
                  enumerable: u in g ? g[u] : d[u],
                  writable: !1,
                }));
            }
            return s(v, f, g);
          }
        : s
      : function (v, f, g) {
          if ((t(v), (f = i(f)), t(g), e))
            try {
              return s(v, f, g);
            } catch {}
          if ("get" in g || "set" in g) throw new a("Accessors not supported");
          return ("value" in g && (v[f] = g.value), v);
        }),
    Lt
  );
}
var Bt, es;
function mr() {
  if (es) return Bt;
  es = 1;
  var n = we(),
    e = Xe(),
    r = Ua();
  return (
    (Bt = n
      ? function (t, i, a) {
          return e.f(t, i, r(1, a));
        }
      : function (t, i, a) {
          return ((t[i] = a), t);
        }),
    Bt
  );
}
var Ft = { exports: {} },
  Ut,
  rs;
function Vr() {
  if (rs) return Ut;
  rs = 1;
  var n = we(),
    e = Ae(),
    r = Function.prototype,
    t = n && Object.getOwnPropertyDescriptor,
    i = e(r, "name"),
    a = i && function () {}.name === "something",
    s = i && (!n || (n && t(r, "name").configurable));
  return ((Ut = { EXISTS: i, PROPER: a, CONFIGURABLE: s }), Ut);
}
var Gt, ts;
function Wa() {
  if (ts) return Gt;
  ts = 1;
  var n = J(),
    e = ee(),
    r = za(),
    t = n(Function.toString);
  return (
    e(r.inspectSource) ||
      (r.inspectSource = function (i) {
        return t(i);
      }),
    (Gt = r.inspectSource),
    Gt
  );
}
var $t, is;
function Ql() {
  if (is) return $t;
  is = 1;
  var n = Q(),
    e = ee(),
    r = n.WeakMap;
  return (($t = e(r) && /native code/.test(String(r))), $t);
}
var zt, as;
function Ya() {
  if (as) return zt;
  as = 1;
  var n = Ha(),
    e = ol(),
    r = n("keys");
  return (
    (zt = function (t) {
      return r[t] || (r[t] = e(t));
    }),
    zt
  );
}
var Ht, ns;
function Xa() {
  return (ns || ((ns = 1), (Ht = {})), Ht);
}
var Wt, ss;
function Lr() {
  if (ss) return Wt;
  ss = 1;
  var n = Ql(),
    e = Q(),
    r = ye(),
    t = mr(),
    i = Ae(),
    a = za(),
    s = Ya(),
    o = Xa(),
    u = "Object already initialized",
    l = e.TypeError,
    h = e.WeakMap,
    c,
    v,
    f,
    g = function (m) {
      return f(m) ? v(m) : c(m, {});
    },
    d = function (m) {
      return function (b) {
        var x;
        if (!r(b) || (x = v(b)).type !== m)
          throw new l("Incompatible receiver, " + m + " required");
        return x;
      };
    };
  if (n || a.state) {
    var p = a.state || (a.state = new h());
    ((p.get = p.get),
      (p.has = p.has),
      (p.set = p.set),
      (c = function (m, b) {
        if (p.has(m)) throw new l(u);
        return ((b.facade = m), p.set(m, b), b);
      }),
      (v = function (m) {
        return p.get(m) || {};
      }),
      (f = function (m) {
        return p.has(m);
      }));
  } else {
    var y = s("state");
    ((o[y] = !0),
      (c = function (m, b) {
        if (i(m, y)) throw new l(u);
        return ((b.facade = m), t(m, y, b), b);
      }),
      (v = function (m) {
        return i(m, y) ? m[y] : {};
      }),
      (f = function (m) {
        return i(m, y);
      }));
  }
  return ((Wt = { set: c, get: v, has: f, enforce: g, getterFor: d }), Wt);
}
var os;
function fl() {
  if (os) return Ft.exports;
  os = 1;
  var n = J(),
    e = Z(),
    r = ee(),
    t = Ae(),
    i = we(),
    a = Vr().CONFIGURABLE,
    s = Wa(),
    o = Lr(),
    u = o.enforce,
    l = o.get,
    h = String,
    c = Object.defineProperty,
    v = n("".slice),
    f = n("".replace),
    g = n([].join),
    d =
      i &&
      !e(function () {
        return c(function () {}, "length", { value: 8 }).length !== 8;
      }),
    p = String(String).split("String"),
    y = (Ft.exports = function (m, b, x) {
      (v(h(b), 0, 7) === "Symbol(" &&
        (b = "[" + f(h(b), /^Symbol\(([^)]*)\).*$/, "$1") + "]"),
        x && x.getter && (b = "get " + b),
        x && x.setter && (b = "set " + b),
        (!t(m, "name") || (a && m.name !== b)) &&
          (i ? c(m, "name", { value: b, configurable: !0 }) : (m.name = b)),
        d &&
          x &&
          t(x, "arity") &&
          m.length !== x.arity &&
          c(m, "length", { value: x.arity }));
      try {
        x && t(x, "constructor") && x.constructor
          ? i && c(m, "prototype", { writable: !1 })
          : m.prototype && (m.prototype = void 0);
      } catch {}
      var S = u(m);
      return (
        t(S, "source") || (S.source = g(p, typeof b == "string" ? b : "")),
        m
      );
    });
  return (
    (Function.prototype.toString = y(function () {
      return (r(this) && l(this).source) || s(this);
    }, "toString")),
    Ft.exports
  );
}
var Yt, us;
function tr() {
  if (us) return Yt;
  us = 1;
  var n = ee(),
    e = Xe(),
    r = fl(),
    t = $a();
  return (
    (Yt = function (i, a, s, o) {
      o || (o = {});
      var u = o.enumerable,
        l = o.name !== void 0 ? o.name : a;
      if ((n(s) && r(s, l, o), o.global)) u ? (i[a] = s) : t(a, s);
      else {
        try {
          o.unsafe ? i[a] && (u = !0) : delete i[a];
        } catch {}
        u
          ? (i[a] = s)
          : e.f(i, a, {
              value: s,
              enumerable: !1,
              configurable: !o.nonConfigurable,
              writable: !o.nonWritable,
            });
      }
      return i;
    }),
    Yt
  );
}
var Xt = {},
  Kt,
  ls;
function Zl() {
  if (ls) return Kt;
  ls = 1;
  var n = Math.ceil,
    e = Math.floor;
  return (
    (Kt =
      Math.trunc ||
      function (t) {
        var i = +t;
        return (i > 0 ? e : n)(i);
      }),
    Kt
  );
}
var Qt, hs;
function kr() {
  if (hs) return Qt;
  hs = 1;
  var n = Zl();
  return (
    (Qt = function (e) {
      var r = +e;
      return r !== r || r === 0 ? 0 : n(r);
    }),
    Qt
  );
}
var Zt, fs;
function Jl() {
  if (fs) return Zt;
  fs = 1;
  var n = kr(),
    e = Math.max,
    r = Math.min;
  return (
    (Zt = function (t, i) {
      var a = n(t);
      return a < 0 ? e(a + i, 0) : r(a, i);
    }),
    Zt
  );
}
var Jt, cs;
function sr() {
  if (cs) return Jt;
  cs = 1;
  var n = kr(),
    e = Math.min;
  return (
    (Jt = function (r) {
      var t = n(r);
      return t > 0 ? e(t, 9007199254740991) : 0;
    }),
    Jt
  );
}
var ei, vs;
function Ka() {
  if (vs) return ei;
  vs = 1;
  var n = sr();
  return (
    (ei = function (e) {
      return n(e.length);
    }),
    ei
  );
}
var ri, gs;
function cl() {
  if (gs) return ri;
  gs = 1;
  var n = pr(),
    e = Jl(),
    r = Ka(),
    t = function (i) {
      return function (a, s, o) {
        var u = n(a),
          l = r(u);
        if (l === 0) return !i && -1;
        var h = e(o, l),
          c;
        if (i && s !== s) {
          for (; l > h;) if (((c = u[h++]), c !== c)) return !0;
        } else
          for (; l > h; h++)
            if ((i || h in u) && u[h] === s) return i || h || 0;
        return !i && -1;
      };
    };
  return ((ri = { includes: t(!0), indexOf: t(!1) }), ri);
}
var ti, ds;
function vl() {
  if (ds) return ti;
  ds = 1;
  var n = J(),
    e = Ae(),
    r = pr(),
    t = cl().indexOf,
    i = Xa(),
    a = n([].push);
  return (
    (ti = function (s, o) {
      var u = r(s),
        l = 0,
        h = [],
        c;
      for (c in u) !e(i, c) && e(u, c) && a(h, c);
      for (; o.length > l;) e(u, (c = o[l++])) && (~t(h, c) || a(h, c));
      return h;
    }),
    ti
  );
}
var ii, ps;
function Qa() {
  return (
    ps ||
      ((ps = 1),
      (ii = [
        "constructor",
        "hasOwnProperty",
        "isPrototypeOf",
        "propertyIsEnumerable",
        "toLocaleString",
        "toString",
        "valueOf",
      ])),
    ii
  );
}
var ys;
function eh() {
  if (ys) return Xt;
  ys = 1;
  var n = vl(),
    e = Qa(),
    r = e.concat("length", "prototype");
  return (
    (Xt.f =
      Object.getOwnPropertyNames ||
      function (i) {
        return n(i, r);
      }),
    Xt
  );
}
var ai = {},
  ms;
function rh() {
  return (ms || ((ms = 1), (ai.f = Object.getOwnPropertySymbols)), ai);
}
var ni, bs;
function th() {
  if (bs) return ni;
  bs = 1;
  var n = rr(),
    e = J(),
    r = eh(),
    t = rh(),
    i = he(),
    a = e([].concat);
  return (
    (ni =
      n("Reflect", "ownKeys") ||
      function (o) {
        var u = r.f(i(o)),
          l = t.f;
        return l ? a(u, l(o)) : u;
      }),
    ni
  );
}
var si, xs;
function ih() {
  if (xs) return si;
  xs = 1;
  var n = Ae(),
    e = th(),
    r = Dr(),
    t = Xe();
  return (
    (si = function (i, a, s) {
      for (var o = e(a), u = t.f, l = r.f, h = 0; h < o.length; h++) {
        var c = o[h];
        !n(i, c) && !(s && n(s, c)) && u(i, c, l(a, c));
      }
    }),
    si
  );
}
var oi, Os;
function gl() {
  if (Os) return oi;
  Os = 1;
  var n = Z(),
    e = ee(),
    r = /#|\.prototype\./,
    t = function (u, l) {
      var h = a[i(u)];
      return h === o ? !0 : h === s ? !1 : e(l) ? n(l) : !!l;
    },
    i = (t.normalize = function (u) {
      return String(u).replace(r, ".").toLowerCase();
    }),
    a = (t.data = {}),
    s = (t.NATIVE = "N"),
    o = (t.POLYFILL = "P");
  return ((oi = t), oi);
}
var ui, Ts;
function fe() {
  if (Ts) return ui;
  Ts = 1;
  var n = Q(),
    e = Dr().f,
    r = mr(),
    t = tr(),
    i = $a(),
    a = ih(),
    s = gl();
  return (
    (ui = function (o, u) {
      var l = o.target,
        h = o.global,
        c = o.stat,
        v,
        f,
        g,
        d,
        p,
        y;
      if (
        (h
          ? (f = n)
          : c
            ? (f = n[l] || i(l, {}))
            : (f = n[l] && n[l].prototype),
        f)
      )
        for (g in u) {
          if (
            ((p = u[g]),
            o.dontCallGetSet ? ((y = e(f, g)), (d = y && y.value)) : (d = f[g]),
            (v = s(h ? g : l + (c ? "." : "#") + g, o.forced)),
            !v && d !== void 0)
          ) {
            if (typeof p == typeof d) continue;
            a(p, d);
          }
          ((o.sham || (d && d.sham)) && r(p, "sham", !0), t(f, g, p, o));
        }
    }),
    ui
  );
}
var li, Ss;
function dl() {
  if (Ss) return li;
  Ss = 1;
  var n = Q(),
    e = yr(),
    r = We(),
    t = function (i) {
      return e.slice(0, i.length) === i;
    };
  return (
    (li = (function () {
      return t("Bun/")
        ? "BUN"
        : t("Cloudflare-Workers")
          ? "CLOUDFLARE"
          : t("Deno/")
            ? "DENO"
            : t("Node.js/")
              ? "NODE"
              : n.Bun && typeof Bun.version == "string"
                ? "BUN"
                : n.Deno && typeof Deno.version == "object"
                  ? "DENO"
                  : r(n.process) === "process"
                    ? "NODE"
                    : n.window && n.document
                      ? "BROWSER"
                      : "REST";
    })()),
    li
  );
}
var hi, Es;
function jr() {
  if (Es) return hi;
  Es = 1;
  var n = dl();
  return ((hi = n === "NODE"), hi);
}
var fi, Rs;
function ah() {
  if (Rs) return fi;
  Rs = 1;
  var n = Q();
  return ((fi = n), fi);
}
var ci, Cs;
function nh() {
  if (Cs) return ci;
  Cs = 1;
  var n = J(),
    e = Ye();
  return (
    (ci = function (r, t, i) {
      try {
        return n(e(Object.getOwnPropertyDescriptor(r, t)[i]));
      } catch {}
    }),
    ci
  );
}
var vi, ws;
function sh() {
  if (ws) return vi;
  ws = 1;
  var n = ye();
  return (
    (vi = function (e) {
      return n(e) || e === null;
    }),
    vi
  );
}
var gi, Ps;
function oh() {
  if (Ps) return gi;
  Ps = 1;
  var n = sh(),
    e = String,
    r = TypeError;
  return (
    (gi = function (t) {
      if (n(t)) return t;
      throw new r("Can't set " + e(t) + " as a prototype");
    }),
    gi
  );
}
var di, As;
function pl() {
  if (As) return di;
  As = 1;
  var n = nh(),
    e = ye(),
    r = Pe(),
    t = oh();
  return (
    (di =
      Object.setPrototypeOf ||
      ("__proto__" in {}
        ? (function () {
            var i = !1,
              a = {},
              s;
            try {
              ((s = n(Object.prototype, "__proto__", "set")),
                s(a, []),
                (i = a instanceof Array));
            } catch {}
            return function (u, l) {
              return (r(u), t(l), e(u) && (i ? s(u, l) : (u.__proto__ = l)), u);
            };
          })()
        : void 0)),
    di
  );
}
var pi, Is;
function Br() {
  if (Is) return pi;
  Is = 1;
  var n = Xe().f,
    e = Ae(),
    r = ne(),
    t = r("toStringTag");
  return (
    (pi = function (i, a, s) {
      (i && !s && (i = i.prototype),
        i && !e(i, t) && n(i, t, { configurable: !0, value: a }));
    }),
    pi
  );
}
var yi, Ns;
function uh() {
  if (Ns) return yi;
  Ns = 1;
  var n = fl(),
    e = Xe();
  return (
    (yi = function (r, t, i) {
      return (
        i.get && n(i.get, t, { getter: !0 }),
        i.set && n(i.set, t, { setter: !0 }),
        e.f(r, t, i)
      );
    }),
    yi
  );
}
var mi, _s;
function lh() {
  if (_s) return mi;
  _s = 1;
  var n = rr(),
    e = uh(),
    r = ne(),
    t = we(),
    i = r("species");
  return (
    (mi = function (a) {
      var s = n(a);
      t &&
        s &&
        !s[i] &&
        e(s, i, {
          configurable: !0,
          get: function () {
            return this;
          },
        });
    }),
    mi
  );
}
var bi, Ms;
function hh() {
  if (Ms) return bi;
  Ms = 1;
  var n = Nr(),
    e = TypeError;
  return (
    (bi = function (r, t) {
      if (n(t, r)) return r;
      throw new e("Incorrect invocation");
    }),
    bi
  );
}
var xi, qs;
function fh() {
  if (qs) return xi;
  qs = 1;
  var n = ne(),
    e = n("toStringTag"),
    r = {};
  return ((r[e] = "z"), (xi = String(r) === "[object z]"), xi);
}
var Oi, Ds;
function yl() {
  if (Ds) return Oi;
  Ds = 1;
  var n = fh(),
    e = ee(),
    r = We(),
    t = ne(),
    i = t("toStringTag"),
    a = Object,
    s =
      r(
        (function () {
          return arguments;
        })(),
      ) === "Arguments",
    o = function (u, l) {
      try {
        return u[l];
      } catch {}
    };
  return (
    (Oi = n
      ? r
      : function (u) {
          var l, h, c;
          return u === void 0
            ? "Undefined"
            : u === null
              ? "Null"
              : typeof (h = o((l = a(u)), i)) == "string"
                ? h
                : s
                  ? r(l)
                  : (c = r(l)) === "Object" && e(l.callee)
                    ? "Arguments"
                    : c;
        }),
    Oi
  );
}
var Ti, Vs;
function ch() {
  if (Vs) return Ti;
  Vs = 1;
  var n = J(),
    e = Z(),
    r = ee(),
    t = yl(),
    i = rr(),
    a = Wa(),
    s = function () {},
    o = i("Reflect", "construct"),
    u = /^\s*(?:class|function)\b/,
    l = n(u.exec),
    h = !u.test(s),
    c = function (g) {
      if (!r(g)) return !1;
      try {
        return (o(s, [], g), !0);
      } catch {
        return !1;
      }
    },
    v = function (g) {
      if (!r(g)) return !1;
      switch (t(g)) {
        case "AsyncFunction":
        case "GeneratorFunction":
        case "AsyncGeneratorFunction":
          return !1;
      }
      try {
        return h || !!l(u, a(g));
      } catch {
        return !0;
      }
    };
  return (
    (v.sham = !0),
    (Ti =
      !o ||
      e(function () {
        var f;
        return (
          c(c.call) ||
          !c(Object) ||
          !c(function () {
            f = !0;
          }) ||
          f
        );
      })
        ? v
        : c),
    Ti
  );
}
var Si, Ls;
function vh() {
  if (Ls) return Si;
  Ls = 1;
  var n = ch(),
    e = _r(),
    r = TypeError;
  return (
    (Si = function (t) {
      if (n(t)) return t;
      throw new r(e(t) + " is not a constructor");
    }),
    Si
  );
}
var Ei, ks;
function ml() {
  if (ks) return Ei;
  ks = 1;
  var n = he(),
    e = vh(),
    r = Ir(),
    t = ne(),
    i = t("species");
  return (
    (Ei = function (a, s) {
      var o = n(a).constructor,
        u;
      return o === void 0 || r((u = n(o)[i])) ? s : e(u);
    }),
    Ei
  );
}
var Ri, js;
function bl() {
  if (js) return Ri;
  js = 1;
  var n = Ar(),
    e = Function.prototype,
    r = e.apply,
    t = e.call;
  return (
    (Ri =
      (typeof Reflect == "object" && Reflect.apply) ||
      (n
        ? t.bind(r)
        : function () {
            return t.apply(r, arguments);
          })),
    Ri
  );
}
var Ci, Bs;
function Fr() {
  if (Bs) return Ci;
  Bs = 1;
  var n = We(),
    e = J();
  return (
    (Ci = function (r) {
      if (n(r) === "Function") return e(r);
    }),
    Ci
  );
}
var wi, Fs;
function Za() {
  if (Fs) return wi;
  Fs = 1;
  var n = Fr(),
    e = Ye(),
    r = Ar(),
    t = n(n.bind);
  return (
    (wi = function (i, a) {
      return (
        e(i),
        a === void 0
          ? i
          : r
            ? t(i, a)
            : function () {
                return i.apply(a, arguments);
              }
      );
    }),
    wi
  );
}
var Pi, Us;
function xl() {
  if (Us) return Pi;
  Us = 1;
  var n = rr();
  return ((Pi = n("document", "documentElement")), Pi);
}
var Ai, Gs;
function gh() {
  if (Gs) return Ai;
  Gs = 1;
  var n = J();
  return ((Ai = n([].slice)), Ai);
}
var Ii, $s;
function dh() {
  if ($s) return Ii;
  $s = 1;
  var n = TypeError;
  return (
    (Ii = function (e, r) {
      if (e < r) throw new n("Not enough arguments");
      return e;
    }),
    Ii
  );
}
var Ni, zs;
function Ol() {
  if (zs) return Ni;
  zs = 1;
  var n = yr();
  return ((Ni = /ipad|iphone|ipod/i.test(n) && /applewebkit/i.test(n)), Ni);
}
var _i, Hs;
function Tl() {
  if (Hs) return _i;
  Hs = 1;
  var n = Q(),
    e = bl(),
    r = Za(),
    t = ee(),
    i = Ae(),
    a = Z(),
    s = xl(),
    o = gh(),
    u = qr(),
    l = dh(),
    h = Ol(),
    c = jr(),
    v = n.setImmediate,
    f = n.clearImmediate,
    g = n.process,
    d = n.Dispatch,
    p = n.Function,
    y = n.MessageChannel,
    m = n.String,
    b = 0,
    x = {},
    S = "onreadystatechange",
    E,
    T,
    R,
    P;
  a(function () {
    E = n.location;
  });
  var A = function (w) {
      if (i(x, w)) {
        var V = x[w];
        (delete x[w], V());
      }
    },
    D = function (w) {
      return function () {
        A(w);
      };
    },
    I = function (w) {
      A(w.data);
    },
    k = function (w) {
      n.postMessage(m(w), E.protocol + "//" + E.host);
    };
  return (
    (!v || !f) &&
      ((v = function (V) {
        l(arguments.length, 1);
        var B = t(V) ? V : p(V),
          N = o(arguments, 1);
        return (
          (x[++b] = function () {
            e(B, void 0, N);
          }),
          T(b),
          b
        );
      }),
      (f = function (V) {
        delete x[V];
      }),
      c
        ? (T = function (w) {
            g.nextTick(D(w));
          })
        : d && d.now
          ? (T = function (w) {
              d.now(D(w));
            })
          : y && !h
            ? ((R = new y()),
              (P = R.port2),
              (R.port1.onmessage = I),
              (T = r(P.postMessage, P)))
            : n.addEventListener &&
                t(n.postMessage) &&
                !n.importScripts &&
                E &&
                E.protocol !== "file:" &&
                !a(k)
              ? ((T = k), n.addEventListener("message", I, !1))
              : S in u("script")
                ? (T = function (w) {
                    s.appendChild(u("script"))[S] = function () {
                      (s.removeChild(this), A(w));
                    };
                  })
                : (T = function (w) {
                    setTimeout(D(w), 0);
                  })),
    (_i = { set: v, clear: f }),
    _i
  );
}
var Mi, Ws;
function ph() {
  if (Ws) return Mi;
  Ws = 1;
  var n = Q(),
    e = we(),
    r = Object.getOwnPropertyDescriptor;
  return (
    (Mi = function (t) {
      if (!e) return n[t];
      var i = r(n, t);
      return i && i.value;
    }),
    Mi
  );
}
var qi, Ys;
function Sl() {
  if (Ys) return qi;
  Ys = 1;
  var n = function () {
    ((this.head = null), (this.tail = null));
  };
  return (
    (n.prototype = {
      add: function (e) {
        var r = { item: e, next: null },
          t = this.tail;
        (t ? (t.next = r) : (this.head = r), (this.tail = r));
      },
      get: function () {
        var e = this.head;
        if (e) {
          var r = (this.head = e.next);
          return (r === null && (this.tail = null), e.item);
        }
      },
    }),
    (qi = n),
    qi
  );
}
var Di, Xs;
function yh() {
  if (Xs) return Di;
  Xs = 1;
  var n = yr();
  return ((Di = /ipad|iphone|ipod/i.test(n) && typeof Pebble < "u"), Di);
}
var Vi, Ks;
function mh() {
  if (Ks) return Vi;
  Ks = 1;
  var n = yr();
  return ((Vi = /web0s(?!.*chrome)/i.test(n)), Vi);
}
var Li, Qs;
function bh() {
  if (Qs) return Li;
  Qs = 1;
  var n = Q(),
    e = ph(),
    r = Za(),
    t = Tl().set,
    i = Sl(),
    a = Ol(),
    s = yh(),
    o = mh(),
    u = jr(),
    l = n.MutationObserver || n.WebKitMutationObserver,
    h = n.document,
    c = n.process,
    v = n.Promise,
    f = e("queueMicrotask"),
    g,
    d,
    p,
    y,
    m;
  if (!f) {
    var b = new i(),
      x = function () {
        var S, E;
        for (u && (S = c.domain) && S.exit(); (E = b.get());)
          try {
            E();
          } catch (T) {
            throw (b.head && g(), T);
          }
        S && S.enter();
      };
    (!a && !u && !o && l && h
      ? ((d = !0),
        (p = h.createTextNode("")),
        new l(x).observe(p, { characterData: !0 }),
        (g = function () {
          p.data = d = !d;
        }))
      : !s && v && v.resolve
        ? ((y = v.resolve(void 0)),
          (y.constructor = v),
          (m = r(y.then, y)),
          (g = function () {
            m(x);
          }))
        : u
          ? (g = function () {
              c.nextTick(x);
            })
          : ((t = r(t, n)),
            (g = function () {
              t(x);
            })),
      (f = function (S) {
        (b.head || g(), b.add(S));
      }));
  }
  return ((Li = f), Li);
}
var ki, Zs;
function xh() {
  return (
    Zs ||
      ((Zs = 1),
      (ki = function (n, e) {
        try {
          arguments.length === 1 ? console.error(n) : console.error(n, e);
        } catch {}
      })),
    ki
  );
}
var ji, Js;
function Ja() {
  return (
    Js ||
      ((Js = 1),
      (ji = function (n) {
        try {
          return { error: !1, value: n() };
        } catch (e) {
          return { error: !0, value: e };
        }
      })),
    ji
  );
}
var Bi, eo;
function br() {
  if (eo) return Bi;
  eo = 1;
  var n = Q();
  return ((Bi = n.Promise), Bi);
}
var Fi, ro;
function xr() {
  if (ro) return Fi;
  ro = 1;
  var n = Q(),
    e = br(),
    r = ee(),
    t = gl(),
    i = Wa(),
    a = ne(),
    s = dl(),
    o = Me(),
    u = Ga(),
    l = e && e.prototype,
    h = a("species"),
    c = !1,
    v = r(n.PromiseRejectionEvent),
    f = t("Promise", function () {
      var g = i(e),
        d = g !== String(e);
      if ((!d && u === 66) || (o && !(l.catch && l.finally))) return !0;
      if (!u || u < 51 || !/native code/.test(g)) {
        var p = new e(function (b) {
            b(1);
          }),
          y = function (b) {
            b(
              function () {},
              function () {},
            );
          },
          m = (p.constructor = {});
        if (((m[h] = y), (c = p.then(function () {}) instanceof y), !c))
          return !0;
      }
      return !d && (s === "BROWSER" || s === "DENO") && !v;
    });
  return ((Fi = { CONSTRUCTOR: f, REJECTION_EVENT: v, SUBCLASSING: c }), Fi);
}
var Ui = {},
  to;
function Or() {
  if (to) return Ui;
  to = 1;
  var n = Ye(),
    e = TypeError,
    r = function (t) {
      var i, a;
      ((this.promise = new t(function (s, o) {
        if (i !== void 0 || a !== void 0)
          throw new e("Bad Promise constructor");
        ((i = s), (a = o));
      })),
        (this.resolve = n(i)),
        (this.reject = n(a)));
    };
  return (
    (Ui.f = function (t) {
      return new r(t);
    }),
    Ui
  );
}
var io;
function Oh() {
  if (io) return fn;
  io = 1;
  var n = fe(),
    e = Me(),
    r = jr(),
    t = Q(),
    i = ah(),
    a = se(),
    s = tr(),
    o = pl(),
    u = Br(),
    l = lh(),
    h = Ye(),
    c = ee(),
    v = ye(),
    f = hh(),
    g = ml(),
    d = Tl().set,
    p = bh(),
    y = xh(),
    m = Ja(),
    b = Sl(),
    x = Lr(),
    S = br(),
    E = xr(),
    T = Or(),
    R = "Promise",
    P = E.CONSTRUCTOR,
    A = E.REJECTION_EVENT,
    D = E.SUBCLASSING,
    I = x.getterFor(R),
    k = x.set,
    w = S && S.prototype,
    V = S,
    B = w,
    N = t.TypeError,
    j = t.document,
    _ = t.process,
    q = T.f,
    U = q,
    L = !!(j && j.createEvent && t.dispatchEvent),
    $ = "unhandledrejection",
    X = "rejectionhandled",
    ae = 0,
    oe = 1,
    ue = 2,
    Fe = 1,
    Ue = 2,
    ce,
    Ne,
    _e,
    be,
    ve = function (C) {
      var F;
      return v(C) && c((F = C.then)) ? F : !1;
    },
    xe = function (C, F) {
      var z = F.value,
        H = F.state === oe,
        W = H ? C.ok : C.fail,
        Te = C.resolve,
        Le = C.reject,
        Se = C.domain,
        Ee,
        lr,
        hr;
      try {
        W
          ? (H || (F.rejection === Ue && Ge(F), (F.rejection = Fe)),
            W === !0
              ? (Ee = z)
              : (Se && Se.enter(), (Ee = W(z)), Se && (Se.exit(), (hr = !0))),
            Ee === C.promise
              ? Le(new N("Promise-chain cycle"))
              : (lr = ve(Ee))
                ? a(lr, Ee, Te, Le)
                : Te(Ee))
          : Le(z);
      } catch (fr) {
        (Se && !hr && Se.exit(), Le(fr));
      }
    },
    De = function (C, F) {
      C.notified ||
        ((C.notified = !0),
        p(function () {
          for (var z = C.reactions, H; (H = z.get());) xe(H, C);
          ((C.notified = !1), F && !C.rejection && Ke(C));
        }));
    },
    Ve = function (C, F, z) {
      var H, W;
      (L
        ? ((H = j.createEvent("Event")),
          (H.promise = F),
          (H.reason = z),
          H.initEvent(C, !1, !0),
          t.dispatchEvent(H))
        : (H = { promise: F, reason: z }),
        !A && (W = t["on" + C])
          ? W(H)
          : C === $ && y("Unhandled promise rejection", z));
    },
    Ke = function (C) {
      a(d, t, function () {
        var F = C.facade,
          z = C.value,
          H = ur(C),
          W;
        if (
          H &&
          ((W = m(function () {
            r ? _.emit("unhandledRejection", z, F) : Ve($, F, z);
          })),
          (C.rejection = r || ur(C) ? Ue : Fe),
          W.error)
        )
          throw W.value;
      });
    },
    ur = function (C) {
      return C.rejection !== Fe && !C.parent;
    },
    Ge = function (C) {
      a(d, t, function () {
        var F = C.facade;
        r ? _.emit("rejectionHandled", F) : Ve(X, F, C.value);
      });
    },
    ge = function (C, F, z) {
      return function (H) {
        C(F, H, z);
      };
    },
    de = function (C, F, z) {
      C.done ||
        ((C.done = !0), z && (C = z), (C.value = F), (C.state = ue), De(C, !0));
    },
    Oe = function (C, F, z) {
      if (!C.done) {
        ((C.done = !0), z && (C = z));
        try {
          if (C.facade === F) throw new N("Promise can't be resolved itself");
          var H = ve(F);
          H
            ? p(function () {
                var W = { done: !1 };
                try {
                  a(H, F, ge(Oe, W, C), ge(de, W, C));
                } catch (Te) {
                  de(W, Te, C);
                }
              })
            : ((C.value = F), (C.state = oe), De(C, !1));
        } catch (W) {
          de({ done: !1 }, W, C);
        }
      }
    };
  if (
    P &&
    ((V = function (F) {
      (f(this, B), h(F), a(ce, this));
      var z = I(this);
      try {
        F(ge(Oe, z), ge(de, z));
      } catch (H) {
        de(z, H);
      }
    }),
    (B = V.prototype),
    (ce = function (F) {
      k(this, {
        type: R,
        done: !1,
        notified: !1,
        parent: !1,
        reactions: new b(),
        rejection: !1,
        state: ae,
        value: null,
      });
    }),
    (ce.prototype = s(B, "then", function (F, z) {
      var H = I(this),
        W = q(g(this, V));
      return (
        (H.parent = !0),
        (W.ok = c(F) ? F : !0),
        (W.fail = c(z) && z),
        (W.domain = r ? _.domain : void 0),
        H.state === ae
          ? H.reactions.add(W)
          : p(function () {
              xe(W, H);
            }),
        W.promise
      );
    })),
    (Ne = function () {
      var C = new ce(),
        F = I(C);
      ((this.promise = C),
        (this.resolve = ge(Oe, F)),
        (this.reject = ge(de, F)));
    }),
    (T.f = q =
      function (C) {
        return C === V || C === _e ? new Ne(C) : U(C);
      }),
    !e && c(S) && w !== Object.prototype)
  ) {
    ((be = w.then),
      D ||
        s(
          w,
          "then",
          function (F, z) {
            var H = this;
            return new V(function (W, Te) {
              a(be, H, W, Te);
            }).then(F, z);
          },
          { unsafe: !0 },
        ));
    try {
      delete w.constructor;
    } catch {}
    o && o(w, B);
  }
  return (
    n({ global: !0, constructor: !0, wrap: !0, forced: P }, { Promise: V }),
    (_e = i.Promise),
    u(V, R, !1, !0),
    l(R),
    fn
  );
}
var ao = {},
  Gi,
  no;
function Ur() {
  return (
    no || ((no = 1), (Gi = Object.create ? Object.create(null) : {})),
    Gi
  );
}
var $i, so;
function Th() {
  if (so) return $i;
  so = 1;
  var n = ne(),
    e = Ur(),
    r = n("iterator"),
    t = Array.prototype;
  return (
    ($i = function (i) {
      return i !== void 0 && (e.Array === i || t[r] === i);
    }),
    $i
  );
}
var zi, oo;
function El() {
  if (oo) return zi;
  oo = 1;
  var n = We(),
    e = Ir(),
    r = nr(),
    t = ne(),
    i = t("iterator"),
    a = Array.prototype;
  return (
    (zi = function (s) {
      if (!e(s))
        return (
          r(s, i) ||
          r(s, "@@iterator") ||
          (n(s) === "Arguments" ? a[i] : void 0)
        );
    }),
    zi
  );
}
var Hi, uo;
function Sh() {
  if (uo) return Hi;
  uo = 1;
  var n = se(),
    e = ee(),
    r = he(),
    t = _r(),
    i = El(),
    a = TypeError;
  return (
    (Hi = function (s, o) {
      var u = arguments.length < 2 ? i(s) : o;
      if (e(u)) return r(n(u, s));
      throw new a(t(s) + " is not iterable");
    }),
    Hi
  );
}
var Wi, lo;
function Eh() {
  if (lo) return Wi;
  lo = 1;
  var n = se(),
    e = he(),
    r = nr();
  return (
    (Wi = function (t, i, a) {
      var s, o;
      e(t);
      try {
        if (((s = r(t, "return")), !s)) {
          if (i === "throw") throw a;
          return a;
        }
        s = n(s, t);
      } catch (u) {
        ((o = !0), (s = u));
      }
      if (i === "throw") throw a;
      if (o) throw s;
      return (e(s), a);
    }),
    Wi
  );
}
var Yi, ho;
function Rl() {
  if (ho) return Yi;
  ho = 1;
  var n = Za(),
    e = se(),
    r = he(),
    t = _r(),
    i = Th(),
    a = Ka(),
    s = Nr(),
    o = Sh(),
    u = El(),
    l = Eh(),
    h = TypeError,
    c = function (f, g) {
      ((this.stopped = f), (this.result = g));
    },
    v = c.prototype;
  return (
    (Yi = function (f, g, d) {
      var p = d && d.that,
        y = !!(d && d.AS_ENTRIES),
        m = !!(d && d.IS_RECORD),
        b = !!(d && d.IS_ITERATOR),
        x = !!(d && d.INTERRUPTED),
        S = n(g, p),
        E,
        T,
        R,
        P,
        A,
        D,
        I,
        k = function (B) {
          var N = E;
          return ((E = void 0), N && l(N, "normal"), new c(!0, B));
        },
        w = function (B) {
          return y
            ? (r(B), x ? S(B[0], B[1], k) : S(B[0], B[1]))
            : x
              ? S(B, k)
              : S(B);
        };
      if (m) E = f.iterator;
      else if (b) E = f;
      else {
        if (((T = u(f)), !T)) throw new h(t(f) + " is not iterable");
        if (i(T)) {
          for (R = 0, P = a(f); P > R; R++)
            if (((A = w(f[R])), A && s(v, A))) return A;
          return new c(!1);
        }
        E = o(f, T);
      }
      for (D = m ? f.next : E.next; !(I = e(D, E)).done;) {
        var V = I.value;
        try {
          A = w(V);
        } catch (B) {
          if (E) l(E, "throw", B);
          else throw B;
        }
        if (typeof A == "object" && A && s(v, A)) return A;
      }
      return new c(!1);
    }),
    Yi
  );
}
var Xi, fo;
function Rh() {
  if (fo) return Xi;
  fo = 1;
  var n = ne(),
    e = n("iterator"),
    r = !1;
  try {
    var t = 0,
      i = {
        next: function () {
          return { done: !!t++ };
        },
        return: function () {
          r = !0;
        },
      };
    ((i[e] = function () {
      return this;
    }),
      Array.from(i, function () {
        throw 2;
      }));
  } catch {}
  return (
    (Xi = function (a, s) {
      try {
        if (!s && !r) return !1;
      } catch {
        return !1;
      }
      var o = !1;
      try {
        var u = {};
        ((u[e] = function () {
          return {
            next: function () {
              return { done: (o = !0) };
            },
          };
        }),
          a(u));
      } catch {}
      return o;
    }),
    Xi
  );
}
var Ki, co;
function Cl() {
  if (co) return Ki;
  co = 1;
  var n = br(),
    e = Rh(),
    r = xr().CONSTRUCTOR;
  return (
    (Ki =
      r ||
      !e(function (t) {
        n.all(t).then(void 0, function () {});
      })),
    Ki
  );
}
var vo;
function Ch() {
  if (vo) return ao;
  vo = 1;
  var n = fe(),
    e = se(),
    r = Ye(),
    t = Or(),
    i = Ja(),
    a = Rl(),
    s = Cl();
  return (
    n(
      { target: "Promise", stat: !0, forced: s },
      {
        all: function (u) {
          var l = this,
            h = t.f(l),
            c = h.resolve,
            v = h.reject,
            f = i(function () {
              var g = r(l.resolve),
                d = [],
                p = 0,
                y = 1;
              (a(u, function (m) {
                var b = p++,
                  x = !1;
                (y++,
                  e(g, l, m).then(function (S) {
                    x || ((x = !0), (d[b] = S), --y || c(d));
                  }, v));
              }),
                --y || c(d));
            });
          return (f.error && v(f.value), h.promise);
        },
      },
    ),
    ao
  );
}
var go = {},
  po;
function wh() {
  if (po) return go;
  po = 1;
  var n = fe(),
    e = Me(),
    r = xr().CONSTRUCTOR,
    t = br(),
    i = rr(),
    a = ee(),
    s = tr(),
    o = t && t.prototype;
  if (
    (n(
      { target: "Promise", proto: !0, forced: r, real: !0 },
      {
        catch: function (l) {
          return this.then(void 0, l);
        },
      },
    ),
    !e && a(t))
  ) {
    var u = i("Promise").prototype.catch;
    o.catch !== u && s(o, "catch", u, { unsafe: !0 });
  }
  return go;
}
var yo = {},
  mo;
function Ph() {
  if (mo) return yo;
  mo = 1;
  var n = fe(),
    e = se(),
    r = Ye(),
    t = Or(),
    i = Ja(),
    a = Rl(),
    s = Cl();
  return (
    n(
      { target: "Promise", stat: !0, forced: s },
      {
        race: function (u) {
          var l = this,
            h = t.f(l),
            c = h.reject,
            v = i(function () {
              var f = r(l.resolve);
              a(u, function (g) {
                e(f, l, g).then(h.resolve, c);
              });
            });
          return (v.error && c(v.value), h.promise);
        },
      },
    ),
    yo
  );
}
var bo = {},
  xo;
function Ah() {
  if (xo) return bo;
  xo = 1;
  var n = fe(),
    e = Or(),
    r = xr().CONSTRUCTOR;
  return (
    n(
      { target: "Promise", stat: !0, forced: r },
      {
        reject: function (i) {
          var a = e.f(this),
            s = a.reject;
          return (s(i), a.promise);
        },
      },
    ),
    bo
  );
}
var Oo = {},
  Qi,
  To;
function Ih() {
  if (To) return Qi;
  To = 1;
  var n = he(),
    e = ye(),
    r = Or();
  return (
    (Qi = function (t, i) {
      if ((n(t), e(i) && i.constructor === t)) return i;
      var a = r.f(t),
        s = a.resolve;
      return (s(i), a.promise);
    }),
    Qi
  );
}
var So;
function Nh() {
  if (So) return Oo;
  So = 1;
  var n = fe(),
    e = rr(),
    r = Me(),
    t = br(),
    i = xr().CONSTRUCTOR,
    a = Ih(),
    s = e("Promise"),
    o = r && !i;
  return (
    n(
      { target: "Promise", stat: !0, forced: r || i },
      {
        resolve: function (l) {
          return a(o && this === s ? t : this, l);
        },
      },
    ),
    Oo
  );
}
var Eo;
function _h() {
  return (Eo || ((Eo = 1), Oh(), Ch(), wh(), Ph(), Ah(), Nh()), hn);
}
_h();
function Ro(n, e, r, t, i, a, s) {
  try {
    var o = n[a](s),
      u = o.value;
  } catch (l) {
    return void r(l);
  }
  o.done ? e(u) : Promise.resolve(u).then(t, i);
}
function Be(n) {
  return function () {
    var e = this,
      r = arguments;
    return new Promise(function (t, i) {
      var a = n.apply(e, r);
      function s(u) {
        Ro(a, t, i, s, o, "next", u);
      }
      function o(u) {
        Ro(a, t, i, s, o, "throw", u);
      }
      s(void 0);
    });
  };
}
var Co = {},
  wo = {},
  Zi,
  Po;
function qe() {
  if (Po) return Zi;
  Po = 1;
  var n = yl(),
    e = String;
  return (
    (Zi = function (r) {
      if (n(r) === "Symbol")
        throw new TypeError("Cannot convert a Symbol value to a string");
      return e(r);
    }),
    Zi
  );
}
var Ji, Ao;
function wl() {
  if (Ao) return Ji;
  Ao = 1;
  var n = he();
  return (
    (Ji = function () {
      var e = n(this),
        r = "";
      return (
        e.hasIndices && (r += "d"),
        e.global && (r += "g"),
        e.ignoreCase && (r += "i"),
        e.multiline && (r += "m"),
        e.dotAll && (r += "s"),
        e.unicode && (r += "u"),
        e.unicodeSets && (r += "v"),
        e.sticky && (r += "y"),
        r
      );
    }),
    Ji
  );
}
var ea, Io;
function Pl() {
  if (Io) return ea;
  Io = 1;
  var n = Z(),
    e = Q(),
    r = e.RegExp,
    t = n(function () {
      var s = r("a", "y");
      return ((s.lastIndex = 2), s.exec("abcd") !== null);
    }),
    i =
      t ||
      n(function () {
        return !r("a", "y").sticky;
      }),
    a =
      t ||
      n(function () {
        var s = r("^r", "gy");
        return ((s.lastIndex = 2), s.exec("str") !== null);
      });
  return ((ea = { BROKEN_CARET: a, MISSED_STICKY: i, UNSUPPORTED_Y: t }), ea);
}
var ra = {},
  ta,
  No;
function Mh() {
  if (No) return ta;
  No = 1;
  var n = vl(),
    e = Qa();
  return (
    (ta =
      Object.keys ||
      function (t) {
        return n(t, e);
      }),
    ta
  );
}
var _o;
function qh() {
  if (_o) return ra;
  _o = 1;
  var n = we(),
    e = hl(),
    r = Xe(),
    t = he(),
    i = pr(),
    a = Mh();
  return (
    (ra.f =
      n && !e
        ? Object.defineProperties
        : function (o, u) {
            t(o);
            for (var l = i(u), h = a(u), c = h.length, v = 0, f; c > v;)
              r.f(o, (f = h[v++]), l[f]);
            return o;
          }),
    ra
  );
}
var ia, Mo;
function Gr() {
  if (Mo) return ia;
  Mo = 1;
  var n = he(),
    e = qh(),
    r = Qa(),
    t = Xa(),
    i = xl(),
    a = qr(),
    s = Ya(),
    o = ">",
    u = "<",
    l = "prototype",
    h = "script",
    c = s("IE_PROTO"),
    v = function () {},
    f = function (m) {
      return u + h + o + m + u + "/" + h + o;
    },
    g = function (m) {
      (m.write(f("")), m.close());
      var b = m.parentWindow.Object;
      return ((m = null), b);
    },
    d = function () {
      var m = a("iframe"),
        b = "java" + h + ":",
        x;
      return (
        (m.style.display = "none"),
        i.appendChild(m),
        (m.src = String(b)),
        (x = m.contentWindow.document),
        x.open(),
        x.write(f("document.F=Object")),
        x.close(),
        x.F
      );
    },
    p,
    y = function () {
      try {
        p = new ActiveXObject("htmlfile");
      } catch {}
      y = typeof document < "u" ? (document.domain && p ? g(p) : d()) : g(p);
      for (var m = r.length; m--;) delete y[l][r[m]];
      return y();
    };
  return (
    (t[c] = !0),
    (ia =
      Object.create ||
      function (b, x) {
        var S;
        return (
          b !== null
            ? ((v[l] = n(b)), (S = new v()), (v[l] = null), (S[c] = b))
            : (S = y()),
          x === void 0 ? S : e.f(S, x)
        );
      }),
    ia
  );
}
var aa, qo;
function Dh() {
  if (qo) return aa;
  qo = 1;
  var n = Z(),
    e = Q(),
    r = e.RegExp;
  return (
    (aa = n(function () {
      var t = r(".", "s");
      return !(
        t.dotAll &&
        t.test(`
`) &&
        t.flags === "s"
      );
    })),
    aa
  );
}
var na, Do;
function Vh() {
  if (Do) return na;
  Do = 1;
  var n = Z(),
    e = Q(),
    r = e.RegExp;
  return (
    (na = n(function () {
      var t = r("(?<a>b)", "g");
      return t.exec("b").groups.a !== "b" || "b".replace(t, "$<a>c") !== "bc";
    })),
    na
  );
}
var sa, Vo;
function en() {
  if (Vo) return sa;
  Vo = 1;
  var n = se(),
    e = J(),
    r = qe(),
    t = wl(),
    i = Pl(),
    a = Ha(),
    s = Gr(),
    o = Lr().get,
    u = Dh(),
    l = Vh(),
    h = a("native-string-replace", String.prototype.replace),
    c = RegExp.prototype.exec,
    v = c,
    f = e("".charAt),
    g = e("".indexOf),
    d = e("".replace),
    p = e("".slice),
    y = (function () {
      var E = /a/,
        T = /b*/g;
      return (
        n(c, E, "a"),
        n(c, T, "a"),
        E.lastIndex !== 0 || T.lastIndex !== 0
      );
    })(),
    m = i.BROKEN_CARET,
    b = /()??/.exec("")[1] !== void 0,
    x = y || b || m || u || l,
    S = function (E, T) {
      for (var R = (E.groups = s(null)), P = 0; P < T.length; P++) {
        var A = T[P];
        R[A[0]] = E[A[1]];
      }
    };
  return (
    x &&
      (v = function (T) {
        var R = this,
          P = o(R),
          A = r(T),
          D = P.raw,
          I,
          k,
          w;
        if (D)
          return (
            (D.lastIndex = R.lastIndex),
            (I = n(v, D, A)),
            (R.lastIndex = D.lastIndex),
            I && P.groups && S(I, P.groups),
            I
          );
        var V = P.groups,
          B = m && R.sticky,
          N = n(t, R),
          j = R.source,
          _ = 0,
          q = A;
        if (B) {
          ((N = d(N, "y", "")),
            g(N, "g") === -1 && (N += "g"),
            (q = p(A, R.lastIndex)));
          var U = R.lastIndex > 0 && f(A, R.lastIndex - 1);
          (R.lastIndex > 0 &&
            (!R.multiline ||
              (R.multiline &&
                U !==
                  `
` &&
                U !== "\r" &&
                U !== "\u2028" &&
                U !== "\u2029")) &&
            ((j = "(?: (?:" + j + "))"), (q = " " + q), _++),
            (k = new RegExp("^(?:" + j + ")", N)));
        }
        (b && (k = new RegExp("^" + j + "$(?!\\s)", N)),
          y && (w = R.lastIndex));
        var L = n(c, B ? k : R, q);
        return (
          B
            ? L
              ? ((L.input = A),
                (L[0] = p(L[0], _)),
                (L.index = R.lastIndex),
                (R.lastIndex += L[0].length))
              : (R.lastIndex = 0)
            : y && L && (R.lastIndex = R.global ? L.index + L[0].length : w),
          b &&
            L &&
            L.length > 1 &&
            n(h, L[0], k, function () {
              for (var $ = 1; $ < arguments.length - 2; $++)
                arguments[$] === void 0 && (L[$] = void 0);
            }),
          L && V && S(L, V),
          L
        );
      }),
    (sa = v),
    sa
  );
}
var Lo;
function Lh() {
  if (Lo) return wo;
  Lo = 1;
  var n = fe(),
    e = en();
  return (
    n({ target: "RegExp", proto: !0, forced: /./.exec !== e }, { exec: e }),
    wo
  );
}
var oa, ko;
function rn() {
  if (ko) return oa;
  ((ko = 1), Lh());
  var n = se(),
    e = tr(),
    r = en(),
    t = Z(),
    i = ne(),
    a = mr(),
    s = i("species"),
    o = RegExp.prototype;
  return (
    (oa = function (u, l, h, c) {
      var v = i(u),
        f = !t(function () {
          var y = {};
          return (
            (y[v] = function () {
              return 7;
            }),
            ""[u](y) !== 7
          );
        }),
        g =
          f &&
          !t(function () {
            var y = !1,
              m = /a/;
            if (u === "split") {
              var b = {};
              ((b[s] = function () {
                return m;
              }),
                (m = { constructor: b, flags: "" }),
                (m[v] = /./[v]));
            }
            return (
              (m.exec = function () {
                return ((y = !0), null);
              }),
              m[v](""),
              !y
            );
          });
      if (!f || !g || h) {
        var d = /./[v],
          p = l(v, ""[u], function (y, m, b, x, S) {
            var E = m.exec;
            return E === r || E === o.exec
              ? f && !S
                ? { done: !0, value: n(d, m, b, x) }
                : { done: !0, value: n(y, b, m, x) }
              : { done: !1 };
          });
        (e(String.prototype, u, p[0]), e(o, v, p[1]));
      }
      c && a(o[v], "sham", !0);
    }),
    oa
  );
}
var ua, jo;
function kh() {
  if (jo) return ua;
  jo = 1;
  var n = J(),
    e = kr(),
    r = qe(),
    t = Pe(),
    i = n("".charAt),
    a = n("".charCodeAt),
    s = n("".slice),
    o = function (u) {
      return function (l, h) {
        var c = r(t(l)),
          v = e(h),
          f = c.length,
          g,
          d;
        return v < 0 || v >= f
          ? u
            ? ""
            : void 0
          : ((g = a(c, v)),
            g < 55296 ||
            g > 56319 ||
            v + 1 === f ||
            (d = a(c, v + 1)) < 56320 ||
            d > 57343
              ? u
                ? i(c, v)
                : g
              : u
                ? s(c, v, v + 2)
                : ((g - 55296) << 10) + (d - 56320) + 65536);
      };
    };
  return ((ua = { codeAt: o(!1), charAt: o(!0) }), ua);
}
var la, Bo;
function tn() {
  if (Bo) return la;
  Bo = 1;
  var n = kh().charAt;
  return (
    (la = function (e, r, t) {
      return r + ((t && n(e, r).length) || 1);
    }),
    la
  );
}
var ha, Fo;
function jh() {
  if (Fo) return ha;
  Fo = 1;
  var n = Q(),
    e = Z(),
    r = n.RegExp,
    t = !e(function () {
      var i = !0;
      try {
        r(".", "d");
      } catch {
        i = !1;
      }
      var a = {},
        s = "",
        o = i ? "dgimsy" : "gimsy",
        u = function (v, f) {
          Object.defineProperty(a, v, {
            get: function () {
              return ((s += f), !0);
            },
          });
        },
        l = {
          dotAll: "s",
          global: "g",
          ignoreCase: "i",
          multiline: "m",
          sticky: "y",
        };
      i && (l.hasIndices = "d");
      for (var h in l) u(h, l[h]);
      var c = Object.getOwnPropertyDescriptor(r.prototype, "flags").get.call(a);
      return c !== o || s !== o;
    });
  return ((ha = { correct: t }), ha);
}
var fa, Uo;
function $r() {
  if (Uo) return fa;
  Uo = 1;
  var n = se(),
    e = Ae(),
    r = Nr(),
    t = jh(),
    i = wl(),
    a = RegExp.prototype;
  return (
    (fa = t.correct
      ? function (s) {
          return s.flags;
        }
      : function (s) {
          return !t.correct && r(a, s) && !e(s, "flags") ? n(i, s) : s.flags;
        }),
    fa
  );
}
var ca, Go;
function an() {
  if (Go) return ca;
  Go = 1;
  var n = se(),
    e = he(),
    r = ee(),
    t = We(),
    i = en(),
    a = TypeError;
  return (
    (ca = function (s, o) {
      var u = s.exec;
      if (r(u)) {
        var l = n(u, s, o);
        return (l !== null && e(l), l);
      }
      if (t(s) === "RegExp") return n(i, s, o);
      throw new a("RegExp#exec called on incompatible receiver");
    }),
    ca
  );
}
var $o;
function Bh() {
  if ($o) return Co;
  $o = 1;
  var n = se(),
    e = J(),
    r = rn(),
    t = he(),
    i = ye(),
    a = sr(),
    s = qe(),
    o = Pe(),
    u = nr(),
    l = tn(),
    h = $r(),
    c = an(),
    v = e("".indexOf);
  return (
    r("match", function (f, g, d) {
      return [
        function (y) {
          var m = o(this),
            b = i(y) ? u(y, f) : void 0;
          if (b) return n(b, y, m);
          var x = s(m);
          return new RegExp(y)[f](x);
        },
        function (p) {
          var y = t(this),
            m = s(p),
            b = d(g, y, m);
          if (b.done) return b.value;
          var x = s(h(y));
          if (!~v(x, "g")) return c(y, m);
          var S = !!~v(x, "u") || !!~v(x, "v");
          y.lastIndex = 0;
          for (var E = [], T = 0, R; (R = c(y, m)) !== null;) {
            var P = s(R[0]);
            ((E[T] = P),
              P === "" && (y.lastIndex = l(m, a(y.lastIndex), S)),
              T++);
          }
          return T === 0 ? null : E;
        },
      ];
    }),
    Co
  );
}
Bh();
var zo = {},
  va,
  Ho;
function Fh() {
  if (Ho) return va;
  Ho = 1;
  var n = J(),
    e = Mr(),
    r = Math.floor,
    t = n("".charAt),
    i = n("".replace),
    a = n("".slice),
    s = /\$([$&'`]|\d{1,2}|<[^>]*>)/g,
    o = /\$([$&'`]|\d{1,2})/g;
  return (
    (va = function (u, l, h, c, v, f) {
      var g = h + u.length,
        d = c.length,
        p = o;
      return (
        v !== void 0 && ((v = e(v)), (p = s)),
        i(f, p, function (y, m) {
          var b;
          switch (t(m, 0)) {
            case "$":
              return "$";
            case "&":
              return u;
            case "`":
              return a(l, 0, h);
            case "'":
              return a(l, g);
            case "<":
              b = v[a(m, 1, -1)];
              break;
            default:
              var x = +m;
              if (x === 0) return y;
              if (x > d) {
                var S = r(x / 10);
                return S === 0
                  ? y
                  : S <= d
                    ? c[S - 1] === void 0
                      ? t(m, 1)
                      : c[S - 1] + t(m, 1)
                    : y;
              }
              b = c[x - 1];
          }
          return b === void 0 ? "" : b;
        })
      );
    }),
    va
  );
}
var Wo;
function Uh() {
  if (Wo) return zo;
  Wo = 1;
  var n = bl(),
    e = se(),
    r = J(),
    t = rn(),
    i = Z(),
    a = he(),
    s = ee(),
    o = ye(),
    u = kr(),
    l = sr(),
    h = qe(),
    c = Pe(),
    v = tn(),
    f = nr(),
    g = Fh(),
    d = $r(),
    p = an(),
    y = ne(),
    m = y("replace"),
    b = Math.max,
    x = Math.min,
    S = r([].concat),
    E = r([].push),
    T = r("".indexOf),
    R = r("".slice),
    P = function (k) {
      return k === void 0 ? k : String(k);
    },
    A = (function () {
      return "a".replace(/./, "$0") === "$0";
    })(),
    D = (function () {
      return /./[m] ? /./[m]("a", "$0") === "" : !1;
    })(),
    I = !i(function () {
      var k = /./;
      return (
        (k.exec = function () {
          var w = [];
          return ((w.groups = { a: "7" }), w);
        }),
        "".replace(k, "$<a>") !== "7"
      );
    });
  return (
    t(
      "replace",
      function (k, w, V) {
        var B = D ? "$" : "$0";
        return [
          function (j, _) {
            var q = c(this),
              U = o(j) ? f(j, m) : void 0;
            return U ? e(U, j, q, _) : e(w, h(q), j, _);
          },
          function (N, j) {
            var _ = a(this),
              q = h(N),
              U = s(j);
            U || (j = h(j));
            var L = h(d(_));
            if (
              typeof j == "string" &&
              !~T(j, B) &&
              !~T(j, "$<") &&
              !~T(L, "y")
            ) {
              var $ = V(w, _, q, j);
              if ($.done) return $.value;
            }
            var X = !!~T(L, "g"),
              ae;
            X && ((ae = !!~T(L, "u") || !!~T(L, "v")), (_.lastIndex = 0));
            for (
              var oe = [], ue;
              (ue = p(_, q)), !(ue === null || (E(oe, ue), !X));
            ) {
              var Fe = h(ue[0]);
              Fe === "" && (_.lastIndex = v(q, l(_.lastIndex), ae));
            }
            for (var Ue = "", ce = 0, Ne = 0; Ne < oe.length; Ne++) {
              ue = oe[Ne];
              for (
                var _e = h(ue[0]),
                  be = b(x(u(ue.index), q.length), 0),
                  ve = [],
                  xe,
                  De = 1;
                De < ue.length;
                De++
              )
                E(ve, P(ue[De]));
              var Ve = ue.groups;
              if (U) {
                var Ke = S([_e], ve, be, q);
                (Ve !== void 0 && E(Ke, Ve), (xe = h(n(j, void 0, Ke))));
              } else xe = g(_e, q, be, ve, Ve, j);
              be >= ce && ((Ue += R(q, ce, be) + xe), (ce = be + _e.length));
            }
            return Ue + R(q, ce);
          },
        ];
      },
      !I || !A || D,
    ),
    zo
  );
}
Uh();
var Yo = {},
  ga,
  Xo;
function Gh() {
  if (Xo) return ga;
  Xo = 1;
  var n = ye(),
    e = We(),
    r = ne(),
    t = r("match");
  return (
    (ga = function (i) {
      var a;
      return n(i) && ((a = i[t]) !== void 0 ? !!a : e(i) === "RegExp");
    }),
    ga
  );
}
var da, Ko;
function nn() {
  if (Ko) return da;
  Ko = 1;
  var n = Gh(),
    e = TypeError;
  return (
    (da = function (r) {
      if (n(r)) throw new e("The method doesn't accept regular expressions");
      return r;
    }),
    da
  );
}
var pa, Qo;
function sn() {
  if (Qo) return pa;
  Qo = 1;
  var n = ne(),
    e = n("match");
  return (
    (pa = function (r) {
      var t = /./;
      try {
        "/./"[r](t);
      } catch {
        try {
          return ((t[e] = !1), "/./"[r](t));
        } catch {}
      }
      return !1;
    }),
    pa
  );
}
var Zo;
function $h() {
  if (Zo) return Yo;
  Zo = 1;
  var n = fe(),
    e = Fr(),
    r = Dr().f,
    t = sr(),
    i = qe(),
    a = nn(),
    s = Pe(),
    o = sn(),
    u = Me(),
    l = e("".slice),
    h = Math.min,
    c = o("startsWith"),
    v =
      !u &&
      !c &&
      !!(function () {
        var f = r(String.prototype, "startsWith");
        return f && !f.writable;
      })();
  return (
    n(
      { target: "String", proto: !0, forced: !v && !c },
      {
        startsWith: function (g) {
          var d = i(s(this));
          a(g);
          var p = i(g),
            y = t(h(arguments.length > 1 ? arguments[1] : void 0, d.length));
          return l(d, y, y + p.length) === p;
        },
      },
    ),
    Yo
  );
}
$h();
var ya, Jo;
function zh() {
  if (Jo) return ya;
  Jo = 1;
  var n = ne(),
    e = Gr(),
    r = Xe().f,
    t = n("unscopables"),
    i = Array.prototype;
  return (
    i[t] === void 0 && r(i, t, { configurable: !0, value: e(null) }),
    (ya = function (a) {
      i[t][a] = !0;
    }),
    ya
  );
}
var ma, eu;
function Hh() {
  if (eu) return ma;
  eu = 1;
  var n = Z();
  return (
    (ma = !n(function () {
      function e() {}
      return (
        (e.prototype.constructor = null),
        Object.getPrototypeOf(new e()) !== e.prototype
      );
    })),
    ma
  );
}
var ba, ru;
function Al() {
  if (ru) return ba;
  ru = 1;
  var n = Ae(),
    e = ee(),
    r = Mr(),
    t = Ya(),
    i = Hh(),
    a = t("IE_PROTO"),
    s = Object,
    o = s.prototype;
  return (
    (ba = i
      ? s.getPrototypeOf
      : function (u) {
          var l = r(u);
          if (n(l, a)) return l[a];
          var h = l.constructor;
          return e(h) && l instanceof h
            ? h.prototype
            : l instanceof s
              ? o
              : null;
        }),
    ba
  );
}
var xa, tu;
function Il() {
  if (tu) return xa;
  tu = 1;
  var n = Z(),
    e = ee(),
    r = ye(),
    t = Gr(),
    i = Al(),
    a = tr(),
    s = ne(),
    o = Me(),
    u = s("iterator"),
    l = !1,
    h,
    c,
    v;
  [].keys &&
    ((v = [].keys()),
    "next" in v
      ? ((c = i(i(v))), c !== Object.prototype && (h = c))
      : (l = !0));
  var f =
    !r(h) ||
    n(function () {
      var g = {};
      return h[u].call(g) !== g;
    });
  return (
    f ? (h = {}) : o && (h = t(h)),
    e(h[u]) ||
      a(h, u, function () {
        return this;
      }),
    (xa = { IteratorPrototype: h, BUGGY_SAFARI_ITERATORS: l }),
    xa
  );
}
var Oa, iu;
function Wh() {
  if (iu) return Oa;
  iu = 1;
  var n = Il().IteratorPrototype,
    e = Gr(),
    r = Ua(),
    t = Br(),
    i = Ur(),
    a = function () {
      return this;
    };
  return (
    (Oa = function (s, o, u, l) {
      var h = o + " Iterator";
      return (
        (s.prototype = e(n, { next: r(+!l, u) })),
        t(s, h, !1, !0),
        (i[h] = a),
        s
      );
    }),
    Oa
  );
}
var Ta, au;
function Yh() {
  if (au) return Ta;
  au = 1;
  var n = fe(),
    e = se(),
    r = Me(),
    t = Vr(),
    i = ee(),
    a = Wh(),
    s = Al(),
    o = pl(),
    u = Br(),
    l = mr(),
    h = tr(),
    c = ne(),
    v = Ur(),
    f = Il(),
    g = t.PROPER,
    d = t.CONFIGURABLE,
    p = f.IteratorPrototype,
    y = f.BUGGY_SAFARI_ITERATORS,
    m = c("iterator"),
    b = "keys",
    x = "values",
    S = "entries",
    E = function () {
      return this;
    };
  return (
    (Ta = function (T, R, P, A, D, I, k) {
      a(P, R, A);
      var w = function (X) {
          if (X === D && _) return _;
          if (!y && X && X in N) return N[X];
          switch (X) {
            case b:
              return function () {
                return new P(this, X);
              };
            case x:
              return function () {
                return new P(this, X);
              };
            case S:
              return function () {
                return new P(this, X);
              };
          }
          return function () {
            return new P(this);
          };
        },
        V = R + " Iterator",
        B = !1,
        N = T.prototype,
        j = N[m] || N["@@iterator"] || (D && N[D]),
        _ = (!y && j) || w(D),
        q = (R === "Array" && N.entries) || j,
        U,
        L,
        $;
      if (
        (q &&
          ((U = s(q.call(new T()))),
          U !== Object.prototype &&
            U.next &&
            (!r && s(U) !== p && (o ? o(U, p) : i(U[m]) || h(U, m, E)),
            u(U, V, !0, !0),
            r && (v[V] = E))),
        g &&
          D === x &&
          j &&
          j.name !== x &&
          (!r && d
            ? l(N, "name", x)
            : ((B = !0),
              (_ = function () {
                return e(j, this);
              }))),
        D)
      )
        if (((L = { values: w(x), keys: I ? _ : w(b), entries: w(S) }), k))
          for ($ in L) (y || B || !($ in N)) && h(N, $, L[$]);
        else n({ target: R, proto: !0, forced: y || B }, L);
      return (
        (!r || k) && N[m] !== _ && h(N, m, _, { name: D }),
        (v[R] = _),
        L
      );
    }),
    Ta
  );
}
var Sa, nu;
function Xh() {
  return (
    nu ||
      ((nu = 1),
      (Sa = function (n, e) {
        return { value: n, done: e };
      })),
    Sa
  );
}
var Ea, su;
function Nl() {
  if (su) return Ea;
  su = 1;
  var n = pr(),
    e = zh(),
    r = Ur(),
    t = Lr(),
    i = Xe().f,
    a = Yh(),
    s = Xh(),
    o = Me(),
    u = we(),
    l = "Array Iterator",
    h = t.set,
    c = t.getterFor(l);
  Ea = a(
    Array,
    "Array",
    function (f, g) {
      h(this, { type: l, target: n(f), index: 0, kind: g });
    },
    function () {
      var f = c(this),
        g = f.target,
        d = f.index++;
      if (!g || d >= g.length) return ((f.target = null), s(void 0, !0));
      switch (f.kind) {
        case "keys":
          return s(d, !1);
        case "values":
          return s(g[d], !1);
      }
      return s([d, g[d]], !1);
    },
    "values",
  );
  var v = (r.Arguments = r.Array);
  if ((e("keys"), e("values"), e("entries"), !o && u && v.name !== "values"))
    try {
      i(v, "name", { value: "values" });
    } catch {}
  return Ea;
}
Nl();
var ou = {},
  Ra,
  uu;
function Kh() {
  return (
    uu ||
      ((uu = 1),
      (Ra = {
        CSSRuleList: 0,
        CSSStyleDeclaration: 0,
        CSSValueList: 0,
        ClientRectList: 0,
        DOMRectList: 0,
        DOMStringList: 0,
        DOMTokenList: 1,
        DataTransferItemList: 0,
        FileList: 0,
        HTMLAllCollection: 0,
        HTMLCollection: 0,
        HTMLFormElement: 0,
        HTMLSelectElement: 0,
        MediaList: 0,
        MimeTypeArray: 0,
        NamedNodeMap: 0,
        NodeList: 1,
        PaintRequestList: 0,
        Plugin: 0,
        PluginArray: 0,
        SVGLengthList: 0,
        SVGNumberList: 0,
        SVGPathSegList: 0,
        SVGPointList: 0,
        SVGStringList: 0,
        SVGTransformList: 0,
        SourceBufferList: 0,
        StyleSheetList: 0,
        TextTrackCueList: 0,
        TextTrackList: 0,
        TouchList: 0,
      })),
    Ra
  );
}
var Ca, lu;
function Qh() {
  if (lu) return Ca;
  lu = 1;
  var n = qr(),
    e = n("span").classList,
    r = e && e.constructor && e.constructor.prototype;
  return ((Ca = r === Object.prototype ? void 0 : r), Ca);
}
var hu;
function Zh() {
  if (hu) return ou;
  hu = 1;
  var n = Q(),
    e = Kh(),
    r = Qh(),
    t = Nl(),
    i = mr(),
    a = Br(),
    s = ne(),
    o = s("iterator"),
    u = t.values,
    l = function (c, v) {
      if (c) {
        if (c[o] !== u)
          try {
            i(c, o, u);
          } catch {
            c[o] = u;
          }
        if ((a(c, v, !0), e[v])) {
          for (var f in t)
            if (c[f] !== t[f])
              try {
                i(c, f, t[f]);
              } catch {
                c[f] = t[f];
              }
        }
      }
    };
  for (var h in e) l(n[h] && n[h].prototype, h);
  return (l(r, "DOMTokenList"), ou);
}
Zh();
function dr(n) {
  "@babel/helpers - typeof";
  return (
    (dr =
      typeof Symbol == "function" && typeof Symbol.iterator == "symbol"
        ? function (e) {
            return typeof e;
          }
        : function (e) {
            return e &&
              typeof Symbol == "function" &&
              e.constructor === Symbol &&
              e !== Symbol.prototype
              ? "symbol"
              : typeof e;
          }),
    dr(n)
  );
}
function Jh(n, e) {
  if (dr(n) != "object" || !n) return n;
  var r = n[Symbol.toPrimitive];
  if (r !== void 0) {
    var t = r.call(n, e);
    if (dr(t) != "object") return t;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (e === "string" ? String : Number)(n);
}
function ef(n) {
  var e = Jh(n, "string");
  return dr(e) == "symbol" ? e : e + "";
}
function on(n, e, r) {
  return (
    (e = ef(e)) in n
      ? Object.defineProperty(n, e, {
          value: r,
          enumerable: !0,
          configurable: !0,
          writable: !0,
        })
      : (n[e] = r),
    n
  );
}
var fu = {},
  wa,
  cu;
function rf() {
  if (cu) return wa;
  cu = 1;
  var n = Ye(),
    e = Mr(),
    r = il(),
    t = Ka(),
    i = TypeError,
    a = "Reduce of empty array with no initial value",
    s = function (o) {
      return function (u, l, h, c) {
        var v = e(u),
          f = r(v),
          g = t(v);
        if ((n(l), g === 0 && h < 2)) throw new i(a);
        var d = o ? g - 1 : 0,
          p = o ? -1 : 1;
        if (h < 2)
          for (;;) {
            if (d in f) {
              ((c = f[d]), (d += p));
              break;
            }
            if (((d += p), o ? d < 0 : g <= d)) throw new i(a);
          }
        for (; o ? d >= 0 : g > d; d += p) d in f && (c = l(c, f[d], d, v));
        return c;
      };
    };
  return ((wa = { left: s(!1), right: s(!0) }), wa);
}
var Pa, vu;
function _l() {
  if (vu) return Pa;
  vu = 1;
  var n = Z();
  return (
    (Pa = function (e, r) {
      var t = [][e];
      return (
        !!t &&
        n(function () {
          t.call(
            null,
            r ||
              function () {
                return 1;
              },
            1,
          );
        })
      );
    }),
    Pa
  );
}
var gu;
function tf() {
  if (gu) return fu;
  gu = 1;
  var n = fe(),
    e = rf().left,
    r = _l(),
    t = Ga(),
    i = jr(),
    a = !i && t > 79 && t < 83,
    s = a || !r("reduce");
  return (
    n(
      { target: "Array", proto: !0, forced: s },
      {
        reduce: function (u) {
          var l = arguments.length;
          return e(this, u, l, l > 1 ? arguments[1] : void 0);
        },
      },
    ),
    fu
  );
}
tf();
var du = {},
  pu;
function af() {
  if (pu) return du;
  pu = 1;
  var n = fe(),
    e = Fr(),
    r = Dr().f,
    t = sr(),
    i = qe(),
    a = nn(),
    s = Pe(),
    o = sn(),
    u = Me(),
    l = e("".slice),
    h = Math.min,
    c = o("endsWith"),
    v =
      !u &&
      !c &&
      !!(function () {
        var f = r(String.prototype, "endsWith");
        return f && !f.writable;
      })();
  return (
    n(
      { target: "String", proto: !0, forced: !v && !c },
      {
        endsWith: function (g) {
          var d = i(s(this));
          a(g);
          var p = i(g),
            y = arguments.length > 1 ? arguments[1] : void 0,
            m = d.length,
            b = y === void 0 ? m : h(t(y), m);
          return l(d, b - p.length, b) === p;
        },
      },
    ),
    du
  );
}
af();
var yu = {},
  mu;
function nf() {
  if (mu) return yu;
  mu = 1;
  var n = se(),
    e = J(),
    r = rn(),
    t = he(),
    i = ye(),
    a = Pe(),
    s = ml(),
    o = tn(),
    u = sr(),
    l = qe(),
    h = nr(),
    c = $r(),
    v = an(),
    f = Pl(),
    g = Z(),
    d = f.UNSUPPORTED_Y,
    p = 4294967295,
    y = Math.min,
    m = e([].push),
    b = e("".slice),
    x = e("".indexOf),
    S = !g(function () {
      var T = /(?:)/,
        R = T.exec;
      T.exec = function () {
        return R.apply(this, arguments);
      };
      var P = "ab".split(T);
      return P.length !== 2 || P[0] !== "a" || P[1] !== "b";
    }),
    E =
      "abbc".split(/(b)*/)[1] === "c" ||
      "test".split(/(?:)/, -1).length !== 4 ||
      "ab".split(/(?:ab)*/).length !== 2 ||
      ".".split(/(.?)(.?)/).length !== 4 ||
      ".".split(/()()/).length > 1 ||
      "".split(/.?/).length;
  return (
    r(
      "split",
      function (T, R, P) {
        var A = "0".split(void 0, 0).length
          ? function (D, I) {
              return D === void 0 && I === 0 ? [] : n(R, this, D, I);
            }
          : R;
        return [
          function (I, k) {
            var w = a(this),
              V = i(I) ? h(I, T) : void 0;
            return V ? n(V, I, w, k) : n(A, l(w), I, k);
          },
          function (D, I) {
            var k = t(this),
              w = l(D);
            if (!E) {
              var V = P(A, k, w, I, A !== R);
              if (V.done) return V.value;
            }
            var B = s(k, RegExp),
              N = l(c(k)),
              j = !!~x(N, "u") || !!~x(N, "v");
            d ? ~x(N, "g") || (N += "g") : ~x(N, "y") || (N += "y");
            var _ = new B(d ? "^(?:" + k.source + ")" : k, N),
              q = I === void 0 ? p : I >>> 0;
            if (q === 0) return [];
            if (w.length === 0) return v(_, w) === null ? [w] : [];
            for (var U = 0, L = 0, $ = []; L < w.length;) {
              _.lastIndex = d ? 0 : L;
              var X = v(_, d ? b(w, L) : w),
                ae;
              if (
                X === null ||
                (ae = y(u(_.lastIndex + (d ? L : 0)), w.length)) === U
              )
                L = o(w, L, j);
              else {
                if ((m($, b(w, U, L)), $.length === q)) return $;
                for (var oe = 1; oe <= X.length - 1; oe++)
                  if ((m($, X[oe]), $.length === q)) return $;
                L = U = ae;
              }
            }
            return (m($, b(w, U)), $);
          },
        ];
      },
      E || !S,
      d,
    ),
    yu
  );
}
nf();
var vr = { exports: {} },
  Je = { exports: {} },
  sf = Je.exports,
  bu;
function of() {
  return (
    bu ||
      ((bu = 1),
      function () {
        var n, e, r, t, i, a;
        typeof performance < "u" && performance !== null && performance.now
          ? (Je.exports = function () {
              return performance.now();
            })
          : typeof process < "u" && process !== null && process.hrtime
            ? ((Je.exports = function () {
                return (n() - i) / 1e6;
              }),
              (e = process.hrtime),
              (n = function () {
                var s;
                return ((s = e()), s[0] * 1e9 + s[1]);
              }),
              (t = n()),
              (a = process.uptime() * 1e9),
              (i = t - a))
            : Date.now
              ? ((Je.exports = function () {
                  return Date.now() - r;
                }),
                (r = Date.now()))
              : ((Je.exports = function () {
                  return new Date().getTime() - r;
                }),
                (r = new Date().getTime()));
      }.call(sf)),
    Je.exports
  );
}
var xu;
function uf() {
  if (xu) return vr.exports;
  xu = 1;
  for (
    var n = of(),
      e = typeof window > "u" ? La : window,
      r = ["moz", "webkit"],
      t = "AnimationFrame",
      i = e["request" + t],
      a = e["cancel" + t] || e["cancelRequest" + t],
      s = 0;
    !i && s < r.length;
    s++
  )
    ((i = e[r[s] + "Request" + t]),
      (a = e[r[s] + "Cancel" + t] || e[r[s] + "CancelRequest" + t]));
  if (!i || !a) {
    var o = 0,
      u = 0,
      l = [],
      h = 1e3 / 60;
    ((i = function (c) {
      if (l.length === 0) {
        var v = n(),
          f = Math.max(0, h - (v - o));
        ((o = f + v),
          setTimeout(function () {
            var g = l.slice(0);
            l.length = 0;
            for (var d = 0; d < g.length; d++)
              if (!g[d].cancelled)
                try {
                  g[d].callback(o);
                } catch (p) {
                  setTimeout(function () {
                    throw p;
                  }, 0);
                }
          }, Math.round(f)));
      }
      return (l.push({ handle: ++u, callback: c, cancelled: !1 }), u);
    }),
      (a = function (c) {
        for (var v = 0; v < l.length; v++)
          l[v].handle === c && (l[v].cancelled = !0);
      }));
  }
  return (
    (vr.exports = function (c) {
      return i.call(e, c);
    }),
    (vr.exports.cancel = function () {
      a.apply(e, arguments);
    }),
    (vr.exports.polyfill = function (c) {
      (c || (c = e),
        (c.requestAnimationFrame = i),
        (c.cancelAnimationFrame = a));
    }),
    vr.exports
  );
}
var lf = uf();
const Aa = tl(lf);
var Ou = {},
  Ia,
  Tu;
function Ml() {
  return (
    Tu ||
      ((Tu = 1),
      (Ia = `	
\v\f\r                　\u2028\u2029\uFEFF`)),
    Ia
  );
}
var Na, Su;
function hf() {
  if (Su) return Na;
  Su = 1;
  var n = J(),
    e = Pe(),
    r = qe(),
    t = Ml(),
    i = n("".replace),
    a = RegExp("^[" + t + "]+"),
    s = RegExp("(^|[^" + t + "])[" + t + "]+$"),
    o = function (u) {
      return function (l) {
        var h = r(e(l));
        return (u & 1 && (h = i(h, a, "")), u & 2 && (h = i(h, s, "$1")), h);
      };
    };
  return ((Na = { start: o(1), end: o(2), trim: o(3) }), Na);
}
var _a, Eu;
function ff() {
  if (Eu) return _a;
  Eu = 1;
  var n = Vr().PROPER,
    e = Z(),
    r = Ml(),
    t = "​᠎";
  return (
    (_a = function (i) {
      return e(function () {
        return !!r[i]() || t[i]() !== t || (n && r[i].name !== i);
      });
    }),
    _a
  );
}
var Ru;
function cf() {
  if (Ru) return Ou;
  Ru = 1;
  var n = fe(),
    e = hf().trim,
    r = ff();
  return (
    n(
      { target: "String", proto: !0, forced: r("trim") },
      {
        trim: function () {
          return e(this);
        },
      },
    ),
    Ou
  );
}
cf();
var Ma, Cu;
function vf() {
  return (
    Cu ||
      ((Cu = 1),
      (Ma = function (n) {
        ((this.ok = !1),
          (this.alpha = 1),
          n.charAt(0) == "#" && (n = n.substr(1, 6)),
          (n = n.replace(/ /g, "")),
          (n = n.toLowerCase()));
        var e = {
          aliceblue: "f0f8ff",
          antiquewhite: "faebd7",
          aqua: "00ffff",
          aquamarine: "7fffd4",
          azure: "f0ffff",
          beige: "f5f5dc",
          bisque: "ffe4c4",
          black: "000000",
          blanchedalmond: "ffebcd",
          blue: "0000ff",
          blueviolet: "8a2be2",
          brown: "a52a2a",
          burlywood: "deb887",
          cadetblue: "5f9ea0",
          chartreuse: "7fff00",
          chocolate: "d2691e",
          coral: "ff7f50",
          cornflowerblue: "6495ed",
          cornsilk: "fff8dc",
          crimson: "dc143c",
          cyan: "00ffff",
          darkblue: "00008b",
          darkcyan: "008b8b",
          darkgoldenrod: "b8860b",
          darkgray: "a9a9a9",
          darkgreen: "006400",
          darkkhaki: "bdb76b",
          darkmagenta: "8b008b",
          darkolivegreen: "556b2f",
          darkorange: "ff8c00",
          darkorchid: "9932cc",
          darkred: "8b0000",
          darksalmon: "e9967a",
          darkseagreen: "8fbc8f",
          darkslateblue: "483d8b",
          darkslategray: "2f4f4f",
          darkturquoise: "00ced1",
          darkviolet: "9400d3",
          deeppink: "ff1493",
          deepskyblue: "00bfff",
          dimgray: "696969",
          dodgerblue: "1e90ff",
          feldspar: "d19275",
          firebrick: "b22222",
          floralwhite: "fffaf0",
          forestgreen: "228b22",
          fuchsia: "ff00ff",
          gainsboro: "dcdcdc",
          ghostwhite: "f8f8ff",
          gold: "ffd700",
          goldenrod: "daa520",
          gray: "808080",
          green: "008000",
          greenyellow: "adff2f",
          honeydew: "f0fff0",
          hotpink: "ff69b4",
          indianred: "cd5c5c",
          indigo: "4b0082",
          ivory: "fffff0",
          khaki: "f0e68c",
          lavender: "e6e6fa",
          lavenderblush: "fff0f5",
          lawngreen: "7cfc00",
          lemonchiffon: "fffacd",
          lightblue: "add8e6",
          lightcoral: "f08080",
          lightcyan: "e0ffff",
          lightgoldenrodyellow: "fafad2",
          lightgrey: "d3d3d3",
          lightgreen: "90ee90",
          lightpink: "ffb6c1",
          lightsalmon: "ffa07a",
          lightseagreen: "20b2aa",
          lightskyblue: "87cefa",
          lightslateblue: "8470ff",
          lightslategray: "778899",
          lightsteelblue: "b0c4de",
          lightyellow: "ffffe0",
          lime: "00ff00",
          limegreen: "32cd32",
          linen: "faf0e6",
          magenta: "ff00ff",
          maroon: "800000",
          mediumaquamarine: "66cdaa",
          mediumblue: "0000cd",
          mediumorchid: "ba55d3",
          mediumpurple: "9370d8",
          mediumseagreen: "3cb371",
          mediumslateblue: "7b68ee",
          mediumspringgreen: "00fa9a",
          mediumturquoise: "48d1cc",
          mediumvioletred: "c71585",
          midnightblue: "191970",
          mintcream: "f5fffa",
          mistyrose: "ffe4e1",
          moccasin: "ffe4b5",
          navajowhite: "ffdead",
          navy: "000080",
          oldlace: "fdf5e6",
          olive: "808000",
          olivedrab: "6b8e23",
          orange: "ffa500",
          orangered: "ff4500",
          orchid: "da70d6",
          palegoldenrod: "eee8aa",
          palegreen: "98fb98",
          paleturquoise: "afeeee",
          palevioletred: "d87093",
          papayawhip: "ffefd5",
          peachpuff: "ffdab9",
          peru: "cd853f",
          pink: "ffc0cb",
          plum: "dda0dd",
          powderblue: "b0e0e6",
          purple: "800080",
          rebeccapurple: "663399",
          red: "ff0000",
          rosybrown: "bc8f8f",
          royalblue: "4169e1",
          saddlebrown: "8b4513",
          salmon: "fa8072",
          sandybrown: "f4a460",
          seagreen: "2e8b57",
          seashell: "fff5ee",
          sienna: "a0522d",
          silver: "c0c0c0",
          skyblue: "87ceeb",
          slateblue: "6a5acd",
          slategray: "708090",
          snow: "fffafa",
          springgreen: "00ff7f",
          steelblue: "4682b4",
          tan: "d2b48c",
          teal: "008080",
          thistle: "d8bfd8",
          tomato: "ff6347",
          turquoise: "40e0d0",
          violet: "ee82ee",
          violetred: "d02090",
          wheat: "f5deb3",
          white: "ffffff",
          whitesmoke: "f5f5f5",
          yellow: "ffff00",
          yellowgreen: "9acd32",
        };
        n = e[n] || n;
        for (
          var r = [
              {
                re: /^rgba\((\d{1,3}),\s*(\d{1,3}),\s*(\d{1,3}),\s*((?:\d?\.)?\d)\)$/,
                example: ["rgba(123, 234, 45, 0.8)", "rgba(255,234,245,1.0)"],
                process: function (u) {
                  return [
                    parseInt(u[1]),
                    parseInt(u[2]),
                    parseInt(u[3]),
                    parseFloat(u[4]),
                  ];
                },
              },
              {
                re: /^rgb\((\d{1,3}),\s*(\d{1,3}),\s*(\d{1,3})\)$/,
                example: ["rgb(123, 234, 45)", "rgb(255,234,245)"],
                process: function (u) {
                  return [parseInt(u[1]), parseInt(u[2]), parseInt(u[3])];
                },
              },
              {
                re: /^([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})$/,
                example: ["#00ff00", "336699"],
                process: function (u) {
                  return [
                    parseInt(u[1], 16),
                    parseInt(u[2], 16),
                    parseInt(u[3], 16),
                  ];
                },
              },
              {
                re: /^([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})$/,
                example: ["#fb0", "f0f"],
                process: function (u) {
                  return [
                    parseInt(u[1] + u[1], 16),
                    parseInt(u[2] + u[2], 16),
                    parseInt(u[3] + u[3], 16),
                  ];
                },
              },
            ],
            t = 0;
          t < r.length;
          t++
        ) {
          var i = r[t].re,
            a = r[t].process,
            s = i.exec(n);
          if (s) {
            var o = a(s);
            ((this.r = o[0]),
              (this.g = o[1]),
              (this.b = o[2]),
              o.length > 3 && (this.alpha = o[3]),
              (this.ok = !0));
          }
        }
        ((this.r =
          this.r < 0 || isNaN(this.r) ? 0 : this.r > 255 ? 255 : this.r),
          (this.g =
            this.g < 0 || isNaN(this.g) ? 0 : this.g > 255 ? 255 : this.g),
          (this.b =
            this.b < 0 || isNaN(this.b) ? 0 : this.b > 255 ? 255 : this.b),
          (this.alpha =
            this.alpha < 0
              ? 0
              : this.alpha > 1 || isNaN(this.alpha)
                ? 1
                : this.alpha),
          (this.toRGB = function () {
            return "rgb(" + this.r + ", " + this.g + ", " + this.b + ")";
          }),
          (this.toRGBA = function () {
            return (
              "rgba(" +
              this.r +
              ", " +
              this.g +
              ", " +
              this.b +
              ", " +
              this.alpha +
              ")"
            );
          }),
          (this.toHex = function () {
            var u = this.r.toString(16),
              l = this.g.toString(16),
              h = this.b.toString(16);
            return (
              u.length == 1 && (u = "0" + u),
              l.length == 1 && (l = "0" + l),
              h.length == 1 && (h = "0" + h),
              "#" + u + l + h
            );
          }),
          (this.getHelpXML = function () {
            for (var u = new Array(), l = 0; l < r.length; l++)
              for (var h = r[l].example, c = 0; c < h.length; c++)
                u[u.length] = h[c];
            for (var v in e) u[u.length] = v;
            var f = document.createElement("ul");
            f.setAttribute("id", "rgbcolor-examples");
            for (var l = 0; l < u.length; l++)
              try {
                var g = document.createElement("li"),
                  d = new RGBColor(u[l]),
                  p = document.createElement("div");
                ((p.style.cssText =
                  "margin: 3px; border: 1px solid black; background:" +
                  d.toHex() +
                  "; color:" +
                  d.toHex()),
                  p.appendChild(document.createTextNode("test")));
                var y = document.createTextNode(
                  " " + u[l] + " -> " + d.toRGB() + " -> " + d.toHex(),
                );
                (g.appendChild(p), g.appendChild(y), f.appendChild(g));
              } catch {}
            return f;
          }));
      })),
    Ma
  );
}
var gf = vf();
const ka = tl(gf);
var wu = {},
  Pu;
function df() {
  if (Pu) return wu;
  Pu = 1;
  var n = fe(),
    e = Fr(),
    r = cl().indexOf,
    t = _l(),
    i = e([].indexOf),
    a = !!i && 1 / i([1], 1, -0) < 0,
    s = a || !t("indexOf");
  return (
    n(
      { target: "Array", proto: !0, forced: s },
      {
        indexOf: function (u) {
          var l = arguments.length > 1 ? arguments[1] : void 0;
          return a ? i(this, u, l) || 0 : r(this, u, l);
        },
      },
    ),
    wu
  );
}
df();
var Au = {},
  Iu;
function pf() {
  if (Iu) return Au;
  Iu = 1;
  var n = fe(),
    e = J(),
    r = nn(),
    t = Pe(),
    i = qe(),
    a = sn(),
    s = e("".indexOf);
  return (
    n(
      { target: "String", proto: !0, forced: !a("includes") },
      {
        includes: function (u) {
          return !!~s(
            i(t(this)),
            i(r(u)),
            arguments.length > 1 ? arguments[1] : void 0,
          );
        },
      },
    ),
    Au
  );
}
pf();
var Nu = {},
  qa,
  _u;
function yf() {
  if (_u) return qa;
  _u = 1;
  var n = We();
  return (
    (qa =
      Array.isArray ||
      function (r) {
        return n(r) === "Array";
      }),
    qa
  );
}
var Mu;
function mf() {
  if (Mu) return Nu;
  Mu = 1;
  var n = fe(),
    e = J(),
    r = yf(),
    t = e([].reverse),
    i = [1, 2];
  return (
    n(
      { target: "Array", proto: !0, forced: String(i) === String(i.reverse()) },
      {
        reverse: function () {
          return (r(this) && (this.length = this.length), t(this));
        },
      },
    ),
    Nu
  );
}
mf();
/*! *****************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */ var ql =
  function (n, e) {
    return (ql =
      Object.setPrototypeOf ||
      ({ __proto__: [] } instanceof Array &&
        function (r, t) {
          r.__proto__ = t;
        }) ||
      function (r, t) {
        for (var i in t)
          Object.prototype.hasOwnProperty.call(t, i) && (r[i] = t[i]);
      })(n, e);
  };
function Dl(n, e) {
  if (typeof e != "function" && e !== null)
    throw new TypeError(
      "Class extends value " + String(e) + " is not a constructor or null",
    );
  function r() {
    this.constructor = n;
  }
  (ql(n, e),
    (n.prototype =
      e === null ? Object.create(e) : ((r.prototype = e.prototype), new r())));
}
function bf(n) {
  var e = "";
  Array.isArray(n) || (n = [n]);
  for (var r = 0; r < n.length; r++) {
    var t = n[r];
    if (t.type === O.CLOSE_PATH) e += "z";
    else if (t.type === O.HORIZ_LINE_TO) e += (t.relative ? "h" : "H") + t.x;
    else if (t.type === O.VERT_LINE_TO) e += (t.relative ? "v" : "V") + t.y;
    else if (t.type === O.MOVE_TO)
      e += (t.relative ? "m" : "M") + t.x + " " + t.y;
    else if (t.type === O.LINE_TO)
      e += (t.relative ? "l" : "L") + t.x + " " + t.y;
    else if (t.type === O.CURVE_TO)
      e +=
        (t.relative ? "c" : "C") +
        t.x1 +
        " " +
        t.y1 +
        " " +
        t.x2 +
        " " +
        t.y2 +
        " " +
        t.x +
        " " +
        t.y;
    else if (t.type === O.SMOOTH_CURVE_TO)
      e += (t.relative ? "s" : "S") + t.x2 + " " + t.y2 + " " + t.x + " " + t.y;
    else if (t.type === O.QUAD_TO)
      e += (t.relative ? "q" : "Q") + t.x1 + " " + t.y1 + " " + t.x + " " + t.y;
    else if (t.type === O.SMOOTH_QUAD_TO)
      e += (t.relative ? "t" : "T") + t.x + " " + t.y;
    else {
      if (t.type !== O.ARC)
        throw new Error(
          'Unexpected command type "' + t.type + '" at index ' + r + ".",
        );
      e +=
        (t.relative ? "a" : "A") +
        t.rX +
        " " +
        t.rY +
        " " +
        t.xRot +
        " " +
        +t.lArcFlag +
        " " +
        +t.sweepFlag +
        " " +
        t.x +
        " " +
        t.y;
    }
  }
  return e;
}
function ja(n, e) {
  var r = n[0],
    t = n[1];
  return [r * Math.cos(e) - t * Math.sin(e), r * Math.sin(e) + t * Math.cos(e)];
}
function Ce() {
  for (var n = [], e = 0; e < arguments.length; e++) n[e] = arguments[e];
  for (var r = 0; r < n.length; r++)
    if (typeof n[r] != "number")
      throw new Error(
        "assertNumbers arguments[" +
          r +
          "] is not a number. " +
          typeof n[r] +
          " == typeof " +
          n[r],
      );
  return !0;
}
var $e = Math.PI;
function Da(n, e, r) {
  ((n.lArcFlag = n.lArcFlag === 0 ? 0 : 1),
    (n.sweepFlag = n.sweepFlag === 0 ? 0 : 1));
  var t = n.rX,
    i = n.rY,
    a = n.x,
    s = n.y;
  ((t = Math.abs(n.rX)), (i = Math.abs(n.rY)));
  var o = ja([(e - a) / 2, (r - s) / 2], (-n.xRot / 180) * $e),
    u = o[0],
    l = o[1],
    h = Math.pow(u, 2) / Math.pow(t, 2) + Math.pow(l, 2) / Math.pow(i, 2);
  (1 < h && ((t *= Math.sqrt(h)), (i *= Math.sqrt(h))), (n.rX = t), (n.rY = i));
  var c = Math.pow(t, 2) * Math.pow(l, 2) + Math.pow(i, 2) * Math.pow(u, 2),
    v =
      (n.lArcFlag !== n.sweepFlag ? 1 : -1) *
      Math.sqrt(Math.max(0, (Math.pow(t, 2) * Math.pow(i, 2) - c) / c)),
    f = ((t * l) / i) * v,
    g = ((-i * u) / t) * v,
    d = ja([f, g], (n.xRot / 180) * $e);
  ((n.cX = d[0] + (e + a) / 2),
    (n.cY = d[1] + (r + s) / 2),
    (n.phi1 = Math.atan2((l - g) / i, (u - f) / t)),
    (n.phi2 = Math.atan2((-l - g) / i, (-u - f) / t)),
    n.sweepFlag === 0 && n.phi2 > n.phi1 && (n.phi2 -= 2 * $e),
    n.sweepFlag === 1 && n.phi2 < n.phi1 && (n.phi2 += 2 * $e),
    (n.phi1 *= 180 / $e),
    (n.phi2 *= 180 / $e));
}
function qu(n, e, r) {
  Ce(n, e, r);
  var t = n * n + e * e - r * r;
  if (0 > t) return [];
  if (t === 0) return [[(n * r) / (n * n + e * e), (e * r) / (n * n + e * e)]];
  var i = Math.sqrt(t);
  return [
    [(n * r + e * i) / (n * n + e * e), (e * r - n * i) / (n * n + e * e)],
    [(n * r - e * i) / (n * n + e * e), (e * r + n * i) / (n * n + e * e)],
  ];
}
var ie,
  ke = Math.PI / 180;
function Du(n, e, r) {
  return (1 - r) * n + r * e;
}
function Vu(n, e, r, t) {
  return n + Math.cos((t / 180) * $e) * e + Math.sin((t / 180) * $e) * r;
}
function Lu(n, e, r, t) {
  var i = 1e-6,
    a = e - n,
    s = r - e,
    o = 3 * a + 3 * (t - r) - 6 * s,
    u = 6 * (s - a),
    l = 3 * a;
  return Math.abs(o) < i
    ? [-l / u]
    : (function (h, c, v) {
        var f = (h * h) / 4 - c;
        if (f < -v) return [];
        if (f <= v) return [-h / 2];
        var g = Math.sqrt(f);
        return [-h / 2 - g, -h / 2 + g];
      })(u / o, l / o, i);
}
function ku(n, e, r, t, i) {
  var a = 1 - i;
  return (
    n * (a * a * a) +
    e * (3 * a * a * i) +
    r * (3 * a * i * i) +
    t * (i * i * i)
  );
}
(function (n) {
  function e() {
    return i(function (o, u, l) {
      return (
        o.relative &&
          (o.x1 !== void 0 && (o.x1 += u),
          o.y1 !== void 0 && (o.y1 += l),
          o.x2 !== void 0 && (o.x2 += u),
          o.y2 !== void 0 && (o.y2 += l),
          o.x !== void 0 && (o.x += u),
          o.y !== void 0 && (o.y += l),
          (o.relative = !1)),
        o
      );
    });
  }
  function r() {
    var o = NaN,
      u = NaN,
      l = NaN,
      h = NaN;
    return i(function (c, v, f) {
      return (
        c.type & O.SMOOTH_CURVE_TO &&
          ((c.type = O.CURVE_TO),
          (o = isNaN(o) ? v : o),
          (u = isNaN(u) ? f : u),
          (c.x1 = c.relative ? v - o : 2 * v - o),
          (c.y1 = c.relative ? f - u : 2 * f - u)),
        c.type & O.CURVE_TO
          ? ((o = c.relative ? v + c.x2 : c.x2),
            (u = c.relative ? f + c.y2 : c.y2))
          : ((o = NaN), (u = NaN)),
        c.type & O.SMOOTH_QUAD_TO &&
          ((c.type = O.QUAD_TO),
          (l = isNaN(l) ? v : l),
          (h = isNaN(h) ? f : h),
          (c.x1 = c.relative ? v - l : 2 * v - l),
          (c.y1 = c.relative ? f - h : 2 * f - h)),
        c.type & O.QUAD_TO
          ? ((l = c.relative ? v + c.x1 : c.x1),
            (h = c.relative ? f + c.y1 : c.y1))
          : ((l = NaN), (h = NaN)),
        c
      );
    });
  }
  function t() {
    var o = NaN,
      u = NaN;
    return i(function (l, h, c) {
      if (
        (l.type & O.SMOOTH_QUAD_TO &&
          ((l.type = O.QUAD_TO),
          (o = isNaN(o) ? h : o),
          (u = isNaN(u) ? c : u),
          (l.x1 = l.relative ? h - o : 2 * h - o),
          (l.y1 = l.relative ? c - u : 2 * c - u)),
        l.type & O.QUAD_TO)
      ) {
        ((o = l.relative ? h + l.x1 : l.x1),
          (u = l.relative ? c + l.y1 : l.y1));
        var v = l.x1,
          f = l.y1;
        ((l.type = O.CURVE_TO),
          (l.x1 = ((l.relative ? 0 : h) + 2 * v) / 3),
          (l.y1 = ((l.relative ? 0 : c) + 2 * f) / 3),
          (l.x2 = (l.x + 2 * v) / 3),
          (l.y2 = (l.y + 2 * f) / 3));
      } else ((o = NaN), (u = NaN));
      return l;
    });
  }
  function i(o) {
    var u = 0,
      l = 0,
      h = NaN,
      c = NaN;
    return function (v) {
      if (isNaN(h) && !(v.type & O.MOVE_TO))
        throw new Error("path must start with moveto");
      var f = o(v, u, l, h, c);
      return (
        v.type & O.CLOSE_PATH && ((u = h), (l = c)),
        v.x !== void 0 && (u = v.relative ? u + v.x : v.x),
        v.y !== void 0 && (l = v.relative ? l + v.y : v.y),
        v.type & O.MOVE_TO && ((h = u), (c = l)),
        f
      );
    };
  }
  function a(o, u, l, h, c, v) {
    return (
      Ce(o, u, l, h, c, v),
      i(function (f, g, d, p) {
        var y = f.x1,
          m = f.x2,
          b = f.relative && !isNaN(p),
          x = f.x !== void 0 ? f.x : b ? 0 : g,
          S = f.y !== void 0 ? f.y : b ? 0 : d;
        function E(L) {
          return L * L;
        }
        (f.type & O.HORIZ_LINE_TO &&
          u !== 0 &&
          ((f.type = O.LINE_TO), (f.y = f.relative ? 0 : d)),
          f.type & O.VERT_LINE_TO &&
            l !== 0 &&
            ((f.type = O.LINE_TO), (f.x = f.relative ? 0 : g)),
          f.x !== void 0 && (f.x = f.x * o + S * l + (b ? 0 : c)),
          f.y !== void 0 && (f.y = x * u + f.y * h + (b ? 0 : v)),
          f.x1 !== void 0 && (f.x1 = f.x1 * o + f.y1 * l + (b ? 0 : c)),
          f.y1 !== void 0 && (f.y1 = y * u + f.y1 * h + (b ? 0 : v)),
          f.x2 !== void 0 && (f.x2 = f.x2 * o + f.y2 * l + (b ? 0 : c)),
          f.y2 !== void 0 && (f.y2 = m * u + f.y2 * h + (b ? 0 : v)));
        var T = o * h - u * l;
        if (f.xRot !== void 0 && (o !== 1 || u !== 0 || l !== 0 || h !== 1))
          if (T === 0)
            (delete f.rX,
              delete f.rY,
              delete f.xRot,
              delete f.lArcFlag,
              delete f.sweepFlag,
              (f.type = O.LINE_TO));
          else {
            var R = (f.xRot * Math.PI) / 180,
              P = Math.sin(R),
              A = Math.cos(R),
              D = 1 / E(f.rX),
              I = 1 / E(f.rY),
              k = E(A) * D + E(P) * I,
              w = 2 * P * A * (D - I),
              V = E(P) * D + E(A) * I,
              B = k * h * h - w * u * h + V * u * u,
              N = w * (o * h + u * l) - 2 * (k * l * h + V * o * u),
              j = k * l * l - w * o * l + V * o * o,
              _ = ((Math.atan2(N, B - j) + Math.PI) % Math.PI) / 2,
              q = Math.sin(_),
              U = Math.cos(_);
            ((f.rX = Math.abs(T) / Math.sqrt(B * E(U) + N * q * U + j * E(q))),
              (f.rY = Math.abs(T) / Math.sqrt(B * E(q) - N * q * U + j * E(U))),
              (f.xRot = (180 * _) / Math.PI));
          }
        return (
          f.sweepFlag !== void 0 && 0 > T && (f.sweepFlag = +!f.sweepFlag),
          f
        );
      })
    );
  }
  function s() {
    return function (o) {
      var u = {};
      for (var l in o) u[l] = o[l];
      return u;
    };
  }
  ((n.ROUND = function (o) {
    function u(l) {
      return Math.round(l * o) / o;
    }
    return (
      o === void 0 && (o = 1e13),
      Ce(o),
      function (l) {
        return (
          l.x1 !== void 0 && (l.x1 = u(l.x1)),
          l.y1 !== void 0 && (l.y1 = u(l.y1)),
          l.x2 !== void 0 && (l.x2 = u(l.x2)),
          l.y2 !== void 0 && (l.y2 = u(l.y2)),
          l.x !== void 0 && (l.x = u(l.x)),
          l.y !== void 0 && (l.y = u(l.y)),
          l.rX !== void 0 && (l.rX = u(l.rX)),
          l.rY !== void 0 && (l.rY = u(l.rY)),
          l
        );
      }
    );
  }),
    (n.TO_ABS = e),
    (n.TO_REL = function () {
      return i(function (o, u, l) {
        return (
          o.relative ||
            (o.x1 !== void 0 && (o.x1 -= u),
            o.y1 !== void 0 && (o.y1 -= l),
            o.x2 !== void 0 && (o.x2 -= u),
            o.y2 !== void 0 && (o.y2 -= l),
            o.x !== void 0 && (o.x -= u),
            o.y !== void 0 && (o.y -= l),
            (o.relative = !0)),
          o
        );
      });
    }),
    (n.NORMALIZE_HVZ = function (o, u, l) {
      return (
        o === void 0 && (o = !0),
        u === void 0 && (u = !0),
        l === void 0 && (l = !0),
        i(function (h, c, v, f, g) {
          if (isNaN(f) && !(h.type & O.MOVE_TO))
            throw new Error("path must start with moveto");
          return (
            u &&
              h.type & O.HORIZ_LINE_TO &&
              ((h.type = O.LINE_TO), (h.y = h.relative ? 0 : v)),
            l &&
              h.type & O.VERT_LINE_TO &&
              ((h.type = O.LINE_TO), (h.x = h.relative ? 0 : c)),
            o &&
              h.type & O.CLOSE_PATH &&
              ((h.type = O.LINE_TO),
              (h.x = h.relative ? f - c : f),
              (h.y = h.relative ? g - v : g)),
            h.type & O.ARC &&
              (h.rX === 0 || h.rY === 0) &&
              ((h.type = O.LINE_TO),
              delete h.rX,
              delete h.rY,
              delete h.xRot,
              delete h.lArcFlag,
              delete h.sweepFlag),
            h
          );
        })
      );
    }),
    (n.NORMALIZE_ST = r),
    (n.QT_TO_C = t),
    (n.INFO = i),
    (n.SANITIZE = function (o) {
      (o === void 0 && (o = 0), Ce(o));
      var u = NaN,
        l = NaN,
        h = NaN,
        c = NaN;
      return i(function (v, f, g, d, p) {
        var y = Math.abs,
          m = !1,
          b = 0,
          x = 0;
        if (
          (v.type & O.SMOOTH_CURVE_TO &&
            ((b = isNaN(u) ? 0 : f - u), (x = isNaN(l) ? 0 : g - l)),
          v.type & (O.CURVE_TO | O.SMOOTH_CURVE_TO)
            ? ((u = v.relative ? f + v.x2 : v.x2),
              (l = v.relative ? g + v.y2 : v.y2))
            : ((u = NaN), (l = NaN)),
          v.type & O.SMOOTH_QUAD_TO
            ? ((h = isNaN(h) ? f : 2 * f - h), (c = isNaN(c) ? g : 2 * g - c))
            : v.type & O.QUAD_TO
              ? ((h = v.relative ? f + v.x1 : v.x1),
                (c = v.relative ? g + v.y1 : v.y2))
              : ((h = NaN), (c = NaN)),
          v.type & O.LINE_COMMANDS ||
            (v.type & O.ARC && (v.rX === 0 || v.rY === 0 || !v.lArcFlag)) ||
            v.type & O.CURVE_TO ||
            v.type & O.SMOOTH_CURVE_TO ||
            v.type & O.QUAD_TO ||
            v.type & O.SMOOTH_QUAD_TO)
        ) {
          var S = v.x === void 0 ? 0 : v.relative ? v.x : v.x - f,
            E = v.y === void 0 ? 0 : v.relative ? v.y : v.y - g;
          ((b = isNaN(h)
            ? v.x1 === void 0
              ? b
              : v.relative
                ? v.x
                : v.x1 - f
            : h - f),
            (x = isNaN(c)
              ? v.y1 === void 0
                ? x
                : v.relative
                  ? v.y
                  : v.y1 - g
              : c - g));
          var T = v.x2 === void 0 ? 0 : v.relative ? v.x : v.x2 - f,
            R = v.y2 === void 0 ? 0 : v.relative ? v.y : v.y2 - g;
          y(S) <= o &&
            y(E) <= o &&
            y(b) <= o &&
            y(x) <= o &&
            y(T) <= o &&
            y(R) <= o &&
            (m = !0);
        }
        return (
          v.type & O.CLOSE_PATH && y(f - d) <= o && y(g - p) <= o && (m = !0),
          m ? [] : v
        );
      });
    }),
    (n.MATRIX = a),
    (n.ROTATE = function (o, u, l) {
      (u === void 0 && (u = 0), l === void 0 && (l = 0), Ce(o, u, l));
      var h = Math.sin(o),
        c = Math.cos(o);
      return a(c, h, -h, c, u - u * c + l * h, l - u * h - l * c);
    }),
    (n.TRANSLATE = function (o, u) {
      return (u === void 0 && (u = 0), Ce(o, u), a(1, 0, 0, 1, o, u));
    }),
    (n.SCALE = function (o, u) {
      return (u === void 0 && (u = o), Ce(o, u), a(o, 0, 0, u, 0, 0));
    }),
    (n.SKEW_X = function (o) {
      return (Ce(o), a(1, 0, Math.atan(o), 1, 0, 0));
    }),
    (n.SKEW_Y = function (o) {
      return (Ce(o), a(1, Math.atan(o), 0, 1, 0, 0));
    }),
    (n.X_AXIS_SYMMETRY = function (o) {
      return (o === void 0 && (o = 0), Ce(o), a(-1, 0, 0, 1, o, 0));
    }),
    (n.Y_AXIS_SYMMETRY = function (o) {
      return (o === void 0 && (o = 0), Ce(o), a(1, 0, 0, -1, 0, o));
    }),
    (n.A_TO_C = function () {
      return i(function (o, u, l) {
        return O.ARC === o.type
          ? (function (h, c, v) {
              var f, g, d, p;
              h.cX || Da(h, c, v);
              for (
                var y = Math.min(h.phi1, h.phi2),
                  m = Math.max(h.phi1, h.phi2) - y,
                  b = Math.ceil(m / 90),
                  x = new Array(b),
                  S = c,
                  E = v,
                  T = 0;
                T < b;
                T++
              ) {
                var R = Du(h.phi1, h.phi2, T / b),
                  P = Du(h.phi1, h.phi2, (T + 1) / b),
                  A = P - R,
                  D = (4 / 3) * Math.tan((A * ke) / 4),
                  I = [
                    Math.cos(R * ke) - D * Math.sin(R * ke),
                    Math.sin(R * ke) + D * Math.cos(R * ke),
                  ],
                  k = I[0],
                  w = I[1],
                  V = [Math.cos(P * ke), Math.sin(P * ke)],
                  B = V[0],
                  N = V[1],
                  j = [B + D * Math.sin(P * ke), N - D * Math.cos(P * ke)],
                  _ = j[0],
                  q = j[1];
                x[T] = { relative: h.relative, type: O.CURVE_TO };
                var U = function (L, $) {
                  var X = ja([L * h.rX, $ * h.rY], h.xRot),
                    ae = X[0],
                    oe = X[1];
                  return [h.cX + ae, h.cY + oe];
                };
                ((f = U(k, w)),
                  (x[T].x1 = f[0]),
                  (x[T].y1 = f[1]),
                  (g = U(_, q)),
                  (x[T].x2 = g[0]),
                  (x[T].y2 = g[1]),
                  (d = U(B, N)),
                  (x[T].x = d[0]),
                  (x[T].y = d[1]),
                  h.relative &&
                    ((x[T].x1 -= S),
                    (x[T].y1 -= E),
                    (x[T].x2 -= S),
                    (x[T].y2 -= E),
                    (x[T].x -= S),
                    (x[T].y -= E)),
                  (S = (p = [x[T].x, x[T].y])[0]),
                  (E = p[1]));
              }
              return x;
            })(o, o.relative ? 0 : u, o.relative ? 0 : l)
          : o;
      });
    }),
    (n.ANNOTATE_ARCS = function () {
      return i(function (o, u, l) {
        return (
          o.relative && ((u = 0), (l = 0)),
          O.ARC === o.type && Da(o, u, l),
          o
        );
      });
    }),
    (n.CLONE = s),
    (n.CALCULATE_BOUNDS = function () {
      var o = function (v) {
          var f = {};
          for (var g in v) f[g] = v[g];
          return f;
        },
        u = e(),
        l = t(),
        h = r(),
        c = i(function (v, f, g) {
          var d = h(l(u(o(v))));
          function p(q) {
            (q > c.maxX && (c.maxX = q), q < c.minX && (c.minX = q));
          }
          function y(q) {
            (q > c.maxY && (c.maxY = q), q < c.minY && (c.minY = q));
          }
          if (
            (d.type & O.DRAWING_COMMANDS && (p(f), y(g)),
            d.type & O.HORIZ_LINE_TO && p(d.x),
            d.type & O.VERT_LINE_TO && y(d.y),
            d.type & O.LINE_TO && (p(d.x), y(d.y)),
            d.type & O.CURVE_TO)
          ) {
            (p(d.x), y(d.y));
            for (var m = 0, b = Lu(f, d.x1, d.x2, d.x); m < b.length; m++)
              0 < (_ = b[m]) && 1 > _ && p(ku(f, d.x1, d.x2, d.x, _));
            for (var x = 0, S = Lu(g, d.y1, d.y2, d.y); x < S.length; x++)
              0 < (_ = S[x]) && 1 > _ && y(ku(g, d.y1, d.y2, d.y, _));
          }
          if (d.type & O.ARC) {
            (p(d.x), y(d.y), Da(d, f, g));
            for (
              var E = (d.xRot / 180) * Math.PI,
                T = Math.cos(E) * d.rX,
                R = Math.sin(E) * d.rX,
                P = -Math.sin(E) * d.rY,
                A = Math.cos(E) * d.rY,
                D =
                  d.phi1 < d.phi2
                    ? [d.phi1, d.phi2]
                    : -180 > d.phi2
                      ? [d.phi2 + 360, d.phi1 + 360]
                      : [d.phi2, d.phi1],
                I = D[0],
                k = D[1],
                w = function (q) {
                  var U = q[0],
                    L = q[1],
                    $ = (180 * Math.atan2(L, U)) / Math.PI;
                  return $ < I ? $ + 360 : $;
                },
                V = 0,
                B = qu(P, -T, 0).map(w);
              V < B.length;
              V++
            )
              (_ = B[V]) > I && _ < k && p(Vu(d.cX, T, P, _));
            for (var N = 0, j = qu(A, -R, 0).map(w); N < j.length; N++) {
              var _;
              (_ = j[N]) > I && _ < k && y(Vu(d.cY, R, A, _));
            }
          }
          return v;
        });
      return (
        (c.minX = 1 / 0),
        (c.maxX = -1 / 0),
        (c.minY = 1 / 0),
        (c.maxY = -1 / 0),
        c
      );
    }));
})(ie || (ie = {}));
var Re,
  Vl = (function () {
    function n() {}
    return (
      (n.prototype.round = function (e) {
        return this.transform(ie.ROUND(e));
      }),
      (n.prototype.toAbs = function () {
        return this.transform(ie.TO_ABS());
      }),
      (n.prototype.toRel = function () {
        return this.transform(ie.TO_REL());
      }),
      (n.prototype.normalizeHVZ = function (e, r, t) {
        return this.transform(ie.NORMALIZE_HVZ(e, r, t));
      }),
      (n.prototype.normalizeST = function () {
        return this.transform(ie.NORMALIZE_ST());
      }),
      (n.prototype.qtToC = function () {
        return this.transform(ie.QT_TO_C());
      }),
      (n.prototype.aToC = function () {
        return this.transform(ie.A_TO_C());
      }),
      (n.prototype.sanitize = function (e) {
        return this.transform(ie.SANITIZE(e));
      }),
      (n.prototype.translate = function (e, r) {
        return this.transform(ie.TRANSLATE(e, r));
      }),
      (n.prototype.scale = function (e, r) {
        return this.transform(ie.SCALE(e, r));
      }),
      (n.prototype.rotate = function (e, r, t) {
        return this.transform(ie.ROTATE(e, r, t));
      }),
      (n.prototype.matrix = function (e, r, t, i, a, s) {
        return this.transform(ie.MATRIX(e, r, t, i, a, s));
      }),
      (n.prototype.skewX = function (e) {
        return this.transform(ie.SKEW_X(e));
      }),
      (n.prototype.skewY = function (e) {
        return this.transform(ie.SKEW_Y(e));
      }),
      (n.prototype.xSymmetry = function (e) {
        return this.transform(ie.X_AXIS_SYMMETRY(e));
      }),
      (n.prototype.ySymmetry = function (e) {
        return this.transform(ie.Y_AXIS_SYMMETRY(e));
      }),
      (n.prototype.annotateArcs = function () {
        return this.transform(ie.ANNOTATE_ARCS());
      }),
      n
    );
  })(),
  xf = function (n) {
    return (
      n === " " ||
      n === "	" ||
      n === "\r" ||
      n ===
        `
`
    );
  },
  ju = function (n) {
    return 48 <= n.charCodeAt(0) && n.charCodeAt(0) <= 57;
  },
  Of = (function (n) {
    function e() {
      var r = n.call(this) || this;
      return (
        (r.curNumber = ""),
        (r.curCommandType = -1),
        (r.curCommandRelative = !1),
        (r.canParseCommandOrComma = !0),
        (r.curNumberHasExp = !1),
        (r.curNumberHasExpDigits = !1),
        (r.curNumberHasDecimal = !1),
        (r.curArgs = []),
        r
      );
    }
    return (
      Dl(e, n),
      (e.prototype.finish = function (r) {
        if (
          (r === void 0 && (r = []),
          this.parse(" ", r),
          this.curArgs.length !== 0 || !this.canParseCommandOrComma)
        )
          throw new SyntaxError("Unterminated command at the path end.");
        return r;
      }),
      (e.prototype.parse = function (r, t) {
        var i = this;
        t === void 0 && (t = []);
        for (
          var a = function (c) {
              (t.push(c),
                (i.curArgs.length = 0),
                (i.canParseCommandOrComma = !0));
            },
            s = 0;
          s < r.length;
          s++
        ) {
          var o = r[s],
            u = !(
              this.curCommandType !== O.ARC ||
              (this.curArgs.length !== 3 && this.curArgs.length !== 4) ||
              this.curNumber.length !== 1 ||
              (this.curNumber !== "0" && this.curNumber !== "1")
            ),
            l = ju(o) && ((this.curNumber === "0" && o === "0") || u);
          if (!ju(o) || l)
            if (o !== "e" && o !== "E")
              if (
                (o !== "-" && o !== "+") ||
                !this.curNumberHasExp ||
                this.curNumberHasExpDigits
              )
                if (
                  o !== "." ||
                  this.curNumberHasExp ||
                  this.curNumberHasDecimal ||
                  u
                ) {
                  if (this.curNumber && this.curCommandType !== -1) {
                    var h = Number(this.curNumber);
                    if (isNaN(h))
                      throw new SyntaxError("Invalid number ending at " + s);
                    if (this.curCommandType === O.ARC) {
                      if (
                        this.curArgs.length === 0 ||
                        this.curArgs.length === 1
                      ) {
                        if (0 > h)
                          throw new SyntaxError(
                            'Expected positive number, got "' +
                              h +
                              '" at index "' +
                              s +
                              '"',
                          );
                      } else if (
                        (this.curArgs.length === 3 ||
                          this.curArgs.length === 4) &&
                        this.curNumber !== "0" &&
                        this.curNumber !== "1"
                      )
                        throw new SyntaxError(
                          'Expected a flag, got "' +
                            this.curNumber +
                            '" at index "' +
                            s +
                            '"',
                        );
                    }
                    (this.curArgs.push(h),
                      this.curArgs.length === Tf[this.curCommandType] &&
                        (O.HORIZ_LINE_TO === this.curCommandType
                          ? a({
                              type: O.HORIZ_LINE_TO,
                              relative: this.curCommandRelative,
                              x: h,
                            })
                          : O.VERT_LINE_TO === this.curCommandType
                            ? a({
                                type: O.VERT_LINE_TO,
                                relative: this.curCommandRelative,
                                y: h,
                              })
                            : this.curCommandType === O.MOVE_TO ||
                                this.curCommandType === O.LINE_TO ||
                                this.curCommandType === O.SMOOTH_QUAD_TO
                              ? (a({
                                  type: this.curCommandType,
                                  relative: this.curCommandRelative,
                                  x: this.curArgs[0],
                                  y: this.curArgs[1],
                                }),
                                O.MOVE_TO === this.curCommandType &&
                                  (this.curCommandType = O.LINE_TO))
                              : this.curCommandType === O.CURVE_TO
                                ? a({
                                    type: O.CURVE_TO,
                                    relative: this.curCommandRelative,
                                    x1: this.curArgs[0],
                                    y1: this.curArgs[1],
                                    x2: this.curArgs[2],
                                    y2: this.curArgs[3],
                                    x: this.curArgs[4],
                                    y: this.curArgs[5],
                                  })
                                : this.curCommandType === O.SMOOTH_CURVE_TO
                                  ? a({
                                      type: O.SMOOTH_CURVE_TO,
                                      relative: this.curCommandRelative,
                                      x2: this.curArgs[0],
                                      y2: this.curArgs[1],
                                      x: this.curArgs[2],
                                      y: this.curArgs[3],
                                    })
                                  : this.curCommandType === O.QUAD_TO
                                    ? a({
                                        type: O.QUAD_TO,
                                        relative: this.curCommandRelative,
                                        x1: this.curArgs[0],
                                        y1: this.curArgs[1],
                                        x: this.curArgs[2],
                                        y: this.curArgs[3],
                                      })
                                    : this.curCommandType === O.ARC &&
                                      a({
                                        type: O.ARC,
                                        relative: this.curCommandRelative,
                                        rX: this.curArgs[0],
                                        rY: this.curArgs[1],
                                        xRot: this.curArgs[2],
                                        lArcFlag: this.curArgs[3],
                                        sweepFlag: this.curArgs[4],
                                        x: this.curArgs[5],
                                        y: this.curArgs[6],
                                      })),
                      (this.curNumber = ""),
                      (this.curNumberHasExpDigits = !1),
                      (this.curNumberHasExp = !1),
                      (this.curNumberHasDecimal = !1),
                      (this.canParseCommandOrComma = !0));
                  }
                  if (!xf(o))
                    if (o === "," && this.canParseCommandOrComma)
                      this.canParseCommandOrComma = !1;
                    else if (o !== "+" && o !== "-" && o !== ".")
                      if (l)
                        ((this.curNumber = o), (this.curNumberHasDecimal = !1));
                      else {
                        if (this.curArgs.length !== 0)
                          throw new SyntaxError(
                            "Unterminated command at index " + s + ".",
                          );
                        if (!this.canParseCommandOrComma)
                          throw new SyntaxError(
                            'Unexpected character "' +
                              o +
                              '" at index ' +
                              s +
                              ". Command cannot follow comma",
                          );
                        if (
                          ((this.canParseCommandOrComma = !1),
                          o !== "z" && o !== "Z")
                        )
                          if (o === "h" || o === "H")
                            ((this.curCommandType = O.HORIZ_LINE_TO),
                              (this.curCommandRelative = o === "h"));
                          else if (o === "v" || o === "V")
                            ((this.curCommandType = O.VERT_LINE_TO),
                              (this.curCommandRelative = o === "v"));
                          else if (o === "m" || o === "M")
                            ((this.curCommandType = O.MOVE_TO),
                              (this.curCommandRelative = o === "m"));
                          else if (o === "l" || o === "L")
                            ((this.curCommandType = O.LINE_TO),
                              (this.curCommandRelative = o === "l"));
                          else if (o === "c" || o === "C")
                            ((this.curCommandType = O.CURVE_TO),
                              (this.curCommandRelative = o === "c"));
                          else if (o === "s" || o === "S")
                            ((this.curCommandType = O.SMOOTH_CURVE_TO),
                              (this.curCommandRelative = o === "s"));
                          else if (o === "q" || o === "Q")
                            ((this.curCommandType = O.QUAD_TO),
                              (this.curCommandRelative = o === "q"));
                          else if (o === "t" || o === "T")
                            ((this.curCommandType = O.SMOOTH_QUAD_TO),
                              (this.curCommandRelative = o === "t"));
                          else {
                            if (o !== "a" && o !== "A")
                              throw new SyntaxError(
                                'Unexpected character "' +
                                  o +
                                  '" at index ' +
                                  s +
                                  ".",
                              );
                            ((this.curCommandType = O.ARC),
                              (this.curCommandRelative = o === "a"));
                          }
                        else
                          (t.push({ type: O.CLOSE_PATH }),
                            (this.canParseCommandOrComma = !0),
                            (this.curCommandType = -1));
                      }
                    else
                      ((this.curNumber = o),
                        (this.curNumberHasDecimal = o === "."));
                } else ((this.curNumber += o), (this.curNumberHasDecimal = !0));
              else this.curNumber += o;
            else ((this.curNumber += o), (this.curNumberHasExp = !0));
          else
            ((this.curNumber += o),
              (this.curNumberHasExpDigits = this.curNumberHasExp));
        }
        return t;
      }),
      (e.prototype.transform = function (r) {
        return Object.create(this, {
          parse: {
            value: function (t, i) {
              i === void 0 && (i = []);
              for (
                var a = 0, s = Object.getPrototypeOf(this).parse.call(this, t);
                a < s.length;
                a++
              ) {
                var o = s[a],
                  u = r(o);
                Array.isArray(u) ? i.push.apply(i, u) : i.push(u);
              }
              return i;
            },
          },
        });
      }),
      e
    );
  })(Vl),
  O = (function (n) {
    function e(r) {
      var t = n.call(this) || this;
      return ((t.commands = typeof r == "string" ? e.parse(r) : r), t);
    }
    return (
      Dl(e, n),
      (e.prototype.encode = function () {
        return e.encode(this.commands);
      }),
      (e.prototype.getBounds = function () {
        var r = ie.CALCULATE_BOUNDS();
        return (this.transform(r), r);
      }),
      (e.prototype.transform = function (r) {
        for (var t = [], i = 0, a = this.commands; i < a.length; i++) {
          var s = r(a[i]);
          Array.isArray(s) ? t.push.apply(t, s) : t.push(s);
        }
        return ((this.commands = t), this);
      }),
      (e.encode = function (r) {
        return bf(r);
      }),
      (e.parse = function (r) {
        var t = new Of(),
          i = [];
        return (t.parse(r, i), t.finish(i), i);
      }),
      (e.CLOSE_PATH = 1),
      (e.MOVE_TO = 2),
      (e.HORIZ_LINE_TO = 4),
      (e.VERT_LINE_TO = 8),
      (e.LINE_TO = 16),
      (e.CURVE_TO = 32),
      (e.SMOOTH_CURVE_TO = 64),
      (e.QUAD_TO = 128),
      (e.SMOOTH_QUAD_TO = 256),
      (e.ARC = 512),
      (e.LINE_COMMANDS = e.LINE_TO | e.HORIZ_LINE_TO | e.VERT_LINE_TO),
      (e.DRAWING_COMMANDS =
        e.HORIZ_LINE_TO |
        e.VERT_LINE_TO |
        e.LINE_TO |
        e.CURVE_TO |
        e.SMOOTH_CURVE_TO |
        e.QUAD_TO |
        e.SMOOTH_QUAD_TO |
        e.ARC),
      e
    );
  })(Vl),
  Tf =
    (((Re = {})[O.MOVE_TO] = 2),
    (Re[O.LINE_TO] = 2),
    (Re[O.HORIZ_LINE_TO] = 1),
    (Re[O.VERT_LINE_TO] = 1),
    (Re[O.CLOSE_PATH] = 0),
    (Re[O.QUAD_TO] = 4),
    (Re[O.SMOOTH_QUAD_TO] = 2),
    (Re[O.CURVE_TO] = 6),
    (Re[O.SMOOTH_CURVE_TO] = 4),
    (Re[O.ARC] = 7),
    Re),
  Bu = {},
  Fu;
function Sf() {
  if (Fu) return Bu;
  Fu = 1;
  var n = Vr().PROPER,
    e = tr(),
    r = he(),
    t = qe(),
    i = Z(),
    a = $r(),
    s = "toString",
    o = RegExp.prototype,
    u = o[s],
    l = i(function () {
      return u.call({ source: "a", flags: "b" }) !== "/a/b";
    }),
    h = n && u.name !== s;
  return (
    (l || h) &&
      e(
        o,
        s,
        function () {
          var v = r(this),
            f = t(v.source),
            g = t(a(v));
          return "/" + f + "/" + g;
        },
        { unsafe: !0 },
      ),
    Bu
  );
}
Sf();
function Pr(n) {
  "@babel/helpers - typeof";
  return (
    typeof Symbol == "function" && typeof Symbol.iterator == "symbol"
      ? (Pr = function (e) {
          return typeof e;
        })
      : (Pr = function (e) {
          return e &&
            typeof Symbol == "function" &&
            e.constructor === Symbol &&
            e !== Symbol.prototype
            ? "symbol"
            : typeof e;
        }),
    Pr(n)
  );
}
function Ef(n, e) {
  if (!(n instanceof e))
    throw new TypeError("Cannot call a class as a function");
}
var Rf = [
    512, 512, 456, 512, 328, 456, 335, 512, 405, 328, 271, 456, 388, 335, 292,
    512, 454, 405, 364, 328, 298, 271, 496, 456, 420, 388, 360, 335, 312, 292,
    273, 512, 482, 454, 428, 405, 383, 364, 345, 328, 312, 298, 284, 271, 259,
    496, 475, 456, 437, 420, 404, 388, 374, 360, 347, 335, 323, 312, 302, 292,
    282, 273, 265, 512, 497, 482, 468, 454, 441, 428, 417, 405, 394, 383, 373,
    364, 354, 345, 337, 328, 320, 312, 305, 298, 291, 284, 278, 271, 265, 259,
    507, 496, 485, 475, 465, 456, 446, 437, 428, 420, 412, 404, 396, 388, 381,
    374, 367, 360, 354, 347, 341, 335, 329, 323, 318, 312, 307, 302, 297, 292,
    287, 282, 278, 273, 269, 265, 261, 512, 505, 497, 489, 482, 475, 468, 461,
    454, 447, 441, 435, 428, 422, 417, 411, 405, 399, 394, 389, 383, 378, 373,
    368, 364, 359, 354, 350, 345, 341, 337, 332, 328, 324, 320, 316, 312, 309,
    305, 301, 298, 294, 291, 287, 284, 281, 278, 274, 271, 268, 265, 262, 259,
    257, 507, 501, 496, 491, 485, 480, 475, 470, 465, 460, 456, 451, 446, 442,
    437, 433, 428, 424, 420, 416, 412, 408, 404, 400, 396, 392, 388, 385, 381,
    377, 374, 370, 367, 363, 360, 357, 354, 350, 347, 344, 341, 338, 335, 332,
    329, 326, 323, 320, 318, 315, 312, 310, 307, 304, 302, 299, 297, 294, 292,
    289, 287, 285, 282, 280, 278, 275, 273, 271, 269, 267, 265, 263, 261, 259,
  ],
  Cf = [
    9, 11, 12, 13, 13, 14, 14, 15, 15, 15, 15, 16, 16, 16, 16, 17, 17, 17, 17,
    17, 17, 17, 18, 18, 18, 18, 18, 18, 18, 18, 18, 19, 19, 19, 19, 19, 19, 19,
    19, 19, 19, 19, 19, 19, 19, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20,
    20, 20, 20, 20, 20, 20, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21,
    21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 22, 22, 22, 22, 22,
    22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22,
    22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 23, 23, 23, 23, 23, 23,
    23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23,
    23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23,
    23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 24, 24, 24, 24, 24, 24, 24, 24, 24,
    24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24,
    24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24,
    24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24,
    24, 24, 24, 24, 24, 24, 24, 24,
  ];
function wf(n, e, r, t, i) {
  if (
    (typeof n == "string" && (n = document.getElementById(n)),
    !n || Pr(n) !== "object" || !("getContext" in n))
  )
    throw new TypeError(
      "Expecting canvas with `getContext` method in processCanvasRGB(A) calls!",
    );
  var a = n.getContext("2d");
  try {
    return a.getImageData(e, r, t, i);
  } catch (s) {
    throw new Error("unable to access image data: " + s);
  }
}
function Pf(n, e, r, t, i, a) {
  if (!(isNaN(a) || a < 1)) {
    a |= 0;
    var s = wf(n, e, r, t, i);
    ((s = Af(s, e, r, t, i, a)), n.getContext("2d").putImageData(s, e, r));
  }
}
function Af(n, e, r, t, i, a) {
  for (
    var s = n.data,
      o = 2 * a + 1,
      u = t - 1,
      l = i - 1,
      h = a + 1,
      c = (h * (h + 1)) / 2,
      v = new Uu(),
      f = v,
      g,
      d = 1;
    d < o;
    d++
  )
    ((f = f.next = new Uu()), d === h && (g = f));
  f.next = v;
  for (
    var p = null, y = null, m = 0, b = 0, x = Rf[a], S = Cf[a], E = 0;
    E < i;
    E++
  ) {
    f = v;
    for (
      var T = s[b], R = s[b + 1], P = s[b + 2], A = s[b + 3], D = 0;
      D < h;
      D++
    )
      ((f.r = T), (f.g = R), (f.b = P), (f.a = A), (f = f.next));
    for (
      var I = 0,
        k = 0,
        w = 0,
        V = 0,
        B = h * T,
        N = h * R,
        j = h * P,
        _ = h * A,
        q = c * T,
        U = c * R,
        L = c * P,
        $ = c * A,
        X = 1;
      X < h;
      X++
    ) {
      var ae = b + ((u < X ? u : X) << 2),
        oe = s[ae],
        ue = s[ae + 1],
        Fe = s[ae + 2],
        Ue = s[ae + 3],
        ce = h - X;
      ((q += (f.r = oe) * ce),
        (U += (f.g = ue) * ce),
        (L += (f.b = Fe) * ce),
        ($ += (f.a = Ue) * ce),
        (I += oe),
        (k += ue),
        (w += Fe),
        (V += Ue),
        (f = f.next));
    }
    ((p = v), (y = g));
    for (var Ne = 0; Ne < t; Ne++) {
      var _e = ($ * x) >>> S;
      if (((s[b + 3] = _e), _e !== 0)) {
        var be = 255 / _e;
        ((s[b] = ((q * x) >>> S) * be),
          (s[b + 1] = ((U * x) >>> S) * be),
          (s[b + 2] = ((L * x) >>> S) * be));
      } else s[b] = s[b + 1] = s[b + 2] = 0;
      ((q -= B),
        (U -= N),
        (L -= j),
        ($ -= _),
        (B -= p.r),
        (N -= p.g),
        (j -= p.b),
        (_ -= p.a));
      var ve = Ne + a + 1;
      ((ve = (m + (ve < u ? ve : u)) << 2),
        (I += p.r = s[ve]),
        (k += p.g = s[ve + 1]),
        (w += p.b = s[ve + 2]),
        (V += p.a = s[ve + 3]),
        (q += I),
        (U += k),
        (L += w),
        ($ += V),
        (p = p.next));
      var xe = y,
        De = xe.r,
        Ve = xe.g,
        Ke = xe.b,
        ur = xe.a;
      ((B += De),
        (N += Ve),
        (j += Ke),
        (_ += ur),
        (I -= De),
        (k -= Ve),
        (w -= Ke),
        (V -= ur),
        (y = y.next),
        (b += 4));
    }
    m += t;
  }
  for (var Ge = 0; Ge < t; Ge++) {
    b = Ge << 2;
    var ge = s[b],
      de = s[b + 1],
      Oe = s[b + 2],
      C = s[b + 3],
      F = h * ge,
      z = h * de,
      H = h * Oe,
      W = h * C,
      Te = c * ge,
      Le = c * de,
      Se = c * Oe,
      Ee = c * C;
    f = v;
    for (var lr = 0; lr < h; lr++)
      ((f.r = ge), (f.g = de), (f.b = Oe), (f.a = C), (f = f.next));
    for (var hr = t, fr = 0, Xr = 0, Kr = 0, Qr = 0, Sr = 1; Sr <= a; Sr++) {
      b = (hr + Ge) << 2;
      var Er = h - Sr;
      ((Te += (f.r = ge = s[b]) * Er),
        (Le += (f.g = de = s[b + 1]) * Er),
        (Se += (f.b = Oe = s[b + 2]) * Er),
        (Ee += (f.a = C = s[b + 3]) * Er),
        (Qr += ge),
        (fr += de),
        (Xr += Oe),
        (Kr += C),
        (f = f.next),
        Sr < l && (hr += t));
    }
    ((b = Ge), (p = v), (y = g));
    for (var Zr = 0; Zr < i; Zr++) {
      var pe = b << 2;
      ((s[pe + 3] = C = (Ee * x) >>> S),
        C > 0
          ? ((C = 255 / C),
            (s[pe] = ((Te * x) >>> S) * C),
            (s[pe + 1] = ((Le * x) >>> S) * C),
            (s[pe + 2] = ((Se * x) >>> S) * C))
          : (s[pe] = s[pe + 1] = s[pe + 2] = 0),
        (Te -= F),
        (Le -= z),
        (Se -= H),
        (Ee -= W),
        (F -= p.r),
        (z -= p.g),
        (H -= p.b),
        (W -= p.a),
        (pe = (Ge + ((pe = Zr + h) < l ? pe : l) * t) << 2),
        (Te += Qr += p.r = s[pe]),
        (Le += fr += p.g = s[pe + 1]),
        (Se += Xr += p.b = s[pe + 2]),
        (Ee += Kr += p.a = s[pe + 3]),
        (p = p.next),
        (F += ge = y.r),
        (z += de = y.g),
        (H += Oe = y.b),
        (W += C = y.a),
        (Qr -= ge),
        (fr -= de),
        (Xr -= Oe),
        (Kr -= C),
        (y = y.next),
        (b += t));
    }
  }
  return n;
}
var Uu = function n() {
  (Ef(this, n),
    (this.r = 0),
    (this.g = 0),
    (this.b = 0),
    (this.a = 0),
    (this.next = null));
};
function If() {
  var { DOMParser: n } =
      arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {},
    e = {
      window: null,
      ignoreAnimation: !0,
      ignoreMouse: !0,
      DOMParser: n,
      createCanvas(r, t) {
        return new OffscreenCanvas(r, t);
      },
      createImage(r) {
        return Be(function* () {
          var t = yield fetch(r),
            i = yield t.blob(),
            a = yield createImageBitmap(i);
          return a;
        })();
      },
    };
  return (
    (typeof DOMParser < "u" || typeof n > "u") &&
      Reflect.deleteProperty(e, "DOMParser"),
    e
  );
}
function Nf(n) {
  var { DOMParser: e, canvas: r, fetch: t } = n;
  return {
    window: null,
    ignoreAnimation: !0,
    ignoreMouse: !0,
    DOMParser: e,
    fetch: t,
    createCanvas: r.createCanvas,
    createImage: r.loadImage,
  };
}
var Gc = Object.freeze({ __proto__: null, offscreen: If, node: Nf });
function or(n) {
  return n.replace(/(?!\u3000)\s+/gm, " ");
}
function _f(n) {
  return n.replace(/^[\n \t]+/, "");
}
function Mf(n) {
  return n.replace(/[\n \t]+$/, "");
}
function me(n) {
  var e =
    (n || "").match(/-?(\d+(?:\.\d*(?:[eE][+-]?\d+)?)?|\.\d+)(?=\D|$)/gm) || [];
  return e.map(parseFloat);
}
var qf = /^[A-Z-]+$/;
function Df(n) {
  return qf.test(n) ? n.toLowerCase() : n;
}
function Ll(n) {
  var e = /url\(('([^']+)'|"([^"]+)"|([^'")]+))\)/.exec(n) || [];
  return e[2] || e[3] || e[4];
}
function Vf(n) {
  if (!n.startsWith("rgb")) return n;
  var e = 3,
    r = n.replace(/\d+(\.\d+)?/g, (t, i) =>
      e-- && i ? String(Math.round(parseFloat(t))) : t,
    );
  return r;
}
var Lf = /(\[[^\]]+\])/g,
  kf = /(#[^\s+>~.[:]+)/g,
  jf = /(\.[^\s+>~.[:]+)/g,
  Bf = /(::[^\s+>~.[:]+|:first-line|:first-letter|:before|:after)/gi,
  Ff = /(:[\w-]+\([^)]*\))/gi,
  Uf = /(:[^\s+>~.[:]+)/g,
  Gf = /([^\s+>~.[:]+)/g;
function Qe(n, e) {
  var r = e.exec(n);
  return r ? [n.replace(e, " "), r.length] : [n, 0];
}
function $f(n) {
  var e = [0, 0, 0],
    r = n.replace(/:not\(([^)]*)\)/g, "     $1 ").replace(/{[\s\S]*/gm, " "),
    t = 0;
  return (
    ([r, t] = Qe(r, Lf)),
    (e[1] += t),
    ([r, t] = Qe(r, kf)),
    (e[0] += t),
    ([r, t] = Qe(r, jf)),
    (e[1] += t),
    ([r, t] = Qe(r, Bf)),
    (e[2] += t),
    ([r, t] = Qe(r, Ff)),
    (e[1] += t),
    ([r, t] = Qe(r, Uf)),
    (e[1] += t),
    (r = r.replace(/[*\s+>~]/g, " ").replace(/[#.]/g, " ")),
    ([r, t] = Qe(r, Gf)),
    (e[2] += t),
    e.join("")
  );
}
var ar = 1e-8;
function Gu(n) {
  return Math.sqrt(Math.pow(n[0], 2) + Math.pow(n[1], 2));
}
function Ba(n, e) {
  return (n[0] * e[0] + n[1] * e[1]) / (Gu(n) * Gu(e));
}
function $u(n, e) {
  return (n[0] * e[1] < n[1] * e[0] ? -1 : 1) * Math.acos(Ba(n, e));
}
function zu(n) {
  return n * n * n;
}
function Hu(n) {
  return 3 * n * n * (1 - n);
}
function Wu(n) {
  return 3 * n * (1 - n) * (1 - n);
}
function Yu(n) {
  return (1 - n) * (1 - n) * (1 - n);
}
function Xu(n) {
  return n * n;
}
function Ku(n) {
  return 2 * n * (1 - n);
}
function Qu(n) {
  return (1 - n) * (1 - n);
}
class M {
  constructor(e, r, t) {
    ((this.document = e),
      (this.name = r),
      (this.value = t),
      (this.isNormalizedColor = !1));
  }
  static empty(e) {
    return new M(e, "EMPTY", "");
  }
  split() {
    var e =
        arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : " ",
      { document: r, name: t } = this;
    return or(this.getString())
      .trim()
      .split(e)
      .map((i) => new M(r, t, i));
  }
  hasValue(e) {
    var { value: r } = this;
    return r !== null && r !== "" && (e || r !== 0) && typeof r < "u";
  }
  isString(e) {
    var { value: r } = this,
      t = typeof r == "string";
    return !t || !e ? t : e.test(r);
  }
  isUrlDefinition() {
    return this.isString(/^url\(/);
  }
  isPixels() {
    if (!this.hasValue()) return !1;
    var e = this.getString();
    switch (!0) {
      case e.endsWith("px"):
      case /^[0-9]+$/.test(e):
        return !0;
      default:
        return !1;
    }
  }
  setValue(e) {
    return ((this.value = e), this);
  }
  getValue(e) {
    return typeof e > "u" || this.hasValue() ? this.value : e;
  }
  getNumber(e) {
    if (!this.hasValue()) return typeof e > "u" ? 0 : parseFloat(e);
    var { value: r } = this,
      t = parseFloat(r);
    return (this.isString(/%$/) && (t /= 100), t);
  }
  getString(e) {
    return typeof e > "u" || this.hasValue()
      ? typeof this.value > "u"
        ? ""
        : String(this.value)
      : String(e);
  }
  getColor(e) {
    var r = this.getString(e);
    return (
      this.isNormalizedColor ||
        ((this.isNormalizedColor = !0), (r = Vf(r)), (this.value = r)),
      r
    );
  }
  getDpi() {
    return 96;
  }
  getRem() {
    return this.document.rootEmSize;
  }
  getEm() {
    return this.document.emSize;
  }
  getUnits() {
    return this.getString().replace(/[0-9.-]/g, "");
  }
  getPixels(e) {
    var r = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !1;
    if (!this.hasValue()) return 0;
    var [t, i] = typeof e == "boolean" ? [void 0, e] : [e],
      { viewPort: a } = this.document.screen;
    switch (!0) {
      case this.isString(/vmin$/):
        return (
          (this.getNumber() / 100) *
          Math.min(a.computeSize("x"), a.computeSize("y"))
        );
      case this.isString(/vmax$/):
        return (
          (this.getNumber() / 100) *
          Math.max(a.computeSize("x"), a.computeSize("y"))
        );
      case this.isString(/vw$/):
        return (this.getNumber() / 100) * a.computeSize("x");
      case this.isString(/vh$/):
        return (this.getNumber() / 100) * a.computeSize("y");
      case this.isString(/rem$/):
        return this.getNumber() * this.getRem();
      case this.isString(/em$/):
        return this.getNumber() * this.getEm();
      case this.isString(/ex$/):
        return (this.getNumber() * this.getEm()) / 2;
      case this.isString(/px$/):
        return this.getNumber();
      case this.isString(/pt$/):
        return this.getNumber() * this.getDpi() * (1 / 72);
      case this.isString(/pc$/):
        return this.getNumber() * 15;
      case this.isString(/cm$/):
        return (this.getNumber() * this.getDpi()) / 2.54;
      case this.isString(/mm$/):
        return (this.getNumber() * this.getDpi()) / 25.4;
      case this.isString(/in$/):
        return this.getNumber() * this.getDpi();
      case this.isString(/%$/) && i:
        return this.getNumber() * this.getEm();
      case this.isString(/%$/):
        return this.getNumber() * a.computeSize(t);
      default: {
        var s = this.getNumber();
        return r && s < 1 ? s * a.computeSize(t) : s;
      }
    }
  }
  getMilliseconds() {
    return this.hasValue()
      ? this.isString(/ms$/)
        ? this.getNumber()
        : this.getNumber() * 1e3
      : 0;
  }
  getRadians() {
    if (!this.hasValue()) return 0;
    switch (!0) {
      case this.isString(/deg$/):
        return this.getNumber() * (Math.PI / 180);
      case this.isString(/grad$/):
        return this.getNumber() * (Math.PI / 200);
      case this.isString(/rad$/):
        return this.getNumber();
      default:
        return this.getNumber() * (Math.PI / 180);
    }
  }
  getDefinition() {
    var e = this.getString(),
      r = /#([^)'"]+)/.exec(e);
    return (r && (r = r[1]), r || (r = e), this.document.definitions[r]);
  }
  getFillStyleDefinition(e, r) {
    var t = this.getDefinition();
    if (!t) return null;
    if (typeof t.createGradient == "function")
      return t.createGradient(this.document.ctx, e, r);
    if (typeof t.createPattern == "function") {
      if (t.getHrefAttribute().hasValue()) {
        var i = t.getAttribute("patternTransform");
        ((t = t.getHrefAttribute().getDefinition()),
          i.hasValue() &&
            t.getAttribute("patternTransform", !0).setValue(i.value));
      }
      return t.createPattern(this.document.ctx, e, r);
    }
    return null;
  }
  getTextBaseline() {
    return this.hasValue() ? M.textBaselineMapping[this.getString()] : null;
  }
  addOpacity(e) {
    for (
      var r = this.getColor(), t = r.length, i = 0, a = 0;
      a < t && (r[a] === "," && i++, i !== 3);
      a++
    );
    if (e.hasValue() && this.isString() && i !== 3) {
      var s = new ka(r);
      s.ok && ((s.alpha = e.getNumber()), (r = s.toRGBA()));
    }
    return new M(this.document, this.name, r);
  }
}
M.textBaselineMapping = {
  baseline: "alphabetic",
  "before-edge": "top",
  "text-before-edge": "top",
  middle: "middle",
  central: "middle",
  "after-edge": "bottom",
  "text-after-edge": "bottom",
  ideographic: "ideographic",
  alphabetic: "alphabetic",
  hanging: "hanging",
  mathematical: "alphabetic",
};
class zf {
  constructor() {
    this.viewPorts = [];
  }
  clear() {
    this.viewPorts = [];
  }
  setCurrent(e, r) {
    this.viewPorts.push({ width: e, height: r });
  }
  removeCurrent() {
    this.viewPorts.pop();
  }
  getCurrent() {
    var { viewPorts: e } = this;
    return e[e.length - 1];
  }
  get width() {
    return this.getCurrent().width;
  }
  get height() {
    return this.getCurrent().height;
  }
  computeSize(e) {
    return typeof e == "number"
      ? e
      : e === "x"
        ? this.width
        : e === "y"
          ? this.height
          : Math.sqrt(Math.pow(this.width, 2) + Math.pow(this.height, 2)) /
            Math.sqrt(2);
  }
}
class re {
  constructor(e, r) {
    ((this.x = e), (this.y = r));
  }
  static parse(e) {
    var r = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 0,
      [t = r, i = r] = me(e);
    return new re(t, i);
  }
  static parseScale(e) {
    var r = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 1,
      [t = r, i = t] = me(e);
    return new re(t, i);
  }
  static parsePath(e) {
    for (var r = me(e), t = r.length, i = [], a = 0; a < t; a += 2)
      i.push(new re(r[a], r[a + 1]));
    return i;
  }
  angleTo(e) {
    return Math.atan2(e.y - this.y, e.x - this.x);
  }
  applyTransform(e) {
    var { x: r, y: t } = this,
      i = r * e[0] + t * e[2] + e[4],
      a = r * e[1] + t * e[3] + e[5];
    ((this.x = i), (this.y = a));
  }
}
class Hf {
  constructor(e) {
    ((this.screen = e),
      (this.working = !1),
      (this.events = []),
      (this.eventElements = []),
      (this.onClick = this.onClick.bind(this)),
      (this.onMouseMove = this.onMouseMove.bind(this)));
  }
  isWorking() {
    return this.working;
  }
  start() {
    if (!this.working) {
      var { screen: e, onClick: r, onMouseMove: t } = this,
        i = e.ctx.canvas;
      ((i.onclick = r), (i.onmousemove = t), (this.working = !0));
    }
  }
  stop() {
    if (this.working) {
      var e = this.screen.ctx.canvas;
      ((this.working = !1), (e.onclick = null), (e.onmousemove = null));
    }
  }
  hasEvents() {
    return this.working && this.events.length > 0;
  }
  runEvents() {
    if (this.working) {
      var { screen: e, events: r, eventElements: t } = this,
        { style: i } = e.ctx.canvas;
      (i && (i.cursor = ""),
        r.forEach((a, s) => {
          for (var { run: o } = a, u = t[s]; u;) (o(u), (u = u.parent));
        }),
        (this.events = []),
        (this.eventElements = []));
    }
  }
  checkPath(e, r) {
    if (!(!this.working || !r)) {
      var { events: t, eventElements: i } = this;
      t.forEach((a, s) => {
        var { x: o, y: u } = a;
        !i[s] && r.isPointInPath && r.isPointInPath(o, u) && (i[s] = e);
      });
    }
  }
  checkBoundingBox(e, r) {
    if (!(!this.working || !r)) {
      var { events: t, eventElements: i } = this;
      t.forEach((a, s) => {
        var { x: o, y: u } = a;
        !i[s] && r.isPointInBox(o, u) && (i[s] = e);
      });
    }
  }
  mapXY(e, r) {
    for (
      var { window: t, ctx: i } = this.screen, a = new re(e, r), s = i.canvas;
      s;
    )
      ((a.x -= s.offsetLeft), (a.y -= s.offsetTop), (s = s.offsetParent));
    return (
      t.scrollX && (a.x += t.scrollX),
      t.scrollY && (a.y += t.scrollY),
      a
    );
  }
  onClick(e) {
    var { x: r, y: t } = this.mapXY(e.clientX, e.clientY);
    this.events.push({
      type: "onclick",
      x: r,
      y: t,
      run(i) {
        i.onClick && i.onClick();
      },
    });
  }
  onMouseMove(e) {
    var { x: r, y: t } = this.mapXY(e.clientX, e.clientY);
    this.events.push({
      type: "onmousemove",
      x: r,
      y: t,
      run(i) {
        i.onMouseMove && i.onMouseMove();
      },
    });
  }
}
var kl = typeof window < "u" ? window : null,
  jl = typeof fetch < "u" ? fetch.bind(void 0) : null;
class zr {
  constructor(e) {
    var { fetch: r = jl, window: t = kl } =
      arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
    ((this.ctx = e),
      (this.FRAMERATE = 30),
      (this.MAX_VIRTUAL_PIXELS = 3e4),
      (this.CLIENT_WIDTH = 800),
      (this.CLIENT_HEIGHT = 600),
      (this.viewPort = new zf()),
      (this.mouse = new Hf(this)),
      (this.animations = []),
      (this.waits = []),
      (this.frameDuration = 0),
      (this.isReadyLock = !1),
      (this.isFirstRender = !0),
      (this.intervalId = null),
      (this.window = t),
      (this.fetch = r));
  }
  wait(e) {
    this.waits.push(e);
  }
  ready() {
    return this.readyPromise ? this.readyPromise : Promise.resolve();
  }
  isReady() {
    if (this.isReadyLock) return !0;
    var e = this.waits.every((r) => r());
    return (
      e && ((this.waits = []), this.resolveReady && this.resolveReady()),
      (this.isReadyLock = e),
      e
    );
  }
  setDefaults(e) {
    ((e.strokeStyle = "rgba(0,0,0,0)"),
      (e.lineCap = "butt"),
      (e.lineJoin = "miter"),
      (e.miterLimit = 4));
  }
  setViewBox(e) {
    var {
        document: r,
        ctx: t,
        aspectRatio: i,
        width: a,
        desiredWidth: s,
        height: o,
        desiredHeight: u,
        minX: l = 0,
        minY: h = 0,
        refX: c,
        refY: v,
        clip: f = !1,
        clipX: g = 0,
        clipY: d = 0,
      } = e,
      p = or(i).replace(/^defer\s/, ""),
      [y, m] = p.split(" "),
      b = y || "xMidYMid",
      x = m || "meet",
      S = a / s,
      E = o / u,
      T = Math.min(S, E),
      R = Math.max(S, E),
      P = s,
      A = u;
    (x === "meet" && ((P *= T), (A *= T)),
      x === "slice" && ((P *= R), (A *= R)));
    var D = new M(r, "refX", c),
      I = new M(r, "refY", v),
      k = D.hasValue() && I.hasValue();
    if ((k && t.translate(-T * D.getPixels("x"), -T * I.getPixels("y")), f)) {
      var w = T * g,
        V = T * d;
      (t.beginPath(),
        t.moveTo(w, V),
        t.lineTo(a, V),
        t.lineTo(a, o),
        t.lineTo(w, o),
        t.closePath(),
        t.clip());
    }
    if (!k) {
      var B = x === "meet" && T === E,
        N = x === "slice" && R === E,
        j = x === "meet" && T === S,
        _ = x === "slice" && R === S;
      (b.startsWith("xMid") && (B || N) && t.translate(a / 2 - P / 2, 0),
        b.endsWith("YMid") && (j || _) && t.translate(0, o / 2 - A / 2),
        b.startsWith("xMax") && (B || N) && t.translate(a - P, 0),
        b.endsWith("YMax") && (j || _) && t.translate(0, o - A));
    }
    switch (!0) {
      case b === "none":
        t.scale(S, E);
        break;
      case x === "meet":
        t.scale(T, T);
        break;
      case x === "slice":
        t.scale(R, R);
        break;
    }
    t.translate(-l, -h);
  }
  start(e) {
    var {
        enableRedraw: r = !1,
        ignoreMouse: t = !1,
        ignoreAnimation: i = !1,
        ignoreDimensions: a = !1,
        ignoreClear: s = !1,
        forceRedraw: o,
        scaleWidth: u,
        scaleHeight: l,
        offsetX: h,
        offsetY: c,
      } = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {},
      { FRAMERATE: v, mouse: f } = this,
      g = 1e3 / v;
    if (
      ((this.frameDuration = g),
      (this.readyPromise = new Promise((b) => {
        this.resolveReady = b;
      })),
      this.isReady() && this.render(e, a, s, u, l, h, c),
      !!r)
    ) {
      var d = Date.now(),
        p = d,
        y = 0,
        m = () => {
          ((d = Date.now()),
            (y = d - p),
            y >= g &&
              ((p = d - (y % g)),
              this.shouldUpdate(i, o) &&
                (this.render(e, a, s, u, l, h, c), f.runEvents())),
            (this.intervalId = Aa(m)));
        };
      (t || f.start(), (this.intervalId = Aa(m)));
    }
  }
  stop() {
    (this.intervalId && (Aa.cancel(this.intervalId), (this.intervalId = null)),
      this.mouse.stop());
  }
  shouldUpdate(e, r) {
    if (!e) {
      var { frameDuration: t } = this,
        i = this.animations.reduce((a, s) => s.update(t) || a, !1);
      if (i) return !0;
    }
    return !!(
      (typeof r == "function" && r()) ||
      (!this.isReadyLock && this.isReady()) ||
      this.mouse.hasEvents()
    );
  }
  render(e, r, t, i, a, s, o) {
    var {
        CLIENT_WIDTH: u,
        CLIENT_HEIGHT: l,
        viewPort: h,
        ctx: c,
        isFirstRender: v,
      } = this,
      f = c.canvas;
    (h.clear(),
      f.width && f.height
        ? h.setCurrent(f.width, f.height)
        : h.setCurrent(u, l));
    var g = e.getStyle("width"),
      d = e.getStyle("height");
    !r &&
      (v || (typeof i != "number" && typeof a != "number")) &&
      (g.hasValue() &&
        ((f.width = g.getPixels("x")),
        f.style && (f.style.width = "".concat(f.width, "px"))),
      d.hasValue() &&
        ((f.height = d.getPixels("y")),
        f.style && (f.style.height = "".concat(f.height, "px"))));
    var p = f.clientWidth || f.width,
      y = f.clientHeight || f.height;
    if (
      (r &&
        g.hasValue() &&
        d.hasValue() &&
        ((p = g.getPixels("x")), (y = d.getPixels("y"))),
      h.setCurrent(p, y),
      typeof s == "number" && e.getAttribute("x", !0).setValue(s),
      typeof o == "number" && e.getAttribute("y", !0).setValue(o),
      typeof i == "number" || typeof a == "number")
    ) {
      var m = me(e.getAttribute("viewBox").getString()),
        b = 0,
        x = 0;
      if (typeof i == "number") {
        var S = e.getStyle("width");
        S.hasValue()
          ? (b = S.getPixels("x") / i)
          : isNaN(m[2]) || (b = m[2] / i);
      }
      if (typeof a == "number") {
        var E = e.getStyle("height");
        E.hasValue()
          ? (x = E.getPixels("y") / a)
          : isNaN(m[3]) || (x = m[3] / a);
      }
      (b || (b = x),
        x || (x = b),
        e.getAttribute("width", !0).setValue(i),
        e.getAttribute("height", !0).setValue(a));
      var T = e.getStyle("transform", !0, !0);
      T.setValue(
        ""
          .concat(T.getString(), " scale(")
          .concat(1 / b, ", ")
          .concat(1 / x, ")"),
      );
    }
    (t || c.clearRect(0, 0, p, y), e.render(c), v && (this.isFirstRender = !1));
  }
}
zr.defaultWindow = kl;
zr.defaultFetch = jl;
var { defaultFetch: Wf } = zr,
  Yf = typeof DOMParser < "u" ? DOMParser : null;
class Va {
  constructor() {
    var { fetch: e = Wf, DOMParser: r = Yf } =
      arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    ((this.fetch = e), (this.DOMParser = r));
  }
  parse(e) {
    var r = this;
    return Be(function* () {
      return e.startsWith("<") ? r.parseFromString(e) : r.load(e);
    })();
  }
  parseFromString(e) {
    var r = new this.DOMParser();
    try {
      return this.checkDocument(r.parseFromString(e, "image/svg+xml"));
    } catch {
      return this.checkDocument(r.parseFromString(e, "text/xml"));
    }
  }
  checkDocument(e) {
    var r = e.getElementsByTagName("parsererror")[0];
    if (r) throw new Error(r.textContent);
    return e;
  }
  load(e) {
    var r = this;
    return Be(function* () {
      var t = yield r.fetch(e),
        i = yield t.text();
      return r.parseFromString(i);
    })();
  }
}
class Xf {
  constructor(e, r) {
    ((this.type = "translate"),
      (this.point = null),
      (this.point = re.parse(r)));
  }
  apply(e) {
    var { x: r, y: t } = this.point;
    e.translate(r || 0, t || 0);
  }
  unapply(e) {
    var { x: r, y: t } = this.point;
    e.translate(-1 * r || 0, -1 * t || 0);
  }
  applyToPoint(e) {
    var { x: r, y: t } = this.point;
    e.applyTransform([1, 0, 0, 1, r || 0, t || 0]);
  }
}
class Kf {
  constructor(e, r, t) {
    ((this.type = "rotate"),
      (this.angle = null),
      (this.originX = null),
      (this.originY = null),
      (this.cx = 0),
      (this.cy = 0));
    var i = me(r);
    ((this.angle = new M(e, "angle", i[0])),
      (this.originX = t[0]),
      (this.originY = t[1]),
      (this.cx = i[1] || 0),
      (this.cy = i[2] || 0));
  }
  apply(e) {
    var { cx: r, cy: t, originX: i, originY: a, angle: s } = this,
      o = r + i.getPixels("x"),
      u = t + a.getPixels("y");
    (e.translate(o, u), e.rotate(s.getRadians()), e.translate(-o, -u));
  }
  unapply(e) {
    var { cx: r, cy: t, originX: i, originY: a, angle: s } = this,
      o = r + i.getPixels("x"),
      u = t + a.getPixels("y");
    (e.translate(o, u), e.rotate(-1 * s.getRadians()), e.translate(-o, -u));
  }
  applyToPoint(e) {
    var { cx: r, cy: t, angle: i } = this,
      a = i.getRadians();
    (e.applyTransform([1, 0, 0, 1, r || 0, t || 0]),
      e.applyTransform([
        Math.cos(a),
        Math.sin(a),
        -Math.sin(a),
        Math.cos(a),
        0,
        0,
      ]),
      e.applyTransform([1, 0, 0, 1, -r || 0, -t || 0]));
  }
}
class Qf {
  constructor(e, r, t) {
    ((this.type = "scale"),
      (this.scale = null),
      (this.originX = null),
      (this.originY = null));
    var i = re.parseScale(r);
    ((i.x === 0 || i.y === 0) && ((i.x = ar), (i.y = ar)),
      (this.scale = i),
      (this.originX = t[0]),
      (this.originY = t[1]));
  }
  apply(e) {
    var {
        scale: { x: r, y: t },
        originX: i,
        originY: a,
      } = this,
      s = i.getPixels("x"),
      o = a.getPixels("y");
    (e.translate(s, o), e.scale(r, t || r), e.translate(-s, -o));
  }
  unapply(e) {
    var {
        scale: { x: r, y: t },
        originX: i,
        originY: a,
      } = this,
      s = i.getPixels("x"),
      o = a.getPixels("y");
    (e.translate(s, o), e.scale(1 / r, 1 / t || r), e.translate(-s, -o));
  }
  applyToPoint(e) {
    var { x: r, y: t } = this.scale;
    e.applyTransform([r || 0, 0, 0, t || 0, 0, 0]);
  }
}
class Bl {
  constructor(e, r, t) {
    ((this.type = "matrix"),
      (this.matrix = []),
      (this.originX = null),
      (this.originY = null),
      (this.matrix = me(r)),
      (this.originX = t[0]),
      (this.originY = t[1]));
  }
  apply(e) {
    var { originX: r, originY: t, matrix: i } = this,
      a = r.getPixels("x"),
      s = t.getPixels("y");
    (e.translate(a, s),
      e.transform(i[0], i[1], i[2], i[3], i[4], i[5]),
      e.translate(-a, -s));
  }
  unapply(e) {
    var { originX: r, originY: t, matrix: i } = this,
      a = i[0],
      s = i[2],
      o = i[4],
      u = i[1],
      l = i[3],
      h = i[5],
      c = 0,
      v = 0,
      f = 1,
      g = 1 / (a * (l * f - h * v) - s * (u * f - h * c) + o * (u * v - l * c)),
      d = r.getPixels("x"),
      p = t.getPixels("y");
    (e.translate(d, p),
      e.transform(
        g * (l * f - h * v),
        g * (h * c - u * f),
        g * (o * v - s * f),
        g * (a * f - o * c),
        g * (s * h - o * l),
        g * (o * u - a * h),
      ),
      e.translate(-d, -p));
  }
  applyToPoint(e) {
    e.applyTransform(this.matrix);
  }
}
class Fl extends Bl {
  constructor(e, r, t) {
    (super(e, r, t),
      (this.type = "skew"),
      (this.angle = null),
      (this.angle = new M(e, "angle", r)));
  }
}
class Zf extends Fl {
  constructor(e, r, t) {
    (super(e, r, t),
      (this.type = "skewX"),
      (this.matrix = [1, 0, Math.tan(this.angle.getRadians()), 1, 0, 0]));
  }
}
class Jf extends Fl {
  constructor(e, r, t) {
    (super(e, r, t),
      (this.type = "skewY"),
      (this.matrix = [1, Math.tan(this.angle.getRadians()), 0, 1, 0, 0]));
  }
}
function ec(n) {
  return or(n)
    .trim()
    .replace(/\)([a-zA-Z])/g, ") $1")
    .replace(/\)(\s?,\s?)/g, ") ")
    .split(/\s(?=[a-z])/);
}
function rc(n) {
  var [e, r] = n.split("(");
  return [e.trim(), r.trim().replace(")", "")];
}
class er {
  constructor(e, r, t) {
    ((this.document = e), (this.transforms = []));
    var i = ec(r);
    i.forEach((a) => {
      if (a !== "none") {
        var [s, o] = rc(a),
          u = er.transformTypes[s];
        typeof u < "u" && this.transforms.push(new u(this.document, o, t));
      }
    });
  }
  static fromElement(e, r) {
    var t = r.getStyle("transform", !1, !0),
      [i, a = i] = r.getStyle("transform-origin", !1, !0).split(),
      s = [i, a];
    return t.hasValue() ? new er(e, t.getString(), s) : null;
  }
  apply(e) {
    for (var { transforms: r } = this, t = r.length, i = 0; i < t; i++)
      r[i].apply(e);
  }
  unapply(e) {
    for (var { transforms: r } = this, t = r.length, i = t - 1; i >= 0; i--)
      r[i].unapply(e);
  }
  applyToPoint(e) {
    for (var { transforms: r } = this, t = r.length, i = 0; i < t; i++)
      r[i].applyToPoint(e);
  }
}
er.transformTypes = {
  translate: Xf,
  rotate: Kf,
  scale: Qf,
  matrix: Bl,
  skewX: Zf,
  skewY: Jf,
};
class K {
  constructor(e, r) {
    var t = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : !1;
    if (
      ((this.document = e),
      (this.node = r),
      (this.captureTextNodes = t),
      (this.attributes = Object.create(null)),
      (this.styles = Object.create(null)),
      (this.stylesSpecificity = Object.create(null)),
      (this.animationFrozen = !1),
      (this.animationFrozenValue = ""),
      (this.parent = null),
      (this.children = []),
      !(!r || r.nodeType !== 1))
    ) {
      if (
        (Array.from(r.attributes).forEach((o) => {
          var u = Df(o.nodeName);
          this.attributes[u] = new M(e, u, o.value);
        }),
        this.addStylesFromStyleDefinition(),
        this.getAttribute("style").hasValue())
      ) {
        var i = this.getAttribute("style")
          .getString()
          .split(";")
          .map((o) => o.trim());
        i.forEach((o) => {
          if (o) {
            var [u, l] = o.split(":").map((h) => h.trim());
            this.styles[u] = new M(e, u, l);
          }
        });
      }
      var { definitions: a } = e,
        s = this.getAttribute("id");
      (s.hasValue() && (a[s.getString()] || (a[s.getString()] = this)),
        Array.from(r.childNodes).forEach((o) => {
          if (o.nodeType === 1) this.addChild(o);
          else if (t && (o.nodeType === 3 || o.nodeType === 4)) {
            var u = e.createTextNode(o);
            u.getText().length > 0 && this.addChild(u);
          }
        }));
    }
  }
  getAttribute(e) {
    var r = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !1,
      t = this.attributes[e];
    if (!t && r) {
      var i = new M(this.document, e, "");
      return ((this.attributes[e] = i), i);
    }
    return t || M.empty(this.document);
  }
  getHrefAttribute() {
    for (var e in this.attributes)
      if (e === "href" || e.endsWith(":href")) return this.attributes[e];
    return M.empty(this.document);
  }
  getStyle(e) {
    var r = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !1,
      t = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : !1,
      i = this.styles[e];
    if (i) return i;
    var a = this.getAttribute(e);
    if (a != null && a.hasValue()) return ((this.styles[e] = a), a);
    if (!t) {
      var { parent: s } = this;
      if (s) {
        var o = s.getStyle(e);
        if (o != null && o.hasValue()) return o;
      }
    }
    if (r) {
      var u = new M(this.document, e, "");
      return ((this.styles[e] = u), u);
    }
    return i || M.empty(this.document);
  }
  render(e) {
    if (!(
      this.getStyle("display").getString() === "none" ||
      this.getStyle("visibility").getString() === "hidden"
    )) {
      if ((e.save(), this.getStyle("mask").hasValue())) {
        var r = this.getStyle("mask").getDefinition();
        r && (this.applyEffects(e), r.apply(e, this));
      } else if (this.getStyle("filter").getValue("none") !== "none") {
        var t = this.getStyle("filter").getDefinition();
        t && (this.applyEffects(e), t.apply(e, this));
      } else (this.setContext(e), this.renderChildren(e), this.clearContext(e));
      e.restore();
    }
  }
  setContext(e) {}
  applyEffects(e) {
    var r = er.fromElement(this.document, this);
    r && r.apply(e);
    var t = this.getStyle("clip-path", !1, !0);
    if (t.hasValue()) {
      var i = t.getDefinition();
      i && i.apply(e);
    }
  }
  clearContext(e) {}
  renderChildren(e) {
    this.children.forEach((r) => {
      r.render(e);
    });
  }
  addChild(e) {
    var r = e instanceof K ? e : this.document.createElement(e);
    ((r.parent = this),
      K.ignoreChildTypes.includes(r.type) || this.children.push(r));
  }
  matchesSelector(e) {
    var r,
      { node: t } = this;
    if (typeof t.matches == "function") return t.matches(e);
    var i =
      (r = t.getAttribute) === null || r === void 0
        ? void 0
        : r.call(t, "class");
    return !i || i === "" ? !1 : i.split(" ").some((a) => ".".concat(a) === e);
  }
  addStylesFromStyleDefinition() {
    var { styles: e, stylesSpecificity: r } = this.document;
    for (var t in e)
      if (!t.startsWith("@") && this.matchesSelector(t)) {
        var i = e[t],
          a = r[t];
        if (i)
          for (var s in i) {
            var o = this.stylesSpecificity[s];
            (typeof o > "u" && (o = "000"),
              a >= o &&
                ((this.styles[s] = i[s]), (this.stylesSpecificity[s] = a)));
          }
      }
  }
  removeStyles(e, r) {
    var t = r.reduce((i, a) => {
      var s = e.getStyle(a);
      if (!s.hasValue()) return i;
      var o = s.getString();
      return (s.setValue(""), [...i, [a, o]]);
    }, []);
    return t;
  }
  restoreStyles(e, r) {
    r.forEach((t) => {
      var [i, a] = t;
      e.getStyle(i, !0).setValue(a);
    });
  }
  isFirstChild() {
    var e;
    return (
      ((e = this.parent) === null || e === void 0
        ? void 0
        : e.children.indexOf(this)) === 0
    );
  }
}
K.ignoreChildTypes = ["title"];
class tc extends K {
  constructor(e, r, t) {
    super(e, r, t);
  }
}
function ic(n) {
  var e = n.trim();
  return /^('|")/.test(e) ? e : '"'.concat(e, '"');
}
function ac(n) {
  return typeof process > "u" ? n : n.trim().split(",").map(ic).join(",");
}
function nc(n) {
  if (!n) return "";
  var e = n.trim().toLowerCase();
  switch (e) {
    case "normal":
    case "italic":
    case "oblique":
    case "inherit":
    case "initial":
    case "unset":
      return e;
    default:
      return /^oblique\s+(-|)\d+deg$/.test(e) ? e : "";
  }
}
function sc(n) {
  if (!n) return "";
  var e = n.trim().toLowerCase();
  switch (e) {
    case "normal":
    case "bold":
    case "lighter":
    case "bolder":
    case "inherit":
    case "initial":
    case "unset":
      return e;
    default:
      return /^[\d.]+$/.test(e) ? e : "";
  }
}
class le {
  constructor(e, r, t, i, a, s) {
    var o = s ? (typeof s == "string" ? le.parse(s) : s) : {};
    ((this.fontFamily = a || o.fontFamily),
      (this.fontSize = i || o.fontSize),
      (this.fontStyle = e || o.fontStyle),
      (this.fontWeight = t || o.fontWeight),
      (this.fontVariant = r || o.fontVariant));
  }
  static parse() {
    var e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "",
      r = arguments.length > 1 ? arguments[1] : void 0,
      t = "",
      i = "",
      a = "",
      s = "",
      o = "",
      u = or(e).trim().split(" "),
      l = { fontSize: !1, fontStyle: !1, fontWeight: !1, fontVariant: !1 };
    return (
      u.forEach((h) => {
        switch (!0) {
          case !l.fontStyle && le.styles.includes(h):
            (h !== "inherit" && (t = h), (l.fontStyle = !0));
            break;
          case !l.fontVariant && le.variants.includes(h):
            (h !== "inherit" && (i = h),
              (l.fontStyle = !0),
              (l.fontVariant = !0));
            break;
          case !l.fontWeight && le.weights.includes(h):
            (h !== "inherit" && (a = h),
              (l.fontStyle = !0),
              (l.fontVariant = !0),
              (l.fontWeight = !0));
            break;
          case !l.fontSize:
            (h !== "inherit" && ([s] = h.split("/")),
              (l.fontStyle = !0),
              (l.fontVariant = !0),
              (l.fontWeight = !0),
              (l.fontSize = !0));
            break;
          default:
            h !== "inherit" && (o += h);
        }
      }),
      new le(t, i, a, s, o, r)
    );
  }
  toString() {
    return [
      nc(this.fontStyle),
      this.fontVariant,
      sc(this.fontWeight),
      this.fontSize,
      ac(this.fontFamily),
    ]
      .join(" ")
      .trim();
  }
}
le.styles = "normal|italic|oblique|inherit";
le.variants = "normal|small-caps|inherit";
le.weights =
  "normal|bold|bolder|lighter|100|200|300|400|500|600|700|800|900|inherit";
class Ie {
  constructor() {
    var e =
        arguments.length > 0 && arguments[0] !== void 0
          ? arguments[0]
          : Number.NaN,
      r =
        arguments.length > 1 && arguments[1] !== void 0
          ? arguments[1]
          : Number.NaN,
      t =
        arguments.length > 2 && arguments[2] !== void 0
          ? arguments[2]
          : Number.NaN,
      i =
        arguments.length > 3 && arguments[3] !== void 0
          ? arguments[3]
          : Number.NaN;
    ((this.x1 = e),
      (this.y1 = r),
      (this.x2 = t),
      (this.y2 = i),
      this.addPoint(e, r),
      this.addPoint(t, i));
  }
  get x() {
    return this.x1;
  }
  get y() {
    return this.y1;
  }
  get width() {
    return this.x2 - this.x1;
  }
  get height() {
    return this.y2 - this.y1;
  }
  addPoint(e, r) {
    (typeof e < "u" &&
      ((isNaN(this.x1) || isNaN(this.x2)) && ((this.x1 = e), (this.x2 = e)),
      e < this.x1 && (this.x1 = e),
      e > this.x2 && (this.x2 = e)),
      typeof r < "u" &&
        ((isNaN(this.y1) || isNaN(this.y2)) && ((this.y1 = r), (this.y2 = r)),
        r < this.y1 && (this.y1 = r),
        r > this.y2 && (this.y2 = r)));
  }
  addX(e) {
    this.addPoint(e, null);
  }
  addY(e) {
    this.addPoint(null, e);
  }
  addBoundingBox(e) {
    if (e) {
      var { x1: r, y1: t, x2: i, y2: a } = e;
      (this.addPoint(r, t), this.addPoint(i, a));
    }
  }
  sumCubic(e, r, t, i, a) {
    return (
      Math.pow(1 - e, 3) * r +
      3 * Math.pow(1 - e, 2) * e * t +
      3 * (1 - e) * Math.pow(e, 2) * i +
      Math.pow(e, 3) * a
    );
  }
  bezierCurveAdd(e, r, t, i, a) {
    var s = 6 * r - 12 * t + 6 * i,
      o = -3 * r + 9 * t - 9 * i + 3 * a,
      u = 3 * t - 3 * r;
    if (o === 0) {
      if (s === 0) return;
      var l = -u / s;
      0 < l &&
        l < 1 &&
        (e
          ? this.addX(this.sumCubic(l, r, t, i, a))
          : this.addY(this.sumCubic(l, r, t, i, a)));
      return;
    }
    var h = Math.pow(s, 2) - 4 * u * o;
    if (!(h < 0)) {
      var c = (-s + Math.sqrt(h)) / (2 * o);
      0 < c &&
        c < 1 &&
        (e
          ? this.addX(this.sumCubic(c, r, t, i, a))
          : this.addY(this.sumCubic(c, r, t, i, a)));
      var v = (-s - Math.sqrt(h)) / (2 * o);
      0 < v &&
        v < 1 &&
        (e
          ? this.addX(this.sumCubic(v, r, t, i, a))
          : this.addY(this.sumCubic(v, r, t, i, a)));
    }
  }
  addBezierCurve(e, r, t, i, a, s, o, u) {
    (this.addPoint(e, r),
      this.addPoint(o, u),
      this.bezierCurveAdd(!0, e, t, a, o),
      this.bezierCurveAdd(!1, r, i, s, u));
  }
  addQuadraticCurve(e, r, t, i, a, s) {
    var o = e + 0.6666666666666666 * (t - e),
      u = r + (2 / 3) * (i - r),
      l = o + (1 / 3) * (a - e),
      h = u + (1 / 3) * (s - r);
    this.addBezierCurve(e, r, o, l, u, h, a, s);
  }
  isPointInBox(e, r) {
    var { x1: t, y1: i, x2: a, y2: s } = this;
    return t <= e && e <= a && i <= r && r <= s;
  }
}
class G extends O {
  constructor(e) {
    (super(
      e
        .replace(/([+\-.])\s+/gm, "$1")
        .replace(/[^MmZzLlHhVvCcSsQqTtAae\d\s.,+-].*/g, ""),
    ),
      (this.control = null),
      (this.start = null),
      (this.current = null),
      (this.command = null),
      (this.commands = this.commands),
      (this.i = -1),
      (this.previousCommand = null),
      (this.points = []),
      (this.angles = []));
  }
  reset() {
    ((this.i = -1),
      (this.command = null),
      (this.previousCommand = null),
      (this.start = new re(0, 0)),
      (this.control = new re(0, 0)),
      (this.current = new re(0, 0)),
      (this.points = []),
      (this.angles = []));
  }
  isEnd() {
    var { i: e, commands: r } = this;
    return e >= r.length - 1;
  }
  next() {
    var e = this.commands[++this.i];
    return ((this.previousCommand = this.command), (this.command = e), e);
  }
  getPoint() {
    var e =
        arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "x",
      r = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "y",
      t = new re(this.command[e], this.command[r]);
    return this.makeAbsolute(t);
  }
  getAsControlPoint(e, r) {
    var t = this.getPoint(e, r);
    return ((this.control = t), t);
  }
  getAsCurrentPoint(e, r) {
    var t = this.getPoint(e, r);
    return ((this.current = t), t);
  }
  getReflectedControlPoint() {
    var e = this.previousCommand.type;
    if (
      e !== O.CURVE_TO &&
      e !== O.SMOOTH_CURVE_TO &&
      e !== O.QUAD_TO &&
      e !== O.SMOOTH_QUAD_TO
    )
      return this.current;
    var {
        current: { x: r, y: t },
        control: { x: i, y: a },
      } = this,
      s = new re(2 * r - i, 2 * t - a);
    return s;
  }
  makeAbsolute(e) {
    if (this.command.relative) {
      var { x: r, y: t } = this.current;
      ((e.x += r), (e.y += t));
    }
    return e;
  }
  addMarker(e, r, t) {
    var { points: i, angles: a } = this;
    (t &&
      a.length > 0 &&
      !a[a.length - 1] &&
      (a[a.length - 1] = i[i.length - 1].angleTo(t)),
      this.addMarkerAngle(e, r ? r.angleTo(e) : null));
  }
  addMarkerAngle(e, r) {
    (this.points.push(e), this.angles.push(r));
  }
  getMarkerPoints() {
    return this.points;
  }
  getMarkerAngles() {
    for (var { angles: e } = this, r = e.length, t = 0; t < r; t++)
      if (!e[t]) {
        for (var i = t + 1; i < r; i++)
          if (e[i]) {
            e[t] = e[i];
            break;
          }
      }
    return e;
  }
}
class ir extends K {
  constructor() {
    (super(...arguments), (this.modifiedEmSizeStack = !1));
  }
  calculateOpacity() {
    for (var e = 1, r = this; r;) {
      var t = r.getStyle("opacity", !1, !0);
      (t.hasValue(!0) && (e *= t.getNumber()), (r = r.parent));
    }
    return e;
  }
  setContext(e) {
    var r = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !1;
    if (!r) {
      var t = this.getStyle("fill"),
        i = this.getStyle("fill-opacity"),
        a = this.getStyle("stroke"),
        s = this.getStyle("stroke-opacity");
      if (t.isUrlDefinition()) {
        var o = t.getFillStyleDefinition(this, i);
        o && (e.fillStyle = o);
      } else if (t.hasValue()) {
        t.getString() === "currentColor" &&
          t.setValue(this.getStyle("color").getColor());
        var u = t.getColor();
        u !== "inherit" && (e.fillStyle = u === "none" ? "rgba(0,0,0,0)" : u);
      }
      if (i.hasValue()) {
        var l = new M(this.document, "fill", e.fillStyle)
          .addOpacity(i)
          .getColor();
        e.fillStyle = l;
      }
      if (a.isUrlDefinition()) {
        var h = a.getFillStyleDefinition(this, s);
        h && (e.strokeStyle = h);
      } else if (a.hasValue()) {
        a.getString() === "currentColor" &&
          a.setValue(this.getStyle("color").getColor());
        var c = a.getString();
        c !== "inherit" && (e.strokeStyle = c === "none" ? "rgba(0,0,0,0)" : c);
      }
      if (s.hasValue()) {
        var v = new M(this.document, "stroke", e.strokeStyle)
          .addOpacity(s)
          .getString();
        e.strokeStyle = v;
      }
      var f = this.getStyle("stroke-width");
      if (f.hasValue()) {
        var g = f.getPixels();
        e.lineWidth = g || ar;
      }
      var d = this.getStyle("stroke-linecap"),
        p = this.getStyle("stroke-linejoin"),
        y = this.getStyle("stroke-miterlimit"),
        m = this.getStyle("stroke-dasharray"),
        b = this.getStyle("stroke-dashoffset");
      if (
        (d.hasValue() && (e.lineCap = d.getString()),
        p.hasValue() && (e.lineJoin = p.getString()),
        y.hasValue() && (e.miterLimit = y.getNumber()),
        m.hasValue() && m.getString() !== "none")
      ) {
        var x = me(m.getString());
        typeof e.setLineDash < "u"
          ? e.setLineDash(x)
          : typeof e.webkitLineDash < "u"
            ? (e.webkitLineDash = x)
            : typeof e.mozDash < "u" &&
              !(x.length === 1 && x[0] === 0) &&
              (e.mozDash = x);
        var S = b.getPixels();
        typeof e.lineDashOffset < "u"
          ? (e.lineDashOffset = S)
          : typeof e.webkitLineDashOffset < "u"
            ? (e.webkitLineDashOffset = S)
            : typeof e.mozDashOffset < "u" && (e.mozDashOffset = S);
      }
    }
    if (((this.modifiedEmSizeStack = !1), typeof e.font < "u")) {
      var E = this.getStyle("font"),
        T = this.getStyle("font-style"),
        R = this.getStyle("font-variant"),
        P = this.getStyle("font-weight"),
        A = this.getStyle("font-size"),
        D = this.getStyle("font-family"),
        I = new le(
          T.getString(),
          R.getString(),
          P.getString(),
          A.hasValue() ? "".concat(A.getPixels(!0), "px") : "",
          D.getString(),
          le.parse(E.getString(), e.font),
        );
      (T.setValue(I.fontStyle),
        R.setValue(I.fontVariant),
        P.setValue(I.fontWeight),
        A.setValue(I.fontSize),
        D.setValue(I.fontFamily),
        (e.font = I.toString()),
        A.isPixels() &&
          ((this.document.emSize = A.getPixels()),
          (this.modifiedEmSizeStack = !0)));
    }
    r || (this.applyEffects(e), (e.globalAlpha = this.calculateOpacity()));
  }
  clearContext(e) {
    (super.clearContext(e),
      this.modifiedEmSizeStack && this.document.popEmSize());
  }
}
class Y extends ir {
  constructor(e, r, t) {
    (super(e, r, t),
      (this.type = "path"),
      (this.pathParser = null),
      (this.pathParser = new G(this.getAttribute("d").getString())));
  }
  path(e) {
    var { pathParser: r } = this,
      t = new Ie();
    for (r.reset(), e && e.beginPath(); !r.isEnd();)
      switch (r.next().type) {
        case G.MOVE_TO:
          this.pathM(e, t);
          break;
        case G.LINE_TO:
          this.pathL(e, t);
          break;
        case G.HORIZ_LINE_TO:
          this.pathH(e, t);
          break;
        case G.VERT_LINE_TO:
          this.pathV(e, t);
          break;
        case G.CURVE_TO:
          this.pathC(e, t);
          break;
        case G.SMOOTH_CURVE_TO:
          this.pathS(e, t);
          break;
        case G.QUAD_TO:
          this.pathQ(e, t);
          break;
        case G.SMOOTH_QUAD_TO:
          this.pathT(e, t);
          break;
        case G.ARC:
          this.pathA(e, t);
          break;
        case G.CLOSE_PATH:
          this.pathZ(e, t);
          break;
      }
    return t;
  }
  getBoundingBox(e) {
    return this.path();
  }
  getMarkers() {
    var { pathParser: e } = this,
      r = e.getMarkerPoints(),
      t = e.getMarkerAngles(),
      i = r.map((a, s) => [a, t[s]]);
    return i;
  }
  renderChildren(e) {
    (this.path(e), this.document.screen.mouse.checkPath(this, e));
    var r = this.getStyle("fill-rule");
    (e.fillStyle !== "" &&
      (r.getString("inherit") !== "inherit" ? e.fill(r.getString()) : e.fill()),
      e.strokeStyle !== "" &&
        (this.getAttribute("vector-effect").getString() === "non-scaling-stroke"
          ? (e.save(),
            e.setTransform(1, 0, 0, 1, 0, 0),
            e.stroke(),
            e.restore())
          : e.stroke()));
    var t = this.getMarkers();
    if (t) {
      var i = t.length - 1,
        a = this.getStyle("marker-start"),
        s = this.getStyle("marker-mid"),
        o = this.getStyle("marker-end");
      if (a.isUrlDefinition()) {
        var u = a.getDefinition(),
          [l, h] = t[0];
        u.render(e, l, h);
      }
      if (s.isUrlDefinition())
        for (var c = s.getDefinition(), v = 1; v < i; v++) {
          var [f, g] = t[v];
          c.render(e, f, g);
        }
      if (o.isUrlDefinition()) {
        var d = o.getDefinition(),
          [p, y] = t[i];
        d.render(e, p, y);
      }
    }
  }
  static pathM(e) {
    var r = e.getAsCurrentPoint();
    return ((e.start = e.current), { point: r });
  }
  pathM(e, r) {
    var { pathParser: t } = this,
      { point: i } = Y.pathM(t),
      { x: a, y: s } = i;
    (t.addMarker(i), r.addPoint(a, s), e && e.moveTo(a, s));
  }
  static pathL(e) {
    var { current: r } = e,
      t = e.getAsCurrentPoint();
    return { current: r, point: t };
  }
  pathL(e, r) {
    var { pathParser: t } = this,
      { current: i, point: a } = Y.pathL(t),
      { x: s, y: o } = a;
    (t.addMarker(a, i), r.addPoint(s, o), e && e.lineTo(s, o));
  }
  static pathH(e) {
    var { current: r, command: t } = e,
      i = new re((t.relative ? r.x : 0) + t.x, r.y);
    return ((e.current = i), { current: r, point: i });
  }
  pathH(e, r) {
    var { pathParser: t } = this,
      { current: i, point: a } = Y.pathH(t),
      { x: s, y: o } = a;
    (t.addMarker(a, i), r.addPoint(s, o), e && e.lineTo(s, o));
  }
  static pathV(e) {
    var { current: r, command: t } = e,
      i = new re(r.x, (t.relative ? r.y : 0) + t.y);
    return ((e.current = i), { current: r, point: i });
  }
  pathV(e, r) {
    var { pathParser: t } = this,
      { current: i, point: a } = Y.pathV(t),
      { x: s, y: o } = a;
    (t.addMarker(a, i), r.addPoint(s, o), e && e.lineTo(s, o));
  }
  static pathC(e) {
    var { current: r } = e,
      t = e.getPoint("x1", "y1"),
      i = e.getAsControlPoint("x2", "y2"),
      a = e.getAsCurrentPoint();
    return { current: r, point: t, controlPoint: i, currentPoint: a };
  }
  pathC(e, r) {
    var { pathParser: t } = this,
      { current: i, point: a, controlPoint: s, currentPoint: o } = Y.pathC(t);
    (t.addMarker(o, s, a),
      r.addBezierCurve(i.x, i.y, a.x, a.y, s.x, s.y, o.x, o.y),
      e && e.bezierCurveTo(a.x, a.y, s.x, s.y, o.x, o.y));
  }
  static pathS(e) {
    var { current: r } = e,
      t = e.getReflectedControlPoint(),
      i = e.getAsControlPoint("x2", "y2"),
      a = e.getAsCurrentPoint();
    return { current: r, point: t, controlPoint: i, currentPoint: a };
  }
  pathS(e, r) {
    var { pathParser: t } = this,
      { current: i, point: a, controlPoint: s, currentPoint: o } = Y.pathS(t);
    (t.addMarker(o, s, a),
      r.addBezierCurve(i.x, i.y, a.x, a.y, s.x, s.y, o.x, o.y),
      e && e.bezierCurveTo(a.x, a.y, s.x, s.y, o.x, o.y));
  }
  static pathQ(e) {
    var { current: r } = e,
      t = e.getAsControlPoint("x1", "y1"),
      i = e.getAsCurrentPoint();
    return { current: r, controlPoint: t, currentPoint: i };
  }
  pathQ(e, r) {
    var { pathParser: t } = this,
      { current: i, controlPoint: a, currentPoint: s } = Y.pathQ(t);
    (t.addMarker(s, a, a),
      r.addQuadraticCurve(i.x, i.y, a.x, a.y, s.x, s.y),
      e && e.quadraticCurveTo(a.x, a.y, s.x, s.y));
  }
  static pathT(e) {
    var { current: r } = e,
      t = e.getReflectedControlPoint();
    e.control = t;
    var i = e.getAsCurrentPoint();
    return { current: r, controlPoint: t, currentPoint: i };
  }
  pathT(e, r) {
    var { pathParser: t } = this,
      { current: i, controlPoint: a, currentPoint: s } = Y.pathT(t);
    (t.addMarker(s, a, a),
      r.addQuadraticCurve(i.x, i.y, a.x, a.y, s.x, s.y),
      e && e.quadraticCurveTo(a.x, a.y, s.x, s.y));
  }
  static pathA(e) {
    var { current: r, command: t } = e,
      { rX: i, rY: a, xRot: s, lArcFlag: o, sweepFlag: u } = t,
      l = s * (Math.PI / 180),
      h = e.getAsCurrentPoint(),
      c = new re(
        (Math.cos(l) * (r.x - h.x)) / 2 + (Math.sin(l) * (r.y - h.y)) / 2,
        (-Math.sin(l) * (r.x - h.x)) / 2 + (Math.cos(l) * (r.y - h.y)) / 2,
      ),
      v = Math.pow(c.x, 2) / Math.pow(i, 2) + Math.pow(c.y, 2) / Math.pow(a, 2);
    v > 1 && ((i *= Math.sqrt(v)), (a *= Math.sqrt(v)));
    var f =
      (o === u ? -1 : 1) *
      Math.sqrt(
        (Math.pow(i, 2) * Math.pow(a, 2) -
          Math.pow(i, 2) * Math.pow(c.y, 2) -
          Math.pow(a, 2) * Math.pow(c.x, 2)) /
          (Math.pow(i, 2) * Math.pow(c.y, 2) +
            Math.pow(a, 2) * Math.pow(c.x, 2)),
      );
    isNaN(f) && (f = 0);
    var g = new re((f * i * c.y) / a, (f * -a * c.x) / i),
      d = new re(
        (r.x + h.x) / 2 + Math.cos(l) * g.x - Math.sin(l) * g.y,
        (r.y + h.y) / 2 + Math.sin(l) * g.x + Math.cos(l) * g.y,
      ),
      p = $u([1, 0], [(c.x - g.x) / i, (c.y - g.y) / a]),
      y = [(c.x - g.x) / i, (c.y - g.y) / a],
      m = [(-c.x - g.x) / i, (-c.y - g.y) / a],
      b = $u(y, m);
    return (
      Ba(y, m) <= -1 && (b = Math.PI),
      Ba(y, m) >= 1 && (b = 0),
      {
        currentPoint: h,
        rX: i,
        rY: a,
        sweepFlag: u,
        xAxisRotation: l,
        centp: d,
        a1: p,
        ad: b,
      }
    );
  }
  pathA(e, r) {
    var { pathParser: t } = this,
      {
        currentPoint: i,
        rX: a,
        rY: s,
        sweepFlag: o,
        xAxisRotation: u,
        centp: l,
        a1: h,
        ad: c,
      } = Y.pathA(t),
      v = 1 - o ? 1 : -1,
      f = h + v * (c / 2),
      g = new re(l.x + a * Math.cos(f), l.y + s * Math.sin(f));
    if (
      (t.addMarkerAngle(g, f - (v * Math.PI) / 2),
      t.addMarkerAngle(i, f - v * Math.PI),
      r.addPoint(i.x, i.y),
      e && !isNaN(h) && !isNaN(c))
    ) {
      var d = a > s ? a : s,
        p = a > s ? 1 : a / s,
        y = a > s ? s / a : 1;
      (e.translate(l.x, l.y),
        e.rotate(u),
        e.scale(p, y),
        e.arc(0, 0, d, h, h + c, !!(1 - o)),
        e.scale(1 / p, 1 / y),
        e.rotate(-u),
        e.translate(-l.x, -l.y));
    }
  }
  static pathZ(e) {
    e.current = e.start;
  }
  pathZ(e, r) {
    (Y.pathZ(this.pathParser),
      e && r.x1 !== r.x2 && r.y1 !== r.y2 && e.closePath());
  }
}
class Ul extends Y {
  constructor(e, r, t) {
    (super(e, r, t),
      (this.type = "glyph"),
      (this.horizAdvX = this.getAttribute("horiz-adv-x").getNumber()),
      (this.unicode = this.getAttribute("unicode").getString()),
      (this.arabicForm = this.getAttribute("arabic-form").getString()));
  }
}
class He extends ir {
  constructor(e, r, t) {
    (super(e, r, new.target === He ? !0 : t),
      (this.type = "text"),
      (this.x = 0),
      (this.y = 0),
      (this.measureCache = -1));
  }
  setContext(e) {
    var r = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !1;
    super.setContext(e, r);
    var t =
      this.getStyle("dominant-baseline").getTextBaseline() ||
      this.getStyle("alignment-baseline").getTextBaseline();
    t && (e.textBaseline = t);
  }
  initializeCoordinates() {
    ((this.x = 0),
      (this.y = 0),
      (this.leafTexts = []),
      (this.textChunkStart = 0),
      (this.minX = Number.POSITIVE_INFINITY),
      (this.maxX = Number.NEGATIVE_INFINITY));
  }
  getBoundingBox(e) {
    if (this.type !== "text") return this.getTElementBoundingBox(e);
    (this.initializeCoordinates(), this.adjustChildCoordinatesRecursive(e));
    var r = null;
    return (
      this.children.forEach((t, i) => {
        var a = this.getChildBoundingBox(e, this, this, i);
        r ? r.addBoundingBox(a) : (r = a);
      }),
      r
    );
  }
  getFontSize() {
    var { document: e, parent: r } = this,
      t = le.parse(e.ctx.font).fontSize,
      i = r.getStyle("font-size").getNumber(t);
    return i;
  }
  getTElementBoundingBox(e) {
    var r = this.getFontSize();
    return new Ie(this.x, this.y - r, this.x + this.measureText(e), this.y);
  }
  getGlyph(e, r, t) {
    var i = r[t],
      a = null;
    if (e.isArabic) {
      var s = r.length,
        o = r[t - 1],
        u = r[t + 1],
        l = "isolated";
      if (
        ((t === 0 || o === " ") && t < s - 1 && u !== " " && (l = "terminal"),
        t > 0 && o !== " " && t < s - 1 && u !== " " && (l = "medial"),
        t > 0 && o !== " " && (t === s - 1 || u === " ") && (l = "initial"),
        typeof e.glyphs[i] < "u")
      ) {
        var h = e.glyphs[i];
        a = h instanceof Ul ? h : h[l];
      }
    } else a = e.glyphs[i];
    return (a || (a = e.missingGlyph), a);
  }
  getText() {
    return "";
  }
  getTextFromNode(e) {
    var r = e || this.node,
      t = Array.from(r.parentNode.childNodes),
      i = t.indexOf(r),
      a = t.length - 1,
      s = or(r.textContent || "");
    return (i === 0 && (s = _f(s)), i === a && (s = Mf(s)), s);
  }
  renderChildren(e) {
    if (this.type !== "text") {
      this.renderTElementChildren(e);
      return;
    }
    (this.initializeCoordinates(),
      this.adjustChildCoordinatesRecursive(e),
      this.children.forEach((t, i) => {
        this.renderChild(e, this, this, i);
      }));
    var { mouse: r } = this.document.screen;
    r.isWorking() && r.checkBoundingBox(this, this.getBoundingBox(e));
  }
  renderTElementChildren(e) {
    var { document: r, parent: t } = this,
      i = this.getText(),
      a = t.getStyle("font-family").getDefinition();
    if (a) {
      for (
        var { unitsPerEm: s } = a.fontFace,
          o = le.parse(r.ctx.font),
          u = t.getStyle("font-size").getNumber(o.fontSize),
          l = t.getStyle("font-style").getString(o.fontStyle),
          h = u / s,
          c = a.isRTL ? i.split("").reverse().join("") : i,
          v = me(t.getAttribute("dx").getString()),
          f = c.length,
          g = 0;
        g < f;
        g++
      ) {
        var d = this.getGlyph(a, c, g);
        (e.translate(this.x, this.y), e.scale(h, -h));
        var p = e.lineWidth;
        ((e.lineWidth = (e.lineWidth * s) / u),
          l === "italic" && e.transform(1, 0, 0.4, 1, 0, 0),
          d.render(e),
          l === "italic" && e.transform(1, 0, -0.4, 1, 0, 0),
          (e.lineWidth = p),
          e.scale(1 / h, -1 / h),
          e.translate(-this.x, -this.y),
          (this.x += (u * (d.horizAdvX || a.horizAdvX)) / s),
          typeof v[g] < "u" && !isNaN(v[g]) && (this.x += v[g]));
      }
      return;
    }
    var { x: y, y: m } = this;
    (e.fillStyle && e.fillText(i, y, m),
      e.strokeStyle && e.strokeText(i, y, m));
  }
  applyAnchoring() {
    if (!(this.textChunkStart >= this.leafTexts.length)) {
      var e = this.leafTexts[this.textChunkStart],
        r = e.getStyle("text-anchor").getString("start"),
        t = !1,
        i = 0;
      (r === "start" && !t) || (r === "end" && t)
        ? (i = e.x - this.minX)
        : (r === "end" && !t) || (r === "start" && t)
          ? (i = e.x - this.maxX)
          : (i = e.x - (this.minX + this.maxX) / 2);
      for (var a = this.textChunkStart; a < this.leafTexts.length; a++)
        this.leafTexts[a].x += i;
      ((this.minX = Number.POSITIVE_INFINITY),
        (this.maxX = Number.NEGATIVE_INFINITY),
        (this.textChunkStart = this.leafTexts.length));
    }
  }
  adjustChildCoordinatesRecursive(e) {
    (this.children.forEach((r, t) => {
      this.adjustChildCoordinatesRecursiveCore(e, this, this, t);
    }),
      this.applyAnchoring());
  }
  adjustChildCoordinatesRecursiveCore(e, r, t, i) {
    var a = t.children[i];
    a.children.length > 0
      ? a.children.forEach((s, o) => {
          r.adjustChildCoordinatesRecursiveCore(e, r, a, o);
        })
      : this.adjustChildCoordinates(e, r, t, i);
  }
  adjustChildCoordinates(e, r, t, i) {
    var a = t.children[i];
    if (typeof a.measureText != "function") return a;
    (e.save(), a.setContext(e, !0));
    var s = a.getAttribute("x"),
      o = a.getAttribute("y"),
      u = a.getAttribute("dx"),
      l = a.getAttribute("dy"),
      h = a.getStyle("font-family").getDefinition(),
      c = !!h && h.isRTL;
    i === 0 &&
      (s.hasValue() || s.setValue(a.getInheritedAttribute("x")),
      o.hasValue() || o.setValue(a.getInheritedAttribute("y")),
      u.hasValue() || u.setValue(a.getInheritedAttribute("dx")),
      l.hasValue() || l.setValue(a.getInheritedAttribute("dy")));
    var v = a.measureText(e);
    return (
      c && (r.x -= v),
      s.hasValue()
        ? (r.applyAnchoring(),
          (a.x = s.getPixels("x")),
          u.hasValue() && (a.x += u.getPixels("x")))
        : (u.hasValue() && (r.x += u.getPixels("x")), (a.x = r.x)),
      (r.x = a.x),
      c || (r.x += v),
      o.hasValue()
        ? ((a.y = o.getPixels("y")), l.hasValue() && (a.y += l.getPixels("y")))
        : (l.hasValue() && (r.y += l.getPixels("y")), (a.y = r.y)),
      (r.y = a.y),
      r.leafTexts.push(a),
      (r.minX = Math.min(r.minX, a.x, a.x + v)),
      (r.maxX = Math.max(r.maxX, a.x, a.x + v)),
      a.clearContext(e),
      e.restore(),
      a
    );
  }
  getChildBoundingBox(e, r, t, i) {
    var a = t.children[i];
    if (typeof a.getBoundingBox != "function") return null;
    var s = a.getBoundingBox(e);
    return s
      ? (a.children.forEach((o, u) => {
          var l = r.getChildBoundingBox(e, r, a, u);
          s.addBoundingBox(l);
        }),
        s)
      : null;
  }
  renderChild(e, r, t, i) {
    var a = t.children[i];
    (a.render(e),
      a.children.forEach((s, o) => {
        r.renderChild(e, r, a, o);
      }));
  }
  measureText(e) {
    var { measureCache: r } = this;
    if (~r) return r;
    var t = this.getText(),
      i = this.measureTargetText(e, t);
    return ((this.measureCache = i), i);
  }
  measureTargetText(e, r) {
    if (!r.length) return 0;
    var { parent: t } = this,
      i = t.getStyle("font-family").getDefinition();
    if (i) {
      for (
        var a = this.getFontSize(),
          s = i.isRTL ? r.split("").reverse().join("") : r,
          o = me(t.getAttribute("dx").getString()),
          u = s.length,
          l = 0,
          h = 0;
        h < u;
        h++
      ) {
        var c = this.getGlyph(i, s, h);
        ((l += ((c.horizAdvX || i.horizAdvX) * a) / i.fontFace.unitsPerEm),
          typeof o[h] < "u" && !isNaN(o[h]) && (l += o[h]));
      }
      return l;
    }
    if (!e.measureText) return r.length * 10;
    (e.save(), this.setContext(e, !0));
    var { width: v } = e.measureText(r);
    return (this.clearContext(e), e.restore(), v);
  }
  getInheritedAttribute(e) {
    for (var r = this; r instanceof He && r.isFirstChild();) {
      var t = r.parent.getAttribute(e);
      if (t.hasValue(!0)) return t.getValue("0");
      r = r.parent;
    }
    return null;
  }
}
class Hr extends He {
  constructor(e, r, t) {
    (super(e, r, new.target === Hr ? !0 : t),
      (this.type = "tspan"),
      (this.text = this.children.length > 0 ? "" : this.getTextFromNode()));
  }
  getText() {
    return this.text;
  }
}
class oc extends Hr {
  constructor() {
    (super(...arguments), (this.type = "textNode"));
  }
}
class Tr extends ir {
  constructor() {
    (super(...arguments), (this.type = "svg"), (this.root = !1));
  }
  setContext(e) {
    var r,
      { document: t } = this,
      { screen: i, window: a } = t,
      s = e.canvas;
    if (
      (i.setDefaults(e),
      s.style && typeof e.font < "u" && a && typeof a.getComputedStyle < "u")
    ) {
      e.font = a.getComputedStyle(s).getPropertyValue("font");
      var o = new M(t, "fontSize", le.parse(e.font).fontSize);
      o.hasValue() &&
        ((t.rootEmSize = o.getPixels("y")), (t.emSize = t.rootEmSize));
    }
    (this.getAttribute("x").hasValue() ||
      this.getAttribute("x", !0).setValue(0),
      this.getAttribute("y").hasValue() ||
        this.getAttribute("y", !0).setValue(0));
    var { width: u, height: l } = i.viewPort;
    (this.getStyle("width").hasValue() ||
      this.getStyle("width", !0).setValue("100%"),
      this.getStyle("height").hasValue() ||
        this.getStyle("height", !0).setValue("100%"),
      this.getStyle("color").hasValue() ||
        this.getStyle("color", !0).setValue("black"));
    var h = this.getAttribute("refX"),
      c = this.getAttribute("refY"),
      v = this.getAttribute("viewBox"),
      f = v.hasValue() ? me(v.getString()) : null,
      g =
        !this.root &&
        this.getStyle("overflow").getValue("hidden") !== "visible",
      d = 0,
      p = 0,
      y = 0,
      m = 0;
    (f && ((d = f[0]), (p = f[1])),
      this.root ||
        ((u = this.getStyle("width").getPixels("x")),
        (l = this.getStyle("height").getPixels("y")),
        this.type === "marker" && ((y = d), (m = p), (d = 0), (p = 0))),
      i.viewPort.setCurrent(u, l),
      this.node &&
        (!this.parent ||
          ((r = this.node.parentNode) === null || r === void 0
            ? void 0
            : r.nodeName) === "foreignObject") &&
        this.getStyle("transform", !1, !0).hasValue() &&
        !this.getStyle("transform-origin", !1, !0).hasValue() &&
        this.getStyle("transform-origin", !0, !0).setValue("50% 50%"),
      super.setContext(e),
      e.translate(
        this.getAttribute("x").getPixels("x"),
        this.getAttribute("y").getPixels("y"),
      ),
      f && ((u = f[2]), (l = f[3])),
      t.setViewBox({
        ctx: e,
        aspectRatio: this.getAttribute("preserveAspectRatio").getString(),
        width: i.viewPort.width,
        desiredWidth: u,
        height: i.viewPort.height,
        desiredHeight: l,
        minX: d,
        minY: p,
        refX: h.getValue(),
        refY: c.getValue(),
        clip: g,
        clipX: y,
        clipY: m,
      }),
      f && (i.viewPort.removeCurrent(), i.viewPort.setCurrent(u, l)));
  }
  clearContext(e) {
    (super.clearContext(e), this.document.screen.viewPort.removeCurrent());
  }
  resize(e) {
    var r = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : e,
      t = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : !1,
      i = this.getAttribute("width", !0),
      a = this.getAttribute("height", !0),
      s = this.getAttribute("viewBox"),
      o = this.getAttribute("style"),
      u = i.getNumber(0),
      l = a.getNumber(0);
    if (t)
      if (typeof t == "string")
        this.getAttribute("preserveAspectRatio", !0).setValue(t);
      else {
        var h = this.getAttribute("preserveAspectRatio");
        h.hasValue() &&
          h.setValue(h.getString().replace(/^\s*(\S.*\S)\s*$/, "$1"));
      }
    if (
      (i.setValue(e),
      a.setValue(r),
      s.hasValue() || s.setValue("0 0 ".concat(u || e, " ").concat(l || r)),
      o.hasValue())
    ) {
      var c = this.getStyle("width"),
        v = this.getStyle("height");
      (c.hasValue() && c.setValue("".concat(e, "px")),
        v.hasValue() && v.setValue("".concat(r, "px")));
    }
  }
}
class Gl extends Y {
  constructor() {
    (super(...arguments), (this.type = "rect"));
  }
  path(e) {
    var r = this.getAttribute("x").getPixels("x"),
      t = this.getAttribute("y").getPixels("y"),
      i = this.getStyle("width", !1, !0).getPixels("x"),
      a = this.getStyle("height", !1, !0).getPixels("y"),
      s = this.getAttribute("rx"),
      o = this.getAttribute("ry"),
      u = s.getPixels("x"),
      l = o.getPixels("y");
    if (
      (s.hasValue() && !o.hasValue() && (l = u),
      o.hasValue() && !s.hasValue() && (u = l),
      (u = Math.min(u, i / 2)),
      (l = Math.min(l, a / 2)),
      e)
    ) {
      var h = 4 * ((Math.sqrt(2) - 1) / 3);
      (e.beginPath(),
        a > 0 &&
          i > 0 &&
          (e.moveTo(r + u, t),
          e.lineTo(r + i - u, t),
          e.bezierCurveTo(
            r + i - u + h * u,
            t,
            r + i,
            t + l - h * l,
            r + i,
            t + l,
          ),
          e.lineTo(r + i, t + a - l),
          e.bezierCurveTo(
            r + i,
            t + a - l + h * l,
            r + i - u + h * u,
            t + a,
            r + i - u,
            t + a,
          ),
          e.lineTo(r + u, t + a),
          e.bezierCurveTo(
            r + u - h * u,
            t + a,
            r,
            t + a - l + h * l,
            r,
            t + a - l,
          ),
          e.lineTo(r, t + l),
          e.bezierCurveTo(r, t + l - h * l, r + u - h * u, t, r + u, t),
          e.closePath()));
    }
    return new Ie(r, t, r + i, t + a);
  }
  getMarkers() {
    return null;
  }
}
class uc extends Y {
  constructor() {
    (super(...arguments), (this.type = "circle"));
  }
  path(e) {
    var r = this.getAttribute("cx").getPixels("x"),
      t = this.getAttribute("cy").getPixels("y"),
      i = this.getAttribute("r").getPixels();
    return (
      e &&
        i > 0 &&
        (e.beginPath(), e.arc(r, t, i, 0, Math.PI * 2, !1), e.closePath()),
      new Ie(r - i, t - i, r + i, t + i)
    );
  }
  getMarkers() {
    return null;
  }
}
class lc extends Y {
  constructor() {
    (super(...arguments), (this.type = "ellipse"));
  }
  path(e) {
    var r = 4 * ((Math.sqrt(2) - 1) / 3),
      t = this.getAttribute("rx").getPixels("x"),
      i = this.getAttribute("ry").getPixels("y"),
      a = this.getAttribute("cx").getPixels("x"),
      s = this.getAttribute("cy").getPixels("y");
    return (
      e &&
        t > 0 &&
        i > 0 &&
        (e.beginPath(),
        e.moveTo(a + t, s),
        e.bezierCurveTo(a + t, s + r * i, a + r * t, s + i, a, s + i),
        e.bezierCurveTo(a - r * t, s + i, a - t, s + r * i, a - t, s),
        e.bezierCurveTo(a - t, s - r * i, a - r * t, s - i, a, s - i),
        e.bezierCurveTo(a + r * t, s - i, a + t, s - r * i, a + t, s),
        e.closePath()),
      new Ie(a - t, s - i, a + t, s + i)
    );
  }
  getMarkers() {
    return null;
  }
}
class hc extends Y {
  constructor() {
    (super(...arguments), (this.type = "line"));
  }
  getPoints() {
    return [
      new re(
        this.getAttribute("x1").getPixels("x"),
        this.getAttribute("y1").getPixels("y"),
      ),
      new re(
        this.getAttribute("x2").getPixels("x"),
        this.getAttribute("y2").getPixels("y"),
      ),
    ];
  }
  path(e) {
    var [{ x: r, y: t }, { x: i, y: a }] = this.getPoints();
    return (
      e && (e.beginPath(), e.moveTo(r, t), e.lineTo(i, a)),
      new Ie(r, t, i, a)
    );
  }
  getMarkers() {
    var [e, r] = this.getPoints(),
      t = e.angleTo(r);
    return [
      [e, t],
      [r, t],
    ];
  }
}
class $l extends Y {
  constructor(e, r, t) {
    (super(e, r, t),
      (this.type = "polyline"),
      (this.points = []),
      (this.points = re.parsePath(this.getAttribute("points").getString())));
  }
  path(e) {
    var { points: r } = this,
      [{ x: t, y: i }] = r,
      a = new Ie(t, i);
    return (
      e && (e.beginPath(), e.moveTo(t, i)),
      r.forEach((s) => {
        var { x: o, y: u } = s;
        (a.addPoint(o, u), e && e.lineTo(o, u));
      }),
      a
    );
  }
  getMarkers() {
    var { points: e } = this,
      r = e.length - 1,
      t = [];
    return (
      e.forEach((i, a) => {
        a !== r && t.push([i, i.angleTo(e[a + 1])]);
      }),
      t.length > 0 && t.push([e[e.length - 1], t[t.length - 1][1]]),
      t
    );
  }
}
class fc extends $l {
  constructor() {
    (super(...arguments), (this.type = "polygon"));
  }
  path(e) {
    var r = super.path(e),
      [{ x: t, y: i }] = this.points;
    return (e && (e.lineTo(t, i), e.closePath()), r);
  }
}
class cc extends K {
  constructor() {
    (super(...arguments), (this.type = "pattern"));
  }
  createPattern(e, r, t) {
    var i = this.getStyle("width").getPixels("x", !0),
      a = this.getStyle("height").getPixels("y", !0),
      s = new Tr(this.document, null);
    ((s.attributes.viewBox = new M(
      this.document,
      "viewBox",
      this.getAttribute("viewBox").getValue(),
    )),
      (s.attributes.width = new M(this.document, "width", "".concat(i, "px"))),
      (s.attributes.height = new M(
        this.document,
        "height",
        "".concat(a, "px"),
      )),
      (s.attributes.transform = new M(
        this.document,
        "transform",
        this.getAttribute("patternTransform").getValue(),
      )),
      (s.children = this.children));
    var o = this.document.createCanvas(i, a),
      u = o.getContext("2d"),
      l = this.getAttribute("x"),
      h = this.getAttribute("y");
    (l.hasValue() &&
      h.hasValue() &&
      u.translate(l.getPixels("x", !0), h.getPixels("y", !0)),
      t.hasValue()
        ? (this.styles["fill-opacity"] = t)
        : Reflect.deleteProperty(this.styles, "fill-opacity"));
    for (var c = -1; c <= 1; c++)
      for (var v = -1; v <= 1; v++)
        (u.save(),
          (s.attributes.x = new M(this.document, "x", c * o.width)),
          (s.attributes.y = new M(this.document, "y", v * o.height)),
          s.render(u),
          u.restore());
    var f = e.createPattern(o, "repeat");
    return f;
  }
}
class vc extends K {
  constructor() {
    (super(...arguments), (this.type = "marker"));
  }
  render(e, r, t) {
    if (r) {
      var { x: i, y: a } = r,
        s = this.getAttribute("orient").getString("auto"),
        o = this.getAttribute("markerUnits").getString("strokeWidth");
      (e.translate(i, a),
        s === "auto" && e.rotate(t),
        o === "strokeWidth" && e.scale(e.lineWidth, e.lineWidth),
        e.save());
      var u = new Tr(this.document, null);
      ((u.type = this.type),
        (u.attributes.viewBox = new M(
          this.document,
          "viewBox",
          this.getAttribute("viewBox").getValue(),
        )),
        (u.attributes.refX = new M(
          this.document,
          "refX",
          this.getAttribute("refX").getValue(),
        )),
        (u.attributes.refY = new M(
          this.document,
          "refY",
          this.getAttribute("refY").getValue(),
        )),
        (u.attributes.width = new M(
          this.document,
          "width",
          this.getAttribute("markerWidth").getValue(),
        )),
        (u.attributes.height = new M(
          this.document,
          "height",
          this.getAttribute("markerHeight").getValue(),
        )),
        (u.attributes.overflow = new M(
          this.document,
          "overflow",
          this.getAttribute("overflow").getValue(),
        )),
        (u.attributes.fill = new M(
          this.document,
          "fill",
          this.getAttribute("fill").getColor("black"),
        )),
        (u.attributes.stroke = new M(
          this.document,
          "stroke",
          this.getAttribute("stroke").getValue("none"),
        )),
        (u.children = this.children),
        u.render(e),
        e.restore(),
        o === "strokeWidth" && e.scale(1 / e.lineWidth, 1 / e.lineWidth),
        s === "auto" && e.rotate(-t),
        e.translate(-i, -a));
    }
  }
}
class gc extends K {
  constructor() {
    (super(...arguments), (this.type = "defs"));
  }
  render() {}
}
class un extends ir {
  constructor() {
    (super(...arguments), (this.type = "g"));
  }
  getBoundingBox(e) {
    var r = new Ie();
    return (
      this.children.forEach((t) => {
        r.addBoundingBox(t.getBoundingBox(e));
      }),
      r
    );
  }
}
class zl extends K {
  constructor(e, r, t) {
    (super(e, r, t),
      (this.attributesToInherit = ["gradientUnits"]),
      (this.stops = []));
    var { stops: i, children: a } = this;
    a.forEach((s) => {
      s.type === "stop" && i.push(s);
    });
  }
  getGradientUnits() {
    return this.getAttribute("gradientUnits").getString("objectBoundingBox");
  }
  createGradient(e, r, t) {
    var i = this;
    this.getHrefAttribute().hasValue() &&
      ((i = this.getHrefAttribute().getDefinition()),
      this.inheritStopContainer(i));
    var { stops: a } = i,
      s = this.getGradient(e, r);
    if (!s) return this.addParentOpacity(t, a[a.length - 1].color);
    if (
      (a.forEach((p) => {
        s.addColorStop(p.offset, this.addParentOpacity(t, p.color));
      }),
      this.getAttribute("gradientTransform").hasValue())
    ) {
      var { document: o } = this,
        { MAX_VIRTUAL_PIXELS: u, viewPort: l } = o.screen,
        [h] = l.viewPorts,
        c = new Gl(o, null);
      ((c.attributes.x = new M(o, "x", -u / 3)),
        (c.attributes.y = new M(o, "y", -u / 3)),
        (c.attributes.width = new M(o, "width", u)),
        (c.attributes.height = new M(o, "height", u)));
      var v = new un(o, null);
      ((v.attributes.transform = new M(
        o,
        "transform",
        this.getAttribute("gradientTransform").getValue(),
      )),
        (v.children = [c]));
      var f = new Tr(o, null);
      ((f.attributes.x = new M(o, "x", 0)),
        (f.attributes.y = new M(o, "y", 0)),
        (f.attributes.width = new M(o, "width", h.width)),
        (f.attributes.height = new M(o, "height", h.height)),
        (f.children = [v]));
      var g = o.createCanvas(h.width, h.height),
        d = g.getContext("2d");
      return ((d.fillStyle = s), f.render(d), d.createPattern(g, "no-repeat"));
    }
    return s;
  }
  inheritStopContainer(e) {
    this.attributesToInherit.forEach((r) => {
      !this.getAttribute(r).hasValue() &&
        e.getAttribute(r).hasValue() &&
        this.getAttribute(r, !0).setValue(e.getAttribute(r).getValue());
    });
  }
  addParentOpacity(e, r) {
    if (e.hasValue()) {
      var t = new M(this.document, "color", r);
      return t.addOpacity(e).getColor();
    }
    return r;
  }
}
class dc extends zl {
  constructor(e, r, t) {
    (super(e, r, t),
      (this.type = "linearGradient"),
      this.attributesToInherit.push("x1", "y1", "x2", "y2"));
  }
  getGradient(e, r) {
    var t = this.getGradientUnits() === "objectBoundingBox",
      i = t ? r.getBoundingBox(e) : null;
    if (t && !i) return null;
    !this.getAttribute("x1").hasValue() &&
      !this.getAttribute("y1").hasValue() &&
      !this.getAttribute("x2").hasValue() &&
      !this.getAttribute("y2").hasValue() &&
      (this.getAttribute("x1", !0).setValue(0),
      this.getAttribute("y1", !0).setValue(0),
      this.getAttribute("x2", !0).setValue(1),
      this.getAttribute("y2", !0).setValue(0));
    var a = t
        ? i.x + i.width * this.getAttribute("x1").getNumber()
        : this.getAttribute("x1").getPixels("x"),
      s = t
        ? i.y + i.height * this.getAttribute("y1").getNumber()
        : this.getAttribute("y1").getPixels("y"),
      o = t
        ? i.x + i.width * this.getAttribute("x2").getNumber()
        : this.getAttribute("x2").getPixels("x"),
      u = t
        ? i.y + i.height * this.getAttribute("y2").getNumber()
        : this.getAttribute("y2").getPixels("y");
    return a === o && s === u ? null : e.createLinearGradient(a, s, o, u);
  }
}
class pc extends zl {
  constructor(e, r, t) {
    (super(e, r, t),
      (this.type = "radialGradient"),
      this.attributesToInherit.push("cx", "cy", "r", "fx", "fy", "fr"));
  }
  getGradient(e, r) {
    var t = this.getGradientUnits() === "objectBoundingBox",
      i = r.getBoundingBox(e);
    if (t && !i) return null;
    (this.getAttribute("cx").hasValue() ||
      this.getAttribute("cx", !0).setValue("50%"),
      this.getAttribute("cy").hasValue() ||
        this.getAttribute("cy", !0).setValue("50%"),
      this.getAttribute("r").hasValue() ||
        this.getAttribute("r", !0).setValue("50%"));
    var a = t
        ? i.x + i.width * this.getAttribute("cx").getNumber()
        : this.getAttribute("cx").getPixels("x"),
      s = t
        ? i.y + i.height * this.getAttribute("cy").getNumber()
        : this.getAttribute("cy").getPixels("y"),
      o = a,
      u = s;
    (this.getAttribute("fx").hasValue() &&
      (o = t
        ? i.x + i.width * this.getAttribute("fx").getNumber()
        : this.getAttribute("fx").getPixels("x")),
      this.getAttribute("fy").hasValue() &&
        (u = t
          ? i.y + i.height * this.getAttribute("fy").getNumber()
          : this.getAttribute("fy").getPixels("y")));
    var l = t
        ? ((i.width + i.height) / 2) * this.getAttribute("r").getNumber()
        : this.getAttribute("r").getPixels(),
      h = this.getAttribute("fr").getPixels();
    return e.createRadialGradient(o, u, h, a, s, l);
  }
}
class yc extends K {
  constructor(e, r, t) {
    (super(e, r, t), (this.type = "stop"));
    var i = Math.max(0, Math.min(1, this.getAttribute("offset").getNumber())),
      a = this.getStyle("stop-opacity"),
      s = this.getStyle("stop-color", !0);
    (s.getString() === "" && s.setValue("#000"),
      a.hasValue() && (s = s.addOpacity(a)),
      (this.offset = i),
      (this.color = s.getColor()));
  }
}
class ln extends K {
  constructor(e, r, t) {
    (super(e, r, t),
      (this.type = "animate"),
      (this.duration = 0),
      (this.initialValue = null),
      (this.initialUnits = ""),
      (this.removed = !1),
      (this.frozen = !1),
      e.screen.animations.push(this),
      (this.begin = this.getAttribute("begin").getMilliseconds()),
      (this.maxDuration =
        this.begin + this.getAttribute("dur").getMilliseconds()),
      (this.from = this.getAttribute("from")),
      (this.to = this.getAttribute("to")),
      (this.values = new M(e, "values", null)));
    var i = this.getAttribute("values");
    i.hasValue() && this.values.setValue(i.getString().split(";"));
  }
  getProperty() {
    var e = this.getAttribute("attributeType").getString(),
      r = this.getAttribute("attributeName").getString();
    return e === "CSS"
      ? this.parent.getStyle(r, !0)
      : this.parent.getAttribute(r, !0);
  }
  calcValue() {
    var { initialUnits: e } = this,
      { progress: r, from: t, to: i } = this.getProgress(),
      a = t.getNumber() + (i.getNumber() - t.getNumber()) * r;
    return (e === "%" && (a *= 100), "".concat(a).concat(e));
  }
  update(e) {
    var { parent: r } = this,
      t = this.getProperty();
    if (
      (this.initialValue ||
        ((this.initialValue = t.getString()),
        (this.initialUnits = t.getUnits())),
      this.duration > this.maxDuration)
    ) {
      var i = this.getAttribute("fill").getString("remove");
      if (
        this.getAttribute("repeatCount").getString() === "indefinite" ||
        this.getAttribute("repeatDur").getString() === "indefinite"
      )
        this.duration = 0;
      else if (i === "freeze" && !this.frozen)
        ((this.frozen = !0),
          (r.animationFrozen = !0),
          (r.animationFrozenValue = t.getString()));
      else if (i === "remove" && !this.removed)
        return (
          (this.removed = !0),
          t.setValue(
            r.animationFrozen ? r.animationFrozenValue : this.initialValue,
          ),
          !0
        );
      return !1;
    }
    this.duration += e;
    var a = !1;
    if (this.begin < this.duration) {
      var s = this.calcValue(),
        o = this.getAttribute("type");
      if (o.hasValue()) {
        var u = o.getString();
        s = "".concat(u, "(").concat(s, ")");
      }
      (t.setValue(s), (a = !0));
    }
    return a;
  }
  getProgress() {
    var { document: e, values: r } = this,
      t = {
        progress:
          (this.duration - this.begin) / (this.maxDuration - this.begin),
      };
    if (r.hasValue()) {
      var i = t.progress * (r.getValue().length - 1),
        a = Math.floor(i),
        s = Math.ceil(i);
      ((t.from = new M(e, "from", parseFloat(r.getValue()[a]))),
        (t.to = new M(e, "to", parseFloat(r.getValue()[s]))),
        (t.progress = (i - a) / (s - a)));
    } else ((t.from = this.from), (t.to = this.to));
    return t;
  }
}
class mc extends ln {
  constructor() {
    (super(...arguments), (this.type = "animateColor"));
  }
  calcValue() {
    var { progress: e, from: r, to: t } = this.getProgress(),
      i = new ka(r.getColor()),
      a = new ka(t.getColor());
    if (i.ok && a.ok) {
      var s = i.r + (a.r - i.r) * e,
        o = i.g + (a.g - i.g) * e,
        u = i.b + (a.b - i.b) * e;
      return "rgb("
        .concat(Math.floor(s), ", ")
        .concat(Math.floor(o), ", ")
        .concat(Math.floor(u), ")");
    }
    return this.getAttribute("from").getColor();
  }
}
class bc extends ln {
  constructor() {
    (super(...arguments), (this.type = "animateTransform"));
  }
  calcValue() {
    var { progress: e, from: r, to: t } = this.getProgress(),
      i = me(r.getString()),
      a = me(t.getString()),
      s = i
        .map((o, u) => {
          var l = a[u];
          return o + (l - o) * e;
        })
        .join(" ");
    return s;
  }
}
class xc extends K {
  constructor(e, r, t) {
    (super(e, r, t),
      (this.type = "font"),
      (this.glyphs = Object.create(null)),
      (this.horizAdvX = this.getAttribute("horiz-adv-x").getNumber()));
    var { definitions: i } = e,
      { children: a } = this;
    for (var s of a)
      switch (s.type) {
        case "font-face": {
          this.fontFace = s;
          var o = s.getStyle("font-family");
          o.hasValue() && (i[o.getString()] = this);
          break;
        }
        case "missing-glyph":
          this.missingGlyph = s;
          break;
        case "glyph": {
          var u = s;
          u.arabicForm
            ? ((this.isRTL = !0),
              (this.isArabic = !0),
              typeof this.glyphs[u.unicode] > "u" &&
                (this.glyphs[u.unicode] = Object.create(null)),
              (this.glyphs[u.unicode][u.arabicForm] = u))
            : (this.glyphs[u.unicode] = u);
          break;
        }
      }
  }
  render() {}
}
class Oc extends K {
  constructor(e, r, t) {
    (super(e, r, t),
      (this.type = "font-face"),
      (this.ascent = this.getAttribute("ascent").getNumber()),
      (this.descent = this.getAttribute("descent").getNumber()),
      (this.unitsPerEm = this.getAttribute("units-per-em").getNumber()));
  }
}
class Tc extends Y {
  constructor() {
    (super(...arguments), (this.type = "missing-glyph"), (this.horizAdvX = 0));
  }
}
class Sc extends He {
  constructor() {
    (super(...arguments), (this.type = "tref"));
  }
  getText() {
    var e = this.getHrefAttribute().getDefinition();
    if (e) {
      var r = e.children[0];
      if (r) return r.getText();
    }
    return "";
  }
}
class Ec extends He {
  constructor(e, r, t) {
    (super(e, r, t), (this.type = "a"));
    var { childNodes: i } = r,
      a = i[0],
      s = i.length > 0 && Array.from(i).every((o) => o.nodeType === 3);
    ((this.hasText = s), (this.text = s ? this.getTextFromNode(a) : ""));
  }
  getText() {
    return this.text;
  }
  renderChildren(e) {
    if (this.hasText) {
      super.renderChildren(e);
      var { document: r, x: t, y: i } = this,
        { mouse: a } = r.screen,
        s = new M(r, "fontSize", le.parse(r.ctx.font).fontSize);
      a.isWorking() &&
        a.checkBoundingBox(
          this,
          new Ie(t, i - s.getPixels("y"), t + this.measureText(e), i),
        );
    } else if (this.children.length > 0) {
      var o = new un(this.document, null);
      ((o.children = this.children), (o.parent = this), o.render(e));
    }
  }
  onClick() {
    var { window: e } = this.document;
    e && e.open(this.getHrefAttribute().getString());
  }
  onMouseMove() {
    var e = this.document.ctx;
    e.canvas.style.cursor = "pointer";
  }
}
function Zu(n, e) {
  var r = Object.keys(n);
  if (Object.getOwnPropertySymbols) {
    var t = Object.getOwnPropertySymbols(n);
    (e &&
      (t = t.filter(function (i) {
        return Object.getOwnPropertyDescriptor(n, i).enumerable;
      })),
      r.push.apply(r, t));
  }
  return r;
}
function Rr(n) {
  for (var e = 1; e < arguments.length; e++) {
    var r = arguments[e] != null ? arguments[e] : {};
    e % 2
      ? Zu(Object(r), !0).forEach(function (t) {
          on(n, t, r[t]);
        })
      : Object.getOwnPropertyDescriptors
        ? Object.defineProperties(n, Object.getOwnPropertyDescriptors(r))
        : Zu(Object(r)).forEach(function (t) {
            Object.defineProperty(n, t, Object.getOwnPropertyDescriptor(r, t));
          });
  }
  return n;
}
class Rc extends He {
  constructor(e, r, t) {
    (super(e, r, t),
      (this.type = "textPath"),
      (this.textWidth = 0),
      (this.textHeight = 0),
      (this.pathLength = -1),
      (this.glyphInfo = null),
      (this.letterSpacingCache = []),
      (this.measuresCache = new Map([["", 0]])));
    var i = this.getHrefAttribute().getDefinition();
    ((this.text = this.getTextFromNode()),
      (this.dataArray = this.parsePathData(i)));
  }
  getText() {
    return this.text;
  }
  path(e) {
    var { dataArray: r } = this;
    (e && e.beginPath(),
      r.forEach((t) => {
        var { type: i, points: a } = t;
        switch (i) {
          case G.LINE_TO:
            e && e.lineTo(a[0], a[1]);
            break;
          case G.MOVE_TO:
            e && e.moveTo(a[0], a[1]);
            break;
          case G.CURVE_TO:
            e && e.bezierCurveTo(a[0], a[1], a[2], a[3], a[4], a[5]);
            break;
          case G.QUAD_TO:
            e && e.quadraticCurveTo(a[0], a[1], a[2], a[3]);
            break;
          case G.ARC: {
            var [s, o, u, l, h, c, v, f] = a,
              g = u > l ? u : l,
              d = u > l ? 1 : u / l,
              p = u > l ? l / u : 1;
            e &&
              (e.translate(s, o),
              e.rotate(v),
              e.scale(d, p),
              e.arc(0, 0, g, h, h + c, !!(1 - f)),
              e.scale(1 / d, 1 / p),
              e.rotate(-v),
              e.translate(-s, -o));
            break;
          }
          case G.CLOSE_PATH:
            e && e.closePath();
            break;
        }
      }));
  }
  renderChildren(e) {
    (this.setTextData(e), e.save());
    var r = this.parent.getStyle("text-decoration").getString(),
      t = this.getFontSize(),
      { glyphInfo: i } = this,
      a = e.fillStyle;
    (r === "underline" && e.beginPath(),
      i.forEach((s, o) => {
        var { p0: u, p1: l, rotation: h, text: c } = s;
        (e.save(),
          e.translate(u.x, u.y),
          e.rotate(h),
          e.fillStyle && e.fillText(c, 0, 0),
          e.strokeStyle && e.strokeText(c, 0, 0),
          e.restore(),
          r === "underline" &&
            (o === 0 && e.moveTo(u.x, u.y + t / 8),
            e.lineTo(l.x, l.y + t / 5)));
      }),
      r === "underline" &&
        ((e.lineWidth = t / 20),
        (e.strokeStyle = a),
        e.stroke(),
        e.closePath()),
      e.restore());
  }
  getLetterSpacingAt() {
    var e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : 0;
    return this.letterSpacingCache[e] || 0;
  }
  findSegmentToFitChar(e, r, t, i, a, s, o, u, l) {
    var h = s,
      c = this.measureText(e, u);
    (u === " " && r === "justify" && t < i && (c += (i - t) / a),
      l > -1 && (h += this.getLetterSpacingAt(l)));
    var v = this.textHeight / 20,
      f = this.getEquidistantPointOnPath(h, v, 0),
      g = this.getEquidistantPointOnPath(h + c, v, 0),
      d = { p0: f, p1: g },
      p = f && g ? Math.atan2(g.y - f.y, g.x - f.x) : 0;
    if (o) {
      var y = Math.cos(Math.PI / 2 + p) * o,
        m = Math.cos(-p) * o;
      ((d.p0 = Rr(Rr({}, f), {}, { x: f.x + y, y: f.y + m })),
        (d.p1 = Rr(Rr({}, g), {}, { x: g.x + y, y: g.y + m })));
    }
    return ((h += c), { offset: h, segment: d, rotation: p });
  }
  measureText(e, r) {
    var { measuresCache: t } = this,
      i = r || this.getText();
    if (t.has(i)) return t.get(i);
    var a = this.measureTargetText(e, i);
    return (t.set(i, a), a);
  }
  setTextData(e) {
    if (!this.glyphInfo) {
      var r = this.getText(),
        t = r.split(""),
        i = r.split(" ").length - 1,
        a = this.parent
          .getAttribute("dx")
          .split()
          .map((x) => x.getPixels("x")),
        s = this.parent.getAttribute("dy").getPixels("y"),
        o = this.parent.getStyle("text-anchor").getString("start"),
        u = this.getStyle("letter-spacing"),
        l = this.parent.getStyle("letter-spacing"),
        h = 0;
      !u.hasValue() || u.getValue() === "inherit"
        ? (h = l.getPixels())
        : u.hasValue() &&
          u.getValue() !== "initial" &&
          u.getValue() !== "unset" &&
          (h = u.getPixels());
      var c = [],
        v = r.length;
      this.letterSpacingCache = c;
      for (var f = 0; f < v; f++) c.push(typeof a[f] < "u" ? a[f] : h);
      var g = c.reduce((x, S, E) => (E === 0 ? 0 : x + S || 0), 0),
        d = this.measureText(e),
        p = Math.max(d + g, 0);
      ((this.textWidth = d),
        (this.textHeight = this.getFontSize()),
        (this.glyphInfo = []));
      var y = this.getPathLength(),
        m = this.getStyle("startOffset").getNumber(0) * y,
        b = 0;
      ((o === "middle" || o === "center") && (b = -p / 2),
        (o === "end" || o === "right") && (b = -p),
        (b += m),
        t.forEach((x, S) => {
          var {
            offset: E,
            segment: T,
            rotation: R,
          } = this.findSegmentToFitChar(e, o, p, y, i, b, s, x, S);
          ((b = E),
            !(!T.p0 || !T.p1) &&
              this.glyphInfo.push({
                text: t[S],
                p0: T.p0,
                p1: T.p1,
                rotation: R,
              }));
        }));
    }
  }
  parsePathData(e) {
    if (((this.pathLength = -1), !e)) return [];
    var r = [],
      { pathParser: t } = e;
    for (t.reset(); !t.isEnd();) {
      var { current: i } = t,
        a = i ? i.x : 0,
        s = i ? i.y : 0,
        o = t.next(),
        u = o.type,
        l = [];
      switch (o.type) {
        case G.MOVE_TO:
          this.pathM(t, l);
          break;
        case G.LINE_TO:
          u = this.pathL(t, l);
          break;
        case G.HORIZ_LINE_TO:
          u = this.pathH(t, l);
          break;
        case G.VERT_LINE_TO:
          u = this.pathV(t, l);
          break;
        case G.CURVE_TO:
          this.pathC(t, l);
          break;
        case G.SMOOTH_CURVE_TO:
          u = this.pathS(t, l);
          break;
        case G.QUAD_TO:
          this.pathQ(t, l);
          break;
        case G.SMOOTH_QUAD_TO:
          u = this.pathT(t, l);
          break;
        case G.ARC:
          l = this.pathA(t);
          break;
        case G.CLOSE_PATH:
          Y.pathZ(t);
          break;
      }
      o.type !== G.CLOSE_PATH
        ? r.push({
            type: u,
            points: l,
            start: { x: a, y: s },
            pathLength: this.calcLength(a, s, u, l),
          })
        : r.push({ type: G.CLOSE_PATH, points: [], pathLength: 0 });
    }
    return r;
  }
  pathM(e, r) {
    var { x: t, y: i } = Y.pathM(e).point;
    r.push(t, i);
  }
  pathL(e, r) {
    var { x: t, y: i } = Y.pathL(e).point;
    return (r.push(t, i), G.LINE_TO);
  }
  pathH(e, r) {
    var { x: t, y: i } = Y.pathH(e).point;
    return (r.push(t, i), G.LINE_TO);
  }
  pathV(e, r) {
    var { x: t, y: i } = Y.pathV(e).point;
    return (r.push(t, i), G.LINE_TO);
  }
  pathC(e, r) {
    var { point: t, controlPoint: i, currentPoint: a } = Y.pathC(e);
    r.push(t.x, t.y, i.x, i.y, a.x, a.y);
  }
  pathS(e, r) {
    var { point: t, controlPoint: i, currentPoint: a } = Y.pathS(e);
    return (r.push(t.x, t.y, i.x, i.y, a.x, a.y), G.CURVE_TO);
  }
  pathQ(e, r) {
    var { controlPoint: t, currentPoint: i } = Y.pathQ(e);
    r.push(t.x, t.y, i.x, i.y);
  }
  pathT(e, r) {
    var { controlPoint: t, currentPoint: i } = Y.pathT(e);
    return (r.push(t.x, t.y, i.x, i.y), G.QUAD_TO);
  }
  pathA(e) {
    var {
      rX: r,
      rY: t,
      sweepFlag: i,
      xAxisRotation: a,
      centp: s,
      a1: o,
      ad: u,
    } = Y.pathA(e);
    return (
      i === 0 && u > 0 && (u -= 2 * Math.PI),
      i === 1 && u < 0 && (u += 2 * Math.PI),
      [s.x, s.y, r, t, o, u, a, i]
    );
  }
  calcLength(e, r, t, i) {
    var a = 0,
      s = null,
      o = null,
      u = 0;
    switch (t) {
      case G.LINE_TO:
        return this.getLineLength(e, r, i[0], i[1]);
      case G.CURVE_TO:
        for (
          a = 0,
            s = this.getPointOnCubicBezier(
              0,
              e,
              r,
              i[0],
              i[1],
              i[2],
              i[3],
              i[4],
              i[5],
            ),
            u = 0.01;
          u <= 1;
          u += 0.01
        )
          ((o = this.getPointOnCubicBezier(
            u,
            e,
            r,
            i[0],
            i[1],
            i[2],
            i[3],
            i[4],
            i[5],
          )),
            (a += this.getLineLength(s.x, s.y, o.x, o.y)),
            (s = o));
        return a;
      case G.QUAD_TO:
        for (
          a = 0,
            s = this.getPointOnQuadraticBezier(0, e, r, i[0], i[1], i[2], i[3]),
            u = 0.01;
          u <= 1;
          u += 0.01
        )
          ((o = this.getPointOnQuadraticBezier(
            u,
            e,
            r,
            i[0],
            i[1],
            i[2],
            i[3],
          )),
            (a += this.getLineLength(s.x, s.y, o.x, o.y)),
            (s = o));
        return a;
      case G.ARC: {
        a = 0;
        var l = i[4],
          h = i[5],
          c = i[4] + h,
          v = Math.PI / 180;
        if (
          (Math.abs(l - c) < v && (v = Math.abs(l - c)),
          (s = this.getPointOnEllipticalArc(i[0], i[1], i[2], i[3], l, 0)),
          h < 0)
        )
          for (u = l - v; u > c; u -= v)
            ((o = this.getPointOnEllipticalArc(i[0], i[1], i[2], i[3], u, 0)),
              (a += this.getLineLength(s.x, s.y, o.x, o.y)),
              (s = o));
        else
          for (u = l + v; u < c; u += v)
            ((o = this.getPointOnEllipticalArc(i[0], i[1], i[2], i[3], u, 0)),
              (a += this.getLineLength(s.x, s.y, o.x, o.y)),
              (s = o));
        return (
          (o = this.getPointOnEllipticalArc(i[0], i[1], i[2], i[3], c, 0)),
          (a += this.getLineLength(s.x, s.y, o.x, o.y)),
          a
        );
      }
    }
    return 0;
  }
  getPointOnLine(e, r, t, i, a) {
    var s = arguments.length > 5 && arguments[5] !== void 0 ? arguments[5] : r,
      o = arguments.length > 6 && arguments[6] !== void 0 ? arguments[6] : t,
      u = (a - t) / (i - r + ar),
      l = Math.sqrt((e * e) / (1 + u * u));
    i < r && (l *= -1);
    var h = u * l,
      c = null;
    if (i === r) c = { x: s, y: o + h };
    else if ((o - t) / (s - r + ar) === u) c = { x: s + l, y: o + h };
    else {
      var v = 0,
        f = 0,
        g = this.getLineLength(r, t, i, a);
      if (g < ar) return null;
      var d = (s - r) * (i - r) + (o - t) * (a - t);
      ((d /= g * g), (v = r + d * (i - r)), (f = t + d * (a - t)));
      var p = this.getLineLength(s, o, v, f),
        y = Math.sqrt(e * e - p * p);
      ((l = Math.sqrt((y * y) / (1 + u * u))),
        i < r && (l *= -1),
        (h = u * l),
        (c = { x: v + l, y: f + h }));
    }
    return c;
  }
  getPointOnPath(e) {
    var r = this.getPathLength(),
      t = 0,
      i = null;
    if (e < -5e-5 || e - 5e-5 > r) return null;
    var { dataArray: a } = this;
    for (var s of a) {
      if (s && (s.pathLength < 5e-5 || t + s.pathLength + 5e-5 < e)) {
        t += s.pathLength;
        continue;
      }
      var o = e - t,
        u = 0;
      switch (s.type) {
        case G.LINE_TO:
          i = this.getPointOnLine(
            o,
            s.start.x,
            s.start.y,
            s.points[0],
            s.points[1],
            s.start.x,
            s.start.y,
          );
          break;
        case G.ARC: {
          var l = s.points[4],
            h = s.points[5],
            c = s.points[4] + h;
          if (
            ((u = l + (o / s.pathLength) * h),
            (h < 0 && u < c) || (h >= 0 && u > c))
          )
            break;
          i = this.getPointOnEllipticalArc(
            s.points[0],
            s.points[1],
            s.points[2],
            s.points[3],
            u,
            s.points[6],
          );
          break;
        }
        case G.CURVE_TO:
          ((u = o / s.pathLength),
            u > 1 && (u = 1),
            (i = this.getPointOnCubicBezier(
              u,
              s.start.x,
              s.start.y,
              s.points[0],
              s.points[1],
              s.points[2],
              s.points[3],
              s.points[4],
              s.points[5],
            )));
          break;
        case G.QUAD_TO:
          ((u = o / s.pathLength),
            u > 1 && (u = 1),
            (i = this.getPointOnQuadraticBezier(
              u,
              s.start.x,
              s.start.y,
              s.points[0],
              s.points[1],
              s.points[2],
              s.points[3],
            )));
          break;
      }
      if (i) return i;
      break;
    }
    return null;
  }
  getLineLength(e, r, t, i) {
    return Math.sqrt((t - e) * (t - e) + (i - r) * (i - r));
  }
  getPathLength() {
    return (
      this.pathLength === -1 &&
        (this.pathLength = this.dataArray.reduce(
          (e, r) => (r.pathLength > 0 ? e + r.pathLength : e),
          0,
        )),
      this.pathLength
    );
  }
  getPointOnCubicBezier(e, r, t, i, a, s, o, u, l) {
    var h = u * zu(e) + s * Hu(e) + i * Wu(e) + r * Yu(e),
      c = l * zu(e) + o * Hu(e) + a * Wu(e) + t * Yu(e);
    return { x: h, y: c };
  }
  getPointOnQuadraticBezier(e, r, t, i, a, s, o) {
    var u = s * Xu(e) + i * Ku(e) + r * Qu(e),
      l = o * Xu(e) + a * Ku(e) + t * Qu(e);
    return { x: u, y: l };
  }
  getPointOnEllipticalArc(e, r, t, i, a, s) {
    var o = Math.cos(s),
      u = Math.sin(s),
      l = { x: t * Math.cos(a), y: i * Math.sin(a) };
    return { x: e + (l.x * o - l.y * u), y: r + (l.x * u + l.y * o) };
  }
  buildEquidistantCache(e, r) {
    var t = this.getPathLength(),
      i = r || 0.25,
      a = e || t / 100;
    if (
      !this.equidistantCache ||
      this.equidistantCache.step !== a ||
      this.equidistantCache.precision !== i
    ) {
      this.equidistantCache = { step: a, precision: i, points: [] };
      for (var s = 0, o = 0; o <= t; o += i) {
        var u = this.getPointOnPath(o),
          l = this.getPointOnPath(o + i);
        !u ||
          !l ||
          ((s += this.getLineLength(u.x, u.y, l.x, l.y)),
          s >= a &&
            (this.equidistantCache.points.push({ x: u.x, y: u.y, distance: o }),
            (s -= a)));
      }
    }
  }
  getEquidistantPointOnPath(e, r, t) {
    if (
      (this.buildEquidistantCache(r, t),
      e < 0 || e - this.getPathLength() > 5e-5)
    )
      return null;
    var i = Math.round(
      (e / this.getPathLength()) * (this.equidistantCache.points.length - 1),
    );
    return this.equidistantCache.points[i] || null;
  }
}
var Cc =
  /^\s*data:(([^/,;]+\/[^/,;]+)(?:;([^,;=]+=[^,;=]+))?)?(?:;(base64))?,(.*)$/i;
class wc extends ir {
  constructor(e, r, t) {
    (super(e, r, t), (this.type = "image"), (this.loaded = !1));
    var i = this.getHrefAttribute().getString();
    if (i) {
      var a = i.endsWith(".svg") || /^\s*data:image\/svg\+xml/i.test(i);
      (e.images.push(this),
        a ? this.loadSvg(i) : this.loadImage(i),
        (this.isSvg = a));
    }
  }
  loadImage(e) {
    var r = this;
    return Be(function* () {
      try {
        var t = yield r.document.createImage(e);
        r.image = t;
      } catch (i) {
        console.error('Error while loading image "'.concat(e, '":'), i);
      }
      r.loaded = !0;
    })();
  }
  loadSvg(e) {
    var r = this;
    return Be(function* () {
      var t = Cc.exec(e);
      if (t) {
        var i = t[5];
        t[4] === "base64"
          ? (r.image = atob(i))
          : (r.image = decodeURIComponent(i));
      } else
        try {
          var a = yield r.document.fetch(e),
            s = yield a.text();
          r.image = s;
        } catch (o) {
          console.error('Error while loading image "'.concat(e, '":'), o);
        }
      r.loaded = !0;
    })();
  }
  renderChildren(e) {
    var { document: r, image: t, loaded: i } = this,
      a = this.getAttribute("x").getPixels("x"),
      s = this.getAttribute("y").getPixels("y"),
      o = this.getStyle("width").getPixels("x"),
      u = this.getStyle("height").getPixels("y");
    if (!(!i || !t || !o || !u)) {
      if ((e.save(), e.translate(a, s), this.isSvg)) {
        var l = r.canvg.forkString(e, this.image, {
          ignoreMouse: !0,
          ignoreAnimation: !0,
          ignoreDimensions: !0,
          ignoreClear: !0,
          offsetX: 0,
          offsetY: 0,
          scaleWidth: o,
          scaleHeight: u,
        });
        ((l.document.documentElement.parent = this), l.render());
      } else {
        var h = this.image;
        (r.setViewBox({
          ctx: e,
          aspectRatio: this.getAttribute("preserveAspectRatio").getString(),
          width: o,
          desiredWidth: h.width,
          height: u,
          desiredHeight: h.height,
        }),
          this.loaded &&
            (typeof h.complete > "u" || h.complete) &&
            e.drawImage(h, 0, 0));
      }
      e.restore();
    }
  }
  getBoundingBox() {
    var e = this.getAttribute("x").getPixels("x"),
      r = this.getAttribute("y").getPixels("y"),
      t = this.getStyle("width").getPixels("x"),
      i = this.getStyle("height").getPixels("y");
    return new Ie(e, r, e + t, r + i);
  }
}
class Pc extends ir {
  constructor() {
    (super(...arguments), (this.type = "symbol"));
  }
  render(e) {}
}
class Ac {
  constructor(e) {
    ((this.document = e), (this.loaded = !1), e.fonts.push(this));
  }
  load(e, r) {
    var t = this;
    return Be(function* () {
      try {
        var { document: i } = t,
          a = yield i.canvg.parser.load(r),
          s = a.getElementsByTagName("font");
        Array.from(s).forEach((o) => {
          var u = i.createElement(o);
          i.definitions[e] = u;
        });
      } catch (o) {
        console.error('Error while loading font "'.concat(r, '":'), o);
      }
      t.loaded = !0;
    })();
  }
}
class Hl extends K {
  constructor(e, r, t) {
    (super(e, r, t), (this.type = "style"));
    var i = or(
        Array.from(r.childNodes)
          .map((s) => s.textContent)
          .join("")
          .replace(
            /(\/\*([^*]|[\r\n]|(\*+([^*/]|[\r\n])))*\*+\/)|(^[\s]*\/\/.*)/gm,
            "",
          )
          .replace(/@import.*;/g, ""),
      ),
      a = i.split("}");
    a.forEach((s) => {
      var o = s.trim();
      if (o) {
        var u = o.split("{"),
          l = u[0].split(","),
          h = u[1].split(";");
        l.forEach((c) => {
          var v = c.trim();
          if (v) {
            var f = e.styles[v] || {};
            if (
              (h.forEach((p) => {
                var y = p.indexOf(":"),
                  m = p.substr(0, y).trim(),
                  b = p.substr(y + 1, p.length - y).trim();
                m && b && (f[m] = new M(e, m, b));
              }),
              (e.styles[v] = f),
              (e.stylesSpecificity[v] = $f(v)),
              v === "@font-face")
            ) {
              var g = f["font-family"].getString().replace(/"|'/g, ""),
                d = f.src.getString().split(",");
              d.forEach((p) => {
                if (p.indexOf('format("svg")') > 0) {
                  var y = Ll(p);
                  y && new Ac(e).load(g, y);
                }
              });
            }
          }
        });
      }
    });
  }
}
Hl.parseExternalUrl = Ll;
class Ic extends ir {
  constructor() {
    (super(...arguments), (this.type = "use"));
  }
  setContext(e) {
    super.setContext(e);
    var r = this.getAttribute("x"),
      t = this.getAttribute("y");
    (r.hasValue() && e.translate(r.getPixels("x"), 0),
      t.hasValue() && e.translate(0, t.getPixels("y")));
  }
  path(e) {
    var { element: r } = this;
    r && r.path(e);
  }
  renderChildren(e) {
    var { document: r, element: t } = this;
    if (t) {
      var i = t;
      if (
        (t.type === "symbol" &&
          ((i = new Tr(r, null)),
          (i.attributes.viewBox = new M(
            r,
            "viewBox",
            t.getAttribute("viewBox").getString(),
          )),
          (i.attributes.preserveAspectRatio = new M(
            r,
            "preserveAspectRatio",
            t.getAttribute("preserveAspectRatio").getString(),
          )),
          (i.attributes.overflow = new M(
            r,
            "overflow",
            t.getAttribute("overflow").getString(),
          )),
          (i.children = t.children),
          (t.styles.opacity = new M(r, "opacity", this.calculateOpacity()))),
        i.type === "svg")
      ) {
        var a = this.getStyle("width", !1, !0),
          s = this.getStyle("height", !1, !0);
        (a.hasValue() &&
          (i.attributes.width = new M(r, "width", a.getString())),
          s.hasValue() &&
            (i.attributes.height = new M(r, "height", s.getString())));
      }
      var o = i.parent;
      ((i.parent = this), i.render(e), (i.parent = o));
    }
  }
  getBoundingBox(e) {
    var { element: r } = this;
    return r ? r.getBoundingBox(e) : null;
  }
  elementTransform() {
    var { document: e, element: r } = this;
    return er.fromElement(e, r);
  }
  get element() {
    return (
      this.cachedElement ||
        (this.cachedElement = this.getHrefAttribute().getDefinition()),
      this.cachedElement
    );
  }
}
function Cr(n, e, r, t, i, a) {
  return n[r * t * 4 + e * 4 + a];
}
function wr(n, e, r, t, i, a, s) {
  n[r * t * 4 + e * 4 + a] = s;
}
function te(n, e, r) {
  var t = n[e];
  return t * r;
}
function je(n, e, r, t) {
  return e + Math.cos(n) * r + Math.sin(n) * t;
}
class Wl extends K {
  constructor(e, r, t) {
    (super(e, r, t), (this.type = "feColorMatrix"));
    var i = me(this.getAttribute("values").getString());
    switch (this.getAttribute("type").getString("matrix")) {
      case "saturate": {
        var a = i[0];
        i = [
          0.213 + 0.787 * a,
          0.715 - 0.715 * a,
          0.072 - 0.072 * a,
          0,
          0,
          0.213 - 0.213 * a,
          0.715 + 0.285 * a,
          0.072 - 0.072 * a,
          0,
          0,
          0.213 - 0.213 * a,
          0.715 - 0.715 * a,
          0.072 + 0.928 * a,
          0,
          0,
          0,
          0,
          0,
          1,
          0,
          0,
          0,
          0,
          0,
          1,
        ];
        break;
      }
      case "hueRotate": {
        var s = (i[0] * Math.PI) / 180;
        i = [
          je(s, 0.213, 0.787, -0.213),
          je(s, 0.715, -0.715, -0.715),
          je(s, 0.072, -0.072, 0.928),
          0,
          0,
          je(s, 0.213, -0.213, 0.143),
          je(s, 0.715, 0.285, 0.14),
          je(s, 0.072, -0.072, -0.283),
          0,
          0,
          je(s, 0.213, -0.213, -0.787),
          je(s, 0.715, -0.715, 0.715),
          je(s, 0.072, 0.928, 0.072),
          0,
          0,
          0,
          0,
          0,
          1,
          0,
          0,
          0,
          0,
          0,
          1,
        ];
        break;
      }
      case "luminanceToAlpha":
        i = [
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.2125, 0.7154, 0.0721,
          0, 0, 0, 0, 0, 0, 1,
        ];
        break;
    }
    ((this.matrix = i),
      (this.includeOpacity = this.getAttribute("includeOpacity").hasValue()));
  }
  apply(e, r, t, i, a) {
    for (
      var { includeOpacity: s, matrix: o } = this,
        u = e.getImageData(0, 0, i, a),
        l = 0;
      l < a;
      l++
    )
      for (var h = 0; h < i; h++) {
        var c = Cr(u.data, h, l, i, a, 0),
          v = Cr(u.data, h, l, i, a, 1),
          f = Cr(u.data, h, l, i, a, 2),
          g = Cr(u.data, h, l, i, a, 3),
          d =
            te(o, 0, c) + te(o, 1, v) + te(o, 2, f) + te(o, 3, g) + te(o, 4, 1),
          p =
            te(o, 5, c) + te(o, 6, v) + te(o, 7, f) + te(o, 8, g) + te(o, 9, 1),
          y =
            te(o, 10, c) +
            te(o, 11, v) +
            te(o, 12, f) +
            te(o, 13, g) +
            te(o, 14, 1),
          m =
            te(o, 15, c) +
            te(o, 16, v) +
            te(o, 17, f) +
            te(o, 18, g) +
            te(o, 19, 1);
        (s && ((d = 0), (p = 0), (y = 0), (m *= g / 255)),
          wr(u.data, h, l, i, a, 0, d),
          wr(u.data, h, l, i, a, 1, p),
          wr(u.data, h, l, i, a, 2, y),
          wr(u.data, h, l, i, a, 3, m));
      }
    (e.clearRect(0, 0, i, a), e.putImageData(u, 0, 0));
  }
}
class Wr extends K {
  constructor() {
    (super(...arguments), (this.type = "mask"));
  }
  apply(e, r) {
    var { document: t } = this,
      i = this.getAttribute("x").getPixels("x"),
      a = this.getAttribute("y").getPixels("y"),
      s = this.getStyle("width").getPixels("x"),
      o = this.getStyle("height").getPixels("y");
    if (!s && !o) {
      var u = new Ie();
      (this.children.forEach((g) => {
        u.addBoundingBox(g.getBoundingBox(e));
      }),
        (i = Math.floor(u.x1)),
        (a = Math.floor(u.y1)),
        (s = Math.floor(u.width)),
        (o = Math.floor(u.height)));
    }
    var l = this.removeStyles(r, Wr.ignoreStyles),
      h = t.createCanvas(i + s, a + o),
      c = h.getContext("2d");
    (t.screen.setDefaults(c),
      this.renderChildren(c),
      new Wl(t, {
        nodeType: 1,
        childNodes: [],
        attributes: [
          { nodeName: "type", value: "luminanceToAlpha" },
          { nodeName: "includeOpacity", value: "true" },
        ],
      }).apply(c, 0, 0, i + s, a + o));
    var v = t.createCanvas(i + s, a + o),
      f = v.getContext("2d");
    (t.screen.setDefaults(f),
      r.render(f),
      (f.globalCompositeOperation = "destination-in"),
      (f.fillStyle = c.createPattern(h, "no-repeat")),
      f.fillRect(0, 0, i + s, a + o),
      (e.fillStyle = f.createPattern(v, "no-repeat")),
      e.fillRect(0, 0, i + s, a + o),
      this.restoreStyles(r, l));
  }
  render(e) {}
}
Wr.ignoreStyles = ["mask", "transform", "clip-path"];
var Ju = () => {};
class Nc extends K {
  constructor() {
    (super(...arguments), (this.type = "clipPath"));
  }
  apply(e) {
    var { document: r } = this,
      t = Reflect.getPrototypeOf(e),
      { beginPath: i, closePath: a } = e;
    (t && ((t.beginPath = Ju), (t.closePath = Ju)),
      Reflect.apply(i, e, []),
      this.children.forEach((s) => {
        if (!(typeof s.path > "u")) {
          var o = typeof s.elementTransform < "u" ? s.elementTransform() : null;
          (o || (o = er.fromElement(r, s)),
            o && o.apply(e),
            s.path(e),
            t && (t.closePath = a),
            o && o.unapply(e));
        }
      }),
      Reflect.apply(a, e, []),
      e.clip(),
      t && ((t.beginPath = i), (t.closePath = a)));
  }
  render(e) {}
}
class Yr extends K {
  constructor() {
    (super(...arguments), (this.type = "filter"));
  }
  apply(e, r) {
    var { document: t, children: i } = this,
      a = r.getBoundingBox(e);
    if (a) {
      var s = 0,
        o = 0;
      i.forEach((y) => {
        var m = y.extraFilterDistance || 0;
        ((s = Math.max(s, m)), (o = Math.max(o, m)));
      });
      var u = Math.floor(a.width),
        l = Math.floor(a.height),
        h = u + 2 * s,
        c = l + 2 * o;
      if (!(h < 1 || c < 1)) {
        var v = Math.floor(a.x),
          f = Math.floor(a.y),
          g = this.removeStyles(r, Yr.ignoreStyles),
          d = t.createCanvas(h, c),
          p = d.getContext("2d");
        (t.screen.setDefaults(p),
          p.translate(-v + s, -f + o),
          r.render(p),
          i.forEach((y) => {
            typeof y.apply == "function" && y.apply(p, 0, 0, h, c);
          }),
          e.drawImage(d, 0, 0, h, c, v - s, f - o, h, c),
          this.restoreStyles(r, g));
      }
    }
  }
  render(e) {}
}
Yr.ignoreStyles = ["filter", "transform", "clip-path"];
class _c extends K {
  constructor(e, r, t) {
    (super(e, r, t),
      (this.type = "feDropShadow"),
      this.addStylesFromStyleDefinition());
  }
  apply(e, r, t, i, a) {}
}
class Mc extends K {
  constructor() {
    (super(...arguments), (this.type = "feMorphology"));
  }
  apply(e, r, t, i, a) {}
}
class qc extends K {
  constructor() {
    (super(...arguments), (this.type = "feComposite"));
  }
  apply(e, r, t, i, a) {}
}
class Dc extends K {
  constructor(e, r, t) {
    (super(e, r, t),
      (this.type = "feGaussianBlur"),
      (this.blurRadius = Math.floor(
        this.getAttribute("stdDeviation").getNumber(),
      )),
      (this.extraFilterDistance = this.blurRadius));
  }
  apply(e, r, t, i, a) {
    var { document: s, blurRadius: o } = this,
      u = s.window ? s.window.document.body : null,
      l = e.canvas;
    ((l.id = s.getUniqueId()),
      u && ((l.style.display = "none"), u.appendChild(l)),
      Pf(l, r, t, i, a, o),
      u && u.removeChild(l));
  }
}
class Vc extends K {
  constructor() {
    (super(...arguments), (this.type = "title"));
  }
}
class Lc extends K {
  constructor() {
    (super(...arguments), (this.type = "desc"));
  }
}
var kc = {
  svg: Tr,
  rect: Gl,
  circle: uc,
  ellipse: lc,
  line: hc,
  polyline: $l,
  polygon: fc,
  path: Y,
  pattern: cc,
  marker: vc,
  defs: gc,
  linearGradient: dc,
  radialGradient: pc,
  stop: yc,
  animate: ln,
  animateColor: mc,
  animateTransform: bc,
  font: xc,
  "font-face": Oc,
  "missing-glyph": Tc,
  glyph: Ul,
  text: He,
  tspan: Hr,
  tref: Sc,
  a: Ec,
  textPath: Rc,
  image: wc,
  g: un,
  symbol: Pc,
  style: Hl,
  use: Ic,
  mask: Wr,
  clipPath: Nc,
  filter: Yr,
  feDropShadow: _c,
  feMorphology: Mc,
  feComposite: qc,
  feColorMatrix: Wl,
  feGaussianBlur: Dc,
  title: Vc,
  desc: Lc,
};
function el(n, e) {
  var r = Object.keys(n);
  if (Object.getOwnPropertySymbols) {
    var t = Object.getOwnPropertySymbols(n);
    (e &&
      (t = t.filter(function (i) {
        return Object.getOwnPropertyDescriptor(n, i).enumerable;
      })),
      r.push.apply(r, t));
  }
  return r;
}
function jc(n) {
  for (var e = 1; e < arguments.length; e++) {
    var r = arguments[e] != null ? arguments[e] : {};
    e % 2
      ? el(Object(r), !0).forEach(function (t) {
          on(n, t, r[t]);
        })
      : Object.getOwnPropertyDescriptors
        ? Object.defineProperties(n, Object.getOwnPropertyDescriptors(r))
        : el(Object(r)).forEach(function (t) {
            Object.defineProperty(n, t, Object.getOwnPropertyDescriptor(r, t));
          });
  }
  return n;
}
function Bc(n, e) {
  var r = document.createElement("canvas");
  return ((r.width = n), (r.height = e), r);
}
function Fc(n) {
  return Fa.apply(this, arguments);
}
function Fa() {
  return (
    (Fa = Be(function* (n) {
      var e =
          arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !1,
        r = document.createElement("img");
      return (
        e && (r.crossOrigin = "Anonymous"),
        new Promise((t, i) => {
          ((r.onload = () => {
            t(r);
          }),
            (r.onerror = (a, s, o, u, l) => {
              i(l);
            }),
            (r.src = n));
        })
      );
    })),
    Fa.apply(this, arguments)
  );
}
class ze {
  constructor(e) {
    var {
      rootEmSize: r = 12,
      emSize: t = 12,
      createCanvas: i = ze.createCanvas,
      createImage: a = ze.createImage,
      anonymousCrossOrigin: s,
    } = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
    ((this.canvg = e),
      (this.definitions = Object.create(null)),
      (this.styles = Object.create(null)),
      (this.stylesSpecificity = Object.create(null)),
      (this.images = []),
      (this.fonts = []),
      (this.emSizeStack = []),
      (this.uniqueId = 0),
      (this.screen = e.screen),
      (this.rootEmSize = r),
      (this.emSize = t),
      (this.createCanvas = i),
      (this.createImage = this.bindCreateImage(a, s)),
      this.screen.wait(this.isImagesLoaded.bind(this)),
      this.screen.wait(this.isFontsLoaded.bind(this)));
  }
  bindCreateImage(e, r) {
    return typeof r == "boolean"
      ? (t, i) => e(t, typeof i == "boolean" ? i : r)
      : e;
  }
  get window() {
    return this.screen.window;
  }
  get fetch() {
    return this.screen.fetch;
  }
  get ctx() {
    return this.screen.ctx;
  }
  get emSize() {
    var { emSizeStack: e } = this;
    return e[e.length - 1];
  }
  set emSize(e) {
    var { emSizeStack: r } = this;
    r.push(e);
  }
  popEmSize() {
    var { emSizeStack: e } = this;
    e.pop();
  }
  getUniqueId() {
    return "canvg".concat(++this.uniqueId);
  }
  isImagesLoaded() {
    return this.images.every((e) => e.loaded);
  }
  isFontsLoaded() {
    return this.fonts.every((e) => e.loaded);
  }
  createDocumentElement(e) {
    var r = this.createElement(e.documentElement);
    return (
      (r.root = !0),
      r.addStylesFromStyleDefinition(),
      (this.documentElement = r),
      r
    );
  }
  createElement(e) {
    var r = e.nodeName.replace(/^[^:]+:/, ""),
      t = ze.elementTypes[r];
    return typeof t < "u" ? new t(this, e) : new tc(this, e);
  }
  createTextNode(e) {
    return new oc(this, e);
  }
  setViewBox(e) {
    this.screen.setViewBox(jc({ document: this }, e));
  }
}
ze.createCanvas = Bc;
ze.createImage = Fc;
ze.elementTypes = kc;
function rl(n, e) {
  var r = Object.keys(n);
  if (Object.getOwnPropertySymbols) {
    var t = Object.getOwnPropertySymbols(n);
    (e &&
      (t = t.filter(function (i) {
        return Object.getOwnPropertyDescriptor(n, i).enumerable;
      })),
      r.push.apply(r, t));
  }
  return r;
}
function Ze(n) {
  for (var e = 1; e < arguments.length; e++) {
    var r = arguments[e] != null ? arguments[e] : {};
    e % 2
      ? rl(Object(r), !0).forEach(function (t) {
          on(n, t, r[t]);
        })
      : Object.getOwnPropertyDescriptors
        ? Object.defineProperties(n, Object.getOwnPropertyDescriptors(r))
        : rl(Object(r)).forEach(function (t) {
            Object.defineProperty(n, t, Object.getOwnPropertyDescriptor(r, t));
          });
  }
  return n;
}
class gr {
  constructor(e, r) {
    var t = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
    ((this.parser = new Va(t)),
      (this.screen = new zr(e, t)),
      (this.options = t));
    var i = new ze(this, t),
      a = i.createDocumentElement(r);
    ((this.document = i), (this.documentElement = a));
  }
  static from(e, r) {
    var t = arguments;
    return Be(function* () {
      var i = t.length > 2 && t[2] !== void 0 ? t[2] : {},
        a = new Va(i),
        s = yield a.parse(r);
      return new gr(e, s, i);
    })();
  }
  static fromString(e, r) {
    var t = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {},
      i = new Va(t),
      a = i.parseFromString(r);
    return new gr(e, a, t);
  }
  fork(e, r) {
    var t = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
    return gr.from(e, r, Ze(Ze({}, this.options), t));
  }
  forkString(e, r) {
    var t = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
    return gr.fromString(e, r, Ze(Ze({}, this.options), t));
  }
  ready() {
    return this.screen.ready();
  }
  isReady() {
    return this.screen.isReady();
  }
  render() {
    var e = arguments,
      r = this;
    return Be(function* () {
      var t = e.length > 0 && e[0] !== void 0 ? e[0] : {};
      (r.start(
        Ze({ enableRedraw: !0, ignoreAnimation: !0, ignoreMouse: !0 }, t),
      ),
        yield r.ready(),
        r.stop());
    })();
  }
  start() {
    var e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {},
      { documentElement: r, screen: t, options: i } = this;
    t.start(r, Ze(Ze({ enableRedraw: !0 }, i), e));
  }
  stop() {
    this.screen.stop();
  }
  resize(e) {
    var r = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : e,
      t = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : !1;
    this.documentElement.resize(e, r, t);
  }
}
export {
  Ec as AElement,
  mc as AnimateColorElement,
  ln as AnimateElement,
  bc as AnimateTransformElement,
  Ie as BoundingBox,
  zu as CB1,
  Hu as CB2,
  Wu as CB3,
  Yu as CB4,
  gr as Canvg,
  uc as CircleElement,
  Nc as ClipPathElement,
  gc as DefsElement,
  Lc as DescElement,
  ze as Document,
  K as Element,
  lc as EllipseElement,
  Wl as FeColorMatrixElement,
  qc as FeCompositeElement,
  _c as FeDropShadowElement,
  Dc as FeGaussianBlurElement,
  Mc as FeMorphologyElement,
  Yr as FilterElement,
  le as Font,
  xc as FontElement,
  Oc as FontFaceElement,
  un as GElement,
  Ul as GlyphElement,
  zl as GradientElement,
  wc as ImageElement,
  hc as LineElement,
  dc as LinearGradientElement,
  vc as MarkerElement,
  Wr as MaskElement,
  Bl as Matrix,
  Tc as MissingGlyphElement,
  Hf as Mouse,
  ar as PSEUDO_ZERO,
  Va as Parser,
  Y as PathElement,
  G as PathParser,
  cc as PatternElement,
  re as Point,
  fc as PolygonElement,
  $l as PolylineElement,
  M as Property,
  Xu as QB1,
  Ku as QB2,
  Qu as QB3,
  pc as RadialGradientElement,
  Gl as RectElement,
  ir as RenderedElement,
  Kf as Rotate,
  Tr as SVGElement,
  Ac as SVGFontLoader,
  Qf as Scale,
  zr as Screen,
  Fl as Skew,
  Zf as SkewX,
  Jf as SkewY,
  yc as StopElement,
  Hl as StyleElement,
  Pc as SymbolElement,
  Sc as TRefElement,
  Hr as TSpanElement,
  He as TextElement,
  Rc as TextPathElement,
  Vc as TitleElement,
  er as Transform,
  Xf as Translate,
  tc as UnknownElement,
  Ic as UseElement,
  zf as ViewPort,
  or as compressSpaces,
  gr as default,
  $f as getSelectorSpecificity,
  Df as normalizeAttributeName,
  Vf as normalizeColor,
  Ll as parseExternalUrl,
  Gc as presets,
  me as toNumbers,
  _f as trimLeft,
  Mf as trimRight,
  Gu as vectorMagnitude,
  $u as vectorsAngle,
  Ba as vectorsRatio,
};
