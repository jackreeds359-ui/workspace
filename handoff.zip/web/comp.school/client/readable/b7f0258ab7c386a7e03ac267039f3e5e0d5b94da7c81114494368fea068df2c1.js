import { r as A, o as r, b as Ut } from "./react-vendor-BK1G6oO1.js";
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const Xt = (e) => e.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase(),
  jt = (...e) =>
    e
      .filter((a, n, i) => !!a && a.trim() !== "" && i.indexOf(a) === n)
      .join(" ")
      .trim();
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ var Zt = {
  xmlns: "http://www.w3.org/2000/svg",
  width: 24,
  height: 24,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 2,
  strokeLinecap: "round",
  strokeLinejoin: "round",
};
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const Wt = A.forwardRef(
  (
    {
      color: e = "currentColor",
      size: a = 24,
      strokeWidth: n = 2,
      absoluteStrokeWidth: i,
      className: h = "",
      children: g,
      iconNode: k,
      ...w
    },
    d,
  ) =>
    A.createElement(
      "svg",
      {
        ref: d,
        ...Zt,
        width: a,
        height: a,
        stroke: e,
        strokeWidth: i ? (Number(n) * 24) / Number(a) : n,
        className: jt("lucide", h),
        ...w,
      },
      [
        ...k.map(([p, x]) => A.createElement(p, x)),
        ...(Array.isArray(g) ? g : [g]),
      ],
    ),
);
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const o = (e, a) => {
  const n = A.forwardRef(({ className: i, ...h }, g) =>
    A.createElement(Wt, {
      ref: g,
      iconNode: a,
      className: jt(`lucide-${Xt(e)}`, i),
      ...h,
    }),
  );
  return ((n.displayName = `${e}`), n);
};
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const Me = o("ArrowDownToLine", [
  ["path", { d: "M12 17V3", key: "1cwfxf" }],
  ["path", { d: "m6 11 6 6 6-6", key: "12ii2o" }],
  ["path", { d: "M19 21H5", key: "150jfl" }],
]);
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const Ce = o("ArrowLeftRight", [
  ["path", { d: "M8 3 4 7l4 4", key: "9rb6wj" }],
  ["path", { d: "M4 7h16", key: "6tx8e3" }],
  ["path", { d: "m16 21 4-4-4-4", key: "siv7j2" }],
  ["path", { d: "M20 17H4", key: "h6l3hr" }],
]);
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const Ee = o("BookOpen", [
  ["path", { d: "M12 7v14", key: "1akyts" }],
  [
    "path",
    {
      d: "M3 18a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h5a4 4 0 0 1 4 4 4 4 0 0 1 4-4h5a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1h-6a3 3 0 0 0-3 3 3 3 0 0 0-3-3z",
      key: "ruj8y",
    },
  ],
]);
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const ze = o("Briefcase", [
  ["path", { d: "M16 20V4a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16", key: "jecpp" }],
  [
    "rect",
    { width: "20", height: "14", x: "2", y: "6", rx: "2", key: "i6l2r4" },
  ],
]);
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const Se = o("CalendarDays", [
  ["path", { d: "M8 2v4", key: "1cmpym" }],
  ["path", { d: "M16 2v4", key: "4m81vk" }],
  [
    "rect",
    { width: "18", height: "18", x: "3", y: "4", rx: "2", key: "1hopcy" },
  ],
  ["path", { d: "M3 10h18", key: "8toen8" }],
  ["path", { d: "M8 14h.01", key: "6423bh" }],
  ["path", { d: "M12 14h.01", key: "1etili" }],
  ["path", { d: "M16 14h.01", key: "1gbofw" }],
  ["path", { d: "M8 18h.01", key: "lrp35t" }],
  ["path", { d: "M12 18h.01", key: "mhygvu" }],
  ["path", { d: "M16 18h.01", key: "kzsmim" }],
]);
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const Ne = o("Check", [["path", { d: "M20 6 9 17l-5-5", key: "1gmf2c" }]]);
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const Te = o("ChevronLeft", [
  ["path", { d: "m15 18-6-6 6-6", key: "1wnfg3" }],
]);
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const Be = o("ChevronRight", [
  ["path", { d: "m9 18 6-6-6-6", key: "mthhwq" }],
]);
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const Le = o("CircleCheck", [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "m9 12 2 2 4-4", key: "dzmm74" }],
]);
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const je = o("CircleX", [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "m15 9-6 6", key: "1uzhvr" }],
  ["path", { d: "m9 9 6 6", key: "z0biqf" }],
]);
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const Pe = o("ClipboardCheck", [
  [
    "rect",
    {
      width: "8",
      height: "4",
      x: "8",
      y: "2",
      rx: "1",
      ry: "1",
      key: "tgr4d6",
    },
  ],
  [
    "path",
    {
      d: "M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2",
      key: "116196",
    },
  ],
  ["path", { d: "m9 14 2 2 4-4", key: "df797q" }],
]);
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const Re = o("CodeXml", [
  ["path", { d: "m18 16 4-4-4-4", key: "1inbqp" }],
  ["path", { d: "m6 8-4 4 4 4", key: "15zrgr" }],
  ["path", { d: "m14.5 4-5 16", key: "e7oirm" }],
]);
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const Ae = o("Copyright", [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "M14.83 14.83a4 4 0 1 1 0-5.66", key: "1i56pz" }],
]);
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const qe = o("Crosshair", [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["line", { x1: "22", x2: "18", y1: "12", y2: "12", key: "l9bcsi" }],
  ["line", { x1: "6", x2: "2", y1: "12", y2: "12", key: "13hhkx" }],
  ["line", { x1: "12", x2: "12", y1: "6", y2: "2", key: "10w3f3" }],
  ["line", { x1: "12", x2: "12", y1: "22", y2: "18", key: "15g9kq" }],
]);
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const He = o("EqualNot", [
  ["line", { x1: "5", x2: "19", y1: "9", y2: "9", key: "1nwqeh" }],
  ["line", { x1: "5", x2: "19", y1: "15", y2: "15", key: "g8yjpy" }],
  ["line", { x1: "19", x2: "5", y1: "5", y2: "19", key: "1x9vlm" }],
]);
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const Ie = o("FileDown", [
  [
    "path",
    {
      d: "M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z",
      key: "1rqfz7",
    },
  ],
  ["path", { d: "M14 2v4a2 2 0 0 0 2 2h4", key: "tnqrlb" }],
  ["path", { d: "M12 18v-6", key: "17g6i2" }],
  ["path", { d: "m9 15 3 3 3-3", key: "1npd3o" }],
]);
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const De = o("FileText", [
  [
    "path",
    {
      d: "M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z",
      key: "1rqfz7",
    },
  ],
  ["path", { d: "M14 2v4a2 2 0 0 0 2 2h4", key: "tnqrlb" }],
  ["path", { d: "M10 9H8", key: "b1mrlr" }],
  ["path", { d: "M16 13H8", key: "t4e002" }],
  ["path", { d: "M16 17H8", key: "z1uh3a" }],
]);
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const $e = o("Gamepad2", [
  ["line", { x1: "6", x2: "10", y1: "11", y2: "11", key: "1gktln" }],
  ["line", { x1: "8", x2: "8", y1: "9", y2: "13", key: "qnk9ow" }],
  ["line", { x1: "15", x2: "15.01", y1: "12", y2: "12", key: "krot7o" }],
  ["line", { x1: "18", x2: "18.01", y1: "10", y2: "10", key: "1lcuu1" }],
  [
    "path",
    {
      d: "M17.32 5H6.68a4 4 0 0 0-3.978 3.59c-.006.052-.01.101-.017.152C2.604 9.416 2 14.456 2 16a3 3 0 0 0 3 3c1 0 1.5-.5 2-1l1.414-1.414A2 2 0 0 1 9.828 16h4.344a2 2 0 0 1 1.414.586L17 18c.5.5 1 1 2 1a3 3 0 0 0 3-3c0-1.545-.604-6.584-.685-7.258-.007-.05-.011-.1-.017-.151A4 4 0 0 0 17.32 5z",
      key: "mfqc10",
    },
  ],
]);
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const Ye = o("GraduationCap", [
  [
    "path",
    {
      d: "M21.42 10.922a1 1 0 0 0-.019-1.838L12.83 5.18a2 2 0 0 0-1.66 0L2.6 9.08a1 1 0 0 0 0 1.832l8.57 3.908a2 2 0 0 0 1.66 0z",
      key: "j76jl0",
    },
  ],
  ["path", { d: "M22 10v6", key: "1lu8f3" }],
  ["path", { d: "M6 12.5V16a6 3 0 0 0 12 0v-3.5", key: "1r8lef" }],
]);
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const Ve = o("Grid2x2", [
  [
    "rect",
    { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" },
  ],
  ["path", { d: "M3 12h18", key: "1i2n21" }],
  ["path", { d: "M12 3v18", key: "108xh3" }],
]);
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const Oe = o("Grid3x3", [
  [
    "rect",
    { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" },
  ],
  ["path", { d: "M3 9h18", key: "1pudct" }],
  ["path", { d: "M3 15h18", key: "5xshup" }],
  ["path", { d: "M9 3v18", key: "fh3hqa" }],
  ["path", { d: "M15 3v18", key: "14nvp0" }],
]);
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const Fe = o("Info", [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "M12 16v-4", key: "1dtifu" }],
  ["path", { d: "M12 8h.01", key: "e9boi3" }],
]);
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const Ge = o("Layers", [
  [
    "path",
    {
      d: "m12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83Z",
      key: "8b97xw",
    },
  ],
  [
    "path",
    { d: "m22 17.65-9.17 4.16a2 2 0 0 1-1.66 0L2 17.65", key: "dd6zsq" },
  ],
  [
    "path",
    { d: "m22 12.65-9.17 4.16a2 2 0 0 1-1.66 0L2 12.65", key: "ep9fru" },
  ],
]);
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const Ue = o("Lightbulb", [
  [
    "path",
    {
      d: "M15 14c.2-1 .7-1.7 1.5-2.5 1-.9 1.5-2.2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5",
      key: "1gvzjb",
    },
  ],
  ["path", { d: "M9 18h6", key: "x1upvd" }],
  ["path", { d: "M10 22h4", key: "ceow96" }],
]);
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const Xe = o("Link2", [
  ["path", { d: "M9 17H7A5 5 0 0 1 7 7h2", key: "8i5ue5" }],
  ["path", { d: "M15 7h2a5 5 0 1 1 0 10h-2", key: "1b9ql8" }],
  ["line", { x1: "8", x2: "16", y1: "12", y2: "12", key: "1jonct" }],
]);
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const Ze = o("Lock", [
  [
    "rect",
    {
      width: "18",
      height: "11",
      x: "3",
      y: "11",
      rx: "2",
      ry: "2",
      key: "1w4ew1",
    },
  ],
  ["path", { d: "M7 11V7a5 5 0 0 1 10 0v4", key: "fwvmzm" }],
]);
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const We = o("Maximize2", [
  ["polyline", { points: "15 3 21 3 21 9", key: "mznyad" }],
  ["polyline", { points: "9 21 3 21 3 15", key: "1avn1i" }],
  ["line", { x1: "21", x2: "14", y1: "3", y2: "10", key: "ota7mn" }],
  ["line", { x1: "3", x2: "10", y1: "21", y2: "14", key: "1atl0r" }],
]);
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const Ke = o("Menu", [
  ["line", { x1: "4", x2: "20", y1: "12", y2: "12", key: "1e0a9i" }],
  ["line", { x1: "4", x2: "20", y1: "6", y2: "6", key: "1owob3" }],
  ["line", { x1: "4", x2: "20", y1: "18", y2: "18", key: "yk5zj1" }],
]);
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const Je = o("Minimize2", [
  ["polyline", { points: "4 14 10 14 10 20", key: "11kfnr" }],
  ["polyline", { points: "20 10 14 10 14 4", key: "rlmsce" }],
  ["line", { x1: "14", x2: "21", y1: "10", y2: "3", key: "o5lafz" }],
  ["line", { x1: "3", x2: "10", y1: "21", y2: "14", key: "1atl0r" }],
]);
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const Qe = o("MonitorPlay", [
  [
    "path",
    {
      d: "M10 7.75a.75.75 0 0 1 1.142-.638l3.664 2.249a.75.75 0 0 1 0 1.278l-3.664 2.25a.75.75 0 0 1-1.142-.64z",
      key: "1pctta",
    },
  ],
  ["path", { d: "M12 17v4", key: "1riwvh" }],
  ["path", { d: "M8 21h8", key: "1ev6f3" }],
  [
    "rect",
    { x: "2", y: "3", width: "20", height: "14", rx: "2", key: "x3v2xh" },
  ],
]);
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const _e = o("Moon", [
  ["path", { d: "M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z", key: "a7tn18" }],
]);
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const ta = o("NotebookPen", [
  [
    "path",
    {
      d: "M13.4 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-7.4",
      key: "re6nr2",
    },
  ],
  ["path", { d: "M2 6h4", key: "aawbzj" }],
  ["path", { d: "M2 10h4", key: "l0bgd4" }],
  ["path", { d: "M2 14h4", key: "1gsvsf" }],
  ["path", { d: "M2 18h4", key: "1bu2t1" }],
  [
    "path",
    {
      d: "M21.378 5.626a1 1 0 1 0-3.004-3.004l-5.01 5.012a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506z",
      key: "pqwjuv",
    },
  ],
]);
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const ea = o("PanelLeftClose", [
  [
    "rect",
    { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" },
  ],
  ["path", { d: "M9 3v18", key: "fh3hqa" }],
  ["path", { d: "m16 15-3-3 3-3", key: "14y99z" }],
]);
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const aa = o("PanelLeftOpen", [
  [
    "rect",
    { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" },
  ],
  ["path", { d: "M9 3v18", key: "fh3hqa" }],
  ["path", { d: "m14 9 3 3-3 3", key: "8010ee" }],
]);
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const ra = o("PanelRightClose", [
  [
    "rect",
    { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" },
  ],
  ["path", { d: "M15 3v18", key: "14nvp0" }],
  ["path", { d: "m8 9 3 3-3 3", key: "12hl5m" }],
]);
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const oa = o("PanelRightOpen", [
  [
    "rect",
    { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" },
  ],
  ["path", { d: "M15 3v18", key: "14nvp0" }],
  ["path", { d: "m10 15-3-3 3-3", key: "1pgupc" }],
]);
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const na = o("PanelTopClose", [
  [
    "rect",
    { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" },
  ],
  ["path", { d: "M3 9h18", key: "1pudct" }],
  ["path", { d: "m9 16 3-3 3 3", key: "1idcnm" }],
]);
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const sa = o("PanelTopOpen", [
  [
    "rect",
    { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" },
  ],
  ["path", { d: "M3 9h18", key: "1pudct" }],
  ["path", { d: "m15 14-3 3-3-3", key: "g215vf" }],
]);
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const ia = o("Pencil", [
  [
    "path",
    {
      d: "M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z",
      key: "1a8usu",
    },
  ],
  ["path", { d: "m15 5 4 4", key: "1mk7zo" }],
]);
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const la = o("PiggyBank", [
  [
    "path",
    {
      d: "M19 5c-1.5 0-2.8 1.4-3 2-3.5-1.5-11-.3-11 5 0 1.8 0 3 2 4.5V20h4v-2h3v2h4v-4c1-.5 1.7-1 2-2h2v-4h-2c0-1-.5-1.5-1-2V5z",
      key: "1ivx2i",
    },
  ],
  ["path", { d: "M2 9v1c0 1.1.9 2 2 2h1", key: "nm575m" }],
  ["path", { d: "M16 11h.01", key: "xkw8gn" }],
]);
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const da = o("Play", [
  ["polygon", { points: "6 3 20 12 6 21 6 3", key: "1oa8hb" }],
]);
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const ca = o("Plus", [
  ["path", { d: "M5 12h14", key: "1ays0h" }],
  ["path", { d: "M12 5v14", key: "s699le" }],
]);
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const ha = o("RectangleEllipsis", [
  [
    "rect",
    { width: "20", height: "12", x: "2", y: "6", rx: "2", key: "9lu3g6" },
  ],
  ["path", { d: "M12 12h.01", key: "1mp3jc" }],
  ["path", { d: "M17 12h.01", key: "1m0b6t" }],
  ["path", { d: "M7 12h.01", key: "eqddd0" }],
]);
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const ua = o("RotateCcw", [
  [
    "path",
    { d: "M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8", key: "1357e3" },
  ],
  ["path", { d: "M3 3v5h5", key: "1xhq8a" }],
]);
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const pa = o("Scale", [
  [
    "path",
    { d: "m16 16 3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1Z", key: "7g6ntu" },
  ],
  [
    "path",
    { d: "m2 16 3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1Z", key: "ijws7r" },
  ],
  ["path", { d: "M7 21h10", key: "1b0cd5" }],
  ["path", { d: "M12 3v18", key: "108xh3" }],
  ["path", { d: "M3 7h2c2 0 5-1 7-2 2 1 5 2 7 2h2", key: "3gwbw2" }],
]);
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const ya = o("Search", [
  ["circle", { cx: "11", cy: "11", r: "8", key: "4ej97u" }],
  ["path", { d: "m21 21-4.3-4.3", key: "1qie3q" }],
]);
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const ma = o("Settings", [
  [
    "path",
    {
      d: "M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z",
      key: "1qme2f",
    },
  ],
  ["circle", { cx: "12", cy: "12", r: "3", key: "1v7zrd" }],
]);
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const fa = o("ShieldAlert", [
  [
    "path",
    {
      d: "M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",
      key: "oel41y",
    },
  ],
  ["path", { d: "M12 8v4", key: "1got3b" }],
  ["path", { d: "M12 16h.01", key: "1drbdi" }],
]);
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const ga = o("ShieldCheck", [
  [
    "path",
    {
      d: "M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",
      key: "oel41y",
    },
  ],
  ["path", { d: "m9 12 2 2 4-4", key: "dzmm74" }],
]);
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const va = o("ShieldOff", [
  ["path", { d: "m2 2 20 20", key: "1ooewy" }],
  [
    "path",
    {
      d: "M5 5a1 1 0 0 0-1 1v7c0 5 3.5 7.5 7.67 8.94a1 1 0 0 0 .67.01c2.35-.82 4.48-1.97 5.9-3.71",
      key: "1jlk70",
    },
  ],
  [
    "path",
    {
      d: "M9.309 3.652A12.252 12.252 0 0 0 11.24 2.28a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1v7a9.784 9.784 0 0 1-.08 1.264",
      key: "18rp1v",
    },
  ],
]);
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const ba = o("Shield", [
  [
    "path",
    {
      d: "M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",
      key: "oel41y",
    },
  ],
]);
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const wa = o("Sun", [
  ["circle", { cx: "12", cy: "12", r: "4", key: "4exip2" }],
  ["path", { d: "M12 2v2", key: "tus03m" }],
  ["path", { d: "M12 20v2", key: "1lh1kg" }],
  ["path", { d: "m4.93 4.93 1.41 1.41", key: "149t6j" }],
  ["path", { d: "m17.66 17.66 1.41 1.41", key: "ptbguv" }],
  ["path", { d: "M2 12h2", key: "1t8f8n" }],
  ["path", { d: "M20 12h2", key: "1q8mjw" }],
  ["path", { d: "m6.34 17.66-1.41 1.41", key: "1m8zz5" }],
  ["path", { d: "m19.07 4.93-1.41 1.41", key: "1shlcs" }],
]);
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const xa = o("Type", [
  ["polyline", { points: "4 7 4 4 20 4 20 7", key: "1nosan" }],
  ["line", { x1: "9", x2: "15", y1: "20", y2: "20", key: "swin9y" }],
  ["line", { x1: "12", x2: "12", y1: "4", y2: "20", key: "1tx1rr" }],
]);
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const ka = o("Users", [
  ["path", { d: "M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2", key: "1yyitq" }],
  ["circle", { cx: "9", cy: "7", r: "4", key: "nufk8" }],
  ["path", { d: "M22 21v-2a4 4 0 0 0-3-3.87", key: "kshegd" }],
  ["path", { d: "M16 3.13a4 4 0 0 1 0 7.75", key: "1da9ce" }],
]);
/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ const Ma = o("X", [
  ["path", { d: "M18 6 6 18", key: "1bl5f8" }],
  ["path", { d: "m6 6 12 12", key: "d8bk6v" }],
]);
var Kt = (e) => {
    switch (e) {
      case "success":
        return _t;
      case "info":
        return ee;
      case "warning":
        return te;
      case "error":
        return ae;
      default:
        return null;
    }
  },
  Jt = Array(12).fill(0),
  Qt = ({ visible: e, className: a }) =>
    r.createElement(
      "div",
      {
        className: ["sonner-loading-wrapper", a].filter(Boolean).join(" "),
        "data-visible": e,
      },
      r.createElement(
        "div",
        { className: "sonner-spinner" },
        Jt.map((n, i) =>
          r.createElement("div", {
            className: "sonner-loading-bar",
            key: `spinner-bar-${i}`,
          }),
        ),
      ),
    ),
  _t = r.createElement(
    "svg",
    {
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      height: "20",
      width: "20",
    },
    r.createElement("path", {
      fillRule: "evenodd",
      d: "M10 18a8 8 0 100-16 8 8 0 000 16zm3.857-9.809a.75.75 0 00-1.214-.882l-3.483 4.79-1.88-1.88a.75.75 0 10-1.06 1.061l2.5 2.5a.75.75 0 001.137-.089l4-5.5z",
      clipRule: "evenodd",
    }),
  ),
  te = r.createElement(
    "svg",
    {
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 24 24",
      fill: "currentColor",
      height: "20",
      width: "20",
    },
    r.createElement("path", {
      fillRule: "evenodd",
      d: "M9.401 3.003c1.155-2 4.043-2 5.197 0l7.355 12.748c1.154 2-.29 4.5-2.599 4.5H4.645c-2.309 0-3.752-2.5-2.598-4.5L9.4 3.003zM12 8.25a.75.75 0 01.75.75v3.75a.75.75 0 01-1.5 0V9a.75.75 0 01.75-.75zm0 8.25a.75.75 0 100-1.5.75.75 0 000 1.5z",
      clipRule: "evenodd",
    }),
  ),
  ee = r.createElement(
    "svg",
    {
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      height: "20",
      width: "20",
    },
    r.createElement("path", {
      fillRule: "evenodd",
      d: "M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a.75.75 0 000 1.5h.253a.25.25 0 01.244.304l-.459 2.066A1.75 1.75 0 0010.747 15H11a.75.75 0 000-1.5h-.253a.25.25 0 01-.244-.304l.459-2.066A1.75 1.75 0 009.253 9H9z",
      clipRule: "evenodd",
    }),
  ),
  ae = r.createElement(
    "svg",
    {
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      height: "20",
      width: "20",
    },
    r.createElement("path", {
      fillRule: "evenodd",
      d: "M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-8-5a.75.75 0 01.75.75v4.5a.75.75 0 01-1.5 0v-4.5A.75.75 0 0110 5zm0 10a1 1 0 100-2 1 1 0 000 2z",
      clipRule: "evenodd",
    }),
  ),
  re = r.createElement(
    "svg",
    {
      xmlns: "http://www.w3.org/2000/svg",
      width: "12",
      height: "12",
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "currentColor",
      strokeWidth: "1.5",
      strokeLinecap: "round",
      strokeLinejoin: "round",
    },
    r.createElement("line", { x1: "18", y1: "6", x2: "6", y2: "18" }),
    r.createElement("line", { x1: "6", y1: "6", x2: "18", y2: "18" }),
  ),
  oe = () => {
    let [e, a] = r.useState(document.hidden);
    return (
      r.useEffect(() => {
        let n = () => {
          a(document.hidden);
        };
        return (
          document.addEventListener("visibilitychange", n),
          () => window.removeEventListener("visibilitychange", n)
        );
      }, []),
      e
    );
  },
  xt = 1,
  ne = class {
    constructor() {
      ((this.subscribe = (e) => (
        this.subscribers.push(e),
        () => {
          let a = this.subscribers.indexOf(e);
          this.subscribers.splice(a, 1);
        }
      )),
        (this.publish = (e) => {
          this.subscribers.forEach((a) => a(e));
        }),
        (this.addToast = (e) => {
          (this.publish(e), (this.toasts = [...this.toasts, e]));
        }),
        (this.create = (e) => {
          var a;
          let { message: n, ...i } = e,
            h =
              typeof e?.id == "number" ||
              ((a = e.id) == null ? void 0 : a.length) > 0
                ? e.id
                : xt++,
            g = this.toasts.find((w) => w.id === h),
            k = e.dismissible === void 0 ? !0 : e.dismissible;
          return (
            this.dismissedToasts.has(h) && this.dismissedToasts.delete(h),
            g
              ? (this.toasts = this.toasts.map((w) =>
                  w.id === h
                    ? (this.publish({ ...w, ...e, id: h, title: n }),
                      { ...w, ...e, id: h, dismissible: k, title: n })
                    : w,
                ))
              : this.addToast({ title: n, ...i, dismissible: k, id: h }),
            h
          );
        }),
        (this.dismiss = (e) => (
          this.dismissedToasts.add(e),
          e ||
            this.toasts.forEach((a) => {
              this.subscribers.forEach((n) => n({ id: a.id, dismiss: !0 }));
            }),
          this.subscribers.forEach((a) => a({ id: e, dismiss: !0 })),
          e
        )),
        (this.message = (e, a) => this.create({ ...a, message: e })),
        (this.error = (e, a) =>
          this.create({ ...a, message: e, type: "error" })),
        (this.success = (e, a) =>
          this.create({ ...a, type: "success", message: e })),
        (this.info = (e, a) => this.create({ ...a, type: "info", message: e })),
        (this.warning = (e, a) =>
          this.create({ ...a, type: "warning", message: e })),
        (this.loading = (e, a) =>
          this.create({ ...a, type: "loading", message: e })),
        (this.promise = (e, a) => {
          if (!a) return;
          let n;
          a.loading !== void 0 &&
            (n = this.create({
              ...a,
              promise: e,
              type: "loading",
              message: a.loading,
              description:
                typeof a.description != "function" ? a.description : void 0,
            }));
          let i = e instanceof Promise ? e : e(),
            h = n !== void 0,
            g,
            k = i
              .then(async (d) => {
                if (((g = ["resolve", d]), r.isValidElement(d)))
                  ((h = !1),
                    this.create({ id: n, type: "default", message: d }));
                else if (ie(d) && !d.ok) {
                  h = !1;
                  let p =
                      typeof a.error == "function"
                        ? await a.error(`HTTP error! status: ${d.status}`)
                        : a.error,
                    x =
                      typeof a.description == "function"
                        ? await a.description(`HTTP error! status: ${d.status}`)
                        : a.description;
                  this.create({
                    id: n,
                    type: "error",
                    message: p,
                    description: x,
                  });
                } else if (a.success !== void 0) {
                  h = !1;
                  let p =
                      typeof a.success == "function"
                        ? await a.success(d)
                        : a.success,
                    x =
                      typeof a.description == "function"
                        ? await a.description(d)
                        : a.description;
                  this.create({
                    id: n,
                    type: "success",
                    message: p,
                    description: x,
                  });
                }
              })
              .catch(async (d) => {
                if (((g = ["reject", d]), a.error !== void 0)) {
                  h = !1;
                  let p =
                      typeof a.error == "function" ? await a.error(d) : a.error,
                    x =
                      typeof a.description == "function"
                        ? await a.description(d)
                        : a.description;
                  this.create({
                    id: n,
                    type: "error",
                    message: p,
                    description: x,
                  });
                }
              })
              .finally(() => {
                var d;
                (h && (this.dismiss(n), (n = void 0)),
                  (d = a.finally) == null || d.call(a));
              }),
            w = () =>
              new Promise((d, p) =>
                k.then(() => (g[0] === "reject" ? p(g[1]) : d(g[1]))).catch(p),
              );
          return typeof n != "string" && typeof n != "number"
            ? { unwrap: w }
            : Object.assign(n, { unwrap: w });
        }),
        (this.custom = (e, a) => {
          let n = a?.id || xt++;
          return (this.create({ jsx: e(n), id: n, ...a }), n);
        }),
        (this.getActiveToasts = () =>
          this.toasts.filter((e) => !this.dismissedToasts.has(e.id))),
        (this.subscribers = []),
        (this.toasts = []),
        (this.dismissedToasts = new Set()));
    }
  },
  C = new ne(),
  se = (e, a) => {
    let n = a?.id || xt++;
    return (C.addToast({ title: e, ...a, id: n }), n);
  },
  ie = (e) =>
    e &&
    typeof e == "object" &&
    "ok" in e &&
    typeof e.ok == "boolean" &&
    "status" in e &&
    typeof e.status == "number",
  le = se,
  de = () => C.toasts,
  ce = () => C.getActiveToasts(),
  Ca = Object.assign(
    le,
    {
      success: C.success,
      info: C.info,
      warning: C.warning,
      error: C.error,
      custom: C.custom,
      message: C.message,
      promise: C.promise,
      dismiss: C.dismiss,
      loading: C.loading,
    },
    { getHistory: de, getToasts: ce },
  );
function he(e, { insertAt: a } = {}) {
  if (typeof document > "u") return;
  let n = document.head || document.getElementsByTagName("head")[0],
    i = document.createElement("style");
  ((i.type = "text/css"),
    a === "top" && n.firstChild
      ? n.insertBefore(i, n.firstChild)
      : n.appendChild(i),
    i.styleSheet
      ? (i.styleSheet.cssText = e)
      : i.appendChild(document.createTextNode(e)));
}
he(`:where(html[dir="ltr"]),:where([data-sonner-toaster][dir="ltr"]){--toast-icon-margin-start: -3px;--toast-icon-margin-end: 4px;--toast-svg-margin-start: -1px;--toast-svg-margin-end: 0px;--toast-button-margin-start: auto;--toast-button-margin-end: 0;--toast-close-button-start: 0;--toast-close-button-end: unset;--toast-close-button-transform: translate(-35%, -35%)}:where(html[dir="rtl"]),:where([data-sonner-toaster][dir="rtl"]){--toast-icon-margin-start: 4px;--toast-icon-margin-end: -3px;--toast-svg-margin-start: 0px;--toast-svg-margin-end: -1px;--toast-button-margin-start: 0;--toast-button-margin-end: auto;--toast-close-button-start: unset;--toast-close-button-end: 0;--toast-close-button-transform: translate(35%, -35%)}:where([data-sonner-toaster]){position:fixed;width:var(--width);font-family:ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica Neue,Arial,Noto Sans,sans-serif,Apple Color Emoji,Segoe UI Emoji,Segoe UI Symbol,Noto Color Emoji;--gray1: hsl(0, 0%, 99%);--gray2: hsl(0, 0%, 97.3%);--gray3: hsl(0, 0%, 95.1%);--gray4: hsl(0, 0%, 93%);--gray5: hsl(0, 0%, 90.9%);--gray6: hsl(0, 0%, 88.7%);--gray7: hsl(0, 0%, 85.8%);--gray8: hsl(0, 0%, 78%);--gray9: hsl(0, 0%, 56.1%);--gray10: hsl(0, 0%, 52.3%);--gray11: hsl(0, 0%, 43.5%);--gray12: hsl(0, 0%, 9%);--border-radius: 8px;box-sizing:border-box;padding:0;margin:0;list-style:none;outline:none;z-index:999999999;transition:transform .4s ease}:where([data-sonner-toaster][data-lifted="true"]){transform:translateY(-10px)}@media (hover: none) and (pointer: coarse){:where([data-sonner-toaster][data-lifted="true"]){transform:none}}:where([data-sonner-toaster][data-x-position="right"]){right:var(--offset-right)}:where([data-sonner-toaster][data-x-position="left"]){left:var(--offset-left)}:where([data-sonner-toaster][data-x-position="center"]){left:50%;transform:translate(-50%)}:where([data-sonner-toaster][data-y-position="top"]){top:var(--offset-top)}:where([data-sonner-toaster][data-y-position="bottom"]){bottom:var(--offset-bottom)}:where([data-sonner-toast]){--y: translateY(100%);--lift-amount: calc(var(--lift) * var(--gap));z-index:var(--z-index);position:absolute;opacity:0;transform:var(--y);filter:blur(0);touch-action:none;transition:transform .4s,opacity .4s,height .4s,box-shadow .2s;box-sizing:border-box;outline:none;overflow-wrap:anywhere}:where([data-sonner-toast][data-styled="true"]){padding:16px;background:var(--normal-bg);border:1px solid var(--normal-border);color:var(--normal-text);border-radius:var(--border-radius);box-shadow:0 4px 12px #0000001a;width:var(--width);font-size:13px;display:flex;align-items:center;gap:6px}:where([data-sonner-toast]:focus-visible){box-shadow:0 4px 12px #0000001a,0 0 0 2px #0003}:where([data-sonner-toast][data-y-position="top"]){top:0;--y: translateY(-100%);--lift: 1;--lift-amount: calc(1 * var(--gap))}:where([data-sonner-toast][data-y-position="bottom"]){bottom:0;--y: translateY(100%);--lift: -1;--lift-amount: calc(var(--lift) * var(--gap))}:where([data-sonner-toast]) :where([data-description]){font-weight:400;line-height:1.4;color:inherit}:where([data-sonner-toast]) :where([data-title]){font-weight:500;line-height:1.5;color:inherit}:where([data-sonner-toast]) :where([data-icon]){display:flex;height:16px;width:16px;position:relative;justify-content:flex-start;align-items:center;flex-shrink:0;margin-left:var(--toast-icon-margin-start);margin-right:var(--toast-icon-margin-end)}:where([data-sonner-toast][data-promise="true"]) :where([data-icon])>svg{opacity:0;transform:scale(.8);transform-origin:center;animation:sonner-fade-in .3s ease forwards}:where([data-sonner-toast]) :where([data-icon])>*{flex-shrink:0}:where([data-sonner-toast]) :where([data-icon]) svg{margin-left:var(--toast-svg-margin-start);margin-right:var(--toast-svg-margin-end)}:where([data-sonner-toast]) :where([data-content]){display:flex;flex-direction:column;gap:2px}[data-sonner-toast][data-styled=true] [data-button]{border-radius:4px;padding-left:8px;padding-right:8px;height:24px;font-size:12px;color:var(--normal-bg);background:var(--normal-text);margin-left:var(--toast-button-margin-start);margin-right:var(--toast-button-margin-end);border:none;cursor:pointer;outline:none;display:flex;align-items:center;flex-shrink:0;transition:opacity .4s,box-shadow .2s}:where([data-sonner-toast]) :where([data-button]):focus-visible{box-shadow:0 0 0 2px #0006}:where([data-sonner-toast]) :where([data-button]):first-of-type{margin-left:var(--toast-button-margin-start);margin-right:var(--toast-button-margin-end)}:where([data-sonner-toast]) :where([data-cancel]){color:var(--normal-text);background:rgba(0,0,0,.08)}:where([data-sonner-toast][data-theme="dark"]) :where([data-cancel]){background:rgba(255,255,255,.3)}:where([data-sonner-toast]) :where([data-close-button]){position:absolute;left:var(--toast-close-button-start);right:var(--toast-close-button-end);top:0;height:20px;width:20px;display:flex;justify-content:center;align-items:center;padding:0;color:var(--gray12);border:1px solid var(--gray4);transform:var(--toast-close-button-transform);border-radius:50%;cursor:pointer;z-index:1;transition:opacity .1s,background .2s,border-color .2s}[data-sonner-toast] [data-close-button]{background:var(--gray1)}:where([data-sonner-toast]) :where([data-close-button]):focus-visible{box-shadow:0 4px 12px #0000001a,0 0 0 2px #0003}:where([data-sonner-toast]) :where([data-disabled="true"]){cursor:not-allowed}:where([data-sonner-toast]):hover :where([data-close-button]):hover{background:var(--gray2);border-color:var(--gray5)}:where([data-sonner-toast][data-swiping="true"]):before{content:"";position:absolute;left:-50%;right:-50%;height:100%;z-index:-1}:where([data-sonner-toast][data-y-position="top"][data-swiping="true"]):before{bottom:50%;transform:scaleY(3) translateY(50%)}:where([data-sonner-toast][data-y-position="bottom"][data-swiping="true"]):before{top:50%;transform:scaleY(3) translateY(-50%)}:where([data-sonner-toast][data-swiping="false"][data-removed="true"]):before{content:"";position:absolute;inset:0;transform:scaleY(2)}:where([data-sonner-toast]):after{content:"";position:absolute;left:0;height:calc(var(--gap) + 1px);bottom:100%;width:100%}:where([data-sonner-toast][data-mounted="true"]){--y: translateY(0);opacity:1}:where([data-sonner-toast][data-expanded="false"][data-front="false"]){--scale: var(--toasts-before) * .05 + 1;--y: translateY(calc(var(--lift-amount) * var(--toasts-before))) scale(calc(-1 * var(--scale)));height:var(--front-toast-height)}:where([data-sonner-toast])>*{transition:opacity .4s}:where([data-sonner-toast][data-expanded="false"][data-front="false"][data-styled="true"])>*{opacity:0}:where([data-sonner-toast][data-visible="false"]){opacity:0;pointer-events:none}:where([data-sonner-toast][data-mounted="true"][data-expanded="true"]){--y: translateY(calc(var(--lift) * var(--offset)));height:var(--initial-height)}:where([data-sonner-toast][data-removed="true"][data-front="true"][data-swipe-out="false"]){--y: translateY(calc(var(--lift) * -100%));opacity:0}:where([data-sonner-toast][data-removed="true"][data-front="false"][data-swipe-out="false"][data-expanded="true"]){--y: translateY(calc(var(--lift) * var(--offset) + var(--lift) * -100%));opacity:0}:where([data-sonner-toast][data-removed="true"][data-front="false"][data-swipe-out="false"][data-expanded="false"]){--y: translateY(40%);opacity:0;transition:transform .5s,opacity .2s}:where([data-sonner-toast][data-removed="true"][data-front="false"]):before{height:calc(var(--initial-height) + 20%)}[data-sonner-toast][data-swiping=true]{transform:var(--y) translateY(var(--swipe-amount-y, 0px)) translate(var(--swipe-amount-x, 0px));transition:none}[data-sonner-toast][data-swiped=true]{user-select:none}[data-sonner-toast][data-swipe-out=true][data-y-position=bottom],[data-sonner-toast][data-swipe-out=true][data-y-position=top]{animation-duration:.2s;animation-timing-function:ease-out;animation-fill-mode:forwards}[data-sonner-toast][data-swipe-out=true][data-swipe-direction=left]{animation-name:swipe-out-left}[data-sonner-toast][data-swipe-out=true][data-swipe-direction=right]{animation-name:swipe-out-right}[data-sonner-toast][data-swipe-out=true][data-swipe-direction=up]{animation-name:swipe-out-up}[data-sonner-toast][data-swipe-out=true][data-swipe-direction=down]{animation-name:swipe-out-down}@keyframes swipe-out-left{0%{transform:var(--y) translate(var(--swipe-amount-x));opacity:1}to{transform:var(--y) translate(calc(var(--swipe-amount-x) - 100%));opacity:0}}@keyframes swipe-out-right{0%{transform:var(--y) translate(var(--swipe-amount-x));opacity:1}to{transform:var(--y) translate(calc(var(--swipe-amount-x) + 100%));opacity:0}}@keyframes swipe-out-up{0%{transform:var(--y) translateY(var(--swipe-amount-y));opacity:1}to{transform:var(--y) translateY(calc(var(--swipe-amount-y) - 100%));opacity:0}}@keyframes swipe-out-down{0%{transform:var(--y) translateY(var(--swipe-amount-y));opacity:1}to{transform:var(--y) translateY(calc(var(--swipe-amount-y) + 100%));opacity:0}}@media (max-width: 600px){[data-sonner-toaster]{position:fixed;right:var(--mobile-offset-right);left:var(--mobile-offset-left);width:100%}[data-sonner-toaster][dir=rtl]{left:calc(var(--mobile-offset-left) * -1)}[data-sonner-toaster] [data-sonner-toast]{left:0;right:0;width:calc(100% - var(--mobile-offset-left) * 2)}[data-sonner-toaster][data-x-position=left]{left:var(--mobile-offset-left)}[data-sonner-toaster][data-y-position=bottom]{bottom:var(--mobile-offset-bottom)}[data-sonner-toaster][data-y-position=top]{top:var(--mobile-offset-top)}[data-sonner-toaster][data-x-position=center]{left:var(--mobile-offset-left);right:var(--mobile-offset-right);transform:none}}[data-sonner-toaster][data-theme=light]{--normal-bg: #fff;--normal-border: var(--gray4);--normal-text: var(--gray12);--success-bg: hsl(143, 85%, 96%);--success-border: hsl(145, 92%, 91%);--success-text: hsl(140, 100%, 27%);--info-bg: hsl(208, 100%, 97%);--info-border: hsl(221, 91%, 91%);--info-text: hsl(210, 92%, 45%);--warning-bg: hsl(49, 100%, 97%);--warning-border: hsl(49, 91%, 91%);--warning-text: hsl(31, 92%, 45%);--error-bg: hsl(359, 100%, 97%);--error-border: hsl(359, 100%, 94%);--error-text: hsl(360, 100%, 45%)}[data-sonner-toaster][data-theme=light] [data-sonner-toast][data-invert=true]{--normal-bg: #000;--normal-border: hsl(0, 0%, 20%);--normal-text: var(--gray1)}[data-sonner-toaster][data-theme=dark] [data-sonner-toast][data-invert=true]{--normal-bg: #fff;--normal-border: var(--gray3);--normal-text: var(--gray12)}[data-sonner-toaster][data-theme=dark]{--normal-bg: #000;--normal-bg-hover: hsl(0, 0%, 12%);--normal-border: hsl(0, 0%, 20%);--normal-border-hover: hsl(0, 0%, 25%);--normal-text: var(--gray1);--success-bg: hsl(150, 100%, 6%);--success-border: hsl(147, 100%, 12%);--success-text: hsl(150, 86%, 65%);--info-bg: hsl(215, 100%, 6%);--info-border: hsl(223, 100%, 12%);--info-text: hsl(216, 87%, 65%);--warning-bg: hsl(64, 100%, 6%);--warning-border: hsl(60, 100%, 12%);--warning-text: hsl(46, 87%, 65%);--error-bg: hsl(358, 76%, 10%);--error-border: hsl(357, 89%, 16%);--error-text: hsl(358, 100%, 81%)}[data-sonner-toaster][data-theme=dark] [data-sonner-toast] [data-close-button]{background:var(--normal-bg);border-color:var(--normal-border);color:var(--normal-text)}[data-sonner-toaster][data-theme=dark] [data-sonner-toast] [data-close-button]:hover{background:var(--normal-bg-hover);border-color:var(--normal-border-hover)}[data-rich-colors=true][data-sonner-toast][data-type=success],[data-rich-colors=true][data-sonner-toast][data-type=success] [data-close-button]{background:var(--success-bg);border-color:var(--success-border);color:var(--success-text)}[data-rich-colors=true][data-sonner-toast][data-type=info],[data-rich-colors=true][data-sonner-toast][data-type=info] [data-close-button]{background:var(--info-bg);border-color:var(--info-border);color:var(--info-text)}[data-rich-colors=true][data-sonner-toast][data-type=warning],[data-rich-colors=true][data-sonner-toast][data-type=warning] [data-close-button]{background:var(--warning-bg);border-color:var(--warning-border);color:var(--warning-text)}[data-rich-colors=true][data-sonner-toast][data-type=error],[data-rich-colors=true][data-sonner-toast][data-type=error] [data-close-button]{background:var(--error-bg);border-color:var(--error-border);color:var(--error-text)}.sonner-loading-wrapper{--size: 16px;height:var(--size);width:var(--size);position:absolute;inset:0;z-index:10}.sonner-loading-wrapper[data-visible=false]{transform-origin:center;animation:sonner-fade-out .2s ease forwards}.sonner-spinner{position:relative;top:50%;left:50%;height:var(--size);width:var(--size)}.sonner-loading-bar{animation:sonner-spin 1.2s linear infinite;background:var(--gray11);border-radius:6px;height:8%;left:-10%;position:absolute;top:-3.9%;width:24%}.sonner-loading-bar:nth-child(1){animation-delay:-1.2s;transform:rotate(.0001deg) translate(146%)}.sonner-loading-bar:nth-child(2){animation-delay:-1.1s;transform:rotate(30deg) translate(146%)}.sonner-loading-bar:nth-child(3){animation-delay:-1s;transform:rotate(60deg) translate(146%)}.sonner-loading-bar:nth-child(4){animation-delay:-.9s;transform:rotate(90deg) translate(146%)}.sonner-loading-bar:nth-child(5){animation-delay:-.8s;transform:rotate(120deg) translate(146%)}.sonner-loading-bar:nth-child(6){animation-delay:-.7s;transform:rotate(150deg) translate(146%)}.sonner-loading-bar:nth-child(7){animation-delay:-.6s;transform:rotate(180deg) translate(146%)}.sonner-loading-bar:nth-child(8){animation-delay:-.5s;transform:rotate(210deg) translate(146%)}.sonner-loading-bar:nth-child(9){animation-delay:-.4s;transform:rotate(240deg) translate(146%)}.sonner-loading-bar:nth-child(10){animation-delay:-.3s;transform:rotate(270deg) translate(146%)}.sonner-loading-bar:nth-child(11){animation-delay:-.2s;transform:rotate(300deg) translate(146%)}.sonner-loading-bar:nth-child(12){animation-delay:-.1s;transform:rotate(330deg) translate(146%)}@keyframes sonner-fade-in{0%{opacity:0;transform:scale(.8)}to{opacity:1;transform:scale(1)}}@keyframes sonner-fade-out{0%{opacity:1;transform:scale(1)}to{opacity:0;transform:scale(.8)}}@keyframes sonner-spin{0%{opacity:1}to{opacity:.15}}@media (prefers-reduced-motion){[data-sonner-toast],[data-sonner-toast]>*,.sonner-loading-bar{transition:none!important;animation:none!important}}.sonner-loader{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);transform-origin:center;transition:opacity .2s,transform .2s}.sonner-loader[data-visible=false]{opacity:0;transform:scale(.8) translate(-50%,-50%)}
`);
function ct(e) {
  return e.label !== void 0;
}
var ue = 3,
  pe = "32px",
  ye = "16px",
  Bt = 4e3,
  me = 356,
  fe = 14,
  ge = 20,
  ve = 200;
function L(...e) {
  return e.filter(Boolean).join(" ");
}
function be(e) {
  let [a, n] = e.split("-"),
    i = [];
  return (a && i.push(a), n && i.push(n), i);
}
var we = (e) => {
  var a, n, i, h, g, k, w, d, p, x, tt;
  let {
      invert: ht,
      toast: t,
      unstyled: ut,
      interacting: b,
      setHeights: j,
      visibleToasts: et,
      heights: O,
      index: q,
      toasts: pt,
      expanded: W,
      removeToast: S,
      defaultRichColors: K,
      closeButton: at,
      style: rt,
      cancelButtonStyle: yt,
      actionButtonStyle: ot,
      className: P = "",
      descriptionClassName: nt = "",
      duration: F,
      position: st,
      gap: $,
      loadingIcon: R,
      expandByDefault: it,
      classNames: l,
      icons: E,
      closeButtonAriaLabel: mt = "Close toast",
      pauseWhenPageIsHidden: u,
    } = e,
    [y, f] = r.useState(null),
    [M, G] = r.useState(null),
    [v, ft] = r.useState(!1),
    [J, lt] = r.useState(!1),
    [Q, gt] = r.useState(!1),
    [kt, Pt] = r.useState(!1),
    [Rt, Mt] = r.useState(!1),
    [At, vt] = r.useState(0),
    [qt, Ct] = r.useState(0),
    _ = r.useRef(t.duration || F || Bt),
    Et = r.useRef(null),
    Y = r.useRef(null),
    Ht = q === 0,
    It = q + 1 <= et,
    z = t.type,
    U = t.dismissible !== !1,
    Dt = t.className || "",
    $t = t.descriptionClassName || "",
    dt = r.useMemo(
      () => O.findIndex((s) => s.toastId === t.id) || 0,
      [O, t.id],
    ),
    Yt = r.useMemo(() => {
      var s;
      return (s = t.closeButton) != null ? s : at;
    }, [t.closeButton, at]),
    zt = r.useMemo(() => t.duration || F || Bt, [t.duration, F]),
    bt = r.useRef(0),
    X = r.useRef(0),
    St = r.useRef(0),
    Z = r.useRef(null),
    [Vt, Ot] = st.split("-"),
    Nt = r.useMemo(
      () => O.reduce((s, c, m) => (m >= dt ? s : s + c.height), 0),
      [O, dt],
    ),
    Tt = oe(),
    Ft = t.invert || ht,
    wt = z === "loading";
  ((X.current = r.useMemo(() => dt * $ + Nt, [dt, Nt])),
    r.useEffect(() => {
      _.current = zt;
    }, [zt]),
    r.useEffect(() => {
      ft(!0);
    }, []),
    r.useEffect(() => {
      let s = Y.current;
      if (s) {
        let c = s.getBoundingClientRect().height;
        return (
          Ct(c),
          j((m) => [{ toastId: t.id, height: c, position: t.position }, ...m]),
          () => j((m) => m.filter((N) => N.toastId !== t.id))
        );
      }
    }, [j, t.id]),
    r.useLayoutEffect(() => {
      if (!v) return;
      let s = Y.current,
        c = s.style.height;
      s.style.height = "auto";
      let m = s.getBoundingClientRect().height;
      ((s.style.height = c),
        Ct(m),
        j((N) =>
          N.find((T) => T.toastId === t.id)
            ? N.map((T) => (T.toastId === t.id ? { ...T, height: m } : T))
            : [{ toastId: t.id, height: m, position: t.position }, ...N],
        ));
    }, [v, t.title, t.description, j, t.id]));
  let H = r.useCallback(() => {
    (lt(!0),
      vt(X.current),
      j((s) => s.filter((c) => c.toastId !== t.id)),
      setTimeout(() => {
        S(t);
      }, ve));
  }, [t, S, j, X]);
  (r.useEffect(() => {
    if (
      (t.promise && z === "loading") ||
      t.duration === 1 / 0 ||
      t.type === "loading"
    )
      return;
    let s;
    return (
      W || b || (u && Tt)
        ? (() => {
            if (St.current < bt.current) {
              let c = new Date().getTime() - bt.current;
              _.current = _.current - c;
            }
            St.current = new Date().getTime();
          })()
        : _.current !== 1 / 0 &&
          ((bt.current = new Date().getTime()),
          (s = setTimeout(() => {
            var c;
            ((c = t.onAutoClose) == null || c.call(t, t), H());
          }, _.current))),
      () => clearTimeout(s)
    );
  }, [W, b, t, z, u, Tt, H]),
    r.useEffect(() => {
      t.delete && H();
    }, [H, t.delete]));
  function Gt() {
    var s, c, m;
    return E != null && E.loading
      ? r.createElement(
          "div",
          {
            className: L(
              l?.loader,
              (s = t?.classNames) == null ? void 0 : s.loader,
              "sonner-loader",
            ),
            "data-visible": z === "loading",
          },
          E.loading,
        )
      : R
        ? r.createElement(
            "div",
            {
              className: L(
                l?.loader,
                (c = t?.classNames) == null ? void 0 : c.loader,
                "sonner-loader",
              ),
              "data-visible": z === "loading",
            },
            R,
          )
        : r.createElement(Qt, {
            className: L(
              l?.loader,
              (m = t?.classNames) == null ? void 0 : m.loader,
            ),
            visible: z === "loading",
          });
  }
  return r.createElement(
    "li",
    {
      tabIndex: 0,
      ref: Y,
      className: L(
        P,
        Dt,
        l?.toast,
        (a = t?.classNames) == null ? void 0 : a.toast,
        l?.default,
        l?.[z],
        (n = t?.classNames) == null ? void 0 : n[z],
      ),
      "data-sonner-toast": "",
      "data-rich-colors": (i = t.richColors) != null ? i : K,
      "data-styled": !(t.jsx || t.unstyled || ut),
      "data-mounted": v,
      "data-promise": !!t.promise,
      "data-swiped": Rt,
      "data-removed": J,
      "data-visible": It,
      "data-y-position": Vt,
      "data-x-position": Ot,
      "data-index": q,
      "data-front": Ht,
      "data-swiping": Q,
      "data-dismissible": U,
      "data-type": z,
      "data-invert": Ft,
      "data-swipe-out": kt,
      "data-swipe-direction": M,
      "data-expanded": !!(W || (it && v)),
      style: {
        "--index": q,
        "--toasts-before": q,
        "--z-index": pt.length - q,
        "--offset": `${J ? At : X.current}px`,
        "--initial-height": it ? "auto" : `${qt}px`,
        ...rt,
        ...t.style,
      },
      onDragEnd: () => {
        (gt(!1), f(null), (Z.current = null));
      },
      onPointerDown: (s) => {
        wt ||
          !U ||
          ((Et.current = new Date()),
          vt(X.current),
          s.target.setPointerCapture(s.pointerId),
          s.target.tagName !== "BUTTON" &&
            (gt(!0), (Z.current = { x: s.clientX, y: s.clientY })));
      },
      onPointerUp: () => {
        var s, c, m, N;
        if (kt || !U) return;
        Z.current = null;
        let T = Number(
            ((s = Y.current) == null
              ? void 0
              : s.style
                  .getPropertyValue("--swipe-amount-x")
                  .replace("px", "")) || 0,
          ),
          I = Number(
            ((c = Y.current) == null
              ? void 0
              : c.style
                  .getPropertyValue("--swipe-amount-y")
                  .replace("px", "")) || 0,
          ),
          V =
            new Date().getTime() -
            ((m = Et.current) == null ? void 0 : m.getTime()),
          B = y === "x" ? T : I,
          D = Math.abs(B) / V;
        if (Math.abs(B) >= ge || D > 0.11) {
          (vt(X.current),
            (N = t.onDismiss) == null || N.call(t, t),
            G(y === "x" ? (T > 0 ? "right" : "left") : I > 0 ? "down" : "up"),
            H(),
            Pt(!0),
            Mt(!1));
          return;
        }
        (gt(!1), f(null));
      },
      onPointerMove: (s) => {
        var c, m, N, T;
        if (
          !Z.current ||
          !U ||
          ((c = window.getSelection()) == null ? void 0 : c.toString().length) >
            0
        )
          return;
        let I = s.clientY - Z.current.y,
          V = s.clientX - Z.current.x,
          B = (m = e.swipeDirections) != null ? m : be(st);
        !y &&
          (Math.abs(V) > 1 || Math.abs(I) > 1) &&
          f(Math.abs(V) > Math.abs(I) ? "x" : "y");
        let D = { x: 0, y: 0 };
        (y === "y"
          ? (B.includes("top") || B.includes("bottom")) &&
            ((B.includes("top") && I < 0) || (B.includes("bottom") && I > 0)) &&
            (D.y = I)
          : y === "x" &&
            (B.includes("left") || B.includes("right")) &&
            ((B.includes("left") && V < 0) || (B.includes("right") && V > 0)) &&
            (D.x = V),
          (Math.abs(D.x) > 0 || Math.abs(D.y) > 0) && Mt(!0),
          (N = Y.current) == null ||
            N.style.setProperty("--swipe-amount-x", `${D.x}px`),
          (T = Y.current) == null ||
            T.style.setProperty("--swipe-amount-y", `${D.y}px`));
      },
    },
    Yt && !t.jsx
      ? r.createElement(
          "button",
          {
            "aria-label": mt,
            "data-disabled": wt,
            "data-close-button": !0,
            onClick:
              wt || !U
                ? () => {}
                : () => {
                    var s;
                    (H(), (s = t.onDismiss) == null || s.call(t, t));
                  },
            className: L(
              l?.closeButton,
              (h = t?.classNames) == null ? void 0 : h.closeButton,
            ),
          },
          (g = E?.close) != null ? g : re,
        )
      : null,
    t.jsx || A.isValidElement(t.title)
      ? t.jsx
        ? t.jsx
        : typeof t.title == "function"
          ? t.title()
          : t.title
      : r.createElement(
          r.Fragment,
          null,
          z || t.icon || t.promise
            ? r.createElement(
                "div",
                {
                  "data-icon": "",
                  className: L(
                    l?.icon,
                    (k = t?.classNames) == null ? void 0 : k.icon,
                  ),
                },
                t.promise || (t.type === "loading" && !t.icon)
                  ? t.icon || Gt()
                  : null,
                t.type !== "loading" ? t.icon || E?.[z] || Kt(z) : null,
              )
            : null,
          r.createElement(
            "div",
            {
              "data-content": "",
              className: L(
                l?.content,
                (w = t?.classNames) == null ? void 0 : w.content,
              ),
            },
            r.createElement(
              "div",
              {
                "data-title": "",
                className: L(
                  l?.title,
                  (d = t?.classNames) == null ? void 0 : d.title,
                ),
              },
              typeof t.title == "function" ? t.title() : t.title,
            ),
            t.description
              ? r.createElement(
                  "div",
                  {
                    "data-description": "",
                    className: L(
                      nt,
                      $t,
                      l?.description,
                      (p = t?.classNames) == null ? void 0 : p.description,
                    ),
                  },
                  typeof t.description == "function"
                    ? t.description()
                    : t.description,
                )
              : null,
          ),
          A.isValidElement(t.cancel)
            ? t.cancel
            : t.cancel && ct(t.cancel)
              ? r.createElement(
                  "button",
                  {
                    "data-button": !0,
                    "data-cancel": !0,
                    style: t.cancelButtonStyle || yt,
                    onClick: (s) => {
                      var c, m;
                      ct(t.cancel) &&
                        U &&
                        ((m = (c = t.cancel).onClick) == null || m.call(c, s),
                        H());
                    },
                    className: L(
                      l?.cancelButton,
                      (x = t?.classNames) == null ? void 0 : x.cancelButton,
                    ),
                  },
                  t.cancel.label,
                )
              : null,
          A.isValidElement(t.action)
            ? t.action
            : t.action && ct(t.action)
              ? r.createElement(
                  "button",
                  {
                    "data-button": !0,
                    "data-action": !0,
                    style: t.actionButtonStyle || ot,
                    onClick: (s) => {
                      var c, m;
                      ct(t.action) &&
                        ((m = (c = t.action).onClick) == null || m.call(c, s),
                        !s.defaultPrevented && H());
                    },
                    className: L(
                      l?.actionButton,
                      (tt = t?.classNames) == null ? void 0 : tt.actionButton,
                    ),
                  },
                  t.action.label,
                )
              : null,
        ),
  );
};
function Lt() {
  if (typeof window > "u" || typeof document > "u") return "ltr";
  let e = document.documentElement.getAttribute("dir");
  return e === "auto" || !e
    ? window.getComputedStyle(document.documentElement).direction
    : e;
}
function xe(e, a) {
  let n = {};
  return (
    [e, a].forEach((i, h) => {
      let g = h === 1,
        k = g ? "--mobile-offset" : "--offset",
        w = g ? ye : pe;
      function d(p) {
        ["top", "right", "bottom", "left"].forEach((x) => {
          n[`${k}-${x}`] = typeof p == "number" ? `${p}px` : p;
        });
      }
      typeof i == "number" || typeof i == "string"
        ? d(i)
        : typeof i == "object"
          ? ["top", "right", "bottom", "left"].forEach((p) => {
              i[p] === void 0
                ? (n[`${k}-${p}`] = w)
                : (n[`${k}-${p}`] =
                    typeof i[p] == "number" ? `${i[p]}px` : i[p]);
            })
          : d(w);
    }),
    n
  );
}
var Ea = A.forwardRef(function (e, a) {
  let {
      invert: n,
      position: i = "bottom-right",
      hotkey: h = ["altKey", "KeyT"],
      expand: g,
      closeButton: k,
      className: w,
      offset: d,
      mobileOffset: p,
      theme: x = "light",
      richColors: tt,
      duration: ht,
      style: t,
      visibleToasts: ut = ue,
      toastOptions: b,
      dir: j = Lt(),
      gap: et = fe,
      loadingIcon: O,
      icons: q,
      containerAriaLabel: pt = "Notifications",
      pauseWhenPageIsHidden: W,
    } = e,
    [S, K] = r.useState([]),
    at = r.useMemo(
      () =>
        Array.from(
          new Set(
            [i].concat(S.filter((u) => u.position).map((u) => u.position)),
          ),
        ),
      [S, i],
    ),
    [rt, yt] = r.useState([]),
    [ot, P] = r.useState(!1),
    [nt, F] = r.useState(!1),
    [st, $] = r.useState(
      x !== "system"
        ? x
        : typeof window < "u" &&
            window.matchMedia &&
            window.matchMedia("(prefers-color-scheme: dark)").matches
          ? "dark"
          : "light",
    ),
    R = r.useRef(null),
    it = h.join("+").replace(/Key/g, "").replace(/Digit/g, ""),
    l = r.useRef(null),
    E = r.useRef(!1),
    mt = r.useCallback((u) => {
      K((y) => {
        var f;
        return (
          ((f = y.find((M) => M.id === u.id)) != null && f.delete) ||
            C.dismiss(u.id),
          y.filter(({ id: M }) => M !== u.id)
        );
      });
    }, []);
  return (
    r.useEffect(
      () =>
        C.subscribe((u) => {
          if (u.dismiss) {
            K((y) => y.map((f) => (f.id === u.id ? { ...f, delete: !0 } : f)));
            return;
          }
          setTimeout(() => {
            Ut.flushSync(() => {
              K((y) => {
                let f = y.findIndex((M) => M.id === u.id);
                return f !== -1
                  ? [...y.slice(0, f), { ...y[f], ...u }, ...y.slice(f + 1)]
                  : [u, ...y];
              });
            });
          });
        }),
      [],
    ),
    r.useEffect(() => {
      if (x !== "system") {
        $(x);
        return;
      }
      if (
        (x === "system" &&
          (window.matchMedia &&
          window.matchMedia("(prefers-color-scheme: dark)").matches
            ? $("dark")
            : $("light")),
        typeof window > "u")
      )
        return;
      let u = window.matchMedia("(prefers-color-scheme: dark)");
      try {
        u.addEventListener("change", ({ matches: y }) => {
          $(y ? "dark" : "light");
        });
      } catch {
        u.addListener(({ matches: f }) => {
          try {
            $(f ? "dark" : "light");
          } catch (M) {
            console.error(M);
          }
        });
      }
    }, [x]),
    r.useEffect(() => {
      S.length <= 1 && P(!1);
    }, [S]),
    r.useEffect(() => {
      let u = (y) => {
        var f, M;
        (h.every((G) => y[G] || y.code === G) &&
          (P(!0), (f = R.current) == null || f.focus()),
          y.code === "Escape" &&
            (document.activeElement === R.current ||
              ((M = R.current) != null &&
                M.contains(document.activeElement))) &&
            P(!1));
      };
      return (
        document.addEventListener("keydown", u),
        () => document.removeEventListener("keydown", u)
      );
    }, [h]),
    r.useEffect(() => {
      if (R.current)
        return () => {
          l.current &&
            (l.current.focus({ preventScroll: !0 }),
            (l.current = null),
            (E.current = !1));
        };
    }, [R.current]),
    r.createElement(
      "section",
      {
        ref: a,
        "aria-label": `${pt} ${it}`,
        tabIndex: -1,
        "aria-live": "polite",
        "aria-relevant": "additions text",
        "aria-atomic": "false",
        suppressHydrationWarning: !0,
      },
      at.map((u, y) => {
        var f;
        let [M, G] = u.split("-");
        return S.length
          ? r.createElement(
              "ol",
              {
                key: u,
                dir: j === "auto" ? Lt() : j,
                tabIndex: -1,
                ref: R,
                className: w,
                "data-sonner-toaster": !0,
                "data-theme": st,
                "data-y-position": M,
                "data-lifted": ot && S.length > 1 && !g,
                "data-x-position": G,
                style: {
                  "--front-toast-height": `${((f = rt[0]) == null ? void 0 : f.height) || 0}px`,
                  "--width": `${me}px`,
                  "--gap": `${et}px`,
                  ...t,
                  ...xe(d, p),
                },
                onBlur: (v) => {
                  E.current &&
                    !v.currentTarget.contains(v.relatedTarget) &&
                    ((E.current = !1),
                    l.current &&
                      (l.current.focus({ preventScroll: !0 }),
                      (l.current = null)));
                },
                onFocus: (v) => {
                  (v.target instanceof HTMLElement &&
                    v.target.dataset.dismissible === "false") ||
                    E.current ||
                    ((E.current = !0), (l.current = v.relatedTarget));
                },
                onMouseEnter: () => P(!0),
                onMouseMove: () => P(!0),
                onMouseLeave: () => {
                  nt || P(!1);
                },
                onDragEnd: () => P(!1),
                onPointerDown: (v) => {
                  (v.target instanceof HTMLElement &&
                    v.target.dataset.dismissible === "false") ||
                    F(!0);
                },
                onPointerUp: () => F(!1),
              },
              S.filter((v) => (!v.position && y === 0) || v.position === u).map(
                (v, ft) => {
                  var J, lt;
                  return r.createElement(we, {
                    key: v.id,
                    icons: q,
                    index: ft,
                    toast: v,
                    defaultRichColors: tt,
                    duration: (J = b?.duration) != null ? J : ht,
                    className: b?.className,
                    descriptionClassName: b?.descriptionClassName,
                    invert: n,
                    visibleToasts: ut,
                    closeButton: (lt = b?.closeButton) != null ? lt : k,
                    interacting: nt,
                    position: u,
                    style: b?.style,
                    unstyled: b?.unstyled,
                    classNames: b?.classNames,
                    cancelButtonStyle: b?.cancelButtonStyle,
                    actionButtonStyle: b?.actionButtonStyle,
                    removeToast: mt,
                    toasts: S.filter((Q) => Q.position == v.position),
                    heights: rt.filter((Q) => Q.position == v.position),
                    setHeights: yt,
                    expandByDefault: g,
                    gap: et,
                    loadingIcon: O,
                    expanded: ot,
                    pauseWhenPageIsHidden: W,
                    swipeDirections: e.swipeDirections,
                  });
                },
              ),
            )
          : null;
      }),
    )
  );
});
export {
  Ea as $,
  ba as A,
  ze as B,
  Pe as C,
  Ae as D,
  He as E,
  De as F,
  $e as G,
  Le as H,
  Fe as I,
  Ce as J,
  Me as K,
  Ue as L,
  Ke as M,
  ta as N,
  va as O,
  ea as P,
  fa as Q,
  ha as R,
  pa as S,
  xa as T,
  ka as U,
  ga as V,
  je as W,
  Ma as X,
  la as Y,
  Ze as Z,
  sa as _,
  aa as a,
  na as a0,
  oa as a1,
  ra as a2,
  ca as b,
  Re as c,
  qe as d,
  Oe as e,
  Xe as f,
  Ge as g,
  Qe as h,
  Ye as i,
  ya as j,
  ia as k,
  Ve as l,
  Se as m,
  da as n,
  Ee as o,
  Ie as p,
  Je as q,
  We as r,
  Te as s,
  Be as t,
  Ca as u,
  Ne as v,
  ma as w,
  _e as x,
  wa as y,
  ua as z,
};
