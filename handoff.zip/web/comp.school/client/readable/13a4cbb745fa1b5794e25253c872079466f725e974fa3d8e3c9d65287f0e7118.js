import { co as rt, c4 as ea, _ as bt } from "./index-CHiQZc8e.js";
import { c as nt } from "./_commonjs-dynamic-modules-TDtrdbi3.js";
var pt = { exports: {} };
/*!

JSZip v3.10.2 - A JavaScript class for generating and reading zip files
<http://stuartk.com/jszip>

(c) 2009-2016 Stuart Knightley <stuart [at] stuartk.com>
Dual licenced under the MIT license or GPLv3. See https://raw.github.com/Stuk/jszip/main/LICENSE.markdown.

JSZip uses the library pako released under the MIT license :
https://github.com/nodeca/pako/blob/main/LICENSE
*/ var It;
function ta() {
  return (
    It ||
      ((It = 1),
      (function (e, A) {
        (function (t) {
          e.exports = t();
        })(function () {
          return (function t(o, n, s) {
            function l(a, r) {
              if (!n[a]) {
                if (!o[a]) {
                  var u = typeof nt == "function" && nt;
                  if (!r && u) return u(a, !0);
                  if (c) return c(a, !0);
                  var g = new Error("Cannot find module '" + a + "'");
                  throw ((g.code = "MODULE_NOT_FOUND"), g);
                }
                var d = (n[a] = { exports: {} });
                o[a][0].call(
                  d.exports,
                  function (m) {
                    var h = o[a][1][m];
                    return l(h || m);
                  },
                  d,
                  d.exports,
                  t,
                  o,
                  n,
                  s,
                );
              }
              return n[a].exports;
            }
            for (
              var c = typeof nt == "function" && nt, i = 0;
              i < s.length;
              i++
            )
              l(s[i]);
            return l;
          })(
            {
              1: [
                function (t, o, n) {
                  var s = t("./utils"),
                    l = t("./support"),
                    c =
                      "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
                  ((n.encode = function (i) {
                    for (
                      var a,
                        r,
                        u,
                        g,
                        d,
                        m,
                        h,
                        y = [],
                        v = 0,
                        b = i.length,
                        C = b,
                        D = s.getTypeOf(i) !== "string";
                      v < i.length;
                    )
                      ((C = b - v),
                        (u = D
                          ? ((a = i[v++]),
                            (r = v < b ? i[v++] : 0),
                            v < b ? i[v++] : 0)
                          : ((a = i.charCodeAt(v++)),
                            (r = v < b ? i.charCodeAt(v++) : 0),
                            v < b ? i.charCodeAt(v++) : 0)),
                        (g = a >> 2),
                        (d = ((3 & a) << 4) | (r >> 4)),
                        (m = 1 < C ? ((15 & r) << 2) | (u >> 6) : 64),
                        (h = 2 < C ? 63 & u : 64),
                        y.push(
                          c.charAt(g) + c.charAt(d) + c.charAt(m) + c.charAt(h),
                        ));
                    return y.join("");
                  }),
                    (n.decode = function (i) {
                      var a,
                        r,
                        u,
                        g,
                        d,
                        m,
                        h = 0,
                        y = 0,
                        v = "data:";
                      if (i.substr(0, v.length) === v)
                        throw new Error(
                          "Invalid base64 input, it looks like a data url.",
                        );
                      var b,
                        C =
                          (3 * (i = i.replace(/[^A-Za-z0-9+/=]/g, "")).length) /
                          4;
                      if (
                        (i.charAt(i.length - 1) === c.charAt(64) && C--,
                        i.charAt(i.length - 2) === c.charAt(64) && C--,
                        C % 1 != 0)
                      )
                        throw new Error(
                          "Invalid base64 input, bad content length.",
                        );
                      for (
                        b = l.uint8array
                          ? new Uint8Array(0 | C)
                          : new Array(0 | C);
                        h < i.length;
                      )
                        ((a =
                          (c.indexOf(i.charAt(h++)) << 2) |
                          ((g = c.indexOf(i.charAt(h++))) >> 4)),
                          (r =
                            ((15 & g) << 4) |
                            ((d = c.indexOf(i.charAt(h++))) >> 2)),
                          (u = ((3 & d) << 6) | (m = c.indexOf(i.charAt(h++)))),
                          (b[y++] = a),
                          d !== 64 && (b[y++] = r),
                          m !== 64 && (b[y++] = u));
                      return b;
                    }));
                },
                { "./support": 30, "./utils": 32 },
              ],
              2: [
                function (t, o, n) {
                  var s = t("./external"),
                    l = t("./stream/DataWorker"),
                    c = t("./stream/Crc32Probe"),
                    i = t("./stream/DataLengthProbe");
                  function a(r, u, g, d, m) {
                    ((this.compressedSize = r),
                      (this.uncompressedSize = u),
                      (this.crc32 = g),
                      (this.compression = d),
                      (this.compressedContent = m));
                  }
                  ((a.prototype = {
                    getContentWorker: function () {
                      var r = new l(s.Promise.resolve(this.compressedContent))
                          .pipe(this.compression.uncompressWorker())
                          .pipe(new i("data_length")),
                        u = this;
                      return (
                        r.on("end", function () {
                          if (
                            this.streamInfo.data_length !== u.uncompressedSize
                          )
                            throw new Error(
                              "Bug : uncompressed data size mismatch",
                            );
                        }),
                        r
                      );
                    },
                    getCompressedWorker: function () {
                      return new l(s.Promise.resolve(this.compressedContent))
                        .withStreamInfo("compressedSize", this.compressedSize)
                        .withStreamInfo(
                          "uncompressedSize",
                          this.uncompressedSize,
                        )
                        .withStreamInfo("crc32", this.crc32)
                        .withStreamInfo("compression", this.compression);
                    },
                  }),
                    (a.createWorkerFrom = function (r, u, g) {
                      return r
                        .pipe(new c())
                        .pipe(new i("uncompressedSize"))
                        .pipe(u.compressWorker(g))
                        .pipe(new i("compressedSize"))
                        .withStreamInfo("compression", u);
                    }),
                    (o.exports = a));
                },
                {
                  "./external": 6,
                  "./stream/Crc32Probe": 25,
                  "./stream/DataLengthProbe": 26,
                  "./stream/DataWorker": 27,
                },
              ],
              3: [
                function (t, o, n) {
                  var s = t("./stream/GenericWorker");
                  ((n.STORE = {
                    magic: "\0\0",
                    compressWorker: function () {
                      return new s("STORE compression");
                    },
                    uncompressWorker: function () {
                      return new s("STORE decompression");
                    },
                  }),
                    (n.DEFLATE = t("./flate")));
                },
                { "./flate": 7, "./stream/GenericWorker": 28 },
              ],
              4: [
                function (t, o, n) {
                  var s = t("./utils"),
                    l = (function () {
                      for (var c, i = [], a = 0; a < 256; a++) {
                        c = a;
                        for (var r = 0; r < 8; r++)
                          c = 1 & c ? 3988292384 ^ (c >>> 1) : c >>> 1;
                        i[a] = c;
                      }
                      return i;
                    })();
                  o.exports = function (c, i) {
                    return c !== void 0 && c.length
                      ? s.getTypeOf(c) !== "string"
                        ? (function (a, r, u, g) {
                            var d = l,
                              m = g + u;
                            a ^= -1;
                            for (var h = g; h < m; h++)
                              a = (a >>> 8) ^ d[255 & (a ^ r[h])];
                            return -1 ^ a;
                          })(0 | i, c, c.length, 0)
                        : (function (a, r, u, g) {
                            var d = l,
                              m = g + u;
                            a ^= -1;
                            for (var h = g; h < m; h++)
                              a = (a >>> 8) ^ d[255 & (a ^ r.charCodeAt(h))];
                            return -1 ^ a;
                          })(0 | i, c, c.length, 0)
                      : 0;
                  };
                },
                { "./utils": 32 },
              ],
              5: [
                function (t, o, n) {
                  ((n.base64 = !1),
                    (n.binary = !1),
                    (n.dir = !1),
                    (n.createFolders = !0),
                    (n.date = null),
                    (n.compression = null),
                    (n.compressionOptions = null),
                    (n.comment = null),
                    (n.unixPermissions = null),
                    (n.dosPermissions = null));
                },
                {},
              ],
              6: [
                function (t, o, n) {
                  var s = null;
                  ((s = typeof Promise < "u" ? Promise : t("lie")),
                    (o.exports = { Promise: s }));
                },
                { lie: 37 },
              ],
              7: [
                function (t, o, n) {
                  var s =
                      typeof Uint8Array < "u" &&
                      typeof Uint16Array < "u" &&
                      typeof Uint32Array < "u",
                    l = t("pako"),
                    c = t("./utils"),
                    i = t("./stream/GenericWorker"),
                    a = s ? "uint8array" : "array";
                  function r(u, g) {
                    (i.call(this, "FlateWorker/" + u),
                      (this._pako = null),
                      (this._pakoAction = u),
                      (this._pakoOptions = g),
                      (this.meta = {}));
                  }
                  ((n.magic = "\b\0"),
                    c.inherits(r, i),
                    (r.prototype.processChunk = function (u) {
                      ((this.meta = u.meta),
                        this._pako === null && this._createPako(),
                        this._pako.push(c.transformTo(a, u.data), !1));
                    }),
                    (r.prototype.flush = function () {
                      (i.prototype.flush.call(this),
                        this._pako === null && this._createPako(),
                        this._pako.push([], !0));
                    }),
                    (r.prototype.cleanUp = function () {
                      (i.prototype.cleanUp.call(this), (this._pako = null));
                    }),
                    (r.prototype._createPako = function () {
                      this._pako = new l[this._pakoAction]({
                        raw: !0,
                        level: this._pakoOptions.level || -1,
                      });
                      var u = this;
                      this._pako.onData = function (g) {
                        u.push({ data: g, meta: u.meta });
                      };
                    }),
                    (n.compressWorker = function (u) {
                      return new r("Deflate", u);
                    }),
                    (n.uncompressWorker = function () {
                      return new r("Inflate", {});
                    }));
                },
                { "./stream/GenericWorker": 28, "./utils": 32, pako: 38 },
              ],
              8: [
                function (t, o, n) {
                  function s(d, m) {
                    var h,
                      y = "";
                    for (h = 0; h < m; h++)
                      ((y += String.fromCharCode(255 & d)), (d >>>= 8));
                    return y;
                  }
                  function l(d, m, h, y, v, b) {
                    var C,
                      D,
                      L = d.file,
                      M = d.compression,
                      _ = b !== a.utf8encode,
                      X = c.transformTo("string", b(L.name)),
                      P = c.transformTo("string", a.utf8encode(L.name)),
                      E = L.comment,
                      J = c.transformTo("string", b(E)),
                      B = c.transformTo("string", a.utf8encode(E)),
                      S = P.length !== L.name.length,
                      p = B.length !== E.length,
                      T = "",
                      Z = "",
                      U = "",
                      ae = L.dir,
                      Q = L.date,
                      $ = { crc32: 0, compressedSize: 0, uncompressedSize: 0 };
                    (m && !h) ||
                      (($.crc32 = d.crc32),
                      ($.compressedSize = d.compressedSize),
                      ($.uncompressedSize = d.uncompressedSize));
                    var F = 0;
                    (m && (F |= 8), _ || (!S && !p) || (F |= 2048));
                    var R = 0,
                      K = 0;
                    (ae && (R |= 16),
                      v === "UNIX"
                        ? ((K = 798),
                          (R |= (function (q, oe) {
                            var ye = q;
                            return (
                              q || (ye = oe ? 16893 : 33204),
                              (65535 & ye) << 16
                            );
                          })(L.unixPermissions, ae)))
                        : ((K = 20),
                          (R |= (function (q) {
                            return 63 & (q || 0);
                          })(L.dosPermissions))),
                      (C = Q.getUTCHours()),
                      (C <<= 6),
                      (C |= Q.getUTCMinutes()),
                      (C <<= 5),
                      (C |= Q.getUTCSeconds() / 2),
                      (D = Q.getUTCFullYear() - 1980),
                      (D <<= 4),
                      (D |= Q.getUTCMonth() + 1),
                      (D <<= 5),
                      (D |= Q.getUTCDate()),
                      S &&
                        ((Z = s(1, 1) + s(r(X), 4) + P),
                        (T += "up" + s(Z.length, 2) + Z)),
                      p &&
                        ((U = s(1, 1) + s(r(J), 4) + B),
                        (T += "uc" + s(U.length, 2) + U)));
                    var H = "";
                    return (
                      (H += `
\0`),
                      (H += s(F, 2)),
                      (H += M.magic),
                      (H += s(C, 2)),
                      (H += s(D, 2)),
                      (H += s($.crc32, 4)),
                      (H += s($.compressedSize, 4)),
                      (H += s($.uncompressedSize, 4)),
                      (H += s(X.length, 2)),
                      (H += s(T.length, 2)),
                      {
                        fileRecord: u.LOCAL_FILE_HEADER + H + X + T,
                        dirRecord:
                          u.CENTRAL_FILE_HEADER +
                          s(K, 2) +
                          H +
                          s(J.length, 2) +
                          "\0\0\0\0" +
                          s(R, 4) +
                          s(y, 4) +
                          X +
                          T +
                          J,
                      }
                    );
                  }
                  var c = t("../utils"),
                    i = t("../stream/GenericWorker"),
                    a = t("../utf8"),
                    r = t("../crc32"),
                    u = t("../signature");
                  function g(d, m, h, y) {
                    (i.call(this, "ZipFileWorker"),
                      (this.bytesWritten = 0),
                      (this.zipComment = m),
                      (this.zipPlatform = h),
                      (this.encodeFileName = y),
                      (this.streamFiles = d),
                      (this.accumulate = !1),
                      (this.contentBuffer = []),
                      (this.dirRecords = []),
                      (this.currentSourceOffset = 0),
                      (this.entriesCount = 0),
                      (this.currentFile = null),
                      (this._sources = []));
                  }
                  (c.inherits(g, i),
                    (g.prototype.push = function (d) {
                      var m = d.meta.percent || 0,
                        h = this.entriesCount,
                        y = this._sources.length;
                      this.accumulate
                        ? this.contentBuffer.push(d)
                        : ((this.bytesWritten += d.data.length),
                          i.prototype.push.call(this, {
                            data: d.data,
                            meta: {
                              currentFile: this.currentFile,
                              percent: h ? (m + 100 * (h - y - 1)) / h : 100,
                            },
                          }));
                    }),
                    (g.prototype.openedSource = function (d) {
                      ((this.currentSourceOffset = this.bytesWritten),
                        (this.currentFile = d.file.name));
                      var m = this.streamFiles && !d.file.dir;
                      if (m) {
                        var h = l(
                          d,
                          m,
                          !1,
                          this.currentSourceOffset,
                          this.zipPlatform,
                          this.encodeFileName,
                        );
                        this.push({ data: h.fileRecord, meta: { percent: 0 } });
                      } else this.accumulate = !0;
                    }),
                    (g.prototype.closedSource = function (d) {
                      this.accumulate = !1;
                      var m = this.streamFiles && !d.file.dir,
                        h = l(
                          d,
                          m,
                          !0,
                          this.currentSourceOffset,
                          this.zipPlatform,
                          this.encodeFileName,
                        );
                      if ((this.dirRecords.push(h.dirRecord), m))
                        this.push({
                          data: (function (y) {
                            return (
                              u.DATA_DESCRIPTOR +
                              s(y.crc32, 4) +
                              s(y.compressedSize, 4) +
                              s(y.uncompressedSize, 4)
                            );
                          })(d),
                          meta: { percent: 100 },
                        });
                      else
                        for (
                          this.push({
                            data: h.fileRecord,
                            meta: { percent: 0 },
                          });
                          this.contentBuffer.length;
                        )
                          this.push(this.contentBuffer.shift());
                      this.currentFile = null;
                    }),
                    (g.prototype.flush = function () {
                      for (
                        var d = this.bytesWritten, m = 0;
                        m < this.dirRecords.length;
                        m++
                      )
                        this.push({
                          data: this.dirRecords[m],
                          meta: { percent: 100 },
                        });
                      var h = this.bytesWritten - d,
                        y = (function (v, b, C, D, L) {
                          var M = c.transformTo("string", L(D));
                          return (
                            u.CENTRAL_DIRECTORY_END +
                            "\0\0\0\0" +
                            s(v, 2) +
                            s(v, 2) +
                            s(b, 4) +
                            s(C, 4) +
                            s(M.length, 2) +
                            M
                          );
                        })(
                          this.dirRecords.length,
                          h,
                          d,
                          this.zipComment,
                          this.encodeFileName,
                        );
                      this.push({ data: y, meta: { percent: 100 } });
                    }),
                    (g.prototype.prepareNextSource = function () {
                      ((this.previous = this._sources.shift()),
                        this.openedSource(this.previous.streamInfo),
                        this.isPaused
                          ? this.previous.pause()
                          : this.previous.resume());
                    }),
                    (g.prototype.registerPrevious = function (d) {
                      this._sources.push(d);
                      var m = this;
                      return (
                        d.on("data", function (h) {
                          m.processChunk(h);
                        }),
                        d.on("end", function () {
                          (m.closedSource(m.previous.streamInfo),
                            m._sources.length
                              ? m.prepareNextSource()
                              : m.end());
                        }),
                        d.on("error", function (h) {
                          m.error(h);
                        }),
                        this
                      );
                    }),
                    (g.prototype.resume = function () {
                      return (
                        !!i.prototype.resume.call(this) &&
                        (!this.previous && this._sources.length
                          ? (this.prepareNextSource(), !0)
                          : this.previous ||
                              this._sources.length ||
                              this.generatedError
                            ? void 0
                            : (this.end(), !0))
                      );
                    }),
                    (g.prototype.error = function (d) {
                      var m = this._sources;
                      if (!i.prototype.error.call(this, d)) return !1;
                      for (var h = 0; h < m.length; h++)
                        try {
                          m[h].error(d);
                        } catch {}
                      return !0;
                    }),
                    (g.prototype.lock = function () {
                      i.prototype.lock.call(this);
                      for (var d = this._sources, m = 0; m < d.length; m++)
                        d[m].lock();
                    }),
                    (o.exports = g));
                },
                {
                  "../crc32": 4,
                  "../signature": 23,
                  "../stream/GenericWorker": 28,
                  "../utf8": 31,
                  "../utils": 32,
                },
              ],
              9: [
                function (t, o, n) {
                  var s = t("../compressions"),
                    l = t("./ZipFileWorker");
                  n.generateWorker = function (c, i, a) {
                    var r = new l(
                        i.streamFiles,
                        a,
                        i.platform,
                        i.encodeFileName,
                      ),
                      u = 0;
                    try {
                      (c.forEach(function (g, d) {
                        u++;
                        var m = (function (b, C) {
                            var D = b || C,
                              L = s[D];
                            if (!L)
                              throw new Error(
                                D + " is not a valid compression method !",
                              );
                            return L;
                          })(d.options.compression, i.compression),
                          h =
                            d.options.compressionOptions ||
                            i.compressionOptions ||
                            {},
                          y = d.dir,
                          v = d.date;
                        d._compressWorker(m, h)
                          .withStreamInfo("file", {
                            name: g,
                            dir: y,
                            date: v,
                            comment: d.comment || "",
                            unixPermissions: d.unixPermissions,
                            dosPermissions: d.dosPermissions,
                          })
                          .pipe(r);
                      }),
                        (r.entriesCount = u));
                    } catch (g) {
                      r.error(g);
                    }
                    return r;
                  };
                },
                { "../compressions": 3, "./ZipFileWorker": 8 },
              ],
              10: [
                function (t, o, n) {
                  function s() {
                    if (!(this instanceof s)) return new s();
                    if (arguments.length)
                      throw new Error(
                        "The constructor with parameters has been removed in JSZip 3.0, please check the upgrade guide.",
                      );
                    ((this.files = Object.create(null)),
                      (this.comment = null),
                      (this.root = ""),
                      (this.clone = function () {
                        var l = new s();
                        for (var c in this)
                          typeof this[c] != "function" && (l[c] = this[c]);
                        return l;
                      }));
                  }
                  (((s.prototype = t("./object")).loadAsync = t("./load")),
                    (s.support = t("./support")),
                    (s.defaults = t("./defaults")),
                    (s.version = "3.10.2"),
                    (s.loadAsync = function (l, c) {
                      return new s().loadAsync(l, c);
                    }),
                    (s.external = t("./external")),
                    (o.exports = s));
                },
                {
                  "./defaults": 5,
                  "./external": 6,
                  "./load": 11,
                  "./object": 15,
                  "./support": 30,
                },
              ],
              11: [
                function (t, o, n) {
                  var s = t("./utils"),
                    l = t("./external"),
                    c = t("./utf8"),
                    i = t("./zipEntries"),
                    a = t("./stream/Crc32Probe"),
                    r = t("./nodejsUtils");
                  function u(g) {
                    return new l.Promise(function (d, m) {
                      var h = g.decompressed.getContentWorker().pipe(new a());
                      h.on("error", function (y) {
                        m(y);
                      })
                        .on("end", function () {
                          h.streamInfo.crc32 !== g.decompressed.crc32
                            ? m(new Error("Corrupted zip : CRC32 mismatch"))
                            : d();
                        })
                        .resume();
                    });
                  }
                  o.exports = function (g, d) {
                    var m = this;
                    return (
                      (d = s.extend(d || {}, {
                        base64: !1,
                        checkCRC32: !1,
                        optimizedBinaryString: !1,
                        createFolders: !1,
                        decodeFileName: c.utf8decode,
                      })),
                      r.isNode && r.isStream(g)
                        ? l.Promise.reject(
                            new Error(
                              "JSZip can't accept a stream when loading a zip file.",
                            ),
                          )
                        : s
                            .prepareContent(
                              "the loaded zip file",
                              g,
                              !0,
                              d.optimizedBinaryString,
                              d.base64,
                            )
                            .then(function (h) {
                              var y = new i(d);
                              return (y.load(h), y);
                            })
                            .then(function (h) {
                              var y = [l.Promise.resolve(h)],
                                v = h.files;
                              if (d.checkCRC32)
                                for (var b = 0; b < v.length; b++)
                                  y.push(u(v[b]));
                              return l.Promise.all(y);
                            })
                            .then(function (h) {
                              for (
                                var y = h.shift(), v = y.files, b = 0;
                                b < v.length;
                                b++
                              ) {
                                var C = v[b],
                                  D = C.fileNameStr,
                                  L = s.resolve(C.fileNameStr);
                                (m.file(L, C.decompressed, {
                                  binary: !0,
                                  optimizedBinaryString: !0,
                                  date: C.date,
                                  dir: C.dir,
                                  comment: C.fileCommentStr.length
                                    ? C.fileCommentStr
                                    : null,
                                  unixPermissions: C.unixPermissions,
                                  dosPermissions: C.dosPermissions,
                                  createFolders: d.createFolders,
                                }),
                                  C.dir || (m.file(L).unsafeOriginalName = D));
                              }
                              return (
                                y.zipComment.length &&
                                  (m.comment = y.zipComment),
                                m
                              );
                            })
                    );
                  };
                },
                {
                  "./external": 6,
                  "./nodejsUtils": 14,
                  "./stream/Crc32Probe": 25,
                  "./utf8": 31,
                  "./utils": 32,
                  "./zipEntries": 33,
                },
              ],
              12: [
                function (t, o, n) {
                  var s = t("../utils"),
                    l = t("../stream/GenericWorker");
                  function c(i, a) {
                    (l.call(this, "Nodejs stream input adapter for " + i),
                      (this._upstreamEnded = !1),
                      this._bindStream(a));
                  }
                  (s.inherits(c, l),
                    (c.prototype._bindStream = function (i) {
                      var a = this;
                      ((this._stream = i).pause(),
                        i
                          .on("data", function (r) {
                            a.push({ data: r, meta: { percent: 0 } });
                          })
                          .on("error", function (r) {
                            a.isPaused ? (this.generatedError = r) : a.error(r);
                          })
                          .on("end", function () {
                            a.isPaused ? (a._upstreamEnded = !0) : a.end();
                          }));
                    }),
                    (c.prototype.pause = function () {
                      return (
                        !!l.prototype.pause.call(this) &&
                        (this._stream.pause(), !0)
                      );
                    }),
                    (c.prototype.resume = function () {
                      return (
                        !!l.prototype.resume.call(this) &&
                        (this._upstreamEnded
                          ? this.end()
                          : this._stream.resume(),
                        !0)
                      );
                    }),
                    (o.exports = c));
                },
                { "../stream/GenericWorker": 28, "../utils": 32 },
              ],
              13: [
                function (t, o, n) {
                  var s = t("readable-stream").Readable;
                  function l(c, i, a) {
                    (s.call(this, i), (this._helper = c));
                    var r = this;
                    c.on("data", function (u, g) {
                      (r.push(u) || r._helper.pause(), a && a(g));
                    })
                      .on("error", function (u) {
                        r.emit("error", u);
                      })
                      .on("end", function () {
                        r.push(null);
                      });
                  }
                  (t("../utils").inherits(l, s),
                    (l.prototype._read = function () {
                      this._helper.resume();
                    }),
                    (o.exports = l));
                },
                { "../utils": 32, "readable-stream": 16 },
              ],
              14: [
                function (t, o, n) {
                  o.exports = {
                    isNode: typeof Buffer < "u",
                    newBufferFrom: function (s, l) {
                      if (Buffer.from && Buffer.from !== Uint8Array.from)
                        return Buffer.from(s, l);
                      if (typeof s == "number")
                        throw new Error(
                          'The "data" argument must not be a number',
                        );
                      return new Buffer(s, l);
                    },
                    allocBuffer: function (s) {
                      if (Buffer.alloc) return Buffer.alloc(s);
                      var l = new Buffer(s);
                      return (l.fill(0), l);
                    },
                    isBuffer: function (s) {
                      return Buffer.isBuffer(s);
                    },
                    isStream: function (s) {
                      return (
                        s &&
                        typeof s.on == "function" &&
                        typeof s.pause == "function" &&
                        typeof s.resume == "function"
                      );
                    },
                  };
                },
                {},
              ],
              15: [
                function (t, o, n) {
                  function s(L, M, _) {
                    var X,
                      P = c.getTypeOf(M),
                      E = c.extend(_ || {}, r);
                    ((E.date = E.date || new Date()),
                      E.compression !== null &&
                        (E.compression = E.compression.toUpperCase()),
                      typeof E.unixPermissions == "string" &&
                        (E.unixPermissions = parseInt(E.unixPermissions, 8)),
                      E.unixPermissions &&
                        16384 & E.unixPermissions &&
                        (E.dir = !0),
                      E.dosPermissions && 16 & E.dosPermissions && (E.dir = !0),
                      E.dir && (L = v(L)),
                      E.createFolders && (X = y(L)) && b.call(this, X, !0));
                    var J =
                      P === "string" && E.binary === !1 && E.base64 === !1;
                    ((_ && _.binary !== void 0) || (E.binary = !J),
                      ((M instanceof u && M.uncompressedSize === 0) ||
                        E.dir ||
                        !M ||
                        M.length === 0) &&
                        ((E.base64 = !1),
                        (E.binary = !0),
                        (M = ""),
                        (E.compression = "STORE"),
                        (P = "string")));
                    var B = null;
                    B =
                      M instanceof u || M instanceof i
                        ? M
                        : m.isNode && m.isStream(M)
                          ? new h(L, M)
                          : c.prepareContent(
                              L,
                              M,
                              E.binary,
                              E.optimizedBinaryString,
                              E.base64,
                            );
                    var S = new g(L, B, E);
                    this.files[L] = S;
                  }
                  var l = t("./utf8"),
                    c = t("./utils"),
                    i = t("./stream/GenericWorker"),
                    a = t("./stream/StreamHelper"),
                    r = t("./defaults"),
                    u = t("./compressedObject"),
                    g = t("./zipObject"),
                    d = t("./generate"),
                    m = t("./nodejsUtils"),
                    h = t("./nodejs/NodejsStreamInputAdapter"),
                    y = function (L) {
                      L.slice(-1) === "/" && (L = L.substring(0, L.length - 1));
                      var M = L.lastIndexOf("/");
                      return 0 < M ? L.substring(0, M) : "";
                    },
                    v = function (L) {
                      return (L.slice(-1) !== "/" && (L += "/"), L);
                    },
                    b = function (L, M) {
                      return (
                        (M = M !== void 0 ? M : r.createFolders),
                        (L = v(L)),
                        this.files[L] ||
                          s.call(this, L, null, { dir: !0, createFolders: M }),
                        this.files[L]
                      );
                    };
                  function C(L) {
                    return (
                      Object.prototype.toString.call(L) === "[object RegExp]"
                    );
                  }
                  var D = {
                    load: function () {
                      throw new Error(
                        "This method has been removed in JSZip 3.0, please check the upgrade guide.",
                      );
                    },
                    forEach: function (L) {
                      var M, _, X;
                      for (M in this.files)
                        ((X = this.files[M]),
                          (_ = M.slice(this.root.length, M.length)) &&
                            M.slice(0, this.root.length) === this.root &&
                            L(_, X));
                    },
                    filter: function (L) {
                      var M = [];
                      return (
                        this.forEach(function (_, X) {
                          L(_, X) && M.push(X);
                        }),
                        M
                      );
                    },
                    file: function (L, M, _) {
                      if (arguments.length !== 1)
                        return (
                          (L = this.root + L),
                          s.call(this, L, M, _),
                          this
                        );
                      if (C(L)) {
                        var X = L;
                        return this.filter(function (E, J) {
                          return !J.dir && X.test(E);
                        });
                      }
                      var P = this.files[this.root + L];
                      return P && !P.dir ? P : null;
                    },
                    folder: function (L) {
                      if (!L) return this;
                      if (C(L))
                        return this.filter(function (P, E) {
                          return E.dir && L.test(P);
                        });
                      var M = this.root + L,
                        _ = b.call(this, M),
                        X = this.clone();
                      return ((X.root = _.name), X);
                    },
                    remove: function (L) {
                      L = this.root + L;
                      var M = this.files[L];
                      if (
                        (M ||
                          (L.slice(-1) !== "/" && (L += "/"),
                          (M = this.files[L])),
                        M && !M.dir)
                      )
                        delete this.files[L];
                      else
                        for (
                          var _ = this.filter(function (P, E) {
                              return E.name.slice(0, L.length) === L;
                            }),
                            X = 0;
                          X < _.length;
                          X++
                        )
                          delete this.files[_[X].name];
                      return this;
                    },
                    generate: function () {
                      throw new Error(
                        "This method has been removed in JSZip 3.0, please check the upgrade guide.",
                      );
                    },
                    generateInternalStream: function (L) {
                      var M,
                        _ = {};
                      try {
                        if (
                          (((_ = c.extend(L || {}, {
                            streamFiles: !1,
                            compression: "STORE",
                            compressionOptions: null,
                            type: "",
                            platform: "DOS",
                            comment: null,
                            mimeType: "application/zip",
                            encodeFileName: l.utf8encode,
                          })).type = _.type.toLowerCase()),
                          (_.compression = _.compression.toUpperCase()),
                          _.type === "binarystring" && (_.type = "string"),
                          !_.type)
                        )
                          throw new Error("No output type specified.");
                        (c.checkSupport(_.type),
                          (_.platform !== "darwin" &&
                            _.platform !== "freebsd" &&
                            _.platform !== "linux" &&
                            _.platform !== "sunos") ||
                            (_.platform = "UNIX"),
                          _.platform === "win32" && (_.platform = "DOS"));
                        var X = _.comment || this.comment || "";
                        M = d.generateWorker(this, _, X);
                      } catch (P) {
                        (M = new i("error")).error(P);
                      }
                      return new a(M, _.type || "string", _.mimeType);
                    },
                    generateAsync: function (L, M) {
                      return this.generateInternalStream(L).accumulate(M);
                    },
                    generateNodeStream: function (L, M) {
                      return (
                        (L = L || {}).type || (L.type = "nodebuffer"),
                        this.generateInternalStream(L).toNodejsStream(M)
                      );
                    },
                  };
                  o.exports = D;
                },
                {
                  "./compressedObject": 2,
                  "./defaults": 5,
                  "./generate": 9,
                  "./nodejs/NodejsStreamInputAdapter": 12,
                  "./nodejsUtils": 14,
                  "./stream/GenericWorker": 28,
                  "./stream/StreamHelper": 29,
                  "./utf8": 31,
                  "./utils": 32,
                  "./zipObject": 35,
                },
              ],
              16: [
                function (t, o, n) {
                  o.exports = t("stream");
                },
                { stream: void 0 },
              ],
              17: [
                function (t, o, n) {
                  var s = t("./DataReader");
                  function l(c) {
                    s.call(this, c);
                    for (var i = 0; i < this.data.length; i++)
                      c[i] = 255 & c[i];
                  }
                  (t("../utils").inherits(l, s),
                    (l.prototype.byteAt = function (c) {
                      return this.data[this.zero + c];
                    }),
                    (l.prototype.lastIndexOfSignature = function (c) {
                      for (
                        var i = c.charCodeAt(0),
                          a = c.charCodeAt(1),
                          r = c.charCodeAt(2),
                          u = c.charCodeAt(3),
                          g = this.length - 4;
                        0 <= g;
                        --g
                      )
                        if (
                          this.data[g] === i &&
                          this.data[g + 1] === a &&
                          this.data[g + 2] === r &&
                          this.data[g + 3] === u
                        )
                          return g - this.zero;
                      return -1;
                    }),
                    (l.prototype.readAndCheckSignature = function (c) {
                      var i = c.charCodeAt(0),
                        a = c.charCodeAt(1),
                        r = c.charCodeAt(2),
                        u = c.charCodeAt(3),
                        g = this.readData(4);
                      return (
                        i === g[0] && a === g[1] && r === g[2] && u === g[3]
                      );
                    }),
                    (l.prototype.readData = function (c) {
                      if ((this.checkOffset(c), c === 0)) return [];
                      var i = this.data.slice(
                        this.zero + this.index,
                        this.zero + this.index + c,
                      );
                      return ((this.index += c), i);
                    }),
                    (o.exports = l));
                },
                { "../utils": 32, "./DataReader": 18 },
              ],
              18: [
                function (t, o, n) {
                  var s = t("../utils");
                  function l(c) {
                    ((this.data = c),
                      (this.length = c.length),
                      (this.index = 0),
                      (this.zero = 0));
                  }
                  ((l.prototype = {
                    checkOffset: function (c) {
                      this.checkIndex(this.index + c);
                    },
                    checkIndex: function (c) {
                      if (this.length < this.zero + c || c < 0)
                        throw new Error(
                          "End of data reached (data length = " +
                            this.length +
                            ", asked index = " +
                            c +
                            "). Corrupted zip ?",
                        );
                    },
                    setIndex: function (c) {
                      (this.checkIndex(c), (this.index = c));
                    },
                    skip: function (c) {
                      this.setIndex(this.index + c);
                    },
                    byteAt: function () {},
                    readInt: function (c) {
                      var i,
                        a = 0;
                      for (
                        this.checkOffset(c), i = this.index + c - 1;
                        i >= this.index;
                        i--
                      )
                        a = (a << 8) + this.byteAt(i);
                      return ((this.index += c), a);
                    },
                    readString: function (c) {
                      return s.transformTo("string", this.readData(c));
                    },
                    readData: function () {},
                    lastIndexOfSignature: function () {},
                    readAndCheckSignature: function () {},
                    readDate: function () {
                      var c = this.readInt(4);
                      return new Date(
                        Date.UTC(
                          1980 + ((c >> 25) & 127),
                          ((c >> 21) & 15) - 1,
                          (c >> 16) & 31,
                          (c >> 11) & 31,
                          (c >> 5) & 63,
                          (31 & c) << 1,
                        ),
                      );
                    },
                  }),
                    (o.exports = l));
                },
                { "../utils": 32 },
              ],
              19: [
                function (t, o, n) {
                  var s = t("./Uint8ArrayReader");
                  function l(c) {
                    s.call(this, c);
                  }
                  (t("../utils").inherits(l, s),
                    (l.prototype.readData = function (c) {
                      this.checkOffset(c);
                      var i = this.data.slice(
                        this.zero + this.index,
                        this.zero + this.index + c,
                      );
                      return ((this.index += c), i);
                    }),
                    (o.exports = l));
                },
                { "../utils": 32, "./Uint8ArrayReader": 21 },
              ],
              20: [
                function (t, o, n) {
                  var s = t("./DataReader");
                  function l(c) {
                    s.call(this, c);
                  }
                  (t("../utils").inherits(l, s),
                    (l.prototype.byteAt = function (c) {
                      return this.data.charCodeAt(this.zero + c);
                    }),
                    (l.prototype.lastIndexOfSignature = function (c) {
                      return this.data.lastIndexOf(c) - this.zero;
                    }),
                    (l.prototype.readAndCheckSignature = function (c) {
                      return c === this.readData(4);
                    }),
                    (l.prototype.readData = function (c) {
                      this.checkOffset(c);
                      var i = this.data.slice(
                        this.zero + this.index,
                        this.zero + this.index + c,
                      );
                      return ((this.index += c), i);
                    }),
                    (o.exports = l));
                },
                { "../utils": 32, "./DataReader": 18 },
              ],
              21: [
                function (t, o, n) {
                  var s = t("./ArrayReader");
                  function l(c) {
                    s.call(this, c);
                  }
                  (t("../utils").inherits(l, s),
                    (l.prototype.readData = function (c) {
                      if ((this.checkOffset(c), c === 0))
                        return new Uint8Array(0);
                      var i = this.data.subarray(
                        this.zero + this.index,
                        this.zero + this.index + c,
                      );
                      return ((this.index += c), i);
                    }),
                    (o.exports = l));
                },
                { "../utils": 32, "./ArrayReader": 17 },
              ],
              22: [
                function (t, o, n) {
                  var s = t("../utils"),
                    l = t("../support"),
                    c = t("./ArrayReader"),
                    i = t("./StringReader"),
                    a = t("./NodeBufferReader"),
                    r = t("./Uint8ArrayReader");
                  o.exports = function (u) {
                    var g = s.getTypeOf(u);
                    return (
                      s.checkSupport(g),
                      g !== "string" || l.uint8array
                        ? g === "nodebuffer"
                          ? new a(u)
                          : l.uint8array
                            ? new r(s.transformTo("uint8array", u))
                            : new c(s.transformTo("array", u))
                        : new i(u)
                    );
                  };
                },
                {
                  "../support": 30,
                  "../utils": 32,
                  "./ArrayReader": 17,
                  "./NodeBufferReader": 19,
                  "./StringReader": 20,
                  "./Uint8ArrayReader": 21,
                },
              ],
              23: [
                function (t, o, n) {
                  ((n.LOCAL_FILE_HEADER = "PK"),
                    (n.CENTRAL_FILE_HEADER = "PK"),
                    (n.CENTRAL_DIRECTORY_END = "PK"),
                    (n.ZIP64_CENTRAL_DIRECTORY_LOCATOR = "PK\x07"),
                    (n.ZIP64_CENTRAL_DIRECTORY_END = "PK"),
                    (n.DATA_DESCRIPTOR = "PK\x07\b"));
                },
                {},
              ],
              24: [
                function (t, o, n) {
                  var s = t("./GenericWorker"),
                    l = t("../utils");
                  function c(i) {
                    (s.call(this, "ConvertWorker to " + i),
                      (this.destType = i));
                  }
                  (l.inherits(c, s),
                    (c.prototype.processChunk = function (i) {
                      this.push({
                        data: l.transformTo(this.destType, i.data),
                        meta: i.meta,
                      });
                    }),
                    (o.exports = c));
                },
                { "../utils": 32, "./GenericWorker": 28 },
              ],
              25: [
                function (t, o, n) {
                  var s = t("./GenericWorker"),
                    l = t("../crc32");
                  function c() {
                    (s.call(this, "Crc32Probe"),
                      this.withStreamInfo("crc32", 0));
                  }
                  (t("../utils").inherits(c, s),
                    (c.prototype.processChunk = function (i) {
                      ((this.streamInfo.crc32 = l(
                        i.data,
                        this.streamInfo.crc32 || 0,
                      )),
                        this.push(i));
                    }),
                    (o.exports = c));
                },
                { "../crc32": 4, "../utils": 32, "./GenericWorker": 28 },
              ],
              26: [
                function (t, o, n) {
                  var s = t("../utils"),
                    l = t("./GenericWorker");
                  function c(i) {
                    (l.call(this, "DataLengthProbe for " + i),
                      (this.propName = i),
                      this.withStreamInfo(i, 0));
                  }
                  (s.inherits(c, l),
                    (c.prototype.processChunk = function (i) {
                      if (i) {
                        var a = this.streamInfo[this.propName] || 0;
                        this.streamInfo[this.propName] = a + i.data.length;
                      }
                      l.prototype.processChunk.call(this, i);
                    }),
                    (o.exports = c));
                },
                { "../utils": 32, "./GenericWorker": 28 },
              ],
              27: [
                function (t, o, n) {
                  var s = t("../utils"),
                    l = t("./GenericWorker");
                  function c(i) {
                    l.call(this, "DataWorker");
                    var a = this;
                    ((this.dataIsReady = !1),
                      (this.index = 0),
                      (this.max = 0),
                      (this.data = null),
                      (this.type = ""),
                      (this._tickScheduled = !1),
                      i.then(
                        function (r) {
                          ((a.dataIsReady = !0),
                            (a.data = r),
                            (a.max = (r && r.length) || 0),
                            (a.type = s.getTypeOf(r)),
                            a.isPaused || a._tickAndRepeat());
                        },
                        function (r) {
                          a.error(r);
                        },
                      ));
                  }
                  (s.inherits(c, l),
                    (c.prototype.cleanUp = function () {
                      (l.prototype.cleanUp.call(this), (this.data = null));
                    }),
                    (c.prototype.resume = function () {
                      return (
                        !!l.prototype.resume.call(this) &&
                        (!this._tickScheduled &&
                          this.dataIsReady &&
                          ((this._tickScheduled = !0),
                          s.delay(this._tickAndRepeat, [], this)),
                        !0)
                      );
                    }),
                    (c.prototype._tickAndRepeat = function () {
                      ((this._tickScheduled = !1),
                        this.isPaused ||
                          this.isFinished ||
                          (this._tick(),
                          this.isFinished ||
                            (s.delay(this._tickAndRepeat, [], this),
                            (this._tickScheduled = !0))));
                    }),
                    (c.prototype._tick = function () {
                      if (this.isPaused || this.isFinished) return !1;
                      var i = null,
                        a = Math.min(this.max, this.index + 16384);
                      if (this.index >= this.max) return this.end();
                      switch (this.type) {
                        case "string":
                          i = this.data.substring(this.index, a);
                          break;
                        case "uint8array":
                          i = this.data.subarray(this.index, a);
                          break;
                        case "array":
                        case "nodebuffer":
                          i = this.data.slice(this.index, a);
                      }
                      return (
                        (this.index = a),
                        this.push({
                          data: i,
                          meta: {
                            percent: this.max
                              ? (this.index / this.max) * 100
                              : 0,
                          },
                        })
                      );
                    }),
                    (o.exports = c));
                },
                { "../utils": 32, "./GenericWorker": 28 },
              ],
              28: [
                function (t, o, n) {
                  function s(l) {
                    ((this.name = l || "default"),
                      (this.streamInfo = {}),
                      (this.generatedError = null),
                      (this.extraStreamInfo = {}),
                      (this.isPaused = !0),
                      (this.isFinished = !1),
                      (this.isLocked = !1),
                      (this._listeners = { data: [], end: [], error: [] }),
                      (this.previous = null));
                  }
                  ((s.prototype = {
                    push: function (l) {
                      this.emit("data", l);
                    },
                    end: function () {
                      if (this.isFinished) return !1;
                      this.flush();
                      try {
                        (this.emit("end"),
                          this.cleanUp(),
                          (this.isFinished = !0));
                      } catch (l) {
                        this.emit("error", l);
                      }
                      return !0;
                    },
                    error: function (l) {
                      return (
                        !this.isFinished &&
                        (this.isPaused
                          ? (this.generatedError = l)
                          : ((this.isFinished = !0),
                            this.emit("error", l),
                            this.previous && this.previous.error(l),
                            this.cleanUp()),
                        !0)
                      );
                    },
                    on: function (l, c) {
                      return (this._listeners[l].push(c), this);
                    },
                    cleanUp: function () {
                      ((this.streamInfo =
                        this.generatedError =
                        this.extraStreamInfo =
                          null),
                        (this._listeners = []));
                    },
                    emit: function (l, c) {
                      if (this._listeners[l])
                        for (var i = 0; i < this._listeners[l].length; i++)
                          this._listeners[l][i].call(this, c);
                    },
                    pipe: function (l) {
                      return l.registerPrevious(this);
                    },
                    registerPrevious: function (l) {
                      if (this.isLocked)
                        throw new Error(
                          "The stream '" + this + "' has already been used.",
                        );
                      ((this.streamInfo = l.streamInfo),
                        this.mergeStreamInfo(),
                        (this.previous = l));
                      var c = this;
                      return (
                        l.on("data", function (i) {
                          c.processChunk(i);
                        }),
                        l.on("end", function () {
                          c.end();
                        }),
                        l.on("error", function (i) {
                          c.error(i);
                        }),
                        this
                      );
                    },
                    pause: function () {
                      return (
                        !this.isPaused &&
                        !this.isFinished &&
                        ((this.isPaused = !0),
                        this.previous && this.previous.pause(),
                        !0)
                      );
                    },
                    resume: function () {
                      if (!this.isPaused || this.isFinished) return !1;
                      var l = (this.isPaused = !1);
                      return (
                        this.generatedError &&
                          (this.error(this.generatedError), (l = !0)),
                        this.previous && this.previous.resume(),
                        !l
                      );
                    },
                    flush: function () {},
                    processChunk: function (l) {
                      this.push(l);
                    },
                    withStreamInfo: function (l, c) {
                      return (
                        (this.extraStreamInfo[l] = c),
                        this.mergeStreamInfo(),
                        this
                      );
                    },
                    mergeStreamInfo: function () {
                      for (var l in this.extraStreamInfo)
                        Object.prototype.hasOwnProperty.call(
                          this.extraStreamInfo,
                          l,
                        ) && (this.streamInfo[l] = this.extraStreamInfo[l]);
                    },
                    lock: function () {
                      if (this.isLocked)
                        throw new Error(
                          "The stream '" + this + "' has already been used.",
                        );
                      ((this.isLocked = !0),
                        this.previous && this.previous.lock());
                    },
                    toString: function () {
                      var l = "Worker " + this.name;
                      return this.previous ? this.previous + " -> " + l : l;
                    },
                  }),
                    (o.exports = s));
                },
                {},
              ],
              29: [
                function (t, o, n) {
                  var s = t("../utils"),
                    l = t("./ConvertWorker"),
                    c = t("./GenericWorker"),
                    i = t("../base64"),
                    a = t("../support"),
                    r = t("../external"),
                    u = null;
                  if (a.nodestream)
                    try {
                      u = t("../nodejs/NodejsStreamOutputAdapter");
                    } catch {}
                  function g(m, h) {
                    return new r.Promise(function (y, v) {
                      var b = [],
                        C = m._internalType,
                        D = m._outputType,
                        L = m._mimeType;
                      m.on("data", function (M, _) {
                        (b.push(M), h && h(_));
                      })
                        .on("error", function (M) {
                          ((b = []), v(M));
                        })
                        .on("end", function () {
                          try {
                            var M = (function (_, X, P) {
                              switch (_) {
                                case "blob":
                                  return s.newBlob(
                                    s.transformTo("arraybuffer", X),
                                    P,
                                  );
                                case "base64":
                                  return i.encode(X);
                                default:
                                  return s.transformTo(_, X);
                              }
                            })(
                              D,
                              (function (_, X) {
                                var P,
                                  E = 0,
                                  J = null,
                                  B = 0;
                                for (P = 0; P < X.length; P++) B += X[P].length;
                                switch (_) {
                                  case "string":
                                    return X.join("");
                                  case "array":
                                    return Array.prototype.concat.apply([], X);
                                  case "uint8array":
                                    for (
                                      J = new Uint8Array(B), P = 0;
                                      P < X.length;
                                      P++
                                    )
                                      (J.set(X[P], E), (E += X[P].length));
                                    return J;
                                  case "nodebuffer":
                                    return Buffer.concat(X);
                                  default:
                                    throw new Error(
                                      "concat : unsupported type '" + _ + "'",
                                    );
                                }
                              })(C, b),
                              L,
                            );
                            y(M);
                          } catch (_) {
                            v(_);
                          }
                          b = [];
                        })
                        .resume();
                    });
                  }
                  function d(m, h, y) {
                    var v = h;
                    switch (h) {
                      case "blob":
                      case "arraybuffer":
                        v = "uint8array";
                        break;
                      case "base64":
                        v = "string";
                    }
                    try {
                      ((this._internalType = v),
                        (this._outputType = h),
                        (this._mimeType = y),
                        s.checkSupport(v),
                        (this._worker = m.pipe(new l(v))),
                        m.lock());
                    } catch (b) {
                      ((this._worker = new c("error")), this._worker.error(b));
                    }
                  }
                  ((d.prototype = {
                    accumulate: function (m) {
                      return g(this, m);
                    },
                    on: function (m, h) {
                      var y = this;
                      return (
                        m === "data"
                          ? this._worker.on(m, function (v) {
                              h.call(y, v.data, v.meta);
                            })
                          : this._worker.on(m, function () {
                              s.delay(h, arguments, y);
                            }),
                        this
                      );
                    },
                    resume: function () {
                      return (
                        s.delay(this._worker.resume, [], this._worker),
                        this
                      );
                    },
                    pause: function () {
                      return (this._worker.pause(), this);
                    },
                    toNodejsStream: function (m) {
                      if (
                        (s.checkSupport("nodestream"),
                        this._outputType !== "nodebuffer")
                      )
                        throw new Error(
                          this._outputType + " is not supported by this method",
                        );
                      return new u(
                        this,
                        { objectMode: this._outputType !== "nodebuffer" },
                        m,
                      );
                    },
                  }),
                    (o.exports = d));
                },
                {
                  "../base64": 1,
                  "../external": 6,
                  "../nodejs/NodejsStreamOutputAdapter": 13,
                  "../support": 30,
                  "../utils": 32,
                  "./ConvertWorker": 24,
                  "./GenericWorker": 28,
                },
              ],
              30: [
                function (t, o, n) {
                  if (
                    ((n.base64 = !0),
                    (n.array = !0),
                    (n.string = !0),
                    (n.arraybuffer =
                      typeof ArrayBuffer < "u" && typeof Uint8Array < "u"),
                    (n.nodebuffer = typeof Buffer < "u"),
                    (n.uint8array = typeof Uint8Array < "u"),
                    typeof ArrayBuffer > "u")
                  )
                    n.blob = !1;
                  else {
                    var s = new ArrayBuffer(0);
                    try {
                      n.blob =
                        new Blob([s], { type: "application/zip" }).size === 0;
                    } catch {
                      try {
                        var l = new (
                          self.BlobBuilder ||
                          self.WebKitBlobBuilder ||
                          self.MozBlobBuilder ||
                          self.MSBlobBuilder
                        )();
                        (l.append(s),
                          (n.blob = l.getBlob("application/zip").size === 0));
                      } catch {
                        n.blob = !1;
                      }
                    }
                  }
                  try {
                    n.nodestream = !!t("readable-stream").Readable;
                  } catch {
                    n.nodestream = !1;
                  }
                },
                { "readable-stream": 16 },
              ],
              31: [
                function (t, o, n) {
                  for (
                    var s = t("./utils"),
                      l = t("./support"),
                      c = t("./nodejsUtils"),
                      i = t("./stream/GenericWorker"),
                      a = new Array(256),
                      r = 0;
                    r < 256;
                    r++
                  )
                    a[r] =
                      252 <= r
                        ? 6
                        : 248 <= r
                          ? 5
                          : 240 <= r
                            ? 4
                            : 224 <= r
                              ? 3
                              : 192 <= r
                                ? 2
                                : 1;
                  a[254] = a[254] = 1;
                  function u() {
                    (i.call(this, "utf-8 decode"), (this.leftOver = null));
                  }
                  function g() {
                    i.call(this, "utf-8 encode");
                  }
                  ((n.utf8encode = function (d) {
                    return l.nodebuffer
                      ? c.newBufferFrom(d, "utf-8")
                      : (function (m) {
                          var h,
                            y,
                            v,
                            b,
                            C,
                            D = m.length,
                            L = 0;
                          for (b = 0; b < D; b++)
                            ((64512 & (y = m.charCodeAt(b))) == 55296 &&
                              b + 1 < D &&
                              (64512 & (v = m.charCodeAt(b + 1))) == 56320 &&
                              ((y = 65536 + ((y - 55296) << 10) + (v - 56320)),
                              b++),
                              (L +=
                                y < 128
                                  ? 1
                                  : y < 2048
                                    ? 2
                                    : y < 65536
                                      ? 3
                                      : 4));
                          for (
                            h = l.uint8array ? new Uint8Array(L) : new Array(L),
                              b = C = 0;
                            C < L;
                            b++
                          )
                            ((64512 & (y = m.charCodeAt(b))) == 55296 &&
                              b + 1 < D &&
                              (64512 & (v = m.charCodeAt(b + 1))) == 56320 &&
                              ((y = 65536 + ((y - 55296) << 10) + (v - 56320)),
                              b++),
                              y < 128
                                ? (h[C++] = y)
                                : (y < 2048
                                    ? (h[C++] = 192 | (y >>> 6))
                                    : (y < 65536
                                        ? (h[C++] = 224 | (y >>> 12))
                                        : ((h[C++] = 240 | (y >>> 18)),
                                          (h[C++] = 128 | ((y >>> 12) & 63))),
                                      (h[C++] = 128 | ((y >>> 6) & 63))),
                                  (h[C++] = 128 | (63 & y))));
                          return h;
                        })(d);
                  }),
                    (n.utf8decode = function (d) {
                      return l.nodebuffer
                        ? s.transformTo("nodebuffer", d).toString("utf-8")
                        : (function (m) {
                            var h,
                              y,
                              v,
                              b,
                              C = m.length,
                              D = new Array(2 * C);
                            for (h = y = 0; h < C;)
                              if ((v = m[h++]) < 128) D[y++] = v;
                              else if (4 < (b = a[v]))
                                ((D[y++] = 65533), (h += b - 1));
                              else {
                                for (
                                  v &= b === 2 ? 31 : b === 3 ? 15 : 7;
                                  1 < b && h < C;
                                )
                                  ((v = (v << 6) | (63 & m[h++])), b--);
                                1 < b
                                  ? (D[y++] = 65533)
                                  : v < 65536
                                    ? (D[y++] = v)
                                    : ((v -= 65536),
                                      (D[y++] = 55296 | ((v >> 10) & 1023)),
                                      (D[y++] = 56320 | (1023 & v)));
                              }
                            return (
                              D.length !== y &&
                                (D.subarray
                                  ? (D = D.subarray(0, y))
                                  : (D.length = y)),
                              s.applyFromCharCode(D)
                            );
                          })(
                            (d = s.transformTo(
                              l.uint8array ? "uint8array" : "array",
                              d,
                            )),
                          );
                    }),
                    s.inherits(u, i),
                    (u.prototype.processChunk = function (d) {
                      var m = s.transformTo(
                        l.uint8array ? "uint8array" : "array",
                        d.data,
                      );
                      if (this.leftOver && this.leftOver.length) {
                        if (l.uint8array) {
                          var h = m;
                          ((m = new Uint8Array(
                            h.length + this.leftOver.length,
                          )).set(this.leftOver, 0),
                            m.set(h, this.leftOver.length));
                        } else m = this.leftOver.concat(m);
                        this.leftOver = null;
                      }
                      var y = (function (b, C) {
                          var D;
                          for (
                            (C = C || b.length) > b.length && (C = b.length),
                              D = C - 1;
                            0 <= D && (192 & b[D]) == 128;
                          )
                            D--;
                          return D < 0 || D === 0 ? C : D + a[b[D]] > C ? D : C;
                        })(m),
                        v = m;
                      (y !== m.length &&
                        (l.uint8array
                          ? ((v = m.subarray(0, y)),
                            (this.leftOver = m.subarray(y, m.length)))
                          : ((v = m.slice(0, y)),
                            (this.leftOver = m.slice(y, m.length)))),
                        this.push({ data: n.utf8decode(v), meta: d.meta }));
                    }),
                    (u.prototype.flush = function () {
                      this.leftOver &&
                        this.leftOver.length &&
                        (this.push({
                          data: n.utf8decode(this.leftOver),
                          meta: {},
                        }),
                        (this.leftOver = null));
                    }),
                    (n.Utf8DecodeWorker = u),
                    s.inherits(g, i),
                    (g.prototype.processChunk = function (d) {
                      this.push({ data: n.utf8encode(d.data), meta: d.meta });
                    }),
                    (n.Utf8EncodeWorker = g));
                },
                {
                  "./nodejsUtils": 14,
                  "./stream/GenericWorker": 28,
                  "./support": 30,
                  "./utils": 32,
                },
              ],
              32: [
                function (t, o, n) {
                  var s = t("./support"),
                    l = t("./base64"),
                    c = t("./nodejsUtils"),
                    i = t("./external");
                  function a(h) {
                    return h;
                  }
                  function r(h, y) {
                    for (var v = 0; v < h.length; ++v)
                      y[v] = 255 & h.charCodeAt(v);
                    return y;
                  }
                  (t("setimmediate"),
                    (n.newBlob = function (h, y) {
                      n.checkSupport("blob");
                      try {
                        return new Blob([h], { type: y });
                      } catch {
                        try {
                          var v = new (
                            self.BlobBuilder ||
                            self.WebKitBlobBuilder ||
                            self.MozBlobBuilder ||
                            self.MSBlobBuilder
                          )();
                          return (v.append(h), v.getBlob(y));
                        } catch {
                          throw new Error("Bug : can't construct the Blob.");
                        }
                      }
                    }));
                  var u = {
                    stringifyByChunk: function (h, y, v) {
                      var b = [],
                        C = 0,
                        D = h.length;
                      if (D <= v) return String.fromCharCode.apply(null, h);
                      for (; C < D;)
                        (y === "array" || y === "nodebuffer"
                          ? b.push(
                              String.fromCharCode.apply(
                                null,
                                h.slice(C, Math.min(C + v, D)),
                              ),
                            )
                          : b.push(
                              String.fromCharCode.apply(
                                null,
                                h.subarray(C, Math.min(C + v, D)),
                              ),
                            ),
                          (C += v));
                      return b.join("");
                    },
                    stringifyByChar: function (h) {
                      for (var y = "", v = 0; v < h.length; v++)
                        y += String.fromCharCode(h[v]);
                      return y;
                    },
                    applyCanBeUsed: {
                      uint8array: (function () {
                        try {
                          return (
                            s.uint8array &&
                            String.fromCharCode.apply(null, new Uint8Array(1))
                              .length === 1
                          );
                        } catch {
                          return !1;
                        }
                      })(),
                      nodebuffer: (function () {
                        try {
                          return (
                            s.nodebuffer &&
                            String.fromCharCode.apply(null, c.allocBuffer(1))
                              .length === 1
                          );
                        } catch {
                          return !1;
                        }
                      })(),
                    },
                  };
                  function g(h) {
                    var y = 65536,
                      v = n.getTypeOf(h),
                      b = !0;
                    if (
                      (v === "uint8array"
                        ? (b = u.applyCanBeUsed.uint8array)
                        : v === "nodebuffer" &&
                          (b = u.applyCanBeUsed.nodebuffer),
                      b)
                    )
                      for (; 1 < y;)
                        try {
                          return u.stringifyByChunk(h, v, y);
                        } catch {
                          y = Math.floor(y / 2);
                        }
                    return u.stringifyByChar(h);
                  }
                  function d(h, y) {
                    for (var v = 0; v < h.length; v++) y[v] = h[v];
                    return y;
                  }
                  n.applyFromCharCode = g;
                  var m = {};
                  ((m.string = {
                    string: a,
                    array: function (h) {
                      return r(h, new Array(h.length));
                    },
                    arraybuffer: function (h) {
                      return m.string.uint8array(h).buffer;
                    },
                    uint8array: function (h) {
                      return r(h, new Uint8Array(h.length));
                    },
                    nodebuffer: function (h) {
                      return r(h, c.allocBuffer(h.length));
                    },
                  }),
                    (m.array = {
                      string: g,
                      array: a,
                      arraybuffer: function (h) {
                        return new Uint8Array(h).buffer;
                      },
                      uint8array: function (h) {
                        return new Uint8Array(h);
                      },
                      nodebuffer: function (h) {
                        return c.newBufferFrom(h);
                      },
                    }),
                    (m.arraybuffer = {
                      string: function (h) {
                        return g(new Uint8Array(h));
                      },
                      array: function (h) {
                        return d(new Uint8Array(h), new Array(h.byteLength));
                      },
                      arraybuffer: a,
                      uint8array: function (h) {
                        return new Uint8Array(h);
                      },
                      nodebuffer: function (h) {
                        return c.newBufferFrom(new Uint8Array(h));
                      },
                    }),
                    (m.uint8array = {
                      string: g,
                      array: function (h) {
                        return d(h, new Array(h.length));
                      },
                      arraybuffer: function (h) {
                        return h.buffer;
                      },
                      uint8array: a,
                      nodebuffer: function (h) {
                        return c.newBufferFrom(h);
                      },
                    }),
                    (m.nodebuffer = {
                      string: g,
                      array: function (h) {
                        return d(h, new Array(h.length));
                      },
                      arraybuffer: function (h) {
                        return m.nodebuffer.uint8array(h).buffer;
                      },
                      uint8array: function (h) {
                        return d(h, new Uint8Array(h.length));
                      },
                      nodebuffer: a,
                    }),
                    (n.transformTo = function (h, y) {
                      if (((y = y || ""), !h)) return y;
                      n.checkSupport(h);
                      var v = n.getTypeOf(y);
                      return m[v][h](y);
                    }),
                    (n.resolve = function (h) {
                      for (
                        var y = h.split("/"), v = [], b = 0;
                        b < y.length;
                        b++
                      ) {
                        var C = y[b];
                        C === "." ||
                          (C === "" && b !== 0 && b !== y.length - 1) ||
                          (C === ".." ? v.pop() : v.push(C));
                      }
                      return v.join("/");
                    }),
                    (n.getTypeOf = function (h) {
                      if (typeof h == "string") return "string";
                      var y = Object.prototype.toString.call(h);
                      return y === "[object Array]"
                        ? "array"
                        : s.nodebuffer && c.isBuffer(h)
                          ? "nodebuffer"
                          : s.uint8array && y === "[object Uint8Array]"
                            ? "uint8array"
                            : s.arraybuffer && y === "[object ArrayBuffer]"
                              ? "arraybuffer"
                              : void 0;
                    }),
                    (n.checkSupport = function (h) {
                      if (!s[h.toLowerCase()])
                        throw new Error(
                          h + " is not supported by this platform",
                        );
                    }),
                    (n.MAX_VALUE_16BITS = 65535),
                    (n.MAX_VALUE_32BITS = -1),
                    (n.pretty = function (h) {
                      var y,
                        v,
                        b = "";
                      for (v = 0; v < (h || "").length; v++)
                        b +=
                          "\\x" +
                          ((y = h.charCodeAt(v)) < 16 ? "0" : "") +
                          y.toString(16).toUpperCase();
                      return b;
                    }),
                    (n.delay = function (h, y, v) {
                      setImmediate(function () {
                        h.apply(v || null, y || []);
                      });
                    }),
                    (n.inherits = function (h, y) {
                      function v() {}
                      ((v.prototype = y.prototype), (h.prototype = new v()));
                    }),
                    (n.extend = function () {
                      var h,
                        y,
                        v = {};
                      for (h = 0; h < arguments.length; h++)
                        for (y in arguments[h])
                          Object.prototype.hasOwnProperty.call(
                            arguments[h],
                            y,
                          ) &&
                            v[y] === void 0 &&
                            (v[y] = arguments[h][y]);
                      return v;
                    }),
                    (n.prepareContent = function (h, y, v, b, C) {
                      return i.Promise.resolve(y)
                        .then(function (D) {
                          return s.blob &&
                            (D instanceof Blob ||
                              ["[object File]", "[object Blob]"].indexOf(
                                Object.prototype.toString.call(D),
                              ) !== -1)
                            ? Blob.prototype.arrayBuffer !== void 0
                              ? D.arrayBuffer()
                              : typeof FileReader < "u"
                                ? new i.Promise(function (L, M) {
                                    var _ = new FileReader();
                                    ((_.onload = function (X) {
                                      L(X.target.result);
                                    }),
                                      (_.onerror = function (X) {
                                        M(X.target.error);
                                      }),
                                      _.readAsArrayBuffer(D));
                                  })
                                : i.Promise.reject(
                                    new Error(
                                      h +
                                        " is a Blob, but we have no way of reading it.",
                                    ),
                                  )
                            : D;
                        })
                        .then(function (D) {
                          var L = n.getTypeOf(D);
                          return L
                            ? (L === "arraybuffer"
                                ? (D = n.transformTo("uint8array", D))
                                : L === "string" &&
                                  (C
                                    ? (D = l.decode(D))
                                    : v &&
                                      b !== !0 &&
                                      (D = (function (M) {
                                        return r(
                                          M,
                                          s.uint8array
                                            ? new Uint8Array(M.length)
                                            : new Array(M.length),
                                        );
                                      })(D))),
                              D)
                            : i.Promise.reject(
                                new Error(
                                  "Can't read the data of '" +
                                    h +
                                    "'. Is it in a supported JavaScript type (String, Blob, ArrayBuffer, etc) ?",
                                ),
                              );
                        });
                    }));
                },
                {
                  "./base64": 1,
                  "./external": 6,
                  "./nodejsUtils": 14,
                  "./support": 30,
                  setimmediate: 54,
                },
              ],
              33: [
                function (t, o, n) {
                  var s = t("./reader/readerFor"),
                    l = t("./utils"),
                    c = t("./signature"),
                    i = t("./zipEntry"),
                    a = t("./support");
                  function r(u) {
                    ((this.files = []), (this.loadOptions = u));
                  }
                  ((r.prototype = {
                    checkSignature: function (u) {
                      if (!this.reader.readAndCheckSignature(u)) {
                        this.reader.index -= 4;
                        var g = this.reader.readString(4);
                        throw new Error(
                          "Corrupted zip or bug: unexpected signature (" +
                            l.pretty(g) +
                            ", expected " +
                            l.pretty(u) +
                            ")",
                        );
                      }
                    },
                    isSignature: function (u, g) {
                      var d = this.reader.index;
                      this.reader.setIndex(u);
                      var m = this.reader.readString(4) === g;
                      return (this.reader.setIndex(d), m);
                    },
                    readBlockEndOfCentral: function () {
                      ((this.diskNumber = this.reader.readInt(2)),
                        (this.diskWithCentralDirStart = this.reader.readInt(2)),
                        (this.centralDirRecordsOnThisDisk =
                          this.reader.readInt(2)),
                        (this.centralDirRecords = this.reader.readInt(2)),
                        (this.centralDirSize = this.reader.readInt(4)),
                        (this.centralDirOffset = this.reader.readInt(4)),
                        (this.zipCommentLength = this.reader.readInt(2)));
                      var u = this.reader.readData(this.zipCommentLength),
                        g = a.uint8array ? "uint8array" : "array",
                        d = l.transformTo(g, u);
                      this.zipComment = this.loadOptions.decodeFileName(d);
                    },
                    readBlockZip64EndOfCentral: function () {
                      ((this.zip64EndOfCentralSize = this.reader.readInt(8)),
                        this.reader.skip(4),
                        (this.diskNumber = this.reader.readInt(4)),
                        (this.diskWithCentralDirStart = this.reader.readInt(4)),
                        (this.centralDirRecordsOnThisDisk =
                          this.reader.readInt(8)),
                        (this.centralDirRecords = this.reader.readInt(8)),
                        (this.centralDirSize = this.reader.readInt(8)),
                        (this.centralDirOffset = this.reader.readInt(8)),
                        (this.zip64ExtensibleData = {}));
                      for (
                        var u, g, d, m = this.zip64EndOfCentralSize - 44;
                        0 < m;
                      )
                        ((u = this.reader.readInt(2)),
                          (g = this.reader.readInt(4)),
                          (d = this.reader.readData(g)),
                          (this.zip64ExtensibleData[u] = {
                            id: u,
                            length: g,
                            value: d,
                          }));
                    },
                    readBlockZip64EndOfCentralLocator: function () {
                      if (
                        ((this.diskWithZip64CentralDirStart =
                          this.reader.readInt(4)),
                        (this.relativeOffsetEndOfZip64CentralDir =
                          this.reader.readInt(8)),
                        (this.disksCount = this.reader.readInt(4)),
                        1 < this.disksCount)
                      )
                        throw new Error("Multi-volumes zip are not supported");
                    },
                    readLocalFiles: function () {
                      var u, g;
                      for (u = 0; u < this.files.length; u++)
                        ((g = this.files[u]),
                          this.reader.setIndex(g.localHeaderOffset),
                          this.checkSignature(c.LOCAL_FILE_HEADER),
                          g.readLocalPart(this.reader),
                          g.handleUTF8(),
                          g.processAttributes());
                    },
                    readCentralDir: function () {
                      var u;
                      for (
                        this.reader.setIndex(this.centralDirOffset);
                        this.reader.readAndCheckSignature(
                          c.CENTRAL_FILE_HEADER,
                        );
                      )
                        ((u = new i(
                          { zip64: this.zip64 },
                          this.loadOptions,
                        )).readCentralPart(this.reader),
                          this.files.push(u));
                      if (
                        this.centralDirRecords !== this.files.length &&
                        this.centralDirRecords !== 0 &&
                        this.files.length === 0
                      )
                        throw new Error(
                          "Corrupted zip or bug: expected " +
                            this.centralDirRecords +
                            " records in central dir, got " +
                            this.files.length,
                        );
                    },
                    readEndOfCentral: function () {
                      var u = this.reader.lastIndexOfSignature(
                        c.CENTRAL_DIRECTORY_END,
                      );
                      if (u < 0)
                        throw this.isSignature(0, c.LOCAL_FILE_HEADER)
                          ? new Error(
                              "Corrupted zip: can't find end of central directory",
                            )
                          : new Error(
                              "Can't find end of central directory : is this a zip file ? If it is, see https://stuk.github.io/jszip/documentation/howto/read_zip.html",
                            );
                      this.reader.setIndex(u);
                      var g = u;
                      if (
                        (this.checkSignature(c.CENTRAL_DIRECTORY_END),
                        this.readBlockEndOfCentral(),
                        this.diskNumber === l.MAX_VALUE_16BITS ||
                          this.diskWithCentralDirStart === l.MAX_VALUE_16BITS ||
                          this.centralDirRecordsOnThisDisk ===
                            l.MAX_VALUE_16BITS ||
                          this.centralDirRecords === l.MAX_VALUE_16BITS ||
                          this.centralDirSize === l.MAX_VALUE_32BITS ||
                          this.centralDirOffset === l.MAX_VALUE_32BITS)
                      ) {
                        if (
                          ((this.zip64 = !0),
                          (u = this.reader.lastIndexOfSignature(
                            c.ZIP64_CENTRAL_DIRECTORY_LOCATOR,
                          )) < 0)
                        )
                          throw new Error(
                            "Corrupted zip: can't find the ZIP64 end of central directory locator",
                          );
                        if (
                          (this.reader.setIndex(u),
                          this.checkSignature(
                            c.ZIP64_CENTRAL_DIRECTORY_LOCATOR,
                          ),
                          this.readBlockZip64EndOfCentralLocator(),
                          !this.isSignature(
                            this.relativeOffsetEndOfZip64CentralDir,
                            c.ZIP64_CENTRAL_DIRECTORY_END,
                          ) &&
                            ((this.relativeOffsetEndOfZip64CentralDir =
                              this.reader.lastIndexOfSignature(
                                c.ZIP64_CENTRAL_DIRECTORY_END,
                              )),
                            this.relativeOffsetEndOfZip64CentralDir < 0))
                        )
                          throw new Error(
                            "Corrupted zip: can't find the ZIP64 end of central directory",
                          );
                        (this.reader.setIndex(
                          this.relativeOffsetEndOfZip64CentralDir,
                        ),
                          this.checkSignature(c.ZIP64_CENTRAL_DIRECTORY_END),
                          this.readBlockZip64EndOfCentral());
                      }
                      var d = this.centralDirOffset + this.centralDirSize;
                      this.zip64 &&
                        ((d += 20), (d += 12 + this.zip64EndOfCentralSize));
                      var m = g - d;
                      if (0 < m)
                        this.isSignature(g, c.CENTRAL_FILE_HEADER) ||
                          (this.reader.zero = m);
                      else if (m < 0)
                        throw new Error(
                          "Corrupted zip: missing " + Math.abs(m) + " bytes.",
                        );
                    },
                    prepareReader: function (u) {
                      this.reader = s(u);
                    },
                    load: function (u) {
                      (this.prepareReader(u),
                        this.readEndOfCentral(),
                        this.readCentralDir(),
                        this.readLocalFiles());
                    },
                  }),
                    (o.exports = r));
                },
                {
                  "./reader/readerFor": 22,
                  "./signature": 23,
                  "./support": 30,
                  "./utils": 32,
                  "./zipEntry": 34,
                },
              ],
              34: [
                function (t, o, n) {
                  var s = t("./reader/readerFor"),
                    l = t("./utils"),
                    c = t("./compressedObject"),
                    i = t("./crc32"),
                    a = t("./utf8"),
                    r = t("./compressions"),
                    u = t("./support");
                  function g(d, m) {
                    ((this.options = d), (this.loadOptions = m));
                  }
                  ((g.prototype = {
                    isEncrypted: function () {
                      return (1 & this.bitFlag) == 1;
                    },
                    useUTF8: function () {
                      return (2048 & this.bitFlag) == 2048;
                    },
                    readLocalPart: function (d) {
                      var m, h;
                      if (
                        (d.skip(22),
                        (this.fileNameLength = d.readInt(2)),
                        (h = d.readInt(2)),
                        (this.fileName = d.readData(this.fileNameLength)),
                        d.skip(h),
                        this.compressedSize === -1 ||
                          this.uncompressedSize === -1)
                      )
                        throw new Error(
                          "Bug or corrupted zip : didn't get enough information from the central directory (compressedSize === -1 || uncompressedSize === -1)",
                        );
                      if (
                        (m = (function (y) {
                          for (var v in r)
                            if (
                              Object.prototype.hasOwnProperty.call(r, v) &&
                              r[v].magic === y
                            )
                              return r[v];
                          return null;
                        })(this.compressionMethod)) === null
                      )
                        throw new Error(
                          "Corrupted zip : compression " +
                            l.pretty(this.compressionMethod) +
                            " unknown (inner file : " +
                            l.transformTo("string", this.fileName) +
                            ")",
                        );
                      this.decompressed = new c(
                        this.compressedSize,
                        this.uncompressedSize,
                        this.crc32,
                        m,
                        d.readData(this.compressedSize),
                      );
                    },
                    readCentralPart: function (d) {
                      ((this.versionMadeBy = d.readInt(2)),
                        d.skip(2),
                        (this.bitFlag = d.readInt(2)),
                        (this.compressionMethod = d.readString(2)),
                        (this.date = d.readDate()),
                        (this.crc32 = d.readInt(4)),
                        (this.compressedSize = d.readInt(4)),
                        (this.uncompressedSize = d.readInt(4)));
                      var m = d.readInt(2);
                      if (
                        ((this.extraFieldsLength = d.readInt(2)),
                        (this.fileCommentLength = d.readInt(2)),
                        (this.diskNumberStart = d.readInt(2)),
                        (this.internalFileAttributes = d.readInt(2)),
                        (this.externalFileAttributes = d.readInt(4)),
                        (this.localHeaderOffset = d.readInt(4)),
                        this.isEncrypted())
                      )
                        throw new Error("Encrypted zip are not supported");
                      (d.skip(m),
                        this.readExtraFields(d),
                        this.parseZIP64ExtraField(d),
                        (this.fileComment = d.readData(
                          this.fileCommentLength,
                        )));
                    },
                    processAttributes: function () {
                      ((this.unixPermissions = null),
                        (this.dosPermissions = null));
                      var d = this.versionMadeBy >> 8;
                      ((this.dir = !!(16 & this.externalFileAttributes)),
                        d == 0 &&
                          (this.dosPermissions =
                            63 & this.externalFileAttributes),
                        d == 3 &&
                          (this.unixPermissions =
                            (this.externalFileAttributes >> 16) & 65535),
                        this.dir ||
                          this.fileNameStr.slice(-1) !== "/" ||
                          (this.dir = !0));
                    },
                    parseZIP64ExtraField: function () {
                      if (this.extraFields[1]) {
                        var d = s(this.extraFields[1].value);
                        (this.uncompressedSize === l.MAX_VALUE_32BITS &&
                          (this.uncompressedSize = d.readInt(8)),
                          this.compressedSize === l.MAX_VALUE_32BITS &&
                            (this.compressedSize = d.readInt(8)),
                          this.localHeaderOffset === l.MAX_VALUE_32BITS &&
                            (this.localHeaderOffset = d.readInt(8)),
                          this.diskNumberStart === l.MAX_VALUE_32BITS &&
                            (this.diskNumberStart = d.readInt(4)));
                      }
                    },
                    readExtraFields: function (d) {
                      var m,
                        h,
                        y,
                        v = d.index + this.extraFieldsLength;
                      for (
                        this.extraFields || (this.extraFields = {});
                        d.index + 4 < v;
                      )
                        ((m = d.readInt(2)),
                          (h = d.readInt(2)),
                          (y = d.readData(h)),
                          (this.extraFields[m] = {
                            id: m,
                            length: h,
                            value: y,
                          }));
                      d.setIndex(v);
                    },
                    handleUTF8: function () {
                      var d = u.uint8array ? "uint8array" : "array";
                      if (this.useUTF8())
                        ((this.fileNameStr = a.utf8decode(this.fileName)),
                          (this.fileCommentStr = a.utf8decode(
                            this.fileComment,
                          )));
                      else {
                        var m = this.findExtraFieldUnicodePath();
                        if (m !== null) this.fileNameStr = m;
                        else {
                          var h = l.transformTo(d, this.fileName);
                          this.fileNameStr = this.loadOptions.decodeFileName(h);
                        }
                        var y = this.findExtraFieldUnicodeComment();
                        if (y !== null) this.fileCommentStr = y;
                        else {
                          var v = l.transformTo(d, this.fileComment);
                          this.fileCommentStr =
                            this.loadOptions.decodeFileName(v);
                        }
                      }
                    },
                    findExtraFieldUnicodePath: function () {
                      var d = this.extraFields[28789];
                      if (d) {
                        var m = s(d.value);
                        return m.readInt(1) !== 1 ||
                          i(this.fileName) !== m.readInt(4)
                          ? null
                          : a.utf8decode(m.readData(d.length - 5));
                      }
                      return null;
                    },
                    findExtraFieldUnicodeComment: function () {
                      var d = this.extraFields[25461];
                      if (d) {
                        var m = s(d.value);
                        return m.readInt(1) !== 1 ||
                          i(this.fileComment) !== m.readInt(4)
                          ? null
                          : a.utf8decode(m.readData(d.length - 5));
                      }
                      return null;
                    },
                  }),
                    (o.exports = g));
                },
                {
                  "./compressedObject": 2,
                  "./compressions": 3,
                  "./crc32": 4,
                  "./reader/readerFor": 22,
                  "./support": 30,
                  "./utf8": 31,
                  "./utils": 32,
                },
              ],
              35: [
                function (t, o, n) {
                  function s(m, h, y) {
                    ((this.name = m),
                      (this.dir = y.dir),
                      (this.date = y.date),
                      (this.comment = y.comment),
                      (this.unixPermissions = y.unixPermissions),
                      (this.dosPermissions = y.dosPermissions),
                      (this._data = h),
                      (this._dataBinary = y.binary),
                      (this.options = {
                        compression: y.compression,
                        compressionOptions: y.compressionOptions,
                      }));
                  }
                  var l = t("./stream/StreamHelper"),
                    c = t("./stream/DataWorker"),
                    i = t("./utf8"),
                    a = t("./compressedObject"),
                    r = t("./stream/GenericWorker");
                  s.prototype = {
                    internalStream: function (m) {
                      var h = null,
                        y = "string";
                      try {
                        if (!m) throw new Error("No output type specified.");
                        var v =
                          (y = m.toLowerCase()) === "string" || y === "text";
                        ((y !== "binarystring" && y !== "text") ||
                          (y = "string"),
                          (h = this._decompressWorker()));
                        var b = !this._dataBinary;
                        (b && !v && (h = h.pipe(new i.Utf8EncodeWorker())),
                          !b && v && (h = h.pipe(new i.Utf8DecodeWorker())));
                      } catch (C) {
                        (h = new r("error")).error(C);
                      }
                      return new l(h, y, "");
                    },
                    async: function (m, h) {
                      return this.internalStream(m).accumulate(h);
                    },
                    nodeStream: function (m, h) {
                      return this.internalStream(
                        m || "nodebuffer",
                      ).toNodejsStream(h);
                    },
                    _compressWorker: function (m, h) {
                      if (
                        this._data instanceof a &&
                        this._data.compression.magic === m.magic
                      )
                        return this._data.getCompressedWorker();
                      var y = this._decompressWorker();
                      return (
                        this._dataBinary ||
                          (y = y.pipe(new i.Utf8EncodeWorker())),
                        a.createWorkerFrom(y, m, h)
                      );
                    },
                    _decompressWorker: function () {
                      return this._data instanceof a
                        ? this._data.getContentWorker()
                        : this._data instanceof r
                          ? this._data
                          : new c(this._data);
                    },
                  };
                  for (
                    var u = [
                        "asText",
                        "asBinary",
                        "asNodeBuffer",
                        "asUint8Array",
                        "asArrayBuffer",
                      ],
                      g = function () {
                        throw new Error(
                          "This method has been removed in JSZip 3.0, please check the upgrade guide.",
                        );
                      },
                      d = 0;
                    d < u.length;
                    d++
                  )
                    s.prototype[u[d]] = g;
                  o.exports = s;
                },
                {
                  "./compressedObject": 2,
                  "./stream/DataWorker": 27,
                  "./stream/GenericWorker": 28,
                  "./stream/StreamHelper": 29,
                  "./utf8": 31,
                },
              ],
              36: [
                function (t, o, n) {
                  (function (s) {
                    var l,
                      c,
                      i = s.MutationObserver || s.WebKitMutationObserver;
                    if (i) {
                      var a = 0,
                        r = new i(m),
                        u = s.document.createTextNode("");
                      (r.observe(u, { characterData: !0 }),
                        (l = function () {
                          u.data = a = ++a % 2;
                        }));
                    } else if (s.setImmediate || s.MessageChannel === void 0)
                      l =
                        "document" in s &&
                        "onreadystatechange" in
                          s.document.createElement("script")
                          ? function () {
                              var h = s.document.createElement("script");
                              ((h.onreadystatechange = function () {
                                (m(),
                                  (h.onreadystatechange = null),
                                  h.parentNode.removeChild(h),
                                  (h = null));
                              }),
                                s.document.documentElement.appendChild(h));
                            }
                          : function () {
                              setTimeout(m, 0);
                            };
                    else {
                      var g = new s.MessageChannel();
                      ((g.port1.onmessage = m),
                        (l = function () {
                          g.port2.postMessage(0);
                        }));
                    }
                    var d = [];
                    function m() {
                      var h, y;
                      c = !0;
                      for (var v = d.length; v;) {
                        for (y = d, d = [], h = -1; ++h < v;) y[h]();
                        v = d.length;
                      }
                      c = !1;
                    }
                    o.exports = function (h) {
                      d.push(h) !== 1 || c || l();
                    };
                  }).call(
                    this,
                    typeof rt < "u"
                      ? rt
                      : typeof self < "u"
                        ? self
                        : typeof window < "u"
                          ? window
                          : {},
                  );
                },
                {},
              ],
              37: [
                function (t, o, n) {
                  var s = t("immediate");
                  function l() {}
                  var c = {},
                    i = ["REJECTED"],
                    a = ["FULFILLED"],
                    r = ["PENDING"];
                  function u(v) {
                    if (typeof v != "function")
                      throw new TypeError("resolver must be a function");
                    ((this.state = r),
                      (this.queue = []),
                      (this.outcome = void 0),
                      v !== l && h(this, v));
                  }
                  function g(v, b, C) {
                    ((this.promise = v),
                      typeof b == "function" &&
                        ((this.onFulfilled = b),
                        (this.callFulfilled = this.otherCallFulfilled)),
                      typeof C == "function" &&
                        ((this.onRejected = C),
                        (this.callRejected = this.otherCallRejected)));
                  }
                  function d(v, b, C) {
                    s(function () {
                      var D;
                      try {
                        D = b(C);
                      } catch (L) {
                        return c.reject(v, L);
                      }
                      D === v
                        ? c.reject(
                            v,
                            new TypeError("Cannot resolve promise with itself"),
                          )
                        : c.resolve(v, D);
                    });
                  }
                  function m(v) {
                    var b = v && v.then;
                    if (
                      v &&
                      (typeof v == "object" || typeof v == "function") &&
                      typeof b == "function"
                    )
                      return function () {
                        b.apply(v, arguments);
                      };
                  }
                  function h(v, b) {
                    var C = !1;
                    function D(_) {
                      C || ((C = !0), c.reject(v, _));
                    }
                    function L(_) {
                      C || ((C = !0), c.resolve(v, _));
                    }
                    var M = y(function () {
                      b(L, D);
                    });
                    M.status === "error" && D(M.value);
                  }
                  function y(v, b) {
                    var C = {};
                    try {
                      ((C.value = v(b)), (C.status = "success"));
                    } catch (D) {
                      ((C.status = "error"), (C.value = D));
                    }
                    return C;
                  }
                  (((o.exports = u).prototype.finally = function (v) {
                    if (typeof v != "function") return this;
                    var b = this.constructor;
                    return this.then(
                      function (C) {
                        return b.resolve(v()).then(function () {
                          return C;
                        });
                      },
                      function (C) {
                        return b.resolve(v()).then(function () {
                          throw C;
                        });
                      },
                    );
                  }),
                    (u.prototype.catch = function (v) {
                      return this.then(null, v);
                    }),
                    (u.prototype.then = function (v, b) {
                      if (
                        (typeof v != "function" && this.state === a) ||
                        (typeof b != "function" && this.state === i)
                      )
                        return this;
                      var C = new this.constructor(l);
                      return (
                        this.state !== r
                          ? d(C, this.state === a ? v : b, this.outcome)
                          : this.queue.push(new g(C, v, b)),
                        C
                      );
                    }),
                    (g.prototype.callFulfilled = function (v) {
                      c.resolve(this.promise, v);
                    }),
                    (g.prototype.otherCallFulfilled = function (v) {
                      d(this.promise, this.onFulfilled, v);
                    }),
                    (g.prototype.callRejected = function (v) {
                      c.reject(this.promise, v);
                    }),
                    (g.prototype.otherCallRejected = function (v) {
                      d(this.promise, this.onRejected, v);
                    }),
                    (c.resolve = function (v, b) {
                      var C = y(m, b);
                      if (C.status === "error") return c.reject(v, C.value);
                      var D = C.value;
                      if (D) h(v, D);
                      else {
                        ((v.state = a), (v.outcome = b));
                        for (var L = -1, M = v.queue.length; ++L < M;)
                          v.queue[L].callFulfilled(b);
                      }
                      return v;
                    }),
                    (c.reject = function (v, b) {
                      ((v.state = i), (v.outcome = b));
                      for (var C = -1, D = v.queue.length; ++C < D;)
                        v.queue[C].callRejected(b);
                      return v;
                    }),
                    (u.resolve = function (v) {
                      return v instanceof this ? v : c.resolve(new this(l), v);
                    }),
                    (u.reject = function (v) {
                      var b = new this(l);
                      return c.reject(b, v);
                    }),
                    (u.all = function (v) {
                      var b = this;
                      if (
                        Object.prototype.toString.call(v) !== "[object Array]"
                      )
                        return this.reject(new TypeError("must be an array"));
                      var C = v.length,
                        D = !1;
                      if (!C) return this.resolve([]);
                      for (
                        var L = new Array(C), M = 0, _ = -1, X = new this(l);
                        ++_ < C;
                      )
                        P(v[_], _);
                      return X;
                      function P(E, J) {
                        b.resolve(E).then(
                          function (B) {
                            ((L[J] = B),
                              ++M !== C || D || ((D = !0), c.resolve(X, L)));
                          },
                          function (B) {
                            D || ((D = !0), c.reject(X, B));
                          },
                        );
                      }
                    }),
                    (u.race = function (v) {
                      var b = this;
                      if (
                        Object.prototype.toString.call(v) !== "[object Array]"
                      )
                        return this.reject(new TypeError("must be an array"));
                      var C = v.length,
                        D = !1;
                      if (!C) return this.resolve([]);
                      for (var L = -1, M = new this(l); ++L < C;)
                        ((_ = v[L]),
                          b.resolve(_).then(
                            function (X) {
                              D || ((D = !0), c.resolve(M, X));
                            },
                            function (X) {
                              D || ((D = !0), c.reject(M, X));
                            },
                          ));
                      var _;
                      return M;
                    }));
                },
                { immediate: 36 },
              ],
              38: [
                function (t, o, n) {
                  var s = {};
                  ((0, t("./lib/utils/common").assign)(
                    s,
                    t("./lib/deflate"),
                    t("./lib/inflate"),
                    t("./lib/zlib/constants"),
                  ),
                    (o.exports = s));
                },
                {
                  "./lib/deflate": 39,
                  "./lib/inflate": 40,
                  "./lib/utils/common": 41,
                  "./lib/zlib/constants": 44,
                },
              ],
              39: [
                function (t, o, n) {
                  var s = t("./zlib/deflate"),
                    l = t("./utils/common"),
                    c = t("./utils/strings"),
                    i = t("./zlib/messages"),
                    a = t("./zlib/zstream"),
                    r = Object.prototype.toString,
                    u = 0,
                    g = -1,
                    d = 0,
                    m = 8;
                  function h(v) {
                    if (!(this instanceof h)) return new h(v);
                    this.options = l.assign(
                      {
                        level: g,
                        method: m,
                        chunkSize: 16384,
                        windowBits: 15,
                        memLevel: 8,
                        strategy: d,
                        to: "",
                      },
                      v || {},
                    );
                    var b = this.options;
                    (b.raw && 0 < b.windowBits
                      ? (b.windowBits = -b.windowBits)
                      : b.gzip &&
                        0 < b.windowBits &&
                        b.windowBits < 16 &&
                        (b.windowBits += 16),
                      (this.err = 0),
                      (this.msg = ""),
                      (this.ended = !1),
                      (this.chunks = []),
                      (this.strm = new a()),
                      (this.strm.avail_out = 0));
                    var C = s.deflateInit2(
                      this.strm,
                      b.level,
                      b.method,
                      b.windowBits,
                      b.memLevel,
                      b.strategy,
                    );
                    if (C !== u) throw new Error(i[C]);
                    if (
                      (b.header && s.deflateSetHeader(this.strm, b.header),
                      b.dictionary)
                    ) {
                      var D;
                      if (
                        ((D =
                          typeof b.dictionary == "string"
                            ? c.string2buf(b.dictionary)
                            : r.call(b.dictionary) === "[object ArrayBuffer]"
                              ? new Uint8Array(b.dictionary)
                              : b.dictionary),
                        (C = s.deflateSetDictionary(this.strm, D)) !== u)
                      )
                        throw new Error(i[C]);
                      this._dict_set = !0;
                    }
                  }
                  function y(v, b) {
                    var C = new h(b);
                    if ((C.push(v, !0), C.err)) throw C.msg || i[C.err];
                    return C.result;
                  }
                  ((h.prototype.push = function (v, b) {
                    var C,
                      D,
                      L = this.strm,
                      M = this.options.chunkSize;
                    if (this.ended) return !1;
                    ((D = b === ~~b ? b : b === !0 ? 4 : 0),
                      typeof v == "string"
                        ? (L.input = c.string2buf(v))
                        : r.call(v) === "[object ArrayBuffer]"
                          ? (L.input = new Uint8Array(v))
                          : (L.input = v),
                      (L.next_in = 0),
                      (L.avail_in = L.input.length));
                    do {
                      if (
                        (L.avail_out === 0 &&
                          ((L.output = new l.Buf8(M)),
                          (L.next_out = 0),
                          (L.avail_out = M)),
                        (C = s.deflate(L, D)) !== 1 && C !== u)
                      )
                        return (this.onEnd(C), !(this.ended = !0));
                      (L.avail_out !== 0 &&
                        (L.avail_in !== 0 || (D !== 4 && D !== 2))) ||
                        (this.options.to === "string"
                          ? this.onData(
                              c.buf2binstring(
                                l.shrinkBuf(L.output, L.next_out),
                              ),
                            )
                          : this.onData(l.shrinkBuf(L.output, L.next_out)));
                    } while ((0 < L.avail_in || L.avail_out === 0) && C !== 1);
                    return D === 4
                      ? ((C = s.deflateEnd(this.strm)),
                        this.onEnd(C),
                        (this.ended = !0),
                        C === u)
                      : D !== 2 || (this.onEnd(u), !(L.avail_out = 0));
                  }),
                    (h.prototype.onData = function (v) {
                      this.chunks.push(v);
                    }),
                    (h.prototype.onEnd = function (v) {
                      (v === u &&
                        (this.options.to === "string"
                          ? (this.result = this.chunks.join(""))
                          : (this.result = l.flattenChunks(this.chunks))),
                        (this.chunks = []),
                        (this.err = v),
                        (this.msg = this.strm.msg));
                    }),
                    (n.Deflate = h),
                    (n.deflate = y),
                    (n.deflateRaw = function (v, b) {
                      return (((b = b || {}).raw = !0), y(v, b));
                    }),
                    (n.gzip = function (v, b) {
                      return (((b = b || {}).gzip = !0), y(v, b));
                    }));
                },
                {
                  "./utils/common": 41,
                  "./utils/strings": 42,
                  "./zlib/deflate": 46,
                  "./zlib/messages": 51,
                  "./zlib/zstream": 53,
                },
              ],
              40: [
                function (t, o, n) {
                  var s = t("./zlib/inflate"),
                    l = t("./utils/common"),
                    c = t("./utils/strings"),
                    i = t("./zlib/constants"),
                    a = t("./zlib/messages"),
                    r = t("./zlib/zstream"),
                    u = t("./zlib/gzheader"),
                    g = Object.prototype.toString;
                  function d(h) {
                    if (!(this instanceof d)) return new d(h);
                    this.options = l.assign(
                      { chunkSize: 16384, windowBits: 0, to: "" },
                      h || {},
                    );
                    var y = this.options;
                    (y.raw &&
                      0 <= y.windowBits &&
                      y.windowBits < 16 &&
                      ((y.windowBits = -y.windowBits),
                      y.windowBits === 0 && (y.windowBits = -15)),
                      !(0 <= y.windowBits && y.windowBits < 16) ||
                        (h && h.windowBits) ||
                        (y.windowBits += 32),
                      15 < y.windowBits &&
                        y.windowBits < 48 &&
                        (15 & y.windowBits) == 0 &&
                        (y.windowBits |= 15),
                      (this.err = 0),
                      (this.msg = ""),
                      (this.ended = !1),
                      (this.chunks = []),
                      (this.strm = new r()),
                      (this.strm.avail_out = 0));
                    var v = s.inflateInit2(this.strm, y.windowBits);
                    if (v !== i.Z_OK) throw new Error(a[v]);
                    ((this.header = new u()),
                      s.inflateGetHeader(this.strm, this.header));
                  }
                  function m(h, y) {
                    var v = new d(y);
                    if ((v.push(h, !0), v.err)) throw v.msg || a[v.err];
                    return v.result;
                  }
                  ((d.prototype.push = function (h, y) {
                    var v,
                      b,
                      C,
                      D,
                      L,
                      M,
                      _ = this.strm,
                      X = this.options.chunkSize,
                      P = this.options.dictionary,
                      E = !1;
                    if (this.ended) return !1;
                    ((b = y === ~~y ? y : y === !0 ? i.Z_FINISH : i.Z_NO_FLUSH),
                      typeof h == "string"
                        ? (_.input = c.binstring2buf(h))
                        : g.call(h) === "[object ArrayBuffer]"
                          ? (_.input = new Uint8Array(h))
                          : (_.input = h),
                      (_.next_in = 0),
                      (_.avail_in = _.input.length));
                    do {
                      if (
                        (_.avail_out === 0 &&
                          ((_.output = new l.Buf8(X)),
                          (_.next_out = 0),
                          (_.avail_out = X)),
                        (v = s.inflate(_, i.Z_NO_FLUSH)) === i.Z_NEED_DICT &&
                          P &&
                          ((M =
                            typeof P == "string"
                              ? c.string2buf(P)
                              : g.call(P) === "[object ArrayBuffer]"
                                ? new Uint8Array(P)
                                : P),
                          (v = s.inflateSetDictionary(this.strm, M))),
                        v === i.Z_BUF_ERROR &&
                          E === !0 &&
                          ((v = i.Z_OK), (E = !1)),
                        v !== i.Z_STREAM_END && v !== i.Z_OK)
                      )
                        return (this.onEnd(v), !(this.ended = !0));
                      (_.next_out &&
                        ((_.avail_out !== 0 &&
                          v !== i.Z_STREAM_END &&
                          (_.avail_in !== 0 ||
                            (b !== i.Z_FINISH && b !== i.Z_SYNC_FLUSH))) ||
                          (this.options.to === "string"
                            ? ((C = c.utf8border(_.output, _.next_out)),
                              (D = _.next_out - C),
                              (L = c.buf2string(_.output, C)),
                              (_.next_out = D),
                              (_.avail_out = X - D),
                              D && l.arraySet(_.output, _.output, C, D, 0),
                              this.onData(L))
                            : this.onData(l.shrinkBuf(_.output, _.next_out)))),
                        _.avail_in === 0 && _.avail_out === 0 && (E = !0));
                    } while (
                      (0 < _.avail_in || _.avail_out === 0) &&
                      v !== i.Z_STREAM_END
                    );
                    return (
                      v === i.Z_STREAM_END && (b = i.Z_FINISH),
                      b === i.Z_FINISH
                        ? ((v = s.inflateEnd(this.strm)),
                          this.onEnd(v),
                          (this.ended = !0),
                          v === i.Z_OK)
                        : b !== i.Z_SYNC_FLUSH ||
                          (this.onEnd(i.Z_OK), !(_.avail_out = 0))
                    );
                  }),
                    (d.prototype.onData = function (h) {
                      this.chunks.push(h);
                    }),
                    (d.prototype.onEnd = function (h) {
                      (h === i.Z_OK &&
                        (this.options.to === "string"
                          ? (this.result = this.chunks.join(""))
                          : (this.result = l.flattenChunks(this.chunks))),
                        (this.chunks = []),
                        (this.err = h),
                        (this.msg = this.strm.msg));
                    }),
                    (n.Inflate = d),
                    (n.inflate = m),
                    (n.inflateRaw = function (h, y) {
                      return (((y = y || {}).raw = !0), m(h, y));
                    }),
                    (n.ungzip = m));
                },
                {
                  "./utils/common": 41,
                  "./utils/strings": 42,
                  "./zlib/constants": 44,
                  "./zlib/gzheader": 47,
                  "./zlib/inflate": 49,
                  "./zlib/messages": 51,
                  "./zlib/zstream": 53,
                },
              ],
              41: [
                function (t, o, n) {
                  var s =
                    typeof Uint8Array < "u" &&
                    typeof Uint16Array < "u" &&
                    typeof Int32Array < "u";
                  ((n.assign = function (i) {
                    for (
                      var a = Array.prototype.slice.call(arguments, 1);
                      a.length;
                    ) {
                      var r = a.shift();
                      if (r) {
                        if (typeof r != "object")
                          throw new TypeError(r + "must be non-object");
                        for (var u in r) r.hasOwnProperty(u) && (i[u] = r[u]);
                      }
                    }
                    return i;
                  }),
                    (n.shrinkBuf = function (i, a) {
                      return i.length === a
                        ? i
                        : i.subarray
                          ? i.subarray(0, a)
                          : ((i.length = a), i);
                    }));
                  var l = {
                      arraySet: function (i, a, r, u, g) {
                        if (a.subarray && i.subarray)
                          i.set(a.subarray(r, r + u), g);
                        else for (var d = 0; d < u; d++) i[g + d] = a[r + d];
                      },
                      flattenChunks: function (i) {
                        var a, r, u, g, d, m;
                        for (a = u = 0, r = i.length; a < r; a++)
                          u += i[a].length;
                        for (
                          m = new Uint8Array(u), a = g = 0, r = i.length;
                          a < r;
                          a++
                        )
                          ((d = i[a]), m.set(d, g), (g += d.length));
                        return m;
                      },
                    },
                    c = {
                      arraySet: function (i, a, r, u, g) {
                        for (var d = 0; d < u; d++) i[g + d] = a[r + d];
                      },
                      flattenChunks: function (i) {
                        return [].concat.apply([], i);
                      },
                    };
                  ((n.setTyped = function (i) {
                    i
                      ? ((n.Buf8 = Uint8Array),
                        (n.Buf16 = Uint16Array),
                        (n.Buf32 = Int32Array),
                        n.assign(n, l))
                      : ((n.Buf8 = Array),
                        (n.Buf16 = Array),
                        (n.Buf32 = Array),
                        n.assign(n, c));
                  }),
                    n.setTyped(s));
                },
                {},
              ],
              42: [
                function (t, o, n) {
                  var s = t("./common"),
                    l = !0,
                    c = !0;
                  try {
                    String.fromCharCode.apply(null, [0]);
                  } catch {
                    l = !1;
                  }
                  try {
                    String.fromCharCode.apply(null, new Uint8Array(1));
                  } catch {
                    c = !1;
                  }
                  for (var i = new s.Buf8(256), a = 0; a < 256; a++)
                    i[a] =
                      252 <= a
                        ? 6
                        : 248 <= a
                          ? 5
                          : 240 <= a
                            ? 4
                            : 224 <= a
                              ? 3
                              : 192 <= a
                                ? 2
                                : 1;
                  function r(u, g) {
                    if (g < 65537 && ((u.subarray && c) || (!u.subarray && l)))
                      return String.fromCharCode.apply(null, s.shrinkBuf(u, g));
                    for (var d = "", m = 0; m < g; m++)
                      d += String.fromCharCode(u[m]);
                    return d;
                  }
                  ((i[254] = i[254] = 1),
                    (n.string2buf = function (u) {
                      var g,
                        d,
                        m,
                        h,
                        y,
                        v = u.length,
                        b = 0;
                      for (h = 0; h < v; h++)
                        ((64512 & (d = u.charCodeAt(h))) == 55296 &&
                          h + 1 < v &&
                          (64512 & (m = u.charCodeAt(h + 1))) == 56320 &&
                          ((d = 65536 + ((d - 55296) << 10) + (m - 56320)),
                          h++),
                          (b +=
                            d < 128 ? 1 : d < 2048 ? 2 : d < 65536 ? 3 : 4));
                      for (g = new s.Buf8(b), h = y = 0; y < b; h++)
                        ((64512 & (d = u.charCodeAt(h))) == 55296 &&
                          h + 1 < v &&
                          (64512 & (m = u.charCodeAt(h + 1))) == 56320 &&
                          ((d = 65536 + ((d - 55296) << 10) + (m - 56320)),
                          h++),
                          d < 128
                            ? (g[y++] = d)
                            : (d < 2048
                                ? (g[y++] = 192 | (d >>> 6))
                                : (d < 65536
                                    ? (g[y++] = 224 | (d >>> 12))
                                    : ((g[y++] = 240 | (d >>> 18)),
                                      (g[y++] = 128 | ((d >>> 12) & 63))),
                                  (g[y++] = 128 | ((d >>> 6) & 63))),
                              (g[y++] = 128 | (63 & d))));
                      return g;
                    }),
                    (n.buf2binstring = function (u) {
                      return r(u, u.length);
                    }),
                    (n.binstring2buf = function (u) {
                      for (
                        var g = new s.Buf8(u.length), d = 0, m = g.length;
                        d < m;
                        d++
                      )
                        g[d] = u.charCodeAt(d);
                      return g;
                    }),
                    (n.buf2string = function (u, g) {
                      var d,
                        m,
                        h,
                        y,
                        v = g || u.length,
                        b = new Array(2 * v);
                      for (d = m = 0; d < v;)
                        if ((h = u[d++]) < 128) b[m++] = h;
                        else if (4 < (y = i[h]))
                          ((b[m++] = 65533), (d += y - 1));
                        else {
                          for (
                            h &= y === 2 ? 31 : y === 3 ? 15 : 7;
                            1 < y && d < v;
                          )
                            ((h = (h << 6) | (63 & u[d++])), y--);
                          1 < y
                            ? (b[m++] = 65533)
                            : h < 65536
                              ? (b[m++] = h)
                              : ((h -= 65536),
                                (b[m++] = 55296 | ((h >> 10) & 1023)),
                                (b[m++] = 56320 | (1023 & h)));
                        }
                      return r(b, m);
                    }),
                    (n.utf8border = function (u, g) {
                      var d;
                      for (
                        (g = g || u.length) > u.length && (g = u.length),
                          d = g - 1;
                        0 <= d && (192 & u[d]) == 128;
                      )
                        d--;
                      return d < 0 || d === 0 ? g : d + i[u[d]] > g ? d : g;
                    }));
                },
                { "./common": 41 },
              ],
              43: [
                function (t, o, n) {
                  o.exports = function (s, l, c, i) {
                    for (
                      var a = (65535 & s) | 0,
                        r = ((s >>> 16) & 65535) | 0,
                        u = 0;
                      c !== 0;
                    ) {
                      for (
                        c -= u = 2e3 < c ? 2e3 : c;
                        (r = (r + (a = (a + l[i++]) | 0)) | 0), --u;
                      );
                      ((a %= 65521), (r %= 65521));
                    }
                    return a | (r << 16) | 0;
                  };
                },
                {},
              ],
              44: [
                function (t, o, n) {
                  o.exports = {
                    Z_NO_FLUSH: 0,
                    Z_PARTIAL_FLUSH: 1,
                    Z_SYNC_FLUSH: 2,
                    Z_FULL_FLUSH: 3,
                    Z_FINISH: 4,
                    Z_BLOCK: 5,
                    Z_TREES: 6,
                    Z_OK: 0,
                    Z_STREAM_END: 1,
                    Z_NEED_DICT: 2,
                    Z_ERRNO: -1,
                    Z_STREAM_ERROR: -2,
                    Z_DATA_ERROR: -3,
                    Z_BUF_ERROR: -5,
                    Z_NO_COMPRESSION: 0,
                    Z_BEST_SPEED: 1,
                    Z_BEST_COMPRESSION: 9,
                    Z_DEFAULT_COMPRESSION: -1,
                    Z_FILTERED: 1,
                    Z_HUFFMAN_ONLY: 2,
                    Z_RLE: 3,
                    Z_FIXED: 4,
                    Z_DEFAULT_STRATEGY: 0,
                    Z_BINARY: 0,
                    Z_TEXT: 1,
                    Z_UNKNOWN: 2,
                    Z_DEFLATED: 8,
                  };
                },
                {},
              ],
              45: [
                function (t, o, n) {
                  var s = (function () {
                    for (var l, c = [], i = 0; i < 256; i++) {
                      l = i;
                      for (var a = 0; a < 8; a++)
                        l = 1 & l ? 3988292384 ^ (l >>> 1) : l >>> 1;
                      c[i] = l;
                    }
                    return c;
                  })();
                  o.exports = function (l, c, i, a) {
                    var r = s,
                      u = a + i;
                    l ^= -1;
                    for (var g = a; g < u; g++)
                      l = (l >>> 8) ^ r[255 & (l ^ c[g])];
                    return -1 ^ l;
                  };
                },
                {},
              ],
              46: [
                function (t, o, n) {
                  var s,
                    l = t("../utils/common"),
                    c = t("./trees"),
                    i = t("./adler32"),
                    a = t("./crc32"),
                    r = t("./messages"),
                    u = 0,
                    g = 4,
                    d = 0,
                    m = -2,
                    h = -1,
                    y = 4,
                    v = 2,
                    b = 8,
                    C = 9,
                    D = 286,
                    L = 30,
                    M = 19,
                    _ = 2 * D + 1,
                    X = 15,
                    P = 3,
                    E = 258,
                    J = E + P + 1,
                    B = 42,
                    S = 113,
                    p = 1,
                    T = 2,
                    Z = 3,
                    U = 4;
                  function ae(f, z) {
                    return ((f.msg = r[z]), z);
                  }
                  function Q(f) {
                    return (f << 1) - (4 < f ? 9 : 0);
                  }
                  function $(f) {
                    for (var z = f.length; 0 <= --z;) f[z] = 0;
                  }
                  function F(f) {
                    var z = f.state,
                      I = z.pending;
                    (I > f.avail_out && (I = f.avail_out),
                      I !== 0 &&
                        (l.arraySet(
                          f.output,
                          z.pending_buf,
                          z.pending_out,
                          I,
                          f.next_out,
                        ),
                        (f.next_out += I),
                        (z.pending_out += I),
                        (f.total_out += I),
                        (f.avail_out -= I),
                        (z.pending -= I),
                        z.pending === 0 && (z.pending_out = 0)));
                  }
                  function R(f, z) {
                    (c._tr_flush_block(
                      f,
                      0 <= f.block_start ? f.block_start : -1,
                      f.strstart - f.block_start,
                      z,
                    ),
                      (f.block_start = f.strstart),
                      F(f.strm));
                  }
                  function K(f, z) {
                    f.pending_buf[f.pending++] = z;
                  }
                  function H(f, z) {
                    ((f.pending_buf[f.pending++] = (z >>> 8) & 255),
                      (f.pending_buf[f.pending++] = 255 & z));
                  }
                  function q(f, z) {
                    var I,
                      x,
                      w = f.max_chain_length,
                      k = f.strstart,
                      G = f.prev_length,
                      O = f.nice_match,
                      N =
                        f.strstart > f.w_size - J
                          ? f.strstart - (f.w_size - J)
                          : 0,
                      V = f.window,
                      j = f.w_mask,
                      Y = f.prev,
                      ee = f.strstart + E,
                      me = V[k + G - 1],
                      pe = V[k + G];
                    (f.prev_length >= f.good_match && (w >>= 2),
                      O > f.lookahead && (O = f.lookahead));
                    do
                      if (
                        V[(I = z) + G] === pe &&
                        V[I + G - 1] === me &&
                        V[I] === V[k] &&
                        V[++I] === V[k + 1]
                      ) {
                        ((k += 2), I++);
                        do;
                        while (
                          V[++k] === V[++I] &&
                          V[++k] === V[++I] &&
                          V[++k] === V[++I] &&
                          V[++k] === V[++I] &&
                          V[++k] === V[++I] &&
                          V[++k] === V[++I] &&
                          V[++k] === V[++I] &&
                          V[++k] === V[++I] &&
                          k < ee
                        );
                        if (((x = E - (ee - k)), (k = ee - E), G < x)) {
                          if (((f.match_start = z), O <= (G = x))) break;
                          ((me = V[k + G - 1]), (pe = V[k + G]));
                        }
                      }
                    while ((z = Y[z & j]) > N && --w != 0);
                    return G <= f.lookahead ? G : f.lookahead;
                  }
                  function oe(f) {
                    var z,
                      I,
                      x,
                      w,
                      k,
                      G,
                      O,
                      N,
                      V,
                      j,
                      Y = f.w_size;
                    do {
                      if (
                        ((w = f.window_size - f.lookahead - f.strstart),
                        f.strstart >= Y + (Y - J))
                      ) {
                        for (
                          l.arraySet(f.window, f.window, Y, Y, 0),
                            f.match_start -= Y,
                            f.strstart -= Y,
                            f.block_start -= Y,
                            z = I = f.hash_size;
                          (x = f.head[--z]),
                            (f.head[z] = Y <= x ? x - Y : 0),
                            --I;
                        );
                        for (
                          z = I = Y;
                          (x = f.prev[--z]),
                            (f.prev[z] = Y <= x ? x - Y : 0),
                            --I;
                        );
                        w += Y;
                      }
                      if (f.strm.avail_in === 0) break;
                      if (
                        ((G = f.strm),
                        (O = f.window),
                        (N = f.strstart + f.lookahead),
                        (V = w),
                        (j = void 0),
                        (j = G.avail_in),
                        V < j && (j = V),
                        (I =
                          j === 0
                            ? 0
                            : ((G.avail_in -= j),
                              l.arraySet(O, G.input, G.next_in, j, N),
                              G.state.wrap === 1
                                ? (G.adler = i(G.adler, O, j, N))
                                : G.state.wrap === 2 &&
                                  (G.adler = a(G.adler, O, j, N)),
                              (G.next_in += j),
                              (G.total_in += j),
                              j)),
                        (f.lookahead += I),
                        f.lookahead + f.insert >= P)
                      )
                        for (
                          k = f.strstart - f.insert,
                            f.ins_h = f.window[k],
                            f.ins_h =
                              ((f.ins_h << f.hash_shift) ^ f.window[k + 1]) &
                              f.hash_mask;
                          f.insert &&
                          ((f.ins_h =
                            ((f.ins_h << f.hash_shift) ^ f.window[k + P - 1]) &
                            f.hash_mask),
                          (f.prev[k & f.w_mask] = f.head[f.ins_h]),
                          (f.head[f.ins_h] = k),
                          k++,
                          f.insert--,
                          !(f.lookahead + f.insert < P));
                        );
                    } while (f.lookahead < J && f.strm.avail_in !== 0);
                  }
                  function ye(f, z) {
                    for (var I, x; ;) {
                      if (f.lookahead < J) {
                        if ((oe(f), f.lookahead < J && z === u)) return p;
                        if (f.lookahead === 0) break;
                      }
                      if (
                        ((I = 0),
                        f.lookahead >= P &&
                          ((f.ins_h =
                            ((f.ins_h << f.hash_shift) ^
                              f.window[f.strstart + P - 1]) &
                            f.hash_mask),
                          (I = f.prev[f.strstart & f.w_mask] = f.head[f.ins_h]),
                          (f.head[f.ins_h] = f.strstart)),
                        I !== 0 &&
                          f.strstart - I <= f.w_size - J &&
                          (f.match_length = q(f, I)),
                        f.match_length >= P)
                      )
                        if (
                          ((x = c._tr_tally(
                            f,
                            f.strstart - f.match_start,
                            f.match_length - P,
                          )),
                          (f.lookahead -= f.match_length),
                          f.match_length <= f.max_lazy_match &&
                            f.lookahead >= P)
                        ) {
                          for (
                            f.match_length--;
                            f.strstart++,
                              (f.ins_h =
                                ((f.ins_h << f.hash_shift) ^
                                  f.window[f.strstart + P - 1]) &
                                f.hash_mask),
                              (I = f.prev[f.strstart & f.w_mask] =
                                f.head[f.ins_h]),
                              (f.head[f.ins_h] = f.strstart),
                              --f.match_length != 0;
                          );
                          f.strstart++;
                        } else
                          ((f.strstart += f.match_length),
                            (f.match_length = 0),
                            (f.ins_h = f.window[f.strstart]),
                            (f.ins_h =
                              ((f.ins_h << f.hash_shift) ^
                                f.window[f.strstart + 1]) &
                              f.hash_mask));
                      else
                        ((x = c._tr_tally(f, 0, f.window[f.strstart])),
                          f.lookahead--,
                          f.strstart++);
                      if (x && (R(f, !1), f.strm.avail_out === 0)) return p;
                    }
                    return (
                      (f.insert = f.strstart < P - 1 ? f.strstart : P - 1),
                      z === g
                        ? (R(f, !0), f.strm.avail_out === 0 ? Z : U)
                        : f.last_lit && (R(f, !1), f.strm.avail_out === 0)
                          ? p
                          : T
                    );
                  }
                  function ce(f, z) {
                    for (var I, x, w; ;) {
                      if (f.lookahead < J) {
                        if ((oe(f), f.lookahead < J && z === u)) return p;
                        if (f.lookahead === 0) break;
                      }
                      if (
                        ((I = 0),
                        f.lookahead >= P &&
                          ((f.ins_h =
                            ((f.ins_h << f.hash_shift) ^
                              f.window[f.strstart + P - 1]) &
                            f.hash_mask),
                          (I = f.prev[f.strstart & f.w_mask] = f.head[f.ins_h]),
                          (f.head[f.ins_h] = f.strstart)),
                        (f.prev_length = f.match_length),
                        (f.prev_match = f.match_start),
                        (f.match_length = P - 1),
                        I !== 0 &&
                          f.prev_length < f.max_lazy_match &&
                          f.strstart - I <= f.w_size - J &&
                          ((f.match_length = q(f, I)),
                          f.match_length <= 5 &&
                            (f.strategy === 1 ||
                              (f.match_length === P &&
                                4096 < f.strstart - f.match_start)) &&
                            (f.match_length = P - 1)),
                        f.prev_length >= P && f.match_length <= f.prev_length)
                      ) {
                        for (
                          w = f.strstart + f.lookahead - P,
                            x = c._tr_tally(
                              f,
                              f.strstart - 1 - f.prev_match,
                              f.prev_length - P,
                            ),
                            f.lookahead -= f.prev_length - 1,
                            f.prev_length -= 2;
                          ++f.strstart <= w &&
                            ((f.ins_h =
                              ((f.ins_h << f.hash_shift) ^
                                f.window[f.strstart + P - 1]) &
                              f.hash_mask),
                            (I = f.prev[f.strstart & f.w_mask] =
                              f.head[f.ins_h]),
                            (f.head[f.ins_h] = f.strstart)),
                            --f.prev_length != 0;
                        );
                        if (
                          ((f.match_available = 0),
                          (f.match_length = P - 1),
                          f.strstart++,
                          x && (R(f, !1), f.strm.avail_out === 0))
                        )
                          return p;
                      } else if (f.match_available) {
                        if (
                          ((x = c._tr_tally(f, 0, f.window[f.strstart - 1])) &&
                            R(f, !1),
                          f.strstart++,
                          f.lookahead--,
                          f.strm.avail_out === 0)
                        )
                          return p;
                      } else
                        ((f.match_available = 1), f.strstart++, f.lookahead--);
                    }
                    return (
                      f.match_available &&
                        ((x = c._tr_tally(f, 0, f.window[f.strstart - 1])),
                        (f.match_available = 0)),
                      (f.insert = f.strstart < P - 1 ? f.strstart : P - 1),
                      z === g
                        ? (R(f, !0), f.strm.avail_out === 0 ? Z : U)
                        : f.last_lit && (R(f, !1), f.strm.avail_out === 0)
                          ? p
                          : T
                    );
                  }
                  function de(f, z, I, x, w) {
                    ((this.good_length = f),
                      (this.max_lazy = z),
                      (this.nice_length = I),
                      (this.max_chain = x),
                      (this.func = w));
                  }
                  function ve() {
                    ((this.strm = null),
                      (this.status = 0),
                      (this.pending_buf = null),
                      (this.pending_buf_size = 0),
                      (this.pending_out = 0),
                      (this.pending = 0),
                      (this.wrap = 0),
                      (this.gzhead = null),
                      (this.gzindex = 0),
                      (this.method = b),
                      (this.last_flush = -1),
                      (this.w_size = 0),
                      (this.w_bits = 0),
                      (this.w_mask = 0),
                      (this.window = null),
                      (this.window_size = 0),
                      (this.prev = null),
                      (this.head = null),
                      (this.ins_h = 0),
                      (this.hash_size = 0),
                      (this.hash_bits = 0),
                      (this.hash_mask = 0),
                      (this.hash_shift = 0),
                      (this.block_start = 0),
                      (this.match_length = 0),
                      (this.prev_match = 0),
                      (this.match_available = 0),
                      (this.strstart = 0),
                      (this.match_start = 0),
                      (this.lookahead = 0),
                      (this.prev_length = 0),
                      (this.max_chain_length = 0),
                      (this.max_lazy_match = 0),
                      (this.level = 0),
                      (this.strategy = 0),
                      (this.good_match = 0),
                      (this.nice_match = 0),
                      (this.dyn_ltree = new l.Buf16(2 * _)),
                      (this.dyn_dtree = new l.Buf16(2 * (2 * L + 1))),
                      (this.bl_tree = new l.Buf16(2 * (2 * M + 1))),
                      $(this.dyn_ltree),
                      $(this.dyn_dtree),
                      $(this.bl_tree),
                      (this.l_desc = null),
                      (this.d_desc = null),
                      (this.bl_desc = null),
                      (this.bl_count = new l.Buf16(X + 1)),
                      (this.heap = new l.Buf16(2 * D + 1)),
                      $(this.heap),
                      (this.heap_len = 0),
                      (this.heap_max = 0),
                      (this.depth = new l.Buf16(2 * D + 1)),
                      $(this.depth),
                      (this.l_buf = 0),
                      (this.lit_bufsize = 0),
                      (this.last_lit = 0),
                      (this.d_buf = 0),
                      (this.opt_len = 0),
                      (this.static_len = 0),
                      (this.matches = 0),
                      (this.insert = 0),
                      (this.bi_buf = 0),
                      (this.bi_valid = 0));
                  }
                  function se(f) {
                    var z;
                    return f && f.state
                      ? ((f.total_in = f.total_out = 0),
                        (f.data_type = v),
                        ((z = f.state).pending = 0),
                        (z.pending_out = 0),
                        z.wrap < 0 && (z.wrap = -z.wrap),
                        (z.status = z.wrap ? B : S),
                        (f.adler = z.wrap === 2 ? 0 : 1),
                        (z.last_flush = u),
                        c._tr_init(z),
                        d)
                      : ae(f, m);
                  }
                  function we(f) {
                    var z = se(f);
                    return (
                      z === d &&
                        (function (I) {
                          ((I.window_size = 2 * I.w_size),
                            $(I.head),
                            (I.max_lazy_match = s[I.level].max_lazy),
                            (I.good_match = s[I.level].good_length),
                            (I.nice_match = s[I.level].nice_length),
                            (I.max_chain_length = s[I.level].max_chain),
                            (I.strstart = 0),
                            (I.block_start = 0),
                            (I.lookahead = 0),
                            (I.insert = 0),
                            (I.match_length = I.prev_length = P - 1),
                            (I.match_available = 0),
                            (I.ins_h = 0));
                        })(f.state),
                      z
                    );
                  }
                  function ue(f, z, I, x, w, k) {
                    if (!f) return m;
                    var G = 1;
                    if (
                      (z === h && (z = 6),
                      x < 0
                        ? ((G = 0), (x = -x))
                        : 15 < x && ((G = 2), (x -= 16)),
                      w < 1 ||
                        C < w ||
                        I !== b ||
                        x < 8 ||
                        15 < x ||
                        z < 0 ||
                        9 < z ||
                        k < 0 ||
                        y < k)
                    )
                      return ae(f, m);
                    x === 8 && (x = 9);
                    var O = new ve();
                    return (
                      ((f.state = O).strm = f),
                      (O.wrap = G),
                      (O.gzhead = null),
                      (O.w_bits = x),
                      (O.w_size = 1 << O.w_bits),
                      (O.w_mask = O.w_size - 1),
                      (O.hash_bits = w + 7),
                      (O.hash_size = 1 << O.hash_bits),
                      (O.hash_mask = O.hash_size - 1),
                      (O.hash_shift = ~~((O.hash_bits + P - 1) / P)),
                      (O.window = new l.Buf8(2 * O.w_size)),
                      (O.head = new l.Buf16(O.hash_size)),
                      (O.prev = new l.Buf16(O.w_size)),
                      (O.lit_bufsize = 1 << (w + 6)),
                      (O.pending_buf_size = 4 * O.lit_bufsize),
                      (O.pending_buf = new l.Buf8(O.pending_buf_size)),
                      (O.d_buf = 1 * O.lit_bufsize),
                      (O.l_buf = 3 * O.lit_bufsize),
                      (O.level = z),
                      (O.strategy = k),
                      (O.method = I),
                      we(f)
                    );
                  }
                  ((s = [
                    new de(0, 0, 0, 0, function (f, z) {
                      var I = 65535;
                      for (
                        I > f.pending_buf_size - 5 &&
                        (I = f.pending_buf_size - 5);
                        ;
                      ) {
                        if (f.lookahead <= 1) {
                          if ((oe(f), f.lookahead === 0 && z === u)) return p;
                          if (f.lookahead === 0) break;
                        }
                        ((f.strstart += f.lookahead), (f.lookahead = 0));
                        var x = f.block_start + I;
                        if (
                          ((f.strstart === 0 || f.strstart >= x) &&
                            ((f.lookahead = f.strstart - x),
                            (f.strstart = x),
                            R(f, !1),
                            f.strm.avail_out === 0)) ||
                          (f.strstart - f.block_start >= f.w_size - J &&
                            (R(f, !1), f.strm.avail_out === 0))
                        )
                          return p;
                      }
                      return (
                        (f.insert = 0),
                        z === g
                          ? (R(f, !0), f.strm.avail_out === 0 ? Z : U)
                          : (f.strstart > f.block_start &&
                              (R(f, !1), f.strm.avail_out),
                            p)
                      );
                    }),
                    new de(4, 4, 8, 4, ye),
                    new de(4, 5, 16, 8, ye),
                    new de(4, 6, 32, 32, ye),
                    new de(4, 4, 16, 16, ce),
                    new de(8, 16, 32, 32, ce),
                    new de(8, 16, 128, 128, ce),
                    new de(8, 32, 128, 256, ce),
                    new de(32, 128, 258, 1024, ce),
                    new de(32, 258, 258, 4096, ce),
                  ]),
                    (n.deflateInit = function (f, z) {
                      return ue(f, z, b, 15, 8, 0);
                    }),
                    (n.deflateInit2 = ue),
                    (n.deflateReset = we),
                    (n.deflateResetKeep = se),
                    (n.deflateSetHeader = function (f, z) {
                      return f && f.state
                        ? f.state.wrap !== 2
                          ? m
                          : ((f.state.gzhead = z), d)
                        : m;
                    }),
                    (n.deflate = function (f, z) {
                      var I, x, w, k;
                      if (!f || !f.state || 5 < z || z < 0)
                        return f ? ae(f, m) : m;
                      if (
                        ((x = f.state),
                        !f.output ||
                          (!f.input && f.avail_in !== 0) ||
                          (x.status === 666 && z !== g))
                      )
                        return ae(f, f.avail_out === 0 ? -5 : m);
                      if (
                        ((x.strm = f),
                        (I = x.last_flush),
                        (x.last_flush = z),
                        x.status === B)
                      )
                        if (x.wrap === 2)
                          ((f.adler = 0),
                            K(x, 31),
                            K(x, 139),
                            K(x, 8),
                            x.gzhead
                              ? (K(
                                  x,
                                  (x.gzhead.text ? 1 : 0) +
                                    (x.gzhead.hcrc ? 2 : 0) +
                                    (x.gzhead.extra ? 4 : 0) +
                                    (x.gzhead.name ? 8 : 0) +
                                    (x.gzhead.comment ? 16 : 0),
                                ),
                                K(x, 255 & x.gzhead.time),
                                K(x, (x.gzhead.time >> 8) & 255),
                                K(x, (x.gzhead.time >> 16) & 255),
                                K(x, (x.gzhead.time >> 24) & 255),
                                K(
                                  x,
                                  x.level === 9
                                    ? 2
                                    : 2 <= x.strategy || x.level < 2
                                      ? 4
                                      : 0,
                                ),
                                K(x, 255 & x.gzhead.os),
                                x.gzhead.extra &&
                                  x.gzhead.extra.length &&
                                  (K(x, 255 & x.gzhead.extra.length),
                                  K(x, (x.gzhead.extra.length >> 8) & 255)),
                                x.gzhead.hcrc &&
                                  (f.adler = a(
                                    f.adler,
                                    x.pending_buf,
                                    x.pending,
                                    0,
                                  )),
                                (x.gzindex = 0),
                                (x.status = 69))
                              : (K(x, 0),
                                K(x, 0),
                                K(x, 0),
                                K(x, 0),
                                K(x, 0),
                                K(
                                  x,
                                  x.level === 9
                                    ? 2
                                    : 2 <= x.strategy || x.level < 2
                                      ? 4
                                      : 0,
                                ),
                                K(x, 3),
                                (x.status = S)));
                        else {
                          var G = (b + ((x.w_bits - 8) << 4)) << 8;
                          ((G |=
                            (2 <= x.strategy || x.level < 2
                              ? 0
                              : x.level < 6
                                ? 1
                                : x.level === 6
                                  ? 2
                                  : 3) << 6),
                            x.strstart !== 0 && (G |= 32),
                            (G += 31 - (G % 31)),
                            (x.status = S),
                            H(x, G),
                            x.strstart !== 0 &&
                              (H(x, f.adler >>> 16), H(x, 65535 & f.adler)),
                            (f.adler = 1));
                        }
                      if (x.status === 69)
                        if (x.gzhead.extra) {
                          for (
                            w = x.pending;
                            x.gzindex < (65535 & x.gzhead.extra.length) &&
                            (x.pending !== x.pending_buf_size ||
                              (x.gzhead.hcrc &&
                                x.pending > w &&
                                (f.adler = a(
                                  f.adler,
                                  x.pending_buf,
                                  x.pending - w,
                                  w,
                                )),
                              F(f),
                              (w = x.pending),
                              x.pending !== x.pending_buf_size));
                          )
                            (K(x, 255 & x.gzhead.extra[x.gzindex]),
                              x.gzindex++);
                          (x.gzhead.hcrc &&
                            x.pending > w &&
                            (f.adler = a(
                              f.adler,
                              x.pending_buf,
                              x.pending - w,
                              w,
                            )),
                            x.gzindex === x.gzhead.extra.length &&
                              ((x.gzindex = 0), (x.status = 73)));
                        } else x.status = 73;
                      if (x.status === 73)
                        if (x.gzhead.name) {
                          w = x.pending;
                          do {
                            if (
                              x.pending === x.pending_buf_size &&
                              (x.gzhead.hcrc &&
                                x.pending > w &&
                                (f.adler = a(
                                  f.adler,
                                  x.pending_buf,
                                  x.pending - w,
                                  w,
                                )),
                              F(f),
                              (w = x.pending),
                              x.pending === x.pending_buf_size)
                            ) {
                              k = 1;
                              break;
                            }
                            ((k =
                              x.gzindex < x.gzhead.name.length
                                ? 255 & x.gzhead.name.charCodeAt(x.gzindex++)
                                : 0),
                              K(x, k));
                          } while (k !== 0);
                          (x.gzhead.hcrc &&
                            x.pending > w &&
                            (f.adler = a(
                              f.adler,
                              x.pending_buf,
                              x.pending - w,
                              w,
                            )),
                            k === 0 && ((x.gzindex = 0), (x.status = 91)));
                        } else x.status = 91;
                      if (x.status === 91)
                        if (x.gzhead.comment) {
                          w = x.pending;
                          do {
                            if (
                              x.pending === x.pending_buf_size &&
                              (x.gzhead.hcrc &&
                                x.pending > w &&
                                (f.adler = a(
                                  f.adler,
                                  x.pending_buf,
                                  x.pending - w,
                                  w,
                                )),
                              F(f),
                              (w = x.pending),
                              x.pending === x.pending_buf_size)
                            ) {
                              k = 1;
                              break;
                            }
                            ((k =
                              x.gzindex < x.gzhead.comment.length
                                ? 255 & x.gzhead.comment.charCodeAt(x.gzindex++)
                                : 0),
                              K(x, k));
                          } while (k !== 0);
                          (x.gzhead.hcrc &&
                            x.pending > w &&
                            (f.adler = a(
                              f.adler,
                              x.pending_buf,
                              x.pending - w,
                              w,
                            )),
                            k === 0 && (x.status = 103));
                        } else x.status = 103;
                      if (
                        (x.status === 103 &&
                          (x.gzhead.hcrc
                            ? (x.pending + 2 > x.pending_buf_size && F(f),
                              x.pending + 2 <= x.pending_buf_size &&
                                (K(x, 255 & f.adler),
                                K(x, (f.adler >> 8) & 255),
                                (f.adler = 0),
                                (x.status = S)))
                            : (x.status = S)),
                        x.pending !== 0)
                      ) {
                        if ((F(f), f.avail_out === 0))
                          return ((x.last_flush = -1), d);
                      } else if (f.avail_in === 0 && Q(z) <= Q(I) && z !== g)
                        return ae(f, -5);
                      if (x.status === 666 && f.avail_in !== 0)
                        return ae(f, -5);
                      if (
                        f.avail_in !== 0 ||
                        x.lookahead !== 0 ||
                        (z !== u && x.status !== 666)
                      ) {
                        var O =
                          x.strategy === 2
                            ? (function (N, V) {
                                for (var j; ;) {
                                  if (
                                    N.lookahead === 0 &&
                                    (oe(N), N.lookahead === 0)
                                  ) {
                                    if (V === u) return p;
                                    break;
                                  }
                                  if (
                                    ((N.match_length = 0),
                                    (j = c._tr_tally(
                                      N,
                                      0,
                                      N.window[N.strstart],
                                    )),
                                    N.lookahead--,
                                    N.strstart++,
                                    j && (R(N, !1), N.strm.avail_out === 0))
                                  )
                                    return p;
                                }
                                return (
                                  (N.insert = 0),
                                  V === g
                                    ? (R(N, !0), N.strm.avail_out === 0 ? Z : U)
                                    : N.last_lit &&
                                        (R(N, !1), N.strm.avail_out === 0)
                                      ? p
                                      : T
                                );
                              })(x, z)
                            : x.strategy === 3
                              ? (function (N, V) {
                                  for (var j, Y, ee, me, pe = N.window; ;) {
                                    if (N.lookahead <= E) {
                                      if ((oe(N), N.lookahead <= E && V === u))
                                        return p;
                                      if (N.lookahead === 0) break;
                                    }
                                    if (
                                      ((N.match_length = 0),
                                      N.lookahead >= P &&
                                        0 < N.strstart &&
                                        (Y = pe[(ee = N.strstart - 1)]) ===
                                          pe[++ee] &&
                                        Y === pe[++ee] &&
                                        Y === pe[++ee])
                                    ) {
                                      me = N.strstart + E;
                                      do;
                                      while (
                                        Y === pe[++ee] &&
                                        Y === pe[++ee] &&
                                        Y === pe[++ee] &&
                                        Y === pe[++ee] &&
                                        Y === pe[++ee] &&
                                        Y === pe[++ee] &&
                                        Y === pe[++ee] &&
                                        Y === pe[++ee] &&
                                        ee < me
                                      );
                                      ((N.match_length = E - (me - ee)),
                                        N.match_length > N.lookahead &&
                                          (N.match_length = N.lookahead));
                                    }
                                    if (
                                      (N.match_length >= P
                                        ? ((j = c._tr_tally(
                                            N,
                                            1,
                                            N.match_length - P,
                                          )),
                                          (N.lookahead -= N.match_length),
                                          (N.strstart += N.match_length),
                                          (N.match_length = 0))
                                        : ((j = c._tr_tally(
                                            N,
                                            0,
                                            N.window[N.strstart],
                                          )),
                                          N.lookahead--,
                                          N.strstart++),
                                      j && (R(N, !1), N.strm.avail_out === 0))
                                    )
                                      return p;
                                  }
                                  return (
                                    (N.insert = 0),
                                    V === g
                                      ? (R(N, !0),
                                        N.strm.avail_out === 0 ? Z : U)
                                      : N.last_lit &&
                                          (R(N, !1), N.strm.avail_out === 0)
                                        ? p
                                        : T
                                  );
                                })(x, z)
                              : s[x.level].func(x, z);
                        if (
                          ((O !== Z && O !== U) || (x.status = 666),
                          O === p || O === Z)
                        )
                          return (f.avail_out === 0 && (x.last_flush = -1), d);
                        if (
                          O === T &&
                          (z === 1
                            ? c._tr_align(x)
                            : z !== 5 &&
                              (c._tr_stored_block(x, 0, 0, !1),
                              z === 3 &&
                                ($(x.head),
                                x.lookahead === 0 &&
                                  ((x.strstart = 0),
                                  (x.block_start = 0),
                                  (x.insert = 0)))),
                          F(f),
                          f.avail_out === 0)
                        )
                          return ((x.last_flush = -1), d);
                      }
                      return z !== g
                        ? d
                        : x.wrap <= 0
                          ? 1
                          : (x.wrap === 2
                              ? (K(x, 255 & f.adler),
                                K(x, (f.adler >> 8) & 255),
                                K(x, (f.adler >> 16) & 255),
                                K(x, (f.adler >> 24) & 255),
                                K(x, 255 & f.total_in),
                                K(x, (f.total_in >> 8) & 255),
                                K(x, (f.total_in >> 16) & 255),
                                K(x, (f.total_in >> 24) & 255))
                              : (H(x, f.adler >>> 16), H(x, 65535 & f.adler)),
                            F(f),
                            0 < x.wrap && (x.wrap = -x.wrap),
                            x.pending !== 0 ? d : 1);
                    }),
                    (n.deflateEnd = function (f) {
                      var z;
                      return f && f.state
                        ? (z = f.state.status) !== B &&
                          z !== 69 &&
                          z !== 73 &&
                          z !== 91 &&
                          z !== 103 &&
                          z !== S &&
                          z !== 666
                          ? ae(f, m)
                          : ((f.state = null), z === S ? ae(f, -3) : d)
                        : m;
                    }),
                    (n.deflateSetDictionary = function (f, z) {
                      var I,
                        x,
                        w,
                        k,
                        G,
                        O,
                        N,
                        V,
                        j = z.length;
                      if (
                        !f ||
                        !f.state ||
                        (k = (I = f.state).wrap) === 2 ||
                        (k === 1 && I.status !== B) ||
                        I.lookahead
                      )
                        return m;
                      for (
                        k === 1 && (f.adler = i(f.adler, z, j, 0)),
                          I.wrap = 0,
                          j >= I.w_size &&
                            (k === 0 &&
                              ($(I.head),
                              (I.strstart = 0),
                              (I.block_start = 0),
                              (I.insert = 0)),
                            (V = new l.Buf8(I.w_size)),
                            l.arraySet(V, z, j - I.w_size, I.w_size, 0),
                            (z = V),
                            (j = I.w_size)),
                          G = f.avail_in,
                          O = f.next_in,
                          N = f.input,
                          f.avail_in = j,
                          f.next_in = 0,
                          f.input = z,
                          oe(I);
                        I.lookahead >= P;
                      ) {
                        for (
                          x = I.strstart, w = I.lookahead - (P - 1);
                          (I.ins_h =
                            ((I.ins_h << I.hash_shift) ^ I.window[x + P - 1]) &
                            I.hash_mask),
                            (I.prev[x & I.w_mask] = I.head[I.ins_h]),
                            (I.head[I.ins_h] = x),
                            x++,
                            --w;
                        );
                        ((I.strstart = x), (I.lookahead = P - 1), oe(I));
                      }
                      return (
                        (I.strstart += I.lookahead),
                        (I.block_start = I.strstart),
                        (I.insert = I.lookahead),
                        (I.lookahead = 0),
                        (I.match_length = I.prev_length = P - 1),
                        (I.match_available = 0),
                        (f.next_in = O),
                        (f.input = N),
                        (f.avail_in = G),
                        (I.wrap = k),
                        d
                      );
                    }),
                    (n.deflateInfo = "pako deflate (from Nodeca project)"));
                },
                {
                  "../utils/common": 41,
                  "./adler32": 43,
                  "./crc32": 45,
                  "./messages": 51,
                  "./trees": 52,
                },
              ],
              47: [
                function (t, o, n) {
                  o.exports = function () {
                    ((this.text = 0),
                      (this.time = 0),
                      (this.xflags = 0),
                      (this.os = 0),
                      (this.extra = null),
                      (this.extra_len = 0),
                      (this.name = ""),
                      (this.comment = ""),
                      (this.hcrc = 0),
                      (this.done = !1));
                  };
                },
                {},
              ],
              48: [
                function (t, o, n) {
                  o.exports = function (s, l) {
                    var c,
                      i,
                      a,
                      r,
                      u,
                      g,
                      d,
                      m,
                      h,
                      y,
                      v,
                      b,
                      C,
                      D,
                      L,
                      M,
                      _,
                      X,
                      P,
                      E,
                      J,
                      B,
                      S,
                      p,
                      T;
                    ((c = s.state),
                      (i = s.next_in),
                      (p = s.input),
                      (a = i + (s.avail_in - 5)),
                      (r = s.next_out),
                      (T = s.output),
                      (u = r - (l - s.avail_out)),
                      (g = r + (s.avail_out - 257)),
                      (d = c.dmax),
                      (m = c.wsize),
                      (h = c.whave),
                      (y = c.wnext),
                      (v = c.window),
                      (b = c.hold),
                      (C = c.bits),
                      (D = c.lencode),
                      (L = c.distcode),
                      (M = (1 << c.lenbits) - 1),
                      (_ = (1 << c.distbits) - 1));
                    e: do {
                      (C < 15 &&
                        ((b += p[i++] << C),
                        (C += 8),
                        (b += p[i++] << C),
                        (C += 8)),
                        (X = D[b & M]));
                      t: for (;;) {
                        if (
                          ((b >>>= P = X >>> 24),
                          (C -= P),
                          (P = (X >>> 16) & 255) === 0)
                        )
                          T[r++] = 65535 & X;
                        else {
                          if (!(16 & P)) {
                            if ((64 & P) == 0) {
                              X = D[(65535 & X) + (b & ((1 << P) - 1))];
                              continue t;
                            }
                            if (32 & P) {
                              c.mode = 12;
                              break e;
                            }
                            ((s.msg = "invalid literal/length code"),
                              (c.mode = 30));
                            break e;
                          }
                          ((E = 65535 & X),
                            (P &= 15) &&
                              (C < P && ((b += p[i++] << C), (C += 8)),
                              (E += b & ((1 << P) - 1)),
                              (b >>>= P),
                              (C -= P)),
                            C < 15 &&
                              ((b += p[i++] << C),
                              (C += 8),
                              (b += p[i++] << C),
                              (C += 8)),
                            (X = L[b & _]));
                          a: for (;;) {
                            if (
                              ((b >>>= P = X >>> 24),
                              (C -= P),
                              !(16 & (P = (X >>> 16) & 255)))
                            ) {
                              if ((64 & P) == 0) {
                                X = L[(65535 & X) + (b & ((1 << P) - 1))];
                                continue a;
                              }
                              ((s.msg = "invalid distance code"),
                                (c.mode = 30));
                              break e;
                            }
                            if (
                              ((J = 65535 & X),
                              C < (P &= 15) &&
                                ((b += p[i++] << C),
                                (C += 8) < P && ((b += p[i++] << C), (C += 8))),
                              d < (J += b & ((1 << P) - 1)))
                            ) {
                              ((s.msg = "invalid distance too far back"),
                                (c.mode = 30));
                              break e;
                            }
                            if (((b >>>= P), (C -= P), (P = r - u) < J)) {
                              if (h < (P = J - P) && c.sane) {
                                ((s.msg = "invalid distance too far back"),
                                  (c.mode = 30));
                                break e;
                              }
                              if (((S = v), (B = 0) === y)) {
                                if (((B += m - P), P < E)) {
                                  for (E -= P; (T[r++] = v[B++]), --P;);
                                  ((B = r - J), (S = T));
                                }
                              } else if (y < P) {
                                if (((B += m + y - P), (P -= y) < E)) {
                                  for (E -= P; (T[r++] = v[B++]), --P;);
                                  if (((B = 0), y < E)) {
                                    for (E -= P = y; (T[r++] = v[B++]), --P;);
                                    ((B = r - J), (S = T));
                                  }
                                }
                              } else if (((B += y - P), P < E)) {
                                for (E -= P; (T[r++] = v[B++]), --P;);
                                ((B = r - J), (S = T));
                              }
                              for (; 2 < E;)
                                ((T[r++] = S[B++]),
                                  (T[r++] = S[B++]),
                                  (T[r++] = S[B++]),
                                  (E -= 3));
                              E &&
                                ((T[r++] = S[B++]), 1 < E && (T[r++] = S[B++]));
                            } else {
                              for (
                                B = r - J;
                                (T[r++] = T[B++]),
                                  (T[r++] = T[B++]),
                                  (T[r++] = T[B++]),
                                  2 < (E -= 3);
                              );
                              E &&
                                ((T[r++] = T[B++]), 1 < E && (T[r++] = T[B++]));
                            }
                            break;
                          }
                        }
                        break;
                      }
                    } while (i < a && r < g);
                    ((i -= E = C >> 3),
                      (b &= (1 << (C -= E << 3)) - 1),
                      (s.next_in = i),
                      (s.next_out = r),
                      (s.avail_in = i < a ? a - i + 5 : 5 - (i - a)),
                      (s.avail_out = r < g ? g - r + 257 : 257 - (r - g)),
                      (c.hold = b),
                      (c.bits = C));
                  };
                },
                {},
              ],
              49: [
                function (t, o, n) {
                  var s = t("../utils/common"),
                    l = t("./adler32"),
                    c = t("./crc32"),
                    i = t("./inffast"),
                    a = t("./inftrees"),
                    r = 1,
                    u = 2,
                    g = 0,
                    d = -2,
                    m = 1,
                    h = 852,
                    y = 592;
                  function v(B) {
                    return (
                      ((B >>> 24) & 255) +
                      ((B >>> 8) & 65280) +
                      ((65280 & B) << 8) +
                      ((255 & B) << 24)
                    );
                  }
                  function b() {
                    ((this.mode = 0),
                      (this.last = !1),
                      (this.wrap = 0),
                      (this.havedict = !1),
                      (this.flags = 0),
                      (this.dmax = 0),
                      (this.check = 0),
                      (this.total = 0),
                      (this.head = null),
                      (this.wbits = 0),
                      (this.wsize = 0),
                      (this.whave = 0),
                      (this.wnext = 0),
                      (this.window = null),
                      (this.hold = 0),
                      (this.bits = 0),
                      (this.length = 0),
                      (this.offset = 0),
                      (this.extra = 0),
                      (this.lencode = null),
                      (this.distcode = null),
                      (this.lenbits = 0),
                      (this.distbits = 0),
                      (this.ncode = 0),
                      (this.nlen = 0),
                      (this.ndist = 0),
                      (this.have = 0),
                      (this.next = null),
                      (this.lens = new s.Buf16(320)),
                      (this.work = new s.Buf16(288)),
                      (this.lendyn = null),
                      (this.distdyn = null),
                      (this.sane = 0),
                      (this.back = 0),
                      (this.was = 0));
                  }
                  function C(B) {
                    var S;
                    return B && B.state
                      ? ((S = B.state),
                        (B.total_in = B.total_out = S.total = 0),
                        (B.msg = ""),
                        S.wrap && (B.adler = 1 & S.wrap),
                        (S.mode = m),
                        (S.last = 0),
                        (S.havedict = 0),
                        (S.dmax = 32768),
                        (S.head = null),
                        (S.hold = 0),
                        (S.bits = 0),
                        (S.lencode = S.lendyn = new s.Buf32(h)),
                        (S.distcode = S.distdyn = new s.Buf32(y)),
                        (S.sane = 1),
                        (S.back = -1),
                        g)
                      : d;
                  }
                  function D(B) {
                    var S;
                    return B && B.state
                      ? (((S = B.state).wsize = 0),
                        (S.whave = 0),
                        (S.wnext = 0),
                        C(B))
                      : d;
                  }
                  function L(B, S) {
                    var p, T;
                    return B && B.state
                      ? ((T = B.state),
                        S < 0
                          ? ((p = 0), (S = -S))
                          : ((p = 1 + (S >> 4)), S < 48 && (S &= 15)),
                        S && (S < 8 || 15 < S)
                          ? d
                          : (T.window !== null &&
                              T.wbits !== S &&
                              (T.window = null),
                            (T.wrap = p),
                            (T.wbits = S),
                            D(B)))
                      : d;
                  }
                  function M(B, S) {
                    var p, T;
                    return B
                      ? ((T = new b()),
                        ((B.state = T).window = null),
                        (p = L(B, S)) !== g && (B.state = null),
                        p)
                      : d;
                  }
                  var _,
                    X,
                    P = !0;
                  function E(B) {
                    if (P) {
                      var S;
                      for (
                        _ = new s.Buf32(512), X = new s.Buf32(32), S = 0;
                        S < 144;
                      )
                        B.lens[S++] = 8;
                      for (; S < 256;) B.lens[S++] = 9;
                      for (; S < 280;) B.lens[S++] = 7;
                      for (; S < 288;) B.lens[S++] = 8;
                      for (
                        a(r, B.lens, 0, 288, _, 0, B.work, { bits: 9 }), S = 0;
                        S < 32;
                      )
                        B.lens[S++] = 5;
                      (a(u, B.lens, 0, 32, X, 0, B.work, { bits: 5 }),
                        (P = !1));
                    }
                    ((B.lencode = _),
                      (B.lenbits = 9),
                      (B.distcode = X),
                      (B.distbits = 5));
                  }
                  function J(B, S, p, T) {
                    var Z,
                      U = B.state;
                    return (
                      U.window === null &&
                        ((U.wsize = 1 << U.wbits),
                        (U.wnext = 0),
                        (U.whave = 0),
                        (U.window = new s.Buf8(U.wsize))),
                      T >= U.wsize
                        ? (s.arraySet(U.window, S, p - U.wsize, U.wsize, 0),
                          (U.wnext = 0),
                          (U.whave = U.wsize))
                        : (T < (Z = U.wsize - U.wnext) && (Z = T),
                          s.arraySet(U.window, S, p - T, Z, U.wnext),
                          (T -= Z)
                            ? (s.arraySet(U.window, S, p - T, T, 0),
                              (U.wnext = T),
                              (U.whave = U.wsize))
                            : ((U.wnext += Z),
                              U.wnext === U.wsize && (U.wnext = 0),
                              U.whave < U.wsize && (U.whave += Z))),
                      0
                    );
                  }
                  ((n.inflateReset = D),
                    (n.inflateReset2 = L),
                    (n.inflateResetKeep = C),
                    (n.inflateInit = function (B) {
                      return M(B, 15);
                    }),
                    (n.inflateInit2 = M),
                    (n.inflate = function (B, S) {
                      var p,
                        T,
                        Z,
                        U,
                        ae,
                        Q,
                        $,
                        F,
                        R,
                        K,
                        H,
                        q,
                        oe,
                        ye,
                        ce,
                        de,
                        ve,
                        se,
                        we,
                        ue,
                        f,
                        z,
                        I,
                        x,
                        w = 0,
                        k = new s.Buf8(4),
                        G = [
                          16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2,
                          14, 1, 15,
                        ];
                      if (
                        !B ||
                        !B.state ||
                        !B.output ||
                        (!B.input && B.avail_in !== 0)
                      )
                        return d;
                      ((p = B.state).mode === 12 && (p.mode = 13),
                        (ae = B.next_out),
                        (Z = B.output),
                        ($ = B.avail_out),
                        (U = B.next_in),
                        (T = B.input),
                        (Q = B.avail_in),
                        (F = p.hold),
                        (R = p.bits),
                        (K = Q),
                        (H = $),
                        (z = g));
                      e: for (;;)
                        switch (p.mode) {
                          case m:
                            if (p.wrap === 0) {
                              p.mode = 13;
                              break;
                            }
                            for (; R < 16;) {
                              if (Q === 0) break e;
                              (Q--, (F += T[U++] << R), (R += 8));
                            }
                            if (2 & p.wrap && F === 35615) {
                              ((k[(p.check = 0)] = 255 & F),
                                (k[1] = (F >>> 8) & 255),
                                (p.check = c(p.check, k, 2, 0)),
                                (R = F = 0),
                                (p.mode = 2));
                              break;
                            }
                            if (
                              ((p.flags = 0),
                              p.head && (p.head.done = !1),
                              !(1 & p.wrap) ||
                                (((255 & F) << 8) + (F >> 8)) % 31)
                            ) {
                              ((B.msg = "incorrect header check"),
                                (p.mode = 30));
                              break;
                            }
                            if ((15 & F) != 8) {
                              ((B.msg = "unknown compression method"),
                                (p.mode = 30));
                              break;
                            }
                            if (
                              ((R -= 4),
                              (f = 8 + (15 & (F >>>= 4))),
                              p.wbits === 0)
                            )
                              p.wbits = f;
                            else if (f > p.wbits) {
                              ((B.msg = "invalid window size"), (p.mode = 30));
                              break;
                            }
                            ((p.dmax = 1 << f),
                              (B.adler = p.check = 1),
                              (p.mode = 512 & F ? 10 : 12),
                              (R = F = 0));
                            break;
                          case 2:
                            for (; R < 16;) {
                              if (Q === 0) break e;
                              (Q--, (F += T[U++] << R), (R += 8));
                            }
                            if (((p.flags = F), (255 & p.flags) != 8)) {
                              ((B.msg = "unknown compression method"),
                                (p.mode = 30));
                              break;
                            }
                            if (57344 & p.flags) {
                              ((B.msg = "unknown header flags set"),
                                (p.mode = 30));
                              break;
                            }
                            (p.head && (p.head.text = (F >> 8) & 1),
                              512 & p.flags &&
                                ((k[0] = 255 & F),
                                (k[1] = (F >>> 8) & 255),
                                (p.check = c(p.check, k, 2, 0))),
                              (R = F = 0),
                              (p.mode = 3));
                          case 3:
                            for (; R < 32;) {
                              if (Q === 0) break e;
                              (Q--, (F += T[U++] << R), (R += 8));
                            }
                            (p.head && (p.head.time = F),
                              512 & p.flags &&
                                ((k[0] = 255 & F),
                                (k[1] = (F >>> 8) & 255),
                                (k[2] = (F >>> 16) & 255),
                                (k[3] = (F >>> 24) & 255),
                                (p.check = c(p.check, k, 4, 0))),
                              (R = F = 0),
                              (p.mode = 4));
                          case 4:
                            for (; R < 16;) {
                              if (Q === 0) break e;
                              (Q--, (F += T[U++] << R), (R += 8));
                            }
                            (p.head &&
                              ((p.head.xflags = 255 & F), (p.head.os = F >> 8)),
                              512 & p.flags &&
                                ((k[0] = 255 & F),
                                (k[1] = (F >>> 8) & 255),
                                (p.check = c(p.check, k, 2, 0))),
                              (R = F = 0),
                              (p.mode = 5));
                          case 5:
                            if (1024 & p.flags) {
                              for (; R < 16;) {
                                if (Q === 0) break e;
                                (Q--, (F += T[U++] << R), (R += 8));
                              }
                              ((p.length = F),
                                p.head && (p.head.extra_len = F),
                                512 & p.flags &&
                                  ((k[0] = 255 & F),
                                  (k[1] = (F >>> 8) & 255),
                                  (p.check = c(p.check, k, 2, 0))),
                                (R = F = 0));
                            } else p.head && (p.head.extra = null);
                            p.mode = 6;
                          case 6:
                            if (
                              1024 & p.flags &&
                              (Q < (q = p.length) && (q = Q),
                              q &&
                                (p.head &&
                                  ((f = p.head.extra_len - p.length),
                                  p.head.extra ||
                                    (p.head.extra = new Array(
                                      p.head.extra_len,
                                    )),
                                  s.arraySet(p.head.extra, T, U, q, f)),
                                512 & p.flags &&
                                  (p.check = c(p.check, T, q, U)),
                                (Q -= q),
                                (U += q),
                                (p.length -= q)),
                              p.length)
                            )
                              break e;
                            ((p.length = 0), (p.mode = 7));
                          case 7:
                            if (2048 & p.flags) {
                              if (Q === 0) break e;
                              for (
                                q = 0;
                                (f = T[U + q++]),
                                  p.head &&
                                    f &&
                                    p.length < 65536 &&
                                    (p.head.name += String.fromCharCode(f)),
                                  f && q < Q;
                              );
                              if (
                                (512 & p.flags &&
                                  (p.check = c(p.check, T, q, U)),
                                (Q -= q),
                                (U += q),
                                f)
                              )
                                break e;
                            } else p.head && (p.head.name = null);
                            ((p.length = 0), (p.mode = 8));
                          case 8:
                            if (4096 & p.flags) {
                              if (Q === 0) break e;
                              for (
                                q = 0;
                                (f = T[U + q++]),
                                  p.head &&
                                    f &&
                                    p.length < 65536 &&
                                    (p.head.comment += String.fromCharCode(f)),
                                  f && q < Q;
                              );
                              if (
                                (512 & p.flags &&
                                  (p.check = c(p.check, T, q, U)),
                                (Q -= q),
                                (U += q),
                                f)
                              )
                                break e;
                            } else p.head && (p.head.comment = null);
                            p.mode = 9;
                          case 9:
                            if (512 & p.flags) {
                              for (; R < 16;) {
                                if (Q === 0) break e;
                                (Q--, (F += T[U++] << R), (R += 8));
                              }
                              if (F !== (65535 & p.check)) {
                                ((B.msg = "header crc mismatch"),
                                  (p.mode = 30));
                                break;
                              }
                              R = F = 0;
                            }
                            (p.head &&
                              ((p.head.hcrc = (p.flags >> 9) & 1),
                              (p.head.done = !0)),
                              (B.adler = p.check = 0),
                              (p.mode = 12));
                            break;
                          case 10:
                            for (; R < 32;) {
                              if (Q === 0) break e;
                              (Q--, (F += T[U++] << R), (R += 8));
                            }
                            ((B.adler = p.check = v(F)),
                              (R = F = 0),
                              (p.mode = 11));
                          case 11:
                            if (p.havedict === 0)
                              return (
                                (B.next_out = ae),
                                (B.avail_out = $),
                                (B.next_in = U),
                                (B.avail_in = Q),
                                (p.hold = F),
                                (p.bits = R),
                                2
                              );
                            ((B.adler = p.check = 1), (p.mode = 12));
                          case 12:
                            if (S === 5 || S === 6) break e;
                          case 13:
                            if (p.last) {
                              ((F >>>= 7 & R), (R -= 7 & R), (p.mode = 27));
                              break;
                            }
                            for (; R < 3;) {
                              if (Q === 0) break e;
                              (Q--, (F += T[U++] << R), (R += 8));
                            }
                            switch (
                              ((p.last = 1 & F), (R -= 1), 3 & (F >>>= 1))
                            ) {
                              case 0:
                                p.mode = 14;
                                break;
                              case 1:
                                if ((E(p), (p.mode = 20), S !== 6)) break;
                                ((F >>>= 2), (R -= 2));
                                break e;
                              case 2:
                                p.mode = 17;
                                break;
                              case 3:
                                ((B.msg = "invalid block type"), (p.mode = 30));
                            }
                            ((F >>>= 2), (R -= 2));
                            break;
                          case 14:
                            for (F >>>= 7 & R, R -= 7 & R; R < 32;) {
                              if (Q === 0) break e;
                              (Q--, (F += T[U++] << R), (R += 8));
                            }
                            if ((65535 & F) != ((F >>> 16) ^ 65535)) {
                              ((B.msg = "invalid stored block lengths"),
                                (p.mode = 30));
                              break;
                            }
                            if (
                              ((p.length = 65535 & F),
                              (R = F = 0),
                              (p.mode = 15),
                              S === 6)
                            )
                              break e;
                          case 15:
                            p.mode = 16;
                          case 16:
                            if ((q = p.length)) {
                              if ((Q < q && (q = Q), $ < q && (q = $), q === 0))
                                break e;
                              (s.arraySet(Z, T, U, q, ae),
                                (Q -= q),
                                (U += q),
                                ($ -= q),
                                (ae += q),
                                (p.length -= q));
                              break;
                            }
                            p.mode = 12;
                            break;
                          case 17:
                            for (; R < 14;) {
                              if (Q === 0) break e;
                              (Q--, (F += T[U++] << R), (R += 8));
                            }
                            if (
                              ((p.nlen = 257 + (31 & F)),
                              (F >>>= 5),
                              (R -= 5),
                              (p.ndist = 1 + (31 & F)),
                              (F >>>= 5),
                              (R -= 5),
                              (p.ncode = 4 + (15 & F)),
                              (F >>>= 4),
                              (R -= 4),
                              286 < p.nlen || 30 < p.ndist)
                            ) {
                              ((B.msg = "too many length or distance symbols"),
                                (p.mode = 30));
                              break;
                            }
                            ((p.have = 0), (p.mode = 18));
                          case 18:
                            for (; p.have < p.ncode;) {
                              for (; R < 3;) {
                                if (Q === 0) break e;
                                (Q--, (F += T[U++] << R), (R += 8));
                              }
                              ((p.lens[G[p.have++]] = 7 & F),
                                (F >>>= 3),
                                (R -= 3));
                            }
                            for (; p.have < 19;) p.lens[G[p.have++]] = 0;
                            if (
                              ((p.lencode = p.lendyn),
                              (p.lenbits = 7),
                              (I = { bits: p.lenbits }),
                              (z = a(
                                0,
                                p.lens,
                                0,
                                19,
                                p.lencode,
                                0,
                                p.work,
                                I,
                              )),
                              (p.lenbits = I.bits),
                              z)
                            ) {
                              ((B.msg = "invalid code lengths set"),
                                (p.mode = 30));
                              break;
                            }
                            ((p.have = 0), (p.mode = 19));
                          case 19:
                            for (; p.have < p.nlen + p.ndist;) {
                              for (
                                ;
                                (de =
                                  ((w =
                                    p.lencode[F & ((1 << p.lenbits) - 1)]) >>>
                                    16) &
                                  255),
                                  (ve = 65535 & w),
                                  !((ce = w >>> 24) <= R);
                              ) {
                                if (Q === 0) break e;
                                (Q--, (F += T[U++] << R), (R += 8));
                              }
                              if (ve < 16)
                                ((F >>>= ce),
                                  (R -= ce),
                                  (p.lens[p.have++] = ve));
                              else {
                                if (ve === 16) {
                                  for (x = ce + 2; R < x;) {
                                    if (Q === 0) break e;
                                    (Q--, (F += T[U++] << R), (R += 8));
                                  }
                                  if (((F >>>= ce), (R -= ce), p.have === 0)) {
                                    ((B.msg = "invalid bit length repeat"),
                                      (p.mode = 30));
                                    break;
                                  }
                                  ((f = p.lens[p.have - 1]),
                                    (q = 3 + (3 & F)),
                                    (F >>>= 2),
                                    (R -= 2));
                                } else if (ve === 17) {
                                  for (x = ce + 3; R < x;) {
                                    if (Q === 0) break e;
                                    (Q--, (F += T[U++] << R), (R += 8));
                                  }
                                  ((R -= ce),
                                    (f = 0),
                                    (q = 3 + (7 & (F >>>= ce))),
                                    (F >>>= 3),
                                    (R -= 3));
                                } else {
                                  for (x = ce + 7; R < x;) {
                                    if (Q === 0) break e;
                                    (Q--, (F += T[U++] << R), (R += 8));
                                  }
                                  ((R -= ce),
                                    (f = 0),
                                    (q = 11 + (127 & (F >>>= ce))),
                                    (F >>>= 7),
                                    (R -= 7));
                                }
                                if (p.have + q > p.nlen + p.ndist) {
                                  ((B.msg = "invalid bit length repeat"),
                                    (p.mode = 30));
                                  break;
                                }
                                for (; q--;) p.lens[p.have++] = f;
                              }
                            }
                            if (p.mode === 30) break;
                            if (p.lens[256] === 0) {
                              ((B.msg = "invalid code -- missing end-of-block"),
                                (p.mode = 30));
                              break;
                            }
                            if (
                              ((p.lenbits = 9),
                              (I = { bits: p.lenbits }),
                              (z = a(
                                r,
                                p.lens,
                                0,
                                p.nlen,
                                p.lencode,
                                0,
                                p.work,
                                I,
                              )),
                              (p.lenbits = I.bits),
                              z)
                            ) {
                              ((B.msg = "invalid literal/lengths set"),
                                (p.mode = 30));
                              break;
                            }
                            if (
                              ((p.distbits = 6),
                              (p.distcode = p.distdyn),
                              (I = { bits: p.distbits }),
                              (z = a(
                                u,
                                p.lens,
                                p.nlen,
                                p.ndist,
                                p.distcode,
                                0,
                                p.work,
                                I,
                              )),
                              (p.distbits = I.bits),
                              z)
                            ) {
                              ((B.msg = "invalid distances set"),
                                (p.mode = 30));
                              break;
                            }
                            if (((p.mode = 20), S === 6)) break e;
                          case 20:
                            p.mode = 21;
                          case 21:
                            if (6 <= Q && 258 <= $) {
                              ((B.next_out = ae),
                                (B.avail_out = $),
                                (B.next_in = U),
                                (B.avail_in = Q),
                                (p.hold = F),
                                (p.bits = R),
                                i(B, H),
                                (ae = B.next_out),
                                (Z = B.output),
                                ($ = B.avail_out),
                                (U = B.next_in),
                                (T = B.input),
                                (Q = B.avail_in),
                                (F = p.hold),
                                (R = p.bits),
                                p.mode === 12 && (p.back = -1));
                              break;
                            }
                            for (
                              p.back = 0;
                              (de =
                                ((w = p.lencode[F & ((1 << p.lenbits) - 1)]) >>>
                                  16) &
                                255),
                                (ve = 65535 & w),
                                !((ce = w >>> 24) <= R);
                            ) {
                              if (Q === 0) break e;
                              (Q--, (F += T[U++] << R), (R += 8));
                            }
                            if (de && (240 & de) == 0) {
                              for (
                                se = ce, we = de, ue = ve;
                                (de =
                                  ((w =
                                    p.lencode[
                                      ue + ((F & ((1 << (se + we)) - 1)) >> se)
                                    ]) >>>
                                    16) &
                                  255),
                                  (ve = 65535 & w),
                                  !(se + (ce = w >>> 24) <= R);
                              ) {
                                if (Q === 0) break e;
                                (Q--, (F += T[U++] << R), (R += 8));
                              }
                              ((F >>>= se), (R -= se), (p.back += se));
                            }
                            if (
                              ((F >>>= ce),
                              (R -= ce),
                              (p.back += ce),
                              (p.length = ve),
                              de === 0)
                            ) {
                              p.mode = 26;
                              break;
                            }
                            if (32 & de) {
                              ((p.back = -1), (p.mode = 12));
                              break;
                            }
                            if (64 & de) {
                              ((B.msg = "invalid literal/length code"),
                                (p.mode = 30));
                              break;
                            }
                            ((p.extra = 15 & de), (p.mode = 22));
                          case 22:
                            if (p.extra) {
                              for (x = p.extra; R < x;) {
                                if (Q === 0) break e;
                                (Q--, (F += T[U++] << R), (R += 8));
                              }
                              ((p.length += F & ((1 << p.extra) - 1)),
                                (F >>>= p.extra),
                                (R -= p.extra),
                                (p.back += p.extra));
                            }
                            ((p.was = p.length), (p.mode = 23));
                          case 23:
                            for (
                              ;
                              (de =
                                ((w =
                                  p.distcode[F & ((1 << p.distbits) - 1)]) >>>
                                  16) &
                                255),
                                (ve = 65535 & w),
                                !((ce = w >>> 24) <= R);
                            ) {
                              if (Q === 0) break e;
                              (Q--, (F += T[U++] << R), (R += 8));
                            }
                            if ((240 & de) == 0) {
                              for (
                                se = ce, we = de, ue = ve;
                                (de =
                                  ((w =
                                    p.distcode[
                                      ue + ((F & ((1 << (se + we)) - 1)) >> se)
                                    ]) >>>
                                    16) &
                                  255),
                                  (ve = 65535 & w),
                                  !(se + (ce = w >>> 24) <= R);
                              ) {
                                if (Q === 0) break e;
                                (Q--, (F += T[U++] << R), (R += 8));
                              }
                              ((F >>>= se), (R -= se), (p.back += se));
                            }
                            if (
                              ((F >>>= ce), (R -= ce), (p.back += ce), 64 & de)
                            ) {
                              ((B.msg = "invalid distance code"),
                                (p.mode = 30));
                              break;
                            }
                            ((p.offset = ve),
                              (p.extra = 15 & de),
                              (p.mode = 24));
                          case 24:
                            if (p.extra) {
                              for (x = p.extra; R < x;) {
                                if (Q === 0) break e;
                                (Q--, (F += T[U++] << R), (R += 8));
                              }
                              ((p.offset += F & ((1 << p.extra) - 1)),
                                (F >>>= p.extra),
                                (R -= p.extra),
                                (p.back += p.extra));
                            }
                            if (p.offset > p.dmax) {
                              ((B.msg = "invalid distance too far back"),
                                (p.mode = 30));
                              break;
                            }
                            p.mode = 25;
                          case 25:
                            if ($ === 0) break e;
                            if (((q = H - $), p.offset > q)) {
                              if ((q = p.offset - q) > p.whave && p.sane) {
                                ((B.msg = "invalid distance too far back"),
                                  (p.mode = 30));
                                break;
                              }
                              ((oe =
                                q > p.wnext
                                  ? ((q -= p.wnext), p.wsize - q)
                                  : p.wnext - q),
                                q > p.length && (q = p.length),
                                (ye = p.window));
                            } else
                              ((ye = Z), (oe = ae - p.offset), (q = p.length));
                            for (
                              $ < q && (q = $), $ -= q, p.length -= q;
                              (Z[ae++] = ye[oe++]), --q;
                            );
                            p.length === 0 && (p.mode = 21);
                            break;
                          case 26:
                            if ($ === 0) break e;
                            ((Z[ae++] = p.length), $--, (p.mode = 21));
                            break;
                          case 27:
                            if (p.wrap) {
                              for (; R < 32;) {
                                if (Q === 0) break e;
                                (Q--, (F |= T[U++] << R), (R += 8));
                              }
                              if (
                                ((H -= $),
                                (B.total_out += H),
                                (p.total += H),
                                H &&
                                  (B.adler = p.check =
                                    p.flags
                                      ? c(p.check, Z, H, ae - H)
                                      : l(p.check, Z, H, ae - H)),
                                (H = $),
                                (p.flags ? F : v(F)) !== p.check)
                              ) {
                                ((B.msg = "incorrect data check"),
                                  (p.mode = 30));
                                break;
                              }
                              R = F = 0;
                            }
                            p.mode = 28;
                          case 28:
                            if (p.wrap && p.flags) {
                              for (; R < 32;) {
                                if (Q === 0) break e;
                                (Q--, (F += T[U++] << R), (R += 8));
                              }
                              if (F !== (4294967295 & p.total)) {
                                ((B.msg = "incorrect length check"),
                                  (p.mode = 30));
                                break;
                              }
                              R = F = 0;
                            }
                            p.mode = 29;
                          case 29:
                            z = 1;
                            break e;
                          case 30:
                            z = -3;
                            break e;
                          case 31:
                            return -4;
                          case 32:
                          default:
                            return d;
                        }
                      return (
                        (B.next_out = ae),
                        (B.avail_out = $),
                        (B.next_in = U),
                        (B.avail_in = Q),
                        (p.hold = F),
                        (p.bits = R),
                        (p.wsize ||
                          (H !== B.avail_out &&
                            p.mode < 30 &&
                            (p.mode < 27 || S !== 4))) &&
                        J(B, B.output, B.next_out, H - B.avail_out)
                          ? ((p.mode = 31), -4)
                          : ((K -= B.avail_in),
                            (H -= B.avail_out),
                            (B.total_in += K),
                            (B.total_out += H),
                            (p.total += H),
                            p.wrap &&
                              H &&
                              (B.adler = p.check =
                                p.flags
                                  ? c(p.check, Z, H, B.next_out - H)
                                  : l(p.check, Z, H, B.next_out - H)),
                            (B.data_type =
                              p.bits +
                              (p.last ? 64 : 0) +
                              (p.mode === 12 ? 128 : 0) +
                              (p.mode === 20 || p.mode === 15 ? 256 : 0)),
                            ((K == 0 && H === 0) || S === 4) &&
                              z === g &&
                              (z = -5),
                            z)
                      );
                    }),
                    (n.inflateEnd = function (B) {
                      if (!B || !B.state) return d;
                      var S = B.state;
                      return (
                        S.window && (S.window = null),
                        (B.state = null),
                        g
                      );
                    }),
                    (n.inflateGetHeader = function (B, S) {
                      var p;
                      return B && B.state
                        ? (2 & (p = B.state).wrap) == 0
                          ? d
                          : (((p.head = S).done = !1), g)
                        : d;
                    }),
                    (n.inflateSetDictionary = function (B, S) {
                      var p,
                        T = S.length;
                      return B && B.state
                        ? (p = B.state).wrap !== 0 && p.mode !== 11
                          ? d
                          : p.mode === 11 && l(1, S, T, 0) !== p.check
                            ? -3
                            : J(B, S, T, T)
                              ? ((p.mode = 31), -4)
                              : ((p.havedict = 1), g)
                        : d;
                    }),
                    (n.inflateInfo = "pako inflate (from Nodeca project)"));
                },
                {
                  "../utils/common": 41,
                  "./adler32": 43,
                  "./crc32": 45,
                  "./inffast": 48,
                  "./inftrees": 50,
                },
              ],
              50: [
                function (t, o, n) {
                  var s = t("../utils/common"),
                    l = [
                      3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31,
                      35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258,
                      0, 0,
                    ],
                    c = [
                      16, 16, 16, 16, 16, 16, 16, 16, 17, 17, 17, 17, 18, 18,
                      18, 18, 19, 19, 19, 19, 20, 20, 20, 20, 21, 21, 21, 21,
                      16, 72, 78,
                    ],
                    i = [
                      1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193,
                      257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145,
                      8193, 12289, 16385, 24577, 0, 0,
                    ],
                    a = [
                      16, 16, 16, 16, 17, 17, 18, 18, 19, 19, 20, 20, 21, 21,
                      22, 22, 23, 23, 24, 24, 25, 25, 26, 26, 27, 27, 28, 28,
                      29, 29, 64, 64,
                    ];
                  o.exports = function (r, u, g, d, m, h, y, v) {
                    var b,
                      C,
                      D,
                      L,
                      M,
                      _,
                      X,
                      P,
                      E,
                      J = v.bits,
                      B = 0,
                      S = 0,
                      p = 0,
                      T = 0,
                      Z = 0,
                      U = 0,
                      ae = 0,
                      Q = 0,
                      $ = 0,
                      F = 0,
                      R = null,
                      K = 0,
                      H = new s.Buf16(16),
                      q = new s.Buf16(16),
                      oe = null,
                      ye = 0;
                    for (B = 0; B <= 15; B++) H[B] = 0;
                    for (S = 0; S < d; S++) H[u[g + S]]++;
                    for (Z = J, T = 15; 1 <= T && H[T] === 0; T--);
                    if ((T < Z && (Z = T), T === 0))
                      return (
                        (m[h++] = 20971520),
                        (m[h++] = 20971520),
                        (v.bits = 1),
                        0
                      );
                    for (p = 1; p < T && H[p] === 0; p++);
                    for (Z < p && (Z = p), B = Q = 1; B <= 15; B++)
                      if (((Q <<= 1), (Q -= H[B]) < 0)) return -1;
                    if (0 < Q && (r === 0 || T !== 1)) return -1;
                    for (q[1] = 0, B = 1; B < 15; B++) q[B + 1] = q[B] + H[B];
                    for (S = 0; S < d; S++)
                      u[g + S] !== 0 && (y[q[u[g + S]]++] = S);
                    if (
                      ((_ =
                        r === 0
                          ? ((R = oe = y), 19)
                          : r === 1
                            ? ((R = l), (K -= 257), (oe = c), (ye -= 257), 256)
                            : ((R = i), (oe = a), -1)),
                      (B = p),
                      (M = h),
                      (ae = S = F = 0),
                      (D = -1),
                      (L = ($ = 1 << (U = Z)) - 1),
                      (r === 1 && 852 < $) || (r === 2 && 592 < $))
                    )
                      return 1;
                    for (;;) {
                      for (
                        X = B - ae,
                          E =
                            y[S] < _
                              ? ((P = 0), y[S])
                              : y[S] > _
                                ? ((P = oe[ye + y[S]]), R[K + y[S]])
                                : ((P = 96), 0),
                          b = 1 << (B - ae),
                          p = C = 1 << U;
                        (m[M + (F >> ae) + (C -= b)] =
                          (X << 24) | (P << 16) | E | 0),
                          C !== 0;
                      );
                      for (b = 1 << (B - 1); F & b;) b >>= 1;
                      if (
                        (b !== 0 ? ((F &= b - 1), (F += b)) : (F = 0),
                        S++,
                        --H[B] == 0)
                      ) {
                        if (B === T) break;
                        B = u[g + y[S]];
                      }
                      if (Z < B && (F & L) !== D) {
                        for (
                          ae === 0 && (ae = Z), M += p, Q = 1 << (U = B - ae);
                          U + ae < T && !((Q -= H[U + ae]) <= 0);
                        )
                          (U++, (Q <<= 1));
                        if (
                          (($ += 1 << U),
                          (r === 1 && 852 < $) || (r === 2 && 592 < $))
                        )
                          return 1;
                        m[(D = F & L)] = (Z << 24) | (U << 16) | (M - h) | 0;
                      }
                    }
                    return (
                      F !== 0 && (m[M + F] = ((B - ae) << 24) | (64 << 16) | 0),
                      (v.bits = Z),
                      0
                    );
                  };
                },
                { "../utils/common": 41 },
              ],
              51: [
                function (t, o, n) {
                  o.exports = {
                    2: "need dictionary",
                    1: "stream end",
                    0: "",
                    "-1": "file error",
                    "-2": "stream error",
                    "-3": "data error",
                    "-4": "insufficient memory",
                    "-5": "buffer error",
                    "-6": "incompatible version",
                  };
                },
                {},
              ],
              52: [
                function (t, o, n) {
                  var s = t("../utils/common"),
                    l = 0,
                    c = 1;
                  function i(w) {
                    for (var k = w.length; 0 <= --k;) w[k] = 0;
                  }
                  var a = 0,
                    r = 29,
                    u = 256,
                    g = u + 1 + r,
                    d = 30,
                    m = 19,
                    h = 2 * g + 1,
                    y = 15,
                    v = 16,
                    b = 7,
                    C = 256,
                    D = 16,
                    L = 17,
                    M = 18,
                    _ = [
                      0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3,
                      3, 4, 4, 4, 4, 5, 5, 5, 5, 0,
                    ],
                    X = [
                      0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8,
                      8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13,
                    ],
                    P = [
                      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 3, 7,
                    ],
                    E = [
                      16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14,
                      1, 15,
                    ],
                    J = new Array(2 * (g + 2));
                  i(J);
                  var B = new Array(2 * d);
                  i(B);
                  var S = new Array(512);
                  i(S);
                  var p = new Array(256);
                  i(p);
                  var T = new Array(r);
                  i(T);
                  var Z,
                    U,
                    ae,
                    Q = new Array(d);
                  function $(w, k, G, O, N) {
                    ((this.static_tree = w),
                      (this.extra_bits = k),
                      (this.extra_base = G),
                      (this.elems = O),
                      (this.max_length = N),
                      (this.has_stree = w && w.length));
                  }
                  function F(w, k) {
                    ((this.dyn_tree = w),
                      (this.max_code = 0),
                      (this.stat_desc = k));
                  }
                  function R(w) {
                    return w < 256 ? S[w] : S[256 + (w >>> 7)];
                  }
                  function K(w, k) {
                    ((w.pending_buf[w.pending++] = 255 & k),
                      (w.pending_buf[w.pending++] = (k >>> 8) & 255));
                  }
                  function H(w, k, G) {
                    w.bi_valid > v - G
                      ? ((w.bi_buf |= (k << w.bi_valid) & 65535),
                        K(w, w.bi_buf),
                        (w.bi_buf = k >> (v - w.bi_valid)),
                        (w.bi_valid += G - v))
                      : ((w.bi_buf |= (k << w.bi_valid) & 65535),
                        (w.bi_valid += G));
                  }
                  function q(w, k, G) {
                    H(w, G[2 * k], G[2 * k + 1]);
                  }
                  function oe(w, k) {
                    for (
                      var G = 0;
                      (G |= 1 & w), (w >>>= 1), (G <<= 1), 0 < --k;
                    );
                    return G >>> 1;
                  }
                  function ye(w, k, G) {
                    var O,
                      N,
                      V = new Array(y + 1),
                      j = 0;
                    for (O = 1; O <= y; O++) V[O] = j = (j + G[O - 1]) << 1;
                    for (N = 0; N <= k; N++) {
                      var Y = w[2 * N + 1];
                      Y !== 0 && (w[2 * N] = oe(V[Y]++, Y));
                    }
                  }
                  function ce(w) {
                    var k;
                    for (k = 0; k < g; k++) w.dyn_ltree[2 * k] = 0;
                    for (k = 0; k < d; k++) w.dyn_dtree[2 * k] = 0;
                    for (k = 0; k < m; k++) w.bl_tree[2 * k] = 0;
                    ((w.dyn_ltree[2 * C] = 1),
                      (w.opt_len = w.static_len = 0),
                      (w.last_lit = w.matches = 0));
                  }
                  function de(w) {
                    (8 < w.bi_valid
                      ? K(w, w.bi_buf)
                      : 0 < w.bi_valid &&
                        (w.pending_buf[w.pending++] = w.bi_buf),
                      (w.bi_buf = 0),
                      (w.bi_valid = 0));
                  }
                  function ve(w, k, G, O) {
                    var N = 2 * k,
                      V = 2 * G;
                    return w[N] < w[V] || (w[N] === w[V] && O[k] <= O[G]);
                  }
                  function se(w, k, G) {
                    for (
                      var O = w.heap[G], N = G << 1;
                      N <= w.heap_len &&
                      (N < w.heap_len &&
                        ve(k, w.heap[N + 1], w.heap[N], w.depth) &&
                        N++,
                      !ve(k, O, w.heap[N], w.depth));
                    )
                      ((w.heap[G] = w.heap[N]), (G = N), (N <<= 1));
                    w.heap[G] = O;
                  }
                  function we(w, k, G) {
                    var O,
                      N,
                      V,
                      j,
                      Y = 0;
                    if (w.last_lit !== 0)
                      for (
                        ;
                        (O =
                          (w.pending_buf[w.d_buf + 2 * Y] << 8) |
                          w.pending_buf[w.d_buf + 2 * Y + 1]),
                          (N = w.pending_buf[w.l_buf + Y]),
                          Y++,
                          O === 0
                            ? q(w, N, k)
                            : (q(w, (V = p[N]) + u + 1, k),
                              (j = _[V]) !== 0 && H(w, (N -= T[V]), j),
                              q(w, (V = R(--O)), G),
                              (j = X[V]) !== 0 && H(w, (O -= Q[V]), j)),
                          Y < w.last_lit;
                      );
                    q(w, C, k);
                  }
                  function ue(w, k) {
                    var G,
                      O,
                      N,
                      V = k.dyn_tree,
                      j = k.stat_desc.static_tree,
                      Y = k.stat_desc.has_stree,
                      ee = k.stat_desc.elems,
                      me = -1;
                    for (w.heap_len = 0, w.heap_max = h, G = 0; G < ee; G++)
                      V[2 * G] !== 0
                        ? ((w.heap[++w.heap_len] = me = G), (w.depth[G] = 0))
                        : (V[2 * G + 1] = 0);
                    for (; w.heap_len < 2;)
                      ((V[2 * (N = w.heap[++w.heap_len] = me < 2 ? ++me : 0)] =
                        1),
                        (w.depth[N] = 0),
                        w.opt_len--,
                        Y && (w.static_len -= j[2 * N + 1]));
                    for (k.max_code = me, G = w.heap_len >> 1; 1 <= G; G--)
                      se(w, V, G);
                    for (
                      N = ee;
                      (G = w.heap[1]),
                        (w.heap[1] = w.heap[w.heap_len--]),
                        se(w, V, 1),
                        (O = w.heap[1]),
                        (w.heap[--w.heap_max] = G),
                        (w.heap[--w.heap_max] = O),
                        (V[2 * N] = V[2 * G] + V[2 * O]),
                        (w.depth[N] =
                          (w.depth[G] >= w.depth[O] ? w.depth[G] : w.depth[O]) +
                          1),
                        (V[2 * G + 1] = V[2 * O + 1] = N),
                        (w.heap[1] = N++),
                        se(w, V, 1),
                        2 <= w.heap_len;
                    );
                    ((w.heap[--w.heap_max] = w.heap[1]),
                      (function (pe, De) {
                        var qe,
                          Pe,
                          Ye,
                          ge,
                          tt,
                          ft,
                          Ne = De.dyn_tree,
                          _t = De.max_code,
                          Zt = De.stat_desc.static_tree,
                          jt = De.stat_desc.has_stree,
                          $t = De.stat_desc.extra_bits,
                          St = De.stat_desc.extra_base,
                          Je = De.stat_desc.max_length,
                          at = 0;
                        for (ge = 0; ge <= y; ge++) pe.bl_count[ge] = 0;
                        for (
                          Ne[2 * pe.heap[pe.heap_max] + 1] = 0,
                            qe = pe.heap_max + 1;
                          qe < h;
                          qe++
                        )
                          (Je <
                            (ge =
                              Ne[2 * Ne[2 * (Pe = pe.heap[qe]) + 1] + 1] + 1) &&
                            ((ge = Je), at++),
                            (Ne[2 * Pe + 1] = ge),
                            _t < Pe ||
                              (pe.bl_count[ge]++,
                              (tt = 0),
                              St <= Pe && (tt = $t[Pe - St]),
                              (ft = Ne[2 * Pe]),
                              (pe.opt_len += ft * (ge + tt)),
                              jt &&
                                (pe.static_len += ft * (Zt[2 * Pe + 1] + tt))));
                        if (at !== 0) {
                          do {
                            for (ge = Je - 1; pe.bl_count[ge] === 0;) ge--;
                            (pe.bl_count[ge]--,
                              (pe.bl_count[ge + 1] += 2),
                              pe.bl_count[Je]--,
                              (at -= 2));
                          } while (0 < at);
                          for (ge = Je; ge !== 0; ge--)
                            for (Pe = pe.bl_count[ge]; Pe !== 0;)
                              _t < (Ye = pe.heap[--qe]) ||
                                (Ne[2 * Ye + 1] !== ge &&
                                  ((pe.opt_len +=
                                    (ge - Ne[2 * Ye + 1]) * Ne[2 * Ye]),
                                  (Ne[2 * Ye + 1] = ge)),
                                Pe--);
                        }
                      })(w, k),
                      ye(V, me, w.bl_count));
                  }
                  function f(w, k, G) {
                    var O,
                      N,
                      V = -1,
                      j = k[1],
                      Y = 0,
                      ee = 7,
                      me = 4;
                    for (
                      j === 0 && ((ee = 138), (me = 3)),
                        k[2 * (G + 1) + 1] = 65535,
                        O = 0;
                      O <= G;
                      O++
                    )
                      ((N = j),
                        (j = k[2 * (O + 1) + 1]),
                        (++Y < ee && N === j) ||
                          (Y < me
                            ? (w.bl_tree[2 * N] += Y)
                            : N !== 0
                              ? (N !== V && w.bl_tree[2 * N]++,
                                w.bl_tree[2 * D]++)
                              : Y <= 10
                                ? w.bl_tree[2 * L]++
                                : w.bl_tree[2 * M]++,
                          (V = N),
                          (me =
                            (Y = 0) === j
                              ? ((ee = 138), 3)
                              : N === j
                                ? ((ee = 6), 3)
                                : ((ee = 7), 4))));
                  }
                  function z(w, k, G) {
                    var O,
                      N,
                      V = -1,
                      j = k[1],
                      Y = 0,
                      ee = 7,
                      me = 4;
                    for (j === 0 && ((ee = 138), (me = 3)), O = 0; O <= G; O++)
                      if (
                        ((N = j),
                        (j = k[2 * (O + 1) + 1]),
                        !(++Y < ee && N === j))
                      ) {
                        if (Y < me) for (; q(w, N, w.bl_tree), --Y != 0;);
                        else
                          N !== 0
                            ? (N !== V && (q(w, N, w.bl_tree), Y--),
                              q(w, D, w.bl_tree),
                              H(w, Y - 3, 2))
                            : Y <= 10
                              ? (q(w, L, w.bl_tree), H(w, Y - 3, 3))
                              : (q(w, M, w.bl_tree), H(w, Y - 11, 7));
                        ((V = N),
                          (me =
                            (Y = 0) === j
                              ? ((ee = 138), 3)
                              : N === j
                                ? ((ee = 6), 3)
                                : ((ee = 7), 4)));
                      }
                  }
                  i(Q);
                  var I = !1;
                  function x(w, k, G, O) {
                    (H(w, (a << 1) + (O ? 1 : 0), 3),
                      (function (N, V, j, Y) {
                        (de(N),
                          K(N, j),
                          K(N, ~j),
                          s.arraySet(N.pending_buf, N.window, V, j, N.pending),
                          (N.pending += j));
                      })(w, k, G));
                  }
                  ((n._tr_init = function (w) {
                    (I ||
                      ((function () {
                        var k,
                          G,
                          O,
                          N,
                          V,
                          j = new Array(y + 1);
                        for (N = O = 0; N < r - 1; N++)
                          for (T[N] = O, k = 0; k < 1 << _[N]; k++) p[O++] = N;
                        for (p[O - 1] = N, N = V = 0; N < 16; N++)
                          for (Q[N] = V, k = 0; k < 1 << X[N]; k++) S[V++] = N;
                        for (V >>= 7; N < d; N++)
                          for (Q[N] = V << 7, k = 0; k < 1 << (X[N] - 7); k++)
                            S[256 + V++] = N;
                        for (G = 0; G <= y; G++) j[G] = 0;
                        for (k = 0; k <= 143;)
                          ((J[2 * k + 1] = 8), k++, j[8]++);
                        for (; k <= 255;) ((J[2 * k + 1] = 9), k++, j[9]++);
                        for (; k <= 279;) ((J[2 * k + 1] = 7), k++, j[7]++);
                        for (; k <= 287;) ((J[2 * k + 1] = 8), k++, j[8]++);
                        for (ye(J, g + 1, j), k = 0; k < d; k++)
                          ((B[2 * k + 1] = 5), (B[2 * k] = oe(k, 5)));
                        ((Z = new $(J, _, u + 1, g, y)),
                          (U = new $(B, X, 0, d, y)),
                          (ae = new $(new Array(0), P, 0, m, b)));
                      })(),
                      (I = !0)),
                      (w.l_desc = new F(w.dyn_ltree, Z)),
                      (w.d_desc = new F(w.dyn_dtree, U)),
                      (w.bl_desc = new F(w.bl_tree, ae)),
                      (w.bi_buf = 0),
                      (w.bi_valid = 0),
                      ce(w));
                  }),
                    (n._tr_stored_block = x),
                    (n._tr_flush_block = function (w, k, G, O) {
                      var N,
                        V,
                        j = 0;
                      (0 < w.level
                        ? (w.strm.data_type === 2 &&
                            (w.strm.data_type = (function (Y) {
                              var ee,
                                me = 4093624447;
                              for (ee = 0; ee <= 31; ee++, me >>>= 1)
                                if (1 & me && Y.dyn_ltree[2 * ee] !== 0)
                                  return l;
                              if (
                                Y.dyn_ltree[18] !== 0 ||
                                Y.dyn_ltree[20] !== 0 ||
                                Y.dyn_ltree[26] !== 0
                              )
                                return c;
                              for (ee = 32; ee < u; ee++)
                                if (Y.dyn_ltree[2 * ee] !== 0) return c;
                              return l;
                            })(w)),
                          ue(w, w.l_desc),
                          ue(w, w.d_desc),
                          (j = (function (Y) {
                            var ee;
                            for (
                              f(Y, Y.dyn_ltree, Y.l_desc.max_code),
                                f(Y, Y.dyn_dtree, Y.d_desc.max_code),
                                ue(Y, Y.bl_desc),
                                ee = m - 1;
                              3 <= ee && Y.bl_tree[2 * E[ee] + 1] === 0;
                              ee--
                            );
                            return (
                              (Y.opt_len += 3 * (ee + 1) + 5 + 5 + 4),
                              ee
                            );
                          })(w)),
                          (N = (w.opt_len + 3 + 7) >>> 3),
                          (V = (w.static_len + 3 + 7) >>> 3) <= N && (N = V))
                        : (N = V = G + 5),
                        G + 4 <= N && k !== -1
                          ? x(w, k, G, O)
                          : w.strategy === 4 || V === N
                            ? (H(w, 2 + (O ? 1 : 0), 3), we(w, J, B))
                            : (H(w, 4 + (O ? 1 : 0), 3),
                              (function (Y, ee, me, pe) {
                                var De;
                                for (
                                  H(Y, ee - 257, 5),
                                    H(Y, me - 1, 5),
                                    H(Y, pe - 4, 4),
                                    De = 0;
                                  De < pe;
                                  De++
                                )
                                  H(Y, Y.bl_tree[2 * E[De] + 1], 3);
                                (z(Y, Y.dyn_ltree, ee - 1),
                                  z(Y, Y.dyn_dtree, me - 1));
                              })(
                                w,
                                w.l_desc.max_code + 1,
                                w.d_desc.max_code + 1,
                                j + 1,
                              ),
                              we(w, w.dyn_ltree, w.dyn_dtree)),
                        ce(w),
                        O && de(w));
                    }),
                    (n._tr_tally = function (w, k, G) {
                      return (
                        (w.pending_buf[w.d_buf + 2 * w.last_lit] =
                          (k >>> 8) & 255),
                        (w.pending_buf[w.d_buf + 2 * w.last_lit + 1] = 255 & k),
                        (w.pending_buf[w.l_buf + w.last_lit] = 255 & G),
                        w.last_lit++,
                        k === 0
                          ? w.dyn_ltree[2 * G]++
                          : (w.matches++,
                            k--,
                            w.dyn_ltree[2 * (p[G] + u + 1)]++,
                            w.dyn_dtree[2 * R(k)]++),
                        w.last_lit === w.lit_bufsize - 1
                      );
                    }),
                    (n._tr_align = function (w) {
                      (H(w, 2, 3),
                        q(w, C, J),
                        (function (k) {
                          k.bi_valid === 16
                            ? (K(k, k.bi_buf), (k.bi_buf = 0), (k.bi_valid = 0))
                            : 8 <= k.bi_valid &&
                              ((k.pending_buf[k.pending++] = 255 & k.bi_buf),
                              (k.bi_buf >>= 8),
                              (k.bi_valid -= 8));
                        })(w));
                    }));
                },
                { "../utils/common": 41 },
              ],
              53: [
                function (t, o, n) {
                  o.exports = function () {
                    ((this.input = null),
                      (this.next_in = 0),
                      (this.avail_in = 0),
                      (this.total_in = 0),
                      (this.output = null),
                      (this.next_out = 0),
                      (this.avail_out = 0),
                      (this.total_out = 0),
                      (this.msg = ""),
                      (this.state = null),
                      (this.data_type = 2),
                      (this.adler = 0));
                  };
                },
                {},
              ],
              54: [
                function (t, o, n) {
                  (function (s) {
                    (function (l, c) {
                      if (!l.setImmediate) {
                        var i,
                          a,
                          r,
                          u,
                          g = 1,
                          d = {},
                          m = !1,
                          h = l.document,
                          y = Object.getPrototypeOf && Object.getPrototypeOf(l);
                        ((y = y && y.setTimeout ? y : l),
                          (i =
                            {}.toString.call(l.process) === "[object process]"
                              ? function (D) {
                                  process.nextTick(function () {
                                    b(D);
                                  });
                                }
                              : (function () {
                                    if (l.postMessage && !l.importScripts) {
                                      var D = !0,
                                        L = l.onmessage;
                                      return (
                                        (l.onmessage = function () {
                                          D = !1;
                                        }),
                                        l.postMessage("", "*"),
                                        (l.onmessage = L),
                                        D
                                      );
                                    }
                                  })()
                                ? ((u = "setImmediate$" + Math.random() + "$"),
                                  l.addEventListener
                                    ? l.addEventListener("message", C, !1)
                                    : l.attachEvent("onmessage", C),
                                  function (D) {
                                    l.postMessage(u + D, "*");
                                  })
                                : l.MessageChannel
                                  ? (((r =
                                      new MessageChannel()).port1.onmessage =
                                      function (D) {
                                        b(D.data);
                                      }),
                                    function (D) {
                                      r.port2.postMessage(D);
                                    })
                                  : h &&
                                      "onreadystatechange" in
                                        h.createElement("script")
                                    ? ((a = h.documentElement),
                                      function (D) {
                                        var L = h.createElement("script");
                                        ((L.onreadystatechange = function () {
                                          (b(D),
                                            (L.onreadystatechange = null),
                                            a.removeChild(L),
                                            (L = null));
                                        }),
                                          a.appendChild(L));
                                      })
                                    : function (D) {
                                        setTimeout(b, 0, D);
                                      }),
                          (y.setImmediate = function (D) {
                            typeof D != "function" &&
                              (D = new Function("" + D));
                            for (
                              var L = new Array(arguments.length - 1), M = 0;
                              M < L.length;
                              M++
                            )
                              L[M] = arguments[M + 1];
                            var _ = { callback: D, args: L };
                            return ((d[g] = _), i(g), g++);
                          }),
                          (y.clearImmediate = v));
                      }
                      function v(D) {
                        delete d[D];
                      }
                      function b(D) {
                        if (m) setTimeout(b, 0, D);
                        else {
                          var L = d[D];
                          if (L) {
                            m = !0;
                            try {
                              (function (M) {
                                var _ = M.callback,
                                  X = M.args;
                                switch (X.length) {
                                  case 0:
                                    _();
                                    break;
                                  case 1:
                                    _(X[0]);
                                    break;
                                  case 2:
                                    _(X[0], X[1]);
                                    break;
                                  case 3:
                                    _(X[0], X[1], X[2]);
                                    break;
                                  default:
                                    _.apply(c, X);
                                }
                              })(L);
                            } finally {
                              (v(D), (m = !1));
                            }
                          }
                        }
                      }
                      function C(D) {
                        D.source === l &&
                          typeof D.data == "string" &&
                          D.data.indexOf(u) === 0 &&
                          b(+D.data.slice(u.length));
                      }
                    })(typeof self > "u" ? (s === void 0 ? this : s) : self);
                  }).call(
                    this,
                    typeof rt < "u"
                      ? rt
                      : typeof self < "u"
                        ? self
                        : typeof window < "u"
                          ? window
                          : {},
                  );
                },
                {},
              ],
            },
            {},
            [10],
          )(10);
        });
      })(pt)),
    pt.exports
  );
}
var aa = ta();
const Gt = ea(aa);
function Be(e, A, t, o) {
  function n(s) {
    return s instanceof t
      ? s
      : new t(function (l) {
          l(s);
        });
  }
  return new (t || (t = Promise))(function (s, l) {
    function c(r) {
      try {
        a(o.next(r));
      } catch (u) {
        l(u);
      }
    }
    function i(r) {
      try {
        a(o.throw(r));
      } catch (u) {
        l(u);
      }
    }
    function a(r) {
      r.done ? s(r.value) : n(r.value).then(c, i);
    }
    a((o = o.apply(e, [])).next());
  });
}
const Ae = 914400,
  et = 12700,
  be = `\r
`,
  ra = 2147483649,
  ut = /^[0-9a-fA-F]{6}$/,
  na = 1.67,
  Aa = 27,
  ze = { type: "solid", color: "666666", pt: 1 },
  Qt = [0.05, 0.1, 0.05, 0.1],
  Ue = { color: "363636", pt: 1 },
  Me = { color: "888888", style: "solid", size: 1, cap: "flat" },
  xe = "000000",
  ke = 12,
  ia = 18,
  Xe = "LAYOUT_16x9",
  wt = "DEFAULT",
  Ot = "333333",
  Se = {
    type: "outer",
    blur: 3,
    offset: 23e3 / 12700,
    angle: 90,
    color: "000000",
    opacity: 0.35,
    rotateWithShape: !0,
  },
  $e = [0.5, 0.5, 0.5, 0.5],
  Mt = { color: "000000" },
  oa = { size: 8, color: "FFFFFF", opacity: 0.75 },
  Re = "2094734552",
  it = "2094734553",
  Ke = "2094734554",
  xt = "2094734555",
  Wt = "2094734556",
  He = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".split(""),
  Ze = [
    "C0504D",
    "4F81BD",
    "9BBB59",
    "8064A2",
    "4BACC6",
    "F79646",
    "628FC6",
    "C86360",
    "C0504D",
    "4F81BD",
    "9BBB59",
    "8064A2",
    "4BACC6",
    "F79646",
    "628FC6",
    "C86360",
  ],
  sa = [
    "5DA5DA",
    "FAA43A",
    "60BD68",
    "F17CB0",
    "B2912F",
    "B276B2",
    "DECF3F",
    "F15854",
    "A7A7A7",
    "5DA5DA",
    "FAA43A",
    "60BD68",
    "F17CB0",
    "B2912F",
    "B276B2",
    "DECF3F",
    "F15854",
    "A7A7A7",
  ];
var Ge;
(function (e) {
  ((e.left = "left"),
    (e.center = "center"),
    (e.right = "right"),
    (e.justify = "justify"));
})(Ge || (Ge = {}));
var Qe;
(function (e) {
  ((e.b = "b"), (e.ctr = "ctr"), (e.t = "t"));
})(Qe || (Qe = {}));
const Vt = "{F7021451-1387-4CA6-816F-3879F97B5CBC}";
var Ct;
(function (e) {
  ((e.arraybuffer = "arraybuffer"),
    (e.base64 = "base64"),
    (e.binarystring = "binarystring"),
    (e.blob = "blob"),
    (e.nodebuffer = "nodebuffer"),
    (e.uint8array = "uint8array"));
})(Ct || (Ct = {}));
var Bt;
(function (e) {
  ((e.area = "area"),
    (e.bar = "bar"),
    (e.bar3d = "bar3D"),
    (e.bubble = "bubble"),
    (e.bubble3d = "bubble3D"),
    (e.doughnut = "doughnut"),
    (e.line = "line"),
    (e.pie = "pie"),
    (e.radar = "radar"),
    (e.scatter = "scatter"));
})(Bt || (Bt = {}));
var Lt;
(function (e) {
  ((e.accentBorderCallout1 = "accentBorderCallout1"),
    (e.accentBorderCallout2 = "accentBorderCallout2"),
    (e.accentBorderCallout3 = "accentBorderCallout3"),
    (e.accentCallout1 = "accentCallout1"),
    (e.accentCallout2 = "accentCallout2"),
    (e.accentCallout3 = "accentCallout3"),
    (e.actionButtonBackPrevious = "actionButtonBackPrevious"),
    (e.actionButtonBeginning = "actionButtonBeginning"),
    (e.actionButtonBlank = "actionButtonBlank"),
    (e.actionButtonDocument = "actionButtonDocument"),
    (e.actionButtonEnd = "actionButtonEnd"),
    (e.actionButtonForwardNext = "actionButtonForwardNext"),
    (e.actionButtonHelp = "actionButtonHelp"),
    (e.actionButtonHome = "actionButtonHome"),
    (e.actionButtonInformation = "actionButtonInformation"),
    (e.actionButtonMovie = "actionButtonMovie"),
    (e.actionButtonReturn = "actionButtonReturn"),
    (e.actionButtonSound = "actionButtonSound"),
    (e.arc = "arc"),
    (e.bentArrow = "bentArrow"),
    (e.bentUpArrow = "bentUpArrow"),
    (e.bevel = "bevel"),
    (e.blockArc = "blockArc"),
    (e.borderCallout1 = "borderCallout1"),
    (e.borderCallout2 = "borderCallout2"),
    (e.borderCallout3 = "borderCallout3"),
    (e.bracePair = "bracePair"),
    (e.bracketPair = "bracketPair"),
    (e.callout1 = "callout1"),
    (e.callout2 = "callout2"),
    (e.callout3 = "callout3"),
    (e.can = "can"),
    (e.chartPlus = "chartPlus"),
    (e.chartStar = "chartStar"),
    (e.chartX = "chartX"),
    (e.chevron = "chevron"),
    (e.chord = "chord"),
    (e.circularArrow = "circularArrow"),
    (e.cloud = "cloud"),
    (e.cloudCallout = "cloudCallout"),
    (e.corner = "corner"),
    (e.cornerTabs = "cornerTabs"),
    (e.cube = "cube"),
    (e.curvedDownArrow = "curvedDownArrow"),
    (e.curvedLeftArrow = "curvedLeftArrow"),
    (e.curvedRightArrow = "curvedRightArrow"),
    (e.curvedUpArrow = "curvedUpArrow"),
    (e.custGeom = "custGeom"),
    (e.decagon = "decagon"),
    (e.diagStripe = "diagStripe"),
    (e.diamond = "diamond"),
    (e.dodecagon = "dodecagon"),
    (e.donut = "donut"),
    (e.doubleWave = "doubleWave"),
    (e.downArrow = "downArrow"),
    (e.downArrowCallout = "downArrowCallout"),
    (e.ellipse = "ellipse"),
    (e.ellipseRibbon = "ellipseRibbon"),
    (e.ellipseRibbon2 = "ellipseRibbon2"),
    (e.flowChartAlternateProcess = "flowChartAlternateProcess"),
    (e.flowChartCollate = "flowChartCollate"),
    (e.flowChartConnector = "flowChartConnector"),
    (e.flowChartDecision = "flowChartDecision"),
    (e.flowChartDelay = "flowChartDelay"),
    (e.flowChartDisplay = "flowChartDisplay"),
    (e.flowChartDocument = "flowChartDocument"),
    (e.flowChartExtract = "flowChartExtract"),
    (e.flowChartInputOutput = "flowChartInputOutput"),
    (e.flowChartInternalStorage = "flowChartInternalStorage"),
    (e.flowChartMagneticDisk = "flowChartMagneticDisk"),
    (e.flowChartMagneticDrum = "flowChartMagneticDrum"),
    (e.flowChartMagneticTape = "flowChartMagneticTape"),
    (e.flowChartManualInput = "flowChartManualInput"),
    (e.flowChartManualOperation = "flowChartManualOperation"),
    (e.flowChartMerge = "flowChartMerge"),
    (e.flowChartMultidocument = "flowChartMultidocument"),
    (e.flowChartOfflineStorage = "flowChartOfflineStorage"),
    (e.flowChartOffpageConnector = "flowChartOffpageConnector"),
    (e.flowChartOnlineStorage = "flowChartOnlineStorage"),
    (e.flowChartOr = "flowChartOr"),
    (e.flowChartPredefinedProcess = "flowChartPredefinedProcess"),
    (e.flowChartPreparation = "flowChartPreparation"),
    (e.flowChartProcess = "flowChartProcess"),
    (e.flowChartPunchedCard = "flowChartPunchedCard"),
    (e.flowChartPunchedTape = "flowChartPunchedTape"),
    (e.flowChartSort = "flowChartSort"),
    (e.flowChartSummingJunction = "flowChartSummingJunction"),
    (e.flowChartTerminator = "flowChartTerminator"),
    (e.folderCorner = "folderCorner"),
    (e.frame = "frame"),
    (e.funnel = "funnel"),
    (e.gear6 = "gear6"),
    (e.gear9 = "gear9"),
    (e.halfFrame = "halfFrame"),
    (e.heart = "heart"),
    (e.heptagon = "heptagon"),
    (e.hexagon = "hexagon"),
    (e.homePlate = "homePlate"),
    (e.horizontalScroll = "horizontalScroll"),
    (e.irregularSeal1 = "irregularSeal1"),
    (e.irregularSeal2 = "irregularSeal2"),
    (e.leftArrow = "leftArrow"),
    (e.leftArrowCallout = "leftArrowCallout"),
    (e.leftBrace = "leftBrace"),
    (e.leftBracket = "leftBracket"),
    (e.leftCircularArrow = "leftCircularArrow"),
    (e.leftRightArrow = "leftRightArrow"),
    (e.leftRightArrowCallout = "leftRightArrowCallout"),
    (e.leftRightCircularArrow = "leftRightCircularArrow"),
    (e.leftRightRibbon = "leftRightRibbon"),
    (e.leftRightUpArrow = "leftRightUpArrow"),
    (e.leftUpArrow = "leftUpArrow"),
    (e.lightningBolt = "lightningBolt"),
    (e.line = "line"),
    (e.lineInv = "lineInv"),
    (e.mathDivide = "mathDivide"),
    (e.mathEqual = "mathEqual"),
    (e.mathMinus = "mathMinus"),
    (e.mathMultiply = "mathMultiply"),
    (e.mathNotEqual = "mathNotEqual"),
    (e.mathPlus = "mathPlus"),
    (e.moon = "moon"),
    (e.noSmoking = "noSmoking"),
    (e.nonIsoscelesTrapezoid = "nonIsoscelesTrapezoid"),
    (e.notchedRightArrow = "notchedRightArrow"),
    (e.octagon = "octagon"),
    (e.parallelogram = "parallelogram"),
    (e.pentagon = "pentagon"),
    (e.pie = "pie"),
    (e.pieWedge = "pieWedge"),
    (e.plaque = "plaque"),
    (e.plaqueTabs = "plaqueTabs"),
    (e.plus = "plus"),
    (e.quadArrow = "quadArrow"),
    (e.quadArrowCallout = "quadArrowCallout"),
    (e.rect = "rect"),
    (e.ribbon = "ribbon"),
    (e.ribbon2 = "ribbon2"),
    (e.rightArrow = "rightArrow"),
    (e.rightArrowCallout = "rightArrowCallout"),
    (e.rightBrace = "rightBrace"),
    (e.rightBracket = "rightBracket"),
    (e.round1Rect = "round1Rect"),
    (e.round2DiagRect = "round2DiagRect"),
    (e.round2SameRect = "round2SameRect"),
    (e.roundRect = "roundRect"),
    (e.rtTriangle = "rtTriangle"),
    (e.smileyFace = "smileyFace"),
    (e.snip1Rect = "snip1Rect"),
    (e.snip2DiagRect = "snip2DiagRect"),
    (e.snip2SameRect = "snip2SameRect"),
    (e.snipRoundRect = "snipRoundRect"),
    (e.squareTabs = "squareTabs"),
    (e.star10 = "star10"),
    (e.star12 = "star12"),
    (e.star16 = "star16"),
    (e.star24 = "star24"),
    (e.star32 = "star32"),
    (e.star4 = "star4"),
    (e.star5 = "star5"),
    (e.star6 = "star6"),
    (e.star7 = "star7"),
    (e.star8 = "star8"),
    (e.stripedRightArrow = "stripedRightArrow"),
    (e.sun = "sun"),
    (e.swooshArrow = "swooshArrow"),
    (e.teardrop = "teardrop"),
    (e.trapezoid = "trapezoid"),
    (e.triangle = "triangle"),
    (e.upArrow = "upArrow"),
    (e.upArrowCallout = "upArrowCallout"),
    (e.upDownArrow = "upDownArrow"),
    (e.upDownArrowCallout = "upDownArrowCallout"),
    (e.uturnArrow = "uturnArrow"),
    (e.verticalScroll = "verticalScroll"),
    (e.wave = "wave"),
    (e.wedgeEllipseCallout = "wedgeEllipseCallout"),
    (e.wedgeRectCallout = "wedgeRectCallout"),
    (e.wedgeRoundRectCallout = "wedgeRoundRectCallout"));
})(Lt || (Lt = {}));
var Ce;
(function (e) {
  ((e.text1 = "tx1"),
    (e.text2 = "tx2"),
    (e.background1 = "bg1"),
    (e.background2 = "bg2"),
    (e.accent1 = "accent1"),
    (e.accent2 = "accent2"),
    (e.accent3 = "accent3"),
    (e.accent4 = "accent4"),
    (e.accent5 = "accent5"),
    (e.accent6 = "accent6"));
})(Ce || (Ce = {}));
var Dt;
(function (e) {
  ((e.left = "left"),
    (e.center = "center"),
    (e.right = "right"),
    (e.justify = "justify"));
})(Dt || (Dt = {}));
var kt;
(function (e) {
  ((e.top = "top"), (e.middle = "middle"), (e.bottom = "bottom"));
})(kt || (kt = {}));
var _e;
(function (e) {
  ((e.ACTION_BUTTON_BACK_OR_PREVIOUS = "actionButtonBackPrevious"),
    (e.ACTION_BUTTON_BEGINNING = "actionButtonBeginning"),
    (e.ACTION_BUTTON_CUSTOM = "actionButtonBlank"),
    (e.ACTION_BUTTON_DOCUMENT = "actionButtonDocument"),
    (e.ACTION_BUTTON_END = "actionButtonEnd"),
    (e.ACTION_BUTTON_FORWARD_OR_NEXT = "actionButtonForwardNext"),
    (e.ACTION_BUTTON_HELP = "actionButtonHelp"),
    (e.ACTION_BUTTON_HOME = "actionButtonHome"),
    (e.ACTION_BUTTON_INFORMATION = "actionButtonInformation"),
    (e.ACTION_BUTTON_MOVIE = "actionButtonMovie"),
    (e.ACTION_BUTTON_RETURN = "actionButtonReturn"),
    (e.ACTION_BUTTON_SOUND = "actionButtonSound"),
    (e.ARC = "arc"),
    (e.BALLOON = "wedgeRoundRectCallout"),
    (e.BENT_ARROW = "bentArrow"),
    (e.BENT_UP_ARROW = "bentUpArrow"),
    (e.BEVEL = "bevel"),
    (e.BLOCK_ARC = "blockArc"),
    (e.CAN = "can"),
    (e.CHART_PLUS = "chartPlus"),
    (e.CHART_STAR = "chartStar"),
    (e.CHART_X = "chartX"),
    (e.CHEVRON = "chevron"),
    (e.CHORD = "chord"),
    (e.CIRCULAR_ARROW = "circularArrow"),
    (e.CLOUD = "cloud"),
    (e.CLOUD_CALLOUT = "cloudCallout"),
    (e.CORNER = "corner"),
    (e.CORNER_TABS = "cornerTabs"),
    (e.CROSS = "plus"),
    (e.CUBE = "cube"),
    (e.CURVED_DOWN_ARROW = "curvedDownArrow"),
    (e.CURVED_DOWN_RIBBON = "ellipseRibbon"),
    (e.CURVED_LEFT_ARROW = "curvedLeftArrow"),
    (e.CURVED_RIGHT_ARROW = "curvedRightArrow"),
    (e.CURVED_UP_ARROW = "curvedUpArrow"),
    (e.CURVED_UP_RIBBON = "ellipseRibbon2"),
    (e.CUSTOM_GEOMETRY = "custGeom"),
    (e.DECAGON = "decagon"),
    (e.DIAGONAL_STRIPE = "diagStripe"),
    (e.DIAMOND = "diamond"),
    (e.DODECAGON = "dodecagon"),
    (e.DONUT = "donut"),
    (e.DOUBLE_BRACE = "bracePair"),
    (e.DOUBLE_BRACKET = "bracketPair"),
    (e.DOUBLE_WAVE = "doubleWave"),
    (e.DOWN_ARROW = "downArrow"),
    (e.DOWN_ARROW_CALLOUT = "downArrowCallout"),
    (e.DOWN_RIBBON = "ribbon"),
    (e.EXPLOSION1 = "irregularSeal1"),
    (e.EXPLOSION2 = "irregularSeal2"),
    (e.FLOWCHART_ALTERNATE_PROCESS = "flowChartAlternateProcess"),
    (e.FLOWCHART_CARD = "flowChartPunchedCard"),
    (e.FLOWCHART_COLLATE = "flowChartCollate"),
    (e.FLOWCHART_CONNECTOR = "flowChartConnector"),
    (e.FLOWCHART_DATA = "flowChartInputOutput"),
    (e.FLOWCHART_DECISION = "flowChartDecision"),
    (e.FLOWCHART_DELAY = "flowChartDelay"),
    (e.FLOWCHART_DIRECT_ACCESS_STORAGE = "flowChartMagneticDrum"),
    (e.FLOWCHART_DISPLAY = "flowChartDisplay"),
    (e.FLOWCHART_DOCUMENT = "flowChartDocument"),
    (e.FLOWCHART_EXTRACT = "flowChartExtract"),
    (e.FLOWCHART_INTERNAL_STORAGE = "flowChartInternalStorage"),
    (e.FLOWCHART_MAGNETIC_DISK = "flowChartMagneticDisk"),
    (e.FLOWCHART_MANUAL_INPUT = "flowChartManualInput"),
    (e.FLOWCHART_MANUAL_OPERATION = "flowChartManualOperation"),
    (e.FLOWCHART_MERGE = "flowChartMerge"),
    (e.FLOWCHART_MULTIDOCUMENT = "flowChartMultidocument"),
    (e.FLOWCHART_OFFLINE_STORAGE = "flowChartOfflineStorage"),
    (e.FLOWCHART_OFFPAGE_CONNECTOR = "flowChartOffpageConnector"),
    (e.FLOWCHART_OR = "flowChartOr"),
    (e.FLOWCHART_PREDEFINED_PROCESS = "flowChartPredefinedProcess"),
    (e.FLOWCHART_PREPARATION = "flowChartPreparation"),
    (e.FLOWCHART_PROCESS = "flowChartProcess"),
    (e.FLOWCHART_PUNCHED_TAPE = "flowChartPunchedTape"),
    (e.FLOWCHART_SEQUENTIAL_ACCESS_STORAGE = "flowChartMagneticTape"),
    (e.FLOWCHART_SORT = "flowChartSort"),
    (e.FLOWCHART_STORED_DATA = "flowChartOnlineStorage"),
    (e.FLOWCHART_SUMMING_JUNCTION = "flowChartSummingJunction"),
    (e.FLOWCHART_TERMINATOR = "flowChartTerminator"),
    (e.FOLDED_CORNER = "folderCorner"),
    (e.FRAME = "frame"),
    (e.FUNNEL = "funnel"),
    (e.GEAR_6 = "gear6"),
    (e.GEAR_9 = "gear9"),
    (e.HALF_FRAME = "halfFrame"),
    (e.HEART = "heart"),
    (e.HEPTAGON = "heptagon"),
    (e.HEXAGON = "hexagon"),
    (e.HORIZONTAL_SCROLL = "horizontalScroll"),
    (e.ISOSCELES_TRIANGLE = "triangle"),
    (e.LEFT_ARROW = "leftArrow"),
    (e.LEFT_ARROW_CALLOUT = "leftArrowCallout"),
    (e.LEFT_BRACE = "leftBrace"),
    (e.LEFT_BRACKET = "leftBracket"),
    (e.LEFT_CIRCULAR_ARROW = "leftCircularArrow"),
    (e.LEFT_RIGHT_ARROW = "leftRightArrow"),
    (e.LEFT_RIGHT_ARROW_CALLOUT = "leftRightArrowCallout"),
    (e.LEFT_RIGHT_CIRCULAR_ARROW = "leftRightCircularArrow"),
    (e.LEFT_RIGHT_RIBBON = "leftRightRibbon"),
    (e.LEFT_RIGHT_UP_ARROW = "leftRightUpArrow"),
    (e.LEFT_UP_ARROW = "leftUpArrow"),
    (e.LIGHTNING_BOLT = "lightningBolt"),
    (e.LINE_CALLOUT_1 = "borderCallout1"),
    (e.LINE_CALLOUT_1_ACCENT_BAR = "accentCallout1"),
    (e.LINE_CALLOUT_1_BORDER_AND_ACCENT_BAR = "accentBorderCallout1"),
    (e.LINE_CALLOUT_1_NO_BORDER = "callout1"),
    (e.LINE_CALLOUT_2 = "borderCallout2"),
    (e.LINE_CALLOUT_2_ACCENT_BAR = "accentCallout2"),
    (e.LINE_CALLOUT_2_BORDER_AND_ACCENT_BAR = "accentBorderCallout2"),
    (e.LINE_CALLOUT_2_NO_BORDER = "callout2"),
    (e.LINE_CALLOUT_3 = "borderCallout3"),
    (e.LINE_CALLOUT_3_ACCENT_BAR = "accentCallout3"),
    (e.LINE_CALLOUT_3_BORDER_AND_ACCENT_BAR = "accentBorderCallout3"),
    (e.LINE_CALLOUT_3_NO_BORDER = "callout3"),
    (e.LINE_CALLOUT_4 = "borderCallout4"),
    (e.LINE_CALLOUT_4_ACCENT_BAR = "accentCallout3=4"),
    (e.LINE_CALLOUT_4_BORDER_AND_ACCENT_BAR = "accentBorderCallout4"),
    (e.LINE_CALLOUT_4_NO_BORDER = "callout4"),
    (e.LINE = "line"),
    (e.LINE_INVERSE = "lineInv"),
    (e.MATH_DIVIDE = "mathDivide"),
    (e.MATH_EQUAL = "mathEqual"),
    (e.MATH_MINUS = "mathMinus"),
    (e.MATH_MULTIPLY = "mathMultiply"),
    (e.MATH_NOT_EQUAL = "mathNotEqual"),
    (e.MATH_PLUS = "mathPlus"),
    (e.MOON = "moon"),
    (e.NON_ISOSCELES_TRAPEZOID = "nonIsoscelesTrapezoid"),
    (e.NOTCHED_RIGHT_ARROW = "notchedRightArrow"),
    (e.NO_SYMBOL = "noSmoking"),
    (e.OCTAGON = "octagon"),
    (e.OVAL = "ellipse"),
    (e.OVAL_CALLOUT = "wedgeEllipseCallout"),
    (e.PARALLELOGRAM = "parallelogram"),
    (e.PENTAGON = "homePlate"),
    (e.PIE = "pie"),
    (e.PIE_WEDGE = "pieWedge"),
    (e.PLAQUE = "plaque"),
    (e.PLAQUE_TABS = "plaqueTabs"),
    (e.QUAD_ARROW = "quadArrow"),
    (e.QUAD_ARROW_CALLOUT = "quadArrowCallout"),
    (e.RECTANGLE = "rect"),
    (e.RECTANGULAR_CALLOUT = "wedgeRectCallout"),
    (e.REGULAR_PENTAGON = "pentagon"),
    (e.RIGHT_ARROW = "rightArrow"),
    (e.RIGHT_ARROW_CALLOUT = "rightArrowCallout"),
    (e.RIGHT_BRACE = "rightBrace"),
    (e.RIGHT_BRACKET = "rightBracket"),
    (e.RIGHT_TRIANGLE = "rtTriangle"),
    (e.ROUNDED_RECTANGLE = "roundRect"),
    (e.ROUNDED_RECTANGULAR_CALLOUT = "wedgeRoundRectCallout"),
    (e.ROUND_1_RECTANGLE = "round1Rect"),
    (e.ROUND_2_DIAG_RECTANGLE = "round2DiagRect"),
    (e.ROUND_2_SAME_RECTANGLE = "round2SameRect"),
    (e.SMILEY_FACE = "smileyFace"),
    (e.SNIP_1_RECTANGLE = "snip1Rect"),
    (e.SNIP_2_DIAG_RECTANGLE = "snip2DiagRect"),
    (e.SNIP_2_SAME_RECTANGLE = "snip2SameRect"),
    (e.SNIP_ROUND_RECTANGLE = "snipRoundRect"),
    (e.SQUARE_TABS = "squareTabs"),
    (e.STAR_10_POINT = "star10"),
    (e.STAR_12_POINT = "star12"),
    (e.STAR_16_POINT = "star16"),
    (e.STAR_24_POINT = "star24"),
    (e.STAR_32_POINT = "star32"),
    (e.STAR_4_POINT = "star4"),
    (e.STAR_5_POINT = "star5"),
    (e.STAR_6_POINT = "star6"),
    (e.STAR_7_POINT = "star7"),
    (e.STAR_8_POINT = "star8"),
    (e.STRIPED_RIGHT_ARROW = "stripedRightArrow"),
    (e.SUN = "sun"),
    (e.SWOOSH_ARROW = "swooshArrow"),
    (e.TEAR = "teardrop"),
    (e.TRAPEZOID = "trapezoid"),
    (e.UP_ARROW = "upArrow"),
    (e.UP_ARROW_CALLOUT = "upArrowCallout"),
    (e.UP_DOWN_ARROW = "upDownArrow"),
    (e.UP_DOWN_ARROW_CALLOUT = "upDownArrowCallout"),
    (e.UP_RIBBON = "ribbon2"),
    (e.U_TURN_ARROW = "uturnArrow"),
    (e.VERTICAL_SCROLL = "verticalScroll"),
    (e.WAVE = "wave"));
})(_e || (_e = {}));
var W;
(function (e) {
  ((e.AREA = "area"),
    (e.BAR = "bar"),
    (e.BAR3D = "bar3D"),
    (e.BUBBLE = "bubble"),
    (e.BUBBLE3D = "bubble3D"),
    (e.DOUGHNUT = "doughnut"),
    (e.LINE = "line"),
    (e.PIE = "pie"),
    (e.RADAR = "radar"),
    (e.SCATTER = "scatter"));
})(W || (W = {}));
var lt;
(function (e) {
  ((e.TEXT1 = "tx1"),
    (e.TEXT2 = "tx2"),
    (e.BACKGROUND1 = "bg1"),
    (e.BACKGROUND2 = "bg2"),
    (e.ACCENT1 = "accent1"),
    (e.ACCENT2 = "accent2"),
    (e.ACCENT3 = "accent3"),
    (e.ACCENT4 = "accent4"),
    (e.ACCENT5 = "accent5"),
    (e.ACCENT6 = "accent6"));
})(lt || (lt = {}));
var Te;
(function (e) {
  ((e.chart = "chart"),
    (e.image = "image"),
    (e.line = "line"),
    (e.rect = "rect"),
    (e.text = "text"),
    (e.placeholder = "placeholder"));
})(Te || (Te = {}));
var ne;
(function (e) {
  ((e.chart = "chart"),
    (e.hyperlink = "hyperlink"),
    (e.image = "image"),
    (e.media = "media"),
    (e.online = "online"),
    (e.placeholder = "placeholder"),
    (e.table = "table"),
    (e.tablecell = "tablecell"),
    (e.text = "text"),
    (e.notes = "notes"));
})(ne || (ne = {}));
var je;
(function (e) {
  ((e.title = "title"),
    (e.body = "body"),
    (e.image = "pic"),
    (e.chart = "chart"),
    (e.table = "tbl"),
    (e.media = "media"));
})(je || (je = {}));
var Oe;
(function (e) {
  ((e.DEFAULT = "&#x2022;"),
    (e.CHECK = "&#x2713;"),
    (e.STAR = "&#x2605;"),
    (e.TRIANGLE = "&#x25B6;"));
})(Oe || (Oe = {}));
const We =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAAB3CAYAAAD1oOVhAAAGAUlEQVR4Xu2dT0xcRRzHf7tAYSsc0EBSIq2xEg8mtTGebVzEqOVIolz0siRE4gGTStqKwdpWsXoyGhMuyAVJOHBgqyvLNgonDkabeCBYW/8kTUr0wsJC+Wfm0bfuvn37Znbem9mR9303mJnf/Pb7ed95M7PDI5JIJPYJV5EC7e3t1N/fT62trdqViQCIu+bVgpIHEo/Hqbe3V/sdYVKHyWSSZmZm8ilVA0oeyNjYmEnaVC2Xvr6+qg5fAOJAz4DU1dURGzFSqZRVqtMpAFIGyMjICC0vL9PExIRWKADiAYTNshYWFrRCARAOEFZcCKWtrY0GBgaUTYkBRACIE4rKZwqACALR5RQAqQCIDqcASIVAVDsFQCSAqHQKgEgCUeUUAPEBRIVTAMQnEBvK5OQkbW9vk991CoAEAMQJxc86BUACAhKUUwAkQCBBOAVAAgbi1ykAogCIH6cAiCIgsk4BEIVAZJwCIIqBVLqiBxANQFgXS0tLND4+zl08AogmIG5OSSQS1gGKwgtANAIRcQqAaAbCe6YASBWA2E6xDyeyDUl7+AKQMkDYYevm5mZHabA/Li4uUiaTsYLau8QA4gLE/hU7wajyYtv1hReDAiAOxQcHBymbzark4BkbQKom/X8dp9Npmpqasn4BIAYAYSnYp+4BBEAMUcCwNOCQsAKZnp62NtQOw8WmwT09PUo+ijaHsOMx7GppaaH6+nolH0Z10K2tLVpdXbW6UfV3mNqBdHd3U1NTk2rtlMRfW1uj2dlZAFGirkRQAJEQTWUTAFGprkRsAJEQTWUTAFGprkRsAJEQTWUTAFGprkRsAJEQTWUTAFGprkRsAJEQTWUTAFGprkRsAJEQTWUTAGHqrm8caPzQ0WC1logbeiC7X3xJm0PvUmRzh45cuki1588FAmVn9BO6P3yF9utrqGH0MtW82S8UN9RA9v/4k7InjhcJFTs/TLVXLwmJV67S7vD7tHF5pKi46fYdosdOcOOGG8j1OcqefbFEJD9Q3GCwDhqT31HklS4A8VRgfYM2Op6k3bt/BQJl58J7lPvwg5JYNccepaMry0LPqFA7hCm39+NNyp2J0172b19QysGINj5CsRtpij57musOViH0QPJQXn6J9u7dlYJSFkbrMYolrwvDAJAC+WWdEpQz7FTgECeUCpzi6YxvvqXoM6eEhqnCSgDikEzUKUE7Aw7xuHctKB5OYU3dZlNR9syQdAaAcAYTC0pXF+39c09o2Ik+3EqxVKqiB7hbYAxZkk4pbBaEM+AQofv+wTrFwylBOQNABIGwavdfe4O2pg5elO+86l99nY58/VUF0byrYsjiSFluNlXYrOHcBar7+EogUADEQ0YRGHbzoKAASBkg2+9cpM1rV0tK2QOcXW7bLEFAARAXIF4w2DrDWoeUWaf4hQIgDiA8GPZ2iNfi0Q8UACkAIgrDbrJ385eDxaPLLrEsFAB5oG6lMPJQPLZZZKAACBGVhcG2Q+bmuLu2nk55e4jqPv1IeEoceiBeX7s2zCa5MAqdstl91vfXwaEGsv/rb5TtOFk6tWXOuJGh6KmnhO9sayrMninPx103JBtXblHkice58cINZP4Hyr5wpkgkdiChEmc4FWazLzenNKa/p0jncwDiqcD6BuWePk07t1asatZGoYQzSqA4nFJ7soNiP/+EUyfc25GI2GG53dHPrKo1g/1Cw4pIXLrzO+1c+/wg7tBbFDle/EbQcjFCPWQJCau5EoBoFpzXHYDwFNJcDiCaBed1ByA8hTSXA4hmwXndAQhPIc3lAKJZcF53AMJTSHM5gGgWnNcdgPAU0lwOIJoF53UHIDyFNJcfSiCdnZ0Ui8U0SxlMd7lcjubn561gh+Y1scFIU/0o/3sgeLO12E2k7UXKYumgFoAYdg8ACIAYpoBh6cAhAGKYAoalA4cAiGEKGJYOHAIghilgWDpwCIAYpoBh6cAhAGKYAoalA4cAiGEKGJYOHAIghilgWDpwCIAYpoBh6ZQ4JB6PKzviYthnNy4d9h+1M5mMlVckkUjsG5dhiBMCEMPg/wuOfrZZ/RSywQAAAABJRU5ErkJggg==",
  la =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAB4AAAAVnCAYAAACzfHDVAAAAYHpUWHRSYXcgcHJvZmlsZSB0eXBlIGV4aWYAAHjaVcjJDYAwDEXBu6ughBfH+YnLQSwSHVA+Yrkwx7HtPHabHuEWrQ+lBBAZ6TMweBWoCwUH8quZH6VWFXVT696zxp12ARkVFEqn8wB8AAAACXBIWXMAAC4jAAAuIwF4pT92AADZLklEQVR42uzdd5hV9Z0/8M+dmcsUZmDovYOhKCiKYhR7JJuoSTCWGFI0WUxijBoTTXazVlyza4maYm9rTRSJigVsqCDNQhHBAogKCEgRMjMMU+7vj93sL8kqClLmnPt6PY+PeXZM9vP9vO8jZ+Y955xMfJLjorBrRMuSgmiViyjN1Ee2oSCyucbIBAAAAAAAAADbXaYgcoWNUZcrirpMbdRsysa69wbF+rggGrf439vSF7seF12aFUTnxvoosGIAAAAAAACAXacgoqEgF++/VRgr4r5o+Kh/pvD//F8uiII+LaPrum/EXzqui2b1ddHGKgEAAAAAAAB2rVxEQWMmWrQtjHZlA6N2w2tR84//zP8pgHu3ib6NBdG+zdqorK6KVUXZaB85j3sGAAAAAAAAaAoaG6OwIBdtyneP2PBabPzbr/1dAdx3VHRtyESHiIhcYzQrLo7WmVzkcjmPgAYAAAAAAABoSgpy0eIfS+D/LYD7fy3abC6Inn/7X2hsjELlLwAAAAAAAEDT9D8lcM1fHwddFBFxyAVR9M686PVp/gfqayKiJiLqLBMAAAAAAABgh8hGRGlEUekn/6PFEb3ikNgQk6O+KCJi6dzoksv83/cB/1X9xoiaJdmoWxlRV1dk2QAAAAAAAAA7QTZbH9muERX96v7n9t7/q6Exinq3i86LI94pjOOisHUu+uYykfmof7h+Y8Sa6aVRt74gGhs9DRoAAAAAAABgZ2lsLIi69QWxeUUmSjs0/vedwR8hk4uydSfE+wVd6qOyMfMx7/mtj9jwUtbjngEAAAAAAAB2obrqolg7IxtR/9Ffb4wo7P5GtCwobRaVH/c/UvNmNuqqPfIZAAAAAAAAYFerqy6KmjezH/v1ktpoVZBr/PgCeMN7yl8AAAAAAACApmJLHW5jUVQWNDSP+Q3ZeLco4i9/+8X6teHRzwAAAAAAAABNSd3/dLn/oLAoqqIuVhXFxhhSGB/xqGjlLwAAAAAAAECTU1eTjaK/KXSLIv7SWB+bc5ko9YxnAAAAAAAAgATJFv393bz1EeV//c8F1gMAAAAAAACQDgpgAAAAAAAAgJRQAAMAAAAAAACkhAIYAAAAAAAAICUUwAAAAAAAAAApoQAGAAAAAAAASAkFMAAAAAAAAEBKKIABAAAAAAAAUkIBDAAAAAAAAJASCmAAAAAAAACAlFAAAwAAAAAAAKSEAhgAAAAAAAAgJRTAAAAAAAAAACmhAAYAAAAAAABICQUwAAAAAAAAQEoogAEAAAAAAABSQgEMAAAAAAAAkBIKYAAAAAAAAICUUAADAAAAAAAApIQCGAAAAAAAACAlFMAAAAAAAAAAKaEABgAAAAAAAEgJBTAAAAAAAABASiiAAQAAAAAAAFJCAQwAAAAAAACQEgpgAAAAAAAAgJRQAAMAAAAAAACkhAIYAAAAAAAAICUUwAAAAAAAAAApoQAGAAAAAAAASAkFMAAAAAAAAEBKKIABAAAAAAAAUkIBDAAAAAAAAJASCmAAAAAAAACAlFAAAwAAAAAAAKSEAhgAAAAAAAAgJRTAAAAAAAAAACmhAAYAAAAAAABICQUwAAAAAAAAQEoogAEAAAAAAABSQgEMAAAAAAAAkBIKYAAAAAAAAICUUAADAAAAAAAApIQCGAAAAAAAACAlFMAAAAAAAAAAKaEABgAAAAAAAEgJBTAAAAAAAABASiiAAQAAAAAAAFJCAQwAAAAAAACQEgpgAAAAAAAAgJRQAAMAAAAAAACkhAIYAAAAAAAAICUUwAAAAAAAAAApoQAGAAAAAAAASAkFMAAAAAAAAEBKKIABAAAAAAAAUkIBDAAAAAAAAJASCmAAAAAAAACAlFAAAwAAAAAAAKSEAhgAAAAAAAAgJRTAAAAAAAAAACmhAAYAAAAAAABICQUwAAAAAAAAQEoogAEAAAAAAABSQgEMAAAAAAAAkBIKYAAAAAAAAICUUAADAAAAAAAApIQCGAAAAAAAACAlFMAAAAAAAAAAKaEABgAAAAAAAEgJBTAAAAAAAABASiiAAQAAAAAAAFJCAQwAAAAAAACQEgpgAAAAAAAAgJRQAAMAAAAAAACkhAIYAAAAAAAAICUUwAAAAAAAAAApoQAGAAAAAAAASAkFMAAAAAAAAEBKKIABAAAAAAAAUkIBDAAAAAAAAJASCmAAAAAAAACAlFAAAwAAAAAAAKSEAhgAAAAAAAAgJRTAAAAAAAAAACmhAAYAAAAAAABICQUwAAAAAAAAQEoogAEAAAAAAABSQgEMAAAAAAAAkBIKYAAAAAAAAICUUAADAAAAAAAApIQCGAAAAAAAACAlFMAAAAAAAAAAKaEABgAAAAAAAEgJBTAAAAAAAABASiiAAQAAAAAAAFJCAQwAAAAAAACQEgpgAAAAAAAAgJRQAAMAAAAAAACkhAIYAAAAAAAAICUUwAAAAAAAAAApoQAGAAAAAAAASAkFMAAAAAAAAEBKKIABAAAAAAAAUkIBDAAAAAAAAJASCmAAAAAAAACAlFAAAwAAAAAAAKSEAhgAAAAAAAAgJRTAAAAAAAAAACmhAAYAAAAAAABICQUwAAAAAAAAQEoogAEAAAAAAABSQgEMAAAAAAAAkBIKYAAAAAAAAICUUAADAAAAAAAApIQCGAAAAAAAACAlFMAAAAAAAAAAKaEABgAAAAAAAEgJBTAAAAAAAABASiiAAQAAAAAAAFJCAQwAAAAAAACQEgpgAAAAAAAAgJRQAAMAAAAAAACkhAIYAAAAAAAAICUUwAAAAAAAAAApoQAGAAAAAAAASAkFMAAAAAAAAEBKKIABAAAAAAAAUkIBDAAAAAAAAJASCmAAAAAAAACAlFAAAwAAAAAAAKSEAhgAAAAAAAAgJRTAAAAAAAAAACmhAAYAAAAAAABICQUwAAAAAAAAQEoogAEAAAAAAABSQgEMAAAAAAAAkBIKYAAAAAAAAICUUAADAAAAAAAApIQCGAAAAAAAACAlFMAAAAAAAAAAKaEABgAAAAAAAEgJBTAAAAAAAABASiiAAQAAAAAAAFJCAQwAAAAAAACQEgpgAAAAAAAAgJRQAAMAAAAAAACkhAIYAAAAAAAAICUUwAAAAAAAAAApoQAGAAAAAAAASAkFMAAAAAAAAEBKKIABAAAAAAAAUkIBDAAAAAAAAJASCmAAAAAAAACAlFAAAwAAAAAAAKSEAhgAAAAAAAAgJRTAAAAAAAAAACmhAAYAAAAAAABICQUwAAAAAAAAQEoogAEAAAAAAABSQgEMAAAAAAAAkBIKYAAAAAAAAICUUAADAAAAAAAApIQCGAAAAAAAACAlFMAAAAAAAAAAKaEABgAAAAAAAEgJBTAAAAAAAABASiiAAQAAAAAAAFJCAQwAAAAAAACQEgpgAAAAAAAAgJRQAAMAAAAAAACkhAIYAAAAAAAAICUUwAAAAAAAAAApoQAGAAAAAAAASAkFMAAAAAAAAEBKKIABAAAAAAAAUkIBDAAAAAAAAJASCmAAAAAAAACAlFAAAwAAAAAAAKSEAhgAAAAAAAAgJRTAAAAAAAAAACmhAAYAAAAAAABICQUwAAAAAAAAQEoogAEAAAAAAABSQgEMAAAAAAAAkBIKYAAAAAAAAICUUAADAAAAAAAApIQCGAAAAAAAACAlFMAAAAAAAAAAKaEABgAAAAAAAEgJBTAAAAAAAABASiiAAQAAAAAAAFJCAQwAAAAAAACQEgpgAAAAAAAAgJRQAAMAAAAAAACkhAIYAAAAAAAAICUUwAAAAAAAAAApoQAGAAAAAAAASAkFMAAAAAAAAEBKKIABAAAAAAAAUkIBDAAAAAAAAJASCmAAAAAAAACAlFAAAwAAAAAAAKSEAhgAAAAAAAAgJRTAAAAAAAAAACmhAAYAAAAAAABICQUwAAAAAAAAQEoogAEAAAAAAABSQgEMAAAAAAAAkBIKYAAAAAAAAICUUAADAAAAAAAApIQCGAAAAAAAACAlFMAAAAAAAAAAKaEABgAAAAAAAEgJBTAAAAAAAABASiiAAQAAAAAAAFJCAQwAAAAAAACQEgpgAAAAAAAAgJRQAAMAAAAAAACkhAIYAAAAAAAAICUUwAAAAAAAAAApoQAGAAAAAAAASAkFMAAAAAAAAEBKKIABAAAAAAAAUkIBDAAAAAAAAJASCmAAAAAAAACAlFAAAwAAAAAAAKSEAhgAAAAAAAAgJRTAAAAAAAAAACmhAAYAAAAAAABICQUwAAAAAAAAQEoogAEAAAAAAABSQgEMAAAAAAAAkBIKYAAAAAAAAICUUAADAAAAAAAApIQCGAAAAAAAACAlFMAAAAAAAAAAKaEABgAAAAAAAEgJBTAAAAAAAABASiiAAQAAAAAAAFJCAQwAAAAAAACQEgpgAAAAAAAAgJRQAAMAAAAAAACkhAIYAAAAAAAAICUUwAAAAAAAAAApoQAGAAAAAAAASAkFMAAAAAAAAEBKKIABAAAAAAAAUkIBDAAAAAAAAJASCmAAAAAAAACAlFAAAwAAAAAAAKSEAhgAAAAAAAAgJRTAAAAAAAAAACmhAAYAAAAAAABICQUwAAAAAAAAQEoogAEAAAAAAABSQgEMAAAAAAAAkBIKYAAAAAAAAICUUAADAAAAAAAApIQCGAAAAAAAACAlFMAAAAAAAAAAKaEABgAAAAAAAEgJBTAAAAAAAABASiiAAQAAAAAAAFJCAQwAAAAAAACQEgpgAAAAAAAAgJRQAAMAAAAAAACkhAIYAAAAAAAAICUUwAAAAAAAAAApoQAGAAAAAAAASAkFMAAAAAAAAEBKKIABAAAAAAAAUkIBDAAAAAAAAJASCmAAAAAAAACAlFAAAwAAAAAAAKSEAhgAAAAAAAAgJRTAAAAAAAAAACmhAAYAAAAAAABICQUwAAAAAAAAQEoogAEAAAAAAABSQgEMAAAAAAAAkBIKYAAAAAAAAICUUAADAAAAAAAApIQCGAAAAAAAACAlFMAAAAAAAAAAKaEABgAAAAAAAEgJBTAAAAAAAABASiiAAQAAAAAAAFJCAQwAAAAAAACQEgpgAAAAAAAAgJRQAAMAAAAAAACkhAIYAAAAAAAAICUUwAAAAAAAAAApoQAGAAAAAAAASAkFMAAAAAAAAEBKKIABAAAAAAAAUkIBDAAAAAAAAJASCmAAAAAAAACAlFAAAwAAAAAAAKREkRUAAACwrUpLSwuGDRvWfMCAAS26du3avKysrLiioqKkZcuWzZs1a1bcvHnz0tLS0rJsNtusuLi4ebNmzUoLCgo+8/eijY2N9Zs3b66pra2tqqur21xTU1NdVVVVs2nTptqNGzdWbdiwoeYvf/nL5hUrVlQtWLBgw6xZs6pqamoaJQYAAEDaKYABAACIiIghQ4aUHnTQQW379u3bql27dq3at2/fpkWLFq2bN29eWVpa2qpZs2bNCwsLm2ez2fLCwsLyoqKi8sLCwtKknK+hoaG6vr6+qqGh4S91dXV/aWhoqNq8eXNVTU3NuqqqqvUbNmxYu2rVqjWrV69e99Zbb6177rnnPpgzZ06NTwYAAABJogAGAADIA8OGDWt+xBFHdBwwYECnLl26dGjdunXHFi1adCgtLe1YUlLSvlmzZq0KCgqK07yDwsLCssLCwrKIaPdp/zuNjY21mzdvXrdp06ZVNTU172/YsGHl2rVr31+2bNnKBQsWrHjyySffnzVrVpVPGAAAAE1Fpuexsd9HfaF+ZcSal0ptCAAAIAE6deqUPf744zvtueeeXbp3796lbdu2XSorKzuXlpZ2KS0t7VBYWFhhSztGQ0PDxpqampU1NTXL169fv+yDDz5Y9s477yybPXv2sj/96U8rVqxYUWdLAAAAbE9t9q6Jog4f/TUFMAAAQEJks9nMt7/97Y4jRozo1bdv397t2rXrXl5e3rWsrKxzcXFx+4gosKUmp7G2tnZVTU3Nso0bNy5btWrV0tdff/2tJ598cvG999672noAAADYFgpgAACAhPne977X6a9Fb/v27Xu1bNmyV1lZWa8kvXOXLauvr9/wl7/8ZdG6desWL1u2bNHChQsX/fGPf1w8derUjbYDAADAliiAAQAAmqhsNps59dRTuxx66KH9+/Tp87n27dv3Ly8v719UVOSRzXlq06ZNKzZu3Pj6+++//8abb775xqOPPvrG3XffvcpmAAAA+CsFMAAAQBNx6qmndvniF784qHfv3v3btWv3uYqKis8VFhaW2wxbUl9fv37Dhg1vfPDBB68vXrz4jccee2z+jTfeuNxmAAAA8pMCGAAAYBc45phjWn/rW9/aq3///kPatGnTv6Kiop9HOLO9NDQ0VG/cuPGtNWvWLFy4cOGcO+6445WHHnporc0AAACknwIYAABgJzjjjDO6f+lLX9qrV69eg1u3bj2orKysR0RkbIadJFddXb103bp18xcvXjz30UcffeXqq69+x1oAAADSRwEMAACwnZWWlhb86le/2u3QQw8d1r17931btmw5qLCwsMxmaEoaGhqqP/zww/nvvPPOzGeeeWbW2LFj36ipqWm0GQAAgGRTAAMAAGwHP/7xj7t+9atf3bdXr15D27Ztu1c2m21jKyRJXV3dmg8++OCVRYsWvfznP/95xh/+8IdltgIAAJA8CmAAAIBtcOKJJ7Y75ZRTDujXr9+w1q1bD81ms61shTSpq6tbt3bt2pfffPPNWbfccsvUe++9d7WtAAAANH0KYAAAgE+hoqKi4IILLhg0YsSI/bp27bpfy5YtB2YymUKbIR/kcrmGDz/8cP6777474/nnn59x4YUXvrZx40aPiwYAAGiCFMAAAAAf4/jjj2/7/e9//8D+/fsf2Lp1630KCgpKbAUiGhsbN61fv37eW2+9NeWGG2545u67715lKwAAAE2DAhgAAOB/ZLPZzAUXXPC5I4888sDu3bsfWFFRsVtEFNgMbFl1dfWSd999d8qsWbNmnnvuuS+vW7euwVYAAAB2DQUwAACQ10pLSwsuvfTSQYcccsjBXbt2HVFWVtbDVmDb1dbWrnr//fdfmDp16uRf/vKXL65evbreVgAAAHYeBTAAAJB3Bg0aVHrBBRd8fs899zywQ4cOBxQVFbWwFdj+Ghsba9euXTtrzpw5T59//vmTX3755WpbAQAA2LEUwAAAQF4YNmxY8/POO+/gIUOGHOZ9vrDz/W0ZfNFFFz07a9asKlsBAADY/hTAAABAarVq1arwyiuv3HfEiBEjO3TocFBhYWGZrcCu19DQUP3+++8/O2XKlIk/+clPZm7cuLHRVgAAALYPBTAAAJAqrVq1Kvztb3+7/3777Xd4x44dRxQWFpbbCjRdDQ0NG99///0pM2bMeOqHP/zhC8pgAACAz0YBDAAApMJZZ53V45vf/OaRvXr1GllaWtrVRiB5ampq3l28ePHEO++8c9LVV1/9jo0AAABsPQUwAACQWMOHDy+/6KKLvjB48OCjW7RoMdBGID0+/PDDV+fNmzfhvPPOe3L69Ol/sREAAIBPRwEMAAAkSqtWrQpvuOGGQ/bbb79/atOmzX6ZTCZrK5BeuVyubs2aNTNmzJjx2JgxYyavW7euwVYAAAA+ngIYAABIhB//+Mddv/e9732lZ8+e/1RcXNzWRiD/1NbWfvD2228/dssttzz029/+9l0bAQAA+L8UwAAAQJNVUVFRcO21137+4IMPPrZ169b7ZTKZAlsBIqJxzZo1M59//vnxp5122hR3BQMAAPx/CmAAAKDJOeWUUzqefvrpx/bu3ftL2Wy2jY0AH6e+vn7j0qVLH/vd7373x+uvv36ZjQAAAPlOAQwAADQJ2Ww2c+uttx5wyCGHnNC6deu9I8LdvsDWaFy7du1L06ZN+/OPfvSjZ1evXl1vJQAAQD5SAAMAALtU//79S6655pp/2nPPPY8tLy/vayPAZ1VTU7NswYIF488999wHp06dutFGAACAfKIABgAAdomf//znPU855ZQTu3btemRhYWGZjQDbW2NjY92KFSuevOWWW+689NJLF9kIAACQDxTAAADATuMxz8Cusn79+rlPP/30f5188slT6+rqcjYCAACklQIYAADY4fr27Vv8hz/84a+Pee5nI8CuUlNT8+68efPu/8EPfvDgwoULN9kIAACQNgpgAABghxkyZEjpNddc89XBgwefWFxc3MFGgKaitrZ21dy5c+/5yU9+8uc5c+bU2AgAAJAWWyqAPYoNAADYJqNHj+4wb968n06ZMuXRYcOGnaH8BZqa4uLi9sOGDTtjypQpj86bN++nJ510UntbAQAA0s4dwAAAwFY599xze33/+9//dufOnY/IZDJZGwGSIpfL1S1fvvzJG2644fbLLrvsbRsBAACSyiOgAQCAz+y8887r+53vfOfbHTt2PDyTyRTaCJBUuVyuYcWKFU/cdNNN//XrX/96sY0AAABJowAGAAC22WWXXTboG9/4xg9at249zDaAtFm7du2su++++9pzzjnnNdsAAACSQgEMAABsNcUvkE8UwQAAQJIogAEAgE9N8Qvks7Vr18665557rvv5z38+3zYAAICmaksFcGHlwOj6UV9orIqoWZG1PQAAyBO/+MUvet9xxx3nHHrooT8pLS3tYiNAPiotLe2y7777HvP973+/X1lZ2ZIpU6assxUAAKCpKetcHwXlH/01BTAAAOS5M844o/u99957zpe//OWflZeX94qIjK0AeS5TXl7e8+CDDx71/e9/v3dEvDVjxowPrQUAAGgqFMAAAMD/ceKJJ7a77777fjJq1Kh/KS8v7xOKX4B/lCkvL+99+OGHj/rWt77VfvXq1Qvnz59fbS0AAMCutqUC2DuAAQAgzwwdOrTs+uuvP6l///4nFRYWltkI20NjY2Ns2rQpqquro6amJurr62PTpk2xefPmqK+vj+rq6qivr4/NmzfHpk2boqGhYZv/fxUWFkZJSUk0a9YsioqKoqysLIqKiqJZs2ZRUlISRUVFUVpa+r9/FRQUCIjtoqGhoeq11167a8yYMffMmTOnxkYAAIBdZUvvAFYAAwBAnujUqVP2nnvuGbXXXnudnM1mK22Ej9PQ0BAbN26MDRs2/J+/Nm7cGBs3boyamprYtGlTbNq0KWpqaqK2trbJnqe4uDhKSkqitLT0f/9eUVERFRUV0aJFi//zV0VFRRQWFvog8LHq6urWvvjii7eceOKJf169enW9jQAAADubAhgAAPLcXXfdddAXv/jF00tLS7vZRn7L5XKxYcOGWLt2baxbty7Wrl37d3+tW7cuNmzYkPd7atGiRbRu3TpatWoVrVu3jjZt2vzvf27dunW0aNHCh4morq5e+sgjj1zzne98Z6ptAAAAO5MCGAAA8tTVV189+MQTTzyzoqJioG3kj8bGxli5cmUsX748Pvjgg1i9evX//n3t2rXR2NhoSZ9RYWFhtGrVKtq1axdt27b937937tw5OnTo4LHTeWbDhg3z77333qvOPPPMebYBAADsDApgAADIM1/72tfaXHrppad27979qIjQRKVUQ0NDrFq1KlasWBHvv//+//595cqVTfqRzGlXXFwcHTp0iI4dO0bnzp2jY8eO0alTp2jXrp1HS6dYLpdrfOeddx76+c9/fv2ECRPW2QgAALAjKYABACBP9OrVq9ldd931jT322OM7hYWFZTaSHh9++GG88847sXTp0njvvfdixYoVsXr16mhoaLCchCgsLIz27dtHp06dolu3btG9e/fo3r27x0mnTENDQ9W8efNu++Y3v/nHJUuWbLYRAABgR1AAAwBAHrjrrrtG/NM//dOZJSUlXWwj2davXx9Lly6Nd955539L3w8//NBiUqqysvJ/y+C//tWqVSuLSbiamppljz322G9Gjx49xTYAAIDtTQEMAAAp9qtf/arPD3/4w5+1atVqL9tIno0bN8aSJUvirbfeikWLFsV7770XmzZtspg8V1JSEl27do0+ffpE3759o3fv3lFeXm4xCbRu3bqXr7322ivGjh27yDYAAIDtRQEMAAApNGjQoNI77rjju7vttttJBQUFWRtJhtWrV8ebb74ZixcvjiVLlsTy5cujsbHRYtiigoKC6Ny5c/Tu3Tt69+4d/fr1i7Zt21pMQjQ2Nta98cYbd33rW9+6ff78+TU2AgAAfFYKYAAASJHS0tKCBx988Jj99tvvn7PZbBsbaboaGhri7bffjrfeeisWLFgQS5YscXcv201FRUX06tUr+vbtG3379o2ePXtGYWGhxTRhdXV1a2bMmHHjV77ylYdqamr85gcAALDNFMAAAJASp59+erdf/vKX51ZWVu5jG03T6tWr47XXXouFCxfGm2++GRs3brQUdooWLVpE3759Y8CAATFw4EB3CDdh69evf/E//uM//vPqq69+xzYAAIBtoQAGAICEGzRoUOm99977w969ex+byWTc4teErF+/PubNmxcLFiyIN954Q+FLk9GiRYvo169fDBgwIPbYY4+orKy0lCYkl8s1LF68eNyJJ554rcdCAwAAW0sBDAAACXbNNdcMOemkk35RVlbWyzZ2vVwuF++++27MnTs3XnvttViyZIl3+NLkFRQURK9evWLQoEExePDg6Natm6U0EdXV1UvuvvvuX//kJz+ZYxsAAMCnpQAGAIAEOuqoo1r99re//VmHDh0Ot41da9OmTTF79uyYO3duLFy4MKqqqiyFRGvevHn0798/Bg8eHHvuuWeUlJRYyi62cuXKp04//fTLJ0yYsM42AACAT6IABgCAhBk3btwRRxxxxFnZbLaNbewaVVVVMXfu3Jg7d27Mnz8/amtrLYVUKi4ujoEDB8bgwYNj8ODBUV5ebim7SF1d3ZqnnnrqqlGjRj1hGwAAwJYogAEAICFOOeWUjhdddNEvW7duvZ9t7HwrV66MWbNmxdy5c+Odd96JXC5nKeSdzp07x9577x3Dhg2LDh06WMgusHbt2hnnnXfepbfccsv7tgEAAHwUBTAAADRxpaWlBU899dQ3Bw8e/L2CggLPYt2JVqxYES+99FK89NJLsXz5cguBv/HXMnjvvfeOTp06WchO1NjYuGnu3Lk3H3744XfV1NR40TgAAPB3FMAAANCEjR49usOll176yzZt2gy3jZ1j/fr18eKLL8bMmTNj6dKlFgKfQs+ePWPfffeNYcOGRYsWLSxkJ1mzZs0L55577q/vvvvuVbYBAAD8lQIYAACaoIqKioKJEyd+c/Dgwd8vKCgotpEda8OGDfHiiy/G9OnTlb7wGfXo0SOGDx8ew4YNi4qKCgvZwdwNDAAA/CMFMAAANDGnnHJKx7Fjx/5rZWXlMNvYcerr6+PVV1+NGTNmxLx586Kurs5SYDvKZrMxZMiQ2HfffWP33XePwsJCS9mB1q5dO+MXv/jFv995550rbQMAAPKbAhgAAJqIbDabeeKJJ47fZ599fuSu3x0jl8vFwoULY/r06TF79uzYtGmTpcBOUFpaGkOGDInhw4fHgAEDLGQHaWhoqJ42bdo1Rx555J9tAwAA8pcCGAAAmoDjjz++7ZVXXvmr1q1be9fvDrBmzZqYNm1azJw5M1audHMc7EodO3aMz3/+87H//vt7X/CO+3fetDPPPPOScePGfWAbAACQfxTAAACwi9100037HXvssf9WXFzc1ja2n1wuF6+99lo8//zzMW/evKivr7cUaEKKiopizz33jBEjRsTnPve5yGQylrId1dbWrvrjH/948Q9+8INZtgEAAPlFAQwAALvIkCFDSu+///5zunTp8k+2sf2sXbs2Jk+eHNOnT48PP/zQQiABKisrY8SIEXHIIYdEeXm5hWxHy5Yte+zrX//6f86ZM6fGNgAAID9sqQAurBwYXT/qC41VETUrsrYHAADb6IILLtjt97///VVt2rQZZhvbx+LFi2P8+PFx9913xxtvvBG1tbWWAgmxadOmeOONN+LZZ5+NtWvXRps2bTweejtp0aJFv5NOOumg0tLSuc8+++xaGwEAgPQr61wfBR/zu7XuAAYAgO0sm81mJk2a9PVhw4b9pKCgwG9VfkZ1dXUxY8aMeOaZZ+K9996zEEiRfv36xSGHHBJDhw6NgoICC/mMGhsbN8+YMeOaL37xi+Pq6upyNgIAAOnlEdAAALCTHH/88W2vuuqqCyorK/exjc9mzZo18dRTT8XUqVNj06ZNFgIpVlFREZ///OfjsMMOi8rKSgv5jNavXz/r9NNPv3DcuHEf2AYAAKSTAhgAAHaC22677fNf+9rXzstms5W2se0WLVoUjz/+eMybNy9yOTewQT4pKiqKIUOGxBFHHBG9e/e2kM+grq5u3QMPPHDRySefPM02AAAgfRTAAACwA1VUVBQ8/fTTpwwcOPCUTCbjGabbIJfLxauvvhpPPvlkLFy40EIgz2UymRgwYEAcccQRMWjQIAvZ9n+3Ns6fP/+Www8//JaNGzc22ggAAKTHlgrgwsqB0fWjvtBYFVGzwuvKAABgS0488cR2EyZMuLx79+5fzmQyGRvZOo2NjTFr1qy49dZb48knn4wPPvC0UuC/rV69OmbMmBFz5syJ0tLS6NSpU/jX7NbJZDKZ9u3bD/3+978/dPny5TNfffXValsBAIB0KOtcHwXlH/O9gDuAAQBg29x66637H3vssRcWFRW1sI2tU1NTE0899VQ8++yzsWHDBgsBPlGLFi3i4IMPjsMPPzxKS/28YmvV19d/OG7cuPNPPvnk6bYBAADJ5xHQAACwHWWz2cyzzz77rSFDhvzAI5+3zqZNm2Ly5Mnx1FNPKX6BbdKiRYs47LDD4pBDDlEEb6VcLtfwyiuvXHfooYfeWVdX5yXrAACQYApgAADYTo455pjW11133cWVlZV728ant2HDhnj88cdjypQpUVtbayHAZ1ZcXBwHHnhgfPGLX4wWLTyIYWusWbNm2re//e3zn3nmGb+JAwAACeUdwAAAsB1cfvnlu1900UW/LS8v72cbn05VVVVMmDAhbrnllnjzzTejoaHBUoDtoqGhIZYsWRLPPfdc1NTURI8ePSKb9XOMT6OsrKzb17/+9SPbtm0774knnlhtIwAAkMDreu8ABgCAz+bhhx/+8qGHHnpOQUFBsW18sk2bNsUzzzwTTzzxRFRVVVkIsMOVl5fHkUceGYccckgUF/tX9afR2Ni46emnn/71Mccc87htAABAsngENAAAbKN27doVTZ48+YxevXodZxufrK6uLp5++umYOHGi4hfYJSoqKuKLX/xiHHzwwe4I/pQWLVr0x4MOOuiadevWeUwDAAAkhEdAAwDANjj22GPbPvzww7/p2LHjobaxZXV1dfHkk0/GddddF3Pnzo26ujpLAXaJzZs3x2uvvRbPPfdcRET06NEjCgsLLWYLWrduvfv3vve9fd9+++1pCxYsqLYRAABo+rb0CGgFMAAAfITLL7989wsuuOB3zZs372UbH6+xsTGmTJkS119/fbzyyiuKX6DJ2Lx5cyxYsCCmT58excXF0a1bt8hkMhbzMUpKSjp8+ctfPrJt27ZzvBcYAACaPu8ABgCArTB+/Pgjv/CFL/xLQUFBiW18vAULFsT48eNj6dKllgE0eT169IivfOUrMWjQIMvYgsbGxpqJEydecuyxxz5pGwAA0HR5BzAAAHwK7dq1K3ruued+1qNHj6/axsdbtGhR3H///bF48WLLABKnV69ecdxxx0WfPn0sYwuWLl3654MOOujy1atX19sGAAA0Pd4BDAAAn2DYsGHNn3766V936tTpC7bx0TZs2BD33Xdf/PGPf4y1a9daCJBI69evj2nTpsW6deuiZ8+eUVLiYQ8fpbKysv+3v/3t/lOmTJmyfPlyz/cHAIAmxjuAAQBgC372s5/1uP76669t0aKF54J+hJqamhg/fnzcfPPN8fbbb0cul7MUINFyuVy888478cwzz0RVVVX07t07slk/A/lHZWVl3U488cTD6+rqZkyfPv1DGwEAgCZ0va4ABgCAj3bFFVfscdZZZ11dXFzcwTb+Xi6XixkzZsR1110XCxYsiMbGRksBUqWxsTGWLFkSM2bMiPLy8ujSpUtkMhmL+RvZbLbFQQcddHibNm1mP/HEE6ttBAAAmoYtFcDeAQwAQN6aNGnSqAMOOODsTCZTaBt/b9GiRXHPPffEu+++axlA3ujWrVucdNJJ0bt3b8v4B7lcrm7y5Mm//vKXv/yIbQAAwK63pXcAK4ABAMg7paWlBTNnzjyzT58+x9vG39uwYUOMGzcuZsyY4VHPQF7KZDKx3377xde//vWoqKiwkH+waNGiP+27775X1dTUeCwEAADsQgpgAAD4H926dctOnjz5V506dRppG/9fLpeLqVOnxp///OfYuHGjhQB5r6KiIkaNGhX777+/x0L/g+XLlz9+6KGHXvLuu+/W2QYAAOwaWyqAvQMYAIC8MXz48PInnnjiynbt2o2wjf/vnXfeiWuvvTaee+652Lx5s4UARMTmzZtjzpw58dprr0XPnj2jRYsWlvI/Kioq+n7rW98aMnXq1Ofee+89f3AAAMAusKV3ACuAAQDIC9/+9rc73n777X9o0aLFANv4b1VVVXHXXXfFvffeG+vXr7cQgI+wbt26eP7552P9+vWx2267RVFRkaVERElJSefjjjvuoA8++GDKK6+88hcbAQCAnUsBDABAXjv//PP7XXzxxX8oKSnpbBv/bfr06XHttdfGokWLLAPgU3jnnXdi2rRp0bp16+jc2R8nERHZbLbyC1/4whElJSUvTp48eY2NAADAzqMABgAgb/3ud7/b60c/+tFVRUVFrWwjYs2aNXHzzTfHpEmTora21kIAtkJtbW289NJL8c4770Tfvn2jtLQ073dSWFhYNnz48C/26dNn4UMPPbTMpwQAAHYOBTAAAHnp1ltv3f+b3/zmfxYWFjbP913kcrl4/vnn4/rrr4/ly5f7cAB8BitXroxp06ZFRUVFdOvWLTKZTF7vo6CgIDto0KBDBw0atOiBBx54xycEAAB2vC0VwJmex8Z+H/WF+pURa17ym6wAACTTww8//KXDDjvsXzKZTN6/rPGDDz6I22+/Pd544w0fDIDtbMCAAfGtb30r2rRpk/e7yOVyjVOmTPn1yJEjH/LJAACAHavN3jVR1OGjv6YABgAgdV555ZXTPve5z30r3/fQ0NAQjz32WDz++ONRV1fngwGwg2Sz2Tj66KPjC1/4QhQUFOT9Pl5//fU79tprr9/7ZAAAwI6jAAYAIC9ks9nMyy+/fFafPn2Oz/ddvPvuu3HbbbfFe++954MBsJN069YtvvOd70S3bt3yfhdLliy5f5999rmypqam0ScDAAC2PwUwAACpV1paWjBr1qyzevfufVw+7yGXy8WTTz4ZDz74oLt+AXaBbDYbxxxzTBxxxBF5fzfw0qVLHxg6dOjlSmAAANj+FMAAAKRar169mk2ePHlsu3btDsrnPaxcuTJuueWWePvtt30oAHaxnj17ximnnBIdOnTI6z2sXr16yiGHHPIvS5Ys2exTAQAA28+WCuDCyoHR9aO+0FgVUbMia3sAADRpQ4cOLXvqqacub9Omzf75uoNcLhfPPPNMXH/99bF27VofCoAmYP369TFlypQoKSmJnj17RiaTycs9NG/evPtJJ500ZPLkyc+sWLHCoykAAGA7KetcHwXlH/01BTAAAIk1ZMiQ0kceeeSKVq1a7Z2vO6iuro7bb789nnjiiWhs9IRNgKaksbEx5s+fH++//34MGDAgstn8/DlLaWlpp6997WuDn3rqqadXrlxZ75MBAACfnQIYAIDUOfTQQ1s8+OCDv2/ZsuUe+bqDOXPmxNVXX+2RzwBN3PLly+OFF16Ijh075u0joUtLSzudcMIJ+7/00ktPv/3227U+FQAA8NkogAEASJVhw4Y1v++++37TsmXLQfl4/vr6+hg/fnz88Y9/jNpaP0MHSILNmzfHiy++GJs3b47ddtstCgoK8m4HxcXFbY866qg9n3vuuaeXL1/ucdAAAPAZKIABAEiNI488snLcuHG/b9GixcB8PP97770XV111VcyZM8eHASCBFi1aFC+//HL069cvWrRokXfnLykp6XDcccftP2fOnGcWLVq0yScCAAC2jQIYAIBUOPLIIyvvvPPO35aXl++Wj+d/+umn48Ybb4wPP/zQhwEgwf7yl7/ECy+8ECUlJdGrV6+8O3+zZs3aHHXUUfspgQEAYNspgAEASLxjjz227W233faH5s2b98m3s1dVVcXNN98cTz31VDQ2NvowAKRAY2NjzJ8/P5YtWxYDBgyIZs2a5dX5mzVr1uaYY4458M0333xm4cKFNT4RAACwdRTAAAAk2qGHHtritttuuzofy9+33347rrnmmli8eLEPAkAKvf/++/HKK69Enz59orKyMq/Ons1mK4888sh9Zs6c+dTSpUs3+zQAAMCnpwAGACCxjjjiiJb33nvvteXl5f3y6dy5XC4mTZoUN998c1RVVfkgAKRYVVVVTJ06NbLZbPTp0ycymUzenL24uLjtV7/61c+/8sorTy1evLjWpwEAAD4dBTAAAIl06KGHtrj33nt/l2/lb3V1ddx0000xefLkyOVyPggAeSCXy8WCBQvi3Xffjd133z2y2fz5mUyzZs1aH3300fvNmDHjSXcCAwDAp6MABgAgcYYOHVo2fvz4qysqKgbk07mXLVsWV111lUc+A+SplStXxiuvvBKf+9znoqKiIm/O3axZszZHH3300GeeeebJFStW1PkkAADAlimAAQBIlCFDhpQ++uij17Rs2XL3fDr31KlT49prr42NGzf6EADksaqqqpg+fXq0bds2unTpkjfnLikpaT9q1KihTz755JMrV66s90kAAICPt6UCuMB6AABoSjp16pSdMGHCv1dWVu6RL2dubGyMcePGxR133BF1dW56AiCitrY2br755hg/fnw0NjbmzbkrKyv3mDBhwr9369bNXQkAALCNFMAAADQZrVq1Kpw+ffolbdq02T9fzlxdXR2/+93vYtKkSd73C8DfyeVy8fjjj8fvf//7qK6uzptzt2nTZv8pU6Zc0qpVq0KfAgAA2HoKYAAAmoSKioqC2bNnX9KuXbuD8uXMS5cujYsuuijmz5/vAwDAx3r11VfjoosuiqVLl+bNmdu1a3fQ7Nmz/72iosLPrgAAYCu5iAYAoEmYOXPmz9q1a3dIvpz35ZdfjiuuuCLWrVsnfAA+0bp16+KKK66Il19+OW/O3K5du4Nnzpz5M+kDAMDWUQADALDLvfjii2N69OgxKh/Omsvl4oEHHogbbrghamtrhQ/Ap1ZbWxs33HBDPPDAA3nz2oAePXqMevHFF8dIHwAAPj0FMAAAu9SkSZO+NnDgwFPy4ax1dXVx8803x8SJE73vF4BtksvlYuLEiXHLLbdEXV1dXpx54MCBJ0+aNOlr0gcAgE9HAQwAwC7z6KOPHnXggQeekw9nXbduXfz617+OWbNmCR6Az2zmzJnx61//Ol9eJZA58MADz3n00UePkjwAAHyywsqB0fWjvtBYFVGzImtDAADsEDfeeOO+Rx999EWZTKYw7Wddvnx5XHXVVbFy5UrBA7DdbNiwIWbPnh0DBw6MioqKtB8307179/179uz56sMPP7xc+gAA5LuyzvVRUP7RX1MAAwCw011xxRV7fPe7372qoKCgWdrPOmfOnPjtb38bGzduFDwA2111dXVMmzYtOnfuHB07dkz1WTOZTOHuu+9+eJs2bV6aNGnSKukDAJDPFMAAADQZZ5xxRvef/exnvy0sLCxP+1knTJgQd999d9TX1wsegB2moaEhXnrppchms9G3b99UnzWTyRTttddeB/3lL395dubMmRukDwBAvlIAAwDQJBx00EEVf/jDH64pLi7ulOZz5nK5eOCBB+Kxxx4TOgA77c+eBQsWRF1dXfTv3z8ymUxqz1pQUFBywAEHDJs+ffqkpUuXbpY+AAD5aEsFcIH1AACwMwwaNKj0vvvuu7qsrKxXms9ZV1cX1113XUyaNEnoAOx0EydOjOuvvz7q6upSfc6ysrJef/rTn67u379/idQBAODvKYABANjhKioqCh577LGLKyoqBqb5nNXV1XHNNdfE7NmzhQ7ALvPKK6/ElVdeGVVVVak+Z4sWLQZOnDhxbEVFhZ9vAQDA33CBDADADjdz5syftW3b9sA0n3HdunVx2WWXxRtvvCFwAHa5xYsXx2WXXRZr165N9TnbtWt34MyZM38mcQAA+P8UwAAA7FBPPvnkqB49eoxK8xlXrVoVV1xxRSxfvlzgADQZK1asiCuuuCJWrlyZ6nP26NFj1KRJk0ZJHAAA/lth5cDo+lFfaKyKqFmRtSEAALbZjTfeuO+XvvSlCzOZTGp/8fDdd9+NK6+8MtatWydwAJqc6urqmDVrVvTv3z8qKytTe85u3boN79mz57yHH37Yb2MBAJAXyjrXR0H5R39NAQwAwA5x3nnn9T311FOvLigoKE7rGV977bW45pprorq6WuAANFmbN2+OGTNmRI8ePaJ9+/apPGMmkykYNGjQIYWFhVOee+45v5UFAEDqKYABANipjjrqqFb/8R//8YdmzZq1SusZX3755bj++uujrq5O4AA0eQ0NDfHSSy9Fp06dolOnTqk8Y0FBQXbYsGGfnz9//qQ33nhjk9QBAEizLRXA3gEMAMB21a1bt+wNN9zwnyUlJR3TesYpU6bEjTfeGPX19QIHIDHq6+vjxhtvjKlTp6b2jCUlJZ1uuOGG/+jWrZu7GgAAyFsKYAAAtqunn376XyorK/dI6/kmTZoUd955ZzQ2NgobgMRpbGyMO+64I5588snUnrGysnLw008//UtpAwCQrxTAAABsN88///w3unTp8k9pPd/EiRNj3LhxkcvlhA1AYuVyubj//vtTXQJ36dLlS88+++yJ0gYAIB95BzAAANvFTTfdNPzII488L5PJZNJ4vsceeyzGjx8vaABS47XXXotmzZpF3759U3m+zp0779urV695Dz/88DJpAwCQNlt6B7ACGACAz+wXv/hF7x/+8IdXFxQUNEvj+R544IF45JFHBA1A6ixYsCDq6upiwIABqTtbJpPJDBo06ODGxsbnpk6dul7aAACkiQIYAIAd5oADDqj43e9+99tmzZq1TeP5xo0bF5MmTRI0AKm1aNGi2Lx5cwwcODB1ZysoKMjut99+w5577rnH33vvvc3SBgAgLbZUAHsHMAAA2yybzWbuvPPOfyktLe2exvNNmDBB+QtAXpg0aVI89NBDqTxbaWlpj3vuuedfstlsRtIAAOQDBTAAANvs+eef/06HDh0OTePZHn744Xj44YeFDEDeeOSRR+LPf/5zKs/WoUOHw5599tlvSxkAgHygAAYAYJvcd999hw8ePPjUNJ7t/vvvjwkTJggZgLzz2GOPxX333ZfKs+25554/+NOf/nSYlAEASDvvAAYAYKudccYZ3ceMGXN5QUFBcdrONnHixHjkkUeEDEDeWrx4cWSz2ejbt2/ajpbp06fPvn/5y18mz5w5c4OkAQBIsi29A1gBDADAVhk2bFjzG2+88Q/NmjVrl7azPfroo6l99CUAbI2FCxdGUVFR9OvXL1XnKigoKD7wwAP3e/LJJx9dsWJFnaQBAEiqLRXAHgENAMBWuffee39ZWlraPW3nevzxx+PBBx8UMAD8jz//+c8xceLE1J2rtLS0x3333fdLCQMAkFYKYAAAPrVJkyaN6tSp0xEpPFeMHz9ewADwD8aPHx+TJ09O3bk6der0hUmTJn1VwgAApJFHQAMA8Kmcd955fU888cR/z2QyRWk618yZM+Puu+8WMAB8jNdeey06duwYnTt3TtW5unbtuk9BQcHzzz333DopAwCQNN4BDADAZ3LEEUe0vOKKK67NZrOVaTrXyy+/HDfffHPkcjkhA8DHyOVyMXv27OjSpUt06tQpNefKZDJF++yzz/CpU6c+9u67726WNAAASeIdwAAAbLNsNpu55ZZb/q2kpKRjms61YMGCuPnmm6OxsVHIAPAJGhsb4+abb44333wzVecqLS3tcvfdd5+fzWYzUgYAIC0UwAAAbNGkSZO+3rZt2wPTdKZly5bFDTfcEPX19QIGgE+prq4urr322li+fHmqztWuXbsDH3/88VESBgAgLTwCGgCAj3XZZZcN+upXvzo2k8mk5hcH33///bjyyiujqqpKwACwlerq6uLll1+OIUOGRHl5eWrO1aVLl31LS0unPvPMM2ukDABAEngENAAAW61///4lJ5988q8ymUxRWs60YcOG+P3vfx8bN24UMABso40bN8bvfve7VP15WlBQkP3hD394ft++fYslDABA4q9vrQAAgI/y4IMPnl1WVtYrLeeprq6O3/zmN7Fq1SrhAsBntGrVqrjyyiujuro6NWcqKyvr8/DDD58lXQAAkk4BDADA/zF+/Pgju3XrdnRazlNfX5/KdxYCwK60fPnyuO6666K+vj41Z+rRo8dXx40bd4R0AQBIMgUwAAB/53vf+16nI4444py0nCeXy8Vtt90Wb7zxhnABYDt7/fXX47bbbotcLpeaMx155JHnfvvb3+4oXQAAkkoBDADA/6qoqCi4+OKLLywsLCxPy5nGjx8fs2bNEi4A7CCzZs2Khx56KDXnKSwsrPj1r399QUVFhZ+bAQCQSC5kAQD4XxMnThxdWVk5OC3nef7552PixImCBYAd7LHHHosXXnghNeeprKzc89FHHz1RsgAAJFFh5cDo+lFfaKyKqFmRtSEAgDxxwQUX7DZq1KgLM5lMYRrO8+qrr8Ytt9ySqkdSAkBT/7O3d+/e0a5du1Scp2PHjkNzudxzU6ZMWSddAACamrLO9VHwMc/wcwcwAADRt2/f4h//+McXZzKZVPwG4HvvvRc33HBDNDY2ChcAdpKGhoa47rrrYtmyZak4T0FBQfbss88e27dv32LpAgCQqGtZKwAAYPz48T8qKyvrkYazbNiwIX7/+99HbW2tYAFgJ9u0aVP8/ve/j40bN6biPGVlZb3GjRs3RrIAACSJAhgAIM/ddNNNw/v06XN8Gs5SX18f1157baxdu1awALCLrFmzJq699tqor69PxXn69ev3jd///vdDJQsAQFIogAEA8thBBx1Uceyxx/5rRGTScJ477rgjFi9eLFgA2MUWLVoUd955Z1qOU/CNb3zj34YNG9ZcsgAAJOIC1goAAPLXzTfffFZxcXG7NJxl4sSJMX36dKECQBMxbdq0mDRpUirOUlJS0unOO+88Q6oAACSBAhgAIE/913/914FdunT5UhrO8tprr8Wf//xnoQJAEzN+/PhYsGBBKs7SrVu3o2+66abhUgUAoKlTAAMA5KEvfelLlV/5yld+lYazrFixIq6//vpobGwULAA0MY2NjXHdddfFihUr0nCczHHHHfergw46qEKyAAA0ZQpgAIA8dPXVV5+ezWYrk36OmpqauPbaa2PTpk1CBYAmatOmTXHttddGTU1N4s+SzWbb3njjjT+RKgAATZkCGAAgz9x6663Du3Tp8uWknyOXy8Utt9wSK1euFCoANHErV66MW2+9NXK5XOLP4lHQAAA0dQpgAIA8MnTo0LKvfvWrv0jDWSZMmBBz584VKgAkxJw5c+Kxxx5LxVlGjRr1i6FDh5ZJFQCApkgBDACQR+64444fFRcXd0z6OV5++eV45JFHBAoACfPQQw+l4he4SkpKOt5xxx0/lCgAAE2RAhgAIE9cfvnlu/fs2XNU0s/xwQcfxB133JGKR0gCQL7J5XJx2223xZo1axJ/lp49ex57+eWX7y5VAACaGgUwAEAe6NatW/a73/3uv2YymURf/9XX18cNN9wQ1dXVQgWAhKqqqoobb7wx6uvrE32OTCZT8N3vfvdX3bp1y0oVAICmRAEMAJAHxo8ff0pZWVmvpJ/jnnvuiaVLlwoUABJuyZIlcd999yX+HGVlZT3Hjx9/ikQBAGhKFMAAACn385//vOeAAQNGJ/0c06dPjylTpggUAFJi8uTJMWPGjMSfY8CAAaN//vOf95QoAABNhQIYACDFstls5qyzzjo3k8kk+tGEK1asiLvvvlugAJAyd911V6xYsSLRZ8hkMtmzzjrr3Gw2m5EoAABNgQIYACDFxo0b98XKysq9knyG2trauOGGG6K2tlagAJAyf/1zfvPmzYk+R2Vl5V7jxo0bKVEAAJoCBTAAQEoNHz68/OCDDz4t6ee4//77Y/ny5QIFgJRavnx5jBs3LvHnGDFixI+HDRvWXKIAAOxqCmAAgJS69dZbT8tms22TfIYZM2bEc889J0wASLnJkyfHzJkzE32G4uLitrfffvtp0gQAYFdTAAMApNBVV121R48ePb6S5DOsXLky7rrrLmECQJ64++6744MPPkj0GXr27PnVK664Yg9pAgCwKymAAQBSprS0tOAb3/jGT5N8rdfY2Bi333679/4CQB6pqamJ2267LRobG5N8jIJvfvObZ5aWlvqZGwAAu+6i1AoAANJlwoQJX6uoqBiQ5DOMHz8+Fi1aJEwAyDNvvvlmPPjgg4k+Q4sWLQY9+OCDx0gTAIBdRQEMAJAiRx55ZOWwYcN+kOQzzJ07N5544glhAkCemjhxYixYsCDRZxg+fPiPjjjiiJbSBABgV1AAAwCkyBVXXHFyUVFRRVLnr6qqijvvvDNyuZwwASBP5XK5uP3226O6ujqxZygqKmrxm9/85mRpAgCwKyiAAQBS4vzzz+/Xu3fv45J8httvvz0+/PBDYQJAnlu3bl3cfvvtiT5D7969jz///PP7SRMAgJ1NAQwAkALZbDZz6qmn/jyTyST2+m769OkxZ84cYQIAERExe/bsmDFjRmLnz2QyBaeeeurPs9lsRpoAAOxMCmAAgBT44x//eERlZeXgpM6/du3auPfeewUJAPyde+65J9atW5fY+SsrKwf/6U9/+oIkAQDYmRTAAAAJ17dv3+JDDjnkR0k+w9133x01NTXCBAD+Tk1NTdx9992JPsPBBx/8o759+xZLEwCAnUUBDACQcHfdddc3S0pKOiV1/smTJ8e8efMECQB8pLlz58azzz6b2PlLSko63nPPPd+SJAAAO4sCGAAgwb70pS9VDhw48KSkzr9mzZoYP368IAGALXrggQdizZo1iZ2/f//+Jx111FGtJAkAwM6gAAYASLArrrji1MLCwvIkzp7L5eK2226LTZs2CRIA2KJNmzbFbbfdFrlcLpHzFxYWll1++eU/kCQAADuDAhgAIKF+8Ytf9O7evftXkjr/s88+G2+88YYgAYBP5Y033ojnn38+sfN369bt6F/96ld9JAkAwI6mAAYASKgf/vCHP8pkMom8nvvggw/igQceECIAsFXGjRsX69atS+TsmUym4NRTT/2xFAEA2NEUwAAACXTdddcNa9eu3YFJnD2Xy8Udd9wRtbW1ggQAtsqmTZvizjvvTOz8bdq02f+mm27aT5IAAOxICmAAgIQpLS0t+NrXvnZ6Uud/4YUXYuHChYIEALbJq6++GjNmzEjs/Mccc8zpFRUVfiYHAMAO42ITACBhbr/99oMrKip2S+LsGzZsiHHjxgkRAPhM7r///qiqqkrk7OXl5X3/67/+6wgpAgCwoyiAAQASpKKiouCwww47Nanz33vvvYn9YS0A0HRs2LAh7r///sTOf9BBB/1zq1atCiUJAMCOoAAGAEiQ+++//+iysrKeSZx9zpw58dJLLwkRANguXnjhhViwYEEiZy8tLe32xz/+8StSBABgR1AAAwAkRN++fYv33Xfff07i7LW1tXHvvfcKEQDYru6+++6oq6tL5Oz77bffKf379y+RIgAA25sCGAAgIW6++eZRxcXFbZM4+yOPPBJr164VIgCwXa1atSoee+yxRM6ezWbb3njjjV+TIgAA25sCGAAgAYYOHVq21157fSeJs7/33nvxxBNPCBEA2CEmTpwYK1asSOTsQ4YM+c7QoUPLpAgAwPakAAYASIBrr732xKKiosqkzZ3L5eKee+6JxsZGIQIAO0R9fX3cddddkcvlEjd7UVFR5bXXXnuCFAEA2J4UwAAATdwBBxxQMWDAgG8kcfYZM2bEW2+9JUQAYId6880348UXX0zk7AMGDPjG8OHDy6UIAMD2ogAGAGjirrrqqhOKiooqkjb3pk2b4oEHHhAgALBT3H///VFbW5u4uYuKilpcffXV7gIGAGC7UQADADRhBx10UEX//v0Teffvww8/HB9++KEQAYCdYv369TFhwoREzj5w4MBvHHDAARVSBABge1AAAwA0Yf/5n/95bGFhYfOkzb1q1aqYPHmyAAGAnerpp5+O1atXJ27uwsLC8ssuu2yUBAEA2B4UwAAATdQBBxxQMWjQoNFJnP3uu++O+vp6IQIAO1V9fX3cddddiZx99913/+bQoUPLpAgAwGelAAYAaKIuv/zyYwsLC8uTNvfcuXNjwYIFAgQAdokFCxbE3LlzEzd3UVFRi9/97ndflyAAAJ+VAhgAoAkaOnRo2aBBgxL37t+6urr405/+JEAAYJf605/+FHV1dYmbe/fdd//mkCFDSiUIAMBnoQAGAGiCfvOb33ylqKioZdLmfu655xL53j0AIF1Wr14dzz33XOLmLioqann11VcfLUEAAD4LBTAAQBPTq1evZoMHD/5m0uaurq6ORx55RIAAQJPwyCOPRHV1deLmHjJkyLe6deuWlSAAANtKAQwA0MTcdNNNxxQXF7dN2twTJkyIqqoqAQIATUJVVVUifzmtuLi43a233uouYAAAtpkCGACgCWnVqlXhXnvtdVLS5l61alU8++yzAgQAmpTJkyfHqlWrEjf30KFDR7dq1apQggAAbAsFMABAE3LLLbccXlJS0jlpcz/44INRX18vQACgSamvr48HH3wwcXOXlJR0vummmw6VIAAA20IBDADQRGSz2cwBBxzw7aTNvWjRonjppZcECAA0SS+99FIsXrw4cXOPGDHiO9lsNiNBAAC2lgIYAKCJuOaaa/YuLy/vm7S5H3roocjlcgIEAJqkXC6XyLuAy8vL+1111VV7SRAAgK2lAAYAaCK+8pWvfDdpM8+bNy8WLlwoPACgSVu4cGG8+uqrrg8BAMgLCmAAgCbgsssuG1RZWblPkmbO5XIxfvx44QEAifDAAw8k7qklrVu33veSSy7pLz0AALaGAhgAoAkYNWrUCUmbefbs2bFs2TLhAQCJsGzZsnjllVcSN/cJJ5xwovQAANgaCmAAgF3sn//5nzt37NjxiCTN3NjYGA888IDwAIBEGT9+fDQ0NCRq5k6dOn1h9OjRHaQHAMCnpQAGANjFfvSjH30tk8kk6rps2rRpsWrVKuEBAImyatWqeOGFFxI1cyaTKfzpT386SnoAAHxaCmAAgF1o0KBBpX369Plqkmaur6+PCRMmCA8ASKQJEyZEXV1dombu27fvV/r27VssPQAAPg0FMADALnTZZZcdXlRUVJGkmadOnRpr164VHgCQSOvXr48pU6YkauaioqLK3/zmN0dIDwCAT0MBDACwi2Sz2cy+++57UpJmrqurc/cvAJB4jz76aOLuAt5///1PymazGekBAPBJFMAAALvI1VdfPbSsrKx3kmaeMmVKbNiwQXgAQKJt2LAhnn/++UTNXFZW1ueqq67aS3oAAHwSBTAAwC7y5S9/+bgkzVtfXx8TJ04UHACQCo8//nji7gL+0pe+dLzkAAD4JApgAIBdYPTo0R3atm07IkkzT5s2LdatWyc8ACAVPvzww5g+fXqiZm7fvv2I0aNHd5AeAABbogAGANgFfvrTn47KZDKFSZm3vr4+HnnkEcEBAKnyyCOPRH19fWLmzWQyhT/96U+/JjkAALZEAQwAsJN16tQp26dPn6OTNLO7fwGANFq3bl1MmzYtUTP36dPnmE6dOmWlBwDAx1EAAwDsZFddddUB2Wy2dVLmbWxsjEmTJgmOVOvYsWN06OCJmgD5aNKkSdHY2JiYebPZbOurrrrqAMkBAPBxFMAAADvZiBEjvp6keV988cVYtWqV4Ei1Ll26xIUXXhinnXZadO3a1UIA8siqVavipZdecj0JAEBqKIABAHaiM844o3tlZeXeSZk3l8vFxIkTBUdeyGQyMXjw4PjVr34VY8aMcUcwQB55/PHHI5fLJWbeysrKvc8444zukgMA4KMogAEAdqJTTjnlqxGRScq8CxYsiPfee09w5JVMJhN77713XHjhhTFmzJho3769pQCk3HvvvRcLFy5M1B9X/3NdCQAA/4cCGABgJ+nVq1ezXr16fTlJM3v3L/nsr0XwBRdcECeffHK0bdvWUgBSLGnXPb169fpyr169mkkOAIB/pAAGANhJrrjiioOLiopaJmXeBN4JAztEYWFhDB8+PC688MIYPXp0VFZWWgpACi1YsCCWLVuWmHmLiopaXnnllYdIDgCAf6QABgDYSYYPH/6VJM2btHfhwY5WVFQUI0aMiEsuuSRGjx4dLVu2tBSAFMnlcvH4448naub99tvvK5IDAOAfKYABAHaC0aNHd6isrByalHnXrl0bL7/8suDgI/y1CL744ovjhBNOiBYtWlgKQEq89NJLsW7dusTMW1lZudfo0aM7SA4AgL+lAAYA2AlOP/30o5J07fXMM89EQ0OD4GALiouL47DDDouxY8fGqFGjoqyszFIAEq6hoSGeeeaZJI1c8D/XmQAA8P8vEq0AAGDHymazmX79+n05KfPW1tbGlClTBAefUnFxcYwcOTIuvfTSGDVqVJSWlloKQII9//zzUVtbm5h5+/Xr9+VsNpuRHAAAf6UABgDYwX7zm9/sWVJS0jkp886YMSOqq6sFB1uppKQkRo4cGZdcckkcffTRUVJSYikACVRdXR0zZ85M0p8/na+44orBkgMA4K8UwAAAO9gXvvCFLyVl1lwuF08//bTQ4DNo3rx5HHXUUXHJJZfEyJEjI5vNWgpAwjz11FORy+USM++RRx75ZakBAPBXCmAAgB1oyJAhpZ07dz4iKfO+/vrrsWLFCsHBdlBeXh6jRo2KSy+9VBEMkDArVqyI119/PTHzdunS5fD+/ft79AQAABGhAAYA2KHGjh17aGFhYWJeCOruX9j+KioqYtSoUXHxxRfH4YcfHkVFRZYC4LpouyosLGz+H//xHwdLDQCACAUwAMAOteeeex6ZlFnXrl0b8+bNExrsIK1atYrjjz8+LrroohgxYkQUFPh2DKApmzdvXqxZsyYx8+61115HSg0AgAgFMADADnPMMce0bt269b5Jmfe5556LxsZGwcEO1qZNmxg9enRcfPHFimCAJqyxsTGee+65JP35MvyYY45pLTkAAPykAQBgBznzzDMPz2Qyibjeqq+vj6lTpwoNdqK2bdvG6NGj47zzzovhw4crggGaoBdeeCHq6+sTMWsmkyk844wzDpUaAAB+wgAAsIP079//C0mZdc6cObFhwwahwS7QqVOnOPnkk+Pf/u3fYu+9945MJmMpAE3Ehg0bYvbs2YmZd8CAAR4DDQCAAhgAYEf43ve+16mysnKPpMybpMcbQlp17tw5xowZE7/61a8UwQBNyPPPP5+YWSsrKwd/73vf6yQ1AID8pgAGANgBTj755CMiIhHtzcqVK+P1118XGjQRXbt2jTFjxsQ555wTgwcPthCAXez111+PlStXJmXczMknn3y41AAA8psCGABgB+jXr19iHv88ZcqUyOVyQoMmpnfv3nHaaafFOeecE/3797cQgF0kl8vFlClTknQd6jHQAAB5TgEMALCdnX766d0qKip2S8Ks9fX1MW3aNKFBE9anT58466yz4pxzzonddtvNQgB2gWnTpkV9fX0iZq2oqNjt9NNP7yY1AID8pQAGANjORo8efURSZp03b15s3LhRaJAAffr0ibPPPjvOPPPM6Nmzp4UA7EQbN26MefPmuR4FACARFMAAANtZr169EvPetSQ9zhD4bwMGDIhf/vKXceaZZ0b37t0tBGAnmTp1apKuRw+TGABA/lIAAwBsR2eccUb38vLyvkmYdf369fHaa68JDRJqwIAB8S//8i9x2mmnRbdunvQJsKPNnz8/Pvzww0TMWl5e3u9HP/pRF6kBAOQnBTAAwHZ03HHHHZSUWWfMmBGNjY1CgwTLZDIxePDg+Nd//dcYM2ZMdOjQwVIAdpDGxsaYMWNGYub9xje+cYjUAADykwIYAGA76tOnz8FJmDOXyyXqMYbAlmUymdh7773jwgsvjDFjxkT79u0tBWAHeOGFF5J0XXqIxAAA8pMCGABgOznppJPat2zZcvckzLpkyZJYuXKl0CBl/loEX3DBBXHyySdH27ZtLQVgO1qxYkW8/fbbiZi1srJy0PHHH+8PAgCAPKQABgDYTr773e8eGBGZJMyapMcXAluvsLAwhg8fHhdeeGGMHj06KisrLQVgO5k+fXpSRi34/ve/f6DEAADyjwIYAGA72X333Q9Nwpz19fUxc+ZMgUEeKCoqihEjRsQll1wSo0ePjpYtW1oKwGc0c+bMqK+vT8SsAwcOPFRiAAD5RwEMALAdHHTQQRUtW7bcKwmzLly4MKqrq4UGeeSvRfDFF18cJ5xwQrRo0cJSALZRVVVVvP7664mYtVWrVkOHDx9eLjUAgPyiAAYA2A7OPvvsz2cymaIkzOrxz5C/iouL47DDDouxY8fGqFGjoqyszFIAtkFSnqaSyWSy55577uclBgCQXxTAAADbwe67735AEuasra2NOXPmCAzyXHFxcYwcOTIuvfRSRTDANpg9e3bU1dUlYtY99tjjAIkBAOQXBTAAwGfUqlWrwnbt2u2fhFnnzZsXtbW1QgMiIqKkpCRGjhwZY8eOjaOPPjpKSkosBeBT2LRpU8ybNy8Rs7Zv337/iooKPwMEAMgjLv4AAD6jCy+8cPeioqKKJMz64osvCgz4P5o3bx5HHXVUXHLJJTFy5MjIZrOWAvAJZs2alYg5i4qKWlx88cWDJAYAkD8UwAAAn9GBBx6YiMfqVVdXJ+ZOFWDXKC8vj1GjRsWll16qCAb4BPPmzYuamppEzHrQQQd5DDQAQB5RAAMAfEZdu3YdnoQ5582bF/X19QIDPlFFRUWMGjUqLr744jj88MOjqKjIUgD+QV1dXbz66quJmLVLly77SwwAIH8ogAEAPoNTTjmlY3l5+W5JmPXll18WGLBVWrVqFccff3xcdNFFMWLEiCgo8C0kwN966aWXEjFnRUXFbieddFJ7iQEA5AffvQMAfAYnnnji55MwZ21tbcyfP19gwDZp06ZNjB49OsaOHasIBvgb8+fPj9ra2iSMmvnud7/7eYkBAOQH37UDAHwGn/vc5/ZLwpwLFy6Muro6gQGfyV+L4PPOOy+GDx+uCAby3ubNm2PhwoWJmLVfv37DJQYAkB98tw4AsI1atWpV2Lp1672TMKvHPwPbU6dOneLkk0+Oc889NwYNGmQhQF6bPXt2IuZs06bN3hUVFX4WCACQB1z0AQBso/PPP39gYWFheVOfs76+PubMmSMwYLvr2bNn/OQnP4nzzjsv9t5778hkMpYC5J3Zs2dHfX19k5+zqKio4vzzzx8oMQCA9FMAAwBso/3333/fJMz5+uuvR01NjcCAHaZLly4xZsyYOOecc2Lw4MEWAuSV6urqeOONNxIx64EHHriPxAAA0k8BDACwjbp27ZqIxz/PnTtXWMBO0bt37zjttNPinHPOif79+1sIkDeScr3VvXv3vaUFAJB+CmAAgG0wZMiQ0srKyj2a+py5XM7jn4Gdrk+fPnHWWWfFOeecE7vttpuFAKk3e/bsyOVyTX7Oli1b7jlo0KBSiQEApJsCGABgG5x55pl7ZjKZbFOfc9myZbFu3TqBAbtEnz594uyzz44zzzwzevbsaSFAaq1bty6WL1/e5OfMZDLZs846a4jEAADSrcgKAAC23tChQ4clYc558+YJC9jlBgwYEAMGDIgFCxbE+PHjY+nSpZYCpM68efOiS5cuTX7OffbZZ5+ImC4xAID0cgcwAMA26Nix4z5JmHP+/PnCApqMAQMGxC9/+cs47bTTolu3bhYCpEpSrrs6deq0j7QAANJNAQwAsJWOOOKIlhUVFf2a+pxVVVWxaNEigQFNSiaTicGDB8e//uu/xpgxY6JDhw6WAqTCW2+9FVVVVU1+zoqKis8deuihLSQGAJBeCmAAgK108sknD46ITFOfc/78+dHY2CgwoEnKZDKx9957x4UXXhhjxoyJ9u3bWwqQaI2NjbFgwYJE/Cv4u9/97h4SAwBILwUwAMBW2n333fdMwpze/wskwV+L4AsuuCBOPvnkaNu2raUAiZWU66/BgwfvKS0AgPQqsgIAgK3Trl27wU19xlwul5Q7UAAiIqKwsDCGDx8e++yzT0ybNi0mTJgQ69evtxggURYsWBC5XC4ymab9sJgOHToMlhYAQHq5AxgAYCsMGjSotGXLlgOa+pzvvfdebNy4UWBA4hQVFcWIESPikksuidGjR0fLli0tBUiMDz/8MJYtW9bk52zZsuXA/v37l0gMACCdFMAAAFvhxz/+8aBMJtPkn6Li7l8g6f5aBI8dOzZOOOGEaNGihaUAibBw4cImP2Mmk8n+5Cc/GSAtAIB0UgADAGyFvffee88kzJmEHzwCfBrNmjWLww47LMaOHRujRo2KsrIySwGatKT8Il5SrmsBANh63gEMALAVunbtOqSpz1hfXx9vvvmmsIBUKS4ujpEjR8bBBx8czz77bDz++ONRXV1tMUCT8+abb0Z9fX0UFTXtH7t16dJlT2kBAKSTO4ABAD6lioqKgoqKikFNfc4lS5bE5s2bBQakUklJSYwcOTLGjh0bRx99dJSUeIUl0LTU1tbG0qVLm/ycLVu2HFRaWupngwAAKeQiDwDgUzr77LP7FhYWNvlnj7722mvCAlKvefPmcdRRR8Ull1wSI0eOjGbNmlkK4HpsKxQWFpafffbZvaQFAJA+CmAAgE9p//3375+EOV9//XVhAXmjvLw8Ro0aFf/+7/8eI0eOjGw2aymA67FP6fOf//xAaQEApI8CGADgU+rRo8fuTX3G2traePvtt4UF5J2KiooYNWpUXHzxxXH44Yc3+XdvAum2ePHiRLySo1evXoOkBQCQPgpgAIBPqXXr1k3+DoklS5ZEQ0ODsIC81apVqzj++OPj4osvjhEjRkRBgW97gZ2voaEhlixZ0uTnbNOmjQIYACCFfCcMAPApDBkypLR58+a9m/qcb775prAAIqJ169YxevToGDt2rCIYcF32MZo3b95n0KBBpdICAEgX3wEDAHwKp556av9MJtPkr53eeustYQH8jTZt2sTo0aPjvPPOi+HDhyuCAddlfyOTyRT84Ac/+Jy0AADSxXe+AACfwuDBg5v84/Hq6+tj0aJFwgL4CJ06dYqTTz45/u3f/i323nvvyGQylgLsUIsXL07Eqzn23HPPgdICAEgXBTAAwKfQpUuXAU19xnfeeSfq6uqEBbAFnTt3jjFjxiiCgR2utrY23n333SRc53oPMABAyiiAAQA+hZYtW/Zv6jN6/DPAp9elS5cYM2ZMnHvuuTF48GALAfL2+iwJ17kAAGwdBTAAwCcYPnx4eUlJSeemPqfHPwNsvV69esVpp50W55xzTvTvrwMB8u/6rLS0tPPw4cPLpQUAkB4KYACAT/Ctb31rt4ho8s8IXbx4sbAAtlGfPn3irLPOinPOOSd22203CwG2i4T8gl7m29/+dj9pAQCkhwIYAOAT7L777k2+CVi7dm1s2LBBWACfUZ8+feLss8+OM888M3r27GkhwGfy4Ycfxrp165r8nAMHDlQAAwCkSJEVAABsWadOnZr8D8TefvttQQFsRwMGDIgBAwbEggULYvz48bF06VJLAbb5Oq1Vq1audwEA2GkUwAAAn6CyslIBDJCnBgwYEP3794958+bFQw89FO+++66lAFtlyZIlsddeezX1613PvgcASBEFMADAFnTq1CnbvHnzXk19ziVLlggLYAfJZDIxePDg2GOPPeLll1+OBx98MFauXGkxQGqu05o3b967Xbt2RatXr66XGABA8nkHMADAFowZM6ZnJpPJNuUZGxsbPZoUYCfIZDKx9957x4UXXhhjxoyJ9u3bWwrwiZYuXRqNjY1NesaCgoLsqaee2kNaAADp4A5gAIAt2Hvvvfs29RlXrlwZtbW1wgLYSf5aBO+5554xa9asmDBhQqxevdpigI9UW1sb77//fnTu3LlJzzls2LC+EbFIYgAAyecOYACALejRo0eTL4DfeecdQQHsAoWFhTF8+PC48MILY/To0VFZWWkpQGKv15Jw3QsAwKejAAYA2ILWrVs3+ff/vvvuu4IC2IUKCwtjxIgRcckll8To0aOjZcuWlgIk7notCde9AAB8Oh4BDQCwBc2bN+/Z1GdUAAM0kW+wi4pixIgRsd9++8WUKVPiscceiw0bNlgMEO+9914SrnsVwAAAKeEOYACAj9G/f/+SkpKSjk19TgUwQNPSrFmzOOyww2Ls2LExatSoKCsrsxTIc0m4XistLe3Ut2/fYmkBACSfAhgA4GOccMIJ3Zr69dK6deuiqqpKWABNUHFxcYwcOTJ+/etfK4Ihz1VVVcX69eub+pgF3/zmN7tLCwAg+RTAAAAfY8iQIT2b+oxJeJwgQL77axE8duzYOProo6OkpMRSIA8l4botCde/AAB8MgUwAMDH6N69e8+mPqPHPwMkR/PmzeOoo46KSy65JEaOHBnNmjWzFMgjSbhuS8L1LwAAn0wBDADwMVq1atWjqc+4bNkyQQEkTHl5eYwaNSr+/d//PUaOHBnZbNZSIA8k4botCde/AAB8MgUwAMDHqKio6NXUZ1y+fLmgAJL750yMGjUqLr744jj88MOjqKjIUiDFknDd1rJly16SAgBIPgUwAMBHyGazmbKysq5NecbGxsZYtWqVsAASrlWrVnH88cfHxRdfHCNGjIiCAt+qQxqtWrUqGhsbm/SMJSUlXbPZbEZaAADJ5rtKAICPcNxxx7UrKCgobsozrl69Ourr64UFkBKtW7eO0aNHx9ixYxXBkEJ1dXXxwQcfNOkZCwoKio877rh20gIASDbfTQIAfITPf/7zXZr6jO+//76gAFKoTZs2MXr06Dj//PNj+PDhimBIkRUrVrgOBgBgh/NdJP+PvTuPr7I888d/nSwEkhD2HUQEUVRAoIiouCtq64Jabd1arVorbqO2tlXbaavTOu38Rqffdmpbu9rWpYogsqgFRXCttAIKArJDgAAJBLKQ5JzfH8WO4+DOcp6T9/v18jWvTv657ut6hNvnk/t+AICd2G+//bL+xVcSXiAC8PF17do1Lr300rj99ttj2LBhkUq5lRWSLgn7tyTsgwEAeH8FWgAA8H917txZAAxAVujevXtceeWVsXr16njiiSdi9uzZkclkNAYSKAn7tyTsgwEAeH8CYACAnWjXrp0roAHIKj169Igrr7wyli5dGpMmTYo5c+ZoCiRMEvZvSdgHAwDw/gTAAAA7UVxc3D3baxQAAzRPffr0ibFjx8aSJUti/PjxsWDBAk2BhEjC/i0J+2AAAN6fbwADAOxESUlJz2yur7q6Ourq6gwKoBnbb7/94l/+5V/ia1/7WhxwwAEaAglQV1cX1dXV9sEAAOxWAmAAgHc5/PDDSwsKCtpmc40VFRUGBUBERPTt2zduvPHGuOGGG2LffffVEMhy2b6PKygoaDt8+PASkwIASC4BMADAu5x44oldsr3GDRs2GBQA/8uAAQPiG9/4Rtxwww3Ru3dvDQH7uE+yH+5qUgAAyeUbwAAA79KvX7+sD4DXr19vUADs1IABA+LAAw+MuXPnxoQJE2LlypWaAlkkCTe5HHDAAV0i4i3TAgBIJgEwAMC7dO/evXO21+gEMADvJ5VKxaBBg2LgwIExe/bsGD9+fKxbt05jwD4uZ/bDAAC8NwEwAMC7tG/fvlO21ygABuDDSKVSMWzYsBg6dGjMnj07HnvsMbdIwF6WhBPASdgPAwDw3gTAAADv0rp166w/8ZCEF4cAZI+3g+BDDz00XnnllZg4caK/S8A+LtH7YQAA3psAGADgXUpKSrL6xENjY2Ns3rzZoAD4yPLz8+Pwww+P4cOHx/PPPx8TJ06MqqoqjYE9aPPmzdHY2BgFBdn7Wi7b98MAALw/ATAAwLu0bNmySzbXV1lZGZlMxqAA+Njy8/Nj1KhRMXLkyHjhhRcEwbAHZTKZqKqqio4dO9oPAwCwWwiAAQDepaioKKuvvKusrDQkAHaJgoKCGDVqVIwYMSJmzpwZkydPji1btmgM7IH9XDYHwNm+HwYA4P3laQEAwP8YPnx4SX5+fkk21ygABmBXa9GiRRx//PFxxx13xNlnnx0lJSWaAs14P5efn18yfPhwfxAAACSUABgA4B2OOOKIDtleo+//ArC7FBUVxejRo+P73/9+nH322VFcXKwpsBsk4cr1JOyLAQDYOQEwAMA79O3bt1221+gEMAC729tB8B133BGnn356tGrVSlOgme3n9ttvv7YmBQCQTAJgAIB36NSpkwAYAHYoKSmJz3zmM3HnnXfG6NGjo0WLFpoCzWQ/l4R9MQAAOycABgB4hw4dOrTN9hqTcGUgALmlpKQkzj777PjOd74To0aNivz8fE2BHN/PJWFfDADAzgmAAQDeoaysrG221ygABmBvad++fVx00UVx5513xgknnBCFhYWaAjm6nysrK3MCGAAgoQTAAADvUFJS0j6b68tkMlFdXW1QAOxV7dq1i/POOy+++93vxqhRoyIvz+sF+CiSsJ8rLS0VAAMAJJT/QgMAeIfi4uK22VxfXV1dNDY2GhQAWeHtE8F33HGHIBg+gsbGxqirq7MvBgBgt/BfZgAA79CqVausPung9C8A2ahDhw5x0UUXxbe//e04/PDDBcGQA/u6oqIiJ4ABABLKf5EBALxDQUGBABgAPqauXbvGpZdeGt/61rdi2LBhkUqlNAUSuq9r0aJFW1MCAEimAi0AAPgfhYWFZdlc39atWw0JgKzXrVu3uPLKK2P16tXxxBNPxOzZsyOTyWgMJGhfl+37YgAA3psAGADgnZujgoLW2VyfE8AAJEmPHj3iyiuvjKVLl8akSZNizpw5mgIJ2ddl+74YAID35gpoAIAdWrdunZefn98ym2sUAAOQRH369ImxY8fGLbfcEgMGDNAQSMC+Lj8/v1WrVq28OwQASCCbOACAHQYNGlQSEVn9scJt27YZFACJtd9++8UNN9wQX/va1+KAAw7QEJq1BOzr8gYPHlxsUgAAySMABgDY4YADDijJ9hpramoMCoDE69u3b9x4441xww03xL777qshNEu1tbVZX2P//v1LTQoAIHl8AxgAYIeePXtm/QuuJLwoBIAPa8CAATFgwICYP39+jBs3LpYvX64pNBtJ2Nf16NGjxKQAAJJHAAwAsEOnTp0EwACwFwwYMCAOPPDAmDt3bkyYMCFWrlypKeS8JOzrunbtKgAGAEggATAAwA5lZWVZ/4Krrq7OoADISalUKgYNGhQDBw6M2bNnx4QJE2Lt2rUaQ85KQgDcpk0bV0ADACSQABgAYIeysjIngAFgL0ulUjFs2LAYOnRozJ49O8aPHx/r1q3TGHKOABgAgN1FAAwAsENJSUlxttfoBDAAzcXbQfCQIUPi5ZdfjokTJ0ZFRYXGkDOSEAAnYX8MAMD/JQAGANihqKioKNtrrKmpMSgAmpW8vLw4/PDDY/jw4fH888/HE088EZWVlRpD4iUhAG7RokWRSQEAJI8AGABgh8LCwhbZXF86nY7t27cbFADNUn5+fowaNSpGjhwZL7zwQkycODGqqqo0hsTavn17ZDKZSKVSWVtjixYtWpgUAEDyCIABAHbI9gC4oaHBkABo9goKCmLUqFExYsSImDlzZkyePDm2bNmiMSROJpOJhoaGyOaMtbCw0AlgAIAk/neTFgAA7NgYFRRk9QuuxsZGQwKAHVq0aBHHH398HHnkkfHMM8/E1KlTY9u2bRpDomR7AJzt+2MAAN5jH6cFAAA7NkZZ/oLL9c8A8H8VFRXF6NGj49hjj41nnnkmpkyZEjU1NRpDImT7DS8FBQWugAYASCABMADA2xujLH/B5QpoAHhvbwfBRx11VEyfPj2efvrpqK2t1RiymgAYAIDdIU8LAAD+QQAMAMlXUlISn/nMZ+LOO++M0aNHZ/X1uiAABgBgdxAAAwDskO1XQAuAAeDDKykpibPPPjv+7d/+LUaPHh2FhYWagv3dR5Sfn9/SlAAAkkcADADw9sYoL88JYADIMa1bt46zzz47vve978UJJ5wgCMb+7iPIz8/3LwwAQAIJgAEAdkilUlm9N2psbDQkAPiY2rVrF+edd15897vfjRNOOCEKCgo0Bfu7D94f55sSAEDyCIABAHbI9gA4nU4bEgB8Qu3bt/9nEDxq1KjIy/NqBPu799kfp0wJACB5/FcOAMAOXnABQPPRoUOHuOiii+J73/ueIJi9JpPJZHuJ/sUAAEggmzgAgP+R1QFwAl4QAkDidOzYMS666KL41re+FYcffnj4fTDs796xOc7yG3IAANg5mzgAgITsjQTAALD7dOvWLS699NL41re+FcOGDRMEs0dk+xXQeXl5/kUAAEigAi0AAPiHbH/BJQAGgN2ve/fuceWVV8ayZcviiSeeiDlz5mgKzXl/5/AIAEACCYABAHbIZDJOAAMAERGx7777xtixY2PJkiUxYcKEmD9/vqZgfwwAQCIIgAEA/ocr7gCA/2W//faLG264Id56660YP358vPnmm5rCLpPtV0Cn3IUOAJBIAmAAgB2y/QVXtr8gBIBc1rdv37jxxhvjrbfeinHjxsWiRYs0hU/MFdAAANjEAQDsXln9Bs4BDADY+/r27Rs333xz3HDDDdG7d28NIdf3d75BAgCQQE4AAwDskO0nMATAAJA9BgwYEAMGDIj58+fHI488EitXrtQUcnF/5woaAIAEcgIYAGCHVCqVzvL6DAkAssyAAQPi1ltvjbFjx0bPnj01hJza32UScEc1AAD/lxPAAAD/QwAMAHysv6MHDRoUBx98cDz//PMxadKk2LRpk8aQ+P1dtv+CJAAAO+cEMADADul0dr/fEgADQHarr6+PioqK2LZtm2aQE/u7dDrtBDAAQAI5AQwA8D+cAAYAPrK6urp4+umnY9q0acJfcm1/5wQwAEACCYABAP6HEw4AwIfW0NAQ06ZNiyeffDK2bt2qIXxkCfgGsAAYACCBBMAAADtkMpmsDoDz8ny9AwCywdvB71NPPRXV1dUaQs7u7wTAAADJJAAGANgh219wCYABYO9qbGyMGTNmxJNPPhmVlZUawieWn5+f9VtkUwIASB4BMADADplMpiGb6yssLDQkANgL0ul0zJo1KyZPnhwbN27UEHaZgoLsfjXX1NTUaEoAAAncZ2oBAMA/NDY2bs/m+gTAALBnpdPpePnll2Py5Mmxdu1aDWGXa9GiRbb/O1BvSgAAySMABgDYoampSQAMAEQmk4nZs2fH448/HuXl5RpCs93fNTY2CoABABJIAAwAsENDQ0NWv+ASAAPA7vV28PvEE0/E6tWrNYTdLtuvgM72G3IAAHiPfaYWAAD8gyugAaD5mjNnTkyaNCmWLl2qGewx2X4FtAAYACCZBMAAADs0NTU5AQwAzcyCBQtiwoQJ8dZbb2kG9nfv0tDQIAAGAEggATAAwA7Z/oJLAAwAu87ChQtj/PjxsXjxYs1gr8n2K6Cz/RckAQB4j32mFgAA/EO2B8AFBQWRl5cX6XTasADgY1q+fHmMGzcu5s+frxnsVXl5eVkfAG/fvt0JYACABBIAAwDs0NDQkPUnHFq1ahXbtm0zLAD4iFauXBmPPPKI4Jes2tclYH8sAAYASCABMADADrW1tXXZXqMAGAA+mnXr1sX48eNj9uzZkclkNISs2tdlu7q6ulqTAgBIHgEwAMAOW7du3ZrtNSbhRSEAZIP169fHY489JvjFvu4TqK6u3mpSAADJIwAGANihqqpKAAwACbdhw4Z4/PHH45VXXommpiYNwb7uE6isrHT1DABAAgmAAQB22LRpU9a/4GrZsqVBAcBOVFVVxcSJE+OFF16IxsZGDSHrJSEA3rRpkxPAAAAJJAAGANhh3bp1WR8AOwEMAP/bli1bYsKECYJfEicJ+7ry8nIBMABAAgmAAQB2WLZsmSugASAhqqurY/LkyTFz5syor6/XEBInCfu6pUuXCoABABJIAAwAsMP8+fOz/gRwcXGxQQHQrNXU1MSUKVPimWeeEfySaEnY173++uu+AQwAkEACYACAHRYsWFCXyWQaUqlUYbbW2Lp1a4MCoFmqq6uLp59+OqZNmxbbtsmkSL5s39el0+mGpUuXbjcpAIDkEQADALxDU1PTtoKCgrbZWp8AGIDmZvv27TF9+vR48sknY+tWt9GSO7J9X9fU1ORfOACAhBIAAwC8Q0NDw9ZsDoBLS0sNCYDm8ndyTJs2LZ566qmorq7WEHJOtu/rGhsb/YsHAJBQAmAAgHeor6+vbNWqVc9src8JYAByXWNjY8yYMSOefPLJqKys1BByVrbv6+rr66tMCQAgmQTAAADv0NDQkNVvmgXAAOSqdDods2bNismTJ8fGjRs1hJyX7fu6bN8XAwDw3gTAAADvUFdXV5XN9ZWWlkYqlYpMJmNYAOSETCYTr732Wjz++OOxatUqDaFZSKVSUVJSktU11tbWVpkUAEAyCYABAN5h27Ztm7K5vvz8/GjVqlXU1NQYFgCJlslkYvbs2fH4449HeXm5htCstGrVKvLz87O6xq1btzoBDACQUAJgAIB3qK6u3pztNZaVlQmAAUist4PfiRMnxpo1azSEZqmsrCzra9y2bVuVSQEAJJMAGADgHaqqqjZle43t2rWLtWvXGhYAiTNnzpyYNGlSLF26VDNo1tq1a5f1NW7atMkJYACALNbQWBgFjQ0REZFKRSavMJre/pkAGADgHSoqKqqyvcYkvDAEgHdasGBBTJgwId566y3NgITs5zZs2CAABgDIYoUFDf9MejMRqab0/+S+AmAAgHdYtWpV1r/oatu2rUEBkAgLFy6M8ePHx+LFizUD3iEJAfDq1aurTAoAIJkEwAAA77BgwYKsD4CdAAYg2y1fvjzGjRsX8+fP1wzYiST8Ql8S9sUAAOycABgA4B2eeOKJjZlMpimVSuVna41OAAOQrVauXBmPPPKI4Bc+QLb/Ql8mk2l64oknNpoUAEAyCYABAN6huro6vX379g1FRUVdsrVGJ4AByDZr166NCRMmxOzZsyOTyWgIJHw/t3379g3V1dVpkwIASCYBMADAu9TV1a0XAAPAB1u/fn089thjgl/Isf1cXV3delMCAEguATAAwLvU1dVVtGnTJmvrKykpiRYtWsT27dsNC4C9oqKiIiZOnBivvPJKNDU1aQh8BEVFRVFcXJz1+2GTAgBILgEwAMC7bN26dV2XLll7ADhSqVR07Ngx1qxZY1gA7FFVVVUxceLEeP755wW/8DF17NgxUqlU1u+HTQoAILkEwAAA71JVVZX1Jx46deokAAZgj9m8eXM8/vjj8cILL0RjY6OGwCfcx9kPAwCwOwmAAQDeZf369Vn/zbMkvDgEIPm2bNkSU6ZMiZkzZ0Z9fb2GwC7QsWNH+2EAAHYrATAAwLusXr066088JOHFIQDJVVNTE1OmTIlnnnlG8Au7WBJ+kW/VqlUCYACABBMAAwC8y9///ves/+aZABiA3aG2tjYmT54czz77bNTV1WkINNN93KuvvioABgBIMAEwAMC7PPzww+t//OMfN6RSqcJsrbFz584GBcAus3379pg+fXpMnTo1tm3bpiGwG2X7CeB0Ot3w8MMPC4ABABJMAAwA8C7V1dXpurq68latWu2TrTV26NAh8vLyIp1OGxgAH1tDQ0NMmzYtnnrqqaiurtYQ2M3y8vKiQ4cOWV1jfX39mtraWptMAIAEEwADAOxEbW3tmmwOgAsKCqJdu3axceNGwwLgI2tsbIwZM2bEk08+GZWVlRoCe0j79u2joCC7X8fV1NSUmxQAQLIJgAEAdmLz5s2r2rdvn9U1duvWTQAMwEeSTqdj1qxZMXnyZH+HwF7av2W7LVu2rDQpAIBkEwADAOzEpk2bVvfp0yera+zWrVvMmzfPsAD4QG8Hv1OmTIkNGzZoCOzF/Vu227BhwxqTAgBINgEwAMBOrFixYvWwYcOyusYkvEAEYO/KZDLx0ksvxZQpU6K83K2usLd17do162tctWrVKpMCAEg2ATAAwE7Mnz9/9ZgxY7K6xiS8QARg78hkMjF79uyYOHFirFnjMB9kiyT8At+8efP8oQEAkHACYACAnRg3btyab37zm5mISGVrjU4AA7Azc+bMiSeeeCKWLVumGZBlEvALfJlx48atNikAgGQTAAMA7MTrr79e29DQsKmwsLBDttZYXFwcZWVlsWXLFgMDIBYsWBDjx4+PJUuWaAZkobKysiguLs7qGhsaGjYuWLCgzrQAAJJNAAwA8B62bt26vF27dh2yucauXbsKgAGauYULF8b48eNj8eLFmgFZLAm3t2zbtm25SQEAJJ8AGADgPVRVVS1t167d0GyusWfPnrFw4ULDAmiGli1bFo899ljMnz9fMyABevbsmfU1VlZWLjUpAIDkEwADALyHdevWLevTp09W15iEF4kA7ForVqyIRx99VPALCZOEfdvatWuXmRQAQPIJgAEA3sPChQuXHX744VldY69evQwKoJlYtWpVjB8/PubOnRuZTEZDIGGSsG9buHDhMpMCAEg+ATAAwHuYNm3a0ksuuSSra+zevXvk5+dHU1OTgQHkqHXr1sX48eNj9uzZgl9IqIKCgkR8A/jpp59eZloAADmw/9QCAICde+ihhzbcd999W/Pz80uzdjNXUBBdunSJNWvWGBhAjqmoqIiJEyfGyy+/HOl0WkMgwbp27RoFBdn9Gq6xsbH6kUce2WBaAADJJwAGAHgf27ZtW15WVnZwNtfYq1cvATBADqmqqoqJEyfG888/74YHyBFJ+P7vtm3blpsUAEBuEAADALyPLVu2LMv2ALhnz57x0ksvGRZAwm3evDkef/zxeOGFF6KxsVFDIIck4fu/W7ZsWWpSAAC5QQAMAPA+1q9fvyzbT2z06NHDoAASbMuWLTFlypSYOXNm1NfXawjkoCTs19avX7/MpAAAcoMAGADgfSxYsGDh0KFDs7rGfffdN1KpVGQyGQMDSJCampqYMmVKPPPMM4JfyGGpVCr23XffrK9z/vz5C00LACA3CIABAN7Ho48++uYFF1yQ1TWWlJRE586dY926dQYGkAC1tbUxefLkePbZZ6Ourk5DIMd17do1WrVqlfV1/vnPf15kWgAAuUEADADwPiZNmlRVX1+/oaioqGM217nvvvsKgAGy3Pbt22P69OkxderU2LZtm4ZAM9GnT5+sr7G+vr7iySefrDItAIDcIAAGAPgAW7duXZTtAXCfPn3ipZdeMiyALNTQ0BDTpk2Lp556KqqrqzUEmpkkXP+8detWp38BAHKIABgA4ANUVFQs7NChw8hsrjEJLxYBmpvGxsaYMWNGPPnkk1FZWakh0EwlYZ9WUVHh+78AADlEAAwA8AGWLl266MADD8zqGnv16hUFBQXR2NhoYAB7WTqdjlmzZsWkSZNi06ZNGgLNWGFhYfTs2TMR+13TAgDIHQJgAIAPMHPmzEWnnnpqdm/qCgqiZ8+esWzZMgMD2EveDn4nT54cGzdu1BAg9tlnn8jPz0/CfnexaQEA5I48LQAAeH+//OUvV6bT6bpsr7NPnz6GBbAXZDKZePHFF+O73/1u3H///cJf4J+ScP1zOp2u++Uvf7nStAAAcocTwAAAH6C6ujpdXV29uE2bNodkc539+vWL6dOnGxjAHpLJZGL27NkxceLEWLNmjYYAO92fJWCvu7i6ujptWgAAuUMADADwIWzYsGFetgfA/fv3NyiAPeTVV1+NSZMmxapVqzQD2KlUKpWI/dmGDRvmmhYAQG4RAAMAfAiLFy9+o2/fvlldY1lZWXTu3DnWr19vYAC7yYIFC2L8+PGxZMkSzQDeV5cuXaK0tDQJ+9z5pgUAkFsEwAAAH8JTTz31+ujRo7O+zv33318ADLAbLFy4MMaPHx+LFy/WDOBD78uSYMqUKa+bFgBAbsnTAgCAD/aLX/xiTWNjY1W215mUF40ASbFs2bK4++674z/+4z+Ev8BHkoTv/zY0NFTee++9q00LACC3OAEMAPAhNDQ0ZDZv3jy/Q4cOI7O5TgEwwK6xYsWKePTRR2P+fDejArm7L9uyZYs/5AAAcpAAGADgQ1q3bl3WB8AdO3aMNm3axObNmw0M4GNYtWpVjB8/PubOnRuZTEZDgI+lbdu20aFDh0Tsb00LACD3CIABAD6kefPmzTvooIOyvs4DDzwwXnrpJQMD+AjWrVsX48ePj9mzZwt+gV2yH0uCuXPnzjMtAIDcIwAGAPiQ/vznP88/77zzsr7OAw44QAAM8CFVVFTEuHHjBL/ALt+PJcHDDz/sBDAAQA4SAAMAfEgTJ06srK2tXdGqVat9srnOgw8+2LAAPkBVVVVMnDgxnn/++WhqatIQYJdKwq0xNTU1yydNmlRlWgAAuUcADADwEWzYsOHvvXr1yuoAuG3bttG1a9dYu3atgQG8y+bNm+Pxxx+PF154IRobGzUE2OW6desWbdu2TcS+1rQAAHKTABgA4CNYuHDha7169Toj2+scMGCAABjgHbZs2RJTpkyJ5557LrZv364hwG6TlO//Lly48O+mBQCQmwTAAAAfwcSJE/9+wgknZH2dBx54YEyfPt3AgGavpqYmpkyZEs8880zU19drCLDbDRgwIBF1jh8//u+mBQCQmwTAAAAfwb333rv6Bz/4wfqioqLO2VznAQccEHl5eZFOpw0NaJZqa2tj8uTJ8eyzz0ZdXZ2GAHtEXl5e9O/fP+vrrK+vX3ffffeVmxgAQG4SAAMAfESVlZVzu3btmtXHgFu1ahX77LNPLFu2zMCAZqWuri6efvrpmDZtWmzbtk1DgD1qn332iVatWmV9nZs2bZpjWgAAuUsADADwES1dunR2tgfAERGDBg0SAAPNRkNDQ0ybNi2eeuqpqK6u1hBgr+2/kuCtt976m2kBAOQuATAAwEc0ffr0v48cOTLr6xw4cGBMmDDBwICc1tDQEM8991w8+eSTUVlZqSHAXt9/JcG0adP+bloAALlLAAwA8BH9x3/8x9JbbrmlOj8/v3U219mrV68oKyuLLVu2GBqQc9LpdMyaNSsmTZoUmzZt0hBgrysrK4tevXplfZ2NjY1b7rnnnmUmBgCQuwTAAAAfUW1tbXrDhg1/7dKly3HZXGcqlYqBAwfGrFmzDA3IGW8Hv5MnT46NGzdqCJA1Bg4cGKlUKuvr3Lhx4yu1tbVpEwMAyF0CYACAj+Gtt956JdsD4IgQAAM5I51Ox8svvxxTpkyJ8vJyDQGyct+VBIsWLXrFtAAAcpsAGADgYxg/fvwrRxxxRNbXedBBB0VBQUE0NjYaGpBImUwmZs+eHRMnTow1a9ZoCJCVCgoK4qCDDkpErY888ogAGAAgx+VpAQDAR/fjH/94ZX19/fpsr7OoqCj69etnYEAivfrqq3HHHXfEz3/+c+EvkNX69esXRUVFWV9nXV1d+b333rvaxAAAcpsTwAAAH9OGDRte6dGjx6ezvc5BgwbFggULDAxIjCVLlsSECRNi/vz5mgEkwuDBgxNR5/r1653+BQBoBgTAAAAf07x5815OQgA8bNiwePjhhyOTyRgakNXefPPNmDBhQixevFgzgMRIpVIxdOjQRNQ6d+7cl0wMACD3CYABAD6m++677+XRo0dnIiKVzXW2bds2evfuHcuWLTM0ICstW7YsHnvsMSd+gUTq06dPtG3bNgmlpu+9996/mhgAQO4TAAMAfEwTJ06s3Lp165LS0tK+2V7rkCFDBMBA1lmxYkU8+uijgl8g0YYMGZKIOqurqxc+/fTTm00MACD3CYABAD6B8vLyl/fff/+sD4AHDx4c48aNMzAgK6xcuTImTJgQc+fOdT09kHhJ+f7vmjVrfP8XAKCZEAADAHwCM2fOfG7//ff/fLbX2a1bt+jWrVuUl5cbGrDXrFu3LsaPHx+zZ88W/AI5oWfPntGlS5dE1DpjxoznTAwAoHkQAAMAfAK33Xbba5dcckl1fn5+62yvdciQIQJgYK9Yv359PPbYY4JfIOck5frnxsbGzbfddts8EwMAaB4EwAAAn0BlZWXThg0b/tqlS5fjsr3WQw89NCZNmmRowJ78MzKeeOKJeP7556OpqUlDgJxz6KGHJqLOioqKV6qrq9MmBgDQPAiAAQA+oXnz5s1MQgDcu3dv10ADe0RVVVVMnDgxXnjhhWhsbNQQICd17949evbsmZT9quufAQCakTwtAAD4ZP77v/97VkQk4kTFpz71KQMDdpstW7bEQw89FLfffns899xzwl8gpw0fPjwRdWYymfTdd9/9gokBADQfTgADAHxCkyZNqtqyZcuCsrKyg7K91uHDh8fjjz9uaMAuVVNTE1OmTIlnnnkm6uvrNQTIealUKg477LBE1Lply5bXp0+fvsXUAACaDwEwAMAusHz58lkDBw7M+gC4S5cu0atXr1i5cqWhAZ9YbW1tTJ48OZ599tmoq6vTEKDZ6N27d3Ts2DEx+1QTAwBoXgTAAAC7wLPPPvvCwIEDr0hCrcOGDRMAA59IXV1dPP300zFt2rTYtm2bhgDNzrBhwxJT61/+8pcXTQwAoHnxDWAAgF3g1ltvnV9fX782CbUefvjhkUqlDA34yBoaGmLq1Klx6623xuOPPy78BZqlJF3/XFdXt/rWW29dYGoAAM2LE8AAALtAQ0NDZs2aNc/16dPns9lea7t27aJPnz6xZMkSgwM+7J9xMW3atHjqqaeiurpaQ4Bmbb/99ou2bdsmotbVq1fPNDEAgOZHAAwAsIs8++yz05IQAEdEHHHEEQJg4AOl0+mYNWtWTJo0KTZt2qQhABFx5JFHJqbW6dOnTzMxAIDmxxXQAAC7yC233PJaQ0NDZRJqHT58eLRo0cLQgJ1Kp9Px3HPPxW233Rb333+/8Bdgh6KiovjUpz6ViFobGho23HLLLXNNDQCg+XECGABgF6murk6Xl5c/t88++5yR7bW2bNkyDj300Hj55ZcNDvindDodL7/8ckyZMiXKy8s1BOBdhgwZEkVFRYmodc2aNc/V1tamTQ0AoPkRAAMA7EIvvvjiM0kIgCMiRo4cKQAGIiIik8nE7NmzY+LEibFmzRoNAXif/VNSzJo161kTAwBongTAAAC70O233/7KOeecszU/P78022sdMGBAtG/f3tWu0My9+uqrMWnSpFi1apVmALyPjh07xgEHHJCIWhsbG6u/8Y1v/NXUAACaJwEwAMAutHLlyob169fP6tat2+hsrzWVSsXhhx8ekyZNMjhohubMmROTJ0+OJUuWaAbAh3D44YdHKpVKRK3r16+fVVFR0WhqAADNU54WAADsWq+++mpirts77LDDDAyamTfffDP+/d//PX7yk58IfwE+pFQqFSNGjEhMva+88sozpgYA0Hw5AQwAsIvddNNNz5166qnV+fn5rbO91m7dukX//v1j4cKFBgc5btmyZfHYY4/F/PnzNQPgIzrggAOic+fOiai1sbFxy4033jjL1AAAmi8BMADALrZy5cqG8vLyGT179vx0Euo9+uijBcCQw5YvXx7jxo0T/AJ8wv1SUpSXlz9TXl7eYGoAAM2XABgAYDeYMWPGUxdccEEiAuAhQ4ZE69ato7q62uAgh6xcuTImTJgQc+fOjUwmoyEAH1ObNm3i0EMPTUy9zz777FOmBgDQvPkGMADAbvDVr371lYaGhk1JqLWgoCCOOOIIQ4McsW7duvj5z38ed955Z8yZM0f4C/AJjRw5MvLz8xNRa0NDw8abbrrpVVMDAGjenAAGANgNKisrm1atWjW9T58+5ySh3qOPPjqefPJJQREk2Pr16+Oxxx6L2bNn+3cZYBdJpVIxatSoxNS7cuXKadXV1WmTAwBo3pwABgDYTaZNm5aY6/c6duwYAwYMMDRIoA0bNsSvf/3r+Nd//dd49dVXhb8Au9CAAQOiY8eOian36aefftLUAAAQAAMA7CZf+9rX5tTX11ckpd6jjjrK0CBBqqqq4v77749vf/vb8eKLL0ZTU5OmAOxiRx55ZGJqra+vX/eNb3zjdVMDAMAV0AAAu0ltbW16xYoVT++///6fT0K9hx56aLRt2zaqqqoMD7LYli1bYsqUKfHcc8/F9u3bNQRgN2nbtm0MGTIkMfUuX778qdraWtc/AwDgBDAAwO70xz/+cUJSas3Pz4/jjjvO0CBL1dTUxKOPPhq33XZb/OUvfxH+Auxmxx57bOTn5yel3Myvf/3rCaYGAECEABgAYLe66667llZXV89PSr1HH310tGjRwuAgi7wd/H7jG9+IqVOnRn19vaYA7GYtWrSIo48+OjH1btmy5Y177rlnhckBABDhCmgAgN3u9ddfn3T44YcPSEKtxcXFcdhhh8XMmTMNDvayurq6ePrpp2PatGmxbds2DQHYgw477LAoKSlJTL3z5s17wtQAAHibE8AAALvZ9773vanpdLohKfWecMIJkUqlDA72koaGhpg6dWrceuut8fjjjwt/AfawVCoVJ5xwQmLqTafT27/73e8+ZXIAALzNCWAAgN1s+vTpWyoqKmZ26dIlER/Y7d69e/Tv3z/efPNNw4M9qKGhIaZNmxZPPfVUVFdXawjAXnLAAQdE9+7dE1NvRUXFczNmzPAXBwAA/+QEMADAHjBr1qxEXcuXpFMvkHTpdDqee+65uP322+PRRx8V/gLsZccff3yi6p0xY8YkUwMA4J2cAAYA2AO++tWvvnT66adXFRYWtk1CvQMHDoyOHTvGhg0bDA92k3Q6HbNmzYrJkyfHxo0bNQQgC3Ts2DEGDhyYmHobGhoqb7755pdMDgCAd3ICGABgDygvL29YsWLF1MRsEvPy4sQTTzQ42A3S6XS8+OKL8Z3vfCfuv/9+4S9AFjnppJMiLy85r8tWrFgxpaKiotHkAAB4JwEwAMAe8qtf/erRiMgkpd6jjjoqysrKDA52kUwmE6+++mp873vfi1//+texdu1aTQHIImVlZXHUUUcl6q+W//7v//6zyQEA8G4CYACAPeQ///M/l1dWVv4tKfUWFhbGMcccY3CwC7wd/P785z+PNWvWaAhAFjruuOOioCA5X0urqqqa/dOf/nS1yQEA8G4CYACAPeill14al6R6jzvuuCgqKjI4+JjmzJkTd911V/z85z+P1au9owfIVkVFRYn7xbcXXnhhnMkBALAzBVoAALDnjB079pkFCxZUFhYWtktCvSUlJXHEEUfE9OnTDQ8+gjfffDPGjx8fb731lmYAJMCRRx4ZJSUliam3oaFh0zXXXPOsyQEAsDMCYACAPai8vLxh6dKlE/v3739xUmo+8cQT49lnn410Om2A8AEWLVoUjz32WCxevFgzABIiLy8vTjzxxETVvGTJkifKy8sbTA8AgJ3ucbUAAGDP+u1vfzsxIjJJqbdjx44xdOhQg4P3sXz58rj77rvjRz/6kfAXIGGGDRsWHTp0SFLJmd/85jePmxwAAO9FAAwAsIf953/+5/JNmza9kqSaTz/99EilUoYH77Jy5cr4yU9+Et///vdj/vz5GgKQMHl5eXHGGWckquZNmza9fM8996wwPQAA3osroAEA9oKXXnpp/KmnnnpYUurt2rVrDBkyJGbPnm14EBHr1q2L8ePHx+zZsyOTyWgIQEINHTo0OnfunKiaX3jhhQkmBwDA+xEAAwDsBZdffvkzS5YsWVdUVNQlKTWfccYZ8be//U3YRbO2fv36eOyxxwS/ADkglUrF6aefnqia6+rq1lx22WXTTQ8AgPcjAAYA2AsqKyub5s+f/8ihhx56dVJq7tatm1PANFsbNmyIxx9/PF555ZVoamrSEIAc8KlPfSq6du2aqJrfeOONcdXV1WnTAwDg/fgGMADAXvL1r399XDqdrktSzb4FTHNTVVUV999/f3z729+OF198UfgLkCNSqVR8+tOfTlTN6XS69pvf/OZjpgcAwAdxAhgAYC+ZMWNG9Zo1a/7Ss2fPxLx97N69ewwcODDmzJljgOS0LVu2xIQJE+KFF16IxsZGDQHIMYceemh069YtUTWvXr36qRkzZlSbHgAAH8QJYACAvejXv/71HyMiUR8SPeuss5wCJmdt27YtHn300bjtttviueeeE/4C5KC8vLwYM2ZM0srO/OpXv/qT6QEA8KH2vFoAALD3fP/733+rqqoqUR/V7dGjR3zqU58yPHJKfX19TJ06Nb71rW/F1KlTo76+XlMActSIESOiS5cuiap506ZNf73rrruWmh4AAB+GABgAYC975plnHkpazWeccUbk5dlKkjvmzZsXjz76aGzdulUzAHJYQUFBnH766Ymre9q0aQ+aHgAAH5a3dgAAe9nYsWNn1tfXr01SzZ07d47DDjvM8ACARBk5cmR06NAhUTXX1dWtHjt27POmBwDAhyUABgDYyyorK5tee+21Pyat7jPPPDMKCgoMEABIhBYtWiTy9O/s2bP/UF1dnTZBAAA+LAEwAEAWuOqqqyY0NjZWJanm9u3bx9FHH214AEAiHHfccdGmTZtE1dzQ0LDxiiuumGh6AAB8FAJgAIAssGDBgrqFCxc+lrS6R48eHYWFhQYIAGS1li1bxsknn5y4uhcuXDhu6dKl200QAICPQgAMAJAlvv71r/8pnU7XJqnmtm3bximnnGJ4AEBWO+2006K0tDRRNTc1NdV+7Wtfe8j0AAD4qATAAABZ4umnn968fPnyxF3xN3r06GjXrp0BAgBZqUOHDnH88ccnru5ly5ZNmD59+hYTBADgoxIAAwBkkbvvvvtPmUymKUk1FxYWxumnn254AEBWOvPMMxP3yYpMJtN41113/dH0AAD4OATAAABZ5Be/+MWatWvXTkta3UcccUT06tXLAAGArNK7d+847LDDEld3eXn5X+6///51JggAwMchAAYAyDIPP/zwn5JWcyqVijPPPNPwAICsMmbMmEilUomr+8EHH/yT6QEA8HEJgAEAsszXv/71NzZs2DAraXUPHDgwDj74YAMEALLCoEGDYsCAAYmru6KiYuatt966wAQBAPi4BMAAAFlo3Lhxv01i3WPGjIm8PFtMAGDvysvLizFjxiSy9j//+c+/NUEAAD7RflgLAACyz/XXXz+nqqrqr0mru1evXnHUUUcZIACwVx1zzDHRvXv3xNW9adOmV2666aa5JggAwCchAAYAyFJ/+tOf7k1i3WPGjInS0lIDBAD2ijZt2sRZZ52VyNofeOCBe00QAIBPSgAMAJClbrrpprlJPAVcXFwcZ555pgECAHvFWWedFS1btkxc3Zs2bXrl5ptvnmeCAAB8UgJgAIAsNm7cuF8lse5Ro0ZF7969DRAA2KP69OkTI0eOTGTtjz322K9MEACAXUEADACQxcaOHTu7qqrqb0mrO5VKxfnnnx+pVMoQAYA9tv/4/Oc/n8j9R2Vl5d+uueaav5kiAAC7ggAYACDLTZ069bdJrLtv374xZMgQAwQA9ojDDjsssTeQTJ48+TcmCADAriIABgDIcpdeeumLVVVVryax9s9//vNRXFxsiADAblVaWhrnn39+Imuvqqr66+WXX/6SKQIAsKsIgAEAEuChhx76WRLrLisri9NPP90AAYDd6qyzzoqSkpIklp753e9+91MTBABgVxIAAwAkwA033DB3w4YNs5JY+3HHHRd9+vQxRABgt+jbt28cddRRiay9oqJi1te//vU3TBEAgF1JAAwAkBA///nPfxoR6aTVnUql4vOf/3zk5dl6AgC7Vn5+flx00UWRSqWSWH76F7/4xX+bIgAAu5q3cAAACXHHHXe8tW7duulJrL13795xzDHHGCIAsEudcMIJ0b1790TWXl5e/pc77rjjLVMEAGBXEwADACTI3XfffW8mk2lKYu1nnXVWtG3b1hABgF2iQ4cOcfrppyey9kwm03T33Xf/3BQBANgdBMAAAAlyzz33rCgvL386ibW3bNkyzj33XEMEAHaJc889N1q0aJHI2tesWTP1xz/+8UpTBABgdxAAAwAkzA9/+MOfZzKZhiTWPnz48Bg0aJAhAgCfyKGHHhpDhw5NZO3pdLrhBz/4wS9MEQCA3UUADACQMPfee+/qRYsWPZDU+i+++OIoKSkxSADgY2ndunVcfPHFia1/4cKFf7jvvvvKTRIAgN1FAAwAkECXXXbZrxsaGjYlsfaysjJXQQMAH9u5554bpaWliay9oaFh4+WXX/47UwQAYHcSAAMAJNDs2bNrXn311V8ntf4jjjgiDj74YIMEAD6SwYMHx+GHH57Y+l955ZX7Zs+eXWOSAADsTgJgAICEOueccx6tqalZmtT6L7roomjZsqVBAgAfSsuWLeNzn/tcYuuvqalZMmbMmMdMEgCA3U0ADACQUJWVlU3Tpk37RVLrb9++fZx++ukGCQB8KGeccUa0b98+sfU/+eST91ZXV6dNEgCA3U0ADACQYOedd960qqqqV5Ja/wknnOAqaADgAx188MFx/PHHJ7b+TZs2vXzBBRc8a5IAAOwJAmAAgIT74x//eG9EZJJYeyqVigsuuMBV0ADAe2rZsmVccMEFkUqlkrqEzP333/8zkwQAYE8RAAMAJNzNN988b9WqVU8ktf6OHTsm+nt+AMDudcEFF0THjh0TW/+KFSse//rXv/6GSQIAsKcIgAEAcsCNN974k6ampq1JrX/kyJExdOhQgwQA/pdPfepTMWLEiMTW39TUVH3zzTf/t0kCALAnCYABAHLAxIkTK//+97//KslruPDCC6OsrMwwAYCIiGjTpk18/vOfT/QaZs+efd/EiRMrTRMAgD1JAAwAkCPOPvvsh2pqapYntf7S0tK46KKLDBIAiFQqFV/84hejtLQ0sWuoqal566yzznrYNAEA2NMEwAAAOaKioqJx0qRJP07yGgYPHhwjR440TABo5o444og46KCDEr2GJ5544qeVlZVNpgkAwJ4mAAYAyCGXXHLJzIqKihlJXsMFF1wQ3bp1M0wAaKZ69uyZ+KufKyoqZnzhC1+YZZoAAOwNAmAAgBzzb//2b/ek0+ntSa2/RYsWceWVV0ZhYaFhAkAzU1hYGF/60pcSvQ9Ip9Pb/+3f/u0e0wQAYG8RAAMA5Jh777139aJFix5M8hq6d+8eZ555pmECQDNzxhlnRPfu3RO9hsWLFz947733rjZNAAD2FgEwAEAO+uxnP/vL2traRL94PPHEE2Pw4MGGCQDNxKBBg+Kkk05K9Bpqa2tXn3vuub80TQAA9iYBMABADlq8eHH9uHHj/j3Ja0ilUnHJJZdE27ZtDRQAclybNm3ikksuiVQqleh1jBs37t8XL15cb6IAAOxNAmAAgBx1+eWXv1RRUTEjyWsoLS2NL3zhC4l/GQwAvLe3f+mrdevWiV5HRUXFM5dffvlLJgoAwN4mAAYAyGE33HDDXU1NTVuTvIaDDjrI94ABIId95jOfiUMOOSTRa2hqaqq+4YYbfmiaAABkAwEwAEAOGzdu3MbZs2cn/jt0p5xyiu8BA0AOOuSQQ+LTn/504tfx17/+9efjxo3baKIAAGQDATAAQI77zGc+81B1dfXCJK8hlUrFF7/4xejQoYOBAkCO6NixY3zpS19K/KceNm/ePO+00057xEQBAMgWAmAAgBxXXV2dfuCBB34UEekkr6O4uDguvfTSyMuzhQWApMvPz4/LLrssiouLk76U9P333/+ftbW1aVMFACBbeHsGANAMXH/99XMWLVr0YNLXsf/++8e5555roACQcOedd1707ds38etYuHDhH7/61a++bqIAAGQTATAAQDNxySWX/Lyurq486es4/vjjfQ8YABJs2LBhccwxxyR+HXV1dWsuvPDC+0wUAIBsIwAGAGgmXnvttdoHHnjguxGRSfI6UqlUfOlLX4oePXoYKgAkTO/evePSSy9N/Hd/IyLzwAMPfO/111+vNVUAALKNABgAoBm5+uqr/7Z06dJHk76OoqKiGDt2bJSWlhoqACRE69at46qrrorCwsLEr2X58uXjrr766r+ZKgAA2UgADADQzJx33nn/r66ubnXS19GhQ4e4/PLLIy/PlhYAsl1eXl5cfvnl0b59+8Svpb6+ft0ll1zyE1MFACBr999aAADQvLz++uu1Dz744Pcj4VdBR0QMGDAgzjrrLEMFgCw3ZsyYOPDAA3NiLY899tgPXnnllW2mCgBAthIAAwA0Q1/5ylf+umbNmqm5sJaTTz45Dj30UEMFgCw1ZMiQOOmkk3JiLWvXrv3LpZde+oKpAgCQzQTAAADN1GWXXfYf9fX1FUlfRyqViksvvTS6d+9uqACQZXr06BFf/OIXI5VKJX4tDQ0Nm6655pofmioAANlOAAwA0EzNmDGj+oEHHvhO5MBV0C1btozrr78+2rZta7AAkCXatWsX1113XbRs2TIXlpN56KGH/nXSpElVJgsAQLYTAAMANGNf+cpX/rpkyZI/58Ja2rZtG1dffXW0aNHCYAFgL2vRokVcffXVOfPLWUuXLn30iiuueNlkAQBIAgEwAEAzd+655/6ktrZ2eS6spXfv3jlzzSQAJNXbn2fYZ599cmI9tbW1y88555wfmywAAEkhAAYAaOYWLFhQ97Of/ezbmUymMRfWM2zYsDjllFMMFgD2kk9/+tMxdOjQnFhLJpNp/NnPfvbtBQsW1JksAABJIQAGACBuvfXWBfPnz78/V9Zz5plnxuDBgw0WAPaw4cOHx2c+85mcWc/8+fN/d+utty4wWQAAkkQADABARESMGTPmvpqamrdyYS2pVCouu+yy6Nmzp8ECwB7Su3fvuPjii3PmUwxbt25ddPrpp//aZAEASBoBMAAAERGxcuXKhh/+8Ie3pdPpnLjisGXLlvEv//Iv0aVLF8MFgN2sS5cucf3110dRUVFOrKepqanmu9/97jfKy8sbTBcAgKQRAAMA8E933XXX0ueff/6eXFlPaWlpXHvttVFWVma4ALCblJWVxXXXXRclJSU5s6aZM2fe/f/+3/9bZboAACSRABgAgP/l5JNPHldeXv50rqynU6dOMXbs2Jw5kQQA2aSoqCiuueaa6NixY86sqby8/MlTTz11gukCAJBUAmAAAP6PSy655K66urq1ubKefffdN6644orIy7P9BYBdJS8vL6688sro3bt3zqyprq6u/JJLLvmh6QIAkOi9uhYAAPBus2bNqn7ooYfujIh0rqxp4MCBcd555xkuAOwi559/fhxyyCG5tKT0gw8+eOesWbOqTRcAgCTLb3tQ9NzpjndbRG15oQ4BADRTEydOXDNmzJi8Tp06Dc2VNfXp0yfy8/PjzTffNGAA+ATOOuusOOmkk3JqTa+//vp9Z5555kTTBQAgCYq7N0Ze6c5/5gQwAADv6dRTT/31li1bXs+lNZ122mlx9NFHGy4AfEzHHntsnHrqqTm1pi1btrxx2mmn/cZ0AQDIBQJgAADeU0VFReONN974jcbGxqpcWtcFF1wQRx55pAEDwEd05JFHxuc+97mcWlNjY2PVzTff/I2KiopGEwYAIBcIgAEAeF9//OMf1z/yyCPfiRz6HnAqlYqLLroohgwZYsAA8CENHTo0LrrookilUrm0rPQjjzzynfvvv3+dCQMAkCsEwAAAfKBLL730hQULFvwupzbCeXnxpS99Kfbff38DBoAPcNBBB8WXvvSlyMvLrVdJCxYs+N2ll176ggkDAJBLBMAAAHwoo0eP/mVVVdXcXFpTYWFhfOUrX4kePXoYMAC8h169esUVV1wRBQUFObWuqqqqOaNHj/6lCQMAkGsEwAAAfCgVFRWNV1111S0NDQ0bcmldJSUlcfPNN8c+++xjyADwLr17946bbropiouLc2pdDQ0NG6666qqv++4vAAC5SAAMAMCHNmHChE3333//tzKZTDqX1lVcXBzXXXdddO/e3ZABYIfu3bvHtddeG61atcqpdWUymfT999//rQkTJmwyZQAAcpEAGACAj2Ts2LGz58+f/9tcW1fr1q3juuuuiw4dOhgyAM1ehw4d4rrrrovWrVvn3Nrmz5//m7Fjx842ZQAAcpUAGACAj+y44477xaZNm17MtXW1a9cubrzxxmjXrp0hA9BstW3bNmf/Pty4ceOLxx13nO/+AgCQ0wTAAAB8ZNXV1emLL774W3V1datzbW0dO3aMG2+8Mdq0aWPQADQ7ZWVlceONN0bHjh1zbm21tbWrL7zwwturq6vTJg0AQC7Lb3tQ9NzZD9LbImrLC3UIAICdWrZsWf327dtfOvbYY0/Ny8trkUtrKykpiaFDh8Zrr70WNTU1hg1As9ChQ4f42te+Fp06dcq5tTU1NW39zne+M/bBBx9cb9IAAOSC4u6NkVe6858JgAEA+NhefPHFzYcccsiyAQMGnBgRqZzaRBcXx5AhQ4TAADQLHTt2jJtuuik6dOiQi8tLjx8//ravfvWrc0waAIBc8X4BsCugAQD4RC688MIZb7zxxm9ycW3t27ePm266KSdPQgHA2zp16pTL4W+88cYbv77wwgufM2kAAJoLATAAAJ/YqFGjfrFhw4aZubi2t0Pgzp07GzQAOadz585x0003Rfv27XNyfRs2bJg5atSo+0waAIDmRAAMAMAnVltbm77sssu+V1dXtzoX19euXbu44YYbomPHjoYNQM7o0KFDXH/99dGuXbtc3Z+s/sIXvvDd2tratGkDANCc+AYwAAC7xJIlS+oj4pVRo0admpeX1yLX1ldcXBxDhw6NuXPnxrZt2wwcgETr0qVL3HjjjTl77XNTU1P1nXfeec0f/vCHdaYNAEAuer9vAAuAAQDYZWbNmlXVo0ePuYceeujoVCqVn2vra9WqVYwYMSIWLVoUlZWVBg5AIu23335x0003RVlZWU6uL51ON/z617++4fbbb3/TtAEAyFUCYAAA9phJkyatPeqoozbsu+++R+fi+goLC2P48OGxbNmy2LBhg4EDkCgDBgyIa6+9Nlq1apWza5w2bdq/XXLJJc+ZNgAAuez9AmDfAAYAYJc77bTTHn/rrbcezNX1FRUVxTXXXBNDhgwxbAASY8iQIXHNNddEUVFRzq5xwYIFvzv99NOfMG0AAJozATAAALvFEUcccc+GDRtm5ur6CgoK4sorr4wjjjjCsAFIwt/LceWVV0ZBQUHOrrG8vPypESNG/LdpAwDQ3AmAAQDYLaqrq9MXXXTRd2pra1fk7GY6Ly8uvvjiOPLIIw0cgKw1atSouPjiiyMvL3dfA23dunXxZz/72e83NDRkTBwAgObON4ABANhtli9fvr2mpuaFY4899uT8/PyWubjGVCoVgwYNikwmE4sWLTJ0ALLK6aefHueee26kUqmcXWN9fX3FDTfccM3UqVOrTBwAgObi/b4BLAAGAGC3evnll7cUFBS8cMQRR4zOy8trkYtrTKVSccABB0SnTp1i7ty5kck4fATA3lVYWBhXXHFFHHPMMTm9zsbGxuo777zzKz/72c9WmzoAAM2JABgAgL1qxowZlb169Xp98ODBJ6dSqfxcXWfPnj2jb9++8fe//z0aGxsNHoC9olWrVnH11VfHwIEDc3qd6XS64be//e2Nt9122wJTBwCguREAAwCw1z3xxBPlw4cPX9OvX79jIyJn76Hs2LFjDBw4MObMmRN1dXUGD8Ae1a5du7jxxhujT58+ub7U9JQpU779xS9+8XlTBwCgOXq/ADhPewAA2FPGjBkz9Y033vh1rq+zZ8+eceONN0bHjh0NHYA9pkuXLnHTTTdF9+7dc36tc+fO/eU555zzF1MHAID/SwAMAMAe9alPfernS5cufTjX19mlS5e49dZb48ADDzR0AHa7gQMHxje/+c3o1KlTzq/1rbfeemjEiBG/MnUAANg5ATAAAHvcsccee8/GjRtfyPV1FhcXx7XXXhsjRowwdAB2m8MPPzyuuuqqaNmyZc6vdePGjc8fffTR95g6AAC8NwEwAAB7XEVFReNxxx339crKyr/l+loLCgrisssui/PPPz9SqZThA7DLpFKpOP/88+PSSy+NgoKCnF/vpk2bXj7ssMNuqaysbDJ9AAB4bwJgAAD2isWLF9efddZZN1dXV7/ZHNZ7/PHHx5e//OUoKioyfAA+sRYtWsSXv/zlOP7445vFequrq98cM2bMN8rLyxtMHwAA3l9+24Oi585+kN4WUVteqEMAAOw2a9asaVi1atWs0aNHH1dQUNA619fbrVu3OOCAA2LevHlRX1/vAQDgYykrK4trrrkmDjrooGax3rq6uvKxY8de89RTT202fQAA+Ifi7o2RV7rznwmAAQDYq+bNm1ezevXqZ04++eTjCwoKSnN9ve3atYuRI0fG8uXLY+PGjR4AAD6S/v37x0033RRdu3ZtFuutr69fd9111335T3/6U4XpAwDA/xAAAwCQ1ebMmbMtlUq9fOSRR56Ul5eX83ckt2jRIkaMGBG1tbWxdOlSDwAAH8rxxx8fX/rSl5rN5wQaGxu33HXXXdf99Kc/XWn6AADwvwmAAQDIejNnzqzs2bPn64MHDz4plUrl5/p6U6lUHHLIIdGqVatYsGBBZDIZDwEAO5WXlxef/exn4/TTT49UKtUs1pxOp7f//ve//+o3vvGN1z0BAADwfwmAAQBIhEmTJpXvs88+8wYOHHhCKpUqaA5r3m+//WLAgAExd+5c3wUG4P8oKyuL6667LoYNG9Zs1pxOp7f/8Y9/vOmqq676qycAAAB2TgAMAEBiTJw4cc3BBx+85MADDzwulUrlNYc1t2/fPoYOHRqLFi2KLVu2eAgAiIiIffbZJ66//vro2bNns1lzJpNpnDBhwm1f/OIXn/cEAADAexMAAwCQKI8++ujy/fff/42DDjrohOZwHXRERHFxcRx11FHR2NgYb731locAoJkbPXp0XHHFFVFSUtJs1pxOpxsefvjhr15yySWzPAEAAPD+BMAAACTO+PHjVw0cOHDpAQcccGxzOQmcSqViwIAB0aVLl3jjjTeiqanJgwDQzBQVFcWll14aJ554YrP53m/EP07+Pv7447dffPHFMz0FAADwwQTAAAAk0iOPPLLs0EMPXbb//vs3mxA4IqJHjx4xZMiQePPNN2Pr1q0eBIBmonv37vEv//IvccABBzSrdWcymaYnnnji9s997nPPeAoAAODDEQADAJBYDz/88NJjjjlmY+/evY+KiGZzFKq0tDSGDx8eq1evjvXr13sQAHLcwIED45prrol27do1t6VnZsyY8YOzzjprqqcAAAA+PAEwAACJdv/99795zDHHVO6zzz5HRDMKgVu0aBGHHXZYtGzZMhYuXBjpdNrDAJBjCgoK4pxzzonzzz8/WrRo0dyWn37uuefuOuWUUyZ4EgAA4KMRAAMAkHi///3v5w8bNmxF3759j2lO10GnUqno27dvDB06NBYvXhxbtmzxMADkiJ49e8YNN9wQgwcPblbf+434x7XPU6ZM+fbpp58+2ZMAAAAfnQAYAICc8OCDDy4ZNmzYin79+jWrEDgionXr1nHEEUdEfX19LF261MMAkGCpVCpOOOGEuOKKK6JNmzbNbv07wt9vnXPOOX/xNAAAwMcjAAYAIGc89NBDS4YNG7a8X79+xza3EDg/Pz8OPvjg6NWrV8yfPz8aGho8EAAJU1JSEpdffnmccMIJkZ+f3+zWn8lkGp944olvffazn53maQAAgI9PAAwAQE556KGHlo4cOXJdnz59RqWa252ZEdG1a9cYNmxYLFu2LCorKz0QAAnRt2/fuO6662K//fZrluvPZDLpp59++rvnnHPO054GAAD4ZATAAADknD/96U+LDj300KX7779/s7sOOiKiuLg4jjzyyCgpKYk333wz0um0hwIgSxUUFMRnP/vZuPDCC6OkpKRZ9iCdTjc88sgjt5x//vnTPREAAPDJCYABAMhJDz/88NId3wQelUqlmt09mqlUKvr06RMHH3xwLFy4MLZt2+ahAMgynTt3jrFjx8bQoUOjGV5aERH/CH+feOKJ2y+88MLnPBEAALBrCIABAMhZDz300JIePXq8NmjQoGPz8vJaNMcetG3bNkaNGhVNTU2xZMkSDwVAFkilUjF69Oi48soro0OHDs22D01NTdt++9vf/stll132oqcCAAB2HQEwAAA5bdKkSeXdu3efM3jw4GYbAufn58eAAQOiV69esWDBgti+fbsHA2Avad26dVx66aVx/PHHR35+frPtQ2NjY/WvfvWrf7nuuute81QAAMCuJQAGACDnTZ48eW1jY+OMI4444uiCgoKS5tqHrl27xqhRo2Lbtm2xcuVKDwbAHpRKpWLUqFExduzY6NWrV7PuRX19/fo77rjjK9/61rcWejIAAGDXEwADANAsPP/881UbNmx45rjjjjuqsLCwrLn2obCwMAYNGhT77bdfLF68OGpraz0cALtZ+/bt44orrogTTzwxCgub9/uU2tralTfffPPVP/nJT1Z7MgAAYPcQAAMA0Gz87W9/27p27doZJ5xwwsjCwsK2zbkXnTp1ipEjR0Z1dbXTwAC70ciRI+Pqq6+OHj16NPte1NTULL/hhhuu/e1vf7vOkwEAALuPABgAgGbltdde2zpv3rynTznllKFFRUWdmnMvCgsL49BDD4399tsvFi1a5DQwwC709qnfk08+udmf+o2I2Lx587yLL774unHjxm30dAAAwO71fgFwat9zYsTOftC4LmLjq610DwCAxOrVq1fhs88++69du3Y9QTciGhoaYurUqTF58uRobGzUEICPqaCgIE499dQYPXq04HeH8vLyp4499tjvrly5skE3AABg9+swrDYKuuz8ZwJgAAByWuvWrfNeeumlm/fdd9+zdeMfVq9eHffff38sWbJEMwA+ov322y8uuugi1z2/w8KFC38/fPjwnzY0NGR0AwAA9gwBMAAAzd7zzz9/8aGHHnp1RKR0IyKTycTMmTPjz3/+c9TV1WkIwAcoKSmJ8847L0aMGBGplL9Kdki//PLL9xx77LEPagUAAOxZ7xcA+wYwAADNwn333Tfn+OOP39yrV6/DQwgcqVQqevfuHcOHD49169ZFRUWFhwTgPRxyyCExduzY6N+/v/B3h0wm0/jMM8/828knnzxONwAAYM97v28AC4ABAGg2fve7370xePDgJf369Ts6lUrl60hEcXFxjBgxInr06BFLly6N2tpaTQHYoUOHDvGFL3whzjzzzCguLtaQHZqammoeeOCBWz73uc9N1w0AANg7BMAAALDDww8/vKygoOC54cOHH1FQUFCqI//QrVu3OO6446K0tDQWL14cTU1NmgI0Wy1btoxzzjknLr300ujevbuGvENtbe2K22677arbbrvtDd0AAIC9RwAMAADv8Oyzz25avHjx0yeddNKQoqKiTjryD3l5edGnT58YOXJkbN26NVatWqUpQLNz+OGHx1e+8pUYMGBA5OXlacg7VFVV/e3CCy+8/oEHHvDdAAAA2MsEwAAA8C7z58+vefbZZ58+44wz+hcXF/fSkf/RsmXLGDJkSOyzzz6xdOnSqKmp0RQg53Xs2DG++MUvximnnBItW7bUkHdZt27dMyeffPI3Xn755W26AQAAe9/7BcCpfc+JETv7QeO6iI2vttI9AAByWmFhYer555//0sEHH3y5bvxfTU1N8fzzz8f48eOjurpaQ4Cc07p16zjzzDPjyCOPdOJ35zJ///vff3rMMcfc39DQkNEOAADIDh2G1UZBl53/TAAMAAARMWnSpM8cc8wxt6RSKdfg7ERNTU1MmTIlpk2bFg0NDRoCJF5hYWGccsopcdJJJ0VRUZGG7EQ6na6fOnXqd88555y/6AYAAGSX9wuAXQENAAAR8Yc//GHhfvvt98aAAQOOysvLkwS8S2FhYQwYMCCGDh0amzZtinXr1mkKkFiDBw+Oq666KoYOHRoFBQUashONjY1Vv//972/5whe+MEs3AAAg+/gGMAAAfAgTJkxYXV1dPf3II4/8VGFhYTsd+b9KS0vjsMMOi/79+8eaNWti8+bNmgIkRu/evePyyy+PU045JUpLSzXkPWzdunXxLbfccs33vve9hboBAADZyTeAAQDgI+jTp0+LJ5988us9evQ4TTfe3/z58+ORRx6JlStXagaQtXr16hXnnHNODBgwQDM+wKpVq5444YQTfrBy5Ur3/QMAQBbzDWAAAPgYnnnmmfOHDx9+fSqVytON95bJZGL27Nkxbty4qKio0BAga3Tu3DnOOuusGDp0aKRSKQ15/z/Lm2bNmvXDk08++THdAACA7OcbwAAA8DH85je/eX3//fd//cADDzzSd4HfWyqViu7du8cxxxwT7dq1i2XLlkV9fb3GAHtN27Zt49xzz42LL744evToIfz9AI2NjdUPPvjgLZ/97Gf/ohsAAJAMvgEMAAAf0/jx41dFxPOHHXbYiMLCwjIdeW95eXnRu3fvOOqoo6KgoCBWrlwZjY2NGgPsMcXFxXHKKafEl770pejbt2/k5bnA4YPU1tau+MEPfnD9LbfcMk83AAAgQf/94xvAAADwyQwePLjVo48++s1u3bqdpBsfTn19fTzzzDMxderU2LZtm4YAu01ZWVmceuqpceSRR0ZRkQsbPqyVK1c+/ulPf/pHixcvdm0DAAAkjG8AAwDALvLkk0+edeSRR96USqVcl/MhCYKB3eXtE7/HHnus4PcjyGQyDbNmzfoP3/sFAIDk8g1gAADYRX7/+98v6NGjx2uHHHLIyPz8fL8x+SEUFBREv3794qijjoq8vLxYtWqVq6GBT6Rly5ZxwgknxBVXXBEHHXRQFBQUaMqH1NDQsOG3v/3t1z7/+c8/oxsAAJBcroAGAIBd7Lzzzut4991339m2bdvBuvHR1NTUxLPPPhvTpk2LLVu2aAjwoZWVlcXxxx8fxxxzTBQXF2vIR1RVVfW3a6+99vZHHnlkg24AAECyuQIaAAB2g06dOhVMmzZtbN++fT8XESkd+WgaGhri+eefjyeffDI2bJBFAO/7522cdNJJccQRR0RhodvKPobMokWL/nTsscf+pLKyskk7AAAg+QTAAACwG/3hD38Ydfrpp99WUFDQRjc+unQ6Ha+++mpMnTo1Vq5cqSHAP/Xq1StOOeWUGDp0aOTl5WnIx9DY2Fg1YcKEOy666KKZugEAALlDAAwAALvZaaed1vbee+/9docOHUbqxse3fPnymDZtWrz88suRTqc1BJqhvLy8OOyww+L444+P3r17a8gnsHHjxue//OUvf3fSpElVugEAALlFAAwAAHtAYWFh6qmnnjpv+PDh16RSKXeUfgIbNmyIGTNmxHPPPRc1NTUaAs1AcXFxjBo1Ko4++ujo2LGjhnwCmUym4ZVXXvl/J5100kMNDQ0ZHQEAgNzzfgFwftuDoufOfpDeFlFb7p0VAAB8WOl0On7zm9+8Xlpa+uLgwYM/VVhYWKYrH09xcXEMGDAgjj322GjTpk2sXbs2amtrNQZyUIcOHeKMM86ISy+9NAYOHBjFxcWa8gnU1tau+slPfnLjxRdf/IybFAAAIHcVd2+MvNKd/8wJYAAA2A1OPPHENvfdd9+tnTp1Olo3PrnGxsb429/+Fs8++2wsWrRIQyAH9OvXL44++ugYNmxYFBQUaMguUFFR8cwXv/jFf5s+ffoW3QAAgNzmCmgAANhLHn744RNGjx799YKCgta6sWusX78+Zs6cGc8//3xUV1drCCRIaWlpHHnkkXHUUUdF586dNWQXaWxs3DJ16tS7PvvZz/5FNwAAoHkQAAMAwF50ySWXdP3+97//rXbt2g3VjV2nsbExXnvttXjuuedi/vz5GgJZbMCAATFq1KgYPHiw0767WFVV1atf//rXv/e73/1urW4AAEDzIQAGAIC9rF27dvlTp0699OCDD740lUrl68iutXz58nj++efj5ZdfjpqaGg2BLFBSUhLDhw+PI444Inr37q0hu1gmk2mcN2/efSeeeOJvq6urfewXAACaGQEwAABkia9//ev73Xjjjf9aWlraXzd2vXQ6HW+++WY899xz8dprr0VjY6OmwB5UUFAQgwcPjlGjRsUBBxwQeXl5mrIbVFdXL/zP//zPf/3BD36wRDcAAKB5EgADAEAWOfjgg1v9+c9/vrZ3795jIiKlI7tHZWVlvPjii/HCCy/EunXrNAR2o65du8bIkSPj8MMPj7Zt22rI7pNZunTpn88888z/t3jx4nrtAACA5ksADAAAWejuu+8eePHFF9/WqlUrd6PuZuXl5fHqq6/GSy+9FOvXr9cQ2AU6d+4cI0aMiGHDhkW3bt00ZDerqalZ9tvf/vbOm266aa5uAAAAAmAAAMhS/fr1K3r44Ycv79+//4WpVMpdqXvA8uXL46WXXoqXX345qqurNQQ+grKyshg+fHiMGDHCd333kEwmk164cOEfzj777F8sXbp0u44AAAARAmAAAMh6P/3pT4d97nOf+2bLli176Mae0dDQEHPnzo2//vWvMXfu3Ni+Xa4CO9OyZcsYNGhQDBs2LA455JAoKCjQlD2ktrZ21R//+Mc7rr322r/rBgAA8E4CYAAASIA+ffq0ePTRR69wGnjPS6fTsXTp0nj11VedDIaIaNu2bQwbNiyGDRsWffr0ibw8fyTtSZlMpuG11177+ZlnnvmnioqKRh0BAADeTQAMAAAJ8uMf//jQCy644JutWrXaRzf2vLdPBs+ePTvmzp0bdXV1mkKzUFZWFoMHD45hw4ZF//79Iz8/X1P2gpqammX333//nTfccINv/QIAAO9JAAwAAAnTrl27/HHjxp37qU996qq8vDwb870kk8nEihUrYu7cuTFnzpxYsWJFZDIZjSEnpFKp6Nu3bwwbNiwGDRoUHTt21JS9qKmpqfbVV1/92ZgxY/5cWVnZpCMAAMD7EQADAEBCffnLX+5x++23f7V9+/aH68bet2XLlnjjjTdizpw5MW/evKivr9cUEqVly5Zx8MEHx6BBg+KQQw6J0tJSTckCGzdufPG73/3uv//iF79YoxsAAMCHIQAGAIAEKywsTE2cOPGMkSNHXlNQUNBaR7JDXV1dvPnmm/HGG2/EG2+8EevXr9cUslKXLl3ioIMOioMOOigOOOCAKCoq0pQs0djYuGXmzJk/PvPMMyc2NDS4XgAAAPjQBMAAAJADjjzyyNY/+9nPrujbt++5EZGnI9mluro6Fi5cGPPnz4958+ZFZWWlprBXtGvXLg455JAYMGBA9O/fP1q39nsjWSj91ltv/fmqq676xaxZs6q1AwAA+KgEwAAAkEN++ctfjhgzZsyNrVq16q0b2SmdTsfKlStj0aJFsXDhwli8eHFs27ZNY9gtSkpKol+/ftG/f//Yf//9o1evXpGX53dEslVNTc3yRx999EdXXnnlK7oBAAB8XAJgAADIMd26dSt8+OGHPzd48ODL8vPzbdyzXCaTiTVr1sTChQtj0aJFsWjRotiyZYvG8LGUlZVF//79/xn6du/ePVKplMZkuaampprXXnvtV2PGjHmgoqKiUUcAAIBPQgAMAAA56rjjjiv7r//6r8tdC508mzdvjuXLl8eKFSti+fLlsXjx4qipqdEY/pfi4uLo169f9O7dO/bZZ5/Yd999o6ysTGMSJJPJpJcsWfLn66677pfTp0/3mx8AAMAuIQAGAIAc99Of/nTIueeee3NpaWlf3UimxsbGWLlyZSxdujSWLVsWy5cvj3Xr1kUmk9GcZiKVSkWXLl1in332iT59+kSfPn2iV69eUVBQoDkJtXXr1sUPPvjgj6699tq/6wYAALArCYABAKAZaNeuXf64cePOGTp06BUFBQWtdST56uvrY+XKlf88KbxixYpYu3ZtpNNpzUm4vLy86Nq1a+yzzz7//KdXr17RsmVLzckBjY2NW/7617/+4pxzznm0srKySUcAAIBdTQAMAADNyIknntjmnnvuuXzfffcdk0qlHB3MMdu3b481a9bEmjVrYu3atbF27dooLy+PDRs2CIazUF5eXnTs2DG6desWXbt2jW7dukW3bt2iR48eUVhYqEE5JpPJNC5ZsuRR1z0DAAC7mwAYAACaoa9+9av7Xnfdddd16NDhCN3IfY2Njf8MhNetWxfr1q2LioqKWLduXWzbtk2DdrPS0tLo3LnzP//p0qVLdO3aNbp27eoK52Ziw4YNM//rv/7rxz/60Y+W6wYAALC7CYABAKAZ++UvfznirLPOuq64uNj3gZupmpqaWL9+/T//qaioiMrKyqisrIxNmzZFY2OjJn2AgoKCaN++fbRr1y7at28fHTt2jC5dukSnTp2ic+fOUVxcrEnN1NatW98aP378PVdcccXLugEAAOwpAmAAAGjm2rVrl//ggw+eOWLEiCsLCwvb6gjvtHnz5n+GwZs2bYrKysqorq6OLVu2xJYtW6K6ujqqq6sjk8nk3NpTqVS0bt06WrduHWVlZdGmTZsoLS39X2Fvu3btok2bNh4U/peGhobKl1566efnnHPO+OrqavevAwAAe5QAGAAAiIiIoUOHFt97770XHHjggRfk5+c7ssiHlk6n/xkEV1dXR01Nzfv+k8lkora2NtLpdNTX10dTU1PU1dXt0u8U5+XlRcuWLSM/Pz+KiooiLy8vWrVqFalUKoqLi3f6T0lJSbRq1eqfgW9paWnk5eUZMB9aU1NTzYIFC/745S9/+Y+zZ8+u0REAAGBvEAADAAD/y2mnndb2rrvuurRPnz5n5+XlFeoIe9LbgfDbtm/f/r7XUBcUFESLFi3++b/fDnxhT8pkMg1LliwZd8stt/xq0qRJVToCAADsTQJgAABgp0477bS2d95554X777//5wTBAP9XJpNpWLhw4QO33nrrHwS/AABAtni/ADi/7UHRc2c/SG+LqC33/gcAAHLZokWL6u69995X0un0swcddFCnkpKS3roC8A8VFRUz/7//7/+77aKLLpq6aNGiOh0BAACyRXH3xsgr3fnPBMAAAEDMnDmz8u67736qqalpWr9+/Ypbt27dN5VKpXQGaG4ymUx6zZo1U+65555/Peeccx6cOXNmpa4AAADZRgAMAAB8KDNnzqz88Y9//Gw6nZ4uCAaak7eD37vvvvtfzz///McEvwAAQDYTAAMAAB+JIBhoLgS/AABAEgmAAQCAj+XtILisrOyFvn37diwuLu4VEYJgIBdkKioqnrv33nu/PWbMmEcEvwAAQJK8XwCc2vecGLGzHzSui9j4aivdAwAA/unqq6/u8ZWvfOX8Pn36nJWXl9dCR4CkSafT9UuXLh3/X//1Xw/84he/WKMjAABAEnUYVhsFXXb+MwEwAADwkZ1xxhntb7/99rMPPPDA8/Pz81vrCJDtmpqaqhcsWPDgd77znUcmTpzotC8AAJBoAmAAAGC3GD58eMkPf/jDzwwePPjioqKijjoCZJv6+voNr7322u9vvPHGx2fPnl2jIwAAQC4QAAMAALvV0KFDi++5556zDjnkkPOKioq66giwt9XV1a19/fXXH7z++uvHC34BAIBcIwAGAAD2iFatWuXdc889w0455ZTzO3bseJSOAHtYZsOGDbOmTJny4PXXX/9qbW1tWksAAIBcJAAGAAD2uH/913/tf/7555/dq1ev0/Ly8lroCLC7pNPp+pUrV05+4IEHHvnOd76zSEcAAIBcJwAGAAD2mjPOOKP97bfffvYBBxzw2YKCgjY6AuwqjY2NVW+++eafv/e97z06YcKETToCAAA0FwJgAABgrxs+fHjJ97///dGDBg0aU1paur+OAB9XdXX1wtdee+3Rr371q1Nfe+21Wh0BAACaGwEwAACQVb761a/ue8EFF3y6b9++ZxUUFLTWEeCDNDY2bnnrrbfG/+EPf5j4ox/9aLmOAAAAzZkAGAAAyEpDhw4t/sEPfnDy4MGDz27dunV/HQHerbq6+s2XX375weuuu+7ppUuXbtcRAAAAATAAAJDlCgsLU3ffffeQ0aNHn9G1a9fj8vLyinQFmq90Ol1XXl4+bcqUKROuvfbav+sIAADA/yYABgAAEqNPnz4t/v3f/33UyJEjz2rfvv2nIiKlK9AsZDZt2vTXF1544bGvfe1rzzntCwAA8N4EwAAAQCJddNFFXa6++uqTDzzwwLNbtmzZTUcg99TV1a1ZsGDBuJ/+9KdP3n///et0BAAA4IMJgAEAgETr1q1b4d13333k4YcffmqHDh2OyMvLK9QVSK50Ot2wcePGWbNmzZp8/fXXz6qoqGjUFQAAgA9PAAwAAOSMo48+uvWtt956/CGHHHJKu3btBkdEnq5AIqQrKytfmzdv3uQ777xz+owZM6q1BAAA4OMRAAMAADnpuOOOK/vGN75x/CGHHHJa27ZtB4bvBUO2yVRVVc2dN2/epO9///vTpk+fvkVLAAAAPjkBMAAAkPNuu+22vmedddZJffr0Oa5Vq1a9dQT2ntra2uXLly+f/uijjz51xx13vKUjAAAAu5YAGAAAaFa+9KUvdbv44ouP7t+//wlOBsMekamqqpq7cOHCv/z+97+fcd9995VrCQAAwO4jAAYAAJqtSy65pOtll112jDAYdrl0VVXVvIULF/7lV7/61bO/+93v1moJAADAniEABgAAiIirr766x/nnnz9q//33P7JNmzZDUqlUga7Ah5fJZBoqKyv/vnjx4uf+9Kc/zbr33ntX6woAAMCeJwAGAAB4l379+hV97WtfGzRy5MhRPXv2PLaoqKizrsD/VV9fv37VqlXPvPDCC8/9+7//+5zFixfX6woAAMDeJQAGAAB4H61bt8678847Bx599NFHde/efURpaen+4apomq/M1q1bF69Zs+bF5557btY3v/nNOdXV1WltAQAAyB4CYAAAgI9g8ODBrcaOHXvI8OHDD+vevfvw1q1bHxACYXJXprq6+s01a9a88sorr7z8k5/8ZN5rr71Wqy0AAADZSwAMAADwCVx//fX7nHHGGYf169dvePv27Yfm5+e31hWSrLGxsXrjxo2vvvXWWy+PHz/+lR//+McrdQUAACA5BMAAAAC70Je//OUe55xzzvA+ffoM7tix45CioqKuukI2q6+vX7t27doXFy9ePGfixImv3Xvvvat1BQAAILkEwAAAALvRl7/85R6f+cxnBvfr129Qly5dDm/ZsqVAmL2qrq5u7bp16wS+AAAAOUoADAAAsIe0atUq75prrtnn2GOPPXi//fY7uH379oeUlpb2TaVS+brDbpKuqalZtnHjxnlvvfXW3GeffXbef/3Xfy2vra1Naw0AAEBuEgADAADsRQceeGDLq6+++oAhQ4Yc3LNnz4Pbtm17sGuj+biampqqq6qqXi8vL583Z86ceb/85S/nvfjii1t1BgAAoPkQAAMAAGSZoUOHFn/xi1/cf9CgQQf26NHjwHbt2h3YqlWr3qlUKk932CFdU1OzvLKycsHq1asXzJkzZ8Gf//znJTNmzKjWGgAAgOZNAAwAAJAAxx13XNkFF1xw4MEHH3xA165dDywtLd23pKRkn1QqVag7uS2TyTRs27ZtRXV19dJ169YtfOONNxZOmDBh4YQJEzbpDgAAAO8mAAYAAEiw8847r+OJJ57Yp3///vt16dKlT5s2bfZr3bp1v/z8/GLdSZampqaa6urqxZs3b16ybt26pQsXLlzy9NNPL33ooYc26A4AAAAflgAYAAAgx7Rr1y7/kksu6TFkyJCe++67b89OnTr1Kisr61VcXNyzZcuW3VKpVL4u7R2ZTKaprq6uvKamZtWWLVtWVlRUrFy6dOnK2bNnr7r//vvXVFZWNukSAAAAn4QAGAAAoBnp1KlTwec+97luQ4cO7bnPPvv0aNeuXafWrVt3Li4u7tqyZcvORUVFnfLy8lro1MeTTqe319fXr6+rq6uoqalZW11dvb6ysnL9ihUrVr/66qurHnzwwbUVFRWNOgUAAMDuIgAGAADgfznjjDPaH3bYYZ369OnTuUuXLp3Kysral5SUtC0uLu5YVFTUrqioqG2LFi065OfnlzaXnjQ1NW3dvn37xvr6+qr6+vrKmpqaDdu2bavasmXLpnXr1lUsXbp0/Ysvvrh+4sSJlZ4gAAAA9iYBMAAAAB9Lr169CkeNGtXuoIMOatexY8ey9u3bl7Zp06Z1SUlJWXFxcetWrVq1btGiRVlRUVHrwsLC1hGRX1hYWBoR+QUFBSV5eXkFeXl5u/0/LtPpdG06nW5sbGzcFhFNDQ0NW3f83+r6+vrq7du3b6mtra2uqamp3rZtW/XmzZurN23aVL1hw4YtCxYsqJo1a1bl0qVLt5s4AAAASSAABgAAYK/q169fUffu3Vvss88+xSUlJQVv//8LCwtT3bp1+8BTxuXl5VsbGhoyb//vbdu2Na5YsaJmzZo12xcvXlyvwwAAADQn7xcAF2gPAAAAu9vixYvrdwS11boBAAAAu0+eFgAAAAAAAADkBgEwAAAAAAAAQI4QAAMAAAAAAADkCAEwAAAAAAAAQI4QAAMAAAAAAADkCAEwAAAAAAAAQI4QAAMAAAAAAADkCAEwAAAAAAAAQI4QAAMAAAAAAADkCAEwAAAAAAAAQI4QAAMAAAAAAADkCAEwAAAAAAAAQI4QAAMAAAAAAADkCAEwAAAAAAAAQI4o0AIAAAAAAACA5GhoLIyCxoaIiEilIpNXGE1v/0wADAAAAAAAAJAghQUN/0x6MxGppvT/5L6ugAYAAAAAAADIEQJgAAAAAAAAgBwhAAYAAAAAAADIEQJgAAAAAAAAgBwhAAYAAAAAAADIEQJgAAAAAAAAgBwhAAYAAAAAAADIEQJgAAAAAAAAgBwhAAYAAAAAAADIEQJgAAAAAAAAgBwhAAYAAAAAAADIEQJgAAAAAAAAgBwhAAYAAAAAAADIEQJgAAAAAAAAgBwhAAYAAAAAAADIEQJgAAAAAAAAgBwhAAYAAAAAAADIEQJgAAAAAAAAgBwhAAYAAAAAAADIEQJgAAAAAAAAgBwhAAYAAAAAAADIEQJgAAAAAAAAgBwhAAYAAAAAAADIEQJgAAAAAAAAgBwhAAYAAAAAAADIEQJgAAAAAAAAgBwhAAYAAAAAAADIEQJgAAAAAAAAgBwhAAYAAAAAAADIEQJgAAAAAAAAgBwhAAYAAAAAAADIEQJgAAAAAAAAgBwhAAYAAAAAAADIEQJgAAAAAAAAgBwhAAYAAAAAAADIEQJgAAAAAAAAgBwhAAYAAAAAAADIEQJgAAAAAAAAgBwhAAYAAAAAAADIEQJgAAAAAAAAgBwhAAYAAAAAAADIEQJgAAAAAAAAgBwhAAYAAAAAAADIEQJgAAAAAAAAgBwhAAYAAAAAAADIEQJgAAAAAAAAgBwhAAYAAAAAAADIEQJgAAAAAAAAgBwhAAYAAAAAAADIEQJgAAAAAAAAgBwhAAYAAAAAAADIEQJgAAAAAAAAgBwhAAYAAAAAAADIEQJgAAAAAAAAgBwhAAYAAAAAAADIEQJgAAAAAAAAgBwhAAYAAAAAAADIEQJgAAAAAAAAgBwhAAYAAAAAAADIEQJgAAAAAAAAgBwhAAYAAAAAAADIEQJgAAAAAAAAgBwhAAYAAAAAAADIEQJgAAAAAAAAgBwhAAYAAAAAAADIEQJgAAAAAAAAgBwhAAYAAAAAAADIEQJgAAAAAAAAgBwhAAYAAAAAAADIEQJgAAAAAAAAgBwhAAYAAAAAAADIEQJgAAAAAAAAgBwhAAYAAAAAAADIEQJgAAAAAAAAgBwhAAYAAAAAAADIEQJgAAAAAAAAgBwhAAYAAAAAAADIEQJgAAAAAAAAgBwhAAYAAAAAAADIEQJgAAAAAAAAgBwhAAYAAAAAAADIEQJgAAAAAAAAgBwhAAYAAAAAAADIEQJgAAAAAAAAgBwhAAYAAAAAAADIEQJgAAAAAAAAgBwhAAYAAAAAAADIEQJgAAAAAAAAgBwhAAYAAAAAAADIEQJgAAAAAAAAgBwhAAYAAAAAAADIEQJgAAAAAAAAgBwhAAYAAAAAAADIEQJgAAAAAAAAgBwhAAYAAAAAAADIEQJgAAAAAAAAgBwhAAYAAAAAAADIEQJgAAAAAAAAgBwhAAYAAAAAAADIEQJgAAAAAAAAgBwhAAYAAAAAAADIEQJgAAAAAAAAgBwhAAYAAAAAAADIEQJgAAAAAAAAgBwhAAYAAAAAAADIEQJgAAAAAAAAgBwhAIb/v5272ZHiusM4/FZ1NUkz9sQwOF4EyZJtpJCwysa5jSy4n1xPEqRIuQFvvfGSgIwBOzGRQAQERnx0d1UW0cgWGvKxsMGvnmfVdc7/1OJsf+oCAAAAAACAEgIwAAAAAAAAQAkBGAAAAAAAAKCEAAwAAAAAAABQQgAGAAAAAAAAKCEAAwAAAAAAAJQQgAEAAAAAAABKCMAAAAAAAAAAJQRgAAAAAAAAgBICMAAAAAAAAEAJARgAAAAAAACghAAMAAAAAAAAUEIABgAAAAAAACghAAMAAAAAAACUEIABAAAAAAAASgjAAAAAAAAAACUEYAAAAAAAAIASAjAAAAAAAABACQEYAAAAAAAAoIQADAAAAAAAAFBCAAYAAAAAAAAoIQADAAAAAAAAlBCAAQAAAAAAAEoIwAAAAAAAAAAlBGAAAAAAAACAEgIwAAAAAAAAQAkBGAAAAAAAAKCEAAwAAAAAAABQQgAGAAAAAAAAKCEAAwAAAAAAAJQQgAEAAAAAAABKCMAAAAAAAAAAJQRgAAAAAAAAgBICMAAAAAAAAEAJARgAAAAAAACghAAMAAAAAAAAUEIABgAAAAAAACghAAMAAAAAAACUEIABAAAAAAAASgjAAAAAAAAAACUEYAAAAAAAAIASAjAAAAAAAABACQEYAAAAAAAAoIQADAAAAAAAAFBCAAYAAAAAAAAoIQADAAAAAAAAlBCAAQAAAAAAAEoIwAAAAAAAAAAlBGAAAAAAAACAEgIwAAAAAAAAQAkBGAAAAAAAAKCEAAwAAAAAAABQQgAGAAAAAAAAKCEAAwAAAAAAAJQQgAEAAAAAAABKCMAAAAAAAAAAJQRgAAAAAAAAgBICMAAAAAAAAEAJARgAAAAAAACghAAMAAAAAAAAUEIABgAAAAAAACghAAMAAAAAAACUEIABAAAAAAAASgjAAAAAAAAAACUEYAAAAAAAAIASAjAAAAAAAABACQEYAAAAAAAAoIQADAAAAAAAAFBCAAYAAAAAAAAoIQADAAAAAAAAlBCAAQAAAAAAAEoIwAAAAAAAAAAlBGAAAAAAAACAEgIwAAAAAAAAQAkBGAAAAAAAAKCEAAwAAAAAAABQQgAGAAAAAAAAKCEAAwAAAAAAAJQQgAEAAAAAAABKCMAAAAAAAAAAJQRgAAAAAAAAgBICMAAAAAAAAEAJARgAAAAAAACghAAMAAAAAAAAUEIABgAAAAAAACghAAMAAAAAAACUEIABAAAAAAAASgjAAAAAAAAAACUEYAAAAAAAAIASAjAAAAAAAABACQEYAAAAAAAAoIQADAAAAAAAAFBCAAYAAAAAAAAoIQADAAAAAAAAlBCAAQAAAAAAAEoIwAAAAAAAAAAlBGAAAAAAAACAEgIwAAAAAAAAQAkBGAAAAAAAAKCEAAwAAAAAAABQQgAGAAAAAAAAKCEAAwAAAAAAAJQQgAEAAAAAAABKCMAAAAAAAAAAJQRgAAAAAAAAgBICMAAAAAAAAEAJARgAAAAAAACghAAMAAAAAAAAUEIABgAAAAAAACghAAMAAAAAAACUEIABAAAAAAAASgjAAAAAAAAAACUEYAAAAAAAAIASAjAAAAAAAABACQEYAAAAAAAAoIQADAAAAAAAAFBCAAYAAAAAAAAoIQADAAAAAAAAlBCAAQAAAAAAAEoIwAAAAAAAAAAlBGAAAAAAAACAEgIwAAAAAAAAQAkBGAAAAAAAAKCEAAwAAAAAAABQQgAGAAAAAAAAKCEAAwAAAAAAAJQQgAEAAAAAAABKCMAAAAAAAAAAJQRgAAAAAAAAgBICMAAAAAAAAEAJARgAAAAAAACghAAMAAAAAAAAUEIABgAAAAAAACghAAMAAAAAAACUEIABAAAAAAAASgjAAAAAAAAAACUEYAAAAAAAAIASAjAAAAAAAABACQEYAAAAAAAAoIQADAAAAAAAAFBCAAYAAAAAAAAoIQADAAAAAAAAlBCAAQAAAAAAAEoIwAAAAAAAAAAlBGAAAAAAAACAEgIwAAAAAAAAQAkBGAAAAAAAAKCEAAwAAAAAAABQQgAGAAAAAAAAKCEAAwAAAAAAAJQQgAEAAAAAAABKCMAAAAAAAAAAJQRgAAAAAAAAgBICMAAAAAAAAEAJARgAAAAAAACghAAMAAAAAAAAUEIABgAAAAAAACghAAMAAAAAAACUEIABAAAAAAAASgjAAAAAAAAAACUEYAAAAAAAAIASAjAAAAAAAABACQEYAAAAAAAAoIQADAAAAAAAAFBCAAYAAAAAAAAoIQADAAAAAAAAlBCAAQAAAAAAAEoIwAAAAAAAAAAlBGAAAAAAAACAEgIwAAAAAAAAQAkBGAAAAAAAAKCEAAwAAAAAAABQQgAGAAAAAAAAKCEAAwAAAAAAAJQQgAEAAAAAAABKCMAAAAAAAAAAJQRgAAAAAAAAgBICMAAAAAAAAEAJARgAAAAAAACghAAMAAAAAAAAUEIABgAAAAAAACghAAMAAAAAAACUEIABAAAAAAAASgjAAAAAAAAAACUEYAAAAAAAAIASAjAAAAAAAABACQEYAAAAAAAAoIQADAAAAAAAAFBCAAYAAAAAAAAoIQADAAAAAAAAlBCAAQAAAAAAAEoIwAAAAAAAAAAlBGAAAAAAAACAEgIwAAAAAAAAQAkBGAAAAAAAAKCEAAwAAAAAAABQQgAGAAAAAAAAKCEAAwAAAAAAAJQQgAEAAAAAAABKCMAAAAAAAAAAJQRgAAAAAAAAgBICMAAAAAAAAEAJARgAAAAAAACghAAMAAAAAAAAUEIABgAAAAAAACghAAMAAAAAAACUEIABAAAAAAAASgjAAAAAAAAAACUEYAAAAAAAAIASAjAAAAAAAABACQEYAAAAAAAAoIQADAAAAAAAAFBCAAYAAAAAAAAoMY3JP//9K8My551lzpAk293a7QAAAAAAAAD8iIw3r+SL7TpPxuSt4/ibJJuz20QDBgAAAAAAAHhzrJPp6NvHYcyyjLl7dJTPbl/Jp6sPLufSsM+5ec7q5YOrF0OeP/SVaAAAAAAAAIA3weH7u6zfm79dWDIMSw6225w785vsx3XyzasOby5ssz69c4sAAAAAAAAAr9n69C6bC9sT93a7rKdnORin5Otxynzi1JQcfiwCAwAAAAAAALxO69O7HH68TaaT98cp85R8vbp3Nfszv8q0LHn7xMF1sjk/ZzUPmZ/MmWefhAYAAAAAAAD4oayPdjn7223Gn7x6ZrXPnetX8mBKkpv3cufDd/Pufn5FL56SzcVtNheT3dNt8tQlAwAAAAAAAHyv1sm0ySv/9XtsNWZ3I/lHkgzHi7/4XY7WYz5yiwAAAAAAAAA/Ivtcv/3nPEyS1fHa42t5+vNLyX7JoRsCAAAAAAAAePPt1/nbV3/KvePn1Xc371/NYxEYAAAAAAAA4M0yTHk2rvNo2WdzvHZqzN9v/SF3vju3evng/at5fPDLPDu1yuGyZHSVAAAAAAAAAK/XOGe4ueSvZ4e8M8xZbVe5ceuPufvy3Oqkw4+v5emDX+fuuTlLhhwsEYIBAAAAAAAAXpclGR8OuXP0TR4cPM/9z/+SRyfNDf/1TZezOp/87KdjzizJZkhO7edMy/w/nAUAAAAAAADg/zaMWcZkP8/ZLsmLacr2/MV8+cnvs/tP5/4FmLjAq1ifcioAAAAASUVORK5CYII=";
function ie(e, A, t) {
  return (
    typeof e == "string" && !isNaN(Number(e)) && (e = Number(e)),
    typeof e == "number" && e < 100
      ? le(e)
      : typeof e == "number" && e >= 100
        ? e
        : typeof e == "string" && e.includes("%")
          ? Math.round(
              A && A === "X"
                ? (parseFloat(e) / 100) * t.width
                : A && A === "Y"
                  ? (parseFloat(e) / 100) * t.height
                  : (parseFloat(e) / 100) * t.width,
            )
          : 0
  );
}
function ot(e) {
  return e.replace(/[xy]/g, function (A) {
    const t = (Math.random() * 16) | 0;
    return (A === "x" ? t : (t & 3) | 8).toString(16);
  });
}
function re(e) {
  return typeof e > "u" || e == null
    ? ""
    : e
        .toString()
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&apos;");
}
function le(e) {
  return typeof e == "number" && e > 100
    ? e
    : (typeof e == "string" && (e = Number(e.replace(/in*/gi, ""))),
      Math.round(Ae * e));
}
function te(e) {
  const A = Number(e) || 0;
  return isNaN(A) ? 0 : Math.round(A * et);
}
function Ee(e) {
  return ((e = e || 0), Math.round((e > 360 ? e - 360 : e) * 6e4));
}
function ht(e) {
  const A = e.toString(16);
  return A.length === 1 ? "0" + A : A;
}
function mt(e, A, t) {
  return (ht(e) + ht(A) + ht(t)).toUpperCase();
}
function fe(e, A) {
  let t = (e || "").replace("#", "");
  !ut.test(t) &&
    t !== Ce.background1 &&
    t !== Ce.background2 &&
    t !== Ce.text1 &&
    t !== Ce.text2 &&
    t !== Ce.accent1 &&
    t !== Ce.accent2 &&
    t !== Ce.accent3 &&
    t !== Ce.accent4 &&
    t !== Ce.accent5 &&
    t !== Ce.accent6 &&
    (console.warn(
      `"${t}" is not a valid scheme color or hex RGB! "${xe}" used instead. Only provide 6-digit RGB or 'pptx.SchemeColor' values!`,
    ),
    (t = xe));
  const o = ut.test(t) ? "srgbClr" : "schemeClr",
    n = 'val="' + (ut.test(t) ? t.toUpperCase() : t) + '"';
  return A ? `<a:${o} ${n}>${A}</a:${o}>` : `<a:${o} ${n}/>`;
}
function ca(e, A) {
  let t = "";
  const o = Object.assign(Object.assign({}, A), e),
    n = Math.round(o.size * et),
    s = o.color,
    l = Math.round(o.opacity * 1e5);
  return (
    (t += `<a:glow rad="${n}">`),
    (t += fe(s, `<a:alpha val="${l}"/>`)),
    (t += "</a:glow>"),
    t
  );
}
function Le(e) {
  let A = "solid",
    t = "",
    o = "",
    n = "";
  if (e)
    switch (
      (typeof e == "string"
        ? (t = e)
        : (e.type && (A = e.type),
          e.color && (t = e.color),
          e.alpha &&
            (o += `<a:alpha val="${Math.round((100 - e.alpha) * 1e3)}"/>`),
          e.transparency &&
            (o += `<a:alpha val="${Math.round((100 - e.transparency) * 1e3)}"/>`)),
      A)
    ) {
      case "solid":
        n += `<a:solidFill>${fe(t, o)}</a:solidFill>`;
        break;
      default:
        n += "";
        break;
    }
  return n;
}
function Fe(e) {
  return e._rels.length + e._relsChart.length + e._relsMedia.length + 1;
}
function Nt(e) {
  if (!(!e || typeof e != "object"))
    return (
      e.type !== "outer" &&
        e.type !== "inner" &&
        e.type !== "none" &&
        (console.warn(
          "Warning: shadow.type options are `outer`, `inner` or `none`.",
        ),
        (e.type = "outer")),
      e.angle &&
        ((isNaN(Number(e.angle)) || e.angle < 0 || e.angle > 359) &&
          (console.warn("Warning: shadow.angle can only be 0-359"),
          (e.angle = 270)),
        (e.angle = Math.round(Number(e.angle)))),
      e.opacity &&
        ((isNaN(Number(e.opacity)) || e.opacity < 0 || e.opacity > 1) &&
          (console.warn("Warning: shadow.opacity can only be 0-1"),
          (e.opacity = 0.75)),
        (e.opacity = Number(e.opacity))),
      e.color &&
        e.color.startsWith("#") &&
        (console.warn(
          'Warning: shadow.color should not include hash (#) character, , e.g. "FF0000"',
        ),
        (e.color = e.color.replace("#", ""))),
      e
    );
}
function da(e, A, t) {
  var o, n;
  const s =
      2.3 +
      (!((o = e.options) === null || o === void 0) && o.autoPageCharWeight
        ? e.options.autoPageCharWeight
        : 0),
    l =
      Math.floor((A / et) * Ae) /
      ((!((n = e.options) === null || n === void 0) && n.fontSize
        ? e.options.fontSize
        : ke) /
        s),
    c = [];
  let i = [];
  const a = [],
    r = [];
  e.text && e.text.toString().trim().length === 0
    ? i.push({ _type: ne.tablecell, text: " " })
    : typeof e.text == "number" || typeof e.text == "string"
      ? i.push({ _type: ne.tablecell, text: (e.text || "").toString().trim() })
      : Array.isArray(e.text) && (i = e.text);
  let u = [];
  return (
    i.forEach((g) => {
      var d;
      (typeof g.text == "string" &&
        (g.text.split(`
`).length > 1
          ? g.text
              .split(
                `
`,
              )
              .forEach((m) => {
                u.push({
                  _type: ne.tablecell,
                  text: m,
                  options: Object.assign(Object.assign({}, g.options), {
                    breakLine: !0,
                  }),
                });
              })
          : u.push({
              _type: ne.tablecell,
              text: g.text.trim(),
              options: g.options,
            }),
        !((d = g.options) === null || d === void 0) &&
          d.breakLine &&
          (a.push(u), (u = []))),
        u.length > 0 && (a.push(u), (u = [])));
    }),
    a.forEach((g) => {
      g.forEach((d) => {
        const m = [],
          y = String(d.text).split(" ");
        (y.forEach((v, b) => {
          const C = Object.assign({}, d.options);
          (C?.breakLine && (C.breakLine = b + 1 === y.length),
            m.push({
              _type: ne.tablecell,
              text: v + (b + 1 < y.length ? " " : ""),
              options: C,
            }));
        }),
          r.push(m));
      });
    }),
    r.forEach((g) => {
      let d = [],
        m = "";
      (g.forEach((h) => {
        (m.length + h.text.length > l && (c.push(d), (d = []), (m = "")),
          d.push(h),
          (m += h.text.toString()));
      }),
        d.length > 0 && c.push(d));
    }),
    c
  );
}
function qt(e = [], A = {}, t, o) {
  let n = $e,
    s = Ae * 1,
    l = Ae * 1,
    c = 0,
    i = 0;
  const a = [],
    r = ie(A.x, "X", t),
    u = ie(A.y, "Y", t),
    g = ie(A.w, "X", t),
    d = ie(A.h, "Y", t);
  let m = g;
  function h() {
    let v = 0;
    (a.length === 0 && (v = u || le(n[0])),
      a.length > 0 &&
        (v = le(A.autoPageSlideStartY || A.newSlideStartY || n[0])),
      (l = (d || t.height) - v - le(n[2])),
      a.length > 1 &&
        (typeof A.autoPageSlideStartY == "number"
          ? (l = (d || t.height) - le(A.autoPageSlideStartY + n[2]))
          : typeof A.newSlideStartY == "number"
            ? (l = (d || t.height) - le(A.newSlideStartY + n[2]))
            : u &&
              ((l =
                (d || t.height) - le((u / Ae < n[0] ? u / Ae : n[0]) + n[2])),
              l < d && (l = d))));
  }
  if (
    (A.verbose &&
      (console.log("[[VERBOSE MODE]]"),
      console.log(
        "|-- TABLE PROPS --------------------------------------------------------|",
      ),
      console.log(
        `| presLayout.width ................................ = ${(t.width / Ae).toFixed(1)}`,
      ),
      console.log(
        `| presLayout.height ............................... = ${(t.height / Ae).toFixed(1)}`,
      ),
      console.log(
        `| tableProps.x .................................... = ${typeof A.x == "number" ? (A.x / Ae).toFixed(1) : A.x}`,
      ),
      console.log(
        `| tableProps.y .................................... = ${typeof A.y == "number" ? (A.y / Ae).toFixed(1) : A.y}`,
      ),
      console.log(
        `| tableProps.w .................................... = ${typeof A.w == "number" ? (A.w / Ae).toFixed(1) : A.w}`,
      ),
      console.log(
        `| tableProps.h .................................... = ${typeof A.h == "number" ? (A.h / Ae).toFixed(1) : A.h}`,
      ),
      console.log(
        `| tableProps.slideMargin .......................... = ${A.slideMargin ? String(A.slideMargin) : ""}`,
      ),
      console.log(
        `| tableProps.margin ............................... = ${String(A.margin)}`,
      ),
      console.log(
        `| tableProps.colW ................................. = ${String(A.colW)}`,
      ),
      console.log(
        `| tableProps.autoPageSlideStartY .................. = ${A.autoPageSlideStartY}`,
      ),
      console.log(
        `| tableProps.autoPageCharWeight ................... = ${A.autoPageCharWeight}`,
      ),
      console.log(
        "|-- CALCULATIONS -------------------------------------------------------|",
      ),
      console.log(
        `| tablePropX ...................................... = ${r / Ae}`,
      ),
      console.log(
        `| tablePropY ...................................... = ${u / Ae}`,
      ),
      console.log(
        `| tablePropW ...................................... = ${g / Ae}`,
      ),
      console.log(
        `| tablePropH ...................................... = ${d / Ae}`,
      ),
      console.log(
        `| tableCalcW ...................................... = ${m / Ae}`,
      )),
    !A.slideMargin && A.slideMargin !== 0 && (A.slideMargin = $e[0]),
    o && typeof o._margin < "u"
      ? Array.isArray(o._margin)
        ? (n = o._margin)
        : isNaN(Number(o._margin)) ||
          (n = [
            Number(o._margin),
            Number(o._margin),
            Number(o._margin),
            Number(o._margin),
          ])
      : (A.slideMargin || A.slideMargin === 0) &&
        (Array.isArray(A.slideMargin)
          ? (n = A.slideMargin)
          : isNaN(A.slideMargin) ||
            (n = [A.slideMargin, A.slideMargin, A.slideMargin, A.slideMargin])),
    A.verbose &&
      console.log(
        `| arrInchMargins .................................. = [${n.join(", ")}]`,
      ),
    (e[0] || []).forEach((b) => {
      b || (b = { _type: ne.tablecell });
      const C = b.options || null;
      i += Number(C?.colspan ? C.colspan : 1);
    }),
    A.verbose &&
      console.log(`| numCols ......................................... = ${i}`),
    !g &&
      A.colW &&
      ((m = Array.isArray(A.colW)
        ? A.colW.reduce((v, b) => v + b) * Ae
        : A.colW * i || 0),
      A.verbose &&
        console.log(
          `| tableCalcW ...................................... = ${m / Ae}`,
        )),
    (s = m || le((r ? r / Ae : n[1]) + n[3])),
    A.verbose &&
      console.log(
        `| emuSlideTabW .................................... = ${(s / Ae).toFixed(1)}`,
      ),
    !A.colW || !Array.isArray(A.colW))
  )
    if (A.colW && !isNaN(Number(A.colW))) {
      const v = [];
      ((e[0] || []).forEach(() => v.push(A.colW)),
        (A.colW = []),
        v.forEach((C) => {
          Array.isArray(A.colW) && A.colW.push(C);
        }));
    } else {
      A.colW = [];
      for (let v = 0; v < i; v++) A.colW.push(s / Ae / i);
    }
  let y = { rows: [] };
  return (
    e.forEach((v, b) => {
      const C = [];
      let D = 0,
        L = 0,
        M = [];
      (v.forEach((E) => {
        var J, B, S, p;
        (M.push({ _type: ne.tablecell, text: [], options: E.options }),
          E.options.margin && E.options.margin[0] >= 1
            ? (!((J = E.options) === null || J === void 0) &&
              J.margin &&
              E.options.margin[0] &&
              te(E.options.margin[0]) > D
                ? (D = te(E.options.margin[0]))
                : A?.margin &&
                  A.margin[0] &&
                  te(A.margin[0]) > D &&
                  (D = te(A.margin[0])),
              !((B = E.options) === null || B === void 0) &&
              B.margin &&
              E.options.margin[2] &&
              te(E.options.margin[2]) > L
                ? (L = te(E.options.margin[2]))
                : A?.margin &&
                  A.margin[2] &&
                  te(A.margin[2]) > L &&
                  (L = te(A.margin[2])))
            : (!((S = E.options) === null || S === void 0) &&
              S.margin &&
              E.options.margin[0] &&
              le(E.options.margin[0]) > D
                ? (D = le(E.options.margin[0]))
                : A?.margin &&
                  A.margin[0] &&
                  le(A.margin[0]) > D &&
                  (D = le(A.margin[0])),
              !((p = E.options) === null || p === void 0) &&
              p.margin &&
              E.options.margin[2] &&
              le(E.options.margin[2]) > L
                ? (L = le(E.options.margin[2]))
                : A?.margin &&
                  A.margin[2] &&
                  le(A.margin[2]) > L &&
                  (L = le(A.margin[2]))));
      }),
        h(),
        (c += D + L),
        A.verbose &&
          b === 0 &&
          console.log(
            `| SLIDE [${a.length}]: emuSlideTabH ...... = ${(l / Ae).toFixed(1)} `,
          ),
        v.forEach((E, J) => {
          var B;
          const S = {
            _type: ne.tablecell,
            _lines: null,
            _lineHeight: le(
              ((!((B = E.options) === null || B === void 0) && B.fontSize
                ? E.options.fontSize
                : A.fontSize
                  ? A.fontSize
                  : ke) *
                (na + (A.autoPageLineWeight ? A.autoPageLineWeight : 0))) /
                100,
            ),
            text: [],
            options: E.options,
          };
          (S.options.rowspan && (S._lineHeight = 0),
            (S.options.autoPageCharWeight = A.autoPageCharWeight
              ? A.autoPageCharWeight
              : null));
          let p = A.colW[J];
          (E.options.colspan &&
            Array.isArray(A.colW) &&
            (p = A.colW
              .filter((T, Z) => Z >= J && Z < Z + E.options.colspan)
              .reduce((T, Z) => T + Z)),
            (S._lines = da(E, p)),
            C.push(S));
        }),
        A.verbose &&
          console.log(`
| SLIDE [${a.length}]: ROW [${b}]: START...`));
      let _ = 0,
        X = 0,
        P = !1;
      for (; !P;) {
        const E = C[_];
        let J = M[_];
        (C.forEach((p) => {
          p._lineHeight >= X && (X = p._lineHeight);
        }),
          c + X > l &&
            (A.verbose &&
              (console.log(`
|-----------------------------------------------------------------------|`),
              console.log(
                `|-- NEW SLIDE CREATED (currTabH+currLineH > maxH) => ${(c / Ae).toFixed(2)} + ${(E._lineHeight / Ae).toFixed(2)} > ${l / Ae}`,
              ),
              console.log(`|-----------------------------------------------------------------------|

`)),
            M.length > 0 &&
              M.map((T) => T.text.length).reduce((T, Z) => T + Z) > 0 &&
              y.rows.push(M),
            a.push(y),
            (y = { rows: [] }),
            (M = []),
            v.forEach((T) =>
              M.push({ _type: ne.tablecell, text: [], options: T.options }),
            ),
            h(),
            (c += D + L),
            A.verbose &&
              console.log(
                `| SLIDE [${a.length}]: emuSlideTabH ...... = ${(l / Ae).toFixed(1)} `,
              ),
            (c = 0),
            (A.addHeaderToEach || A.autoPageRepeatHeader) &&
              A._arrObjTabHeadRows &&
              A._arrObjTabHeadRows.forEach((T) => {
                const Z = [];
                let U = 0;
                (T.forEach((ae) => {
                  (Z.push(ae), ae._lineHeight > U && (U = ae._lineHeight));
                }),
                  y.rows.push(Z),
                  (c += U));
              }),
            (J = M[_])));
        const B = E._lines.shift();
        (Array.isArray(J.text) &&
          (B
            ? (J.text = J.text.concat(B))
            : J.text.length === 0 &&
              (J.text = J.text.concat({ _type: ne.tablecell, text: "" }))),
          _ === C.length - 1 && (c += X),
          (_ = _ < C.length - 1 ? _ + 1 : 0),
          C.map((p) => p._lines.length).reduce((p, T) => p + T) === 0 &&
            (P = !0));
      }
      (M.length > 0 && y.rows.push(M),
        A.verbose &&
          console.log(
            `- SLIDE [${a.length}]: ROW [${b}]: ...COMPLETE ...... emuTabCurrH = ${(c / Ae).toFixed(2)} ( emuSlideTabH = ${(l / Ae).toFixed(2)} )`,
          ));
    }),
    a.push(y),
    A.verbose &&
      (console.log(`
|================================================|`),
      console.log(`| FINAL: tableRowSlides.length = ${a.length}`),
      a.forEach((v) => console.log(v)),
      console.log(`|================================================|

`)),
    a
  );
}
function fa(e, A, t = {}, o) {
  const n = t || {};
  n.slideMargin = n.slideMargin || n.slideMargin === 0 ? n.slideMargin : 0.5;
  let s = n.w || e.presLayout.width;
  const l = [],
    c = [],
    i = [],
    a = [],
    r = [];
  let u = [0.5, 0.5, 0.5, 0.5],
    g = 0;
  if (!document.getElementById(A))
    throw new Error('tableToSlides: Table ID "' + A + '" does not exist!');
  (o?._margin
    ? (Array.isArray(o._margin)
        ? (u = o._margin)
        : isNaN(o._margin) ||
          (u = [o._margin, o._margin, o._margin, o._margin]),
      (n.slideMargin = u))
    : n?.slideMargin &&
      (Array.isArray(n.slideMargin)
        ? (u = n.slideMargin)
        : isNaN(n.slideMargin) ||
          (u = [n.slideMargin, n.slideMargin, n.slideMargin, n.slideMargin])),
    (s = (n.w ? le(n.w) : e.presLayout.width) - le(u[1] + u[3])),
    n.verbose &&
      (console.log("[[VERBOSE MODE]]"),
      console.log(
        "|-- `tableToSlides` ----------------------------------------------------|",
      ),
      console.log(
        `| tableProps.h .................................... = ${n.h}`,
      ),
      console.log(
        `| tableProps.w .................................... = ${n.w}`,
      ),
      console.log(
        `| pptx.presLayout.width ........................... = ${(e.presLayout.width / Ae).toFixed(1)}`,
      ),
      console.log(
        `| pptx.presLayout.height .......................... = ${(e.presLayout.height / Ae).toFixed(1)}`,
      ),
      console.log(
        `| emuSlideTabW .................................... = ${(s / Ae).toFixed(1)}`,
      )));
  let d = document.querySelectorAll(`#${A} tr:first-child th`);
  (d.length === 0 && (d = document.querySelectorAll(`#${A} tr:first-child td`)),
    d.forEach((h) => {
      const y = h;
      if (y.getAttribute("colspan"))
        for (let v = 0; v < Number(y.getAttribute("colspan")); v++)
          r.push(Math.round(y.offsetWidth / Number(y.getAttribute("colspan"))));
      else r.push(y.offsetWidth);
    }),
    r.forEach((h) => {
      g += h;
    }),
    r.forEach((h, y) => {
      const v = Number(((Number(s) * ((h / g) * 100)) / 100 / Ae).toFixed(2));
      let b = 0;
      const C = document.querySelector(
        `#${A} thead tr:first-child th:nth-child(${y + 1})`,
      );
      C && (b = Number(C.getAttribute("data-pptx-min-width")));
      const D = document.querySelector(
        `#${A} thead tr:first-child th:nth-child(${y + 1})`,
      );
      (D && (b = Number(D.getAttribute("data-pptx-width"))),
        a.push(b > v ? b : v));
    }),
    n.verbose &&
      console.log(
        `| arrColW ......................................... = [${a.join(", ")}]`,
      ),
    ["thead", "tbody", "tfoot"].forEach((h) => {
      document.querySelectorAll(`#${A} ${h} tr`).forEach((y) => {
        const v = y,
          b = [];
        switch (
          (Array.from(v.cells).forEach((C) => {
            const D = window
              .getComputedStyle(C)
              .getPropertyValue("color")
              .replace(/\s+/gi, "")
              .replace("rgba(", "")
              .replace("rgb(", "")
              .replace(")", "")
              .split(",");
            let L = window
              .getComputedStyle(C)
              .getPropertyValue("background-color")
              .replace(/\s+/gi, "")
              .replace("rgba(", "")
              .replace("rgb(", "")
              .replace(")", "")
              .split(",");
            (window.getComputedStyle(C).getPropertyValue("background-color") ===
              "rgba(0, 0, 0, 0)" ||
              window.getComputedStyle(C).getPropertyValue("transparent")) &&
              (L = ["255", "255", "255"]);
            const M = {
              align: null,
              bold:
                window.getComputedStyle(C).getPropertyValue("font-weight") ===
                  "bold" ||
                Number(
                  window.getComputedStyle(C).getPropertyValue("font-weight"),
                ) >= 500,
              border: null,
              color: mt(Number(D[0]), Number(D[1]), Number(D[2])),
              fill: { color: mt(Number(L[0]), Number(L[1]), Number(L[2])) },
              fontFace:
                (
                  window.getComputedStyle(C).getPropertyValue("font-family") ||
                  ""
                )
                  .split(",")[0]
                  .replace(/"/g, "")
                  .replace("inherit", "")
                  .replace("initial", "") || null,
              fontSize: Number(
                window
                  .getComputedStyle(C)
                  .getPropertyValue("font-size")
                  .replace(/[a-z]/gi, ""),
              ),
              margin: null,
              colspan: Number(C.getAttribute("colspan")) || null,
              rowspan: Number(C.getAttribute("rowspan")) || null,
              valign: null,
            };
            if (
              ["left", "center", "right", "start", "end"].includes(
                window.getComputedStyle(C).getPropertyValue("text-align"),
              )
            ) {
              const _ = window
                .getComputedStyle(C)
                .getPropertyValue("text-align")
                .replace("start", "left")
                .replace("end", "right");
              M.align =
                _ === "center"
                  ? "center"
                  : _ === "left"
                    ? "left"
                    : _ === "right"
                      ? "right"
                      : null;
            }
            if (
              ["top", "middle", "bottom"].includes(
                window.getComputedStyle(C).getPropertyValue("vertical-align"),
              )
            ) {
              const _ = window
                .getComputedStyle(C)
                .getPropertyValue("vertical-align");
              M.valign =
                _ === "top"
                  ? "top"
                  : _ === "middle"
                    ? "middle"
                    : _ === "bottom"
                      ? "bottom"
                      : null;
            }
            (window.getComputedStyle(C).getPropertyValue("padding-left") &&
              ((M.margin = [0, 0, 0, 0]),
              [
                "padding-top",
                "padding-right",
                "padding-bottom",
                "padding-left",
              ].forEach((X, P) => {
                M.margin[P] = Math.round(
                  Number(
                    window
                      .getComputedStyle(C)
                      .getPropertyValue(X)
                      .replace(/\D/gi, ""),
                  ),
                );
              })),
              (window
                .getComputedStyle(C)
                .getPropertyValue("border-top-width") ||
                window
                  .getComputedStyle(C)
                  .getPropertyValue("border-right-width") ||
                window
                  .getComputedStyle(C)
                  .getPropertyValue("border-bottom-width") ||
                window
                  .getComputedStyle(C)
                  .getPropertyValue("border-left-width")) &&
                ((M.border = [null, null, null, null]),
                ["top", "right", "bottom", "left"].forEach((X, P) => {
                  const E = Math.round(
                    Number(
                      window
                        .getComputedStyle(C)
                        .getPropertyValue("border-" + X + "-width")
                        .replace("px", ""),
                    ),
                  );
                  let J = [];
                  J = window
                    .getComputedStyle(C)
                    .getPropertyValue("border-" + X + "-color")
                    .replace(/\s+/gi, "")
                    .replace("rgba(", "")
                    .replace("rgb(", "")
                    .replace(")", "")
                    .split(",");
                  const B = mt(Number(J[0]), Number(J[1]), Number(J[2]));
                  M.border[P] = { pt: E, color: B };
                })),
              b.push({ _type: ne.tablecell, text: C.innerText, options: M }));
          }),
          h)
        ) {
          case "thead":
            l.push(b);
            break;
          case "tbody":
            c.push(b);
            break;
          case "tfoot":
            i.push(b);
            break;
          default:
            console.log(`table parsing: unexpected table part: ${h}`);
            break;
        }
      });
    }),
    (n._arrObjTabHeadRows = l || null),
    (n.colW = a),
    qt([...l, ...c, ...i], n, e.presLayout, o).forEach((h, y) => {
      const v = e.addSlide({ masterName: n.masterSlideName || null });
      (y === 0 && (n.y = n.y || u[0]),
        y > 0 && (n.y = n.autoPageSlideStartY || n.newSlideStartY || u[0]),
        n.verbose &&
          console.log(
            `| opts.autoPageSlideStartY: ${n.autoPageSlideStartY} / arrInchMargins[0]: ${u[0]} => opts.y = ${n.y}`,
          ),
        v.addTable(h.rows, {
          x: n.x || u[3],
          y: n.y,
          w: Number(s) / Ae,
          colW: a,
          autoPage: !1,
        }),
        n.addImage &&
          ((n.addImage.options = n.addImage.options || {}),
          !n.addImage.image ||
          (!n.addImage.image.path && !n.addImage.image.data)
            ? console.warn(
                "Warning: tableToSlides.addImage requires either `path` or `data`",
              )
            : v.addImage({
                path: n.addImage.image.path,
                data: n.addImage.image.data,
                x: n.addImage.options.x,
                y: n.addImage.options.y,
                w: n.addImage.options.w,
                h: n.addImage.options.h,
              })),
        n.addShape &&
          v.addShape(n.addShape.shapeName, n.addShape.options || {}),
        n.addTable && v.addTable(n.addTable.rows, n.addTable.options || {}),
        n.addText && v.addText(n.addText.text, n.addText.options || {}));
    }));
}
let pa = 0;
function ua(e, A) {
  (e.bkgd && (A.bkgd = e.bkgd),
    e.objects &&
      Array.isArray(e.objects) &&
      e.objects.length > 0 &&
      e.objects.forEach((t, o) => {
        const n = Object.keys(t)[0],
          s = A;
        Te[n] && n === "chart"
          ? Yt(s, t[n].type, t[n].data, t[n].opts)
          : Te[n] && n === "image"
            ? Jt(s, t[n])
            : Te[n] && n === "line"
              ? Pt(s, _e.LINE, t[n])
              : Te[n] && n === "rect"
                ? Pt(s, _e.RECTANGLE, t[n])
                : Te[n] && n === "text"
                  ? ct(s, [{ text: t[n].text }], t[n].options, !1)
                  : Te[n] &&
                    n === "placeholder" &&
                    ((t[n].options.placeholder = t[n].options.name),
                    delete t[n].options.name,
                    (t[n].options._placeholderType = t[n].options.type),
                    delete t[n].options.type,
                    (t[n].options._placeholderIdx = 100 + o),
                    ct(s, [{ text: t[n].text }], t[n].options, !0));
      }),
    e.slideNumber &&
      typeof e.slideNumber == "object" &&
      (A._slideNumberProps = e.slideNumber));
}
function Yt(e, A, t, o) {
  var n;
  function s(u) {
    !u ||
      u.style === "none" ||
      (u.size !== void 0 &&
        (isNaN(Number(u.size)) || u.size <= 0) &&
        (console.warn("Warning: chart.gridLine.size must be greater than 0."),
        delete u.size),
      u.style &&
        !["solid", "dash", "dot"].includes(u.style) &&
        (console.warn(
          "Warning: chart.gridLine.style options: `solid`, `dash`, `dot`.",
        ),
        delete u.style),
      u.cap &&
        !["flat", "square", "round"].includes(u.cap) &&
        (console.warn(
          "Warning: chart.gridLine.cap options: `flat`, `square`, `round`.",
        ),
        delete u.cap));
  }
  const l = ++pa,
    c = { _type: null, text: null, options: null, chartRid: null };
  let i = null,
    a = [];
  (Array.isArray(A)
    ? (A.forEach((u) => {
        a = a.concat(u.data);
      }),
      (i = t || o))
    : ((a = t), (i = o)),
    a.forEach((u, g) => {
      ((u._dataIndex = g),
        u.labels !== void 0 &&
          !Array.isArray(u.labels[0]) &&
          (u.labels = [u.labels]));
    }));
  const r = i && typeof i == "object" ? i : {};
  if (
    ((r._type = A),
    (r.x = typeof r.x < "u" && r.x != null && !isNaN(Number(r.x)) ? r.x : 1),
    (r.y = typeof r.y < "u" && r.y != null && !isNaN(Number(r.y)) ? r.y : 1),
    (r.w = r.w || "50%"),
    (r.h = r.h || "50%"),
    (r.objectName = r.objectName
      ? re(r.objectName)
      : `Chart ${e._slideObjects.filter((u) => u._type === ne.chart).length}`),
    ["bar", "col"].includes(r.barDir || "") || (r.barDir = "col"),
    r._type === W.AREA &&
      (["stacked", "standard", "percentStacked"].includes(
        r.barGrouping || "",
      ) ||
        (r.barGrouping = "standard")),
    r._type === W.BAR &&
      (["clustered", "stacked", "percentStacked"].includes(
        r.barGrouping || "",
      ) ||
        (r.barGrouping = "clustered")),
    r._type === W.BAR3D &&
      (["clustered", "stacked", "standard", "percentStacked"].includes(
        r.barGrouping || "",
      ) ||
        (r.barGrouping = "standard")),
    !((n = r.barGrouping) === null || n === void 0) &&
      n.includes("tacked") &&
      (r.barGapWidthPct || (r.barGapWidthPct = 50)),
    r.dataLabelPosition &&
      ((r._type === W.AREA ||
        r._type === W.BAR3D ||
        r._type === W.DOUGHNUT ||
        r._type === W.RADAR) &&
        delete r.dataLabelPosition,
      r._type === W.PIE &&
        (["bestFit", "ctr", "inEnd", "outEnd"].includes(r.dataLabelPosition) ||
          delete r.dataLabelPosition),
      (r._type === W.BUBBLE ||
        r._type === W.BUBBLE3D ||
        r._type === W.LINE ||
        r._type === W.SCATTER) &&
        (["b", "ctr", "l", "r", "t"].includes(r.dataLabelPosition) ||
          delete r.dataLabelPosition),
      r._type === W.BAR &&
        (["stacked", "percentStacked"].includes(r.barGrouping || "") ||
          ["ctr", "inBase", "inEnd"].includes(r.dataLabelPosition) ||
          delete r.dataLabelPosition,
        ["clustered"].includes(r.barGrouping || "") ||
          ["ctr", "inBase", "inEnd", "outEnd"].includes(r.dataLabelPosition) ||
          delete r.dataLabelPosition)),
    (r.dataLabelBkgrdColors =
      r.dataLabelBkgrdColors || !r.dataLabelBkgrdColors
        ? r.dataLabelBkgrdColors
        : !1),
    ["b", "l", "r", "t", "tr"].includes(r.legendPos || "") ||
      (r.legendPos = "r"),
    [
      "cone",
      "coneToMax",
      "box",
      "cylinder",
      "pyramid",
      "pyramidToMax",
    ].includes(r.bar3DShape || "") || (r.bar3DShape = "box"),
    ["circle", "dash", "diamond", "dot", "none", "square", "triangle"].includes(
      r.lineDataSymbol || "",
    ) || (r.lineDataSymbol = "circle"),
    ["gap", "span"].includes(r.displayBlanksAs || "") ||
      (r.displayBlanksAs = "span"),
    ["standard", "marker", "filled"].includes(r.radarStyle || "") ||
      (r.radarStyle = "standard"),
    (r.lineDataSymbolSize =
      r.lineDataSymbolSize && !isNaN(r.lineDataSymbolSize)
        ? r.lineDataSymbolSize
        : 6),
    (r.lineDataSymbolLineSize =
      r.lineDataSymbolLineSize && !isNaN(r.lineDataSymbolLineSize)
        ? te(r.lineDataSymbolLineSize)
        : te(0.75)),
    r.layout &&
      ["x", "y", "w", "h"].forEach((u) => {
        const g = r.layout[u];
        (isNaN(Number(g)) || g < 0 || g > 1) &&
          (console.warn("Warning: chart.layout." + u + " can only be 0-1"),
          delete r.layout[u]);
      }),
    (r.catGridLine =
      r.catGridLine ||
      (r._type === W.SCATTER
        ? { color: "D9D9D9", size: 1 }
        : { style: "none" })),
    (r.valGridLine =
      r.valGridLine ||
      (r._type === W.SCATTER ? { color: "D9D9D9", size: 1 } : {})),
    (r.serGridLine =
      r.serGridLine ||
      (r._type === W.SCATTER
        ? { color: "D9D9D9", size: 1 }
        : { style: "none" })),
    s(r.catGridLine),
    s(r.valGridLine),
    s(r.serGridLine),
    Nt(r.shadow),
    (r.showDataTable =
      r.showDataTable || !r.showDataTable ? r.showDataTable : !1),
    (r.showDataTableHorzBorder =
      r.showDataTableHorzBorder || !r.showDataTableHorzBorder
        ? r.showDataTableHorzBorder
        : !0),
    (r.showDataTableVertBorder =
      r.showDataTableVertBorder || !r.showDataTableVertBorder
        ? r.showDataTableVertBorder
        : !0),
    (r.showDataTableOutline =
      r.showDataTableOutline || !r.showDataTableOutline
        ? r.showDataTableOutline
        : !0),
    (r.showDataTableKeys =
      r.showDataTableKeys || !r.showDataTableKeys ? r.showDataTableKeys : !0),
    (r.showLabel = r.showLabel || !r.showLabel ? r.showLabel : !1),
    (r.showLegend = r.showLegend || !r.showLegend ? r.showLegend : !1),
    (r.showPercent = r.showPercent || !r.showPercent ? r.showPercent : !0),
    (r.showTitle = r.showTitle || !r.showTitle ? r.showTitle : !1),
    (r.showValue = r.showValue || !r.showValue ? r.showValue : !1),
    (r.showLeaderLines =
      r.showLeaderLines || !r.showLeaderLines ? r.showLeaderLines : !1),
    (r.catAxisLineShow =
      typeof r.catAxisLineShow < "u" ? r.catAxisLineShow : !0),
    (r.valAxisLineShow =
      typeof r.valAxisLineShow < "u" ? r.valAxisLineShow : !0),
    (r.serAxisLineShow =
      typeof r.serAxisLineShow < "u" ? r.serAxisLineShow : !0),
    (r.v3DRotX =
      !isNaN(r.v3DRotX) && r.v3DRotX >= -90 && r.v3DRotX <= 90
        ? r.v3DRotX
        : 30),
    (r.v3DRotY =
      !isNaN(r.v3DRotY) && r.v3DRotY >= 0 && r.v3DRotY <= 360 ? r.v3DRotY : 30),
    (r.v3DRAngAx = r.v3DRAngAx || !r.v3DRAngAx ? r.v3DRAngAx : !0),
    (r.v3DPerspective =
      !isNaN(r.v3DPerspective) &&
      r.v3DPerspective >= 0 &&
      r.v3DPerspective <= 240
        ? r.v3DPerspective
        : 30),
    (r.barGapWidthPct =
      !isNaN(r.barGapWidthPct) &&
      r.barGapWidthPct >= 0 &&
      r.barGapWidthPct <= 1e3
        ? r.barGapWidthPct
        : 150),
    (r.barGapDepthPct =
      !isNaN(r.barGapDepthPct) &&
      r.barGapDepthPct >= 0 &&
      r.barGapDepthPct <= 1e3
        ? r.barGapDepthPct
        : 150),
    (r.chartColors = Array.isArray(r.chartColors)
      ? r.chartColors
      : r._type === W.PIE || r._type === W.DOUGHNUT
        ? sa
        : Ze),
    (r.chartColorsOpacity =
      r.chartColorsOpacity && !isNaN(r.chartColorsOpacity)
        ? r.chartColorsOpacity
        : null),
    (r.border = r.border && typeof r.border == "object" ? r.border : null),
    r.border && (!r.border.pt || isNaN(r.border.pt)) && (r.border.pt = Ue.pt),
    r.border &&
      (!r.border.color || typeof r.border.color != "string") &&
      (r.border.color = Ue.color),
    (r.plotArea = r.plotArea || {}),
    (r.plotArea.border =
      r.plotArea.border && typeof r.plotArea.border == "object"
        ? r.plotArea.border
        : null),
    r.plotArea.border &&
      (!r.plotArea.border.pt || isNaN(r.plotArea.border.pt)) &&
      (r.plotArea.border.pt = Ue.pt),
    r.plotArea.border &&
      (!r.plotArea.border.color ||
        typeof r.plotArea.border.color != "string") &&
      (r.plotArea.border.color = Ue.color),
    r.border && (r.plotArea.border = r.border),
    (r.plotArea.fill = r.plotArea.fill || { color: null, transparency: null }),
    r.fill && (r.plotArea.fill.color = r.fill),
    (r.chartArea = r.chartArea || {}),
    (r.chartArea.border =
      r.chartArea.border && typeof r.chartArea.border == "object"
        ? r.chartArea.border
        : null),
    r.chartArea.border &&
      (r.chartArea.border = {
        color: r.chartArea.border.color || Ue.color,
        pt: r.chartArea.border.pt || Ue.pt,
      }),
    (r.chartArea.roundedCorners =
      typeof r.chartArea.roundedCorners == "boolean"
        ? r.chartArea.roundedCorners
        : !0),
    (r.dataBorder =
      r.dataBorder && typeof r.dataBorder == "object" ? r.dataBorder : null),
    r.dataBorder &&
      (!r.dataBorder.pt || isNaN(r.dataBorder.pt)) &&
      (r.dataBorder.pt = 0.75),
    r.dataBorder && r.dataBorder.color)
  ) {
    const u =
        typeof r.dataBorder.color == "string" &&
        r.dataBorder.color.length === 6 &&
        /^[0-9A-Fa-f]{6}$/.test(r.dataBorder.color),
      g = Object.values(lt).includes(r.dataBorder.color);
    !u && !g && (r.dataBorder.color = "F9F9F9");
  }
  return (
    !r.dataLabelFormatCode &&
      r._type === W.SCATTER &&
      (r.dataLabelFormatCode = "General"),
    !r.dataLabelFormatCode &&
      (r._type === W.PIE || r._type === W.DOUGHNUT) &&
      (r.dataLabelFormatCode = r.showPercent ? "0%" : "General"),
    (r.dataLabelFormatCode =
      r.dataLabelFormatCode && typeof r.dataLabelFormatCode == "string"
        ? r.dataLabelFormatCode
        : "#,##0"),
    !r.dataLabelFormatScatter &&
      r._type === W.SCATTER &&
      (r.dataLabelFormatScatter = "custom"),
    (r.lineSize = typeof r.lineSize == "number" ? r.lineSize : 2),
    (r.valAxisMajorUnit =
      typeof r.valAxisMajorUnit == "number" ? r.valAxisMajorUnit : null),
    r._type === W.AREA ||
    r._type === W.BAR ||
    r._type === W.BAR3D ||
    r._type === W.LINE
      ? (r.catAxisMultiLevelLabels = !!r.catAxisMultiLevelLabels)
      : delete r.catAxisMultiLevelLabels,
    (c._type = "chart"),
    (c.options = r),
    (c.chartRid = Fe(e)),
    e._relsChart.push({
      rId: Fe(e),
      data: a,
      opts: r,
      type: r._type,
      globalId: l,
      fileName: `chart${l}.xml`,
      Target: `/ppt/charts/chart${l}.xml`,
    }),
    e._slideObjects.push(c),
    c
  );
}
function Jt(e, A) {
  const t = {
      _type: null,
      text: null,
      options: null,
      image: null,
      imageRid: null,
      hyperlink: null,
    },
    o = A.x || 0,
    n = A.y || 0,
    s = A.w || 0,
    l = A.h || 0,
    c = A.sizing || null,
    i = A.hyperlink || "",
    a = A.data || "",
    r = A.path || "";
  let u = Fe(e);
  const g = A.objectName
    ? re(A.objectName)
    : `Image ${e._slideObjects.filter((m) => m._type === ne.image).length}`;
  if (!r && !a)
    return (
      console.error(
        "ERROR: addImage() requires either 'data' or 'path' parameter!",
      ),
      null
    );
  if (r && typeof r != "string")
    return (
      console.error(
        `ERROR: addImage() 'path' should be a string, ex: {path:'/img/sample.png'} - you sent ${String(r)}`,
      ),
      null
    );
  if (a && typeof a != "string")
    return (
      console.error(
        `ERROR: addImage() 'data' should be a string, ex: {data:'image/png;base64,NMP[...]'} - you sent ${String(a)}`,
      ),
      null
    );
  if (a && typeof a == "string" && !a.toLowerCase().includes("base64,"))
    return (
      console.error(
        "ERROR: Image `data` value lacks a base64 header! Ex: 'image/png;base64,NMP[...]')",
      ),
      null
    );
  let d = (
    r
      .substring(r.lastIndexOf("/") + 1)
      .split("?")[0]
      .split(".")
      .pop()
      .split("#")[0] || "png"
  ).toLowerCase();
  if (
    (a && /image\/(\w+);/.exec(a) && /image\/(\w+);/.exec(a).length > 0
      ? (d = /image\/(\w+);/.exec(a)[1])
      : a?.toLowerCase().includes("image/svg+xml") && (d = "svg"),
    (t._type = ne.image),
    (t.image = r || "preencoded.png"),
    (t.options = {
      x: o || 0,
      y: n || 0,
      w: s || 1,
      h: l || 1,
      altText: A.altText || "",
      rounding: typeof A.rounding == "boolean" ? A.rounding : !1,
      sizing: c,
      placeholder: A.placeholder,
      rotate: A.rotate || 0,
      flipV: A.flipV || !1,
      flipH: A.flipH || !1,
      transparency: A.transparency || 0,
      objectName: g,
      shadow: Nt(A.shadow),
    }),
    d === "svg")
  )
    (e._relsMedia.push({
      path: r || a + "png",
      type: "image/png",
      extn: "png",
      data: a || "",
      rId: u,
      Target: `../media/image-${e._slideNum}-${e._relsMedia.length + 1}.png`,
      isSvgPng: !0,
      svgSize: {
        w: ie(t.options.w, "X", e._presLayout),
        h: ie(t.options.h, "Y", e._presLayout),
      },
    }),
      (t.imageRid = u),
      e._relsMedia.push({
        path: r || a,
        type: "image/svg+xml",
        extn: d,
        data: a || "",
        rId: u + 1,
        Target: `../media/image-${e._slideNum}-${e._relsMedia.length + 1}.${d}`,
      }),
      (t.imageRid = u + 1));
  else {
    const m = e._relsMedia.filter(
      (h) =>
        h.path && h.path === r && h.type === "image/" + d && !h.isDuplicate,
    )[0];
    (e._relsMedia.push({
      path: r || "preencoded." + d,
      type: "image/" + d,
      extn: d,
      data: a || "",
      rId: u,
      isDuplicate: !!m?.Target,
      Target: m?.Target
        ? m.Target
        : `../media/image-${e._slideNum}-${e._relsMedia.length + 1}.${d}`,
    }),
      (t.imageRid = u));
  }
  if (typeof i == "object") {
    if (!i.url && !i.slide)
      throw new Error(
        "ERROR: `hyperlink` option requires either: `url` or `slide`",
      );
    (u++,
      e._rels.push({
        type: ne.hyperlink,
        data: i.slide ? "slide" : "dummy",
        rId: u,
        Target: i.url || i.slide.toString(),
      }),
      (i._rId = u),
      (t.hyperlink = i));
  }
  e._slideObjects.push(t);
}
function ha(e, A) {
  const t = A.x || 0,
    o = A.y || 0,
    n = A.w || 2,
    s = A.h || 2,
    l = A.data || "",
    c = A.link || "",
    i = A.path || "",
    a = A.type || "audio";
  let r = "";
  const u = A.cover || la,
    g = A.objectName
      ? re(A.objectName)
      : `Media ${e._slideObjects.filter((m) => m._type === ne.media).length}`,
    d = { _type: ne.media };
  if (!i && !l && a !== "online")
    throw new Error("addMedia() error: either `data` or `path` are required!");
  if (l && !l.toLowerCase().includes("base64,"))
    throw new Error(
      "addMedia() error: `data` value lacks a base64 header! Ex: 'video/mpeg;base64,NMP[...]')",
    );
  if (!u.toLowerCase().includes("base64,"))
    throw new Error(
      "addMedia() error: `cover` value lacks a base64 header! Ex: 'data:image/png;base64,iV[...]')",
    );
  if (a === "online" && !c)
    throw new Error("addMedia() error: online videos require `link` value");
  if (
    ((r =
      A.extn ||
      (l ? l.split(";")[0].split("/")[1] : i.split(".").pop()) ||
      "mp3"),
    (d.mtype = a),
    (d.media = i || "preencoded.mov"),
    (d.options = {}),
    (d.options.x = t),
    (d.options.y = o),
    (d.options.w = n),
    (d.options.h = s),
    (d.options.objectName = g),
    a === "online")
  ) {
    const m = Fe(e);
    (e._relsMedia.push({
      path: i || "preencoded" + r,
      data: "dummy",
      type: "online",
      extn: r,
      rId: m,
      Target: c,
    }),
      (d.mediaRid = m),
      e._relsMedia.push({
        path: "preencoded.png",
        data: u,
        type: "image/png",
        extn: "png",
        rId: Fe(e),
        Target: `../media/image-${e._slideNum}-${e._relsMedia.length + 1}.png`,
      }));
  } else {
    const m = e._relsMedia.filter(
        (y) =>
          y.path && y.path === i && y.type === a + "/" + r && !y.isDuplicate,
      )[0],
      h = Fe(e);
    (e._relsMedia.push({
      path: i || "preencoded" + r,
      type: a + "/" + r,
      extn: r,
      data: l || "",
      rId: h,
      isDuplicate: !!m?.Target,
      Target: m?.Target
        ? m.Target
        : `../media/media-${e._slideNum}-${e._relsMedia.length + 1}.${r}`,
    }),
      (d.mediaRid = h),
      e._relsMedia.push({
        path: i || "preencoded" + r,
        type: a + "/" + r,
        extn: r,
        data: l || "",
        rId: Fe(e),
        isDuplicate: !!m?.Target,
        Target: m?.Target
          ? m.Target
          : `../media/media-${e._slideNum}-${e._relsMedia.length + 0}.${r}`,
      }),
      e._relsMedia.push({
        path: "preencoded.png",
        type: "image/png",
        extn: "png",
        data: u,
        rId: Fe(e),
        Target: `../media/image-${e._slideNum}-${e._relsMedia.length + 1}.png`,
      }));
  }
  e._slideObjects.push(d);
}
function ma(e, A) {
  e._slideObjects.push({ _type: ne.notes, text: [{ text: A }] });
}
function Pt(e, A, t) {
  const o = typeof t == "object" ? t : {};
  o.line = o.line || { type: "none" };
  const n = {
    _type: ne.text,
    shape: A || _e.RECTANGLE,
    options: o,
    text: null,
  };
  if (!A)
    throw new Error(
      "Missing/Invalid shape parameter! Example: `addShape(pptxgen.shapes.LINE, {x:1, y:1, w:1, h:1});`",
    );
  const s = {
    type: o.line.type || "solid",
    color: o.line.color || Ot,
    transparency: o.line.transparency || 0,
    width: o.line.width || 1,
    dashType: o.line.dashType || "solid",
    beginArrowType: o.line.beginArrowType || null,
    endArrowType: o.line.endArrowType || null,
  };
  if (
    (typeof o.line == "object" && o.line.type !== "none" && (o.line = s),
    (o.x = o.x || (o.x === 0 ? 0 : 1)),
    (o.y = o.y || (o.y === 0 ? 0 : 1)),
    (o.w = o.w || (o.w === 0 ? 0 : 1)),
    (o.h = o.h || (o.h === 0 ? 0 : 1)),
    (o.objectName = o.objectName
      ? re(o.objectName)
      : `Shape ${e._slideObjects.filter((l) => l._type === ne.text).length}`),
    typeof o.line == "string")
  ) {
    const l = s;
    ((l.color = String(o.line)), (o.line = l));
  }
  (typeof o.lineSize == "number" && (o.line.width = o.lineSize),
    typeof o.lineDash == "string" && (o.line.dashType = o.lineDash),
    typeof o.lineHead == "string" && (o.line.beginArrowType = o.lineHead),
    typeof o.lineTail == "string" && (o.line.endArrowType = o.lineTail),
    Ve(e, n),
    e._slideObjects.push(n));
}
function ga(e, A, t, o, n, s, l) {
  const c = [e],
    i = t && typeof t == "object" ? t : {};
  i.objectName = i.objectName
    ? re(i.objectName)
    : `Table ${e._slideObjects.filter((g) => g._type === ne.table).length}`;
  {
    if (A === null || A.length === 0 || !Array.isArray(A))
      throw new Error(
        "addTable: Array expected! EX: 'slide.addTable( [rows], {options} );' (https://gitbrent.github.io/PptxGenJS/docs/api-tables.html)",
      );
    if (!A[0] || !Array.isArray(A[0]))
      throw new Error(
        "addTable: 'rows' should be an array of cells! EX: 'slide.addTable( [ ['A'], ['B'], {text:'C',options:{align:'center'}} ] );' (https://gitbrent.github.io/PptxGenJS/docs/api-tables.html)",
      );
  }
  const a = [];
  (A.forEach((g) => {
    const d = [];
    (Array.isArray(g)
      ? g.forEach((m) => {
          const h = {
            _type: ne.tablecell,
            text: "",
            options: typeof m == "object" && m.options ? m.options : {},
          };
          (typeof m == "string" || typeof m == "number"
            ? (h.text = m.toString())
            : m.text &&
              (typeof m.text == "string" || typeof m.text == "number"
                ? (h.text = m.text.toString())
                : m.text && (h.text = m.text),
              m.options &&
                typeof m.options == "object" &&
                (h.options = m.options)),
            (h.options.border = h.options.border ||
              i.border || [
                { type: "none" },
                { type: "none" },
                { type: "none" },
                { type: "none" },
              ]));
          const y = h.options.border;
          (!Array.isArray(y) &&
            typeof y == "object" &&
            (h.options.border = [y, y, y, y]),
            h.options.border[0] || (h.options.border[0] = { type: "none" }),
            h.options.border[1] || (h.options.border[1] = { type: "none" }),
            h.options.border[2] || (h.options.border[2] = { type: "none" }),
            h.options.border[3] || (h.options.border[3] = { type: "none" }),
            [0, 1, 2, 3].forEach((b) => {
              h.options.border[b] = {
                type: h.options.border[b].type || ze.type,
                color: h.options.border[b].color || ze.color,
                pt:
                  typeof h.options.border[b].pt == "number"
                    ? h.options.border[b].pt
                    : ze.pt,
              };
            }),
            d.push(h));
        })
      : (console.log(
          "addTable: tableRows has a bad row. A row should be an array of cells. You provided:",
        ),
        console.log(g)),
      a.push(d));
  }),
    (i.x = ie(i.x || (i.x === 0 ? 0 : Ae / 2), "X", n)),
    (i.y = ie(i.y || (i.y === 0 ? 0 : Ae / 2), "Y", n)),
    i.h && (i.h = ie(i.h, "Y", n)),
    (i.fontSize = i.fontSize || ke),
    (i.margin = i.margin === 0 || i.margin ? i.margin : Qt),
    typeof i.margin == "number" &&
      (i.margin = [
        Number(i.margin),
        Number(i.margin),
        Number(i.margin),
        Number(i.margin),
      ]),
    JSON.stringify({ arrRows: a }).indexOf("hyperlink") === -1 &&
      (i.color || (i.color = i.color || xe)),
    typeof i.border == "string"
      ? (console.warn(
          "addTable `border` option must be an object. Ex: `{border: {type:'none'}}`",
        ),
        (i.border = null))
      : Array.isArray(i.border) &&
        [0, 1, 2, 3].forEach((g) => {
          i.border[g] = i.border[g]
            ? {
                type: i.border[g].type || ze.type,
                color: i.border[g].color || ze.color,
                pt: i.border[g].pt || ze.pt,
              }
            : { type: "none" };
        }),
    (i.autoPage = typeof i.autoPage == "boolean" ? i.autoPage : !1),
    (i.autoPageRepeatHeader =
      typeof i.autoPageRepeatHeader == "boolean" ? i.autoPageRepeatHeader : !1),
    (i.autoPageHeaderRows =
      typeof i.autoPageHeaderRows < "u" && !isNaN(Number(i.autoPageHeaderRows))
        ? Number(i.autoPageHeaderRows)
        : 1),
    (i.autoPageLineWeight =
      typeof i.autoPageLineWeight < "u" && !isNaN(Number(i.autoPageLineWeight))
        ? Number(i.autoPageLineWeight)
        : 0),
    i.autoPageLineWeight &&
      (i.autoPageLineWeight > 1
        ? (i.autoPageLineWeight = 1)
        : i.autoPageLineWeight < -1 && (i.autoPageLineWeight = -1)));
  let r = $e;
  if (
    (o &&
      typeof o._margin < "u" &&
      (Array.isArray(o._margin)
        ? (r = o._margin)
        : isNaN(Number(o._margin)) ||
          (r = [
            Number(o._margin),
            Number(o._margin),
            Number(o._margin),
            Number(o._margin),
          ])),
    i.colW)
  ) {
    const g = a[0].reduce((d, m) => {
      var h;
      return (
        !((h = m?.options) === null || h === void 0) &&
        h.colspan &&
        typeof m.options.colspan == "number"
          ? (d += m.options.colspan)
          : (d += 1),
        d
      );
    }, 0);
    typeof i.colW == "string" ||
    typeof i.colW == "number" ||
    (i.colW && Array.isArray(i.colW) && i.colW.length === 1 && g > 1)
      ? ((i.w = Math.floor(Number(i.colW) * g)), (i.colW = null))
      : i.colW &&
        Array.isArray(i.colW) &&
        i.colW.length !== g &&
        (console.warn(
          "addTable: mismatch: (colW.length != data.length) Therefore, defaulting to evenly distributed col widths.",
        ),
        (i.colW = null));
  } else
    i.w
      ? (i.w = ie(i.w, "X", n))
      : (i.w = Math.floor(n._sizeW / Ae - r[1] - r[3]));
  (i.x && i.x < 20 && (i.x = le(i.x)),
    i.y && i.y < 20 && (i.y = le(i.y)),
    i.w && typeof i.w == "number" && i.w < 20 && (i.w = le(i.w)),
    i.h && typeof i.h == "number" && i.h < 20 && (i.h = le(i.h)),
    a.forEach((g) => {
      g.forEach((d, m) => {
        typeof d == "number" || typeof d == "string"
          ? (g[m] = { _type: ne.tablecell, text: String(g[m]), options: i })
          : typeof d == "object" &&
            (typeof d.text == "number"
              ? (g[m].text = g[m].text.toString())
              : (typeof d.text > "u" || d.text === null) && (g[m].text = ""),
            (g[m].options = d.options || {}),
            (g[m]._type = ne.tablecell));
      });
    }));
  const u = [];
  return (
    i && !i.autoPage
      ? (Ve(e, a),
        e._slideObjects.push({
          _type: ne.table,
          arrTabRows: a,
          options: Object.assign({}, i),
        }))
      : (i.autoPageRepeatHeader &&
          (i._arrObjTabHeadRows = a.filter((g, d) => d < i.autoPageHeaderRows)),
        qt(a, i, n, o).forEach((g, d) => {
          (l(e._slideNum + d) || c.push(s({ masterName: o?._name || null })),
            d > 0 &&
              (i.y = le(i.autoPageSlideStartY || i.newSlideStartY || r[0])));
          {
            const m = l(e._slideNum + d);
            ((i.autoPage = !1),
              Ve(m, g.rows),
              m.addTable(g.rows, Object.assign({}, i)),
              d > 0 && u.push(m));
          }
        })),
    u
  );
}
function ct(e, A, t, o) {
  const n = {
    _type: o ? ne.placeholder : ne.text,
    shape: t?.shape || _e.RECTANGLE,
    text: !A || A.length === 0 ? [{ text: "", options: null }] : A,
    options: t || {},
  };
  function s(l) {
    {
      if (
        (l.placeholder ||
          (l.color = l.color || n.options.color || e.color || xe),
        (l.placeholder || o) && (l.bullet = l.bullet || !1),
        l.placeholder && e._slideLayout && e._slideLayout._slideObjects)
      ) {
        const c = e._slideLayout._slideObjects.filter(
          (i) =>
            i._type === "placeholder" &&
            i.options &&
            i.options.placeholder &&
            i.options.placeholder === l.placeholder,
        )[0];
        c?.options && (l = Object.assign(Object.assign({}, l), c.options));
      }
      if (
        ((l.objectName = l.objectName
          ? re(l.objectName)
          : `Text ${e._slideObjects.filter((c) => c._type === ne.text).length}`),
        l.shape === _e.LINE)
      ) {
        const c = {
          type: l.line.type || "solid",
          color: l.line.color || Ot,
          transparency: l.line.transparency || 0,
          width: l.line.width || 1,
          dashType: l.line.dashType || "solid",
          beginArrowType: l.line.beginArrowType || null,
          endArrowType: l.line.endArrowType || null,
        };
        if (
          (typeof l.line == "object" && (l.line = c), typeof l.line == "string")
        ) {
          const i = c;
          (typeof l.line == "string" && (i.color = l.line), (l.line = i));
        }
        (typeof l.lineSize == "number" && (l.line.width = l.lineSize),
          typeof l.lineDash == "string" && (l.line.dashType = l.lineDash),
          typeof l.lineHead == "string" && (l.line.beginArrowType = l.lineHead),
          typeof l.lineTail == "string" && (l.line.endArrowType = l.lineTail));
      }
      ((l.line = l.line || {}),
        (l.lineSpacing =
          l.lineSpacing && !isNaN(l.lineSpacing) ? l.lineSpacing : null),
        (l.lineSpacingMultiple =
          l.lineSpacingMultiple && !isNaN(l.lineSpacingMultiple)
            ? l.lineSpacingMultiple
            : null),
        (l._bodyProp = l._bodyProp || {}),
        (l._bodyProp.autoFit = l.autoFit || !1),
        (l._bodyProp.anchor = l.placeholder ? null : Qe.ctr),
        (l._bodyProp.vert = l.vert || null),
        (l._bodyProp.wrap = typeof l.wrap == "boolean" ? l.wrap : !0),
        ((l.inset && !isNaN(Number(l.inset))) || l.inset === 0) &&
          ((l._bodyProp.lIns = le(l.inset)),
          (l._bodyProp.rIns = le(l.inset)),
          (l._bodyProp.tIns = le(l.inset)),
          (l._bodyProp.bIns = le(l.inset))),
        typeof l.underline == "boolean" &&
          l.underline === !0 &&
          (l.underline = { style: "sng" }));
    }
    return (
      (l.align || "").toLowerCase().indexOf("c") === 0
        ? (l._bodyProp.align = Ge.center)
        : (l.align || "").toLowerCase().indexOf("l") === 0
          ? (l._bodyProp.align = Ge.left)
          : (l.align || "").toLowerCase().indexOf("r") === 0
            ? (l._bodyProp.align = Ge.right)
            : (l.align || "").toLowerCase().indexOf("j") === 0 &&
              (l._bodyProp.align = Ge.justify),
      (l.valign || "").toLowerCase().indexOf("b") === 0
        ? (l._bodyProp.anchor = Qe.b)
        : (l.valign || "").toLowerCase().indexOf("m") === 0
          ? (l._bodyProp.anchor = Qe.ctr)
          : (l.valign || "").toLowerCase().indexOf("t") === 0 &&
            (l._bodyProp.anchor = Qe.t),
      Nt(l.shadow),
      l
    );
  }
  ((n.options = s(n.options)),
    n.text.forEach((l) => (l.options = s(l.options || {}))),
    Ve(e, n.text || ""),
    e._slideObjects.push(n));
}
function va(e) {
  (e._slideLayout._slideObjects || []).forEach((A) => {
    A._type === ne.placeholder &&
      e._slideObjects.filter(
        (t) => t.options && t.options.placeholder === A.options.placeholder,
      ).length === 0 &&
      ct(e, [{ text: "" }], A.options, !1);
  });
}
function Ht(e, A) {
  var t;
  if (
    (A.bkgd &&
      (A.background || (A.background = {}),
      typeof A.bkgd == "string"
        ? (A.background.color = A.bkgd)
        : (A.bkgd.data && (A.background.data = A.bkgd.data),
          A.bkgd.path && (A.background.path = A.bkgd.path),
          A.bkgd.src && (A.background.path = A.bkgd.src))),
    !((t = A.background) === null || t === void 0) &&
      t.fill &&
      (A.background.color = A.background.fill),
    e && (e.path || e.data))
  ) {
    e.path = e.path || "preencoded.png";
    let o = (e.path.split(".").pop() || "png").split("?")[0];
    (o === "jpg" && (o = "jpeg"), (A._relsMedia = A._relsMedia || []));
    const n = A._relsMedia.length + 1;
    (A._relsMedia.push({
      path: e.path,
      type: ne.image,
      extn: o,
      data: e.data || null,
      rId: n,
      Target: `../media/${(A._name || "").replace(/\s+/gi, "-")}-image-${A._relsMedia.length + 1}.${o}`,
    }),
      (A._bkgdImgRid = n));
  }
}
function Ve(e, A, t) {
  let o = [];
  typeof A == "string" ||
    typeof A == "number" ||
    (Array.isArray(A) ? (o = A) : typeof A == "object" && (o = [A]),
    o.forEach((n, s) => {
      if (
        (t &&
          t[s] &&
          t[s].hyperlink &&
          (n.options = Object.assign(Object.assign({}, n.options), t[s])),
        Array.isArray(n))
      ) {
        const l = [];
        (n.forEach((c) => {
          c.options && !c.text.options && l.push(c.options);
        }),
          Ve(e, n, l));
      } else if (Array.isArray(n.text))
        Ve(e, n.text, t && t[s] ? [t[s]] : void 0);
      else if (
        n &&
        typeof n == "object" &&
        n.options &&
        n.options.hyperlink &&
        !n.options.hyperlink._rId
      )
        if (typeof n.options.hyperlink != "object")
          console.log(
            "ERROR: text `hyperlink` option should be an object. Ex: `hyperlink: {url:'https://github.com'}` ",
          );
        else if (!n.options.hyperlink.url && !n.options.hyperlink.slide)
          console.log("ERROR: 'hyperlink requires either: `url` or `slide`'");
        else {
          const l = Fe(e);
          (e._rels.push({
            type: ne.hyperlink,
            data: n.options.hyperlink.slide ? "slide" : "dummy",
            rId: l,
            Target:
              re(n.options.hyperlink.url) ||
              n.options.hyperlink.slide.toString(),
          }),
            (n.options.hyperlink._rId = l));
        }
      else
        n &&
          typeof n == "object" &&
          n.options &&
          n.options.hyperlink &&
          n.options.hyperlink._rId &&
          e._rels.filter((l) => l.rId === n.options.hyperlink._rId).length ===
            0 &&
          e._rels.push({
            type: ne.hyperlink,
            data: n.options.hyperlink.slide ? "slide" : "dummy",
            rId: n.options.hyperlink._rId,
            Target:
              re(n.options.hyperlink.url) ||
              n.options.hyperlink.slide.toString(),
          });
    }));
}
class ya {
  constructor(A) {
    var t;
    ((this.addSlide = A.addSlide),
      (this.getSlide = A.getSlide),
      (this._name = `Slide ${A.slideNumber}`),
      (this._presLayout = A.presLayout),
      (this._rId = A.slideRId),
      (this._rels = []),
      (this._relsChart = []),
      (this._relsMedia = []),
      (this._setSlideNum = A.setSlideNum),
      (this._slideId = A.slideId),
      (this._slideLayout = A.slideLayout || null),
      (this._slideNum = A.slideNumber),
      (this._slideObjects = []),
      (this._slideNumberProps =
        !((t = this._slideLayout) === null || t === void 0) &&
        t._slideNumberProps
          ? this._slideLayout._slideNumberProps
          : null));
  }
  set bkgd(A) {
    ((this._bkgd = A),
      (!this._background || !this._background.color) &&
        (this._background || (this._background = {}),
        typeof A == "string" && (this._background.color = A)));
  }
  get bkgd() {
    return this._bkgd;
  }
  set background(A) {
    ((this._background = A), A && Ht(A, this));
  }
  get background() {
    return this._background;
  }
  set color(A) {
    this._color = A;
  }
  get color() {
    return this._color;
  }
  set hidden(A) {
    this._hidden = A;
  }
  get hidden() {
    return this._hidden;
  }
  set slideNumber(A) {
    ((this._slideNumberProps = A), this._setSlideNum(A));
  }
  get slideNumber() {
    return this._slideNumberProps;
  }
  get newAutoPagedSlides() {
    return this._newAutoPagedSlides;
  }
  addChart(A, t, o) {
    const n = o || {};
    return ((n._type = A), Yt(this, A, t, o), this);
  }
  addImage(A) {
    return (Jt(this, A), this);
  }
  addMedia(A) {
    return (ha(this, A), this);
  }
  addNotes(A) {
    return (ma(this, A), this);
  }
  addShape(A, t) {
    return (Pt(this, A, t), this);
  }
  addTable(A, t) {
    return (
      (this._newAutoPagedSlides = ga(
        this,
        A,
        t,
        this._slideLayout,
        this._presLayout,
        this.addSlide,
        this.getSlide,
      )),
      this
    );
  }
  addText(A, t) {
    return (
      ct(
        this,
        typeof A == "string" || typeof A == "number"
          ? [{ text: A, options: t }]
          : A,
        t,
        !1,
      ),
      this
    );
  }
}
function ba(e, A) {
  return Be(this, void 0, void 0, function* () {
    const t = e.data;
    return yield new Promise((o, n) => {
      var s, l;
      const c = new Gt(),
        i = (t.length - 1) * 2 + 1,
        a =
          ((l = (s = t[0]) === null || s === void 0 ? void 0 : s.labels) ===
            null || l === void 0
            ? void 0
            : l.length) > 1;
      (c.folder("_rels"),
        c.folder("docProps"),
        c.folder("xl/_rels"),
        c.folder("xl/tables"),
        c.folder("xl/theme"),
        c.folder("xl/worksheets"),
        c.folder("xl/worksheets/_rels"),
        c.file(
          "[Content_Types].xml",
          `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>  <Default Extension="xml" ContentType="application/xml"/>  <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>  <Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>  <Override PartName="/xl/theme/theme1.xml" ContentType="application/vnd.openxmlformats-officedocument.theme+xml"/>  <Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>  <Override PartName="/xl/sharedStrings.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml"/>  <Override PartName="/xl/tables/table1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.table+xml"/>  <Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>  <Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/></Types>
`,
        ),
        c.file(
          "_rels/.rels",
          `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>
`,
        ),
        c.file(
          "docProps/app.xml",
          `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes"><Application>Microsoft Macintosh Excel</Application><DocSecurity>0</DocSecurity><ScaleCrop>false</ScaleCrop><HeadingPairs><vt:vector size="2" baseType="variant"><vt:variant><vt:lpstr>Worksheets</vt:lpstr></vt:variant><vt:variant><vt:i4>1</vt:i4></vt:variant></vt:vector></HeadingPairs><TitlesOfParts><vt:vector size="1" baseType="lpstr"><vt:lpstr>Sheet1</vt:lpstr></vt:vector></TitlesOfParts><Company></Company><LinksUpToDate>false</LinksUpToDate><SharedDoc>false</SharedDoc><HyperlinksChanged>false</HyperlinksChanged><AppVersion>16.0300</AppVersion></Properties>
`,
        ),
        c.file(
          "docProps/core.xml",
          '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:dcmitype="http://purl.org/dc/dcmitype/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:creator>PptxGenJS</dc:creator><cp:lastModifiedBy>PptxGenJS</cp:lastModifiedBy><dcterms:created xsi:type="dcterms:W3CDTF">' +
            new Date().toISOString() +
            '</dcterms:created><dcterms:modified xsi:type="dcterms:W3CDTF">' +
            new Date().toISOString() +
            "</dcterms:modified></cp:coreProperties>",
        ),
        c.file(
          "xl/_rels/workbook.xml.rels",
          '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/theme" Target="theme/theme1.xml"/><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId4" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/sharedStrings" Target="sharedStrings.xml"/></Relationships>',
        ),
        c.file(
          "xl/styles.xml",
          `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><numFmts count="1"><numFmt numFmtId="0" formatCode="General"/></numFmts><fonts count="4"><font><sz val="9"/><color indexed="8"/><name val="Geneva"/></font><font><sz val="9"/><color indexed="8"/><name val="Geneva"/></font><font><sz val="10"/><color indexed="8"/><name val="Geneva"/></font><font><sz val="18"/><color indexed="8"/><name val="Arial"/></font></fonts><fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><dxfs count="0"/><tableStyles count="0"/><colors><indexedColors><rgbColor rgb="ff000000"/><rgbColor rgb="ffffffff"/><rgbColor rgb="ffff0000"/><rgbColor rgb="ff00ff00"/><rgbColor rgb="ff0000ff"/><rgbColor rgb="ffffff00"/><rgbColor rgb="ffff00ff"/><rgbColor rgb="ff00ffff"/><rgbColor rgb="ff000000"/><rgbColor rgb="ffffffff"/><rgbColor rgb="ff878787"/><rgbColor rgb="fff9f9f9"/></indexedColors></colors></styleSheet>
`,
        ),
        c.file(
          "xl/theme/theme1.xml",
          '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><a:theme xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" name="Office Theme"><a:themeElements><a:clrScheme name="Office"><a:dk1><a:sysClr val="windowText" lastClr="000000"/></a:dk1><a:lt1><a:sysClr val="window" lastClr="FFFFFF"/></a:lt1><a:dk2><a:srgbClr val="44546A"/></a:dk2><a:lt2><a:srgbClr val="E7E6E6"/></a:lt2><a:accent1><a:srgbClr val="4472C4"/></a:accent1><a:accent2><a:srgbClr val="ED7D31"/></a:accent2><a:accent3><a:srgbClr val="A5A5A5"/></a:accent3><a:accent4><a:srgbClr val="FFC000"/></a:accent4><a:accent5><a:srgbClr val="5B9BD5"/></a:accent5><a:accent6><a:srgbClr val="70AD47"/></a:accent6><a:hlink><a:srgbClr val="0563C1"/></a:hlink><a:folHlink><a:srgbClr val="954F72"/></a:folHlink></a:clrScheme><a:fontScheme name="Office"><a:majorFont><a:latin typeface="Calibri Light" panose="020F0302020204030204"/><a:ea typeface=""/><a:cs typeface=""/><a:font script="Jpan" typeface="Yu Gothic Light"/><a:font script="Hang" typeface="맑은 고딕"/><a:font script="Hans" typeface="DengXian Light"/><a:font script="Hant" typeface="新細明體"/><a:font script="Arab" typeface="Times New Roman"/><a:font script="Hebr" typeface="Times New Roman"/><a:font script="Thai" typeface="Tahoma"/><a:font script="Ethi" typeface="Nyala"/><a:font script="Beng" typeface="Vrinda"/><a:font script="Gujr" typeface="Shruti"/><a:font script="Khmr" typeface="MoolBoran"/><a:font script="Knda" typeface="Tunga"/><a:font script="Guru" typeface="Raavi"/><a:font script="Cans" typeface="Euphemia"/><a:font script="Cher" typeface="Plantagenet Cherokee"/><a:font script="Yiii" typeface="Microsoft Yi Baiti"/><a:font script="Tibt" typeface="Microsoft Himalaya"/><a:font script="Thaa" typeface="MV Boli"/><a:font script="Deva" typeface="Mangal"/><a:font script="Telu" typeface="Gautami"/><a:font script="Taml" typeface="Latha"/><a:font script="Syrc" typeface="Estrangelo Edessa"/><a:font script="Orya" typeface="Kalinga"/><a:font script="Mlym" typeface="Kartika"/><a:font script="Laoo" typeface="DokChampa"/><a:font script="Sinh" typeface="Iskoola Pota"/><a:font script="Mong" typeface="Mongolian Baiti"/><a:font script="Viet" typeface="Times New Roman"/><a:font script="Uigh" typeface="Microsoft Uighur"/><a:font script="Geor" typeface="Sylfaen"/></a:majorFont><a:minorFont><a:latin typeface="Calibri" panose="020F0502020204030204"/><a:ea typeface=""/><a:cs typeface=""/><a:font script="Jpan" typeface="Yu Gothic"/><a:font script="Hang" typeface="맑은 고딕"/><a:font script="Hans" typeface="DengXian"/><a:font script="Hant" typeface="新細明體"/><a:font script="Arab" typeface="Arial"/><a:font script="Hebr" typeface="Arial"/><a:font script="Thai" typeface="Tahoma"/><a:font script="Ethi" typeface="Nyala"/><a:font script="Beng" typeface="Vrinda"/><a:font script="Gujr" typeface="Shruti"/><a:font script="Khmr" typeface="DaunPenh"/><a:font script="Knda" typeface="Tunga"/><a:font script="Guru" typeface="Raavi"/><a:font script="Cans" typeface="Euphemia"/><a:font script="Cher" typeface="Plantagenet Cherokee"/><a:font script="Yiii" typeface="Microsoft Yi Baiti"/><a:font script="Tibt" typeface="Microsoft Himalaya"/><a:font script="Thaa" typeface="MV Boli"/><a:font script="Deva" typeface="Mangal"/><a:font script="Telu" typeface="Gautami"/><a:font script="Taml" typeface="Latha"/><a:font script="Syrc" typeface="Estrangelo Edessa"/><a:font script="Orya" typeface="Kalinga"/><a:font script="Mlym" typeface="Kartika"/><a:font script="Laoo" typeface="DokChampa"/><a:font script="Sinh" typeface="Iskoola Pota"/><a:font script="Mong" typeface="Mongolian Baiti"/><a:font script="Viet" typeface="Arial"/><a:font script="Uigh" typeface="Microsoft Uighur"/><a:font script="Geor" typeface="Sylfaen"/></a:minorFont></a:fontScheme><a:fmtScheme name="Office"><a:fillStyleLst><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:gradFill rotWithShape="1"><a:gsLst><a:gs pos="0"><a:schemeClr val="phClr"><a:lumMod val="110000"/><a:satMod val="105000"/><a:tint val="67000"/></a:schemeClr></a:gs><a:gs pos="50000"><a:schemeClr val="phClr"><a:lumMod val="105000"/><a:satMod val="103000"/><a:tint val="73000"/></a:schemeClr></a:gs><a:gs pos="100000"><a:schemeClr val="phClr"><a:lumMod val="105000"/><a:satMod val="109000"/><a:tint val="81000"/></a:schemeClr></a:gs></a:gsLst><a:lin ang="5400000" scaled="0"/></a:gradFill><a:gradFill rotWithShape="1"><a:gsLst><a:gs pos="0"><a:schemeClr val="phClr"><a:satMod val="103000"/><a:lumMod val="102000"/><a:tint val="94000"/></a:schemeClr></a:gs><a:gs pos="50000"><a:schemeClr val="phClr"><a:satMod val="110000"/><a:lumMod val="100000"/><a:shade val="100000"/></a:schemeClr></a:gs><a:gs pos="100000"><a:schemeClr val="phClr"><a:lumMod val="99000"/><a:satMod val="120000"/><a:shade val="78000"/></a:schemeClr></a:gs></a:gsLst><a:lin ang="5400000" scaled="0"/></a:gradFill></a:fillStyleLst><a:lnStyleLst><a:ln w="6350" cap="flat" cmpd="sng" algn="ctr"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:prstDash val="solid"/><a:miter lim="800000"/></a:ln><a:ln w="12700" cap="flat" cmpd="sng" algn="ctr"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:prstDash val="solid"/><a:miter lim="800000"/></a:ln><a:ln w="19050" cap="flat" cmpd="sng" algn="ctr"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:prstDash val="solid"/><a:miter lim="800000"/></a:ln></a:lnStyleLst><a:effectStyleLst><a:effectStyle><a:effectLst/></a:effectStyle><a:effectStyle><a:effectLst/></a:effectStyle><a:effectStyle><a:effectLst><a:outerShdw blurRad="57150" dist="19050" dir="5400000" algn="ctr" rotWithShape="0"><a:srgbClr val="000000"><a:alpha val="63000"/></a:srgbClr></a:outerShdw></a:effectLst></a:effectStyle></a:effectStyleLst><a:bgFillStyleLst><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:solidFill><a:schemeClr val="phClr"><a:tint val="95000"/><a:satMod val="170000"/></a:schemeClr></a:solidFill><a:gradFill rotWithShape="1"><a:gsLst><a:gs pos="0"><a:schemeClr val="phClr"><a:tint val="93000"/><a:satMod val="150000"/><a:shade val="98000"/><a:lumMod val="102000"/></a:schemeClr></a:gs><a:gs pos="50000"><a:schemeClr val="phClr"><a:tint val="98000"/><a:satMod val="130000"/><a:shade val="90000"/><a:lumMod val="103000"/></a:schemeClr></a:gs><a:gs pos="100000"><a:schemeClr val="phClr"><a:shade val="63000"/><a:satMod val="120000"/></a:schemeClr></a:gs></a:gsLst><a:lin ang="5400000" scaled="0"/></a:gradFill></a:bgFillStyleLst></a:fmtScheme></a:themeElements><a:objectDefaults/><a:extraClrSchemeLst/><a:extLst><a:ext uri="{05A4C25C-085E-4340-85A3-A5531E510DB2}"><thm15:themeFamily xmlns:thm15="http://schemas.microsoft.com/office/thememl/2012/main" name="Office Theme" id="{62F939B6-93AF-4DB8-9C6B-D6C7DFDC589F}" vid="{4A3C46E8-61CC-4603-A589-7422A47A8E4A}"/></a:ext></a:extLst></a:theme>',
        ),
        c.file(
          "xl/workbook.xml",
          `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006" mc:Ignorable="x15" xmlns:x15="http://schemas.microsoft.com/office/spreadsheetml/2010/11/main"><fileVersion appName="xl" lastEdited="7" lowestEdited="6" rupBuild="10507"/><workbookPr/><bookViews><workbookView xWindow="0" yWindow="500" windowWidth="20960" windowHeight="15960"/></bookViews><sheets><sheet name="Sheet1" sheetId="1" r:id="rId1"/></sheets><calcPr calcId="0" concurrentCalc="0"/></workbook>
`,
        ),
        c.file(
          "xl/worksheets/_rels/sheet1.xml.rels",
          `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/table" Target="../tables/table1.xml"/></Relationships>
`,
        ));
      {
        let r = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
        if (e.opts._type === W.BUBBLE || e.opts._type === W.BUBBLE3D)
          r += `<sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" count="${i}" uniqueCount="${i}">`;
        else if (e.opts._type === W.SCATTER)
          r += `<sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" count="${t.length}" uniqueCount="${t.length}">`;
        else if (a) {
          let u = t.length;
          (t[0].labels.forEach(
            (g) => (u += g.filter((d) => d && d !== "").length),
          ),
            (r += `<sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" count="${u}" uniqueCount="${u}">`),
            (r += "<si><t/></si>"));
        } else {
          const u =
              t.length +
              t[0].labels.length * t[0].labels[0].length +
              t[0].labels.length,
            g = t.length + t[0].labels.length * t[0].labels[0].length + 1;
          ((r += `<sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" count="${u}" uniqueCount="${g}">`),
            (r += '<si><t xml:space="preserve"></t></si>'));
        }
        (e.opts._type === W.BUBBLE || e.opts._type === W.BUBBLE3D
          ? t.forEach((u, g) => {
              g === 0
                ? (r += "<si><t>X-Axis</t></si>")
                : ((r += `<si><t>${re(u.name || `Y-Axis${g}`)}</t></si>`),
                  (r += `<si><t>${re(`Size${g}`)}</t></si>`));
            })
          : t.forEach((u) => {
              r += `<si><t>${re((u.name || " ").replace("X-Axis", "X-Values"))}</t></si>`;
            }),
          e.opts._type !== W.BUBBLE &&
            e.opts._type !== W.BUBBLE3D &&
            e.opts._type !== W.SCATTER &&
            t[0].labels
              .slice()
              .reverse()
              .forEach((u) => {
                u.filter((g) => g && g !== "").forEach((g) => {
                  r += `<si><t>${re(g)}</t></si>`;
                });
              }),
          (r += `</sst>
`),
          c.file("xl/sharedStrings.xml", r));
      }
      {
        let r = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
        if (e.opts._type === W.BUBBLE || e.opts._type === W.BUBBLE3D) {
          ((r += `<table xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" id="1" name="Table1" displayName="Table1" ref="A1:${he(i)}${i}" totalsRowShown="0">`),
            (r += `<tableColumns count="${i}">`));
          let u = 1;
          t.forEach((g, d) => {
            d === 0
              ? (r += `<tableColumn id="${d + 1}" name="X-Values"/>`)
              : ((r += `<tableColumn id="${d + u}" name="${g.name}"/>`),
                u++,
                (r += `<tableColumn id="${d + u}" name="Size${d}"/>`));
          });
        } else
          e.opts._type === W.SCATTER
            ? ((r += `<table xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" id="1" name="Table1" displayName="Table1" ref="A1:${he(t.length)}${t[0].values.length + 1}" totalsRowShown="0">`),
              (r += `<tableColumns count="${t.length}">`),
              t.forEach((u, g) => {
                r += `<tableColumn id="${g + 1}" name="${g === 0 ? "X-Values" : "Y-Value "}${g}"/>`;
              }))
            : ((r += `<table xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" id="1" name="Table1" displayName="Table1" ref="A1:${he(t.length + t[0].labels.length)}${t[0].labels[0].length + 1}'" totalsRowShown="0">`),
              (r += `<tableColumns count="${t.length + t[0].labels.length}">`),
              t[0].labels.forEach((u, g) => {
                r += `<tableColumn id="${g + 1}" name="Column${g + 1}"/>`;
              }),
              t.forEach((u, g) => {
                r += `<tableColumn id="${g + t[0].labels.length + 1}" name="${re(u.name)}"/>`;
              }));
        ((r += "</tableColumns>"),
          (r +=
            '<tableStyleInfo showFirstColumn="0" showLastColumn="0" showRowStripes="1" showColumnStripes="0"/>'),
          (r += "</table>"),
          c.file("xl/tables/table1.xml", r));
      }
      {
        let r = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
        if (
          ((r +=
            '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006" mc:Ignorable="x14ac" xmlns:x14ac="http://schemas.microsoft.com/office/spreadsheetml/2009/9/ac">'),
          e.opts._type === W.BUBBLE || e.opts._type === W.BUBBLE3D
            ? (r += `<dimension ref="A1:${he(i)}${t[0].values.length + 1}"/>`)
            : e.opts._type === W.SCATTER
              ? (r += `<dimension ref="A1:${he(t.length)}${t[0].values.length + 1}"/>`)
              : (r += `<dimension ref="A1:${he(t.length + 1)}${t[0].values.length + 1}"/>`),
          (r +=
            '<sheetViews><sheetView tabSelected="1" workbookViewId="0"><selection activeCell="B1" sqref="B1"/></sheetView></sheetViews>'),
          (r += '<sheetFormatPr baseColWidth="10" defaultRowHeight="16"/>'),
          e.opts._type === W.BUBBLE || e.opts._type === W.BUBBLE3D)
        ) {
          ((r += "<sheetData>"),
            (r += `<row r="1" spans="1:${i}">`),
            (r += '<c r="A1" t="s"><v>0</v></c>'));
          for (let u = 1; u < i; u++)
            r += `<c r="${he(u + 1)}1" t="s"><v>${u}</v></c>`;
          ((r += "</row>"),
            t[0].values.forEach((u, g) => {
              ((r += `<row r="${g + 2}" spans="1:${i}">`),
                (r += `<c r="A${g + 2}"><v>${u}</v></c>`));
              let d = 2;
              for (let m = 1; m < t.length; m++)
                ((r += `<c r="${he(d)}${g + 2}"><v>${t[m].values[g] || ""}</v></c>`),
                  d++,
                  (r += `<c r="${he(d)}${g + 2}"><v>${t[m].sizes[g] || ""}</v></c>`),
                  d++);
              r += "</row>";
            }));
        } else if (e.opts._type === W.SCATTER) {
          ((r += "<sheetData>"), (r += `<row r="1" spans="1:${t.length}">`));
          for (let u = 0; u < t.length; u++)
            r += `<c r="${he(u + 1)}1" t="s"><v>${u}</v></c>`;
          ((r += "</row>"),
            t[0].values.forEach((u, g) => {
              ((r += `<row r="${g + 2}" spans="1:${t.length}">`),
                (r += `<c r="A${g + 2}"><v>${u}</v></c>`));
              for (let d = 1; d < t.length; d++)
                r += `<c r="${he(d + 1)}${g + 2}"><v>${t[d].values[g] || t[d].values[g] === 0 ? t[d].values[g] : ""}</v></c>`;
              r += "</row>";
            }));
        } else if (((r += "<sheetData>"), a)) {
          r += `<row r="1" spans="1:${t.length + t[0].labels.length}">`;
          for (let m = 0; m < t[0].labels.length; m++)
            r += `<c r="${he(m + 1)}1" t="s"><v>0</v></c>`;
          for (
            let m = t[0].labels.length - 1;
            m < t.length + t[0].labels.length - 1;
            m++
          )
            r += `<c r="${he(m + t[0].labels.length)}1" t="s"><v>${m}</v></c>`;
          r += "</row>";
          const u = t.length,
            g = t[0].labels[0].length,
            d = t[0].labels.length;
          for (let m = 0; m < g; m++) {
            r += `<row r="${m + 2}" spans="1:${u + d}">`;
            let h = u;
            const y = t[0].labels.slice().reverse();
            y.forEach((v, b) => {
              if (v[m]) {
                const D =
                  b === 0 ? 1 : y[b - 1].filter((L) => L && L !== "").length;
                ((h += D),
                  (r += `<c r="${he(m + 1 + b)}${m + 2}" t="s"><v>${h}</v></c>`));
              }
            });
            for (let v = 0; v < u; v++)
              r += `<c r="${he(d + v + 1)}${m + 2}"><v>${t[v].values[m] || 0}</v></c>`;
            r += "</row>";
          }
        } else {
          ((r += `<row r="1" spans="1:${t.length + t[0].labels.length}">`),
            t[0].labels.forEach((u, g) => {
              r += `<c r="${he(g + 1)}1" t="s"><v>0</v></c>`;
            }));
          for (let u = 0; u < t.length; u++)
            r += `<c r="${he(u + 1 + t[0].labels.length)}1" t="s"><v>${u + 1}</v></c>`;
          ((r += "</row>"),
            t[0].labels[0].forEach((u, g) => {
              r += `<row r="${g + 2}" spans="1:${t.length + t[0].labels.length}">`;
              for (let d = t[0].labels.length - 1; d >= 0; d--)
                ((r += `<c r="${he(t[0].labels.length - d)}${g + 2}" t="s">`),
                  (r += `<v>${t.length + g + 1}</v>`),
                  (r += "</c>"));
              for (let d = 0; d < t.length; d++)
                r += `<c r="${he(t[0].labels.length + d + 1)}${g + 2}"><v>${t[d].values[g] || ""}</v></c>`;
              r += "</row>";
            }));
        }
        ((r += "</sheetData>"),
          (r +=
            '<pageMargins left="0.7" right="0.7" top="0.75" bottom="0.75" header="0.3" footer="0.3"/>'),
          (r += `</worksheet>
`),
          c.file("xl/worksheets/sheet1.xml", r));
      }
      c.generateAsync({ type: "base64" })
        .then((r) => {
          (A.file(
            `ppt/embeddings/Microsoft_Excel_Worksheet${e.globalId}.xlsx`,
            r,
            { base64: !0 },
          ),
            A.file(
              "ppt/charts/_rels/" + e.fileName + ".rels",
              `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/package" Target="../embeddings/Microsoft_Excel_Worksheet${e.globalId}.xlsx"/></Relationships>`,
            ),
            A.file(`ppt/charts/${e.fileName}`, wa(e)),
            o(""));
        })
        .catch((r) => {
          n(r);
        });
    });
  });
}
function wa(e) {
  var A, t, o, n;
  let s = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
    l = !1;
  if (
    ((s +=
      '<c:chartSpace xmlns:c="http://schemas.openxmlformats.org/drawingml/2006/chart" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'),
    (s += '<c:date1904 val="0"/>'),
    (s += `<c:roundedCorners val="${e.opts.chartArea.roundedCorners ? "1" : "0"}"/>`),
    (s += "<c:chart>"),
    e.opts.showTitle
      ? ((s += dt(
          {
            title: e.opts.title || "Chart Title",
            color: e.opts.titleColor,
            fontFace: e.opts.titleFontFace,
            fontSize: e.opts.titleFontSize || ia,
            titleAlign: e.opts.titleAlign,
            titleBold: e.opts.titleBold,
            titlePos: e.opts.titlePos,
            titleRotate: e.opts.titleRotate,
          },
          e.opts.x,
          e.opts.y,
        )),
        (s += '<c:autoTitleDeleted val="0"/>'))
      : (s += '<c:autoTitleDeleted val="1"/>'),
    e.opts._type === W.BAR3D &&
      (s += `<c:view3D><c:rotX val="${e.opts.v3DRotX}"/><c:rotY val="${e.opts.v3DRotY}"/><c:rAngAx val="${e.opts.v3DRAngAx ? 1 : 0}"/><c:perspective val="${e.opts.v3DPerspective}"/></c:view3D>`),
    (s += "<c:plotArea>"),
    e.opts.layout
      ? ((s += "<c:layout>"),
        (s += " <c:manualLayout>"),
        (s += '  <c:layoutTarget val="inner" />'),
        (s += '  <c:xMode val="edge" />'),
        (s += '  <c:yMode val="edge" />'),
        (s += '  <c:x val="' + (e.opts.layout.x || 0) + '" />'),
        (s += '  <c:y val="' + (e.opts.layout.y || 0) + '" />'),
        (s += '  <c:w val="' + (e.opts.layout.w || 1) + '" />'),
        (s += '  <c:h val="' + (e.opts.layout.h || 1) + '" />'),
        (s += " </c:manualLayout>"),
        (s += "</c:layout>"))
      : (s += "<c:layout/>"),
    Array.isArray(e.opts._type)
      ? e.opts._type.forEach((c) => {
          const i = Object.assign(Object.assign({}, e.opts), c.options),
            a = i.secondaryValAxis ? it : Re,
            r = i.secondaryCatAxis ? xt : Ke;
          ((l = l || i.secondaryValAxis), (s += Et(c.type, c.data, i, a, r)));
        })
      : (s += Et(e.opts._type, e.data, e.opts, Re, Ke)),
    e.opts._type !== W.PIE && e.opts._type !== W.DOUGHNUT)
  ) {
    if (e.opts.valAxes && e.opts.valAxes.length > 1 && !l)
      throw new Error(
        "Secondary axis must be used by one of the multiple charts",
      );
    if (e.opts.catAxes) {
      if (!e.opts.valAxes || e.opts.valAxes.length !== e.opts.catAxes.length)
        throw new Error(
          "There must be the same number of value and category axes.",
        );
      s += gt(
        Object.assign(Object.assign({}, e.opts), e.opts.catAxes[0]),
        Ke,
        Re,
      );
    } else s += gt(e.opts, Ke, Re);
    (e.opts.valAxes
      ? ((s += vt(
          Object.assign(Object.assign({}, e.opts), e.opts.valAxes[0]),
          Re,
        )),
        e.opts.valAxes[1] &&
          (s += vt(
            Object.assign(Object.assign({}, e.opts), e.opts.valAxes[1]),
            it,
          )))
      : ((s += vt(e.opts, Re)),
        e.opts._type === W.BAR3D && (s += xa(e.opts, Wt, Re))),
      !((A = e.opts) === null || A === void 0) &&
        A.catAxes &&
        !((t = e.opts) === null || t === void 0) &&
        t.catAxes[1] &&
        (s += gt(
          Object.assign(Object.assign({}, e.opts), e.opts.catAxes[1]),
          xt,
          it,
        )));
  }
  return (
    e.opts.showDataTable &&
      ((s += "<c:dTable>"),
      (s += `  <c:showHorzBorder val="${e.opts.showDataTableHorzBorder ? 1 : 0}"/>`),
      (s += `  <c:showVertBorder val="${e.opts.showDataTableVertBorder ? 1 : 0}"/>`),
      (s += `  <c:showOutline    val="${e.opts.showDataTableOutline ? 1 : 0}"/>`),
      (s += `  <c:showKeys       val="${e.opts.showDataTableKeys ? 1 : 0}"/>`),
      (s += "  <c:spPr>"),
      (s += "    <a:noFill/>"),
      (s +=
        '    <a:ln w="9525" cap="flat" cmpd="sng" algn="ctr"><a:solidFill><a:schemeClr val="tx1"><a:lumMod val="15000"/><a:lumOff val="85000"/></a:schemeClr></a:solidFill><a:round/></a:ln>'),
      (s += "    <a:effectLst/>"),
      (s += "  </c:spPr>"),
      (s += "  <c:txPr>"),
      (s +=
        '   <a:bodyPr rot="0" spcFirstLastPara="1" vertOverflow="ellipsis" vert="horz" wrap="square" anchor="ctr" anchorCtr="1"/>'),
      (s += "   <a:lstStyle/>"),
      (s += "   <a:p>"),
      (s += '     <a:pPr rtl="0">'),
      (s += `       <a:defRPr sz="${Math.round((e.opts.dataTableFontSize || ke) * 100)}" b="0" i="0" u="none" strike="noStrike" kern="1200" baseline="0">`),
      (s +=
        '         <a:solidFill><a:schemeClr val="tx1"><a:lumMod val="65000"/><a:lumOff val="35000"/></a:schemeClr></a:solidFill>'),
      (s += '         <a:latin typeface="+mn-lt"/>'),
      (s += '         <a:ea typeface="+mn-ea"/>'),
      (s += '         <a:cs typeface="+mn-cs"/>'),
      (s += "       </a:defRPr>"),
      (s += "     </a:pPr>"),
      (s += '    <a:endParaRPr lang="en-US"/>'),
      (s += "   </a:p>"),
      (s += " </c:txPr>"),
      (s += "</c:dTable>")),
    (s += "  <c:spPr>"),
    (s +=
      !((o = e.opts.plotArea.fill) === null || o === void 0) && o.color
        ? Le(e.opts.plotArea.fill)
        : "<a:noFill/>"),
    (s += e.opts.plotArea.border
      ? `<a:ln w="${te(e.opts.plotArea.border.pt)}" cap="flat">${Le(e.opts.plotArea.border.color)}</a:ln>`
      : "<a:ln><a:noFill/></a:ln>"),
    (s += "    <a:effectLst/>"),
    (s += "  </c:spPr>"),
    (s += "</c:plotArea>"),
    e.opts.showLegend &&
      ((s += "<c:legend>"),
      (s += '<c:legendPos val="' + e.opts.legendPos + '"/>'),
      (s += '<c:overlay val="0"/>'),
      (e.opts.legendFontFace || e.opts.legendFontSize || e.opts.legendColor) &&
        ((s += "<c:txPr>"),
        (s += "  <a:bodyPr/>"),
        (s += "  <a:lstStyle/>"),
        (s += "  <a:p>"),
        (s += "    <a:pPr>"),
        (s += e.opts.legendFontSize
          ? `<a:defRPr sz="${Math.round(Number(e.opts.legendFontSize) * 100)}">`
          : "<a:defRPr>"),
        e.opts.legendColor && (s += Le(e.opts.legendColor)),
        e.opts.legendFontFace &&
          (s += '<a:latin typeface="' + e.opts.legendFontFace + '"/>'),
        e.opts.legendFontFace &&
          (s += '<a:cs    typeface="' + e.opts.legendFontFace + '"/>'),
        (s += "      </a:defRPr>"),
        (s += "    </a:pPr>"),
        (s += '    <a:endParaRPr lang="en-US"/>'),
        (s += "  </a:p>"),
        (s += "</c:txPr>")),
      (s += "</c:legend>")),
    (s += '  <c:plotVisOnly val="1"/>'),
    (s += '  <c:dispBlanksAs val="' + e.opts.displayBlanksAs + '"/>'),
    e.opts._type === W.SCATTER && (s += '<c:showDLblsOverMax val="1"/>'),
    (s += "</c:chart>"),
    (s += "<c:spPr>"),
    (s +=
      !((n = e.opts.chartArea.fill) === null || n === void 0) && n.color
        ? Le(e.opts.chartArea.fill)
        : "<a:noFill/>"),
    (s += e.opts.chartArea.border
      ? `<a:ln w="${te(e.opts.chartArea.border.pt)}" cap="flat">${Le(e.opts.chartArea.border.color)}</a:ln>`
      : "<a:ln><a:noFill/></a:ln>"),
    (s += "  <a:effectLst/>"),
    (s += "</c:spPr>"),
    (s +=
      '<c:externalData r:id="rId1"><c:autoUpdate val="0"/></c:externalData>'),
    (s += "</c:chartSpace>"),
    s
  );
}
function Et(e, A, t, o, n, s) {
  let l = -1,
    c = 1,
    i = null,
    a = "";
  switch (e) {
    case W.AREA:
    case W.BAR:
    case W.BAR3D:
    case W.LINE:
    case W.RADAR:
      ((a += `<c:${e}Chart>`),
        e === W.AREA &&
          t.barGrouping === "stacked" &&
          (a += '<c:grouping val="' + t.barGrouping + '"/>'),
        (e === W.BAR || e === W.BAR3D) &&
          ((a += '<c:barDir val="' + t.barDir + '"/>'),
          (a += '<c:grouping val="' + (t.barGrouping || "clustered") + '"/>')),
        e === W.RADAR && (a += '<c:radarStyle val="' + t.radarStyle + '"/>'),
        (a += '<c:varyColors val="0"/>'),
        A.forEach((r) => {
          var u;
          (l++,
            (a += "<c:ser>"),
            (a += `  <c:idx val="${r._dataIndex}"/><c:order val="${r._dataIndex}"/>`),
            (a += "  <c:tx>"),
            (a += "    <c:strRef>"),
            (a +=
              "      <c:f>Sheet1!$" +
              he(r._dataIndex + r.labels.length + 1) +
              "$1</c:f>"),
            (a +=
              '      <c:strCache><c:ptCount val="1"/><c:pt idx="0"><c:v>' +
              re(r.name) +
              "</c:v></c:pt></c:strCache>"),
            (a += "    </c:strRef>"),
            (a += "  </c:tx>"));
          const g = t.chartColors
            ? t.chartColors[l % t.chartColors.length]
            : null;
          ((a += "  <c:spPr>"),
            g === "transparent"
              ? (a += "<a:noFill/>")
              : t.chartColorsOpacity
                ? (a +=
                    "<a:solidFill>" +
                    fe(
                      g,
                      `<a:alpha val="${Math.round(t.chartColorsOpacity * 1e3)}"/>`,
                    ) +
                    "</a:solidFill>")
                : (a += "<a:solidFill>" + fe(g) + "</a:solidFill>"),
            e === W.LINE || e === W.RADAR
              ? t.lineSize === 0
                ? (a += "<a:ln><a:noFill/></a:ln>")
                : ((a += `<a:ln w="${te(t.lineSize)}" cap="${st(t.lineCap)}"><a:solidFill>${fe(g)}</a:solidFill>`),
                  (a +=
                    '<a:prstDash val="' +
                    (t.lineDash || "solid") +
                    '"/><a:round/></a:ln>'))
              : t.dataBorder &&
                (a += `<a:ln w="${te(t.dataBorder.pt)}" cap="${st(t.lineCap)}"><a:solidFill>${fe(t.dataBorder.color)}</a:solidFill><a:prstDash val="solid"/><a:round/></a:ln>`),
            (a += Ie(t.shadow, Se)),
            (a += "  </c:spPr>"),
            (a += '  <c:invertIfNegative val="0"/>'),
            e !== W.RADAR &&
              ((a += "<c:dLbls>"),
              (a += `<c:numFmt formatCode="${re(t.dataLabelFormatCode) || "General"}" sourceLinked="0"/>`),
              t.dataLabelBkgrdColors &&
                (a += `<c:spPr><a:solidFill>${fe(g)}</a:solidFill></c:spPr>`),
              (a += "<c:txPr><a:bodyPr/><a:lstStyle/><a:p><a:pPr>"),
              (a += `<a:defRPr b="${t.dataLabelFontBold ? 1 : 0}" i="${t.dataLabelFontItalic ? 1 : 0}" strike="noStrike" sz="${Math.round((t.dataLabelFontSize || ke) * 100)}" u="none">`),
              (a += `<a:solidFill>${fe(t.dataLabelColor || xe)}</a:solidFill>`),
              (a += `<a:latin typeface="${t.dataLabelFontFace || "Arial"}"/>`),
              (a += "</a:defRPr></a:pPr></a:p></c:txPr>"),
              t.dataLabelPosition &&
                (a += `<c:dLblPos val="${t.dataLabelPosition}"/>`),
              (a += '<c:showLegendKey val="0"/>'),
              (a += `<c:showVal val="${t.showValue ? "1" : "0"}"/>`),
              (a += `<c:showCatName val="0"/><c:showSerName val="${t.showSerName ? "1" : "0"}"/><c:showPercent val="0"/><c:showBubbleSize val="0"/>`),
              (a += `<c:showLeaderLines val="${t.showLeaderLines ? "1" : "0"}"/>`),
              (a += "</c:dLbls>")),
            (e === W.LINE || e === W.RADAR) &&
              ((a += "<c:marker>"),
              (a += '  <c:symbol val="' + t.lineDataSymbol + '"/>'),
              t.lineDataSymbolSize &&
                (a += `<c:size val="${t.lineDataSymbolSize}"/>`),
              (a += "  <c:spPr>"),
              (a += `    <a:solidFill>${fe(t.chartColors[r._dataIndex + 1 > t.chartColors.length ? Math.floor(Math.random() * t.chartColors.length) : r._dataIndex])}</a:solidFill>`),
              (a += `    <a:ln w="${t.lineDataSymbolLineSize}" cap="flat"><a:solidFill>${fe(t.lineDataSymbolLineColor || g)}</a:solidFill><a:prstDash val="solid"/><a:round/></a:ln>`),
              (a += "    <a:effectLst/>"),
              (a += "  </c:spPr>"),
              (a += "</c:marker>")),
            (e === W.BAR || e === W.BAR3D) &&
              A.length === 1 &&
              ((t.chartColors &&
                t.chartColors !== Ze &&
                t.chartColors.length > 1) ||
                (!((u = t.invertedColors) === null || u === void 0) &&
                  u.length)) &&
              r.values.forEach((d, m) => {
                const h =
                  d < 0
                    ? t.invertedColors || t.chartColors || Ze
                    : t.chartColors || [];
                ((a += "  <c:dPt>"),
                  (a += `    <c:idx val="${m}"/>`),
                  (a += '      <c:invertIfNegative val="0"/>'),
                  (a += '    <c:bubble3D val="0"/>'),
                  (a += "    <c:spPr>"),
                  t.lineSize === 0
                    ? (a += "<a:ln><a:noFill/></a:ln>")
                    : e === W.BAR
                      ? ((a += "<a:solidFill>"),
                        (a += '  <a:srgbClr val="' + h[m % h.length] + '"/>'),
                        (a += "</a:solidFill>"))
                      : ((a += "<a:ln>"),
                        (a += "  <a:solidFill>"),
                        (a += '   <a:srgbClr val="' + h[m % h.length] + '"/>'),
                        (a += "  </a:solidFill>"),
                        (a += "</a:ln>")),
                  (a += Ie(t.shadow, Se)),
                  (a += "    </c:spPr>"),
                  (a += "  </c:dPt>"));
              }),
            (a += "<c:cat>"),
            t.catLabelFormatCode
              ? ((a += "  <c:numRef>"),
                (a += `    <c:f>Sheet1!$A$2:$A$${r.labels[0].length + 1}</c:f>`),
                (a += "    <c:numCache>"),
                (a +=
                  "      <c:formatCode>" +
                  (t.catLabelFormatCode || "General") +
                  "</c:formatCode>"),
                (a += `      <c:ptCount val="${r.labels[0].length}"/>`),
                r.labels[0].forEach(
                  (d, m) =>
                    (a += `<c:pt idx="${m}"><c:v>${re(d)}</c:v></c:pt>`),
                ),
                (a += "    </c:numCache>"),
                (a += "  </c:numRef>"))
              : ((a += "  <c:multiLvlStrRef>"),
                (a += `    <c:f>Sheet1!$A$2:$${he(r.labels.length)}$${r.labels[0].length + 1}</c:f>`),
                (a += "    <c:multiLvlStrCache>"),
                (a += `      <c:ptCount val="${r.labels[0].length}"/>`),
                r.labels.forEach((d) => {
                  ((a += "<c:lvl>"),
                    d.forEach(
                      (m, h) =>
                        (a += `<c:pt idx="${h}"><c:v>${re(m)}</c:v></c:pt>`),
                    ),
                    (a += "</c:lvl>"));
                }),
                (a += "    </c:multiLvlStrCache>"),
                (a += "  </c:multiLvlStrRef>")),
            (a += "</c:cat>"),
            (a += "<c:val>"),
            (a += "  <c:numRef>"),
            (a += `<c:f>Sheet1!$${he(r._dataIndex + r.labels.length + 1)}$2:$${he(r._dataIndex + r.labels.length + 1)}$${r.labels[0].length + 1}</c:f>`),
            (a += "    <c:numCache>"),
            (a +=
              "      <c:formatCode>" +
              (t.valLabelFormatCode || t.dataTableFormatCode || "General") +
              "</c:formatCode>"),
            (a += `      <c:ptCount val="${r.labels[0].length}"/>`),
            r.values.forEach(
              (d, m) =>
                (a += `<c:pt idx="${m}"><c:v>${d || d === 0 ? d : ""}</c:v></c:pt>`),
            ),
            (a += "    </c:numCache>"),
            (a += "  </c:numRef>"),
            (a += "</c:val>"),
            e === W.LINE &&
              (a += '<c:smooth val="' + (t.lineSmooth ? "1" : "0") + '"/>'),
            (a += "</c:ser>"));
        }),
        (a += "  <c:dLbls>"),
        (a += `    <c:numFmt formatCode="${re(t.dataLabelFormatCode) || "General"}" sourceLinked="0"/>`),
        (a += "    <c:txPr>"),
        (a += "      <a:bodyPr/>"),
        (a += "      <a:lstStyle/>"),
        (a += "      <a:p><a:pPr>"),
        (a += `        <a:defRPr b="${t.dataLabelFontBold ? 1 : 0}" i="${t.dataLabelFontItalic ? 1 : 0}" strike="noStrike" sz="${Math.round((t.dataLabelFontSize || ke) * 100)}" u="none">`),
        (a +=
          "          <a:solidFill>" +
          fe(t.dataLabelColor || xe) +
          "</a:solidFill>"),
        (a +=
          '          <a:latin typeface="' +
          (t.dataLabelFontFace || "Arial") +
          '"/>'),
        (a += "        </a:defRPr>"),
        (a += "      </a:pPr></a:p>"),
        (a += "    </c:txPr>"),
        t.dataLabelPosition &&
          (a += ' <c:dLblPos val="' + t.dataLabelPosition + '"/>'),
        (a += '    <c:showLegendKey val="0"/>'),
        (a += '    <c:showVal val="' + (t.showValue ? "1" : "0") + '"/>'),
        (a += '    <c:showCatName val="0"/>'),
        (a += '    <c:showSerName val="' + (t.showSerName ? "1" : "0") + '"/>'),
        (a += '    <c:showPercent val="0"/>'),
        (a += '    <c:showBubbleSize val="0"/>'),
        (a += `    <c:showLeaderLines val="${t.showLeaderLines ? "1" : "0"}"/>`),
        (a += "  </c:dLbls>"),
        e === W.BAR
          ? ((a += `  <c:gapWidth val="${t.barGapWidthPct}"/>`),
            (a += `  <c:overlap val="${(t.barGrouping || "").includes("tacked") ? 100 : t.barOverlapPct ? t.barOverlapPct : 0}"/>`))
          : e === W.BAR3D
            ? ((a += `  <c:gapWidth val="${t.barGapWidthPct}"/>`),
              (a += `  <c:gapDepth val="${t.barGapDepthPct}"/>`),
              (a += '  <c:shape val="' + t.bar3DShape + '"/>'))
            : e === W.LINE && (a += '  <c:marker val="1"/>'),
        (a += `<c:axId val="${n}"/><c:axId val="${o}"/><c:axId val="${Wt}"/>`),
        (a += `</c:${e}Chart>`));
      break;
    case W.SCATTER:
      ((a += "<c:" + e + "Chart>"),
        (a += '<c:scatterStyle val="lineMarker"/>'),
        (a += '<c:varyColors val="0"/>'),
        (l = -1),
        A.filter((r, u) => u > 0).forEach((r, u) => {
          (l++,
            (a += "<c:ser>"),
            (a += `  <c:idx val="${u}"/>`),
            (a += `  <c:order val="${u}"/>`),
            (a += "  <c:tx>"),
            (a += "    <c:strRef>"),
            (a += `      <c:f>Sheet1!$${he(u + 2)}$1</c:f>`),
            (a +=
              '      <c:strCache><c:ptCount val="1"/><c:pt idx="0"><c:v>' +
              re(r.name) +
              "</c:v></c:pt></c:strCache>"),
            (a += "    </c:strRef>"),
            (a += "  </c:tx>"),
            (a += "  <c:spPr>"));
          {
            const g = t.chartColors[l % t.chartColors.length];
            (g === "transparent"
              ? (a += "<a:noFill/>")
              : t.chartColorsOpacity
                ? (a +=
                    "<a:solidFill>" +
                    fe(
                      g,
                      '<a:alpha val="' +
                        Math.round(t.chartColorsOpacity * 1e3).toString() +
                        '"/>',
                    ) +
                    "</a:solidFill>")
                : (a += "<a:solidFill>" + fe(g) + "</a:solidFill>"),
              t.lineSize === 0
                ? (a += "<a:ln><a:noFill/></a:ln>")
                : ((a += `<a:ln w="${te(t.lineSize)}" cap="${st(t.lineCap)}"><a:solidFill>${fe(g)}</a:solidFill>`),
                  (a += `<a:prstDash val="${t.lineDash || "solid"}"/><a:round/></a:ln>`)),
              (a += Ie(t.shadow, Se)));
          }
          if (
            ((a += "  </c:spPr>"),
            (a += "<c:marker>"),
            (a += '  <c:symbol val="' + t.lineDataSymbol + '"/>'),
            t.lineDataSymbolSize &&
              (a += `<c:size val="${t.lineDataSymbolSize}"/>`),
            (a += "<c:spPr>"),
            (a += `<a:solidFill>${fe(t.chartColors[u + 1 > t.chartColors.length ? Math.floor(Math.random() * t.chartColors.length) : u])}</a:solidFill>`),
            (a += `<a:ln w="${t.lineDataSymbolLineSize}" cap="flat"><a:solidFill>${fe(t.lineDataSymbolLineColor || t.chartColors[l % t.chartColors.length])}</a:solidFill><a:prstDash val="solid"/><a:round/></a:ln>`),
            (a += "<a:effectLst/>"),
            (a += "</c:spPr>"),
            (a += "</c:marker>"),
            t.showLabel)
          ) {
            const g = ot("-xxxx-xxxx-xxxx-xxxxxxxxxxxx");
            (r.labels[0] &&
              (t.dataLabelFormatScatter === "custom" ||
                t.dataLabelFormatScatter === "customXY") &&
              ((a += "<c:dLbls>"),
              r.labels[0].forEach((d, m) => {
                (t.dataLabelFormatScatter === "custom" ||
                  t.dataLabelFormatScatter === "customXY") &&
                  ((a += "  <c:dLbl>"),
                  (a += `    <c:idx val="${m}"/>`),
                  (a += "    <c:tx>"),
                  (a += "      <c:rich>"),
                  (a += "            <a:bodyPr>"),
                  (a += "                <a:spAutoFit/>"),
                  (a += "            </a:bodyPr>"),
                  (a += "            <a:lstStyle/>"),
                  (a += "            <a:p>"),
                  (a += "                <a:pPr>"),
                  (a += "                    <a:defRPr/>"),
                  (a += "                </a:pPr>"),
                  (a += "              <a:r>"),
                  (a +=
                    '                    <a:rPr lang="' +
                    (t.lang || "en-US") +
                    '" dirty="0"/>'),
                  (a += "                    <a:t>" + re(d) + "</a:t>"),
                  (a += "              </a:r>"),
                  t.dataLabelFormatScatter === "customXY" &&
                    !/^ *$/.test(d) &&
                    ((a += "              <a:r>"),
                    (a +=
                      '                  <a:rPr lang="' +
                      (t.lang || "en-US") +
                      '" baseline="0" dirty="0"/>'),
                    (a += "                  <a:t> (</a:t>"),
                    (a += "              </a:r>"),
                    (a +=
                      '              <a:fld id="{' +
                      ot("xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx") +
                      '}" type="XVALUE">'),
                    (a +=
                      '                  <a:rPr lang="' +
                      (t.lang || "en-US") +
                      '" baseline="0"/>'),
                    (a += "                  <a:pPr>"),
                    (a += "                      <a:defRPr/>"),
                    (a += "                  </a:pPr>"),
                    (a += "                  <a:t>[" + re(r.name) + "</a:t>"),
                    (a += "              </a:fld>"),
                    (a += "              <a:r>"),
                    (a +=
                      '                  <a:rPr lang="' +
                      (t.lang || "en-US") +
                      '" baseline="0" dirty="0"/>'),
                    (a += "                  <a:t>, </a:t>"),
                    (a += "              </a:r>"),
                    (a +=
                      '              <a:fld id="{' +
                      ot("xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx") +
                      '}" type="YVALUE">'),
                    (a +=
                      '                  <a:rPr lang="' +
                      (t.lang || "en-US") +
                      '" baseline="0"/>'),
                    (a += "                  <a:pPr>"),
                    (a += "                      <a:defRPr/>"),
                    (a += "                  </a:pPr>"),
                    (a += "                  <a:t>[" + re(r.name) + "]</a:t>"),
                    (a += "              </a:fld>"),
                    (a += "              <a:r>"),
                    (a +=
                      '                  <a:rPr lang="' +
                      (t.lang || "en-US") +
                      '" baseline="0" dirty="0"/>'),
                    (a += "                  <a:t>)</a:t>"),
                    (a += "              </a:r>"),
                    (a +=
                      '              <a:endParaRPr lang="' +
                      (t.lang || "en-US") +
                      '" dirty="0"/>')),
                  (a += "            </a:p>"),
                  (a += "      </c:rich>"),
                  (a += "    </c:tx>"),
                  (a += "    <c:spPr>"),
                  (a += "        <a:noFill/>"),
                  (a += "        <a:ln>"),
                  (a += "            <a:noFill/>"),
                  (a += "        </a:ln>"),
                  (a += "        <a:effectLst/>"),
                  (a += "    </c:spPr>"),
                  t.dataLabelPosition &&
                    (a += ' <c:dLblPos val="' + t.dataLabelPosition + '"/>'),
                  (a += '    <c:showLegendKey val="0"/>'),
                  (a += '    <c:showVal val="0"/>'),
                  (a += '    <c:showCatName val="0"/>'),
                  (a += '    <c:showSerName val="0"/>'),
                  (a += '    <c:showPercent val="0"/>'),
                  (a += '    <c:showBubbleSize val="0"/>'),
                  (a += '       <c:showLeaderLines val="1"/>'),
                  (a += "    <c:extLst>"),
                  (a +=
                    '      <c:ext uri="{CE6537A1-D6FC-4f65-9D91-7224C49458BB}" xmlns:c15="http://schemas.microsoft.com/office/drawing/2012/chart"/>'),
                  (a +=
                    '      <c:ext uri="{C3380CC4-5D6E-409C-BE32-E72D297353CC}" xmlns:c16="http://schemas.microsoft.com/office/drawing/2014/chart">'),
                  (a += `            <c16:uniqueId val="{${"00000000".substring(0, 8 - (m + 1).toString().length).toString()}${m + 1}${g}}"/>`),
                  (a += "      </c:ext>"),
                  (a += "        </c:extLst>"),
                  (a += "</c:dLbl>"));
              }),
              (a += "</c:dLbls>")),
              t.dataLabelFormatScatter === "XY" &&
                ((a += "<c:dLbls>"),
                (a += "    <c:spPr>"),
                (a += "        <a:noFill/>"),
                (a += "        <a:ln>"),
                (a += "            <a:noFill/>"),
                (a += "        </a:ln>"),
                (a += "          <a:effectLst/>"),
                (a += "    </c:spPr>"),
                (a += "    <c:txPr>"),
                (a += "        <a:bodyPr>"),
                (a += "            <a:spAutoFit/>"),
                (a += "        </a:bodyPr>"),
                (a += "        <a:lstStyle/>"),
                (a += "        <a:p>"),
                (a += "            <a:pPr>"),
                (a += "                <a:defRPr/>"),
                (a += "            </a:pPr>"),
                (a += '            <a:endParaRPr lang="en-US"/>'),
                (a += "        </a:p>"),
                (a += "    </c:txPr>"),
                t.dataLabelPosition &&
                  (a += ' <c:dLblPos val="' + t.dataLabelPosition + '"/>'),
                (a += '    <c:showLegendKey val="0"/>'),
                (a += ` <c:showVal val="${t.showLabel ? "1" : "0"}"/>`),
                (a += ` <c:showCatName val="${t.showLabel ? "1" : "0"}"/>`),
                (a += ` <c:showSerName val="${t.showSerName ? "1" : "0"}"/>`),
                (a += '    <c:showPercent val="0"/>'),
                (a += '    <c:showBubbleSize val="0"/>'),
                (a += "    <c:extLst>"),
                (a +=
                  '        <c:ext uri="{CE6537A1-D6FC-4f65-9D91-7224C49458BB}" xmlns:c15="http://schemas.microsoft.com/office/drawing/2012/chart">'),
                (a += '            <c15:showLeaderLines val="1"/>'),
                (a += "        </c:ext>"),
                (a += "    </c:extLst>"),
                (a += "</c:dLbls>")));
          }
          (A.length === 1 &&
            t.chartColors !== Ze &&
            r.values.forEach((g, d) => {
              const m =
                g < 0
                  ? t.invertedColors || t.chartColors || Ze
                  : t.chartColors || [];
              ((a += "  <c:dPt>"),
                (a += `    <c:idx val="${d}"/>`),
                (a += '      <c:invertIfNegative val="0"/>'),
                (a += '    <c:bubble3D val="0"/>'),
                (a += "    <c:spPr>"),
                t.lineSize === 0
                  ? (a += "<a:ln><a:noFill/></a:ln>")
                  : ((a += "<a:solidFill>"),
                    (a += ' <a:srgbClr val="' + m[d % m.length] + '"/>'),
                    (a += "</a:solidFill>")),
                (a += Ie(t.shadow, Se)),
                (a += "    </c:spPr>"),
                (a += "  </c:dPt>"));
            }),
            (a += "<c:xVal>"),
            (a += "  <c:numRef>"),
            (a += `    <c:f>Sheet1!$A$2:$A$${A[0].values.length + 1}</c:f>`),
            (a += "    <c:numCache>"),
            (a += "      <c:formatCode>General</c:formatCode>"),
            (a += `      <c:ptCount val="${A[0].values.length}"/>`),
            A[0].values.forEach((g, d) => {
              a += `<c:pt idx="${d}"><c:v>${g || g === 0 ? g : ""}</c:v></c:pt>`;
            }),
            (a += "    </c:numCache>"),
            (a += "  </c:numRef>"),
            (a += "</c:xVal>"),
            (a += "<c:yVal>"),
            (a += "  <c:numRef>"),
            (a += `    <c:f>Sheet1!$${he(u + 2)}$2:$${he(u + 2)}$${A[0].values.length + 1}</c:f>`),
            (a += "    <c:numCache>"),
            (a += "      <c:formatCode>General</c:formatCode>"),
            (a += `      <c:ptCount val="${A[0].values.length}"/>`),
            A[0].values.forEach((g, d) => {
              a += `<c:pt idx="${d}"><c:v>${r.values[d] || r.values[d] === 0 ? r.values[d] : ""}</c:v></c:pt>`;
            }),
            (a += "    </c:numCache>"),
            (a += "  </c:numRef>"),
            (a += "</c:yVal>"),
            (a += '<c:smooth val="' + (t.lineSmooth ? "1" : "0") + '"/>'),
            (a += "</c:ser>"));
        }),
        (a += "  <c:dLbls>"),
        (a += `    <c:numFmt formatCode="${re(t.dataLabelFormatCode) || "General"}" sourceLinked="0"/>`),
        (a += "    <c:txPr>"),
        (a += "      <a:bodyPr/>"),
        (a += "      <a:lstStyle/>"),
        (a += "      <a:p><a:pPr>"),
        (a += `        <a:defRPr b="${t.dataLabelFontBold ? "1" : "0"}" i="${t.dataLabelFontItalic ? "1" : "0"}" strike="noStrike" sz="${Math.round((t.dataLabelFontSize || ke) * 100)}" u="none">`),
        (a +=
          "          <a:solidFill>" +
          fe(t.dataLabelColor || xe) +
          "</a:solidFill>"),
        (a +=
          '          <a:latin typeface="' +
          (t.dataLabelFontFace || "Arial") +
          '"/>'),
        (a += "        </a:defRPr>"),
        (a += "      </a:pPr></a:p>"),
        (a += "    </c:txPr>"),
        t.dataLabelPosition &&
          (a += ' <c:dLblPos val="' + t.dataLabelPosition + '"/>'),
        (a += '    <c:showLegendKey val="0"/>'),
        (a += '    <c:showVal val="' + (t.showValue ? "1" : "0") + '"/>'),
        (a += '    <c:showCatName val="0"/>'),
        (a += '    <c:showSerName val="' + (t.showSerName ? "1" : "0") + '"/>'),
        (a += '    <c:showPercent val="0"/>'),
        (a += '    <c:showBubbleSize val="0"/>'),
        (a += "  </c:dLbls>"),
        (a += `<c:axId val="${n}"/><c:axId val="${o}"/>`),
        (a += "</c:" + e + "Chart>"));
      break;
    case W.BUBBLE:
    case W.BUBBLE3D:
      ((a += "<c:bubbleChart>"),
        (a += '<c:varyColors val="0"/>'),
        (l = -1),
        A.filter((r, u) => u > 0).forEach((r, u) => {
          (l++,
            (a += "<c:ser>"),
            (a += `  <c:idx val="${u}"/>`),
            (a += `  <c:order val="${u}"/>`),
            (a += "  <c:tx>"),
            (a += "    <c:strRef>"),
            (a += "      <c:f>Sheet1!$" + he(c + 1) + "$1</c:f>"),
            (a +=
              '      <c:strCache><c:ptCount val="1"/><c:pt idx="0"><c:v>' +
              re(r.name) +
              "</c:v></c:pt></c:strCache>"),
            (a += "    </c:strRef>"),
            (a += "  </c:tx>"));
          {
            a += "<c:spPr>";
            const g = t.chartColors[l % t.chartColors.length];
            (g === "transparent"
              ? (a += "<a:noFill/>")
              : t.chartColorsOpacity
                ? (a += `<a:solidFill>${fe(g, '<a:alpha val="' + Math.round(t.chartColorsOpacity * 1e3).toString() + '"/>')}</a:solidFill>`)
                : (a += "<a:solidFill>" + fe(g) + "</a:solidFill>"),
              t.lineSize === 0
                ? (a += "<a:ln><a:noFill/></a:ln>")
                : t.dataBorder
                  ? (a += `<a:ln w="${te(t.dataBorder.pt)}" cap="flat"><a:solidFill>${fe(t.dataBorder.color)}</a:solidFill><a:prstDash val="solid"/><a:round/></a:ln>`)
                  : ((a += `<a:ln w="${te(t.lineSize)}" cap="flat"><a:solidFill>${fe(g)}</a:solidFill>`),
                    (a += `<a:prstDash val="${t.lineDash || "solid"}"/><a:round/></a:ln>`)),
              (a += Ie(t.shadow, Se)),
              (a += "</c:spPr>"));
          }
          ((a += "<c:xVal>"),
            (a += "  <c:numRef>"),
            (a += `    <c:f>Sheet1!$A$2:$A$${A[0].values.length + 1}</c:f>`),
            (a += "    <c:numCache>"),
            (a += "      <c:formatCode>General</c:formatCode>"),
            (a += `      <c:ptCount val="${A[0].values.length}"/>`),
            A[0].values.forEach((g, d) => {
              a += `<c:pt idx="${d}"><c:v>${g || g === 0 ? g : ""}</c:v></c:pt>`;
            }),
            (a += "    </c:numCache>"),
            (a += "  </c:numRef>"),
            (a += "</c:xVal>"),
            (a += "<c:yVal>"),
            (a += "  <c:numRef>"),
            (a += `<c:f>Sheet1!$${he(c + 1)}$2:$${he(c + 1)}$${A[0].values.length + 1}</c:f>`),
            c++,
            (a += "    <c:numCache>"),
            (a += "      <c:formatCode>General</c:formatCode>"),
            (a += `      <c:ptCount val="${A[0].values.length}"/>`),
            A[0].values.forEach((g, d) => {
              a += `<c:pt idx="${d}"><c:v>${r.values[d] || r.values[d] === 0 ? r.values[d] : ""}</c:v></c:pt>`;
            }),
            (a += "    </c:numCache>"),
            (a += "  </c:numRef>"),
            (a += "</c:yVal>"),
            (a += "  <c:bubbleSize>"),
            (a += "    <c:numRef>"),
            (a += `<c:f>Sheet1!$${he(c + 1)}$2:$${he(c + 1)}$${r.sizes.length + 1}</c:f>`),
            c++,
            (a += "      <c:numCache>"),
            (a += "        <c:formatCode>General</c:formatCode>"),
            (a += `           <c:ptCount val="${r.sizes.length}"/>`),
            r.sizes.forEach((g, d) => {
              a += `<c:pt idx="${d}"><c:v>${g || ""}</c:v></c:pt>`;
            }),
            (a += "      </c:numCache>"),
            (a += "    </c:numRef>"),
            (a += "  </c:bubbleSize>"),
            (a +=
              '  <c:bubble3D val="' + (e === W.BUBBLE3D ? "1" : "0") + '"/>'),
            (a += "</c:ser>"));
        }),
        (a += "<c:dLbls>"),
        (a += `<c:numFmt formatCode="${re(t.dataLabelFormatCode) || "General"}" sourceLinked="0"/>`),
        (a += "<c:txPr><a:bodyPr/><a:lstStyle/><a:p><a:pPr>"),
        (a += `<a:defRPr b="${t.dataLabelFontBold ? 1 : 0}" i="${t.dataLabelFontItalic ? 1 : 0}" strike="noStrike" sz="${Math.round(Math.round(t.dataLabelFontSize || ke) * 100)}" u="none">`),
        (a += `<a:solidFill>${fe(t.dataLabelColor || xe)}</a:solidFill>`),
        (a += `<a:latin typeface="${t.dataLabelFontFace || "Arial"}"/>`),
        (a += "</a:defRPr></a:pPr></a:p></c:txPr>"),
        t.dataLabelPosition &&
          (a += `<c:dLblPos val="${t.dataLabelPosition}"/>`),
        (a += '<c:showLegendKey val="0"/>'),
        (a += `<c:showVal val="${t.showValue ? "1" : "0"}"/>`),
        (a += `<c:showCatName val="0"/><c:showSerName val="${t.showSerName ? "1" : "0"}"/><c:showPercent val="0"/><c:showBubbleSize val="0"/>`),
        (a += "<c:extLst>"),
        (a +=
          '  <c:ext uri="{CE6537A1-D6FC-4f65-9D91-7224C49458BB}" xmlns:c15="http://schemas.microsoft.com/office/drawing/2012/chart">'),
        (a +=
          '    <c15:showLeaderLines val="' +
          (t.showLeaderLines ? "1" : "0") +
          '"/>'),
        (a += "  </c:ext>"),
        (a += "</c:extLst>"),
        (a += "</c:dLbls>"),
        (a += `<c:axId val="${n}"/><c:axId val="${o}"/>`),
        (a += "</c:bubbleChart>"));
      break;
    case W.DOUGHNUT:
    case W.PIE:
      ((i = A[0]),
        (a += "<c:" + e + "Chart>"),
        (a += '  <c:varyColors val="1"/>'),
        (a += "<c:ser>"),
        (a += '  <c:idx val="0"/>'),
        (a += '  <c:order val="0"/>'),
        (a += "  <c:tx>"),
        (a += "    <c:strRef>"),
        (a += "      <c:f>Sheet1!$B$1</c:f>"),
        (a += "      <c:strCache>"),
        (a += '        <c:ptCount val="1"/>'),
        (a += '        <c:pt idx="0"><c:v>' + re(i.name) + "</c:v></c:pt>"),
        (a += "      </c:strCache>"),
        (a += "    </c:strRef>"),
        (a += "  </c:tx>"),
        (a += "  <c:spPr>"),
        (a += '    <a:solidFill><a:schemeClr val="accent1"/></a:solidFill>'),
        (a +=
          '    <a:ln w="9525" cap="flat"><a:solidFill><a:srgbClr val="F9F9F9"/></a:solidFill><a:prstDash val="solid"/><a:round/></a:ln>'),
        t.dataNoEffects ? (a += "<a:effectLst/>") : (a += Ie(t.shadow, Se)),
        (a += "  </c:spPr>"),
        i.labels[0].forEach((r, u) => {
          ((a += "<c:dPt>"),
            (a += ` <c:idx val="${u}"/>`),
            (a += ' <c:bubble3D val="0"/>'),
            (a += " <c:spPr>"),
            (a += `<a:solidFill>${fe(t.chartColors[u + 1 > t.chartColors.length ? Math.floor(Math.random() * t.chartColors.length) : u])}</a:solidFill>`),
            t.dataBorder &&
              (a += `<a:ln w="${te(t.dataBorder.pt)}" cap="flat"><a:solidFill>${fe(t.dataBorder.color)}</a:solidFill><a:prstDash val="solid"/><a:round/></a:ln>`),
            (a += Ie(t.shadow, Se)),
            (a += "  </c:spPr>"),
            (a += "</c:dPt>"));
        }),
        (a += "<c:dLbls>"),
        i.labels[0].forEach((r, u) => {
          ((a += "<c:dLbl>"),
            (a += ` <c:idx val="${u}"/>`),
            (a += `  <c:numFmt formatCode="${re(t.dataLabelFormatCode) || "General"}" sourceLinked="0"/>`),
            (a += "  <c:spPr/><c:txPr>"),
            (a += "   <a:bodyPr/><a:lstStyle/>"),
            (a += "   <a:p><a:pPr>"),
            (a += `   <a:defRPr sz="${Math.round((t.dataLabelFontSize || ke) * 100)}" b="${t.dataLabelFontBold ? 1 : 0}" i="${t.dataLabelFontItalic ? 1 : 0}" u="none" strike="noStrike">`),
            (a +=
              "    <a:solidFill>" +
              fe(t.dataLabelColor || xe) +
              "</a:solidFill>"),
            (a += `    <a:latin typeface="${t.dataLabelFontFace || "Arial"}"/>`),
            (a += "   </a:defRPr>"),
            (a += "      </a:pPr></a:p>"),
            (a += "    </c:txPr>"),
            e === W.PIE &&
              t.dataLabelPosition &&
              (a += `<c:dLblPos val="${t.dataLabelPosition}"/>`),
            (a += '    <c:showLegendKey val="0"/>'),
            (a += '    <c:showVal val="' + (t.showValue ? "1" : "0") + '"/>'),
            (a +=
              '    <c:showCatName val="' + (t.showLabel ? "1" : "0") + '"/>'),
            (a +=
              '    <c:showSerName val="' + (t.showSerName ? "1" : "0") + '"/>'),
            (a +=
              '    <c:showPercent val="' + (t.showPercent ? "1" : "0") + '"/>'),
            (a += '    <c:showBubbleSize val="0"/>'),
            (a += "  </c:dLbl>"));
        }),
        (a += ` <c:numFmt formatCode="${re(t.dataLabelFormatCode) || "General"}" sourceLinked="0"/>`),
        (a += "    <c:txPr>"),
        (a += "      <a:bodyPr/>"),
        (a += "      <a:lstStyle/>"),
        (a += "      <a:p>"),
        (a += "        <a:pPr>"),
        (a += `          <a:defRPr sz="1800" b="${t.dataLabelFontBold ? "1" : "0"}" i="${t.dataLabelFontItalic ? "1" : "0"}" u="none" strike="noStrike">`),
        (a +=
          '            <a:solidFill><a:srgbClr val="000000"/></a:solidFill><a:latin typeface="Arial"/>'),
        (a += "          </a:defRPr>"),
        (a += "        </a:pPr>"),
        (a += "      </a:p>"),
        (a += "    </c:txPr>"),
        (a += e === W.PIE ? '<c:dLblPos val="ctr"/>' : ""),
        (a += '    <c:showLegendKey val="0"/>'),
        (a += '    <c:showVal val="0"/>'),
        (a += '    <c:showCatName val="1"/>'),
        (a += '    <c:showSerName val="0"/>'),
        (a += '    <c:showPercent val="1"/>'),
        (a += '    <c:showBubbleSize val="0"/>'),
        (a += ` <c:showLeaderLines val="${t.showLeaderLines ? "1" : "0"}"/>`),
        (a += "</c:dLbls>"),
        (a += "<c:cat>"),
        (a += "  <c:strRef>"),
        (a += `    <c:f>Sheet1!$A$2:$A$${i.labels[0].length + 1}</c:f>`),
        (a += "    <c:strCache>"),
        (a += `         <c:ptCount val="${i.labels[0].length}"/>`),
        i.labels[0].forEach((r, u) => {
          a += `<c:pt idx="${u}"><c:v>${re(r)}</c:v></c:pt>`;
        }),
        (a += "    </c:strCache>"),
        (a += "  </c:strRef>"),
        (a += "</c:cat>"),
        (a += "  <c:val>"),
        (a += "    <c:numRef>"),
        (a += `      <c:f>Sheet1!$B$2:$B$${i.labels[0].length + 1}</c:f>`),
        (a += "      <c:numCache>"),
        (a += `           <c:ptCount val="${i.labels[0].length}"/>`),
        i.values.forEach((r, u) => {
          a += `<c:pt idx="${u}"><c:v>${r || r === 0 ? r : ""}</c:v></c:pt>`;
        }),
        (a += "      </c:numCache>"),
        (a += "    </c:numRef>"),
        (a += "  </c:val>"),
        (a += "  </c:ser>"),
        (a += `  <c:firstSliceAng val="${t.firstSliceAng ? Math.round(t.firstSliceAng) : 0}"/>`),
        e === W.DOUGHNUT &&
          (a += `<c:holeSize val="${typeof t.holeSize == "number" ? t.holeSize : "50"}"/>`),
        (a += "</c:" + e + "Chart>"));
      break;
    default:
      a += "";
      break;
  }
  return a;
}
function gt(e, A, t) {
  let o = "";
  return (
    e._type === W.SCATTER || e._type === W.BUBBLE || e._type === W.BUBBLE3D
      ? (o += "<c:valAx>")
      : (o += "<c:" + (e.catLabelFormatCode ? "dateAx" : "catAx") + ">"),
    (o += '  <c:axId val="' + A + '"/>'),
    (o += "  <c:scaling>"),
    (o +=
      '<c:orientation val="' +
      (e.catAxisOrientation || (e.barDir === "col", "minMax")) +
      '"/>'),
    (e.catAxisMaxVal || e.catAxisMaxVal === 0) &&
      (o += `<c:max val="${e.catAxisMaxVal}"/>`),
    (e.catAxisMinVal || e.catAxisMinVal === 0) &&
      (o += `<c:min val="${e.catAxisMinVal}"/>`),
    (o += "</c:scaling>"),
    (o += '  <c:delete val="' + (e.catAxisHidden ? "1" : "0") + '"/>'),
    (o += '  <c:axPos val="' + (e.barDir === "col" ? "b" : "l") + '"/>'),
    (o += e.catGridLine.style !== "none" ? Rt(e.catGridLine) : ""),
    e.showCatAxisTitle &&
      (o += dt({
        color: e.catAxisTitleColor,
        fontFace: e.catAxisTitleFontFace,
        fontSize: e.catAxisTitleFontSize,
        titleRotate: e.catAxisTitleRotate,
        title: e.catAxisTitle || "Axis Title",
      })),
    e._type === W.SCATTER || e._type === W.BUBBLE || e._type === W.BUBBLE3D
      ? (o +=
          '  <c:numFmt formatCode="' +
          (e.valAxisLabelFormatCode
            ? re(e.valAxisLabelFormatCode)
            : "General") +
          '" sourceLinked="1"/>')
      : (o +=
          '  <c:numFmt formatCode="' +
          (re(e.catLabelFormatCode) || "General") +
          '" sourceLinked="1"/>'),
    e._type === W.SCATTER
      ? ((o += '  <c:majorTickMark val="none"/>'),
        (o += '  <c:minorTickMark val="none"/>'),
        (o += '  <c:tickLblPos val="nextTo"/>'))
      : ((o +=
          '  <c:majorTickMark val="' +
          (e.catAxisMajorTickMark || "out") +
          '"/>'),
        (o +=
          '  <c:minorTickMark val="' +
          (e.catAxisMinorTickMark || "none") +
          '"/>'),
        (o +=
          '  <c:tickLblPos val="' +
          (e.catAxisLabelPos || (e.barDir === "col" ? "low" : "nextTo")) +
          '"/>')),
    (o += "  <c:spPr>"),
    (o += `    <a:ln w="${e.catAxisLineSize ? te(e.catAxisLineSize) : et}" cap="flat">`),
    (o += e.catAxisLineShow
      ? "<a:solidFill>" + fe(e.catAxisLineColor || Me.color) + "</a:solidFill>"
      : "<a:noFill/>"),
    (o += '      <a:prstDash val="' + (e.catAxisLineStyle || "solid") + '"/>'),
    (o += "      <a:round/>"),
    (o += "    </a:ln>"),
    (o += "  </c:spPr>"),
    (o += "  <c:txPr>"),
    e.catAxisLabelRotate
      ? (o += `<a:bodyPr rot="${Ee(e.catAxisLabelRotate)}"/>`)
      : (o += "<a:bodyPr/>"),
    (o += "    <a:lstStyle/>"),
    (o += "    <a:p>"),
    (o += "    <a:pPr>"),
    (o += `      <a:defRPr sz="${Math.round((e.catAxisLabelFontSize || ke) * 100)}" b="${e.catAxisLabelFontBold ? 1 : 0}" i="${e.catAxisLabelFontItalic ? 1 : 0}" u="none" strike="noStrike">`),
    (o +=
      "      <a:solidFill>" + fe(e.catAxisLabelColor || xe) + "</a:solidFill>"),
    (o +=
      '      <a:latin typeface="' +
      (e.catAxisLabelFontFace || "Arial") +
      '"/>'),
    (o += "   </a:defRPr>"),
    (o += "  </a:pPr>"),
    (o += '  <a:endParaRPr lang="' + (e.lang || "en-US") + '"/>'),
    (o += "  </a:p>"),
    (o += " </c:txPr>"),
    (o += ' <c:crossAx val="' + t + '"/>'),
    (o += ` <c:${typeof e.valAxisCrossesAt == "number" ? "crossesAt" : "crosses"} val="${e.valAxisCrossesAt || "autoZero"}"/>`),
    (o += ' <c:auto val="1"/>'),
    (o += ' <c:lblAlgn val="ctr"/>'),
    (o += ` <c:noMultiLvlLbl val="${e.catAxisMultiLevelLabels ? 0 : 1}"/>`),
    e.catAxisLabelFrequency &&
      (o += ' <c:tickLblSkip val="' + e.catAxisLabelFrequency + '"/>'),
    (e.catLabelFormatCode ||
      e._type === W.SCATTER ||
      e._type === W.BUBBLE ||
      e._type === W.BUBBLE3D) &&
      (e.catLabelFormatCode &&
        ([
          "catAxisBaseTimeUnit",
          "catAxisMajorTimeUnit",
          "catAxisMinorTimeUnit",
        ].forEach((n) => {
          e[n] &&
            (typeof e[n] != "string" ||
              !["days", "months", "years"].includes(e[n].toLowerCase())) &&
            (console.warn(`"${n}" must be one of: 'days','months','years' !`),
            (e[n] = null));
        }),
        e.catAxisBaseTimeUnit &&
          (o +=
            '<c:baseTimeUnit val="' +
            e.catAxisBaseTimeUnit.toLowerCase() +
            '"/>'),
        e.catAxisMajorTimeUnit &&
          (o +=
            '<c:majorTimeUnit val="' +
            e.catAxisMajorTimeUnit.toLowerCase() +
            '"/>'),
        e.catAxisMinorTimeUnit &&
          (o +=
            '<c:minorTimeUnit val="' +
            e.catAxisMinorTimeUnit.toLowerCase() +
            '"/>')),
      e.catAxisMajorUnit && (o += `<c:majorUnit val="${e.catAxisMajorUnit}"/>`),
      e.catAxisMinorUnit &&
        (o += `<c:minorUnit val="${e.catAxisMinorUnit}"/>`)),
    e._type === W.SCATTER || e._type === W.BUBBLE || e._type === W.BUBBLE3D
      ? (o += "</c:valAx>")
      : (o += "</c:" + (e.catLabelFormatCode ? "dateAx" : "catAx") + ">"),
    o
  );
}
function vt(e, A) {
  let t =
    A === Re
      ? e.barDir === "col"
        ? "l"
        : "b"
      : e.barDir !== "col"
        ? "r"
        : "t";
  A === it && (t = "r");
  const o = A === Re ? Ke : xt;
  let n = "";
  return (
    (n += "<c:valAx>"),
    (n += '  <c:axId val="' + A + '"/>'),
    (n += "  <c:scaling>"),
    e.valAxisLogScaleBase &&
      (n += `<c:logBase val="${e.valAxisLogScaleBase}"/>`),
    (n +=
      '<c:orientation val="' +
      (e.valAxisOrientation || (e.barDir === "col", "minMax")) +
      '"/>'),
    (e.valAxisMaxVal || e.valAxisMaxVal === 0) &&
      (n += `<c:max val="${e.valAxisMaxVal}"/>`),
    (e.valAxisMinVal || e.valAxisMinVal === 0) &&
      (n += `<c:min val="${e.valAxisMinVal}"/>`),
    (n += "  </c:scaling>"),
    (n += `  <c:delete val="${e.valAxisHidden ? 1 : 0}"/>`),
    (n += '  <c:axPos val="' + t + '"/>'),
    e.valGridLine.style !== "none" && (n += Rt(e.valGridLine)),
    e.showValAxisTitle &&
      (n += dt({
        color: e.valAxisTitleColor,
        fontFace: e.valAxisTitleFontFace,
        fontSize: e.valAxisTitleFontSize,
        titleRotate: e.valAxisTitleRotate,
        title: e.valAxisTitle || "Axis Title",
      })),
    (n += `<c:numFmt formatCode="${e.valAxisLabelFormatCode ? re(e.valAxisLabelFormatCode) : "General"}" sourceLinked="0"/>`),
    e._type === W.SCATTER
      ? ((n += '  <c:majorTickMark val="none"/>'),
        (n += '  <c:minorTickMark val="none"/>'),
        (n += '  <c:tickLblPos val="nextTo"/>'))
      : ((n +=
          ' <c:majorTickMark val="' +
          (e.valAxisMajorTickMark || "out") +
          '"/>'),
        (n +=
          ' <c:minorTickMark val="' +
          (e.valAxisMinorTickMark || "none") +
          '"/>'),
        (n +=
          ' <c:tickLblPos val="' +
          (e.valAxisLabelPos || (e.barDir === "col" ? "nextTo" : "low")) +
          '"/>')),
    (n += " <c:spPr>"),
    (n += `   <a:ln w="${e.valAxisLineSize ? te(e.valAxisLineSize) : et}" cap="flat">`),
    (n += e.valAxisLineShow
      ? "<a:solidFill>" + fe(e.valAxisLineColor || Me.color) + "</a:solidFill>"
      : "<a:noFill/>"),
    (n += '     <a:prstDash val="' + (e.valAxisLineStyle || "solid") + '"/>'),
    (n += "     <a:round/>"),
    (n += "   </a:ln>"),
    (n += " </c:spPr>"),
    (n += " <c:txPr>"),
    (n += `  <a:bodyPr${e.valAxisLabelRotate ? ' rot="' + Ee(e.valAxisLabelRotate).toString() + '"' : ""}/>`),
    (n += "  <a:lstStyle/>"),
    (n += "  <a:p>"),
    (n += "    <a:pPr>"),
    (n += `      <a:defRPr sz="${Math.round((e.valAxisLabelFontSize || ke) * 100)}" b="${e.valAxisLabelFontBold ? 1 : 0}" i="${e.valAxisLabelFontItalic ? 1 : 0}" u="none" strike="noStrike">`),
    (n +=
      "        <a:solidFill>" +
      fe(e.valAxisLabelColor || xe) +
      "</a:solidFill>"),
    (n +=
      '        <a:latin typeface="' +
      (e.valAxisLabelFontFace || "Arial") +
      '"/>'),
    (n += "      </a:defRPr>"),
    (n += "    </a:pPr>"),
    (n += '  <a:endParaRPr lang="' + (e.lang || "en-US") + '"/>'),
    (n += "  </a:p>"),
    (n += " </c:txPr>"),
    (n += ' <c:crossAx val="' + o + '"/>'),
    typeof e.catAxisCrossesAt == "number"
      ? (n += ` <c:crossesAt val="${e.catAxisCrossesAt}"/>`)
      : typeof e.catAxisCrossesAt == "string"
        ? (n += ' <c:crosses val="' + e.catAxisCrossesAt + '"/>')
        : (n +=
            ' <c:crosses val="' +
            (t === "r" || t === "t" ? "max" : "autoZero") +
            '"/>'),
    (n +=
      ' <c:crossBetween val="' +
      (e._type === W.SCATTER ||
      (Array.isArray(e._type) &&
        e._type.filter((s) => s.type === W.AREA).length > 0)
        ? "midCat"
        : "between") +
      '"/>'),
    e.valAxisMajorUnit && (n += ` <c:majorUnit val="${e.valAxisMajorUnit}"/>`),
    e.valAxisDisplayUnit &&
      (n += `<c:dispUnits><c:builtInUnit val="${e.valAxisDisplayUnit}"/>${e.valAxisDisplayUnitLabel ? "<c:dispUnitsLbl/>" : ""}</c:dispUnits>`),
    (n += "</c:valAx>"),
    n
  );
}
function xa(e, A, t) {
  let o = "";
  return (
    (o += "<c:serAx>"),
    (o += '  <c:axId val="' + A + '"/>'),
    (o +=
      '  <c:scaling><c:orientation val="' +
      (e.serAxisOrientation || (e.barDir === "col", "minMax")) +
      '"/></c:scaling>'),
    (o += '  <c:delete val="' + (e.serAxisHidden ? "1" : "0") + '"/>'),
    (o += '  <c:axPos val="' + (e.barDir === "col" ? "b" : "l") + '"/>'),
    (o += e.serGridLine.style !== "none" ? Rt(e.serGridLine) : ""),
    e.showSerAxisTitle &&
      (o += dt({
        color: e.serAxisTitleColor,
        fontFace: e.serAxisTitleFontFace,
        fontSize: e.serAxisTitleFontSize,
        titleRotate: e.serAxisTitleRotate,
        title: e.serAxisTitle || "Axis Title",
      })),
    (o += `  <c:numFmt formatCode="${re(e.serLabelFormatCode) || "General"}" sourceLinked="0"/>`),
    (o += '  <c:majorTickMark val="out"/>'),
    (o += '  <c:minorTickMark val="none"/>'),
    (o += `  <c:tickLblPos val="${e.serAxisLabelPos || e.barDir === "col" ? "low" : "nextTo"}"/>`),
    (o += "  <c:spPr>"),
    (o += '    <a:ln w="12700" cap="flat">'),
    (o += e.serAxisLineShow
      ? `<a:solidFill>${fe(e.serAxisLineColor || Me.color)}</a:solidFill>`
      : "<a:noFill/>"),
    (o += '      <a:prstDash val="solid"/>'),
    (o += "      <a:round/>"),
    (o += "    </a:ln>"),
    (o += "  </c:spPr>"),
    (o += "  <c:txPr>"),
    (o += "    <a:bodyPr/>"),
    (o += "    <a:lstStyle/>"),
    (o += "    <a:p>"),
    (o += "    <a:pPr>"),
    (o += `    <a:defRPr sz="${Math.round((e.serAxisLabelFontSize || ke) * 100)}" b="${e.serAxisLabelFontBold ? "1" : "0"}" i="${e.serAxisLabelFontItalic ? "1" : "0"}" u="none" strike="noStrike">`),
    (o += `      <a:solidFill>${fe(e.serAxisLabelColor || xe)}</a:solidFill>`),
    (o += `      <a:latin typeface="${e.serAxisLabelFontFace || "Arial"}"/>`),
    (o += "   </a:defRPr>"),
    (o += "  </a:pPr>"),
    (o += '  <a:endParaRPr lang="' + (e.lang || "en-US") + '"/>'),
    (o += "  </a:p>"),
    (o += " </c:txPr>"),
    (o += ' <c:crossAx val="' + t + '"/>'),
    (o += ' <c:crosses val="autoZero"/>'),
    e.serAxisLabelFrequency &&
      (o += ' <c:tickLblSkip val="' + e.serAxisLabelFrequency + '"/>'),
    e.serLabelFormatCode &&
      ([
        "serAxisBaseTimeUnit",
        "serAxisMajorTimeUnit",
        "serAxisMinorTimeUnit",
      ].forEach((n) => {
        e[n] &&
          (typeof e[n] != "string" ||
            !["days", "months", "years"].includes(n.toLowerCase())) &&
          (console.warn(`"${n}" must be one of: 'days','months','years' !`),
          (e[n] = null));
      }),
      e.serAxisBaseTimeUnit &&
        (o += ` <c:baseTimeUnit  val="${e.serAxisBaseTimeUnit.toLowerCase()}"/>`),
      e.serAxisMajorTimeUnit &&
        (o += ` <c:majorTimeUnit val="${e.serAxisMajorTimeUnit.toLowerCase()}"/>`),
      e.serAxisMinorTimeUnit &&
        (o += ` <c:minorTimeUnit val="${e.serAxisMinorTimeUnit.toLowerCase()}"/>`),
      e.serAxisMajorUnit &&
        (o += ` <c:majorUnit val="${e.serAxisMajorUnit}"/>`),
      e.serAxisMinorUnit &&
        (o += ` <c:minorUnit val="${e.serAxisMinorUnit}"/>`)),
    (o += "</c:serAx>"),
    o
  );
}
function dt(e, A, t) {
  const o =
      e.titleAlign === "left" || e.titleAlign === "right"
        ? `<a:pPr algn="${e.titleAlign.substring(0, 1)}">`
        : "<a:pPr>",
    n = e.titleRotate
      ? `<a:bodyPr rot="${Ee(e.titleRotate)}"/>`
      : "<a:bodyPr/>",
    s = e.fontSize ? `sz="${Math.round(e.fontSize * 100)}"` : "",
    l = e.titleBold ? 1 : 0;
  let c = "<c:layout/>";
  if (
    e.titlePos &&
    typeof e.titlePos.x == "number" &&
    typeof e.titlePos.y == "number"
  ) {
    const i = e.titlePos.x + A,
      a = e.titlePos.y + t;
    let r = i === 0 ? 0 : (i * (i / 5)) / 10;
    (r >= 1 && (r = r / 10), r >= 0.1 && (r = r / 10));
    let u = a === 0 ? 0 : (a * (a / 5)) / 10;
    (u >= 1 && (u = u / 10),
      u >= 0.1 && (u = u / 10),
      (c = `<c:layout><c:manualLayout><c:xMode val="edge"/><c:yMode val="edge"/><c:x val="${r}"/><c:y val="${u}"/></c:manualLayout></c:layout>`));
  }
  return `<c:title>
      <c:tx>
        <c:rich>
          ${n}
          <a:lstStyle/>
          <a:p>
            ${o}
            <a:defRPr ${s} b="${l}" i="0" u="none" strike="noStrike">
              <a:solidFill>${fe(e.color || xe)}</a:solidFill>
              <a:latin typeface="${e.fontFace || "Arial"}"/>
            </a:defRPr>
          </a:pPr>
          <a:r>
            <a:rPr ${s} b="${l}" i="0" u="none" strike="noStrike">
              <a:solidFill>${fe(e.color || xe)}</a:solidFill>
              <a:latin typeface="${e.fontFace || "Arial"}"/>
            </a:rPr>
            <a:t>${re(e.title) || ""}</a:t>
          </a:r>
        </a:p>
        </c:rich>
      </c:tx>
      ${c}
      <c:overlay val="0"/>
    </c:title>`;
}
function he(e) {
  let A = "";
  const t = e - 1;
  return (
    t <= 25
      ? (A = He[t])
      : (A = `${He[Math.floor(t / He.length - 1)]}${He[t % He.length]}`),
    A
  );
}
function Ie(e, A) {
  if (e) {
    if (typeof e != "object")
      return (
        console.warn(
          "`shadow` options must be an object. Ex: `{shadow: {type:'none'}}`",
        ),
        "<a:effectLst/>"
      );
  } else return "<a:effectLst/>";
  let t = "<a:effectLst>";
  const o = Object.assign(Object.assign({}, A), e),
    n = o.type || "outer",
    s = te(o.blur),
    l = te(o.offset),
    c = Math.round(o.angle * 6e4),
    i = o.color,
    a = Math.round(o.opacity * 1e5),
    r = o.rotateWithShape ? 1 : 0;
  return (
    (t += `<a:${n}Shdw sx="100000" sy="100000" kx="0" ky="0"  algn="bl" blurRad="${s}" rotWithShape="${r}" dist="${l}" dir="${c}">`),
    (t += `<a:srgbClr val="${i}">`),
    (t += `<a:alpha val="${a}"/></a:srgbClr>`),
    (t += `</a:${n}Shdw>`),
    (t += "</a:effectLst>"),
    t
  );
}
function Rt(e) {
  let A = "<c:majorGridlines>";
  return (
    (A += " <c:spPr>"),
    (A += `  <a:ln w="${te(e.size || Me.size)}" cap="${st(e.cap || Me.cap)}">`),
    (A +=
      '  <a:solidFill><a:srgbClr val="' +
      (e.color || Me.color) +
      '"/></a:solidFill>'),
    (A += '   <a:prstDash val="' + (e.style || Me.style) + '"/><a:round/>'),
    (A += "  </a:ln>"),
    (A += " </c:spPr>"),
    (A += "</c:majorGridlines>"),
    A
  );
}
function st(e) {
  if (!e || e === "flat") return "flat";
  if (e === "square") return "sq";
  if (e === "round") return "rnd";
  {
    const A = e;
    throw new Error(`Invalid chart line cap: ${A}`);
  }
}
function yt(e) {
  var A, t;
  const o =
    typeof process < "u" &&
    !!(!((A = process.versions) === null || A === void 0) && A.node) &&
    ((t = process.release) === null || t === void 0 ? void 0 : t.name) ===
      "node";
  let n, s;
  const l = o
    ? () =>
        Be(this, void 0, void 0, function* () {
          (({ default: n } = yield bt(
            () => import("./__vite-browser-external-BIHI7g3E.js"),
            [],
          )),
            ({ default: s } = yield bt(
              () => import("./__vite-browser-external-BIHI7g3E.js"),
              [],
            )));
        })
    : () => Be(this, void 0, void 0, function* () {});
  o && l();
  const c = [],
    i = e._relsMedia.filter(
      (r) =>
        r.type !== "online" &&
        !r.data &&
        (!r.path || (r.path && !r.path.includes("preencoded"))),
    ),
    a = [];
  return (
    i.forEach((r) => {
      a.includes(r.path)
        ? (r.isDuplicate = !0)
        : ((r.isDuplicate = !1), a.push(r.path));
    }),
    i
      .filter((r) => !r.isDuplicate)
      .forEach((r) => {
        c.push(
          Be(this, void 0, void 0, function* () {
            if ((s || (yield l()), o && n && r.path.indexOf("http") !== 0))
              try {
                const u = n.readFileSync(r.path);
                return (
                  (r.data = Buffer.from(u).toString("base64")),
                  i
                    .filter((g) => g.isDuplicate && g.path === r.path)
                    .forEach((g) => (g.data = r.data)),
                  "done"
                );
              } catch (u) {
                throw (
                  (r.data = We),
                  i
                    .filter((g) => g.isDuplicate && g.path === r.path)
                    .forEach((g) => (g.data = r.data)),
                  new Error(`ERROR: Unable to read media: "${r.path}"
${String(u)}`)
                );
              }
            return o && s && r.path.startsWith("http")
              ? yield new Promise((u, g) => {
                  s.get(r.path, (d) => {
                    let m = "";
                    (d.setEncoding("binary"),
                      d.on("data", (h) => (m += h)),
                      d.on("end", () => {
                        ((r.data = Buffer.from(m, "binary").toString("base64")),
                          i
                            .filter((h) => h.isDuplicate && h.path === r.path)
                            .forEach((h) => (h.data = r.data)),
                          u("done"));
                      }),
                      d.on("error", () => {
                        ((r.data = We),
                          i
                            .filter((h) => h.isDuplicate && h.path === r.path)
                            .forEach((h) => (h.data = r.data)),
                          g(
                            new Error(
                              `ERROR! Unable to load image (https.get): ${r.path}`,
                            ),
                          ));
                      }));
                  });
                })
              : yield new Promise((u, g) => {
                  const d = new XMLHttpRequest();
                  ((d.onload = () => {
                    const m = new FileReader();
                    ((m.onloadend = () => {
                      ((r.data = m.result),
                        i
                          .filter((h) => h.isDuplicate && h.path === r.path)
                          .forEach((h) => (h.data = r.data)),
                        r.isSvgPng
                          ? zt(r)
                              .then(() => u("done"))
                              .catch(g)
                          : u("done"));
                    }),
                      m.readAsDataURL(d.response));
                  }),
                    (d.onerror = () => {
                      ((r.data = We),
                        i
                          .filter((m) => m.isDuplicate && m.path === r.path)
                          .forEach((m) => (m.data = r.data)),
                        g(
                          new Error(
                            `ERROR! Unable to load image (xhr.onerror): ${r.path}`,
                          ),
                        ));
                    }),
                    d.open("GET", r.path),
                    (d.responseType = "blob"),
                    d.send());
                });
          }),
        );
      }),
    e._relsMedia
      .filter((r) => r.isSvgPng && r.data)
      .forEach((r) => {
        Be(this, void 0, void 0, function* () {
          (o && !n && (yield l()),
            o && n
              ? ((r.data = We), c.push(Promise.resolve("done")))
              : c.push(zt(r)));
        });
      }),
    c
  );
}
function zt(e) {
  return Be(this, void 0, void 0, function* () {
    return yield new Promise((A, t) => {
      const o = new Image();
      ((o.onload = () => {
        o.width + o.height === 0 && o.onerror("h/w=0");
        let n = document.createElement("CANVAS");
        const s = n.getContext("2d");
        ((n.width = o.width), (n.height = o.height), s.drawImage(o, 0, 0));
        try {
          ((e.data = n.toDataURL(e.type)), A("done"));
        } catch (l) {
          o.onerror(l.toString());
        }
        n = null;
      }),
        (o.onerror = () => {
          ((e.data = We),
            t(
              new Error(
                `ERROR! Unable to load image (image.onerror): ${e.path}`,
              ),
            ));
        }),
        (o.src = typeof e.data == "string" ? e.data : We));
    });
  });
}
const Ca = {
  cover: function (e, A) {
    const t = e.h / e.w,
      n = A.h / A.w > t,
      s = n ? A.h / t : A.w,
      l = n ? A.h : A.w * t,
      c = Math.round(1e5 * 0.5 * (1 - A.w / s)),
      i = Math.round(1e5 * 0.5 * (1 - A.h / l));
    return `<a:srcRect l="${c}" r="${c}" t="${i}" b="${i}"/><a:stretch/>`;
  },
  contain: function (e, A) {
    const t = e.h / e.w,
      n = A.h / A.w > t,
      s = n ? A.w : A.h / t,
      l = n ? A.w * t : A.h,
      c = Math.round(1e5 * 0.5 * (1 - A.w / s)),
      i = Math.round(1e5 * 0.5 * (1 - A.h / l));
    return `<a:srcRect l="${c}" r="${c}" t="${i}" b="${i}"/><a:stretch/>`;
  },
  crop: function (e, A) {
    const t = A.x,
      o = e.w - (A.x + A.w),
      n = A.y,
      s = e.h - (A.y + A.h),
      l = Math.round(1e5 * (t / e.w)),
      c = Math.round(1e5 * (o / e.w)),
      i = Math.round(1e5 * (n / e.h)),
      a = Math.round(1e5 * (s / e.h));
    return `<a:srcRect l="${l}" r="${c}" t="${i}" b="${a}"/><a:stretch/>`;
  },
};
function Ft(e) {
  var A;
  let t = e._name ? '<p:cSld name="' + e._name + '">' : "<p:cSld>",
    o = 1;
  return (
    e._bkgdImgRid
      ? (t += `<p:bg><p:bgPr><a:blipFill dpi="0" rotWithShape="1"><a:blip r:embed="rId${e._bkgdImgRid}"><a:lum/></a:blip><a:srcRect/><a:stretch><a:fillRect/></a:stretch></a:blipFill><a:effectLst/></p:bgPr></p:bg>`)
      : !((A = e.background) === null || A === void 0) && A.color
        ? (t += `<p:bg><p:bgPr>${Le(e.background)}</p:bgPr></p:bg>`)
        : !e.bkgd &&
          e._name &&
          e._name === wt &&
          (t +=
            '<p:bg><p:bgRef idx="1001"><a:schemeClr val="bg1"/></p:bgRef></p:bg>'),
    (t += "<p:spTree>"),
    (t +=
      '<p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr>'),
    (t += '<p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/>'),
    (t +=
      '<a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr>'),
    e._slideObjects.forEach((n, s) => {
      var l, c, i, a, r, u, g, d;
      let m = 0,
        h = 0,
        y = ie("75%", "X", e._presLayout),
        v = 0,
        b,
        C = "",
        D = null,
        L = null,
        M = 0,
        _ = 0,
        X = null,
        P = null;
      const E = (l = n.options) === null || l === void 0 ? void 0 : l.sizing,
        J = (c = n.options) === null || c === void 0 ? void 0 : c.rounding;
      (e._slideLayout !== void 0 &&
        e._slideLayout._slideObjects !== void 0 &&
        n.options &&
        n.options.placeholder &&
        (b = e._slideLayout._slideObjects.filter(
          (p) => p.options.placeholder === n.options.placeholder,
        )[0]),
        (n.options = n.options || {}),
        typeof n.options.x < "u" && (m = ie(n.options.x, "X", e._presLayout)),
        typeof n.options.y < "u" && (h = ie(n.options.y, "Y", e._presLayout)),
        typeof n.options.w < "u" && (y = ie(n.options.w, "X", e._presLayout)),
        typeof n.options.h < "u" && (v = ie(n.options.h, "Y", e._presLayout)));
      let B = y,
        S = v;
      switch (
        (b &&
          ((b.options.x || b.options.x === 0) &&
            (m = ie(b.options.x, "X", e._presLayout)),
          (b.options.y || b.options.y === 0) &&
            (h = ie(b.options.y, "Y", e._presLayout)),
          (b.options.w || b.options.w === 0) &&
            (y = ie(b.options.w, "X", e._presLayout)),
          (b.options.h || b.options.h === 0) &&
            (v = ie(b.options.h, "Y", e._presLayout))),
        n.options.flipH && (C += ' flipH="1"'),
        n.options.flipV && (C += ' flipV="1"'),
        n.options.rotate && (C += ` rot="${Ee(n.options.rotate)}"`),
        n._type)
      ) {
        case ne.table:
          if (
            ((D = n.arrTabRows),
            (L = n.options),
            (M = 0),
            (_ = 0),
            D[0].forEach((p) => {
              ((X = p.options || null),
                (M += X?.colspan ? Number(X.colspan) : 1));
            }),
            (P = `<p:graphicFrame><p:nvGraphicFramePr><p:cNvPr id="${o * e._slideNum + 1}" name="${n.options.objectName}"/>`),
            (P +=
              '<p:cNvGraphicFramePr><a:graphicFrameLocks noGrp="1"/></p:cNvGraphicFramePr>  <p:nvPr><p:extLst><p:ext uri="{D42A27DB-BD31-4B8C-83A1-F6EECF244321}"><p14:modId xmlns:p14="http://schemas.microsoft.com/office/powerpoint/2010/main" val="1579011935"/></p:ext></p:extLst></p:nvPr></p:nvGraphicFramePr>'),
            (P += `<p:xfrm><a:off x="${m || (m === 0 ? 0 : Ae)}" y="${h || (h === 0 ? 0 : Ae)}"/><a:ext cx="${y || (y === 0 ? 0 : Ae)}" cy="${v || Ae}"/></p:xfrm>`),
            (P +=
              '<a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/table"><a:tbl><a:tblPr/>'),
            Array.isArray(L.colW))
          ) {
            P += "<a:tblGrid>";
            for (let p = 0; p < M; p++) {
              let T = le(L.colW[p]);
              ((T == null || isNaN(T)) &&
                (T = (typeof n.options.w == "number" ? n.options.w : 1) / M),
                (P += `<a:gridCol w="${Math.round(T)}"/>`));
            }
            P += "</a:tblGrid>";
          } else {
            ((_ = L.colW ? L.colW : Ae),
              n.options.w &&
                !L.colW &&
                (_ = Math.round(
                  (typeof n.options.w == "number" ? n.options.w : 1) / M,
                )),
              (P += "<a:tblGrid>"));
            for (let p = 0; p < M; p++) P += `<a:gridCol w="${_}"/>`;
            P += "</a:tblGrid>";
          }
          (D.forEach((p) => {
            var T, Z;
            for (let U = 0; U < p.length;) {
              const ae = p[U],
                Q =
                  (T = ae.options) === null || T === void 0
                    ? void 0
                    : T.colspan,
                $ =
                  (Z = ae.options) === null || Z === void 0
                    ? void 0
                    : Z.rowspan;
              if (Q && Q > 1) {
                const F = new Array(Q - 1)
                  .fill(void 0)
                  .map(() => ({
                    _type: ne.tablecell,
                    options: { rowspan: $ },
                    _hmerge: !0,
                  }));
                (p.splice(U + 1, 0, ...F), (U += Q));
              } else U += 1;
            }
          }),
            D.forEach((p, T) => {
              const Z = D[T + 1];
              Z &&
                p.forEach((U, ae) => {
                  var Q, $;
                  const F =
                      U._rowContinue ||
                      ((Q = U.options) === null || Q === void 0
                        ? void 0
                        : Q.rowspan),
                    R =
                      ($ = U.options) === null || $ === void 0
                        ? void 0
                        : $.colspan,
                    K = U._hmerge;
                  if (F && F > 1) {
                    const H = {
                      _type: ne.tablecell,
                      options: { colspan: R },
                      _rowContinue: F - 1,
                      _vmerge: !0,
                      _hmerge: K,
                    };
                    Z.splice(ae, 0, H);
                  }
                });
            }),
            D.forEach((p, T) => {
              let Z = 0;
              (Array.isArray(L.rowH) && L.rowH[T]
                ? (Z = le(Number(L.rowH[T])))
                : L.rowH && !isNaN(Number(L.rowH))
                  ? (Z = le(Number(L.rowH)))
                  : (n.options.cy || n.options.h) &&
                    (Z = Math.round(
                      (n.options.h
                        ? le(n.options.h)
                        : typeof n.options.cy == "number"
                          ? n.options.cy
                          : 1) / D.length,
                    )),
                (P += `<a:tr h="${Z}">`),
                p.forEach((U) => {
                  var ae, Q, $, F, R;
                  const K = U,
                    H = {
                      rowSpan:
                        ((ae = K.options) === null || ae === void 0
                          ? void 0
                          : ae.rowspan) > 1
                          ? K.options.rowspan
                          : void 0,
                      gridSpan:
                        ((Q = K.options) === null || Q === void 0
                          ? void 0
                          : Q.colspan) > 1
                          ? K.options.colspan
                          : void 0,
                      vMerge: K._vmerge ? 1 : void 0,
                      hMerge: K._hmerge ? 1 : void 0,
                    };
                  let q = Object.keys(H)
                    .map((ue) => [ue, H[ue]])
                    .filter(([, ue]) => !!ue)
                    .map(([ue, f]) => `${String(ue)}="${String(f)}"`)
                    .join(" ");
                  if ((q && (q = " " + q), K._hmerge || K._vmerge)) {
                    P += `<a:tc${q}><a:tcPr/></a:tc>`;
                    return;
                  }
                  const oe = K.options || {};
                  ((K.options = oe),
                    [
                      "align",
                      "bold",
                      "border",
                      "color",
                      "fill",
                      "fontFace",
                      "fontSize",
                      "margin",
                      "textDirection",
                      "underline",
                      "valign",
                    ].forEach((ue) => {
                      L[ue] && !oe[ue] && oe[ue] !== 0 && (oe[ue] = L[ue]);
                    }));
                  const ye = oe.valign
                      ? ` anchor="${oe.valign.replace(/^c$/i, "ctr").replace(/^m$/i, "ctr").replace("center", "ctr").replace("middle", "ctr").replace("top", "t").replace("btm", "b").replace("bottom", "b")}"`
                      : "",
                    ce =
                      oe.textDirection && oe.textDirection !== "horz"
                        ? ` vert="${oe.textDirection}"`
                        : "";
                  let de =
                    !(
                      (F =
                        ($ = K._optImp) === null || $ === void 0
                          ? void 0
                          : $.fill) === null || F === void 0
                    ) && F.color
                      ? K._optImp.fill.color
                      : !((R = K._optImp) === null || R === void 0) &&
                          R.fill &&
                          typeof K._optImp.fill == "string"
                        ? K._optImp.fill
                        : "";
                  de = de || oe.fill ? oe.fill : "";
                  const ve = de ? Le(de) : "";
                  let se = oe.margin === 0 || oe.margin ? oe.margin : Qt;
                  !Array.isArray(se) &&
                    typeof se == "number" &&
                    (se = [se, se, se, se]);
                  let we = "";
                  (se[0] >= 1
                    ? (we = ` marL="${te(se[3])}" marR="${te(se[1])}" marT="${te(se[0])}" marB="${te(se[2])}"`)
                    : (we = ` marL="${le(se[3])}" marR="${le(se[1])}" marT="${le(se[0])}" marB="${le(se[2])}"`),
                    (P += `<a:tc${q}>${Xt(K)}<a:tcPr${we}${ye}${ce}>`),
                    oe.border &&
                      Array.isArray(oe.border) &&
                      [
                        { idx: 3, name: "lnL" },
                        { idx: 1, name: "lnR" },
                        { idx: 0, name: "lnT" },
                        { idx: 2, name: "lnB" },
                      ].forEach((ue) => {
                        oe.border[ue.idx].type !== "none"
                          ? ((P += `<a:${ue.name} w="${te(oe.border[ue.idx].pt)}" cap="flat" cmpd="sng" algn="ctr">`),
                            (P += `<a:solidFill>${fe(oe.border[ue.idx].color)}</a:solidFill>`),
                            (P += `<a:prstDash val="${oe.border[ue.idx].type === "dash" ? "sysDash" : "solid"}"/><a:round/><a:headEnd type="none" w="med" len="med"/><a:tailEnd type="none" w="med" len="med"/>`),
                            (P += `</a:${ue.name}>`))
                          : (P += `<a:${ue.name} w="0" cap="flat" cmpd="sng" algn="ctr"><a:noFill/></a:${ue.name}>`);
                      }),
                    (P += ve),
                    (P += "  </a:tcPr>"),
                    (P += " </a:tc>"));
                }),
                (P += "</a:tr>"));
            }),
            (P += "      </a:tbl>"),
            (P += "    </a:graphicData>"),
            (P += "  </a:graphic>"),
            (P += "</p:graphicFrame>"),
            (t += P),
            o++);
          break;
        case ne.text:
        case ne.placeholder:
          if (
            (!n.options.line && v === 0 && (v = Ae * 0.3),
            n.options._bodyProp || (n.options._bodyProp = {}),
            n.options.margin && Array.isArray(n.options.margin)
              ? ((n.options._bodyProp.lIns = te(n.options.margin[0] || 0)),
                (n.options._bodyProp.rIns = te(n.options.margin[1] || 0)),
                (n.options._bodyProp.bIns = te(n.options.margin[2] || 0)),
                (n.options._bodyProp.tIns = te(n.options.margin[3] || 0)))
              : typeof n.options.margin == "number" &&
                ((n.options._bodyProp.lIns = te(n.options.margin)),
                (n.options._bodyProp.rIns = te(n.options.margin)),
                (n.options._bodyProp.bIns = te(n.options.margin)),
                (n.options._bodyProp.tIns = te(n.options.margin))),
            (t += "<p:sp>"),
            (t += `<p:nvSpPr><p:cNvPr id="${s + 2}" name="${n.options.objectName}">`),
            !((i = n.options.hyperlink) === null || i === void 0) &&
              i.url &&
              (t += `<a:hlinkClick r:id="rId${n.options.hyperlink._rId}" tooltip="${n.options.hyperlink.tooltip ? re(n.options.hyperlink.tooltip) : ""}"/>`),
            !((a = n.options.hyperlink) === null || a === void 0) &&
              a.slide &&
              (t += `<a:hlinkClick r:id="rId${n.options.hyperlink._rId}" tooltip="${n.options.hyperlink.tooltip ? re(n.options.hyperlink.tooltip) : ""}" action="ppaction://hlinksldjump"/>`),
            (t += "</p:cNvPr>"),
            (t +=
              "<p:cNvSpPr" +
              (!((r = n.options) === null || r === void 0) && r.isTextBox
                ? ' txBox="1"/>'
                : "/>")),
            (t += `<p:nvPr>${n._type === "placeholder" ? At(n) : At(b)}</p:nvPr>`),
            (t += "</p:nvSpPr><p:spPr>"),
            (t += `<a:xfrm${C}>`),
            (t += `<a:off x="${m}" y="${h}"/>`),
            (t += `<a:ext cx="${y}" cy="${v}"/></a:xfrm>`),
            n.shape === "custGeom")
          )
            ((t += "<a:custGeom><a:avLst />"),
              (t += "<a:gdLst>"),
              (t += "</a:gdLst>"),
              (t += "<a:ahLst />"),
              (t += "<a:cxnLst>"),
              (t += "</a:cxnLst>"),
              (t += '<a:rect l="l" t="t" r="r" b="b" />'),
              (t += "<a:pathLst>"),
              (t += `<a:path w="${y}" h="${v}">`),
              (u = n.options.points) === null ||
                u === void 0 ||
                u.forEach((p, T) => {
                  if ("curve" in p)
                    switch (p.curve.type) {
                      case "arc":
                        t += `<a:arcTo hR="${ie(p.curve.hR, "Y", e._presLayout)}" wR="${ie(p.curve.wR, "X", e._presLayout)}" stAng="${Ee(p.curve.stAng)}" swAng="${Ee(p.curve.swAng)}" />`;
                        break;
                      case "cubic":
                        t += `<a:cubicBezTo>
									<a:pt x="${ie(p.curve.x1, "X", e._presLayout)}" y="${ie(p.curve.y1, "Y", e._presLayout)}" />
									<a:pt x="${ie(p.curve.x2, "X", e._presLayout)}" y="${ie(p.curve.y2, "Y", e._presLayout)}" />
									<a:pt x="${ie(p.x, "X", e._presLayout)}" y="${ie(p.y, "Y", e._presLayout)}" />
									</a:cubicBezTo>`;
                        break;
                      case "quadratic":
                        t += `<a:quadBezTo>
									<a:pt x="${ie(p.curve.x1, "X", e._presLayout)}" y="${ie(p.curve.y1, "Y", e._presLayout)}" />
									<a:pt x="${ie(p.x, "X", e._presLayout)}" y="${ie(p.y, "Y", e._presLayout)}" />
									</a:quadBezTo>`;
                        break;
                    }
                  else
                    "close" in p
                      ? (t += "<a:close />")
                      : p.moveTo || T === 0
                        ? (t += `<a:moveTo><a:pt x="${ie(p.x, "X", e._presLayout)}" y="${ie(p.y, "Y", e._presLayout)}" /></a:moveTo>`)
                        : (t += `<a:lnTo><a:pt x="${ie(p.x, "X", e._presLayout)}" y="${ie(p.y, "Y", e._presLayout)}" /></a:lnTo>`);
                }),
              (t += "</a:path>"),
              (t += "</a:pathLst>"),
              (t += "</a:custGeom>"));
          else {
            if (
              ((t += '<a:prstGeom prst="' + n.shape + '"><a:avLst>'),
              n.options.rectRadius)
            )
              t += `<a:gd name="adj" fmla="val ${Math.round((n.options.rectRadius * Ae * 1e5) / Math.min(y, v))}"/>`;
            else if (n.options.angleRange) {
              for (let p = 0; p < 2; p++) {
                const T = n.options.angleRange[p];
                t += `<a:gd name="adj${p + 1}" fmla="val ${Ee(T)}" />`;
              }
              n.options.arcThicknessRatio &&
                (t += `<a:gd name="adj3" fmla="val ${Math.round(n.options.arcThicknessRatio * 5e4)}" />`);
            }
            t += "</a:avLst></a:prstGeom>";
          }
          ((t += n.options.fill ? Le(n.options.fill) : "<a:noFill/>"),
            n.options.line &&
              ((t += n.options.line.width
                ? `<a:ln w="${te(n.options.line.width)}">`
                : "<a:ln>"),
              n.options.line.color && (t += Le(n.options.line)),
              n.options.line.dashType &&
                (t += `<a:prstDash val="${n.options.line.dashType}"/>`),
              n.options.line.beginArrowType &&
                (t += `<a:headEnd type="${n.options.line.beginArrowType}"/>`),
              n.options.line.endArrowType &&
                (t += `<a:tailEnd type="${n.options.line.endArrowType}"/>`),
              (t += "</a:ln>")),
            n.options.shadow &&
              n.options.shadow.type !== "none" &&
              ((n.options.shadow.type = n.options.shadow.type || "outer"),
              (n.options.shadow.blur = te(n.options.shadow.blur || 8)),
              (n.options.shadow.offset = te(n.options.shadow.offset || 4)),
              (n.options.shadow.angle = Math.round(
                (n.options.shadow.angle || 270) * 6e4,
              )),
              (n.options.shadow.opacity = Math.round(
                (n.options.shadow.opacity || 0.75) * 1e5,
              )),
              (n.options.shadow.color = n.options.shadow.color || Mt.color),
              (t += "<a:effectLst>"),
              (t += ` <a:${n.options.shadow.type}Shdw ${n.options.shadow.type === "outer" ? 'sx="100000" sy="100000" kx="0" ky="0" algn="bl" rotWithShape="0"' : ""} blurRad="${n.options.shadow.blur}" dist="${n.options.shadow.offset}" dir="${n.options.shadow.angle}">`),
              (t += ` <a:srgbClr val="${n.options.shadow.color}">`),
              (t += ` <a:alpha val="${n.options.shadow.opacity}"/></a:srgbClr>`),
              (t += " </a:outerShdw>"),
              (t += "</a:effectLst>")),
            (t += "</p:spPr>"),
            (t += Xt(n)),
            (t += "</p:sp>"));
          break;
        case ne.image:
          if (
            ((t += "<p:pic>"),
            (t += "  <p:nvPicPr>"),
            (t += `<p:cNvPr id="${s + 2}" name="${n.options.objectName}" descr="${re(n.options.altText || n.image)}">`),
            !((g = n.hyperlink) === null || g === void 0) &&
              g.url &&
              (t += `<a:hlinkClick r:id="rId${n.hyperlink._rId}" tooltip="${n.hyperlink.tooltip ? re(n.hyperlink.tooltip) : ""}"/>`),
            !((d = n.hyperlink) === null || d === void 0) &&
              d.slide &&
              (t += `<a:hlinkClick r:id="rId${n.hyperlink._rId}" tooltip="${n.hyperlink.tooltip ? re(n.hyperlink.tooltip) : ""}" action="ppaction://hlinksldjump"/>`),
            (t += "    </p:cNvPr>"),
            (t +=
              '    <p:cNvPicPr><a:picLocks noChangeAspect="1"/></p:cNvPicPr>'),
            (t += "    <p:nvPr>" + At(b) + "</p:nvPr>"),
            (t += "  </p:nvPicPr>"),
            (t += "<p:blipFill>"),
            (e._relsMedia || []).filter((p) => p.rId === n.imageRid)[0] &&
            (e._relsMedia || []).filter((p) => p.rId === n.imageRid)[0].extn ===
              "svg"
              ? ((t += `<a:blip r:embed="rId${n.imageRid - 1}">`),
                (t += n.options.transparency
                  ? ` <a:alphaModFix amt="${Math.round((100 - n.options.transparency) * 1e3)}"/>`
                  : ""),
                (t += " <a:extLst>"),
                (t += '  <a:ext uri="{96DAC541-7B7A-43D3-8B79-37D633B846F1}">'),
                (t += `   <asvg:svgBlip xmlns:asvg="http://schemas.microsoft.com/office/drawing/2016/SVG/main" r:embed="rId${n.imageRid}"/>`),
                (t += "  </a:ext>"),
                (t += " </a:extLst>"),
                (t += "</a:blip>"))
              : ((t += `<a:blip r:embed="rId${n.imageRid}">`),
                (t += n.options.transparency
                  ? `<a:alphaModFix amt="${Math.round((100 - n.options.transparency) * 1e3)}"/>`
                  : ""),
                (t += "</a:blip>")),
            E?.type)
          ) {
            const p = E.w ? ie(E.w, "X", e._presLayout) : y,
              T = E.h ? ie(E.h, "Y", e._presLayout) : v,
              Z = ie(E.x || 0, "X", e._presLayout),
              U = ie(E.y || 0, "Y", e._presLayout);
            ((t += Ca[E.type]({ w: B, h: S }, { w: p, h: T, x: Z, y: U })),
              (B = p),
              (S = T));
          } else t += "  <a:stretch><a:fillRect/></a:stretch>";
          ((t += "</p:blipFill>"),
            (t += "<p:spPr>"),
            (t += " <a:xfrm" + C + ">"),
            (t += `  <a:off x="${m}" y="${h}"/>`),
            (t += `  <a:ext cx="${B}" cy="${S}"/>`),
            (t += " </a:xfrm>"),
            (t += ` <a:prstGeom prst="${J ? "ellipse" : "rect"}"><a:avLst/></a:prstGeom>`),
            n.options.shadow &&
              n.options.shadow.type !== "none" &&
              ((n.options.shadow.type = n.options.shadow.type || "outer"),
              (n.options.shadow.blur = te(n.options.shadow.blur || 8)),
              (n.options.shadow.offset = te(n.options.shadow.offset || 4)),
              (n.options.shadow.angle = Math.round(
                (n.options.shadow.angle || 270) * 6e4,
              )),
              (n.options.shadow.opacity = Math.round(
                (n.options.shadow.opacity || 0.75) * 1e5,
              )),
              (n.options.shadow.color = n.options.shadow.color || Mt.color),
              (t += "<a:effectLst>"),
              (t += `<a:${n.options.shadow.type}Shdw ${n.options.shadow.type === "outer" ? 'sx="100000" sy="100000" kx="0" ky="0" algn="bl" rotWithShape="0"' : ""} blurRad="${n.options.shadow.blur}" dist="${n.options.shadow.offset}" dir="${n.options.shadow.angle}">`),
              (t += `<a:srgbClr val="${n.options.shadow.color}">`),
              (t += `<a:alpha val="${n.options.shadow.opacity}"/></a:srgbClr>`),
              (t += `</a:${n.options.shadow.type}Shdw>`),
              (t += "</a:effectLst>")),
            (t += "</p:spPr>"),
            (t += "</p:pic>"));
          break;
        case ne.media:
          n.mtype === "online"
            ? ((t += "<p:pic>"),
              (t += " <p:nvPicPr>"),
              (t += `<p:cNvPr id="${n.mediaRid + 2}" name="${n.options.objectName}"/>`),
              (t += " <p:cNvPicPr/>"),
              (t += " <p:nvPr>"),
              (t += `  <a:videoFile r:link="rId${n.mediaRid}"/>`),
              (t += " </p:nvPr>"),
              (t += " </p:nvPicPr>"),
              (t += ` <p:blipFill><a:blip r:embed="rId${n.mediaRid + 1}"/><a:stretch><a:fillRect/></a:stretch></p:blipFill>`),
              (t += " <p:spPr>"),
              (t += `  <a:xfrm${C}><a:off x="${m}" y="${h}"/><a:ext cx="${y}" cy="${v}"/></a:xfrm>`),
              (t += '  <a:prstGeom prst="rect"><a:avLst/></a:prstGeom>'),
              (t += " </p:spPr>"),
              (t += "</p:pic>"))
            : ((t += "<p:pic>"),
              (t += " <p:nvPicPr>"),
              (t += `<p:cNvPr id="${n.mediaRid + 2}" name="${n.options.objectName}"><a:hlinkClick r:id="" action="ppaction://media"/></p:cNvPr>`),
              (t +=
                ' <p:cNvPicPr><a:picLocks noChangeAspect="1"/></p:cNvPicPr>'),
              (t += " <p:nvPr>"),
              (t += `  <a:videoFile r:link="rId${n.mediaRid}"/>`),
              (t += "  <p:extLst>"),
              (t += '   <p:ext uri="{DAA4B4D4-6D71-4841-9C94-3DE7FCFB9230}">'),
              (t += `    <p14:media xmlns:p14="http://schemas.microsoft.com/office/powerpoint/2010/main" r:embed="rId${n.mediaRid + 1}"/>`),
              (t += "   </p:ext>"),
              (t += "  </p:extLst>"),
              (t += " </p:nvPr>"),
              (t += " </p:nvPicPr>"),
              (t += ` <p:blipFill><a:blip r:embed="rId${n.mediaRid + 2}"/><a:stretch><a:fillRect/></a:stretch></p:blipFill>`),
              (t += " <p:spPr>"),
              (t += `  <a:xfrm${C}><a:off x="${m}" y="${h}"/><a:ext cx="${y}" cy="${v}"/></a:xfrm>`),
              (t += '  <a:prstGeom prst="rect"><a:avLst/></a:prstGeom>'),
              (t += " </p:spPr>"),
              (t += "</p:pic>"));
          break;
        case ne.chart:
          ((t += "<p:graphicFrame>"),
            (t += " <p:nvGraphicFramePr>"),
            (t += `   <p:cNvPr id="${s + 2}" name="${n.options.objectName}" descr="${re(n.options.altText || "")}"/>`),
            (t += "   <p:cNvGraphicFramePr/>"),
            (t += `   <p:nvPr>${At(b)}</p:nvPr>`),
            (t += " </p:nvGraphicFramePr>"),
            (t += ` <p:xfrm><a:off x="${m}" y="${h}"/><a:ext cx="${y}" cy="${v}"/></p:xfrm>`),
            (t +=
              ' <a:graphic xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">'),
            (t +=
              '  <a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/chart">'),
            (t += `   <c:chart r:id="rId${n.chartRid}" xmlns:c="http://schemas.openxmlformats.org/drawingml/2006/chart"/>`),
            (t += "  </a:graphicData>"),
            (t += " </a:graphic>"),
            (t += "</p:graphicFrame>"));
          break;
        default:
          t += "";
          break;
      }
    }),
    e._slideNumberProps &&
      (e._slideNumberProps.align || (e._slideNumberProps.align = "left"),
      (t += "<p:sp>"),
      (t += " <p:nvSpPr>"),
      (t +=
        '  <p:cNvPr id="25" name="Slide Number Placeholder 0"/><p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr>'),
      (t +=
        '  <p:nvPr><p:ph type="sldNum" sz="quarter" idx="4294967295"/></p:nvPr>'),
      (t += " </p:nvSpPr>"),
      (t += " <p:spPr>"),
      (t += `<a:xfrm><a:off x="${ie(e._slideNumberProps.x, "X", e._presLayout)}" y="${ie(e._slideNumberProps.y, "Y", e._presLayout)}"/><a:ext cx="${e._slideNumberProps.w ? ie(e._slideNumberProps.w, "X", e._presLayout) : "800000"}" cy="${e._slideNumberProps.h ? ie(e._slideNumberProps.h, "Y", e._presLayout) : "300000"}"/></a:xfrm> <a:prstGeom prst="rect"><a:avLst/></a:prstGeom> <a:extLst><a:ext uri="{C572A759-6A51-4108-AA02-DFA0A04FC94B}"><ma14:wrappingTextBoxFlag val="0" xmlns:ma14="http://schemas.microsoft.com/office/mac/drawingml/2011/main"/></a:ext></a:extLst></p:spPr>`),
      (t += "<p:txBody>"),
      (t += "<a:bodyPr"),
      e._slideNumberProps.margin && Array.isArray(e._slideNumberProps.margin)
        ? ((t += ` lIns="${te(e._slideNumberProps.margin[3] || 0)}"`),
          (t += ` tIns="${te(e._slideNumberProps.margin[0] || 0)}"`),
          (t += ` rIns="${te(e._slideNumberProps.margin[1] || 0)}"`),
          (t += ` bIns="${te(e._slideNumberProps.margin[2] || 0)}"`))
        : typeof e._slideNumberProps.margin == "number" &&
          ((t += ` lIns="${te(e._slideNumberProps.margin || 0)}"`),
          (t += ` tIns="${te(e._slideNumberProps.margin || 0)}"`),
          (t += ` rIns="${te(e._slideNumberProps.margin || 0)}"`),
          (t += ` bIns="${te(e._slideNumberProps.margin || 0)}"`)),
      e._slideNumberProps.valign &&
        (t += ` anchor="${e._slideNumberProps.valign.replace("top", "t").replace("middle", "ctr").replace("bottom", "b")}"`),
      (t += "/>"),
      (t += "  <a:lstStyle><a:lvl1pPr>"),
      (e._slideNumberProps.fontFace ||
        e._slideNumberProps.fontSize ||
        e._slideNumberProps.color) &&
        ((t += `<a:defRPr sz="${Math.round((e._slideNumberProps.fontSize || 12) * 100)}">`),
        e._slideNumberProps.color && (t += Le(e._slideNumberProps.color)),
        e._slideNumberProps.fontFace &&
          (t += `<a:latin typeface="${e._slideNumberProps.fontFace}"/><a:ea typeface="${e._slideNumberProps.fontFace}"/><a:cs typeface="${e._slideNumberProps.fontFace}"/>`),
        (t += "</a:defRPr>")),
      (t += "</a:lvl1pPr></a:lstStyle>"),
      (t += "<a:p>"),
      e._slideNumberProps.align.startsWith("l")
        ? (t += '<a:pPr algn="l"/>')
        : e._slideNumberProps.align.startsWith("c")
          ? (t += '<a:pPr algn="ctr"/>')
          : e._slideNumberProps.align.startsWith("r")
            ? (t += '<a:pPr algn="r"/>')
            : (t += '<a:pPr algn="l"/>'),
      (t += `<a:fld id="${Vt}" type="slidenum"><a:rPr b="${e._slideNumberProps.bold ? 1 : 0}" lang="en-US"/>`),
      (t += `<a:t>${e._slideNum}</a:t></a:fld><a:endParaRPr lang="en-US"/></a:p>`),
      (t += "</p:txBody></p:sp>")),
    (t += "</p:spTree>"),
    (t += "</p:cSld>"),
    t
  );
}
function Tt(e, A) {
  let t = 0,
    o =
      '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
      be +
      '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">';
  return (
    e._rels.forEach((n) => {
      ((t = Math.max(t, n.rId)),
        n.type.toLowerCase().includes("hyperlink")
          ? n.data === "slide"
            ? (o += `<Relationship Id="rId${n.rId}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide" Target="slide${n.Target}.xml"/>`)
            : (o += `<Relationship Id="rId${n.rId}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink" Target="${n.Target}" TargetMode="External"/>`)
          : n.type.toLowerCase().includes("notesSlide") &&
            (o += `<Relationship Id="rId${n.rId}" Target="${n.Target}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/notesSlide"/>`));
    }),
    (e._relsChart || []).forEach((n) => {
      ((t = Math.max(t, n.rId)),
        (o += `<Relationship Id="rId${n.rId}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/chart" Target="${n.Target}"/>`));
    }),
    (e._relsMedia || []).forEach((n) => {
      const s = n.rId.toString();
      ((t = Math.max(t, n.rId)),
        n.type.toLowerCase().includes("image")
          ? (o +=
              '<Relationship Id="rId' +
              s +
              '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="' +
              n.Target +
              '"/>')
          : n.type.toLowerCase().includes("audio")
            ? o.includes(' Target="' + n.Target + '"')
              ? (o +=
                  '<Relationship Id="rId' +
                  s +
                  '" Type="http://schemas.microsoft.com/office/2007/relationships/media" Target="' +
                  n.Target +
                  '"/>')
              : (o +=
                  '<Relationship Id="rId' +
                  s +
                  '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/audio" Target="' +
                  n.Target +
                  '"/>')
            : n.type.toLowerCase().includes("video")
              ? o.includes(' Target="' + n.Target + '"')
                ? (o +=
                    '<Relationship Id="rId' +
                    s +
                    '" Type="http://schemas.microsoft.com/office/2007/relationships/media" Target="' +
                    n.Target +
                    '"/>')
                : (o +=
                    '<Relationship Id="rId' +
                    s +
                    '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/video" Target="' +
                    n.Target +
                    '"/>')
              : n.type.toLowerCase().includes("online") &&
                (o.includes(' Target="' + n.Target + '"')
                  ? (o +=
                      '<Relationship Id="rId' +
                      s +
                      '" Type="http://schemas.microsoft.com/office/2007/relationships/image" Target="' +
                      n.Target +
                      '"/>')
                  : (o +=
                      '<Relationship Id="rId' +
                      s +
                      '" Target="' +
                      n.Target +
                      '" TargetMode="External" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/video"/>')));
    }),
    A.forEach((n, s) => {
      o += `<Relationship Id="rId${t + s + 1}" Type="${n.type}" Target="${n.target}"/>`;
    }),
    (o += "</Relationships>"),
    o
  );
}
function Ut(e, A) {
  var t, o;
  let n = "",
    s = "",
    l = "",
    c = "";
  const i = A ? "a:lvl1pPr" : "a:pPr";
  let a = te(Aa),
    r = `<${i}${e.options.rtlMode ? ' rtl="1" ' : ""}`;
  {
    if (e.options.align)
      switch (e.options.align) {
        case "left":
          r += ' algn="l"';
          break;
        case "right":
          r += ' algn="r"';
          break;
        case "center":
          r += ' algn="ctr"';
          break;
        case "justify":
          r += ' algn="just"';
          break;
        default:
          r += "";
          break;
      }
    if (
      (e.options.lineSpacing
        ? (s = `<a:lnSpc><a:spcPts val="${Math.round(e.options.lineSpacing * 100)}"/></a:lnSpc>`)
        : e.options.lineSpacingMultiple &&
          (s = `<a:lnSpc><a:spcPct val="${Math.round(e.options.lineSpacingMultiple * 1e5)}"/></a:lnSpc>`),
      e.options.indentLevel &&
        !isNaN(Number(e.options.indentLevel)) &&
        e.options.indentLevel > 0 &&
        (r += ` lvl="${e.options.indentLevel}"`),
      e.options.paraSpaceBefore &&
        !isNaN(Number(e.options.paraSpaceBefore)) &&
        e.options.paraSpaceBefore > 0 &&
        (l += `<a:spcBef><a:spcPts val="${Math.round(e.options.paraSpaceBefore * 100)}"/></a:spcBef>`),
      e.options.paraSpaceAfter &&
        !isNaN(Number(e.options.paraSpaceAfter)) &&
        e.options.paraSpaceAfter > 0 &&
        (l += `<a:spcAft><a:spcPts val="${Math.round(e.options.paraSpaceAfter * 100)}"/></a:spcAft>`),
      typeof e.options.bullet == "object")
    )
      if (
        (!(
          (o =
            (t = e?.options) === null || t === void 0 ? void 0 : t.bullet) ===
            null || o === void 0
        ) &&
          o.indent &&
          (a = te(e.options.bullet.indent)),
        e.options.bullet.type)
      )
        e.options.bullet.type.toString().toLowerCase() === "number" &&
          ((r += ` marL="${e.options.indentLevel && e.options.indentLevel > 0 ? a + a * e.options.indentLevel : a}" indent="-${a}"`),
          (n = `<a:buSzPct val="100000"/><a:buFont typeface="+mj-lt"/><a:buAutoNum type="${e.options.bullet.style || "arabicPeriod"}" startAt="${e.options.bullet.numberStartAt || e.options.bullet.startAt || "1"}"/>`));
      else if (e.options.bullet.characterCode) {
        let u = `&#x${e.options.bullet.characterCode};`;
        (/^[0-9A-Fa-f]{4}$/.test(e.options.bullet.characterCode) ||
          (console.warn(
            "Warning: `bullet.characterCode should be a 4-digit unicode charatcer (ex: 22AB)`!",
          ),
          (u = Oe.DEFAULT)),
          (r += ` marL="${e.options.indentLevel && e.options.indentLevel > 0 ? a + a * e.options.indentLevel : a}" indent="-${a}"`),
          (n = '<a:buSzPct val="100000"/><a:buChar char="' + u + '"/>'));
      } else if (e.options.bullet.code) {
        let u = `&#x${e.options.bullet.code};`;
        (/^[0-9A-Fa-f]{4}$/.test(e.options.bullet.code) ||
          (console.warn(
            "Warning: `bullet.code should be a 4-digit hex code (ex: 22AB)`!",
          ),
          (u = Oe.DEFAULT)),
          (r += ` marL="${e.options.indentLevel && e.options.indentLevel > 0 ? a + a * e.options.indentLevel : a}" indent="-${a}"`),
          (n = '<a:buSzPct val="100000"/><a:buChar char="' + u + '"/>'));
      } else
        ((r += ` marL="${e.options.indentLevel && e.options.indentLevel > 0 ? a + a * e.options.indentLevel : a}" indent="-${a}"`),
          (n = `<a:buSzPct val="100000"/><a:buChar char="${Oe.DEFAULT}"/>`));
    else
      e.options.bullet
        ? ((r += ` marL="${e.options.indentLevel && e.options.indentLevel > 0 ? a + a * e.options.indentLevel : a}" indent="-${a}"`),
          (n = `<a:buSzPct val="100000"/><a:buChar char="${Oe.DEFAULT}"/>`))
        : e.options.bullet ||
          ((r += ' indent="0" marL="0"'), (n = "<a:buNone/>"));
    (e.options.tabStops &&
      Array.isArray(e.options.tabStops) &&
      (c = `<a:tabLst>${e.options.tabStops.map((g) => `<a:tab pos="${le(g.position || 1)}" algn="${g.alignment || "l"}"/>`).join("")}</a:tabLst>`),
      (r += ">" + s + l + n + c),
      A && (r += Kt(e.options, !0)),
      (r += "</" + i + ">"));
  }
  return r;
}
function Kt(e, A) {
  var t;
  let o = "";
  const n = A ? "a:defRPr" : "a:rPr";
  if (
    ((o +=
      "<" +
      n +
      ' lang="' +
      (e.lang ? e.lang : "en-US") +
      '"' +
      (e.lang ? ' altLang="en-US"' : "")),
    (o += e.fontSize ? ` sz="${Math.round(e.fontSize * 100)}"` : ""),
    (o += e?.bold ? ` b="${e.bold ? "1" : "0"}"` : ""),
    (o += e?.italic ? ` i="${e.italic ? "1" : "0"}"` : ""),
    (o += e?.strike
      ? ` strike="${typeof e.strike == "string" ? e.strike : "sngStrike"}"`
      : ""),
    typeof e.underline == "object" &&
    !((t = e.underline) === null || t === void 0) &&
    t.style
      ? (o += ` u="${e.underline.style}"`)
      : typeof e.underline == "string"
        ? (o += ` u="${String(e.underline)}"`)
        : e.hyperlink && (o += ' u="sng"'),
    e.baseline
      ? (o += ` baseline="${Math.round(e.baseline * 50)}"`)
      : e.subscript
        ? (o += ' baseline="-40000"')
        : e.superscript && (o += ' baseline="30000"'),
    (o += e.charSpacing
      ? ` spc="${Math.round(e.charSpacing * 100)}" kern="0"`
      : ""),
    (o += ' dirty="0">'),
    (e.color ||
      e.fontFace ||
      e.outline ||
      (typeof e.underline == "object" && e.underline.color)) &&
      (e.outline &&
        typeof e.outline == "object" &&
        (o += `<a:ln w="${te(e.outline.size || 0.75)}">${Le(e.outline.color || "FFFFFF")}</a:ln>`),
      e.color && (o += Le({ color: e.color, transparency: e.transparency })),
      e.highlight && (o += `<a:highlight>${fe(e.highlight)}</a:highlight>`),
      typeof e.underline == "object" &&
        e.underline.color &&
        (o += `<a:uFill>${Le(e.underline.color)}</a:uFill>`),
      e.glow && (o += `<a:effectLst>${ca(e.glow, oa)}</a:effectLst>`),
      e.fontFace &&
        (o += `<a:latin typeface="${e.fontFace}" pitchFamily="34" charset="0"/><a:ea typeface="${e.fontFace}" pitchFamily="34" charset="-122"/><a:cs typeface="${e.fontFace}" pitchFamily="34" charset="-120"/>`)),
    e.hyperlink)
  ) {
    if (typeof e.hyperlink != "object")
      throw new Error(
        "ERROR: text `hyperlink` option should be an object. Ex: `hyperlink:{url:'https://github.com'}` ",
      );
    if (!e.hyperlink.url && !e.hyperlink.slide)
      throw new Error("ERROR: 'hyperlink requires either `url` or `slide`'");
    (e.hyperlink.url
      ? (o += `<a:hlinkClick r:id="rId${e.hyperlink._rId}" invalidUrl="" action="" tgtFrame="" tooltip="${e.hyperlink.tooltip ? re(e.hyperlink.tooltip) : ""}" history="1" highlightClick="0" endSnd="0"${e.color ? ">" : "/>"}`)
      : e.hyperlink.slide &&
        (o += `<a:hlinkClick r:id="rId${e.hyperlink._rId}" action="ppaction://hlinksldjump" tooltip="${e.hyperlink.tooltip ? re(e.hyperlink.tooltip) : ""}"${e.color ? ">" : "/>"}`),
      e.color &&
        ((o += " <a:extLst>"),
        (o += '  <a:ext uri="{A12FA001-AC4F-418D-AE19-62706E023703}">'),
        (o +=
          '   <ahyp:hlinkClr xmlns:ahyp="http://schemas.microsoft.com/office/drawing/2018/hyperlinkcolor" val="tx"/>'),
        (o += "  </a:ext>"),
        (o += " </a:extLst>"),
        (o += "</a:hlinkClick>")));
  }
  return ((o += `</${n}>`), o);
}
function Ba(e) {
  return e.text
    ? `<a:r>${Kt(e.options, !1)}<a:t>${re(e.text)}</a:t></a:r>`
    : "";
}
function La(e) {
  let A = "<a:bodyPr";
  return (
    e && e._type === ne.text && e.options._bodyProp
      ? ((A += e.options._bodyProp.wrap ? ' wrap="square"' : ' wrap="none"'),
        (e.options._bodyProp.lIns || e.options._bodyProp.lIns === 0) &&
          (A += ` lIns="${e.options._bodyProp.lIns}"`),
        (e.options._bodyProp.tIns || e.options._bodyProp.tIns === 0) &&
          (A += ` tIns="${e.options._bodyProp.tIns}"`),
        (e.options._bodyProp.rIns || e.options._bodyProp.rIns === 0) &&
          (A += ` rIns="${e.options._bodyProp.rIns}"`),
        (e.options._bodyProp.bIns || e.options._bodyProp.bIns === 0) &&
          (A += ` bIns="${e.options._bodyProp.bIns}"`),
        (A += ' rtlCol="0"'),
        e.options._bodyProp.anchor &&
          (A += ' anchor="' + e.options._bodyProp.anchor + '"'),
        e.options._bodyProp.vert &&
          (A += ' vert="' + e.options._bodyProp.vert + '"'),
        (A += ">"),
        e.options.fit &&
          (e.options.fit === "none"
            ? (A += "")
            : e.options.fit === "shrink"
              ? (A += "<a:normAutofit/>")
              : e.options.fit === "resize" && (A += "<a:spAutoFit/>")),
        e.options.shrinkText && (A += "<a:normAutofit/>"),
        (A += e.options._bodyProp.autoFit ? "<a:spAutoFit/>" : ""),
        (A += "</a:bodyPr>"))
      : ((A += ' wrap="square" rtlCol="0">'), (A += "</a:bodyPr>")),
    e._type === ne.tablecell ? "<a:bodyPr/>" : A
  );
}
function Xt(e) {
  const A = e.options || {};
  let t = [];
  const o = [];
  if (A && e._type !== ne.tablecell && (typeof e.text > "u" || e.text === null))
    return "";
  let n = e._type === ne.tablecell ? "<a:txBody>" : "<p:txBody>";
  ((n += La(e)),
    A.h === 0 && A.line && A.align
      ? (n += '<a:lstStyle><a:lvl1pPr algn="l"/></a:lstStyle>')
      : e._type === "placeholder"
        ? (n += `<a:lstStyle>${Ut(e, !0)}</a:lstStyle>`)
        : (n += "<a:lstStyle/>"),
    typeof e.text == "string" || typeof e.text == "number"
      ? t.push({ text: e.text.toString(), options: A || {} })
      : e.text &&
          !Array.isArray(e.text) &&
          typeof e.text == "object" &&
          Object.keys(e.text).includes("text")
        ? t.push({ text: e.text || "", options: e.options || {} })
        : Array.isArray(e.text) &&
          (t = e.text.map((c) => ({ text: c.text, options: c.options }))),
    t.forEach((c, i) => {
      (c.text || (c.text = ""),
        (c.options = c.options || A || {}),
        i === 0 &&
          c.options &&
          !c.options.bullet &&
          A.bullet &&
          (c.options.bullet = A.bullet),
        (typeof c.text == "string" || typeof c.text == "number") &&
          (c.text = c.text.toString().replace(/\r*\n/g, be)),
        c.text.includes(be) && c.text.match(/\n$/g) === null
          ? c.text.split(be).forEach((a) => {
              ((c.options.breakLine = !0),
                o.push({ text: a, options: c.options }));
            })
          : o.push(c));
    }));
  const s = [];
  let l = [];
  return (
    o.forEach((c, i) => {
      (l.length > 0 && (c.options.align || A.align)
        ? c.options.align !== o[i - 1].options.align && (s.push(l), (l = []))
        : l.length > 0 &&
          c.options.bullet &&
          l.length > 0 &&
          (s.push(l), (l = []), (c.options.breakLine = !1)),
        l.push(c),
        l.length > 0 &&
          c.options.breakLine &&
          i + 1 < o.length &&
          (s.push(l), (l = [])),
        i + 1 === o.length && s.push(l));
    }),
    s.forEach((c) => {
      var i;
      let a = !1;
      n += "<a:p>";
      let r = `<a:pPr ${!((i = c[0].options) === null || i === void 0) && i.rtlMode ? ' rtl="1" ' : ""}`;
      (c.forEach((u, g) => {
        ((u.options._lineIdx = g),
          g > 0 && u.options.softBreakBefore && (n += "<a:br/>"),
          (u.options.align = u.options.align || A.align),
          (u.options.lineSpacing = u.options.lineSpacing || A.lineSpacing),
          (u.options.lineSpacingMultiple =
            u.options.lineSpacingMultiple || A.lineSpacingMultiple),
          (u.options.indentLevel = u.options.indentLevel || A.indentLevel),
          (u.options.paraSpaceBefore =
            u.options.paraSpaceBefore || A.paraSpaceBefore),
          (u.options.paraSpaceAfter =
            u.options.paraSpaceAfter || A.paraSpaceAfter),
          (r = Ut(u, !1)),
          (n += r.replace("<a:pPr></a:pPr>", "")),
          Object.entries(A)
            .filter(([d]) => !(u.options.hyperlink && d === "color"))
            .forEach(([d, m]) => {
              d !== "bullet" && !u.options[d] && (u.options[d] = m);
            }),
          (n += Ba(u)),
          ((!u.text && A.fontSize) || u.options.fontSize) &&
            ((a = !0), (A.fontSize = A.fontSize || u.options.fontSize)));
      }),
        e._type === ne.tablecell && (A.fontSize || A.fontFace)
          ? A.fontFace
            ? ((n +=
                `<a:endParaRPr lang="${A.lang || "en-US"}"` +
                (A.fontSize ? ` sz="${Math.round(A.fontSize * 100)}"` : "") +
                ' dirty="0">'),
              (n += `<a:latin typeface="${A.fontFace}" charset="0"/>`),
              (n += `<a:ea typeface="${A.fontFace}" charset="0"/>`),
              (n += `<a:cs typeface="${A.fontFace}" charset="0"/>`),
              (n += "</a:endParaRPr>"))
            : (n +=
                `<a:endParaRPr lang="${A.lang || "en-US"}"` +
                (A.fontSize ? ` sz="${Math.round(A.fontSize * 100)}"` : "") +
                ' dirty="0"/>')
          : a
            ? (n +=
                `<a:endParaRPr lang="${A.lang || "en-US"}"` +
                (A.fontSize ? ` sz="${Math.round(A.fontSize * 100)}"` : "") +
                ' dirty="0"/>')
            : (n += `<a:endParaRPr lang="${A.lang || "en-US"}" dirty="0"/>`),
        (n += "</a:p>"));
    }),
    n.indexOf("<a:p>") === -1 && (n += "<a:p><a:endParaRPr/></a:p>"),
    (n += e._type === ne.tablecell ? "</a:txBody>" : "</p:txBody>"),
    n
  );
}
function At(e) {
  var A, t;
  if (!e) return "";
  const o =
      !((A = e.options) === null || A === void 0) && A._placeholderIdx
        ? e.options._placeholderIdx
        : "",
    n =
      !((t = e.options) === null || t === void 0) && t._placeholderType
        ? e.options._placeholderType
        : "",
    s = n && je[n] ? je[n].toString() : "";
  return `<p:ph
		${o ? ' idx="' + o.toString() + '"' : ""}
		${s && je[s] ? ` type="${s}"` : ""}
		${e.text && e.text.length > 0 ? ' hasCustomPrompt="1"' : ""}
		/>`;
}
function Da(e, A, t) {
  let o = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' + be;
  return (
    (o +=
      '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'),
    (o += '<Default Extension="xml" ContentType="application/xml"/>'),
    (o +=
      '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'),
    (o += '<Default Extension="jpeg" ContentType="image/jpeg"/>'),
    (o += '<Default Extension="jpg" ContentType="image/jpg"/>'),
    (o += '<Default Extension="svg" ContentType="image/svg+xml"/>'),
    (o += '<Default Extension="png" ContentType="image/png"/>'),
    (o += '<Default Extension="gif" ContentType="image/gif"/>'),
    (o += '<Default Extension="m4v" ContentType="video/mp4"/>'),
    (o += '<Default Extension="mp4" ContentType="video/mp4"/>'),
    e.forEach((n) => {
      (n._relsMedia || []).forEach((s) => {
        s.type !== "image" &&
          s.type !== "online" &&
          s.type !== "chart" &&
          s.extn !== "m4v" &&
          !o.includes(s.type) &&
          (o +=
            '<Default Extension="' +
            s.extn +
            '" ContentType="' +
            s.type +
            '"/>');
      });
    }),
    (o +=
      '<Default Extension="vml" ContentType="application/vnd.openxmlformats-officedocument.vmlDrawing"/>'),
    (o +=
      '<Default Extension="xlsx" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"/>'),
    (o +=
      '<Override PartName="/ppt/presentation.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml"/>'),
    (o +=
      '<Override PartName="/ppt/notesMasters/notesMaster1.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.notesMaster+xml"/>'),
    e.forEach((n, s) => {
      ((o += `<Override PartName="/ppt/slideMasters/slideMaster${s + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slideMaster+xml"/>`),
        (o += `<Override PartName="/ppt/slides/slide${s + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slide+xml"/>`),
        n._relsChart.forEach((l) => {
          o += `<Override PartName="${l.Target}" ContentType="application/vnd.openxmlformats-officedocument.drawingml.chart+xml"/>`;
        }));
    }),
    (o +=
      '<Override PartName="/ppt/presProps.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.presProps+xml"/>'),
    (o +=
      '<Override PartName="/ppt/viewProps.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.viewProps+xml"/>'),
    (o +=
      '<Override PartName="/ppt/theme/theme1.xml" ContentType="application/vnd.openxmlformats-officedocument.theme+xml"/>'),
    (o +=
      '<Override PartName="/ppt/tableStyles.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.tableStyles+xml"/>'),
    A.forEach((n, s) => {
      ((o += `<Override PartName="/ppt/slideLayouts/slideLayout${s + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slideLayout+xml"/>`),
        (n._relsChart || []).forEach((l) => {
          o +=
            ' <Override PartName="' +
            l.Target +
            '" ContentType="application/vnd.openxmlformats-officedocument.drawingml.chart+xml"/>';
        }));
    }),
    e.forEach((n, s) => {
      o += `<Override PartName="/ppt/notesSlides/notesSlide${s + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.notesSlide+xml"/>`;
    }),
    t._relsChart.forEach((n) => {
      o +=
        ' <Override PartName="' +
        n.Target +
        '" ContentType="application/vnd.openxmlformats-officedocument.drawingml.chart+xml"/>';
    }),
    t._relsMedia.forEach((n) => {
      n.type !== "image" &&
        n.type !== "online" &&
        n.type !== "chart" &&
        n.extn !== "m4v" &&
        !o.includes(n.type) &&
        (o +=
          ' <Default Extension="' +
          n.extn +
          '" ContentType="' +
          n.type +
          '"/>');
    }),
    (o +=
      ' <Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>'),
    (o +=
      ' <Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>'),
    (o += "</Types>"),
    o
  );
}
function ka() {
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>${be}<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
		<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>
		<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>
		<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="ppt/presentation.xml"/>
		</Relationships>`;
}
function Pa(e, A) {
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>${be}<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes">
	<TotalTime>0</TotalTime>
	<Words>0</Words>
	<Application>Microsoft Office PowerPoint</Application>
	<PresentationFormat>On-screen Show (16:9)</PresentationFormat>
	<Paragraphs>0</Paragraphs>
	<Slides>${e.length}</Slides>
	<Notes>${e.length}</Notes>
	<HiddenSlides>0</HiddenSlides>
	<MMClips>0</MMClips>
	<ScaleCrop>false</ScaleCrop>
	<HeadingPairs>
		<vt:vector size="6" baseType="variant">
			<vt:variant><vt:lpstr>Fonts Used</vt:lpstr></vt:variant>
			<vt:variant><vt:i4>2</vt:i4></vt:variant>
			<vt:variant><vt:lpstr>Theme</vt:lpstr></vt:variant>
			<vt:variant><vt:i4>1</vt:i4></vt:variant>
			<vt:variant><vt:lpstr>Slide Titles</vt:lpstr></vt:variant>
			<vt:variant><vt:i4>${e.length}</vt:i4></vt:variant>
		</vt:vector>
	</HeadingPairs>
	<TitlesOfParts>
		<vt:vector size="${e.length + 1 + 2}" baseType="lpstr">
			<vt:lpstr>Arial</vt:lpstr>
			<vt:lpstr>Calibri</vt:lpstr>
			<vt:lpstr>Office Theme</vt:lpstr>
			${e.map((t, o) => `<vt:lpstr>Slide ${o + 1}</vt:lpstr>`).join("")}
		</vt:vector>
	</TitlesOfParts>
	<Company>${A}</Company>
	<LinksUpToDate>false</LinksUpToDate>
	<SharedDoc>false</SharedDoc>
	<HyperlinksChanged>false</HyperlinksChanged>
	<AppVersion>16.0000</AppVersion>
	</Properties>`;
}
function Na(e, A, t, o) {
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
	<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:dcmitype="http://purl.org/dc/dcmitype/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
		<dc:title>${re(e)}</dc:title>
		<dc:subject>${re(A)}</dc:subject>
		<dc:creator>${re(t)}</dc:creator>
		<cp:lastModifiedBy>${re(t)}</cp:lastModifiedBy>
		<cp:revision>${o}</cp:revision>
		<dcterms:created xsi:type="dcterms:W3CDTF">${new Date().toISOString().replace(/\.\d\d\dZ/, "Z")}</dcterms:created>
		<dcterms:modified xsi:type="dcterms:W3CDTF">${new Date().toISOString().replace(/\.\d\d\dZ/, "Z")}</dcterms:modified>
	</cp:coreProperties>`;
}
function Ra(e) {
  let A = 1,
    t = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' + be;
  ((t +=
    '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'),
    (t +=
      '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideMaster" Target="slideMasters/slideMaster1.xml"/>'));
  for (let o = 1; o <= e.length; o++)
    t += `<Relationship Id="rId${++A}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide" Target="slides/slide${o}.xml"/>`;
  return (
    A++,
    (t += `<Relationship Id="rId${A + 0}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/notesMaster" Target="notesMasters/notesMaster1.xml"/><Relationship Id="rId${A + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/presProps" Target="presProps.xml"/><Relationship Id="rId${A + 2}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/viewProps" Target="viewProps.xml"/><Relationship Id="rId${A + 3}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/theme" Target="theme/theme1.xml"/><Relationship Id="rId${A + 4}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/tableStyles" Target="tableStyles.xml"/></Relationships>`),
    t
  );
}
function Fa(e) {
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>${be}<p:sld xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"${e?.hidden ? ' show="0"' : ""}>${Ft(e)}<p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sld>`;
}
function Ta(e) {
  let A = "";
  return (
    e._slideObjects.forEach((t) => {
      t._type === ne.notes && (A += t?.text && t.text[0] ? t.text[0].text : "");
    }),
    A.replace(/\r*\n/g, be)
  );
}
function _a() {
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>${be}<p:notesMaster xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"><p:cSld><p:bg><p:bgRef idx="1001"><a:schemeClr val="bg1"/></p:bgRef></p:bg><p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr><p:sp><p:nvSpPr><p:cNvPr id="2" name="Header Placeholder 1"/><p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr><p:nvPr><p:ph type="hdr" sz="quarter"/></p:nvPr></p:nvSpPr><p:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="2971800" cy="458788"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></p:spPr><p:txBody><a:bodyPr vert="horz" lIns="91440" tIns="45720" rIns="91440" bIns="45720" rtlCol="0"/><a:lstStyle><a:lvl1pPr algn="l"><a:defRPr sz="1200"/></a:lvl1pPr></a:lstStyle><a:p><a:endParaRPr lang="en-US"/></a:p></p:txBody></p:sp><p:sp><p:nvSpPr><p:cNvPr id="3" name="Date Placeholder 2"/><p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr><p:nvPr><p:ph type="dt" idx="1"/></p:nvPr></p:nvSpPr><p:spPr><a:xfrm><a:off x="3884613" y="0"/><a:ext cx="2971800" cy="458788"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></p:spPr><p:txBody><a:bodyPr vert="horz" lIns="91440" tIns="45720" rIns="91440" bIns="45720" rtlCol="0"/><a:lstStyle><a:lvl1pPr algn="r"><a:defRPr sz="1200"/></a:lvl1pPr></a:lstStyle><a:p><a:fld id="{5282F153-3F37-0F45-9E97-73ACFA13230C}" type="datetimeFigureOut"><a:rPr lang="en-US"/><a:t>7/23/19</a:t></a:fld><a:endParaRPr lang="en-US"/></a:p></p:txBody></p:sp><p:sp><p:nvSpPr><p:cNvPr id="4" name="Slide Image Placeholder 3"/><p:cNvSpPr><a:spLocks noGrp="1" noRot="1" noChangeAspect="1"/></p:cNvSpPr><p:nvPr><p:ph type="sldImg" idx="2"/></p:nvPr></p:nvSpPr><p:spPr><a:xfrm><a:off x="685800" y="1143000"/><a:ext cx="5486400" cy="3086100"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom><a:noFill/><a:ln w="12700"><a:solidFill><a:prstClr val="black"/></a:solidFill></a:ln></p:spPr><p:txBody><a:bodyPr vert="horz" lIns="91440" tIns="45720" rIns="91440" bIns="45720" rtlCol="0" anchor="ctr"/><a:lstStyle/><a:p><a:endParaRPr lang="en-US"/></a:p></p:txBody></p:sp><p:sp><p:nvSpPr><p:cNvPr id="5" name="Notes Placeholder 4"/><p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr><p:nvPr><p:ph type="body" sz="quarter" idx="3"/></p:nvPr></p:nvSpPr><p:spPr><a:xfrm><a:off x="685800" y="4400550"/><a:ext cx="5486400" cy="3600450"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></p:spPr><p:txBody><a:bodyPr vert="horz" lIns="91440" tIns="45720" rIns="91440" bIns="45720" rtlCol="0"/><a:lstStyle/><a:p><a:pPr lvl="0"/><a:r><a:rPr lang="en-US"/><a:t>Click to edit Master text styles</a:t></a:r></a:p><a:p><a:pPr lvl="1"/><a:r><a:rPr lang="en-US"/><a:t>Second level</a:t></a:r></a:p><a:p><a:pPr lvl="2"/><a:r><a:rPr lang="en-US"/><a:t>Third level</a:t></a:r></a:p><a:p><a:pPr lvl="3"/><a:r><a:rPr lang="en-US"/><a:t>Fourth level</a:t></a:r></a:p><a:p><a:pPr lvl="4"/><a:r><a:rPr lang="en-US"/><a:t>Fifth level</a:t></a:r></a:p></p:txBody></p:sp><p:sp><p:nvSpPr><p:cNvPr id="6" name="Footer Placeholder 5"/><p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr><p:nvPr><p:ph type="ftr" sz="quarter" idx="4"/></p:nvPr></p:nvSpPr><p:spPr><a:xfrm><a:off x="0" y="8685213"/><a:ext cx="2971800" cy="458787"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></p:spPr><p:txBody><a:bodyPr vert="horz" lIns="91440" tIns="45720" rIns="91440" bIns="45720" rtlCol="0" anchor="b"/><a:lstStyle><a:lvl1pPr algn="l"><a:defRPr sz="1200"/></a:lvl1pPr></a:lstStyle><a:p><a:endParaRPr lang="en-US"/></a:p></p:txBody></p:sp><p:sp><p:nvSpPr><p:cNvPr id="7" name="Slide Number Placeholder 6"/><p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr><p:nvPr><p:ph type="sldNum" sz="quarter" idx="5"/></p:nvPr></p:nvSpPr><p:spPr><a:xfrm><a:off x="3884613" y="8685213"/><a:ext cx="2971800" cy="458787"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></p:spPr><p:txBody><a:bodyPr vert="horz" lIns="91440" tIns="45720" rIns="91440" bIns="45720" rtlCol="0" anchor="b"/><a:lstStyle><a:lvl1pPr algn="r"><a:defRPr sz="1200"/></a:lvl1pPr></a:lstStyle><a:p><a:fld id="{CE5E9CC1-C706-0F49-92D6-E571CC5EEA8F}" type="slidenum"><a:rPr lang="en-US"/><a:t>‹#›</a:t></a:fld><a:endParaRPr lang="en-US"/></a:p></p:txBody></p:sp></p:spTree><p:extLst><p:ext uri="{BB962C8B-B14F-4D97-AF65-F5344CB8AC3E}"><p14:creationId xmlns:p14="http://schemas.microsoft.com/office/powerpoint/2010/main" val="1024086991"/></p:ext></p:extLst></p:cSld><p:clrMap bg1="lt1" tx1="dk1" bg2="lt2" tx2="dk2" accent1="accent1" accent2="accent2" accent3="accent3" accent4="accent4" accent5="accent5" accent6="accent6" hlink="hlink" folHlink="folHlink"/><p:notesStyle><a:lvl1pPr marL="0" algn="l" defTabSz="914400" rtl="0" eaLnBrk="1" latinLnBrk="0" hangingPunct="1"><a:defRPr sz="1200" kern="1200"><a:solidFill><a:schemeClr val="tx1"/></a:solidFill><a:latin typeface="+mn-lt"/><a:ea typeface="+mn-ea"/><a:cs typeface="+mn-cs"/></a:defRPr></a:lvl1pPr><a:lvl2pPr marL="457200" algn="l" defTabSz="914400" rtl="0" eaLnBrk="1" latinLnBrk="0" hangingPunct="1"><a:defRPr sz="1200" kern="1200"><a:solidFill><a:schemeClr val="tx1"/></a:solidFill><a:latin typeface="+mn-lt"/><a:ea typeface="+mn-ea"/><a:cs typeface="+mn-cs"/></a:defRPr></a:lvl2pPr><a:lvl3pPr marL="914400" algn="l" defTabSz="914400" rtl="0" eaLnBrk="1" latinLnBrk="0" hangingPunct="1"><a:defRPr sz="1200" kern="1200"><a:solidFill><a:schemeClr val="tx1"/></a:solidFill><a:latin typeface="+mn-lt"/><a:ea typeface="+mn-ea"/><a:cs typeface="+mn-cs"/></a:defRPr></a:lvl3pPr><a:lvl4pPr marL="1371600" algn="l" defTabSz="914400" rtl="0" eaLnBrk="1" latinLnBrk="0" hangingPunct="1"><a:defRPr sz="1200" kern="1200"><a:solidFill><a:schemeClr val="tx1"/></a:solidFill><a:latin typeface="+mn-lt"/><a:ea typeface="+mn-ea"/><a:cs typeface="+mn-cs"/></a:defRPr></a:lvl4pPr><a:lvl5pPr marL="1828800" algn="l" defTabSz="914400" rtl="0" eaLnBrk="1" latinLnBrk="0" hangingPunct="1"><a:defRPr sz="1200" kern="1200"><a:solidFill><a:schemeClr val="tx1"/></a:solidFill><a:latin typeface="+mn-lt"/><a:ea typeface="+mn-ea"/><a:cs typeface="+mn-cs"/></a:defRPr></a:lvl5pPr><a:lvl6pPr marL="2286000" algn="l" defTabSz="914400" rtl="0" eaLnBrk="1" latinLnBrk="0" hangingPunct="1"><a:defRPr sz="1200" kern="1200"><a:solidFill><a:schemeClr val="tx1"/></a:solidFill><a:latin typeface="+mn-lt"/><a:ea typeface="+mn-ea"/><a:cs typeface="+mn-cs"/></a:defRPr></a:lvl6pPr><a:lvl7pPr marL="2743200" algn="l" defTabSz="914400" rtl="0" eaLnBrk="1" latinLnBrk="0" hangingPunct="1"><a:defRPr sz="1200" kern="1200"><a:solidFill><a:schemeClr val="tx1"/></a:solidFill><a:latin typeface="+mn-lt"/><a:ea typeface="+mn-ea"/><a:cs typeface="+mn-cs"/></a:defRPr></a:lvl7pPr><a:lvl8pPr marL="3200400" algn="l" defTabSz="914400" rtl="0" eaLnBrk="1" latinLnBrk="0" hangingPunct="1"><a:defRPr sz="1200" kern="1200"><a:solidFill><a:schemeClr val="tx1"/></a:solidFill><a:latin typeface="+mn-lt"/><a:ea typeface="+mn-ea"/><a:cs typeface="+mn-cs"/></a:defRPr></a:lvl8pPr><a:lvl9pPr marL="3657600" algn="l" defTabSz="914400" rtl="0" eaLnBrk="1" latinLnBrk="0" hangingPunct="1"><a:defRPr sz="1200" kern="1200"><a:solidFill><a:schemeClr val="tx1"/></a:solidFill><a:latin typeface="+mn-lt"/><a:ea typeface="+mn-ea"/><a:cs typeface="+mn-cs"/></a:defRPr></a:lvl9pPr></p:notesStyle></p:notesMaster>`;
}
function Sa(e) {
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>${be}<p:notes xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"><p:cSld><p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr><p:sp><p:nvSpPr><p:cNvPr id="2" name="Slide Image Placeholder 1"/><p:cNvSpPr><a:spLocks noGrp="1" noRot="1" noChangeAspect="1"/></p:cNvSpPr><p:nvPr><p:ph type="sldImg"/></p:nvPr></p:nvSpPr><p:spPr/></p:sp><p:sp><p:nvSpPr><p:cNvPr id="3" name="Notes Placeholder 2"/><p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr><p:nvPr><p:ph type="body" idx="1"/></p:nvPr></p:nvSpPr><p:spPr/><p:txBody><a:bodyPr/><a:lstStyle/><a:p><a:r><a:rPr lang="en-US" dirty="0"/><a:t>${re(Ta(e))}</a:t></a:r><a:endParaRPr lang="en-US" dirty="0"/></a:p></p:txBody></p:sp><p:sp><p:nvSpPr><p:cNvPr id="4" name="Slide Number Placeholder 3"/><p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr><p:nvPr><p:ph type="sldNum" sz="quarter" idx="10"/></p:nvPr></p:nvSpPr><p:spPr/><p:txBody><a:bodyPr/><a:lstStyle/><a:p><a:fld id="${Vt}" type="slidenum"><a:rPr lang="en-US"/><a:t>${e._slideNum}</a:t></a:fld><a:endParaRPr lang="en-US"/></a:p></p:txBody></p:sp></p:spTree><p:extLst><p:ext uri="{BB962C8B-B14F-4D97-AF65-F5344CB8AC3E}"><p14:creationId xmlns:p14="http://schemas.microsoft.com/office/powerpoint/2010/main" val="1024086991"/></p:ext></p:extLst></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:notes>`;
}
function Ia(e) {
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
		<p:sldLayout xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main" preserve="1">
		${Ft(e)}
		<p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sldLayout>`;
}
function Ma(e, A) {
  const t = A.map(
    (n, s) =>
      `<p:sldLayoutId id="${ra + s}" r:id="rId${e._rels.length + s + 1}"/>`,
  );
  let o = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' + be;
  return (
    (o +=
      '<p:sldMaster xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main">'),
    (o += Ft(e)),
    (o +=
      '<p:clrMap bg1="lt1" tx1="dk1" bg2="lt2" tx2="dk2" accent1="accent1" accent2="accent2" accent3="accent3" accent4="accent4" accent5="accent5" accent6="accent6" hlink="hlink" folHlink="folHlink"/>'),
    (o += "<p:sldLayoutIdLst>" + t.join("") + "</p:sldLayoutIdLst>"),
    (o += '<p:hf sldNum="0" hdr="0" ftr="0" dt="0"/>'),
    (o +=
      '<p:txStyles> <p:titleStyle>  <a:lvl1pPr algn="ctr" defTabSz="914400" rtl="0" eaLnBrk="1" latinLnBrk="0" hangingPunct="1"><a:spcBef><a:spcPct val="0"/></a:spcBef><a:buNone/><a:defRPr sz="4400" kern="1200"><a:solidFill><a:schemeClr val="tx1"/></a:solidFill><a:latin typeface="+mj-lt"/><a:ea typeface="+mj-ea"/><a:cs typeface="+mj-cs"/></a:defRPr></a:lvl1pPr> </p:titleStyle> <p:bodyStyle>  <a:lvl1pPr marL="342900" indent="-342900" algn="l" defTabSz="914400" rtl="0" eaLnBrk="1" latinLnBrk="0" hangingPunct="1"><a:spcBef><a:spcPct val="20000"/></a:spcBef><a:buFont typeface="Arial" pitchFamily="34" charset="0"/><a:buChar char="•"/><a:defRPr sz="3200" kern="1200"><a:solidFill><a:schemeClr val="tx1"/></a:solidFill><a:latin typeface="+mn-lt"/><a:ea typeface="+mn-ea"/><a:cs typeface="+mn-cs"/></a:defRPr></a:lvl1pPr>  <a:lvl2pPr marL="742950" indent="-285750" algn="l" defTabSz="914400" rtl="0" eaLnBrk="1" latinLnBrk="0" hangingPunct="1"><a:spcBef><a:spcPct val="20000"/></a:spcBef><a:buFont typeface="Arial" pitchFamily="34" charset="0"/><a:buChar char="–"/><a:defRPr sz="2800" kern="1200"><a:solidFill><a:schemeClr val="tx1"/></a:solidFill><a:latin typeface="+mn-lt"/><a:ea typeface="+mn-ea"/><a:cs typeface="+mn-cs"/></a:defRPr></a:lvl2pPr>  <a:lvl3pPr marL="1143000" indent="-228600" algn="l" defTabSz="914400" rtl="0" eaLnBrk="1" latinLnBrk="0" hangingPunct="1"><a:spcBef><a:spcPct val="20000"/></a:spcBef><a:buFont typeface="Arial" pitchFamily="34" charset="0"/><a:buChar char="•"/><a:defRPr sz="2400" kern="1200"><a:solidFill><a:schemeClr val="tx1"/></a:solidFill><a:latin typeface="+mn-lt"/><a:ea typeface="+mn-ea"/><a:cs typeface="+mn-cs"/></a:defRPr></a:lvl3pPr>  <a:lvl4pPr marL="1600200" indent="-228600" algn="l" defTabSz="914400" rtl="0" eaLnBrk="1" latinLnBrk="0" hangingPunct="1"><a:spcBef><a:spcPct val="20000"/></a:spcBef><a:buFont typeface="Arial" pitchFamily="34" charset="0"/><a:buChar char="–"/><a:defRPr sz="2000" kern="1200"><a:solidFill><a:schemeClr val="tx1"/></a:solidFill><a:latin typeface="+mn-lt"/><a:ea typeface="+mn-ea"/><a:cs typeface="+mn-cs"/></a:defRPr></a:lvl4pPr>  <a:lvl5pPr marL="2057400" indent="-228600" algn="l" defTabSz="914400" rtl="0" eaLnBrk="1" latinLnBrk="0" hangingPunct="1"><a:spcBef><a:spcPct val="20000"/></a:spcBef><a:buFont typeface="Arial" pitchFamily="34" charset="0"/><a:buChar char="»"/><a:defRPr sz="2000" kern="1200"><a:solidFill><a:schemeClr val="tx1"/></a:solidFill><a:latin typeface="+mn-lt"/><a:ea typeface="+mn-ea"/><a:cs typeface="+mn-cs"/></a:defRPr></a:lvl5pPr>  <a:lvl6pPr marL="2514600" indent="-228600" algn="l" defTabSz="914400" rtl="0" eaLnBrk="1" latinLnBrk="0" hangingPunct="1"><a:spcBef><a:spcPct val="20000"/></a:spcBef><a:buFont typeface="Arial" pitchFamily="34" charset="0"/><a:buChar char="•"/><a:defRPr sz="2000" kern="1200"><a:solidFill><a:schemeClr val="tx1"/></a:solidFill><a:latin typeface="+mn-lt"/><a:ea typeface="+mn-ea"/><a:cs typeface="+mn-cs"/></a:defRPr></a:lvl6pPr>  <a:lvl7pPr marL="2971800" indent="-228600" algn="l" defTabSz="914400" rtl="0" eaLnBrk="1" latinLnBrk="0" hangingPunct="1"><a:spcBef><a:spcPct val="20000"/></a:spcBef><a:buFont typeface="Arial" pitchFamily="34" charset="0"/><a:buChar char="•"/><a:defRPr sz="2000" kern="1200"><a:solidFill><a:schemeClr val="tx1"/></a:solidFill><a:latin typeface="+mn-lt"/><a:ea typeface="+mn-ea"/><a:cs typeface="+mn-cs"/></a:defRPr></a:lvl7pPr>  <a:lvl8pPr marL="3429000" indent="-228600" algn="l" defTabSz="914400" rtl="0" eaLnBrk="1" latinLnBrk="0" hangingPunct="1"><a:spcBef><a:spcPct val="20000"/></a:spcBef><a:buFont typeface="Arial" pitchFamily="34" charset="0"/><a:buChar char="•"/><a:defRPr sz="2000" kern="1200"><a:solidFill><a:schemeClr val="tx1"/></a:solidFill><a:latin typeface="+mn-lt"/><a:ea typeface="+mn-ea"/><a:cs typeface="+mn-cs"/></a:defRPr></a:lvl8pPr>  <a:lvl9pPr marL="3886200" indent="-228600" algn="l" defTabSz="914400" rtl="0" eaLnBrk="1" latinLnBrk="0" hangingPunct="1"><a:spcBef><a:spcPct val="20000"/></a:spcBef><a:buFont typeface="Arial" pitchFamily="34" charset="0"/><a:buChar char="•"/><a:defRPr sz="2000" kern="1200"><a:solidFill><a:schemeClr val="tx1"/></a:solidFill><a:latin typeface="+mn-lt"/><a:ea typeface="+mn-ea"/><a:cs typeface="+mn-cs"/></a:defRPr></a:lvl9pPr> </p:bodyStyle> <p:otherStyle>  <a:defPPr><a:defRPr lang="en-US"/></a:defPPr>  <a:lvl1pPr marL="0" algn="l" defTabSz="914400" rtl="0" eaLnBrk="1" latinLnBrk="0" hangingPunct="1"><a:defRPr sz="1800" kern="1200"><a:solidFill><a:schemeClr val="tx1"/></a:solidFill><a:latin typeface="+mn-lt"/><a:ea typeface="+mn-ea"/><a:cs typeface="+mn-cs"/></a:defRPr></a:lvl1pPr>  <a:lvl2pPr marL="457200" algn="l" defTabSz="914400" rtl="0" eaLnBrk="1" latinLnBrk="0" hangingPunct="1"><a:defRPr sz="1800" kern="1200"><a:solidFill><a:schemeClr val="tx1"/></a:solidFill><a:latin typeface="+mn-lt"/><a:ea typeface="+mn-ea"/><a:cs typeface="+mn-cs"/></a:defRPr></a:lvl2pPr>  <a:lvl3pPr marL="914400" algn="l" defTabSz="914400" rtl="0" eaLnBrk="1" latinLnBrk="0" hangingPunct="1"><a:defRPr sz="1800" kern="1200"><a:solidFill><a:schemeClr val="tx1"/></a:solidFill><a:latin typeface="+mn-lt"/><a:ea typeface="+mn-ea"/><a:cs typeface="+mn-cs"/></a:defRPr></a:lvl3pPr>  <a:lvl4pPr marL="1371600" algn="l" defTabSz="914400" rtl="0" eaLnBrk="1" latinLnBrk="0" hangingPunct="1"><a:defRPr sz="1800" kern="1200"><a:solidFill><a:schemeClr val="tx1"/></a:solidFill><a:latin typeface="+mn-lt"/><a:ea typeface="+mn-ea"/><a:cs typeface="+mn-cs"/></a:defRPr></a:lvl4pPr>  <a:lvl5pPr marL="1828800" algn="l" defTabSz="914400" rtl="0" eaLnBrk="1" latinLnBrk="0" hangingPunct="1"><a:defRPr sz="1800" kern="1200"><a:solidFill><a:schemeClr val="tx1"/></a:solidFill><a:latin typeface="+mn-lt"/><a:ea typeface="+mn-ea"/><a:cs typeface="+mn-cs"/></a:defRPr></a:lvl5pPr>  <a:lvl6pPr marL="2286000" algn="l" defTabSz="914400" rtl="0" eaLnBrk="1" latinLnBrk="0" hangingPunct="1"><a:defRPr sz="1800" kern="1200"><a:solidFill><a:schemeClr val="tx1"/></a:solidFill><a:latin typeface="+mn-lt"/><a:ea typeface="+mn-ea"/><a:cs typeface="+mn-cs"/></a:defRPr></a:lvl6pPr>  <a:lvl7pPr marL="2743200" algn="l" defTabSz="914400" rtl="0" eaLnBrk="1" latinLnBrk="0" hangingPunct="1"><a:defRPr sz="1800" kern="1200"><a:solidFill><a:schemeClr val="tx1"/></a:solidFill><a:latin typeface="+mn-lt"/><a:ea typeface="+mn-ea"/><a:cs typeface="+mn-cs"/></a:defRPr></a:lvl7pPr>  <a:lvl8pPr marL="3200400" algn="l" defTabSz="914400" rtl="0" eaLnBrk="1" latinLnBrk="0" hangingPunct="1"><a:defRPr sz="1800" kern="1200"><a:solidFill><a:schemeClr val="tx1"/></a:solidFill><a:latin typeface="+mn-lt"/><a:ea typeface="+mn-ea"/><a:cs typeface="+mn-cs"/></a:defRPr></a:lvl8pPr>  <a:lvl9pPr marL="3657600" algn="l" defTabSz="914400" rtl="0" eaLnBrk="1" latinLnBrk="0" hangingPunct="1"><a:defRPr sz="1800" kern="1200"><a:solidFill><a:schemeClr val="tx1"/></a:solidFill><a:latin typeface="+mn-lt"/><a:ea typeface="+mn-ea"/><a:cs typeface="+mn-cs"/></a:defRPr></a:lvl9pPr> </p:otherStyle></p:txStyles>'),
    (o += "</p:sldMaster>"),
    o
  );
}
function Ea(e, A) {
  return Tt(A[e - 1], [
    {
      target: "../slideMasters/slideMaster1.xml",
      type: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideMaster",
    },
  ]);
}
function za(e, A, t) {
  return Tt(e[t - 1], [
    {
      target: `../slideLayouts/slideLayout${Qa(e, A, t)}.xml`,
      type: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideLayout",
    },
    {
      target: `../notesSlides/notesSlide${t}.xml`,
      type: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/notesSlide",
    },
  ]);
}
function Ua(e) {
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
		<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
			<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/notesMaster" Target="../notesMasters/notesMaster1.xml"/>
			<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide" Target="../slides/slide${e}.xml"/>
		</Relationships>`;
}
function Xa(e, A) {
  const t = A.map((o, n) => ({
    target: `../slideLayouts/slideLayout${n + 1}.xml`,
    type: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideLayout",
  }));
  return (
    t.push({
      target: "../theme/theme1.xml",
      type: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/theme",
    }),
    Tt(e, t)
  );
}
function Ga() {
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>${be}<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
		<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/theme" Target="../theme/theme1.xml"/>
		</Relationships>`;
}
function Qa(e, A, t) {
  for (let o = 0; o < A.length; o++)
    if (A[o]._name === e[t - 1]._slideLayout._name) return o + 1;
  return 1;
}
function Oa(e) {
  var A, t, o, n;
  const s =
      !((A = e.theme) === null || A === void 0) && A.headFontFace
        ? `<a:latin typeface="${(t = e.theme) === null || t === void 0 ? void 0 : t.headFontFace}"/>`
        : '<a:latin typeface="Calibri Light" panose="020F0302020204030204"/>',
    l =
      !((o = e.theme) === null || o === void 0) && o.bodyFontFace
        ? `<a:latin typeface="${(n = e.theme) === null || n === void 0 ? void 0 : n.bodyFontFace}"/>`
        : '<a:latin typeface="Calibri" panose="020F0502020204030204"/>';
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><a:theme xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" name="Office Theme"><a:themeElements><a:clrScheme name="Office"><a:dk1><a:sysClr val="windowText" lastClr="000000"/></a:dk1><a:lt1><a:sysClr val="window" lastClr="FFFFFF"/></a:lt1><a:dk2><a:srgbClr val="44546A"/></a:dk2><a:lt2><a:srgbClr val="E7E6E6"/></a:lt2><a:accent1><a:srgbClr val="4472C4"/></a:accent1><a:accent2><a:srgbClr val="ED7D31"/></a:accent2><a:accent3><a:srgbClr val="A5A5A5"/></a:accent3><a:accent4><a:srgbClr val="FFC000"/></a:accent4><a:accent5><a:srgbClr val="5B9BD5"/></a:accent5><a:accent6><a:srgbClr val="70AD47"/></a:accent6><a:hlink><a:srgbClr val="0563C1"/></a:hlink><a:folHlink><a:srgbClr val="954F72"/></a:folHlink></a:clrScheme><a:fontScheme name="Office"><a:majorFont>${s}<a:ea typeface=""/><a:cs typeface=""/><a:font script="Jpan" typeface="游ゴシック Light"/><a:font script="Hang" typeface="맑은 고딕"/><a:font script="Hans" typeface="等线 Light"/><a:font script="Hant" typeface="新細明體"/><a:font script="Arab" typeface="Times New Roman"/><a:font script="Hebr" typeface="Times New Roman"/><a:font script="Thai" typeface="Angsana New"/><a:font script="Ethi" typeface="Nyala"/><a:font script="Beng" typeface="Vrinda"/><a:font script="Gujr" typeface="Shruti"/><a:font script="Khmr" typeface="MoolBoran"/><a:font script="Knda" typeface="Tunga"/><a:font script="Guru" typeface="Raavi"/><a:font script="Cans" typeface="Euphemia"/><a:font script="Cher" typeface="Plantagenet Cherokee"/><a:font script="Yiii" typeface="Microsoft Yi Baiti"/><a:font script="Tibt" typeface="Microsoft Himalaya"/><a:font script="Thaa" typeface="MV Boli"/><a:font script="Deva" typeface="Mangal"/><a:font script="Telu" typeface="Gautami"/><a:font script="Taml" typeface="Latha"/><a:font script="Syrc" typeface="Estrangelo Edessa"/><a:font script="Orya" typeface="Kalinga"/><a:font script="Mlym" typeface="Kartika"/><a:font script="Laoo" typeface="DokChampa"/><a:font script="Sinh" typeface="Iskoola Pota"/><a:font script="Mong" typeface="Mongolian Baiti"/><a:font script="Viet" typeface="Times New Roman"/><a:font script="Uigh" typeface="Microsoft Uighur"/><a:font script="Geor" typeface="Sylfaen"/><a:font script="Armn" typeface="Arial"/><a:font script="Bugi" typeface="Leelawadee UI"/><a:font script="Bopo" typeface="Microsoft JhengHei"/><a:font script="Java" typeface="Javanese Text"/><a:font script="Lisu" typeface="Segoe UI"/><a:font script="Mymr" typeface="Myanmar Text"/><a:font script="Nkoo" typeface="Ebrima"/><a:font script="Olck" typeface="Nirmala UI"/><a:font script="Osma" typeface="Ebrima"/><a:font script="Phag" typeface="Phagspa"/><a:font script="Syrn" typeface="Estrangelo Edessa"/><a:font script="Syrj" typeface="Estrangelo Edessa"/><a:font script="Syre" typeface="Estrangelo Edessa"/><a:font script="Sora" typeface="Nirmala UI"/><a:font script="Tale" typeface="Microsoft Tai Le"/><a:font script="Talu" typeface="Microsoft New Tai Lue"/><a:font script="Tfng" typeface="Ebrima"/></a:majorFont><a:minorFont>${l}<a:ea typeface=""/><a:cs typeface=""/><a:font script="Jpan" typeface="游ゴシック"/><a:font script="Hang" typeface="맑은 고딕"/><a:font script="Hans" typeface="等线"/><a:font script="Hant" typeface="新細明體"/><a:font script="Arab" typeface="Arial"/><a:font script="Hebr" typeface="Arial"/><a:font script="Thai" typeface="Cordia New"/><a:font script="Ethi" typeface="Nyala"/><a:font script="Beng" typeface="Vrinda"/><a:font script="Gujr" typeface="Shruti"/><a:font script="Khmr" typeface="DaunPenh"/><a:font script="Knda" typeface="Tunga"/><a:font script="Guru" typeface="Raavi"/><a:font script="Cans" typeface="Euphemia"/><a:font script="Cher" typeface="Plantagenet Cherokee"/><a:font script="Yiii" typeface="Microsoft Yi Baiti"/><a:font script="Tibt" typeface="Microsoft Himalaya"/><a:font script="Thaa" typeface="MV Boli"/><a:font script="Deva" typeface="Mangal"/><a:font script="Telu" typeface="Gautami"/><a:font script="Taml" typeface="Latha"/><a:font script="Syrc" typeface="Estrangelo Edessa"/><a:font script="Orya" typeface="Kalinga"/><a:font script="Mlym" typeface="Kartika"/><a:font script="Laoo" typeface="DokChampa"/><a:font script="Sinh" typeface="Iskoola Pota"/><a:font script="Mong" typeface="Mongolian Baiti"/><a:font script="Viet" typeface="Arial"/><a:font script="Uigh" typeface="Microsoft Uighur"/><a:font script="Geor" typeface="Sylfaen"/><a:font script="Armn" typeface="Arial"/><a:font script="Bugi" typeface="Leelawadee UI"/><a:font script="Bopo" typeface="Microsoft JhengHei"/><a:font script="Java" typeface="Javanese Text"/><a:font script="Lisu" typeface="Segoe UI"/><a:font script="Mymr" typeface="Myanmar Text"/><a:font script="Nkoo" typeface="Ebrima"/><a:font script="Olck" typeface="Nirmala UI"/><a:font script="Osma" typeface="Ebrima"/><a:font script="Phag" typeface="Phagspa"/><a:font script="Syrn" typeface="Estrangelo Edessa"/><a:font script="Syrj" typeface="Estrangelo Edessa"/><a:font script="Syre" typeface="Estrangelo Edessa"/><a:font script="Sora" typeface="Nirmala UI"/><a:font script="Tale" typeface="Microsoft Tai Le"/><a:font script="Talu" typeface="Microsoft New Tai Lue"/><a:font script="Tfng" typeface="Ebrima"/></a:minorFont></a:fontScheme><a:fmtScheme name="Office"><a:fillStyleLst><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:gradFill rotWithShape="1"><a:gsLst><a:gs pos="0"><a:schemeClr val="phClr"><a:lumMod val="110000"/><a:satMod val="105000"/><a:tint val="67000"/></a:schemeClr></a:gs><a:gs pos="50000"><a:schemeClr val="phClr"><a:lumMod val="105000"/><a:satMod val="103000"/><a:tint val="73000"/></a:schemeClr></a:gs><a:gs pos="100000"><a:schemeClr val="phClr"><a:lumMod val="105000"/><a:satMod val="109000"/><a:tint val="81000"/></a:schemeClr></a:gs></a:gsLst><a:lin ang="5400000" scaled="0"/></a:gradFill><a:gradFill rotWithShape="1"><a:gsLst><a:gs pos="0"><a:schemeClr val="phClr"><a:satMod val="103000"/><a:lumMod val="102000"/><a:tint val="94000"/></a:schemeClr></a:gs><a:gs pos="50000"><a:schemeClr val="phClr"><a:satMod val="110000"/><a:lumMod val="100000"/><a:shade val="100000"/></a:schemeClr></a:gs><a:gs pos="100000"><a:schemeClr val="phClr"><a:lumMod val="99000"/><a:satMod val="120000"/><a:shade val="78000"/></a:schemeClr></a:gs></a:gsLst><a:lin ang="5400000" scaled="0"/></a:gradFill></a:fillStyleLst><a:lnStyleLst><a:ln w="6350" cap="flat" cmpd="sng" algn="ctr"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:prstDash val="solid"/><a:miter lim="800000"/></a:ln><a:ln w="12700" cap="flat" cmpd="sng" algn="ctr"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:prstDash val="solid"/><a:miter lim="800000"/></a:ln><a:ln w="19050" cap="flat" cmpd="sng" algn="ctr"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:prstDash val="solid"/><a:miter lim="800000"/></a:ln></a:lnStyleLst><a:effectStyleLst><a:effectStyle><a:effectLst/></a:effectStyle><a:effectStyle><a:effectLst/></a:effectStyle><a:effectStyle><a:effectLst><a:outerShdw blurRad="57150" dist="19050" dir="5400000" algn="ctr" rotWithShape="0"><a:srgbClr val="000000"><a:alpha val="63000"/></a:srgbClr></a:outerShdw></a:effectLst></a:effectStyle></a:effectStyleLst><a:bgFillStyleLst><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:solidFill><a:schemeClr val="phClr"><a:tint val="95000"/><a:satMod val="170000"/></a:schemeClr></a:solidFill><a:gradFill rotWithShape="1"><a:gsLst><a:gs pos="0"><a:schemeClr val="phClr"><a:tint val="93000"/><a:satMod val="150000"/><a:shade val="98000"/><a:lumMod val="102000"/></a:schemeClr></a:gs><a:gs pos="50000"><a:schemeClr val="phClr"><a:tint val="98000"/><a:satMod val="130000"/><a:shade val="90000"/><a:lumMod val="103000"/></a:schemeClr></a:gs><a:gs pos="100000"><a:schemeClr val="phClr"><a:shade val="63000"/><a:satMod val="120000"/></a:schemeClr></a:gs></a:gsLst><a:lin ang="5400000" scaled="0"/></a:gradFill></a:bgFillStyleLst></a:fmtScheme></a:themeElements><a:objectDefaults/><a:extraClrSchemeLst/><a:extLst><a:ext uri="{05A4C25C-085E-4340-85A3-A5531E510DB2}"><thm15:themeFamily xmlns:thm15="http://schemas.microsoft.com/office/thememl/2012/main" name="Office Theme" id="{62F939B6-93AF-4DB8-9C6B-D6C7DFDC589F}" vid="{4A3C46E8-61CC-4603-A589-7422A47A8E4A}"/></a:ext></a:extLst></a:theme>`;
}
function Wa(e) {
  let A = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>${be}<p:presentation xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main" ${e.rtlMode ? 'rtl="1"' : ""} saveSubsetFonts="1" autoCompressPictures="0">`;
  ((A +=
    '<p:sldMasterIdLst><p:sldMasterId id="2147483648" r:id="rId1"/></p:sldMasterIdLst>'),
    (A += "<p:sldIdLst>"),
    e.slides.forEach(
      (t) => (A += `<p:sldId id="${t._slideId}" r:id="rId${t._rId}"/>`),
    ),
    (A += "</p:sldIdLst>"),
    (A += `<p:notesMasterIdLst><p:notesMasterId r:id="rId${e.slides.length + 2}"/></p:notesMasterIdLst>`),
    (A += `<p:sldSz cx="${e.presLayout.width}" cy="${e.presLayout.height}"/>`),
    (A += `<p:notesSz cx="${e.presLayout.height}" cy="${e.presLayout.width}"/>`),
    (A += "<p:defaultTextStyle>"));
  for (let t = 1; t < 10; t++)
    A += `<a:lvl${t}pPr marL="${(t - 1) * 457200}" algn="l" defTabSz="914400" rtl="0" eaLnBrk="1" latinLnBrk="0" hangingPunct="1"><a:defRPr sz="1800" kern="1200"><a:solidFill><a:schemeClr val="tx1"/></a:solidFill><a:latin typeface="+mn-lt"/><a:ea typeface="+mn-ea"/><a:cs typeface="+mn-cs"/></a:defRPr></a:lvl${t}pPr>`;
  return (
    (A += "</p:defaultTextStyle>"),
    e.sections &&
      e.sections.length > 0 &&
      ((A += '<p:extLst><p:ext uri="{521415D9-36F7-43E2-AB2F-B90AF26B5E84}">'),
      (A +=
        '<p14:sectionLst xmlns:p14="http://schemas.microsoft.com/office/powerpoint/2010/main">'),
      e.sections.forEach((t) => {
        ((A += `<p14:section name="${re(t.title)}" id="{${ot("xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx")}}"><p14:sldIdLst>`),
          t._slides.forEach((o) => (A += `<p14:sldId id="${o._slideId}"/>`)),
          (A += "</p14:sldIdLst></p14:section>"));
      }),
      (A += "</p14:sectionLst></p:ext>"),
      (A +=
        '<p:ext uri="{EFAFB233-063F-42B5-8137-9DF3F51BA10A}"><p15:sldGuideLst xmlns:p15="http://schemas.microsoft.com/office/powerpoint/2012/main"/></p:ext>'),
      (A += "</p:extLst>")),
    (A += "</p:presentation>"),
    A
  );
}
function Va() {
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>${be}<p:presentationPr xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"/>`;
}
function qa() {
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>${be}<a:tblStyleLst xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" def="{5C22544A-7EE6-4342-B048-85BDC9FD1C3A}"/>`;
}
function Ya() {
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>${be}<p:viewPr xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"><p:normalViewPr horzBarState="maximized"><p:restoredLeft sz="15611"/><p:restoredTop sz="94610"/></p:normalViewPr><p:slideViewPr><p:cSldViewPr snapToGrid="0" snapToObjects="1"><p:cViewPr varScale="1"><p:scale><a:sx n="136" d="100"/><a:sy n="136" d="100"/></p:scale><p:origin x="216" y="312"/></p:cViewPr><p:guideLst/></p:cSldViewPr></p:slideViewPr><p:notesTextViewPr><p:cViewPr><p:scale><a:sx n="1" d="1"/><a:sy n="1" d="1"/></p:scale><p:origin x="0" y="0"/></p:cViewPr></p:notesTextViewPr><p:gridSpacing cx="76200" cy="76200"/></p:viewPr>`;
}
const Ja = "4.0.1";
class Za {
  set layout(A) {
    const t = this.LAYOUTS[A];
    if (t) ((this._layout = A), (this._presLayout = t));
    else throw new Error("UNKNOWN-LAYOUT");
  }
  get layout() {
    return this._layout;
  }
  get version() {
    return this._version;
  }
  set author(A) {
    this._author = A;
  }
  get author() {
    return this._author;
  }
  set company(A) {
    this._company = A;
  }
  get company() {
    return this._company;
  }
  set revision(A) {
    this._revision = A;
  }
  get revision() {
    return this._revision;
  }
  set subject(A) {
    this._subject = A;
  }
  get subject() {
    return this._subject;
  }
  set theme(A) {
    this._theme = A;
  }
  get theme() {
    return this._theme;
  }
  set title(A) {
    this._title = A;
  }
  get title() {
    return this._title;
  }
  set rtlMode(A) {
    this._rtlMode = A;
  }
  get rtlMode() {
    return this._rtlMode;
  }
  get masterSlide() {
    return this._masterSlide;
  }
  get slides() {
    return this._slides;
  }
  get sections() {
    return this._sections;
  }
  get slideLayouts() {
    return this._slideLayouts;
  }
  get AlignH() {
    return this._alignH;
  }
  get AlignV() {
    return this._alignV;
  }
  get ChartType() {
    return this._chartType;
  }
  get OutputType() {
    return this._outputType;
  }
  get presLayout() {
    return this._presLayout;
  }
  get SchemeColor() {
    return this._schemeColor;
  }
  get ShapeType() {
    return this._shapeType;
  }
  get charts() {
    return this._charts;
  }
  get colors() {
    return this._colors;
  }
  get shapes() {
    return this._shapes;
  }
  constructor() {
    ((this._version = Ja),
      (this._alignH = Dt),
      (this._alignV = kt),
      (this._chartType = Bt),
      (this._outputType = Ct),
      (this._schemeColor = Ce),
      (this._shapeType = Lt),
      (this._charts = W),
      (this._colors = lt),
      (this._shapes = _e),
      (this.addNewSlide = (s) => {
        const l =
          this.sections.length > 0 &&
          this.sections[this.sections.length - 1]._slides.filter(
            (c) =>
              c._slideNum === this.slides[this.slides.length - 1]._slideNum,
          ).length > 0;
        return (
          (s.sectionTitle = l
            ? this.sections[this.sections.length - 1].title
            : null),
          this.addSlide(s)
        );
      }),
      (this.getSlide = (s) => this.slides.filter((l) => l._slideNum === s)[0]),
      (this.setSlideNumber = (s) => {
        ((this.masterSlide._slideNumberProps = s),
          (this.slideLayouts.filter(
            (l) => l._name === wt,
          )[0]._slideNumberProps = s));
      }),
      (this.createChartMediaRels = (s, l, c) => {
        (s._relsChart.forEach((i) => c.push(ba(i, l))),
          s._relsMedia.forEach((i) => {
            if (i.type !== "online" && i.type !== "hyperlink") {
              let a = i.data && typeof i.data == "string" ? i.data : "";
              (!a.includes(",") && !a.includes(";")
                ? (a = "image/png;base64," + a)
                : a.includes(",")
                  ? a.includes(";") || (a = "image/png;" + a)
                  : (a = "image/png;base64," + a),
                l.file(i.Target.replace("..", "ppt"), a.split(",").pop(), {
                  base64: !0,
                }));
            }
          }));
      }),
      (this.writeFileToBrowser = (s, l) =>
        Be(this, void 0, void 0, function* () {
          const c = document.createElement("a");
          if (
            (c.setAttribute("style", "display:none;"),
            (c.dataset.interception = "off"),
            document.body.appendChild(c),
            window.URL.createObjectURL)
          ) {
            const i = window.URL.createObjectURL(
              new Blob([l], {
                type: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
              }),
            );
            return (
              (c.href = i),
              (c.download = s),
              c.click(),
              setTimeout(() => {
                (window.URL.revokeObjectURL(i), document.body.removeChild(c));
              }, 100),
              yield Promise.resolve(s)
            );
          }
        })),
      (this.exportPresentation = (s) =>
        Be(this, void 0, void 0, function* () {
          const l = [];
          let c = [];
          const i = new Gt();
          return (
            this.slides.forEach((a) => {
              c = c.concat(yt(a));
            }),
            this.slideLayouts.forEach((a) => {
              c = c.concat(yt(a));
            }),
            (c = c.concat(yt(this.masterSlide))),
            yield Promise.all(c).then(() =>
              Be(this, void 0, void 0, function* () {
                return (
                  this.slides.forEach((a) => {
                    a._slideLayout && va(a);
                  }),
                  i.folder("_rels"),
                  i.folder("docProps"),
                  i.folder("ppt").folder("_rels"),
                  i.folder("ppt/charts").folder("_rels"),
                  i.folder("ppt/embeddings"),
                  i.folder("ppt/media"),
                  i.folder("ppt/slideLayouts").folder("_rels"),
                  i.folder("ppt/slideMasters").folder("_rels"),
                  i.folder("ppt/slides").folder("_rels"),
                  i.folder("ppt/theme"),
                  i.folder("ppt/notesMasters").folder("_rels"),
                  i.folder("ppt/notesSlides").folder("_rels"),
                  i.file(
                    "[Content_Types].xml",
                    Da(this.slides, this.slideLayouts, this.masterSlide),
                  ),
                  i.file("_rels/.rels", ka()),
                  i.file("docProps/app.xml", Pa(this.slides, this.company)),
                  i.file(
                    "docProps/core.xml",
                    Na(this.title, this.subject, this.author, this.revision),
                  ),
                  i.file("ppt/_rels/presentation.xml.rels", Ra(this.slides)),
                  i.file("ppt/theme/theme1.xml", Oa(this)),
                  i.file("ppt/presentation.xml", Wa(this)),
                  i.file("ppt/presProps.xml", Va()),
                  i.file("ppt/tableStyles.xml", qa()),
                  i.file("ppt/viewProps.xml", Ya()),
                  this.slideLayouts.forEach((a, r) => {
                    (i.file(`ppt/slideLayouts/slideLayout${r + 1}.xml`, Ia(a)),
                      i.file(
                        `ppt/slideLayouts/_rels/slideLayout${r + 1}.xml.rels`,
                        Ea(r + 1, this.slideLayouts),
                      ));
                  }),
                  this.slides.forEach((a, r) => {
                    (i.file(`ppt/slides/slide${r + 1}.xml`, Fa(a)),
                      i.file(
                        `ppt/slides/_rels/slide${r + 1}.xml.rels`,
                        za(this.slides, this.slideLayouts, r + 1),
                      ),
                      i.file(`ppt/notesSlides/notesSlide${r + 1}.xml`, Sa(a)),
                      i.file(
                        `ppt/notesSlides/_rels/notesSlide${r + 1}.xml.rels`,
                        Ua(r + 1),
                      ));
                  }),
                  i.file(
                    "ppt/slideMasters/slideMaster1.xml",
                    Ma(this.masterSlide, this.slideLayouts),
                  ),
                  i.file(
                    "ppt/slideMasters/_rels/slideMaster1.xml.rels",
                    Xa(this.masterSlide, this.slideLayouts),
                  ),
                  i.file("ppt/notesMasters/notesMaster1.xml", _a()),
                  i.file("ppt/notesMasters/_rels/notesMaster1.xml.rels", Ga()),
                  this.slideLayouts.forEach((a) => {
                    this.createChartMediaRels(a, i, l);
                  }),
                  this.slides.forEach((a) => {
                    this.createChartMediaRels(a, i, l);
                  }),
                  this.createChartMediaRels(this.masterSlide, i, l),
                  yield Promise.all(l).then(() =>
                    Be(this, void 0, void 0, function* () {
                      return s.outputType === "STREAM"
                        ? yield i.generateAsync({
                            type: "nodebuffer",
                            compression: s.compression ? "DEFLATE" : "STORE",
                          })
                        : s.outputType
                          ? yield i.generateAsync({ type: s.outputType })
                          : yield i.generateAsync({
                              type: "blob",
                              compression: s.compression ? "DEFLATE" : "STORE",
                            });
                    }),
                  )
                );
              }),
            )
          );
        })));
    const A = { name: "screen4x3", width: 9144e3, height: 6858e3 },
      t = { name: "screen16x9", width: 9144e3, height: 5143500 },
      o = { name: "screen16x10", width: 9144e3, height: 5715e3 },
      n = { name: "custom", width: 12192e3, height: 6858e3 };
    ((this.LAYOUTS = {
      LAYOUT_4x3: A,
      LAYOUT_16x9: t,
      LAYOUT_16x10: o,
      LAYOUT_WIDE: n,
    }),
      (this._author = "PptxGenJS"),
      (this._company = "PptxGenJS"),
      (this._revision = "1"),
      (this._subject = "PptxGenJS Presentation"),
      (this._title = "PptxGenJS Presentation"),
      (this._presLayout = {
        name: this.LAYOUTS[Xe].name,
        _sizeW: this.LAYOUTS[Xe].width,
        _sizeH: this.LAYOUTS[Xe].height,
        width: this.LAYOUTS[Xe].width,
        height: this.LAYOUTS[Xe].height,
      }),
      (this._rtlMode = !1),
      (this._slideLayouts = [
        {
          _margin: $e,
          _name: wt,
          _presLayout: this._presLayout,
          _rels: [],
          _relsChart: [],
          _relsMedia: [],
          _slide: null,
          _slideNum: 1e3,
          _slideNumberProps: null,
          _slideObjects: [],
        },
      ]),
      (this._slides = []),
      (this._sections = []),
      (this._masterSlide = {
        addChart: null,
        addImage: null,
        addMedia: null,
        addNotes: null,
        addShape: null,
        addTable: null,
        addText: null,
        _name: null,
        _presLayout: this._presLayout,
        _rId: null,
        _rels: [],
        _relsChart: [],
        _relsMedia: [],
        _slideId: null,
        _slideLayout: null,
        _slideNum: null,
        _slideNumberProps: null,
        _slideObjects: [],
      }));
  }
  stream(A) {
    return Be(this, void 0, void 0, function* () {
      return yield this.exportPresentation({
        compression: A?.compression,
        outputType: "STREAM",
      });
    });
  }
  write(A) {
    return Be(this, void 0, void 0, function* () {
      const t =
          typeof A == "object" && A?.outputType ? A.outputType : A || null,
        o = typeof A == "object" && A?.compression ? A.compression : !1;
      return yield this.exportPresentation({ compression: o, outputType: t });
    });
  }
  writeFile(A) {
    return Be(this, void 0, void 0, function* () {
      var t, o;
      const n =
        typeof process < "u" &&
        !!(!((t = process.versions) === null || t === void 0) && t.node) &&
        ((o = process.release) === null || o === void 0 ? void 0 : o.name) ===
          "node";
      typeof A == "string" &&
        (console.warn(
          "[WARNING] writeFile(string) is deprecated - pass { fileName } instead.",
        ),
        (A = { fileName: A }));
      const { fileName: s = "Presentation.pptx", compression: l = !1 } = A,
        c = s.toLowerCase().endsWith(".pptx") ? s : `${s}.pptx`,
        i = n ? "nodebuffer" : null,
        a = yield this.exportPresentation({ compression: l, outputType: i });
      if (n) {
        const { promises: r } = yield bt(
            () => import("./__vite-browser-external-BIHI7g3E.js"),
            [],
          ),
          { writeFile: u } = r;
        return (yield u(c, a), c);
      }
      return (yield this.writeFileToBrowser(c, a), c);
    });
  }
  addSection(A) {
    A
      ? A.title || console.warn("addSection requires a title")
      : console.warn("addSection requires an argument");
    const t = { _type: "user", _slides: [], title: A.title };
    A.order ? this.sections.splice(A.order, 0, t) : this._sections.push(t);
  }
  addSlide(A) {
    const t = typeof A == "string" ? A : A?.masterName ? A.masterName : "";
    let o = {
      _name: this.LAYOUTS[Xe].name,
      _presLayout: this.presLayout,
      _rels: [],
      _relsChart: [],
      _relsMedia: [],
      _slideNum: this.slides.length + 1,
    };
    if (t) {
      const s = this.slideLayouts.filter((l) => l._name === t)[0];
      s && (o = s);
    }
    const n = new ya({
      addSlide: this.addNewSlide,
      getSlide: this.getSlide,
      presLayout: this.presLayout,
      setSlideNum: this.setSlideNumber,
      slideId: this.slides.length + 256,
      slideRId: this.slides.length + 2,
      slideNumber: this.slides.length + 1,
      slideLayout: o,
    });
    if ((this._slides.push(n), A?.sectionTitle)) {
      const s = this.sections.filter((l) => l.title === A.sectionTitle)[0];
      s
        ? s._slides.push(n)
        : console.warn(
            `addSlide: unable to find section with title: "${A.sectionTitle}"`,
          );
    } else if (this.sections && this.sections.length > 0 && !A?.sectionTitle) {
      const s = this._sections[this.sections.length - 1];
      s._type === "default"
        ? s._slides.push(n)
        : this._sections.push({
            title: `Default-${this.sections.filter((l) => l._type === "default").length + 1}`,
            _type: "default",
            _slides: [n],
          });
    }
    return n;
  }
  defineLayout(A) {
    (A
      ? A.name
        ? A.width
          ? A.height
            ? typeof A.height != "number"
              ? console.warn(
                  "defineLayout `height` should be a number (inches)",
                )
              : typeof A.width != "number" &&
                console.warn("defineLayout `width` should be a number (inches)")
            : console.warn("defineLayout requires `height`")
          : console.warn("defineLayout requires `width`")
        : console.warn("defineLayout requires `name`")
      : console.warn("defineLayout requires `{name, width, height}`"),
      (this.LAYOUTS[A.name] = {
        name: A.name,
        _sizeW: Math.round(Number(A.width) * Ae),
        _sizeH: Math.round(Number(A.height) * Ae),
        width: Math.round(Number(A.width) * Ae),
        height: Math.round(Number(A.height) * Ae),
      }));
  }
  defineSlideMaster(A) {
    const t = JSON.parse(JSON.stringify(A));
    if (!t.title)
      throw new Error(
        "defineSlideMaster() object argument requires a `title` value. (https://gitbrent.github.io/PptxGenJS/docs/masters.html)",
      );
    const o = {
      _margin: t.margin || $e,
      _name: t.title,
      _presLayout: this.presLayout,
      _rels: [],
      _relsChart: [],
      _relsMedia: [],
      _slide: null,
      _slideNum: 1e3 + this.slideLayouts.length + 1,
      _slideNumberProps: t.slideNumber || null,
      _slideObjects: [],
      background: t.background || null,
      bkgd: t.bkgd || null,
    };
    (ua(t, o),
      this.slideLayouts.push(o),
      (t.background || t.bkgd) && Ht(t.background, o),
      o._slideNumberProps &&
        !this.masterSlide._slideNumberProps &&
        (this.masterSlide._slideNumberProps = o._slideNumberProps));
  }
  tableToSlides(A, t = {}) {
    fa(
      this,
      A,
      t,
      t?.masterSlideName
        ? this.slideLayouts.filter((o) => o._name === t.masterSlideName)[0]
        : null,
    );
  }
}
export { Za as default };
