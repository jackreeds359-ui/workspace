(function () {
  const u = document.createElement("link").relList;
  if (u && u.supports && u.supports("modulepreload")) return;
  for (const p of document.querySelectorAll('link[rel="modulepreload"]')) d(p);
  new MutationObserver((p) => {
    for (const y of p)
      if (y.type === "childList")
        for (const S of y.addedNodes)
          S.tagName === "LINK" && S.rel === "modulepreload" && d(S);
  }).observe(document, { childList: !0, subtree: !0 });
  function l(p) {
    const y = {};
    return (
      p.integrity && (y.integrity = p.integrity),
      p.referrerPolicy && (y.referrerPolicy = p.referrerPolicy),
      p.crossOrigin === "use-credentials"
        ? (y.credentials = "include")
        : p.crossOrigin === "anonymous"
          ? (y.credentials = "omit")
          : (y.credentials = "same-origin"),
      y
    );
  }
  function d(p) {
    if (p.ep) return;
    p.ep = !0;
    const y = l(p);
    fetch(p.href, y);
  }
})();
function xd(s) {
  return s && s.__esModule && Object.prototype.hasOwnProperty.call(s, "default")
    ? s.default
    : s;
}
var na = { exports: {} },
  Hr = {},
  ra = { exports: {} },
  oe = {};
/**
 * @license React
 * react.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var Nc;
function Yp() {
  if (Nc) return oe;
  Nc = 1;
  var s = Symbol.for("react.element"),
    u = Symbol.for("react.portal"),
    l = Symbol.for("react.fragment"),
    d = Symbol.for("react.strict_mode"),
    p = Symbol.for("react.profiler"),
    y = Symbol.for("react.provider"),
    S = Symbol.for("react.context"),
    j = Symbol.for("react.forward_ref"),
    k = Symbol.for("react.suspense"),
    F = Symbol.for("react.memo"),
    T = Symbol.for("react.lazy"),
    V = Symbol.iterator;
  function D(g) {
    return g === null || typeof g != "object"
      ? null
      : ((g = (V && g[V]) || g["@@iterator"]),
        typeof g == "function" ? g : null);
  }
  var q = {
      isMounted: function () {
        return !1;
      },
      enqueueForceUpdate: function () {},
      enqueueReplaceState: function () {},
      enqueueSetState: function () {},
    },
    X = Object.assign,
    O = {};
  function $(g, E, Z) {
    ((this.props = g),
      (this.context = E),
      (this.refs = O),
      (this.updater = Z || q));
  }
  (($.prototype.isReactComponent = {}),
    ($.prototype.setState = function (g, E) {
      if (typeof g != "object" && typeof g != "function" && g != null)
        throw Error(
          "setState(...): takes an object of state variables to update or a function which returns an object of state variables.",
        );
      this.updater.enqueueSetState(this, g, E, "setState");
    }),
    ($.prototype.forceUpdate = function (g) {
      this.updater.enqueueForceUpdate(this, g, "forceUpdate");
    }));
  function K() {}
  K.prototype = $.prototype;
  function ae(g, E, Z) {
    ((this.props = g),
      (this.context = E),
      (this.refs = O),
      (this.updater = Z || q));
  }
  var be = (ae.prototype = new K());
  ((be.constructor = ae), X(be, $.prototype), (be.isPureReactComponent = !0));
  var ie = Array.isArray,
    Ae = Object.prototype.hasOwnProperty,
    B = { current: null },
    ee = { key: !0, ref: !0, __self: !0, __source: !0 };
  function te(g, E, Z) {
    var re,
      ue = {},
      de = null,
      ve = null;
    if (E != null)
      for (re in (E.ref !== void 0 && (ve = E.ref),
      E.key !== void 0 && (de = "" + E.key),
      E))
        Ae.call(E, re) && !ee.hasOwnProperty(re) && (ue[re] = E[re]);
    var fe = arguments.length - 2;
    if (fe === 1) ue.children = Z;
    else if (1 < fe) {
      for (var Y = Array(fe), we = 0; we < fe; we++) Y[we] = arguments[we + 2];
      ue.children = Y;
    }
    if (g && g.defaultProps)
      for (re in ((fe = g.defaultProps), fe))
        ue[re] === void 0 && (ue[re] = fe[re]);
    return {
      $$typeof: s,
      type: g,
      key: de,
      ref: ve,
      props: ue,
      _owner: B.current,
    };
  }
  function ne(g, E) {
    return {
      $$typeof: s,
      type: g.type,
      key: E,
      ref: g.ref,
      props: g.props,
      _owner: g._owner,
    };
  }
  function le(g) {
    return typeof g == "object" && g !== null && g.$$typeof === s;
  }
  function se(g) {
    var E = { "=": "=0", ":": "=2" };
    return (
      "$" +
      g.replace(/[=:]/g, function (Z) {
        return E[Z];
      })
    );
  }
  var Ee = /\/+/g;
  function he(g, E) {
    return typeof g == "object" && g !== null && g.key != null
      ? se("" + g.key)
      : E.toString(36);
  }
  function je(g, E, Z, re, ue) {
    var de = typeof g;
    (de === "undefined" || de === "boolean") && (g = null);
    var ve = !1;
    if (g === null) ve = !0;
    else
      switch (de) {
        case "string":
        case "number":
          ve = !0;
          break;
        case "object":
          switch (g.$$typeof) {
            case s:
            case u:
              ve = !0;
          }
      }
    if (ve)
      return (
        (ve = g),
        (ue = ue(ve)),
        (g = re === "" ? "." + he(ve, 0) : re),
        ie(ue)
          ? ((Z = ""),
            g != null && (Z = g.replace(Ee, "$&/") + "/"),
            je(ue, E, Z, "", function (we) {
              return we;
            }))
          : ue != null &&
            (le(ue) &&
              (ue = ne(
                ue,
                Z +
                  (!ue.key || (ve && ve.key === ue.key)
                    ? ""
                    : ("" + ue.key).replace(Ee, "$&/") + "/") +
                  g,
              )),
            E.push(ue)),
        1
      );
    if (((ve = 0), (re = re === "" ? "." : re + ":"), ie(g)))
      for (var fe = 0; fe < g.length; fe++) {
        de = g[fe];
        var Y = re + he(de, fe);
        ve += je(de, E, Z, Y, ue);
      }
    else if (((Y = D(g)), typeof Y == "function"))
      for (g = Y.call(g), fe = 0; !(de = g.next()).done;)
        ((de = de.value), (Y = re + he(de, fe++)), (ve += je(de, E, Z, Y, ue)));
    else if (de === "object")
      throw (
        (E = String(g)),
        Error(
          "Objects are not valid as a React child (found: " +
            (E === "[object Object]"
              ? "object with keys {" + Object.keys(g).join(", ") + "}"
              : E) +
            "). If you meant to render a collection of children, use an array instead.",
        )
      );
    return ve;
  }
  function Fe(g, E, Z) {
    if (g == null) return g;
    var re = [],
      ue = 0;
    return (
      je(g, re, "", "", function (de) {
        return E.call(Z, de, ue++);
      }),
      re
    );
  }
  function Le(g) {
    if (g._status === -1) {
      var E = g._result;
      ((E = E()),
        E.then(
          function (Z) {
            (g._status === 0 || g._status === -1) &&
              ((g._status = 1), (g._result = Z));
          },
          function (Z) {
            (g._status === 0 || g._status === -1) &&
              ((g._status = 2), (g._result = Z));
          },
        ),
        g._status === -1 && ((g._status = 0), (g._result = E)));
    }
    if (g._status === 1) return g._result.default;
    throw g._result;
  }
  var ye = { current: null },
    R = { transition: null },
    H = {
      ReactCurrentDispatcher: ye,
      ReactCurrentBatchConfig: R,
      ReactCurrentOwner: B,
    };
  function _() {
    throw Error("act(...) is not supported in production builds of React.");
  }
  return (
    (oe.Children = {
      map: Fe,
      forEach: function (g, E, Z) {
        Fe(
          g,
          function () {
            E.apply(this, arguments);
          },
          Z,
        );
      },
      count: function (g) {
        var E = 0;
        return (
          Fe(g, function () {
            E++;
          }),
          E
        );
      },
      toArray: function (g) {
        return (
          Fe(g, function (E) {
            return E;
          }) || []
        );
      },
      only: function (g) {
        if (!le(g))
          throw Error(
            "React.Children.only expected to receive a single React element child.",
          );
        return g;
      },
    }),
    (oe.Component = $),
    (oe.Fragment = l),
    (oe.Profiler = p),
    (oe.PureComponent = ae),
    (oe.StrictMode = d),
    (oe.Suspense = k),
    (oe.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = H),
    (oe.act = _),
    (oe.cloneElement = function (g, E, Z) {
      if (g == null)
        throw Error(
          "React.cloneElement(...): The argument must be a React element, but you passed " +
            g +
            ".",
        );
      var re = X({}, g.props),
        ue = g.key,
        de = g.ref,
        ve = g._owner;
      if (E != null) {
        if (
          (E.ref !== void 0 && ((de = E.ref), (ve = B.current)),
          E.key !== void 0 && (ue = "" + E.key),
          g.type && g.type.defaultProps)
        )
          var fe = g.type.defaultProps;
        for (Y in E)
          Ae.call(E, Y) &&
            !ee.hasOwnProperty(Y) &&
            (re[Y] = E[Y] === void 0 && fe !== void 0 ? fe[Y] : E[Y]);
      }
      var Y = arguments.length - 2;
      if (Y === 1) re.children = Z;
      else if (1 < Y) {
        fe = Array(Y);
        for (var we = 0; we < Y; we++) fe[we] = arguments[we + 2];
        re.children = fe;
      }
      return {
        $$typeof: s,
        type: g.type,
        key: ue,
        ref: de,
        props: re,
        _owner: ve,
      };
    }),
    (oe.createContext = function (g) {
      return (
        (g = {
          $$typeof: S,
          _currentValue: g,
          _currentValue2: g,
          _threadCount: 0,
          Provider: null,
          Consumer: null,
          _defaultValue: null,
          _globalName: null,
        }),
        (g.Provider = { $$typeof: y, _context: g }),
        (g.Consumer = g)
      );
    }),
    (oe.createElement = te),
    (oe.createFactory = function (g) {
      var E = te.bind(null, g);
      return ((E.type = g), E);
    }),
    (oe.createRef = function () {
      return { current: null };
    }),
    (oe.forwardRef = function (g) {
      return { $$typeof: j, render: g };
    }),
    (oe.isValidElement = le),
    (oe.lazy = function (g) {
      return { $$typeof: T, _payload: { _status: -1, _result: g }, _init: Le };
    }),
    (oe.memo = function (g, E) {
      return { $$typeof: F, type: g, compare: E === void 0 ? null : E };
    }),
    (oe.startTransition = function (g) {
      var E = R.transition;
      R.transition = {};
      try {
        g();
      } finally {
        R.transition = E;
      }
    }),
    (oe.unstable_act = _),
    (oe.useCallback = function (g, E) {
      return ye.current.useCallback(g, E);
    }),
    (oe.useContext = function (g) {
      return ye.current.useContext(g);
    }),
    (oe.useDebugValue = function () {}),
    (oe.useDeferredValue = function (g) {
      return ye.current.useDeferredValue(g);
    }),
    (oe.useEffect = function (g, E) {
      return ye.current.useEffect(g, E);
    }),
    (oe.useId = function () {
      return ye.current.useId();
    }),
    (oe.useImperativeHandle = function (g, E, Z) {
      return ye.current.useImperativeHandle(g, E, Z);
    }),
    (oe.useInsertionEffect = function (g, E) {
      return ye.current.useInsertionEffect(g, E);
    }),
    (oe.useLayoutEffect = function (g, E) {
      return ye.current.useLayoutEffect(g, E);
    }),
    (oe.useMemo = function (g, E) {
      return ye.current.useMemo(g, E);
    }),
    (oe.useReducer = function (g, E, Z) {
      return ye.current.useReducer(g, E, Z);
    }),
    (oe.useRef = function (g) {
      return ye.current.useRef(g);
    }),
    (oe.useState = function (g) {
      return ye.current.useState(g);
    }),
    (oe.useSyncExternalStore = function (g, E, Z) {
      return ye.current.useSyncExternalStore(g, E, Z);
    }),
    (oe.useTransition = function () {
      return ye.current.useTransition();
    }),
    (oe.version = "18.3.1"),
    oe
  );
}
var Ic;
function Ma() {
  return (Ic || ((Ic = 1), (ra.exports = Yp())), ra.exports);
}
/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var Dc;
function qp() {
  if (Dc) return Hr;
  Dc = 1;
  var s = Ma(),
    u = Symbol.for("react.element"),
    l = Symbol.for("react.fragment"),
    d = Object.prototype.hasOwnProperty,
    p = s.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,
    y = { key: !0, ref: !0, __self: !0, __source: !0 };
  function S(j, k, F) {
    var T,
      V = {},
      D = null,
      q = null;
    (F !== void 0 && (D = "" + F),
      k.key !== void 0 && (D = "" + k.key),
      k.ref !== void 0 && (q = k.ref));
    for (T in k) d.call(k, T) && !y.hasOwnProperty(T) && (V[T] = k[T]);
    if (j && j.defaultProps)
      for (T in ((k = j.defaultProps), k)) V[T] === void 0 && (V[T] = k[T]);
    return {
      $$typeof: u,
      type: j,
      key: D,
      ref: q,
      props: V,
      _owner: p.current,
    };
  }
  return ((Hr.Fragment = l), (Hr.jsx = S), (Hr.jsxs = S), Hr);
}
var Uc;
function Xp() {
  return (Uc || ((Uc = 1), (na.exports = qp())), na.exports);
}
var a = Xp(),
  I = Ma();
const Jp = xd(I);
var ri = {},
  oa = { exports: {} },
  st = {},
  ia = { exports: {} },
  sa = {};
/**
 * @license React
 * scheduler.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var Fc;
function em() {
  return (
    Fc ||
      ((Fc = 1),
      (function (s) {
        function u(R, H) {
          var _ = R.length;
          R.push(H);
          e: for (; 0 < _;) {
            var g = (_ - 1) >>> 1,
              E = R[g];
            if (0 < p(E, H)) ((R[g] = H), (R[_] = E), (_ = g));
            else break e;
          }
        }
        function l(R) {
          return R.length === 0 ? null : R[0];
        }
        function d(R) {
          if (R.length === 0) return null;
          var H = R[0],
            _ = R.pop();
          if (_ !== H) {
            R[0] = _;
            e: for (var g = 0, E = R.length, Z = E >>> 1; g < Z;) {
              var re = 2 * (g + 1) - 1,
                ue = R[re],
                de = re + 1,
                ve = R[de];
              if (0 > p(ue, _))
                de < E && 0 > p(ve, ue)
                  ? ((R[g] = ve), (R[de] = _), (g = de))
                  : ((R[g] = ue), (R[re] = _), (g = re));
              else if (de < E && 0 > p(ve, _))
                ((R[g] = ve), (R[de] = _), (g = de));
              else break e;
            }
          }
          return H;
        }
        function p(R, H) {
          var _ = R.sortIndex - H.sortIndex;
          return _ !== 0 ? _ : R.id - H.id;
        }
        if (
          typeof performance == "object" &&
          typeof performance.now == "function"
        ) {
          var y = performance;
          s.unstable_now = function () {
            return y.now();
          };
        } else {
          var S = Date,
            j = S.now();
          s.unstable_now = function () {
            return S.now() - j;
          };
        }
        var k = [],
          F = [],
          T = 1,
          V = null,
          D = 3,
          q = !1,
          X = !1,
          O = !1,
          $ = typeof setTimeout == "function" ? setTimeout : null,
          K = typeof clearTimeout == "function" ? clearTimeout : null,
          ae = typeof setImmediate < "u" ? setImmediate : null;
        typeof navigator < "u" &&
          navigator.scheduling !== void 0 &&
          navigator.scheduling.isInputPending !== void 0 &&
          navigator.scheduling.isInputPending.bind(navigator.scheduling);
        function be(R) {
          for (var H = l(F); H !== null;) {
            if (H.callback === null) d(F);
            else if (H.startTime <= R)
              (d(F), (H.sortIndex = H.expirationTime), u(k, H));
            else break;
            H = l(F);
          }
        }
        function ie(R) {
          if (((O = !1), be(R), !X))
            if (l(k) !== null) ((X = !0), Le(Ae));
            else {
              var H = l(F);
              H !== null && ye(ie, H.startTime - R);
            }
        }
        function Ae(R, H) {
          ((X = !1), O && ((O = !1), K(te), (te = -1)), (q = !0));
          var _ = D;
          try {
            for (
              be(H), V = l(k);
              V !== null && (!(V.expirationTime > H) || (R && !se()));
            ) {
              var g = V.callback;
              if (typeof g == "function") {
                ((V.callback = null), (D = V.priorityLevel));
                var E = g(V.expirationTime <= H);
                ((H = s.unstable_now()),
                  typeof E == "function"
                    ? (V.callback = E)
                    : V === l(k) && d(k),
                  be(H));
              } else d(k);
              V = l(k);
            }
            if (V !== null) var Z = !0;
            else {
              var re = l(F);
              (re !== null && ye(ie, re.startTime - H), (Z = !1));
            }
            return Z;
          } finally {
            ((V = null), (D = _), (q = !1));
          }
        }
        var B = !1,
          ee = null,
          te = -1,
          ne = 5,
          le = -1;
        function se() {
          return !(s.unstable_now() - le < ne);
        }
        function Ee() {
          if (ee !== null) {
            var R = s.unstable_now();
            le = R;
            var H = !0;
            try {
              H = ee(!0, R);
            } finally {
              H ? he() : ((B = !1), (ee = null));
            }
          } else B = !1;
        }
        var he;
        if (typeof ae == "function")
          he = function () {
            ae(Ee);
          };
        else if (typeof MessageChannel < "u") {
          var je = new MessageChannel(),
            Fe = je.port2;
          ((je.port1.onmessage = Ee),
            (he = function () {
              Fe.postMessage(null);
            }));
        } else
          he = function () {
            $(Ee, 0);
          };
        function Le(R) {
          ((ee = R), B || ((B = !0), he()));
        }
        function ye(R, H) {
          te = $(function () {
            R(s.unstable_now());
          }, H);
        }
        ((s.unstable_IdlePriority = 5),
          (s.unstable_ImmediatePriority = 1),
          (s.unstable_LowPriority = 4),
          (s.unstable_NormalPriority = 3),
          (s.unstable_Profiling = null),
          (s.unstable_UserBlockingPriority = 2),
          (s.unstable_cancelCallback = function (R) {
            R.callback = null;
          }),
          (s.unstable_continueExecution = function () {
            X || q || ((X = !0), Le(Ae));
          }),
          (s.unstable_forceFrameRate = function (R) {
            0 > R || 125 < R
              ? console.error(
                  "forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported",
                )
              : (ne = 0 < R ? Math.floor(1e3 / R) : 5);
          }),
          (s.unstable_getCurrentPriorityLevel = function () {
            return D;
          }),
          (s.unstable_getFirstCallbackNode = function () {
            return l(k);
          }),
          (s.unstable_next = function (R) {
            switch (D) {
              case 1:
              case 2:
              case 3:
                var H = 3;
                break;
              default:
                H = D;
            }
            var _ = D;
            D = H;
            try {
              return R();
            } finally {
              D = _;
            }
          }),
          (s.unstable_pauseExecution = function () {}),
          (s.unstable_requestPaint = function () {}),
          (s.unstable_runWithPriority = function (R, H) {
            switch (R) {
              case 1:
              case 2:
              case 3:
              case 4:
              case 5:
                break;
              default:
                R = 3;
            }
            var _ = D;
            D = R;
            try {
              return H();
            } finally {
              D = _;
            }
          }),
          (s.unstable_scheduleCallback = function (R, H, _) {
            var g = s.unstable_now();
            switch (
              (typeof _ == "object" && _ !== null
                ? ((_ = _.delay),
                  (_ = typeof _ == "number" && 0 < _ ? g + _ : g))
                : (_ = g),
              R)
            ) {
              case 1:
                var E = -1;
                break;
              case 2:
                E = 250;
                break;
              case 5:
                E = 1073741823;
                break;
              case 4:
                E = 1e4;
                break;
              default:
                E = 5e3;
            }
            return (
              (E = _ + E),
              (R = {
                id: T++,
                callback: H,
                priorityLevel: R,
                startTime: _,
                expirationTime: E,
                sortIndex: -1,
              }),
              _ > g
                ? ((R.sortIndex = _),
                  u(F, R),
                  l(k) === null &&
                    R === l(F) &&
                    (O ? (K(te), (te = -1)) : (O = !0), ye(ie, _ - g)))
                : ((R.sortIndex = E), u(k, R), X || q || ((X = !0), Le(Ae))),
              R
            );
          }),
          (s.unstable_shouldYield = se),
          (s.unstable_wrapCallback = function (R) {
            var H = D;
            return function () {
              var _ = D;
              D = H;
              try {
                return R.apply(this, arguments);
              } finally {
                D = _;
              }
            };
          }));
      })(sa)),
    sa
  );
}
var Wc;
function tm() {
  return (Wc || ((Wc = 1), (ia.exports = em())), ia.exports);
}
/**
 * @license React
 * react-dom.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var $c;
function nm() {
  if ($c) return st;
  $c = 1;
  var s = Ma(),
    u = tm();
  function l(e) {
    for (
      var t = "https://reactjs.org/docs/error-decoder.html?invariant=" + e,
        n = 1;
      n < arguments.length;
      n++
    )
      t += "&args[]=" + encodeURIComponent(arguments[n]);
    return (
      "Minified React error #" +
      e +
      "; visit " +
      t +
      " for the full message or use the non-minified dev environment for full errors and additional helpful warnings."
    );
  }
  var d = new Set(),
    p = {};
  function y(e, t) {
    (S(e, t), S(e + "Capture", t));
  }
  function S(e, t) {
    for (p[e] = t, e = 0; e < t.length; e++) d.add(t[e]);
  }
  var j = !(
      typeof window > "u" ||
      typeof window.document > "u" ||
      typeof window.document.createElement > "u"
    ),
    k = Object.prototype.hasOwnProperty,
    F =
      /^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/,
    T = {},
    V = {};
  function D(e) {
    return k.call(V, e)
      ? !0
      : k.call(T, e)
        ? !1
        : F.test(e)
          ? (V[e] = !0)
          : ((T[e] = !0), !1);
  }
  function q(e, t, n, r) {
    if (n !== null && n.type === 0) return !1;
    switch (typeof t) {
      case "function":
      case "symbol":
        return !0;
      case "boolean":
        return r
          ? !1
          : n !== null
            ? !n.acceptsBooleans
            : ((e = e.toLowerCase().slice(0, 5)),
              e !== "data-" && e !== "aria-");
      default:
        return !1;
    }
  }
  function X(e, t, n, r) {
    if (t === null || typeof t > "u" || q(e, t, n, r)) return !0;
    if (r) return !1;
    if (n !== null)
      switch (n.type) {
        case 3:
          return !t;
        case 4:
          return t === !1;
        case 5:
          return isNaN(t);
        case 6:
          return isNaN(t) || 1 > t;
      }
    return !1;
  }
  function O(e, t, n, r, o, i, c) {
    ((this.acceptsBooleans = t === 2 || t === 3 || t === 4),
      (this.attributeName = r),
      (this.attributeNamespace = o),
      (this.mustUseProperty = n),
      (this.propertyName = e),
      (this.type = t),
      (this.sanitizeURL = i),
      (this.removeEmptyString = c));
  }
  var $ = {};
  ("children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style"
    .split(" ")
    .forEach(function (e) {
      $[e] = new O(e, 0, !1, e, null, !1, !1);
    }),
    [
      ["acceptCharset", "accept-charset"],
      ["className", "class"],
      ["htmlFor", "for"],
      ["httpEquiv", "http-equiv"],
    ].forEach(function (e) {
      var t = e[0];
      $[t] = new O(t, 1, !1, e[1], null, !1, !1);
    }),
    ["contentEditable", "draggable", "spellCheck", "value"].forEach(
      function (e) {
        $[e] = new O(e, 2, !1, e.toLowerCase(), null, !1, !1);
      },
    ),
    [
      "autoReverse",
      "externalResourcesRequired",
      "focusable",
      "preserveAlpha",
    ].forEach(function (e) {
      $[e] = new O(e, 2, !1, e, null, !1, !1);
    }),
    "allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope"
      .split(" ")
      .forEach(function (e) {
        $[e] = new O(e, 3, !1, e.toLowerCase(), null, !1, !1);
      }),
    ["checked", "multiple", "muted", "selected"].forEach(function (e) {
      $[e] = new O(e, 3, !0, e, null, !1, !1);
    }),
    ["capture", "download"].forEach(function (e) {
      $[e] = new O(e, 4, !1, e, null, !1, !1);
    }),
    ["cols", "rows", "size", "span"].forEach(function (e) {
      $[e] = new O(e, 6, !1, e, null, !1, !1);
    }),
    ["rowSpan", "start"].forEach(function (e) {
      $[e] = new O(e, 5, !1, e.toLowerCase(), null, !1, !1);
    }));
  var K = /[\-:]([a-z])/g;
  function ae(e) {
    return e[1].toUpperCase();
  }
  ("accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height"
    .split(" ")
    .forEach(function (e) {
      var t = e.replace(K, ae);
      $[t] = new O(t, 1, !1, e, null, !1, !1);
    }),
    "xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type"
      .split(" ")
      .forEach(function (e) {
        var t = e.replace(K, ae);
        $[t] = new O(t, 1, !1, e, "http://www.w3.org/1999/xlink", !1, !1);
      }),
    ["xml:base", "xml:lang", "xml:space"].forEach(function (e) {
      var t = e.replace(K, ae);
      $[t] = new O(t, 1, !1, e, "http://www.w3.org/XML/1998/namespace", !1, !1);
    }),
    ["tabIndex", "crossOrigin"].forEach(function (e) {
      $[e] = new O(e, 1, !1, e.toLowerCase(), null, !1, !1);
    }),
    ($.xlinkHref = new O(
      "xlinkHref",
      1,
      !1,
      "xlink:href",
      "http://www.w3.org/1999/xlink",
      !0,
      !1,
    )),
    ["src", "href", "action", "formAction"].forEach(function (e) {
      $[e] = new O(e, 1, !1, e.toLowerCase(), null, !0, !0);
    }));
  function be(e, t, n, r) {
    var o = $.hasOwnProperty(t) ? $[t] : null;
    (o !== null
      ? o.type !== 0
      : r ||
        !(2 < t.length) ||
        (t[0] !== "o" && t[0] !== "O") ||
        (t[1] !== "n" && t[1] !== "N")) &&
      (X(t, n, o, r) && (n = null),
      r || o === null
        ? D(t) &&
          (n === null ? e.removeAttribute(t) : e.setAttribute(t, "" + n))
        : o.mustUseProperty
          ? (e[o.propertyName] = n === null ? (o.type === 3 ? !1 : "") : n)
          : ((t = o.attributeName),
            (r = o.attributeNamespace),
            n === null
              ? e.removeAttribute(t)
              : ((o = o.type),
                (n = o === 3 || (o === 4 && n === !0) ? "" : "" + n),
                r ? e.setAttributeNS(r, t, n) : e.setAttribute(t, n))));
  }
  var ie = s.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED,
    Ae = Symbol.for("react.element"),
    B = Symbol.for("react.portal"),
    ee = Symbol.for("react.fragment"),
    te = Symbol.for("react.strict_mode"),
    ne = Symbol.for("react.profiler"),
    le = Symbol.for("react.provider"),
    se = Symbol.for("react.context"),
    Ee = Symbol.for("react.forward_ref"),
    he = Symbol.for("react.suspense"),
    je = Symbol.for("react.suspense_list"),
    Fe = Symbol.for("react.memo"),
    Le = Symbol.for("react.lazy"),
    ye = Symbol.for("react.offscreen"),
    R = Symbol.iterator;
  function H(e) {
    return e === null || typeof e != "object"
      ? null
      : ((e = (R && e[R]) || e["@@iterator"]),
        typeof e == "function" ? e : null);
  }
  var _ = Object.assign,
    g;
  function E(e) {
    if (g === void 0)
      try {
        throw Error();
      } catch (n) {
        var t = n.stack.trim().match(/\n( *(at )?)/);
        g = (t && t[1]) || "";
      }
    return (
      `
` +
      g +
      e
    );
  }
  var Z = !1;
  function re(e, t) {
    if (!e || Z) return "";
    Z = !0;
    var n = Error.prepareStackTrace;
    Error.prepareStackTrace = void 0;
    try {
      if (t)
        if (
          ((t = function () {
            throw Error();
          }),
          Object.defineProperty(t.prototype, "props", {
            set: function () {
              throw Error();
            },
          }),
          typeof Reflect == "object" && Reflect.construct)
        ) {
          try {
            Reflect.construct(t, []);
          } catch (x) {
            var r = x;
          }
          Reflect.construct(e, [], t);
        } else {
          try {
            t.call();
          } catch (x) {
            r = x;
          }
          e.call(t.prototype);
        }
      else {
        try {
          throw Error();
        } catch (x) {
          r = x;
        }
        e();
      }
    } catch (x) {
      if (x && r && typeof x.stack == "string") {
        for (
          var o = x.stack.split(`
`),
            i = r.stack.split(`
`),
            c = o.length - 1,
            f = i.length - 1;
          1 <= c && 0 <= f && o[c] !== i[f];
        )
          f--;
        for (; 1 <= c && 0 <= f; c--, f--)
          if (o[c] !== i[f]) {
            if (c !== 1 || f !== 1)
              do
                if ((c--, f--, 0 > f || o[c] !== i[f])) {
                  var m =
                    `
` + o[c].replace(" at new ", " at ");
                  return (
                    e.displayName &&
                      m.includes("<anonymous>") &&
                      (m = m.replace("<anonymous>", e.displayName)),
                    m
                  );
                }
              while (1 <= c && 0 <= f);
            break;
          }
      }
    } finally {
      ((Z = !1), (Error.prepareStackTrace = n));
    }
    return (e = e ? e.displayName || e.name : "") ? E(e) : "";
  }
  function ue(e) {
    switch (e.tag) {
      case 5:
        return E(e.type);
      case 16:
        return E("Lazy");
      case 13:
        return E("Suspense");
      case 19:
        return E("SuspenseList");
      case 0:
      case 2:
      case 15:
        return ((e = re(e.type, !1)), e);
      case 11:
        return ((e = re(e.type.render, !1)), e);
      case 1:
        return ((e = re(e.type, !0)), e);
      default:
        return "";
    }
  }
  function de(e) {
    if (e == null) return null;
    if (typeof e == "function") return e.displayName || e.name || null;
    if (typeof e == "string") return e;
    switch (e) {
      case ee:
        return "Fragment";
      case B:
        return "Portal";
      case ne:
        return "Profiler";
      case te:
        return "StrictMode";
      case he:
        return "Suspense";
      case je:
        return "SuspenseList";
    }
    if (typeof e == "object")
      switch (e.$$typeof) {
        case se:
          return (e.displayName || "Context") + ".Consumer";
        case le:
          return (e._context.displayName || "Context") + ".Provider";
        case Ee:
          var t = e.render;
          return (
            (e = e.displayName),
            e ||
              ((e = t.displayName || t.name || ""),
              (e = e !== "" ? "ForwardRef(" + e + ")" : "ForwardRef")),
            e
          );
        case Fe:
          return (
            (t = e.displayName || null),
            t !== null ? t : de(e.type) || "Memo"
          );
        case Le:
          ((t = e._payload), (e = e._init));
          try {
            return de(e(t));
          } catch {}
      }
    return null;
  }
  function ve(e) {
    var t = e.type;
    switch (e.tag) {
      case 24:
        return "Cache";
      case 9:
        return (t.displayName || "Context") + ".Consumer";
      case 10:
        return (t._context.displayName || "Context") + ".Provider";
      case 18:
        return "DehydratedFragment";
      case 11:
        return (
          (e = t.render),
          (e = e.displayName || e.name || ""),
          t.displayName || (e !== "" ? "ForwardRef(" + e + ")" : "ForwardRef")
        );
      case 7:
        return "Fragment";
      case 5:
        return t;
      case 4:
        return "Portal";
      case 3:
        return "Root";
      case 6:
        return "Text";
      case 16:
        return de(t);
      case 8:
        return t === te ? "StrictMode" : "Mode";
      case 22:
        return "Offscreen";
      case 12:
        return "Profiler";
      case 21:
        return "Scope";
      case 13:
        return "Suspense";
      case 19:
        return "SuspenseList";
      case 25:
        return "TracingMarker";
      case 1:
      case 0:
      case 17:
      case 2:
      case 14:
      case 15:
        if (typeof t == "function") return t.displayName || t.name || null;
        if (typeof t == "string") return t;
    }
    return null;
  }
  function fe(e) {
    switch (typeof e) {
      case "boolean":
      case "number":
      case "string":
      case "undefined":
        return e;
      case "object":
        return e;
      default:
        return "";
    }
  }
  function Y(e) {
    var t = e.type;
    return (
      (e = e.nodeName) &&
      e.toLowerCase() === "input" &&
      (t === "checkbox" || t === "radio")
    );
  }
  function we(e) {
    var t = Y(e) ? "checked" : "value",
      n = Object.getOwnPropertyDescriptor(e.constructor.prototype, t),
      r = "" + e[t];
    if (
      !e.hasOwnProperty(t) &&
      typeof n < "u" &&
      typeof n.get == "function" &&
      typeof n.set == "function"
    ) {
      var o = n.get,
        i = n.set;
      return (
        Object.defineProperty(e, t, {
          configurable: !0,
          get: function () {
            return o.call(this);
          },
          set: function (c) {
            ((r = "" + c), i.call(this, c));
          },
        }),
        Object.defineProperty(e, t, { enumerable: n.enumerable }),
        {
          getValue: function () {
            return r;
          },
          setValue: function (c) {
            r = "" + c;
          },
          stopTracking: function () {
            ((e._valueTracker = null), delete e[t]);
          },
        }
      );
    }
  }
  function qe(e) {
    e._valueTracker || (e._valueTracker = we(e));
  }
  function He(e) {
    if (!e) return !1;
    var t = e._valueTracker;
    if (!t) return !0;
    var n = t.getValue(),
      r = "";
    return (
      e && (r = Y(e) ? (e.checked ? "true" : "false") : e.value),
      (e = r),
      e !== n ? (t.setValue(e), !0) : !1
    );
  }
  function Pe(e) {
    if (
      ((e = e || (typeof document < "u" ? document : void 0)), typeof e > "u")
    )
      return null;
    try {
      return e.activeElement || e.body;
    } catch {
      return e.body;
    }
  }
  function Lt(e, t) {
    var n = t.checked;
    return _({}, t, {
      defaultChecked: void 0,
      defaultValue: void 0,
      value: void 0,
      checked: n ?? e._wrapperState.initialChecked,
    });
  }
  function et(e, t) {
    var n = t.defaultValue == null ? "" : t.defaultValue,
      r = t.checked != null ? t.checked : t.defaultChecked;
    ((n = fe(t.value != null ? t.value : n)),
      (e._wrapperState = {
        initialChecked: r,
        initialValue: n,
        controlled:
          t.type === "checkbox" || t.type === "radio"
            ? t.checked != null
            : t.value != null,
      }));
  }
  function Mt(e, t) {
    ((t = t.checked), t != null && be(e, "checked", t, !1));
  }
  function or(e, t) {
    Mt(e, t);
    var n = fe(t.value),
      r = t.type;
    if (n != null)
      r === "number"
        ? ((n === 0 && e.value === "") || e.value != n) && (e.value = "" + n)
        : e.value !== "" + n && (e.value = "" + n);
    else if (r === "submit" || r === "reset") {
      e.removeAttribute("value");
      return;
    }
    (t.hasOwnProperty("value")
      ? di(e, t.type, n)
      : t.hasOwnProperty("defaultValue") && di(e, t.type, fe(t.defaultValue)),
      t.checked == null &&
        t.defaultChecked != null &&
        (e.defaultChecked = !!t.defaultChecked));
  }
  function Va(e, t, n) {
    if (t.hasOwnProperty("value") || t.hasOwnProperty("defaultValue")) {
      var r = t.type;
      if (!(
        (r !== "submit" && r !== "reset") ||
        (t.value !== void 0 && t.value !== null)
      ))
        return;
      ((t = "" + e._wrapperState.initialValue),
        n || t === e.value || (e.value = t),
        (e.defaultValue = t));
    }
    ((n = e.name),
      n !== "" && (e.name = ""),
      (e.defaultChecked = !!e._wrapperState.initialChecked),
      n !== "" && (e.name = n));
  }
  function di(e, t, n) {
    (t !== "number" || Pe(e.ownerDocument) !== e) &&
      (n == null
        ? (e.defaultValue = "" + e._wrapperState.initialValue)
        : e.defaultValue !== "" + n && (e.defaultValue = "" + n));
  }
  var ir = Array.isArray;
  function Rn(e, t, n, r) {
    if (((e = e.options), t)) {
      t = {};
      for (var o = 0; o < n.length; o++) t["$" + n[o]] = !0;
      for (n = 0; n < e.length; n++)
        ((o = t.hasOwnProperty("$" + e[n].value)),
          e[n].selected !== o && (e[n].selected = o),
          o && r && (e[n].defaultSelected = !0));
    } else {
      for (n = "" + fe(n), t = null, o = 0; o < e.length; o++) {
        if (e[o].value === n) {
          ((e[o].selected = !0), r && (e[o].defaultSelected = !0));
          return;
        }
        t !== null || e[o].disabled || (t = e[o]);
      }
      t !== null && (t.selected = !0);
    }
  }
  function fi(e, t) {
    if (t.dangerouslySetInnerHTML != null) throw Error(l(91));
    return _({}, t, {
      value: void 0,
      defaultValue: void 0,
      children: "" + e._wrapperState.initialValue,
    });
  }
  function Ka(e, t) {
    var n = t.value;
    if (n == null) {
      if (((n = t.children), (t = t.defaultValue), n != null)) {
        if (t != null) throw Error(l(92));
        if (ir(n)) {
          if (1 < n.length) throw Error(l(93));
          n = n[0];
        }
        t = n;
      }
      (t == null && (t = ""), (n = t));
    }
    e._wrapperState = { initialValue: fe(n) };
  }
  function Ga(e, t) {
    var n = fe(t.value),
      r = fe(t.defaultValue);
    (n != null &&
      ((n = "" + n),
      n !== e.value && (e.value = n),
      t.defaultValue == null && e.defaultValue !== n && (e.defaultValue = n)),
      r != null && (e.defaultValue = "" + r));
  }
  function Qa(e) {
    var t = e.textContent;
    t === e._wrapperState.initialValue &&
      t !== "" &&
      t !== null &&
      (e.value = t);
  }
  function Za(e) {
    switch (e) {
      case "svg":
        return "http://www.w3.org/2000/svg";
      case "math":
        return "http://www.w3.org/1998/Math/MathML";
      default:
        return "http://www.w3.org/1999/xhtml";
    }
  }
  function pi(e, t) {
    return e == null || e === "http://www.w3.org/1999/xhtml"
      ? Za(t)
      : e === "http://www.w3.org/2000/svg" && t === "foreignObject"
        ? "http://www.w3.org/1999/xhtml"
        : e;
  }
  var Qr,
    Ya = (function (e) {
      return typeof MSApp < "u" && MSApp.execUnsafeLocalFunction
        ? function (t, n, r, o) {
            MSApp.execUnsafeLocalFunction(function () {
              return e(t, n, r, o);
            });
          }
        : e;
    })(function (e, t) {
      if (e.namespaceURI !== "http://www.w3.org/2000/svg" || "innerHTML" in e)
        e.innerHTML = t;
      else {
        for (
          Qr = Qr || document.createElement("div"),
            Qr.innerHTML = "<svg>" + t.valueOf().toString() + "</svg>",
            t = Qr.firstChild;
          e.firstChild;
        )
          e.removeChild(e.firstChild);
        for (; t.firstChild;) e.appendChild(t.firstChild);
      }
    });
  function sr(e, t) {
    if (t) {
      var n = e.firstChild;
      if (n && n === e.lastChild && n.nodeType === 3) {
        n.nodeValue = t;
        return;
      }
    }
    e.textContent = t;
  }
  var ar = {
      animationIterationCount: !0,
      aspectRatio: !0,
      borderImageOutset: !0,
      borderImageSlice: !0,
      borderImageWidth: !0,
      boxFlex: !0,
      boxFlexGroup: !0,
      boxOrdinalGroup: !0,
      columnCount: !0,
      columns: !0,
      flex: !0,
      flexGrow: !0,
      flexPositive: !0,
      flexShrink: !0,
      flexNegative: !0,
      flexOrder: !0,
      gridArea: !0,
      gridRow: !0,
      gridRowEnd: !0,
      gridRowSpan: !0,
      gridRowStart: !0,
      gridColumn: !0,
      gridColumnEnd: !0,
      gridColumnSpan: !0,
      gridColumnStart: !0,
      fontWeight: !0,
      lineClamp: !0,
      lineHeight: !0,
      opacity: !0,
      order: !0,
      orphans: !0,
      tabSize: !0,
      widows: !0,
      zIndex: !0,
      zoom: !0,
      fillOpacity: !0,
      floodOpacity: !0,
      stopOpacity: !0,
      strokeDasharray: !0,
      strokeDashoffset: !0,
      strokeMiterlimit: !0,
      strokeOpacity: !0,
      strokeWidth: !0,
    },
    Jd = ["Webkit", "ms", "Moz", "O"];
  Object.keys(ar).forEach(function (e) {
    Jd.forEach(function (t) {
      ((t = t + e.charAt(0).toUpperCase() + e.substring(1)), (ar[t] = ar[e]));
    });
  });
  function qa(e, t, n) {
    return t == null || typeof t == "boolean" || t === ""
      ? ""
      : n || typeof t != "number" || t === 0 || (ar.hasOwnProperty(e) && ar[e])
        ? ("" + t).trim()
        : t + "px";
  }
  function Xa(e, t) {
    e = e.style;
    for (var n in t)
      if (t.hasOwnProperty(n)) {
        var r = n.indexOf("--") === 0,
          o = qa(n, t[n], r);
        (n === "float" && (n = "cssFloat"),
          r ? e.setProperty(n, o) : (e[n] = o));
      }
  }
  var ef = _(
    { menuitem: !0 },
    {
      area: !0,
      base: !0,
      br: !0,
      col: !0,
      embed: !0,
      hr: !0,
      img: !0,
      input: !0,
      keygen: !0,
      link: !0,
      meta: !0,
      param: !0,
      source: !0,
      track: !0,
      wbr: !0,
    },
  );
  function mi(e, t) {
    if (t) {
      if (ef[e] && (t.children != null || t.dangerouslySetInnerHTML != null))
        throw Error(l(137, e));
      if (t.dangerouslySetInnerHTML != null) {
        if (t.children != null) throw Error(l(60));
        if (
          typeof t.dangerouslySetInnerHTML != "object" ||
          !("__html" in t.dangerouslySetInnerHTML)
        )
          throw Error(l(61));
      }
      if (t.style != null && typeof t.style != "object") throw Error(l(62));
    }
  }
  function hi(e, t) {
    if (e.indexOf("-") === -1) return typeof t.is == "string";
    switch (e) {
      case "annotation-xml":
      case "color-profile":
      case "font-face":
      case "font-face-src":
      case "font-face-uri":
      case "font-face-format":
      case "font-face-name":
      case "missing-glyph":
        return !1;
      default:
        return !0;
    }
  }
  var gi = null;
  function yi(e) {
    return (
      (e = e.target || e.srcElement || window),
      e.correspondingUseElement && (e = e.correspondingUseElement),
      e.nodeType === 3 ? e.parentNode : e
    );
  }
  var vi = null,
    Ln = null,
    Mn = null;
  function Ja(e) {
    if ((e = zr(e))) {
      if (typeof vi != "function") throw Error(l(280));
      var t = e.stateNode;
      t && ((t = vo(t)), vi(e.stateNode, e.type, t));
    }
  }
  function el(e) {
    Ln ? (Mn ? Mn.push(e) : (Mn = [e])) : (Ln = e);
  }
  function tl() {
    if (Ln) {
      var e = Ln,
        t = Mn;
      if (((Mn = Ln = null), Ja(e), t)) for (e = 0; e < t.length; e++) Ja(t[e]);
    }
  }
  function nl(e, t) {
    return e(t);
  }
  function rl() {}
  var wi = !1;
  function ol(e, t, n) {
    if (wi) return e(t, n);
    wi = !0;
    try {
      return nl(e, t, n);
    } finally {
      ((wi = !1), (Ln !== null || Mn !== null) && (rl(), tl()));
    }
  }
  function lr(e, t) {
    var n = e.stateNode;
    if (n === null) return null;
    var r = vo(n);
    if (r === null) return null;
    n = r[t];
    e: switch (t) {
      case "onClick":
      case "onClickCapture":
      case "onDoubleClick":
      case "onDoubleClickCapture":
      case "onMouseDown":
      case "onMouseDownCapture":
      case "onMouseMove":
      case "onMouseMoveCapture":
      case "onMouseUp":
      case "onMouseUpCapture":
      case "onMouseEnter":
        ((r = !r.disabled) ||
          ((e = e.type),
          (r = !(
            e === "button" ||
            e === "input" ||
            e === "select" ||
            e === "textarea"
          ))),
          (e = !r));
        break e;
      default:
        e = !1;
    }
    if (e) return null;
    if (n && typeof n != "function") throw Error(l(231, t, typeof n));
    return n;
  }
  var xi = !1;
  if (j)
    try {
      var ur = {};
      (Object.defineProperty(ur, "passive", {
        get: function () {
          xi = !0;
        },
      }),
        window.addEventListener("test", ur, ur),
        window.removeEventListener("test", ur, ur));
    } catch {
      xi = !1;
    }
  function tf(e, t, n, r, o, i, c, f, m) {
    var x = Array.prototype.slice.call(arguments, 3);
    try {
      t.apply(n, x);
    } catch (A) {
      this.onError(A);
    }
  }
  var cr = !1,
    Zr = null,
    Yr = !1,
    ki = null,
    nf = {
      onError: function (e) {
        ((cr = !0), (Zr = e));
      },
    };
  function rf(e, t, n, r, o, i, c, f, m) {
    ((cr = !1), (Zr = null), tf.apply(nf, arguments));
  }
  function of(e, t, n, r, o, i, c, f, m) {
    if ((rf.apply(this, arguments), cr)) {
      if (cr) {
        var x = Zr;
        ((cr = !1), (Zr = null));
      } else throw Error(l(198));
      Yr || ((Yr = !0), (ki = x));
    }
  }
  function pn(e) {
    var t = e,
      n = e;
    if (e.alternate) for (; t.return;) t = t.return;
    else {
      e = t;
      do ((t = e), (t.flags & 4098) !== 0 && (n = t.return), (e = t.return));
      while (e);
    }
    return t.tag === 3 ? n : null;
  }
  function il(e) {
    if (e.tag === 13) {
      var t = e.memoizedState;
      if (
        (t === null && ((e = e.alternate), e !== null && (t = e.memoizedState)),
        t !== null)
      )
        return t.dehydrated;
    }
    return null;
  }
  function sl(e) {
    if (pn(e) !== e) throw Error(l(188));
  }
  function sf(e) {
    var t = e.alternate;
    if (!t) {
      if (((t = pn(e)), t === null)) throw Error(l(188));
      return t !== e ? null : e;
    }
    for (var n = e, r = t; ;) {
      var o = n.return;
      if (o === null) break;
      var i = o.alternate;
      if (i === null) {
        if (((r = o.return), r !== null)) {
          n = r;
          continue;
        }
        break;
      }
      if (o.child === i.child) {
        for (i = o.child; i;) {
          if (i === n) return (sl(o), e);
          if (i === r) return (sl(o), t);
          i = i.sibling;
        }
        throw Error(l(188));
      }
      if (n.return !== r.return) ((n = o), (r = i));
      else {
        for (var c = !1, f = o.child; f;) {
          if (f === n) {
            ((c = !0), (n = o), (r = i));
            break;
          }
          if (f === r) {
            ((c = !0), (r = o), (n = i));
            break;
          }
          f = f.sibling;
        }
        if (!c) {
          for (f = i.child; f;) {
            if (f === n) {
              ((c = !0), (n = i), (r = o));
              break;
            }
            if (f === r) {
              ((c = !0), (r = i), (n = o));
              break;
            }
            f = f.sibling;
          }
          if (!c) throw Error(l(189));
        }
      }
      if (n.alternate !== r) throw Error(l(190));
    }
    if (n.tag !== 3) throw Error(l(188));
    return n.stateNode.current === n ? e : t;
  }
  function al(e) {
    return ((e = sf(e)), e !== null ? ll(e) : null);
  }
  function ll(e) {
    if (e.tag === 5 || e.tag === 6) return e;
    for (e = e.child; e !== null;) {
      var t = ll(e);
      if (t !== null) return t;
      e = e.sibling;
    }
    return null;
  }
  var ul = u.unstable_scheduleCallback,
    cl = u.unstable_cancelCallback,
    af = u.unstable_shouldYield,
    lf = u.unstable_requestPaint,
    Me = u.unstable_now,
    uf = u.unstable_getCurrentPriorityLevel,
    Si = u.unstable_ImmediatePriority,
    dl = u.unstable_UserBlockingPriority,
    qr = u.unstable_NormalPriority,
    cf = u.unstable_LowPriority,
    fl = u.unstable_IdlePriority,
    Xr = null,
    Pt = null;
  function df(e) {
    if (Pt && typeof Pt.onCommitFiberRoot == "function")
      try {
        Pt.onCommitFiberRoot(Xr, e, void 0, (e.current.flags & 128) === 128);
      } catch {}
  }
  var xt = Math.clz32 ? Math.clz32 : mf,
    ff = Math.log,
    pf = Math.LN2;
  function mf(e) {
    return ((e >>>= 0), e === 0 ? 32 : (31 - ((ff(e) / pf) | 0)) | 0);
  }
  var Jr = 64,
    eo = 4194304;
  function dr(e) {
    switch (e & -e) {
      case 1:
        return 1;
      case 2:
        return 2;
      case 4:
        return 4;
      case 8:
        return 8;
      case 16:
        return 16;
      case 32:
        return 32;
      case 64:
      case 128:
      case 256:
      case 512:
      case 1024:
      case 2048:
      case 4096:
      case 8192:
      case 16384:
      case 32768:
      case 65536:
      case 131072:
      case 262144:
      case 524288:
      case 1048576:
      case 2097152:
        return e & 4194240;
      case 4194304:
      case 8388608:
      case 16777216:
      case 33554432:
      case 67108864:
        return e & 130023424;
      case 134217728:
        return 134217728;
      case 268435456:
        return 268435456;
      case 536870912:
        return 536870912;
      case 1073741824:
        return 1073741824;
      default:
        return e;
    }
  }
  function to(e, t) {
    var n = e.pendingLanes;
    if (n === 0) return 0;
    var r = 0,
      o = e.suspendedLanes,
      i = e.pingedLanes,
      c = n & 268435455;
    if (c !== 0) {
      var f = c & ~o;
      f !== 0 ? (r = dr(f)) : ((i &= c), i !== 0 && (r = dr(i)));
    } else ((c = n & ~o), c !== 0 ? (r = dr(c)) : i !== 0 && (r = dr(i)));
    if (r === 0) return 0;
    if (
      t !== 0 &&
      t !== r &&
      (t & o) === 0 &&
      ((o = r & -r), (i = t & -t), o >= i || (o === 16 && (i & 4194240) !== 0))
    )
      return t;
    if (((r & 4) !== 0 && (r |= n & 16), (t = e.entangledLanes), t !== 0))
      for (e = e.entanglements, t &= r; 0 < t;)
        ((n = 31 - xt(t)), (o = 1 << n), (r |= e[n]), (t &= ~o));
    return r;
  }
  function hf(e, t) {
    switch (e) {
      case 1:
      case 2:
      case 4:
        return t + 250;
      case 8:
      case 16:
      case 32:
      case 64:
      case 128:
      case 256:
      case 512:
      case 1024:
      case 2048:
      case 4096:
      case 8192:
      case 16384:
      case 32768:
      case 65536:
      case 131072:
      case 262144:
      case 524288:
      case 1048576:
      case 2097152:
        return t + 5e3;
      case 4194304:
      case 8388608:
      case 16777216:
      case 33554432:
      case 67108864:
        return -1;
      case 134217728:
      case 268435456:
      case 536870912:
      case 1073741824:
        return -1;
      default:
        return -1;
    }
  }
  function gf(e, t) {
    for (
      var n = e.suspendedLanes,
        r = e.pingedLanes,
        o = e.expirationTimes,
        i = e.pendingLanes;
      0 < i;
    ) {
      var c = 31 - xt(i),
        f = 1 << c,
        m = o[c];
      (m === -1
        ? ((f & n) === 0 || (f & r) !== 0) && (o[c] = hf(f, t))
        : m <= t && (e.expiredLanes |= f),
        (i &= ~f));
    }
  }
  function bi(e) {
    return (
      (e = e.pendingLanes & -1073741825),
      e !== 0 ? e : e & 1073741824 ? 1073741824 : 0
    );
  }
  function pl() {
    var e = Jr;
    return ((Jr <<= 1), (Jr & 4194240) === 0 && (Jr = 64), e);
  }
  function Ei(e) {
    for (var t = [], n = 0; 31 > n; n++) t.push(e);
    return t;
  }
  function fr(e, t, n) {
    ((e.pendingLanes |= t),
      t !== 536870912 && ((e.suspendedLanes = 0), (e.pingedLanes = 0)),
      (e = e.eventTimes),
      (t = 31 - xt(t)),
      (e[t] = n));
  }
  function yf(e, t) {
    var n = e.pendingLanes & ~t;
    ((e.pendingLanes = t),
      (e.suspendedLanes = 0),
      (e.pingedLanes = 0),
      (e.expiredLanes &= t),
      (e.mutableReadLanes &= t),
      (e.entangledLanes &= t),
      (t = e.entanglements));
    var r = e.eventTimes;
    for (e = e.expirationTimes; 0 < n;) {
      var o = 31 - xt(n),
        i = 1 << o;
      ((t[o] = 0), (r[o] = -1), (e[o] = -1), (n &= ~i));
    }
  }
  function ji(e, t) {
    var n = (e.entangledLanes |= t);
    for (e = e.entanglements; n;) {
      var r = 31 - xt(n),
        o = 1 << r;
      ((o & t) | (e[r] & t) && (e[r] |= t), (n &= ~o));
    }
  }
  var ge = 0;
  function ml(e) {
    return (
      (e &= -e),
      1 < e ? (4 < e ? ((e & 268435455) !== 0 ? 16 : 536870912) : 4) : 1
    );
  }
  var hl,
    Ci,
    gl,
    yl,
    vl,
    Ai = !1,
    no = [],
    Vt = null,
    Kt = null,
    Gt = null,
    pr = new Map(),
    mr = new Map(),
    Qt = [],
    vf =
      "mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(
        " ",
      );
  function wl(e, t) {
    switch (e) {
      case "focusin":
      case "focusout":
        Vt = null;
        break;
      case "dragenter":
      case "dragleave":
        Kt = null;
        break;
      case "mouseover":
      case "mouseout":
        Gt = null;
        break;
      case "pointerover":
      case "pointerout":
        pr.delete(t.pointerId);
        break;
      case "gotpointercapture":
      case "lostpointercapture":
        mr.delete(t.pointerId);
    }
  }
  function hr(e, t, n, r, o, i) {
    return e === null || e.nativeEvent !== i
      ? ((e = {
          blockedOn: t,
          domEventName: n,
          eventSystemFlags: r,
          nativeEvent: i,
          targetContainers: [o],
        }),
        t !== null && ((t = zr(t)), t !== null && Ci(t)),
        e)
      : ((e.eventSystemFlags |= r),
        (t = e.targetContainers),
        o !== null && t.indexOf(o) === -1 && t.push(o),
        e);
  }
  function wf(e, t, n, r, o) {
    switch (t) {
      case "focusin":
        return ((Vt = hr(Vt, e, t, n, r, o)), !0);
      case "dragenter":
        return ((Kt = hr(Kt, e, t, n, r, o)), !0);
      case "mouseover":
        return ((Gt = hr(Gt, e, t, n, r, o)), !0);
      case "pointerover":
        var i = o.pointerId;
        return (pr.set(i, hr(pr.get(i) || null, e, t, n, r, o)), !0);
      case "gotpointercapture":
        return (
          (i = o.pointerId),
          mr.set(i, hr(mr.get(i) || null, e, t, n, r, o)),
          !0
        );
    }
    return !1;
  }
  function xl(e) {
    var t = mn(e.target);
    if (t !== null) {
      var n = pn(t);
      if (n !== null) {
        if (((t = n.tag), t === 13)) {
          if (((t = il(n)), t !== null)) {
            ((e.blockedOn = t),
              vl(e.priority, function () {
                gl(n);
              }));
            return;
          }
        } else if (t === 3 && n.stateNode.current.memoizedState.isDehydrated) {
          e.blockedOn = n.tag === 3 ? n.stateNode.containerInfo : null;
          return;
        }
      }
    }
    e.blockedOn = null;
  }
  function ro(e) {
    if (e.blockedOn !== null) return !1;
    for (var t = e.targetContainers; 0 < t.length;) {
      var n = zi(e.domEventName, e.eventSystemFlags, t[0], e.nativeEvent);
      if (n === null) {
        n = e.nativeEvent;
        var r = new n.constructor(n.type, n);
        ((gi = r), n.target.dispatchEvent(r), (gi = null));
      } else return ((t = zr(n)), t !== null && Ci(t), (e.blockedOn = n), !1);
      t.shift();
    }
    return !0;
  }
  function kl(e, t, n) {
    ro(e) && n.delete(t);
  }
  function xf() {
    ((Ai = !1),
      Vt !== null && ro(Vt) && (Vt = null),
      Kt !== null && ro(Kt) && (Kt = null),
      Gt !== null && ro(Gt) && (Gt = null),
      pr.forEach(kl),
      mr.forEach(kl));
  }
  function gr(e, t) {
    e.blockedOn === t &&
      ((e.blockedOn = null),
      Ai ||
        ((Ai = !0),
        u.unstable_scheduleCallback(u.unstable_NormalPriority, xf)));
  }
  function yr(e) {
    function t(o) {
      return gr(o, e);
    }
    if (0 < no.length) {
      gr(no[0], e);
      for (var n = 1; n < no.length; n++) {
        var r = no[n];
        r.blockedOn === e && (r.blockedOn = null);
      }
    }
    for (
      Vt !== null && gr(Vt, e),
        Kt !== null && gr(Kt, e),
        Gt !== null && gr(Gt, e),
        pr.forEach(t),
        mr.forEach(t),
        n = 0;
      n < Qt.length;
      n++
    )
      ((r = Qt[n]), r.blockedOn === e && (r.blockedOn = null));
    for (; 0 < Qt.length && ((n = Qt[0]), n.blockedOn === null);)
      (xl(n), n.blockedOn === null && Qt.shift());
  }
  var On = ie.ReactCurrentBatchConfig,
    oo = !0;
  function kf(e, t, n, r) {
    var o = ge,
      i = On.transition;
    On.transition = null;
    try {
      ((ge = 1), Pi(e, t, n, r));
    } finally {
      ((ge = o), (On.transition = i));
    }
  }
  function Sf(e, t, n, r) {
    var o = ge,
      i = On.transition;
    On.transition = null;
    try {
      ((ge = 4), Pi(e, t, n, r));
    } finally {
      ((ge = o), (On.transition = i));
    }
  }
  function Pi(e, t, n, r) {
    if (oo) {
      var o = zi(e, t, n, r);
      if (o === null) (Ki(e, t, r, io, n), wl(e, r));
      else if (wf(o, e, t, n, r)) r.stopPropagation();
      else if ((wl(e, r), t & 4 && -1 < vf.indexOf(e))) {
        for (; o !== null;) {
          var i = zr(o);
          if (
            (i !== null && hl(i),
            (i = zi(e, t, n, r)),
            i === null && Ki(e, t, r, io, n),
            i === o)
          )
            break;
          o = i;
        }
        o !== null && r.stopPropagation();
      } else Ki(e, t, r, null, n);
    }
  }
  var io = null;
  function zi(e, t, n, r) {
    if (((io = null), (e = yi(r)), (e = mn(e)), e !== null))
      if (((t = pn(e)), t === null)) e = null;
      else if (((n = t.tag), n === 13)) {
        if (((e = il(t)), e !== null)) return e;
        e = null;
      } else if (n === 3) {
        if (t.stateNode.current.memoizedState.isDehydrated)
          return t.tag === 3 ? t.stateNode.containerInfo : null;
        e = null;
      } else t !== e && (e = null);
    return ((io = e), null);
  }
  function Sl(e) {
    switch (e) {
      case "cancel":
      case "click":
      case "close":
      case "contextmenu":
      case "copy":
      case "cut":
      case "auxclick":
      case "dblclick":
      case "dragend":
      case "dragstart":
      case "drop":
      case "focusin":
      case "focusout":
      case "input":
      case "invalid":
      case "keydown":
      case "keypress":
      case "keyup":
      case "mousedown":
      case "mouseup":
      case "paste":
      case "pause":
      case "play":
      case "pointercancel":
      case "pointerdown":
      case "pointerup":
      case "ratechange":
      case "reset":
      case "resize":
      case "seeked":
      case "submit":
      case "touchcancel":
      case "touchend":
      case "touchstart":
      case "volumechange":
      case "change":
      case "selectionchange":
      case "textInput":
      case "compositionstart":
      case "compositionend":
      case "compositionupdate":
      case "beforeblur":
      case "afterblur":
      case "beforeinput":
      case "blur":
      case "fullscreenchange":
      case "focus":
      case "hashchange":
      case "popstate":
      case "select":
      case "selectstart":
        return 1;
      case "drag":
      case "dragenter":
      case "dragexit":
      case "dragleave":
      case "dragover":
      case "mousemove":
      case "mouseout":
      case "mouseover":
      case "pointermove":
      case "pointerout":
      case "pointerover":
      case "scroll":
      case "toggle":
      case "touchmove":
      case "wheel":
      case "mouseenter":
      case "mouseleave":
      case "pointerenter":
      case "pointerleave":
        return 4;
      case "message":
        switch (uf()) {
          case Si:
            return 1;
          case dl:
            return 4;
          case qr:
          case cf:
            return 16;
          case fl:
            return 536870912;
          default:
            return 16;
        }
      default:
        return 16;
    }
  }
  var Zt = null,
    _i = null,
    so = null;
  function bl() {
    if (so) return so;
    var e,
      t = _i,
      n = t.length,
      r,
      o = "value" in Zt ? Zt.value : Zt.textContent,
      i = o.length;
    for (e = 0; e < n && t[e] === o[e]; e++);
    var c = n - e;
    for (r = 1; r <= c && t[n - r] === o[i - r]; r++);
    return (so = o.slice(e, 1 < r ? 1 - r : void 0));
  }
  function ao(e) {
    var t = e.keyCode;
    return (
      "charCode" in e
        ? ((e = e.charCode), e === 0 && t === 13 && (e = 13))
        : (e = t),
      e === 10 && (e = 13),
      32 <= e || e === 13 ? e : 0
    );
  }
  function lo() {
    return !0;
  }
  function El() {
    return !1;
  }
  function lt(e) {
    function t(n, r, o, i, c) {
      ((this._reactName = n),
        (this._targetInst = o),
        (this.type = r),
        (this.nativeEvent = i),
        (this.target = c),
        (this.currentTarget = null));
      for (var f in e)
        e.hasOwnProperty(f) && ((n = e[f]), (this[f] = n ? n(i) : i[f]));
      return (
        (this.isDefaultPrevented = (
          i.defaultPrevented != null ? i.defaultPrevented : i.returnValue === !1
        )
          ? lo
          : El),
        (this.isPropagationStopped = El),
        this
      );
    }
    return (
      _(t.prototype, {
        preventDefault: function () {
          this.defaultPrevented = !0;
          var n = this.nativeEvent;
          n &&
            (n.preventDefault
              ? n.preventDefault()
              : typeof n.returnValue != "unknown" && (n.returnValue = !1),
            (this.isDefaultPrevented = lo));
        },
        stopPropagation: function () {
          var n = this.nativeEvent;
          n &&
            (n.stopPropagation
              ? n.stopPropagation()
              : typeof n.cancelBubble != "unknown" && (n.cancelBubble = !0),
            (this.isPropagationStopped = lo));
        },
        persist: function () {},
        isPersistent: lo,
      }),
      t
    );
  }
  var Nn = {
      eventPhase: 0,
      bubbles: 0,
      cancelable: 0,
      timeStamp: function (e) {
        return e.timeStamp || Date.now();
      },
      defaultPrevented: 0,
      isTrusted: 0,
    },
    Ti = lt(Nn),
    vr = _({}, Nn, { view: 0, detail: 0 }),
    bf = lt(vr),
    Ri,
    Li,
    wr,
    uo = _({}, vr, {
      screenX: 0,
      screenY: 0,
      clientX: 0,
      clientY: 0,
      pageX: 0,
      pageY: 0,
      ctrlKey: 0,
      shiftKey: 0,
      altKey: 0,
      metaKey: 0,
      getModifierState: Oi,
      button: 0,
      buttons: 0,
      relatedTarget: function (e) {
        return e.relatedTarget === void 0
          ? e.fromElement === e.srcElement
            ? e.toElement
            : e.fromElement
          : e.relatedTarget;
      },
      movementX: function (e) {
        return "movementX" in e
          ? e.movementX
          : (e !== wr &&
              (wr && e.type === "mousemove"
                ? ((Ri = e.screenX - wr.screenX), (Li = e.screenY - wr.screenY))
                : (Li = Ri = 0),
              (wr = e)),
            Ri);
      },
      movementY: function (e) {
        return "movementY" in e ? e.movementY : Li;
      },
    }),
    jl = lt(uo),
    Ef = _({}, uo, { dataTransfer: 0 }),
    jf = lt(Ef),
    Cf = _({}, vr, { relatedTarget: 0 }),
    Mi = lt(Cf),
    Af = _({}, Nn, { animationName: 0, elapsedTime: 0, pseudoElement: 0 }),
    Pf = lt(Af),
    zf = _({}, Nn, {
      clipboardData: function (e) {
        return "clipboardData" in e ? e.clipboardData : window.clipboardData;
      },
    }),
    _f = lt(zf),
    Tf = _({}, Nn, { data: 0 }),
    Cl = lt(Tf),
    Rf = {
      Esc: "Escape",
      Spacebar: " ",
      Left: "ArrowLeft",
      Up: "ArrowUp",
      Right: "ArrowRight",
      Down: "ArrowDown",
      Del: "Delete",
      Win: "OS",
      Menu: "ContextMenu",
      Apps: "ContextMenu",
      Scroll: "ScrollLock",
      MozPrintableKey: "Unidentified",
    },
    Lf = {
      8: "Backspace",
      9: "Tab",
      12: "Clear",
      13: "Enter",
      16: "Shift",
      17: "Control",
      18: "Alt",
      19: "Pause",
      20: "CapsLock",
      27: "Escape",
      32: " ",
      33: "PageUp",
      34: "PageDown",
      35: "End",
      36: "Home",
      37: "ArrowLeft",
      38: "ArrowUp",
      39: "ArrowRight",
      40: "ArrowDown",
      45: "Insert",
      46: "Delete",
      112: "F1",
      113: "F2",
      114: "F3",
      115: "F4",
      116: "F5",
      117: "F6",
      118: "F7",
      119: "F8",
      120: "F9",
      121: "F10",
      122: "F11",
      123: "F12",
      144: "NumLock",
      145: "ScrollLock",
      224: "Meta",
    },
    Mf = {
      Alt: "altKey",
      Control: "ctrlKey",
      Meta: "metaKey",
      Shift: "shiftKey",
    };
  function Of(e) {
    var t = this.nativeEvent;
    return t.getModifierState
      ? t.getModifierState(e)
      : (e = Mf[e])
        ? !!t[e]
        : !1;
  }
  function Oi() {
    return Of;
  }
  var Nf = _({}, vr, {
      key: function (e) {
        if (e.key) {
          var t = Rf[e.key] || e.key;
          if (t !== "Unidentified") return t;
        }
        return e.type === "keypress"
          ? ((e = ao(e)), e === 13 ? "Enter" : String.fromCharCode(e))
          : e.type === "keydown" || e.type === "keyup"
            ? Lf[e.keyCode] || "Unidentified"
            : "";
      },
      code: 0,
      location: 0,
      ctrlKey: 0,
      shiftKey: 0,
      altKey: 0,
      metaKey: 0,
      repeat: 0,
      locale: 0,
      getModifierState: Oi,
      charCode: function (e) {
        return e.type === "keypress" ? ao(e) : 0;
      },
      keyCode: function (e) {
        return e.type === "keydown" || e.type === "keyup" ? e.keyCode : 0;
      },
      which: function (e) {
        return e.type === "keypress"
          ? ao(e)
          : e.type === "keydown" || e.type === "keyup"
            ? e.keyCode
            : 0;
      },
    }),
    If = lt(Nf),
    Df = _({}, uo, {
      pointerId: 0,
      width: 0,
      height: 0,
      pressure: 0,
      tangentialPressure: 0,
      tiltX: 0,
      tiltY: 0,
      twist: 0,
      pointerType: 0,
      isPrimary: 0,
    }),
    Al = lt(Df),
    Uf = _({}, vr, {
      touches: 0,
      targetTouches: 0,
      changedTouches: 0,
      altKey: 0,
      metaKey: 0,
      ctrlKey: 0,
      shiftKey: 0,
      getModifierState: Oi,
    }),
    Ff = lt(Uf),
    Wf = _({}, Nn, { propertyName: 0, elapsedTime: 0, pseudoElement: 0 }),
    $f = lt(Wf),
    Bf = _({}, uo, {
      deltaX: function (e) {
        return "deltaX" in e
          ? e.deltaX
          : "wheelDeltaX" in e
            ? -e.wheelDeltaX
            : 0;
      },
      deltaY: function (e) {
        return "deltaY" in e
          ? e.deltaY
          : "wheelDeltaY" in e
            ? -e.wheelDeltaY
            : "wheelDelta" in e
              ? -e.wheelDelta
              : 0;
      },
      deltaZ: 0,
      deltaMode: 0,
    }),
    Hf = lt(Bf),
    Vf = [9, 13, 27, 32],
    Ni = j && "CompositionEvent" in window,
    xr = null;
  j && "documentMode" in document && (xr = document.documentMode);
  var Kf = j && "TextEvent" in window && !xr,
    Pl = j && (!Ni || (xr && 8 < xr && 11 >= xr)),
    zl = " ",
    _l = !1;
  function Tl(e, t) {
    switch (e) {
      case "keyup":
        return Vf.indexOf(t.keyCode) !== -1;
      case "keydown":
        return t.keyCode !== 229;
      case "keypress":
      case "mousedown":
      case "focusout":
        return !0;
      default:
        return !1;
    }
  }
  function Rl(e) {
    return (
      (e = e.detail),
      typeof e == "object" && "data" in e ? e.data : null
    );
  }
  var In = !1;
  function Gf(e, t) {
    switch (e) {
      case "compositionend":
        return Rl(t);
      case "keypress":
        return t.which !== 32 ? null : ((_l = !0), zl);
      case "textInput":
        return ((e = t.data), e === zl && _l ? null : e);
      default:
        return null;
    }
  }
  function Qf(e, t) {
    if (In)
      return e === "compositionend" || (!Ni && Tl(e, t))
        ? ((e = bl()), (so = _i = Zt = null), (In = !1), e)
        : null;
    switch (e) {
      case "paste":
        return null;
      case "keypress":
        if (!(t.ctrlKey || t.altKey || t.metaKey) || (t.ctrlKey && t.altKey)) {
          if (t.char && 1 < t.char.length) return t.char;
          if (t.which) return String.fromCharCode(t.which);
        }
        return null;
      case "compositionend":
        return Pl && t.locale !== "ko" ? null : t.data;
      default:
        return null;
    }
  }
  var Zf = {
    color: !0,
    date: !0,
    datetime: !0,
    "datetime-local": !0,
    email: !0,
    month: !0,
    number: !0,
    password: !0,
    range: !0,
    search: !0,
    tel: !0,
    text: !0,
    time: !0,
    url: !0,
    week: !0,
  };
  function Ll(e) {
    var t = e && e.nodeName && e.nodeName.toLowerCase();
    return t === "input" ? !!Zf[e.type] : t === "textarea";
  }
  function Ml(e, t, n, r) {
    (el(r),
      (t = ho(t, "onChange")),
      0 < t.length &&
        ((n = new Ti("onChange", "change", null, n, r)),
        e.push({ event: n, listeners: t })));
  }
  var kr = null,
    Sr = null;
  function Yf(e) {
    Xl(e, 0);
  }
  function co(e) {
    var t = $n(e);
    if (He(t)) return e;
  }
  function qf(e, t) {
    if (e === "change") return t;
  }
  var Ol = !1;
  if (j) {
    var Ii;
    if (j) {
      var Di = "oninput" in document;
      if (!Di) {
        var Nl = document.createElement("div");
        (Nl.setAttribute("oninput", "return;"),
          (Di = typeof Nl.oninput == "function"));
      }
      Ii = Di;
    } else Ii = !1;
    Ol = Ii && (!document.documentMode || 9 < document.documentMode);
  }
  function Il() {
    kr && (kr.detachEvent("onpropertychange", Dl), (Sr = kr = null));
  }
  function Dl(e) {
    if (e.propertyName === "value" && co(Sr)) {
      var t = [];
      (Ml(t, Sr, e, yi(e)), ol(Yf, t));
    }
  }
  function Xf(e, t, n) {
    e === "focusin"
      ? (Il(), (kr = t), (Sr = n), kr.attachEvent("onpropertychange", Dl))
      : e === "focusout" && Il();
  }
  function Jf(e) {
    if (e === "selectionchange" || e === "keyup" || e === "keydown")
      return co(Sr);
  }
  function ep(e, t) {
    if (e === "click") return co(t);
  }
  function tp(e, t) {
    if (e === "input" || e === "change") return co(t);
  }
  function np(e, t) {
    return (e === t && (e !== 0 || 1 / e === 1 / t)) || (e !== e && t !== t);
  }
  var kt = typeof Object.is == "function" ? Object.is : np;
  function br(e, t) {
    if (kt(e, t)) return !0;
    if (
      typeof e != "object" ||
      e === null ||
      typeof t != "object" ||
      t === null
    )
      return !1;
    var n = Object.keys(e),
      r = Object.keys(t);
    if (n.length !== r.length) return !1;
    for (r = 0; r < n.length; r++) {
      var o = n[r];
      if (!k.call(t, o) || !kt(e[o], t[o])) return !1;
    }
    return !0;
  }
  function Ul(e) {
    for (; e && e.firstChild;) e = e.firstChild;
    return e;
  }
  function Fl(e, t) {
    var n = Ul(e);
    e = 0;
    for (var r; n;) {
      if (n.nodeType === 3) {
        if (((r = e + n.textContent.length), e <= t && r >= t))
          return { node: n, offset: t - e };
        e = r;
      }
      e: {
        for (; n;) {
          if (n.nextSibling) {
            n = n.nextSibling;
            break e;
          }
          n = n.parentNode;
        }
        n = void 0;
      }
      n = Ul(n);
    }
  }
  function Wl(e, t) {
    return e && t
      ? e === t
        ? !0
        : e && e.nodeType === 3
          ? !1
          : t && t.nodeType === 3
            ? Wl(e, t.parentNode)
            : "contains" in e
              ? e.contains(t)
              : e.compareDocumentPosition
                ? !!(e.compareDocumentPosition(t) & 16)
                : !1
      : !1;
  }
  function $l() {
    for (var e = window, t = Pe(); t instanceof e.HTMLIFrameElement;) {
      try {
        var n = typeof t.contentWindow.location.href == "string";
      } catch {
        n = !1;
      }
      if (n) e = t.contentWindow;
      else break;
      t = Pe(e.document);
    }
    return t;
  }
  function Ui(e) {
    var t = e && e.nodeName && e.nodeName.toLowerCase();
    return (
      t &&
      ((t === "input" &&
        (e.type === "text" ||
          e.type === "search" ||
          e.type === "tel" ||
          e.type === "url" ||
          e.type === "password")) ||
        t === "textarea" ||
        e.contentEditable === "true")
    );
  }
  function rp(e) {
    var t = $l(),
      n = e.focusedElem,
      r = e.selectionRange;
    if (
      t !== n &&
      n &&
      n.ownerDocument &&
      Wl(n.ownerDocument.documentElement, n)
    ) {
      if (r !== null && Ui(n)) {
        if (
          ((t = r.start),
          (e = r.end),
          e === void 0 && (e = t),
          "selectionStart" in n)
        )
          ((n.selectionStart = t),
            (n.selectionEnd = Math.min(e, n.value.length)));
        else if (
          ((e = ((t = n.ownerDocument || document) && t.defaultView) || window),
          e.getSelection)
        ) {
          e = e.getSelection();
          var o = n.textContent.length,
            i = Math.min(r.start, o);
          ((r = r.end === void 0 ? i : Math.min(r.end, o)),
            !e.extend && i > r && ((o = r), (r = i), (i = o)),
            (o = Fl(n, i)));
          var c = Fl(n, r);
          o &&
            c &&
            (e.rangeCount !== 1 ||
              e.anchorNode !== o.node ||
              e.anchorOffset !== o.offset ||
              e.focusNode !== c.node ||
              e.focusOffset !== c.offset) &&
            ((t = t.createRange()),
            t.setStart(o.node, o.offset),
            e.removeAllRanges(),
            i > r
              ? (e.addRange(t), e.extend(c.node, c.offset))
              : (t.setEnd(c.node, c.offset), e.addRange(t)));
        }
      }
      for (t = [], e = n; (e = e.parentNode);)
        e.nodeType === 1 &&
          t.push({ element: e, left: e.scrollLeft, top: e.scrollTop });
      for (typeof n.focus == "function" && n.focus(), n = 0; n < t.length; n++)
        ((e = t[n]),
          (e.element.scrollLeft = e.left),
          (e.element.scrollTop = e.top));
    }
  }
  var op = j && "documentMode" in document && 11 >= document.documentMode,
    Dn = null,
    Fi = null,
    Er = null,
    Wi = !1;
  function Bl(e, t, n) {
    var r =
      n.window === n ? n.document : n.nodeType === 9 ? n : n.ownerDocument;
    Wi ||
      Dn == null ||
      Dn !== Pe(r) ||
      ((r = Dn),
      "selectionStart" in r && Ui(r)
        ? (r = { start: r.selectionStart, end: r.selectionEnd })
        : ((r = (
            (r.ownerDocument && r.ownerDocument.defaultView) ||
            window
          ).getSelection()),
          (r = {
            anchorNode: r.anchorNode,
            anchorOffset: r.anchorOffset,
            focusNode: r.focusNode,
            focusOffset: r.focusOffset,
          })),
      (Er && br(Er, r)) ||
        ((Er = r),
        (r = ho(Fi, "onSelect")),
        0 < r.length &&
          ((t = new Ti("onSelect", "select", null, t, n)),
          e.push({ event: t, listeners: r }),
          (t.target = Dn))));
  }
  function fo(e, t) {
    var n = {};
    return (
      (n[e.toLowerCase()] = t.toLowerCase()),
      (n["Webkit" + e] = "webkit" + t),
      (n["Moz" + e] = "moz" + t),
      n
    );
  }
  var Un = {
      animationend: fo("Animation", "AnimationEnd"),
      animationiteration: fo("Animation", "AnimationIteration"),
      animationstart: fo("Animation", "AnimationStart"),
      transitionend: fo("Transition", "TransitionEnd"),
    },
    $i = {},
    Hl = {};
  j &&
    ((Hl = document.createElement("div").style),
    "AnimationEvent" in window ||
      (delete Un.animationend.animation,
      delete Un.animationiteration.animation,
      delete Un.animationstart.animation),
    "TransitionEvent" in window || delete Un.transitionend.transition);
  function po(e) {
    if ($i[e]) return $i[e];
    if (!Un[e]) return e;
    var t = Un[e],
      n;
    for (n in t) if (t.hasOwnProperty(n) && n in Hl) return ($i[e] = t[n]);
    return e;
  }
  var Vl = po("animationend"),
    Kl = po("animationiteration"),
    Gl = po("animationstart"),
    Ql = po("transitionend"),
    Zl = new Map(),
    Yl =
      "abort auxClick cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(
        " ",
      );
  function Yt(e, t) {
    (Zl.set(e, t), y(t, [e]));
  }
  for (var Bi = 0; Bi < Yl.length; Bi++) {
    var Hi = Yl[Bi],
      ip = Hi.toLowerCase(),
      sp = Hi[0].toUpperCase() + Hi.slice(1);
    Yt(ip, "on" + sp);
  }
  (Yt(Vl, "onAnimationEnd"),
    Yt(Kl, "onAnimationIteration"),
    Yt(Gl, "onAnimationStart"),
    Yt("dblclick", "onDoubleClick"),
    Yt("focusin", "onFocus"),
    Yt("focusout", "onBlur"),
    Yt(Ql, "onTransitionEnd"),
    S("onMouseEnter", ["mouseout", "mouseover"]),
    S("onMouseLeave", ["mouseout", "mouseover"]),
    S("onPointerEnter", ["pointerout", "pointerover"]),
    S("onPointerLeave", ["pointerout", "pointerover"]),
    y(
      "onChange",
      "change click focusin focusout input keydown keyup selectionchange".split(
        " ",
      ),
    ),
    y(
      "onSelect",
      "focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(
        " ",
      ),
    ),
    y("onBeforeInput", ["compositionend", "keypress", "textInput", "paste"]),
    y(
      "onCompositionEnd",
      "compositionend focusout keydown keypress keyup mousedown".split(" "),
    ),
    y(
      "onCompositionStart",
      "compositionstart focusout keydown keypress keyup mousedown".split(" "),
    ),
    y(
      "onCompositionUpdate",
      "compositionupdate focusout keydown keypress keyup mousedown".split(" "),
    ));
  var jr =
      "abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(
        " ",
      ),
    ap = new Set(
      "cancel close invalid load scroll toggle".split(" ").concat(jr),
    );
  function ql(e, t, n) {
    var r = e.type || "unknown-event";
    ((e.currentTarget = n), of(r, t, void 0, e), (e.currentTarget = null));
  }
  function Xl(e, t) {
    t = (t & 4) !== 0;
    for (var n = 0; n < e.length; n++) {
      var r = e[n],
        o = r.event;
      r = r.listeners;
      e: {
        var i = void 0;
        if (t)
          for (var c = r.length - 1; 0 <= c; c--) {
            var f = r[c],
              m = f.instance,
              x = f.currentTarget;
            if (((f = f.listener), m !== i && o.isPropagationStopped()))
              break e;
            (ql(o, f, x), (i = m));
          }
        else
          for (c = 0; c < r.length; c++) {
            if (
              ((f = r[c]),
              (m = f.instance),
              (x = f.currentTarget),
              (f = f.listener),
              m !== i && o.isPropagationStopped())
            )
              break e;
            (ql(o, f, x), (i = m));
          }
      }
    }
    if (Yr) throw ((e = ki), (Yr = !1), (ki = null), e);
  }
  function ke(e, t) {
    var n = t[Xi];
    n === void 0 && (n = t[Xi] = new Set());
    var r = e + "__bubble";
    n.has(r) || (Jl(t, e, 2, !1), n.add(r));
  }
  function Vi(e, t, n) {
    var r = 0;
    (t && (r |= 4), Jl(n, e, r, t));
  }
  var mo = "_reactListening" + Math.random().toString(36).slice(2);
  function Cr(e) {
    if (!e[mo]) {
      ((e[mo] = !0),
        d.forEach(function (n) {
          n !== "selectionchange" && (ap.has(n) || Vi(n, !1, e), Vi(n, !0, e));
        }));
      var t = e.nodeType === 9 ? e : e.ownerDocument;
      t === null || t[mo] || ((t[mo] = !0), Vi("selectionchange", !1, t));
    }
  }
  function Jl(e, t, n, r) {
    switch (Sl(t)) {
      case 1:
        var o = kf;
        break;
      case 4:
        o = Sf;
        break;
      default:
        o = Pi;
    }
    ((n = o.bind(null, t, n, e)),
      (o = void 0),
      !xi ||
        (t !== "touchstart" && t !== "touchmove" && t !== "wheel") ||
        (o = !0),
      r
        ? o !== void 0
          ? e.addEventListener(t, n, { capture: !0, passive: o })
          : e.addEventListener(t, n, !0)
        : o !== void 0
          ? e.addEventListener(t, n, { passive: o })
          : e.addEventListener(t, n, !1));
  }
  function Ki(e, t, n, r, o) {
    var i = r;
    if ((t & 1) === 0 && (t & 2) === 0 && r !== null)
      e: for (;;) {
        if (r === null) return;
        var c = r.tag;
        if (c === 3 || c === 4) {
          var f = r.stateNode.containerInfo;
          if (f === o || (f.nodeType === 8 && f.parentNode === o)) break;
          if (c === 4)
            for (c = r.return; c !== null;) {
              var m = c.tag;
              if (
                (m === 3 || m === 4) &&
                ((m = c.stateNode.containerInfo),
                m === o || (m.nodeType === 8 && m.parentNode === o))
              )
                return;
              c = c.return;
            }
          for (; f !== null;) {
            if (((c = mn(f)), c === null)) return;
            if (((m = c.tag), m === 5 || m === 6)) {
              r = i = c;
              continue e;
            }
            f = f.parentNode;
          }
        }
        r = r.return;
      }
    ol(function () {
      var x = i,
        A = yi(n),
        P = [];
      e: {
        var C = Zl.get(e);
        if (C !== void 0) {
          var L = Ti,
            N = e;
          switch (e) {
            case "keypress":
              if (ao(n) === 0) break e;
            case "keydown":
            case "keyup":
              L = If;
              break;
            case "focusin":
              ((N = "focus"), (L = Mi));
              break;
            case "focusout":
              ((N = "blur"), (L = Mi));
              break;
            case "beforeblur":
            case "afterblur":
              L = Mi;
              break;
            case "click":
              if (n.button === 2) break e;
            case "auxclick":
            case "dblclick":
            case "mousedown":
            case "mousemove":
            case "mouseup":
            case "mouseout":
            case "mouseover":
            case "contextmenu":
              L = jl;
              break;
            case "drag":
            case "dragend":
            case "dragenter":
            case "dragexit":
            case "dragleave":
            case "dragover":
            case "dragstart":
            case "drop":
              L = jf;
              break;
            case "touchcancel":
            case "touchend":
            case "touchmove":
            case "touchstart":
              L = Ff;
              break;
            case Vl:
            case Kl:
            case Gl:
              L = Pf;
              break;
            case Ql:
              L = $f;
              break;
            case "scroll":
              L = bf;
              break;
            case "wheel":
              L = Hf;
              break;
            case "copy":
            case "cut":
            case "paste":
              L = _f;
              break;
            case "gotpointercapture":
            case "lostpointercapture":
            case "pointercancel":
            case "pointerdown":
            case "pointermove":
            case "pointerout":
            case "pointerover":
            case "pointerup":
              L = Al;
          }
          var U = (t & 4) !== 0,
            Oe = !U && e === "scroll",
            v = U ? (C !== null ? C + "Capture" : null) : C;
          U = [];
          for (var h = x, w; h !== null;) {
            w = h;
            var z = w.stateNode;
            if (
              (w.tag === 5 &&
                z !== null &&
                ((w = z),
                v !== null &&
                  ((z = lr(h, v)), z != null && U.push(Ar(h, z, w)))),
              Oe)
            )
              break;
            h = h.return;
          }
          0 < U.length &&
            ((C = new L(C, N, null, n, A)), P.push({ event: C, listeners: U }));
        }
      }
      if ((t & 7) === 0) {
        e: {
          if (
            ((C = e === "mouseover" || e === "pointerover"),
            (L = e === "mouseout" || e === "pointerout"),
            C &&
              n !== gi &&
              (N = n.relatedTarget || n.fromElement) &&
              (mn(N) || N[Ot]))
          )
            break e;
          if (
            (L || C) &&
            ((C =
              A.window === A
                ? A
                : (C = A.ownerDocument)
                  ? C.defaultView || C.parentWindow
                  : window),
            L
              ? ((N = n.relatedTarget || n.toElement),
                (L = x),
                (N = N ? mn(N) : null),
                N !== null &&
                  ((Oe = pn(N)), N !== Oe || (N.tag !== 5 && N.tag !== 6)) &&
                  (N = null))
              : ((L = null), (N = x)),
            L !== N)
          ) {
            if (
              ((U = jl),
              (z = "onMouseLeave"),
              (v = "onMouseEnter"),
              (h = "mouse"),
              (e === "pointerout" || e === "pointerover") &&
                ((U = Al),
                (z = "onPointerLeave"),
                (v = "onPointerEnter"),
                (h = "pointer")),
              (Oe = L == null ? C : $n(L)),
              (w = N == null ? C : $n(N)),
              (C = new U(z, h + "leave", L, n, A)),
              (C.target = Oe),
              (C.relatedTarget = w),
              (z = null),
              mn(A) === x &&
                ((U = new U(v, h + "enter", N, n, A)),
                (U.target = w),
                (U.relatedTarget = Oe),
                (z = U)),
              (Oe = z),
              L && N)
            )
              t: {
                for (U = L, v = N, h = 0, w = U; w; w = Fn(w)) h++;
                for (w = 0, z = v; z; z = Fn(z)) w++;
                for (; 0 < h - w;) ((U = Fn(U)), h--);
                for (; 0 < w - h;) ((v = Fn(v)), w--);
                for (; h--;) {
                  if (U === v || (v !== null && U === v.alternate)) break t;
                  ((U = Fn(U)), (v = Fn(v)));
                }
                U = null;
              }
            else U = null;
            (L !== null && eu(P, C, L, U, !1),
              N !== null && Oe !== null && eu(P, Oe, N, U, !0));
          }
        }
        e: {
          if (
            ((C = x ? $n(x) : window),
            (L = C.nodeName && C.nodeName.toLowerCase()),
            L === "select" || (L === "input" && C.type === "file"))
          )
            var W = qf;
          else if (Ll(C))
            if (Ol) W = tp;
            else {
              W = Jf;
              var G = Xf;
            }
          else
            (L = C.nodeName) &&
              L.toLowerCase() === "input" &&
              (C.type === "checkbox" || C.type === "radio") &&
              (W = ep);
          if (W && (W = W(e, x))) {
            Ml(P, W, n, A);
            break e;
          }
          (G && G(e, C, x),
            e === "focusout" &&
              (G = C._wrapperState) &&
              G.controlled &&
              C.type === "number" &&
              di(C, "number", C.value));
        }
        switch (((G = x ? $n(x) : window), e)) {
          case "focusin":
            (Ll(G) || G.contentEditable === "true") &&
              ((Dn = G), (Fi = x), (Er = null));
            break;
          case "focusout":
            Er = Fi = Dn = null;
            break;
          case "mousedown":
            Wi = !0;
            break;
          case "contextmenu":
          case "mouseup":
          case "dragend":
            ((Wi = !1), Bl(P, n, A));
            break;
          case "selectionchange":
            if (op) break;
          case "keydown":
          case "keyup":
            Bl(P, n, A);
        }
        var Q;
        if (Ni)
          e: {
            switch (e) {
              case "compositionstart":
                var J = "onCompositionStart";
                break e;
              case "compositionend":
                J = "onCompositionEnd";
                break e;
              case "compositionupdate":
                J = "onCompositionUpdate";
                break e;
            }
            J = void 0;
          }
        else
          In
            ? Tl(e, n) && (J = "onCompositionEnd")
            : e === "keydown" &&
              n.keyCode === 229 &&
              (J = "onCompositionStart");
        (J &&
          (Pl &&
            n.locale !== "ko" &&
            (In || J !== "onCompositionStart"
              ? J === "onCompositionEnd" && In && (Q = bl())
              : ((Zt = A),
                (_i = "value" in Zt ? Zt.value : Zt.textContent),
                (In = !0))),
          (G = ho(x, J)),
          0 < G.length &&
            ((J = new Cl(J, e, null, n, A)),
            P.push({ event: J, listeners: G }),
            Q ? (J.data = Q) : ((Q = Rl(n)), Q !== null && (J.data = Q)))),
          (Q = Kf ? Gf(e, n) : Qf(e, n)) &&
            ((x = ho(x, "onBeforeInput")),
            0 < x.length &&
              ((A = new Cl("onBeforeInput", "beforeinput", null, n, A)),
              P.push({ event: A, listeners: x }),
              (A.data = Q))));
      }
      Xl(P, t);
    });
  }
  function Ar(e, t, n) {
    return { instance: e, listener: t, currentTarget: n };
  }
  function ho(e, t) {
    for (var n = t + "Capture", r = []; e !== null;) {
      var o = e,
        i = o.stateNode;
      (o.tag === 5 &&
        i !== null &&
        ((o = i),
        (i = lr(e, n)),
        i != null && r.unshift(Ar(e, i, o)),
        (i = lr(e, t)),
        i != null && r.push(Ar(e, i, o))),
        (e = e.return));
    }
    return r;
  }
  function Fn(e) {
    if (e === null) return null;
    do e = e.return;
    while (e && e.tag !== 5);
    return e || null;
  }
  function eu(e, t, n, r, o) {
    for (var i = t._reactName, c = []; n !== null && n !== r;) {
      var f = n,
        m = f.alternate,
        x = f.stateNode;
      if (m !== null && m === r) break;
      (f.tag === 5 &&
        x !== null &&
        ((f = x),
        o
          ? ((m = lr(n, i)), m != null && c.unshift(Ar(n, m, f)))
          : o || ((m = lr(n, i)), m != null && c.push(Ar(n, m, f)))),
        (n = n.return));
    }
    c.length !== 0 && e.push({ event: t, listeners: c });
  }
  var lp = /\r\n?/g,
    up = /\u0000|\uFFFD/g;
  function tu(e) {
    return (typeof e == "string" ? e : "" + e)
      .replace(
        lp,
        `
`,
      )
      .replace(up, "");
  }
  function go(e, t, n) {
    if (((t = tu(t)), tu(e) !== t && n)) throw Error(l(425));
  }
  function yo() {}
  var Gi = null,
    Qi = null;
  function Zi(e, t) {
    return (
      e === "textarea" ||
      e === "noscript" ||
      typeof t.children == "string" ||
      typeof t.children == "number" ||
      (typeof t.dangerouslySetInnerHTML == "object" &&
        t.dangerouslySetInnerHTML !== null &&
        t.dangerouslySetInnerHTML.__html != null)
    );
  }
  var Yi = typeof setTimeout == "function" ? setTimeout : void 0,
    cp = typeof clearTimeout == "function" ? clearTimeout : void 0,
    nu = typeof Promise == "function" ? Promise : void 0,
    dp =
      typeof queueMicrotask == "function"
        ? queueMicrotask
        : typeof nu < "u"
          ? function (e) {
              return nu.resolve(null).then(e).catch(fp);
            }
          : Yi;
  function fp(e) {
    setTimeout(function () {
      throw e;
    });
  }
  function qi(e, t) {
    var n = t,
      r = 0;
    do {
      var o = n.nextSibling;
      if ((e.removeChild(n), o && o.nodeType === 8))
        if (((n = o.data), n === "/$")) {
          if (r === 0) {
            (e.removeChild(o), yr(t));
            return;
          }
          r--;
        } else (n !== "$" && n !== "$?" && n !== "$!") || r++;
      n = o;
    } while (n);
    yr(t);
  }
  function qt(e) {
    for (; e != null; e = e.nextSibling) {
      var t = e.nodeType;
      if (t === 1 || t === 3) break;
      if (t === 8) {
        if (((t = e.data), t === "$" || t === "$!" || t === "$?")) break;
        if (t === "/$") return null;
      }
    }
    return e;
  }
  function ru(e) {
    e = e.previousSibling;
    for (var t = 0; e;) {
      if (e.nodeType === 8) {
        var n = e.data;
        if (n === "$" || n === "$!" || n === "$?") {
          if (t === 0) return e;
          t--;
        } else n === "/$" && t++;
      }
      e = e.previousSibling;
    }
    return null;
  }
  var Wn = Math.random().toString(36).slice(2),
    zt = "__reactFiber$" + Wn,
    Pr = "__reactProps$" + Wn,
    Ot = "__reactContainer$" + Wn,
    Xi = "__reactEvents$" + Wn,
    pp = "__reactListeners$" + Wn,
    mp = "__reactHandles$" + Wn;
  function mn(e) {
    var t = e[zt];
    if (t) return t;
    for (var n = e.parentNode; n;) {
      if ((t = n[Ot] || n[zt])) {
        if (
          ((n = t.alternate),
          t.child !== null || (n !== null && n.child !== null))
        )
          for (e = ru(e); e !== null;) {
            if ((n = e[zt])) return n;
            e = ru(e);
          }
        return t;
      }
      ((e = n), (n = e.parentNode));
    }
    return null;
  }
  function zr(e) {
    return (
      (e = e[zt] || e[Ot]),
      !e || (e.tag !== 5 && e.tag !== 6 && e.tag !== 13 && e.tag !== 3)
        ? null
        : e
    );
  }
  function $n(e) {
    if (e.tag === 5 || e.tag === 6) return e.stateNode;
    throw Error(l(33));
  }
  function vo(e) {
    return e[Pr] || null;
  }
  var Ji = [],
    Bn = -1;
  function Xt(e) {
    return { current: e };
  }
  function Se(e) {
    0 > Bn || ((e.current = Ji[Bn]), (Ji[Bn] = null), Bn--);
  }
  function xe(e, t) {
    (Bn++, (Ji[Bn] = e.current), (e.current = t));
  }
  var Jt = {},
    Ge = Xt(Jt),
    tt = Xt(!1),
    hn = Jt;
  function Hn(e, t) {
    var n = e.type.contextTypes;
    if (!n) return Jt;
    var r = e.stateNode;
    if (r && r.__reactInternalMemoizedUnmaskedChildContext === t)
      return r.__reactInternalMemoizedMaskedChildContext;
    var o = {},
      i;
    for (i in n) o[i] = t[i];
    return (
      r &&
        ((e = e.stateNode),
        (e.__reactInternalMemoizedUnmaskedChildContext = t),
        (e.__reactInternalMemoizedMaskedChildContext = o)),
      o
    );
  }
  function nt(e) {
    return ((e = e.childContextTypes), e != null);
  }
  function wo() {
    (Se(tt), Se(Ge));
  }
  function ou(e, t, n) {
    if (Ge.current !== Jt) throw Error(l(168));
    (xe(Ge, t), xe(tt, n));
  }
  function iu(e, t, n) {
    var r = e.stateNode;
    if (((t = t.childContextTypes), typeof r.getChildContext != "function"))
      return n;
    r = r.getChildContext();
    for (var o in r) if (!(o in t)) throw Error(l(108, ve(e) || "Unknown", o));
    return _({}, n, r);
  }
  function xo(e) {
    return (
      (e =
        ((e = e.stateNode) && e.__reactInternalMemoizedMergedChildContext) ||
        Jt),
      (hn = Ge.current),
      xe(Ge, e),
      xe(tt, tt.current),
      !0
    );
  }
  function su(e, t, n) {
    var r = e.stateNode;
    if (!r) throw Error(l(169));
    (n
      ? ((e = iu(e, t, hn)),
        (r.__reactInternalMemoizedMergedChildContext = e),
        Se(tt),
        Se(Ge),
        xe(Ge, e))
      : Se(tt),
      xe(tt, n));
  }
  var Nt = null,
    ko = !1,
    es = !1;
  function au(e) {
    Nt === null ? (Nt = [e]) : Nt.push(e);
  }
  function hp(e) {
    ((ko = !0), au(e));
  }
  function en() {
    if (!es && Nt !== null) {
      es = !0;
      var e = 0,
        t = ge;
      try {
        var n = Nt;
        for (ge = 1; e < n.length; e++) {
          var r = n[e];
          do r = r(!0);
          while (r !== null);
        }
        ((Nt = null), (ko = !1));
      } catch (o) {
        throw (Nt !== null && (Nt = Nt.slice(e + 1)), ul(Si, en), o);
      } finally {
        ((ge = t), (es = !1));
      }
    }
    return null;
  }
  var Vn = [],
    Kn = 0,
    So = null,
    bo = 0,
    ft = [],
    pt = 0,
    gn = null,
    It = 1,
    Dt = "";
  function yn(e, t) {
    ((Vn[Kn++] = bo), (Vn[Kn++] = So), (So = e), (bo = t));
  }
  function lu(e, t, n) {
    ((ft[pt++] = It), (ft[pt++] = Dt), (ft[pt++] = gn), (gn = e));
    var r = It;
    e = Dt;
    var o = 32 - xt(r) - 1;
    ((r &= ~(1 << o)), (n += 1));
    var i = 32 - xt(t) + o;
    if (30 < i) {
      var c = o - (o % 5);
      ((i = (r & ((1 << c) - 1)).toString(32)),
        (r >>= c),
        (o -= c),
        (It = (1 << (32 - xt(t) + o)) | (n << o) | r),
        (Dt = i + e));
    } else ((It = (1 << i) | (n << o) | r), (Dt = e));
  }
  function ts(e) {
    e.return !== null && (yn(e, 1), lu(e, 1, 0));
  }
  function ns(e) {
    for (; e === So;)
      ((So = Vn[--Kn]), (Vn[Kn] = null), (bo = Vn[--Kn]), (Vn[Kn] = null));
    for (; e === gn;)
      ((gn = ft[--pt]),
        (ft[pt] = null),
        (Dt = ft[--pt]),
        (ft[pt] = null),
        (It = ft[--pt]),
        (ft[pt] = null));
  }
  var ut = null,
    ct = null,
    Ce = !1,
    St = null;
  function uu(e, t) {
    var n = yt(5, null, null, 0);
    ((n.elementType = "DELETED"),
      (n.stateNode = t),
      (n.return = e),
      (t = e.deletions),
      t === null ? ((e.deletions = [n]), (e.flags |= 16)) : t.push(n));
  }
  function cu(e, t) {
    switch (e.tag) {
      case 5:
        var n = e.type;
        return (
          (t =
            t.nodeType !== 1 || n.toLowerCase() !== t.nodeName.toLowerCase()
              ? null
              : t),
          t !== null
            ? ((e.stateNode = t), (ut = e), (ct = qt(t.firstChild)), !0)
            : !1
        );
      case 6:
        return (
          (t = e.pendingProps === "" || t.nodeType !== 3 ? null : t),
          t !== null ? ((e.stateNode = t), (ut = e), (ct = null), !0) : !1
        );
      case 13:
        return (
          (t = t.nodeType !== 8 ? null : t),
          t !== null
            ? ((n = gn !== null ? { id: It, overflow: Dt } : null),
              (e.memoizedState = {
                dehydrated: t,
                treeContext: n,
                retryLane: 1073741824,
              }),
              (n = yt(18, null, null, 0)),
              (n.stateNode = t),
              (n.return = e),
              (e.child = n),
              (ut = e),
              (ct = null),
              !0)
            : !1
        );
      default:
        return !1;
    }
  }
  function rs(e) {
    return (e.mode & 1) !== 0 && (e.flags & 128) === 0;
  }
  function os(e) {
    if (Ce) {
      var t = ct;
      if (t) {
        var n = t;
        if (!cu(e, t)) {
          if (rs(e)) throw Error(l(418));
          t = qt(n.nextSibling);
          var r = ut;
          t && cu(e, t)
            ? uu(r, n)
            : ((e.flags = (e.flags & -4097) | 2), (Ce = !1), (ut = e));
        }
      } else {
        if (rs(e)) throw Error(l(418));
        ((e.flags = (e.flags & -4097) | 2), (Ce = !1), (ut = e));
      }
    }
  }
  function du(e) {
    for (
      e = e.return;
      e !== null && e.tag !== 5 && e.tag !== 3 && e.tag !== 13;
    )
      e = e.return;
    ut = e;
  }
  function Eo(e) {
    if (e !== ut) return !1;
    if (!Ce) return (du(e), (Ce = !0), !1);
    var t;
    if (
      ((t = e.tag !== 3) &&
        !(t = e.tag !== 5) &&
        ((t = e.type),
        (t = t !== "head" && t !== "body" && !Zi(e.type, e.memoizedProps))),
      t && (t = ct))
    ) {
      if (rs(e)) throw (fu(), Error(l(418)));
      for (; t;) (uu(e, t), (t = qt(t.nextSibling)));
    }
    if ((du(e), e.tag === 13)) {
      if (((e = e.memoizedState), (e = e !== null ? e.dehydrated : null), !e))
        throw Error(l(317));
      e: {
        for (e = e.nextSibling, t = 0; e;) {
          if (e.nodeType === 8) {
            var n = e.data;
            if (n === "/$") {
              if (t === 0) {
                ct = qt(e.nextSibling);
                break e;
              }
              t--;
            } else (n !== "$" && n !== "$!" && n !== "$?") || t++;
          }
          e = e.nextSibling;
        }
        ct = null;
      }
    } else ct = ut ? qt(e.stateNode.nextSibling) : null;
    return !0;
  }
  function fu() {
    for (var e = ct; e;) e = qt(e.nextSibling);
  }
  function Gn() {
    ((ct = ut = null), (Ce = !1));
  }
  function is(e) {
    St === null ? (St = [e]) : St.push(e);
  }
  var gp = ie.ReactCurrentBatchConfig;
  function _r(e, t, n) {
    if (
      ((e = n.ref),
      e !== null && typeof e != "function" && typeof e != "object")
    ) {
      if (n._owner) {
        if (((n = n._owner), n)) {
          if (n.tag !== 1) throw Error(l(309));
          var r = n.stateNode;
        }
        if (!r) throw Error(l(147, e));
        var o = r,
          i = "" + e;
        return t !== null &&
          t.ref !== null &&
          typeof t.ref == "function" &&
          t.ref._stringRef === i
          ? t.ref
          : ((t = function (c) {
              var f = o.refs;
              c === null ? delete f[i] : (f[i] = c);
            }),
            (t._stringRef = i),
            t);
      }
      if (typeof e != "string") throw Error(l(284));
      if (!n._owner) throw Error(l(290, e));
    }
    return e;
  }
  function jo(e, t) {
    throw (
      (e = Object.prototype.toString.call(t)),
      Error(
        l(
          31,
          e === "[object Object]"
            ? "object with keys {" + Object.keys(t).join(", ") + "}"
            : e,
        ),
      )
    );
  }
  function pu(e) {
    var t = e._init;
    return t(e._payload);
  }
  function mu(e) {
    function t(v, h) {
      if (e) {
        var w = v.deletions;
        w === null ? ((v.deletions = [h]), (v.flags |= 16)) : w.push(h);
      }
    }
    function n(v, h) {
      if (!e) return null;
      for (; h !== null;) (t(v, h), (h = h.sibling));
      return null;
    }
    function r(v, h) {
      for (v = new Map(); h !== null;)
        (h.key !== null ? v.set(h.key, h) : v.set(h.index, h), (h = h.sibling));
      return v;
    }
    function o(v, h) {
      return ((v = un(v, h)), (v.index = 0), (v.sibling = null), v);
    }
    function i(v, h, w) {
      return (
        (v.index = w),
        e
          ? ((w = v.alternate),
            w !== null
              ? ((w = w.index), w < h ? ((v.flags |= 2), h) : w)
              : ((v.flags |= 2), h))
          : ((v.flags |= 1048576), h)
      );
    }
    function c(v) {
      return (e && v.alternate === null && (v.flags |= 2), v);
    }
    function f(v, h, w, z) {
      return h === null || h.tag !== 6
        ? ((h = Ys(w, v.mode, z)), (h.return = v), h)
        : ((h = o(h, w)), (h.return = v), h);
    }
    function m(v, h, w, z) {
      var W = w.type;
      return W === ee
        ? A(v, h, w.props.children, z, w.key)
        : h !== null &&
            (h.elementType === W ||
              (typeof W == "object" &&
                W !== null &&
                W.$$typeof === Le &&
                pu(W) === h.type))
          ? ((z = o(h, w.props)), (z.ref = _r(v, h, w)), (z.return = v), z)
          : ((z = Zo(w.type, w.key, w.props, null, v.mode, z)),
            (z.ref = _r(v, h, w)),
            (z.return = v),
            z);
    }
    function x(v, h, w, z) {
      return h === null ||
        h.tag !== 4 ||
        h.stateNode.containerInfo !== w.containerInfo ||
        h.stateNode.implementation !== w.implementation
        ? ((h = qs(w, v.mode, z)), (h.return = v), h)
        : ((h = o(h, w.children || [])), (h.return = v), h);
    }
    function A(v, h, w, z, W) {
      return h === null || h.tag !== 7
        ? ((h = jn(w, v.mode, z, W)), (h.return = v), h)
        : ((h = o(h, w)), (h.return = v), h);
    }
    function P(v, h, w) {
      if ((typeof h == "string" && h !== "") || typeof h == "number")
        return ((h = Ys("" + h, v.mode, w)), (h.return = v), h);
      if (typeof h == "object" && h !== null) {
        switch (h.$$typeof) {
          case Ae:
            return (
              (w = Zo(h.type, h.key, h.props, null, v.mode, w)),
              (w.ref = _r(v, null, h)),
              (w.return = v),
              w
            );
          case B:
            return ((h = qs(h, v.mode, w)), (h.return = v), h);
          case Le:
            var z = h._init;
            return P(v, z(h._payload), w);
        }
        if (ir(h) || H(h))
          return ((h = jn(h, v.mode, w, null)), (h.return = v), h);
        jo(v, h);
      }
      return null;
    }
    function C(v, h, w, z) {
      var W = h !== null ? h.key : null;
      if ((typeof w == "string" && w !== "") || typeof w == "number")
        return W !== null ? null : f(v, h, "" + w, z);
      if (typeof w == "object" && w !== null) {
        switch (w.$$typeof) {
          case Ae:
            return w.key === W ? m(v, h, w, z) : null;
          case B:
            return w.key === W ? x(v, h, w, z) : null;
          case Le:
            return ((W = w._init), C(v, h, W(w._payload), z));
        }
        if (ir(w) || H(w)) return W !== null ? null : A(v, h, w, z, null);
        jo(v, w);
      }
      return null;
    }
    function L(v, h, w, z, W) {
      if ((typeof z == "string" && z !== "") || typeof z == "number")
        return ((v = v.get(w) || null), f(h, v, "" + z, W));
      if (typeof z == "object" && z !== null) {
        switch (z.$$typeof) {
          case Ae:
            return (
              (v = v.get(z.key === null ? w : z.key) || null),
              m(h, v, z, W)
            );
          case B:
            return (
              (v = v.get(z.key === null ? w : z.key) || null),
              x(h, v, z, W)
            );
          case Le:
            var G = z._init;
            return L(v, h, w, G(z._payload), W);
        }
        if (ir(z) || H(z)) return ((v = v.get(w) || null), A(h, v, z, W, null));
        jo(h, z);
      }
      return null;
    }
    function N(v, h, w, z) {
      for (
        var W = null, G = null, Q = h, J = (h = 0), Be = null;
        Q !== null && J < w.length;
        J++
      ) {
        Q.index > J ? ((Be = Q), (Q = null)) : (Be = Q.sibling);
        var me = C(v, Q, w[J], z);
        if (me === null) {
          Q === null && (Q = Be);
          break;
        }
        (e && Q && me.alternate === null && t(v, Q),
          (h = i(me, h, J)),
          G === null ? (W = me) : (G.sibling = me),
          (G = me),
          (Q = Be));
      }
      if (J === w.length) return (n(v, Q), Ce && yn(v, J), W);
      if (Q === null) {
        for (; J < w.length; J++)
          ((Q = P(v, w[J], z)),
            Q !== null &&
              ((h = i(Q, h, J)),
              G === null ? (W = Q) : (G.sibling = Q),
              (G = Q)));
        return (Ce && yn(v, J), W);
      }
      for (Q = r(v, Q); J < w.length; J++)
        ((Be = L(Q, v, J, w[J], z)),
          Be !== null &&
            (e &&
              Be.alternate !== null &&
              Q.delete(Be.key === null ? J : Be.key),
            (h = i(Be, h, J)),
            G === null ? (W = Be) : (G.sibling = Be),
            (G = Be)));
      return (
        e &&
          Q.forEach(function (cn) {
            return t(v, cn);
          }),
        Ce && yn(v, J),
        W
      );
    }
    function U(v, h, w, z) {
      var W = H(w);
      if (typeof W != "function") throw Error(l(150));
      if (((w = W.call(w)), w == null)) throw Error(l(151));
      for (
        var G = (W = null), Q = h, J = (h = 0), Be = null, me = w.next();
        Q !== null && !me.done;
        J++, me = w.next()
      ) {
        Q.index > J ? ((Be = Q), (Q = null)) : (Be = Q.sibling);
        var cn = C(v, Q, me.value, z);
        if (cn === null) {
          Q === null && (Q = Be);
          break;
        }
        (e && Q && cn.alternate === null && t(v, Q),
          (h = i(cn, h, J)),
          G === null ? (W = cn) : (G.sibling = cn),
          (G = cn),
          (Q = Be));
      }
      if (me.done) return (n(v, Q), Ce && yn(v, J), W);
      if (Q === null) {
        for (; !me.done; J++, me = w.next())
          ((me = P(v, me.value, z)),
            me !== null &&
              ((h = i(me, h, J)),
              G === null ? (W = me) : (G.sibling = me),
              (G = me)));
        return (Ce && yn(v, J), W);
      }
      for (Q = r(v, Q); !me.done; J++, me = w.next())
        ((me = L(Q, v, J, me.value, z)),
          me !== null &&
            (e &&
              me.alternate !== null &&
              Q.delete(me.key === null ? J : me.key),
            (h = i(me, h, J)),
            G === null ? (W = me) : (G.sibling = me),
            (G = me)));
      return (
        e &&
          Q.forEach(function (Zp) {
            return t(v, Zp);
          }),
        Ce && yn(v, J),
        W
      );
    }
    function Oe(v, h, w, z) {
      if (
        (typeof w == "object" &&
          w !== null &&
          w.type === ee &&
          w.key === null &&
          (w = w.props.children),
        typeof w == "object" && w !== null)
      ) {
        switch (w.$$typeof) {
          case Ae:
            e: {
              for (var W = w.key, G = h; G !== null;) {
                if (G.key === W) {
                  if (((W = w.type), W === ee)) {
                    if (G.tag === 7) {
                      (n(v, G.sibling),
                        (h = o(G, w.props.children)),
                        (h.return = v),
                        (v = h));
                      break e;
                    }
                  } else if (
                    G.elementType === W ||
                    (typeof W == "object" &&
                      W !== null &&
                      W.$$typeof === Le &&
                      pu(W) === G.type)
                  ) {
                    (n(v, G.sibling),
                      (h = o(G, w.props)),
                      (h.ref = _r(v, G, w)),
                      (h.return = v),
                      (v = h));
                    break e;
                  }
                  n(v, G);
                  break;
                } else t(v, G);
                G = G.sibling;
              }
              w.type === ee
                ? ((h = jn(w.props.children, v.mode, z, w.key)),
                  (h.return = v),
                  (v = h))
                : ((z = Zo(w.type, w.key, w.props, null, v.mode, z)),
                  (z.ref = _r(v, h, w)),
                  (z.return = v),
                  (v = z));
            }
            return c(v);
          case B:
            e: {
              for (G = w.key; h !== null;) {
                if (h.key === G)
                  if (
                    h.tag === 4 &&
                    h.stateNode.containerInfo === w.containerInfo &&
                    h.stateNode.implementation === w.implementation
                  ) {
                    (n(v, h.sibling),
                      (h = o(h, w.children || [])),
                      (h.return = v),
                      (v = h));
                    break e;
                  } else {
                    n(v, h);
                    break;
                  }
                else t(v, h);
                h = h.sibling;
              }
              ((h = qs(w, v.mode, z)), (h.return = v), (v = h));
            }
            return c(v);
          case Le:
            return ((G = w._init), Oe(v, h, G(w._payload), z));
        }
        if (ir(w)) return N(v, h, w, z);
        if (H(w)) return U(v, h, w, z);
        jo(v, w);
      }
      return (typeof w == "string" && w !== "") || typeof w == "number"
        ? ((w = "" + w),
          h !== null && h.tag === 6
            ? (n(v, h.sibling), (h = o(h, w)), (h.return = v), (v = h))
            : (n(v, h), (h = Ys(w, v.mode, z)), (h.return = v), (v = h)),
          c(v))
        : n(v, h);
    }
    return Oe;
  }
  var Qn = mu(!0),
    hu = mu(!1),
    Co = Xt(null),
    Ao = null,
    Zn = null,
    ss = null;
  function as() {
    ss = Zn = Ao = null;
  }
  function ls(e) {
    var t = Co.current;
    (Se(Co), (e._currentValue = t));
  }
  function us(e, t, n) {
    for (; e !== null;) {
      var r = e.alternate;
      if (
        ((e.childLanes & t) !== t
          ? ((e.childLanes |= t), r !== null && (r.childLanes |= t))
          : r !== null && (r.childLanes & t) !== t && (r.childLanes |= t),
        e === n)
      )
        break;
      e = e.return;
    }
  }
  function Yn(e, t) {
    ((Ao = e),
      (ss = Zn = null),
      (e = e.dependencies),
      e !== null &&
        e.firstContext !== null &&
        ((e.lanes & t) !== 0 && (rt = !0), (e.firstContext = null)));
  }
  function mt(e) {
    var t = e._currentValue;
    if (ss !== e)
      if (((e = { context: e, memoizedValue: t, next: null }), Zn === null)) {
        if (Ao === null) throw Error(l(308));
        ((Zn = e), (Ao.dependencies = { lanes: 0, firstContext: e }));
      } else Zn = Zn.next = e;
    return t;
  }
  var vn = null;
  function cs(e) {
    vn === null ? (vn = [e]) : vn.push(e);
  }
  function gu(e, t, n, r) {
    var o = t.interleaved;
    return (
      o === null ? ((n.next = n), cs(t)) : ((n.next = o.next), (o.next = n)),
      (t.interleaved = n),
      Ut(e, r)
    );
  }
  function Ut(e, t) {
    e.lanes |= t;
    var n = e.alternate;
    for (n !== null && (n.lanes |= t), n = e, e = e.return; e !== null;)
      ((e.childLanes |= t),
        (n = e.alternate),
        n !== null && (n.childLanes |= t),
        (n = e),
        (e = e.return));
    return n.tag === 3 ? n.stateNode : null;
  }
  var tn = !1;
  function ds(e) {
    e.updateQueue = {
      baseState: e.memoizedState,
      firstBaseUpdate: null,
      lastBaseUpdate: null,
      shared: { pending: null, interleaved: null, lanes: 0 },
      effects: null,
    };
  }
  function yu(e, t) {
    ((e = e.updateQueue),
      t.updateQueue === e &&
        (t.updateQueue = {
          baseState: e.baseState,
          firstBaseUpdate: e.firstBaseUpdate,
          lastBaseUpdate: e.lastBaseUpdate,
          shared: e.shared,
          effects: e.effects,
        }));
  }
  function Ft(e, t) {
    return {
      eventTime: e,
      lane: t,
      tag: 0,
      payload: null,
      callback: null,
      next: null,
    };
  }
  function nn(e, t, n) {
    var r = e.updateQueue;
    if (r === null) return null;
    if (((r = r.shared), (pe & 2) !== 0)) {
      var o = r.pending;
      return (
        o === null ? (t.next = t) : ((t.next = o.next), (o.next = t)),
        (r.pending = t),
        Ut(e, n)
      );
    }
    return (
      (o = r.interleaved),
      o === null ? ((t.next = t), cs(r)) : ((t.next = o.next), (o.next = t)),
      (r.interleaved = t),
      Ut(e, n)
    );
  }
  function Po(e, t, n) {
    if (
      ((t = t.updateQueue), t !== null && ((t = t.shared), (n & 4194240) !== 0))
    ) {
      var r = t.lanes;
      ((r &= e.pendingLanes), (n |= r), (t.lanes = n), ji(e, n));
    }
  }
  function vu(e, t) {
    var n = e.updateQueue,
      r = e.alternate;
    if (r !== null && ((r = r.updateQueue), n === r)) {
      var o = null,
        i = null;
      if (((n = n.firstBaseUpdate), n !== null)) {
        do {
          var c = {
            eventTime: n.eventTime,
            lane: n.lane,
            tag: n.tag,
            payload: n.payload,
            callback: n.callback,
            next: null,
          };
          (i === null ? (o = i = c) : (i = i.next = c), (n = n.next));
        } while (n !== null);
        i === null ? (o = i = t) : (i = i.next = t);
      } else o = i = t;
      ((n = {
        baseState: r.baseState,
        firstBaseUpdate: o,
        lastBaseUpdate: i,
        shared: r.shared,
        effects: r.effects,
      }),
        (e.updateQueue = n));
      return;
    }
    ((e = n.lastBaseUpdate),
      e === null ? (n.firstBaseUpdate = t) : (e.next = t),
      (n.lastBaseUpdate = t));
  }
  function zo(e, t, n, r) {
    var o = e.updateQueue;
    tn = !1;
    var i = o.firstBaseUpdate,
      c = o.lastBaseUpdate,
      f = o.shared.pending;
    if (f !== null) {
      o.shared.pending = null;
      var m = f,
        x = m.next;
      ((m.next = null), c === null ? (i = x) : (c.next = x), (c = m));
      var A = e.alternate;
      A !== null &&
        ((A = A.updateQueue),
        (f = A.lastBaseUpdate),
        f !== c &&
          (f === null ? (A.firstBaseUpdate = x) : (f.next = x),
          (A.lastBaseUpdate = m)));
    }
    if (i !== null) {
      var P = o.baseState;
      ((c = 0), (A = x = m = null), (f = i));
      do {
        var C = f.lane,
          L = f.eventTime;
        if ((r & C) === C) {
          A !== null &&
            (A = A.next =
              {
                eventTime: L,
                lane: 0,
                tag: f.tag,
                payload: f.payload,
                callback: f.callback,
                next: null,
              });
          e: {
            var N = e,
              U = f;
            switch (((C = t), (L = n), U.tag)) {
              case 1:
                if (((N = U.payload), typeof N == "function")) {
                  P = N.call(L, P, C);
                  break e;
                }
                P = N;
                break e;
              case 3:
                N.flags = (N.flags & -65537) | 128;
              case 0:
                if (
                  ((N = U.payload),
                  (C = typeof N == "function" ? N.call(L, P, C) : N),
                  C == null)
                )
                  break e;
                P = _({}, P, C);
                break e;
              case 2:
                tn = !0;
            }
          }
          f.callback !== null &&
            f.lane !== 0 &&
            ((e.flags |= 64),
            (C = o.effects),
            C === null ? (o.effects = [f]) : C.push(f));
        } else
          ((L = {
            eventTime: L,
            lane: C,
            tag: f.tag,
            payload: f.payload,
            callback: f.callback,
            next: null,
          }),
            A === null ? ((x = A = L), (m = P)) : (A = A.next = L),
            (c |= C));
        if (((f = f.next), f === null)) {
          if (((f = o.shared.pending), f === null)) break;
          ((C = f),
            (f = C.next),
            (C.next = null),
            (o.lastBaseUpdate = C),
            (o.shared.pending = null));
        }
      } while (!0);
      if (
        (A === null && (m = P),
        (o.baseState = m),
        (o.firstBaseUpdate = x),
        (o.lastBaseUpdate = A),
        (t = o.shared.interleaved),
        t !== null)
      ) {
        o = t;
        do ((c |= o.lane), (o = o.next));
        while (o !== t);
      } else i === null && (o.shared.lanes = 0);
      ((kn |= c), (e.lanes = c), (e.memoizedState = P));
    }
  }
  function wu(e, t, n) {
    if (((e = t.effects), (t.effects = null), e !== null))
      for (t = 0; t < e.length; t++) {
        var r = e[t],
          o = r.callback;
        if (o !== null) {
          if (((r.callback = null), (r = n), typeof o != "function"))
            throw Error(l(191, o));
          o.call(r);
        }
      }
  }
  var Tr = {},
    _t = Xt(Tr),
    Rr = Xt(Tr),
    Lr = Xt(Tr);
  function wn(e) {
    if (e === Tr) throw Error(l(174));
    return e;
  }
  function fs(e, t) {
    switch ((xe(Lr, t), xe(Rr, e), xe(_t, Tr), (e = t.nodeType), e)) {
      case 9:
      case 11:
        t = (t = t.documentElement) ? t.namespaceURI : pi(null, "");
        break;
      default:
        ((e = e === 8 ? t.parentNode : t),
          (t = e.namespaceURI || null),
          (e = e.tagName),
          (t = pi(t, e)));
    }
    (Se(_t), xe(_t, t));
  }
  function qn() {
    (Se(_t), Se(Rr), Se(Lr));
  }
  function xu(e) {
    wn(Lr.current);
    var t = wn(_t.current),
      n = pi(t, e.type);
    t !== n && (xe(Rr, e), xe(_t, n));
  }
  function ps(e) {
    Rr.current === e && (Se(_t), Se(Rr));
  }
  var ze = Xt(0);
  function _o(e) {
    for (var t = e; t !== null;) {
      if (t.tag === 13) {
        var n = t.memoizedState;
        if (
          n !== null &&
          ((n = n.dehydrated), n === null || n.data === "$?" || n.data === "$!")
        )
          return t;
      } else if (t.tag === 19 && t.memoizedProps.revealOrder !== void 0) {
        if ((t.flags & 128) !== 0) return t;
      } else if (t.child !== null) {
        ((t.child.return = t), (t = t.child));
        continue;
      }
      if (t === e) break;
      for (; t.sibling === null;) {
        if (t.return === null || t.return === e) return null;
        t = t.return;
      }
      ((t.sibling.return = t.return), (t = t.sibling));
    }
    return null;
  }
  var ms = [];
  function hs() {
    for (var e = 0; e < ms.length; e++)
      ms[e]._workInProgressVersionPrimary = null;
    ms.length = 0;
  }
  var To = ie.ReactCurrentDispatcher,
    gs = ie.ReactCurrentBatchConfig,
    xn = 0,
    _e = null,
    Ie = null,
    We = null,
    Ro = !1,
    Mr = !1,
    Or = 0,
    yp = 0;
  function Qe() {
    throw Error(l(321));
  }
  function ys(e, t) {
    if (t === null) return !1;
    for (var n = 0; n < t.length && n < e.length; n++)
      if (!kt(e[n], t[n])) return !1;
    return !0;
  }
  function vs(e, t, n, r, o, i) {
    if (
      ((xn = i),
      (_e = t),
      (t.memoizedState = null),
      (t.updateQueue = null),
      (t.lanes = 0),
      (To.current = e === null || e.memoizedState === null ? kp : Sp),
      (e = n(r, o)),
      Mr)
    ) {
      i = 0;
      do {
        if (((Mr = !1), (Or = 0), 25 <= i)) throw Error(l(301));
        ((i += 1),
          (We = Ie = null),
          (t.updateQueue = null),
          (To.current = bp),
          (e = n(r, o)));
      } while (Mr);
    }
    if (
      ((To.current = Oo),
      (t = Ie !== null && Ie.next !== null),
      (xn = 0),
      (We = Ie = _e = null),
      (Ro = !1),
      t)
    )
      throw Error(l(300));
    return e;
  }
  function ws() {
    var e = Or !== 0;
    return ((Or = 0), e);
  }
  function Tt() {
    var e = {
      memoizedState: null,
      baseState: null,
      baseQueue: null,
      queue: null,
      next: null,
    };
    return (We === null ? (_e.memoizedState = We = e) : (We = We.next = e), We);
  }
  function ht() {
    if (Ie === null) {
      var e = _e.alternate;
      e = e !== null ? e.memoizedState : null;
    } else e = Ie.next;
    var t = We === null ? _e.memoizedState : We.next;
    if (t !== null) ((We = t), (Ie = e));
    else {
      if (e === null) throw Error(l(310));
      ((Ie = e),
        (e = {
          memoizedState: Ie.memoizedState,
          baseState: Ie.baseState,
          baseQueue: Ie.baseQueue,
          queue: Ie.queue,
          next: null,
        }),
        We === null ? (_e.memoizedState = We = e) : (We = We.next = e));
    }
    return We;
  }
  function Nr(e, t) {
    return typeof t == "function" ? t(e) : t;
  }
  function xs(e) {
    var t = ht(),
      n = t.queue;
    if (n === null) throw Error(l(311));
    n.lastRenderedReducer = e;
    var r = Ie,
      o = r.baseQueue,
      i = n.pending;
    if (i !== null) {
      if (o !== null) {
        var c = o.next;
        ((o.next = i.next), (i.next = c));
      }
      ((r.baseQueue = o = i), (n.pending = null));
    }
    if (o !== null) {
      ((i = o.next), (r = r.baseState));
      var f = (c = null),
        m = null,
        x = i;
      do {
        var A = x.lane;
        if ((xn & A) === A)
          (m !== null &&
            (m = m.next =
              {
                lane: 0,
                action: x.action,
                hasEagerState: x.hasEagerState,
                eagerState: x.eagerState,
                next: null,
              }),
            (r = x.hasEagerState ? x.eagerState : e(r, x.action)));
        else {
          var P = {
            lane: A,
            action: x.action,
            hasEagerState: x.hasEagerState,
            eagerState: x.eagerState,
            next: null,
          };
          (m === null ? ((f = m = P), (c = r)) : (m = m.next = P),
            (_e.lanes |= A),
            (kn |= A));
        }
        x = x.next;
      } while (x !== null && x !== i);
      (m === null ? (c = r) : (m.next = f),
        kt(r, t.memoizedState) || (rt = !0),
        (t.memoizedState = r),
        (t.baseState = c),
        (t.baseQueue = m),
        (n.lastRenderedState = r));
    }
    if (((e = n.interleaved), e !== null)) {
      o = e;
      do ((i = o.lane), (_e.lanes |= i), (kn |= i), (o = o.next));
      while (o !== e);
    } else o === null && (n.lanes = 0);
    return [t.memoizedState, n.dispatch];
  }
  function ks(e) {
    var t = ht(),
      n = t.queue;
    if (n === null) throw Error(l(311));
    n.lastRenderedReducer = e;
    var r = n.dispatch,
      o = n.pending,
      i = t.memoizedState;
    if (o !== null) {
      n.pending = null;
      var c = (o = o.next);
      do ((i = e(i, c.action)), (c = c.next));
      while (c !== o);
      (kt(i, t.memoizedState) || (rt = !0),
        (t.memoizedState = i),
        t.baseQueue === null && (t.baseState = i),
        (n.lastRenderedState = i));
    }
    return [i, r];
  }
  function ku() {}
  function Su(e, t) {
    var n = _e,
      r = ht(),
      o = t(),
      i = !kt(r.memoizedState, o);
    if (
      (i && ((r.memoizedState = o), (rt = !0)),
      (r = r.queue),
      Ss(ju.bind(null, n, r, e), [e]),
      r.getSnapshot !== t || i || (We !== null && We.memoizedState.tag & 1))
    ) {
      if (
        ((n.flags |= 2048),
        Ir(9, Eu.bind(null, n, r, o, t), void 0, null),
        $e === null)
      )
        throw Error(l(349));
      (xn & 30) !== 0 || bu(n, t, o);
    }
    return o;
  }
  function bu(e, t, n) {
    ((e.flags |= 16384),
      (e = { getSnapshot: t, value: n }),
      (t = _e.updateQueue),
      t === null
        ? ((t = { lastEffect: null, stores: null }),
          (_e.updateQueue = t),
          (t.stores = [e]))
        : ((n = t.stores), n === null ? (t.stores = [e]) : n.push(e)));
  }
  function Eu(e, t, n, r) {
    ((t.value = n), (t.getSnapshot = r), Cu(t) && Au(e));
  }
  function ju(e, t, n) {
    return n(function () {
      Cu(t) && Au(e);
    });
  }
  function Cu(e) {
    var t = e.getSnapshot;
    e = e.value;
    try {
      var n = t();
      return !kt(e, n);
    } catch {
      return !0;
    }
  }
  function Au(e) {
    var t = Ut(e, 1);
    t !== null && Ct(t, e, 1, -1);
  }
  function Pu(e) {
    var t = Tt();
    return (
      typeof e == "function" && (e = e()),
      (t.memoizedState = t.baseState = e),
      (e = {
        pending: null,
        interleaved: null,
        lanes: 0,
        dispatch: null,
        lastRenderedReducer: Nr,
        lastRenderedState: e,
      }),
      (t.queue = e),
      (e = e.dispatch = xp.bind(null, _e, e)),
      [t.memoizedState, e]
    );
  }
  function Ir(e, t, n, r) {
    return (
      (e = { tag: e, create: t, destroy: n, deps: r, next: null }),
      (t = _e.updateQueue),
      t === null
        ? ((t = { lastEffect: null, stores: null }),
          (_e.updateQueue = t),
          (t.lastEffect = e.next = e))
        : ((n = t.lastEffect),
          n === null
            ? (t.lastEffect = e.next = e)
            : ((r = n.next), (n.next = e), (e.next = r), (t.lastEffect = e))),
      e
    );
  }
  function zu() {
    return ht().memoizedState;
  }
  function Lo(e, t, n, r) {
    var o = Tt();
    ((_e.flags |= e),
      (o.memoizedState = Ir(1 | t, n, void 0, r === void 0 ? null : r)));
  }
  function Mo(e, t, n, r) {
    var o = ht();
    r = r === void 0 ? null : r;
    var i = void 0;
    if (Ie !== null) {
      var c = Ie.memoizedState;
      if (((i = c.destroy), r !== null && ys(r, c.deps))) {
        o.memoizedState = Ir(t, n, i, r);
        return;
      }
    }
    ((_e.flags |= e), (o.memoizedState = Ir(1 | t, n, i, r)));
  }
  function _u(e, t) {
    return Lo(8390656, 8, e, t);
  }
  function Ss(e, t) {
    return Mo(2048, 8, e, t);
  }
  function Tu(e, t) {
    return Mo(4, 2, e, t);
  }
  function Ru(e, t) {
    return Mo(4, 4, e, t);
  }
  function Lu(e, t) {
    if (typeof t == "function")
      return (
        (e = e()),
        t(e),
        function () {
          t(null);
        }
      );
    if (t != null)
      return (
        (e = e()),
        (t.current = e),
        function () {
          t.current = null;
        }
      );
  }
  function Mu(e, t, n) {
    return (
      (n = n != null ? n.concat([e]) : null),
      Mo(4, 4, Lu.bind(null, t, e), n)
    );
  }
  function bs() {}
  function Ou(e, t) {
    var n = ht();
    t = t === void 0 ? null : t;
    var r = n.memoizedState;
    return r !== null && t !== null && ys(t, r[1])
      ? r[0]
      : ((n.memoizedState = [e, t]), e);
  }
  function Nu(e, t) {
    var n = ht();
    t = t === void 0 ? null : t;
    var r = n.memoizedState;
    return r !== null && t !== null && ys(t, r[1])
      ? r[0]
      : ((e = e()), (n.memoizedState = [e, t]), e);
  }
  function Iu(e, t, n) {
    return (xn & 21) === 0
      ? (e.baseState && ((e.baseState = !1), (rt = !0)), (e.memoizedState = n))
      : (kt(n, t) ||
          ((n = pl()), (_e.lanes |= n), (kn |= n), (e.baseState = !0)),
        t);
  }
  function vp(e, t) {
    var n = ge;
    ((ge = n !== 0 && 4 > n ? n : 4), e(!0));
    var r = gs.transition;
    gs.transition = {};
    try {
      (e(!1), t());
    } finally {
      ((ge = n), (gs.transition = r));
    }
  }
  function Du() {
    return ht().memoizedState;
  }
  function wp(e, t, n) {
    var r = an(e);
    if (
      ((n = {
        lane: r,
        action: n,
        hasEagerState: !1,
        eagerState: null,
        next: null,
      }),
      Uu(e))
    )
      Fu(t, n);
    else if (((n = gu(e, t, n, r)), n !== null)) {
      var o = Je();
      (Ct(n, e, r, o), Wu(n, t, r));
    }
  }
  function xp(e, t, n) {
    var r = an(e),
      o = {
        lane: r,
        action: n,
        hasEagerState: !1,
        eagerState: null,
        next: null,
      };
    if (Uu(e)) Fu(t, o);
    else {
      var i = e.alternate;
      if (
        e.lanes === 0 &&
        (i === null || i.lanes === 0) &&
        ((i = t.lastRenderedReducer), i !== null)
      )
        try {
          var c = t.lastRenderedState,
            f = i(c, n);
          if (((o.hasEagerState = !0), (o.eagerState = f), kt(f, c))) {
            var m = t.interleaved;
            (m === null
              ? ((o.next = o), cs(t))
              : ((o.next = m.next), (m.next = o)),
              (t.interleaved = o));
            return;
          }
        } catch {
        } finally {
        }
      ((n = gu(e, t, o, r)),
        n !== null && ((o = Je()), Ct(n, e, r, o), Wu(n, t, r)));
    }
  }
  function Uu(e) {
    var t = e.alternate;
    return e === _e || (t !== null && t === _e);
  }
  function Fu(e, t) {
    Mr = Ro = !0;
    var n = e.pending;
    (n === null ? (t.next = t) : ((t.next = n.next), (n.next = t)),
      (e.pending = t));
  }
  function Wu(e, t, n) {
    if ((n & 4194240) !== 0) {
      var r = t.lanes;
      ((r &= e.pendingLanes), (n |= r), (t.lanes = n), ji(e, n));
    }
  }
  var Oo = {
      readContext: mt,
      useCallback: Qe,
      useContext: Qe,
      useEffect: Qe,
      useImperativeHandle: Qe,
      useInsertionEffect: Qe,
      useLayoutEffect: Qe,
      useMemo: Qe,
      useReducer: Qe,
      useRef: Qe,
      useState: Qe,
      useDebugValue: Qe,
      useDeferredValue: Qe,
      useTransition: Qe,
      useMutableSource: Qe,
      useSyncExternalStore: Qe,
      useId: Qe,
      unstable_isNewReconciler: !1,
    },
    kp = {
      readContext: mt,
      useCallback: function (e, t) {
        return ((Tt().memoizedState = [e, t === void 0 ? null : t]), e);
      },
      useContext: mt,
      useEffect: _u,
      useImperativeHandle: function (e, t, n) {
        return (
          (n = n != null ? n.concat([e]) : null),
          Lo(4194308, 4, Lu.bind(null, t, e), n)
        );
      },
      useLayoutEffect: function (e, t) {
        return Lo(4194308, 4, e, t);
      },
      useInsertionEffect: function (e, t) {
        return Lo(4, 2, e, t);
      },
      useMemo: function (e, t) {
        var n = Tt();
        return (
          (t = t === void 0 ? null : t),
          (e = e()),
          (n.memoizedState = [e, t]),
          e
        );
      },
      useReducer: function (e, t, n) {
        var r = Tt();
        return (
          (t = n !== void 0 ? n(t) : t),
          (r.memoizedState = r.baseState = t),
          (e = {
            pending: null,
            interleaved: null,
            lanes: 0,
            dispatch: null,
            lastRenderedReducer: e,
            lastRenderedState: t,
          }),
          (r.queue = e),
          (e = e.dispatch = wp.bind(null, _e, e)),
          [r.memoizedState, e]
        );
      },
      useRef: function (e) {
        var t = Tt();
        return ((e = { current: e }), (t.memoizedState = e));
      },
      useState: Pu,
      useDebugValue: bs,
      useDeferredValue: function (e) {
        return (Tt().memoizedState = e);
      },
      useTransition: function () {
        var e = Pu(!1),
          t = e[0];
        return ((e = vp.bind(null, e[1])), (Tt().memoizedState = e), [t, e]);
      },
      useMutableSource: function () {},
      useSyncExternalStore: function (e, t, n) {
        var r = _e,
          o = Tt();
        if (Ce) {
          if (n === void 0) throw Error(l(407));
          n = n();
        } else {
          if (((n = t()), $e === null)) throw Error(l(349));
          (xn & 30) !== 0 || bu(r, t, n);
        }
        o.memoizedState = n;
        var i = { value: n, getSnapshot: t };
        return (
          (o.queue = i),
          _u(ju.bind(null, r, i, e), [e]),
          (r.flags |= 2048),
          Ir(9, Eu.bind(null, r, i, n, t), void 0, null),
          n
        );
      },
      useId: function () {
        var e = Tt(),
          t = $e.identifierPrefix;
        if (Ce) {
          var n = Dt,
            r = It;
          ((n = (r & ~(1 << (32 - xt(r) - 1))).toString(32) + n),
            (t = ":" + t + "R" + n),
            (n = Or++),
            0 < n && (t += "H" + n.toString(32)),
            (t += ":"));
        } else ((n = yp++), (t = ":" + t + "r" + n.toString(32) + ":"));
        return (e.memoizedState = t);
      },
      unstable_isNewReconciler: !1,
    },
    Sp = {
      readContext: mt,
      useCallback: Ou,
      useContext: mt,
      useEffect: Ss,
      useImperativeHandle: Mu,
      useInsertionEffect: Tu,
      useLayoutEffect: Ru,
      useMemo: Nu,
      useReducer: xs,
      useRef: zu,
      useState: function () {
        return xs(Nr);
      },
      useDebugValue: bs,
      useDeferredValue: function (e) {
        var t = ht();
        return Iu(t, Ie.memoizedState, e);
      },
      useTransition: function () {
        var e = xs(Nr)[0],
          t = ht().memoizedState;
        return [e, t];
      },
      useMutableSource: ku,
      useSyncExternalStore: Su,
      useId: Du,
      unstable_isNewReconciler: !1,
    },
    bp = {
      readContext: mt,
      useCallback: Ou,
      useContext: mt,
      useEffect: Ss,
      useImperativeHandle: Mu,
      useInsertionEffect: Tu,
      useLayoutEffect: Ru,
      useMemo: Nu,
      useReducer: ks,
      useRef: zu,
      useState: function () {
        return ks(Nr);
      },
      useDebugValue: bs,
      useDeferredValue: function (e) {
        var t = ht();
        return Ie === null ? (t.memoizedState = e) : Iu(t, Ie.memoizedState, e);
      },
      useTransition: function () {
        var e = ks(Nr)[0],
          t = ht().memoizedState;
        return [e, t];
      },
      useMutableSource: ku,
      useSyncExternalStore: Su,
      useId: Du,
      unstable_isNewReconciler: !1,
    };
  function bt(e, t) {
    if (e && e.defaultProps) {
      ((t = _({}, t)), (e = e.defaultProps));
      for (var n in e) t[n] === void 0 && (t[n] = e[n]);
      return t;
    }
    return t;
  }
  function Es(e, t, n, r) {
    ((t = e.memoizedState),
      (n = n(r, t)),
      (n = n == null ? t : _({}, t, n)),
      (e.memoizedState = n),
      e.lanes === 0 && (e.updateQueue.baseState = n));
  }
  var No = {
    isMounted: function (e) {
      return (e = e._reactInternals) ? pn(e) === e : !1;
    },
    enqueueSetState: function (e, t, n) {
      e = e._reactInternals;
      var r = Je(),
        o = an(e),
        i = Ft(r, o);
      ((i.payload = t),
        n != null && (i.callback = n),
        (t = nn(e, i, o)),
        t !== null && (Ct(t, e, o, r), Po(t, e, o)));
    },
    enqueueReplaceState: function (e, t, n) {
      e = e._reactInternals;
      var r = Je(),
        o = an(e),
        i = Ft(r, o);
      ((i.tag = 1),
        (i.payload = t),
        n != null && (i.callback = n),
        (t = nn(e, i, o)),
        t !== null && (Ct(t, e, o, r), Po(t, e, o)));
    },
    enqueueForceUpdate: function (e, t) {
      e = e._reactInternals;
      var n = Je(),
        r = an(e),
        o = Ft(n, r);
      ((o.tag = 2),
        t != null && (o.callback = t),
        (t = nn(e, o, r)),
        t !== null && (Ct(t, e, r, n), Po(t, e, r)));
    },
  };
  function $u(e, t, n, r, o, i, c) {
    return (
      (e = e.stateNode),
      typeof e.shouldComponentUpdate == "function"
        ? e.shouldComponentUpdate(r, i, c)
        : t.prototype && t.prototype.isPureReactComponent
          ? !br(n, r) || !br(o, i)
          : !0
    );
  }
  function Bu(e, t, n) {
    var r = !1,
      o = Jt,
      i = t.contextType;
    return (
      typeof i == "object" && i !== null
        ? (i = mt(i))
        : ((o = nt(t) ? hn : Ge.current),
          (r = t.contextTypes),
          (i = (r = r != null) ? Hn(e, o) : Jt)),
      (t = new t(n, i)),
      (e.memoizedState =
        t.state !== null && t.state !== void 0 ? t.state : null),
      (t.updater = No),
      (e.stateNode = t),
      (t._reactInternals = e),
      r &&
        ((e = e.stateNode),
        (e.__reactInternalMemoizedUnmaskedChildContext = o),
        (e.__reactInternalMemoizedMaskedChildContext = i)),
      t
    );
  }
  function Hu(e, t, n, r) {
    ((e = t.state),
      typeof t.componentWillReceiveProps == "function" &&
        t.componentWillReceiveProps(n, r),
      typeof t.UNSAFE_componentWillReceiveProps == "function" &&
        t.UNSAFE_componentWillReceiveProps(n, r),
      t.state !== e && No.enqueueReplaceState(t, t.state, null));
  }
  function js(e, t, n, r) {
    var o = e.stateNode;
    ((o.props = n), (o.state = e.memoizedState), (o.refs = {}), ds(e));
    var i = t.contextType;
    (typeof i == "object" && i !== null
      ? (o.context = mt(i))
      : ((i = nt(t) ? hn : Ge.current), (o.context = Hn(e, i))),
      (o.state = e.memoizedState),
      (i = t.getDerivedStateFromProps),
      typeof i == "function" && (Es(e, t, i, n), (o.state = e.memoizedState)),
      typeof t.getDerivedStateFromProps == "function" ||
        typeof o.getSnapshotBeforeUpdate == "function" ||
        (typeof o.UNSAFE_componentWillMount != "function" &&
          typeof o.componentWillMount != "function") ||
        ((t = o.state),
        typeof o.componentWillMount == "function" && o.componentWillMount(),
        typeof o.UNSAFE_componentWillMount == "function" &&
          o.UNSAFE_componentWillMount(),
        t !== o.state && No.enqueueReplaceState(o, o.state, null),
        zo(e, n, o, r),
        (o.state = e.memoizedState)),
      typeof o.componentDidMount == "function" && (e.flags |= 4194308));
  }
  function Xn(e, t) {
    try {
      var n = "",
        r = t;
      do ((n += ue(r)), (r = r.return));
      while (r);
      var o = n;
    } catch (i) {
      o =
        `
Error generating stack: ` +
        i.message +
        `
` +
        i.stack;
    }
    return { value: e, source: t, stack: o, digest: null };
  }
  function Cs(e, t, n) {
    return { value: e, source: null, stack: n ?? null, digest: t ?? null };
  }
  function As(e, t) {
    try {
      console.error(t.value);
    } catch (n) {
      setTimeout(function () {
        throw n;
      });
    }
  }
  var Ep = typeof WeakMap == "function" ? WeakMap : Map;
  function Vu(e, t, n) {
    ((n = Ft(-1, n)), (n.tag = 3), (n.payload = { element: null }));
    var r = t.value;
    return (
      (n.callback = function () {
        (Bo || ((Bo = !0), ($s = r)), As(e, t));
      }),
      n
    );
  }
  function Ku(e, t, n) {
    ((n = Ft(-1, n)), (n.tag = 3));
    var r = e.type.getDerivedStateFromError;
    if (typeof r == "function") {
      var o = t.value;
      ((n.payload = function () {
        return r(o);
      }),
        (n.callback = function () {
          As(e, t);
        }));
    }
    var i = e.stateNode;
    return (
      i !== null &&
        typeof i.componentDidCatch == "function" &&
        (n.callback = function () {
          (As(e, t),
            typeof r != "function" &&
              (on === null ? (on = new Set([this])) : on.add(this)));
          var c = t.stack;
          this.componentDidCatch(t.value, {
            componentStack: c !== null ? c : "",
          });
        }),
      n
    );
  }
  function Gu(e, t, n) {
    var r = e.pingCache;
    if (r === null) {
      r = e.pingCache = new Ep();
      var o = new Set();
      r.set(t, o);
    } else ((o = r.get(t)), o === void 0 && ((o = new Set()), r.set(t, o)));
    o.has(n) || (o.add(n), (e = Dp.bind(null, e, t, n)), t.then(e, e));
  }
  function Qu(e) {
    do {
      var t;
      if (
        ((t = e.tag === 13) &&
          ((t = e.memoizedState),
          (t = t !== null ? t.dehydrated !== null : !0)),
        t)
      )
        return e;
      e = e.return;
    } while (e !== null);
    return null;
  }
  function Zu(e, t, n, r, o) {
    return (e.mode & 1) === 0
      ? (e === t
          ? (e.flags |= 65536)
          : ((e.flags |= 128),
            (n.flags |= 131072),
            (n.flags &= -52805),
            n.tag === 1 &&
              (n.alternate === null
                ? (n.tag = 17)
                : ((t = Ft(-1, 1)), (t.tag = 2), nn(n, t, 1))),
            (n.lanes |= 1)),
        e)
      : ((e.flags |= 65536), (e.lanes = o), e);
  }
  var jp = ie.ReactCurrentOwner,
    rt = !1;
  function Xe(e, t, n, r) {
    t.child = e === null ? hu(t, null, n, r) : Qn(t, e.child, n, r);
  }
  function Yu(e, t, n, r, o) {
    n = n.render;
    var i = t.ref;
    return (
      Yn(t, o),
      (r = vs(e, t, n, r, i, o)),
      (n = ws()),
      e !== null && !rt
        ? ((t.updateQueue = e.updateQueue),
          (t.flags &= -2053),
          (e.lanes &= ~o),
          Wt(e, t, o))
        : (Ce && n && ts(t), (t.flags |= 1), Xe(e, t, r, o), t.child)
    );
  }
  function qu(e, t, n, r, o) {
    if (e === null) {
      var i = n.type;
      return typeof i == "function" &&
        !Zs(i) &&
        i.defaultProps === void 0 &&
        n.compare === null &&
        n.defaultProps === void 0
        ? ((t.tag = 15), (t.type = i), Xu(e, t, i, r, o))
        : ((e = Zo(n.type, null, r, t, t.mode, o)),
          (e.ref = t.ref),
          (e.return = t),
          (t.child = e));
    }
    if (((i = e.child), (e.lanes & o) === 0)) {
      var c = i.memoizedProps;
      if (
        ((n = n.compare), (n = n !== null ? n : br), n(c, r) && e.ref === t.ref)
      )
        return Wt(e, t, o);
    }
    return (
      (t.flags |= 1),
      (e = un(i, r)),
      (e.ref = t.ref),
      (e.return = t),
      (t.child = e)
    );
  }
  function Xu(e, t, n, r, o) {
    if (e !== null) {
      var i = e.memoizedProps;
      if (br(i, r) && e.ref === t.ref)
        if (((rt = !1), (t.pendingProps = r = i), (e.lanes & o) !== 0))
          (e.flags & 131072) !== 0 && (rt = !0);
        else return ((t.lanes = e.lanes), Wt(e, t, o));
    }
    return Ps(e, t, n, r, o);
  }
  function Ju(e, t, n) {
    var r = t.pendingProps,
      o = r.children,
      i = e !== null ? e.memoizedState : null;
    if (r.mode === "hidden")
      if ((t.mode & 1) === 0)
        ((t.memoizedState = {
          baseLanes: 0,
          cachePool: null,
          transitions: null,
        }),
          xe(er, dt),
          (dt |= n));
      else {
        if ((n & 1073741824) === 0)
          return (
            (e = i !== null ? i.baseLanes | n : n),
            (t.lanes = t.childLanes = 1073741824),
            (t.memoizedState = {
              baseLanes: e,
              cachePool: null,
              transitions: null,
            }),
            (t.updateQueue = null),
            xe(er, dt),
            (dt |= e),
            null
          );
        ((t.memoizedState = {
          baseLanes: 0,
          cachePool: null,
          transitions: null,
        }),
          (r = i !== null ? i.baseLanes : n),
          xe(er, dt),
          (dt |= r));
      }
    else
      (i !== null ? ((r = i.baseLanes | n), (t.memoizedState = null)) : (r = n),
        xe(er, dt),
        (dt |= r));
    return (Xe(e, t, o, n), t.child);
  }
  function ec(e, t) {
    var n = t.ref;
    ((e === null && n !== null) || (e !== null && e.ref !== n)) &&
      ((t.flags |= 512), (t.flags |= 2097152));
  }
  function Ps(e, t, n, r, o) {
    var i = nt(n) ? hn : Ge.current;
    return (
      (i = Hn(t, i)),
      Yn(t, o),
      (n = vs(e, t, n, r, i, o)),
      (r = ws()),
      e !== null && !rt
        ? ((t.updateQueue = e.updateQueue),
          (t.flags &= -2053),
          (e.lanes &= ~o),
          Wt(e, t, o))
        : (Ce && r && ts(t), (t.flags |= 1), Xe(e, t, n, o), t.child)
    );
  }
  function tc(e, t, n, r, o) {
    if (nt(n)) {
      var i = !0;
      xo(t);
    } else i = !1;
    if ((Yn(t, o), t.stateNode === null))
      (Do(e, t), Bu(t, n, r), js(t, n, r, o), (r = !0));
    else if (e === null) {
      var c = t.stateNode,
        f = t.memoizedProps;
      c.props = f;
      var m = c.context,
        x = n.contextType;
      typeof x == "object" && x !== null
        ? (x = mt(x))
        : ((x = nt(n) ? hn : Ge.current), (x = Hn(t, x)));
      var A = n.getDerivedStateFromProps,
        P =
          typeof A == "function" ||
          typeof c.getSnapshotBeforeUpdate == "function";
      (P ||
        (typeof c.UNSAFE_componentWillReceiveProps != "function" &&
          typeof c.componentWillReceiveProps != "function") ||
        ((f !== r || m !== x) && Hu(t, c, r, x)),
        (tn = !1));
      var C = t.memoizedState;
      ((c.state = C),
        zo(t, r, c, o),
        (m = t.memoizedState),
        f !== r || C !== m || tt.current || tn
          ? (typeof A == "function" && (Es(t, n, A, r), (m = t.memoizedState)),
            (f = tn || $u(t, n, f, r, C, m, x))
              ? (P ||
                  (typeof c.UNSAFE_componentWillMount != "function" &&
                    typeof c.componentWillMount != "function") ||
                  (typeof c.componentWillMount == "function" &&
                    c.componentWillMount(),
                  typeof c.UNSAFE_componentWillMount == "function" &&
                    c.UNSAFE_componentWillMount()),
                typeof c.componentDidMount == "function" &&
                  (t.flags |= 4194308))
              : (typeof c.componentDidMount == "function" &&
                  (t.flags |= 4194308),
                (t.memoizedProps = r),
                (t.memoizedState = m)),
            (c.props = r),
            (c.state = m),
            (c.context = x),
            (r = f))
          : (typeof c.componentDidMount == "function" && (t.flags |= 4194308),
            (r = !1)));
    } else {
      ((c = t.stateNode),
        yu(e, t),
        (f = t.memoizedProps),
        (x = t.type === t.elementType ? f : bt(t.type, f)),
        (c.props = x),
        (P = t.pendingProps),
        (C = c.context),
        (m = n.contextType),
        typeof m == "object" && m !== null
          ? (m = mt(m))
          : ((m = nt(n) ? hn : Ge.current), (m = Hn(t, m))));
      var L = n.getDerivedStateFromProps;
      ((A =
        typeof L == "function" ||
        typeof c.getSnapshotBeforeUpdate == "function") ||
        (typeof c.UNSAFE_componentWillReceiveProps != "function" &&
          typeof c.componentWillReceiveProps != "function") ||
        ((f !== P || C !== m) && Hu(t, c, r, m)),
        (tn = !1),
        (C = t.memoizedState),
        (c.state = C),
        zo(t, r, c, o));
      var N = t.memoizedState;
      f !== P || C !== N || tt.current || tn
        ? (typeof L == "function" && (Es(t, n, L, r), (N = t.memoizedState)),
          (x = tn || $u(t, n, x, r, C, N, m) || !1)
            ? (A ||
                (typeof c.UNSAFE_componentWillUpdate != "function" &&
                  typeof c.componentWillUpdate != "function") ||
                (typeof c.componentWillUpdate == "function" &&
                  c.componentWillUpdate(r, N, m),
                typeof c.UNSAFE_componentWillUpdate == "function" &&
                  c.UNSAFE_componentWillUpdate(r, N, m)),
              typeof c.componentDidUpdate == "function" && (t.flags |= 4),
              typeof c.getSnapshotBeforeUpdate == "function" &&
                (t.flags |= 1024))
            : (typeof c.componentDidUpdate != "function" ||
                (f === e.memoizedProps && C === e.memoizedState) ||
                (t.flags |= 4),
              typeof c.getSnapshotBeforeUpdate != "function" ||
                (f === e.memoizedProps && C === e.memoizedState) ||
                (t.flags |= 1024),
              (t.memoizedProps = r),
              (t.memoizedState = N)),
          (c.props = r),
          (c.state = N),
          (c.context = m),
          (r = x))
        : (typeof c.componentDidUpdate != "function" ||
            (f === e.memoizedProps && C === e.memoizedState) ||
            (t.flags |= 4),
          typeof c.getSnapshotBeforeUpdate != "function" ||
            (f === e.memoizedProps && C === e.memoizedState) ||
            (t.flags |= 1024),
          (r = !1));
    }
    return zs(e, t, n, r, i, o);
  }
  function zs(e, t, n, r, o, i) {
    ec(e, t);
    var c = (t.flags & 128) !== 0;
    if (!r && !c) return (o && su(t, n, !1), Wt(e, t, i));
    ((r = t.stateNode), (jp.current = t));
    var f =
      c && typeof n.getDerivedStateFromError != "function" ? null : r.render();
    return (
      (t.flags |= 1),
      e !== null && c
        ? ((t.child = Qn(t, e.child, null, i)), (t.child = Qn(t, null, f, i)))
        : Xe(e, t, f, i),
      (t.memoizedState = r.state),
      o && su(t, n, !0),
      t.child
    );
  }
  function nc(e) {
    var t = e.stateNode;
    (t.pendingContext
      ? ou(e, t.pendingContext, t.pendingContext !== t.context)
      : t.context && ou(e, t.context, !1),
      fs(e, t.containerInfo));
  }
  function rc(e, t, n, r, o) {
    return (Gn(), is(o), (t.flags |= 256), Xe(e, t, n, r), t.child);
  }
  var _s = { dehydrated: null, treeContext: null, retryLane: 0 };
  function Ts(e) {
    return { baseLanes: e, cachePool: null, transitions: null };
  }
  function oc(e, t, n) {
    var r = t.pendingProps,
      o = ze.current,
      i = !1,
      c = (t.flags & 128) !== 0,
      f;
    if (
      ((f = c) ||
        (f = e !== null && e.memoizedState === null ? !1 : (o & 2) !== 0),
      f
        ? ((i = !0), (t.flags &= -129))
        : (e === null || e.memoizedState !== null) && (o |= 1),
      xe(ze, o & 1),
      e === null)
    )
      return (
        os(t),
        (e = t.memoizedState),
        e !== null && ((e = e.dehydrated), e !== null)
          ? ((t.mode & 1) === 0
              ? (t.lanes = 1)
              : e.data === "$!"
                ? (t.lanes = 8)
                : (t.lanes = 1073741824),
            null)
          : ((c = r.children),
            (e = r.fallback),
            i
              ? ((r = t.mode),
                (i = t.child),
                (c = { mode: "hidden", children: c }),
                (r & 1) === 0 && i !== null
                  ? ((i.childLanes = 0), (i.pendingProps = c))
                  : (i = Yo(c, r, 0, null)),
                (e = jn(e, r, n, null)),
                (i.return = t),
                (e.return = t),
                (i.sibling = e),
                (t.child = i),
                (t.child.memoizedState = Ts(n)),
                (t.memoizedState = _s),
                e)
              : Rs(t, c))
      );
    if (((o = e.memoizedState), o !== null && ((f = o.dehydrated), f !== null)))
      return Cp(e, t, c, r, f, o, n);
    if (i) {
      ((i = r.fallback), (c = t.mode), (o = e.child), (f = o.sibling));
      var m = { mode: "hidden", children: r.children };
      return (
        (c & 1) === 0 && t.child !== o
          ? ((r = t.child),
            (r.childLanes = 0),
            (r.pendingProps = m),
            (t.deletions = null))
          : ((r = un(o, m)), (r.subtreeFlags = o.subtreeFlags & 14680064)),
        f !== null ? (i = un(f, i)) : ((i = jn(i, c, n, null)), (i.flags |= 2)),
        (i.return = t),
        (r.return = t),
        (r.sibling = i),
        (t.child = r),
        (r = i),
        (i = t.child),
        (c = e.child.memoizedState),
        (c =
          c === null
            ? Ts(n)
            : {
                baseLanes: c.baseLanes | n,
                cachePool: null,
                transitions: c.transitions,
              }),
        (i.memoizedState = c),
        (i.childLanes = e.childLanes & ~n),
        (t.memoizedState = _s),
        r
      );
    }
    return (
      (i = e.child),
      (e = i.sibling),
      (r = un(i, { mode: "visible", children: r.children })),
      (t.mode & 1) === 0 && (r.lanes = n),
      (r.return = t),
      (r.sibling = null),
      e !== null &&
        ((n = t.deletions),
        n === null ? ((t.deletions = [e]), (t.flags |= 16)) : n.push(e)),
      (t.child = r),
      (t.memoizedState = null),
      r
    );
  }
  function Rs(e, t) {
    return (
      (t = Yo({ mode: "visible", children: t }, e.mode, 0, null)),
      (t.return = e),
      (e.child = t)
    );
  }
  function Io(e, t, n, r) {
    return (
      r !== null && is(r),
      Qn(t, e.child, null, n),
      (e = Rs(t, t.pendingProps.children)),
      (e.flags |= 2),
      (t.memoizedState = null),
      e
    );
  }
  function Cp(e, t, n, r, o, i, c) {
    if (n)
      return t.flags & 256
        ? ((t.flags &= -257), (r = Cs(Error(l(422)))), Io(e, t, c, r))
        : t.memoizedState !== null
          ? ((t.child = e.child), (t.flags |= 128), null)
          : ((i = r.fallback),
            (o = t.mode),
            (r = Yo({ mode: "visible", children: r.children }, o, 0, null)),
            (i = jn(i, o, c, null)),
            (i.flags |= 2),
            (r.return = t),
            (i.return = t),
            (r.sibling = i),
            (t.child = r),
            (t.mode & 1) !== 0 && Qn(t, e.child, null, c),
            (t.child.memoizedState = Ts(c)),
            (t.memoizedState = _s),
            i);
    if ((t.mode & 1) === 0) return Io(e, t, c, null);
    if (o.data === "$!") {
      if (((r = o.nextSibling && o.nextSibling.dataset), r)) var f = r.dgst;
      return (
        (r = f),
        (i = Error(l(419))),
        (r = Cs(i, r, void 0)),
        Io(e, t, c, r)
      );
    }
    if (((f = (c & e.childLanes) !== 0), rt || f)) {
      if (((r = $e), r !== null)) {
        switch (c & -c) {
          case 4:
            o = 2;
            break;
          case 16:
            o = 8;
            break;
          case 64:
          case 128:
          case 256:
          case 512:
          case 1024:
          case 2048:
          case 4096:
          case 8192:
          case 16384:
          case 32768:
          case 65536:
          case 131072:
          case 262144:
          case 524288:
          case 1048576:
          case 2097152:
          case 4194304:
          case 8388608:
          case 16777216:
          case 33554432:
          case 67108864:
            o = 32;
            break;
          case 536870912:
            o = 268435456;
            break;
          default:
            o = 0;
        }
        ((o = (o & (r.suspendedLanes | c)) !== 0 ? 0 : o),
          o !== 0 &&
            o !== i.retryLane &&
            ((i.retryLane = o), Ut(e, o), Ct(r, e, o, -1)));
      }
      return (Qs(), (r = Cs(Error(l(421)))), Io(e, t, c, r));
    }
    return o.data === "$?"
      ? ((t.flags |= 128),
        (t.child = e.child),
        (t = Up.bind(null, e)),
        (o._reactRetry = t),
        null)
      : ((e = i.treeContext),
        (ct = qt(o.nextSibling)),
        (ut = t),
        (Ce = !0),
        (St = null),
        e !== null &&
          ((ft[pt++] = It),
          (ft[pt++] = Dt),
          (ft[pt++] = gn),
          (It = e.id),
          (Dt = e.overflow),
          (gn = t)),
        (t = Rs(t, r.children)),
        (t.flags |= 4096),
        t);
  }
  function ic(e, t, n) {
    e.lanes |= t;
    var r = e.alternate;
    (r !== null && (r.lanes |= t), us(e.return, t, n));
  }
  function Ls(e, t, n, r, o) {
    var i = e.memoizedState;
    i === null
      ? (e.memoizedState = {
          isBackwards: t,
          rendering: null,
          renderingStartTime: 0,
          last: r,
          tail: n,
          tailMode: o,
        })
      : ((i.isBackwards = t),
        (i.rendering = null),
        (i.renderingStartTime = 0),
        (i.last = r),
        (i.tail = n),
        (i.tailMode = o));
  }
  function sc(e, t, n) {
    var r = t.pendingProps,
      o = r.revealOrder,
      i = r.tail;
    if ((Xe(e, t, r.children, n), (r = ze.current), (r & 2) !== 0))
      ((r = (r & 1) | 2), (t.flags |= 128));
    else {
      if (e !== null && (e.flags & 128) !== 0)
        e: for (e = t.child; e !== null;) {
          if (e.tag === 13) e.memoizedState !== null && ic(e, n, t);
          else if (e.tag === 19) ic(e, n, t);
          else if (e.child !== null) {
            ((e.child.return = e), (e = e.child));
            continue;
          }
          if (e === t) break e;
          for (; e.sibling === null;) {
            if (e.return === null || e.return === t) break e;
            e = e.return;
          }
          ((e.sibling.return = e.return), (e = e.sibling));
        }
      r &= 1;
    }
    if ((xe(ze, r), (t.mode & 1) === 0)) t.memoizedState = null;
    else
      switch (o) {
        case "forwards":
          for (n = t.child, o = null; n !== null;)
            ((e = n.alternate),
              e !== null && _o(e) === null && (o = n),
              (n = n.sibling));
          ((n = o),
            n === null
              ? ((o = t.child), (t.child = null))
              : ((o = n.sibling), (n.sibling = null)),
            Ls(t, !1, o, n, i));
          break;
        case "backwards":
          for (n = null, o = t.child, t.child = null; o !== null;) {
            if (((e = o.alternate), e !== null && _o(e) === null)) {
              t.child = o;
              break;
            }
            ((e = o.sibling), (o.sibling = n), (n = o), (o = e));
          }
          Ls(t, !0, n, null, i);
          break;
        case "together":
          Ls(t, !1, null, null, void 0);
          break;
        default:
          t.memoizedState = null;
      }
    return t.child;
  }
  function Do(e, t) {
    (t.mode & 1) === 0 &&
      e !== null &&
      ((e.alternate = null), (t.alternate = null), (t.flags |= 2));
  }
  function Wt(e, t, n) {
    if (
      (e !== null && (t.dependencies = e.dependencies),
      (kn |= t.lanes),
      (n & t.childLanes) === 0)
    )
      return null;
    if (e !== null && t.child !== e.child) throw Error(l(153));
    if (t.child !== null) {
      for (
        e = t.child, n = un(e, e.pendingProps), t.child = n, n.return = t;
        e.sibling !== null;
      )
        ((e = e.sibling),
          (n = n.sibling = un(e, e.pendingProps)),
          (n.return = t));
      n.sibling = null;
    }
    return t.child;
  }
  function Ap(e, t, n) {
    switch (t.tag) {
      case 3:
        (nc(t), Gn());
        break;
      case 5:
        xu(t);
        break;
      case 1:
        nt(t.type) && xo(t);
        break;
      case 4:
        fs(t, t.stateNode.containerInfo);
        break;
      case 10:
        var r = t.type._context,
          o = t.memoizedProps.value;
        (xe(Co, r._currentValue), (r._currentValue = o));
        break;
      case 13:
        if (((r = t.memoizedState), r !== null))
          return r.dehydrated !== null
            ? (xe(ze, ze.current & 1), (t.flags |= 128), null)
            : (n & t.child.childLanes) !== 0
              ? oc(e, t, n)
              : (xe(ze, ze.current & 1),
                (e = Wt(e, t, n)),
                e !== null ? e.sibling : null);
        xe(ze, ze.current & 1);
        break;
      case 19:
        if (((r = (n & t.childLanes) !== 0), (e.flags & 128) !== 0)) {
          if (r) return sc(e, t, n);
          t.flags |= 128;
        }
        if (
          ((o = t.memoizedState),
          o !== null &&
            ((o.rendering = null), (o.tail = null), (o.lastEffect = null)),
          xe(ze, ze.current),
          r)
        )
          break;
        return null;
      case 22:
      case 23:
        return ((t.lanes = 0), Ju(e, t, n));
    }
    return Wt(e, t, n);
  }
  var ac, Ms, lc, uc;
  ((ac = function (e, t) {
    for (var n = t.child; n !== null;) {
      if (n.tag === 5 || n.tag === 6) e.appendChild(n.stateNode);
      else if (n.tag !== 4 && n.child !== null) {
        ((n.child.return = n), (n = n.child));
        continue;
      }
      if (n === t) break;
      for (; n.sibling === null;) {
        if (n.return === null || n.return === t) return;
        n = n.return;
      }
      ((n.sibling.return = n.return), (n = n.sibling));
    }
  }),
    (Ms = function () {}),
    (lc = function (e, t, n, r) {
      var o = e.memoizedProps;
      if (o !== r) {
        ((e = t.stateNode), wn(_t.current));
        var i = null;
        switch (n) {
          case "input":
            ((o = Lt(e, o)), (r = Lt(e, r)), (i = []));
            break;
          case "select":
            ((o = _({}, o, { value: void 0 })),
              (r = _({}, r, { value: void 0 })),
              (i = []));
            break;
          case "textarea":
            ((o = fi(e, o)), (r = fi(e, r)), (i = []));
            break;
          default:
            typeof o.onClick != "function" &&
              typeof r.onClick == "function" &&
              (e.onclick = yo);
        }
        mi(n, r);
        var c;
        n = null;
        for (x in o)
          if (!r.hasOwnProperty(x) && o.hasOwnProperty(x) && o[x] != null)
            if (x === "style") {
              var f = o[x];
              for (c in f) f.hasOwnProperty(c) && (n || (n = {}), (n[c] = ""));
            } else
              x !== "dangerouslySetInnerHTML" &&
                x !== "children" &&
                x !== "suppressContentEditableWarning" &&
                x !== "suppressHydrationWarning" &&
                x !== "autoFocus" &&
                (p.hasOwnProperty(x)
                  ? i || (i = [])
                  : (i = i || []).push(x, null));
        for (x in r) {
          var m = r[x];
          if (
            ((f = o?.[x]),
            r.hasOwnProperty(x) && m !== f && (m != null || f != null))
          )
            if (x === "style")
              if (f) {
                for (c in f)
                  !f.hasOwnProperty(c) ||
                    (m && m.hasOwnProperty(c)) ||
                    (n || (n = {}), (n[c] = ""));
                for (c in m)
                  m.hasOwnProperty(c) &&
                    f[c] !== m[c] &&
                    (n || (n = {}), (n[c] = m[c]));
              } else (n || (i || (i = []), i.push(x, n)), (n = m));
            else
              x === "dangerouslySetInnerHTML"
                ? ((m = m ? m.__html : void 0),
                  (f = f ? f.__html : void 0),
                  m != null && f !== m && (i = i || []).push(x, m))
                : x === "children"
                  ? (typeof m != "string" && typeof m != "number") ||
                    (i = i || []).push(x, "" + m)
                  : x !== "suppressContentEditableWarning" &&
                    x !== "suppressHydrationWarning" &&
                    (p.hasOwnProperty(x)
                      ? (m != null && x === "onScroll" && ke("scroll", e),
                        i || f === m || (i = []))
                      : (i = i || []).push(x, m));
        }
        n && (i = i || []).push("style", n);
        var x = i;
        (t.updateQueue = x) && (t.flags |= 4);
      }
    }),
    (uc = function (e, t, n, r) {
      n !== r && (t.flags |= 4);
    }));
  function Dr(e, t) {
    if (!Ce)
      switch (e.tailMode) {
        case "hidden":
          t = e.tail;
          for (var n = null; t !== null;)
            (t.alternate !== null && (n = t), (t = t.sibling));
          n === null ? (e.tail = null) : (n.sibling = null);
          break;
        case "collapsed":
          n = e.tail;
          for (var r = null; n !== null;)
            (n.alternate !== null && (r = n), (n = n.sibling));
          r === null
            ? t || e.tail === null
              ? (e.tail = null)
              : (e.tail.sibling = null)
            : (r.sibling = null);
      }
  }
  function Ze(e) {
    var t = e.alternate !== null && e.alternate.child === e.child,
      n = 0,
      r = 0;
    if (t)
      for (var o = e.child; o !== null;)
        ((n |= o.lanes | o.childLanes),
          (r |= o.subtreeFlags & 14680064),
          (r |= o.flags & 14680064),
          (o.return = e),
          (o = o.sibling));
    else
      for (o = e.child; o !== null;)
        ((n |= o.lanes | o.childLanes),
          (r |= o.subtreeFlags),
          (r |= o.flags),
          (o.return = e),
          (o = o.sibling));
    return ((e.subtreeFlags |= r), (e.childLanes = n), t);
  }
  function Pp(e, t, n) {
    var r = t.pendingProps;
    switch ((ns(t), t.tag)) {
      case 2:
      case 16:
      case 15:
      case 0:
      case 11:
      case 7:
      case 8:
      case 12:
      case 9:
      case 14:
        return (Ze(t), null);
      case 1:
        return (nt(t.type) && wo(), Ze(t), null);
      case 3:
        return (
          (r = t.stateNode),
          qn(),
          Se(tt),
          Se(Ge),
          hs(),
          r.pendingContext &&
            ((r.context = r.pendingContext), (r.pendingContext = null)),
          (e === null || e.child === null) &&
            (Eo(t)
              ? (t.flags |= 4)
              : e === null ||
                (e.memoizedState.isDehydrated && (t.flags & 256) === 0) ||
                ((t.flags |= 1024), St !== null && (Vs(St), (St = null)))),
          Ms(e, t),
          Ze(t),
          null
        );
      case 5:
        ps(t);
        var o = wn(Lr.current);
        if (((n = t.type), e !== null && t.stateNode != null))
          (lc(e, t, n, r, o),
            e.ref !== t.ref && ((t.flags |= 512), (t.flags |= 2097152)));
        else {
          if (!r) {
            if (t.stateNode === null) throw Error(l(166));
            return (Ze(t), null);
          }
          if (((e = wn(_t.current)), Eo(t))) {
            ((r = t.stateNode), (n = t.type));
            var i = t.memoizedProps;
            switch (((r[zt] = t), (r[Pr] = i), (e = (t.mode & 1) !== 0), n)) {
              case "dialog":
                (ke("cancel", r), ke("close", r));
                break;
              case "iframe":
              case "object":
              case "embed":
                ke("load", r);
                break;
              case "video":
              case "audio":
                for (o = 0; o < jr.length; o++) ke(jr[o], r);
                break;
              case "source":
                ke("error", r);
                break;
              case "img":
              case "image":
              case "link":
                (ke("error", r), ke("load", r));
                break;
              case "details":
                ke("toggle", r);
                break;
              case "input":
                (et(r, i), ke("invalid", r));
                break;
              case "select":
                ((r._wrapperState = { wasMultiple: !!i.multiple }),
                  ke("invalid", r));
                break;
              case "textarea":
                (Ka(r, i), ke("invalid", r));
            }
            (mi(n, i), (o = null));
            for (var c in i)
              if (i.hasOwnProperty(c)) {
                var f = i[c];
                c === "children"
                  ? typeof f == "string"
                    ? r.textContent !== f &&
                      (i.suppressHydrationWarning !== !0 &&
                        go(r.textContent, f, e),
                      (o = ["children", f]))
                    : typeof f == "number" &&
                      r.textContent !== "" + f &&
                      (i.suppressHydrationWarning !== !0 &&
                        go(r.textContent, f, e),
                      (o = ["children", "" + f]))
                  : p.hasOwnProperty(c) &&
                    f != null &&
                    c === "onScroll" &&
                    ke("scroll", r);
              }
            switch (n) {
              case "input":
                (qe(r), Va(r, i, !0));
                break;
              case "textarea":
                (qe(r), Qa(r));
                break;
              case "select":
              case "option":
                break;
              default:
                typeof i.onClick == "function" && (r.onclick = yo);
            }
            ((r = o), (t.updateQueue = r), r !== null && (t.flags |= 4));
          } else {
            ((c = o.nodeType === 9 ? o : o.ownerDocument),
              e === "http://www.w3.org/1999/xhtml" && (e = Za(n)),
              e === "http://www.w3.org/1999/xhtml"
                ? n === "script"
                  ? ((e = c.createElement("div")),
                    (e.innerHTML = "<script><\/script>"),
                    (e = e.removeChild(e.firstChild)))
                  : typeof r.is == "string"
                    ? (e = c.createElement(n, { is: r.is }))
                    : ((e = c.createElement(n)),
                      n === "select" &&
                        ((c = e),
                        r.multiple
                          ? (c.multiple = !0)
                          : r.size && (c.size = r.size)))
                : (e = c.createElementNS(e, n)),
              (e[zt] = t),
              (e[Pr] = r),
              ac(e, t, !1, !1),
              (t.stateNode = e));
            e: {
              switch (((c = hi(n, r)), n)) {
                case "dialog":
                  (ke("cancel", e), ke("close", e), (o = r));
                  break;
                case "iframe":
                case "object":
                case "embed":
                  (ke("load", e), (o = r));
                  break;
                case "video":
                case "audio":
                  for (o = 0; o < jr.length; o++) ke(jr[o], e);
                  o = r;
                  break;
                case "source":
                  (ke("error", e), (o = r));
                  break;
                case "img":
                case "image":
                case "link":
                  (ke("error", e), ke("load", e), (o = r));
                  break;
                case "details":
                  (ke("toggle", e), (o = r));
                  break;
                case "input":
                  (et(e, r), (o = Lt(e, r)), ke("invalid", e));
                  break;
                case "option":
                  o = r;
                  break;
                case "select":
                  ((e._wrapperState = { wasMultiple: !!r.multiple }),
                    (o = _({}, r, { value: void 0 })),
                    ke("invalid", e));
                  break;
                case "textarea":
                  (Ka(e, r), (o = fi(e, r)), ke("invalid", e));
                  break;
                default:
                  o = r;
              }
              (mi(n, o), (f = o));
              for (i in f)
                if (f.hasOwnProperty(i)) {
                  var m = f[i];
                  i === "style"
                    ? Xa(e, m)
                    : i === "dangerouslySetInnerHTML"
                      ? ((m = m ? m.__html : void 0), m != null && Ya(e, m))
                      : i === "children"
                        ? typeof m == "string"
                          ? (n !== "textarea" || m !== "") && sr(e, m)
                          : typeof m == "number" && sr(e, "" + m)
                        : i !== "suppressContentEditableWarning" &&
                          i !== "suppressHydrationWarning" &&
                          i !== "autoFocus" &&
                          (p.hasOwnProperty(i)
                            ? m != null && i === "onScroll" && ke("scroll", e)
                            : m != null && be(e, i, m, c));
                }
              switch (n) {
                case "input":
                  (qe(e), Va(e, r, !1));
                  break;
                case "textarea":
                  (qe(e), Qa(e));
                  break;
                case "option":
                  r.value != null && e.setAttribute("value", "" + fe(r.value));
                  break;
                case "select":
                  ((e.multiple = !!r.multiple),
                    (i = r.value),
                    i != null
                      ? Rn(e, !!r.multiple, i, !1)
                      : r.defaultValue != null &&
                        Rn(e, !!r.multiple, r.defaultValue, !0));
                  break;
                default:
                  typeof o.onClick == "function" && (e.onclick = yo);
              }
              switch (n) {
                case "button":
                case "input":
                case "select":
                case "textarea":
                  r = !!r.autoFocus;
                  break e;
                case "img":
                  r = !0;
                  break e;
                default:
                  r = !1;
              }
            }
            r && (t.flags |= 4);
          }
          t.ref !== null && ((t.flags |= 512), (t.flags |= 2097152));
        }
        return (Ze(t), null);
      case 6:
        if (e && t.stateNode != null) uc(e, t, e.memoizedProps, r);
        else {
          if (typeof r != "string" && t.stateNode === null) throw Error(l(166));
          if (((n = wn(Lr.current)), wn(_t.current), Eo(t))) {
            if (
              ((r = t.stateNode),
              (n = t.memoizedProps),
              (r[zt] = t),
              (i = r.nodeValue !== n) && ((e = ut), e !== null))
            )
              switch (e.tag) {
                case 3:
                  go(r.nodeValue, n, (e.mode & 1) !== 0);
                  break;
                case 5:
                  e.memoizedProps.suppressHydrationWarning !== !0 &&
                    go(r.nodeValue, n, (e.mode & 1) !== 0);
              }
            i && (t.flags |= 4);
          } else
            ((r = (n.nodeType === 9 ? n : n.ownerDocument).createTextNode(r)),
              (r[zt] = t),
              (t.stateNode = r));
        }
        return (Ze(t), null);
      case 13:
        if (
          (Se(ze),
          (r = t.memoizedState),
          e === null ||
            (e.memoizedState !== null && e.memoizedState.dehydrated !== null))
        ) {
          if (Ce && ct !== null && (t.mode & 1) !== 0 && (t.flags & 128) === 0)
            (fu(), Gn(), (t.flags |= 98560), (i = !1));
          else if (((i = Eo(t)), r !== null && r.dehydrated !== null)) {
            if (e === null) {
              if (!i) throw Error(l(318));
              if (
                ((i = t.memoizedState),
                (i = i !== null ? i.dehydrated : null),
                !i)
              )
                throw Error(l(317));
              i[zt] = t;
            } else
              (Gn(),
                (t.flags & 128) === 0 && (t.memoizedState = null),
                (t.flags |= 4));
            (Ze(t), (i = !1));
          } else (St !== null && (Vs(St), (St = null)), (i = !0));
          if (!i) return t.flags & 65536 ? t : null;
        }
        return (t.flags & 128) !== 0
          ? ((t.lanes = n), t)
          : ((r = r !== null),
            r !== (e !== null && e.memoizedState !== null) &&
              r &&
              ((t.child.flags |= 8192),
              (t.mode & 1) !== 0 &&
                (e === null || (ze.current & 1) !== 0
                  ? De === 0 && (De = 3)
                  : Qs())),
            t.updateQueue !== null && (t.flags |= 4),
            Ze(t),
            null);
      case 4:
        return (
          qn(),
          Ms(e, t),
          e === null && Cr(t.stateNode.containerInfo),
          Ze(t),
          null
        );
      case 10:
        return (ls(t.type._context), Ze(t), null);
      case 17:
        return (nt(t.type) && wo(), Ze(t), null);
      case 19:
        if ((Se(ze), (i = t.memoizedState), i === null)) return (Ze(t), null);
        if (((r = (t.flags & 128) !== 0), (c = i.rendering), c === null))
          if (r) Dr(i, !1);
          else {
            if (De !== 0 || (e !== null && (e.flags & 128) !== 0))
              for (e = t.child; e !== null;) {
                if (((c = _o(e)), c !== null)) {
                  for (
                    t.flags |= 128,
                      Dr(i, !1),
                      r = c.updateQueue,
                      r !== null && ((t.updateQueue = r), (t.flags |= 4)),
                      t.subtreeFlags = 0,
                      r = n,
                      n = t.child;
                    n !== null;
                  )
                    ((i = n),
                      (e = r),
                      (i.flags &= 14680066),
                      (c = i.alternate),
                      c === null
                        ? ((i.childLanes = 0),
                          (i.lanes = e),
                          (i.child = null),
                          (i.subtreeFlags = 0),
                          (i.memoizedProps = null),
                          (i.memoizedState = null),
                          (i.updateQueue = null),
                          (i.dependencies = null),
                          (i.stateNode = null))
                        : ((i.childLanes = c.childLanes),
                          (i.lanes = c.lanes),
                          (i.child = c.child),
                          (i.subtreeFlags = 0),
                          (i.deletions = null),
                          (i.memoizedProps = c.memoizedProps),
                          (i.memoizedState = c.memoizedState),
                          (i.updateQueue = c.updateQueue),
                          (i.type = c.type),
                          (e = c.dependencies),
                          (i.dependencies =
                            e === null
                              ? null
                              : {
                                  lanes: e.lanes,
                                  firstContext: e.firstContext,
                                })),
                      (n = n.sibling));
                  return (xe(ze, (ze.current & 1) | 2), t.child);
                }
                e = e.sibling;
              }
            i.tail !== null &&
              Me() > tr &&
              ((t.flags |= 128), (r = !0), Dr(i, !1), (t.lanes = 4194304));
          }
        else {
          if (!r)
            if (((e = _o(c)), e !== null)) {
              if (
                ((t.flags |= 128),
                (r = !0),
                (n = e.updateQueue),
                n !== null && ((t.updateQueue = n), (t.flags |= 4)),
                Dr(i, !0),
                i.tail === null &&
                  i.tailMode === "hidden" &&
                  !c.alternate &&
                  !Ce)
              )
                return (Ze(t), null);
            } else
              2 * Me() - i.renderingStartTime > tr &&
                n !== 1073741824 &&
                ((t.flags |= 128), (r = !0), Dr(i, !1), (t.lanes = 4194304));
          i.isBackwards
            ? ((c.sibling = t.child), (t.child = c))
            : ((n = i.last),
              n !== null ? (n.sibling = c) : (t.child = c),
              (i.last = c));
        }
        return i.tail !== null
          ? ((t = i.tail),
            (i.rendering = t),
            (i.tail = t.sibling),
            (i.renderingStartTime = Me()),
            (t.sibling = null),
            (n = ze.current),
            xe(ze, r ? (n & 1) | 2 : n & 1),
            t)
          : (Ze(t), null);
      case 22:
      case 23:
        return (
          Gs(),
          (r = t.memoizedState !== null),
          e !== null && (e.memoizedState !== null) !== r && (t.flags |= 8192),
          r && (t.mode & 1) !== 0
            ? (dt & 1073741824) !== 0 &&
              (Ze(t), t.subtreeFlags & 6 && (t.flags |= 8192))
            : Ze(t),
          null
        );
      case 24:
        return null;
      case 25:
        return null;
    }
    throw Error(l(156, t.tag));
  }
  function zp(e, t) {
    switch ((ns(t), t.tag)) {
      case 1:
        return (
          nt(t.type) && wo(),
          (e = t.flags),
          e & 65536 ? ((t.flags = (e & -65537) | 128), t) : null
        );
      case 3:
        return (
          qn(),
          Se(tt),
          Se(Ge),
          hs(),
          (e = t.flags),
          (e & 65536) !== 0 && (e & 128) === 0
            ? ((t.flags = (e & -65537) | 128), t)
            : null
        );
      case 5:
        return (ps(t), null);
      case 13:
        if (
          (Se(ze), (e = t.memoizedState), e !== null && e.dehydrated !== null)
        ) {
          if (t.alternate === null) throw Error(l(340));
          Gn();
        }
        return (
          (e = t.flags),
          e & 65536 ? ((t.flags = (e & -65537) | 128), t) : null
        );
      case 19:
        return (Se(ze), null);
      case 4:
        return (qn(), null);
      case 10:
        return (ls(t.type._context), null);
      case 22:
      case 23:
        return (Gs(), null);
      case 24:
        return null;
      default:
        return null;
    }
  }
  var Uo = !1,
    Ye = !1,
    _p = typeof WeakSet == "function" ? WeakSet : Set,
    M = null;
  function Jn(e, t) {
    var n = e.ref;
    if (n !== null)
      if (typeof n == "function")
        try {
          n(null);
        } catch (r) {
          Te(e, t, r);
        }
      else n.current = null;
  }
  function Os(e, t, n) {
    try {
      n();
    } catch (r) {
      Te(e, t, r);
    }
  }
  var cc = !1;
  function Tp(e, t) {
    if (((Gi = oo), (e = $l()), Ui(e))) {
      if ("selectionStart" in e)
        var n = { start: e.selectionStart, end: e.selectionEnd };
      else
        e: {
          n = ((n = e.ownerDocument) && n.defaultView) || window;
          var r = n.getSelection && n.getSelection();
          if (r && r.rangeCount !== 0) {
            n = r.anchorNode;
            var o = r.anchorOffset,
              i = r.focusNode;
            r = r.focusOffset;
            try {
              (n.nodeType, i.nodeType);
            } catch {
              n = null;
              break e;
            }
            var c = 0,
              f = -1,
              m = -1,
              x = 0,
              A = 0,
              P = e,
              C = null;
            t: for (;;) {
              for (
                var L;
                P !== n || (o !== 0 && P.nodeType !== 3) || (f = c + o),
                  P !== i || (r !== 0 && P.nodeType !== 3) || (m = c + r),
                  P.nodeType === 3 && (c += P.nodeValue.length),
                  (L = P.firstChild) !== null;
              )
                ((C = P), (P = L));
              for (;;) {
                if (P === e) break t;
                if (
                  (C === n && ++x === o && (f = c),
                  C === i && ++A === r && (m = c),
                  (L = P.nextSibling) !== null)
                )
                  break;
                ((P = C), (C = P.parentNode));
              }
              P = L;
            }
            n = f === -1 || m === -1 ? null : { start: f, end: m };
          } else n = null;
        }
      n = n || { start: 0, end: 0 };
    } else n = null;
    for (
      Qi = { focusedElem: e, selectionRange: n }, oo = !1, M = t;
      M !== null;
    )
      if (((t = M), (e = t.child), (t.subtreeFlags & 1028) !== 0 && e !== null))
        ((e.return = t), (M = e));
      else
        for (; M !== null;) {
          t = M;
          try {
            var N = t.alternate;
            if ((t.flags & 1024) !== 0)
              switch (t.tag) {
                case 0:
                case 11:
                case 15:
                  break;
                case 1:
                  if (N !== null) {
                    var U = N.memoizedProps,
                      Oe = N.memoizedState,
                      v = t.stateNode,
                      h = v.getSnapshotBeforeUpdate(
                        t.elementType === t.type ? U : bt(t.type, U),
                        Oe,
                      );
                    v.__reactInternalSnapshotBeforeUpdate = h;
                  }
                  break;
                case 3:
                  var w = t.stateNode.containerInfo;
                  w.nodeType === 1
                    ? (w.textContent = "")
                    : w.nodeType === 9 &&
                      w.documentElement &&
                      w.removeChild(w.documentElement);
                  break;
                case 5:
                case 6:
                case 4:
                case 17:
                  break;
                default:
                  throw Error(l(163));
              }
          } catch (z) {
            Te(t, t.return, z);
          }
          if (((e = t.sibling), e !== null)) {
            ((e.return = t.return), (M = e));
            break;
          }
          M = t.return;
        }
    return ((N = cc), (cc = !1), N);
  }
  function Ur(e, t, n) {
    var r = t.updateQueue;
    if (((r = r !== null ? r.lastEffect : null), r !== null)) {
      var o = (r = r.next);
      do {
        if ((o.tag & e) === e) {
          var i = o.destroy;
          ((o.destroy = void 0), i !== void 0 && Os(t, n, i));
        }
        o = o.next;
      } while (o !== r);
    }
  }
  function Fo(e, t) {
    if (
      ((t = t.updateQueue), (t = t !== null ? t.lastEffect : null), t !== null)
    ) {
      var n = (t = t.next);
      do {
        if ((n.tag & e) === e) {
          var r = n.create;
          n.destroy = r();
        }
        n = n.next;
      } while (n !== t);
    }
  }
  function Ns(e) {
    var t = e.ref;
    if (t !== null) {
      var n = e.stateNode;
      switch (e.tag) {
        case 5:
          e = n;
          break;
        default:
          e = n;
      }
      typeof t == "function" ? t(e) : (t.current = e);
    }
  }
  function dc(e) {
    var t = e.alternate;
    (t !== null && ((e.alternate = null), dc(t)),
      (e.child = null),
      (e.deletions = null),
      (e.sibling = null),
      e.tag === 5 &&
        ((t = e.stateNode),
        t !== null &&
          (delete t[zt],
          delete t[Pr],
          delete t[Xi],
          delete t[pp],
          delete t[mp])),
      (e.stateNode = null),
      (e.return = null),
      (e.dependencies = null),
      (e.memoizedProps = null),
      (e.memoizedState = null),
      (e.pendingProps = null),
      (e.stateNode = null),
      (e.updateQueue = null));
  }
  function fc(e) {
    return e.tag === 5 || e.tag === 3 || e.tag === 4;
  }
  function pc(e) {
    e: for (;;) {
      for (; e.sibling === null;) {
        if (e.return === null || fc(e.return)) return null;
        e = e.return;
      }
      for (
        e.sibling.return = e.return, e = e.sibling;
        e.tag !== 5 && e.tag !== 6 && e.tag !== 18;
      ) {
        if (e.flags & 2 || e.child === null || e.tag === 4) continue e;
        ((e.child.return = e), (e = e.child));
      }
      if (!(e.flags & 2)) return e.stateNode;
    }
  }
  function Is(e, t, n) {
    var r = e.tag;
    if (r === 5 || r === 6)
      ((e = e.stateNode),
        t
          ? n.nodeType === 8
            ? n.parentNode.insertBefore(e, t)
            : n.insertBefore(e, t)
          : (n.nodeType === 8
              ? ((t = n.parentNode), t.insertBefore(e, n))
              : ((t = n), t.appendChild(e)),
            (n = n._reactRootContainer),
            n != null || t.onclick !== null || (t.onclick = yo)));
    else if (r !== 4 && ((e = e.child), e !== null))
      for (Is(e, t, n), e = e.sibling; e !== null;)
        (Is(e, t, n), (e = e.sibling));
  }
  function Ds(e, t, n) {
    var r = e.tag;
    if (r === 5 || r === 6)
      ((e = e.stateNode), t ? n.insertBefore(e, t) : n.appendChild(e));
    else if (r !== 4 && ((e = e.child), e !== null))
      for (Ds(e, t, n), e = e.sibling; e !== null;)
        (Ds(e, t, n), (e = e.sibling));
  }
  var Ve = null,
    Et = !1;
  function rn(e, t, n) {
    for (n = n.child; n !== null;) (mc(e, t, n), (n = n.sibling));
  }
  function mc(e, t, n) {
    if (Pt && typeof Pt.onCommitFiberUnmount == "function")
      try {
        Pt.onCommitFiberUnmount(Xr, n);
      } catch {}
    switch (n.tag) {
      case 5:
        Ye || Jn(n, t);
      case 6:
        var r = Ve,
          o = Et;
        ((Ve = null),
          rn(e, t, n),
          (Ve = r),
          (Et = o),
          Ve !== null &&
            (Et
              ? ((e = Ve),
                (n = n.stateNode),
                e.nodeType === 8
                  ? e.parentNode.removeChild(n)
                  : e.removeChild(n))
              : Ve.removeChild(n.stateNode)));
        break;
      case 18:
        Ve !== null &&
          (Et
            ? ((e = Ve),
              (n = n.stateNode),
              e.nodeType === 8
                ? qi(e.parentNode, n)
                : e.nodeType === 1 && qi(e, n),
              yr(e))
            : qi(Ve, n.stateNode));
        break;
      case 4:
        ((r = Ve),
          (o = Et),
          (Ve = n.stateNode.containerInfo),
          (Et = !0),
          rn(e, t, n),
          (Ve = r),
          (Et = o));
        break;
      case 0:
      case 11:
      case 14:
      case 15:
        if (
          !Ye &&
          ((r = n.updateQueue), r !== null && ((r = r.lastEffect), r !== null))
        ) {
          o = r = r.next;
          do {
            var i = o,
              c = i.destroy;
            ((i = i.tag),
              c !== void 0 && ((i & 2) !== 0 || (i & 4) !== 0) && Os(n, t, c),
              (o = o.next));
          } while (o !== r);
        }
        rn(e, t, n);
        break;
      case 1:
        if (
          !Ye &&
          (Jn(n, t),
          (r = n.stateNode),
          typeof r.componentWillUnmount == "function")
        )
          try {
            ((r.props = n.memoizedProps),
              (r.state = n.memoizedState),
              r.componentWillUnmount());
          } catch (f) {
            Te(n, t, f);
          }
        rn(e, t, n);
        break;
      case 21:
        rn(e, t, n);
        break;
      case 22:
        n.mode & 1
          ? ((Ye = (r = Ye) || n.memoizedState !== null), rn(e, t, n), (Ye = r))
          : rn(e, t, n);
        break;
      default:
        rn(e, t, n);
    }
  }
  function hc(e) {
    var t = e.updateQueue;
    if (t !== null) {
      e.updateQueue = null;
      var n = e.stateNode;
      (n === null && (n = e.stateNode = new _p()),
        t.forEach(function (r) {
          var o = Fp.bind(null, e, r);
          n.has(r) || (n.add(r), r.then(o, o));
        }));
    }
  }
  function jt(e, t) {
    var n = t.deletions;
    if (n !== null)
      for (var r = 0; r < n.length; r++) {
        var o = n[r];
        try {
          var i = e,
            c = t,
            f = c;
          e: for (; f !== null;) {
            switch (f.tag) {
              case 5:
                ((Ve = f.stateNode), (Et = !1));
                break e;
              case 3:
                ((Ve = f.stateNode.containerInfo), (Et = !0));
                break e;
              case 4:
                ((Ve = f.stateNode.containerInfo), (Et = !0));
                break e;
            }
            f = f.return;
          }
          if (Ve === null) throw Error(l(160));
          (mc(i, c, o), (Ve = null), (Et = !1));
          var m = o.alternate;
          (m !== null && (m.return = null), (o.return = null));
        } catch (x) {
          Te(o, t, x);
        }
      }
    if (t.subtreeFlags & 12854)
      for (t = t.child; t !== null;) (gc(t, e), (t = t.sibling));
  }
  function gc(e, t) {
    var n = e.alternate,
      r = e.flags;
    switch (e.tag) {
      case 0:
      case 11:
      case 14:
      case 15:
        if ((jt(t, e), Rt(e), r & 4)) {
          try {
            (Ur(3, e, e.return), Fo(3, e));
          } catch (U) {
            Te(e, e.return, U);
          }
          try {
            Ur(5, e, e.return);
          } catch (U) {
            Te(e, e.return, U);
          }
        }
        break;
      case 1:
        (jt(t, e), Rt(e), r & 512 && n !== null && Jn(n, n.return));
        break;
      case 5:
        if (
          (jt(t, e),
          Rt(e),
          r & 512 && n !== null && Jn(n, n.return),
          e.flags & 32)
        ) {
          var o = e.stateNode;
          try {
            sr(o, "");
          } catch (U) {
            Te(e, e.return, U);
          }
        }
        if (r & 4 && ((o = e.stateNode), o != null)) {
          var i = e.memoizedProps,
            c = n !== null ? n.memoizedProps : i,
            f = e.type,
            m = e.updateQueue;
          if (((e.updateQueue = null), m !== null))
            try {
              (f === "input" &&
                i.type === "radio" &&
                i.name != null &&
                Mt(o, i),
                hi(f, c));
              var x = hi(f, i);
              for (c = 0; c < m.length; c += 2) {
                var A = m[c],
                  P = m[c + 1];
                A === "style"
                  ? Xa(o, P)
                  : A === "dangerouslySetInnerHTML"
                    ? Ya(o, P)
                    : A === "children"
                      ? sr(o, P)
                      : be(o, A, P, x);
              }
              switch (f) {
                case "input":
                  or(o, i);
                  break;
                case "textarea":
                  Ga(o, i);
                  break;
                case "select":
                  var C = o._wrapperState.wasMultiple;
                  o._wrapperState.wasMultiple = !!i.multiple;
                  var L = i.value;
                  L != null
                    ? Rn(o, !!i.multiple, L, !1)
                    : C !== !!i.multiple &&
                      (i.defaultValue != null
                        ? Rn(o, !!i.multiple, i.defaultValue, !0)
                        : Rn(o, !!i.multiple, i.multiple ? [] : "", !1));
              }
              o[Pr] = i;
            } catch (U) {
              Te(e, e.return, U);
            }
        }
        break;
      case 6:
        if ((jt(t, e), Rt(e), r & 4)) {
          if (e.stateNode === null) throw Error(l(162));
          ((o = e.stateNode), (i = e.memoizedProps));
          try {
            o.nodeValue = i;
          } catch (U) {
            Te(e, e.return, U);
          }
        }
        break;
      case 3:
        if (
          (jt(t, e), Rt(e), r & 4 && n !== null && n.memoizedState.isDehydrated)
        )
          try {
            yr(t.containerInfo);
          } catch (U) {
            Te(e, e.return, U);
          }
        break;
      case 4:
        (jt(t, e), Rt(e));
        break;
      case 13:
        (jt(t, e),
          Rt(e),
          (o = e.child),
          o.flags & 8192 &&
            ((i = o.memoizedState !== null),
            (o.stateNode.isHidden = i),
            !i ||
              (o.alternate !== null && o.alternate.memoizedState !== null) ||
              (Ws = Me())),
          r & 4 && hc(e));
        break;
      case 22:
        if (
          ((A = n !== null && n.memoizedState !== null),
          e.mode & 1 ? ((Ye = (x = Ye) || A), jt(t, e), (Ye = x)) : jt(t, e),
          Rt(e),
          r & 8192)
        ) {
          if (
            ((x = e.memoizedState !== null),
            (e.stateNode.isHidden = x) && !A && (e.mode & 1) !== 0)
          )
            for (M = e, A = e.child; A !== null;) {
              for (P = M = A; M !== null;) {
                switch (((C = M), (L = C.child), C.tag)) {
                  case 0:
                  case 11:
                  case 14:
                  case 15:
                    Ur(4, C, C.return);
                    break;
                  case 1:
                    Jn(C, C.return);
                    var N = C.stateNode;
                    if (typeof N.componentWillUnmount == "function") {
                      ((r = C), (n = C.return));
                      try {
                        ((t = r),
                          (N.props = t.memoizedProps),
                          (N.state = t.memoizedState),
                          N.componentWillUnmount());
                      } catch (U) {
                        Te(r, n, U);
                      }
                    }
                    break;
                  case 5:
                    Jn(C, C.return);
                    break;
                  case 22:
                    if (C.memoizedState !== null) {
                      wc(P);
                      continue;
                    }
                }
                L !== null ? ((L.return = C), (M = L)) : wc(P);
              }
              A = A.sibling;
            }
          e: for (A = null, P = e; ;) {
            if (P.tag === 5) {
              if (A === null) {
                A = P;
                try {
                  ((o = P.stateNode),
                    x
                      ? ((i = o.style),
                        typeof i.setProperty == "function"
                          ? i.setProperty("display", "none", "important")
                          : (i.display = "none"))
                      : ((f = P.stateNode),
                        (m = P.memoizedProps.style),
                        (c =
                          m != null && m.hasOwnProperty("display")
                            ? m.display
                            : null),
                        (f.style.display = qa("display", c))));
                } catch (U) {
                  Te(e, e.return, U);
                }
              }
            } else if (P.tag === 6) {
              if (A === null)
                try {
                  P.stateNode.nodeValue = x ? "" : P.memoizedProps;
                } catch (U) {
                  Te(e, e.return, U);
                }
            } else if (
              ((P.tag !== 22 && P.tag !== 23) ||
                P.memoizedState === null ||
                P === e) &&
              P.child !== null
            ) {
              ((P.child.return = P), (P = P.child));
              continue;
            }
            if (P === e) break e;
            for (; P.sibling === null;) {
              if (P.return === null || P.return === e) break e;
              (A === P && (A = null), (P = P.return));
            }
            (A === P && (A = null),
              (P.sibling.return = P.return),
              (P = P.sibling));
          }
        }
        break;
      case 19:
        (jt(t, e), Rt(e), r & 4 && hc(e));
        break;
      case 21:
        break;
      default:
        (jt(t, e), Rt(e));
    }
  }
  function Rt(e) {
    var t = e.flags;
    if (t & 2) {
      try {
        e: {
          for (var n = e.return; n !== null;) {
            if (fc(n)) {
              var r = n;
              break e;
            }
            n = n.return;
          }
          throw Error(l(160));
        }
        switch (r.tag) {
          case 5:
            var o = r.stateNode;
            r.flags & 32 && (sr(o, ""), (r.flags &= -33));
            var i = pc(e);
            Ds(e, i, o);
            break;
          case 3:
          case 4:
            var c = r.stateNode.containerInfo,
              f = pc(e);
            Is(e, f, c);
            break;
          default:
            throw Error(l(161));
        }
      } catch (m) {
        Te(e, e.return, m);
      }
      e.flags &= -3;
    }
    t & 4096 && (e.flags &= -4097);
  }
  function Rp(e, t, n) {
    ((M = e), yc(e));
  }
  function yc(e, t, n) {
    for (var r = (e.mode & 1) !== 0; M !== null;) {
      var o = M,
        i = o.child;
      if (o.tag === 22 && r) {
        var c = o.memoizedState !== null || Uo;
        if (!c) {
          var f = o.alternate,
            m = (f !== null && f.memoizedState !== null) || Ye;
          f = Uo;
          var x = Ye;
          if (((Uo = c), (Ye = m) && !x))
            for (M = o; M !== null;)
              ((c = M),
                (m = c.child),
                c.tag === 22 && c.memoizedState !== null
                  ? xc(o)
                  : m !== null
                    ? ((m.return = c), (M = m))
                    : xc(o));
          for (; i !== null;) ((M = i), yc(i), (i = i.sibling));
          ((M = o), (Uo = f), (Ye = x));
        }
        vc(e);
      } else
        (o.subtreeFlags & 8772) !== 0 && i !== null
          ? ((i.return = o), (M = i))
          : vc(e);
    }
  }
  function vc(e) {
    for (; M !== null;) {
      var t = M;
      if ((t.flags & 8772) !== 0) {
        var n = t.alternate;
        try {
          if ((t.flags & 8772) !== 0)
            switch (t.tag) {
              case 0:
              case 11:
              case 15:
                Ye || Fo(5, t);
                break;
              case 1:
                var r = t.stateNode;
                if (t.flags & 4 && !Ye)
                  if (n === null) r.componentDidMount();
                  else {
                    var o =
                      t.elementType === t.type
                        ? n.memoizedProps
                        : bt(t.type, n.memoizedProps);
                    r.componentDidUpdate(
                      o,
                      n.memoizedState,
                      r.__reactInternalSnapshotBeforeUpdate,
                    );
                  }
                var i = t.updateQueue;
                i !== null && wu(t, i, r);
                break;
              case 3:
                var c = t.updateQueue;
                if (c !== null) {
                  if (((n = null), t.child !== null))
                    switch (t.child.tag) {
                      case 5:
                        n = t.child.stateNode;
                        break;
                      case 1:
                        n = t.child.stateNode;
                    }
                  wu(t, c, n);
                }
                break;
              case 5:
                var f = t.stateNode;
                if (n === null && t.flags & 4) {
                  n = f;
                  var m = t.memoizedProps;
                  switch (t.type) {
                    case "button":
                    case "input":
                    case "select":
                    case "textarea":
                      m.autoFocus && n.focus();
                      break;
                    case "img":
                      m.src && (n.src = m.src);
                  }
                }
                break;
              case 6:
                break;
              case 4:
                break;
              case 12:
                break;
              case 13:
                if (t.memoizedState === null) {
                  var x = t.alternate;
                  if (x !== null) {
                    var A = x.memoizedState;
                    if (A !== null) {
                      var P = A.dehydrated;
                      P !== null && yr(P);
                    }
                  }
                }
                break;
              case 19:
              case 17:
              case 21:
              case 22:
              case 23:
              case 25:
                break;
              default:
                throw Error(l(163));
            }
          Ye || (t.flags & 512 && Ns(t));
        } catch (C) {
          Te(t, t.return, C);
        }
      }
      if (t === e) {
        M = null;
        break;
      }
      if (((n = t.sibling), n !== null)) {
        ((n.return = t.return), (M = n));
        break;
      }
      M = t.return;
    }
  }
  function wc(e) {
    for (; M !== null;) {
      var t = M;
      if (t === e) {
        M = null;
        break;
      }
      var n = t.sibling;
      if (n !== null) {
        ((n.return = t.return), (M = n));
        break;
      }
      M = t.return;
    }
  }
  function xc(e) {
    for (; M !== null;) {
      var t = M;
      try {
        switch (t.tag) {
          case 0:
          case 11:
          case 15:
            var n = t.return;
            try {
              Fo(4, t);
            } catch (m) {
              Te(t, n, m);
            }
            break;
          case 1:
            var r = t.stateNode;
            if (typeof r.componentDidMount == "function") {
              var o = t.return;
              try {
                r.componentDidMount();
              } catch (m) {
                Te(t, o, m);
              }
            }
            var i = t.return;
            try {
              Ns(t);
            } catch (m) {
              Te(t, i, m);
            }
            break;
          case 5:
            var c = t.return;
            try {
              Ns(t);
            } catch (m) {
              Te(t, c, m);
            }
        }
      } catch (m) {
        Te(t, t.return, m);
      }
      if (t === e) {
        M = null;
        break;
      }
      var f = t.sibling;
      if (f !== null) {
        ((f.return = t.return), (M = f));
        break;
      }
      M = t.return;
    }
  }
  var Lp = Math.ceil,
    Wo = ie.ReactCurrentDispatcher,
    Us = ie.ReactCurrentOwner,
    gt = ie.ReactCurrentBatchConfig,
    pe = 0,
    $e = null,
    Ne = null,
    Ke = 0,
    dt = 0,
    er = Xt(0),
    De = 0,
    Fr = null,
    kn = 0,
    $o = 0,
    Fs = 0,
    Wr = null,
    ot = null,
    Ws = 0,
    tr = 1 / 0,
    $t = null,
    Bo = !1,
    $s = null,
    on = null,
    Ho = !1,
    sn = null,
    Vo = 0,
    $r = 0,
    Bs = null,
    Ko = -1,
    Go = 0;
  function Je() {
    return (pe & 6) !== 0 ? Me() : Ko !== -1 ? Ko : (Ko = Me());
  }
  function an(e) {
    return (e.mode & 1) === 0
      ? 1
      : (pe & 2) !== 0 && Ke !== 0
        ? Ke & -Ke
        : gp.transition !== null
          ? (Go === 0 && (Go = pl()), Go)
          : ((e = ge),
            e !== 0 ||
              ((e = window.event), (e = e === void 0 ? 16 : Sl(e.type))),
            e);
  }
  function Ct(e, t, n, r) {
    if (50 < $r) throw (($r = 0), (Bs = null), Error(l(185)));
    (fr(e, n, r),
      ((pe & 2) === 0 || e !== $e) &&
        (e === $e && ((pe & 2) === 0 && ($o |= n), De === 4 && ln(e, Ke)),
        it(e, r),
        n === 1 &&
          pe === 0 &&
          (t.mode & 1) === 0 &&
          ((tr = Me() + 500), ko && en())));
  }
  function it(e, t) {
    var n = e.callbackNode;
    gf(e, t);
    var r = to(e, e === $e ? Ke : 0);
    if (r === 0)
      (n !== null && cl(n), (e.callbackNode = null), (e.callbackPriority = 0));
    else if (((t = r & -r), e.callbackPriority !== t)) {
      if ((n != null && cl(n), t === 1))
        (e.tag === 0 ? hp(Sc.bind(null, e)) : au(Sc.bind(null, e)),
          dp(function () {
            (pe & 6) === 0 && en();
          }),
          (n = null));
      else {
        switch (ml(r)) {
          case 1:
            n = Si;
            break;
          case 4:
            n = dl;
            break;
          case 16:
            n = qr;
            break;
          case 536870912:
            n = fl;
            break;
          default:
            n = qr;
        }
        n = _c(n, kc.bind(null, e));
      }
      ((e.callbackPriority = t), (e.callbackNode = n));
    }
  }
  function kc(e, t) {
    if (((Ko = -1), (Go = 0), (pe & 6) !== 0)) throw Error(l(327));
    var n = e.callbackNode;
    if (nr() && e.callbackNode !== n) return null;
    var r = to(e, e === $e ? Ke : 0);
    if (r === 0) return null;
    if ((r & 30) !== 0 || (r & e.expiredLanes) !== 0 || t) t = Qo(e, r);
    else {
      t = r;
      var o = pe;
      pe |= 2;
      var i = Ec();
      ($e !== e || Ke !== t) && (($t = null), (tr = Me() + 500), bn(e, t));
      do
        try {
          Np();
          break;
        } catch (f) {
          bc(e, f);
        }
      while (!0);
      (as(),
        (Wo.current = i),
        (pe = o),
        Ne !== null ? (t = 0) : (($e = null), (Ke = 0), (t = De)));
    }
    if (t !== 0) {
      if (
        (t === 2 && ((o = bi(e)), o !== 0 && ((r = o), (t = Hs(e, o)))),
        t === 1)
      )
        throw ((n = Fr), bn(e, 0), ln(e, r), it(e, Me()), n);
      if (t === 6) ln(e, r);
      else {
        if (
          ((o = e.current.alternate),
          (r & 30) === 0 &&
            !Mp(o) &&
            ((t = Qo(e, r)),
            t === 2 && ((i = bi(e)), i !== 0 && ((r = i), (t = Hs(e, i)))),
            t === 1))
        )
          throw ((n = Fr), bn(e, 0), ln(e, r), it(e, Me()), n);
        switch (((e.finishedWork = o), (e.finishedLanes = r), t)) {
          case 0:
          case 1:
            throw Error(l(345));
          case 2:
            En(e, ot, $t);
            break;
          case 3:
            if (
              (ln(e, r),
              (r & 130023424) === r && ((t = Ws + 500 - Me()), 10 < t))
            ) {
              if (to(e, 0) !== 0) break;
              if (((o = e.suspendedLanes), (o & r) !== r)) {
                (Je(), (e.pingedLanes |= e.suspendedLanes & o));
                break;
              }
              e.timeoutHandle = Yi(En.bind(null, e, ot, $t), t);
              break;
            }
            En(e, ot, $t);
            break;
          case 4:
            if ((ln(e, r), (r & 4194240) === r)) break;
            for (t = e.eventTimes, o = -1; 0 < r;) {
              var c = 31 - xt(r);
              ((i = 1 << c), (c = t[c]), c > o && (o = c), (r &= ~i));
            }
            if (
              ((r = o),
              (r = Me() - r),
              (r =
                (120 > r
                  ? 120
                  : 480 > r
                    ? 480
                    : 1080 > r
                      ? 1080
                      : 1920 > r
                        ? 1920
                        : 3e3 > r
                          ? 3e3
                          : 4320 > r
                            ? 4320
                            : 1960 * Lp(r / 1960)) - r),
              10 < r)
            ) {
              e.timeoutHandle = Yi(En.bind(null, e, ot, $t), r);
              break;
            }
            En(e, ot, $t);
            break;
          case 5:
            En(e, ot, $t);
            break;
          default:
            throw Error(l(329));
        }
      }
    }
    return (it(e, Me()), e.callbackNode === n ? kc.bind(null, e) : null);
  }
  function Hs(e, t) {
    var n = Wr;
    return (
      e.current.memoizedState.isDehydrated && (bn(e, t).flags |= 256),
      (e = Qo(e, t)),
      e !== 2 && ((t = ot), (ot = n), t !== null && Vs(t)),
      e
    );
  }
  function Vs(e) {
    ot === null ? (ot = e) : ot.push.apply(ot, e);
  }
  function Mp(e) {
    for (var t = e; ;) {
      if (t.flags & 16384) {
        var n = t.updateQueue;
        if (n !== null && ((n = n.stores), n !== null))
          for (var r = 0; r < n.length; r++) {
            var o = n[r],
              i = o.getSnapshot;
            o = o.value;
            try {
              if (!kt(i(), o)) return !1;
            } catch {
              return !1;
            }
          }
      }
      if (((n = t.child), t.subtreeFlags & 16384 && n !== null))
        ((n.return = t), (t = n));
      else {
        if (t === e) break;
        for (; t.sibling === null;) {
          if (t.return === null || t.return === e) return !0;
          t = t.return;
        }
        ((t.sibling.return = t.return), (t = t.sibling));
      }
    }
    return !0;
  }
  function ln(e, t) {
    for (
      t &= ~Fs,
        t &= ~$o,
        e.suspendedLanes |= t,
        e.pingedLanes &= ~t,
        e = e.expirationTimes;
      0 < t;
    ) {
      var n = 31 - xt(t),
        r = 1 << n;
      ((e[n] = -1), (t &= ~r));
    }
  }
  function Sc(e) {
    if ((pe & 6) !== 0) throw Error(l(327));
    nr();
    var t = to(e, 0);
    if ((t & 1) === 0) return (it(e, Me()), null);
    var n = Qo(e, t);
    if (e.tag !== 0 && n === 2) {
      var r = bi(e);
      r !== 0 && ((t = r), (n = Hs(e, r)));
    }
    if (n === 1) throw ((n = Fr), bn(e, 0), ln(e, t), it(e, Me()), n);
    if (n === 6) throw Error(l(345));
    return (
      (e.finishedWork = e.current.alternate),
      (e.finishedLanes = t),
      En(e, ot, $t),
      it(e, Me()),
      null
    );
  }
  function Ks(e, t) {
    var n = pe;
    pe |= 1;
    try {
      return e(t);
    } finally {
      ((pe = n), pe === 0 && ((tr = Me() + 500), ko && en()));
    }
  }
  function Sn(e) {
    sn !== null && sn.tag === 0 && (pe & 6) === 0 && nr();
    var t = pe;
    pe |= 1;
    var n = gt.transition,
      r = ge;
    try {
      if (((gt.transition = null), (ge = 1), e)) return e();
    } finally {
      ((ge = r), (gt.transition = n), (pe = t), (pe & 6) === 0 && en());
    }
  }
  function Gs() {
    ((dt = er.current), Se(er));
  }
  function bn(e, t) {
    ((e.finishedWork = null), (e.finishedLanes = 0));
    var n = e.timeoutHandle;
    if ((n !== -1 && ((e.timeoutHandle = -1), cp(n)), Ne !== null))
      for (n = Ne.return; n !== null;) {
        var r = n;
        switch ((ns(r), r.tag)) {
          case 1:
            ((r = r.type.childContextTypes), r != null && wo());
            break;
          case 3:
            (qn(), Se(tt), Se(Ge), hs());
            break;
          case 5:
            ps(r);
            break;
          case 4:
            qn();
            break;
          case 13:
            Se(ze);
            break;
          case 19:
            Se(ze);
            break;
          case 10:
            ls(r.type._context);
            break;
          case 22:
          case 23:
            Gs();
        }
        n = n.return;
      }
    if (
      (($e = e),
      (Ne = e = un(e.current, null)),
      (Ke = dt = t),
      (De = 0),
      (Fr = null),
      (Fs = $o = kn = 0),
      (ot = Wr = null),
      vn !== null)
    ) {
      for (t = 0; t < vn.length; t++)
        if (((n = vn[t]), (r = n.interleaved), r !== null)) {
          n.interleaved = null;
          var o = r.next,
            i = n.pending;
          if (i !== null) {
            var c = i.next;
            ((i.next = o), (r.next = c));
          }
          n.pending = r;
        }
      vn = null;
    }
    return e;
  }
  function bc(e, t) {
    do {
      var n = Ne;
      try {
        if ((as(), (To.current = Oo), Ro)) {
          for (var r = _e.memoizedState; r !== null;) {
            var o = r.queue;
            (o !== null && (o.pending = null), (r = r.next));
          }
          Ro = !1;
        }
        if (
          ((xn = 0),
          (We = Ie = _e = null),
          (Mr = !1),
          (Or = 0),
          (Us.current = null),
          n === null || n.return === null)
        ) {
          ((De = 1), (Fr = t), (Ne = null));
          break;
        }
        e: {
          var i = e,
            c = n.return,
            f = n,
            m = t;
          if (
            ((t = Ke),
            (f.flags |= 32768),
            m !== null && typeof m == "object" && typeof m.then == "function")
          ) {
            var x = m,
              A = f,
              P = A.tag;
            if ((A.mode & 1) === 0 && (P === 0 || P === 11 || P === 15)) {
              var C = A.alternate;
              C
                ? ((A.updateQueue = C.updateQueue),
                  (A.memoizedState = C.memoizedState),
                  (A.lanes = C.lanes))
                : ((A.updateQueue = null), (A.memoizedState = null));
            }
            var L = Qu(c);
            if (L !== null) {
              ((L.flags &= -257),
                Zu(L, c, f, i, t),
                L.mode & 1 && Gu(i, x, t),
                (t = L),
                (m = x));
              var N = t.updateQueue;
              if (N === null) {
                var U = new Set();
                (U.add(m), (t.updateQueue = U));
              } else N.add(m);
              break e;
            } else {
              if ((t & 1) === 0) {
                (Gu(i, x, t), Qs());
                break e;
              }
              m = Error(l(426));
            }
          } else if (Ce && f.mode & 1) {
            var Oe = Qu(c);
            if (Oe !== null) {
              ((Oe.flags & 65536) === 0 && (Oe.flags |= 256),
                Zu(Oe, c, f, i, t),
                is(Xn(m, f)));
              break e;
            }
          }
          ((i = m = Xn(m, f)),
            De !== 4 && (De = 2),
            Wr === null ? (Wr = [i]) : Wr.push(i),
            (i = c));
          do {
            switch (i.tag) {
              case 3:
                ((i.flags |= 65536), (t &= -t), (i.lanes |= t));
                var v = Vu(i, m, t);
                vu(i, v);
                break e;
              case 1:
                f = m;
                var h = i.type,
                  w = i.stateNode;
                if (
                  (i.flags & 128) === 0 &&
                  (typeof h.getDerivedStateFromError == "function" ||
                    (w !== null &&
                      typeof w.componentDidCatch == "function" &&
                      (on === null || !on.has(w))))
                ) {
                  ((i.flags |= 65536), (t &= -t), (i.lanes |= t));
                  var z = Ku(i, f, t);
                  vu(i, z);
                  break e;
                }
            }
            i = i.return;
          } while (i !== null);
        }
        Cc(n);
      } catch (W) {
        ((t = W), Ne === n && n !== null && (Ne = n = n.return));
        continue;
      }
      break;
    } while (!0);
  }
  function Ec() {
    var e = Wo.current;
    return ((Wo.current = Oo), e === null ? Oo : e);
  }
  function Qs() {
    ((De === 0 || De === 3 || De === 2) && (De = 4),
      $e === null ||
        ((kn & 268435455) === 0 && ($o & 268435455) === 0) ||
        ln($e, Ke));
  }
  function Qo(e, t) {
    var n = pe;
    pe |= 2;
    var r = Ec();
    ($e !== e || Ke !== t) && (($t = null), bn(e, t));
    do
      try {
        Op();
        break;
      } catch (o) {
        bc(e, o);
      }
    while (!0);
    if ((as(), (pe = n), (Wo.current = r), Ne !== null)) throw Error(l(261));
    return (($e = null), (Ke = 0), De);
  }
  function Op() {
    for (; Ne !== null;) jc(Ne);
  }
  function Np() {
    for (; Ne !== null && !af();) jc(Ne);
  }
  function jc(e) {
    var t = zc(e.alternate, e, dt);
    ((e.memoizedProps = e.pendingProps),
      t === null ? Cc(e) : (Ne = t),
      (Us.current = null));
  }
  function Cc(e) {
    var t = e;
    do {
      var n = t.alternate;
      if (((e = t.return), (t.flags & 32768) === 0)) {
        if (((n = Pp(n, t, dt)), n !== null)) {
          Ne = n;
          return;
        }
      } else {
        if (((n = zp(n, t)), n !== null)) {
          ((n.flags &= 32767), (Ne = n));
          return;
        }
        if (e !== null)
          ((e.flags |= 32768), (e.subtreeFlags = 0), (e.deletions = null));
        else {
          ((De = 6), (Ne = null));
          return;
        }
      }
      if (((t = t.sibling), t !== null)) {
        Ne = t;
        return;
      }
      Ne = t = e;
    } while (t !== null);
    De === 0 && (De = 5);
  }
  function En(e, t, n) {
    var r = ge,
      o = gt.transition;
    try {
      ((gt.transition = null), (ge = 1), Ip(e, t, n, r));
    } finally {
      ((gt.transition = o), (ge = r));
    }
    return null;
  }
  function Ip(e, t, n, r) {
    do nr();
    while (sn !== null);
    if ((pe & 6) !== 0) throw Error(l(327));
    n = e.finishedWork;
    var o = e.finishedLanes;
    if (n === null) return null;
    if (((e.finishedWork = null), (e.finishedLanes = 0), n === e.current))
      throw Error(l(177));
    ((e.callbackNode = null), (e.callbackPriority = 0));
    var i = n.lanes | n.childLanes;
    if (
      (yf(e, i),
      e === $e && ((Ne = $e = null), (Ke = 0)),
      ((n.subtreeFlags & 2064) === 0 && (n.flags & 2064) === 0) ||
        Ho ||
        ((Ho = !0),
        _c(qr, function () {
          return (nr(), null);
        })),
      (i = (n.flags & 15990) !== 0),
      (n.subtreeFlags & 15990) !== 0 || i)
    ) {
      ((i = gt.transition), (gt.transition = null));
      var c = ge;
      ge = 1;
      var f = pe;
      ((pe |= 4),
        (Us.current = null),
        Tp(e, n),
        gc(n, e),
        rp(Qi),
        (oo = !!Gi),
        (Qi = Gi = null),
        (e.current = n),
        Rp(n),
        lf(),
        (pe = f),
        (ge = c),
        (gt.transition = i));
    } else e.current = n;
    if (
      (Ho && ((Ho = !1), (sn = e), (Vo = o)),
      (i = e.pendingLanes),
      i === 0 && (on = null),
      df(n.stateNode),
      it(e, Me()),
      t !== null)
    )
      for (r = e.onRecoverableError, n = 0; n < t.length; n++)
        ((o = t[n]), r(o.value, { componentStack: o.stack, digest: o.digest }));
    if (Bo) throw ((Bo = !1), (e = $s), ($s = null), e);
    return (
      (Vo & 1) !== 0 && e.tag !== 0 && nr(),
      (i = e.pendingLanes),
      (i & 1) !== 0 ? (e === Bs ? $r++ : (($r = 0), (Bs = e))) : ($r = 0),
      en(),
      null
    );
  }
  function nr() {
    if (sn !== null) {
      var e = ml(Vo),
        t = gt.transition,
        n = ge;
      try {
        if (((gt.transition = null), (ge = 16 > e ? 16 : e), sn === null))
          var r = !1;
        else {
          if (((e = sn), (sn = null), (Vo = 0), (pe & 6) !== 0))
            throw Error(l(331));
          var o = pe;
          for (pe |= 4, M = e.current; M !== null;) {
            var i = M,
              c = i.child;
            if ((M.flags & 16) !== 0) {
              var f = i.deletions;
              if (f !== null) {
                for (var m = 0; m < f.length; m++) {
                  var x = f[m];
                  for (M = x; M !== null;) {
                    var A = M;
                    switch (A.tag) {
                      case 0:
                      case 11:
                      case 15:
                        Ur(8, A, i);
                    }
                    var P = A.child;
                    if (P !== null) ((P.return = A), (M = P));
                    else
                      for (; M !== null;) {
                        A = M;
                        var C = A.sibling,
                          L = A.return;
                        if ((dc(A), A === x)) {
                          M = null;
                          break;
                        }
                        if (C !== null) {
                          ((C.return = L), (M = C));
                          break;
                        }
                        M = L;
                      }
                  }
                }
                var N = i.alternate;
                if (N !== null) {
                  var U = N.child;
                  if (U !== null) {
                    N.child = null;
                    do {
                      var Oe = U.sibling;
                      ((U.sibling = null), (U = Oe));
                    } while (U !== null);
                  }
                }
                M = i;
              }
            }
            if ((i.subtreeFlags & 2064) !== 0 && c !== null)
              ((c.return = i), (M = c));
            else
              e: for (; M !== null;) {
                if (((i = M), (i.flags & 2048) !== 0))
                  switch (i.tag) {
                    case 0:
                    case 11:
                    case 15:
                      Ur(9, i, i.return);
                  }
                var v = i.sibling;
                if (v !== null) {
                  ((v.return = i.return), (M = v));
                  break e;
                }
                M = i.return;
              }
          }
          var h = e.current;
          for (M = h; M !== null;) {
            c = M;
            var w = c.child;
            if ((c.subtreeFlags & 2064) !== 0 && w !== null)
              ((w.return = c), (M = w));
            else
              e: for (c = h; M !== null;) {
                if (((f = M), (f.flags & 2048) !== 0))
                  try {
                    switch (f.tag) {
                      case 0:
                      case 11:
                      case 15:
                        Fo(9, f);
                    }
                  } catch (W) {
                    Te(f, f.return, W);
                  }
                if (f === c) {
                  M = null;
                  break e;
                }
                var z = f.sibling;
                if (z !== null) {
                  ((z.return = f.return), (M = z));
                  break e;
                }
                M = f.return;
              }
          }
          if (
            ((pe = o),
            en(),
            Pt && typeof Pt.onPostCommitFiberRoot == "function")
          )
            try {
              Pt.onPostCommitFiberRoot(Xr, e);
            } catch {}
          r = !0;
        }
        return r;
      } finally {
        ((ge = n), (gt.transition = t));
      }
    }
    return !1;
  }
  function Ac(e, t, n) {
    ((t = Xn(n, t)),
      (t = Vu(e, t, 1)),
      (e = nn(e, t, 1)),
      (t = Je()),
      e !== null && (fr(e, 1, t), it(e, t)));
  }
  function Te(e, t, n) {
    if (e.tag === 3) Ac(e, e, n);
    else
      for (; t !== null;) {
        if (t.tag === 3) {
          Ac(t, e, n);
          break;
        } else if (t.tag === 1) {
          var r = t.stateNode;
          if (
            typeof t.type.getDerivedStateFromError == "function" ||
            (typeof r.componentDidCatch == "function" &&
              (on === null || !on.has(r)))
          ) {
            ((e = Xn(n, e)),
              (e = Ku(t, e, 1)),
              (t = nn(t, e, 1)),
              (e = Je()),
              t !== null && (fr(t, 1, e), it(t, e)));
            break;
          }
        }
        t = t.return;
      }
  }
  function Dp(e, t, n) {
    var r = e.pingCache;
    (r !== null && r.delete(t),
      (t = Je()),
      (e.pingedLanes |= e.suspendedLanes & n),
      $e === e &&
        (Ke & n) === n &&
        (De === 4 || (De === 3 && (Ke & 130023424) === Ke && 500 > Me() - Ws)
          ? bn(e, 0)
          : (Fs |= n)),
      it(e, t));
  }
  function Pc(e, t) {
    t === 0 &&
      ((e.mode & 1) === 0
        ? (t = 1)
        : ((t = eo), (eo <<= 1), (eo & 130023424) === 0 && (eo = 4194304)));
    var n = Je();
    ((e = Ut(e, t)), e !== null && (fr(e, t, n), it(e, n)));
  }
  function Up(e) {
    var t = e.memoizedState,
      n = 0;
    (t !== null && (n = t.retryLane), Pc(e, n));
  }
  function Fp(e, t) {
    var n = 0;
    switch (e.tag) {
      case 13:
        var r = e.stateNode,
          o = e.memoizedState;
        o !== null && (n = o.retryLane);
        break;
      case 19:
        r = e.stateNode;
        break;
      default:
        throw Error(l(314));
    }
    (r !== null && r.delete(t), Pc(e, n));
  }
  var zc;
  zc = function (e, t, n) {
    if (e !== null)
      if (e.memoizedProps !== t.pendingProps || tt.current) rt = !0;
      else {
        if ((e.lanes & n) === 0 && (t.flags & 128) === 0)
          return ((rt = !1), Ap(e, t, n));
        rt = (e.flags & 131072) !== 0;
      }
    else ((rt = !1), Ce && (t.flags & 1048576) !== 0 && lu(t, bo, t.index));
    switch (((t.lanes = 0), t.tag)) {
      case 2:
        var r = t.type;
        (Do(e, t), (e = t.pendingProps));
        var o = Hn(t, Ge.current);
        (Yn(t, n), (o = vs(null, t, r, e, o, n)));
        var i = ws();
        return (
          (t.flags |= 1),
          typeof o == "object" &&
          o !== null &&
          typeof o.render == "function" &&
          o.$$typeof === void 0
            ? ((t.tag = 1),
              (t.memoizedState = null),
              (t.updateQueue = null),
              nt(r) ? ((i = !0), xo(t)) : (i = !1),
              (t.memoizedState =
                o.state !== null && o.state !== void 0 ? o.state : null),
              ds(t),
              (o.updater = No),
              (t.stateNode = o),
              (o._reactInternals = t),
              js(t, r, e, n),
              (t = zs(null, t, r, !0, i, n)))
            : ((t.tag = 0), Ce && i && ts(t), Xe(null, t, o, n), (t = t.child)),
          t
        );
      case 16:
        r = t.elementType;
        e: {
          switch (
            (Do(e, t),
            (e = t.pendingProps),
            (o = r._init),
            (r = o(r._payload)),
            (t.type = r),
            (o = t.tag = $p(r)),
            (e = bt(r, e)),
            o)
          ) {
            case 0:
              t = Ps(null, t, r, e, n);
              break e;
            case 1:
              t = tc(null, t, r, e, n);
              break e;
            case 11:
              t = Yu(null, t, r, e, n);
              break e;
            case 14:
              t = qu(null, t, r, bt(r.type, e), n);
              break e;
          }
          throw Error(l(306, r, ""));
        }
        return t;
      case 0:
        return (
          (r = t.type),
          (o = t.pendingProps),
          (o = t.elementType === r ? o : bt(r, o)),
          Ps(e, t, r, o, n)
        );
      case 1:
        return (
          (r = t.type),
          (o = t.pendingProps),
          (o = t.elementType === r ? o : bt(r, o)),
          tc(e, t, r, o, n)
        );
      case 3:
        e: {
          if ((nc(t), e === null)) throw Error(l(387));
          ((r = t.pendingProps),
            (i = t.memoizedState),
            (o = i.element),
            yu(e, t),
            zo(t, r, null, n));
          var c = t.memoizedState;
          if (((r = c.element), i.isDehydrated))
            if (
              ((i = {
                element: r,
                isDehydrated: !1,
                cache: c.cache,
                pendingSuspenseBoundaries: c.pendingSuspenseBoundaries,
                transitions: c.transitions,
              }),
              (t.updateQueue.baseState = i),
              (t.memoizedState = i),
              t.flags & 256)
            ) {
              ((o = Xn(Error(l(423)), t)), (t = rc(e, t, r, n, o)));
              break e;
            } else if (r !== o) {
              ((o = Xn(Error(l(424)), t)), (t = rc(e, t, r, n, o)));
              break e;
            } else
              for (
                ct = qt(t.stateNode.containerInfo.firstChild),
                  ut = t,
                  Ce = !0,
                  St = null,
                  n = hu(t, null, r, n),
                  t.child = n;
                n;
              )
                ((n.flags = (n.flags & -3) | 4096), (n = n.sibling));
          else {
            if ((Gn(), r === o)) {
              t = Wt(e, t, n);
              break e;
            }
            Xe(e, t, r, n);
          }
          t = t.child;
        }
        return t;
      case 5:
        return (
          xu(t),
          e === null && os(t),
          (r = t.type),
          (o = t.pendingProps),
          (i = e !== null ? e.memoizedProps : null),
          (c = o.children),
          Zi(r, o) ? (c = null) : i !== null && Zi(r, i) && (t.flags |= 32),
          ec(e, t),
          Xe(e, t, c, n),
          t.child
        );
      case 6:
        return (e === null && os(t), null);
      case 13:
        return oc(e, t, n);
      case 4:
        return (
          fs(t, t.stateNode.containerInfo),
          (r = t.pendingProps),
          e === null ? (t.child = Qn(t, null, r, n)) : Xe(e, t, r, n),
          t.child
        );
      case 11:
        return (
          (r = t.type),
          (o = t.pendingProps),
          (o = t.elementType === r ? o : bt(r, o)),
          Yu(e, t, r, o, n)
        );
      case 7:
        return (Xe(e, t, t.pendingProps, n), t.child);
      case 8:
        return (Xe(e, t, t.pendingProps.children, n), t.child);
      case 12:
        return (Xe(e, t, t.pendingProps.children, n), t.child);
      case 10:
        e: {
          if (
            ((r = t.type._context),
            (o = t.pendingProps),
            (i = t.memoizedProps),
            (c = o.value),
            xe(Co, r._currentValue),
            (r._currentValue = c),
            i !== null)
          )
            if (kt(i.value, c)) {
              if (i.children === o.children && !tt.current) {
                t = Wt(e, t, n);
                break e;
              }
            } else
              for (i = t.child, i !== null && (i.return = t); i !== null;) {
                var f = i.dependencies;
                if (f !== null) {
                  c = i.child;
                  for (var m = f.firstContext; m !== null;) {
                    if (m.context === r) {
                      if (i.tag === 1) {
                        ((m = Ft(-1, n & -n)), (m.tag = 2));
                        var x = i.updateQueue;
                        if (x !== null) {
                          x = x.shared;
                          var A = x.pending;
                          (A === null
                            ? (m.next = m)
                            : ((m.next = A.next), (A.next = m)),
                            (x.pending = m));
                        }
                      }
                      ((i.lanes |= n),
                        (m = i.alternate),
                        m !== null && (m.lanes |= n),
                        us(i.return, n, t),
                        (f.lanes |= n));
                      break;
                    }
                    m = m.next;
                  }
                } else if (i.tag === 10) c = i.type === t.type ? null : i.child;
                else if (i.tag === 18) {
                  if (((c = i.return), c === null)) throw Error(l(341));
                  ((c.lanes |= n),
                    (f = c.alternate),
                    f !== null && (f.lanes |= n),
                    us(c, n, t),
                    (c = i.sibling));
                } else c = i.child;
                if (c !== null) c.return = i;
                else
                  for (c = i; c !== null;) {
                    if (c === t) {
                      c = null;
                      break;
                    }
                    if (((i = c.sibling), i !== null)) {
                      ((i.return = c.return), (c = i));
                      break;
                    }
                    c = c.return;
                  }
                i = c;
              }
          (Xe(e, t, o.children, n), (t = t.child));
        }
        return t;
      case 9:
        return (
          (o = t.type),
          (r = t.pendingProps.children),
          Yn(t, n),
          (o = mt(o)),
          (r = r(o)),
          (t.flags |= 1),
          Xe(e, t, r, n),
          t.child
        );
      case 14:
        return (
          (r = t.type),
          (o = bt(r, t.pendingProps)),
          (o = bt(r.type, o)),
          qu(e, t, r, o, n)
        );
      case 15:
        return Xu(e, t, t.type, t.pendingProps, n);
      case 17:
        return (
          (r = t.type),
          (o = t.pendingProps),
          (o = t.elementType === r ? o : bt(r, o)),
          Do(e, t),
          (t.tag = 1),
          nt(r) ? ((e = !0), xo(t)) : (e = !1),
          Yn(t, n),
          Bu(t, r, o),
          js(t, r, o, n),
          zs(null, t, r, !0, e, n)
        );
      case 19:
        return sc(e, t, n);
      case 22:
        return Ju(e, t, n);
    }
    throw Error(l(156, t.tag));
  };
  function _c(e, t) {
    return ul(e, t);
  }
  function Wp(e, t, n, r) {
    ((this.tag = e),
      (this.key = n),
      (this.sibling =
        this.child =
        this.return =
        this.stateNode =
        this.type =
        this.elementType =
          null),
      (this.index = 0),
      (this.ref = null),
      (this.pendingProps = t),
      (this.dependencies =
        this.memoizedState =
        this.updateQueue =
        this.memoizedProps =
          null),
      (this.mode = r),
      (this.subtreeFlags = this.flags = 0),
      (this.deletions = null),
      (this.childLanes = this.lanes = 0),
      (this.alternate = null));
  }
  function yt(e, t, n, r) {
    return new Wp(e, t, n, r);
  }
  function Zs(e) {
    return ((e = e.prototype), !(!e || !e.isReactComponent));
  }
  function $p(e) {
    if (typeof e == "function") return Zs(e) ? 1 : 0;
    if (e != null) {
      if (((e = e.$$typeof), e === Ee)) return 11;
      if (e === Fe) return 14;
    }
    return 2;
  }
  function un(e, t) {
    var n = e.alternate;
    return (
      n === null
        ? ((n = yt(e.tag, t, e.key, e.mode)),
          (n.elementType = e.elementType),
          (n.type = e.type),
          (n.stateNode = e.stateNode),
          (n.alternate = e),
          (e.alternate = n))
        : ((n.pendingProps = t),
          (n.type = e.type),
          (n.flags = 0),
          (n.subtreeFlags = 0),
          (n.deletions = null)),
      (n.flags = e.flags & 14680064),
      (n.childLanes = e.childLanes),
      (n.lanes = e.lanes),
      (n.child = e.child),
      (n.memoizedProps = e.memoizedProps),
      (n.memoizedState = e.memoizedState),
      (n.updateQueue = e.updateQueue),
      (t = e.dependencies),
      (n.dependencies =
        t === null ? null : { lanes: t.lanes, firstContext: t.firstContext }),
      (n.sibling = e.sibling),
      (n.index = e.index),
      (n.ref = e.ref),
      n
    );
  }
  function Zo(e, t, n, r, o, i) {
    var c = 2;
    if (((r = e), typeof e == "function")) Zs(e) && (c = 1);
    else if (typeof e == "string") c = 5;
    else
      e: switch (e) {
        case ee:
          return jn(n.children, o, i, t);
        case te:
          ((c = 8), (o |= 8));
          break;
        case ne:
          return (
            (e = yt(12, n, t, o | 2)),
            (e.elementType = ne),
            (e.lanes = i),
            e
          );
        case he:
          return (
            (e = yt(13, n, t, o)),
            (e.elementType = he),
            (e.lanes = i),
            e
          );
        case je:
          return (
            (e = yt(19, n, t, o)),
            (e.elementType = je),
            (e.lanes = i),
            e
          );
        case ye:
          return Yo(n, o, i, t);
        default:
          if (typeof e == "object" && e !== null)
            switch (e.$$typeof) {
              case le:
                c = 10;
                break e;
              case se:
                c = 9;
                break e;
              case Ee:
                c = 11;
                break e;
              case Fe:
                c = 14;
                break e;
              case Le:
                ((c = 16), (r = null));
                break e;
            }
          throw Error(l(130, e == null ? e : typeof e, ""));
      }
    return (
      (t = yt(c, n, t, o)),
      (t.elementType = e),
      (t.type = r),
      (t.lanes = i),
      t
    );
  }
  function jn(e, t, n, r) {
    return ((e = yt(7, e, r, t)), (e.lanes = n), e);
  }
  function Yo(e, t, n, r) {
    return (
      (e = yt(22, e, r, t)),
      (e.elementType = ye),
      (e.lanes = n),
      (e.stateNode = { isHidden: !1 }),
      e
    );
  }
  function Ys(e, t, n) {
    return ((e = yt(6, e, null, t)), (e.lanes = n), e);
  }
  function qs(e, t, n) {
    return (
      (t = yt(4, e.children !== null ? e.children : [], e.key, t)),
      (t.lanes = n),
      (t.stateNode = {
        containerInfo: e.containerInfo,
        pendingChildren: null,
        implementation: e.implementation,
      }),
      t
    );
  }
  function Bp(e, t, n, r, o) {
    ((this.tag = t),
      (this.containerInfo = e),
      (this.finishedWork =
        this.pingCache =
        this.current =
        this.pendingChildren =
          null),
      (this.timeoutHandle = -1),
      (this.callbackNode = this.pendingContext = this.context = null),
      (this.callbackPriority = 0),
      (this.eventTimes = Ei(0)),
      (this.expirationTimes = Ei(-1)),
      (this.entangledLanes =
        this.finishedLanes =
        this.mutableReadLanes =
        this.expiredLanes =
        this.pingedLanes =
        this.suspendedLanes =
        this.pendingLanes =
          0),
      (this.entanglements = Ei(0)),
      (this.identifierPrefix = r),
      (this.onRecoverableError = o),
      (this.mutableSourceEagerHydrationData = null));
  }
  function Xs(e, t, n, r, o, i, c, f, m) {
    return (
      (e = new Bp(e, t, n, f, m)),
      t === 1 ? ((t = 1), i === !0 && (t |= 8)) : (t = 0),
      (i = yt(3, null, null, t)),
      (e.current = i),
      (i.stateNode = e),
      (i.memoizedState = {
        element: r,
        isDehydrated: n,
        cache: null,
        transitions: null,
        pendingSuspenseBoundaries: null,
      }),
      ds(i),
      e
    );
  }
  function Hp(e, t, n) {
    var r =
      3 < arguments.length && arguments[3] !== void 0 ? arguments[3] : null;
    return {
      $$typeof: B,
      key: r == null ? null : "" + r,
      children: e,
      containerInfo: t,
      implementation: n,
    };
  }
  function Tc(e) {
    if (!e) return Jt;
    e = e._reactInternals;
    e: {
      if (pn(e) !== e || e.tag !== 1) throw Error(l(170));
      var t = e;
      do {
        switch (t.tag) {
          case 3:
            t = t.stateNode.context;
            break e;
          case 1:
            if (nt(t.type)) {
              t = t.stateNode.__reactInternalMemoizedMergedChildContext;
              break e;
            }
        }
        t = t.return;
      } while (t !== null);
      throw Error(l(171));
    }
    if (e.tag === 1) {
      var n = e.type;
      if (nt(n)) return iu(e, n, t);
    }
    return t;
  }
  function Rc(e, t, n, r, o, i, c, f, m) {
    return (
      (e = Xs(n, r, !0, e, o, i, c, f, m)),
      (e.context = Tc(null)),
      (n = e.current),
      (r = Je()),
      (o = an(n)),
      (i = Ft(r, o)),
      (i.callback = t ?? null),
      nn(n, i, o),
      (e.current.lanes = o),
      fr(e, o, r),
      it(e, r),
      e
    );
  }
  function qo(e, t, n, r) {
    var o = t.current,
      i = Je(),
      c = an(o);
    return (
      (n = Tc(n)),
      t.context === null ? (t.context = n) : (t.pendingContext = n),
      (t = Ft(i, c)),
      (t.payload = { element: e }),
      (r = r === void 0 ? null : r),
      r !== null && (t.callback = r),
      (e = nn(o, t, c)),
      e !== null && (Ct(e, o, c, i), Po(e, o, c)),
      c
    );
  }
  function Xo(e) {
    if (((e = e.current), !e.child)) return null;
    switch (e.child.tag) {
      case 5:
        return e.child.stateNode;
      default:
        return e.child.stateNode;
    }
  }
  function Lc(e, t) {
    if (((e = e.memoizedState), e !== null && e.dehydrated !== null)) {
      var n = e.retryLane;
      e.retryLane = n !== 0 && n < t ? n : t;
    }
  }
  function Js(e, t) {
    (Lc(e, t), (e = e.alternate) && Lc(e, t));
  }
  function Vp() {
    return null;
  }
  var Mc =
    typeof reportError == "function"
      ? reportError
      : function (e) {
          console.error(e);
        };
  function ea(e) {
    this._internalRoot = e;
  }
  ((Jo.prototype.render = ea.prototype.render =
    function (e) {
      var t = this._internalRoot;
      if (t === null) throw Error(l(409));
      qo(e, t, null, null);
    }),
    (Jo.prototype.unmount = ea.prototype.unmount =
      function () {
        var e = this._internalRoot;
        if (e !== null) {
          this._internalRoot = null;
          var t = e.containerInfo;
          (Sn(function () {
            qo(null, e, null, null);
          }),
            (t[Ot] = null));
        }
      }));
  function Jo(e) {
    this._internalRoot = e;
  }
  Jo.prototype.unstable_scheduleHydration = function (e) {
    if (e) {
      var t = yl();
      e = { blockedOn: null, target: e, priority: t };
      for (var n = 0; n < Qt.length && t !== 0 && t < Qt[n].priority; n++);
      (Qt.splice(n, 0, e), n === 0 && xl(e));
    }
  };
  function ta(e) {
    return !(!e || (e.nodeType !== 1 && e.nodeType !== 9 && e.nodeType !== 11));
  }
  function ei(e) {
    return !(
      !e ||
      (e.nodeType !== 1 &&
        e.nodeType !== 9 &&
        e.nodeType !== 11 &&
        (e.nodeType !== 8 || e.nodeValue !== " react-mount-point-unstable "))
    );
  }
  function Oc() {}
  function Kp(e, t, n, r, o) {
    if (o) {
      if (typeof r == "function") {
        var i = r;
        r = function () {
          var x = Xo(c);
          i.call(x);
        };
      }
      var c = Rc(t, r, e, 0, null, !1, !1, "", Oc);
      return (
        (e._reactRootContainer = c),
        (e[Ot] = c.current),
        Cr(e.nodeType === 8 ? e.parentNode : e),
        Sn(),
        c
      );
    }
    for (; (o = e.lastChild);) e.removeChild(o);
    if (typeof r == "function") {
      var f = r;
      r = function () {
        var x = Xo(m);
        f.call(x);
      };
    }
    var m = Xs(e, 0, !1, null, null, !1, !1, "", Oc);
    return (
      (e._reactRootContainer = m),
      (e[Ot] = m.current),
      Cr(e.nodeType === 8 ? e.parentNode : e),
      Sn(function () {
        qo(t, m, n, r);
      }),
      m
    );
  }
  function ti(e, t, n, r, o) {
    var i = n._reactRootContainer;
    if (i) {
      var c = i;
      if (typeof o == "function") {
        var f = o;
        o = function () {
          var m = Xo(c);
          f.call(m);
        };
      }
      qo(t, c, e, o);
    } else c = Kp(n, t, e, o, r);
    return Xo(c);
  }
  ((hl = function (e) {
    switch (e.tag) {
      case 3:
        var t = e.stateNode;
        if (t.current.memoizedState.isDehydrated) {
          var n = dr(t.pendingLanes);
          n !== 0 &&
            (ji(t, n | 1),
            it(t, Me()),
            (pe & 6) === 0 && ((tr = Me() + 500), en()));
        }
        break;
      case 13:
        (Sn(function () {
          var r = Ut(e, 1);
          if (r !== null) {
            var o = Je();
            Ct(r, e, 1, o);
          }
        }),
          Js(e, 1));
    }
  }),
    (Ci = function (e) {
      if (e.tag === 13) {
        var t = Ut(e, 134217728);
        if (t !== null) {
          var n = Je();
          Ct(t, e, 134217728, n);
        }
        Js(e, 134217728);
      }
    }),
    (gl = function (e) {
      if (e.tag === 13) {
        var t = an(e),
          n = Ut(e, t);
        if (n !== null) {
          var r = Je();
          Ct(n, e, t, r);
        }
        Js(e, t);
      }
    }),
    (yl = function () {
      return ge;
    }),
    (vl = function (e, t) {
      var n = ge;
      try {
        return ((ge = e), t());
      } finally {
        ge = n;
      }
    }),
    (vi = function (e, t, n) {
      switch (t) {
        case "input":
          if ((or(e, n), (t = n.name), n.type === "radio" && t != null)) {
            for (n = e; n.parentNode;) n = n.parentNode;
            for (
              n = n.querySelectorAll(
                "input[name=" + JSON.stringify("" + t) + '][type="radio"]',
              ),
                t = 0;
              t < n.length;
              t++
            ) {
              var r = n[t];
              if (r !== e && r.form === e.form) {
                var o = vo(r);
                if (!o) throw Error(l(90));
                (He(r), or(r, o));
              }
            }
          }
          break;
        case "textarea":
          Ga(e, n);
          break;
        case "select":
          ((t = n.value), t != null && Rn(e, !!n.multiple, t, !1));
      }
    }),
    (nl = Ks),
    (rl = Sn));
  var Gp = { usingClientEntryPoint: !1, Events: [zr, $n, vo, el, tl, Ks] },
    Br = {
      findFiberByHostInstance: mn,
      bundleType: 0,
      version: "18.3.1",
      rendererPackageName: "react-dom",
    },
    Qp = {
      bundleType: Br.bundleType,
      version: Br.version,
      rendererPackageName: Br.rendererPackageName,
      rendererConfig: Br.rendererConfig,
      overrideHookState: null,
      overrideHookStateDeletePath: null,
      overrideHookStateRenamePath: null,
      overrideProps: null,
      overridePropsDeletePath: null,
      overridePropsRenamePath: null,
      setErrorHandler: null,
      setSuspenseHandler: null,
      scheduleUpdate: null,
      currentDispatcherRef: ie.ReactCurrentDispatcher,
      findHostInstanceByFiber: function (e) {
        return ((e = al(e)), e === null ? null : e.stateNode);
      },
      findFiberByHostInstance: Br.findFiberByHostInstance || Vp,
      findHostInstancesForRefresh: null,
      scheduleRefresh: null,
      scheduleRoot: null,
      setRefreshHandler: null,
      getCurrentFiber: null,
      reconcilerVersion: "18.3.1-next-f1338f8080-20240426",
    };
  if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u") {
    var ni = __REACT_DEVTOOLS_GLOBAL_HOOK__;
    if (!ni.isDisabled && ni.supportsFiber)
      try {
        ((Xr = ni.inject(Qp)), (Pt = ni));
      } catch {}
  }
  return (
    (st.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = Gp),
    (st.createPortal = function (e, t) {
      var n =
        2 < arguments.length && arguments[2] !== void 0 ? arguments[2] : null;
      if (!ta(t)) throw Error(l(200));
      return Hp(e, t, null, n);
    }),
    (st.createRoot = function (e, t) {
      if (!ta(e)) throw Error(l(299));
      var n = !1,
        r = "",
        o = Mc;
      return (
        t != null &&
          (t.unstable_strictMode === !0 && (n = !0),
          t.identifierPrefix !== void 0 && (r = t.identifierPrefix),
          t.onRecoverableError !== void 0 && (o = t.onRecoverableError)),
        (t = Xs(e, 1, !1, null, null, n, !1, r, o)),
        (e[Ot] = t.current),
        Cr(e.nodeType === 8 ? e.parentNode : e),
        new ea(t)
      );
    }),
    (st.findDOMNode = function (e) {
      if (e == null) return null;
      if (e.nodeType === 1) return e;
      var t = e._reactInternals;
      if (t === void 0)
        throw typeof e.render == "function"
          ? Error(l(188))
          : ((e = Object.keys(e).join(",")), Error(l(268, e)));
      return ((e = al(t)), (e = e === null ? null : e.stateNode), e);
    }),
    (st.flushSync = function (e) {
      return Sn(e);
    }),
    (st.hydrate = function (e, t, n) {
      if (!ei(t)) throw Error(l(200));
      return ti(null, e, t, !0, n);
    }),
    (st.hydrateRoot = function (e, t, n) {
      if (!ta(e)) throw Error(l(405));
      var r = (n != null && n.hydratedSources) || null,
        o = !1,
        i = "",
        c = Mc;
      if (
        (n != null &&
          (n.unstable_strictMode === !0 && (o = !0),
          n.identifierPrefix !== void 0 && (i = n.identifierPrefix),
          n.onRecoverableError !== void 0 && (c = n.onRecoverableError)),
        (t = Rc(t, null, e, 1, n ?? null, o, !1, i, c)),
        (e[Ot] = t.current),
        Cr(e),
        r)
      )
        for (e = 0; e < r.length; e++)
          ((n = r[e]),
            (o = n._getVersion),
            (o = o(n._source)),
            t.mutableSourceEagerHydrationData == null
              ? (t.mutableSourceEagerHydrationData = [n, o])
              : t.mutableSourceEagerHydrationData.push(n, o));
      return new Jo(t);
    }),
    (st.render = function (e, t, n) {
      if (!ei(t)) throw Error(l(200));
      return ti(null, e, t, !1, n);
    }),
    (st.unmountComponentAtNode = function (e) {
      if (!ei(e)) throw Error(l(40));
      return e._reactRootContainer
        ? (Sn(function () {
            ti(null, null, e, !1, function () {
              ((e._reactRootContainer = null), (e[Ot] = null));
            });
          }),
          !0)
        : !1;
    }),
    (st.unstable_batchedUpdates = Ks),
    (st.unstable_renderSubtreeIntoContainer = function (e, t, n, r) {
      if (!ei(n)) throw Error(l(200));
      if (e == null || e._reactInternals === void 0) throw Error(l(38));
      return ti(e, t, n, !1, r);
    }),
    (st.version = "18.3.1-next-f1338f8080-20240426"),
    st
  );
}
var Bc;
function rm() {
  if (Bc) return oa.exports;
  Bc = 1;
  function s() {
    if (!(
      typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > "u" ||
      typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != "function"
    ))
      try {
        __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(s);
      } catch (u) {
        console.error(u);
      }
  }
  return (s(), (oa.exports = nm()), oa.exports);
}
var Hc;
function om() {
  if (Hc) return ri;
  Hc = 1;
  var s = rm();
  return ((ri.createRoot = s.createRoot), (ri.hydrateRoot = s.hydrateRoot), ri);
}
var im = om();
const sm = xd(im);
let Vc = [];
const am = new Set();
function lm(s) {
  if (s.join() !== Vc.join()) {
    Vc = s;
    for (const u of am) u();
  }
}
function kd(s) {
  const u = [...s.getAll("source"), ...s.getAll("sql")];
  return u.length
    ? u.some((l) => l !== "product" && l !== "mock" && l !== "real") ||
      new Set(u).size !== 1
      ? null
      : u[0]
    : "real";
}
new TextEncoder();
const um = {},
  rr = [
    "fox",
    "owl",
    "bear",
    "panda",
    "wolf",
    "badger",
    "hedgehog",
    "squirrel",
    "deer",
    "raccoon",
    "cat",
    "dog",
    "rabbit",
    "hamster",
    "guineapig",
    "ferret",
    "budgie",
    "goldfish",
    "pony",
    "mouse",
    "cow",
    "pig",
    "sheep",
    "goat",
    "horse",
    "donkey",
    "chicken",
    "duck",
    "goose",
    "bull",
    "lion",
    "tiger",
    "elephant",
    "giraffe",
    "zebra",
    "rhino",
    "hippo",
    "cheetah",
    "meerkat",
    "monkey",
    "polarbear",
    "penguin",
    "seal",
    "arcticfox",
    "snowleopard",
    "walrus",
    "reindeer",
    "husky",
    "puffin",
    "yak",
    "whale",
    "dolphin",
    "shark",
    "octopus",
    "crab",
    "jellyfish",
    "seahorse",
    "pufferfish",
    "narwhal",
    "otter",
    "frog",
    "turtle",
    "gecko",
    "chameleon",
    "snake",
    "crocodile",
    "bee",
    "ladybird",
    "butterfly",
    "snail",
    "dragon",
    "unicorn",
    "phoenix",
    "griffin",
    "yeti",
    "pegasus",
    "kraken",
    "sphinx",
    "wyvern",
    "golem",
    "trex",
    "triceratops",
    "stegosaurus",
    "raptor",
    "pterodactyl",
    "brachiosaurus",
    "ankylosaurus",
    "spinosaurus",
    "dilophosaurus",
    "mosasaurus",
    "astronaut",
    "alien",
    "martian",
    "moon",
    "sun",
    "star",
    "comet",
    "satellite",
    "ufo",
    "rover",
    "robot",
    "android",
    "cyborg",
    "drone",
    "mecha",
    "servo",
    "glitch",
    "pixel",
    "sentry",
    "beacon",
    "vampire",
    "werewolf",
    "zombie",
    "ghost",
    "mummy",
    "frankenstein",
    "goblin",
    "ogre",
    "slime",
    "gargoyle",
  ];
function Kc(s) {
  return typeof s == "string" && rr.includes(s);
}
function cm(s) {
  return !(s?.role === "student" && s.aiAccess === !1);
}
function zn(s) {
  return s?.role === "student" && s.lane === "fallback";
}
function dm(s) {
  return s.role === "student" && s.dataSource === "real" ? "real" : "product";
}
const fm = 3600 * 12,
  Oa = "comp_school_local_development_session",
  pm = "x-comp-school-fallback-access",
  Sd = "https://comp.school/fallback",
  At = "comp.school",
  mm = /^(preview-[a-z0-9-]+)(?:\.[a-z0-9-]+)?\.comp\.school$/i,
  hm = /^(preview-[a-z0-9-]+)\.[a-z0-9-]+\.pages\.dev$/i,
  gm = Object.freeze({
    "comp.school": 3e3,
    "code.comp.school": 3001,
    "admin.comp.school": 3002,
    "exams.comp.school": 3010,
    "recall.comp.school": 3011,
    "mark.comp.school": 3013,
    "games.comp.school": 3014,
    "self-assess.comp.school": 3015,
    "issues.comp.school": 3016,
    "printouts.comp.school": 3017,
    "docs.comp.school": 3018,
    "homework.comp.school": 3019,
  });
function ui() {
  return um?.VITE_COMP_SCHOOL_TARGET === "android";
}
function Gc(s) {
  return `${globalThis.location.origin}${s.pathname}${s.search}${s.hash}`;
}
function Na(s) {
  const u = s
    .trim()
    .toLowerCase()
    .replace(/^\[|\]$/g, "");
  return u === "localhost" || u === "127.0.0.1" || u === "::1";
}
function ym(s) {
  return [
    `${Oa}=${encodeURIComponent(JSON.stringify({ version: 1, user: s }))}`,
    "Path=/",
    `Max-Age=${fm}`,
    "SameSite=Lax",
  ].join("; ");
}
function vm() {
  return [`${Oa}=`, "Path=/", "Max-Age=0", "SameSite=Lax"].join("; ");
}
function bd(s, u, l) {
  if (!l || !Na(u)) return null;
  const d = _m(s)[Oa];
  if (!d) return null;
  try {
    const p = JSON.parse(d),
      y = p.user;
    return p.version !== 1 ||
      !y ||
      typeof y.id != "string" ||
      typeof y.name != "string" ||
      !["admin", "teacher", "student"].includes(y.role)
      ? null
      : y;
  } catch {
    return null;
  }
}
function wm(s, u, l) {
  const d = new URL(s),
    p = new URLSearchParams(d.hash.replace(/^#/, ""));
  return (
    p.set("fallback", u),
    (d.hash = p.toString()),
    l ? Ed(d.toString(), l) : d.toString()
  );
}
function Ed(s, u) {
  const l = new URL(s),
    d = new URLSearchParams(l.hash.replace(/^#/, ""));
  return (d.set(Sa, u), (l.hash = d.toString()), l.toString());
}
const Sa = "fallbackAvatar",
  ba = "comp-school-fallback-avatar";
function xm(s) {
  let u = 2166136261;
  for (let l = 0; l < s.length; l += 1)
    ((u ^= s.charCodeAt(l)), (u = Math.imul(u, 16777619) >>> 0));
  return rr[u % rr.length];
}
function km(s = Math.random) {
  const u = Math.min(rr.length - 1, Math.max(0, Math.floor(s() * rr.length)));
  return rr[u];
}
function Sm(s, u, l = Math.random) {
  const d = s.getItem(ba),
    p = Kc(u) ? u : Kc(d) ? d : km(l);
  return (p !== d && s.setItem(ba, p), p);
}
function bm(s) {
  return btoa(s).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}
function Em(s) {
  let u = "";
  for (const l of s) u += String.fromCharCode(l);
  return bm(u);
}
function jm(s) {
  if (!s || !/^[A-Za-z0-9_-]+$/.test(s))
    throw new Error("Invalid base64url value");
  const u = s
      .replace(/-/g, "+")
      .replace(/_/g, "/")
      .padEnd(Math.ceil(s.length / 4) * 4, "="),
    l = atob(u),
    d = new Uint8Array(l.length);
  for (let p = 0; p < l.length; p += 1) d[p] = l.charCodeAt(p);
  if (Em(d) !== s) throw new Error("Non-canonical base64url value");
  return d;
}
function jd(s) {
  const u = jm(s);
  return new TextDecoder("utf-8", { fatal: !0 }).decode(u);
}
function Cm(s) {
  return !!s && typeof s == "object" && !Array.isArray(s);
}
function Cd(s) {
  const u = JSON.parse(s);
  if (!Cm(u)) throw new Error("Expected a JSON object");
  return u;
}
const Ad = Object.freeze([
    {
      hostname: "exams.comp.school",
      prefix: "/exams",
      pagesProject: "exam-host",
    },
    {
      hostname: "recall.comp.school",
      prefix: "/recall",
      pagesProject: "comp-school-recall",
    },
    {
      hostname: "code.comp.school",
      prefix: "/code",
      pagesProject: "coding-playground",
    },
  ]),
  Am = /^(preview-[a-z0-9-]+)\./i;
function Pm(s) {
  const u = s.trim().toLowerCase().replace(Am, "");
  return Ad.find((l) => l.hostname === u) ?? null;
}
function Pd(s) {
  return Ad.find((u) => s === u.prefix || s.startsWith(`${u.prefix}/`)) ?? null;
}
function zd(s) {
  const u = s.trim().toLowerCase();
  return (u.match(mm) || u.match(hm))?.[1] || null;
}
function fn(s) {
  if (ui()) return globalThis.location.origin;
  if (Na(s))
    return `http://${s.replace(/^\[|\]$/g, "") === "::1" ? "[::1]" : s}:3000`;
  const u = zd(s);
  return u ? `https://${u}.${At}` : `https://${At}`;
}
function Gr(s, u) {
  if (ui()) {
    const p = Qc(At, u);
    if (p) return Gc(new URL(p));
    try {
      const y = new URL(u);
      return y.hostname.toLowerCase() === At ? Gc(y) : u;
    } catch {
      return u;
    }
  }
  if (Na(s))
    try {
      const p = new URL(u),
        y = gm[p.hostname.toLowerCase()];
      if (y)
        return (
          (p.protocol = "http:"),
          (p.hostname = s),
          (p.port = String(y)),
          p.toString()
        );
    } catch {
      return u;
    }
  const l = Qc(s, u);
  if (l) return l;
  const d = zd(s);
  if (!d) return u;
  try {
    const p = new URL(u),
      y = p.hostname.toLowerCase();
    if (y === At || y.endsWith(`.${At}`))
      return (
        (p.hostname = y === At ? `${d}.${At}` : `${d}.${y}`),
        p.toString()
      );
  } catch {
    return u;
  }
  return u;
}
function Qc(s, u) {
  try {
    const l = new URL(u),
      d = Pm(l.hostname);
    if (!d || l.hostname.toLowerCase() !== d.hostname) return null;
    const p = new URL(fn(s));
    return (
      (l.protocol = p.protocol),
      (l.hostname = p.hostname),
      (l.port = p.port),
      (l.pathname = `${d.prefix}${l.pathname}`),
      l.toString()
    );
  } catch {
    return null;
  }
}
function _d(s) {
  if (!s?.trim()) return null;
  try {
    const u = new URL(s),
      l = u.hostname.toLowerCase();
    return u.protocol !== "https:" ||
      u.username ||
      u.password ||
      u.port ||
      !(l === At || l.endsWith(`.${At}`)) ||
      (l.replace(/^preview-[a-z0-9-]+\./, "") === At && !Pd(u.pathname))
      ? null
      : u.toString();
  } catch {
    return null;
  }
}
function zm(s, u, l) {
  const d = l?.trim() || fn(s),
    p = _d(Gr(s, u));
  if (!p) return d;
  try {
    const y = new URL(d);
    return (y.searchParams.set("returnTo", p), y.toString());
  } catch {
    return d;
  }
}
function _m(s) {
  return s
    ? s.split(";").reduce((u, l) => {
        const [d, ...p] = l.trim().split("=");
        if (!d) return u;
        const y = p.join("=");
        try {
          u[d] = decodeURIComponent(y);
        } catch {
          u[d] = y;
        }
        return u;
      }, {})
    : {};
}
function aa(s) {
  if (!s) return null;
  try {
    const u = Cd(jd(s.split(".")[0] ?? ""));
    return u.iss === Sd && typeof u.exp == "number" && Number.isInteger(u.exp)
      ? u.exp * 1e3
      : null;
  } catch {
    return null;
  }
}
function Ea(s, u = new Date()) {
  if (!s) return !1;
  try {
    const [l, d, p] = s.split(".");
    if (!l || p !== void 0 || !d || !/^[A-Za-z0-9_-]+$/.test(d)) return !1;
    const y = Cd(jd(l));
    return (
      y.iss === Sd &&
      typeof y.exp == "number" &&
      Number.isInteger(y.exp) &&
      (ui() || y.exp > Math.floor(u.getTime() / 1e3))
    );
  } catch {
    return !1;
  }
}
function Tm(s) {
  const u = window.location.hostname.toLowerCase(),
    l =
      u === "comp.school" || u.endsWith(".comp.school")
        ? "; Domain=comp.school"
        : "",
    d = window.location.protocol === "https:" ? "; Secure" : "";
  return `; Path=/; Max-Age=${s}; SameSite=Lax${l}${d}`;
}
const Rm = [
    "examhost:",
    "coding-playground:theme:",
    "companion:variant:",
    "comp-school:flashcards:",
    "comp-school:paused:",
    "comp-school-self-assessment-v2",
    "comp-school:game-clock:",
    "comp-school:homework-done:",
    "comp-school:btec-coursework:",
    "comp-school:btec-games:",
  ],
  Td = ["comp_school_recent_sessions", "comp_school_btec_recent_sessions"],
  Lm = 200,
  Rd = 64e3,
  Ld = /^\d{1,20}$/;
function Md(s) {
  if (typeof s != "string" || s.length > Lm || /[\u0000-\u001f]/.test(s))
    return !1;
  if (s.startsWith("cookie:")) return Td.includes(s.slice(7));
  if (!s.startsWith("local:")) return !1;
  const u = s.slice(6);
  return Rm.some((l) => u.startsWith(l) && u.length > l.length);
}
function ii(s, u) {
  const l = {};
  for (const [p, y] of Object.entries(u)) s[p] !== y && (l[p] = y);
  const d = Object.keys(s).filter((p) => !(p in u));
  return { set: l, remove: d };
}
function Vr(s) {
  return s.remove.length > 0 || Object.keys(s.set).length > 0;
}
function Od(s) {
  let u = 2166136261;
  for (let l = 0; l < s.length; l += 1)
    ((u ^= s.charCodeAt(l)), (u = Math.imul(u, 16777619)));
  return `${(u >>> 0).toString(36)}.${s.length.toString(36)}`;
}
function Mm(s) {
  return Object.fromEntries(Object.entries(s).map(([u, l]) => [u, Od(l)]));
}
function Om(s, u) {
  const l = {};
  for (const [p, y] of Object.entries(u)) s[p] !== Od(y) && (l[p] = y);
  const d = Object.keys(s).filter((p) => !(p in u));
  return { set: l, remove: d };
}
function Nm(s, u) {
  const l = { ...s, ...u.set };
  for (const d of u.remove) delete l[d];
  return l;
}
const ai = "comp-school:saved-state-owner",
  _n = "comp-school:saved-state-dirty",
  Ia = "comp-school:saved-state-confirmed",
  Da = "comp-school:saved-state-revisions",
  Im = 4320 * 60 * 60,
  Dm = 3e3,
  Um = "comp-school:recent-sessions-change";
function Fm(s) {
  return `${s.dataSource === "real" ? "real" : "product"}:${s.id}`;
}
function wt() {
  try {
    return window.localStorage;
  } catch {
    return null;
  }
}
function Wm(s) {
  const u = `${s}=`,
    d = window.document.cookie
      .split("; ")
      .find((p) => p.startsWith(u))
      ?.slice(u.length);
  return d || null;
}
function Ua() {
  const s = {},
    u = wt();
  if (u)
    for (let l = 0; l < u.length; l += 1) {
      const d = u.key(l);
      if (!d || !Md(`local:${d}`)) continue;
      const p = u.getItem(d);
      p !== null && p.length <= Rd && (s[`local:${d}`] = p);
    }
  for (const l of Td) {
    const d = Wm(l);
    d !== null && (s[`cookie:${l}`] = d);
  }
  return s;
}
function Fa() {
  const s = [],
    u = wt();
  if (!u) return s;
  for (let l = 0; l < u.length; l += 1) {
    const d = u.key(l);
    if (!d || !Md(`local:${d}`)) continue;
    const p = u.getItem(d);
    p !== null && p.length > Rd && s.push(`local:${d}`);
  }
  return s;
}
function Zc(s, u) {
  if (s.startsWith("cookie:")) {
    const d = s.slice(7);
    window.document.cookie = `${d}=${u ?? ""}${Tm(u === null ? 0 : Im)}`;
    return;
  }
  const l = s.slice(6);
  u === null ? wt()?.removeItem(l) : wt()?.setItem(l, u);
}
function si(s, u = new Set()) {
  for (const l of [...Object.keys(Ua()), ...Fa()])
    !(l in s) && !u.has(l) && Zc(l, null);
  for (const [l, d] of Object.entries(s)) u.has(l) || Zc(l, d);
  window.dispatchEvent(new Event(Um));
}
const ja = "comp-school:saved-state-notice",
  Yc = new Set();
function Ca(s, u) {
  const l = u.filter((d) => !Yc.has(`${s}:${d}`));
  if (!(!l.length || typeof window > "u")) {
    for (const d of l) Yc.add(`${s}:${d}`);
    window.dispatchEvent(new CustomEvent(ja, { detail: { kind: s, keys: l } }));
  }
}
function $m(s) {
  const u = (l) => {
    const d = l.detail;
    d && (d.kind === "conflict" || d.kind === "too-big") && s(d);
  };
  return (
    window.addEventListener(ja, u),
    () => window.removeEventListener(ja, u)
  );
}
function Wa() {
  const s = wt();
  s?.getItem(ai) &&
    (si({}),
    s.removeItem(ai),
    s.removeItem(_n),
    s.removeItem(Ia),
    s.removeItem(Da));
}
function Bm() {
  try {
    const s = JSON.parse(wt()?.getItem(Ia) ?? "null");
    return !s || typeof s != "object" || Array.isArray(s)
      ? null
      : Object.fromEntries(
          Object.entries(s).filter((u) => typeof u[1] == "string"),
        );
  } catch {
    return null;
  }
}
function Aa(s) {
  try {
    wt()?.setItem(Ia, JSON.stringify(Mm(s)));
  } catch {}
}
function Nd() {
  try {
    const s = JSON.parse(wt()?.getItem(Da) ?? "null");
    return !s || typeof s != "object" || Array.isArray(s)
      ? null
      : Object.fromEntries(
          Object.entries(s).filter(
            (u) => typeof u[1] == "string" && Ld.test(u[1]),
          ),
        );
  } catch {
    return null;
  }
}
function Pa(s) {
  try {
    wt()?.setItem(Da, JSON.stringify(s));
  } catch {}
}
function Id(s, u, l) {
  const d = {};
  if (!u) return d;
  for (const p of [...Object.keys(s.set), ...s.remove])
    u[p] ? (d[p] = u[p]) : p in l || (d[p] = "0");
  return d;
}
function Dd(s, u, l) {
  const d = { ...s },
    p = new Set(l.conflicts);
  for (const y of u.remove) p.has(y) || delete d[y];
  for (const y of Object.keys(u.set))
    !p.has(y) && !l.revisions[y] && delete d[y];
  return { ...d, ...l.revisions };
}
const Hm = new Set();
function za() {
  for (const s of [...Hm])
    try {
      s();
    } catch {}
}
function qc(s) {
  return !s || typeof s != "object" || Array.isArray(s)
    ? {}
    : Object.fromEntries(
        Object.entries(s).filter(
          (u) => typeof u[1] == "string" && Ld.test(u[1]),
        ),
      );
}
function Vm(s) {
  const u = new URL("/api/saved-state", s).toString();
  return {
    async read() {
      const l = await fetch(u, {
          cache: "no-store",
          credentials: "include",
          headers: { accept: "application/json" },
        }),
        d = await l.json().catch(() => null);
      if (!l.ok || !d?.ok || !d.items)
        throw new Error("Saved state could not be read.");
      return { items: d.items, revisions: qc(d.revisions) };
    },
    async write(l, { keepalive: d = !1 } = {}) {
      const p = await fetch(u, {
        method: "POST",
        cache: "no-store",
        credentials: "include",
        keepalive: d,
        headers: {
          accept: "application/json",
          "content-type": "application/json",
        },
        body: JSON.stringify(l),
      });
      if (!p.ok) throw new Error("Saved state could not be written.");
      const y = await p.json().catch(() => null),
        S = new Set([...Object.keys(l.set), ...l.remove]);
      return {
        revisions: qc(y?.revisions),
        conflicts: Array.isArray(y?.conflicts)
          ? y.conflicts.filter((j) => typeof j == "string" && S.has(j))
          : [],
      };
    },
  };
}
async function Km(s, u) {
  const l = wt();
  if (!l) return null;
  const d = Fm(s),
    p = l.getItem(ai);
  p && p !== d && Wa();
  let y;
  try {
    y = await u.read();
  } catch {
    return null;
  }
  const S = y.items,
    j = Ua(),
    k = new Set(p === d ? Fa() : []);
  for (const X of k) X in S && (j[X] = S[X]);
  k.size && Ca("too-big", [...k]);
  const F = p === d ? Bm() : null,
    T = p === d ? Nd() : p ? {} : y.revisions,
    V =
      (p === d && l.getItem(_n) !== null) ||
      (!p && Object.keys(S).length === 0 && Object.keys(j).length > 0),
    D = F && !V ? Om(F, j) : null;
  l.setItem(ai, d);
  const q = V ? j : D && Vr(D) ? Nm(S, D) : null;
  if (q) {
    const X = ii(S, q);
    try {
      let O = q,
        $ = y.revisions;
      if (Vr(X)) {
        const K = await u.write({ ...X, base: Id(X, T, F ?? {}) });
        if ((($ = Dd(y.revisions, X, K)), K.conflicts.length)) {
          O = { ...q };
          for (const ae of K.conflicts)
            ae in S ? (O[ae] = S[ae]) : delete O[ae];
        }
      }
      return (O !== j && si(O, k), l.removeItem(_n), Aa(O), Pa($), O);
    } catch {
      return (l.setItem(_n, "1"), q !== j && si(q, k), S);
    }
  }
  return (si(S, k), l.removeItem(_n), Aa(S), Pa(y.revisions), S);
}
function Gm(s, u, l = Dm) {
  let d = s,
    p = Nd();
  const y = new Set();
  let S = !1;
  function j() {
    const D = Ua(),
      q = Fa();
    q.length && Ca("too-big", q);
    for (const X of [...q, ...y]) X in d ? (D[X] = d[X]) : delete D[X];
    return D;
  }
  async function k(D = !1) {
    if (S && !D) return;
    const q = j(),
      X = ii(d, q);
    if (Vr(X)) {
      (wt()?.setItem(_n, "1"), (S = !0));
      try {
        const O = await u.write({ ...X, base: Id(X, p, d) }, { keepalive: D });
        ((p = Dd(p, X, O)), Pa(p));
        const $ = { ...q };
        for (const K of O.conflicts)
          (y.add(K), K in d ? ($[K] = d[K]) : delete $[K]);
        ((d = $),
          Aa($),
          O.conflicts.length && Ca("conflict", O.conflicts),
          Vr(ii(d, j())) || wt()?.removeItem(_n));
      } catch {
      } finally {
        S = !1;
      }
    }
  }
  const F = window.setInterval(() => void k(), l),
    T = () => {
      window.document.visibilityState === "hidden" && (za(), k(!0));
    },
    V = () => {
      (za(), k(!0));
    };
  return (
    window.document.addEventListener("visibilitychange", T),
    window.addEventListener("pagehide", V),
    {
      flush: () => k(),
      pending: () => Vr(ii(d, j())),
      stop() {
        (window.clearInterval(F),
          window.document.removeEventListener("visibilitychange", T),
          window.removeEventListener("pagehide", V));
      },
    }
  );
}
let Kr = null;
function Qm(s) {
  return (
    (Kr ??= (async () => {
      const u = Vm(fn(window.location.hostname)),
        l = await Km(s, u);
      return l ? Gm(l, u) : null;
    })()),
    Kr
  );
}
async function Zm(s = 4e3) {
  const u = await Kr?.catch(() => null);
  if (!u) return;
  const l = Date.now() + s;
  do {
    if ((await u.flush().catch(() => {}), !u.pending())) return;
    await new Promise((d) => window.setTimeout(d, 150));
  } while (Date.now() < l);
}
async function _a(s = 4e3) {
  (za(), await Zm(s));
}
async function Ym() {
  const s = await Kr?.catch(() => null);
  ((Kr = null), s && (await s.flush().catch(() => {}), s.stop()), Wa());
}
const Ud = {
    1.1: [
      {
        term: "Arithmetic Logic Unit (ALU)",
        definition:
          "Performs calculations and logical comparisons inside the Central Processing Unit (CPU)",
        example: "Adding two numbers together, comparing if A > B",
      },
      {
        term: "Control Unit (CU)",
        definition:
          "Directs the flow of data and instructions around the CPU by sending control signals",
        example:
          "Sends signals telling memory to release data to the correct register",
      },
      {
        term: "Cache",
        definition:
          "Small, fast memory inside the CPU that stores frequently used data and instructions",
        example:
          "Stores the next instruction the CPU is likely to need so it does not have to fetch from Random Access Memory (RAM)",
      },
      {
        term: "Register",
        definition:
          "A tiny, high-speed storage location inside the CPU that temporarily holds data, instructions or memory addresses",
        example:
          "Memory Address Register (MAR), Memory Data Register (MDR), Accumulator (ACC), Program Counter (PC)",
      },
      {
        term: "Memory Address Register (MAR)",
        definition:
          "A register that holds the memory address of the data or instruction the CPU wants to read or write",
        example:
          "Before fetching the next instruction, the Program Counter copies its address into the MAR",
      },
      {
        term: "Memory Data Register (MDR)",
        definition:
          "A register that holds the data or instruction just fetched from memory, or about to be written to memory",
        example:
          "After fetching, the instruction at the address held in the MAR is loaded into the MDR",
      },
      {
        term: "Program Counter (PC)",
        definition:
          "A register that holds the memory address of the next instruction to be fetched, incrementing automatically after each fetch",
        example:
          "After fetching the instruction at address 100, the PC updates to 101 ready for the next cycle",
      },
      {
        term: "Accumulator (ACC)",
        definition:
          "A register in the CPU that temporarily stores the result of arithmetic and logical operations carried out by the ALU",
        example:
          "When the ALU calculates 5 + 3, the result 8 is held in the Accumulator before being moved to memory",
      },
      {
        term: "Fetch-Decode-Execute (FDE) Cycle",
        definition:
          "The repeated process of fetching an instruction from memory, decoding what it means, then executing it",
        example:
          "The CPU fetches an instruction from RAM; the CU decodes it; the CPU carries it out, for example using the ALU to add two values",
      },
      {
        term: "Clock Speed",
        definition:
          "The number of CPU clock cycles per second, usually measured in Gigahertz (GHz); a higher clock speed allows more cycles each second",
        example:
          "A 3.5 GHz processor has 3.5 billion clock cycles per second; clock speed alone does not determine performance",
      },
      {
        term: "Cores",
        definition:
          "Independent processing units within a CPU that can work on instructions concurrently",
        example:
          "More cores can speed up work that can be split between them; doubling cores does not necessarily halve running time",
      },
      {
        term: "Cache Size",
        definition:
          "The amount of fast cache memory available to store frequently used data and instructions",
        example:
          "More cache can reduce fetching from slower RAM, improving performance when the needed data is in cache",
      },
      {
        term: "Embedded System",
        definition:
          "A computer built into a larger device to carry out a specific task or a limited set of related tasks",
        example:
          "A washing-machine controller runs the wash cycle; a thermostat controls heating; a car's automatic-light controller switches its lights according to light levels",
      },
      {
        term: "Von Neumann Architecture",
        definition:
          "A model of computer design where a single memory stores both data and instructions, and the CPU processes them sequentially via the fetch-decode-execute cycle",
        example:
          "The CPU fetches instructions from the same memory where data is stored, using registers like MAR, MDR, PC and ACC to manage the process",
      },
      {
        term: "Embedded System Characteristics",
        definition:
          "Dedicated hardware and software perform limited functions; the user cannot easily repurpose the system to run unrelated applications",
        example:
          "A car's automatic-light controller has a processor dedicated to checking the light sensor and switching the lamps, rather than running general-purpose applications",
      },
    ],
    1.2: [
      {
        term: "Random Access Memory (RAM)",
        definition:
          "Volatile primary storage that holds data and programs currently in use; contents are lost when power is off",
        example:
          "When you open Google Chrome, its program code is loaded from storage into RAM",
      },
      {
        term: "Read Only Memory (ROM)",
        definition:
          "Non-volatile primary storage that retains startup or firmware instructions without power; its contents are not normally changed during use",
        example:
          "A car controller's ROM can hold its startup instructions and the firmware that controls the system",
      },
      {
        term: "Virtual Memory",
        definition:
          "Secondary storage used to hold data moved out of RAM when RAM is full; the OS transfers data back to RAM when needed",
        example:
          "An OS moves inactive data to an SSD or HDD to free RAM; accessing secondary storage is slower than accessing RAM",
      },
      {
        term: "Magnetic Storage",
        definition:
          "Non-volatile storage that records data magnetically, for example on hard disks or magnetic tape",
        example:
          "An HDD uses rotating platters and a read/write head; magnetic tape is often used for large backups",
      },
      {
        term: "Optical Storage",
        definition: "Uses a laser to read and write data on a reflective disc",
        example: "Compact Disc (CD), Digital Versatile Disc (DVD), Blu-ray",
      },
      {
        term: "Solid State Storage",
        definition:
          "Uses electronic flash memory with no moving parts, making it faster and more durable",
        example:
          "Solid State Drive (SSD), Universal Serial Bus (USB) flash drive",
      },
      {
        term: "Bit",
        definition:
          "The smallest unit of data in computing; a single binary digit, either 0 or 1",
        example: "One switch that is either on (1) or off (0)",
      },
      {
        term: "Nibble",
        definition: "A group of 4 bits",
        example: "Half a byte, e.g. 1010",
      },
      {
        term: "Byte",
        definition: "A group of 8 bits",
        example: "Can represent a whole number from 0 to 255",
      },
      {
        term: "Kilobyte (KB)",
        definition:
          "A unit of data storage equal to 1000 bytes (OCR also accepts 1024)",
        example: "A small text file might be 50 KB",
      },
      {
        term: "Megabyte (MB)",
        definition:
          "A unit of data storage equal to 1000 kilobytes (OCR also accepts 1024)",
        example: "A photo might be several MB",
      },
      {
        term: "Gigabyte (GB)",
        definition:
          "A unit of data storage equal to 1000 megabytes (OCR also accepts 1024)",
        example: "A high-definition film might be 4 GB",
      },
      {
        term: "Terabyte (TB)",
        definition:
          "A unit of data storage equal to 1000 gigabytes (OCR also accepts 1024)",
        example: "A laptop hard drive might store 1 TB of data",
      },
      {
        term: "Petabyte (PB)",
        definition:
          "A unit of data storage equal to 1000 terabytes (OCR also accepts 1024)",
        example: "Large cloud providers may store many PB of data",
      },
      {
        term: "Binary",
        definition: "Base-2 number system using only the digits 0 and 1",
        example: "01001010 in binary represents 74 in denary",
      },
      {
        term: "Denary",
        definition:
          "Base-10 number system using digits 0 to 9; the everyday counting system",
        example: "The number 255 in denary is 11111111 in binary",
      },
      {
        term: "Hexadecimal",
        definition: "Base-16 number system using digits 0-9 and letters A-F",
        example:
          "2F = 2 x 16 + 15 = 47 in denary; each hex digit maps to four bits, so 2F = 0010 1111",
      },
      {
        term: "Binary Addition",
        definition:
          "Adding two binary numbers together, carrying over when a column totals 2 or more",
        example: "1011 + 0111 = 10010 (11 + 7 = 18 in denary)",
      },
      {
        term: "Overflow",
        definition:
          "An error that occurs when the result of a binary calculation needs more bits than are available; the extra bit is lost so the stored answer is incorrect",
        example:
          "Adding 11111111 + 00000001 in 8 bits gives 100000000 - the leading 1 is dropped and the result is recorded as 00000000",
      },
      {
        term: "Binary Shift",
        definition:
          "Moving every bit a set number of places, filling empty positions with zero and discarding bits shifted out",
        example:
          "For unsigned 8-bit values, 00001100 shifted left once becomes 00011000 (12 to 24); 00001101 shifted right once becomes 00000110 (13 to 6). Left shifts double per place only if no significant bit is lost",
      },
      {
        term: "Most Significant Bit (MSB)",
        definition:
          "The bit with the highest place value in a binary number, usually the leftmost bit",
        example: "In 10110001, the MSB is 1 and represents 128",
      },
      {
        term: "Least Significant Bit (LSB)",
        definition:
          "The bit with the lowest place value in a binary number, usually the rightmost bit",
        example: "In 10110001, the LSB is 1 and represents 1",
      },
      {
        term: "Character Set",
        definition:
          "A collection of characters with a unique code for each; n bits can represent up to 2^n different codes",
        example:
          "7 bits give 128 codes; 8 bits give 256, so representing 150 different characters requires at least 8 bits",
      },
      {
        term: "American Standard Code for Information Interchange (ASCII)",
        definition:
          "A character set mapping characters to numeric codes; OCR J277 questions represent ASCII using 8 bits per character (original ASCII used 7 bits)",
        example:
          "'A' is 65 (01000001), 'B' is 66 (01000010); consecutive letters have consecutive codes",
      },
      {
        term: "Unicode",
        definition:
          "A character set covering many languages and symbols; the number of bits used depends on the encoding",
        example:
          "Unicode can represent Hello, Chinese characters and emojis; ASCII cannot represent all of these. Use the stated bits per character in file-size questions",
      },
      {
        term: "Sound Sampling",
        definition:
          "Converting analogue sound to digital by measuring amplitude at regular intervals and storing each sample as a binary value",
        example:
          "Higher sample rate or bit depth can improve fidelity and increase file size; a longer recording increases file size without improving fidelity",
      },
      {
        term: "Sample Rate",
        definition:
          "The number of audio samples taken per second, measured in Hertz (Hz)",
        example: "CD quality audio uses 44,100 samples per second (44.1 kHz)",
      },
      {
        term: "Bit Depth",
        definition:
          "The number of bits used to record each audio sample; more bits means more detail",
        example:
          "16-bit audio gives 65,536 possible amplitude levels per sample",
      },
      {
        term: "Pixel",
        definition:
          "The smallest individual element of a digital image; each pixel stores a single colour value as a binary code",
        example:
          "A 1920 x 1080 image is made up of 2,073,600 pixels arranged in a grid",
      },
      {
        term: "Bitmap Image",
        definition:
          "A graphic made up of a grid of pixels, each assigned a colour value",
        example: "A 1920 x 1080 image contains over 2 million pixels",
      },
      {
        term: "Colour Depth",
        definition:
          "The number of bits used for each pixel; n bits allow up to 2^n colours",
        example:
          "7 bits allow 128 colours; 8 allow 256, so 240 colours need 8 bits. More bits can improve colour detail but increase file size",
      },
      {
        term: "Resolution",
        definition:
          "The dimensions of an image in pixels, usually width x height",
        example:
          "A 200 x 100 image has 20,000 pixels. Increasing dimensions can capture more detail but increases file size at the same colour depth",
      },
      {
        term: "Metadata",
        definition:
          "Additional data stored alongside an image or sound file describing its properties so the file can be interpreted correctly",
        example:
          "An image file's metadata includes width, height, colour depth, date taken and camera model",
      },
      {
        term: "Image File Size Calculation",
        definition:
          "File size = width x height x colour depth (in bits), then convert to bytes",
        example:
          "100 x 100 pixels at 24-bit colour = 240,000 bits = 30,000 bytes",
      },
      {
        term: "Sound File Size Calculation",
        definition:
          "File size = sample rate x bit depth x duration (seconds), then convert to bytes",
        example: "44,100 x 16 x 10 seconds = 7,056,000 bits = 882,000 bytes",
      },
      {
        term: "Text File Size Calculation",
        definition:
          "File size = bits per character x number of characters, then convert bits to bytes if required",
        example:
          "A 1,000-character message in 8-bit ASCII = 1,000 x 8 = 8,000 bits = 1,000 bytes (1 KB)",
      },
      {
        term: "Compression",
        definition:
          "Reducing the size of a file so it takes up less storage and transfers more quickly across a network; can be lossy or lossless",
        example:
          "A 10 MB photo compressed to 2 MB downloads five times faster on the same connection",
      },
      {
        term: "Lossy Compression",
        definition:
          "Reduces file size by permanently removing some data that cannot be recovered",
        example:
          "Joint Photographic Experts Group (JPEG) removes colour detail the human eye barely notices",
      },
      {
        term: "Lossless Compression",
        definition:
          "Reduces file size without losing any data; the original file can be perfectly rebuilt",
        example:
          "Portable Network Graphics (PNG), ZIP files; identical data when decompressed",
      },
      {
        term: "Secondary Storage",
        definition:
          "Non-volatile storage that keeps programs and files when power is off",
        example:
          "A saved document remains on an SSD after shutdown; it is loaded into RAM when opened",
      },
      {
        term: "Choosing Storage",
        definition:
          "Compare capacity, speed, cost, portability, durability and reliability against the needs of the user",
        example:
          "A portable SSD is fast, compact and resists knocks because it has no moving parts; an HDD may offer more capacity for the same cost, but moving parts are vulnerable to damage",
      },
    ],
    1.3: [
      {
        term: "Local Area Network (LAN)",
        definition:
          "A network covering a small geographical area, typically owned and managed by one organisation",
        example:
          "A school network connecting all computers across one or two buildings",
      },
      {
        term: "Wide Area Network (WAN)",
        definition:
          "A network covering a large geographical area, using third-party communication links",
        example:
          "The internet connecting users in London to servers in New York",
      },
      {
        term: "Bandwidth",
        definition:
          "The maximum amount of data that can be transmitted across a network connection in a fixed time, usually measured in megabits per second (Mbps); a key factor affecting network performance alongside the number of connected devices",
        example:
          "A 100 Mbps fibre line shared between 10 users averages 10 Mbps each; a school Wi-Fi slows at break time when many phones connect",
      },
      {
        term: "Star Topology",
        definition:
          "A network layout where all devices connect to a central switch or hub",
        example:
          "A failed device link leaves other devices connected, but failure of the central switch affects the whole network; adding a device requires a link to the switch",
      },
      {
        term: "Mesh Topology",
        definition:
          "A network with multiple direct connections between devices; a full mesh connects every pair, while a partial mesh connects only some pairs",
        example:
          "Alternative paths can keep communication working if a link fails; extra connections can make setup more complex",
      },
      {
        term: "Client-Server Network",
        definition:
          "A central server provides services and resources; client devices make requests",
        example:
          "A school file server holds shared folders that students access from their PCs",
      },
      {
        term: "Peer-to-Peer (P2P) Network",
        definition:
          "All devices are equal and share resources directly with each other without a central server",
        example: "Two laptops sharing files directly over a home network",
      },
      {
        term: "Wired Connection (Ethernet)",
        definition:
          "Connecting devices using physical cables and Ethernet standards",
        example:
          "A fixed office computer can use a stable, high-bandwidth cable connection, but installing cables costs money and restricts movement",
      },
      {
        term: "Wireless Connection (Wi-Fi)",
        definition:
          "Connecting devices using radio waves through a Wireless Access Point (WAP)",
        example:
          "A tablet can move within signal range without a cable, but walls, interference and shared bandwidth can reduce performance",
      },
      {
        term: "Bluetooth",
        definition:
          "Short-range wireless technology for pairing devices over a few metres",
        example: "Wireless headphones connecting to a smartphone",
      },
      {
        term: "Internet Protocol (IP) Address",
        definition:
          "An address used to identify a device or interface on an IP network and route data to it",
        example:
          "IPv4 example: 192.168.1.1. IPv6 example: 2001:0db8:0000:0000:0000:0000:0000:0001",
      },
      {
        term: "Media Access Control (MAC) Address",
        definition:
          "A unique hardware address permanently burned into a device's Network Interface Card (NIC)",
        example:
          "00:1A:2B:3C:4D:5E; set during manufacturing and cannot normally be changed",
      },
      {
        term: "TCP (Transmission Control Protocol)",
        definition:
          "A network protocol that checks packets are delivered reliably and reassembles them in the correct order",
        example:
          "When a web page is downloaded, TCP can request missing packets again so the page data arrives complete",
      },
      {
        term: "IP (Internet Protocol)",
        definition:
          "A network protocol that adds source and destination addresses so packets can be routed between networks",
        example:
          "Each packet travelling across the internet includes an IP address for the device it is being sent to",
      },
      {
        term: "HyperText Transfer Protocol (HTTP) / Secure (HTTPS)",
        definition:
          "Protocols for requesting and transferring web pages; HTTPS also encrypts the data between the browser and the web server",
        example:
          "Visiting https://www.bbc.co.uk; the padlock icon shows HTTPS is active",
      },
      {
        term: "File Transfer Protocol (FTP)",
        definition:
          "A protocol used for transferring files between a client and a server",
        example:
          "Uploading website files from a local computer to a web hosting server",
      },
      {
        term: "SMTP (Simple Mail Transfer Protocol)",
        definition:
          "The protocol used to send emails from a client to a server, or between mail servers",
        example:
          "When you click Send in Gmail, SMTP transfers your email to the recipient's mail server",
      },
      {
        term: "POP (Post Office Protocol)",
        definition:
          "An email protocol that downloads messages from the server to the local device and then removes them from the server",
        example:
          "Downloading emails to a desktop client using POP means they are no longer accessible from your phone",
      },
      {
        term: "IMAP (Internet Message Access Protocol)",
        definition:
          "An email protocol that keeps messages stored on the server and syncs them across all devices",
        example:
          "Reading an email on your phone and it also appearing as read on your laptop uses IMAP",
      },
      {
        term: "Email Protocols",
        definition:
          "A set of rules that govern how emails are sent, received, and stored across networks; SMTP handles sending, while POP and IMAP handle receiving",
        example:
          "When you send an email, SMTP delivers it to the recipient's server; when they check their inbox, POP or IMAP retrieves it",
      },
      {
        term: "Layering",
        definition:
          "The concept of dividing network communication into separate, independent layers where each layer has a specific role and communicates only with the layers directly above and below it",
        example:
          "Switching from Ethernet to Wi-Fi only changes the layer that handles the connection; the layers above it, such as the one where HTTP works, are unaffected",
      },
      {
        term: "Network Interface Card (NIC)",
        definition:
          "Hardware component that allows a device to connect to a network, either wired or wirelessly",
        example: "Every laptop has a built-in wireless NIC",
      },
      {
        term: "Router",
        definition:
          "A device that forwards packets between different networks and determines the best route",
        example:
          "Your home router sends data between your LAN and the internet (WAN)",
      },
      {
        term: "Switch",
        definition:
          "A device that connects devices within a LAN and sends data only to the intended recipient using MAC addresses",
        example:
          "A 24-port switch in a school server room connecting all classroom PCs",
      },
      {
        term: "Wireless Access Point (WAP)",
        definition:
          "A device that allows wireless devices to connect to a wired network",
        example: "A WAP mounted on a classroom ceiling providing Wi-Fi",
      },
      {
        term: "Transmission Media",
        definition:
          "The physical pathways that carry data signals between devices on a network, either wired (cables) or wireless (radio waves)",
        example:
          "Copper Ethernet cable, fibre optic cable and Wi-Fi radio waves are all transmission media",
      },
      {
        term: "Domain Name System (DNS)",
        definition:
          "A system of Domain Name Servers that converts human-readable domain names into IP addresses so browsers can locate websites",
        example:
          "Typing www.bbc.co.uk into a browser; the DNS converts this to an IP address like 151.101.0.81 so the request reaches the correct server",
      },
      {
        term: "The Cloud",
        definition:
          "Remote provision of storage, software or processing over a network, usually the internet",
        example:
          "Cloud storage allows access from different devices and can reduce local hardware needs, but depends on connectivity and the provider, and may have ongoing costs",
      },
      {
        term: "Hosting",
        definition:
          "The provision of server space and resources by a hosting company so that websites, applications or files are continuously available over the internet",
        example:
          "A web hosting company stores a school's website files on its servers so they can be reached at any time via the school's domain name",
      },
      {
        term: "Web Server and Client",
        definition:
          "A web server stores and delivers web pages; a client is a device or program that requests and displays those pages",
        example:
          "A web server hosts the BBC website; your browser acts as the client requesting and displaying the page",
      },
      {
        term: "Standards",
        definition:
          "Agreed rules and specifications that allow hardware and software from different manufacturers to work together",
        example:
          "Standards ensure a keyboard made by one company works with a computer made by another; they enable interoperability across the industry",
      },
      {
        term: "IP Address Formats",
        definition:
          "IPv4 has four decimal groups from 0 to 255 separated by dots. An uncompressed IPv6 address has eight groups of up to four hexadecimal digits separated by colons",
        example:
          "192.168.1.1 is valid IPv4; 258.0.0.1 is invalid. 2001:0db8:0000:0000:0000:0000:0000:0001 is valid IPv6",
      },
    ],
    1.4: [
      {
        term: "Malware",
        definition:
          "Malicious software designed to damage systems or gain unauthorised access",
        example: "Virus, trojan, spyware, ransomware, worm",
      },
      {
        term: "Virus",
        definition:
          "Malware that attaches to a legitimate file and spreads when the file is executed",
        example:
          "A virus hidden inside a downloaded game installer that corrupts files when run",
      },
      {
        term: "Trojan",
        definition:
          "Malware disguised as legitimate software that creates a backdoor for attackers",
        example:
          "A free app that secretly installs a keylogger to record passwords",
      },
      {
        term: "Spyware",
        definition:
          "Malware that secretly monitors user activity and sends data to a third party",
        example:
          "Software tracking every website you visit and sending it to advertisers",
      },
      {
        term: "Ransomware",
        definition:
          "Malware that encrypts a victim's files and demands payment for the decryption key",
        example:
          "WannaCry attack in 2017 locked hospital computers and demanded Bitcoin",
      },
      {
        term: "Worm",
        definition:
          "Self-replicating malware that spreads automatically across networks without needing a host file or user action",
        example:
          "A worm exploits a vulnerability in connected computers and copies itself between them, slowing the network as it spreads",
      },
      {
        term: "Phishing",
        definition:
          "Fake communication (usually email) designed to trick users into revealing personal data",
        example:
          "An email pretending to be from a bank asking you to click a link and enter your login details",
      },
      {
        term: "Brute Force Attack",
        definition:
          "Trying every possible password combination systematically until the correct one is found",
        example:
          "Software cycling through millions of password combinations per second",
      },
      {
        term: "Denial of Service (DoS) Attack",
        definition:
          "Flooding a server with so many requests that it becomes overloaded and unavailable to legitimate users",
        example:
          "Overloading an online shop's server so real customers cannot access the website",
      },
      {
        term: "Structured Query Language (SQL) Injection",
        definition:
          "Inserting malicious SQL code into a website's input field to access or manipulate the database",
        example:
          "Typing ' OR 1=1 -- into a login form to bypass authentication",
      },
      {
        term: "Data Interception and Theft",
        definition:
          "Intercepting data as it is being transmitted across a network, often using packet sniffing tools or man-in-the-middle techniques",
        example:
          "An attacker on a public Wi-Fi network capturing unencrypted login credentials as they are sent between a laptop and a server",
      },
      {
        term: "Social Engineering",
        definition:
          "Manipulating people psychologically into giving up confidential information or access",
        example:
          "Phoning an IT helpdesk pretending to be a senior manager to get a password reset",
      },
      {
        term: "Penetration Testing",
        definition:
          "An authorised simulated attack carried out to identify security weaknesses before real attackers do",
        example:
          "An ethical hacker hired by a company to test whether their firewall can be breached",
      },
      {
        term: "Anti-Malware Software",
        definition:
          "Software that scans for, blocks and removes malicious programs such as viruses, trojans and spyware before they can damage the system",
        example:
          "Microsoft Defender or Norton scanning incoming downloads and quarantining infected files",
      },
      {
        term: "Passwords",
        definition:
          "A secret string of characters used to authenticate a user; strong passwords combine length, mixed case, digits and symbols to resist brute-force attacks",
        example:
          "Requiring at least 12 characters with mixed case, digits and symbols, and locking the account after three failed attempts",
      },
      {
        term: "Firewall",
        definition:
          "Software or hardware that monitors and filters incoming and outgoing network traffic based on security rules",
        example: "Blocking incoming connections from unrecognised IP addresses",
      },
      {
        term: "Encryption",
        definition:
          "Using an algorithm and key to turn readable data into ciphertext that needs the appropriate key to decrypt",
        example:
          "HTTPS encrypts transmitted data so an interceptor cannot understand it without the decryption key; encryption does not prevent interception",
      },
      {
        term: "User Access Levels",
        definition:
          "Rules that give each user only the access they need: which files, folders and software they can use, and whether they can read, edit or delete them",
        example:
          "A student account cannot install software, but an admin account can",
      },
      {
        term: "Physical Security",
        definition:
          "Measures that physically protect computer systems and data from unauthorised access, theft or damage",
        example:
          "Locked server rooms, security cameras, biometric door entry systems, cable locks on laptops",
      },
    ],
    1.5: [
      {
        term: "Operating System (OS)",
        definition:
          "System software that manages hardware resources and provides a platform for application software to run",
        example: "Microsoft Windows, Apple macOS, Linux, Google Android",
      },
      {
        term: "User Interface",
        definition:
          "The means by which the user interacts with the computer system",
        example:
          "Graphical User Interface (GUI) uses icons, windows and menus; Command Line Interface (CLI) uses typed text commands",
      },
      {
        term: "Memory Management",
        definition:
          "The OS allocates and frees RAM, manages transfers to and from memory, and keeps running programs separate to support multitasking",
        example:
          "The OS gives each application memory and can move inactive data to secondary storage when RAM is full",
      },
      {
        term: "Multitasking",
        definition:
          "The OS rapidly switches between running programs so they appear to run at the same time",
        example: "Listening to music on Spotify while typing an essay in Word",
      },
      {
        term: "Peripheral Management",
        definition:
          "An operating system function that controls communication with input, output and storage devices",
        example:
          "The OS manages sending data to a printer and receiving data from a scanner",
      },
      {
        term: "Drivers",
        definition:
          "Software that lets the operating system communicate with and control a specific hardware device",
        example:
          "Installing a printer driver so the OS knows how to send documents to print",
      },
      {
        term: "User Management",
        definition:
          "The OS controls user accounts, access levels and permissions",
        example:
          "An admin account has full access; a student account has restricted permissions",
      },
      {
        term: "File Management",
        definition:
          "The OS organises files into folders and directories and controls who can read, write or delete them",
        example:
          "Creating a folder called Homework, moving files into it, setting read-only permissions",
      },
      {
        term: "Defragmentation",
        definition:
          "A utility that reorganises fragmented files on a Hard Disk Drive (HDD) so they are stored in contiguous blocks",
        example:
          "Files accessed faster because the read/write head does not need to jump across the platter",
      },
      {
        term: "Compression Utility",
        definition:
          "Software that reduces the size of files for storage or transfer",
        example:
          "Zipping a folder of images before emailing it to reduce the attachment size",
      },
      {
        term: "Encryption Utility",
        definition:
          "Software that scrambles files or drives so they cannot be understood without the decryption key",
        example:
          "Encrypting a USB flash drive with BitLocker so its contents are protected if lost",
      },
      {
        term: "Utility Software",
        definition:
          "System software that maintains, protects or optimises a computer",
        example:
          "Encryption protects stored data; compression reduces file size; defragmentation speeds access to fragmented files on an HDD",
      },
    ],
    1.6: [
      {
        term: "Data Protection Act (DPA) 2018 / General Data Protection Regulation (GDPR)",
        definition:
          "United Kingdom (UK) law governing how personal data is collected, stored, used and shared; organisations must keep data secure",
        example:
          "A school must keep student records secure, only use them for educational purposes, and delete them when no longer needed",
      },
      {
        term: "Computer Misuse Act (CMA) 1990",
        definition:
          "UK law making it illegal to gain unauthorised access to computer systems, or to modify data without permission",
        example:
          "Hacking into someone's email account is a criminal offence, even if no data is stolen",
      },
      {
        term: "Copyright, Designs and Patents Act 1988",
        definition:
          "UK law protecting creators' intellectual property from being copied, distributed or modified without permission",
        example:
          "Illegally downloading music, films or software without paying the creator",
      },
      {
        term: "Open Source Software",
        definition:
          "Software supplied with source code and a licence allowing users to inspect, modify and redistribute it under the licence terms",
        example:
          "A school can adapt an open-source program to its needs, but needs the skills to maintain changes and must follow the licence conditions",
      },
      {
        term: "Proprietary Software",
        definition:
          "Software controlled by its owner; source code is normally unavailable and use or modification is restricted by its licence. It may be free or paid",
        example:
          "A school might choose a supported commercial package for vendor support, but cannot normally adapt its source code",
      },
      {
        term: "Software Licence",
        definition:
          "A legal agreement that defines how software can be installed, used, copied and distributed; protects the creator's intellectual property and sets the terms of use",
        example:
          "A school buying a site licence for Microsoft Office that permits installation on every staff computer for one year",
      },
      {
        term: "Digital Divide",
        definition:
          "The gap between people who can access and effectively use digital technology and those who cannot",
        example:
          "Moving homework online offers flexible access, but can disadvantage pupils without devices, connectivity or digital skills",
      },
      {
        term: "Privacy",
        definition:
          "Control over access to personal information and how it is collected, used and shared",
        example:
          "Facial recognition may help identify offenders, but also records innocent people; consider security benefits, privacy, consent and how data is protected",
      },
      {
        term: "Cyberbullying",
        definition:
          "Using digital technology to harass, threaten or humiliate someone",
        example: "Sending abusive messages through social media or group chats",
      },
      {
        term: "Environmental Impact of Technology",
        definition:
          "The effects of manufacturing, using and disposing of technology on the environment",
        example:
          "Replacing school tablets uses raw materials and creates e-waste; keeping usable devices longer reduces waste, while newer efficient devices may use less power",
      },
      {
        term: "Sustainability",
        definition:
          "Designing and using technology in ways that minimise environmental harm",
        example:
          "Using renewable energy to power data centres, recycling old devices",
      },
    ],
    2.1: [
      {
        term: "Computational Thinking",
        definition:
          "Analysing a problem so that it can be solved in a logical way, using abstraction, decomposition and algorithmic thinking",
        example:
          "Planning a quiz app before coding: ignore the colours, split it into questions and scoring, then write the steps for each part",
      },
      {
        term: "Abstraction",
        definition:
          "Removing unnecessary detail to focus on the important information needed to solve a problem",
        example:
          "A London Underground map removes real geography and shows only stations and connections",
      },
      {
        term: "Decomposition",
        definition:
          "Breaking a large, complex problem down into smaller, more manageable sub-problems",
        example:
          "Building a game: break it into input handling, scoring, graphics, and collision detection",
      },
      {
        term: "Algorithmic Thinking",
        definition:
          "Creating a step-by-step set of instructions (an algorithm) to solve a problem",
        example:
          "Writing out the steps for making a cup of tea in the exact order a computer would follow",
      },
      {
        term: "Pseudocode",
        definition:
          "A way of writing out an algorithm in structured English that resembles code but is not tied to any programming language",
        example: 'IF age >= 18 THEN OUTPUT "You can vote"',
      },
      {
        term: "Flowchart",
        definition:
          "A diagram using standard shapes to represent the steps and decisions in an algorithm",
        example:
          "Oval = start/stop, rectangle = process, diamond = decision, parallelogram = input/output",
      },
      {
        term: "Structure Diagram",
        definition:
          "A hierarchical diagram that shows how a problem has been decomposed into sub-problems",
        example:
          "A top box labelled Quiz Program with sub-boxes for Ask Questions, Check Answers, Display Score",
      },
      {
        term: "Trace Table",
        definition:
          "A table used to manually track the values of variables as an algorithm is executed step by step",
        example:
          "Tracking the value of count through each iteration of a loop to check the output is correct",
      },
      {
        term: "Identifying Errors",
        definition:
          "Using trace tables, dry runs or testing to find logical or syntactical mistakes in an algorithm",
        example:
          "Tracing a sorting algorithm and spotting that two values are swapped in the wrong order",
      },
      {
        term: "Inputs, Processes, Outputs",
        definition:
          "Inputs provide data, processing transforms it, and outputs communicate the result",
        example: `Python: age = int(input("Age: ")); print(age + 1) inputs an age, calculates next year's age and outputs it`,
      },
      {
        term: "Linear Search",
        definition:
          "A searching algorithm that checks each item in a list one by one from start to end until the target is found or the list ends",
        example:
          "Searching for Zain in an unsorted register by reading every name from the top",
      },
      {
        term: "Binary Search",
        definition:
          "A searching algorithm that repeatedly halves a sorted list by comparing the target to the middle item",
        example:
          "Searching for 42 in a sorted list: check middle, discard the half that cannot contain 42, repeat",
      },
      {
        term: "Bubble Sort",
        definition:
          "A sorting algorithm that repeatedly compares adjacent pairs and swaps them if they are in the wrong order; passes continue until no swaps are needed",
        example:
          "List [5, 3, 8, 1]: first pass compares 5-3 (swap), 5-8 (no swap), 8-1 (swap)",
      },
      {
        term: "Merge Sort",
        definition:
          "A sorting algorithm that splits the list in half repeatedly until each sub-list has one item, then merges them back together in order",
        example:
          "[6,3,8,1] splits into [6,3] and [8,1], then [6],[3],[8],[1], then merges: [3,6],[1,8], then [1,3,6,8]",
      },
      {
        term: "Insertion Sort",
        definition:
          "A sorting algorithm that takes one item at a time and inserts it into the correct position within the already-sorted portion of the list",
        example:
          "Like sorting a hand of playing cards: pick up each card and slide it into the right place",
      },
    ],
    2.2: [
      {
        term: "Variable",
        definition:
          "A named storage location in memory whose value can change while the program runs",
        example:
          "score = 0; the value of score can be updated as the game progresses",
      },
      {
        term: "Constant",
        definition:
          "A named storage location whose value is set once and does not change during the program",
        example: "VAT_RATE = 0.20; the rate stays the same throughout",
      },
      {
        term: "Local Variable",
        definition:
          "A variable defined within a subprogram whose scope is that subprogram",
        example:
          "A function's total is local; a local constant such as TAX_RATE is also restricted to that function. In Python, uppercase names indicate constants by convention",
      },
      {
        term: "Global Variable",
        definition:
          "A variable defined at program scope and accessible from subprograms, subject to the language's scope rules",
        example:
          "A global constant such as MAX_SCORE can be read by functions. In Python, assigning a global variable inside a function requires a global declaration",
      },
      {
        term: "Assignment",
        definition:
          "Storing a value in a variable or constant using the assignment operator",
        example: 'name = "Ada" assigns the string to the variable name',
      },
      {
        term: "Sequence",
        definition:
          "Instructions executed one after another in the order they are written",
        example: "Line 1 runs, then line 2, then line 3",
      },
      {
        term: "Selection (IF/ELSE/ELIF)",
        definition:
          "A decision point where the program chooses which path to follow based on a condition",
        example: 'IF temperature > 30 THEN OUTPUT "Hot" ELSE OUTPUT "Cold"',
      },
      {
        term: "Iteration (Loops)",
        definition:
          "Repeating a block of code either a set number of times or until a condition is met",
        example:
          'FOR i = 1 TO 10 (count-controlled) or WHILE answer != "quit" (condition-controlled)',
      },
      {
        term: "Count-Controlled Loop (FOR)",
        definition: "A loop that repeats a fixed number of times",
        example: "for i in range(5): runs exactly 5 times",
      },
      {
        term: "Condition-Controlled Loop (WHILE / DO UNTIL)",
        definition:
          "A loop controlled by a condition: WHILE checks before the body and may run zero times; DO UNTIL checks after the body and runs at least once",
        example:
          "OCR: do ... until valid == true repeats until valid. Python: while not valid: repeats while valid is false",
      },
      {
        term: "Arithmetic Operators",
        definition: "Symbols used to perform mathematical calculations",
        example:
          "OCR notation: +, -, *, /, MOD (remainder), DIV (quotient), ^ (power). Python uses %, // and ** for the last three",
      },
      {
        term: "Comparison Operators",
        definition:
          "Symbols used to compare two values, returning True or False",
        example:
          "== (equal to), != (not equal to), < (less than), > (greater than), <=, >=",
      },
      {
        term: "Boolean Operators",
        definition: "Logical operators used to combine or invert conditions",
        example:
          "AND (both must be true), OR (at least one must be true), NOT (reverses the condition)",
      },
      {
        term: "Integer",
        definition: "A whole number data type with no decimal point",
        example: "42, -7, 0",
      },
      {
        term: "Real (Float)",
        definition: "A number data type that includes a decimal point",
        example: "3.14, -0.5, 99.99",
      },
      {
        term: "Boolean",
        definition: "A data type with only two possible values: True or False",
        example: "gameOver = True",
      },
      {
        term: "Character",
        definition: "A single letter, digit or symbol",
        example: "'A', '7', '!'",
      },
      {
        term: "String",
        definition:
          "A sequence of characters, typically enclosed in quotation marks",
        example: '"Hello World", "OCR J277"',
      },
      {
        term: "Casting",
        definition: "Converting a value from one data type to another",
        example:
          'int("42") converts the string "42" into the integer 42; str(100) converts 100 into "100"',
      },
      {
        term: "String Manipulation",
        definition:
          "Operations performed on strings such as extracting, finding length, joining or converting case",
        example:
          '"hello".upper() returns "HELLO"; "hello"[0] returns "h"; len("hello") returns 5',
      },
      {
        term: "String Concatenation",
        definition: "Joining two or more strings together",
        example: '"Hello " + "World" produces "Hello World"',
      },
      {
        term: "String Slicing",
        definition:
          "Extracting a portion (substring) of a string by specifying a start and end position",
        example:
          '"Hello World"[0:5] returns "Hello"; "Hello World"[6:] returns "World"',
      },
      {
        term: "File Handling",
        definition:
          "Opening a file, reading or writing its contents, then closing it so data can persist between runs",
        example:
          'Python: f = open("scores.txt", "w"); f.write("42"); f.close(). To read: f = open("scores.txt", "r"); score = f.read(); f.close()',
      },
      {
        term: "Record",
        definition:
          "A data structure that groups together related fields of different data types under one name",
        example:
          "A student record containing: name (string), age (integer), enrolled (Boolean)",
      },
      {
        term: "One-Dimensional (1D) Array",
        definition:
          "A fixed-length collection of values of the same type accessed by one index; Python lists can be used as an equivalent but can change length",
        example:
          'Python: names = ["Ali", "Ben", "Cara"]; names[0] is "Ali". Valid indices are 0 to len(names) - 1',
      },
      {
        term: "Two-Dimensional (2D) Array",
        definition:
          "A table-like collection accessed by row and column indices; Python can represent it as a list of lists",
        example:
          "With zero-based indexing, grid[2][3] accesses the third row and fourth column; pass grid to a function as an argument to process its rows",
      },
      {
        term: "Structured Query Language (SQL)",
        definition:
          "A language used to search for and retrieve data from a database",
        example: "SELECT name FROM students WHERE grade = 9;",
      },
      {
        term: "SQL SELECT",
        definition:
          "Retrieves specific fields from a database table, with optional conditions",
        example: "SELECT name, score FROM results WHERE score > 50;",
      },
      {
        term: "SQL FROM",
        definition:
          "Specifies which database table the SELECT statement should retrieve data from",
        example:
          "SELECT name FROM students; pulls the name column from the students table",
      },
      {
        term: "SQL WHERE",
        definition:
          "Filters the rows returned by a SELECT statement so only rows that match a condition are included",
        example:
          "SELECT name FROM students WHERE year = 11; returns only Year 11 students",
      },
      {
        term: "Sub Program",
        definition:
          "A named block of code that performs a specific task, called from the main program to reduce repetition",
        example:
          "Using a sub program called calculateAverage() whenever you need to find a mean",
      },
      {
        term: "Function",
        definition:
          "A subprogram that returns a value to its caller and may receive parameters",
        example:
          "Python: def first(items): return items[0] accepts an array/list; def copy(items): return items[:] returns a new list",
      },
      {
        term: "Procedure",
        definition:
          "A subprogram that performs a task without returning a useful value; it may receive parameters",
        example:
          'Python: def printWelcome(): print("Welcome") needs no parameters; printWelcome() calls it. Python returns None implicitly',
      },
      {
        term: "Parameter",
        definition:
          "A variable in a sub program definition that receives a value (argument) when the sub program is called",
        example: "In def greet(name):, name is the parameter",
      },
      {
        term: "Passing Data to Sub Programs",
        definition:
          "Sending values (arguments) into a function or procedure so it can use them",
        example:
          'greet("Hamid") passes the string "Hamid" as the argument for the parameter name',
      },
      {
        term: "Returning Values",
        definition:
          "A function sends a result back to the code that called it using a return statement",
        example:
          "return total sends the value of total back to the main program",
      },
      {
        term: "Random Number Generation",
        definition:
          "Using a built-in library to produce a random number within a specified range",
        example:
          "import random then random.randint(1, 6) simulates rolling a dice",
      },
    ],
    2.3: [
      {
        term: "Defensive Design",
        definition:
          "Writing programs that anticipate and handle potential misuse or errors gracefully",
        example:
          "Checking that a user enters a number, not text, before performing a calculation",
      },
      {
        term: "Anticipating Misuse",
        definition:
          "A defensive design consideration where the programmer thinks ahead about how a program might be used incorrectly or maliciously and writes safeguards against it",
        example:
          "Designing a banking app to refuse negative withdrawal amounts and to lock the account after suspicious activity",
      },
      {
        term: "Input Validation",
        definition:
          "Checking that data entered by a user meets specific rules before the program accepts it",
        example:
          "Range check: age must be between 0 and 120. Presence check: field cannot be left empty. Type check: must be a number",
      },
      {
        term: "Authentication",
        definition:
          "Verifying a user's identity before allowing access to a program or its features",
        example:
          "Asking for a username and password at login; locking the account after 3 failed attempts",
      },
      {
        term: "Maintainability",
        definition:
          "Writing code that other programmers (or your future self) can easily read, understand and update",
        example:
          "Using meaningful variable names, adding comments, consistent indentation, modular sub programs",
      },
      {
        term: "Comments",
        definition:
          "Notes written in the source code that are ignored by the translator, used to explain what the code does",
        example: "# This loop checks each item in the list",
      },
      {
        term: "Indentation",
        definition:
          "Using consistent spacing to show the structure of code, especially inside loops, selections and sub programs",
        example: "All lines inside a for loop are indented by the same amount",
      },
      {
        term: "Naming Conventions",
        definition:
          "Using clear, descriptive names for variables, constants and sub programs so their purpose is obvious",
        example:
          "total_score is clearer than ts; calculateAverage() is clearer than ca()",
      },
      {
        term: "Iterative Testing",
        definition:
          "Testing individual parts of the program during development, fixing issues as they arise",
        example:
          "Testing the login module before building the rest of the program",
      },
      {
        term: "Final (Terminal) Testing",
        definition:
          "Testing the complete program at the end of development to check it meets all requirements",
        example:
          "Running the finished quiz program through every scenario to confirm it works as a whole",
      },
      {
        term: "Syntax Error",
        definition:
          "An error that breaks a programming language's grammatical rules and prevents the affected code from being parsed",
        example:
          'print("Hello" has a missing closing bracket; printt("Hello") misspells the keyword print',
      },
      {
        term: "Logic Error",
        definition:
          "The code runs without crashing but produces an incorrect or unexpected result",
        example:
          "Using > instead of >= so the boundary value is excluded when it should be included",
      },
      {
        term: "Normal Test Data",
        definition:
          "Valid data that the program should handle correctly under typical use",
        example:
          "Entering the age 25 when the program expects an age between 0 and 120",
      },
      {
        term: "Boundary Test Data",
        definition:
          "Valid data at the very edge of an accepted range, testing that limits are handled correctly",
        example:
          "Entering 0 and 120 for an age range of 0 to 120; both should be accepted",
      },
      {
        term: "Invalid Test Data",
        definition:
          "Data of the correct data type that should still be rejected because it is outside the accepted rules",
        example:
          "Entering -5 or 200 when the program expects an age between 0 and 120",
      },
      {
        term: "Erroneous Test Data",
        definition:
          "Data of the wrong data type that the program should reject before any processing takes place",
        example:
          'Entering "abc" or a date when the program expects an integer age',
      },
      {
        term: "Test Plan",
        definition:
          "A set of tests giving the input, expected outcome and space to record the actual outcome and any action needed",
        example:
          'For integer ages 0 to 120: 25 accepted (normal); 0 and 120 accepted (boundaries); -1 rejected (invalid); "abc" rejected (erroneous)',
      },
    ],
    2.4: [
      {
        term: "AND Gate",
        definition:
          "A logic gate that outputs 1 (True) only when both inputs are 1",
        example:
          "Input A = 1, Input B = 1, Output = 1. Any other combination gives 0",
      },
      {
        term: "OR Gate",
        definition:
          "A logic gate that outputs 1 (True) when at least one input is 1",
        example: "Input A = 0, Input B = 1, Output = 1. Only 0,0 gives 0",
      },
      {
        term: "NOT Gate",
        definition:
          "A logic gate that inverts the input: 1 becomes 0, and 0 becomes 1",
        example: "Input = 1, Output = 0. Input = 0, Output = 1",
      },
      {
        term: "Truth Table",
        definition:
          "A table showing every possible combination of inputs and the resulting output for a logic gate or circuit",
        example:
          "A 2-input AND gate has 4 rows: (0,0)=0, (0,1)=0, (1,0)=0, (1,1)=1",
      },
      {
        term: "Logic Diagram / Logic Circuit",
        definition:
          "A diagram using standard gate symbols to represent a Boolean expression visually",
        example:
          "Drawing an AND gate feeding into a NOT gate to represent NOT (A AND B)",
      },
      {
        term: "Combining Logic Gates",
        definition:
          "Connecting multiple gates together to create more complex Boolean expressions",
        example:
          "(A OR B) AND (NOT C): an OR gate and a NOT gate both feeding into an AND gate",
      },
    ],
    2.5: [
      {
        term: "High-Level Language",
        definition:
          "A language with human-readable constructs that must be translated for execution",
        example:
          "Python is easier to read and portable across systems with a suitable implementation; low-level languages offer closer hardware control",
      },
      {
        term: "Low-Level Language",
        definition:
          "A language closely tied to a processor's instructions and hardware",
        example:
          "Assembly can offer direct hardware control and efficient resource use, but is harder to develop and less portable than high-level code",
      },
      {
        term: "Machine Code",
        definition:
          "Binary instructions (0s and 1s) that the CPU can execute directly without translation",
        example:
          "10110000 01100001: the only language the processor actually understands",
      },
      {
        term: "Translator",
        definition:
          "Software that converts source code into machine code so the CPU can run it",
        example: "Compilers and interpreters are both types of translator",
      },
      {
        term: "Compiler",
        definition:
          "A translator that translates a whole program before execution, commonly producing an executable",
        example:
          "A compiled executable can run without the compiler and is often fast; after changing source code, it must be compiled again",
      },
      {
        term: "Interpreter",
        definition:
          "A translator that executes a program as it translates instructions, rather than first producing a standalone executable",
        example:
          "An interpreter supports quick testing and debugging, but translation is needed when running the source again and execution may be slower",
      },
      {
        term: "Integrated Development Environment (IDE)",
        definition:
          "A software application that provides a complete set of tools for writing, testing and debugging code in one place",
        example: "Visual Studio Code, PyCharm, IDLE, Thonny",
      },
      {
        term: "Code Editor",
        definition:
          "The IDE feature that provides a text area for writing code, often with syntax highlighting and auto-complete",
        example:
          "Keywords like def and for are colour-coded; bracket matching highlights pairs",
      },
      {
        term: "Error Diagnostics",
        definition:
          "IDE tools that identify and describe errors in the code, showing line numbers and error messages",
        example:
          "A red underline on line 12 with the message IndentationError: unexpected indent",
      },
      {
        term: "Run-Time Environment",
        definition:
          "The IDE feature that allows the programmer to execute their code and see the output within the same application",
        example:
          "Clicking Run in Thonny and seeing the output appear in the console below",
      },
      {
        term: "Debugging Tools",
        definition:
          "IDE features that help locate and fix errors, such as breakpoints, stepping through code, and variable watches",
        example:
          "Setting a breakpoint on line 20 so the program pauses there, then inspecting the current value of each variable",
      },
    ],
  },
  li = {
    1.1: "Systems architecture",
    1.2: "Memory and storage",
    1.3: "Networks and protocols",
    1.4: "Network security",
    1.5: "Systems software",
    1.6: "Ethical, legal and environmental impacts",
    2.1: "Algorithms",
    2.2: "Programming fundamentals",
    2.3: "Producing robust programs",
    2.4: "Boolean logic",
    2.5: "Languages and IDEs",
  },
  qm = 24,
  Xm = 13,
  Jm = 3,
  eh = 6,
  Fd = /\s*\(([^)]*)\)\s*/g;
function Xc(s) {
  return s.toUpperCase().replace(/[^A-Z0-9]/g, "");
}
function th(s) {
  const u = s.replace(Fd, " ").replace(/\s+/g, " ").trim();
  if (/[/,]/.test(u)) return null;
  const l = u
      .split(" ")
      .map((y) =>
        [...y].flatMap((S) =>
          /[A-Za-z0-9]/.test(S)
            ? [{ kind: "letter", char: S.toUpperCase() }]
            : S === "-"
              ? [{ kind: "fixed", char: S }]
              : [],
        ),
      ),
    d = l.map((y) => y.filter((S) => S.kind === "letter").length),
    p = d.reduce((y, S) => y + S, 0);
  return p < Jm || p > qm || d.some((y) => y === 0 || y > Xm)
    ? null
    : { shown: u, words: l };
}
const Jc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
function nh(s) {
  const u = s.match(/[A-Za-z0-9]+/g) ?? [],
    l = new Set(
      u.filter(
        (p) => (p.match(/[A-Z]/g) ?? []).length >= 2 || /^\d[A-Z]$/.test(p),
      ),
    ),
    d = new Set(
      u.filter((p) => p.length >= 4 && !l.has(p)).map((p) => p.toLowerCase()),
    );
  return [
    ...[...l].map((p) => new RegExp(`\\b${Jc(p)}s?\\b`, "gi")),
    ...[...d].map((p) => new RegExp(`\\b${Jc(p)}\\w*`, "gi")),
  ];
}
function ed(s, u) {
  let l = u.trim().replace(/[.\s]+$/, "");
  for (const d of nh(s)) l = l.replace(d, "…");
  return l;
}
const rh = /\(([A-Za-z0-9-]{2,7})\)(.*)$/;
function oh(s) {
  const u = s.match(rh);
  return !u || (u[1].match(/[A-Z]/g) ?? []).length < 1
    ? []
    : [Xc(u[1]) + Xc(u[2].replace(Fd, " "))];
}
function ih(s) {
  const u = th(s.term);
  if (!u) return null;
  const l = u.words
      .flat()
      .filter((p) => p.kind === "letter")
      .map((p) => p.char)
      .join(""),
    d = oh(s.term);
  return {
    id: `${s.deck}/${s.term}`,
    deck: s.deck,
    term: s.term,
    shown: u.shown,
    words: u.words,
    answer: l,
    accept: [...new Set(d)].filter((p) => p !== l && p.length > 0),
    definition: ed(s.term, s.definition),
    example: s.example ? ed(s.term, s.example) : null,
    meaning: s.definition.trim(),
  };
}
function sh(s) {
  const u = new Set();
  return s.flatMap((l) => {
    const d = ih(l);
    return !d || u.has(d.answer) ? [] : (u.add(d.answer), [d]);
  });
}
const la = Object.entries(Ud).flatMap(([s, u]) =>
  sh(u.map((l) => ({ ...l, deck: s }))),
);
[
  la.filter((s) => s.deck.startsWith("1.")),
  la.filter((s) => s.deck.startsWith("2.")),
  ...Object.keys(li)
    .map((s) => ({
      id: s,
      title: `${s} ${li[s]}`,
      words: la.filter((u) => u.deck === s),
    }))
    .filter((s) => s.words.length >= eh),
];
function ah(s) {
  let u = 2166136261;
  for (const l of s.id)
    ((u ^= l.charCodeAt(0)), (u = Math.imul(u, 16777619) >>> 0));
  return `w${u.toString(36)}`;
}
const lh = 3,
  uh = 13,
  Wd = /^(.*?)\s*\(([A-Z]{3,6})\)\s*$/;
function ch(s) {
  if (/^SQL\s/.test(s)) return null;
  const u = s.match(Wd);
  if (u) return { answer: u[2], enumeration: String(u[2].length) };
  if (/[()\d]/.test(s) || s.includes("-")) return null;
  const l = s.match(/[A-Za-z]+/g) ?? [],
    d = l.join("").toUpperCase();
  return d.length < lh || d.length > uh
    ? null
    : { answer: d, enumeration: l.map((p) => p.length).join(",") };
}
const ua = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"),
  dh = new Set(["the", "and", "for", "of", "to", "in", "on", "a", "an", "or"]);
function $d(s, u) {
  const l = s.match(Wd),
    d = (l ? l[1] : s).match(/[A-Za-z]+/g) ?? [],
    p = d.filter((k) => /^[A-Z]{2,}$/.test(k)),
    y = l ? 4 : 3,
    S = new Set(
      d
        .filter(
          (k) => k.length >= y && !p.includes(k) && !dh.has(k.toLowerCase()),
        )
        .map((k) => k.toLowerCase().replace(new RegExp("(?<=\\w{3})s$"), "")),
    );
  let j = u.trim().replace(/[.\s]+$/, "");
  d.length > 1 &&
    (j = j.replace(
      new RegExp(`\\b${d.map(ua).join("[\\s-]+")}\\w*`, "gi"),
      "…",
    ));
  for (const k of [...(l ? [l[2]] : []), ...p])
    j = j.replace(new RegExp(`\\b${ua(k)}s?\\b`, "gi"), "…");
  for (const k of S) j = j.replace(new RegExp(`\\b${ua(k)}\\w*`, "gi"), "…");
  return j.replace(/…(?:[\s-]+…)+/g, "…");
}
function fh(s, u, l) {
  return `${$d(s, u)} (${l})`;
}
const ca = Object.entries(Ud).flatMap(([s, u]) => {
    const l = new Set();
    return u.flatMap((d) => {
      const p = ch(d.term);
      return !p || l.has(p.answer)
        ? []
        : (l.add(p.answer),
          [
            {
              id: `${s}/${p.answer}`,
              topic: s,
              term: d.term,
              ...p,
              clue: fh(d.term, d.definition, p.enumeration),
              definition: d.definition.trim(),
              example: d.example?.trim() ? $d(d.term, d.example) : null,
              ref: ah({ id: `${s}/${d.term}` }),
            },
          ]);
    });
  }),
  ph = 8;
[
  ca.filter((s) => s.topic.startsWith("1.")),
  ca.filter((s) => s.topic.startsWith("2.")),
  ...Object.keys(li)
    .map((s) => ({
      id: s,
      title: `${s} ${li[s]}`,
      words: ca.filter((u) => u.topic === s),
    }))
    .filter((s) => s.words.length >= ph),
];
const mh = 15e3;
function Bd(s) {
  return !!(s && s.live === !0);
}
function hh(s, u = {}) {
  const l = new URL("/api/lobby", s);
  for (const [S, j] of Object.entries(u)) l.searchParams.set(S, j);
  const d = l.toString(),
    p = (S, j) => {
      const k = new URL(d);
      return (k.searchParams.set(S, j), k.toString());
    };
  async function y(S, j = {}) {
    const k = { accept: "application/json" };
    j.body && (k["content-type"] = "application/json");
    try {
      const F = await fetch(S, {
          cache: "no-store",
          credentials: "include",
          ...j,
          headers: k,
        }),
        T = await F.json().catch(() => null);
      return !F.ok || !T?.ok
        ? {
            ok: !1,
            status: F.status,
            message: T?.message ?? "The lobby could not be reached.",
          }
        : { ok: !0, data: T.data ?? null };
    } catch {
      return { ok: !1, status: 0, message: "The lobby could not be reached." };
    }
  }
  return {
    overview: () => y(d),
    takeover: () => y(p("view", "takeover")),
    get: (S, j) => {
      const k = new URL(p("id", S));
      return (j && k.searchParams.set("version", String(j)), y(k.toString()));
    },
    send: (S) =>
      y(d, {
        method: "POST",
        body: JSON.stringify(S),
        keepalive: S.action === "leave",
      }),
    live: (S, j) => {
      const k = new URL(p("view", "live"));
      return (
        S && k.searchParams.set("classId", S),
        j && j !== "crossword" && k.searchParams.set("game", j),
        y(k.toString())
      );
    },
    liveStatus: (S, j) => {
      const k = new URL(p("view", "live-status"));
      return (
        S && k.searchParams.set("classId", S),
        j && j !== "crossword" && k.searchParams.set("game", j),
        y(k.toString())
      );
    },
    liveStart: (S, j, k) =>
      y(d, {
        method: "POST",
        body: JSON.stringify({
          action: "live-start",
          classId: S,
          set: j,
          ...(k ? { pupils: k } : {}),
        }),
      }),
    liveRecord: (S) =>
      y(d, {
        method: "POST",
        body: JSON.stringify({ action: "live-record", receipt: S }),
        keepalive: !0,
      }),
    liveBoard: () => y(p("view", "live-board")),
    liveEnd: (S) =>
      y(d, {
        method: "POST",
        body: JSON.stringify({ action: "live-end", classId: S }),
      }),
  };
}
const Hd = "back",
  gh = "data-room-held";
function td() {
  return typeof document < "u" && document.documentElement.hasAttribute(gh);
}
const yh = 1e4,
  vh = "Your teacher has started a game. Saving your work...";
function wh(s, u, l = window.location.hostname) {
  const d = new URL(Gr(l, "https://exams.comp.school"));
  return (
    (d.pathname = `${d.pathname.replace(/\/$/, "")}/games/lobby`),
    (d.search = ""),
    d.searchParams.set("id", s),
    u && d.searchParams.set(Hd, u),
    d.toString()
  );
}
function xh(s, u = window.location) {
  return (
    /\/games\/lobby\/?$/.test(u.pathname) &&
    new URLSearchParams(u.search).get("id") === s
  );
}
function kh(s, u = window.location.hostname) {
  const l = new URL(Gr(u, "https://exams.comp.school"));
  return (
    (l.pathname = `${l.pathname.replace(/\/$/, "")}/games/crossword`),
    (l.search = ""),
    s && l.searchParams.set(Hd, s),
    l.toString()
  );
}
function Sh(s = window.location) {
  return /\/games\/crossword\/?$/.test(s.pathname);
}
function nd(s, u = window.location) {
  return Bd(s) ? Sh(u) : xh(s.id, u);
}
function bh(s, u) {
  return Bd(s) ? kh(u) : wh(s.id, u);
}
function Eh(s) {
  return s?.role === "student" && s.aiAccess === !1;
}
function jh(s) {
  return (
    s?.role === "student" && !Eh(s) && (s.courses ?? ["j277"]).includes("j277")
  );
}
const Ch = {
  position: "fixed",
  insetInline: "1rem",
  top: "1rem",
  zIndex: 2147483e3,
  maxWidth: "32rem",
  marginInline: "auto",
  padding: "1rem 1.25rem",
  borderRadius: "0.75rem",
  border: "2px solid #0f766e",
  background: "#ffffff",
  color: "#0f172a",
  boxShadow: "0 10px 30px rgba(15, 23, 42, 0.25)",
  fontSize: "1.125rem",
  fontWeight: 600,
  lineHeight: 1.4,
  textAlign: "center",
};
function Ah({ user: s }) {
  const u = jh(s),
    [l, d] = I.useState(!1);
  return (
    I.useEffect(() => {
      if (!u) return;
      const p = hh(fn(window.location.hostname));
      let y = !1,
        S = !1,
        j = null;
      async function k() {
        if (!(S || y || j !== null || document.visibilityState === "hidden")) {
          S = !0;
          try {
            const D = await p.takeover();
            if (y || !D.ok || !D.data || nd(D.data) || td()) return;
            (d(!0), (j = window.setTimeout(() => void F(), yh)));
          } finally {
            S = !1;
          }
        }
      }
      async function F() {
        await _a();
        const D = await p.takeover();
        if (!y) {
          if (!D.ok || !D.data || nd(D.data) || td()) {
            ((j = null), d(!1));
            return;
          }
          window.location.assign(bh(D.data, window.location.href));
        }
      }
      k();
      const T = window.setInterval(() => void k(), mh),
        V = () => void k();
      return (
        document.addEventListener("visibilitychange", V),
        () => {
          ((y = !0),
            window.clearInterval(T),
            j !== null && window.clearTimeout(j),
            document.removeEventListener("visibilitychange", V));
        }
      );
    }, [u]),
    !u || !l
      ? null
      : a.jsx("div", {
          role: "status",
          "aria-live": "assertive",
          style: Ch,
          "data-lobby-takeover-notice": !0,
          children: vh,
        })
  );
}
const Ph = 5e3,
  rd = 1e4,
  da = "Room control could not be reached.";
function zh(s) {
  return typeof s == "object" && s !== null && typeof s.live == "boolean";
}
function _h(s, u = {}) {
  const l = (y = {}) => {
    const S = new URL("/api/room-control", s);
    for (const [j, k] of Object.entries({ ...u, ...y }))
      S.searchParams.set(j, k);
    return S.toString();
  };
  async function d(y, S) {
    const j = { accept: "application/json" };
    S !== void 0 && (j["content-type"] = "application/json");
    try {
      const k = await fetch(y, {
          cache: "no-store",
          credentials: "include",
          headers: j,
          ...(S === void 0 ? {} : { method: "POST", body: JSON.stringify(S) }),
        }),
        F = await k.json().catch(() => null);
      return !k.ok || !F?.ok
        ? {
            ok: !1,
            status: k.status,
            message: F?.message ?? da,
            ...(F?.current ? { current: F.current } : {}),
          }
        : { ok: !0, data: F.data ?? null };
    } catch {
      return { ok: !1, status: 0, message: da };
    }
  }
  async function p(y, S) {
    const j = await d(y, S);
    return j.ok
      ? zh(j.data)
        ? { ok: !0, data: j.data }
        : { ok: !1, status: 0, message: da }
      : j;
  }
  return {
    roster: (y) => d(l({ roster: y })),
    state: (y) => d(l({ class: y })),
    presence: (y) => d(l({ presence: y })),
    send: (y, S, j) => d(l(), { class: y, action: S, edits: j }),
    directive: () => p(l({ me: "1" })),
    complete: (y) => p(l(), { complete: y }),
    playlists: () => d(l({ playlists: "1" })),
    savePlaylist: (y) => d(l(), { playlist: y }),
    deletePlaylist: (y) => d(l(), { deletePlaylist: y }),
  };
}
const $a = "roomStep",
  Th = "roomStepKind",
  Rh = "roomStepCount",
  od = "comp-school:room-step-completed",
  Lh = {
    "matching-terms": {
      label: "Matching terms",
      cohorts: ["gcse", "ks3"],
      needsTopic: !0,
      completes: !0,
    },
    "guess-the-term": {
      label: "Guess the term",
      cohorts: ["gcse", "ks3"],
      needsTopic: !0,
      completes: !0,
    },
    flashcards: {
      label: "Flashcards",
      cohorts: ["gcse", "ks3"],
      needsTopic: !0,
      completes: !0,
    },
    "coding-challenge": {
      label: "Coding challenge",
      cohorts: ["gcse", "ks3"],
      needsTopic: !1,
      completes: !0,
    },
    "past-paper-questions": {
      label: "Past paper questions",
      cohorts: ["gcse"],
      needsTopic: !0,
      completes: !0,
    },
    "past-paper": {
      label: "Past paper",
      cohorts: ["gcse"],
      needsTopic: !1,
      completes: !0,
    },
    "tell-me-why": {
      label: "Tell me why",
      cohorts: ["gcse"],
      needsTopic: !0,
      completes: !0,
    },
    "live-game": {
      label: "Live class game",
      cohorts: ["gcse"],
      needsTopic: !1,
      completes: !1,
    },
    "topic-game": {
      label: "Topic game",
      cohorts: ["gcse", "ks3"],
      needsTopic: !0,
      completes: !0,
    },
    "crit-wall": {
      label: "Crit wall",
      cohorts: ["gcse"],
      needsTopic: !0,
      completes: !0,
    },
  },
  id = "https://exams.comp.school",
  Cn = "https://recall.comp.school",
  Mh = "https://code.comp.school",
  Oh = "set",
  Nh = ["crossword", "code-climb"],
  sd = /^[12]\.\d$/,
  fa = /^[12]\.\d\.\d{1,2}$/,
  Ih = /^J277-0([12])-[A-Za-z0-9-]+$/,
  Dh = {
    io: "io",
    if: "if",
    for: "for",
    while: "while",
    fn: "functions",
    scratch: "scratch",
  },
  Uh = /^(io|if|for|while|fn|scratch)-[a-z0-9-]+$/;
function Fh(s) {
  return s.split(".").slice(0, 2).join(".");
}
function An(s, u, l) {
  const d = new URL(s);
  (d.searchParams.set("paper", u.charAt(0)),
    d.searchParams.set("topic", Fh(u)),
    d.searchParams.set("sub", u));
  for (const [p, y] of Object.entries(l)) d.searchParams.set(p, y);
  return d;
}
function Wh(s) {
  return `topic-${s.replace(/\./g, "-")}`;
}
function $h(s) {
  const u = s.topic ?? "",
    l = sd.test(u) || fa.test(u);
  switch (s.kind) {
    case "matching-terms":
      return l ? An(`${Cn}/`, u, { activity: "matching" }) : null;
    case "guess-the-term":
      return l ? An(`${Cn}/`, u, { activity: "guess" }) : null;
    case "crit-wall":
      return l ? An(`${Cn}/`, u, { activity: "crit-wall" }) : null;
    case "flashcards":
      return l ? An(`${Cn}/`, u, { activity: "flashcards" }) : null;
    case "tell-me-why":
      return l ? An(`${Cn}/`, u, { activity: "tell-me-why" }) : null;
    case "topic-game":
      return fa.test(u) && s.target
        ? An(`${Cn}/`, u, { activity: "game", game: s.target })
        : null;
    case "past-paper-questions":
      return fa.test(u)
        ? An(`${Cn}/`, u, {
            target: Wh(u),
            revision: "0",
            ...(s.count && s.count > 0 ? { [Rh]: String(s.count) } : {}),
          })
        : null;
    case "past-paper": {
      const d = s.target?.match(Ih)?.[1];
      if (!d || !s.target) return null;
      const p = new URL(`${id}/`);
      return (
        p.searchParams.set("paper", d),
        p.searchParams.set("target", s.target),
        p
      );
    }
    case "coding-challenge": {
      const d = s.target?.match(Uh)?.[1],
        p = d ? Dh[d] : void 0;
      if (!p || !s.target) return null;
      const y = new URL(`${Mh}/essentials/${p}`);
      return (y.searchParams.set("challenge", s.target), y);
    }
    case "live-game": {
      if (!Nh.includes(s.target ?? "")) return null;
      const d = new URL(`${id}/games/${s.target}`);
      return (
        s.target === "crossword" && sd.test(u) && d.searchParams.set(Oh, u),
        d
      );
    }
  }
}
function Vd(s, u) {
  const l = $h(s);
  if (!l) return u;
  (l.searchParams.set($a, s.id), l.searchParams.set(Th, s.kind));
  let d;
  try {
    d = new URL(u).hostname;
  } catch {
    return u;
  }
  return Gr(d, l.toString());
}
const Bh = "Your teacher is moving you. Saving your work...",
  Hh = "You have finished. Retake a step or choose something else.",
  Vh = "Next step...",
  Kh = 6e4,
  vt = "data-room-held",
  pa = "comp-school-room-control:finished-seen";
function Gh(s) {
  return s?.role === "student" && (s.courses ?? ["j277"]).includes("j277");
}
function Pn(s) {
  return !!(s && s.live && !s.free);
}
function Qh(s) {
  return `Step ${s.index + 1} of ${s.total}`;
}
function Zh(s) {
  const u = Lh[s.kind]?.label ?? "Activity";
  return s.topic ? `${u} ${s.topic}` : u;
}
function ma(s, u, l = Vd) {
  const d = new URL(l(s, u));
  return (d.searchParams.set($a, s.id), d.toString());
}
function ha(s, u, l, d = null) {
  const p = new URL(l);
  return p.origin !== new URL(u).origin
    ? !1
    : p.searchParams.get($a) === s.id
      ? !0
      : d?.stepId === s.id && d.pathname === p.pathname;
}
const Yh = `
html[${vt}] [data-session-sidebar],
html[${vt}] [data-session-sidebar-toggle],
html[${vt}] [data-session-sidebar-rail-toggle],
html[${vt}] [data-session-sidebar-search],
html[${vt}] [data-session-sidebar-search-open],
html[${vt}] [data-topic-breadcrumb],
html[${vt}] nav[aria-label="Breadcrumb"],
html[${vt}] [data-phone-bar-back],
html[${vt}] [data-launcher-phone-bar] { display: none !important; }
html[${vt}] [data-session-sidebar-layout] { padding-left: 0 !important; }
`,
  qh = {
    display: "flex",
    flexWrap: "wrap",
    alignItems: "baseline",
    justifyContent: "center",
    gap: "0.25rem 0.75rem",
    padding: "0.5rem 1rem",
    background: "#0f172a",
    color: "#f8fafc",
    fontSize: "1rem",
    lineHeight: 1.4,
    textAlign: "center",
  },
  Ta = {
    position: "fixed",
    insetInline: "1rem",
    top: "1rem",
    zIndex: 2147483e3,
    maxWidth: "32rem",
    marginInline: "auto",
    padding: "1rem 1.25rem",
    borderRadius: "0.75rem",
    border: "2px solid #0f766e",
    background: "#ffffff",
    color: "#0f172a",
    boxShadow: "0 10px 30px rgba(15, 23, 42, 0.25)",
    fontSize: "1.125rem",
    fontWeight: 600,
    lineHeight: 1.4,
    textAlign: "center",
  },
  Xh = {
    ...Ta,
    cursor: "pointer",
    font: "inherit",
    fontSize: "1.125rem",
    fontWeight: 600,
  };
function Jh(s) {
  try {
    return window.localStorage.getItem(s) === "1";
  } catch {
    return !1;
  }
}
function ad(s, u) {
  try {
    u ? window.localStorage.setItem(s, "1") : window.localStorage.removeItem(s);
  } catch {}
}
function eg({ user: s, transport: u, navigate: l, stepUrl: d = Vd }) {
  const p = Gh(s),
    [y, S] = I.useState(null),
    [j, k] = I.useState(!1),
    [F, T] = I.useState(!1),
    [V, D] = I.useState(!1),
    q = I.useRef(u),
    X = I.useRef(l);
  ((q.current = u), (X.current = l));
  const O = I.useRef(d);
  ((O.current = d),
    I.useEffect(() => {
      if (!p) return;
      const K = fn(window.location.hostname),
        ae = q.current ?? _h(K),
        be = (_) => (X.current ? X.current(_) : window.location.assign(_));
      let ie = !1,
        Ae = !1,
        B = null,
        ee = !1,
        te = null,
        ne = !1,
        le = 0,
        se = null;
      function Ee(_) {
        ((te = _),
          S(_),
          _.live && _.free && _.finished
            ? Jh(pa) || (ad(pa, !0), T(!0))
            : (ad(pa, !1), T(!1)));
      }
      function he() {
        (B !== null && window.clearTimeout(B), (B = null), k(!1));
      }
      async function je() {
        if (!(Ae || ie || ee || document.visibilityState === "hidden")) {
          Ae = !0;
          try {
            const _ = await ae.directive();
            if (ie) return;
            if (!_.ok) {
              Date.now() - le >= Kh && (he(), Ee({ live: !1 }));
              return;
            }
            le = Date.now();
            const g = te,
              E = !ne;
            ne = !0;
            const Z = _.data;
            if ((Ee(Z), !Pn(Z))) {
              he();
              return;
            }
            const re = ma(Z.step, K, O.current);
            if (ha(Z.step, re, window.location.href, se)) {
              (se?.stepId !== Z.step.id &&
                (se = {
                  stepId: Z.step.id,
                  pathname: window.location.pathname,
                }),
                he());
              return;
            }
            if (B !== null) return;
            if (!(!E && !(Pn(g) && g.step.id === Z.step.id))) {
              Fe();
              return;
            }
            (k(!0), (B = window.setTimeout(() => void Fe(), rd)));
          } finally {
            Ae = !1;
          }
        }
      }
      async function Fe() {
        ((ee = !0), await _a());
        const _ = await ae.directive();
        if (ie) return;
        const g = _.ok ? _.data : te;
        _.ok && ((le = Date.now()), Ee(_.data));
        const E = Pn(g) ? ma(g.step, K, O.current) : null;
        if (!Pn(g) || !E || ha(g.step, E, window.location.href, se)) {
          ((ee = !1), (B = null), k(!1));
          return;
        }
        be(E);
      }
      async function Le(_) {
        const g = _.detail;
        if (
          ie ||
          ee ||
          !g ||
          typeof g != "object" ||
          typeof g.live != "boolean" ||
          ((le = Date.now()), (ne = !0), he(), Ee(g), !Pn(g))
        )
          return;
        const E = ma(g.step, K, O.current);
        if (ha(g.step, E, window.location.href, se)) {
          se?.stepId !== g.step.id &&
            (se = { stepId: g.step.id, pathname: window.location.pathname });
          return;
        }
        ((ee = !0), D(!0), await _a(), !ie && be(E));
      }
      const ye = (_) => void Le(_);
      (window.addEventListener(od, ye), je());
      const R = window.setInterval(() => void je(), Ph),
        H = () => void je();
      return (
        document.addEventListener("visibilitychange", H),
        window.addEventListener("popstate", H),
        () => {
          ((ie = !0),
            window.clearInterval(R),
            B !== null && window.clearTimeout(B),
            document.removeEventListener("visibilitychange", H),
            window.removeEventListener("popstate", H),
            window.removeEventListener(od, ye));
        }
      );
    }, [p]));
  const $ = p && Pn(y);
  return (
    I.useEffect(() => {
      if ($)
        return (
          document.documentElement.setAttribute(vt, ""),
          () => document.documentElement.removeAttribute(vt)
        );
    }, [$]),
    I.useEffect(() => {
      if (!F) return;
      const K = window.setTimeout(() => T(!1), rd);
      return () => window.clearTimeout(K);
    }, [F]),
    p
      ? a.jsxs(a.Fragment, {
          children: [
            $ && Pn(y)
              ? a.jsxs(a.Fragment, {
                  children: [
                    a.jsx("style", { children: Yh }),
                    a.jsxs("div", {
                      style: qh,
                      "data-room-step-bar": "",
                      children: [
                        a.jsx("strong", { children: Qh(y) }),
                        a.jsx("span", { children: Zh(y.step) }),
                      ],
                    }),
                  ],
                })
              : null,
            j
              ? a.jsx("div", {
                  role: "status",
                  "aria-live": "assertive",
                  style: Ta,
                  "data-room-move-notice": "",
                  children: Bh,
                })
              : null,
            V && !j
              ? a.jsx("div", {
                  role: "status",
                  "aria-live": "polite",
                  style: Ta,
                  "data-room-next-step": "",
                  children: Vh,
                })
              : null,
            F && !j && !V
              ? a.jsx("button", {
                  type: "button",
                  role: "status",
                  "aria-live": "polite",
                  style: Xh,
                  onClick: () => T(!1),
                  "data-room-finished-notice": "",
                  children: Hh,
                })
              : null,
          ],
        })
      : null
  );
}
const Ra = "cs_reduce_motion",
  La = "data-reduce-motion",
  tg = 3600 * 24 * 365;
function ng(s) {
  return s === "comp.school" || s.endsWith(".comp.school")
    ? "; Domain=.comp.school"
    : "";
}
function rg(s = typeof document > "u" ? "" : document.cookie) {
  return s.split(";").some((u) => u.trim() === `${Ra}=1`);
}
function og(s, u) {
  const l = ng(u);
  return s
    ? `${Ra}=1; Path=/; Max-Age=${tg}; SameSite=Lax${l}`
    : `${Ra}=; Path=/; Max-Age=0; SameSite=Lax${l}`;
}
function Kd(s) {
  typeof document > "u" ||
    (s
      ? document.documentElement.setAttribute(La, "true")
      : document.documentElement.removeAttribute(La));
}
function ig(s) {
  typeof document > "u" ||
    ((document.cookie = og(s, window.location.hostname)), Kd(s));
}
function sg() {
  return (
    typeof document < "u" &&
    document.documentElement.getAttribute(La) === "true"
  );
}
Kd(rg());
const Gd = "Accessibility";
function Qd() {
  return a.jsxs("svg", {
    "aria-hidden": "true",
    fill: "none",
    height: "16",
    stroke: "currentColor",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    strokeWidth: "1.8",
    viewBox: "0 0 24 24",
    width: "16",
    children: [
      a.jsx("circle", { cx: "12", cy: "5", r: "1" }),
      a.jsx("path", { d: "m9 20 3-6 3 6M6 8l6 2 6-2M12 10v4" }),
    ],
  });
}
function ag({ style: s, tone: u = "light" }) {
  const [l, d] = I.useState(sg),
    p = u === "dark",
    y = p ? "rgb(var(--slate-200, 226 232 240))" : "#334155",
    S = l
      ? p
        ? "rgb(var(--slate-50, 248 250 252))"
        : "#0f172a"
      : p
        ? "rgb(var(--slate-600, 71 85 105))"
        : "#cbd5e1",
    j = l && p ? "rgb(var(--slate-900, 15 23 42))" : "#ffffff";
  return a.jsxs("button", {
    "aria-checked": l,
    "data-profile-reduce-motion": !0,
    onClick: () => {
      (ig(!l), d(!l));
    },
    role: "switch",
    style: {
      alignItems: "center",
      background: "transparent",
      border: 0,
      borderRadius: "0.5rem",
      color: y,
      cursor: "pointer",
      display: "flex",
      fontFamily: "inherit",
      fontSize: "0.875rem",
      fontWeight: 650,
      gap: "0.5rem",
      minHeight: "2.25rem",
      padding: "0.5rem",
      textAlign: "left",
      width: "100%",
      ...s,
    },
    type: "button",
    children: [
      a.jsxs("svg", {
        "aria-hidden": "true",
        fill: "none",
        height: "16",
        viewBox: "0 0 24 24",
        width: "16",
        children: [
          a.jsx("path", {
            d: "M3 12h4M17 12h4M12 3v4M12 17v4",
            stroke: "currentColor",
            strokeLinecap: "round",
            strokeWidth: "1.8",
          }),
          a.jsx("circle", {
            cx: "12",
            cy: "12",
            r: "3",
            stroke: "currentColor",
            strokeWidth: "1.8",
          }),
        ],
      }),
      a.jsx("span", { style: { flex: 1 }, children: "Reduce motion" }),
      a.jsx("span", {
        "aria-hidden": "true",
        style: {
          background: S,
          borderRadius: "9999px",
          display: "inline-flex",
          height: "1.125rem",
          padding: "0.125rem",
          transition: "background 120ms",
          width: "2rem",
        },
        children: a.jsx("span", {
          style: {
            background: j,
            borderRadius: "9999px",
            height: "0.875rem",
            transform: l ? "translateX(0.875rem)" : void 0,
            transition: "transform 120ms",
            width: "0.875rem",
          },
        }),
      }),
    ],
  });
}
function lg({ dialogRef: s, tone: u = "dark" }) {
  const l = I.useId(),
    d = u === "dark",
    p = d ? "rgb(var(--slate-50, 248 250 252))" : "#0f172a",
    y = d ? "rgb(var(--slate-700, 51 65 85))" : "#e2e8f0",
    S = d ? "rgb(var(--slate-900, 15 23 42))" : "#ffffff",
    j = d ? "rgb(var(--slate-800, 30 41 59))" : "#f1f5f9";
  return a.jsxs("dialog", {
    "aria-labelledby": l,
    "data-comp-school-accessibility-dialog": !0,
    onClick: (k) => {
      k.target === k.currentTarget && k.currentTarget.close();
    },
    ref: s,
    style: {
      background: S,
      border: `1px solid ${y}`,
      borderRadius: "1rem",
      boxShadow: "0 25px 50px -12px rgb(var(--slate-950, 2 6 23) / 0.5)",
      color: p,
      fontFamily: "inherit",
      margin: "auto",
      maxWidth: "min(92vw, 24rem)",
      padding: 0,
      textAlign: "left",
      width: "100%",
    },
    children: [
      a.jsx("style", {
        children:
          "[data-comp-school-accessibility-dialog]::backdrop{background:rgb(var(--slate-950, 2 6 23) / 0.7)}",
      }),
      a.jsxs("div", {
        style: {
          display: "flex",
          flexDirection: "column",
          gap: "0.875rem",
          padding: "1.25rem",
        },
        children: [
          a.jsxs("h2", {
            id: l,
            style: {
              alignItems: "center",
              display: "flex",
              fontSize: "1.125rem",
              fontWeight: 800,
              gap: "0.5rem",
              margin: 0,
            },
            children: [a.jsx(Qd, {}), Gd],
          }),
          a.jsx(ag, {
            style: {
              background: j,
              borderRadius: "0.625rem",
              minHeight: "2.75rem",
              padding: "0.625rem 0.75rem",
            },
            tone: u,
          }),
          a.jsx("form", {
            method: "dialog",
            style: { display: "flex", justifyContent: "flex-end", margin: 0 },
            children: a.jsx("button", {
              style: {
                background: d
                  ? "rgb(var(--slate-200, 226 232 240))"
                  : "#0f172a",
                border: 0,
                borderRadius: "0.625rem",
                color: d ? "rgb(var(--slate-900, 15 23 42))" : "#ffffff",
                cursor: "pointer",
                fontFamily: "inherit",
                fontSize: "0.875rem",
                fontWeight: 700,
                minHeight: "2.5rem",
                padding: "0.5rem 1rem",
              },
              type: "submit",
              children: "Close",
            }),
          }),
        ],
      }),
    ],
  });
}
const ug = "Send feedback",
  cg = "https://forms.cloud.microsoft/e/LdA5fPwYt1",
  ld = 64,
  ud = { x: 9, y: 12, width: 46, height: 44, rx: 13 },
  ce = "#1f2937",
  Ue = "#ffffff",
  Re = 33,
  Bt = 24,
  Ht = 40,
  cd = new Set(["shell"]);
function ci(s) {
  return s.detail || s.shade;
}
function dg(s) {
  const { shade: u, accent: l } = s,
    d = ci(s);
  switch (s.ears) {
    case "pointed":
      return a.jsxs("g", {
        children: [
          a.jsx("path", { d: "M11 26 17 3 30 17Z", fill: u }),
          a.jsx("path", { d: "M53 26 47 3 34 17Z", fill: u }),
          a.jsx("path", { d: "M16.5 22 19 9.5 26 17Z", fill: l }),
          a.jsx("path", { d: "M47.5 22 45 9.5 38 17Z", fill: l }),
        ],
      });
    case "round":
      return a.jsxs("g", {
        children: [
          a.jsx("circle", { cx: "17", cy: "14", r: "8.5", fill: u }),
          a.jsx("circle", { cx: "47", cy: "14", r: "8.5", fill: u }),
          a.jsx("circle", { cx: "17", cy: "14", r: "4", fill: l }),
          a.jsx("circle", { cx: "47", cy: "14", r: "4", fill: l }),
        ],
      });
    case "tall":
      return a.jsxs("g", {
        children: [
          a.jsxs("g", {
            transform: "rotate(-9 20.5 9)",
            children: [
              a.jsx("rect", {
                x: "15",
                y: "-5",
                width: "11",
                height: "27",
                rx: "5.5",
                fill: u,
              }),
              a.jsx("rect", {
                x: "18",
                y: "0",
                width: "5",
                height: "18",
                rx: "2.5",
                fill: l,
              }),
            ],
          }),
          a.jsxs("g", {
            transform: "rotate(9 43.5 9)",
            children: [
              a.jsx("rect", {
                x: "38",
                y: "-5",
                width: "11",
                height: "27",
                rx: "5.5",
                fill: u,
              }),
              a.jsx("rect", {
                x: "41",
                y: "0",
                width: "5",
                height: "18",
                rx: "2.5",
                fill: l,
              }),
            ],
          }),
        ],
      });
    case "floppy":
      return a.jsxs("g", {
        fill: u,
        children: [
          a.jsx("path", { d: "M15 16C5 18 3 34 9 41c5 4 9-2 9-11Z" }),
          a.jsx("path", { d: "M49 16c10 2 12 18 6 25-5 4-9-2-9-11Z" }),
        ],
      });
    case "tuft":
      return a.jsxs("g", {
        fill: u,
        children: [
          a.jsx("path", { d: "M12 19 15.5 5 24 15.5Z" }),
          a.jsx("path", { d: "M52 19 48.5 5 40 15.5Z" }),
        ],
      });
    case "horns":
      return a.jsxs("g", {
        fill: d,
        children: [
          a.jsx("path", {
            d: "M17.5 13C10 11 6 5 10.5 1.5c2.5 3.5 6.5 6.5 10.5 8.5Z",
          }),
          a.jsx("path", {
            d: "M46.5 13C54 11 58 5 53.5 1.5c-2.5 3.5-6.5 6.5-10.5 8.5Z",
          }),
        ],
      });
    case "antlers":
      return a.jsxs("g", {
        stroke: d,
        strokeWidth: "3",
        strokeLinecap: "round",
        fill: "none",
        children: [
          a.jsx("path", { d: "M21 14 16 3" }),
          a.jsx("path", { d: "M17.6 8 10 5" }),
          a.jsx("path", { d: "M43 14 48 3" }),
          a.jsx("path", { d: "M46.4 8 54 5" }),
        ],
      });
    case "flap":
      return a.jsxs("g", {
        children: [
          a.jsx("ellipse", { cx: "10", cy: "32", rx: "10", ry: "15", fill: u }),
          a.jsx("ellipse", { cx: "54", cy: "32", rx: "10", ry: "15", fill: u }),
          a.jsx("ellipse", { cx: "11", cy: "32", rx: "5", ry: "9", fill: l }),
          a.jsx("ellipse", { cx: "53", cy: "32", rx: "5", ry: "9", fill: l }),
        ],
      });
    case "spikes":
      return a.jsx("path", {
        d: "M8 22 13 3 20 18 26 1 32 17 38 1 44 18 51 3 56 22Z",
        fill: u,
      });
    case "crest":
      return a.jsxs("g", {
        fill: d,
        children: [
          a.jsx("circle", { cx: "25", cy: "10", r: "5" }),
          a.jsx("circle", { cx: "32", cy: "5.5", r: "5.5" }),
          a.jsx("circle", { cx: "39", cy: "10", r: "5" }),
        ],
      });
    case "fins":
      return a.jsxs("g", {
        fill: u,
        children: [
          a.jsx("path", { d: "M12 26 1 19 4 37Z" }),
          a.jsx("path", { d: "M52 26 63 19 60 37Z" }),
          a.jsx("path", { d: "M25 13 32 1 39 13Z" }),
        ],
      });
    case "antennae":
      return a.jsxs("g", {
        children: [
          a.jsxs("g", {
            stroke: u,
            strokeWidth: "2.6",
            strokeLinecap: "round",
            fill: "none",
            children: [
              a.jsx("path", { d: "M23 14C20 7 17 4 13.5 3" }),
              a.jsx("path", { d: "M41 14c3-7 6-10 9.5-11" }),
            ],
          }),
          a.jsx("circle", { cx: "12.5", cy: "3", r: "3", fill: u }),
          a.jsx("circle", { cx: "51.5", cy: "3", r: "3", fill: u }),
        ],
      });
    case "mane":
      return a.jsx("g", {
        fill: d,
        children: Array.from({ length: 12 }, (p, y) => {
          const S = (y / 12) * Math.PI * 2;
          return a.jsx(
            "circle",
            { cx: 32 + Math.cos(S) * 25, cy: 34 + Math.sin(S) * 23, r: "8.5" },
            y,
          );
        }),
      });
    case "wool":
      return a.jsxs("g", {
        fill: l,
        children: [
          a.jsx("circle", { cx: "15", cy: "17", r: "8" }),
          a.jsx("circle", { cx: "26", cy: "10", r: "9" }),
          a.jsx("circle", { cx: "38", cy: "10", r: "9" }),
          a.jsx("circle", { cx: "49", cy: "17", r: "8" }),
        ],
      });
    case "wings":
      return a.jsxs("g", {
        fill: d,
        children: [
          a.jsx("path", { d: "M13 22C-1 16 0 42 12 46Z" }),
          a.jsx("path", { d: "M51 22c14-6 13 20 1 24Z" }),
        ],
      });
    case "tentacles":
      return a.jsxs("g", {
        fill: u,
        children: [
          a.jsx("path", { d: "M12 44c-6 4-8 12-6 18 4 1 7-5 9-11Z" }),
          a.jsx("path", { d: "M52 44c6 4 8 12 6 18-4 1-7-5-9-11Z" }),
          a.jsx("path", { d: "M25 50c-3 6-3 12-1 14 3 0 5-6 5-12Z" }),
          a.jsx("path", { d: "M39 50c3 6 3 12 1 14-3 0-5-6-5-12Z" }),
        ],
      });
    case "dome":
      return a.jsx("path", { d: "M11 22a21 21 0 0 1 42 0Z", fill: u });
    case "frill":
      return a.jsxs("g", {
        children: [
          a.jsx("path", { d: "M1 42C1 16 14 1 32 1s31 15 31 41Z", fill: u }),
          a.jsx("g", {
            fill: l,
            children: Array.from({ length: 9 }, (p, y) => {
              const S = Math.PI + (y + 0.5) * (Math.PI / 9);
              return a.jsx(
                "circle",
                {
                  cx: 32 + Math.cos(S) * 27,
                  cy: 40 + Math.sin(S) * 33,
                  r: "3.2",
                },
                y,
              );
            }),
          }),
        ],
      });
    case "rays":
      return a.jsx("g", {
        fill: d,
        children: Array.from({ length: 12 }, (p, y) => {
          const S = (y / 12) * 360;
          return a.jsx(
            "path",
            { d: "M32 2 27 12h10Z", transform: `rotate(${S} 32 34)` },
            y,
          );
        }),
      });
    case "points":
      return a.jsxs("g", {
        fill: u,
        children: [
          a.jsx("path", { d: "M32 0 24 16h16Z" }),
          a.jsx("path", { d: "M6 14 12 30l12-9Z" }),
          a.jsx("path", { d: "M58 14 52 30l-12-9Z" }),
          a.jsx("path", { d: "M8 56 4 42l14 4Z" }),
          a.jsx("path", { d: "M56 56l4-14-14 4Z" }),
        ],
      });
    case "none":
    default:
      return null;
  }
}
function fg(s) {
  const { base: u, shade: l } = s,
    d = ci(s);
  switch (s.eyes) {
    case "round":
      return a.jsxs("g", {
        children: [
          a.jsx("circle", { cx: Bt, cy: Re, r: "6.5", fill: Ue }),
          a.jsx("circle", { cx: Ht, cy: Re, r: "6.5", fill: Ue }),
          a.jsx("circle", { cx: Bt, cy: Re, r: "3.4", fill: ce }),
          a.jsx("circle", { cx: Ht, cy: Re, r: "3.4", fill: ce }),
          a.jsx("circle", { cx: Bt + 1.4, cy: Re - 1.6, r: "1.3", fill: Ue }),
          a.jsx("circle", { cx: Ht + 1.4, cy: Re - 1.6, r: "1.3", fill: Ue }),
        ],
      });
    case "big":
      return a.jsxs("g", {
        children: [
          a.jsx("circle", { cx: "23", cy: "32", r: "9.5", fill: Ue }),
          a.jsx("circle", { cx: "41", cy: "32", r: "9.5", fill: Ue }),
          a.jsx("circle", { cx: "23", cy: "32", r: "5", fill: ce }),
          a.jsx("circle", { cx: "41", cy: "32", r: "5", fill: ce }),
          a.jsx("circle", { cx: "24.6", cy: "30.2", r: "1.9", fill: Ue }),
          a.jsx("circle", { cx: "42.6", cy: "30.2", r: "1.9", fill: Ue }),
        ],
      });
    case "bulge":
      return a.jsxs("g", {
        children: [
          a.jsx("circle", {
            cx: "20",
            cy: "14",
            r: "9",
            fill: u,
            stroke: l,
            strokeWidth: "1.6",
          }),
          a.jsx("circle", {
            cx: "44",
            cy: "14",
            r: "9",
            fill: u,
            stroke: l,
            strokeWidth: "1.6",
          }),
          a.jsx("circle", { cx: "20", cy: "13.5", r: "4.8", fill: Ue }),
          a.jsx("circle", { cx: "44", cy: "13.5", r: "4.8", fill: Ue }),
          a.jsx("circle", { cx: "20", cy: "13.5", r: "2.6", fill: ce }),
          a.jsx("circle", { cx: "44", cy: "13.5", r: "2.6", fill: ce }),
        ],
      });
    case "slit":
      return a.jsxs("g", {
        children: [
          a.jsx("ellipse", { cx: Bt, cy: Re, rx: "5.4", ry: "6", fill: d }),
          a.jsx("ellipse", { cx: Ht, cy: Re, rx: "5.4", ry: "6", fill: d }),
          a.jsx("ellipse", { cx: Bt, cy: Re, rx: "1.8", ry: "5", fill: ce }),
          a.jsx("ellipse", { cx: Ht, cy: Re, rx: "1.8", ry: "5", fill: ce }),
        ],
      });
    case "sleepy":
      return a.jsxs("g", {
        stroke: ce,
        strokeWidth: "3",
        strokeLinecap: "round",
        fill: "none",
        children: [
          a.jsx("path", { d: "M18.5 31.5q5.5 5 11 0" }),
          a.jsx("path", { d: "M34.5 31.5q5.5 5 11 0" }),
        ],
      });
    case "wide":
      return a.jsxs("g", {
        children: [
          a.jsx("circle", { cx: "20", cy: Re, r: "3.8", fill: ce }),
          a.jsx("circle", { cx: "44", cy: Re, r: "3.8", fill: ce }),
          a.jsx("circle", { cx: "21.3", cy: Re - 1.4, r: "1.3", fill: Ue }),
          a.jsx("circle", { cx: "45.3", cy: Re - 1.4, r: "1.3", fill: Ue }),
        ],
      });
    case "turret":
      return a.jsxs("g", {
        children: [
          a.jsx("circle", { cx: "21", cy: "31", r: "7.5", fill: l }),
          a.jsx("circle", { cx: "43", cy: "31", r: "7.5", fill: l }),
          a.jsx("circle", { cx: "21", cy: "31", r: "3.6", fill: d }),
          a.jsx("circle", { cx: "43", cy: "31", r: "3.6", fill: d }),
          a.jsx("circle", { cx: "21", cy: "31", r: "1.7", fill: ce }),
          a.jsx("circle", { cx: "43", cy: "31", r: "1.7", fill: ce }),
        ],
      });
    case "compound":
      return a.jsxs("g", {
        children: [
          a.jsx("ellipse", {
            cx: "22",
            cy: "31",
            rx: "7.5",
            ry: "9",
            fill: ce,
            transform: "rotate(-12 22 31)",
          }),
          a.jsx("ellipse", {
            cx: "42",
            cy: "31",
            rx: "7.5",
            ry: "9",
            fill: ce,
            transform: "rotate(12 42 31)",
          }),
          a.jsx("ellipse", {
            cx: "20.5",
            cy: "28",
            rx: "2.2",
            ry: "3",
            fill: Ue,
            opacity: "0.75",
          }),
          a.jsx("ellipse", {
            cx: "43.5",
            cy: "28",
            rx: "2.2",
            ry: "3",
            fill: Ue,
            opacity: "0.75",
          }),
        ],
      });
    case "stalk":
      return a.jsxs("g", {
        children: [
          a.jsxs("g", {
            stroke: l,
            strokeWidth: "2.8",
            strokeLinecap: "round",
            fill: "none",
            children: [
              a.jsx("path", { d: "M23 16 19.5 5" }),
              a.jsx("path", { d: "M41 16 44.5 5" }),
            ],
          }),
          a.jsx("circle", {
            cx: "19",
            cy: "4",
            r: "3.8",
            fill: Ue,
            stroke: l,
            strokeWidth: "1.2",
          }),
          a.jsx("circle", {
            cx: "45",
            cy: "4",
            r: "3.8",
            fill: Ue,
            stroke: l,
            strokeWidth: "1.2",
          }),
          a.jsx("circle", { cx: "19", cy: "4", r: "1.8", fill: ce }),
          a.jsx("circle", { cx: "45", cy: "4", r: "1.8", fill: ce }),
        ],
      });
    case "visor":
      return a.jsxs("g", {
        children: [
          a.jsx("rect", {
            x: "14",
            y: "26.5",
            width: "36",
            height: "13",
            rx: "6.5",
            fill: ce,
          }),
          a.jsx("circle", { cx: Bt, cy: Re, r: "3.2", fill: d }),
          a.jsx("circle", { cx: Ht, cy: Re, r: "3.2", fill: d }),
        ],
      });
    case "dot":
    default:
      return a.jsxs("g", {
        children: [
          a.jsx("circle", { cx: Bt, cy: Re, r: "4.2", fill: ce }),
          a.jsx("circle", { cx: Ht, cy: Re, r: "4.2", fill: ce }),
          a.jsx("circle", { cx: Bt + 1.4, cy: Re - 1.5, r: "1.4", fill: Ue }),
          a.jsx("circle", { cx: Ht + 1.4, cy: Re - 1.5, r: "1.4", fill: Ue }),
        ],
      });
  }
}
function dd() {
  return a.jsxs("g", {
    children: [
      a.jsx("path", { d: "M27.5 39q4.5-3.4 9 0Q32 44.6 27.5 39Z", fill: ce }),
      a.jsx("path", {
        d: "M32 43.5v2.4M32 45.9q-2.4 2.6-4.6.4M32 45.9q2.4 2.6 4.6.4",
        stroke: ce,
        strokeWidth: "2",
        strokeLinecap: "round",
        fill: "none",
      }),
    ],
  });
}
function pg(s) {
  const { accent: u, shade: l } = s,
    d = ci(s);
  switch (s.muzzle) {
    case "nose":
      return dd();
    case "snout":
      return a.jsxs("g", {
        children: [
          a.jsx("ellipse", { cx: "32", cy: "43", rx: "13", ry: "9", fill: u }),
          dd(),
        ],
      });
    case "beak":
      return a.jsxs("g", {
        children: [
          a.jsx("path", { d: "M23 38h18l-9 11Z", fill: d }),
          a.jsx("path", {
            d: "M23 38h18",
            stroke: ce,
            strokeWidth: "1.4",
            opacity: "0.35",
          }),
        ],
      });
    case "bill":
      return a.jsxs("g", {
        children: [
          a.jsx("rect", {
            x: "19",
            y: "37.5",
            width: "26",
            height: "11.5",
            rx: "5.75",
            fill: d,
          }),
          a.jsx("circle", { cx: "26", cy: "41.5", r: "1.3", fill: ce }),
          a.jsx("circle", { cx: "38", cy: "41.5", r: "1.3", fill: ce }),
        ],
      });
    case "pig":
      return a.jsxs("g", {
        children: [
          a.jsx("ellipse", { cx: "32", cy: "43", rx: "11", ry: "8", fill: u }),
          a.jsx("ellipse", {
            cx: "28",
            cy: "43",
            rx: "2.2",
            ry: "3",
            fill: ce,
          }),
          a.jsx("ellipse", {
            cx: "36",
            cy: "43",
            rx: "2.2",
            ry: "3",
            fill: ce,
          }),
        ],
      });
    case "wide":
      return a.jsx("path", {
        d: "M16 41q16 11 32 0",
        stroke: ce,
        strokeWidth: "3",
        strokeLinecap: "round",
        fill: "none",
      });
    case "tusks":
      return a.jsxs("g", {
        children: [
          a.jsx("ellipse", {
            cx: "32",
            cy: "42",
            rx: "13",
            ry: "8.5",
            fill: u,
          }),
          a.jsx("ellipse", {
            cx: "32",
            cy: "38.5",
            rx: "3.4",
            ry: "2.6",
            fill: ce,
          }),
          a.jsx("path", {
            d: "M27 45q-1.6 8-3.6 12M37 45q1.6 8 3.6 12",
            stroke: "#f8fafc",
            strokeWidth: "3.6",
            strokeLinecap: "round",
            fill: "none",
          }),
        ],
      });
    case "trunk":
      return a.jsx("path", {
        d: "M32 36q0 10-3 14t2 10",
        stroke: l,
        strokeWidth: "7.5",
        strokeLinecap: "round",
        fill: "none",
      });
    case "mandibles":
      return a.jsxs("g", {
        stroke: ce,
        strokeWidth: "2.6",
        strokeLinecap: "round",
        fill: "none",
        children: [
          a.jsx("path", { d: "M26 43q6 6 12 0" }),
          a.jsx("path", { d: "M24.5 41q-3.5 4.5 0 8" }),
          a.jsx("path", { d: "M39.5 41q3.5 4.5 0 8" }),
        ],
      });
    case "grill":
      return a.jsxs("g", {
        children: [
          a.jsx("rect", {
            x: "23",
            y: "41",
            width: "18",
            height: "8",
            rx: "4",
            fill: ce,
          }),
          a.jsx("path", {
            d: "M28 41v8M32 41v8M36 41v8",
            stroke: d,
            strokeWidth: "1.4",
            opacity: "0.8",
          }),
        ],
      });
    case "smile":
    default:
      return a.jsx("path", {
        d: "M26.5 42.5q5.5 5 11 0",
        stroke: ce,
        strokeWidth: "2.8",
        strokeLinecap: "round",
        fill: "none",
      });
  }
}
function ga(s, u, l) {
  const { shade: d, accent: p } = u,
    y = ci(u);
  switch (s) {
    case "mask":
      return a.jsxs(
        "g",
        {
          clipPath: `url(#${l})`,
          fill: d,
          children: [
            a.jsx("ellipse", { cx: Bt, cy: Re - 0.5, rx: "9", ry: "8.5" }),
            a.jsx("ellipse", { cx: Ht, cy: Re - 0.5, rx: "9", ry: "8.5" }),
          ],
        },
        s,
      );
    case "stripes":
      return a.jsxs(
        "g",
        {
          clipPath: `url(#${l})`,
          stroke: d,
          strokeWidth: "3.4",
          strokeLinecap: "round",
          fill: "none",
          children: [
            a.jsx("path", { d: "M19 11q3 8-2 14" }),
            a.jsx("path", { d: "M32 10v10" }),
            a.jsx("path", { d: "M45 11q-3 8 2 14" }),
          ],
        },
        s,
      );
    case "spots":
      return a.jsxs(
        "g",
        {
          clipPath: `url(#${l})`,
          fill: d,
          opacity: "0.8",
          children: [
            a.jsx("circle", { cx: "16", cy: "24", r: "4" }),
            a.jsx("circle", { cx: "48", cy: "24", r: "4" }),
            a.jsx("circle", { cx: "14", cy: "42", r: "3.4" }),
            a.jsx("circle", { cx: "50", cy: "42", r: "3.4" }),
            a.jsx("circle", { cx: "32", cy: "18", r: "3.4" }),
          ],
        },
        s,
      );
    case "blush":
      return a.jsxs(
        "g",
        {
          clipPath: `url(#${l})`,
          fill: "#f87171",
          opacity: "0.35",
          children: [
            a.jsx("ellipse", { cx: "15", cy: "40", rx: "5.5", ry: "3.6" }),
            a.jsx("ellipse", { cx: "49", cy: "40", rx: "5.5", ry: "3.6" }),
          ],
        },
        s,
      );
    case "patch":
      return a.jsx(
        "g",
        {
          clipPath: `url(#${l})`,
          children: a.jsx("rect", {
            x: "15",
            y: "37",
            width: "34",
            height: "21",
            rx: "11",
            fill: p,
            opacity: "0.9",
          }),
        },
        s,
      );
    case "whiskers":
      return a.jsx(
        "g",
        {
          stroke: ce,
          strokeWidth: "1.7",
          strokeLinecap: "round",
          opacity: "0.65",
          fill: "none",
          children: a.jsx("path", {
            d: "M18 40 6 37M18 43.5 6 44M46 40l12-3M46 43.5l12 .5",
          }),
        },
        s,
      );
    case "brows":
      return a.jsxs(
        "g",
        {
          stroke: ce,
          strokeWidth: "3",
          strokeLinecap: "round",
          fill: "none",
          children: [
            a.jsx("path", { d: "M17.5 24.5 29 28.5" }),
            a.jsx("path", { d: "M46.5 24.5 35 28.5" }),
          ],
        },
        s,
      );
    case "horn":
      return a.jsxs(
        "g",
        {
          children: [
            a.jsx("path", { d: "M28 15 32-2l4 17Z", fill: y }),
            a.jsx("path", {
              d: "M29.4 10.5h5.2M30.4 6h3.2",
              stroke: ce,
              strokeWidth: "1.3",
              opacity: "0.35",
            }),
          ],
        },
        s,
      );
    case "tongue":
      return a.jsx("path", { d: "M28.5 45q3.5 9 7 0Z", fill: "#f472b6" }, s);
    case "fangs":
      return a.jsxs(
        "g",
        {
          fill: Ue,
          children: [
            a.jsx("path", { d: "M26.5 42 29 48l2.5-6Z" }),
            a.jsx("path", { d: "M32.5 42 35 48l2.5-6Z" }),
          ],
        },
        s,
      );
    case "sparkle":
      return a.jsxs(
        "g",
        {
          fill: y,
          children: [
            a.jsx("path", {
              d: "M53 8 54.4 12 58 13.4 54.4 14.8 53 18.6 51.6 14.8 48 13.4 51.6 12Z",
            }),
            a.jsx("path", {
              d: "M10 44 11 47 14 48 11 49 10 52 9 49 6 48 9 47Z",
            }),
          ],
        },
        s,
      );
    case "crown":
      return a.jsxs(
        "g",
        {
          children: [
            a.jsx("path", {
              d: "M19 13 23 3l5 6 5-8 5 8 5-6 4 10Z",
              fill: "#fbbf24",
            }),
            a.jsx("circle", { cx: "32", cy: "6", r: "1.8", fill: "#fde68a" }),
          ],
        },
        s,
      );
    case "shell":
      return a.jsxs(
        "g",
        {
          children: [
            a.jsx("path", { d: "M0 61q0-27 32-27t32 27Z", fill: y }),
            a.jsxs("g", {
              fill: d,
              opacity: "0.55",
              children: [
                a.jsx("circle", { cx: "5.5", cy: "52", r: "3" }),
                a.jsx("circle", { cx: "58.5", cy: "52", r: "3" }),
                a.jsx("circle", { cx: "20", cy: "59", r: "3" }),
                a.jsx("circle", { cx: "44", cy: "59", r: "3" }),
                a.jsx("circle", { cx: "32", cy: "60", r: "3" }),
              ],
            }),
          ],
        },
        s,
      );
    case "stitches":
      return a.jsxs(
        "g",
        {
          clipPath: `url(#${l})`,
          stroke: d,
          strokeWidth: "1.8",
          strokeLinecap: "round",
          children: [
            a.jsx("path", { d: "M45 12v14" }),
            a.jsx("path", { d: "M41.5 16h7M41.5 21h7" }),
            a.jsx("path", { d: "M14 44h9" }),
            a.jsx("path", { d: "M17 41.5v5M21 41.5v5" }),
          ],
        },
        s,
      );
    case "bolt":
      return a.jsx(
        "path",
        { d: "M49 2 39 18h6l-8 14 20-20h-7l6-10Z", fill: y },
        s,
      );
    case "bandage":
      return a.jsxs(
        "g",
        {
          clipPath: `url(#${l})`,
          fill: p,
          opacity: "0.9",
          children: [
            a.jsx("path", { d: "M2 20 62 12v7L2 27Z" }),
            a.jsx("path", { d: "M2 44 62 36v7L2 51Z" }),
            a.jsx("path", { d: "M6 56 58 48v6H6Z" }),
          ],
        },
        s,
      );
    case "visorGlow":
      return a.jsx(
        "g",
        {
          opacity: "0.75",
          children: a.jsx("path", {
            d: "M18 27q14-6 28 0",
            stroke: y,
            strokeWidth: "2",
            fill: "none",
            strokeLinecap: "round",
          }),
        },
        s,
      );
    default:
      return null;
  }
}
function mg({ features: s, idSuffix: u, className: l, title: d }) {
  const p = `cs-avatar-head-${u}`,
    y = s.marks || [],
    S = y.filter((k) => cd.has(k)),
    j = y.filter((k) => !cd.has(k));
  return a.jsxs("svg", {
    className: l,
    viewBox: `0 0 ${ld} ${ld}`,
    width: "100%",
    height: "100%",
    role: d ? "img" : "presentation",
    "aria-label": d,
    "aria-hidden": d ? void 0 : !0,
    focusable: "false",
    children: [
      a.jsx("defs", {
        children: a.jsx("clipPath", {
          id: p,
          children: a.jsx("rect", { ...ud }),
        }),
      }),
      S.map((k) => ga(k, s, p)),
      dg(s),
      a.jsx("rect", { ...ud, fill: s.base }),
      j
        .filter(
          (k) =>
            k === "mask" ||
            k === "stripes" ||
            k === "spots" ||
            k === "patch" ||
            k === "bandage",
        )
        .map((k) => ga(k, s, p)),
      pg(s),
      fg(s),
      j
        .filter(
          (k) =>
            !(
              k === "mask" ||
              k === "stripes" ||
              k === "spots" ||
              k === "patch" ||
              k === "bandage"
            ),
        )
        .map((k) => ga(k, s, p)),
    ],
  });
}
const hg = {
  rust: ["#ef8043", "#cd5f27", "#ffe0c6"],
  amber: ["#f0993f", "#cb7220", "#ffe8cd"],
  brown: ["#a97551", "#7d5133", "#f2ddc8"],
  cocoa: ["#8b5e3c", "#5d3c23", "#ebd6c1"],
  sand: ["#e6c48b", "#c39a55", "#fdf1da"],
  cream: ["#f3e3c3", "#d6b988", "#fff8ea"],
  grey: ["#9aa8bb", "#6b7c93", "#e6edf5"],
  slate: ["#7c8ba1", "#4f5d74", "#dde5ef"],
  charcoal: ["#4d5765", "#2e3641", "#c6cedb"],
  snow: ["#eef3f9", "#c0cbd9", "#ffffff"],
  pink: ["#f5a6ba", "#da7c92", "#ffe4ec"],
  rose: ["#ef8ba2", "#cd6079", "#ffdde5"],
  green: ["#5fba70", "#3d9350", "#d9f2dd"],
  moss: ["#7fbc5a", "#5d9639", "#e4f5d5"],
  lime: ["#95cf57", "#6da733", "#eafada"],
  teal: ["#42b5a8", "#2a8a80", "#d3f1ed"],
  blue: ["#5c9cd6", "#3c74a7", "#dceaf8"],
  sky: ["#7cc4ef", "#4d9acb", "#e3f3fd"],
  navy: ["#41628f", "#2b4568", "#d0dcec"],
  yellow: ["#f3c552", "#d09c2c", "#fff3d0"],
  gold: ["#e9aa3c", "#c1811d", "#ffeecb"],
  purple: ["#a68bf5", "#7c5cef", "#e9e3ff"],
  violet: ["#8a6fd4", "#63499f", "#e0d8f6"],
  red: ["#e15c4f", "#b73e33", "#fbdad5"],
  stone: ["#98a0a8", "#6a737c", "#dfe4e8"],
};
function b(s, u, l, d, p) {
  const [y, S, j] = hg[d];
  return { id: s, label: u, group: l, base: y, shade: S, accent: j, ...p };
}
const gg = Object.freeze([
    b("fox", "Fox", "woodland", "rust", {
      ears: "pointed",
      eyes: "round",
      muzzle: "snout",
      marks: ["whiskers"],
    }),
    b("owl", "Owl", "woodland", "cocoa", {
      ears: "tuft",
      eyes: "big",
      muzzle: "beak",
      detail: "#f3c552",
    }),
    b("bear", "Bear", "woodland", "brown", {
      ears: "round",
      eyes: "dot",
      muzzle: "snout",
    }),
    b("panda", "Panda", "woodland", "snow", {
      ears: "round",
      eyes: "dot",
      muzzle: "snout",
      marks: ["mask"],
      shade: "#39414d",
    }),
    b("wolf", "Wolf", "woodland", "slate", {
      ears: "pointed",
      eyes: "round",
      muzzle: "snout",
    }),
    b("badger", "Badger", "woodland", "snow", {
      ears: "round",
      eyes: "dot",
      muzzle: "snout",
      marks: ["mask"],
      shade: "#3b4553",
    }),
    b("hedgehog", "Hedgehog", "woodland", "sand", {
      ears: "spikes",
      eyes: "dot",
      muzzle: "nose",
    }),
    b("squirrel", "Squirrel", "woodland", "amber", {
      ears: "tuft",
      eyes: "round",
      muzzle: "nose",
      marks: ["patch"],
    }),
    b("deer", "Deer", "woodland", "sand", {
      ears: "antlers",
      eyes: "round",
      muzzle: "snout",
      marks: ["spots"],
      detail: "#8b5e3c",
    }),
    b("raccoon", "Raccoon", "woodland", "grey", {
      ears: "round",
      eyes: "dot",
      muzzle: "snout",
      marks: ["mask"],
      shade: "#3e4756",
    }),
    b("cat", "Cat", "pets", "amber", {
      ears: "pointed",
      eyes: "slit",
      muzzle: "nose",
      marks: ["stripes", "whiskers"],
      detail: "#5fba70",
    }),
    b("dog", "Dog", "pets", "brown", {
      ears: "floppy",
      eyes: "round",
      muzzle: "snout",
    }),
    b("rabbit", "Rabbit", "pets", "cream", {
      ears: "tall",
      eyes: "round",
      muzzle: "nose",
      marks: ["blush"],
    }),
    b("hamster", "Hamster", "pets", "sand", {
      ears: "round",
      eyes: "dot",
      muzzle: "nose",
      marks: ["patch", "blush"],
    }),
    b("guineapig", "Guinea pig", "pets", "cocoa", {
      ears: "round",
      eyes: "dot",
      muzzle: "nose",
      marks: ["patch"],
    }),
    b("ferret", "Ferret", "pets", "cream", {
      ears: "round",
      eyes: "dot",
      muzzle: "nose",
      marks: ["mask"],
      shade: "#a97551",
    }),
    b("budgie", "Budgie", "pets", "lime", {
      ears: "crest",
      eyes: "dot",
      muzzle: "beak",
      marks: ["blush"],
      detail: "#f3c552",
    }),
    b("goldfish", "Goldfish", "pets", "gold", {
      ears: "fins",
      eyes: "wide",
      muzzle: "smile",
    }),
    b("pony", "Pony", "pets", "sand", {
      ears: "pointed",
      eyes: "round",
      muzzle: "snout",
      marks: ["patch"],
    }),
    b("mouse", "Mouse", "pets", "grey", {
      ears: "round",
      eyes: "dot",
      muzzle: "nose",
      marks: ["whiskers", "blush"],
    }),
    b("cow", "Cow", "farm", "snow", {
      ears: "horns",
      eyes: "round",
      muzzle: "pig",
      marks: ["spots"],
      shade: "#39414d",
      detail: "#e6c48b",
    }),
    b("pig", "Pig", "farm", "pink", {
      ears: "floppy",
      eyes: "dot",
      muzzle: "pig",
      marks: ["blush"],
    }),
    b("sheep", "Sheep", "farm", "cream", {
      ears: "wool",
      eyes: "dot",
      muzzle: "nose",
    }),
    b("goat", "Goat", "farm", "cream", {
      ears: "horns",
      eyes: "slit",
      muzzle: "nose",
      marks: ["patch"],
      detail: "#a97551",
    }),
    b("horse", "Horse", "farm", "cocoa", {
      ears: "pointed",
      eyes: "round",
      muzzle: "snout",
      marks: ["patch"],
    }),
    b("donkey", "Donkey", "farm", "grey", {
      ears: "tall",
      eyes: "sleepy",
      muzzle: "snout",
    }),
    b("chicken", "Chicken", "farm", "snow", {
      ears: "crest",
      eyes: "dot",
      muzzle: "beak",
      detail: "#e15c4f",
    }),
    b("duck", "Duck", "farm", "yellow", {
      ears: "none",
      eyes: "dot",
      muzzle: "bill",
      detail: "#f0993f",
    }),
    b("goose", "Goose", "farm", "snow", {
      ears: "none",
      eyes: "dot",
      muzzle: "bill",
      detail: "#f0993f",
    }),
    b("bull", "Bull", "farm", "charcoal", {
      ears: "horns",
      eyes: "round",
      muzzle: "pig",
      marks: ["brows"],
      detail: "#e6c48b",
    }),
    b("lion", "Lion", "savanna", "gold", {
      ears: "mane",
      eyes: "round",
      muzzle: "snout",
      marks: ["whiskers"],
      detail: "#b9762a",
    }),
    b("tiger", "Tiger", "savanna", "amber", {
      ears: "pointed",
      eyes: "round",
      muzzle: "snout",
      marks: ["stripes", "whiskers"],
      shade: "#8a4a17",
    }),
    b("elephant", "Elephant", "savanna", "grey", {
      ears: "flap",
      eyes: "dot",
      muzzle: "trunk",
    }),
    b("giraffe", "Giraffe", "savanna", "sand", {
      ears: "horns",
      eyes: "round",
      muzzle: "snout",
      marks: ["spots"],
      detail: "#8b5e3c",
    }),
    b("zebra", "Zebra", "savanna", "snow", {
      ears: "round",
      eyes: "round",
      muzzle: "snout",
      marks: ["stripes"],
      shade: "#39414d",
    }),
    b("rhino", "Rhino", "savanna", "stone", {
      ears: "round",
      eyes: "dot",
      muzzle: "pig",
      marks: ["horn"],
      detail: "#dfe4e8",
    }),
    b("hippo", "Hippo", "savanna", "violet", {
      ears: "round",
      eyes: "wide",
      muzzle: "pig",
    }),
    b("cheetah", "Cheetah", "savanna", "sand", {
      ears: "round",
      eyes: "round",
      muzzle: "nose",
      marks: ["spots", "whiskers"],
    }),
    b("meerkat", "Meerkat", "savanna", "cream", {
      ears: "round",
      eyes: "dot",
      muzzle: "nose",
      marks: ["mask"],
      shade: "#8b5e3c",
    }),
    b("monkey", "Monkey", "savanna", "cocoa", {
      ears: "round",
      eyes: "round",
      muzzle: "snout",
      marks: ["patch"],
    }),
    b("polarbear", "Polar bear", "polar", "snow", {
      ears: "round",
      eyes: "dot",
      muzzle: "snout",
    }),
    b("penguin", "Penguin", "polar", "charcoal", {
      ears: "none",
      eyes: "round",
      muzzle: "beak",
      marks: ["patch"],
      accent: "#ffffff",
      detail: "#f0993f",
    }),
    b("seal", "Seal", "polar", "slate", {
      ears: "none",
      eyes: "sleepy",
      muzzle: "nose",
      marks: ["whiskers"],
    }),
    b("arcticfox", "Arctic fox", "polar", "snow", {
      ears: "pointed",
      eyes: "round",
      muzzle: "snout",
      marks: ["whiskers"],
    }),
    b("snowleopard", "Snow leopard", "polar", "snow", {
      ears: "tuft",
      eyes: "slit",
      muzzle: "nose",
      marks: ["spots", "whiskers"],
      detail: "#5fba70",
    }),
    b("walrus", "Walrus", "polar", "brown", {
      ears: "none",
      eyes: "dot",
      muzzle: "tusks",
      marks: ["whiskers"],
    }),
    b("reindeer", "Reindeer", "polar", "cocoa", {
      ears: "antlers",
      eyes: "round",
      muzzle: "snout",
      detail: "#c39a55",
    }),
    b("husky", "Husky", "polar", "slate", {
      ears: "pointed",
      eyes: "slit",
      muzzle: "snout",
      marks: ["mask"],
      detail: "#7cc4ef",
    }),
    b("puffin", "Puffin", "polar", "charcoal", {
      ears: "none",
      eyes: "dot",
      muzzle: "beak",
      marks: ["patch"],
      accent: "#ffffff",
      detail: "#f0993f",
    }),
    b("yak", "Yak", "polar", "cocoa", {
      ears: "horns",
      eyes: "sleepy",
      muzzle: "nose",
      marks: ["patch"],
      detail: "#e6c48b",
    }),
    b("whale", "Whale", "ocean", "navy", {
      ears: "fins",
      eyes: "wide",
      muzzle: "smile",
      marks: ["patch"],
    }),
    b("dolphin", "Dolphin", "ocean", "sky", {
      ears: "fins",
      eyes: "dot",
      muzzle: "smile",
      marks: ["patch"],
    }),
    b("shark", "Shark", "ocean", "slate", {
      ears: "fins",
      eyes: "round",
      muzzle: "wide",
      marks: ["brows", "fangs"],
    }),
    b("octopus", "Octopus", "ocean", "purple", {
      ears: "tentacles",
      eyes: "round",
      muzzle: "smile",
    }),
    b("crab", "Crab", "ocean", "red", {
      ears: "none",
      eyes: "stalk",
      muzzle: "mandibles",
    }),
    b("jellyfish", "Jellyfish", "ocean", "rose", {
      ears: "tentacles",
      eyes: "dot",
      muzzle: "smile",
    }),
    b("seahorse", "Seahorse", "ocean", "yellow", {
      ears: "crest",
      eyes: "wide",
      muzzle: "beak",
      detail: "#d09c2c",
    }),
    b("pufferfish", "Pufferfish", "ocean", "amber", {
      ears: "spikes",
      eyes: "wide",
      muzzle: "smile",
    }),
    b("narwhal", "Narwhal", "ocean", "sky", {
      ears: "fins",
      eyes: "dot",
      muzzle: "smile",
      marks: ["horn"],
      detail: "#eef3f9",
    }),
    b("otter", "Otter", "ocean", "brown", {
      ears: "round",
      eyes: "round",
      muzzle: "snout",
      marks: ["whiskers"],
    }),
    b("frog", "Frog", "creatures", "green", {
      ears: "none",
      eyes: "bulge",
      muzzle: "wide",
      marks: ["tongue"],
    }),
    b("turtle", "Turtle", "creatures", "moss", {
      ears: "none",
      eyes: "round",
      muzzle: "smile",
      marks: ["shell"],
      detail: "#3f7a2a",
    }),
    b("gecko", "Gecko", "creatures", "lime", {
      ears: "none",
      eyes: "round",
      muzzle: "smile",
      marks: ["spots"],
    }),
    b("chameleon", "Chameleon", "creatures", "teal", {
      ears: "crest",
      eyes: "turret",
      muzzle: "smile",
      marks: ["spots"],
      detail: "#f3c552",
    }),
    b("snake", "Snake", "creatures", "moss", {
      ears: "none",
      eyes: "slit",
      muzzle: "smile",
      marks: ["stripes"],
      detail: "#f3c552",
    }),
    b("crocodile", "Crocodile", "creatures", "green", {
      ears: "none",
      eyes: "wide",
      muzzle: "wide",
      marks: ["brows", "fangs"],
    }),
    b("bee", "Bee", "creatures", "yellow", {
      ears: "antennae",
      eyes: "compound",
      muzzle: "mandibles",
      marks: ["stripes"],
      shade: "#39414d",
    }),
    b("ladybird", "Ladybird", "creatures", "red", {
      ears: "antennae",
      eyes: "dot",
      muzzle: "smile",
      marks: ["spots"],
      shade: "#39414d",
    }),
    b("butterfly", "Butterfly", "creatures", "purple", {
      ears: "wings",
      eyes: "compound",
      muzzle: "smile",
      marks: ["sparkle"],
      detail: "#f3c552",
    }),
    b("snail", "Snail", "creatures", "cream", {
      ears: "none",
      eyes: "stalk",
      muzzle: "smile",
      marks: ["shell"],
      detail: "#c39a55",
    }),
    b("dragon", "Dragon", "mythical", "green", {
      ears: "spikes",
      eyes: "slit",
      muzzle: "wide",
      marks: ["fangs", "brows"],
      detail: "#f3c552",
    }),
    b("unicorn", "Unicorn", "mythical", "snow", {
      ears: "pointed",
      eyes: "round",
      muzzle: "snout",
      marks: ["horn", "sparkle"],
      detail: "#a68bf5",
    }),
    b("phoenix", "Phoenix", "mythical", "red", {
      ears: "crest",
      eyes: "round",
      muzzle: "beak",
      marks: ["sparkle"],
      detail: "#f3c552",
    }),
    b("griffin", "Griffin", "mythical", "gold", {
      ears: "wings",
      eyes: "big",
      muzzle: "beak",
      marks: ["brows"],
      detail: "#c1811d",
    }),
    b("yeti", "Yeti", "mythical", "snow", {
      ears: "wool",
      eyes: "round",
      muzzle: "snout",
      marks: ["fangs"],
      accent: "#dcecfb",
    }),
    b("pegasus", "Pegasus", "mythical", "snow", {
      ears: "wings",
      eyes: "round",
      muzzle: "snout",
      marks: ["sparkle"],
      detail: "#7cc4ef",
    }),
    b("kraken", "Kraken", "mythical", "violet", {
      ears: "tentacles",
      eyes: "slit",
      muzzle: "smile",
      marks: ["brows"],
      detail: "#42b5a8",
    }),
    b("sphinx", "Sphinx", "mythical", "sand", {
      ears: "pointed",
      eyes: "round",
      muzzle: "nose",
      marks: ["crown"],
    }),
    b("wyvern", "Wyvern", "mythical", "red", {
      ears: "wings",
      eyes: "slit",
      muzzle: "wide",
      marks: ["horn", "fangs"],
      detail: "#f3c552",
    }),
    b("golem", "Golem", "mythical", "stone", {
      ears: "dome",
      eyes: "visor",
      muzzle: "grill",
      marks: ["sparkle"],
      detail: "#7cc4ef",
    }),
    b("trex", "T. rex", "dinosaurs", "moss", {
      ears: "none",
      eyes: "slit",
      muzzle: "wide",
      marks: ["brows", "fangs"],
      detail: "#f3c552",
    }),
    b("triceratops", "Triceratops", "dinosaurs", "teal", {
      ears: "frill",
      eyes: "round",
      muzzle: "beak",
      marks: ["horn"],
      detail: "#e6c48b",
    }),
    b("stegosaurus", "Stegosaurus", "dinosaurs", "violet", {
      ears: "spikes",
      eyes: "dot",
      muzzle: "smile",
      marks: ["spots"],
    }),
    b("raptor", "Raptor", "dinosaurs", "amber", {
      ears: "none",
      eyes: "slit",
      muzzle: "wide",
      marks: ["stripes", "fangs"],
      detail: "#5fba70",
    }),
    b("pterodactyl", "Pterodactyl", "dinosaurs", "rust", {
      ears: "wings",
      eyes: "round",
      muzzle: "beak",
      detail: "#cd5f27",
    }),
    b("brachiosaurus", "Brachiosaurus", "dinosaurs", "sky", {
      ears: "none",
      eyes: "dot",
      muzzle: "smile",
      marks: ["spots"],
    }),
    b("ankylosaurus", "Ankylosaurus", "dinosaurs", "stone", {
      ears: "points",
      eyes: "dot",
      muzzle: "smile",
      marks: ["spots"],
    }),
    b("spinosaurus", "Spinosaurus", "dinosaurs", "navy", {
      ears: "spikes",
      eyes: "slit",
      muzzle: "wide",
      marks: ["fangs"],
      detail: "#f3c552",
    }),
    b("dilophosaurus", "Dilophosaurus", "dinosaurs", "lime", {
      ears: "crest",
      eyes: "round",
      muzzle: "wide",
      marks: ["tongue"],
      detail: "#e15c4f",
    }),
    b("mosasaurus", "Mosasaurus", "dinosaurs", "teal", {
      ears: "fins",
      eyes: "wide",
      muzzle: "wide",
      marks: ["fangs"],
    }),
    b("astronaut", "Astronaut", "space", "snow", {
      ears: "dome",
      eyes: "visor",
      muzzle: "smile",
      marks: ["visorGlow"],
      detail: "#7cc4ef",
    }),
    b("alien", "Alien", "space", "lime", {
      ears: "antennae",
      eyes: "compound",
      muzzle: "smile",
      detail: "#6da733",
    }),
    b("martian", "Martian", "space", "red", {
      ears: "antennae",
      eyes: "big",
      muzzle: "smile",
      marks: ["blush"],
    }),
    b("moon", "Moon", "space", "snow", {
      ears: "none",
      eyes: "sleepy",
      muzzle: "smile",
      marks: ["spots"],
    }),
    b("sun", "Sun", "space", "yellow", {
      ears: "rays",
      eyes: "dot",
      muzzle: "smile",
      marks: ["blush"],
      detail: "#e9aa3c",
    }),
    b("star", "Star", "space", "yellow", {
      ears: "points",
      eyes: "dot",
      muzzle: "smile",
      marks: ["sparkle"],
      shade: "#e9aa3c",
      detail: "#fff3d0",
    }),
    b("comet", "Comet", "space", "sky", {
      ears: "points",
      eyes: "wide",
      muzzle: "smile",
      marks: ["sparkle", "bolt"],
      detail: "#f3c552",
    }),
    b("satellite", "Satellite", "space", "slate", {
      ears: "antennae",
      eyes: "visor",
      muzzle: "grill",
      marks: ["bolt"],
      detail: "#f3c552",
    }),
    b("ufo", "UFO", "space", "teal", {
      ears: "dome",
      eyes: "big",
      muzzle: "smile",
      marks: ["visorGlow"],
      detail: "#95cf57",
    }),
    b("rover", "Rover", "space", "stone", {
      ears: "antennae",
      eyes: "visor",
      muzzle: "grill",
      marks: ["spots"],
      detail: "#f0993f",
    }),
    b("robot", "Robot", "robots", "stone", {
      ears: "antennae",
      eyes: "visor",
      muzzle: "grill",
      marks: ["bolt"],
      detail: "#7cc4ef",
    }),
    b("android", "Android", "robots", "snow", {
      ears: "none",
      eyes: "round",
      muzzle: "smile",
      marks: ["visorGlow"],
      detail: "#42b5a8",
    }),
    b("cyborg", "Cyborg", "robots", "charcoal", {
      ears: "none",
      eyes: "slit",
      muzzle: "grill",
      marks: ["stitches"],
      detail: "#e15c4f",
    }),
    b("drone", "Drone", "robots", "slate", {
      ears: "fins",
      eyes: "big",
      muzzle: "smile",
      detail: "#95cf57",
    }),
    b("mecha", "Mecha", "robots", "navy", {
      ears: "horns",
      eyes: "visor",
      muzzle: "grill",
      marks: ["bolt"],
      detail: "#f3c552",
    }),
    b("servo", "Servo", "robots", "gold", {
      ears: "antennae",
      eyes: "dot",
      muzzle: "smile",
      marks: ["blush"],
    }),
    b("glitch", "Glitch", "robots", "purple", {
      ears: "points",
      eyes: "compound",
      muzzle: "grill",
      marks: ["sparkle"],
      detail: "#95cf57",
    }),
    b("pixel", "Pixel", "robots", "lime", {
      ears: "none",
      eyes: "dot",
      muzzle: "grill",
      marks: ["spots"],
      detail: "#f3c552",
    }),
    b("sentry", "Sentry", "robots", "red", {
      ears: "dome",
      eyes: "visor",
      muzzle: "grill",
      marks: ["visorGlow"],
      detail: "#f3c552",
    }),
    b("beacon", "Beacon", "robots", "sky", {
      ears: "rays",
      eyes: "dot",
      muzzle: "smile",
      marks: ["sparkle"],
      detail: "#f3c552",
    }),
    b("vampire", "Vampire", "monsters", "snow", {
      ears: "pointed",
      eyes: "slit",
      muzzle: "smile",
      marks: ["brows", "fangs"],
      detail: "#e15c4f",
    }),
    b("werewolf", "Werewolf", "monsters", "charcoal", {
      ears: "pointed",
      eyes: "round",
      muzzle: "snout",
      marks: ["brows", "fangs"],
    }),
    b("zombie", "Zombie", "monsters", "moss", {
      ears: "round",
      eyes: "round",
      muzzle: "smile",
      marks: ["stitches", "fangs"],
    }),
    b("ghost", "Ghost", "monsters", "snow", {
      ears: "none",
      eyes: "big",
      muzzle: "wide",
      marks: ["sparkle"],
      detail: "#a68bf5",
    }),
    b("mummy", "Mummy", "monsters", "cream", {
      ears: "none",
      eyes: "dot",
      muzzle: "smile",
      marks: ["bandage"],
      accent: "#fffaf0",
    }),
    b("frankenstein", "Frankenstein", "monsters", "lime", {
      ears: "none",
      eyes: "sleepy",
      muzzle: "smile",
      marks: ["brows", "stitches", "bolt"],
      detail: "#f3c552",
    }),
    b("goblin", "Goblin", "monsters", "moss", {
      ears: "pointed",
      eyes: "slit",
      muzzle: "wide",
      marks: ["brows", "fangs"],
      detail: "#f3c552",
    }),
    b("ogre", "Ogre", "monsters", "brown", {
      ears: "round",
      eyes: "dot",
      muzzle: "tusks",
      marks: ["brows"],
    }),
    b("slime", "Slime", "monsters", "teal", {
      ears: "none",
      eyes: "round",
      muzzle: "smile",
      marks: ["blush", "sparkle"],
    }),
    b("gargoyle", "Gargoyle", "monsters", "stone", {
      ears: "wings",
      eyes: "slit",
      muzzle: "wide",
      marks: ["brows", "fangs"],
      detail: "#6a737c",
    }),
  ]),
  yg = new Map(gg.map((s) => [s.id, s]));
function Zd(s) {
  return s ? yg.get(s) : void 0;
}
const Ba = "(max-width: 639px)";
function vg(s) {
  if (typeof window > "u" || typeof window.matchMedia != "function")
    return () => {};
  const u = window.matchMedia(Ba);
  return (
    u.addEventListener("change", s),
    () => u.removeEventListener("change", s)
  );
}
function wg() {
  return (
    typeof window < "u" &&
    typeof window.matchMedia == "function" &&
    window.matchMedia(Ba).matches
  );
}
function xg() {
  return I.useSyncExternalStore(vg, wg, () => !1);
}
const kg = I.createContext(null),
  fd = "var(--safe-area-inset-top, env(safe-area-inset-top, 0px))",
  pd = "var(--safe-area-inset-left, env(safe-area-inset-left, 0px))",
  md = "var(--comp-school-phone-bar-bg, hsl(var(--background, 222 47% 11%)))",
  Sg = `
[data-phone-bar-slot] { display: none; }
@media ${Ba} {
  [data-phone-bar] {
    position: sticky !important;
    top: 0;
    z-index: 30 !important;
    border-bottom: 0 !important;
    background: linear-gradient(to bottom, ${md} 0, ${md} 72%, transparent) !important;
  }
  [data-phone-bar] [data-phone-bar-row] {
    justify-content: flex-start !important;
    min-height: 0 !important;
    max-width: none !important;
    padding: calc(${fd} + 0.75rem) 0.75rem 1rem calc(${pd} + 0.75rem) !important;
  }
  [data-phone-bar] [data-phone-bar-row] > div:first-of-type {
    flex: 1 1 auto;
  }
  [data-phone-bar] [data-phone-bar-hide] { display: none !important; }
  [data-phone-bar] [data-phone-bar-slot] {
    display: flex;
    flex: 1 1 auto;
    min-width: 0;
    align-items: center;
  }
  [data-phone-bar] [data-phone-bar-leading] > button {
    display: inline-flex;
    width: 2.75rem;
    height: 2.75rem;
    flex-shrink: 0;
    align-items: center;
    justify-content: center;
    border: 1px solid rgb(255 255 255 / 0.15);
    border-radius: 0.5rem;
    background: rgb(2 6 23 / 0.7);
    color: rgb(241 245 249);
    pointer-events: auto;
    -webkit-backdrop-filter: blur(8px);
    backdrop-filter: blur(8px);
  }
}
/* The bare bar is the floating button alone, at every width below a desktop.
   It sits over a full-screen page's own layers (Aquatic Sort's sea is 35) and
   under the sidebar (45). */
[data-phone-bar='bare'] {
  position: fixed !important;
  inset: 0 auto auto 0;
  z-index: 40 !important;
  border-bottom: 0 !important;
  background: none !important;
  pointer-events: none;
}
[data-phone-bar='bare'] [data-phone-bar-row] {
  justify-content: flex-start !important;
  min-height: 0 !important;
  max-width: none !important;
  padding: calc(${fd} + 0.75rem) 0.75rem 1rem calc(${pd} + 0.75rem) !important;
}
[data-phone-bar='bare'] [data-phone-bar-hide],
[data-phone-bar='bare'] [data-phone-bar-back],
[data-phone-bar='bare'] [data-phone-bar-slot] { display: none !important; }
[data-phone-bar='bare'] [data-phone-bar-leading] > button {
  display: inline-flex;
  width: 2.75rem;
  height: 2.75rem;
  flex-shrink: 0;
  align-items: center;
  justify-content: center;
  border: 1px solid rgb(255 255 255 / 0.15);
  border-radius: 0.5rem;
  background: rgb(2 6 23 / 0.7);
  color: rgb(241 245 249);
  pointer-events: auto;
  -webkit-backdrop-filter: blur(8px);
  backdrop-filter: blur(8px);
}
@media (min-width: 1024px) {
  [data-phone-bar='bare'] { display: none !important; }
}
`;
function bg() {
  return a.jsx("style", { children: Sg });
}
const Eg = "Checking platform access...",
  jg = {
    alignItems: "center",
    background: "var(--cs-background, #020617)",
    color: "rgb(var(--slate-50, 248 250 252))",
    display: "grid",
    minHeight: "100vh",
    padding: "1rem",
    placeItems: "center",
  },
  Cg = { opacity: 0.5 },
  Ag = {
    border: 0,
    clip: "rect(0 0 0 0)",
    height: "1px",
    margin: "-1px",
    overflow: "hidden",
    padding: 0,
    position: "absolute",
    whiteSpace: "nowrap",
    width: "1px",
  };
function Pg() {
  return a.jsxs("main", {
    "aria-busy": "true",
    "data-comp-school-loading": "",
    style: jg,
    children: [
      a.jsx(Yd, { size: "large", style: Cg }),
      a.jsx("p", { role: "status", style: Ag, children: Eg }),
    ],
  });
}
function zg() {
  const [s, u] = I.useState(null);
  return (
    I.useEffect(
      () =>
        $m((l) => {
          u((d) => (d === "conflict" ? d : l.kind));
        }),
      [],
    ),
    s
      ? a.jsxs("div", {
          role: "alert",
          "data-testid": "saved-state-notice",
          style: oi.banner,
          children: [
            a.jsx("p", {
              style: oi.copy,
              children:
                s === "conflict"
                  ? "This was changed on another device. Reload."
                  : "This is too long to save to your account. It is saved on this device.",
            }),
            s === "conflict"
              ? a.jsx("button", {
                  type: "button",
                  style: oi.button,
                  onClick: () => window.location.reload(),
                  children: "Reload",
                })
              : a.jsx("button", {
                  type: "button",
                  style: oi.button,
                  onClick: () => u(null),
                  children: "OK",
                }),
          ],
        })
      : null
  );
}
const oi = {
    banner: {
      alignItems: "center",
      background: "var(--cs-surface, #ffffff)",
      border: "1px solid var(--cs-border, #cbd5e1)",
      borderRadius: "0.5rem",
      bottom: "1rem",
      boxShadow: "0 12px 24px -12px rgb(15 23 42 / 0.45)",
      boxSizing: "border-box",
      color: "var(--cs-text, #020617)",
      display: "flex",
      flexWrap: "wrap",
      fontFamily:
        'Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
      gap: "0.75rem",
      justifyContent: "space-between",
      left: "50%",
      maxWidth: "calc(100vw - 2rem)",
      padding: "0.75rem 1rem",
      position: "fixed",
      transform: "translateX(-50%)",
      width: "32rem",
      zIndex: 2147483e3,
    },
    copy: {
      flex: "1 1 14rem",
      fontSize: "1rem",
      fontWeight: 600,
      lineHeight: 1.4,
      margin: 0,
    },
    button: {
      background: "var(--cs-primary-hover, #2563eb)",
      border: 0,
      borderRadius: "0.375rem",
      color: "#ffffff",
      cursor: "pointer",
      fontSize: "1rem",
      fontWeight: 700,
      minHeight: "2.75rem",
      minWidth: "6rem",
      padding: "0.5rem 1rem",
    },
  },
  _g = { small: "1.25rem", medium: "1.75rem", large: "2.5rem" },
  hd = "#f8fafc",
  Tg = "#60a5fa",
  gd = [
    { value: "product", label: "Product" },
    { value: "mock", label: "Mock" },
    { value: "real", label: "Real" },
  ];
function Rg({ dataSource: s, onDataSourceChange: u, tone: l = "light" }) {
  const [d, p] = I.useState(!1),
    y = l === "dark",
    S = gd.find((T) => T.value === s)?.label || "Product",
    j = y ? "rgb(var(--slate-200, 226 232 240))" : "#334155",
    k = y ? "rgb(var(--slate-400, 148 163 184))" : "#64748b",
    F = y ? "rgb(var(--slate-50, 248 250 252))" : "#0f172a";
  return a.jsxs("div", {
    "data-profile-database-row": !0,
    style: { marginBottom: "0.25rem" },
    children: [
      a.jsxs("button", {
        "aria-controls": "profile-database-options",
        "aria-expanded": d,
        "data-profile-database-trigger": !0,
        onClick: () => p((T) => !T),
        style: {
          alignItems: "center",
          background: "transparent",
          border: 0,
          borderRadius: "0.5rem",
          color: j,
          cursor: "pointer",
          display: "flex",
          fontFamily: "inherit",
          fontSize: "0.875rem",
          fontWeight: 650,
          gap: "0.5rem",
          minHeight: "2.25rem",
          padding: "0.5rem",
          textAlign: "left",
          width: "100%",
        },
        type: "button",
        children: [
          a.jsxs("svg", {
            "aria-hidden": "true",
            fill: "none",
            height: "16",
            viewBox: "0 0 24 24",
            width: "16",
            children: [
              a.jsx("ellipse", {
                cx: "12",
                cy: "5",
                rx: "8",
                ry: "3",
                stroke: "currentColor",
                strokeWidth: "1.8",
              }),
              a.jsx("path", {
                d: "M4 5v7c0 1.7 3.6 3 8 3s8-1.3 8-3V5M4 12v7c0 1.7 3.6 3 8 3s8-1.3 8-3v-7",
                stroke: "currentColor",
                strokeWidth: "1.8",
              }),
            ],
          }),
          a.jsx("span", { style: { flex: 1 }, children: "Database" }),
          a.jsx("span", {
            style: { color: k, fontSize: "0.75rem", fontWeight: 600 },
            children: S,
          }),
          a.jsx("svg", {
            "aria-hidden": "true",
            fill: "none",
            height: "15",
            style: { transform: d ? "rotate(180deg)" : void 0 },
            viewBox: "0 0 24 24",
            width: "15",
            children: a.jsx("path", {
              d: "m6 9 6 6 6-6",
              stroke: "currentColor",
              strokeLinecap: "round",
              strokeLinejoin: "round",
              strokeWidth: "2",
            }),
          }),
        ],
      }),
      d
        ? a.jsx("div", {
            "aria-label": "Database",
            id: "profile-database-options",
            role: "radiogroup",
            style: {
              display: "grid",
              gap: "0.125rem",
              gridTemplateColumns: "repeat(3, minmax(0, 1fr))",
              padding: "0.125rem 0.5rem 0.5rem 2rem",
            },
            children: gd.map((T) =>
              a.jsxs(
                "button",
                {
                  "aria-checked": s === T.value,
                  "aria-label": T.locked ? `${T.label}, locked` : T.label,
                  "data-database-source": T.value,
                  disabled: T.locked,
                  onClick: () => u(T.value),
                  role: "radio",
                  style: {
                    background: s === T.value ? F : "transparent",
                    border: `1px solid ${s === T.value ? F : y ? "rgb(var(--slate-600, 71 85 105))" : "#cbd5e1"}`,
                    borderRadius: "9999px",
                    color: T.locked
                      ? k
                      : s === T.value
                        ? y
                          ? "rgb(var(--slate-900, 15 23 42))"
                          : "#ffffff"
                        : j,
                    cursor: T.locked ? "not-allowed" : "pointer",
                    display: "inline-flex",
                    fontFamily: "inherit",
                    fontSize: "0.75rem",
                    fontWeight: 700,
                    minHeight: "1.875rem",
                    opacity: T.locked ? 0.62 : 1,
                    padding: "0.25rem 0.45rem",
                    alignItems: "center",
                    justifyContent: "center",
                    gap: "0.2rem",
                  },
                  title: T.locked ? "Locked" : T.label,
                  type: "button",
                  children: [
                    T.locked
                      ? a.jsxs("svg", {
                          "aria-hidden": "true",
                          fill: "none",
                          height: "11",
                          viewBox: "0 0 24 24",
                          width: "11",
                          children: [
                            a.jsx("rect", {
                              height: "10",
                              rx: "2",
                              stroke: "currentColor",
                              strokeWidth: "2",
                              width: "14",
                              x: "5",
                              y: "11",
                            }),
                            a.jsx("path", {
                              d: "M8 11V8a4 4 0 0 1 8 0v3",
                              stroke: "currentColor",
                              strokeLinecap: "round",
                              strokeWidth: "2",
                            }),
                          ],
                        })
                      : null,
                    T.label,
                  ],
                },
                T.value,
              ),
            ),
          })
        : null,
    ],
  });
}
function Yd({ className: s, size: u = "medium", style: l }) {
  return a.jsxs("span", {
    "aria-label": "comp.school",
    className: s,
    style: {
      alignItems: "baseline",
      color: "inherit",
      display: "inline-flex",
      fontSize: _g[u],
      lineHeight: 1,
      textTransform: "none",
      whiteSpace: "nowrap",
      ...l,
    },
    children: [
      a.jsxs("span", {
        "aria-hidden": "true",
        "data-comp-school-wordmark-part": "comp-dot",
        style: {
          color: hd,
          fontFamily:
            "Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
          fontSize: "0.88em",
          fontStyle: "normal",
          fontWeight: 650,
          letterSpacing: "-0.035em",
        },
        children: [
          "comp",
          a.jsx("span", { style: { color: hd }, children: "." }),
        ],
      }),
      a.jsx("span", {
        "aria-hidden": "true",
        "data-comp-school-wordmark-part": "school",
        style: {
          color: Tg,
          fontFamily: "'Caveat', 'Segoe Print', cursive",
          fontSize: "1.2em",
          fontStyle: "italic",
          fontWeight: 700,
          letterSpacing: "-0.04em",
          transform: "rotate(-2deg)",
        },
        children: "school",
      }),
    ],
  });
}
function Lg(s) {
  return s.trim().charAt(0).toLocaleUpperCase() || "U";
}
function yd({ avatar: s, instanceId: u, profileName: l, style: d }) {
  const p = Zd(s);
  return p
    ? a.jsx("span", {
        "aria-hidden": "true",
        "data-student-avatar": p.id,
        style: {
          display: "block",
          height: "100%",
          lineHeight: 0,
          width: "100%",
          ...d,
        },
        children: a.jsx(mg, {
          features: p,
          idSuffix: u ? `${u}-${p.id}` : p.id,
        }),
      })
    : a.jsx("span", {
        "aria-hidden": "true",
        style: { lineHeight: 1, ...d },
        children: Lg(l),
      });
}
function vd() {
  return a.jsxs("svg", {
    "aria-hidden": "true",
    fill: "none",
    height: "16",
    viewBox: "0 0 24 24",
    width: "16",
    children: [
      a.jsx("path", {
        d: "M12 4c-4.4 0-8 3.1-8 7 0 2.9 2 5.4 4.9 6.5L8 21l3.4-2.8H12c4.4 0 8-3.1 8-7s-3.6-7.2-8-7.2Z",
        stroke: "currentColor",
        strokeLinejoin: "round",
        strokeWidth: "1.8",
      }),
      a.jsx("circle", { cx: "9", cy: "10", fill: "currentColor", r: "1" }),
      a.jsx("circle", { cx: "15", cy: "10", fill: "currentColor", r: "1" }),
    ],
  });
}
function Mg(s) {
  if (typeof window > "u") return "https://comp.school/?page=release-log";
  const u = new URL(fn(window.location.hostname));
  u.searchParams.set("page", "release-log");
  const l = window.sessionStorage.getItem("comp-school-fallback-access");
  return l && Ea(l) ? wm(u.toString(), l, s) : u.toString();
}
function Og({
  profileName: s,
  canChangeAvatar: u = !1,
  changeAvatarHref: l,
  onChangeAvatar: d,
  dataSource: p,
  feedbackWelcomeInstead: y = !1,
  onDataSourceChange: S,
  onSignOut: j,
  profileAvatar: k,
  reportIssueHref: F,
  releaseLogHref: T,
  tone: V = "dark",
  placement: D = "below-end",
  showName: q = !1,
}) {
  const X = I.useRef(null),
    [O, $] = I.useState(!1),
    K = V === "dark",
    ae = !!Zd(k),
    be = K ? "rgb(var(--slate-50, 248 250 252))" : "#0f172a",
    ie = K ? "rgb(var(--slate-300, 203 213 225))" : "#475569",
    Ae = K ? "rgb(var(--slate-700, 51 65 85))" : "#e2e8f0",
    B = K ? "rgb(var(--slate-900, 15 23 42))" : "#ffffff",
    ee = {
      alignItems: "center",
      background: "transparent",
      border: 0,
      borderRadius: "0.625rem",
      color: be,
      cursor: "pointer",
      display: "inline-flex",
      fontFamily: "inherit",
      fontSize: "0.875rem",
      fontWeight: 700,
      gap: "0.375rem",
      justifyContent: "flex-start",
      minHeight: "2.5rem",
      padding: "0.5rem 0.75rem",
      textDecoration: "none",
      whiteSpace: "nowrap",
      width: "100%",
    },
    te = {
      alignItems: "center",
      background: ae
        ? "transparent"
        : K
          ? "rgb(var(--slate-200, 226 232 240))"
          : "#0f172a",
      borderRadius: ae ? "0.8rem" : "9999px",
      color: K ? "rgb(var(--slate-900, 15 23 42))" : "#ffffff",
      display: "inline-flex",
      flex: "0 0 auto",
      fontSize: "0.875rem",
      fontWeight: 800,
      height: "2.5rem",
      justifyContent: "center",
      overflow: "hidden",
      width: "2.5rem",
    };
  return (F || y) && j
    ? a.jsxs(a.Fragment, {
        children: [
          a.jsxs("details", {
            "data-comp-school-account-menu": !0,
            onToggle: (ne) => {
              ne.currentTarget.open || $(!1);
            },
            style: { position: "relative", width: q ? "100%" : void 0 },
            children: [
              a.jsxs("summary", {
                "aria-label": `${s} account menu`,
                title: `${s} account`,
                style: {
                  alignItems: "center",
                  borderRadius: "0.625rem",
                  color: be,
                  cursor: "pointer",
                  display: "flex",
                  gap: "0.625rem",
                  listStyle: "none",
                  padding: q ? "0.25rem" : 0,
                  width: q ? "100%" : void 0,
                },
                children: [
                  a.jsx("span", {
                    style: te,
                    children: a.jsx(yd, { avatar: k, profileName: s }),
                  }),
                  q
                    ? a.jsx("span", {
                        style: {
                          fontSize: "0.875rem",
                          fontWeight: 600,
                          minWidth: 0,
                          overflow: "hidden",
                          textOverflow: "ellipsis",
                          whiteSpace: "nowrap",
                        },
                        children: s,
                      })
                    : null,
                ],
              }),
              a.jsxs("div", {
                style: {
                  background: B,
                  border: `1px solid ${Ae}`,
                  borderRadius: "0.75rem",
                  boxShadow: "0 20px 25px -5px rgba(2, 6, 23, 0.35)",
                  minWidth: "15rem",
                  padding: "0.5rem",
                  position: "absolute",
                  zIndex: 40,
                  ...(D === "above-start"
                    ? { bottom: "calc(100% + 0.5rem)", left: 0 }
                    : { right: 0, top: "calc(100% + 0.5rem)" }),
                },
                children: [
                  D === "above-start"
                    ? null
                    : a.jsx("p", {
                        style: {
                          color: ie,
                          fontSize: "0.75rem",
                          fontWeight: 700,
                          letterSpacing: "0.05em",
                          margin: 0,
                          padding: "0.375rem 0.5rem",
                          textTransform: "uppercase",
                        },
                        children: s.split(" ")[0] || s,
                      }),
                  p && S
                    ? a.jsx(Rg, {
                        dataSource: p,
                        onDataSourceChange: S,
                        tone: V,
                      })
                    : null,
                  O
                    ? a.jsxs(a.Fragment, {
                        children: [
                          a.jsxs("button", {
                            "data-account-menu-back": !0,
                            onClick: () => $(!1),
                            style: { ...ee, textAlign: "left" },
                            type: "button",
                            children: [
                              a.jsx("svg", {
                                "aria-hidden": "true",
                                fill: "none",
                                height: "16",
                                viewBox: "0 0 24 24",
                                width: "16",
                                children: a.jsx("path", {
                                  d: "m15 18-6-6 6-6",
                                  stroke: "currentColor",
                                  strokeLinecap: "round",
                                  strokeLinejoin: "round",
                                  strokeWidth: "1.8",
                                }),
                              }),
                              a.jsx("span", { children: "Back" }),
                            ],
                          }),
                          a.jsxs("a", {
                            href: T ?? Mg(k),
                            style: ee,
                            children: [
                              a.jsx("svg", {
                                "aria-hidden": "true",
                                fill: "none",
                                height: "16",
                                viewBox: "0 0 24 24",
                                width: "16",
                                children: a.jsx("path", {
                                  d: "M3 11a9 9 0 1 1 2.6 6.4M3 5v6h6m3-4v5l3 2",
                                  stroke: "currentColor",
                                  strokeLinecap: "round",
                                  strokeLinejoin: "round",
                                  strokeWidth: "1.8",
                                }),
                              }),
                              a.jsx("span", { children: "What's new" }),
                            ],
                          }),
                          a.jsxs("button", {
                            "data-profile-accessibility": !0,
                            onClick: (ne) => {
                              (ne.currentTarget
                                .closest("[data-comp-school-account-menu]")
                                ?.removeAttribute("open"),
                                X.current?.showModal());
                            },
                            style: { ...ee, textAlign: "left" },
                            type: "button",
                            children: [
                              a.jsx(Qd, {}),
                              a.jsx("span", { children: Gd }),
                            ],
                          }),
                        ],
                      })
                    : a.jsxs(a.Fragment, {
                        children: [
                          u && d
                            ? a.jsxs("button", {
                                onClick: (ne) => {
                                  (ne.currentTarget
                                    .closest("details")
                                    ?.removeAttribute("open"),
                                    d());
                                },
                                style: ee,
                                type: "button",
                                children: [
                                  a.jsx(vd, {}),
                                  a.jsx("span", { children: "Change avatar" }),
                                ],
                              })
                            : u && l
                              ? a.jsxs("a", {
                                  href: l,
                                  style: ee,
                                  children: [
                                    a.jsx(vd, {}),
                                    a.jsx("span", {
                                      children: "Change avatar",
                                    }),
                                  ],
                                })
                              : null,
                          y
                            ? a.jsxs("a", {
                                href: cg,
                                onClick: (ne) =>
                                  ne.currentTarget
                                    .closest("details")
                                    ?.removeAttribute("open"),
                                rel: "noopener noreferrer",
                                style: ee,
                                target: "_blank",
                                children: [
                                  a.jsxs("svg", {
                                    "aria-hidden": "true",
                                    fill: "none",
                                    height: "16",
                                    viewBox: "0 0 24 24",
                                    width: "16",
                                    children: [
                                      a.jsx("rect", {
                                        height: "14",
                                        rx: "2",
                                        stroke: "currentColor",
                                        strokeWidth: "1.8",
                                        width: "18",
                                        x: "3",
                                        y: "5",
                                      }),
                                      a.jsx("path", {
                                        d: "m4 7 8 6 8-6",
                                        stroke: "currentColor",
                                        strokeLinecap: "round",
                                        strokeLinejoin: "round",
                                        strokeWidth: "1.8",
                                      }),
                                    ],
                                  }),
                                  a.jsx("span", { children: ug }),
                                ],
                              })
                            : a.jsxs("a", {
                                href: F,
                                style: ee,
                                children: [
                                  a.jsxs("svg", {
                                    "aria-hidden": "true",
                                    fill: "none",
                                    height: "16",
                                    viewBox: "0 0 24 24",
                                    width: "16",
                                    children: [
                                      a.jsx("path", {
                                        d: "M8 2 6.5 5M16 2l1.5 3M4 9H2M22 9h-2M5 19l2.5-2.5M19 19l-2.5-2.5M9 5h6a4 4 0 0 1 4 4v4a7 7 0 0 1-14 0V9a4 4 0 0 1 4-4Z",
                                        stroke: "currentColor",
                                        strokeLinecap: "round",
                                        strokeLinejoin: "round",
                                        strokeWidth: "1.8",
                                      }),
                                      a.jsx("path", {
                                        d: "M8 12h8M12 8v8",
                                        stroke: "currentColor",
                                        strokeLinecap: "round",
                                        strokeWidth: "1.8",
                                      }),
                                    ],
                                  }),
                                  a.jsx("span", {
                                    children: "Report an issue",
                                  }),
                                ],
                              }),
                          a.jsxs("button", {
                            "data-account-menu-more": !0,
                            onClick: () => $(!0),
                            style: { ...ee, textAlign: "left" },
                            type: "button",
                            children: [
                              a.jsxs("svg", {
                                "aria-hidden": "true",
                                fill: "none",
                                height: "16",
                                viewBox: "0 0 24 24",
                                width: "16",
                                children: [
                                  a.jsx("circle", {
                                    cx: "5",
                                    cy: "12",
                                    r: "1.6",
                                    fill: "currentColor",
                                  }),
                                  a.jsx("circle", {
                                    cx: "12",
                                    cy: "12",
                                    r: "1.6",
                                    fill: "currentColor",
                                  }),
                                  a.jsx("circle", {
                                    cx: "19",
                                    cy: "12",
                                    r: "1.6",
                                    fill: "currentColor",
                                  }),
                                ],
                              }),
                              a.jsx("span", { children: "More" }),
                            ],
                          }),
                          a.jsxs("button", {
                            onClick: j,
                            style: { ...ee, marginTop: "0.25rem" },
                            type: "button",
                            children: [
                              a.jsx("svg", {
                                "aria-hidden": "true",
                                fill: "none",
                                height: "16",
                                viewBox: "0 0 24 24",
                                width: "16",
                                children: a.jsx("path", {
                                  d: "M10 17l5-5-5-5M15 12H3M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4",
                                  stroke: "currentColor",
                                  strokeLinecap: "round",
                                  strokeLinejoin: "round",
                                  strokeWidth: "1.8",
                                }),
                              }),
                              a.jsx("span", { children: "Sign out" }),
                            ],
                          }),
                        ],
                      }),
                ],
              }),
            ],
          }),
          a.jsx(lg, { dialogRef: X, tone: V }),
        ],
      })
    : a.jsx("span", {
        "aria-label": `${s} profile`,
        title: s,
        style: te,
        children: a.jsx(yd, { avatar: k, profileName: s }),
      });
}
function Ng({
  appName: s,
  backHref: u,
  profileName: l,
  backLabel: d = "Back",
  canChangeAvatar: p = !1,
  changeAvatarHref: y,
  children: S,
  className: j,
  contextLabel: k,
  dataSource: F,
  onBack: T,
  onDataSourceChange: V,
  onSignOut: D,
  profileAvatar: q,
  feedbackWelcomeInstead: X = !1,
  leading: O,
  hideAccountMenu: $ = !1,
  breadcrumbNavigation: K = !1,
  phoneBar: ae,
  phoneBarSlotRef: be,
  actionsSlotRef: ie,
  reportIssueHref: Ae,
  style: B,
  tone: ee = "dark",
}) {
  const te = ee === "dark",
    ne = te ? "rgb(var(--slate-50, 248 250 252))" : "#0f172a",
    le = te ? "rgb(var(--slate-300, 203 213 225))" : "#475569",
    se = te ? "rgb(var(--slate-700, 51 65 85))" : "#e2e8f0",
    Ee = te ? "rgb(var(--slate-900, 15 23 42))" : "#ffffff",
    he = te ? "rgb(var(--slate-800, 30 41 59))" : "#f8fafc",
    je = a.jsxs(a.Fragment, {
      children: [
        a.jsx("svg", {
          "aria-hidden": "true",
          fill: "none",
          height: "16",
          viewBox: "0 0 24 24",
          width: "16",
          children: a.jsx("path", {
            d: "M19 12H5m7 7-7-7 7-7",
            stroke: "currentColor",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "2",
          }),
        }),
        a.jsx("span", { children: d }),
      ],
    }),
    Fe = {
      alignItems: "center",
      background: he,
      border: `1px solid ${se}`,
      borderRadius: "0.625rem",
      color: le,
      cursor: "pointer",
      display: "inline-flex",
      fontFamily: "inherit",
      fontSize: "0.875rem",
      fontWeight: 700,
      gap: "0.375rem",
      minHeight: "2.5rem",
      padding: "0.5rem 0.75rem",
      textDecoration: "none",
      whiteSpace: "nowrap",
    },
    Le = K && $ && !S && !k;
  return a.jsx("header", {
    "aria-label": `${s} navigation`,
    className: j,
    "data-comp-school-navbar": K ? "breadcrumb" : "standard",
    "data-navbar-wide-hidden": Le ? "" : void 0,
    "data-phone-bar": ae,
    style: {
      background: Ee,
      borderBottom: `1px solid ${se}`,
      color: ne,
      fontFamily:
        "Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
      position: "relative",
      zIndex: 30,
      ...B,
    },
    children: a.jsxs("div", {
      "data-phone-bar-row": ae ? "" : void 0,
      style: {
        alignItems: "center",
        display: "flex",
        gap: "0.75rem",
        justifyContent: "space-between",
        margin: "0 auto",
        maxWidth: "80rem",
        minHeight: "4rem",
        padding: "0.625rem clamp(1rem, 3vw, 2rem)",
        width: "100%",
      },
      children: [
        Le
          ? a.jsx("style", {
              children:
                "@media (min-width: 1024px) { [data-navbar-wide-hidden] { display: none; } }",
            })
          : null,
        ae ? a.jsx(bg, {}) : null,
        a.jsxs("div", {
          style: {
            alignItems: "center",
            display: "flex",
            gap: "0.625rem",
            minWidth: 0,
          },
          children: [
            ae
              ? a.jsx("span", {
                  "data-phone-bar-leading": "",
                  style: { display: "contents" },
                  children: O,
                })
              : O,
            K
              ? null
              : T
                ? a.jsx("button", {
                    "aria-label": d,
                    "data-phone-bar-back": "",
                    onClick: T,
                    style: Fe,
                    type: "button",
                    children: je,
                  })
                : a.jsx("a", {
                    "aria-label": d,
                    "data-phone-bar-back": "",
                    href: u,
                    style: Fe,
                    children: je,
                  }),
            ae ? a.jsx("div", { "data-phone-bar-slot": "", ref: be }) : null,
            k
              ? a.jsx("span", {
                  "data-phone-bar-hide": "",
                  style: {
                    borderLeft: `1px solid ${se}`,
                    color: le,
                    fontSize: "0.875rem",
                    fontWeight: 650,
                    lineHeight: 1.2,
                    minWidth: 0,
                    overflow: "hidden",
                    paddingLeft: "0.625rem",
                    textOverflow: "ellipsis",
                    whiteSpace: "nowrap",
                  },
                  children: k,
                })
              : null,
          ],
        }),
        a.jsxs("div", {
          "data-phone-bar-hide": ae ? "" : void 0,
          style: { alignItems: "center", display: "flex", gap: "0.625rem" },
          children: [
            ie
              ? a.jsx("div", {
                  "data-navbar-actions": "",
                  ref: ie,
                  style: {
                    alignItems: "center",
                    display: "flex",
                    gap: "0.5rem",
                  },
                })
              : null,
            S,
            $
              ? null
              : a.jsx(Og, {
                  canChangeAvatar: p,
                  changeAvatarHref: y,
                  dataSource: F,
                  feedbackWelcomeInstead: X,
                  onDataSourceChange: V,
                  onSignOut: D,
                  profileAvatar: q,
                  profileName: l,
                  reportIssueHref: Ae,
                  tone: ee,
                }),
          ],
        }),
      ],
    }),
  });
}
const Ig = 900 * 1e3,
  Dg = 15 * 1e3;
function Ug({ storageKey: s, now: u = Date.now }) {
  const [l, d] = I.useState(() => aa(window.sessionStorage.getItem(s))),
    [p, y] = I.useState(u),
    [S, j] = I.useState(""),
    [k, F] = I.useState(null),
    [T, V] = I.useState(!1),
    D = I.useId();
  if (
    (I.useEffect(() => {
      const O = window.setInterval(() => {
        y(u());
        const $ = aa(window.sessionStorage.getItem(s));
        $ && d((K) => (K && K > $ ? K : $));
      }, Dg);
      return () => window.clearInterval(O);
    }, [u, s]),
    ui() || !l || l - p > Ig)
  )
    return null;
  const q = Math.max(0, Math.ceil((l - p) / 6e4));
  async function X(O) {
    if ((O.preventDefault(), !(!S.trim() || T))) {
      (V(!0), F(null));
      try {
        const $ = await fetch(
            new URL(
              "/api/fallback-access",
              fn(window.location.hostname),
            ).toString(),
            {
              method: "POST",
              cache: "no-store",
              headers: {
                accept: "application/json",
                "content-type": "application/json",
              },
              body: JSON.stringify({ password: S }),
            },
          ),
          K = await $.json().catch(() => null),
          ae = aa(K?.grant);
        if (!$.ok || !K?.ok || !K.grant || !ae) {
          F(K?.message || "That did not work. Try again.");
          return;
        }
        (window.sessionStorage.setItem(s, K.grant), d(ae), j(""));
      } catch {
        F("No connection. Try again.");
      } finally {
        V(!1);
      }
    }
  }
  return a.jsx("div", {
    role: "dialog",
    "aria-labelledby": `${D}-title`,
    "data-testid": "fallback-renewal",
    style: dn.panel,
    children: a.jsxs("form", {
      onSubmit: (O) => void X(O),
      style: dn.form,
      children: [
        a.jsx("p", {
          id: `${D}-title`,
          style: dn.title,
          children:
            q > 0
              ? `Your access ends in ${q} minute${q === 1 ? "" : "s"}.`
              : "Your access has ended.",
        }),
        a.jsx("label", {
          htmlFor: D,
          style: dn.label,
          children: "Class password",
        }),
        a.jsxs("div", {
          style: dn.row,
          children: [
            a.jsx("input", {
              id: D,
              type: "password",
              autoComplete: "off",
              value: S,
              onChange: (O) => j(O.target.value),
              style: dn.input,
            }),
            a.jsx("button", {
              type: "submit",
              disabled: T,
              style: dn.button,
              children: "Keep going",
            }),
          ],
        }),
        k ? a.jsx("p", { role: "alert", style: dn.error, children: k }) : null,
      ],
    }),
  });
}
const dn = {
    panel: {
      background: "var(--cs-surface, #ffffff)",
      border: "1px solid var(--cs-border, #cbd5e1)",
      borderRadius: "0.5rem",
      bottom: "1rem",
      boxShadow: "0 12px 24px -12px rgb(15 23 42 / 0.45)",
      boxSizing: "border-box",
      color: "var(--cs-text, #020617)",
      fontFamily:
        'Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
      left: "50%",
      maxWidth: "calc(100vw - 2rem)",
      padding: "1rem",
      position: "fixed",
      transform: "translateX(-50%)",
      width: "26rem",
      zIndex: 2147483001,
    },
    form: { display: "grid", gap: "0.5rem", margin: 0 },
    title: { fontSize: "1rem", fontWeight: 700, lineHeight: 1.4, margin: 0 },
    label: { fontSize: "0.875rem", fontWeight: 600 },
    row: { display: "flex", gap: "0.5rem", flexWrap: "wrap" },
    input: {
      border: "1px solid var(--cs-border, #94a3b8)",
      borderRadius: "0.375rem",
      boxSizing: "border-box",
      flex: "1 1 10rem",
      fontSize: "1rem",
      minHeight: "2.75rem",
      minWidth: 0,
      padding: "0.5rem 0.75rem",
    },
    button: {
      background: "var(--cs-primary-hover, #2563eb)",
      border: 0,
      borderRadius: "0.375rem",
      color: "#ffffff",
      cursor: "pointer",
      fontSize: "1rem",
      fontWeight: 700,
      minHeight: "2.75rem",
      padding: "0.5rem 1rem",
    },
    error: {
      color: "#b91c1c",
      fontSize: "0.875rem",
      fontWeight: 600,
      margin: 0,
    },
  },
  Fg = { BASE_URL: "/", DEV: !1, MODE: "production", PROD: !0, SSR: !1 },
  Wg = I.createContext(null),
  $g = I.createContext(null),
  Bg = I.createContext(null),
  Hg = I.createContext(null),
  Vg = I.createContext(null),
  Kg = I.createContext(!1),
  Tn = "comp-school-fallback-access";
function wd() {
  return typeof window > "u" || typeof document > "u"
    ? null
    : bd(document.cookie, window.location.hostname, Ha().DEV === !0);
}
function Gg(s) {
  if (typeof window > "u" || typeof document > "u") return;
  const u = ym(s);
  bd(u, window.location.hostname, Ha().DEV === !0) && (document.cookie = u);
}
function Qg() {
  typeof document > "u" || (document.cookie = vm());
}
function ya(s, u) {
  return (
    u &&
    s.role === "teacher" &&
    new URLSearchParams(window.location.search).get("preview") === "student"
  );
}
function qd() {
  if (typeof window > "u") return null;
  const s = new URLSearchParams(window.location.hash.replace(/^#/, "")),
    u = s.get("fallback");
  if (u && Ea(u)) {
    (window.sessionStorage.setItem(Tn, u), s.delete("fallback"));
    const d = s.toString();
    window.history.replaceState(
      {},
      "",
      `${window.location.pathname}${window.location.search}${d ? `#${d}` : ""}`,
    );
  }
  const l = u || window.sessionStorage.getItem(Tn);
  return Ea(l) ? l : (window.sessionStorage.removeItem(Tn), null);
}
function Zg() {
  const s = new URLSearchParams(window.location.hash.replace(/^#/, "")),
    u = s.get(Sa);
  if (u !== null) {
    s.delete(Sa);
    const l = s.toString();
    window.history.replaceState(
      {},
      "",
      `${window.location.pathname}${window.location.search}${l ? `#${l}` : ""}`,
    );
  }
  return Sm(window.sessionStorage, u);
}
function va() {
  return qd() ? (window.sessionStorage.removeItem(Tn), !0) : !1;
}
function Xd() {
  const s = qd();
  return s ? { [pm]: s } : {};
}
function wa(s) {
  (cm(s),
    lm(zn(s) && s.role === "student" ? (s.courses ?? ["j277"]) : []),
    s.role === "student" && s.aiAccess);
}
const at = {
  main: {
    alignItems: "center",
    background: "var(--cs-background, #020617)",
    color: "rgb(var(--slate-50, 255 255 255))",
    display: "flex",
    fontFamily:
      'Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
    justifyContent: "center",
    minHeight: "100vh",
    padding: "2.5rem 1rem",
  },
  panel: {
    background: "var(--cs-surface, #ffffff)",
    border: "1px solid var(--cs-border, rgba(255, 255, 255, 0.1))",
    borderRadius: "0.5rem",
    boxShadow:
      "0 25px 50px -12px rgb(var(--slate-900, 15 23 42) / 0.45), 0 12px 24px -16px rgb(var(--slate-900, 15 23 42) / 0.6)",
    color: "var(--cs-text, #020617)",
    maxWidth: "24rem",
    padding: "1.5rem",
    width: "100%",
  },
  title: {
    fontSize: "1.5rem",
    fontWeight: 700,
    lineHeight: 1.2,
    margin: "0.75rem 0 0",
  },
  copy: {
    color: "var(--cs-text-muted, #475569)",
    fontSize: "0.875rem",
    lineHeight: 1.6,
    margin: "0.5rem 0 0",
  },
  actions: { display: "grid", gap: "1rem", marginTop: "1.5rem" },
  error: { color: "#dc2626", fontSize: "0.875rem", fontWeight: 600, margin: 0 },
  link: {
    background: "var(--cs-primary-hover, #2563eb)",
    borderRadius: "0.375rem",
    color: "rgb(var(--slate-50, 255 255 255))",
    display: "block",
    fontSize: "0.875rem",
    fontWeight: 700,
    padding: "0.75rem 1rem",
    textAlign: "center",
    textDecoration: "none",
    width: "100%",
  },
};
function Ha() {
  return Fg || {};
}
function Yg(s) {
  const u = zm(window.location.hostname, s, Ha().VITE_PLATFORM_URL),
    l = `${window.location.origin}${window.location.pathname}${window.location.search}`;
  if (Pd(window.location.pathname) && _d(l)) {
    const d = new URL(u);
    return (d.searchParams.set("returnTo", l), d.toString());
  }
  return u;
}
function xa(s) {
  if (s.role !== "student") return !1;
  const u = zn(s) ? "mock" : dm(s),
    l = new URL(window.location.href);
  return kd(l.searchParams) === u
    ? !1
    : (l.searchParams.set("sql", u),
      l.searchParams.delete("source"),
      window.location.replace(l.toString()),
      !0);
}
const qg = "signedOut";
function Xg({
  appName: s,
  children: u,
  allowedRoles: l,
  navbarChildren: d,
  navbarLeading: p,
  navbarStyle: y,
  productionUrl: S,
  showNavbar: j = !0,
  laneMenuButton: k = !1,
  whileChecking: F,
  allowFallback: T = !1,
  allowTeacherStudentPreview: V = !1,
  prepare: D,
}) {
  const q = kd(new URLSearchParams(window.location.search)),
    X = I.useMemo(() => Yg(S), [S]),
    O = I.useMemo(() => fn(window.location.hostname), []),
    $ = I.useMemo(
      () => Gr(window.location.hostname, "https://issues.comp.school"),
      [],
    ),
    K = I.useMemo(() => {
      const Y = new URL(O);
      return (Y.searchParams.set("changeAvatar", "1"), Y.toString());
    }, [O]),
    ae = l ? l.join(",") : "",
    [be, ie] = I.useState(null),
    [Ae, B] = I.useState(!0),
    ee = I.useRef(D);
  ee.current = D;
  const te = () => (ee.current?.() ?? Promise.resolve()).catch(() => {}),
    [ne, le] = I.useState(!1),
    [se, Ee] = I.useState(null),
    [he, je] = I.useState(!1),
    [Fe, Le] = I.useState(null),
    [ye, R] = I.useState(null),
    [H, _] = I.useState(!1),
    [g, E] = I.useState(null),
    [Z, re] = I.useState(null),
    ue = xg(),
    de = I.useCallback((Y) => R(() => Y), []);
  async function ve() {
    const Y = se !== null;
    if (
      (zn(se) && (await Ym()),
      await fetch("/api/logout", {
        cache: "no-store",
        credentials: "same-origin",
        method: "POST",
      }).catch(() => {}),
      Ee(null),
      Qg(),
      window.sessionStorage.removeItem(Tn),
      window.sessionStorage.removeItem(ba),
      je(!1),
      le(!1),
      !Y)
    ) {
      window.location.assign(O);
      return;
    }
    const we = new URL(O);
    (we.searchParams.set(qg, "1"), window.location.assign(we.toString()));
  }
  function fe(Y) {
    const we = new URL(window.location.href);
    (we.searchParams.set("sql", Y),
      we.searchParams.delete("source"),
      we.searchParams.delete("student"),
      window.location.assign(we.toString()));
  }
  if (
    (I.useEffect(() => {
      let Y = !1,
        we = !1;
      const qe = () => {
        we = !0;
      };
      return (
        fetch("/api/session", {
          cache: "no-store",
          credentials: "same-origin",
          headers: { accept: "application/json", ...(T ? Xd() : {}) },
        })
          .then(async (He) => {
            const Pe = await He.json().catch(() => null);
            if (Y) return;
            const Lt = T && Pe?.fallback === !0;
            if (
              (T && !Lt && window.sessionStorage.removeItem(Tn),
              He.ok &&
                Pe?.ok &&
                Pe.user &&
                (!l || l.includes(Pe.user.role) || ya(Pe.user, V)))
            ) {
              if (T && va()) {
                (qe(), window.location.reload());
                return;
              }
              if (xa(Pe.user)) {
                qe();
                return;
              }
              const Mt = T && zn(Pe.user);
              if (
                Mt &&
                Pe.user.role === "student" &&
                !(Pe.user.courses ?? ["j277"]).includes("j277")
              ) {
                (qe(), window.location.replace(O));
                return;
              }
              if (
                (Mt && (await Qm(Pe.user)), Y || (wa(Pe.user), await te(), Y))
              )
                return;
              (Gg(Pe.user), ie(null), Ee(Pe.user), je(Mt), le(!0));
              return;
            }
            He.status === 401 && Wa();
            const et = wd();
            if (et && (!l || l.includes(et.role) || ya(et, V))) {
              if (T && va()) {
                (qe(), window.location.reload());
                return;
              }
              if ((ie(null), xa(et))) {
                qe();
                return;
              }
              if ((wa(et), await te(), Y)) return;
              (Ee(et), je(T && zn(et)), le(!0));
              return;
            }
            if (Lt) {
              if ((await te(), Y)) return;
              (ie(null), je(!0), le(!0));
              return;
            }
            (ie(Pe?.message || null), Ee(null), le(!1));
          })
          .catch(async () => {
            if (!Y) {
              const He = wd();
              if (He && (!l || l.includes(He.role) || ya(He, V))) {
                if (T && va()) {
                  (qe(), window.location.reload());
                  return;
                }
                if ((ie(null), xa(He))) {
                  qe();
                  return;
                }
                if ((wa(He), await te(), Y)) return;
                (Ee(He), je(T && zn(He)), le(!0));
                return;
              }
              (ie("Unable to check platform access right now."),
                Ee(null),
                le(!1));
            }
          })
          .finally(() => {
            !Y && !we && B(!1);
          }),
        () => {
          Y = !0;
        }
      );
    }, [ae, T, V]),
    !q)
  )
    return a.jsx("main", {
      style: at.main,
      children: a.jsxs("section", {
        style: at.panel,
        children: [
          a.jsx("h1", { style: at.title, children: "Database unavailable" }),
          a.jsx("p", {
            style: at.copy,
            children: "Choose Product, Mock, or Real to continue.",
          }),
          a.jsx("button", {
            style: at.link,
            onClick: () => fe("product"),
            children: "Open Product",
          }),
          a.jsx("button", {
            style: at.link,
            onClick: () => fe("mock"),
            children: "Open Mock",
          }),
          a.jsx("button", {
            style: at.link,
            onClick: () => fe("real"),
            children: "Open Real",
          }),
        ],
      }),
    });
  if (Ae) return a.jsxs(a.Fragment, { children: [F, a.jsx(Pg, {})] });
  if (ne) {
    const Y = he && !se ? Zg() : void 0,
      we = se?.role === "admin" || se?.role === "teacher",
      qe = new URL(O);
    we && qe.searchParams.set("sql", q);
    const He = {
        canChangeAvatar: se?.role === "student" || !!Y,
        changeAvatarHref: Y ? Ed(K, Y) : K,
        dataSource: we ? q : void 0,
        feedbackWelcomeInstead: he,
        onDataSourceChange: we ? fe : void 0,
        onSignOut: ve,
        profileAvatar: se?.role === "student" ? (se.avatar ?? xm(se.id)) : Y,
        profileName: se?.name || "Anonymous",
        reportIssueHref: he ? void 0 : $,
      },
      Pe = typeof p == "function",
      Lt = he && Pe,
      et = !j && k && Pe,
      Mt = j || et,
      or = Mt && (se || he) && !et && !(Lt && ue) ? Z : null;
    return a.jsxs(a.Fragment, {
      children: [
        Mt && (se || he)
          ? a.jsx(Ng, {
              ...He,
              appName: s,
              backHref: qe.toString(),
              breadcrumbNavigation: H,
              contextLabel: Fe,
              hideAccountMenu: Pe,
              leading: typeof p == "function" ? p(He) : p,
              onBack: ye ? () => ye() : void 0,
              phoneBar: et ? "bare" : Lt ? "band" : void 0,
              phoneBarSlotRef: E,
              actionsSlotRef: re,
              style: y,
              children: d,
            })
          : null,
        he && !se ? a.jsx(Ug, { storageKey: Tn }) : null,
        zn(se) ? a.jsx(zg, {}) : null,
        a.jsx(Kg.Provider, {
          value: he,
          children: a.jsxs(Vg.Provider, {
            value: se,
            children: [
              a.jsx(Ah, { user: se }),
              a.jsx(eg, { user: se }),
              a.jsx(Wg.Provider, {
                value: Le,
                children: a.jsx($g.Provider, {
                  value: de,
                  children: a.jsx(Bg.Provider, {
                    value: _,
                    children: a.jsx(kg.Provider, {
                      value: g,
                      children: a.jsx(Hg.Provider, { value: or, children: u }),
                    }),
                  }),
                }),
              }),
            ],
          }),
        }),
      ],
    });
  }
  return a.jsx("main", {
    style: at.main,
    children: a.jsxs("section", {
      style: at.panel,
      children: [
        a.jsx(Yd, {
          size: "small",
          style: { color: "rgb(var(--slate-900, 15 23 42))" },
        }),
        a.jsx("h1", { style: at.title, children: s }),
        a.jsx("p", {
          style: at.copy,
          children: "Open comp.school and sign in to continue.",
        }),
        a.jsxs("div", {
          style: at.actions,
          children: [
            be && a.jsx("p", { style: at.error, children: be }),
            a.jsx("a", {
              "aria-label": `Open comp.school to access ${s}`,
              href: X,
              style: at.link,
              children: "Open comp.school",
            }),
          ],
        }),
      ],
    }),
  });
}
const Jg = [
  { value: "exams", label: "Exams" },
  { value: "recall", label: "Recall" },
  { value: "marking", label: "Marking" },
  { value: "coding", label: "Coding" },
  { value: "analytics", label: "Analytics" },
];
function ey({ onChange: s, value: u }) {
  return a.jsxs("fieldset", {
    className: "grid grid-cols-2 gap-1 rounded-2xl bg-[#f1f0ed] p-1",
    children: [
      a.jsx("legend", { className: "sr-only", children: "Report type" }),
      ["bug", "feature"].map((l) =>
        a.jsx(
          "button",
          {
            type: "button",
            "aria-pressed": u === l,
            onClick: () => s(l),
            className: `rounded-xl px-4 py-2.5 text-sm font-semibold transition ${u === l ? "bg-white text-[#20231f] shadow-sm" : "text-[#737770] hover:text-[#363a35]"}`,
            children: l === "bug" ? "Report a bug" : "Request a feature",
          },
          l,
        ),
      ),
    ],
  });
}
function ty({ onChange: s, value: u }) {
  return a.jsxs("fieldset", {
    className: "mt-5 px-1",
    children: [
      a.jsxs("div", {
        className: "flex items-baseline justify-between gap-4",
        children: [
          a.jsx("legend", {
            className: "text-sm font-semibold",
            children: "Which app?",
          }),
          a.jsx("span", {
            className: "text-xs text-slate-500",
            children: "Optional",
          }),
        ],
      }),
      a.jsx("div", {
        className: "mt-2 flex flex-wrap gap-2",
        children: Jg.map((l) =>
          a.jsx(
            "button",
            {
              type: "button",
              "aria-pressed": u === l.value,
              onClick: () => s(u === l.value ? null : l.value),
              className: `rounded-full border px-3.5 py-2 text-sm font-medium transition ${u === l.value ? "border-[#315e3f] bg-[#eaf3ec] text-[#285438]" : "border-black/[0.08] bg-white text-[#656a63] hover:border-black/20 hover:text-[#2d312d]"}`,
              children: l.label,
            },
            l.value,
          ),
        ),
      }),
    ],
  });
}
const ny = new Set(["image/png", "image/jpeg"]),
  ka = 5,
  ry = 8 * 1024 * 1024;
function oy() {
  return a.jsxs("svg", {
    viewBox: "0 0 24 24",
    "aria-hidden": "true",
    className: "h-5 w-5",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "1.8",
    children: [
      a.jsx("rect", { x: "3", y: "4", width: "18", height: "16", rx: "3" }),
      a.jsx("circle", { cx: "8.5", cy: "9", r: "1.5" }),
      a.jsx("path", { d: "m5 18 4.5-4.5 3 3 2.2-2.2L19 18" }),
    ],
  });
}
function iy() {
  return a.jsx("svg", {
    viewBox: "0 0 24 24",
    "aria-hidden": "true",
    className: "h-5 w-5",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    children: a.jsx("path", {
      d: "M12 19V5m0 0-6 6m6-6 6 6",
      strokeLinecap: "round",
      strokeLinejoin: "round",
    }),
  });
}
function sy() {
  return a.jsx("svg", {
    viewBox: "0 0 24 24",
    "aria-hidden": "true",
    className: "h-7 w-7",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2.2",
    children: a.jsx("path", {
      d: "m5 12 4.5 4.5L19 7",
      strokeLinecap: "round",
      strokeLinejoin: "round",
    }),
  });
}
function ay() {
  return a.jsxs("svg", {
    viewBox: "0 0 24 24",
    "aria-hidden": "true",
    className: "h-5 w-5",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "1.8",
    children: [
      a.jsx("rect", { x: "4", y: "4", width: "6", height: "6", rx: "1.5" }),
      a.jsx("rect", { x: "14", y: "4", width: "6", height: "6", rx: "1.5" }),
      a.jsx("rect", { x: "4", y: "14", width: "6", height: "6", rx: "1.5" }),
      a.jsx("rect", { x: "14", y: "14", width: "6", height: "6", rx: "1.5" }),
    ],
  });
}
function ly() {
  const [s, u] = I.useState("bug"),
    [l, d] = I.useState(null),
    [p, y] = I.useState(""),
    [S, j] = I.useState([]),
    [k, F] = I.useState(""),
    [T, V] = I.useState(!1),
    [D, q] = I.useState(null),
    X = I.useRef(null),
    O = I.useRef([]);
  (I.useEffect(() => {
    O.current = S;
  }, [S]),
    I.useEffect(
      () => () => O.current.forEach((B) => URL.revokeObjectURL(B.previewUrl)),
      [],
    ));
  function $(B) {
    if ((F(""), B.find((ne) => !ny.has(ne.type)))) {
      F("Only PNG and JPEG images can be attached.");
      return;
    }
    if (B.find((ne) => ne.size > ry)) {
      F("Each image must be smaller than 8 MB.");
      return;
    }
    if (S.length + B.length > ka) {
      F(`You can attach up to ${ka} images.`);
      return;
    }
    j((ne) => [
      ...ne,
      ...B.map((le) => ({
        id: `${le.name}-${le.size}-${crypto.randomUUID()}`,
        file: le,
        previewUrl: URL.createObjectURL(le),
      })),
    ]);
  }
  function K(B) {
    ($(Array.from(B.target.files ?? [])), (B.target.value = ""));
  }
  function ae(B) {
    const ee = Array.from(B.clipboardData.items)
      .filter((te) => te.kind === "file")
      .map((te) => te.getAsFile())
      .filter((te) => !!te);
    ee.length && (B.preventDefault(), $(ee));
  }
  function be(B) {
    j((ee) => {
      const te = ee.find((ne) => ne.id === B);
      return (
        te && URL.revokeObjectURL(te.previewUrl),
        ee.filter((ne) => ne.id !== B)
      );
    });
  }
  function ie() {
    (S.forEach((B) => URL.revokeObjectURL(B.previewUrl)),
      u("bug"),
      d(null),
      y(""),
      j([]),
      F(""),
      q(null));
  }
  async function Ae(B) {
    B.preventDefault();
    const ee = p.trim();
    if (ee.length < 3) {
      F("Please add a little more detail before sending.");
      return;
    }
    (F(""), V(!0));
    const te = new FormData();
    (te.set("kind", s),
      te.set("description", ee),
      l && te.set("app", l),
      S.forEach((ne) => te.append("images", ne.file, ne.file.name)));
    try {
      const ne = await fetch("/api/report", {
          method: "POST",
          headers: Xd(),
          body: te,
          credentials: "same-origin",
        }),
        le = await ne.json().catch(() => null);
      if (!ne.ok || !le?.ok || !le.issue)
        throw new Error(
          le?.message || "Your issue could not be sent. Please try again.",
        );
      q(le.issue);
    } catch (ne) {
      F(
        ne instanceof Error
          ? ne.message
          : "Your issue could not be sent. Please try again.",
      );
    } finally {
      V(!1);
    }
  }
  return D
    ? a.jsx("main", {
        className:
          "grid min-h-screen place-items-center bg-[#f6f5f2] px-6 py-12 text-[#1d201d]",
        children: a.jsxs("section", {
          className:
            "w-full max-w-lg rounded-[2rem] border border-black/[0.06] bg-white px-8 py-12 text-center shadow-[0_24px_70px_rgba(44,45,39,0.10)] sm:px-12",
          children: [
            a.jsx("div", {
              className:
                "mx-auto grid h-16 w-16 place-items-center rounded-full bg-[#e5f4e8] text-[#26753d]",
              children: a.jsx(sy, {}),
            }),
            a.jsx("p", {
              className:
                "mt-7 text-sm font-semibold uppercase tracking-[0.18em] text-[#26753d]",
              children: "Sent successfully",
            }),
            a.jsx("h1", {
              className: "mt-3 text-3xl font-semibold tracking-[-0.035em]",
              children: "Your issue has been sent",
            }),
            a.jsxs("p", {
              className:
                "mx-auto mt-4 max-w-sm text-base leading-7 text-slate-600",
              children: [
                "Thanks for helping us improve comp.school. Ticket #",
                D.number,
                " is ready for the team to review.",
              ],
            }),
            a.jsxs("div", {
              className: "mt-8 flex flex-col justify-center gap-3 sm:flex-row",
              children: [
                a.jsx("button", {
                  type: "button",
                  onClick: ie,
                  className:
                    "rounded-full bg-[#1e211e] px-5 py-3 text-sm font-semibold text-white transition hover:bg-black",
                  children: "Send another",
                }),
                a.jsx("a", {
                  href: "https://comp.school",
                  "aria-label": "Back to comp.school menu",
                  title: "Back to menu",
                  className:
                    "grid h-11 w-11 place-items-center self-center rounded-full border border-black/10 text-[#353935] transition hover:bg-[#f6f5f2]",
                  children: a.jsx(ay, {}),
                }),
              ],
            }),
          ],
        }),
      })
    : a.jsx("main", {
        className: "min-h-screen bg-[#f6f5f2] text-[#1d201d]",
        children: a.jsxs("div", {
          className:
            "mx-auto flex min-h-screen w-full max-w-3xl flex-col px-5 py-8 sm:px-8 sm:py-12",
          children: [
            a.jsx("header", { className: "flex items-center justify-between" }),
            a.jsxs("section", {
              className: "my-auto py-12 sm:py-16",
              children: [
                a.jsxs("div", {
                  className: "mb-8 text-center",
                  children: [
                    a.jsx("h1", {
                      className:
                        "mx-auto mt-3 max-w-xl text-4xl font-semibold tracking-[-0.045em] sm:text-5xl",
                      children: "What would you like to see improved?",
                    }),
                    a.jsx("p", {
                      className:
                        "mx-auto mt-4 max-w-lg text-base leading-7 text-slate-500",
                      children:
                        "Report something that is not working or share an idea. A screenshot often tells the story fastest.",
                    }),
                  ],
                }),
                a.jsxs("form", {
                  onSubmit: Ae,
                  className:
                    "rounded-[1.75rem] border border-black/[0.07] bg-white p-3 shadow-[0_22px_65px_rgba(42,43,38,0.09)] sm:p-4",
                  children: [
                    a.jsx(ey, { onChange: u, value: s }),
                    a.jsx(ty, { onChange: d, value: l }),
                    a.jsxs("div", {
                      className:
                        "mt-5 rounded-2xl border border-black/[0.09] bg-[#fbfbfa] p-3 focus-within:border-[#60806a] focus-within:ring-4 focus-within:ring-[#60806a]/10",
                      children: [
                        S.length > 0 &&
                          a.jsx("div", {
                            className: "mb-3 flex gap-2 overflow-x-auto pb-1",
                            "aria-label": "Attached images",
                            children: S.map((B) =>
                              a.jsxs(
                                "div",
                                {
                                  className:
                                    "group relative h-20 w-20 shrink-0 overflow-hidden rounded-xl border border-black/10 bg-white",
                                  children: [
                                    a.jsx("img", {
                                      src: B.previewUrl,
                                      alt: B.file.name || "Pasted screenshot",
                                      className: "h-full w-full object-cover",
                                    }),
                                    a.jsx("button", {
                                      type: "button",
                                      onClick: () => be(B.id),
                                      "aria-label": `Remove ${B.file.name || "image"}`,
                                      className:
                                        "absolute right-1 top-1 grid h-6 w-6 place-items-center rounded-full bg-black/70 text-base leading-none text-white opacity-100 transition sm:opacity-0 sm:group-hover:opacity-100 sm:group-focus-within:opacity-100",
                                      children: "×",
                                    }),
                                  ],
                                },
                                B.id,
                              ),
                            ),
                          }),
                        a.jsx("label", {
                          htmlFor: "issue-description",
                          className: "sr-only",
                          children: "Describe the issue or idea",
                        }),
                        a.jsx("textarea", {
                          id: "issue-description",
                          value: p,
                          onChange: (B) => y(B.target.value),
                          onPaste: ae,
                          maxLength: 1e4,
                          rows: 6,
                          placeholder:
                            s === "bug"
                              ? "Tell us what happened, what you expected, and how to reproduce it…"
                              : "Describe your idea and how it would help…",
                          className:
                            "block min-h-36 w-full resize-none bg-transparent px-1 py-1 text-base leading-7 text-[#252824] outline-none placeholder:text-[#9a9d97]",
                        }),
                        a.jsxs("div", {
                          className:
                            "mt-2 flex items-center justify-between gap-3",
                          children: [
                            a.jsxs("div", {
                              className: "flex items-center gap-2",
                              children: [
                                a.jsx("input", {
                                  ref: X,
                                  type: "file",
                                  accept: "image/png,image/jpeg",
                                  multiple: !0,
                                  onChange: K,
                                  className: "sr-only",
                                }),
                                a.jsx("button", {
                                  type: "button",
                                  onClick: () => X.current?.click(),
                                  disabled: S.length >= ka,
                                  "aria-label": "Attach images",
                                  className:
                                    "grid h-10 w-10 place-items-center rounded-full border border-black/[0.08] bg-white text-[#555a54] transition hover:bg-[#f0efec] disabled:cursor-not-allowed disabled:opacity-40",
                                  children: a.jsx(oy, {}),
                                }),
                                a.jsx("span", {
                                  className:
                                    "hidden text-xs text-slate-500 sm:inline",
                                  children:
                                    "Paste an image with Ctrl+V · PNG or JPEG",
                                }),
                              ],
                            }),
                            a.jsx("button", {
                              type: "submit",
                              disabled: T || p.trim().length < 3,
                              "aria-label": "Send issue",
                              className:
                                "grid h-10 w-10 place-items-center rounded-full bg-[#1e211e] text-white transition hover:bg-black disabled:cursor-not-allowed disabled:bg-slate-300",
                              children: T
                                ? a.jsx("span", {
                                    className:
                                      "h-4 w-4 animate-spin rounded-full border-2 border-white/40 border-t-white",
                                  })
                                : a.jsx(iy, {}),
                            }),
                          ],
                        }),
                      ],
                    }),
                    a.jsx("div", {
                      "aria-live": "polite",
                      className: "min-h-7 px-2 pt-2",
                      children: k
                        ? a.jsx("p", {
                            className: "text-sm font-medium text-[#ad342d]",
                            children: k,
                          })
                        : a.jsx("p", {
                            className: "text-xs text-slate-400",
                            children:
                              "Images are uploaded to ImageKit and included with your ticket.",
                          }),
                    }),
                  ],
                }),
              ],
            }),
          ],
        }),
      });
}
sm.createRoot(document.getElementById("root")).render(
  a.jsx(Jp.StrictMode, {
    children: a.jsx(Xg, {
      appName: "Issues",
      allowFallback: !0,
      allowedRoles: ["admin", "teacher", "student"],
      productionUrl: "https://issues.comp.school",
      children: a.jsx(ly, {}),
    }),
  }),
);
