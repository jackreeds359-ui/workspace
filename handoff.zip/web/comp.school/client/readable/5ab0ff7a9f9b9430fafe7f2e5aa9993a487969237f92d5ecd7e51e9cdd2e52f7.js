import { j as e, r as g } from "./react-vendor-BK1G6oO1.js";
import {
  c7 as He,
  bW as he,
  bZ as De,
  ae as qe,
  P as de,
  c8 as xe,
  b6 as K,
  bm as J,
  R as fe,
  a2 as Ge,
  a5 as Ke,
} from "./index-DjyiOHey.js";
import { aq as Je, aT as Ve } from "./GameNotebook-b0Qw2wzd.js";
import { T as Ye } from "./action-styles-DWMwPIR0.js";
import { m as I } from "./proxy-DGk2Wawc.js";
import "./ui-components-DeMDYLzO.js";
const _ = ["clock", "cores", "cache"],
  Q = { clock: "Clock speed", cores: "Number of cores", cache: "Cache size" },
  Qe = {
    clock:
      "The number of fetch-execute cycles the CPU carries out each second. 3 GHz is 3 billion cycles a second.",
    cores:
      "Each core processes instructions on its own, so more cores process more instructions at the same time.",
    cache:
      "Small, fast memory in the CPU that holds frequently used data and instructions, so there are fewer slower fetches from RAM.",
  },
  v = { clock: [2, 2.5, 3, 3.5, 4], cores: [1, 2, 4, 8], cache: [2, 4, 8, 16] },
  me = { clock: 40, cores: 60, cache: 30 };
function R(t) {
  return {
    clock: v.clock[t.clock],
    cores: v.cores[t.cores],
    cache: v.cache[t.cache],
  };
}
function A(t, s) {
  return t === "clock"
    ? `${s} GHz`
    : t === "cache"
      ? `${s} MB`
      : `${s} ${s === 1 ? "core" : "cores"}`;
}
const se = 0.95,
  Xe = 0.5;
function Ze(t, s) {
  const r = Math.min(s.cores, t.maxCores),
    l = (t.instructions * (1 - t.parallel + t.parallel / r)) / s.clock,
    o = s.cache >= t.reusedMb ? se : (se * s.cache) / t.reusedMb,
    i = t.instructions * t.fetchShare * (1 - o) * Xe;
  return { seconds: et(l + i), coresUsed: r, cacheHits: o };
}
function et(t) {
  return Math.round(t * 10) / 10;
}
const tt = [
  {
    id: "flight-sim",
    look: "gamer",
    customer: "Priya",
    role: "Plays a 3D flight simulator",
    problem:
      "My flight simulator stutters on the landing approach. The game says it can share its work across 4 cores.",
    task: "Fly the airport approach",
    software: "the flight simulator",
    workload: {
      instructions: 60,
      parallel: 0.85,
      maxCores: 4,
      reusedMb: 4,
      fetchShare: 0.2,
    },
    start: { clock: 1, cores: 1, cache: 1 },
    budget: 130,
    target: 8.5,
    focus: ["cores", "clock"],
    lesson:
      "The game splits its work between 4 cores, so going from 2 to 4 cores lets more instructions be processed at the same time. It is not written to use more than 4, so an 8-core CPU would leave cores idle. Spend what is left on clock speed.",
    followUp: {
      kind: "choice",
      prompt:
        "When running a 3D flight simulator, Computer 1 is likely to run faster than Computer 2. Using the information in Fig. 1, identify one reason for this.",
      table: {
        headers: ["Computer 1", "Computer 2"],
        rows: [
          ["Clock Speed: 1 GHz", "Clock Speed: 1.4 GHz"],
          ["Cache size: 2 MB", "Cache size: 2 MB"],
          ["Number of Cores: 4", "Number of Cores: 2"],
        ],
      },
      answer: "Computer 1 has more cores",
      wrong: [
        "Computer 1 has a higher clock speed",
        "Computer 1 has a larger cache",
        "Computer 1’s cache can hold more data",
      ],
      why: "Computer 1 has 4 cores and Computer 2 has 2, so Computer 1 can share the simulator’s work across more cores. Its clock speed is lower and the cache sizes are the same, so cores is the only reason in Fig. 1.",
    },
  },
  {
    id: "video-export",
    look: "editor",
    customer: "Jamal",
    role: "Edits wedding videos",
    problem:
      "Exporting a wedding video takes nearly a minute. The editing software splits the export across every core it is given.",
    task: "Export the wedding video",
    software: "the video editor",
    workload: {
      instructions: 300,
      parallel: 0.95,
      maxCores: 8,
      reusedMb: 8,
      fetchShare: 0.1,
    },
    start: { clock: 2, cores: 1, cache: 2 },
    budget: 130,
    target: 20,
    focus: ["cores"],
    lesson:
      "Exporting video splits into many separate parts, so more cores process more instructions at the same time. More cores was faster, but not that many times faster: some of the work still has to happen one step after another, so it cannot be split between cores.",
    followUp: {
      kind: "choice",
      prompt:
        "Jamal doubles the number of cores in his CPU. Explain why his video may not export twice as fast.",
      answer:
        "Some tasks depend on others finishing first, so not all of the work can be split between the cores",
      wrong: [
        "Each core runs at half the clock speed when the cores are doubled",
        "Doubling the cores halves the size of the cache",
        "The extra cores have to fetch every instruction from secondary storage",
      ],
      why: "Doubling the number of cores does not double performance. Some tasks depend on the result of another task, so they cannot be processed at the same time, and some software is not written to use more cores.",
    },
  },
  {
    id: "office-register",
    look: "office",
    customer: "Mrs Shah",
    role: "Runs the school office",
    problem:
      "Our attendance program crawls every morning. It is an old program that was written to use only one core.",
    task: "Load the morning register",
    software: "the attendance program",
    workload: {
      instructions: 40,
      parallel: 0,
      maxCores: 1,
      reusedMb: 2,
      fetchShare: 0.2,
    },
    start: { clock: 0, cores: 2, cache: 0 },
    budget: 160,
    target: 12,
    focus: ["clock"],
    lesson:
      "The program only uses one core, so extra cores sit idle. A higher clock speed means more fetch-execute cycles per second, so that one core processes more instructions every second.",
    followUp: {
      kind: "choice",
      prompt:
        "The office CPU’s clock speed is increased. State what is meant by clock speed.",
      answer:
        "The number of fetch-execute cycles the CPU carries out each second",
      wrong: [
        "The number of instructions the CPU can store at once",
        "The number of cores that can work at the same time",
        "How quickly data is saved to secondary storage",
      ],
      why: "Clock speed is the number of fetch-execute cycles per second, measured in hertz. 4 GHz is 4 billion cycles per second, so more instructions are processed every second. A lower clock speed means fewer cycles per second, so instructions are processed more slowly.",
    },
  },
  {
    id: "results-spreadsheet",
    look: "teacher",
    customer: "Mr Okafor",
    role: "Head of year",
    problem:
      "My exam results spreadsheet works through the same 16 MB table of marks again and again. Every recalculation leaves me waiting. It only uses 2 cores.",
    task: "Recalculate the results spreadsheet",
    software: "the spreadsheet",
    workload: {
      instructions: 40,
      parallel: 0.5,
      maxCores: 2,
      reusedMb: 16,
      fetchShare: 1,
    },
    start: { clock: 2, cores: 1, cache: 0 },
    budget: 100,
    target: 15,
    focus: ["cache"],
    lesson:
      "The spreadsheet uses the same data over and over. A larger cache holds more of that frequently used data close to the CPU, and cache is faster to access than RAM, so the CPU spends less time waiting.",
    followUp: {
      kind: "choice",
      prompt:
        "Explain one reason why the cache size affects the performance of the CPU.",
      answer:
        "A larger cache can hold more frequently used data and instructions, and it is faster to transfer data to and from cache than to and from RAM",
      wrong: [
        "A larger cache lets the CPU carry out more fetch-execute cycles every second",
        "A larger cache keeps the spreadsheet saved when the power is turned off",
        "A larger cache splits the instructions between more cores",
      ],
      why: "Cache is small, fast memory that holds frequently used data and instructions. Transferring data to and from cache is faster than to and from RAM, so with a larger cache the CPU fetches from RAM less often and is more efficient.",
    },
  },
  {
    id: "chess-coach",
    look: "chess",
    customer: "Ola",
    role: "Captain of the chess club",
    problem:
      "My chess app is slow to suggest a move. It works out each step from the result of the step before.",
    task: "Suggest the best move",
    software: "the chess app",
    workload: {
      instructions: 60,
      parallel: 0.2,
      maxCores: 8,
      reusedMb: 4,
      fetchShare: 0.3,
    },
    start: { clock: 1, cores: 1, cache: 1 },
    budget: 120,
    target: 16,
    focus: ["clock"],
    lesson:
      "Each step depends on the result of the one before, so most of the work cannot be processed at the same time on different cores. A higher clock speed processes every one of those steps faster.",
    followUp: {
      kind: "choice",
      prompt:
        "Explain why a CPU with more cores may not make the chess app run faster.",
      answer:
        "Each step depends on the result of the step before, so the steps cannot be processed at the same time",
      wrong: [
        "More cores lower the clock speed of the CPU",
        "More cores mean less data fits in the cache",
        "Each core has to wait for the hard disk before it can start",
      ],
      why: "Extra cores only help when work can be split up and processed at the same time. When a task depends on another task finishing first, the cores cannot share it, so performance does not improve much.",
    },
  },
  {
    id: "physics-lab",
    look: "scientist",
    customer: "Dr Reid",
    role: "Runs the science lab",
    problem:
      "Our particle simulation splits across all the cores, and it uses the same 8 MB block of particle data again and again. It needs to be much quicker for lessons.",
    task: "Run the particle simulation",
    software: "the simulation",
    workload: {
      instructions: 120,
      parallel: 0.9,
      maxCores: 8,
      reusedMb: 8,
      fetchShare: 0.5,
    },
    start: { clock: 2, cores: 1, cache: 0 },
    budget: 170,
    target: 15,
    focus: ["cores", "cache"],
    lesson:
      "This job needs characteristics in combination. More cores share the simulation, but each core still waits for data from RAM unless the frequently used particle data fits in the cache. Upgrading cores and cache size together gives a big improvement.",
    followUp: {
      kind: "pick-two",
      prompt:
        "Identify two other parts of a computer, not the CPU, which could improve the performance of the lab’s computer.",
      answers: ["RAM", "Graphics card (GPU)", "Solid state drive (SSD)"],
      wrong: ["Keyboard", "Printer", "Mouse"],
      why: "RAM, an SSD or a graphics card (GPU) can all improve performance. A keyboard, printer and mouse are input and output devices: they do not make the computer process faster.",
    },
  },
];
function B(t, s) {
  return _.reduce((r, a) => r + Math.max(0, s[a] - t.start[a]) * me[a], 0);
}
function Y(t, s, r, a) {
  const l = s[r] + a;
  return l < t.start[r] || l >= v[r].length
    ? !1
    : a === 1
      ? B(t, { ...s, [r]: l }) <= t.budget
      : !0;
}
function w(t, s) {
  return Ze(t.workload, R(s));
}
function st(t) {
  const s = [];
  for (let r = t.start.clock; r < v.clock.length; r += 1)
    for (let a = t.start.cores; a < v.cores.length; a += 1)
      for (let l = t.start.cache; l < v.cache.length; l += 1) {
        const o = { clock: r, cores: a, cache: l };
        B(t, o) <= t.budget && s.push(o);
      }
  return s;
}
function ue(t) {
  let s = t.start,
    r = w(t, s).seconds;
  for (const a of st(t)) {
    const l = w(t, a).seconds;
    (l < r || (l === r && B(t, a) < B(t, s))) && ((s = a), (r = l));
  }
  return s;
}
function rt(t, s) {
  const r = w(t, s).seconds,
    a = w(t, ue(t)).seconds;
  return r <= t.target && r <= a * 1.05
    ? 3
    : r <= t.target
      ? 2
      : r < w(t, t.start).seconds * 0.9
        ? 1
        : 0;
}
const pe = 10,
  X = 10,
  je = 10;
function at(t, s) {
  const r = R(t.start),
    a = R(s),
    l = w(t, t.start).seconds,
    o = [];
  for (const i of _) {
    if (s[i] === t.start[i]) continue;
    const d = w(t, { ...t.start, [i]: s[i] }).seconds,
      c = l - d,
      n = r[i],
      x = a[i];
    let h,
      u = c >= l * 0.15 ? "helped" : c > 0 ? "small" : "wasted";
    (i === "clock"
      ? (h = `${x} billion fetch-execute cycles per second instead of ${n} billion, so instructions are processed faster.`)
      : i === "cores"
        ? n >= t.workload.maxCores
          ? ((u = "wasted"),
            (h = `${re(t.software)} is written to use ${t.workload.maxCores === 1 ? "only one core" : `${t.workload.maxCores} cores`}, so the extra cores sat idle.`))
          : x > t.workload.maxCores
            ? (h = `${re(t.software)} is written to use ${t.workload.maxCores} cores, so ${x - t.workload.maxCores} of the ${x} cores sat idle.`)
            : t.workload.parallel < 0.5
              ? (h =
                  "Most of the work depends on the step before, so it cannot be split between cores and processed at the same time.")
              : (h = `${x} cores process instructions at the same time. It is not ${x / n} times as fast, because some work cannot be split between cores.`)
        : n >= t.workload.reusedMb
          ? ((u = "wasted"),
            (h =
              "The frequently used data and instructions already fitted in the old cache, so the extra cache made no difference."))
          : (h =
              x >= t.workload.reusedMb
                ? "All the frequently used data and instructions now fit in cache, so the CPU rarely has to fetch from slower RAM."
                : "More of the frequently used data and instructions fit in cache, so there are fewer slower fetches from RAM."),
      o.push({ trait: i, from: n, to: x, alone: d, effect: u, why: h }));
  }
  return o;
}
function re(t) {
  return t.charAt(0).toUpperCase() + t.slice(1);
}
function ae(t, s) {
  const r = [...t];
  for (let a = r.length - 1; a > 0; a -= 1) {
    const l = Math.floor(s() * (a + 1));
    [r[a], r[l]] = [r[l], r[a]];
  }
  return r;
}
const ge = 5;
function lt(t = Math.random) {
  return ae(tt, t)
    .slice(0, ge)
    .map((s) => ({
      job: s,
      options: ae(
        s.followUp.kind === "choice"
          ? [s.followUp.answer, ...s.followUp.wrong]
          : [...s.followUp.answers, ...s.followUp.wrong],
        t,
      ),
    }));
}
function it(t, s) {
  const r = t.followUp;
  return r.kind === "choice"
    ? s.length === 1 && s[0] === r.answer
    : s.length === 2 &&
        new Set(s).size === 2 &&
        s.every((a) => r.answers.includes(a));
}
const U = {
    prompt:
      "A computer has a Central Processing Unit (CPU). Give three characteristics of a CPU that can affect its performance.",
    marks: 3,
    guidance:
      "Clock speed, cache size and number of cores. ‘Clock’, ‘cache’, ‘speed’ or ‘cores’ on their own are not enough.",
  },
  ot = {
    clock: /\bclock\s*(speed|rate|frequency)\b|\bspeed of (the )?clock\b/,
    cache:
      /\b(cache|cash)\s*(memory\s*)?(size|capacity)\b|\b(size|capacity|amount) of (the )?(cache|cash)\b/,
    cores:
      /\b(number|no\.?|amount|count) of (processor |processing |cpu )?cores\b|\bcore count\b|\bhow many cores\b/,
  };
function ct(t) {
  const s = t.toLowerCase().replace(/[-_]/g, " ").replace(/\s+/g, " ").trim();
  return _.filter((r) => ot[r].test(s));
}
function nt(t) {
  const s = new Set(),
    r = t.map((a) => ct(a).filter((l) => (s.has(l) ? !1 : (s.add(l), !0))));
  return { marks: s.size, credited: r };
}
function ht(t) {
  return t.stars * pe + t.followUps * X + t.examMarks * je;
}
const ye = ge * (3 * pe + X) + U.marks * je;
function dt(t) {
  const s = t / ye;
  return s >= 0.9
    ? "Workshop chief"
    : s >= 0.7
      ? "Senior technician"
      : s >= 0.45
        ? "Technician"
        : "Apprentice";
}
const xt = {
    1: { cols: 1, rows: 1 },
    2: { cols: 2, rows: 1 },
    4: { cols: 2, rows: 2 },
    8: { cols: 4, rows: 2 },
  },
  y = { x: 112, y: 36, w: 136, h: 164 },
  D = { x: y.x + 10, y: y.y + 12, w: y.w - 20, h: 92 },
  S = { x: y.x + 10, y: y.y + 112, w: y.w - 20, h: 32 },
  le = "M288 170H238";
function be({ specs: t, run: s, focus: r, animate: a = !1, className: l }) {
  const o = xt[t.cores] ?? { cols: 4, rows: 2 },
    i = 6,
    d = (D.w - i * (o.cols - 1)) / o.cols,
    c = (D.h - i * (o.rows - 1)) / o.rows,
    n = (v.cache.indexOf(t.cache) + 1) / v.cache.length,
    x = s ? Math.round((1 - s.cacheHits) * 6) : 0,
    h = { "--ub-tick": `${(1.6 / t.clock).toFixed(2)}s` },
    u = `CPU: ${A("clock", t.clock)}, ${A("cores", t.cores)}, ${A("cache", t.cache)} cache${s && s.coresUsed < t.cores ? `. ${t.cores - s.coresUsed} cores idle` : ""}`;
  return e.jsxs("svg", {
    viewBox: "0 0 360 236",
    className: l,
    role: "img",
    "aria-label": u,
    "data-cpu-board": !0,
    "data-running": s ? "true" : void 0,
    style: h,
    children: [
      e.jsx("rect", { width: 360, height: 236, rx: 14, fill: "#064e3b" }),
      e.jsxs("g", {
        stroke: "#10b981",
        strokeOpacity: 0.25,
        strokeWidth: 2,
        fill: "none",
        children: [
          e.jsx("path", { d: "M0 30h60l20 20v120l-20 20H0" }),
          e.jsx("path", { d: "M360 214h-60l-14-14" }),
          e.jsx("path", { d: "M60 236v-20l14-14h40" }),
          e.jsx("path", { d: "M250 20h40l14 14" }),
        ],
      }),
      [20, 340].map((f) =>
        [20, 216].map((m) =>
          e.jsx(
            "circle",
            {
              cx: f,
              cy: m,
              r: 5,
              fill: "#022c22",
              stroke: "#a7f3d0",
              strokeOpacity: 0.4,
            },
            `${f}-${m}`,
          ),
        ),
      ),
      e.jsxs("g", {
        "data-board-part": "clock",
        className: r === "clock" ? "ub-focus" : void 0,
        children: [
          e.jsx("path", {
            d: "M84 118h28",
            stroke: "#fbbf24",
            strokeWidth: 2,
            strokeOpacity: 0.6,
          }),
          e.jsx("rect", {
            x: 22,
            y: 98,
            width: 62,
            height: 40,
            rx: 20,
            fill: "#cbd5e1",
            stroke: "#f8fafc",
            strokeWidth: 2,
          }),
          e.jsx("circle", {
            cx: 53,
            cy: 118,
            r: 9,
            fill: "#fbbf24",
            className: s && a ? "ub-tick" : void 0,
          }),
          e.jsx("text", {
            x: 53,
            y: 158,
            textAnchor: "middle",
            className: "ub-board-label",
            children: "Clock",
          }),
          e.jsx("text", {
            x: 53,
            y: 174,
            textAnchor: "middle",
            className: "ub-board-value",
            children: A("clock", t.clock),
          }),
        ],
      }),
      e.jsxs("g", {
        "data-board-part": "ram",
        children: [
          [288, 314].map((f) =>
            e.jsxs(
              "g",
              {
                children: [
                  e.jsx("rect", {
                    x: f,
                    y: 44,
                    width: 18,
                    height: 130,
                    rx: 2,
                    fill: "#1e3a8a",
                    stroke: "#93c5fd",
                    strokeWidth: 1.5,
                  }),
                  [0, 1, 2, 3].map((m) =>
                    e.jsx(
                      "rect",
                      {
                        x: f + 4,
                        y: 54 + m * 29,
                        width: 10,
                        height: 20,
                        rx: 1,
                        fill: "#0f172a",
                      },
                      m,
                    ),
                  ),
                ],
              },
              f,
            ),
          ),
          e.jsx("text", {
            x: 310,
            y: 194,
            textAnchor: "middle",
            className: "ub-board-label",
            children: "RAM",
          }),
        ],
      }),
      e.jsx("rect", {
        x: y.x - 6,
        y: y.y - 6,
        width: y.w + 12,
        height: y.h + 12,
        rx: 8,
        fill: "#94a3b8",
      }),
      e.jsx("rect", {
        x: y.x,
        y: y.y,
        width: y.w,
        height: y.h,
        rx: 6,
        fill: "#1e293b",
      }),
      e.jsx("g", {
        "data-board-part": "cores",
        className: r === "cores" ? "ub-focus" : void 0,
        children: Array.from({ length: t.cores }, (f, m) => {
          const $ = m % o.cols,
            b = Math.floor(m / o.cols),
            N = D.x + $ * (d + i),
            j = D.y + b * (c + i),
            k = s ? m >= s.coresUsed : !1;
          return e.jsxs(
            "g",
            {
              "data-core": k ? "idle" : s ? "busy" : "ready",
              children: [
                e.jsx("rect", {
                  x: N,
                  y: j,
                  width: d,
                  height: c,
                  rx: 4,
                  fill: k ? "#334155" : "#0d9488",
                  stroke: k ? "#475569" : "#5eead4",
                  strokeWidth: 1.5,
                  className: s && a && !k ? "ub-core-busy" : void 0,
                  style: { animationDelay: `${(m * 0.13).toFixed(2)}s` },
                }),
                e.jsx("text", {
                  x: N + d / 2,
                  y: j + c / 2 + 4,
                  textAnchor: "middle",
                  className: "ub-core-text",
                  fill: k ? "#94a3b8" : "#f0fdfa",
                  children: k ? "idle" : t.cores > 4 ? m + 1 : `Core ${m + 1}`,
                }),
              ],
            },
            m,
          );
        }),
      }),
      e.jsxs("g", {
        "data-board-part": "cache",
        className: r === "cache" ? "ub-focus" : void 0,
        children: [
          e.jsx("rect", {
            x: S.x,
            y: S.y,
            width: S.w,
            height: S.h,
            rx: 4,
            fill: "#0f172a",
            stroke: "#a78bfa",
            strokeOpacity: 0.5,
          }),
          e.jsx("rect", {
            x: S.x,
            y: S.y,
            width: S.w * n,
            height: S.h,
            rx: 4,
            fill: "#7c3aed",
          }),
          e.jsxs("text", {
            x: y.x + y.w / 2,
            y: S.y + 21,
            textAnchor: "middle",
            className: "ub-cache-text",
            children: ["Cache ", t.cache, " MB"],
          }),
        ],
      }),
      e.jsxs("g", {
        "data-board-part": "fetches",
        children: [
          e.jsx("path", {
            d: le,
            stroke: "#93c5fd",
            strokeOpacity: 0.5,
            strokeWidth: 3,
            fill: "none",
          }),
          a
            ? Array.from({ length: x }, (f, m) =>
                e.jsx(
                  "circle",
                  {
                    r: 4,
                    fill: "#f87171",
                    "data-ram-fetch": !0,
                    children: e.jsx("animateMotion", {
                      path: le,
                      dur: "1.2s",
                      begin: `${(m * 0.2).toFixed(1)}s`,
                      repeatCount: "indefinite",
                    }),
                  },
                  m,
                ),
              )
            : null,
        ],
      }),
      e.jsx("text", {
        x: y.x + y.w / 2,
        y: y.y + y.h - 4,
        textAnchor: "middle",
        className: "ub-chip-name",
        children: "CPU",
      }),
    ],
  });
}
function ft({
  trait: t,
  index: s,
  start: r,
  canLower: a,
  canRaise: l,
  onStep: o,
  onFocus: i,
  disabled: d,
}) {
  const c = v[t],
    n = c[s],
    x = (s / (c.length - 1)) * 180 - 180,
    h = Q[t],
    u = g.useId(),
    [f, m] = g.useState(!1);
  function $(b) {
    d ||
      ((b.key === "ArrowUp" || b.key === "ArrowRight") && l
        ? (b.preventDefault(), o(1))
        : (b.key === "ArrowDown" || b.key === "ArrowLeft") &&
          a &&
          (b.preventDefault(), o(-1)));
  }
  return e.jsxs("div", {
    className: "ub-dial",
    "data-trait-dial": t,
    "data-upgraded": s > r || void 0,
    onMouseEnter: () => i(t),
    onMouseLeave: () => i(null),
    children: [
      e.jsxs("div", {
        className: "flex items-center justify-center gap-1",
        children: [
          e.jsx("p", {
            className: "text-sm font-semibold text-slate-200",
            children: h,
          }),
          e.jsx("button", {
            type: "button",
            className: "ub-info",
            "aria-label": `What is ${h.toLowerCase()}?`,
            "aria-expanded": f,
            "aria-describedby": f ? u : void 0,
            onClick: () => m(!0),
            onMouseEnter: () => m(!0),
            onMouseLeave: () => m(!1),
            onBlur: () => m(!1),
            onKeyDown: (b) => {
              b.key === "Escape" && m(!1);
            },
            children: e.jsx(He, {
              "aria-hidden": "true",
              className: "h-4 w-4",
            }),
          }),
        ],
      }),
      f
        ? e.jsx("p", {
            id: u,
            role: "tooltip",
            className: "ub-tip",
            "data-trait-tip": t,
            children: Qe[t],
          })
        : null,
      e.jsxs("div", {
        className: "mt-1 flex items-center gap-2",
        children: [
          e.jsx("button", {
            type: "button",
            className: "ub-step",
            "aria-label": `Lower ${h.toLowerCase()}`,
            disabled: d || !a,
            onClick: () => o(-1),
            onFocus: () => i(t),
            onBlur: () => i(null),
            children: e.jsx(he, {
              "aria-hidden": "true",
              className: "h-4 w-4",
            }),
          }),
          e.jsxs("svg", {
            viewBox: "0 0 120 70",
            className: "ub-gauge",
            role: "slider",
            tabIndex: d ? -1 : 0,
            "aria-label": h,
            "aria-valuemin": c[r],
            "aria-valuemax": c[c.length - 1],
            "aria-valuenow": n,
            "aria-valuetext": A(t, n),
            "aria-disabled": d || void 0,
            onKeyDown: $,
            onFocus: () => i(t),
            onBlur: () => i(null),
            children: [
              e.jsx("path", {
                d: "M10 60a50 50 0 0 1 100 0",
                fill: "none",
                stroke: "#334155",
                strokeWidth: 8,
                strokeLinecap: "round",
              }),
              c.map((b, N) => {
                const j = ((N / (c.length - 1)) * 180 - 180) * (Math.PI / 180),
                  k = N <= s;
                return e.jsx(
                  "circle",
                  {
                    cx: 60 + Math.cos(j) * 50,
                    cy: 60 + Math.sin(j) * 50,
                    r: N === r ? 5 : 4,
                    fill: k ? (N > r ? "#2dd4bf" : "#94a3b8") : "#1e293b",
                    stroke: N === r ? "#f8fafc" : "none",
                    strokeWidth: 1.2,
                  },
                  b,
                );
              }),
              e.jsx("g", {
                className: "ub-needle",
                style: { transform: `rotate(${x + 90}deg)` },
                children: e.jsx("path", {
                  d: "M60 60L60 22",
                  stroke: "#f8fafc",
                  strokeWidth: 3,
                  strokeLinecap: "round",
                }),
              }),
              e.jsx("circle", { cx: 60, cy: 60, r: 6, fill: "#f8fafc" }),
            ],
          }),
          e.jsx("button", {
            type: "button",
            className: "ub-step",
            "aria-label": `Raise ${h.toLowerCase()}`,
            disabled: d || !l,
            onClick: () => o(1),
            onFocus: () => i(t),
            onBlur: () => i(null),
            children: e.jsx(De, {
              "aria-hidden": "true",
              className: "h-4 w-4",
            }),
          }),
        ],
      }),
      e.jsx("output", {
        className:
          "mt-1 block text-center font-mono text-lg font-bold text-slate-50",
        "aria-hidden": "true",
        children: A(t, n),
      }),
      e.jsxs("p", {
        className: "text-center font-mono text-xs text-slate-400",
        children: ["£", me[t], " a step"],
      }),
    ],
  });
}
const L = "#0f172a",
  mt = ["#f1c9a5", "#d9a57a", "#a8714a", "#7a4b2c"],
  ut = ["#2b1d14", "#5b3a24", "#c2873e", "#111827", "#9ca3af"],
  E = "rgba(15,23,42,0.22)",
  ie = "rgba(15,23,42,0.38)",
  W = "rgba(255,255,255,0.18)";
function pt({ style: t, color: s, back: r }) {
  return t === "long"
    ? e.jsxs(e.Fragment, {
        children: [
          e.jsx("path", {
            d: "M-16 -50c-2 14-2 28 -4 40c6 3 14 4 20 4s14-1 20-4c-2-12-2-26-4-40z",
            fill: s,
          }),
          e.jsx("path", {
            d: "M-12 -40c0 12 -1 22 -3 31M12 -40c0 12 1 22 3 31",
            stroke: E,
            strokeWidth: 1.4,
            fill: "none",
          }),
        ],
      })
    : t === "curly"
      ? e.jsxs("g", {
          fill: s,
          children: [
            [-16, -10, 10, 16].map((a) =>
              e.jsx("circle", { cx: a, cy: -40 + Math.abs(a) * 0.2, r: 6 }, a),
            ),
            r ? e.jsx("circle", { cx: 0, cy: -38, r: 9 }) : null,
          ],
        })
      : null;
}
function jt({ style: t, color: s, back: r }) {
  switch (t) {
    case "long":
      return r
        ? e.jsxs(e.Fragment, {
            children: [
              e.jsx("path", {
                d: "M-15 -47a15 15 0 0 1 30 0v18c-10 4-20 4-30 0z",
                fill: s,
              }),
              e.jsx("path", {
                d: "M-6 -60c2 8 2 20 0 30M5 -60c-1 9-1 20 1 30",
                stroke: E,
                strokeWidth: 1.2,
                fill: "none",
              }),
            ],
          })
        : e.jsxs(e.Fragment, {
            children: [
              e.jsx("path", {
                d: "M-15 -44c-1-12 6-18 15-18c10 0 16 6 15 18c-3-6-8-9-13-9c-3 3-9 6-17 9z",
                fill: s,
              }),
              e.jsx("path", {
                d: "M-14 -46c-1 6 -1 12 0 16",
                stroke: s,
                strokeWidth: 4,
                strokeLinecap: "round",
              }),
              e.jsx("path", {
                d: "M3 -59c4 0 8 2 10 6",
                stroke: W,
                strokeWidth: 1.6,
                fill: "none",
                strokeLinecap: "round",
              }),
            ],
          });
    case "bun":
      return e.jsxs(e.Fragment, {
        children: [
          e.jsx("circle", { cx: 1, cy: -63, r: 7.5, fill: s }),
          e.jsx("path", {
            d: "M-4 -66a6 6 0 0 1 8 -2",
            stroke: W,
            strokeWidth: 1.4,
            fill: "none",
          }),
          e.jsx("path", {
            d: r
              ? "M-14 -46a14 14 0 0 1 28 0v6c-8 3-20 3-28 0z"
              : "M-14 -45c0-10 6-15 14-15s14 5 14 15c-4-5-9-7-14-7s-10 2-14 7z",
            fill: s,
          }),
          e.jsx("path", {
            d: "M-6 -57q6 -3 12 0",
            stroke: W,
            strokeWidth: 1.2,
            fill: "none",
          }),
        ],
      });
    case "curly":
      return e.jsxs("g", {
        fill: s,
        children: [
          [-13, -7, -1, 5, 11].map((a, l) =>
            e.jsx(
              "circle",
              {
                cx: a + 1,
                cy: -57 + Math.abs(a) * 0.42 - (l % 2) * 1.5,
                r: 6.6,
              },
              a,
            ),
          ),
          e.jsx("circle", { cx: -14, cy: -48, r: 5 }),
          e.jsx("circle", { cx: 15, cy: -48, r: 5 }),
          r ? e.jsx("path", { d: "M-14 -50a14 14 0 0 1 28 0v10h-28z" }) : null,
          e.jsxs("g", {
            fill: "none",
            stroke: W,
            strokeWidth: 1.1,
            children: [
              e.jsx("path", { d: "M-9 -62a4 4 0 0 1 5 -1" }),
              e.jsx("path", { d: "M3 -63a4 4 0 0 1 5 0" }),
            ],
          }),
        ],
      });
    case "bald":
      return e.jsxs(e.Fragment, {
        children: [
          e.jsx("path", {
            d: "M-14 -44c1 4 2 7 3 9M14 -44c-1 4-2 7-3 9",
            stroke: s,
            strokeWidth: 4,
            strokeLinecap: "round",
          }),
          e.jsx("ellipse", { cx: 4, cy: -56, rx: 5, ry: 2.5, fill: W }),
        ],
      });
    default:
      return r
        ? e.jsxs(e.Fragment, {
            children: [
              e.jsx("path", {
                d: "M-14.5 -47a14.5 14.5 0 0 1 29 0v9c-9 2-20 2-29 0z",
                fill: s,
              }),
              e.jsx("path", {
                d: "M-8 -59q8 -4 16 0",
                stroke: W,
                strokeWidth: 1.3,
                fill: "none",
              }),
            ],
          })
        : e.jsxs(e.Fragment, {
            children: [
              e.jsx("path", {
                d: "M-14.5 -45c-1-11 6-17 15-17c9 0 15 5 14.5 15c-2-3-5-5-9-5c-5 3-12 3-17 2c-1 2-2 3-3.5 5z",
                fill: s,
              }),
              e.jsx("path", {
                d: "M-14 -46v6",
                stroke: s,
                strokeWidth: 3,
                strokeLinecap: "round",
              }),
              e.jsx("path", {
                d: "M-2 -59c5-2 10-1 13 3",
                stroke: W,
                strokeWidth: 1.5,
                fill: "none",
                strokeLinecap: "round",
              }),
            ],
          });
  }
}
function T({
  x: t,
  y: s,
  s: r = 1,
  skin: a,
  hair: l,
  style: o = "short",
  shirt: i,
  flip: d,
  back: c,
  mood: n = "calm",
  glasses: x,
  headset: h,
}) {
  const u = ut[l],
    f = mt[a];
  return e.jsxs("g", {
    transform: `translate(${t} ${s}) scale(${d ? -r : r} ${r})`,
    children: [
      e.jsx(pt, { style: o, color: u, back: c }),
      e.jsx("path", {
        d: "M-27 0v-9c0-13 9-21 20-22.5h14c11 1.5 20 9.5 20 22.5V0z",
        fill: i,
      }),
      e.jsx("path", {
        d: "M12 -30.5c9 2 15 9.5 15 21.5V0h-9v-14c0-6-3-12-6-16.5z",
        fill: E,
      }),
      e.jsx("path", {
        d: "M-17 -24c-1 8-1 16 0 24M17 -24c1 8 1 16 0 24",
        stroke: E,
        strokeWidth: 1.2,
        fill: "none",
      }),
      e.jsx("path", {
        d: "M-22 -22c3-4 7-7 12-8.5",
        stroke: W,
        strokeWidth: 2,
        fill: "none",
        strokeLinecap: "round",
      }),
      e.jsx("path", {
        d: "M-5.5 -36h11v6c-2 2.5-4 4-5.5 4s-3.5-1.5-5.5-4z",
        fill: f,
      }),
      e.jsx("path", { d: "M-5.5 -36h11v3c-3 2-8 2-11 0z", fill: E }),
      c
        ? null
        : e.jsx("path", {
            d: "M-8 -31.5c2 4 5 6 8 6s6-2 8-6",
            stroke: ie,
            strokeWidth: 1.4,
            fill: "none",
          }),
      e.jsx("ellipse", { cx: -12.6, cy: -45, rx: 3.2, ry: 4.6, fill: f }),
      e.jsx("path", {
        d: "M-13.2 -47c-1 1.5-1 3.5 0 4.5",
        stroke: E,
        strokeWidth: 1,
        fill: "none",
      }),
      c
        ? e.jsx("ellipse", { cx: 12.6, cy: -45, rx: 3.2, ry: 4.6, fill: f })
        : null,
      e.jsx("ellipse", { cx: 0, cy: -46, rx: 13.2, ry: 14.6, fill: f }),
      e.jsx("path", {
        d: "M7 -59.5a13.2 14.6 0 0 1 0 27.2c4-8 4-19 0-27.2z",
        fill: E,
        opacity: 0.55,
      }),
      e.jsx(jt, { style: o, color: u, back: c }),
      c
        ? null
        : e.jsxs(e.Fragment, {
            children: [
              e.jsx("g", {
                stroke: u,
                strokeWidth: 1.7,
                strokeLinecap: "round",
                fill: "none",
                children:
                  n === "fed-up"
                    ? e.jsxs(e.Fragment, {
                        children: [
                          e.jsx("path", { d: "M-7.5 -52.5l6 2" }),
                          e.jsx("path", { d: "M9 -52.5l-6 2" }),
                        ],
                      })
                    : e.jsxs(e.Fragment, {
                        children: [
                          e.jsx("path", { d: "M-7.5 -51q3 -2.2 6 -0.6" }),
                          e.jsx("path", { d: "M3 -51.6q3 -1.6 6 0.6" }),
                        ],
                      }),
              }),
              [-4.2, 5.8].map((m) =>
                e.jsxs(
                  "g",
                  {
                    children: [
                      e.jsx("ellipse", {
                        cx: m,
                        cy: -46.2,
                        rx: 2.6,
                        ry: n === "fed-up" ? 1.5 : 2,
                        fill: "#f8fafc",
                      }),
                      e.jsx("circle", {
                        cx: m + 0.6,
                        cy: -46.1,
                        r: 1.55,
                        fill: L,
                      }),
                      e.jsx("circle", {
                        cx: m + 1.1,
                        cy: -46.7,
                        r: 0.5,
                        fill: "#fff",
                      }),
                    ],
                  },
                  m,
                ),
              ),
              e.jsx("path", {
                d: "M2.2 -44.2q1.8 2.6 -0.6 3.4",
                stroke: ie,
                strokeWidth: 1.1,
                fill: "none",
                strokeLinecap: "round",
              }),
              e.jsx("circle", {
                cx: -6.5,
                cy: -41,
                r: 2.4,
                fill: "#f43f5e",
                opacity: 0.16,
              }),
              e.jsx("circle", {
                cx: 8.5,
                cy: -41,
                r: 2.2,
                fill: "#f43f5e",
                opacity: 0.16,
              }),
              n === "fed-up"
                ? e.jsx("path", {
                    d: "M-2 -36.6q3 -2.2 6.2 0.2",
                    stroke: "#7f1d1d",
                    strokeWidth: 1.4,
                    fill: "none",
                    strokeLinecap: "round",
                  })
                : e.jsx("path", {
                    d: "M-2.4 -38.4q3.2 2.6 6.8 0",
                    stroke: "#7f1d1d",
                    strokeWidth: 1.4,
                    fill: "none",
                    strokeLinecap: "round",
                  }),
              x
                ? e.jsxs("g", {
                    fill: "rgba(186,230,253,0.18)",
                    stroke: L,
                    strokeWidth: 1.1,
                    children: [
                      e.jsx("rect", {
                        x: -8.4,
                        y: -49.4,
                        width: 8.4,
                        height: 6.4,
                        rx: 2.6,
                      }),
                      e.jsx("rect", {
                        x: 1.8,
                        y: -49.4,
                        width: 8.4,
                        height: 6.4,
                        rx: 2.6,
                      }),
                      e.jsx("path", {
                        d: "M0 -46.6h1.8M-8.4 -46.6l-4 -0.6",
                        fill: "none",
                      }),
                    ],
                  })
                : null,
            ],
          }),
      h
        ? e.jsxs(e.Fragment, {
            children: [
              e.jsx("path", {
                d: "M-15 -49a15 16 0 0 1 30 0",
                fill: "none",
                stroke: "#111827",
                strokeWidth: 3.2,
              }),
              e.jsx("rect", {
                x: -20.4,
                y: -52,
                width: 7,
                height: 12,
                rx: 3.5,
                fill: "#ef4444",
              }),
              e.jsx("rect", {
                x: -19,
                y: -50,
                width: 2.4,
                height: 8,
                rx: 1.2,
                fill: "#fca5a5",
                opacity: 0.6,
              }),
              c
                ? e.jsx("rect", {
                    x: 11.4,
                    y: -52,
                    width: 7,
                    height: 12,
                    rx: 3.5,
                    fill: "#ef4444",
                  })
                : e.jsx("path", {
                    d: "M-15 -41c2 5 7 7.5 12 6.6",
                    stroke: "#111827",
                    strokeWidth: 1.6,
                    fill: "none",
                    strokeLinecap: "round",
                  }),
            ],
          })
        : null,
    ],
  });
}
function P({ wall: t, floor: s, horizon: r = 140 }) {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 320, height: r, fill: t }),
      e.jsx("rect", { y: r, width: 320, height: 200 - r, fill: s }),
      e.jsx("rect", {
        y: r - 3,
        width: 320,
        height: 3,
        fill: "rgba(0,0,0,0.18)",
      }),
    ],
  });
}
function F({ x: t, y: s, w: r, color: a = "#8b5e34" }) {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { x: t, y: s, width: r, height: 9, rx: 2, fill: a }),
      e.jsx("rect", {
        x: t,
        y: s + 9,
        width: r,
        height: 4,
        fill: "rgba(0,0,0,0.25)",
      }),
      e.jsx("rect", {
        x: t + 8,
        y: s + 13,
        width: 7,
        height: 200 - s,
        fill: a,
      }),
      e.jsx("rect", {
        x: t + r - 15,
        y: s + 13,
        width: 7,
        height: 200 - s,
        fill: a,
      }),
    ],
  });
}
function O({
  x: t,
  y: s,
  w: r = 110,
  h: a = 68,
  bezel: l = "#111827",
  children: o,
}) {
  return e.jsxs("g", {
    children: [
      e.jsx("rect", {
        x: t - 5,
        y: s - 14,
        width: 10,
        height: 14,
        fill: "#334155",
      }),
      e.jsx("rect", {
        x: t - 20,
        y: s - 3,
        width: 40,
        height: 4,
        rx: 2,
        fill: "#334155",
      }),
      e.jsx("rect", {
        x: t - r / 2,
        y: s - 14 - a,
        width: r,
        height: a,
        rx: 4,
        fill: l,
      }),
      e.jsxs("g", {
        transform: `translate(${t - r / 2 + 4} ${s - 10 - a}) scale(${(r - 8) / 100} ${(a - 8) / 60})`,
        children: [
          e.jsx("rect", { width: 100, height: 60, fill: "#0b1220" }),
          o,
        ],
      }),
    ],
  });
}
function we({ x: t, y: s, w: r = 84, children: a }) {
  const l = r * 0.62;
  return e.jsxs("g", {
    children: [
      e.jsx("rect", {
        x: t - r / 2,
        y: s - l,
        width: r,
        height: l,
        rx: 4,
        fill: "#1f2937",
      }),
      e.jsxs("g", {
        transform: `translate(${t - r / 2 + 4} ${s - l + 4}) scale(${(r - 8) / 100} ${(l - 8) / 60})`,
        children: [
          e.jsx("rect", { width: 100, height: 60, fill: "#f8fafc" }),
          a,
        ],
      }),
      e.jsx("path", {
        d: `M${t - r / 2 - 8} ${s}h${r + 16}l-6 5h${-(r + 4)}z`,
        fill: "#94a3b8",
      }),
    ],
  });
}
function ke({ x: t, y: s, r = 7 }) {
  return e.jsx("g", {
    transform: `translate(${t} ${s})`,
    children: e.jsxs("g", {
      className: "ub-busy",
      children: [
        e.jsx("circle", {
          r,
          fill: "none",
          stroke: "rgba(255,255,255,0.25)",
          strokeWidth: r * 0.4,
        }),
        e.jsx("path", {
          d: `M0 ${-r}a${r} ${r} 0 0 1 ${r} ${r}`,
          fill: "none",
          stroke: "#fbbf24",
          strokeWidth: r * 0.4,
          strokeLinecap: "round",
        }),
      ],
    }),
  });
}
function Z({ x: t, y: s, w: r, children: a }) {
  return e.jsxs("g", {
    children: [
      e.jsx("rect", {
        x: t,
        y: s,
        width: r,
        height: 22,
        rx: 8,
        fill: "#fff",
        stroke: L,
        strokeWidth: 1,
      }),
      e.jsx("path", {
        d: `M${t + 14} ${s + 22}l-4 7l10 -7`,
        fill: "#fff",
        stroke: L,
        strokeWidth: 1,
      }),
      e.jsx("rect", {
        x: t + 13,
        y: s + 20.5,
        width: 8,
        height: 2,
        fill: "#fff",
      }),
      e.jsx("text", {
        x: t + r / 2,
        y: s + 15,
        textAnchor: "middle",
        fontSize: 11,
        fontWeight: 700,
        fontFamily: "system-ui, sans-serif",
        fill: L,
        children: a,
      }),
    ],
  });
}
function gt() {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx(P, { wall: "#312e81", floor: "#1e1b4b" }),
      e.jsx("rect", {
        x: 18,
        y: 20,
        width: 70,
        height: 46,
        rx: 3,
        fill: "#1e1b4b",
      }),
      e.jsx("path", { d: "M24 60l14-18 10 10 10-14 24 22z", fill: "#4338ca" }),
      e.jsx("rect", {
        x: 232,
        y: 18,
        width: 64,
        height: 40,
        rx: 3,
        fill: "#a5b4fc",
        opacity: 0.25,
      }),
      e.jsx(F, { x: 60, y: 128, w: 210, color: "#475569" }),
      e.jsxs(O, {
        x: 166,
        y: 128,
        w: 150,
        h: 90,
        children: [
          e.jsx("rect", { width: 100, height: 34, fill: "#38bdf8" }),
          e.jsx("rect", { y: 34, width: 100, height: 26, fill: "#4d7c0f" }),
          e.jsx("path", { d: "M38 60l10-26h4l10 26z", fill: "#334155" }),
          e.jsx("path", {
            d: "M49 38v4M49 46v5M49 55v5",
            stroke: "#f8fafc",
            strokeWidth: 1,
          }),
          e.jsx("path", {
            d: "M30 12l40 6-40 6z",
            fill: "#e2e8f0",
            opacity: 0.9,
          }),
          e.jsx("path", {
            d: "M44 14l-6-8h4l8 8M44 22l-6 8h4l8-8",
            fill: "#cbd5e1",
          }),
          e.jsx("g", {
            opacity: 0.55,
            children: e.jsx("path", {
              d: "M26 12l40 6-40 6z",
              fill: "#e2e8f0",
            }),
          }),
          e.jsx("rect", {
            x: 64,
            y: 3,
            width: 33,
            height: 9,
            rx: 2,
            fill: "rgba(15,23,42,0.75)",
          }),
          e.jsx("text", {
            x: 80.5,
            y: 10,
            textAnchor: "middle",
            fontSize: 6,
            fill: "#fca5a5",
            fontFamily: "monospace",
            children: "12 FPS",
          }),
        ],
      }),
      e.jsx("rect", {
        x: 232,
        y: 112,
        width: 10,
        height: 16,
        rx: 2,
        fill: "#1f2937",
      }),
      e.jsx("rect", {
        x: 234,
        y: 98,
        width: 6,
        height: 16,
        rx: 3,
        fill: "#111827",
      }),
      e.jsx("circle", { cx: 237, cy: 97, r: 4, fill: "#ef4444" }),
      e.jsx(T, {
        x: 100,
        y: 200,
        s: 1.3,
        skin: 1,
        hair: 0,
        style: "long",
        shirt: "#db2777",
        back: !0,
        headset: !0,
      }),
      e.jsx(Z, { x: 196, y: 24, w: 84, children: "Stutter, stutter…" }),
    ],
  });
}
function yt() {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx(P, { wall: "#1f2937", floor: "#111827" }),
      e.jsx("rect", {
        x: 14,
        y: 18,
        width: 52,
        height: 70,
        rx: 2,
        fill: "#374151",
      }),
      e.jsx("circle", {
        cx: 40,
        cy: 44,
        r: 14,
        fill: "#fde68a",
        opacity: 0.25,
      }),
      e.jsx(F, { x: 70, y: 128, w: 236, color: "#78350f" }),
      e.jsxs(O, {
        x: 150,
        y: 128,
        w: 120,
        h: 74,
        children: [
          e.jsx("rect", { x: 4, y: 4, width: 56, height: 32, fill: "#fef3c7" }),
          e.jsx("circle", { cx: 22, cy: 18, r: 6, fill: "#f1c9a5" }),
          e.jsx("circle", { cx: 40, cy: 18, r: 6, fill: "#a8714a" }),
          e.jsx("path", {
            d: "M14 36q8-14 16 0M32 36q8-14 16 0",
            fill: "#f8fafc",
          }),
          e.jsx("rect", {
            x: 64,
            y: 4,
            width: 32,
            height: 32,
            fill: "#1e293b",
          }),
          [0, 1, 2, 3].map((t) =>
            e.jsx(
              "rect",
              { x: 4, y: 40 + t * 5, width: 92, height: 3, fill: "#334155" },
              t,
            ),
          ),
          e.jsx("rect", {
            x: 10,
            y: 40,
            width: 30,
            height: 3,
            fill: "#a78bfa",
          }),
          e.jsx("rect", {
            x: 42,
            y: 45,
            width: 24,
            height: 3,
            fill: "#34d399",
          }),
          e.jsx("rect", {
            x: 20,
            y: 50,
            width: 40,
            height: 3,
            fill: "#f472b6",
          }),
          e.jsx("rect", {
            x: 20,
            y: 20,
            width: 60,
            height: 20,
            rx: 2,
            fill: "rgba(15,23,42,0.92)",
          }),
          e.jsx("text", {
            x: 50,
            y: 28,
            textAnchor: "middle",
            fontSize: 5,
            fill: "#e2e8f0",
            fontFamily: "sans-serif",
            children: "Exporting…",
          }),
          e.jsx("rect", {
            x: 26,
            y: 32,
            width: 48,
            height: 3,
            rx: 1.5,
            fill: "#334155",
          }),
          e.jsx("rect", {
            x: 26,
            y: 32,
            width: 9,
            height: 3,
            rx: 1.5,
            fill: "#fbbf24",
          }),
        ],
      }),
      e.jsxs(O, {
        x: 258,
        y: 128,
        w: 80,
        h: 56,
        children: [
          e.jsx("rect", { x: 6, y: 8, width: 88, height: 44, fill: "#0f172a" }),
          e.jsx("path", {
            d: "M10 46l20-22 18 14 16-12 26 20z",
            fill: "#334155",
          }),
          e.jsx(ke, { x: 50, y: 28, r: 8 }),
        ],
      }),
      e.jsxs("g", {
        transform: "translate(40 128)",
        children: [
          e.jsx("path", {
            d: "M0 0l-14 72M0 0l14 72M0 0v72",
            stroke: "#475569",
            strokeWidth: 3,
          }),
          e.jsx("rect", {
            x: -14,
            y: -20,
            width: 28,
            height: 18,
            rx: 3,
            fill: "#111827",
          }),
          e.jsx("circle", {
            cx: 10,
            cy: -11,
            r: 6,
            fill: "#1f2937",
            stroke: "#64748b",
            strokeWidth: 2,
          }),
        ],
      }),
      e.jsx(T, {
        x: 176,
        y: 200,
        s: 1.3,
        skin: 3,
        hair: 3,
        style: "short",
        shirt: "#0d9488",
        back: !0,
      }),
    ],
  });
}
function bt() {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx(P, { wall: "#e7e5e4", floor: "#a8a29e" }),
      e.jsx("rect", {
        x: 196,
        y: 14,
        width: 110,
        height: 36,
        rx: 3,
        fill: "#fff",
        stroke: "#78716c",
      }),
      e.jsx("text", {
        x: 251,
        y: 37,
        textAnchor: "middle",
        fontSize: 13,
        fontWeight: 700,
        fill: "#1e3a8a",
        fontFamily: "system-ui, sans-serif",
        children: "School Office",
      }),
      e.jsx("circle", {
        cx: 34,
        cy: 36,
        r: 18,
        fill: "#fff",
        stroke: "#44403c",
        strokeWidth: 2,
      }),
      e.jsx("path", {
        d: "M34 36v-11M34 36l7 4",
        stroke: "#44403c",
        strokeWidth: 2,
        strokeLinecap: "round",
      }),
      e.jsx(F, { x: 36, y: 130, w: 250, color: "#a16207" }),
      e.jsxs("g", {
        children: [
          e.jsx("rect", {
            x: 68,
            y: 98,
            width: 92,
            height: 32,
            rx: 3,
            fill: "#e7e5e4",
            stroke: "#78716c",
          }),
          e.jsx("rect", {
            x: 74,
            y: 104,
            width: 12,
            height: 4,
            fill: "#78716c",
          }),
          e.jsx("circle", { cx: 148, cy: 114, r: 3, fill: "#22c55e" }),
        ],
      }),
      e.jsxs(O, {
        x: 114,
        y: 98,
        w: 96,
        h: 64,
        bezel: "#d6d3d1",
        children: [
          e.jsx("rect", { width: 100, height: 60, fill: "#1e3a8a" }),
          e.jsx("text", {
            x: 50,
            y: 10,
            textAnchor: "middle",
            fontSize: 6,
            fill: "#fff",
            fontFamily: "monospace",
            children: "ATTENDANCE",
          }),
          [0, 1, 2, 3, 4].map((t) =>
            e.jsxs(
              "g",
              {
                children: [
                  e.jsx("rect", {
                    x: 8,
                    y: 16 + t * 8,
                    width: 44,
                    height: 4,
                    fill: "#93c5fd",
                    opacity: 0.5,
                  }),
                  e.jsx("rect", {
                    x: 60,
                    y: 16 + t * 8,
                    width: 8,
                    height: 4,
                    fill: t < 2 ? "#86efac" : "#475569",
                  }),
                ],
              },
              t,
            ),
          ),
          e.jsx(ke, { x: 82, y: 36, r: 7 }),
        ],
      }),
      e.jsx("rect", {
        x: 196,
        y: 112,
        width: 40,
        height: 18,
        rx: 2,
        fill: "#fef9c3",
        stroke: "#a16207",
      }),
      e.jsx("path", {
        d: "M200 118h30M200 123h22",
        stroke: "#a16207",
        strokeWidth: 1.5,
      }),
      e.jsx(T, {
        x: 262,
        y: 200,
        s: 1.45,
        skin: 1,
        hair: 0,
        style: "bun",
        shirt: "#7c3aed",
        mood: "fed-up",
        flip: !0,
        glasses: !0,
      }),
      e.jsx(Z, { x: 168, y: 64, w: 92, children: "Still loading!" }),
    ],
  });
}
function wt() {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx(P, { wall: "#ecfccb", floor: "#a3a3a3" }),
      e.jsx("rect", {
        x: 18,
        y: 16,
        width: 150,
        height: 66,
        rx: 3,
        fill: "#14532d",
        stroke: "#a16207",
        strokeWidth: 4,
      }),
      e.jsx("text", {
        x: 93,
        y: 44,
        textAnchor: "middle",
        fontSize: 11,
        fill: "#f0fdf4",
        fontFamily: "system-ui, sans-serif",
        children: "Year 11 results",
      }),
      e.jsx("path", {
        d: "M40 62h70M40 70h50",
        stroke: "#f0fdf4",
        strokeWidth: 1.5,
        opacity: 0.7,
      }),
      e.jsx(F, { x: 40, y: 136, w: 250, color: "#92400e" }),
      e.jsxs(we, {
        x: 140,
        y: 136,
        w: 110,
        children: [
          e.jsx("rect", { width: 100, height: 8, fill: "#16a34a" }),
          [0, 1, 2, 3, 4, 5].map((t) =>
            [0, 1, 2, 3, 4].map((s) =>
              e.jsx(
                "rect",
                {
                  x: 2 + s * 19.5,
                  y: 10 + t * 8,
                  width: 18.5,
                  height: 7,
                  fill: t === 0 ? "#bbf7d0" : "#fff",
                  stroke: "#cbd5e1",
                  strokeWidth: 0.5,
                },
                `${t}-${s}`,
              ),
            ),
          ),
          e.jsx("rect", {
            x: 22,
            y: 20,
            width: 56,
            height: 22,
            rx: 2,
            fill: "rgba(15,23,42,0.88)",
          }),
          e.jsx("text", {
            x: 50,
            y: 29,
            textAnchor: "middle",
            fontSize: 5.5,
            fill: "#f8fafc",
            fontFamily: "sans-serif",
            children: "Calculating…",
          }),
          e.jsx("text", {
            x: 50,
            y: 37,
            textAnchor: "middle",
            fontSize: 5,
            fill: "#fbbf24",
            fontFamily: "monospace",
            children: "=AVERAGE(B2:B501)",
          }),
        ],
      }),
      e.jsxs("g", {
        children: [
          e.jsx("rect", {
            x: 214,
            y: 118,
            width: 44,
            height: 18,
            fill: "#fff",
            stroke: "#94a3b8",
          }),
          e.jsx("rect", {
            x: 218,
            y: 112,
            width: 44,
            height: 18,
            fill: "#fff",
            stroke: "#94a3b8",
          }),
          e.jsx("rect", {
            x: 222,
            y: 106,
            width: 44,
            height: 18,
            fill: "#fff",
            stroke: "#94a3b8",
          }),
          e.jsx("path", {
            d: "M228 112h30M228 117h24",
            stroke: "#94a3b8",
            strokeWidth: 1.2,
          }),
        ],
      }),
      e.jsx(T, {
        x: 272,
        y: 200,
        s: 1.45,
        skin: 3,
        hair: 3,
        style: "short",
        shirt: "#1d4ed8",
        flip: !0,
        glasses: !0,
        mood: "fed-up",
      }),
    ],
  });
}
const oe = Array.from({ length: 64 }, (t, s) => s);
function kt() {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx(P, { wall: "#fef3c7", floor: "#78716c" }),
      e.jsx("rect", {
        x: 196,
        y: 14,
        width: 104,
        height: 30,
        rx: 3,
        fill: "#7c2d12",
      }),
      e.jsx("text", {
        x: 248,
        y: 34,
        textAnchor: "middle",
        fontSize: 12,
        fontWeight: 700,
        fill: "#fde68a",
        fontFamily: "system-ui, sans-serif",
        children: "Chess club",
      }),
      e.jsx(F, { x: 22, y: 136, w: 280, color: "#57534e" }),
      e.jsx("g", {
        transform: "translate(36 106) skewX(-20)",
        children: oe.map((t) =>
          e.jsx(
            "rect",
            {
              x: (t % 8) * 9 + 14,
              y: Math.floor(t / 8) * 3.6,
              width: 9,
              height: 3.6,
              fill: (t + Math.floor(t / 8)) % 2 ? "#78350f" : "#fde68a",
            },
            t,
          ),
        ),
      }),
      e.jsxs("g", {
        fill: "#111827",
        children: [
          e.jsx("path", { d: "M60 106v-10h5v10z" }),
          e.jsx("circle", { cx: 62.5, cy: 94, r: 3.5 }),
          e.jsx("path", { d: "M90 116v-9h5v9z" }),
          e.jsx("circle", { cx: 92.5, cy: 105, r: 3 }),
        ],
      }),
      e.jsxs("g", {
        fill: "#f8fafc",
        stroke: "#111827",
        strokeWidth: 0.8,
        children: [
          e.jsx("path", { d: "M74 120v-10h5v10z" }),
          e.jsx("circle", { cx: 76.5, cy: 108, r: 3.5 }),
        ],
      }),
      e.jsxs(we, {
        x: 200,
        y: 136,
        w: 100,
        children: [
          e.jsxs("g", {
            transform: "translate(26 4)",
            children: [
              oe.map((t) =>
                e.jsx(
                  "rect",
                  {
                    x: (t % 8) * 6.4,
                    y: Math.floor(t / 8) * 6.4,
                    width: 6.4,
                    height: 6.4,
                    fill: (t + Math.floor(t / 8)) % 2 ? "#a16207" : "#fef3c7",
                  },
                  t,
                ),
              ),
              e.jsx("path", {
                d: "M16 38l13-13",
                stroke: "#22c55e",
                strokeWidth: 2,
                strokeDasharray: "3 2",
              }),
            ],
          }),
          e.jsx("rect", {
            x: 2,
            y: 22,
            width: 22,
            height: 16,
            rx: 2,
            fill: "rgba(15,23,42,0.85)",
          }),
          e.jsx("text", {
            x: 13,
            y: 32,
            textAnchor: "middle",
            fontSize: 4.5,
            fill: "#fbbf24",
            fontFamily: "sans-serif",
            children: "Thinking",
          }),
        ],
      }),
      e.jsxs("g", {
        transform: "translate(26 62)",
        children: [
          e.jsx("path", {
            d: "M-8 -14h16l-6 10v1l6 10h-16l6-10v-1z",
            fill: "#fde68a",
            stroke: "#78350f",
            strokeWidth: 1.5,
          }),
          e.jsx("path", { d: "M-3 4h6l-3 -4z", fill: "#b45309" }),
        ],
      }),
      e.jsx(T, {
        x: 286,
        y: 200,
        s: 1.35,
        skin: 2,
        hair: 0,
        style: "curly",
        shirt: "#ea580c",
        mood: "fed-up",
        flip: !0,
      }),
    ],
  });
}
const Mt = [
  [14, 12, "#f472b6"],
  [30, 40, "#38bdf8"],
  [52, 18, "#facc15"],
  [70, 46, "#34d399"],
  [84, 22, "#f472b6"],
  [42, 30, "#38bdf8"],
  [22, 50, "#facc15"],
  [62, 8, "#34d399"],
  [90, 52, "#38bdf8"],
  [8, 34, "#34d399"],
];
function Nt() {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx(P, { wall: "#e0f2fe", floor: "#64748b" }),
      e.jsx("rect", { x: 14, y: 58, width: 90, height: 6, fill: "#475569" }),
      e.jsxs("g", {
        children: [
          e.jsx("path", {
            d: "M24 58v-16h10v16z",
            fill: "#bae6fd",
            stroke: "#0369a1",
          }),
          e.jsx("path", {
            d: "M44 58l6-22h4l6 22z",
            fill: "#bbf7d0",
            stroke: "#15803d",
          }),
          e.jsx("rect", {
            x: 70,
            y: 38,
            width: 10,
            height: 20,
            rx: 4,
            fill: "#fecdd3",
            stroke: "#be123c",
          }),
        ],
      }),
      e.jsx(F, { x: 40, y: 134, w: 262, color: "#334155" }),
      e.jsxs(O, {
        x: 190,
        y: 134,
        w: 150,
        h: 96,
        children: [
          e.jsx("rect", { width: 100, height: 60, fill: "#020617" }),
          Mt.map(([t, s, r], a) =>
            e.jsxs(
              "g",
              {
                children: [
                  e.jsx("circle", { cx: t, cy: s, r: 2.4, fill: r }),
                  e.jsx("path", {
                    d: `M${t} ${s}l-6 ${a % 2 ? 3 : -3}`,
                    stroke: r,
                    strokeWidth: 0.7,
                    opacity: 0.5,
                  }),
                ],
              },
              a,
            ),
          ),
          e.jsx("rect", {
            x: 60,
            y: 50,
            width: 38,
            height: 8,
            rx: 2,
            fill: "rgba(15,23,42,0.9)",
          }),
          e.jsx("text", {
            x: 79,
            y: 56,
            textAnchor: "middle",
            fontSize: 5,
            fill: "#fbbf24",
            fontFamily: "monospace",
            children: "step 41/1000",
          }),
        ],
      }),
      e.jsx(T, {
        x: 74,
        y: 200,
        s: 1.4,
        skin: 0,
        hair: 4,
        style: "short",
        shirt: "#f8fafc",
        glasses: !0,
      }),
      e.jsx("path", {
        d: "M62 158l12 42M86 158l-12 42",
        stroke: "#cbd5e1",
        strokeWidth: 2,
      }),
      e.jsx(Z, { x: 110, y: 92, w: 76, children: "Class soon!" }),
    ],
  });
}
const vt = {
    gamer: gt,
    editor: yt,
    office: bt,
    teacher: wt,
    chess: kt,
    scientist: Nt,
  },
  $t = {
    gamer:
      "A gamer at her desk. The flight simulator on her monitor shows 12 frames per second.",
    editor: "A video editor at two monitors. The export bar has barely moved.",
    office:
      "The school office. The attendance register is still loading on an old PC.",
    teacher:
      "A head of year at a laptop. The results spreadsheet says Calculating.",
    chess:
      "A chess player at the club. The chess app on the laptop is still thinking.",
    scientist:
      "A science teacher by a monitor. The particle simulation is on step 41 of 1000.",
  };
function Ct({ look: t, className: s }) {
  const r = vt[t],
    a = g.useId().replace(/:/g, "");
  return e.jsxs("svg", {
    viewBox: "0 0 320 200",
    className: s,
    role: "img",
    "aria-label": $t[t],
    "data-customer-scene": t,
    children: [
      e.jsx("defs", {
        children: e.jsxs("radialGradient", {
          id: `${a}-light`,
          cx: "0.5",
          cy: "0.35",
          r: "0.75",
          children: [
            e.jsx("stop", {
              offset: "0.55",
              stopColor: "#020617",
              stopOpacity: 0,
            }),
            e.jsx("stop", {
              offset: "1",
              stopColor: "#020617",
              stopOpacity: 0.42,
            }),
          ],
        }),
      }),
      e.jsx(r, {}),
      e.jsx("rect", {
        width: 320,
        height: 200,
        fill: `url(#${a}-light)`,
        pointerEvents: "none",
      }),
    ],
  });
}
const Me = {
  gamer: { skin: 1, hair: 0, style: "long", shirt: "#db2777", headset: !0 },
  editor: { skin: 3, hair: 3, style: "short", shirt: "#0d9488" },
  office: { skin: 1, hair: 0, style: "bun", shirt: "#7c3aed", glasses: !0 },
  teacher: { skin: 3, hair: 3, style: "short", shirt: "#1d4ed8", glasses: !0 },
  chess: { skin: 2, hair: 0, style: "curly", shirt: "#ea580c" },
  scientist: {
    skin: 0,
    hair: 4,
    style: "short",
    shirt: "#f8fafc",
    glasses: !0,
  },
};
function V({ look: t, className: s }) {
  return e.jsxs("svg", {
    viewBox: "0 0 64 64",
    className: s,
    "aria-hidden": "true",
    children: [
      e.jsx("circle", { cx: 32, cy: 32, r: 32, fill: "#334155" }),
      e.jsx("clipPath", {
        id: `ub-avatar-${t}`,
        children: e.jsx("circle", { cx: 32, cy: 32, r: 32 }),
      }),
      e.jsx("g", {
        clipPath: `url(#ub-avatar-${t})`,
        children: e.jsx(T, { x: 32, y: 84, s: 0.95, ...Me[t] }),
      }),
    ],
  });
}
function Ne({ ids: t }) {
  return e.jsxs("defs", {
    children: [
      e.jsxs("pattern", {
        id: t.peg,
        width: 14,
        height: 14,
        patternUnits: "userSpaceOnUse",
        children: [
          e.jsx("rect", { width: 14, height: 14, fill: "#25384f" }),
          e.jsx("circle", { cx: 7, cy: 7, r: 1.8, fill: "#111d2e" }),
        ],
      }),
      e.jsxs("filter", {
        id: t.glow,
        x: "-30%",
        y: "-60%",
        width: "160%",
        height: "220%",
        children: [
          e.jsx("feGaussianBlur", { stdDeviation: 5, result: "blur" }),
          e.jsxs("feMerge", {
            children: [
              e.jsx("feMergeNode", { in: "blur" }),
              e.jsx("feMergeNode", { in: "blur" }),
              e.jsx("feMergeNode", { in: "SourceGraphic" }),
            ],
          }),
        ],
      }),
      e.jsxs("linearGradient", {
        id: t.cone,
        x1: "0",
        y1: "0",
        x2: "0",
        y2: "1",
        children: [
          e.jsx("stop", {
            offset: "0",
            stopColor: "#fde68a",
            stopOpacity: 0.3,
          }),
          e.jsx("stop", { offset: "1", stopColor: "#fde68a", stopOpacity: 0 }),
        ],
      }),
      e.jsxs("linearGradient", {
        id: t.wood,
        x1: "0",
        y1: "0",
        x2: "0",
        y2: "1",
        children: [
          e.jsx("stop", { offset: "0", stopColor: "#c2753a" }),
          e.jsx("stop", { offset: "1", stopColor: "#7c3f12" }),
        ],
      }),
      e.jsxs("linearGradient", {
        id: t.wall,
        x1: "0",
        y1: "0",
        x2: "0",
        y2: "1",
        children: [
          e.jsx("stop", { offset: "0", stopColor: "#0d1626" }),
          e.jsx("stop", { offset: "1", stopColor: "#1c2b41" }),
        ],
      }),
      e.jsxs("linearGradient", {
        id: t.corridor,
        x1: "0",
        y1: "0",
        x2: "0",
        y2: "1",
        children: [
          e.jsx("stop", { offset: "0", stopColor: "#5b7fa6" }),
          e.jsx("stop", { offset: "1", stopColor: "#2a3d57" }),
        ],
      }),
      e.jsxs("radialGradient", {
        id: t.vignette,
        cx: "0.5",
        cy: "0.45",
        r: "0.75",
        children: [
          e.jsx("stop", {
            offset: "0.6",
            stopColor: "#020617",
            stopOpacity: 0,
          }),
          e.jsx("stop", {
            offset: "1",
            stopColor: "#020617",
            stopOpacity: 0.6,
          }),
        ],
      }),
    ],
  });
}
function q({ x: t, top: s, floor: r, spread: a, ids: l }) {
  return e.jsxs("g", {
    children: [
      e.jsx("path", { d: `M${t} 0V${s}`, stroke: "#0b1220", strokeWidth: 2 }),
      e.jsx("path", {
        d: `M${t - 24} ${s + 26}L${t + 24} ${s + 26}L${t + a} ${r}L${t - a} ${r}z`,
        fill: `url(#${l.cone})`,
      }),
      e.jsx("path", { d: `M${t - 10} ${s}h20l14 26h-48z`, fill: "#334155" }),
      e.jsx("path", { d: `M${t - 10} ${s}h20l3 6h-26z`, fill: "#475569" }),
      e.jsx("ellipse", {
        cx: t,
        cy: s + 27,
        rx: 13,
        ry: 4,
        fill: "#fef3c7",
        filter: `url(#${l.glow})`,
      }),
    ],
  });
}
const ce = [
  { char: "U", width: 0.74 },
  { char: "P", width: 0.68, dy: -0.02, tilt: -2 },
  { char: "G", width: 0.78, dx: 0.01 },
  { char: "R", width: 0.7, dy: 0.02, tilt: 2 },
  { char: "A", width: 0.74, dy: 0.03, tilt: -3, dead: !0 },
  { char: "D", width: 0.76, dy: -0.01 },
  { char: "E", width: 0.64, dx: 0.02, dy: 0.12, tilt: 14 },
  { char: " ", width: 0.34 },
  { char: "B", width: 0.7, dy: -0.02, tilt: -1.5 },
  { char: "A", width: 0.74, dy: 0.01 },
  { char: "Y", width: 0.7, dx: 0.04, dy: 0.2, tilt: 24 },
];
function ve({ w: t, h: s, ids: r }) {
  const a = Math.min(s * 0.48, t / 9.6),
    l = a * 0.06,
    o = ce.reduce((n, x) => n + x.width * a + l, -l),
    i = s / 2 + a * 0.36;
  let d = (t - o) / 2;
  const c = ce.map((n, x) => {
    const h = d + (n.width * a) / 2 + (n.dx ?? 0) * a;
    return (
      (d += n.width * a + l),
      { ...n, index: x, x: h, y: i + (n.dy ?? 0) * a }
    );
  });
  return e.jsxs("g", {
    children: [
      e.jsx("rect", {
        width: t,
        height: s,
        rx: s * 0.16,
        fill: "#0a1220",
        stroke: "#1d3b48",
        strokeWidth: 3,
      }),
      e.jsx("path", {
        d: `M${t * 0.2} 0v-12M${t * 0.8} 0v-12`,
        stroke: "#0b1220",
        strokeWidth: 2,
      }),
      e.jsx("g", {
        fontSize: a,
        fontWeight: 800,
        fontFamily: "system-ui, sans-serif",
        textAnchor: "middle",
        strokeWidth: 1.2,
        children: c
          .filter((n) => n.char !== " ")
          .map((n) =>
            e.jsx(
              "text",
              {
                x: n.x,
                y: n.y,
                transform: `rotate(${n.tilt ?? 0} ${n.x} ${n.y - a * 0.36})`,
                fill: n.dead ? "#1e3a3f" : "#ccfbf1",
                stroke: n.dead ? "#2b4a50" : "#2dd4bf",
                opacity: n.dead ? 0.6 : 1,
                filter: n.dead ? void 0 : `url(#${r.glow})`,
                children: n.char,
              },
              n.index,
            ),
          ),
      }),
    ],
  });
}
function $e({ ids: t }) {
  return e.jsxs("g", {
    children: [
      e.jsx("rect", {
        width: 164,
        height: 150,
        rx: 6,
        fill: `url(#${t.peg})`,
        stroke: "#0b1220",
        strokeWidth: 3,
      }),
      e.jsx("g", {
        stroke: "#94a3b8",
        strokeWidth: 2,
        strokeLinecap: "round",
        children: e.jsx("path", {
          d: "M22 14v6M42 14v6M90 14v6M130 14v6M60 84v6",
        }),
      }),
      e.jsx("rect", {
        x: 17,
        y: 18,
        width: 10,
        height: 34,
        rx: 4,
        fill: "#ef4444",
      }),
      e.jsx("rect", {
        x: 18,
        y: 20,
        width: 3,
        height: 30,
        rx: 1.5,
        fill: "#fca5a5",
        opacity: 0.6,
      }),
      e.jsx("rect", { x: 20.5, y: 52, width: 3, height: 38, fill: "#cbd5e1" }),
      e.jsx("rect", {
        x: 37,
        y: 18,
        width: 10,
        height: 28,
        rx: 4,
        fill: "#facc15",
      }),
      e.jsx("rect", { x: 40.5, y: 46, width: 3, height: 28, fill: "#cbd5e1" }),
      e.jsxs("g", {
        children: [
          e.jsx("path", {
            d: "M84 20l6 30 6-30",
            stroke: "#64748b",
            strokeWidth: 4,
            fill: "none",
            strokeLinecap: "round",
          }),
          e.jsx("path", {
            d: "M86 50l-6 34M94 50l6 34",
            stroke: "#2563eb",
            strokeWidth: 7,
            strokeLinecap: "round",
          }),
          e.jsx("circle", { cx: 90, cy: 50, r: 3, fill: "#cbd5e1" }),
        ],
      }),
      e.jsx("circle", {
        cx: 132,
        cy: 40,
        r: 18,
        fill: "none",
        stroke: "#f59e0b",
        strokeWidth: 5,
      }),
      e.jsx("circle", {
        cx: 132,
        cy: 40,
        r: 11,
        fill: "none",
        stroke: "#d97706",
        strokeWidth: 4,
      }),
      e.jsx("path", {
        d: "M132 58c0 10 -6 16 -14 18",
        stroke: "#f59e0b",
        strokeWidth: 4,
        fill: "none",
        strokeLinecap: "round",
      }),
      e.jsxs("g", {
        transform: "translate(112 82)",
        children: [
          e.jsx("rect", { width: 42, height: 58, rx: 7, fill: "#facc15" }),
          e.jsx("rect", {
            x: 5,
            y: 6,
            width: 32,
            height: 16,
            rx: 2,
            fill: "#1f2937",
          }),
          e.jsx("text", {
            x: 21,
            y: 18,
            textAnchor: "middle",
            fontSize: 10,
            fill: "#86efac",
            fontFamily: "ui-monospace, monospace",
            children: "3.60",
          }),
          e.jsx("circle", { cx: 21, cy: 38, r: 9, fill: "#1f2937" }),
          e.jsx("path", {
            d: "M21 38l5-5",
            stroke: "#f8fafc",
            strokeWidth: 2,
            strokeLinecap: "round",
          }),
          e.jsx("circle", { cx: 10, cy: 52, r: 2.5, fill: "#ef4444" }),
          e.jsx("circle", { cx: 32, cy: 52, r: 2.5, fill: "#111827" }),
        ],
      }),
      e.jsxs("g", {
        transform: "translate(58 116)",
        children: [
          e.jsx("circle", {
            r: 24,
            fill: "#1f2937",
            stroke: "#475569",
            strokeWidth: 3,
          }),
          [0, 72, 144, 216, 288].map((s) =>
            e.jsx(
              "path",
              {
                d: "M0 -4c6-6 14-8 18-4c-4 2-10 4-18 4z",
                fill: "#64748b",
                transform: `rotate(${s})`,
              },
              s,
            ),
          ),
          e.jsx("circle", { r: 5, fill: "#94a3b8" }),
        ],
      }),
    ],
  });
}
function St({ ids: t }) {
  const s = [
    { x: 6, w: 48, h: 38, fill: "#e2e8f0", ink: "#0f766e", label: "CPU" },
    { x: 60, w: 42, h: 28, fill: "#fde68a", ink: "#92400e", label: "RAM" },
    { x: 108, w: 50, h: 44, fill: "#a5b4fc", ink: "#312e81", label: "FAN" },
  ];
  return e.jsxs("g", {
    children: [
      s.map((r) =>
        e.jsxs(
          "g",
          {
            children: [
              e.jsx("rect", {
                x: r.x,
                y: 44 - r.h,
                width: r.w,
                height: r.h,
                rx: 2,
                fill: r.fill,
              }),
              e.jsx("rect", {
                x: r.x,
                y: 44 - r.h,
                width: r.w,
                height: 6,
                fill: "rgba(15,23,42,0.12)",
              }),
              e.jsx("rect", {
                x: r.x + r.w - 10,
                y: 44 - r.h,
                width: 10,
                height: r.h,
                fill: "rgba(15,23,42,0.14)",
              }),
              e.jsx("text", {
                x: r.x + (r.w - 10) / 2 + 2,
                y: 44 - r.h / 2 + 5,
                textAnchor: "middle",
                fontSize: 11,
                fontWeight: 800,
                fill: r.ink,
                fontFamily: "system-ui, sans-serif",
                children: r.label,
              }),
            ],
          },
          r.label,
        ),
      ),
      e.jsx("rect", {
        y: 44,
        width: 164,
        height: 8,
        rx: 2,
        fill: `url(#${t.wood})`,
      }),
      e.jsx("path", { d: "M14 52v12l10-12M150 52v12l-10-12", fill: "#334155" }),
    ],
  });
}
function Ce({ ids: t }) {
  return e.jsxs("g", {
    children: [
      e.jsx("rect", {
        width: 132,
        height: 164,
        rx: 8,
        fill: "#111827",
        stroke: "#334155",
        strokeWidth: 3,
      }),
      e.jsx("rect", {
        x: 10,
        y: 10,
        width: 112,
        height: 146,
        rx: 4,
        fill: "#070d18",
      }),
      e.jsx("rect", {
        x: 10,
        y: 10,
        width: 112,
        height: 3,
        fill: "#2dd4bf",
        filter: `url(#${t.glow})`,
      }),
      e.jsx("rect", {
        x: 16,
        y: 18,
        width: 100,
        height: 118,
        rx: 3,
        fill: "#14532d",
      }),
      e.jsx("g", {
        stroke: "#22c55e",
        strokeWidth: 1,
        opacity: 0.5,
        fill: "none",
        children: e.jsx("path", {
          d: "M22 30h20v20M100 26v30h-12M24 120h40l8-8M96 120v-14",
        }),
      }),
      e.jsxs("g", {
        transform: "translate(52 56)",
        children: [
          e.jsx("rect", {
            x: -26,
            y: -26,
            width: 52,
            height: 52,
            rx: 6,
            fill: "#1f2937",
            stroke: "#64748b",
            strokeWidth: 2,
          }),
          e.jsx("circle", { r: 21, fill: "#0b1220" }),
          [0, 60, 120, 180, 240, 300].map((s) =>
            e.jsx(
              "path",
              {
                d: "M0 -4c6-8 16-11 20-6c-5 3-12 6-20 6z",
                fill: "#475569",
                transform: `rotate(${s})`,
              },
              s,
            ),
          ),
          e.jsx("circle", { r: 6, fill: "#94a3b8" }),
          e.jsx("circle", { r: 2.5, fill: "#2dd4bf" }),
        ],
      }),
      [88, 97].map((s) =>
        e.jsxs(
          "g",
          {
            children: [
              e.jsx("rect", {
                x: s,
                y: 30,
                width: 6,
                height: 50,
                rx: 1,
                fill: "#2563eb",
              }),
              e.jsx("rect", {
                x: s,
                y: 30,
                width: 6,
                height: 4,
                fill: "#93c5fd",
              }),
            ],
          },
          s,
        ),
      ),
      e.jsx("rect", {
        x: 20,
        y: 100,
        width: 92,
        height: 22,
        rx: 3,
        fill: "#334155",
      }),
      e.jsx("rect", {
        x: 20,
        y: 100,
        width: 92,
        height: 3,
        fill: "#a78bfa",
        filter: `url(#${t.glow})`,
      }),
      e.jsx("circle", {
        cx: 42,
        cy: 113,
        r: 7,
        fill: "#1f2937",
        stroke: "#64748b",
      }),
      e.jsx("circle", {
        cx: 70,
        cy: 113,
        r: 7,
        fill: "#1f2937",
        stroke: "#64748b",
      }),
      e.jsx("path", {
        d: "M24 140c10 0 16 6 20 14M60 156c4-10 14-14 26-14",
        stroke: "#f97316",
        strokeWidth: 3,
        fill: "none",
        strokeLinecap: "round",
      }),
      e.jsx("path", {
        d: "M96 156c0-8 6-12 14-12",
        stroke: "#64748b",
        strokeWidth: 4,
        fill: "none",
        strokeLinecap: "round",
      }),
      e.jsx("rect", {
        x: 10,
        y: 164,
        width: 18,
        height: 4,
        rx: 1,
        fill: "#020617",
      }),
      e.jsx("rect", {
        x: 104,
        y: 164,
        width: 18,
        height: 4,
        rx: 1,
        fill: "#020617",
      }),
    ],
  });
}
function Se() {
  return e.jsxs("g", {
    children: [
      e.jsx("rect", {
        width: 150,
        height: 88,
        rx: 6,
        fill: "#0f172a",
        stroke: "#334155",
        strokeWidth: 3,
      }),
      e.jsx("rect", {
        x: 8,
        y: 8,
        width: 134,
        height: 72,
        rx: 2,
        fill: "#04111f",
      }),
      e.jsx("text", {
        x: 16,
        y: 23,
        fontSize: 8,
        fontWeight: 700,
        letterSpacing: 1.4,
        fill: "#5eead4",
        fontFamily: "ui-monospace, monospace",
        children: "BENCHMARK",
      }),
      e.jsx("rect", {
        x: 16,
        y: 32,
        width: 118,
        height: 9,
        rx: 2,
        fill: "#1e293b",
      }),
      e.jsx("rect", {
        x: 16,
        y: 32,
        width: 112,
        height: 9,
        rx: 2,
        fill: "#fb7185",
      }),
      e.jsx("rect", {
        x: 16,
        y: 48,
        width: 118,
        height: 9,
        rx: 2,
        fill: "#1e293b",
      }),
      e.jsx("rect", {
        x: 16,
        y: 48,
        width: 68,
        height: 9,
        rx: 2,
        fill: "#2dd4bf",
      }),
      e.jsx("path", {
        d: "M96 30v30",
        stroke: "#fbbf24",
        strokeWidth: 1.5,
        strokeDasharray: "2 2",
      }),
      e.jsx("circle", { cx: 130, cy: 70, r: 3, fill: "#22c55e" }),
      e.jsx("rect", { x: 68, y: 88, width: 14, height: 12, fill: "#334155" }),
      e.jsx("rect", {
        x: 48,
        y: 100,
        width: 54,
        height: 8,
        rx: 3,
        fill: "#334155",
      }),
    ],
  });
}
function Ae() {
  return e.jsxs("g", {
    children: [
      e.jsx("rect", { width: 62, height: 14, rx: 3, fill: "#0f766e" }),
      [5, 24, 43].map((t) =>
        e.jsxs(
          "g",
          {
            children: [
              e.jsx("rect", {
                x: t,
                y: 2.5,
                width: 14,
                height: 9,
                rx: 1.5,
                fill: "#cbd5e1",
              }),
              e.jsx("rect", {
                x: t + 4,
                y: 5,
                width: 6,
                height: 4,
                fill: "#94a3b8",
              }),
              e.jsx("circle", { cx: t + 2, cy: 4.5, r: 0.9, fill: "#f59e0b" }),
            ],
          },
          t,
        ),
      ),
    ],
  });
}
const At = ["chess", "scientist", "gamer"];
function We({ w: t, h: s, queue: r, scale: a, ids: l }) {
  const o = s - 22,
    i = { x: 10, y: 10, w: t - 20, h: o - 10 },
    d = r.length > 1 ? Math.min(46 * a, (i.w - 64 * a) / (r.length - 1)) : 0;
  return e.jsxs("g", {
    children: [
      e.jsx("rect", { width: t, height: s, rx: 8, fill: "#334155" }),
      e.jsx("rect", {
        x: i.x,
        y: i.y,
        width: i.w,
        height: i.h,
        fill: `url(#${l.corridor})`,
      }),
      e.jsx("clipPath", {
        id: l.hatch,
        children: e.jsx("rect", { x: i.x, y: i.y, width: i.w, height: i.h }),
      }),
      e.jsxs("g", {
        clipPath: `url(#${l.hatch})`,
        children: [
          e.jsx("rect", {
            x: i.x,
            y: o - 40,
            width: i.w,
            height: 40,
            fill: "#1e293b",
            opacity: 0.6,
          }),
          e.jsx("rect", {
            x: i.x + i.w - 40,
            y: i.y + 26,
            width: 26,
            height: o - i.y - 66,
            rx: 2,
            fill: "#1e293b",
            opacity: 0.7,
          }),
          e.jsx("rect", {
            x: i.x + 12,
            y: i.y + 10,
            width: 34,
            height: 20,
            rx: 3,
            fill: "#0b1220",
          }),
          e.jsx("text", {
            x: i.x + 29,
            y: i.y + 25,
            textAnchor: "middle",
            fontSize: 13,
            fontWeight: 700,
            fill: "#f87171",
            fontFamily: "ui-monospace, monospace",
            children: "01",
          }),
          r
            .map((c, n) => ({ look: c, place: n }))
            .reverse()
            .map(({ look: c, place: n }) => {
              const x = a * (1 - n * 0.08);
              return e.jsx(
                "g",
                {
                  style: { filter: `brightness(${1 - n * 0.12})` },
                  children: e.jsx(T, {
                    x: i.x + 34 * a + n * d,
                    y: o + 6,
                    s: x,
                    flip: !0,
                    mood: n === 0 ? "calm" : "fed-up",
                    ...Me[c],
                  }),
                },
                `${c}-${n}`,
              );
            }),
        ],
      }),
      e.jsx("rect", {
        x: -6,
        y: o - 4,
        width: t + 12,
        height: 14,
        rx: 3,
        fill: `url(#${l.wood})`,
      }),
      e.jsx("rect", {
        x: -6,
        y: o + 10,
        width: t + 12,
        height: 4,
        fill: "rgba(2,6,23,0.4)",
      }),
      e.jsx("rect", {
        x: i.x + 10 * a,
        y: o - 12,
        width: 50 * a,
        height: 8,
        rx: 2,
        fill: "#475569",
      }),
      e.jsx("rect", {
        x: i.x + 10 * a,
        y: o - 12,
        width: 50 * a,
        height: 2,
        fill: "#94a3b8",
      }),
      e.jsxs("g", {
        transform: `translate(${t - 22} ${o - 4})`,
        children: [
          e.jsx("path", { d: "M-9 0a9 9 0 0 1 18 0z", fill: "#fbbf24" }),
          e.jsx("path", {
            d: "M-4 -6a6 6 0 0 1 5 -2",
            stroke: "#fef3c7",
            strokeWidth: 1.5,
            fill: "none",
          }),
          e.jsx("circle", { cy: -10, r: 2, fill: "#fbbf24" }),
        ],
      }),
    ],
  });
}
function Te({ w: t, h: s, ids: r }) {
  const a = Math.min(110, t * 0.22);
  return e.jsxs("g", {
    children: [
      e.jsx("rect", { width: t, height: 16, fill: `url(#${r.wood})` }),
      e.jsx("rect", { width: t, height: 2, fill: "#fbbf24", opacity: 0.35 }),
      e.jsx("rect", { y: 16, width: t, height: s - 16, fill: "#1b2638" }),
      e.jsx("rect", { y: 16, width: t, height: 8, fill: "rgba(2,6,23,0.45)" }),
      [12, t - 12 - a].map((l) =>
        [36, 36 + (s - 52) / 2].map((o) =>
          e.jsxs(
            "g",
            {
              children: [
                e.jsx("rect", {
                  x: l,
                  y: o,
                  width: a,
                  height: (s - 64) / 2,
                  rx: 4,
                  fill: "#26344b",
                  stroke: "#111827",
                  strokeWidth: 2,
                }),
                e.jsx("rect", {
                  x: l + a / 2 - 14,
                  y: o + 10,
                  width: 28,
                  height: 5,
                  rx: 2.5,
                  fill: "#64748b",
                }),
              ],
            },
            `${l}-${o}`,
          ),
        ),
      ),
    ],
  });
}
function Ee({ y: t, w: s, h: r }) {
  return e.jsxs("g", {
    children: [
      e.jsx("rect", { y: t, width: s, height: r, fill: "#0a101c" }),
      e.jsx("rect", { y: t, width: s, height: 10, fill: "rgba(0,0,0,0.45)" }),
      e.jsx("path", {
        d: `M0 ${t + r * 0.45}H${s}`,
        stroke: "#141c2b",
        strokeWidth: 2,
      }),
    ],
  });
}
function Ue() {
  const t = g.useId().replace(/:/g, "");
  return {
    peg: `${t}-peg`,
    glow: `${t}-glow`,
    cone: `${t}-cone`,
    wood: `${t}-wood`,
    wall: `${t}-wall`,
    corridor: `${t}-corridor`,
    vignette: `${t}-vignette`,
    hatch: `${t}-hatch`,
  };
}
const Re =
  "Inside the Upgrade Bay: an open computer and a benchmark screen on the bench, tools on the wall, and customers queuing at the hatch.";
function Wt({ queue: t }) {
  const s = Ue();
  return e.jsxs("svg", {
    viewBox: "0 0 360 780",
    preserveAspectRatio: "xMidYMid slice",
    className: "game-landing-art game-landing-portrait",
    role: "img",
    "aria-label": Re,
    children: [
      e.jsx(Ne, { ids: s }),
      e.jsx("rect", { width: 360, height: 780, fill: `url(#${s.wall})` }),
      e.jsx("rect", { width: 360, height: 30, fill: "#070c16" }),
      e.jsx("g", {
        transform: "translate(30 92)",
        children: e.jsx(ve, { w: 300, h: 78, ids: s }),
      }),
      e.jsx("g", {
        transform: "translate(14 190)",
        children: e.jsx($e, { ids: s }),
      }),
      e.jsx("g", {
        transform: "translate(196 186)",
        children: e.jsx(We, {
          w: 152,
          h: 226,
          queue: t.slice(0, 3),
          scale: 1.45,
          ids: s,
        }),
      }),
      e.jsx(q, { x: 96, top: 30, floor: 540, spread: 120, ids: s }),
      e.jsx(q, { x: 268, top: 30, floor: 540, spread: 120, ids: s }),
      e.jsx("g", {
        transform: "translate(22 372)",
        children: e.jsx(Ce, { ids: s }),
      }),
      e.jsx("g", { transform: "translate(192 432)", children: e.jsx(Se, {}) }),
      e.jsx("g", { transform: "translate(160 526)", children: e.jsx(Ae, {}) }),
      e.jsx("path", {
        d: "M300 536l40 -8",
        stroke: "#ef4444",
        strokeWidth: 6,
        strokeLinecap: "round",
      }),
      e.jsx("path", {
        d: "M340 528l12 -2.5",
        stroke: "#cbd5e1",
        strokeWidth: 2.5,
        strokeLinecap: "round",
      }),
      e.jsx("g", {
        transform: "translate(0 540)",
        children: e.jsx(Te, { w: 360, h: 170, ids: s }),
      }),
      e.jsx(Ee, { y: 710, w: 360, h: 70 }),
      e.jsx("rect", { width: 360, height: 780, fill: `url(#${s.vignette})` }),
    ],
  });
}
function Tt({ queue: t }) {
  const s = Ue();
  return e.jsxs("svg", {
    viewBox: "0 0 1280 720",
    preserveAspectRatio: "xMidYMid slice",
    className: "game-landing-art game-landing-landscape",
    role: "img",
    "aria-label": Re,
    children: [
      e.jsx(Ne, { ids: s }),
      e.jsx("rect", { width: 1280, height: 720, fill: `url(#${s.wall})` }),
      e.jsx("rect", { width: 1280, height: 36, fill: "#070c16" }),
      e.jsx("g", {
        transform: "translate(400 70)",
        children: e.jsx(ve, { w: 480, h: 100, ids: s }),
      }),
      e.jsx("g", {
        transform: "translate(56 150) scale(1.22)",
        children: e.jsx($e, { ids: s }),
      }),
      e.jsx("g", {
        transform: "translate(470 252) scale(1.5)",
        children: e.jsx(St, { ids: s }),
      }),
      e.jsx("g", {
        transform: "translate(840 150)",
        children: e.jsx(We, { w: 390, h: 300, queue: t, scale: 1.6, ids: s }),
      }),
      e.jsx(q, { x: 320, top: 36, floor: 540, spread: 240, ids: s }),
      e.jsx(q, { x: 960, top: 36, floor: 540, spread: 240, ids: s }),
      e.jsx("g", {
        transform: "translate(290 330) scale(1.25)",
        children: e.jsx(Ce, { ids: s }),
      }),
      e.jsx("g", {
        transform: "translate(470 367) scale(1.6)",
        children: e.jsx(Se, {}),
      }),
      e.jsx("g", {
        transform: "translate(84 518) scale(1.5)",
        children: e.jsx(Ae, {}),
      }),
      e.jsxs("g", {
        transform: "translate(210 522)",
        children: [
          e.jsx("rect", {
            width: 14,
            height: 18,
            rx: 1,
            fill: "#2563eb",
            transform: "rotate(-80)",
          }),
          e.jsx("rect", {
            x: 30,
            width: 14,
            height: 18,
            rx: 1,
            fill: "#2563eb",
            transform: "rotate(-80 30 0)",
          }),
        ],
      }),
      e.jsx("path", {
        d: "M740 534l70 -12",
        stroke: "#ef4444",
        strokeWidth: 8,
        strokeLinecap: "round",
      }),
      e.jsx("path", {
        d: "M810 522l20 -3.5",
        stroke: "#cbd5e1",
        strokeWidth: 3,
        strokeLinecap: "round",
      }),
      e.jsx("g", {
        transform: "translate(0 540)",
        children: e.jsx(Te, { w: 1280, h: 120, ids: s }),
      }),
      e.jsx(Ee, { y: 660, w: 1280, h: 60 }),
      e.jsx("rect", { width: 1280, height: 720, fill: `url(#${s.vignette})` }),
    ],
  });
}
function Et({ queue: t = At }) {
  return e.jsxs(e.Fragment, {
    children: [e.jsx(Wt, { queue: t }), e.jsx(Tt, { queue: t })],
  });
}
const z = `inline-flex items-center justify-center gap-2 rounded-lg px-5 py-2.5 text-sm font-semibold transition disabled:cursor-not-allowed disabled:opacity-40 focus:outline-none focus-visible:ring-2 focus-visible:ring-teal-300 ${Ye}`,
  ze =
    "inline-flex items-center justify-center gap-2 rounded-lg border border-slate-600 px-4 py-2.5 text-sm font-semibold text-slate-100 transition hover:bg-slate-800 disabled:cursor-not-allowed disabled:opacity-40 focus:outline-none focus-visible:ring-2 focus-visible:ring-teal-300",
  ne = 3200;
function M(t) {
  return `${t.toFixed(1)} s`;
}
function G(t) {
  const s = R(t);
  return _.map((r) => A(r, s[r])).join(" · ");
}
function Pe({ stars: t, size: s = "h-6 w-6" }) {
  return e.jsx("span", {
    className: "inline-flex gap-0.5",
    role: "img",
    "aria-label": `${t} of 3 stars`,
    children: [1, 2, 3].map((r) =>
      e.jsx(
        Ke,
        {
          "aria-hidden": "true",
          className: `${s} ${r <= t ? "fill-amber-300 text-amber-300" : "text-slate-600"}`,
        },
        r,
      ),
    ),
  });
}
function Ut({ shift: t, onStart: s }) {
  return e.jsxs(I.div, {
    initial: { opacity: 0 },
    animate: { opacity: 1 },
    className: "game-landing",
    "data-game-landing": !0,
    "data-upgrade-bay-phase": "intro",
    children: [
      e.jsx(Et, { queue: t.map(({ job: r }) => r.look) }),
      e.jsx("ul", {
        className: "sr-only",
        "aria-label": "Today’s customers",
        children: t.map(({ job: r }) =>
          e.jsx("li", { children: r.customer }, r.id),
        ),
      }),
      e.jsxs("button", {
        type: "button",
        onClick: s,
        className: `game-landing-start ${z}`,
        children: [
          e.jsx(de, { "aria-hidden": "true", className: "h-5 w-5" }),
          "Open the workshop",
        ],
      }),
    ],
  });
}
function Rt({ shift: t, records: s, active: r, points: a }) {
  return e.jsxs("div", {
    className: "flex items-center justify-between gap-3",
    "data-upgrade-bay-hud": !0,
    children: [
      e.jsx("ol", {
        className: "flex gap-1.5",
        "aria-label": `Customer ${Math.min(r + 1, t.length)} of ${t.length}`,
        children: t.map(({ job: l }, o) => {
          const i = s[o],
            d = i
              ? i.stars >= 2
                ? "ring-emerald-400"
                : "ring-rose-400"
              : o === r
                ? "ring-teal-300"
                : "ring-slate-700 opacity-50";
          return e.jsx(
            "li",
            {
              className: "relative",
              children: e.jsx(V, {
                look: l.look,
                className: `h-9 w-9 rounded-full ring-2 ${d}`,
              }),
            },
            l.id,
          );
        }),
      }),
      e.jsxs("p", {
        className: "text-right font-mono text-2xl font-bold text-slate-50",
        "data-upgrade-bay-points": !0,
        children: [
          a,
          e.jsx("span", { className: "sr-only", children: " points" }),
        ],
      }),
    ],
  });
}
function zt({ job: t }) {
  const s = w(t, t.start).seconds;
  return e.jsxs("article", {
    className:
      "overflow-hidden rounded-xl border border-slate-700 bg-slate-900/80",
    "data-job": t.id,
    children: [
      e.jsx(Ct, { look: t.look, className: "block h-auto w-full" }),
      e.jsxs("div", {
        className: "space-y-3 p-4",
        children: [
          e.jsxs("div", {
            className: "flex items-center gap-3",
            children: [
              e.jsx(V, {
                look: t.look,
                className: "h-10 w-10 shrink-0 rounded-full",
              }),
              e.jsxs("div", {
                children: [
                  e.jsx("h2", {
                    className: "text-xl font-semibold text-slate-50",
                    children: t.customer,
                  }),
                  e.jsx("p", {
                    className: "text-sm text-slate-400",
                    children: t.role,
                  }),
                ],
              }),
            ],
          }),
          e.jsx("blockquote", {
            className:
              "border-l-4 border-teal-400/60 pl-3 leading-7 text-slate-200",
            children: t.problem,
          }),
          e.jsxs("dl", {
            className: "grid grid-cols-2 gap-2 text-sm",
            children: [
              e.jsxs("div", {
                className: "col-span-2 rounded-lg bg-slate-950/60 px-3 py-2",
                children: [
                  e.jsx("dt", {
                    className: "text-slate-400",
                    children: "Benchmark",
                  }),
                  e.jsx("dd", {
                    className: "font-semibold text-slate-100",
                    children: t.task,
                  }),
                ],
              }),
              e.jsxs("div", {
                className: "rounded-lg bg-slate-950/60 px-3 py-2",
                children: [
                  e.jsx("dt", { className: "text-slate-400", children: "Now" }),
                  e.jsx("dd", {
                    className: "font-mono font-bold text-rose-300",
                    children: M(s),
                  }),
                ],
              }),
              e.jsxs("div", {
                className: "rounded-lg bg-slate-950/60 px-3 py-2",
                children: [
                  e.jsx("dt", {
                    className: "text-slate-400",
                    children: "Needs",
                  }),
                  e.jsxs("dd", {
                    className: "font-mono font-bold text-emerald-300",
                    children: [M(t.target), " or less"],
                  }),
                ],
              }),
            ],
          }),
        ],
      }),
    ],
  });
}
function Pt({ job: t, build: s, onStep: r, onReset: a, onRun: l }) {
  const [o, i] = g.useState(null),
    d = B(t, s),
    c = Math.min(100, (d / t.budget) * 100),
    n = d > 0;
  return e.jsxs("div", {
    className: "space-y-4",
    "data-upgrade-bay-phase": "bench",
    children: [
      e.jsx(be, {
        specs: R(s),
        focus: o,
        className: "block h-auto w-full rounded-xl",
      }),
      e.jsxs("div", {
        children: [
          e.jsxs("div", {
            className: "mb-1.5 flex justify-between text-sm",
            children: [
              e.jsx("span", {
                className: "text-slate-400",
                children: "Budget",
              }),
              e.jsxs("span", {
                className: "font-mono font-semibold text-slate-50",
                "data-budget-spent": d,
                children: ["£", d, " / £", t.budget],
              }),
            ],
          }),
          e.jsx("div", {
            className: "h-2.5 overflow-hidden rounded-full bg-slate-700",
            "aria-hidden": "true",
            children: e.jsx("div", {
              className: `h-full rounded-full transition-all duration-300 ${c > 90 ? "bg-amber-400" : "bg-teal-400"}`,
              style: { width: `${c}%` },
            }),
          }),
        ],
      }),
      e.jsx("div", {
        className: "grid gap-3 sm:grid-cols-3",
        children: _.map((x) =>
          e.jsx(
            ft,
            {
              trait: x,
              index: s[x],
              start: t.start[x],
              canLower: Y(t, s, x, -1),
              canRaise: Y(t, s, x, 1),
              onStep: (h) => r(x, h),
              onFocus: i,
            },
            x,
          ),
        ),
      }),
      e.jsxs("div", {
        className: "flex flex-wrap gap-3",
        children: [
          e.jsxs("button", {
            type: "button",
            onClick: l,
            className: z,
            children: [
              e.jsx(de, { "aria-hidden": "true", className: "h-4 w-4" }),
              "Run benchmark",
            ],
          }),
          e.jsxs("button", {
            type: "button",
            onClick: a,
            disabled: !n,
            className: ze,
            children: [
              e.jsx(fe, { "aria-hidden": "true", className: "h-4 w-4" }),
              "Reset",
            ],
          }),
        ],
      }),
    ],
  });
}
function Ft({ job: t, build: s, animate: r, onDone: a }) {
  const l = w(t, t.start).seconds,
    o = w(t, s).seconds,
    [i, d] = g.useState(r ? 0 : Number.POSITIVE_INFINITY),
    c = g.useRef(a);
  ((c.current = a),
    g.useEffect(() => {
      if (!r) {
        c.current();
        return;
      }
      let h = 0;
      const u = performance.now(),
        f = (m) => {
          const $ = m - u;
          if ((d($), $ >= ne)) {
            c.current();
            return;
          }
          h = requestAnimationFrame(f);
        };
      return ((h = requestAnimationFrame(f)), () => cancelAnimationFrame(h));
    }, [r]));
  const n = [
      {
        id: "before",
        name: "Before",
        specs: G(t.start),
        total: l,
        tone: "bg-rose-400",
      },
      {
        id: "after",
        name: "After",
        specs: G(s),
        total: o,
        tone: "bg-teal-400",
      },
    ],
    x = Math.min(100, (t.target / l) * 100);
  return e.jsxs("div", {
    className:
      "space-y-3 rounded-xl border border-slate-700 bg-slate-950/60 p-4",
    "data-race": !0,
    children: [
      n.map((h) => {
        const u = (h.total / l) * 100,
          f = Math.min(1, i / ne / (h.total / l));
        return e.jsxs(
          "div",
          {
            "data-race-row": h.id,
            children: [
              e.jsxs("div", {
                className:
                  "mb-1 flex flex-wrap items-baseline justify-between gap-x-3 text-sm",
                children: [
                  e.jsxs("span", {
                    className: "font-semibold text-slate-100",
                    children: [
                      h.name,
                      " ",
                      e.jsx("span", {
                        className: "font-normal text-slate-400",
                        children: h.specs,
                      }),
                    ],
                  }),
                  e.jsx("span", {
                    className: "font-mono font-bold text-slate-50",
                    children: M(Math.min(h.total, f * h.total)),
                  }),
                ],
              }),
              e.jsxs("div", {
                className: "relative h-4 rounded-full bg-slate-800",
                children: [
                  e.jsx("div", {
                    className: `ub-race-fill h-full rounded-full ${h.tone}`,
                    style: { width: `${u * f}%` },
                  }),
                  e.jsx("div", {
                    className:
                      "absolute -top-1 bottom-[-4px] w-0.5 bg-amber-300",
                    style: { left: `${x}%` },
                    "aria-hidden": "true",
                  }),
                ],
              }),
            ],
          },
          h.id,
        );
      }),
      e.jsxs("p", {
        className: "text-xs text-amber-200",
        children: [
          e.jsx("span", { "aria-hidden": "true", children: "| " }),
          t.customer,
          " needs ",
          M(t.target),
          " or less",
        ],
      }),
    ],
  });
}
const Lt = {
  helped: { Icon: K, tone: "text-emerald-300", label: "helped" },
  small: { Icon: he, tone: "text-amber-300", label: "helped a little" },
  wasted: { Icon: J, tone: "text-rose-300", label: "made no difference" },
};
function It({ job: t, build: s, stars: r }) {
  const a = w(t, t.start).seconds,
    l = w(t, s).seconds,
    o = at(t, s),
    i = ue(t),
    d = l <= t.target;
  return e.jsxs("div", {
    className: "space-y-4",
    "data-report": !0,
    "data-stars": r,
    children: [
      e.jsxs("div", {
        className: `flex items-start gap-3 rounded-xl border p-4 sm:items-center sm:gap-4 ${d ? "border-emerald-500/40 bg-emerald-500/10" : "border-rose-500/40 bg-rose-500/10"}`,
        children: [
          e.jsx(V, {
            look: t.look,
            className: "h-14 w-14 shrink-0 rounded-full",
          }),
          e.jsxs("div", {
            className: "min-w-0 flex-1",
            children: [
              e.jsx("p", {
                className: `text-base font-semibold sm:text-lg ${d ? "text-emerald-200" : "text-rose-200"}`,
                children: d
                  ? r === 3
                    ? "“That’s as fast as my budget could buy. Perfect!”"
                    : "“Much better, thank you!”"
                  : "“It’s still too slow for me.”",
              }),
              e.jsxs("div", {
                className:
                  "mt-1 flex flex-wrap items-center justify-between gap-x-4 gap-y-1",
                children: [
                  e.jsxs("p", {
                    className: "font-mono text-sm text-slate-300",
                    children: [
                      M(a),
                      " → ",
                      M(l),
                      e.jsxs("span", {
                        className: "text-slate-500",
                        children: [" (needs ", M(t.target), ")"],
                      }),
                    ],
                  }),
                  e.jsx(Pe, { stars: r, size: "h-7 w-7" }),
                ],
              }),
            ],
          }),
        ],
      }),
      e.jsxs("div", {
        className: "rounded-xl border border-slate-700 bg-slate-900/80 p-4",
        children: [
          e.jsx("h3", {
            className: "mb-3 text-base font-semibold text-slate-100",
            children: "What each upgrade did on its own",
          }),
          o.length === 0
            ? e.jsx("p", {
                className: "text-sm text-slate-400",
                children: "No upgrades: the CPU went back unchanged.",
              })
            : e.jsx("ul", {
                className: "space-y-3",
                children: o.map((c) => {
                  const n = Lt[c.effect];
                  return e.jsxs(
                    "li",
                    {
                      className: "flex gap-3",
                      "data-change": c.trait,
                      "data-effect": c.effect,
                      children: [
                        e.jsx(n.Icon, {
                          "aria-hidden": "true",
                          className: `mt-0.5 h-5 w-5 shrink-0 ${n.tone}`,
                        }),
                        e.jsxs("div", {
                          className: "min-w-0",
                          children: [
                            e.jsxs("p", {
                              className: "text-sm font-semibold text-slate-100",
                              children: [
                                Q[c.trait],
                                ": ",
                                A(c.trait, c.from),
                                " →",
                                " ",
                                A(c.trait, c.to),
                                " ",
                                e.jsxs("span", {
                                  className: `font-mono font-normal ${n.tone}`,
                                  children: [M(a), " → ", M(c.alone)],
                                }),
                                e.jsxs("span", {
                                  className: "sr-only",
                                  children: [", ", n.label],
                                }),
                              ],
                            }),
                            e.jsx("p", {
                              className: "text-sm leading-6 text-slate-300",
                              children: c.why,
                            }),
                          ],
                        }),
                      ],
                    },
                    c.trait,
                  );
                }),
              }),
        ],
      }),
      e.jsxs("div", {
        className: "rounded-xl border border-teal-400/30 bg-teal-400/10 p-4",
        children: [
          e.jsxs("p", {
            className: "flex gap-2 text-sm leading-6 text-slate-200",
            children: [
              e.jsx(Ge, {
                "aria-hidden": "true",
                className: "mt-0.5 h-5 w-5 shrink-0 text-amber-300",
              }),
              e.jsx("span", { children: t.lesson }),
            ],
          }),
          r < 3
            ? e.jsxs("p", {
                className:
                  "mt-3 border-t border-teal-400/20 pt-3 text-sm text-slate-300",
                "data-best-build": !0,
                children: [
                  "Best build for £",
                  t.budget,
                  ":",
                  " ",
                  e.jsx("strong", {
                    className: "text-slate-50",
                    children: G(i),
                  }),
                  ",",
                  " ",
                  e.jsx("span", {
                    className: "font-mono",
                    children: M(w(t, i).seconds),
                  }),
                ],
              })
            : null,
        ],
      }),
    ],
  });
}
function Bt({ shiftJob: t, answered: s, onAnswer: r }) {
  const { job: a, options: l } = t,
    o = a.followUp,
    [i, d] = g.useState([]),
    c = o.kind === "pick-two",
    n = (h) => (o.kind === "choice" ? h === o.answer : o.answers.includes(h));
  function x(h) {
    if (!s) {
      if (!c) {
        r([h]);
        return;
      }
      d((u) =>
        u.includes(h) ? u.filter((f) => f !== h) : u.length < 2 ? [...u, h] : u,
      );
    }
  }
  return e.jsxs("section", {
    className: "rounded-xl border border-slate-700 bg-slate-900/80 p-4 sm:p-5",
    "data-follow-up": a.id,
    children: [
      e.jsx("h3", {
        className: "mb-3 text-lg font-semibold leading-7 text-slate-50",
        children: o.prompt,
      }),
      o.kind === "choice" && o.table
        ? e.jsxs("figure", {
            className: "mb-4 overflow-x-auto",
            children: [
              e.jsxs("table", {
                className:
                  "w-full max-w-md border-collapse text-sm text-slate-200",
                children: [
                  e.jsx("thead", {
                    children: e.jsx("tr", {
                      children: o.table.headers.map((h) =>
                        e.jsx(
                          "th",
                          {
                            className:
                              "border border-slate-600 bg-slate-800 px-3 py-1.5 text-left",
                            children: h,
                          },
                          h,
                        ),
                      ),
                    }),
                  }),
                  e.jsx("tbody", {
                    children: o.table.rows.map((h) =>
                      e.jsx(
                        "tr",
                        {
                          children: h.map((u, f) =>
                            e.jsx(
                              "td",
                              {
                                className:
                                  "border border-slate-600 px-3 py-1.5 font-mono",
                                children: u,
                              },
                              f,
                            ),
                          ),
                        },
                        h[0],
                      ),
                    ),
                  }),
                ],
              }),
              e.jsx("figcaption", {
                className: "mt-1 text-xs text-slate-400",
                children: "Fig. 1",
              }),
            ],
          })
        : null,
      e.jsx("div", {
        className: "grid gap-2 sm:grid-cols-2",
        role: "group",
        "aria-label": c ? "Pick two answers" : "Answers",
        children: l.map((h) => {
          const u = s ? s.picked.includes(h) : i.includes(h),
            f = s
              ? n(h)
                ? "right"
                : u
                  ? "wrong"
                  : "idle"
              : u
                ? "chosen"
                : "idle",
            m =
              f === "right"
                ? "border-emerald-400 bg-emerald-500/15 text-emerald-50"
                : f === "wrong"
                  ? "border-rose-400 bg-rose-500/15 text-rose-50"
                  : f === "chosen"
                    ? "border-teal-300 bg-teal-400/15 text-slate-50"
                    : "border-slate-700 bg-slate-950/50 text-slate-200 hover:border-slate-500";
          return e.jsxs(
            "button",
            {
              type: "button",
              onClick: () => x(h),
              "aria-pressed": c ? u : void 0,
              "aria-disabled": s ? !0 : void 0,
              "data-option-state": f,
              className: `flex items-start gap-2 rounded-lg border px-3 py-2.5 text-left text-sm leading-6 transition focus:outline-none focus-visible:ring-2 focus-visible:ring-teal-300 ${m}`,
              children: [
                f === "right"
                  ? e.jsx(K, {
                      "aria-hidden": "true",
                      className: "mt-1 h-4 w-4 shrink-0 text-emerald-300",
                    })
                  : f === "wrong"
                    ? e.jsx(J, {
                        "aria-hidden": "true",
                        className: "mt-1 h-4 w-4 shrink-0 text-rose-300",
                      })
                    : null,
                e.jsx("span", { children: h }),
              ],
            },
            h,
          );
        }),
      }),
      c && !s
        ? e.jsx("button", {
            type: "button",
            className: `${z} mt-3`,
            disabled: i.length !== 2,
            onClick: () => r(i),
            children: "Check",
          })
        : null,
      s
        ? e.jsxs("div", {
            className: `mt-4 rounded-lg border-l-4 p-3 text-sm leading-6 ${s.right ? "border-emerald-400 bg-emerald-500/10 text-emerald-50" : "border-rose-400 bg-rose-500/10 text-rose-50"}`,
            "aria-live": "polite",
            "data-follow-up-result": s.right ? "right" : "wrong",
            children: [
              e.jsx("span", {
                className: "sr-only",
                children: s.right ? "Right. " : "Not right. ",
              }),
              e.jsxs("span", {
                className: "font-mono font-bold",
                children: ["+", s.right ? X : 0],
              }),
              " ",
              o.why,
            ],
          })
        : null,
    ],
  });
}
function Ot({ onDone: t }) {
  const [s, r] = g.useState(["", "", ""]),
    [a, l] = g.useState(null);
  function o(i) {
    (i.preventDefault(), !a && l(nt(s)));
  }
  return e.jsxs(I.form, {
    initial: { opacity: 0, y: 12 },
    animate: { opacity: 1, y: 0 },
    onSubmit: o,
    className:
      "space-y-4 rounded-xl border border-slate-700 bg-slate-900/80 p-4 sm:p-6",
    "data-upgrade-bay-phase": "exam",
    children: [
      e.jsxs("div", {
        className: "flex items-start justify-between gap-4",
        children: [
          e.jsx("h2", {
            className: "text-lg font-semibold leading-7 text-slate-50",
            children: U.prompt,
          }),
          e.jsxs("span", {
            className: "shrink-0 font-mono text-sm text-slate-400",
            children: ["[", U.marks, "]"],
          }),
        ],
      }),
      e.jsx("ol", {
        className: "space-y-2",
        children: s.map((i, d) => {
          const c = a?.credited[d];
          return e.jsxs(
            "li",
            {
              className: "flex items-center gap-3",
              children: [
                e.jsx("label", {
                  htmlFor: `ub-exam-${d}`,
                  className: "w-4 font-mono text-slate-400",
                  children: d + 1,
                }),
                e.jsx("input", {
                  id: `ub-exam-${d}`,
                  value: i,
                  readOnly: !!a,
                  autoComplete: "off",
                  onChange: (n) =>
                    r((x) => x.map((h, u) => (u === d ? n.target.value : h))),
                  className:
                    "min-w-0 flex-1 rounded-lg border border-slate-600 bg-slate-950 px-3 py-2 text-slate-50 placeholder:text-slate-600 focus:border-teal-300 focus:outline-none",
                }),
                a
                  ? c && c.length > 0
                    ? e.jsxs("span", {
                        className:
                          "flex shrink-0 items-center gap-1 text-sm text-emerald-300",
                        "data-exam-credit": c.join(" "),
                        children: [
                          c.map((n) =>
                            e.jsx(
                              K,
                              { "aria-hidden": "true", className: "h-4 w-4" },
                              n,
                            ),
                          ),
                          e.jsx("span", {
                            className: "sr-only",
                            children:
                              c.length === 1
                                ? "Mark for "
                                : `${c.length} marks for `,
                          }),
                          e.jsx("span", {
                            className: "hidden sm:inline",
                            children: c.map((n) => Q[n]).join(", "),
                          }),
                        ],
                      })
                    : e.jsx("span", {
                        className: "flex shrink-0 items-center text-rose-300",
                        "data-exam-credit": "none",
                        children: e.jsx(J, {
                          "aria-label": "No mark",
                          className: "h-4 w-4",
                        }),
                      })
                  : null,
              ],
            },
            d,
          );
        }),
      }),
      a
        ? e.jsxs("div", {
            className: "space-y-3",
            "aria-live": "polite",
            children: [
              e.jsxs("p", {
                className:
                  "rounded-lg border-l-4 border-teal-400 bg-teal-400/10 p-3 text-sm leading-6 text-slate-200",
                children: [
                  e.jsxs("strong", {
                    className: "font-mono text-slate-50",
                    children: [a.marks, "/", U.marks],
                  }),
                  " ",
                  U.guidance,
                ],
              }),
              e.jsxs("button", {
                type: "button",
                className: z,
                onClick: () => t(a.marks),
                children: [
                  e.jsx(xe, { "aria-hidden": "true", className: "h-4 w-4" }),
                  "Close the workshop",
                ],
              }),
            ],
          })
        : e.jsx("button", {
            type: "submit",
            className: z,
            disabled: s.every((i) => !i.trim()),
            children: "Mark my answer",
          }),
    ],
  });
}
function _t({ records: t, examMarks: s, points: r, onRestart: a }) {
  return e.jsxs(I.div, {
    initial: { opacity: 0, scale: 0.97 },
    animate: { opacity: 1, scale: 1 },
    className:
      "space-y-5 rounded-xl border border-slate-700 bg-slate-900/80 p-5 sm:p-7",
    "aria-live": "polite",
    "data-game-finished": !0,
    children: [
      e.jsxs("div", {
        className: "flex flex-wrap items-center justify-between gap-4",
        children: [
          e.jsxs("div", {
            className: "flex items-center gap-3",
            children: [
              e.jsx(xe, {
                "aria-hidden": "true",
                className: "h-10 w-10 text-amber-300",
              }),
              e.jsx("h2", {
                className: "text-3xl font-semibold text-slate-50",
                "data-rank": !0,
                children: dt(r),
              }),
            ],
          }),
          e.jsxs("p", {
            className: "font-mono text-3xl font-bold text-teal-200",
            children: [
              r,
              e.jsxs("span", {
                className: "text-lg text-slate-400",
                children: [" / ", ye],
              }),
            ],
          }),
        ],
      }),
      e.jsxs("ul", {
        className: "divide-y divide-slate-700/70 border-y border-slate-700/70",
        children: [
          t.map((l) =>
            e.jsxs(
              "li",
              {
                className: "flex flex-wrap items-center gap-3 py-3",
                "data-record": l.job.id,
                children: [
                  e.jsx(V, {
                    look: l.job.look,
                    className: "h-10 w-10 shrink-0 rounded-full",
                  }),
                  e.jsxs("div", {
                    className: "min-w-0 flex-1",
                    children: [
                      e.jsx("p", {
                        className: "font-semibold text-slate-100",
                        children: l.job.customer,
                      }),
                      e.jsxs("p", {
                        className: "font-mono text-xs text-slate-400",
                        children: [
                          G(l.build),
                          " · ",
                          M(l.seconds),
                          " (needs",
                          " ",
                          M(l.job.target),
                          ")",
                        ],
                      }),
                    ],
                  }),
                  e.jsx(Pe, { stars: l.stars, size: "h-5 w-5" }),
                  l.followUp
                    ? e.jsx(K, {
                        "aria-label": "Question right",
                        className: "h-5 w-5 text-emerald-300",
                      })
                    : e.jsx(J, {
                        "aria-label": "Question wrong",
                        className: "h-5 w-5 text-rose-300",
                      }),
                ],
              },
              l.job.id,
            ),
          ),
          e.jsxs("li", {
            className: "flex items-center justify-between gap-3 py-3",
            children: [
              e.jsx("p", {
                className: "font-semibold text-slate-100",
                children: "Exam question",
              }),
              e.jsxs("p", {
                className: "font-mono text-slate-200",
                children: [s, "/", U.marks],
              }),
            ],
          }),
        ],
      }),
      e.jsxs("button", {
        type: "button",
        onClick: a,
        className: ze,
        children: [
          e.jsx(fe, { "aria-hidden": "true", className: "h-4 w-4" }),
          "New shift",
        ],
      }),
    ],
  });
}
function Yt({ random: t }) {
  const [s, r] = g.useState(0),
    a = g.useMemo(() => lt(t ?? Math.random), [s, t]),
    [l, o] = g.useState("intro"),
    [i, d] = g.useState(0),
    [c, n] = g.useState(() => a[0].job.start),
    [x, h] = g.useState([]),
    [u, f] = g.useState(null),
    [m, $] = g.useState(0),
    [b, N] = g.useState(!1),
    j = a[i],
    k = x[i];
  Je(
    x.filter((p) => p.followUp !== null).length + (l === "done" ? 1 : 0),
    a.length + 1,
    x.filter((p) => p.stars >= 2 && p.followUp === !0).length +
      (l === "done" && m === U.marks ? 1 : 0),
  );
  const ee = ht({
    stars: x.reduce((p, C) => p + C.stars, 0),
    followUps: x.filter((p) => p.followUp).length,
    examMarks: m,
  });
  function Fe(p, C) {
    !j || !Y(j.job, c, p, C) || n((H) => ({ ...H, [p]: H[p] + C }));
  }
  function Le() {
    if (!j) return;
    const p = j.job;
    (N(!qe()),
      h((C) => [
        ...C.slice(0, i),
        {
          job: p,
          build: c,
          seconds: w(p, c).seconds,
          stars: rt(p, c),
          followUp: null,
        },
      ]),
      o("running"));
  }
  function Ie(p) {
    if (!j || u) return;
    const C = it(j.job, p);
    (f({ picked: p, right: C }),
      h((H) => H.map((te, _e) => (_e === i ? { ...te, followUp: C } : te))));
  }
  function Be() {
    const p = a[i + 1];
    if ((f(null), !p)) {
      o("exam");
      return;
    }
    (d(i + 1), n(p.job.start), o("bench"));
  }
  function Oe() {
    const p = s + 1;
    (r(p), d(0), h([]), f(null), $(0), o("intro"));
  }
  return (
    g.useEffect(() => {
      l === "intro" && n(a[0].job.start);
    }, [l, a]),
    e.jsx("div", {
      className: "upgrade-bay space-y-5 rounded-2xl p-4 sm:p-6",
      "data-upgrade-bay": !0,
      "data-phase": l,
      children:
        l === "intro"
          ? e.jsx(Ut, { shift: a, onStart: () => o("bench") })
          : l === "done"
            ? e.jsxs(e.Fragment, {
                children: [
                  e.jsx(_t, {
                    records: x,
                    examMarks: m,
                    points: ee,
                    onRestart: Oe,
                  }),
                  e.jsx(Ve, { game: "upgrade-bay" }),
                ],
              })
            : e.jsxs(e.Fragment, {
                children: [
                  e.jsx(Rt, {
                    shift: a,
                    records: x,
                    active: l === "exam" ? a.length : i,
                    points: ee,
                  }),
                  l === "exam"
                    ? e.jsx(Ot, {
                        onDone: (p) => {
                          ($(p), o("done"));
                        },
                      })
                    : j
                      ? e.jsxs(
                          I.div,
                          {
                            initial: { opacity: 0, x: 24 },
                            animate: { opacity: 1, x: 0 },
                            className:
                              "grid gap-5 lg:grid-cols-[minmax(0,0.9fr)_minmax(0,1.1fr)] lg:items-start",
                            children: [
                              e.jsx(zt, { job: j.job }),
                              l === "bench"
                                ? e.jsx(Pt, {
                                    job: j.job,
                                    build: c,
                                    onStep: Fe,
                                    onReset: () => n(j.job.start),
                                    onRun: Le,
                                  })
                                : e.jsxs("div", {
                                    className: "space-y-4",
                                    "data-upgrade-bay-phase": l,
                                    children: [
                                      e.jsx(be, {
                                        specs: R(c),
                                        run: Ht(j.job, c),
                                        animate: b && l === "running",
                                        className:
                                          "block h-auto w-full rounded-xl",
                                      }),
                                      e.jsx(Ft, {
                                        job: j.job,
                                        build: c,
                                        animate: b,
                                        onDone: () => o("report"),
                                      }),
                                    ],
                                  }),
                            ],
                          },
                          j.job.id,
                        )
                      : null,
                  l === "report" && j && k
                    ? e.jsxs(I.div, {
                        initial: { opacity: 0, y: 16 },
                        animate: { opacity: 1, y: 0 },
                        className: "space-y-4",
                        children: [
                          e.jsx(It, {
                            job: j.job,
                            build: k.build,
                            stars: k.stars,
                          }),
                          e.jsx(
                            Bt,
                            { shiftJob: j, answered: u, onAnswer: Ie },
                            j.job.id,
                          ),
                          u
                            ? e.jsx("button", {
                                type: "button",
                                onClick: Be,
                                className: z,
                                children:
                                  i + 1 >= a.length
                                    ? "Final exam question"
                                    : "Next customer",
                              })
                            : null,
                        ],
                      })
                    : null,
                ],
              }),
    })
  );
}
function Ht(t, s) {
  const r = w(t, s);
  return { coresUsed: r.coresUsed, cacheHits: r.cacheHits };
}
export { Yt as default };
