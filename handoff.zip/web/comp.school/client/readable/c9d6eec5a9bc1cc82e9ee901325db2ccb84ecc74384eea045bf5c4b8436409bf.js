/*! @license DOMPurify 3.4.14 | (c) Cure53 and other contributors | Released under the Apache license 2.0 and Mozilla Public License 2.0 | github.com/cure53/DOMPurify/blob/3.4.14/LICENSE */ function We(
  r,
  i,
) {
  (i == null || i > r.length) && (i = r.length);
  for (var s = 0, c = Array(i); s < i; s++) c[s] = r[s];
  return c;
}
function Fn(r) {
  if (Array.isArray(r)) return r;
}
function zn(r, i) {
  var s =
    r == null
      ? null
      : (typeof Symbol < "u" && r[Symbol.iterator]) || r["@@iterator"];
  if (s != null) {
    var c,
      f,
      d,
      y,
      st = [],
      N = !0,
      lt = !1;
    try {
      if (((d = (s = s.call(r)).next), i !== 0))
        for (
          ;
          !(N = (c = d.call(s)).done) && (st.push(c.value), st.length !== i);
          N = !0
        );
    } catch (xt) {
      ((lt = !0), (f = xt));
    } finally {
      try {
        if (!N && s.return != null && ((y = s.return()), Object(y) !== y))
          return;
      } finally {
        if (lt) throw f;
      }
    }
    return st;
  }
}
function Hn() {
  throw new TypeError(`Invalid attempt to destructure non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
}
function Gn(r, i) {
  return Fn(r) || zn(r, i) || Wn(r, i) || Hn();
}
function Wn(r, i) {
  if (r) {
    if (typeof r == "string") return We(r, i);
    var s = {}.toString.call(r).slice(8, -1);
    return (
      s === "Object" && r.constructor && (s = r.constructor.name),
      s === "Map" || s === "Set"
        ? Array.from(r)
        : s === "Arguments" ||
            /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(s)
          ? We(r, i)
          : void 0
    );
  }
}
const on = Object.entries,
  Be = Object.setPrototypeOf,
  Bn = Object.isFrozen,
  Yn = Object.getPrototypeOf,
  jn = Object.getOwnPropertyDescriptor;
let S = Object.freeze,
  b = Object.seal,
  it = Object.create,
  rn = typeof Reflect < "u" && Reflect,
  se = rn.apply,
  le = rn.construct;
S ||
  (S = function (i) {
    return i;
  });
b ||
  (b = function (i) {
    return i;
  });
se ||
  (se = function (i, s) {
    for (
      var c = arguments.length, f = new Array(c > 2 ? c - 2 : 0), d = 2;
      d < c;
      d++
    )
      f[d - 2] = arguments[d];
    return i.apply(s, f);
  });
le ||
  (le = function (i) {
    for (
      var s = arguments.length, c = new Array(s > 1 ? s - 1 : 0), f = 1;
      f < s;
      f++
    )
      c[f - 1] = arguments[f];
    return new i(...c);
  });
const V = A(Array.prototype.forEach),
  $n = A(Array.prototype.lastIndexOf),
  Ye = A(Array.prototype.pop),
  dt = A(Array.prototype.push),
  Xn = A(Array.prototype.splice),
  at = Array.isArray,
  _t = A(String.prototype.toLowerCase),
  ee = A(String.prototype.toString),
  je = A(String.prototype.match),
  Tt = A(String.prototype.replace),
  $e = A(String.prototype.indexOf),
  Vn = A(String.prototype.trim),
  qn = A(Number.prototype.toString),
  Kn = A(Boolean.prototype.toString),
  Xe = typeof BigInt > "u" ? null : A(BigInt.prototype.toString),
  Ve = typeof Symbol > "u" ? null : A(Symbol.prototype.toString),
  I = A(Object.prototype.hasOwnProperty),
  ht = A(Object.prototype.toString),
  O = A(RegExp.prototype.test),
  X = Zn(TypeError);
function A(r) {
  return function (i) {
    i instanceof RegExp && (i.lastIndex = 0);
    for (
      var s = arguments.length, c = new Array(s > 1 ? s - 1 : 0), f = 1;
      f < s;
      f++
    )
      c[f - 1] = arguments[f];
    return se(r, i, c);
  };
}
function Zn(r) {
  return function () {
    for (var i = arguments.length, s = new Array(i), c = 0; c < i; c++)
      s[c] = arguments[c];
    return le(r, s);
  };
}
function p(r, i) {
  let s = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : _t;
  if ((Be && Be(r, null), !at(i))) return r;
  let c = i.length;
  for (; c--;) {
    let f = i[c];
    if (typeof f == "string") {
      const d = s(f);
      d !== f && (Bn(i) || (i[c] = d), (f = d));
    }
    r[f] = !0;
  }
  return r;
}
function Jn(r) {
  for (let i = 0; i < r.length; i++) I(r, i) || (r[i] = null);
  return r;
}
function C(r) {
  const i = it(null);
  for (const c of on(r)) {
    var s = Gn(c, 2);
    const f = s[0],
      d = s[1];
    I(r, f) &&
      (at(d)
        ? (i[f] = Jn(d))
        : d && typeof d == "object" && d.constructor === Object
          ? (i[f] = C(d))
          : (i[f] = d));
  }
  return i;
}
function Qn(r) {
  switch (typeof r) {
    case "string":
      return r;
    case "number":
      return qn(r);
    case "boolean":
      return Kn(r);
    case "bigint":
      return Xe ? Xe(r) : "0";
    case "symbol":
      return Ve ? Ve(r) : "Symbol()";
    case "undefined":
      return ht(r);
    case "function":
    case "object": {
      if (r === null) return ht(r);
      const i = r,
        s = P(i, "toString");
      if (typeof s == "function") {
        const c = s(i);
        return typeof c == "string" ? c : ht(c);
      }
      return ht(r);
    }
    default:
      return ht(r);
  }
}
function P(r, i) {
  for (; r !== null;) {
    const c = jn(r, i);
    if (c) {
      if (c.get) return A(c.get);
      if (typeof c.value == "function") return A(c.value);
    }
    r = Yn(r);
  }
  function s() {
    return null;
  }
  return s;
}
function to(r) {
  try {
    return (O(r, ""), !0);
  } catch {
    return !1;
  }
}
const qe = S([
    "a",
    "abbr",
    "acronym",
    "address",
    "area",
    "article",
    "aside",
    "audio",
    "b",
    "bdi",
    "bdo",
    "big",
    "blink",
    "blockquote",
    "body",
    "br",
    "button",
    "canvas",
    "caption",
    "center",
    "cite",
    "code",
    "col",
    "colgroup",
    "content",
    "data",
    "datalist",
    "dd",
    "decorator",
    "del",
    "details",
    "dfn",
    "dialog",
    "dir",
    "div",
    "dl",
    "dt",
    "element",
    "em",
    "fieldset",
    "figcaption",
    "figure",
    "font",
    "footer",
    "form",
    "h1",
    "h2",
    "h3",
    "h4",
    "h5",
    "h6",
    "head",
    "header",
    "hgroup",
    "hr",
    "html",
    "i",
    "img",
    "input",
    "ins",
    "kbd",
    "label",
    "legend",
    "li",
    "main",
    "map",
    "mark",
    "marquee",
    "menu",
    "menuitem",
    "meter",
    "nav",
    "nobr",
    "ol",
    "optgroup",
    "option",
    "output",
    "p",
    "picture",
    "pre",
    "progress",
    "q",
    "rp",
    "rt",
    "ruby",
    "s",
    "samp",
    "search",
    "section",
    "select",
    "shadow",
    "slot",
    "small",
    "source",
    "spacer",
    "span",
    "strike",
    "strong",
    "style",
    "sub",
    "summary",
    "sup",
    "table",
    "tbody",
    "td",
    "template",
    "textarea",
    "tfoot",
    "th",
    "thead",
    "time",
    "tr",
    "track",
    "tt",
    "u",
    "ul",
    "var",
    "video",
    "wbr",
  ]),
  ne = S([
    "svg",
    "a",
    "altglyph",
    "altglyphdef",
    "altglyphitem",
    "animatecolor",
    "animatemotion",
    "animatetransform",
    "circle",
    "clippath",
    "defs",
    "desc",
    "ellipse",
    "enterkeyhint",
    "exportparts",
    "filter",
    "font",
    "g",
    "glyph",
    "glyphref",
    "hkern",
    "image",
    "inputmode",
    "line",
    "lineargradient",
    "marker",
    "mask",
    "metadata",
    "mpath",
    "part",
    "path",
    "pattern",
    "polygon",
    "polyline",
    "radialgradient",
    "rect",
    "stop",
    "style",
    "switch",
    "symbol",
    "text",
    "textpath",
    "title",
    "tref",
    "tspan",
    "view",
    "vkern",
  ]),
  oe = S([
    "feBlend",
    "feColorMatrix",
    "feComponentTransfer",
    "feComposite",
    "feConvolveMatrix",
    "feDiffuseLighting",
    "feDisplacementMap",
    "feDistantLight",
    "feDropShadow",
    "feFlood",
    "feFuncA",
    "feFuncB",
    "feFuncG",
    "feFuncR",
    "feGaussianBlur",
    "feImage",
    "feMerge",
    "feMergeNode",
    "feMorphology",
    "feOffset",
    "fePointLight",
    "feSpecularLighting",
    "feSpotLight",
    "feTile",
    "feTurbulence",
  ]),
  eo = S([
    "animate",
    "color-profile",
    "cursor",
    "discard",
    "font-face",
    "font-face-format",
    "font-face-name",
    "font-face-src",
    "font-face-uri",
    "foreignobject",
    "hatch",
    "hatchpath",
    "mesh",
    "meshgradient",
    "meshpatch",
    "meshrow",
    "missing-glyph",
    "script",
    "set",
    "solidcolor",
    "unknown",
    "use",
  ]),
  re = S([
    "math",
    "menclose",
    "merror",
    "mfenced",
    "mfrac",
    "mglyph",
    "mi",
    "mlabeledtr",
    "mmultiscripts",
    "mn",
    "mo",
    "mover",
    "mpadded",
    "mphantom",
    "mroot",
    "mrow",
    "ms",
    "mspace",
    "msqrt",
    "mstyle",
    "msub",
    "msup",
    "msubsup",
    "mtable",
    "mtd",
    "mtext",
    "mtr",
    "munder",
    "munderover",
    "mprescripts",
  ]),
  no = S([
    "maction",
    "maligngroup",
    "malignmark",
    "mlongdiv",
    "mscarries",
    "mscarry",
    "msgroup",
    "mstack",
    "msline",
    "msrow",
    "semantics",
    "annotation",
    "annotation-xml",
    "mprescripts",
    "none",
  ]),
  Ke = S(["#text"]),
  Ze = S([
    "accept",
    "action",
    "align",
    "alt",
    "autocapitalize",
    "autocomplete",
    "autopictureinpicture",
    "autoplay",
    "background",
    "bgcolor",
    "border",
    "capture",
    "cellpadding",
    "cellspacing",
    "checked",
    "cite",
    "class",
    "clear",
    "color",
    "cols",
    "colspan",
    "command",
    "commandfor",
    "controls",
    "controlslist",
    "coords",
    "crossorigin",
    "datetime",
    "decoding",
    "default",
    "dir",
    "disabled",
    "disablepictureinpicture",
    "disableremoteplayback",
    "download",
    "draggable",
    "enctype",
    "enterkeyhint",
    "exportparts",
    "face",
    "for",
    "headers",
    "height",
    "hidden",
    "high",
    "href",
    "hreflang",
    "id",
    "inert",
    "inputmode",
    "integrity",
    "ismap",
    "kind",
    "label",
    "lang",
    "list",
    "loading",
    "loop",
    "low",
    "max",
    "maxlength",
    "media",
    "method",
    "min",
    "minlength",
    "multiple",
    "muted",
    "name",
    "nonce",
    "noshade",
    "novalidate",
    "nowrap",
    "open",
    "optimum",
    "part",
    "pattern",
    "placeholder",
    "playsinline",
    "popover",
    "popovertarget",
    "popovertargetaction",
    "poster",
    "preload",
    "pubdate",
    "radiogroup",
    "readonly",
    "rel",
    "required",
    "rev",
    "reversed",
    "role",
    "rows",
    "rowspan",
    "spellcheck",
    "scope",
    "selected",
    "shape",
    "size",
    "sizes",
    "slot",
    "span",
    "srclang",
    "start",
    "src",
    "srcset",
    "step",
    "style",
    "summary",
    "tabindex",
    "title",
    "translate",
    "type",
    "usemap",
    "valign",
    "value",
    "width",
    "wrap",
    "xmlns",
  ]),
  ie = S([
    "accent-height",
    "accumulate",
    "additive",
    "alignment-baseline",
    "amplitude",
    "ascent",
    "attributename",
    "attributetype",
    "azimuth",
    "basefrequency",
    "baseline-shift",
    "begin",
    "bias",
    "by",
    "class",
    "clip",
    "clippathunits",
    "clip-path",
    "clip-rule",
    "color",
    "color-interpolation",
    "color-interpolation-filters",
    "color-profile",
    "color-rendering",
    "cx",
    "cy",
    "d",
    "dx",
    "dy",
    "diffuseconstant",
    "direction",
    "display",
    "divisor",
    "dominant-baseline",
    "dur",
    "edgemode",
    "elevation",
    "end",
    "exponent",
    "fill",
    "fill-opacity",
    "fill-rule",
    "filter",
    "filterunits",
    "flood-color",
    "flood-opacity",
    "font-family",
    "font-size",
    "font-size-adjust",
    "font-stretch",
    "font-style",
    "font-variant",
    "font-weight",
    "fx",
    "fy",
    "g1",
    "g2",
    "glyph-name",
    "glyphref",
    "gradientunits",
    "gradienttransform",
    "height",
    "href",
    "id",
    "image-rendering",
    "in",
    "in2",
    "intercept",
    "k",
    "k1",
    "k2",
    "k3",
    "k4",
    "kerning",
    "keypoints",
    "keysplines",
    "keytimes",
    "lang",
    "lengthadjust",
    "letter-spacing",
    "kernelmatrix",
    "kernelunitlength",
    "lighting-color",
    "local",
    "marker-end",
    "marker-mid",
    "marker-start",
    "markerheight",
    "markerunits",
    "markerwidth",
    "maskcontentunits",
    "maskunits",
    "max",
    "mask",
    "mask-type",
    "media",
    "method",
    "mode",
    "min",
    "name",
    "numoctaves",
    "offset",
    "operator",
    "opacity",
    "order",
    "orient",
    "orientation",
    "origin",
    "overflow",
    "paint-order",
    "path",
    "pathlength",
    "patterncontentunits",
    "patterntransform",
    "patternunits",
    "pointer-events",
    "points",
    "preservealpha",
    "preserveaspectratio",
    "primitiveunits",
    "r",
    "rx",
    "ry",
    "radius",
    "refx",
    "refy",
    "repeatcount",
    "repeatdur",
    "restart",
    "result",
    "rotate",
    "scale",
    "seed",
    "shape-rendering",
    "slope",
    "specularconstant",
    "specularexponent",
    "spreadmethod",
    "startoffset",
    "stddeviation",
    "stitchtiles",
    "stop-color",
    "stop-opacity",
    "stroke-dasharray",
    "stroke-dashoffset",
    "stroke-linecap",
    "stroke-linejoin",
    "stroke-miterlimit",
    "stroke-opacity",
    "stroke",
    "stroke-width",
    "style",
    "surfacescale",
    "systemlanguage",
    "tabindex",
    "tablevalues",
    "targetx",
    "targety",
    "transform",
    "transform-origin",
    "text-anchor",
    "text-decoration",
    "text-orientation",
    "text-rendering",
    "textlength",
    "type",
    "u1",
    "u2",
    "unicode",
    "values",
    "vector-effect",
    "viewbox",
    "visibility",
    "version",
    "vert-adv-y",
    "vert-origin-x",
    "vert-origin-y",
    "width",
    "word-spacing",
    "wrap",
    "writing-mode",
    "xchannelselector",
    "ychannelselector",
    "x",
    "x1",
    "x2",
    "xmlns",
    "y",
    "y1",
    "y2",
    "z",
    "zoomandpan",
  ]),
  Je = S([
    "accent",
    "accentunder",
    "align",
    "bevelled",
    "close",
    "columnalign",
    "columnlines",
    "columnspacing",
    "columnspan",
    "denomalign",
    "depth",
    "dir",
    "display",
    "displaystyle",
    "encoding",
    "fence",
    "frame",
    "height",
    "href",
    "id",
    "largeop",
    "length",
    "linethickness",
    "lquote",
    "lspace",
    "mathbackground",
    "mathcolor",
    "mathsize",
    "mathvariant",
    "maxsize",
    "minsize",
    "movablelimits",
    "notation",
    "numalign",
    "open",
    "rowalign",
    "rowlines",
    "rowspacing",
    "rowspan",
    "rspace",
    "rquote",
    "scriptlevel",
    "scriptminsize",
    "scriptsizemultiplier",
    "selection",
    "separator",
    "separators",
    "stretchy",
    "subscriptshift",
    "supscriptshift",
    "symmetric",
    "voffset",
    "width",
    "xmlns",
  ]),
  Pt = S(["xlink:href", "xml:id", "xlink:title", "xml:space", "xmlns:xlink"]),
  oo = b(/{{[\w\W]*|^[\w\W]*}}/g),
  ro = b(/<%[\w\W]*|^[\w\W]*%>/g),
  io = b(/\${[\w\W]*/g),
  ao = b(/^data-[\-\w.\u00B7-\uFFFF]+$/),
  so = b(/^aria-[\-\w]+$/),
  Qe = b(
    /^(?:(?:(?:f|ht)tps?|mailto|tel|callto|sms|cid|xmpp|matrix):|[^a-z]|[a-z+.\-]+(?:[^a-z+.\-:]|$))/i,
  ),
  lo = b(/^(?:\w+script|data):/i),
  co = b(/[\u0000-\u0020\u00A0\u1680\u180E\u2000-\u2029\u205F\u3000]/g),
  uo = b(/^html$/i),
  fo = b(/^[a-z][.\w]*(-[.\w]+)+$/i),
  tn = b(/<[/\w!]/g),
  en = b(/<[/\w]/g),
  po = b(/<\/no(script|embed|frames)/i),
  mo = b(/\/>/i),
  M = {
    element: 1,
    attribute: 2,
    text: 3,
    cdataSection: 4,
    entityReference: 5,
    entityNode: 6,
    processingInstruction: 7,
    comment: 8,
    document: 9,
    documentType: 10,
    documentFragment: 11,
    notation: 12,
  },
  an = [
    "style",
    "script",
    "xmp",
    "iframe",
    "noembed",
    "noframes",
    "plaintext",
    "noscript",
  ],
  To = S(p({}, an)),
  ho = (function () {
    const r = {};
    return (
      V(an, (i) => {
        r[i] = b(new RegExp("</" + i + "(?=[\\t\\n\\f\\r />])", "i"));
      }),
      S(r)
    );
  })(),
  _o = function () {
    return typeof window > "u" ? null : window;
  },
  go = function (i, s) {
    if (typeof i != "object" || typeof i.createPolicy != "function")
      return null;
    let c = null;
    const f = "data-tt-policy-suffix";
    s && s.hasAttribute(f) && (c = s.getAttribute(f));
    const d = "dompurify" + (c ? "#" + c : "");
    try {
      return i.createPolicy(d, {
        createHTML(y) {
          return y;
        },
        createScriptURL(y) {
          return y;
        },
      });
    } catch {
      return (
        console.warn("TrustedTypes policy " + d + " could not be created."),
        null
      );
    }
  },
  nn = function () {
    return {
      afterSanitizeAttributes: [],
      afterSanitizeElements: [],
      afterSanitizeShadowDOM: [],
      beforeSanitizeAttributes: [],
      beforeSanitizeElements: [],
      beforeSanitizeShadowDOM: [],
      uponSanitizeAttribute: [],
      uponSanitizeElement: [],
      uponSanitizeShadowNode: [],
    };
  },
  H = function (i, s, c, f) {
    return I(i, s) && at(i[s])
      ? p(f.base ? C(f.base) : {}, i[s], f.transform)
      : c;
  },
  ae = function (i, s, c) {
    const f = I(i, s) ? i[s] : void 0;
    return f && typeof f == "object" ? C(f) : c();
  };
function sn() {
  let r = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : _o();
  const i = (o) => sn(o);
  if (
    ((i.version = "3.4.14"),
    (i.removed = []),
    !r || !r.document || r.document.nodeType !== M.document || !r.Element)
  )
    return ((i.isSupported = !1), i);
  let s = r.document;
  const c = s,
    f = c.currentScript;
  r.DocumentFragment;
  const d = r.HTMLTemplateElement,
    y = r.Node,
    st = r.Element,
    N = r.NodeFilter,
    lt = r.NamedNodeMap;
  (lt === void 0 && (r.NamedNodeMap || r.MozNamedAttrMap), r.HTMLFormElement);
  const xt = r.DOMParser,
    gt = r.trustedTypes,
    G = st.prototype,
    ln = P(G, "cloneNode"),
    vt = P(G, "remove"),
    cn = P(G, "nextSibling"),
    q = P(G, "childNodes"),
    K = P(G, "parentNode"),
    ce = P(G, "shadowRoot"),
    kt = P(G, "attributes"),
    W = y && y.prototype ? P(y.prototype, "nodeType") : null,
    Z = y && y.prototype ? P(y.prototype, "nodeName") : null,
    Et = y && y.prototype ? P(y.prototype, "ownerDocument") : null,
    ct = function (t) {
      return W ? W(t) : t.nodeType;
    },
    Ut = function (t) {
      return Z ? Z(t) : t.nodeName;
    };
  if (typeof d == "function") {
    const o = s.createElement("template");
    o.content && o.content.ownerDocument && (s = o.content.ownerDocument);
  }
  let L,
    B = "",
    Ft,
    ue = !1,
    ut = 0;
  const fe = function () {
      if (ut > 0)
        throw X(
          'A configured TRUSTED_TYPES_POLICY callback (createHTML or createScriptURL) must not call DOMPurify.sanitize, as that causes infinite recursion. Do not pass a policy whose callbacks wrap DOMPurify as TRUSTED_TYPES_POLICY; see the "DOMPurify and Trusted Types" section of the README.',
        );
    },
    J = function (t) {
      (fe(), ut++);
      try {
        return L.createHTML(t);
      } finally {
        ut--;
      }
    },
    un = function (t) {
      (fe(), ut++);
      try {
        return L.createScriptURL(t);
      } finally {
        ut--;
      }
    },
    fn = function () {
      return (ue || ((Ft = go(gt, f)), (ue = !0)), Ft);
    },
    At = s,
    zt = At.implementation,
    pe = At.createNodeIterator,
    pn = At.createDocumentFragment,
    mn = At.getElementsByTagName,
    dn = c.importNode;
  let T = nn();
  i.isSupported =
    typeof on == "function" &&
    typeof K == "function" &&
    zt &&
    zt.createHTMLDocument !== void 0;
  const Tn = oo,
    hn = ro,
    _n = io,
    gn = ao,
    En = so,
    An = lo,
    me = co,
    yn = fo;
  let de = Qe,
    h = null;
  const Ht = p({}, [...qe, ...ne, ...oe, ...re, ...Ke]);
  let _ = null;
  const Gt = p({}, [...Ze, ...ie, ...Je, ...Pt]);
  let x = Object.seal(
      it(null, {
        tagNameCheck: {
          writable: !0,
          configurable: !1,
          enumerable: !0,
          value: null,
        },
        attributeNameCheck: {
          writable: !0,
          configurable: !1,
          enumerable: !0,
          value: null,
        },
        allowCustomizedBuiltInElements: {
          writable: !0,
          configurable: !1,
          enumerable: !0,
          value: !1,
        },
      }),
    ),
    ft = null,
    Te = null;
  const U = Object.seal(
    it(null, {
      tagCheck: { writable: !0, configurable: !1, enumerable: !0, value: null },
      attributeCheck: {
        writable: !0,
        configurable: !1,
        enumerable: !0,
        value: null,
      },
    }),
  );
  let he = !0,
    Wt = !0,
    _e = !1,
    ge = !0,
    F = !1,
    Y = !0,
    j = !1,
    Bt = !1,
    yt = null,
    St = null,
    Yt = !1,
    Q = !1,
    bt = !1,
    Ot = !1,
    Ee = !0,
    Ae = !1;
  const ye = "user-content-";
  let jt = !0,
    $t = !1,
    tt = {},
    et = null;
  const Se = p({}, [
    "annotation-xml",
    "audio",
    "colgroup",
    "desc",
    "foreignobject",
    "head",
    "iframe",
    "math",
    "mi",
    "mn",
    "mo",
    "ms",
    "mtext",
    "noembed",
    "noframes",
    "noscript",
    "plaintext",
    "script",
    "selectedcontent",
    "style",
    "svg",
    "template",
    "thead",
    "title",
    "video",
    "xmp",
  ]);
  let be = null;
  const Oe = p({}, ["audio", "video", "img", "source", "image", "track"]);
  let Re = null;
  const Le = p({}, [
      "alt",
      "class",
      "for",
      "id",
      "label",
      "name",
      "pattern",
      "placeholder",
      "role",
      "summary",
      "title",
      "value",
      "style",
      "xmlns",
    ]),
    Rt = "http://www.w3.org/1998/Math/MathML",
    Lt = "http://www.w3.org/2000/svg",
    v = "http://www.w3.org/1999/xhtml";
  let nt = v,
    Xt = !1,
    Vt = null;
  const Sn = p({}, [Rt, Lt, v], ee),
    De = S(["mi", "mo", "mn", "ms", "mtext"]);
  let qt = p({}, De);
  const we = S(["annotation-xml"]);
  let Kt = p({}, we);
  const bn = p({}, ["title", "style", "font", "a", "script"]);
  let pt = null;
  const On = ["application/xhtml+xml", "text/html"],
    Rn = "text/html";
  let E = null,
    ot = null;
  const Ln = s.createElement("form"),
    Ie = function (t) {
      return t instanceof RegExp || t instanceof Function;
    },
    Zt = function () {
      let t =
        arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
      if (ot && ot === t) return;
      ((!t || typeof t != "object") && (t = {}),
        (t = C(t)),
        (pt =
          On.indexOf(t.PARSER_MEDIA_TYPE) === -1 ? Rn : t.PARSER_MEDIA_TYPE),
        (E = pt === "application/xhtml+xml" ? ee : _t),
        (h = H(t, "ALLOWED_TAGS", Ht, { transform: E })),
        (_ = H(t, "ALLOWED_ATTR", Gt, { transform: E })),
        (Vt = H(t, "ALLOWED_NAMESPACES", Sn, { transform: ee })),
        (Re = H(t, "ADD_URI_SAFE_ATTR", Le, { transform: E, base: Le })),
        (be = H(t, "ADD_DATA_URI_TAGS", Oe, { transform: E, base: Oe })),
        (et = H(t, "FORBID_CONTENTS", Se, { transform: E })),
        (ft = H(t, "FORBID_TAGS", C({}), { transform: E })),
        (Te = H(t, "FORBID_ATTR", C({}), { transform: E })),
        (tt = I(t, "USE_PROFILES")
          ? t.USE_PROFILES && typeof t.USE_PROFILES == "object"
            ? C(t.USE_PROFILES)
            : t.USE_PROFILES
          : !1),
        (he = t.ALLOW_ARIA_ATTR !== !1),
        (Wt = t.ALLOW_DATA_ATTR !== !1),
        (_e = t.ALLOW_UNKNOWN_PROTOCOLS || !1),
        (ge = t.ALLOW_SELF_CLOSE_IN_ATTR !== !1),
        (F = t.SAFE_FOR_TEMPLATES || !1),
        (Y = t.SAFE_FOR_XML !== !1),
        (j = t.WHOLE_DOCUMENT || !1),
        (Q = t.RETURN_DOM || !1),
        (bt = t.RETURN_DOM_FRAGMENT || !1),
        (Ot = t.RETURN_TRUSTED_TYPE || !1),
        (Yt = t.FORCE_BODY || !1),
        (Ee = t.SANITIZE_DOM !== !1),
        (Ae = t.SANITIZE_NAMED_PROPS || !1),
        (jt = t.KEEP_CONTENT !== !1),
        ($t = t.IN_PLACE || !1),
        (de = to(t.ALLOWED_URI_REGEXP) ? t.ALLOWED_URI_REGEXP : Qe),
        (nt = typeof t.NAMESPACE == "string" ? t.NAMESPACE : v),
        (qt = ae(t, "MATHML_TEXT_INTEGRATION_POINTS", () => p({}, De))),
        (Kt = ae(t, "HTML_INTEGRATION_POINTS", () => p({}, we))));
      const e = ae(t, "CUSTOM_ELEMENT_HANDLING", () => it(null));
      if (
        ((x = it(null)),
        I(e, "tagNameCheck") &&
          Ie(e.tagNameCheck) &&
          (x.tagNameCheck = e.tagNameCheck),
        I(e, "attributeNameCheck") &&
          Ie(e.attributeNameCheck) &&
          (x.attributeNameCheck = e.attributeNameCheck),
        I(e, "allowCustomizedBuiltInElements") &&
          typeof e.allowCustomizedBuiltInElements == "boolean" &&
          (x.allowCustomizedBuiltInElements = e.allowCustomizedBuiltInElements),
        b(x),
        F && (Wt = !1),
        bt && (Q = !0),
        tt &&
          ((h = p({}, Ke)),
          (_ = it(null)),
          tt.html === !0 && (p(h, qe), p(_, Ze)),
          tt.svg === !0 && (p(h, ne), p(_, ie), p(_, Pt)),
          tt.svgFilters === !0 && (p(h, oe), p(_, ie), p(_, Pt)),
          tt.mathMl === !0 && (p(h, re), p(_, Je), p(_, Pt))),
        (U.tagCheck = null),
        (U.attributeCheck = null),
        I(t, "ADD_TAGS") &&
          (typeof t.ADD_TAGS == "function"
            ? (U.tagCheck = t.ADD_TAGS)
            : at(t.ADD_TAGS) && (h === Ht && (h = C(h)), p(h, t.ADD_TAGS, E))),
        I(t, "ADD_ATTR") &&
          (typeof t.ADD_ATTR == "function"
            ? (U.attributeCheck = t.ADD_ATTR)
            : at(t.ADD_ATTR) && (_ === Gt && (_ = C(_)), p(_, t.ADD_ATTR, E))),
        I(t, "ADD_FORBID_CONTENTS") &&
          at(t.ADD_FORBID_CONTENTS) &&
          (et === Se && (et = C(et)), p(et, t.ADD_FORBID_CONTENTS, E)),
        jt && (h["#text"] = !0),
        j && p(h, ["html", "head", "body"]),
        h.table && (p(h, ["tbody"]), delete ft.tbody),
        t.TRUSTED_TYPES_POLICY)
      ) {
        if (typeof t.TRUSTED_TYPES_POLICY.createHTML != "function")
          throw X(
            'TRUSTED_TYPES_POLICY configuration option must provide a "createHTML" hook.',
          );
        if (typeof t.TRUSTED_TYPES_POLICY.createScriptURL != "function")
          throw X(
            'TRUSTED_TYPES_POLICY configuration option must provide a "createScriptURL" hook.',
          );
        const n = L;
        L = t.TRUSTED_TYPES_POLICY;
        try {
          B = J("");
        } catch (a) {
          throw ((L = n), a);
        }
      } else
        t.TRUSTED_TYPES_POLICY === null
          ? ((L = void 0), (B = ""))
          : (L === void 0 && (L = fn()),
            L && typeof B == "string" && (B = J("")));
      (S && S(t), (ot = t));
    },
    Ne = p({}, [...ne, ...oe, ...eo]),
    Me = p({}, [...re, ...no]),
    Dn = function (t, e, n) {
      return e.namespaceURI === v
        ? t === "svg"
        : e.namespaceURI === Rt
          ? t === "svg" && (n === "annotation-xml" || qt[n])
          : !!Ne[t];
    },
    wn = function (t, e, n) {
      return e.namespaceURI === v
        ? t === "math"
        : e.namespaceURI === Lt
          ? t === "math" && Kt[n]
          : !!Me[t];
    },
    In = function (t, e, n) {
      return (e.namespaceURI === Lt && !Kt[n]) ||
        (e.namespaceURI === Rt && !qt[n])
        ? !1
        : !Me[t] && (bn[t] || !Ne[t]);
    },
    Nn = function (t) {
      let e = K(t);
      (!e || !e.tagName) && (e = { namespaceURI: nt, tagName: "template" });
      const n = _t(t.tagName),
        a = _t(e.tagName);
      return Vt[t.namespaceURI]
        ? t.namespaceURI === Lt
          ? Dn(n, e, a)
          : t.namespaceURI === Rt
            ? wn(n, e, a)
            : t.namespaceURI === v
              ? In(n, e, a)
              : !!(pt === "application/xhtml+xml" && Vt[t.namespaceURI])
        : !1;
    },
    z = function (t) {
      dt(i.removed, { element: t });
      try {
        K(t).removeChild(t);
      } catch {
        if ((vt(t), !K(t)))
          throw X(
            "a node selected for removal could not be detached from its tree and cannot be safely returned; refusing to sanitize in place",
          );
      }
    },
    Ce = function (t, e, n) {
      try {
        t.removeAttributeNode(e);
      } catch {
        try {
          t.removeAttribute(n);
        } catch {}
      }
    },
    Dt = function (t) {
      wt(t);
      const e = q(t);
      if (e) {
        const a = [];
        (V(e, (l) => {
          dt(a, l);
        }),
          V(a, (l) => {
            try {
              vt(l);
            } catch {}
          }));
      }
      const n = kt(t);
      if (n)
        for (let a = n.length - 1; a >= 0; --a) {
          const l = n[a],
            u = l && l.name;
          typeof u == "string" && Ce(t, l, u);
        }
    },
    $ = function (t, e, n) {
      if (!n)
        try {
          n = e.getAttributeNode(t);
        } catch {
          n = null;
        }
      dt(i.removed, { attribute: n || null, from: e });
      try {
        n ? e.removeAttributeNode(n) : e.removeAttribute(t);
      } catch {
        try {
          e.removeAttribute(t);
        } catch {}
      }
      if (t === "is")
        if (Q || bt)
          try {
            z(e);
          } catch {}
        else
          try {
            e.setAttribute(t, "");
          } catch {}
    },
    Mn = function (t) {
      const e = kt(t);
      if (e)
        for (let n = e.length - 1; n >= 0; --n) {
          const a = e[n],
            l = a && a.name;
          typeof l != "string" || _[E(l)] || Ce(t, a, l);
        }
    },
    wt = function (t) {
      const e = [t];
      for (; e.length > 0;) {
        const n = e.pop();
        ct(n) === M.element && Mn(n);
        const l = q(n);
        if (l) for (let u = l.length - 1; u >= 0; --u) e.push(l[u]);
      }
    },
    Pe = function (t, e) {
      return Y
        ? t === "patchsrc"
          ? !0
          : t === "for" && e !== "label" && e !== "output"
        : !1;
    },
    Cn = function (t) {
      if (!Y) return;
      const e = [t];
      for (; e.length > 0;) {
        const n = e.pop(),
          a = ct(n);
        if (
          a === M.processingInstruction ||
          (a === M.comment && O(en, n.data))
        ) {
          try {
            vt(n);
          } catch {}
          continue;
        }
        if (a === M.element) {
          const u = n,
            m = E(Ut(n));
          try {
            (u.hasAttribute &&
              u.hasAttribute("patchsrc") &&
              u.removeAttribute("patchsrc"),
              u.hasAttribute &&
                u.hasAttribute("for") &&
                Pe("for", m) &&
                u.removeAttribute("for"));
          } catch {}
        }
        const l = q(n);
        if (l) for (let u = l.length - 1; u >= 0; --u) e.push(l[u]);
      }
    },
    xe = function (t) {
      let e = null,
        n = null;
      if (Yt) t = "<remove></remove>" + t;
      else {
        const u = je(t, /^[\r\n\t ]+/);
        n = u && u[0];
      }
      pt === "application/xhtml+xml" &&
        nt === v &&
        (t =
          '<html xmlns="http://www.w3.org/1999/xhtml"><head></head><body>' +
          t +
          "</body></html>");
      const a = L ? J(t) : t;
      if (nt === v)
        try {
          e = new xt().parseFromString(a, pt);
        } catch {}
      if (!e || !e.documentElement) {
        e = zt.createDocument(nt, "template", null);
        try {
          e.documentElement.innerHTML = Xt ? B : a;
        } catch {}
      }
      const l = e.body || e.documentElement;
      return (
        t && n && l.insertBefore(s.createTextNode(n), l.childNodes[0] || null),
        nt === v
          ? mn.call(e, j ? "html" : "body")[0]
          : j
            ? e.documentElement
            : l
      );
    },
    ve = function (t) {
      const e = Et ? Et(t) : t.ownerDocument;
      return pe.call(
        e || t,
        t,
        N.SHOW_ELEMENT |
          N.SHOW_COMMENT |
          N.SHOW_TEXT |
          N.SHOW_PROCESSING_INSTRUCTION |
          N.SHOW_CDATA_SECTION,
        null,
      );
    },
    It = function (t) {
      return (
        (t = Tt(t, Tn, " ")),
        (t = Tt(t, hn, " ")),
        (t = Tt(t, _n, " ")),
        t
      );
    },
    Jt = function (t) {
      var e;
      t.normalize();
      const n = Et ? Et(t) : t.ownerDocument,
        a = pe.call(
          n || t,
          t,
          N.SHOW_TEXT |
            N.SHOW_COMMENT |
            N.SHOW_CDATA_SECTION |
            N.SHOW_PROCESSING_INSTRUCTION,
          null,
        );
      let l = a.nextNode();
      for (; l;) ((l.data = It(l.data)), (l = a.nextNode()));
      const u =
        (e = t.querySelectorAll) === null || e === void 0
          ? void 0
          : e.call(t, "template");
      u &&
        V(u, (m) => {
          rt(m.content) && Jt(m.content);
        });
    },
    Nt = function (t) {
      const e = Z ? Z(t) : null;
      return typeof e != "string" || E(e) !== "form"
        ? !1
        : typeof t.nodeName != "string" ||
            typeof t.textContent != "string" ||
            typeof t.removeChild != "function" ||
            t.attributes !== kt(t) ||
            typeof t.removeAttribute != "function" ||
            typeof t.setAttribute != "function" ||
            typeof t.namespaceURI != "string" ||
            typeof t.insertBefore != "function" ||
            typeof t.hasChildNodes != "function" ||
            t.nodeType !== W(t) ||
            t.childNodes !== q(t);
    },
    rt = function (t) {
      if (!W || typeof t != "object" || t === null) return !1;
      try {
        return W(t) === M.documentFragment;
      } catch {
        return !1;
      }
    },
    mt = function (t) {
      if (!W || typeof t != "object" || t === null) return !1;
      try {
        return typeof W(t) == "number";
      } catch {
        return !1;
      }
    };
  function k(o, t, e) {
    o.length !== 0 &&
      V(o, (n) => {
        n.call(i, t, e, ot);
      });
  }
  const Pn = function (t, e) {
      return !!(
        (Y &&
          t.hasChildNodes() &&
          !mt(t.firstElementChild) &&
          O(tn, t.textContent) &&
          O(tn, t.innerHTML)) ||
        (Y &&
          t.namespaceURI === v &&
          To[e] &&
          (mt(t.firstElementChild) ||
            (typeof t.textContent == "string" && O(ho[e], t.textContent)))) ||
        t.nodeType === M.processingInstruction ||
        (Y && t.nodeType === M.comment && O(en, t.data))
      );
    },
    Mt = function (t, e) {
      if (t instanceof RegExp) return O(t, e);
      if (t instanceof Function) {
        for (
          var n = arguments.length, a = new Array(n > 2 ? n - 2 : 0), l = 2;
          l < n;
          l++
        )
          a[l - 2] = arguments[l];
        return !!t(e, ...a);
      }
      return !1;
    },
    xn = function (t, e, n) {
      if (!ft[e] && He(e) && Mt(x.tagNameCheck, e)) return !1;
      if (jt && !et[e]) {
        const a = K(t),
          l = q(t);
        if (l && a) {
          const u = l.length;
          for (let m = u - 1; m >= 0; --m) {
            const g = t === n ? ln(l[m], !0) : l[m];
            a.insertBefore(g, cn(t));
          }
        }
      }
      return (z(t), !0);
    },
    ke = function (t, e, n, a) {
      return t.length === 0 ? e : e === n || e === a ? C(e) : e;
    },
    Ue = function (t, e) {
      return t === e || K(t) !== null ? !1 : ($t && wt(t), !0);
    },
    Fe = function (t, e) {
      if ((k(T.beforeSanitizeElements, t, null), Ue(t, e))) return !0;
      if (Nt(t)) return (z(t), !0);
      const n = E(Ut(t));
      if (
        ((h = ke(T.uponSanitizeElement, h, Ht, yt)),
        k(T.uponSanitizeElement, t, { tagName: n, allowedTags: h }),
        Ue(t, e))
      )
        return !0;
      if (Pn(t, n)) return (z(t), !0);
      if (
        ft[n] ||
        (!(U.tagCheck instanceof Function && U.tagCheck(n)) && !h[n])
      ) {
        const l = xn(t, n, e);
        return (l === !1 && k(T.afterSanitizeElements, t, null), l);
      }
      if (
        (ct(t) === M.element && !Nn(t)) ||
        ((n === "noscript" || n === "noembed" || n === "noframes") &&
          O(po, t.innerHTML))
      )
        return (z(t), !0);
      if (F && t.nodeType === M.text) {
        const l = It(t.textContent);
        t.textContent !== l &&
          (dt(i.removed, { element: t.cloneNode() }), (t.textContent = l));
      }
      return (k(T.afterSanitizeElements, t, null), !1);
    },
    ze = function (t, e, n) {
      if (
        Te[e] ||
        Pe(e, t) ||
        (Ee && (e === "id" || e === "name") && (n in s || n in Ln))
      )
        return !1;
      const a =
        _[e] ||
        (U.attributeCheck instanceof Function && U.attributeCheck(e, t));
      return (Wt && O(gn, e)) || (he && O(En, e))
        ? !0
        : a
          ? Re[e] ||
            O(de, Tt(n, me, "")) ||
            ((e === "src" || e === "xlink:href" || e === "href") &&
              t !== "script" &&
              $e(n, "data:") === 0 &&
              be[t]) ||
            (_e && !O(An, Tt(n, me, "")))
            ? !0
            : !n
          : (He(t) &&
              Mt(x.tagNameCheck, t) &&
              Mt(x.attributeNameCheck, e, t)) ||
            (e === "is" &&
              x.allowCustomizedBuiltInElements &&
              Mt(x.tagNameCheck, n));
    },
    vn = p({}, [
      "annotation-xml",
      "color-profile",
      "font-face",
      "font-face-format",
      "font-face-name",
      "font-face-src",
      "font-face-uri",
      "missing-glyph",
    ]),
    He = function (t) {
      return !vn[_t(t)] && O(yn, t);
    },
    kn = function (t, e, n, a) {
      if (
        L &&
        typeof gt == "object" &&
        typeof gt.getAttributeType == "function" &&
        !n
      )
        switch (gt.getAttributeType(t, e)) {
          case "TrustedHTML":
            return J(a);
          case "TrustedScriptURL":
            return un(a);
        }
      return a;
    },
    Un = function (t, e, n, a) {
      try {
        (n ? t.setAttributeNS(n, e, a) : t.setAttribute(e, a),
          Nt(t) ? z(t) : Ye(i.removed));
      } catch {
        $(e, t);
      }
    },
    Ge = function (t) {
      k(T.beforeSanitizeAttributes, t, null);
      const e = t.attributes;
      if (!e || Nt(t)) return;
      _ = ke(T.uponSanitizeAttribute, _, Gt, St);
      const n = {
        attrName: "",
        attrValue: "",
        keepAttr: !0,
        allowedAttributes: _,
        forceKeepAttr: void 0,
      };
      let a = e.length;
      const l = E(t.nodeName);
      for (; a--;) {
        const u = e[a],
          m = u.name,
          g = u.namespaceURI,
          D = u.value,
          w = E(m),
          te = D;
        let R = m === "value" ? te : Vn(te);
        if (
          ((n.attrName = w),
          (n.attrValue = R),
          (n.keepAttr = !0),
          (n.forceKeepAttr = void 0),
          k(T.uponSanitizeAttribute, t, n),
          (R = n.attrValue),
          Ae &&
            (w === "id" || w === "name") &&
            $e(R, ye) !== 0 &&
            ($(m, t, u), (R = ye + R)),
          Y &&
            O(
              /((--!?|])>)|<\/(style|script|title|xmp|textarea|noscript|iframe|noembed|noframes)/i,
              R,
            ))
        ) {
          $(m, t, u);
          continue;
        }
        if (w === "attributename" && je(R, "href")) {
          $(m, t, u);
          continue;
        }
        if (!n.forceKeepAttr) {
          if (!n.keepAttr) {
            $(m, t, u);
            continue;
          }
          if (!ge && O(mo, R)) {
            $(m, t, u);
            continue;
          }
          if ((F && (R = It(R)), !ze(l, w, R))) {
            $(m, t, u);
            continue;
          }
          ((R = kn(l, w, g, R)), R !== te && Un(t, m, g, R));
        }
      }
      k(T.afterSanitizeAttributes, t, null);
    },
    Ct = function (t) {
      let e = null;
      const n = ve(t);
      for (k(T.beforeSanitizeShadowDOM, t, null); (e = n.nextNode());)
        if (
          (k(T.uponSanitizeShadowNode, e, null),
          Fe(e, t),
          Ge(e),
          rt(e.content) && Ct(e.content),
          ct(e) === M.element)
        ) {
          const a = ce(e);
          rt(a) && (Qt(a), Ct(a));
        }
      k(T.afterSanitizeShadowDOM, t, null);
    },
    Qt = function (t) {
      const e = [{ node: t, shadow: null }];
      for (; e.length > 0;) {
        const n = e.pop();
        if (n.shadow) {
          Ct(n.shadow);
          continue;
        }
        const a = n.node,
          u = ct(a) === M.element,
          m = q(a);
        if (m)
          for (let g = m.length - 1; g >= 0; --g)
            e.push({ node: m[g], shadow: null });
        if (u) {
          const g = Z ? Z(a) : null;
          if (typeof g == "string" && E(g) === "template") {
            const D = a.content;
            rt(D) && e.push({ node: D, shadow: null });
          }
        }
        if (u) {
          const g = ce(a);
          rt(g) && e.push({ node: null, shadow: g }, { node: g, shadow: null });
        }
      }
    };
  return (
    (i.sanitize = function (o) {
      let t =
          arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {},
        e = null,
        n = null,
        a = null,
        l = null;
      if (
        ((Xt = !o),
        Xt && (o = "<!-->"),
        typeof o != "string" && !mt(o) && ((o = Qn(o)), typeof o != "string"))
      )
        throw X("dirty is not a string, aborting");
      if (!i.isSupported) return o;
      (Bt ? ((h = yt), (_ = St)) : Zt(t),
        (T.uponSanitizeElement.length > 0 ||
          T.uponSanitizeAttribute.length > 0) &&
          (h = C(h)),
        T.uponSanitizeAttribute.length > 0 && (_ = C(_)),
        (i.removed = []));
      const u = $t && typeof o != "string" && mt(o);
      if (u) {
        Cn(o);
        const D = Ut(o);
        if (typeof D == "string") {
          const w = E(D);
          if (!h[w] || ft[w])
            throw (
              Dt(o),
              X("root node is forbidden and cannot be sanitized in-place")
            );
        }
        if (Nt(o))
          throw (
            Dt(o),
            X("root node is clobbered and cannot be sanitized in-place")
          );
        try {
          Qt(o);
        } catch (w) {
          throw (Dt(o), w);
        }
      } else if (mt(o))
        ((e = xe("<!---->")),
          (n = e.ownerDocument.importNode(o, !0)),
          (n.nodeType === M.element && n.nodeName === "BODY") ||
          n.nodeName === "HTML"
            ? (e = n)
            : e.appendChild(n),
          Qt(n));
      else {
        if (!Q && !F && !j && o.indexOf("<") === -1) return L && Ot ? J(o) : o;
        if (((e = xe(o)), !e)) return Q ? null : Ot ? B : "";
      }
      e && Yt && z(e.firstChild);
      const m = u ? o : e;
      try {
        const D = ve(m);
        for (; (a = D.nextNode());)
          (Fe(a, m), Ge(a), rt(a.content) && Ct(a.content));
      } catch (D) {
        throw (
          u &&
            (Dt(o),
            V(i.removed, (w) => {
              w.element && wt(w.element);
            })),
          D
        );
      }
      if (u)
        return (
          V(i.removed, (D) => {
            D.element && wt(D.element);
          }),
          F && Jt(o),
          o
        );
      if (Q) {
        if ((F && Jt(e), bt))
          for (l = pn.call(e.ownerDocument); e.firstChild;)
            l.appendChild(e.firstChild);
        else l = e;
        return (
          (_.shadowroot || _.shadowrootmode) && (l = dn.call(c, l, !0)),
          l
        );
      }
      let g = j ? e.outerHTML : e.innerHTML;
      return (
        j &&
          h["!doctype"] &&
          e.ownerDocument &&
          e.ownerDocument.doctype &&
          e.ownerDocument.doctype.name &&
          O(uo, e.ownerDocument.doctype.name) &&
          (g =
            "<!DOCTYPE " +
            e.ownerDocument.doctype.name +
            `>
` +
            g),
        F && (g = It(g)),
        L && Ot ? J(g) : g
      );
    }),
    (i.setConfig = function () {
      let o =
        arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
      (Zt(o), (Bt = !0), (yt = h), (St = _));
    }),
    (i.clearConfig = function () {
      ((ot = null), (Bt = !1), (yt = null), (St = null), (L = Ft), (B = ""));
    }),
    (i.isValidAttribute = function (o, t, e) {
      ot || Zt({});
      const n = E(o),
        a = E(t);
      return ze(n, a, e);
    }),
    (i.addHook = function (o, t) {
      typeof t == "function" && I(T, o) && dt(T[o], t);
    }),
    (i.removeHook = function (o, t) {
      if (I(T, o)) {
        if (t !== void 0) {
          const e = $n(T[o], t);
          return e === -1 ? void 0 : Xn(T[o], e, 1)[0];
        }
        return Ye(T[o]);
      }
    }),
    (i.removeHooks = function (o) {
      I(T, o) && (T[o] = []);
    }),
    (i.removeAllHooks = function () {
      T = nn();
    }),
    i
  );
}
var Eo = sn();
export { Eo as default };
