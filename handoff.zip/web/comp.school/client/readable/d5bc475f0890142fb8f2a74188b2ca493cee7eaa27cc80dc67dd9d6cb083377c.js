import { j as e, r as W } from "./react-vendor-BK1G6oO1.js";
import { aq as ti, aT as ii } from "./GameNotebook-b0Qw2wzd.js";
import { T as Ct } from "./action-styles-DWMwPIR0.js";
import { I as si } from "./immersive-picker-PA4Q0OWd.js";
import { d as ri, K as li } from "./keyword-deck-Bo8inXG8.js";
import { u as ue } from "./keyword-flashcards-Ha6Msavb.js";
import {
  O as ai,
  Q as ci,
  V as hi,
  z as oi,
  U as ni,
  H as di,
  W as xi,
  Y as fi,
  Z as ji,
  v as yi,
} from "./ui-components-DeMDYLzO.js";
import { m as me } from "./proxy-DGk2Wawc.js";
import "./index-DjyiOHey.js";
import "./use-cover-art-CyGvgy9q.js";
const B = [
    { id: "pen_testers", name: "Penetration Testing", cost: 2e5 },
    { id: "anti_malware", name: "Anti-Malware Software", cost: 1e5 },
    { id: "firewall", name: "Firewall", cost: 15e4 },
    { id: "user_access", name: "User Access Levels", cost: 5e4 },
    { id: "password_policy", name: "Strong Password Policy", cost: 5e4 },
    { id: "account_lockout", name: "Account Lockout", cost: 5e4 },
    { id: "two_factor", name: "Two-Factor Authentication", cost: 1e5 },
    { id: "encryption", name: "Encryption", cost: 1e5 },
    { id: "physical_security", name: "Physical Security", cost: 1e5 },
    { id: "staff_training", name: "Staff Training", cost: 1e5 },
    { id: "input_validation", name: "Input Validation", cost: 1e5 },
  ],
  pi = {
    pen_testers: ["1.4", "Penetration Testing"],
    anti_malware: ["1.4", "Anti-Malware Software"],
    firewall: ["1.4", "Firewall"],
    user_access: ["1.4", "User Access Levels"],
    password_policy: ["1.4", "Passwords"],
    account_lockout: ["1.4", "Account Lockout"],
    two_factor: ["1.4", "Two-Factor Authentication"],
    encryption: ["1.4", "Encryption"],
    physical_security: ["1.4", "Physical Security"],
    staff_training: ["1.4", "Staff Training"],
    input_validation: ["2.3", "Input Validation"],
  },
  O =
    "Phishing is social engineering: it attacks people, not machines. Staff training stops it, because staff learn to check sender addresses, spot pressure tactics and hover over links before clicking. Two-factor authentication also stops it, because a stolen password is useless without the code sent to the real owner's phone. User access levels cannot stop the trick, but they limit how much a stolen account can reach.",
  Q =
    "A brute-force attack tries password after password until one works. Three defences stop it: a strong password policy makes the right answer take far too long to guess, account lockout stops the guessing after a few wrong attempts, and two-factor authentication means even a guessed password is not enough. A firewall can block traffic from the attacking addresses, but bots simply switch to new ones.",
  U =
    "SQL injection hides database commands inside a form field. If the website does not check what is typed, the database runs the attacker's code. Input validation stops it by rejecting anything that is not a normal answer. Penetration testing stops it too, by finding the weakness so it can be fixed before criminals do. User access levels limit the damage, because the website's database account can only reach the tables it needs.",
  Z =
    "Blagging is social engineering where the attacker invents a story and piles on pressure until someone hands over access. Staff training stops it: staff learn to slow down, check who is calling using details already on file, and never change accounts or share passwords over the phone. Technical defences cannot help when a person willingly gives access away.",
  Y =
    "A denial of service attack does not steal data: it floods a server with so much traffic that real users cannot get through. A firewall inspects incoming traffic against rules, so it can block the attacking sources and limit how many requests reach the server. Anti-malware, passwords and encryption do not help, because nothing is installed, nobody logs in and no data is taken.",
  G =
    "Data interception means capturing data as it travels across a network, often with packet-sniffing software. You cannot stop someone capturing signals, but encryption makes what they capture useless: the data is scrambled with a key and cannot be read without it. A firewall checks what enters and leaves your network, but it cannot stop someone listening along the route.",
  K =
    "Shouldering, or shoulder surfing, is social engineering where someone simply watches a person type a password or PIN, in person or through a camera. Staff training stops it: staff learn to shield the keyboard, check who is nearby and never log in where they can be overlooked. Two-factor authentication also stops it, because a password seen over a shoulder is useless without the code sent to the owner's phone. User access levels cannot stop the login, but they limit how much a stolen account can reach.",
  gi = [
    {
      id: "police_ransomware",
      name: "999 Ransomware",
      attackType: "Malware",
      scenario:
        "At 2am a call handler opens an attachment called 'Shift rota.xls'. Hidden inside is ransomware. Within minutes every screen in the 999 control room locks: 'Your dispatch system is encrypted. Pay £3 million in Bitcoin.' Emergency calls are queuing and no one can see where the patrol cars are.",
      protectedBy: ["anti_malware"],
      alsoHelpedBy: ["user_access"],
      outcomeProtected:
        "Your anti-malware software recognised the ransomware inside the attachment and quarantined it before it could run. The control room never noticed and every 999 call was answered.",
      outcomePartial:
        "The ransomware ran, but it only had the call handler's access level. It encrypted one desk's files and could not reach the dispatch servers, so the control room switched desks and kept going.",
      outcomeVulnerable:
        "The ransomware spread to every dispatch server. For six hours officers were sent out by pen, paper and radio, response times tripled and the force faced a choice between paying criminals or rebuilding everything.",
      learning:
        "Ransomware is malware that encrypts your files and demands payment. Anti-malware software stops it by checking files against known malware signatures and watching for suspicious behaviour, then quarantining anything dangerous before it runs. User access levels limit the damage, because malware can only reach what the infected account can reach.",
      consequence:
        "999 dispatch down for 6 hours · £3m ransom demand · Lives put at risk",
    },
    {
      id: "police_interception",
      name: "Bodycam Interception",
      attackType: "Data Interception and Theft",
      scenario:
        "An organised crime gang parks a van near a busy police station. Inside, a laptop running packet-sniffing software captures the bodycam footage and radio messages that officers send back over public mobile networks, including names of witnesses and the time of a planned raid.",
      protectedBy: ["encryption"],
      alsoHelpedBy: [],
      outcomeProtected:
        "The gang captured thousands of packets, but every one was encrypted. Without the key they had scrambled nonsense, and the raid went ahead as planned.",
      outcomePartial:
        "Some of the data was protected, but the gang still read a batch of messages.",
      outcomeVulnerable:
        "Everything travelled as plain data. The gang read witnesses' names and the raid time, cleared out before officers arrived and the witnesses had to be moved into protection.",
      learning: G,
      consequence: "Raid tipped off · Witnesses in danger · Case collapses",
    },
    {
      id: "police_evidence_theft",
      name: "Evidence Store Break-in",
      attackType: "Data Theft",
      scenario:
        "A stranger in a delivery uniform follows an officer through the station's back door, walks into the evidence store and leaves with a laptop. On it: the real names of the force's secret informants.",
      protectedBy: ["physical_security"],
      alsoHelpedBy: ["encryption"],
      outcomeProtected:
        "The evidence store needed a keycard, the door alarm sounded when it was forced and CCTV caught everything. The intruder was arrested in the car park.",
      outcomePartial:
        "The intruder escaped with the laptop, but its drive was encrypted. The hardware was gone, but the list of informants was unreadable.",
      outcomeVulnerable:
        "The laptop walked out of the station and nothing on it was protected. Within days the informants' names were being passed around by the gangs they had reported.",
      learning:
        "Not every attack comes over the internet. Physical security, such as locks, keycards, alarms and CCTV, stops people getting their hands on the hardware at all. Encryption is the backup plan: if a device is stolen anyway, the data on it cannot be read without the key.",
      consequence:
        "Informants exposed · Lives at risk · Public trust shattered",
    },
    {
      id: "police_shouldering",
      name: "Custody Desk Shoulder Surf",
      attackType: "Social Engineering",
      scenario:
        "A man waiting at the custody desk leans on the counter and watches a sergeant type a password into the intelligence database. He films it on his phone, slowly, key by key. That night a stranger tries to log in from outside the station.",
      protectedBy: ["staff_training", "two_factor"],
      alsoHelpedBy: ["user_access"],
      outcomeProtected:
        "Either your trained sergeant angled the screen away, shielded the keyboard and reported the man for filming, or the filmed password was useless without the code sent to the sergeant's phone. The stranger never got into the database.",
      outcomePartial:
        "He filmed the whole password and the stranger logged in, but user access levels meant the sergeant's account could only search the custody records for that station. He saw who had been arrested that week, not the force's surveillance targets.",
      outcomeVulnerable:
        "He filmed the whole password and nothing else was needed. The stranger logged into the intelligence database and downloaded a list of addresses under police watch.",
      learning: K,
      consequence:
        "Intelligence database breached · Surveillance targets warned · Operations blown",
    },
    {
      id: "police_ddos",
      name: "Manhunt Appeal DDoS",
      attackType: "Denial of Service",
      scenario:
        "A dangerous prisoner has escaped and the force's website is running an urgent public appeal with his photo. Within an hour a botnet of hijacked computers floods the site with millions of fake requests, and tip-offs from the public stop arriving.",
      protectedBy: ["firewall"],
      alsoHelpedBy: [],
      outcomeProtected:
        "Your firewall recognised the flood from the botnet and its rules blocked those sources. The appeal stayed online, a dog walker sent in a sighting and the prisoner was caught by morning.",
      outcomePartial:
        "Some of the flood was filtered, but the appeal page was down for an hour.",
      outcomeVulnerable:
        "The website collapsed for the whole evening. Sightings went unreported, the prisoner slipped across the county border and the manhunt took another week.",
      learning: Y,
      consequence:
        "Appeal offline · Sightings lost · Escaped prisoner still at large",
    },
    {
      id: "police_phishing",
      name: "Overtime Claim Phish",
      attackType: "Social Engineering",
      scenario:
        "Officers coming off a night shift get an email from 'Northgate Payroll': 'Your overtime claim has been rejected. Log in and resubmit before midnight or it will not be paid.' The link opens a perfect copy of the force login page on a lookalike web address.",
      protectedBy: ["staff_training", "two_factor"],
      alsoHelpedBy: ["user_access"],
      outcomeProtected:
        "Either your officers spotted the lookalike address and reported the email, or the stolen passwords were useless without the code sent to each officer's phone. The attackers never got past the login page.",
      outcomePartial:
        "Thirty officers gave away their passwords and the attackers logged in, but user access levels meant each account could only open that officer's own cases, not the force's crime records.",
      outcomeVulnerable:
        "Thirty officers gave away their passwords and their accounts could search everything. The attackers downloaded years of crime reports, including the names and addresses of victims and witnesses.",
      learning: O,
      consequence:
        "Officer accounts stolen · Crime reports downloaded · Victims exposed",
    },
    {
      id: "police_brute_force",
      name: "Officer Email Brute Force",
      attackType: "Brute-Force",
      scenario:
        "A gang copies the names of 200 officers from the 'Meet your local team' pages on the force website. Their bots then hammer the force email login with every name, trying thousands of passwords a minute: 'Northgate1', 'Police2026', 'Bobby123'.",
      protectedBy: ["password_policy", "account_lockout", "two_factor"],
      alsoHelpedBy: ["firewall"],
      outcomeProtected:
        "The bots got nowhere: the passwords were too long to guess, each account locked after a few wrong tries, or a second code was needed. Not one officer inbox was opened.",
      outcomePartial:
        "Your firewall blocked the busiest attacking addresses, but the bots switched to new ones and cracked three officers' weak passwords before IT noticed the strange logins.",
      outcomeVulnerable:
        "The bots cracked sixty weak passwords overnight. The gang read officers' emails about planned raids and used their accounts to send convincing fake messages to other forces.",
      learning: Q,
      consequence:
        "60 inboxes cracked · Raid plans read · Fake emails sent to other forces",
    },
    {
      id: "police_sql_injection",
      name: "Crime Tracker SQL Injection",
      attackType: "SQL Injection",
      scenario:
        "Victims of crime can check the progress of their case on the force website by typing in a report reference. An attacker types ' OR 1=1; -- into the box instead. If the page passes it straight to the database, it will send back every crime report the force holds.",
      protectedBy: ["input_validation", "pen_testers"],
      alsoHelpedBy: ["user_access"],
      outcomeProtected:
        "The tracker rejected the code, either because it checks every reference matches the pattern NG followed by eight digits, or because your penetration testers had already found and fixed the hole. The attacker got an error message.",
      outcomePartial:
        "The injection worked, but the tracker's database account could only read the case status table. The attacker got a list of report numbers and progress updates, not victims' names or statements.",
      outcomeVulnerable:
        "The database handed over 300,000 crime reports, complete with victims' names, phone numbers, home addresses and statements. Some victims were contacted by the very people they had reported.",
      learning: U,
      consequence:
        "300,000 crime reports leaked · Victims contacted · ICO investigation",
    },
    {
      id: "police_blagging",
      name: "Fake Detective Blag",
      attackType: "Social Engineering",
      scenario:
        "The control room takes a call from a withheld number. 'DS Hughes, Westshire CID. A child is missing and I think she is with her mum. I need the address you hold for her right now.' The address is protected because the mum moved to escape the caller.",
      protectedBy: ["staff_training"],
      alsoHelpedBy: [],
      outcomeProtected:
        "Your trained call handler said she would ring Westshire back through their main switchboard. Westshire had no DS Hughes and no missing child, and the call was traced to the man the mum had fled.",
      outcomePartial:
        "The call handler refused to give the address, but confirmed which town the mum now lives in.",
      outcomeVulnerable:
        "Under pressure, the call handler read out the address. The caller turned up that night, and the mum and her daughter had to be moved to emergency housing in another county.",
      learning: Z,
      consequence:
        "Protected address given away · Family in danger · Emergency rehousing",
    },
    {
      id: "police_spyware",
      name: "CCTV Player Spyware",
      attackType: "Malware",
      scenario:
        "A shopkeeper emails a detective some CCTV footage of a robbery, but it will not open. The detective downloads a 'free CCTV player' from a forum. Hidden inside is spyware, malware that secretly records every key pressed and screen opened, and sends it all to a gang.",
      protectedBy: ["anti_malware"],
      alsoHelpedBy: ["user_access"],
      outcomeProtected:
        "Your anti-malware software scanned the download, recognised the spyware and quarantined it before it could install. The detective got a safe player from IT and watched the footage that afternoon.",
      outcomePartial:
        "The spyware ran for a fortnight, but the detective's account could only open their own team's robbery cases. The gang learned about a few burglaries, not the force's undercover work.",
      outcomeVulnerable:
        "The spyware ran for three months on a laptop that could open every case in the force. The gang read the real names of undercover officers and the plans for Operation Kestrel.",
      learning:
        "Spyware is malware that secretly records what you do, such as keys pressed and screens opened, and sends it to the attacker. Anti-malware software stops it by scanning downloads and quarantining anything that matches known malware or behaves suspiciously. User access levels limit the damage, because spyware can only see what the infected account can open.",
      consequence:
        "Undercover officers exposed · Operation abandoned · Gang tipped off",
    },
  ],
  bi = [
    {
      id: "hospital_worm",
      name: "Hospital Worm",
      attackType: "Malware",
      scenario:
        "A worm, malware that copies itself from computer to computer with no one clicking anything, gets onto one old PC in radiology. By lunchtime it is spreading across the hospital network towards the MRI scanners, theatre computers and A&E.",
      protectedBy: ["anti_malware"],
      alsoHelpedBy: ["firewall"],
      outcomeProtected:
        "Your anti-malware software spotted the worm on the first PC and quarantined it before it could copy itself anywhere else. Operations went ahead as normal.",
      outcomePartial:
        "Firewall rules between the hospital departments stopped the worm crossing into theatres and A&E, but radiology was down for a day and scans had to be rebooked.",
      outcomeVulnerable:
        "The worm spread to every department. Scanners went dark, 300 operations were cancelled and ambulances were diverted to other hospitals for two days.",
      learning:
        "A worm is malware that spreads across a network on its own. Anti-malware software stops it by recognising it and quarantining it before it can copy itself. A firewall helps contain it by blocking the traffic it uses to jump between parts of the network, but it does not remove it.",
      consequence:
        "300 operations cancelled · Ambulances diverted · Patients at risk",
    },
    {
      id: "hospital_phishing",
      name: "Phishing the Doctors",
      attackType: "Social Engineering",
      scenario:
        "Doctors get an urgent email: 'Your patient records login expires today. Verify now or lose access.' The link leads to a convincing fake hospital login page. Busy doctors between patients have seconds to decide whether to type in their passwords.",
      protectedBy: ["staff_training", "two_factor"],
      alsoHelpedBy: ["user_access"],
      outcomeProtected:
        "Either your staff spotted the fake web address and reported it, or the stolen passwords were useless without the code sent to each doctor's phone. The attackers never got into a single patient record.",
      outcomePartial:
        "Twelve doctors gave away their passwords and the attackers logged in, but user access levels meant each account could only see that doctor's own patients, not the whole hospital.",
      outcomeVulnerable:
        "Twelve doctors gave away their passwords and their accounts could open everything. The attackers copied 400,000 patients' medical records and threatened to publish them.",
      learning: O,
      consequence:
        "400,000 medical records stolen · Patients blackmailed · Huge fine",
    },
    {
      id: "hospital_brute_force",
      name: "Portal Brute Force",
      attackType: "Brute-Force",
      scenario:
        "Consultants log in from home through a remote-access portal. Overnight, bots start hammering it with thousands of password guesses a minute: 'password1', 'nhs2024', 'doctor!', pets' names, football teams.",
      protectedBy: ["password_policy", "account_lockout", "two_factor"],
      alsoHelpedBy: ["firewall"],
      outcomeProtected:
        "The bots got nowhere: long passwords, locked accounts after a few wrong guesses, or a second code they could never receive. Not one consultant account was cracked.",
      outcomePartial:
        "Your firewall blocked the busiest attacking addresses, but the bots switched to new ones and cracked two consultants with weak passwords before IT noticed.",
      outcomeVulnerable:
        "The bots cracked forty weak passwords overnight and walked straight into the hospital network with consultant-level access.",
      learning: Q,
      consequence:
        "Consultant accounts hijacked · Network breached · Records exposed",
    },
    {
      id: "hospital_sql_injection",
      name: "Prescription SQL Injection",
      attackType: "SQL Injection",
      scenario:
        "On the hospital's online repeat-prescription form, an attacker types ' OR 1=1; -- into the NHS number box. If the form passes it straight to the database, the database will send back every patient's medicines and home address.",
      protectedBy: ["input_validation", "pen_testers"],
      alsoHelpedBy: ["user_access"],
      outcomeProtected:
        "The form rejected the code, either because it checks every NHS number is ten digits or because your penetration testers had already found and fixed the weakness. The attacker got an error message and nothing else.",
      outcomePartial:
        "The injection worked, but the form's database account could only read the prescriptions table, not full medical histories. A few thousand medicine lists leaked before the hole was closed.",
      outcomeVulnerable:
        "The database handed over 900,000 patients' medicines, conditions and home addresses. People on HIV and cancer drugs were sent blackmail letters within a month.",
      learning: U,
      consequence:
        "900,000 prescriptions stolen · Patients blackmailed · ICO fine",
    },
    {
      id: "hospital_blagging",
      name: "Fake IT Engineer Blag",
      attackType: "Social Engineering",
      scenario:
        "A night-shift nurse takes a call. 'Hi, it's Dan from the IT service desk. Your ward's drug cabinet system is about to crash. I just need your login to patch it before the 3am medicines round.' There is no Dan.",
      protectedBy: ["staff_training"],
      alsoHelpedBy: [],
      outcomeProtected:
        "Your trained nurse knew IT never asks for passwords, hung up and rang the real service desk on the number on the wall. Dan was reported and the call was traced.",
      outcomePartial:
        "The nurse refused to give the password, but did confirm their username and ward.",
      outcomeVulnerable:
        "The nurse read out their password. The caller used it to unlock the ward's controlled-drugs records and changed the stock counts to cover a theft of strong painkillers.",
      learning: Z,
      consequence:
        "Controlled drugs stolen · Records falsified · Police investigation",
    },
    {
      id: "hospital_interception",
      name: "Pager Interception",
      attackType: "Data Interception and Theft",
      scenario:
        "St Elm's doctors still carry pagers, and every message is broadcast by radio across the city. A man a mile away plugs a cheap radio receiver into his laptop and decodes them all: patient names, bed numbers and what is wrong with them.",
      protectedBy: ["encryption"],
      alsoHelpedBy: [],
      outcomeProtected:
        "Every pager message was encrypted before it was broadcast. The man captured thousands of messages of scrambled nonsense and not one patient name.",
      outcomePartial:
        "Some pagers were protected, but a batch of messages was readable.",
      outcomeVulnerable:
        "Every message went out as plain text. The man posted months of messages online, including famous patients' names and conditions, and journalists were outside the hospital by morning.",
      learning: G,
      consequence:
        "Patient messages published · Famous patients exposed · Data breach fine",
    },
    {
      id: "hospital_ddos",
      name: "Blood Appeal DDoS",
      attackType: "Denial of Service",
      scenario:
        "A motorway pile-up has sent 38 casualties to St Elm and the blood bank is running out of O-negative, the blood type any patient can be given. The hospital launches an urgent online appeal for donors to book emergency slots. Within minutes a botnet of hijacked computers floods the appeal page with millions of fake requests, and no donor can book.",
      protectedBy: ["firewall"],
      alsoHelpedBy: [],
      outcomeProtected:
        "Your firewall recognised the flood from the botnet and its rules blocked those sources. The appeal stayed online, 300 donors booked slots by teatime and every casualty who needed blood got it.",
      outcomePartial:
        "Some of the flood was filtered, but the appeal page was down for two hours while the O-negative supply ran dangerously low.",
      outcomeVulnerable:
        "The appeal page was down all night. Not a single donor could book, the O-negative ran out before midnight and surgeons had to wait for emergency blood to be driven in from another region.",
      learning: Y,
      consequence: "Appeal offline · No donors booked · O-negative runs out",
    },
    {
      id: "hospital_laptop_theft",
      name: "Visiting Hours Laptop Theft",
      attackType: "Data Theft",
      scenario:
        "During busy visiting hours, a man carrying flowers wanders down the children's ward, slips into the unlocked staff office and walks out with a laptop. On it is the ward's patient list with every child's name, address and condition.",
      protectedBy: ["physical_security"],
      alsoHelpedBy: ["encryption"],
      outcomeProtected:
        "The staff office needed a keycard, so the door would not open. CCTV picked him out trying the handle and security met him at the ward exit.",
      outcomePartial:
        "The man escaped with the laptop, but its drive was encrypted. The hospital lost the hardware, but not a single readable patient record.",
      outcomeVulnerable:
        "The laptop left the hospital and nothing on it was protected. Parents started getting calls from strangers who knew their child's name and illness.",
      learning:
        "Not every attack comes over the internet. Physical security, such as keycard doors, CCTV and security staff, stops people getting their hands on the hardware at all. Encryption is the backup plan: if a laptop is stolen anyway, the data on its drive cannot be read without the key.",
      consequence:
        "Children's records stolen · Families targeted · Ward security review",
    },
    {
      id: "hospital_shouldering",
      name: "Night Ward Shoulder Surf",
      attackType: "Social Engineering",
      scenario:
        "At 3am on a busy A&E ward, a nurse logs into the patient records system on the computer on wheels at the nurses' station. A man wearing a visitor sticker leans on the counter with his phone pointed at her keyboard and records every key she presses. Nobody has asked who he is visiting.",
      protectedBy: ["staff_training", "two_factor"],
      alsoHelpedBy: ["user_access"],
      outcomeProtected:
        "Either your trained nurse spotted the phone, turned the computer away and called security, who found he had no patient on the ward, or the recorded password was useless without the code sent to the nurse's phone. Not one record was opened.",
      outcomePartial:
        "He recorded the whole password and logged in from home, but user access levels meant the nurse's account could only open patients on her own ward that night. He read a handful of A&E notes before the account was locked, not the footballer's file.",
      outcomeVulnerable:
        "He recorded the whole password and nothing else was needed. From home he logged into the patient records system, read the A&E notes of 40 patients and sold the story of a footballer's secret injury to the papers.",
      learning: K,
      consequence:
        "Nurse account misused · 40 patient records read · Story sold to the papers",
    },
    {
      id: "hospital_ransomware",
      name: "Pathology Lab Ransomware",
      attackType: "Malware",
      scenario:
        "A pop-up on a pathology lab computer says 'Your browser is out of date. Click to update.' A lab technician clicks it. It is ransomware, and the lab system that tracks every blood test locks with a message: 'Pay £4 million or your results are gone for good.'",
      protectedBy: ["anti_malware"],
      alsoHelpedBy: ["user_access"],
      outcomeProtected:
        "Your anti-malware software recognised the fake update as ransomware and quarantined it before it ran. The lab kept testing and every result reached the wards on time.",
      outcomePartial:
        "The ransomware ran, but the technician's account could only reach one analyser. That machine was offline for a morning while the rest of the lab kept running.",
      outcomeVulnerable:
        "The ransomware locked the whole lab system. With no blood test results, 1,000 operations were postponed, blood transfusions were rationed and the lab took a month to recover.",
      learning:
        "Ransomware is malware that encrypts your files and demands payment. It often arrives disguised as something harmless, such as a fake software update. Anti-malware software stops it by recognising it from known signatures and suspicious behaviour, then quarantining it before it runs. User access levels limit the damage, because malware can only reach what the infected account can reach.",
      consequence:
        "Blood tests stopped · 1,000 operations postponed · £4m ransom demand",
    },
  ],
  wi = [
    {
      id: "civil_sql_injection",
      name: "Passport SQL Injection",
      attackType: "SQL Injection",
      scenario:
        "On the online passport application, an attacker types SQL code into the Surname box: ' OR 1=1; --. If the website passes it straight to the database, the database will obey and send back every citizen's passport record.",
      protectedBy: ["input_validation", "pen_testers"],
      alsoHelpedBy: ["user_access"],
      outcomeProtected:
        "The form rejected the code, either because it checks every input or because your penetration testers found this weakness last year and it was fixed. The attacker got an error message and nothing else.",
      outcomePartial:
        "The injection worked, but the application form's database account could only read the applications table, not the passport register. A few hundred half-finished applications leaked before the hole was closed.",
      outcomeVulnerable:
        "The database handed over 50 million citizens' names, dates of birth and passport numbers. Every one of them is now at risk of identity fraud.",
      learning: U,
      consequence:
        "50 million passport records stolen · Identity fraud · Questions in Parliament",
    },
    {
      id: "civil_blagging",
      name: "Minister's Office Blag",
      attackType: "Social Engineering",
      scenario:
        "The help desk phone rings. 'This is the Secretary of State's private secretary. The minister flies to a summit in an hour and the passport record is wrong. Change the details now or I'll have your job.' The caller is not who they say they are.",
      protectedBy: ["staff_training"],
      alsoHelpedBy: [],
      outcomeProtected:
        "Your trained officer stayed calm, refused to change anything over the phone and called the minister's office back on the number on file. The real private secretary had never called.",
      outcomePartial:
        "The officer hesitated, but still confirmed some personal details before hanging up.",
      outcomeVulnerable:
        "Under pressure, the officer changed the record. A criminal now holds a valid passport in a minister's name, and the story is on every front page.",
      learning: Z,
      consequence:
        "Fake passport issued · National security alert · Front-page scandal",
    },
    {
      id: "civil_ddos",
      name: "Tax Deadline DDoS",
      attackType: "Denial of Service",
      scenario:
        "It's 11pm on 31 January, the deadline for millions of tax returns. Just as the rush peaks, a botnet of hijacked computers floods the online tax service with millions of fake requests a second.",
      protectedBy: ["firewall"],
      alsoHelpedBy: [],
      outcomeProtected:
        "Your firewall recognised the flood from the botnet and its rules blocked those sources, so real taxpayers could still file before midnight.",
      outcomePartial:
        "Some of the flood was filtered, but the service was still down for an hour.",
      outcomeVulnerable:
        "The service collapsed for the final hour. Millions missed the deadline, the deadline had to be extended and the government faced a furious public.",
      learning: Y,
      consequence:
        "Tax service down · Millions miss the deadline · Public fury",
    },
    {
      id: "civil_spyware",
      name: "Benefits Office Spyware",
      attackType: "Malware",
      scenario:
        "A caseworker plugs in a USB stick handed out at a conference. It quietly installs spyware, malware that records every key pressed and every screen opened, and sends it to a server abroad. The caseworker's PC can open benefits claims for the whole North West.",
      protectedBy: ["anti_malware"],
      alsoHelpedBy: ["user_access"],
      outcomeProtected:
        "Your anti-malware software scanned the USB stick the moment it was plugged in, recognised the spyware and quarantined it before it could install.",
      outcomePartial:
        "The spyware ran for a week, but the caseworker's account could only open their own caseload. A few hundred claims leaked, not the whole region.",
      outcomeVulnerable:
        "The spyware ran for three months. It recorded logins, bank details and medical notes from 200,000 benefits claims and sent them all abroad.",
      learning:
        "Spyware is malware that secretly records what you do, such as keys pressed and screens opened, and sends it to the attacker. Anti-malware software stops it by scanning files and devices and quarantining anything that matches known malware or behaves suspiciously. User access levels limit the damage, because spyware can only see what the infected account can open.",
      consequence:
        "200,000 claims spied on · Bank details stolen · Vulnerable people exposed",
    },
    {
      id: "civil_server_theft",
      name: "Data Centre Break-in",
      attackType: "Data Theft",
      scenario:
        "At 4am two people in hi-vis jackets wave a clipboard at the night guard, walk into the government data centre and start unscrewing a backup server from its rack. It holds copies of every passport photo in the country.",
      protectedBy: ["physical_security"],
      alsoHelpedBy: ["encryption"],
      outcomeProtected:
        "The server hall needed a keycard and a PIN, CCTV flagged the clipboard trick and the alarm sounded as the rack door opened. Both intruders were arrested inside.",
      outcomePartial:
        "The intruders escaped with the server, but its drives were encrypted. The government lost the hardware, but not a single readable passport photo.",
      outcomeVulnerable:
        "The server left the building and nothing on it was protected. Millions of passport photos turned up for sale, ready-made for forged identity documents.",
      learning:
        "Not every attack comes over the internet. Physical security, such as keycard doors, PIN pads, guards, CCTV and alarms, stops intruders reaching the hardware at all. Encryption is the backup plan: if a server or drive is stolen anyway, the data on it is unreadable without the key.",
      consequence:
        "Passport photos stolen · Forged IDs on sale · National security review",
    },
    {
      id: "civil_phishing",
      name: "Civil Service Bonus Phish",
      attackType: "Social Engineering",
      scenario:
        "Every tax officer gets an email that seems to come from the Cabinet Office: 'All civil servants will receive a £500 cost of living bonus. Log in with your work account by Friday to claim it.' The login page is a fake on a lookalike web address, and these accounts can open any citizen's tax record.",
      protectedBy: ["staff_training", "two_factor"],
      alsoHelpedBy: ["user_access"],
      outcomeProtected:
        "Either your trained officers spotted the lookalike web address and reported the email, or the stolen passwords were useless without the code sent to each officer's phone. Not one tax record was opened.",
      outcomePartial:
        "Forty officers gave away their passwords and the attackers logged in, but user access levels meant each account could only open its own team's cases. A few hundred tax records leaked, not millions.",
      outcomeVulnerable:
        "Forty officers gave away their passwords and every account could search the whole country. The attackers downloaded the tax records of 3 million citizens, including their incomes and home addresses.",
      learning: O,
      consequence:
        "3 million tax records stolen · Fake bonus email · Staff accounts locked down",
    },
    {
      id: "civil_brute_force",
      name: "Tax Refund Brute Force",
      attackType: "Brute-Force",
      scenario:
        "In April, when tax refunds are paid, bots start trying password after password on citizens' online tax accounts: 'password1', 'Summer2026', pet names and birthdays. Every account they crack lets them change the bank details so the refund lands in a criminal's account.",
      protectedBy: ["password_policy", "account_lockout", "two_factor"],
      alsoHelpedBy: ["firewall"],
      outcomeProtected:
        "The bots got nowhere: passwords were too strong to guess, accounts locked after a few wrong tries, or a code from the citizen's phone was needed. Every refund went to the right bank account.",
      outcomePartial:
        "Your firewall blocked the busiest attacking addresses, but the bots switched to new ones and cracked 2,000 accounts before the refunds were frozen.",
      outcomeVulnerable:
        "The bots cracked 90,000 weak passwords and redirected £40 million of tax refunds to criminal bank accounts. Families who were counting on that money got nothing.",
      learning: Q,
      consequence:
        "90,000 tax accounts cracked · £40m refunds stolen · Families left short",
    },
    {
      id: "civil_interception",
      name: "Passport Scan Interception",
      attackType: "Data Interception and Theft",
      scenario:
        "Every night a regional passport office sends the day's scanned applications to the Whitehall printing centre over the internet: photos, birth certificates and signatures. A criminal has opened a street cabinet on the route and clipped a laptop onto the line to capture every packet.",
      protectedBy: ["encryption"],
      alsoHelpedBy: [],
      outcomeProtected:
        "Every scan was encrypted before it left the office. The criminal captured a whole night of traffic and could not read a single photo or birth certificate.",
      outcomePartial:
        "Most scans were protected, but one batch went across unencrypted and was read.",
      outcomeVulnerable:
        "The scans travelled as plain data. Twelve thousand birth certificates, photos and signatures were copied, everything a forger needs to apply for a passport in someone else's name.",
      learning: G,
      consequence:
        "12,000 applications copied · Forged identities · Passport office shut down",
    },
    {
      id: "civil_shouldering",
      name: "Departure Lounge Shoulder Surf",
      attackType: "Social Engineering",
      scenario:
        "Final call for the 09:40 to Geneva. At Gate B22, a senior Digital Identity Office manager opens a work laptop to approve one last batch and logs into the passport records system, which can issue or cancel any passport in the country. A traveller standing behind the seats raises a phone and quietly films every key.",
      protectedBy: ["staff_training", "two_factor"],
      alsoHelpedBy: ["user_access"],
      outcomeProtected:
        "Either your trained manager shielded the keyboard, spotted the phone and reported the traveller to airport security, or the filmed password was useless without the code sent to the manager's phone. Nobody else got into the passport system.",
      outcomePartial:
        "The traveller filmed the whole password and criminals logged in that evening, but user access levels meant the manager's account could approve batches, not issue new passports. They read a day's applications before the account was locked.",
      outcomeVulnerable:
        "The traveller filmed the whole password and nothing else was needed. Before the plane had landed, criminals logged in and issued 300 real passports in made-up names to a smuggling gang.",
      learning: K,
      consequence:
        "300 passports issued to criminals · Identity records altered · Border alert raised",
    },
    {
      id: "civil_ransomware",
      name: "Passport Printer Ransomware",
      attackType: "Malware",
      scenario:
        "It's June and half a million families are waiting for passports before the summer holidays. A technician downloads a 'printer driver update' from a website onto the PC that controls the passport printing line. It is ransomware, and the screen turns red: 'Pay £8 million or no passport is printed.'",
      protectedBy: ["anti_malware"],
      alsoHelpedBy: ["user_access"],
      outcomeProtected:
        "Your anti-malware software recognised the fake driver as ransomware and quarantined it before it ran. The printers kept going and every family flew on time.",
      outcomePartial:
        "The ransomware ran, but the technician's account could only reach one printing line. That line stopped for two days while the others kept printing.",
      outcomeVulnerable:
        "The ransomware spread to every printing line in the country. No passports were printed for three weeks and thousands of families missed their holidays.",
      learning:
        "Ransomware is malware that encrypts your files and demands payment. Anti-malware software stops it by recognising it from known signatures and suspicious behaviour, then quarantining it before it runs. User access levels limit the damage, because ransomware can only encrypt what the infected account can reach.",
      consequence:
        "Passport printing stopped · Holidays cancelled · £8m ransom demand",
    },
  ],
  ki = [
    {
      id: "threadline_ddos",
      name: "Black Friday DDoS",
      attackType: "Denial of Service",
      scenario:
        "Black Friday, 9am, the biggest sales hour of Threadline's year. Suddenly the website stops responding: a botnet of hijacked computers is sending millions of requests a second. Every minute offline costs £500,000 in lost sales.",
      protectedBy: ["firewall"],
      alsoHelpedBy: [],
      outcomeProtected:
        "Your firewall spotted the flood from the botnet and its rules blocked those sources, so real shoppers kept checking out. Black Friday broke sales records.",
      outcomePartial:
        "Some of the flood was filtered, but the site was down for an hour.",
      outcomeVulnerable:
        "The site was down for six hours on the busiest day of the year. Shoppers went to rivals and Threadline lost £180 million in sales.",
      learning: Y,
      consequence:
        "Site down 6 hours · £180m lost sales · Shoppers gone to rivals",
    },
    {
      id: "threadline_brute_force",
      name: "Account Takeover",
      attackType: "Brute-Force",
      scenario:
        "Bots start trying millions of passwords against Threadline customer accounts, working through lists of common passwords like 'fashion1', 'qwerty' and 'Summer2026'. Every account they crack has a saved card and a home address.",
      protectedBy: ["password_policy", "account_lockout", "two_factor"],
      alsoHelpedBy: ["firewall"],
      outcomeProtected:
        "The bots got nowhere: passwords were too strong to guess, accounts locked after a few wrong tries, or a second code was needed. Not one customer account was taken over.",
      outcomePartial:
        "Your firewall blocked the busiest attacking addresses, but the bots moved to new ones and took over 3,000 accounts before IT noticed.",
      outcomeVulnerable:
        "The bots cracked 200,000 weak passwords and went shopping on customers' saved cards, sending designer orders to new addresses.",
      learning: Q,
      consequence:
        "200,000 accounts hijacked · Fraudulent orders · Refunds and fines",
    },
    {
      id: "threadline_interception",
      name: "Card Interception",
      attackType: "Data Interception and Theft",
      scenario:
        "A criminal has tapped into the network route between Threadline's checkout and its payment provider, and is running packet-sniffing software on everything that passes: names, card numbers and expiry dates.",
      protectedBy: ["encryption"],
      alsoHelpedBy: [],
      outcomeProtected:
        "Every payment was encrypted. The criminal captured millions of packets of scrambled nonsense and not one card number.",
      outcomePartial:
        "Some payments were protected, but a batch of card numbers was readable.",
      outcomeVulnerable:
        "Card details travelled as plain data. Two million cards were copied and sold online within a week, and the banks had to cancel every one.",
      learning: G,
      consequence:
        "2 million cards stolen · Banks cancel cards · Trust in Threadline gone",
    },
    {
      id: "threadline_phishing",
      name: "Supplier Invoice Phish",
      attackType: "Social Engineering",
      scenario:
        "Threadline's finance team gets an email that looks exactly like it is from their biggest denim supplier: 'Our bank details have changed. Log in to the supplier portal to approve this month's £4 million invoice.' The portal is a fake on a lookalike address.",
      protectedBy: ["staff_training", "two_factor"],
      alsoHelpedBy: ["user_access"],
      outcomeProtected:
        "Either your finance team spotted the lookalike address and rang the supplier on a number they already had, or the stolen passwords were useless without the code sent to each person's phone. Not a penny moved.",
      outcomePartial:
        "One finance clerk gave away their password and the attackers logged in, but user access levels meant the clerk could only view invoices, not approve payments.",
      outcomeVulnerable:
        "A finance manager gave away their password and their account could approve anything. £4 million was paid into the criminals' account and never recovered.",
      learning: O,
      consequence:
        "£4m paid to criminals · Supplier unpaid · Auditors called in",
    },
    {
      id: "threadline_ransomware",
      name: "Warehouse Ransomware",
      attackType: "Malware",
      scenario:
        "Three weeks before Christmas, a warehouse worker downloads a 'free shift-swap app' onto a picking terminal. It is ransomware. The screens on every conveyor and label printer turn red: 'Pay £10 million or no parcel leaves this building.'",
      protectedBy: ["anti_malware"],
      alsoHelpedBy: ["user_access"],
      outcomeProtected:
        "Your anti-malware software flagged the fake app as ransomware and quarantined it before it ran. The conveyors kept moving and every Christmas parcel went out on time.",
      outcomePartial:
        "The ransomware ran, but the picking terminal's account could only reach its own zone. One aisle stopped for a day while the rest of the warehouse kept packing.",
      outcomeVulnerable:
        "The ransomware locked every system in the warehouse. A million Christmas orders sat on the shelves for ten days, customers were refunded and Threadline trended for all the wrong reasons.",
      learning:
        "Ransomware is malware that encrypts your files and demands payment. Anti-malware software stops it by recognising it from known signatures and suspicious behaviour, then quarantining it before it runs. User access levels limit the damage, because malware can only reach what the infected account can reach.",
      consequence:
        "Warehouse frozen 10 days · 1 million orders late · £10m ransom demand",
    },
    {
      id: "threadline_sql_injection",
      name: "Promo Code SQL Injection",
      attackType: "SQL Injection",
      scenario:
        "At the Threadline checkout, someone types SQL code into the promo code box instead of a discount code: ' OR 1=1; --. If the website passes it straight to the database, it will send back every customer's name, email and home address.",
      protectedBy: ["input_validation", "pen_testers"],
      alsoHelpedBy: ["user_access"],
      outcomeProtected:
        "The promo code box rejected the code, either because it only accepts letters and numbers or because your penetration testers found this weakness last spring and it was fixed. The attacker just saw 'Code not recognised'.",
      outcomePartial:
        "The injection worked, but the checkout's database account could only read the promo codes table. The attacker got a list of discount codes, not a single customer.",
      outcomeVulnerable:
        "The database handed over the names, emails and home addresses of 25 million customers. Within days they were all getting convincing scam emails in Threadline's name.",
      learning: U,
      consequence:
        "25 million customers leaked · Scam emails flood in · Data watchdog fine",
    },
    {
      id: "threadline_blagging",
      name: "Fake Courier Blag",
      attackType: "Social Engineering",
      scenario:
        "The dispatch office phone rings. 'It's the courier depot. Our system has crashed and 40,000 parcels will miss Christmas. Email me today's delivery list right now or it's on you.' The caller is not from the courier.",
      protectedBy: ["staff_training"],
      alsoHelpedBy: [],
      outcomeProtected:
        "Your trained dispatcher did not send anything. They rang the courier back on the number in the contract, and the real depot said its system was running perfectly.",
      outcomePartial:
        "The dispatcher hesitated, but still read out a few customer addresses before hanging up.",
      outcomeVulnerable:
        "The dispatcher emailed the list. A gang now knew exactly which homes had expensive parcels arriving and when, and doorstep thefts and fake 'missed delivery' texts followed.",
      learning: Z,
      consequence:
        "40,000 addresses handed over · Parcels stolen from doorsteps · Fake delivery texts",
    },
    {
      id: "threadline_warehouse_theft",
      name: "Shift Change Tailgater",
      attackType: "Data Theft",
      scenario:
        "At the 10pm shift change, a stranger in a Threadline hoodie follows a crowd of workers through the warehouse turnstile. They walk into the IT room and fill a bag with the backup drives, which hold a copy of every customer's order history and address.",
      protectedBy: ["physical_security"],
      alsoHelpedBy: ["encryption"],
      outcomeProtected:
        "The turnstile only let one keycard through at a time, the IT room needed a keycard and a PIN, and CCTV flagged the stranger at once. Security stopped them before they reached the drives.",
      outcomePartial:
        "The stranger got out with the drives, but every one was encrypted. Threadline lost the hardware, but not one readable customer record.",
      outcomeVulnerable:
        "The drives left the building and nothing on them was protected. Millions of customer addresses and order histories went on sale online.",
      learning:
        "Not every attack comes over the internet. Physical security, such as turnstiles, keycard doors, PIN pads, guards and CCTV, stops intruders reaching the hardware at all. Encryption is the backup plan: if a drive is stolen anyway, the data on it is unreadable without the key.",
      consequence:
        "Backup drives stolen · Customer data on sale · Warehouse security review",
    },
    {
      id: "threadline_shouldering",
      name: "Pop-up Shop Shoulder Surf",
      attackType: "Social Engineering",
      scenario:
        "At Threadline's first pop-up shop in London, the store manager logs into the stock and customer system on the counter tablet. A 'shopper' browsing the rail behind them holds up a phone and films every key of the admin password.",
      protectedBy: ["staff_training", "two_factor"],
      alsoHelpedBy: ["user_access"],
      outcomeProtected:
        "Either your trained manager turned the tablet away, covered the screen and spotted the phone, or the filmed password was useless without the code sent to the manager's phone. The break-in attempt that night got nowhere.",
      outcomePartial:
        "The shopper filmed the whole password and logged in that night, but user access levels meant a store manager could only change the pop-up shop's stock, not issue store credit or open the customer list. A few prices were changed before head office noticed.",
      outcomeVulnerable:
        "The shopper filmed the whole password and nothing else was needed. That night they logged in as an admin, gave themselves £50,000 of store credit and downloaded the customer list.",
      learning: K,
      consequence:
        "Admin account hijacked · £50,000 store credit stolen · Customer list taken",
    },
    {
      id: "threadline_spyware",
      name: "Browser Add-on Spyware",
      attackType: "Malware",
      scenario:
        "A customer service agent installs a free 'size chart helper' add-on in their web browser. It is spyware: it secretly records every key pressed and every customer record opened, and sends it to a server abroad. Agents can see addresses, orders and the last four digits of cards.",
      protectedBy: ["anti_malware"],
      alsoHelpedBy: ["user_access"],
      outcomeProtected:
        "Your anti-malware software recognised the add-on as spyware and quarantined it the moment it was installed. Nothing left the building.",
      outcomePartial:
        "The spyware ran for a week, but the agent's account could only open the customers they were helping. A few hundred records leaked, not the whole customer base.",
      outcomeVulnerable:
        "The spyware ran for two months. It recorded the agent's password and every customer record they opened, and criminals used the details to pass security checks and take over accounts.",
      learning:
        "Spyware is malware that secretly records what you do, such as keys pressed and screens opened, and sends it to the attacker. Anti-malware software stops it by scanning new software and quarantining anything that matches known malware or behaves suspiciously. User access levels limit the damage, because spyware can only see what the infected account can open.",
      consequence:
        "Customer records spied on · Agent login stolen · Accounts taken over",
    },
  ],
  ui = [
    {
      id: "law_phishing",
      name: "Shared Document Phish",
      attackType: "Social Engineering",
      scenario:
        "Lawyers get an email: 'A client has shared a confidential document with you. Log in to view.' The link leads to a convincing fake login page on a lookalike web address. The firm handles celebrity divorces and billion-pound mergers.",
      protectedBy: ["staff_training", "two_factor"],
      alsoHelpedBy: ["user_access"],
      outcomeProtected:
        "Either your lawyers spotted the lookalike web address and reported it, or the stolen passwords were useless without the code sent to their phones. No case file was touched.",
      outcomePartial:
        "Three lawyers gave away their passwords, but user access levels meant each could only open their own cases. The attackers saw one property deal, not the firm's secrets.",
      outcomeVulnerable:
        "Three lawyers gave away their passwords and their accounts could open everything. Details of a secret merger leaked and the share price moved before it was announced.",
      learning: O,
      consequence:
        "Merger secrets leaked · Clients leave · Regulator investigates",
    },
    {
      id: "law_laptop_theft",
      name: "Laptop Snatched on a Train",
      attackType: "Data Theft",
      scenario:
        "A partner falls asleep on the evening train. When they wake up, their laptop has gone from the luggage rack. On it is the full file for a celebrity divorce that every newspaper wants.",
      protectedBy: ["encryption"],
      alsoHelpedBy: ["password_policy"],
      outcomeProtected:
        "The laptop was gone, but its drive was encrypted. To the thief the divorce file was unreadable scrambled data, and the story never came out.",
      outcomePartial:
        "The laptop's long password kept the thief out, so he wiped it and sold it on. The divorce file probably never leaked, but the drive was not encrypted, so nobody could be sure and the firm had to report the loss to the regulator as a data breach.",
      outcomeVulnerable:
        "Nothing on the laptop was protected. Within a week the divorce file was on the front pages and the celebrity was suing the firm.",
      learning:
        "Physical security cannot help once a device leaves the building, which is why encryption matters: if a laptop is stolen, the data on its drive is unreadable without the key. A strong password only protects the account: anyone who removes the drive and plugs it into another computer can read everything that is not encrypted.",
      consequence: "Celebrity file leaked · Firm sued · Reputation destroyed",
    },
    {
      id: "law_ransomware",
      name: "Leak-Site Ransomware",
      attackType: "Malware",
      scenario:
        "A trainee installs a free 'PDF converter' from a website. It is ransomware. It encrypts the firm's case files and posts a message: 'Pay £5 million or we publish every client's secrets on our leak site.'",
      protectedBy: ["anti_malware"],
      alsoHelpedBy: ["user_access"],
      outcomeProtected:
        "Your anti-malware software flagged the fake converter as ransomware and quarantined it before it ran. Not one case file was touched.",
      outcomePartial:
        "The ransomware ran, but the trainee's account could only reach their own team's folders. A handful of files were encrypted and the rest of the firm carried on.",
      outcomeVulnerable:
        "The ransomware encrypted every case file in the firm and the criminals began publishing clients' secrets one by one.",
      learning:
        "Ransomware is malware that encrypts your files and demands payment, and modern gangs also threaten to publish what they steal. Anti-malware software stops it by recognising it and quarantining it before it runs. User access levels limit the damage, because malware can only reach what the infected account can reach.",
      consequence:
        "Every case file encrypted · £5m ransom · Client secrets published",
    },
    {
      id: "law_brute_force",
      name: "Client Portal Brute Force",
      attackType: "Brute-Force",
      scenario:
        "Harcourt & Vale's clients log in to a portal to read their case documents. A rival's hired hacker points a bot at a billionaire client's account and fires thousands of guesses a minute: 'yacht2024', 'Monaco!', 'password123'.",
      protectedBy: ["password_policy", "account_lockout", "two_factor"],
      alsoHelpedBy: ["firewall"],
      outcomeProtected:
        "The bot got nowhere: the password was too long to guess, the account locked after a few wrong tries, or a second code was needed. The billionaire's documents were never opened.",
      outcomePartial:
        "Your firewall blocked the first attacking addresses, but the bot switched to new ones and cracked the password after two days. IT spotted the strange login and locked it within the hour.",
      outcomeVulnerable:
        "The bot cracked the weak password in minutes. The rival read the billionaire's whole takeover strategy and outbid them the next morning.",
      learning: Q,
      consequence:
        "Client account cracked · Takeover strategy leaked · Client sues the firm",
    },
    {
      id: "law_court_interception",
      name: "Court Wi-Fi Interception",
      attackType: "Data Interception and Theft",
      scenario:
        "During a huge fraud trial, Harcourt & Vale's barristers send witness statements back to the office over the court's free Wi-Fi. A journalist on the public benches runs packet-sniffing software on the same network and captures everything.",
      protectedBy: ["encryption"],
      alsoHelpedBy: [],
      outcomeProtected:
        "Every statement was encrypted before it left the laptop. The journalist captured thousands of packets of scrambled nonsense and the trial carried on.",
      outcomePartial:
        "Some files were protected, but one witness statement was readable.",
      outcomeVulnerable:
        "Everything travelled as plain data. The statements were in a newspaper the next day, the judge halted the trial and the firm was reported to the regulator.",
      learning: G,
      consequence:
        "Witness statements leaked · Trial halted · Firm reported to the regulator",
    },
    {
      id: "law_sql_injection",
      name: "Case Tracker SQL Injection",
      attackType: "SQL Injection",
      scenario:
        "Harcourt & Vale's clients check on their house purchase by typing a case reference into a 'Track your case' box. An attacker types ' OR 1=1; -- instead. If the box passes it straight to the database, it will send back every client's case notes, home address and bank details.",
      protectedBy: ["input_validation", "pen_testers"],
      alsoHelpedBy: ["user_access"],
      outcomeProtected:
        "The box rejected the code, either because it only accepts a case reference like HV-123456 or because your penetration testers had already found and fixed the weakness. The attacker got an error message and nothing else.",
      outcomePartial:
        "The injection worked, but the tracker's database account could only read the progress table, not the case files. A list of clients' names and purchase stages leaked before the hole was closed.",
      outcomeVulnerable:
        "The database handed over 60,000 clients' case notes, home addresses and bank details. Fraudsters used them to pose as the firm and ask clients to send money.",
      learning: U,
      consequence:
        "60,000 client files stolen · Clients targeted by fraudsters · ICO fine",
    },
    {
      id: "law_blagging",
      name: "Completion Day Blag",
      attackType: "Social Engineering",
      scenario:
        "On completion day, a conveyancing assistant takes a call from someone claiming to be a client selling her house. 'I've changed banks this morning. Send the £640,000 from the sale to my new account before 2pm or the whole chain collapses!' It is not the client.",
      protectedBy: ["staff_training"],
      alsoHelpedBy: [],
      outcomeProtected:
        "Your trained assistant refused to change bank details over the phone and rang the client back on the number already on file. The real client had not changed banks, and the money went to the right account.",
      outcomePartial:
        "The assistant did not send the money, but confirmed the client's address and sale price to the caller.",
      outcomeVulnerable:
        "Under pressure, the assistant typed in the new bank details and sent the money. The £640,000 vanished through accounts abroad within an hour, and the firm had to repay the client.",
      learning: Z,
      consequence:
        "£640,000 sent to criminals · House sale delayed · Firm repays the client",
    },
    {
      id: "law_ddos",
      name: "Deal Data Room DDoS",
      attackType: "Denial of Service",
      scenario:
        "Harcourt & Vale runs the online data room for a £2 billion takeover, and every bidder must upload its final offer by midnight. At 9pm a botnet of hijacked computers floods the data room with millions of fake requests, and the bidders cannot get in.",
      protectedBy: ["firewall"],
      alsoHelpedBy: [],
      outcomeProtected:
        "Your firewall recognised the flood from the botnet and its rules blocked those sources. Every bidder uploaded on time and the deal was signed the next morning.",
      outcomePartial:
        "Some of the flood was filtered, but the data room was down for two hours before midnight.",
      outcomeVulnerable:
        "The data room stayed down until well after midnight. Two bidders missed the deadline, the sale had to be restarted and the client blamed the firm.",
      learning: Y,
      consequence: "Data room offline · Final bids missed · £2bn deal delayed",
    },
    {
      id: "law_shouldering",
      name: "Courtside Café Shoulder Surf",
      attackType: "Social Engineering",
      scenario:
        "A trainee grabs a coffee near the Royal Courts and logs into the firm's case system on a laptop to check a hearing time. A man at the next table angles his phone at the keyboard and films every key. That evening a stranger tries to log in.",
      protectedBy: ["staff_training", "two_factor"],
      alsoHelpedBy: ["user_access"],
      outcomeProtected:
        "Either your trained trainee sat with their back to the wall, shielded the keyboard and noticed the phone, or the filmed password was useless without the code sent to the trainee's phone. The stranger never got in.",
      outcomePartial:
        "He filmed the whole password and the stranger logged in, but user access levels meant a trainee could only open their own team's cases. He saw a hearing list, not the celebrity's files.",
      outcomeVulnerable:
        "He filmed the whole password and nothing else was needed. The stranger logged into the case system and copied the files on a celebrity's upcoming court case.",
      learning: K,
      consequence:
        "Case system breached · Celebrity case leaked · Client loses trust",
    },
    {
      id: "law_office_break_in",
      name: "Archive Room Break-in",
      attackType: "Data Theft",
      scenario:
        "Late on a Friday, a man in a cleaner's tabard pushes a trolley past reception, walks into the archive room and unplugs the backup drive. It holds scanned copies of every will, deed and contract the firm has handled in twenty years.",
      protectedBy: ["physical_security"],
      alsoHelpedBy: ["encryption"],
      outcomeProtected:
        "The archive room needed a keycard, CCTV flagged a cleaner who was not on the rota and the door alarm sounded. Security stopped him at the lifts with the drive still on his trolley.",
      outcomePartial:
        "He escaped with the backup drive, but it was encrypted. The firm lost the hardware, but not a single readable will or deed.",
      outcomeVulnerable:
        "The drive left the building and nothing on it was protected. Clients' wills, property deeds and family secrets were offered for sale online.",
      learning:
        "Not every attack comes over the internet. Physical security, such as keycard doors, CCTV, alarms and checking who should be in the building, stops intruders reaching the hardware at all. Encryption is the backup plan: if a drive is stolen anyway, the data on it cannot be read without the key.",
      consequence:
        "Twenty years of wills stolen · Clients' secrets for sale · Regulator investigates",
    },
  ],
  mi = [
    {
      id: "vidora_brute_force",
      name: "Mega-Creator Takeover",
      attackType: "Brute-Force",
      scenario:
        "Bots start hammering the login of Vidora's biggest creator, with 40 million subscribers, trying thousands of passwords a minute. Whoever gets in can post to 40 million people.",
      protectedBy: ["password_policy", "account_lockout", "two_factor"],
      alsoHelpedBy: ["firewall"],
      outcomeProtected:
        "The bots got nowhere: the password was too strong, the account locked after a few wrong guesses, or a second code was needed. The channel was never touched.",
      outcomePartial:
        "Your firewall slowed the bots down, but they switched addresses and got in for ten minutes before the creator noticed.",
      outcomeVulnerable:
        "The bots cracked the password and posted a crypto scam to 40 million subscribers. Thousands of fans lost money before the video came down.",
      learning: Q,
      consequence:
        "Channel hijacked · Scam sent to 40 million · Fans lose money",
    },
    {
      id: "vidora_sql_injection",
      name: "Payouts SQL Injection",
      attackType: "SQL Injection",
      scenario:
        "On the creator payouts page, an attacker types ' OR 1=1; -- into the search box. If the page passes it straight to the database, it will send back every creator's bank details and earnings.",
      protectedBy: ["input_validation", "pen_testers"],
      alsoHelpedBy: ["user_access"],
      outcomeProtected:
        "The search box rejected the code, either because it validates every input or because your penetration testers found the hole and it was fixed. The attacker got nothing.",
      outcomePartial:
        "The injection worked, but the search page's database account could only read creators' channel names and payout dates, not their bank details. The attacker got a list of who earns what and when, and nothing they could steal money with.",
      outcomeVulnerable:
        "The database handed over two million creators' bank details and earnings. Creators were targeted by fraudsters and many left for rival platforms.",
      learning: U,
      consequence: "2 million creators exposed · Bank fraud · Creators quit",
    },
    {
      id: "vidora_blagging",
      name: "Live-Stream Blag",
      attackType: "Social Engineering",
      scenario:
        "Creator support gets a frantic call. 'I'm the manager of your biggest star. They go live to two million people in five minutes and they're locked out. Reset the password now or we move to another platform!' The caller is not the manager.",
      protectedBy: ["staff_training"],
      alsoHelpedBy: [],
      outcomeProtected:
        "Your trained agent recognised the pressure tactics, refused to reset anything over the phone and checked with the creator through the app. The real creator went live on time.",
      outcomePartial:
        "The agent hesitated, but still gave away the email address on the account.",
      outcomeVulnerable:
        "Under pressure, the agent reset the password. The caller went live on the star's channel in front of two million viewers and streamed a scam.",
      learning: Z,
      consequence:
        "Star channel hijacked live · Scam to 2 million viewers · Trust destroyed",
    },
    {
      id: "vidora_trojan",
      name: "Editing Plugin Trojan",
      attackType: "Malware",
      scenario:
        "A Vidora engineer installs a 'free 8K video filter plugin' from a forum. It is a trojan: malware disguised as something useful. Behind the scenes it opens a back door into the servers that store unreleased videos from the platform's biggest stars.",
      protectedBy: ["anti_malware"],
      alsoHelpedBy: ["user_access"],
      outcomeProtected:
        "Your anti-malware software recognised the plugin as a trojan and quarantined it before the back door ever opened.",
      outcomePartial:
        "The trojan ran, but the engineer's account could only reach the test servers. The attackers found dummy videos and nothing else.",
      outcomeVulnerable:
        "The back door stayed open for weeks. Hundreds of unreleased videos leaked online before their premieres, and furious creators threatened to leave.",
      learning:
        "A trojan is malware disguised as useful software, so the victim installs it themselves. Anti-malware software stops it by recognising it from known signatures and suspicious behaviour, then quarantining it before it runs. User access levels limit the damage, because the trojan can only reach what the infected account can reach.",
      consequence:
        "Unreleased videos leaked · Premieres ruined · Creators threaten to leave",
    },
    {
      id: "vidora_ddos",
      name: "World Cup Final DDoS",
      attackType: "Denial of Service",
      scenario:
        "Vidora has the rights to stream the World Cup final live to 300 million viewers. Ten minutes before kick-off, a botnet of hijacked computers floods the streaming servers with billions of fake requests.",
      protectedBy: ["firewall"],
      alsoHelpedBy: [],
      outcomeProtected:
        "Your firewall recognised the flood from the botnet and its rules blocked those sources. The stream never buffered and Vidora set a world record for live viewers.",
      outcomePartial:
        "Some of the flood was filtered, but the stream froze for the whole first half.",
      outcomeVulnerable:
        "The stream collapsed before kick-off and stayed down for the whole match. 300 million viewers missed the final and advertisers demanded £200 million back.",
      learning: Y,
      consequence: "Final not shown · 300 million viewers lost · £200m refunds",
    },
    {
      id: "vidora_phishing",
      name: "Moderator Text Phish",
      attackType: "Social Engineering",
      scenario:
        "Vidora's content moderators get a text: 'ModDesk: your account will be suspended in 30 minutes. Verify now at vidora-moddesk.help.' The link opens a perfect copy of the moderation login page. A moderator account can delete any video and ban any creator.",
      protectedBy: ["staff_training", "two_factor"],
      alsoHelpedBy: ["user_access"],
      outcomeProtected:
        "Either your moderators spotted the fake web address and reported the text, or the stolen passwords were useless without the code sent to their phones. Not one video was touched.",
      outcomePartial:
        "Two moderators gave away their passwords, but user access levels meant each could only act on their own region's queue. A few hundred videos were hidden for an hour before the accounts were locked.",
      outcomeVulnerable:
        "Two moderators gave away their passwords and their accounts could reach everything. On a Saturday night the attackers banned the platform's top creators and deleted their channels.",
      learning: O,
      consequence:
        "Moderator accounts hijacked · Top channels deleted · Creators furious",
    },
    {
      id: "vidora_interception",
      name: "Hotel Wi-Fi Sniffing",
      attackType: "Data Interception and Theft",
      scenario:
        "The night before the Vidora Creator Awards, a Vidora talent manager sits in a hotel lobby and uploads the secret winners list to the show team over the hotel's free guest Wi-Fi. A guest across the lobby is on the same network, running packet-sniffing software on a laptop that captures every packet sent through the router.",
      protectedBy: ["encryption"],
      alsoHelpedBy: [],
      outcomeProtected:
        "The winners list was encrypted before it left the laptop. The guest captured every packet but could only see scrambled nonsense, and the winners stayed secret until they were announced live on stage.",
      outcomePartial:
        "Most of the upload was protected, but some of the list was readable.",
      outcomeVulnerable:
        "Everything travelled as plain data. The guest pieced the packets back together and posted every winner online before midnight. By the time the show went live, millions of fans already knew the results and the creators had lost their big moment.",
      learning: G,
      consequence:
        "Winners leaked online · Awards show spoiled · Sponsors pull out",
    },
    {
      id: "vidora_virus",
      name: "Final Cut Virus",
      attackType: "Malware",
      scenario:
        "Two days before Vidora's biggest original series premieres, an editor finds a USB stick in the car park labelled 'S2 FINAL CUT' and plugs it in. Hidden on it is a virus, malware that attaches itself to files. It latches onto the episode files, and every time another edit machine opens a shared episode, the virus copies itself there and corrupts more footage.",
      protectedBy: ["anti_malware"],
      alsoHelpedBy: ["user_access"],
      outcomeProtected:
        "Your anti-malware software scanned the stick the moment it was plugged in, matched the virus to a known signature and quarantined it before it could attach to a single episode. The premiere went out on Friday as planned.",
      outcomePartial:
        "The virus attached itself to the editor's episode, but user access levels meant that account could only reach one shared folder. One episode was corrupted and rebuilt from backup while the other edit machines stayed clean.",
      outcomeVulnerable:
        "The virus rode the shared episode files onto every edit machine in the building, corrupting 3,412 clips as it spread. The premiere was cancelled after the trailer had already gone out, and fans flooded social media with complaints.",
      learning:
        "A virus is malware that attaches itself to a file or program. It runs when that file is opened, copies itself into other files, and spreads every time an infected file is run or shared. Unlike a worm, it needs a person to run or share the infected file. Anti-malware software stops it by checking files against known virus signatures and watching for suspicious behaviour, then quarantining infected files before they run. User access levels limit the damage, because a virus can only reach the shared folders the infected account can open.",
      consequence:
        "Virus on every edit machine · 3,412 clips corrupted · Premiere cancelled",
    },
    {
      id: "vidora_studio_break_in",
      name: "Creator Studio Break-in",
      attackType: "Data Theft",
      scenario:
        "Vidora's London creator studio is filming a secret collaboration between two of the world's biggest stars. A man carrying a box of props follows a runner through the side door, walks into the edit bay and leaves with the hard drive of raw footage.",
      protectedBy: ["physical_security"],
      alsoHelpedBy: ["encryption"],
      outcomeProtected:
        "The edit bay needed a keycard, the side door alarm sounded when it was held open and CCTV picked him out. Security stopped him in the car park with the drive still in the box.",
      outcomePartial:
        "He escaped with the drive, but it was encrypted. The studio lost the hardware, but not a second of watchable footage.",
      outcomeVulnerable:
        "The drive left the building and nothing on it was protected. The secret collaboration leaked online a week before its premiere and both stars blamed Vidora.",
      learning:
        "Not every attack comes over the internet. Physical security, such as keycard doors, door alarms, CCTV and not letting people follow you in, stops intruders reaching the hardware at all. Encryption is the backup plan: if a drive is stolen anyway, the data on it is unreadable without the key.",
      consequence:
        "Secret collab leaked · Premiere ruined · Stars blame Vidora",
    },
    {
      id: "vidora_shouldering",
      name: "Gaming Expo Shoulder Surf",
      attackType: "Social Engineering",
      scenario:
        "At a packed gaming expo, a Vidora engineer logs into the platform's admin panel on the stand laptop to fix a broken demo. A fan in the crowd is live-streaming the stand on his phone, and the stream shows every key she types.",
      protectedBy: ["staff_training", "two_factor"],
      alsoHelpedBy: ["user_access"],
      outcomeProtected:
        "Either your trained engineer turned the laptop away, shielded the keyboard and spotted the phone, or the streamed password was useless without the code sent to the engineer's phone. Nobody got into the admin panel.",
      outcomePartial:
        "Thousands of viewers saw the password and someone logged in, but user access levels meant the engineer's account could only manage expo demos, not the home page. A demo video was swapped for a meme before the password was changed.",
      outcomeVulnerable:
        "Thousands of viewers saw the password and nothing else was needed. Within minutes someone logged into the admin panel and put a scam banner on Vidora's home page.",
      learning: K,
      consequence:
        "Admin panel breached · Scam on the home page · 2 billion viewers see it",
    },
  ],
  be = [
    {
      id: "police",
      sector: "Public sector",
      organisation: "Northgate Police Service",
      manager: "Priya",
      briefing:
        "You run the network for a police force: the 999 control room, the evidence store and officers on the street.",
      budget: 7e6,
      topUp: 5e6,
      costScale: 20,
      attacks: gi,
    },
    {
      id: "hospital",
      sector: "Public sector",
      organisation: "St Elm University Hospital",
      manager: "Kwame",
      briefing:
        "You run the network for a major hospital: patient records, scanners, operating theatres and A&E.",
      budget: 875e4,
      topUp: 5e6,
      costScale: 25,
      attacks: bi,
    },
    {
      id: "civil",
      sector: "Public sector",
      organisation: "Civil Service Digital Identity Office",
      manager: "Eleanor",
      briefing:
        "You run the network behind passports, tax and benefits for 67 million citizens, from an office in Whitehall.",
      budget: 16e6,
      topUp: 8e6,
      costScale: 40,
      attacks: wi,
    },
    {
      id: "threadline",
      sector: "Private sector",
      organisation: "Threadline",
      manager: "Jade",
      briefing:
        "You run the network for an online fashion giant with 25 million customers, and Black Friday is coming.",
      budget: 7e6,
      topUp: 4e6,
      costScale: 20,
      attacks: ki,
    },
    {
      id: "law",
      sector: "Private sector",
      organisation: "Harcourt & Vale LLP",
      manager: "Raj",
      briefing:
        "You run the network for a top City law firm handling celebrity divorces and billion-pound mergers.",
      budget: 35e5,
      topUp: 2e6,
      costScale: 10,
      attacks: ui,
    },
    {
      id: "vidora",
      sector: "Private sector",
      organisation: "Vidora",
      manager: "Marcus",
      briefing:
        "You run the network for a video and social platform with 2 billion viewers and the world's biggest creators.",
      budget: 175e5,
      topUp: 1e7,
      costScale: 50,
      attacks: mi,
    },
  ],
  ge = 3,
  Me = ge + 2;
function Nt(i) {
  return i.budget + i.topUp;
}
function st(i) {
  return be.find((t) => t.id === i) ?? be[0];
}
function rt(i, t = Math.random) {
  const s = [...i.attacks];
  for (let l = s.length - 1; l > 0; l -= 1) {
    const a = Math.floor(t() * (l + 1));
    [s[l], s[a]] = [s[a], s[l]];
  }
  return s.slice(0, Me);
}
function Mi(i, t) {
  return i.protectedBy.some((a) => t.includes(a))
    ? "protected"
    : i.alsoHelpedBy.some((a) => t.includes(a))
      ? "partial"
      : "vulnerable";
}
function H(i) {
  return i >= 1e6
    ? `£${Number((i / 1e6).toFixed(2))}m`
    : `£${Number((i / 1e3).toFixed(1))}k`;
}
const Ne = { protected: 2, partial: 1, vulnerable: 0 };
function ve(i, t) {
  return i.cost * t.costScale;
}
function Ye(i, t) {
  return i.reduce((s, l) => {
    const a = B.find((c) => c.id === l);
    return s + (a ? ve(a, t) : 0);
  }, 0);
}
function vi(i, t, s, l = s.budget) {
  return t.includes(i.id) || l - Ye(t, s) >= ve(i, s);
}
function zi(i, t) {
  const s = t === 0 ? 0 : Math.round((i / t) * 100);
  return s >= 84
    ? {
        label: "Expert Defender",
        message:
          "Outstanding budget management. Your network was well protected against every threat.",
        tone: "good",
      }
    : s >= 50
      ? {
          label: "Competent Manager",
          message:
            "You stopped some attacks but not all. Think about which measures cover the widest range of threats.",
          tone: "mixed",
        }
      : {
          label: "Network at Risk",
          message:
            "The attackers had a field day. Revisit which measures protect against the most threats and try again.",
          tone: "bad",
        };
}
function r({
  x: i,
  y: t,
  size: s = 10,
  fill: l = "#111b23",
  weight: a = 700,
  anchor: c = "start",
  children: h,
}) {
  return e.jsx("text", {
    x: i,
    y: t,
    fontSize: s,
    fill: l,
    fontWeight: a,
    textAnchor: c,
    children: h,
  });
}
function f({ x: i, y: t, w: s, h: l, bar: a = "#333e48", children: c }) {
  return e.jsxs("g", {
    children: [
      e.jsx("rect", {
        x: i,
        y: t,
        width: s,
        height: l,
        rx: 6,
        fill: "#e3e9ee",
        stroke: "#95a1ac",
      }),
      e.jsx("path", {
        d: `M${i} ${t + 6}a6 6 0 0 1 6 -6h${s - 12}a6 6 0 0 1 6 6v10h${-s}z`,
        fill: a,
      }),
      e.jsx("circle", { cx: i + 9, cy: t + 8, r: 2.4, fill: "#ee766f" }),
      e.jsx("circle", { cx: i + 17, cy: t + 8, r: 2.4, fill: "#e8ba61" }),
      e.jsx("circle", { cx: i + 25, cy: t + 8, r: 2.4, fill: "#7ed99f" }),
      c,
    ],
  });
}
function J({ x: i, y: t, s = 1, fill: l = "#cb5651", shackle: a }) {
  return e.jsxs("g", {
    transform: `translate(${i} ${t}) scale(${s})`,
    children: [
      e.jsx("path", {
        d: "M-7 -2v-6a7 7 0 0 1 14 0v6",
        fill: "none",
        stroke: a ?? l,
        strokeWidth: 3.2,
      }),
      e.jsx("rect", { x: -11, y: -3, width: 22, height: 18, rx: 3, fill: l }),
      e.jsx("circle", { cx: 0, cy: 5, r: 2.6, fill: "rgba(0,0,0,0.45)" }),
      e.jsx("rect", {
        x: -1,
        y: 6,
        width: 2,
        height: 5,
        fill: "rgba(0,0,0,0.45)",
      }),
    ],
  });
}
function ze({ x: i, y: t, s = 1, fill: l = "#5bb57e" }) {
  return e.jsxs("g", {
    transform: `translate(${i} ${t}) scale(${s})`,
    children: [
      e.jsx("path", {
        d: "M0 -20 L16 -14 V0 C16 11 8 17 0 21 C-8 17 -16 11 -16 0 V-14z",
        fill: l,
      }),
      e.jsx("path", {
        d: "M-7 0l5 5 9 -10",
        fill: "none",
        stroke: "#102333",
        strokeWidth: 3.4,
        strokeLinecap: "round",
        strokeLinejoin: "round",
      }),
    ],
  });
}
function q({ x: i, y: t, r: s = 5, stroke: l = "#cb5651", width: a = 3 }) {
  return e.jsx("path", {
    d: `M${i - s} ${t - s}l${s * 2} ${s * 2}M${i + s} ${t - s}l${-s * 2} ${s * 2}`,
    stroke: l,
    strokeWidth: a,
    strokeLinecap: "round",
  });
}
function Le({ x: i, y: t, s = 1, stroke: l = "#5bb57e" }) {
  return e.jsx("path", {
    d: `M${i - 5 * s} ${t}l${4 * s} ${4 * s} ${7 * s} ${-8 * s}`,
    fill: "none",
    stroke: l,
    strokeWidth: 2.8,
    strokeLinecap: "round",
    strokeLinejoin: "round",
  });
}
function St({ x: i, y: t, w: s, units: l }) {
  return e.jsxs("g", {
    children: [
      e.jsx("rect", {
        x: i,
        y: t,
        width: s,
        height: l * 22 + 12,
        rx: 4,
        fill: "#242f38",
        stroke: "#46515b",
        strokeWidth: 2,
      }),
      Array.from({ length: l }, (a, c) =>
        e.jsxs(
          "g",
          {
            children: [
              e.jsx("rect", {
                x: i + 6,
                y: t + 6 + c * 22,
                width: s - 12,
                height: 18,
                rx: 2,
                fill: "#333e48",
              }),
              e.jsx("circle", {
                cx: i + s - 14,
                cy: t + 15 + c * 22,
                r: 2.6,
                fill: "#7ed99f",
              }),
              e.jsx("circle", {
                cx: i + s - 22,
                cy: t + 15 + c * 22,
                r: 2.6,
                fill: "#6ca8ca",
              }),
              e.jsx("rect", {
                x: i + 12,
                y: t + 13 + c * 22,
                width: s * 0.38,
                height: 4,
                rx: 2,
                fill: "#242f38",
              }),
            ],
          },
          c,
        ),
      ),
    ],
  });
}
function Li() {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#111b23" }),
      e.jsx("rect", { y: 196, width: 400, height: 44, fill: "#242f38" }),
      e.jsxs("g", {
        transform: "translate(96 196) scale(1.18) translate(-96 -196)",
        children: [
          e.jsx("path", {
            d: "M22 196 C22 150 40 132 70 132 C100 132 118 150 118 196z",
            fill: "#bac3cb",
          }),
          e.jsx("path", {
            d: "M70 132 L70 196",
            stroke: "#bac3cb",
            strokeWidth: 2,
          }),
          e.jsx("circle", { cx: 70, cy: 106, r: 22, fill: "#f1c9a5" }),
          e.jsx("path", {
            d: "M50 102 C50 84 90 84 90 102 Q70 96 50 102z",
            fill: "#901e21",
          }),
          e.jsx("path", {
            d: "M36 92 Q70 82 104 92 Q70 98 36 92z",
            fill: "#e3e9ee",
          }),
          e.jsx("path", { d: "M52 92 C52 64 88 64 88 92z", fill: "#e3e9ee" }),
          e.jsx("rect", {
            x: 52,
            y: 84,
            width: 36,
            height: 5,
            fill: "#95a1ac",
          }),
          e.jsx("circle", { cx: 62, cy: 108, r: 2.4, fill: "#111b23" }),
          e.jsx("circle", { cx: 78, cy: 108, r: 2.4, fill: "#111b23" }),
          e.jsx("path", {
            d: "M63 118 q7 5 14 0",
            fill: "none",
            stroke: "#111b23",
            strokeWidth: 2,
            strokeLinecap: "round",
          }),
          e.jsx("path", {
            d: "M78 196 L96 150 H170 L152 196z",
            fill: "#46515b",
          }),
          e.jsx("path", {
            d: "M102 156 H164 L150 190 H88z",
            fill: "#6ca8ca",
            opacity: 0.35,
          }),
          e.jsx("rect", {
            x: 70,
            y: 194,
            width: 100,
            height: 6,
            rx: 2,
            fill: "#5c6873",
          }),
          e.jsx("path", {
            d: "M108 168 h18 M104 177 h30",
            stroke: "#bac3cb",
            strokeWidth: 2.5,
            strokeLinecap: "round",
          }),
        ],
      }),
      e.jsx("path", {
        d: "M166 150 C186 140 190 120 208 110",
        fill: "none",
        stroke: "#6ca8ca",
        strokeWidth: 2,
        strokeDasharray: "5 5",
        className: "attack-flow",
      }),
      e.jsx(St, { x: 204, y: 14, w: 76, units: 8 }),
      e.jsx("circle", {
        cx: 242,
        cy: 108,
        r: 30,
        fill: "#111b23",
        opacity: 0.55,
      }),
      e.jsx("circle", {
        cx: 242,
        cy: 108,
        r: 30,
        fill: "none",
        stroke: "#e8ba61",
        strokeWidth: 6,
      }),
      e.jsx("path", {
        d: "M228 92 l10 10 -6 6 14 8 -4 6 10 6",
        fill: "none",
        stroke: "#cb5651",
        strokeWidth: 3.5,
        strokeLinecap: "round",
        strokeLinejoin: "round",
        className: "attack-flash",
      }),
      e.jsx("path", {
        d: "M263 130 L284 152",
        stroke: "#e8ba61",
        strokeWidth: 9,
        strokeLinecap: "round",
      }),
      e.jsx("rect", {
        x: 298,
        y: 26,
        width: 88,
        height: 178,
        rx: 6,
        fill: "#746351",
      }),
      e.jsx("rect", {
        x: 305,
        y: 36,
        width: 74,
        height: 162,
        rx: 2,
        fill: "#e3e9ee",
      }),
      e.jsx("rect", {
        x: 326,
        y: 20,
        width: 32,
        height: 14,
        rx: 3,
        fill: "#5c6873",
      }),
      e.jsx(r, {
        x: 342,
        y: 58,
        size: 10,
        anchor: "middle",
        fill: "#111b23",
        children: "REPORT",
      }),
      [0, 1, 2, 3, 4].map((i) => {
        const t = i !== 2 && i !== 4,
          s = 82 + i * 25;
        return e.jsxs(
          "g",
          {
            children: [
              t
                ? e.jsx(q, { x: 316, y: s, r: 4, width: 2.6 })
                : e.jsx(Le, { x: 316, y: s - 1, s: 0.9 }),
              e.jsx("rect", {
                x: 326,
                y: s - 4,
                width: i % 2 ? 36 : 46,
                height: 4,
                rx: 2,
                fill: "#95a1ac",
              }),
              e.jsx("rect", {
                x: 326,
                y: s + 3,
                width: 28,
                height: 3,
                rx: 1.5,
                fill: "#bac3cb",
              }),
            ],
          },
          i,
        );
      }),
    ],
  });
}
function Wi({ x: i, y: t, bad: s }) {
  return e.jsxs("g", {
    children: [
      e.jsx("path", {
        d: `M${i} ${t}h22l9 9v31h-31z`,
        fill: s ? "#d1beaa" : "#bac3cb",
      }),
      e.jsx("path", {
        d: `M${i + 22} ${t}v9h9`,
        fill: "none",
        stroke: "#95a1ac",
      }),
      [0, 1, 2].map((l) =>
        e.jsx(
          "rect",
          {
            x: i + 5,
            y: t + 16 + l * 6,
            width: l === 2 ? 12 : 20,
            height: 2.6,
            rx: 1.3,
            fill: s ? "#ee766f" : "#95a1ac",
          },
          l,
        ),
      ),
    ],
  });
}
function $i({ x: i, y: t, s = 1 }) {
  return e.jsxs("g", {
    transform: `translate(${i} ${t}) scale(${s})`,
    children: [
      e.jsx("path", {
        d: "M-10 -6l-8 -6M10 -6l8 -6M-12 2h-10M12 2h10M-10 10l-8 7M10 10l8 7M-4 -14l-4 -7M4 -14l4 -7",
        stroke: "#901e21",
        strokeWidth: 2.6,
        strokeLinecap: "round",
      }),
      e.jsx("ellipse", { cx: 0, cy: 4, rx: 12, ry: 15, fill: "#cb5651" }),
      e.jsx("circle", { cx: 0, cy: -11, r: 7, fill: "#ac3a38" }),
      e.jsx("path", { d: "M0 -4v22", stroke: "#901e21", strokeWidth: 2 }),
      e.jsx("circle", { cx: -3, cy: -12, r: 1.8, fill: "#e3e9ee" }),
      e.jsx("circle", { cx: 3, cy: -12, r: 1.8, fill: "#e3e9ee" }),
    ],
  });
}
function Ti() {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#111b23" }),
      e.jsx("rect", {
        x: 104,
        y: 196,
        width: 90,
        height: 8,
        rx: 3,
        fill: "#333e48",
      }),
      e.jsx("rect", { x: 138, y: 178, width: 22, height: 20, fill: "#333e48" }),
      e.jsx("rect", {
        x: 14,
        y: 18,
        width: 270,
        height: 164,
        rx: 8,
        fill: "#242f38",
      }),
      e.jsx("rect", {
        x: 24,
        y: 28,
        width: 250,
        height: 144,
        rx: 3,
        fill: "#19232c",
      }),
      [0, 1, 2, 3].map((i) =>
        [0, 1].map((t) =>
          e.jsx(
            Wi,
            { x: 38 + i * 52, y: 46 + t * 62, bad: i === 3 && t === 0 },
            `${i}-${t}`,
          ),
        ),
      ),
      e.jsx("rect", {
        x: 24,
        y: 84,
        width: 250,
        height: 26,
        fill: "#5bb57e",
        opacity: 0.18,
        className: "attack-flash",
      }),
      e.jsx("rect", { x: 24, y: 108, width: 250, height: 3, fill: "#7ed99f" }),
      e.jsx("path", {
        d: "M188 42 h43 v48 h-43z",
        fill: "none",
        stroke: "#cb5651",
        strokeWidth: 2.5,
        className: "attack-flash",
      }),
      e.jsx(ze, { x: 252, y: 100, s: 1.1 }),
      e.jsx("path", {
        d: "M222 40 C270 6 330 26 336 76",
        fill: "none",
        stroke: "#ee766f",
        strokeWidth: 2.2,
        strokeDasharray: "5 5",
        className: "attack-flow",
      }),
      e.jsx("path", {
        d: "M329 70 l7 10 6 -11",
        fill: "none",
        stroke: "#ee766f",
        strokeWidth: 2.2,
        strokeLinejoin: "round",
      }),
      e.jsx("rect", {
        x: 292,
        y: 88,
        width: 92,
        height: 112,
        rx: 4,
        fill: "#242f38",
      }),
      e.jsx($i, { x: 338, y: 146, s: 1.25 }),
      [0, 1, 2, 3, 4, 5].map((i) =>
        e.jsx(
          "rect",
          { x: 298 + i * 16, y: 88, width: 5, height: 112, fill: "#95a1ac" },
          i,
        ),
      ),
      e.jsx("rect", {
        x: 288,
        y: 84,
        width: 100,
        height: 10,
        rx: 3,
        fill: "#bac3cb",
      }),
      e.jsx("rect", {
        x: 288,
        y: 196,
        width: 100,
        height: 10,
        rx: 3,
        fill: "#bac3cb",
      }),
      e.jsx(J, { x: 372, y: 110, s: 1.1, fill: "#e8ba61", shackle: "#ffe4b4" }),
      e.jsx("rect", {
        x: 14,
        y: 212,
        width: 370,
        height: 14,
        rx: 7,
        fill: "#242f38",
      }),
      e.jsx("rect", {
        x: 14,
        y: 212,
        width: 250,
        height: 14,
        rx: 7,
        fill: "#5bb57e",
      }),
    ],
  });
}
function Se({ x: i, y: t, ok: s }) {
  return e.jsxs("g", {
    children: [
      e.jsx("rect", {
        x: i - 11,
        y: t - 8,
        width: 22,
        height: 16,
        rx: 2,
        fill: s ? "#7ed99f" : "#ee766f",
      }),
      e.jsx("path", {
        d: `M${i - 11} ${t - 7}l11 8 11 -8`,
        fill: "none",
        stroke: s ? "#006034" : "#901e21",
        strokeWidth: 1.6,
      }),
    ],
  });
}
function Ci() {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#111b23" }),
      e.jsx("rect", { y: 214, width: 400, height: 26, fill: "#242f38" }),
      e.jsxs("g", {
        transform: "translate(46 70)",
        children: [
          e.jsx("circle", { r: 32, fill: "#326e8e" }),
          e.jsx("ellipse", {
            rx: 14,
            ry: 32,
            fill: "none",
            stroke: "#8ecbee",
            strokeWidth: 2,
          }),
          e.jsx("path", {
            d: "M-32 0h64M-28 -14h56M-28 14h56",
            stroke: "#8ecbee",
            strokeWidth: 2,
          }),
          e.jsx("circle", {
            r: 32,
            fill: "none",
            stroke: "#8ecbee",
            strokeWidth: 2,
          }),
        ],
      }),
      e.jsx("path", {
        d: "M76 90 C100 120 120 124 160 124 H310",
        fill: "none",
        stroke: "#7ed99f",
        strokeWidth: 2,
        strokeDasharray: "5 6",
        className: "attack-flow",
      }),
      e.jsx(Se, { x: 112, y: 120, ok: !0 }),
      e.jsx(Se, { x: 276, y: 124, ok: !0 }),
      [
        { y: 70, by: 40 },
        { y: 178, by: 198 },
      ].map(({ y: t, by: s }) =>
        e.jsxs(
          "g",
          {
            children: [
              e.jsx("path", {
                d: `M150 ${t} Q130 ${t} 100 ${s}`,
                fill: "none",
                stroke: "#ee766f",
                strokeWidth: 2,
                strokeDasharray: "4 4",
              }),
              e.jsx("path", {
                d: `M152 ${t - 9} l4 6 6 -4 -2 7 7 2 -7 2 2 7 -6 -4 -4 6 -1 -7 -7 0 5 -5 -5 -5 7 0z`,
                fill: "#ffe4b4",
              }),
              e.jsx(Se, { x: 92, y: s }),
            ],
          },
          t,
        ),
      ),
      Array.from({ length: 9 }, (t, s) => {
        const l = 52 + s * 18;
        if (s === 3 || s === 4) return null;
        const a = s % 2 ? [10, 20, 20, 20, 10] : [20, 20, 20, 20];
        let c = 160;
        return a.map((h, o) => {
          const d = e.jsx(
            "rect",
            {
              x: c + 0.5,
              y: l,
              width: h - 1,
              height: 17,
              fill: ((s + o) % 3, "#ac3a38"),
            },
            `${s}-${o}`,
          );
          return ((c += h), d);
        });
      }),
      e.jsx("rect", {
        x: 160,
        y: 106,
        width: 80,
        height: 36,
        fill: "#5bb57e",
        opacity: 0.16,
      }),
      e.jsx("rect", { x: 158, y: 106, width: 4, height: 36, fill: "#5bb57e" }),
      e.jsx("rect", { x: 238, y: 106, width: 4, height: 36, fill: "#5bb57e" }),
      [0, 1, 2, 3].map((t) =>
        e.jsxs(
          "g",
          {
            className: t % 2 ? "attack-flash" : void 0,
            children: [
              e.jsx("path", {
                d: `M${167 + t * 20} 52 q-7 -14 2 -26 q0 10 7 12 q2 -8 -1 -14 q12 10 6 28z`,
                fill: "#ee766f",
              }),
              e.jsx("path", {
                d: `M${170 + t * 20} 52 q-2 -8 3 -12 q2 6 4 12z`,
                fill: "#ffe4b4",
              }),
            ],
          },
          t,
        ),
      ),
      e.jsx(St, { x: 310, y: 74, w: 74, units: 6 }),
      e.jsx(ze, { x: 347, y: 48, s: 0.9 }),
    ],
  });
}
function ae({ x: i, y: t, color: s, open: l }) {
  return e.jsxs("g", {
    children: [
      e.jsx("rect", {
        x: i - 4,
        y: t - 4,
        width: 56,
        height: 124,
        rx: 3,
        fill: "#46515b",
      }),
      l
        ? e.jsxs(e.Fragment, {
            children: [
              e.jsx("rect", {
                x: i,
                y: t,
                width: 48,
                height: 120,
                fill: "#f8e4cf",
              }),
              e.jsx("rect", {
                x: i,
                y: t,
                width: 48,
                height: 120,
                fill: "#7ed99f",
                opacity: 0.35,
              }),
              e.jsx("path", { d: `M${i} ${t}l16 8v104l-16 8z`, fill: s }),
            ],
          })
        : e.jsxs(e.Fragment, {
            children: [
              e.jsx("rect", { x: i, y: t, width: 48, height: 120, fill: s }),
              e.jsx("rect", {
                x: i + 6,
                y: t + 8,
                width: 36,
                height: 44,
                rx: 2,
                fill: "rgba(0,0,0,0.18)",
              }),
              e.jsx("rect", {
                x: i + 6,
                y: t + 60,
                width: 36,
                height: 50,
                rx: 2,
                fill: "rgba(0,0,0,0.18)",
              }),
              e.jsx(J, { x: i + 24, y: t + 58, s: 0.95 }),
            ],
          }),
      e.jsx("rect", {
        x: i + 10,
        y: t - 20,
        width: 28,
        height: 10,
        rx: 2,
        fill: s,
      }),
    ],
  });
}
function Ni() {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#242f38" }),
      e.jsx("rect", { y: 200, width: 400, height: 40, fill: "#333e48" }),
      e.jsx(ae, { x: 140, y: 80, color: "#5bb57e", open: !0 }),
      e.jsx(ae, { x: 200, y: 80, color: "#4e89aa" }),
      e.jsx(ae, { x: 260, y: 80, color: "#6e8498" }),
      e.jsx(ae, { x: 320, y: 80, color: "#e8ba61" }),
      e.jsx("path", {
        d: "M158 114 l6 -3 v14 l-6 3z",
        fill: "#f8e4cf",
        opacity: 0.6,
      }),
      e.jsx("path", {
        d: "M18 200 C18 152 38 138 68 138 C98 138 118 152 118 200z",
        fill: "#326e8e",
      }),
      e.jsx("circle", { cx: 68, cy: 110, r: 24, fill: "#c68a5b" }),
      e.jsx("path", {
        d: "M44 106 C44 80 92 80 92 106 Q86 92 68 92 Q50 92 44 106z",
        fill: "#111b23",
      }),
      e.jsx("circle", { cx: 60, cy: 112, r: 2.4, fill: "#111b23" }),
      e.jsx("circle", { cx: 76, cy: 112, r: 2.4, fill: "#111b23" }),
      e.jsx("path", {
        d: "M61 122 q7 5 14 0",
        fill: "none",
        stroke: "#111b23",
        strokeWidth: 2,
        strokeLinecap: "round",
      }),
      e.jsx("path", {
        d: "M54 140 L68 166 L82 140",
        fill: "none",
        stroke: "#5bb57e",
        strokeWidth: 3,
      }),
      e.jsx("rect", {
        x: 52,
        y: 164,
        width: 32,
        height: 34,
        rx: 3,
        fill: "#e3e9ee",
        stroke: "#5bb57e",
        strokeWidth: 3,
      }),
      e.jsx("rect", { x: 52, y: 164, width: 32, height: 8, fill: "#5bb57e" }),
      e.jsx("circle", { cx: 62, cy: 182, r: 5, fill: "#c68a5b" }),
      e.jsx("rect", {
        x: 70,
        y: 178,
        width: 10,
        height: 3,
        rx: 1.5,
        fill: "#95a1ac",
      }),
      e.jsx("rect", {
        x: 70,
        y: 184,
        width: 8,
        height: 3,
        rx: 1.5,
        fill: "#95a1ac",
      }),
      e.jsx("path", {
        d: "M90 180 C112 176 118 150 136 146",
        fill: "none",
        stroke: "#7ed99f",
        strokeWidth: 2.4,
        strokeDasharray: "5 5",
        className: "attack-flow",
      }),
      e.jsx(Le, { x: 164, y: 44, s: 1.4 }),
      [224, 284, 344].map((i) =>
        e.jsx(q, { x: i, y: 42, r: 6, width: 3.2 }, i),
      ),
    ],
  });
}
function Si() {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#111b23" }),
      e.jsxs(f, {
        x: 16,
        y: 22,
        w: 216,
        h: 196,
        bar: "#333e48",
        children: [
          e.jsx("circle", { cx: 124, cy: 66, r: 18, fill: "#bac3cb" }),
          e.jsx("circle", { cx: 124, cy: 60, r: 7, fill: "#5c6873" }),
          e.jsx("path", { d: "M110 78 a14 11 0 0 1 28 0z", fill: "#5c6873" }),
          e.jsx("rect", {
            x: 32,
            y: 94,
            width: 184,
            height: 22,
            rx: 4,
            fill: "#e3e9ee",
            stroke: "#95a1ac",
          }),
          e.jsx("rect", {
            x: 40,
            y: 102,
            width: 70,
            height: 6,
            rx: 3,
            fill: "#95a1ac",
          }),
          e.jsx("rect", {
            x: 32,
            y: 124,
            width: 184,
            height: 24,
            rx: 4,
            fill: "#e3e9ee",
            stroke: "#326e8e",
            strokeWidth: 2,
          }),
          Array.from({ length: 16 }, (i, t) =>
            e.jsx(
              "circle",
              { cx: 42 + t * 10.6, cy: 136, r: 3.2, fill: "#242f38" },
              t,
            ),
          ),
          [0, 1, 2, 3, 4].map((i) =>
            e.jsx(
              "rect",
              {
                x: 32 + i * 26,
                y: 158,
                width: 23,
                height: 9,
                rx: 2,
                fill: "#5bb57e",
              },
              i,
            ),
          ),
          e.jsx(r, {
            x: 216,
            y: 166,
            size: 10,
            anchor: "end",
            fill: "#137a47",
            children: "STRONG",
          }),
          e.jsx("rect", {
            x: 32,
            y: 180,
            width: 184,
            height: 26,
            rx: 4,
            fill: "#bac3cb",
            stroke: "#cb5651",
            strokeWidth: 1.5,
          }),
          e.jsx(J, { x: 124, y: 190, s: 0.75 }),
        ],
      }),
      [0, 1, 2].map((i) =>
        e.jsxs(
          "g",
          {
            children: [
              e.jsx("rect", {
                x: 250 + i * 46,
                y: 24,
                width: 38,
                height: 30,
                rx: 5,
                fill: "#480004",
                stroke: "#cb5651",
                strokeWidth: 2,
              }),
              e.jsx(q, { x: 269 + i * 46, y: 39, r: 7, width: 3.6 }),
            ],
          },
          i,
        ),
      ),
      e.jsx("path", { d: "M318 70 V82", stroke: "#95a1ac", strokeWidth: 3 }),
      e.jsx("circle", {
        cx: 318,
        cy: 68,
        r: 5,
        fill: "#cb5651",
        className: "attack-flash",
      }),
      e.jsx("rect", {
        x: 282,
        y: 82,
        width: 72,
        height: 54,
        rx: 10,
        fill: "#95a1ac",
      }),
      e.jsx("rect", {
        x: 290,
        y: 92,
        width: 56,
        height: 26,
        rx: 6,
        fill: "#242f38",
      }),
      e.jsx("path", {
        d: "M298 100 l10 6 M338 100 l-10 6",
        stroke: "#ee766f",
        strokeWidth: 3,
        strokeLinecap: "round",
      }),
      e.jsx("circle", { cx: 306, cy: 109, r: 4, fill: "#ee766f" }),
      e.jsx("circle", { cx: 330, cy: 109, r: 4, fill: "#ee766f" }),
      e.jsx("rect", {
        x: 304,
        y: 124,
        width: 28,
        height: 5,
        rx: 2,
        fill: "#46515b",
      }),
      e.jsx("rect", {
        x: 276,
        y: 142,
        width: 84,
        height: 60,
        rx: 8,
        fill: "#5c6873",
      }),
      e.jsx("rect", {
        x: 290,
        y: 152,
        width: 56,
        height: 22,
        rx: 3,
        fill: "#242f38",
      }),
      e.jsx(r, {
        x: 318,
        y: 167,
        size: 9,
        anchor: "middle",
        weight: 400,
        fill: "#ee766f",
        children: "?????",
      }),
      e.jsx("path", {
        d: "M276 160 C256 164 248 186 240 192",
        fill: "none",
        stroke: "#5c6873",
        strokeWidth: 9,
        strokeLinecap: "round",
      }),
      e.jsx("path", {
        d: "M360 160 C376 170 380 186 380 200",
        fill: "none",
        stroke: "#5c6873",
        strokeWidth: 9,
        strokeLinecap: "round",
      }),
      e.jsx("rect", { x: 288, y: 202, width: 18, height: 18, fill: "#46515b" }),
      e.jsx("rect", { x: 330, y: 202, width: 18, height: 18, fill: "#46515b" }),
    ],
  });
}
function lt({ x: i, y: t, children: s }) {
  return e.jsxs("g", {
    children: [
      e.jsx("path", { d: `M${i} ${t}h66l18 18v118h-84z`, fill: "#e3e9ee" }),
      e.jsx("path", { d: `M${i + 66} ${t}v18h18`, fill: "#bac3cb" }),
      s,
    ],
  });
}
function Ai() {
  const i = ["#7&Qz!", "x%9@Lp", "K$2~r&", "!vW8#e", "Z^4j%c", "@m5?Yq"];
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#111b23" }),
      e.jsxs(lt, {
        x: 14,
        y: 28,
        children: [
          e.jsx(r, {
            x: 24,
            y: 58,
            size: 12,
            fill: "#111b23",
            children: "Hi Sam,",
          }),
          [0, 1, 2, 3, 4, 5].map((t) =>
            e.jsx(
              "rect",
              {
                x: 24,
                y: 70 + t * 12,
                width: t === 5 ? 36 : 64,
                height: 5,
                rx: 2.5,
                fill: "#5c6873",
              },
              t,
            ),
          ),
          e.jsx("rect", {
            x: 24,
            y: 146,
            width: 40,
            height: 6,
            rx: 3,
            fill: "#326e8e",
          }),
        ],
      }),
      e.jsx("path", { d: "M104 98 H148", stroke: "#95a1ac", strokeWidth: 3 }),
      e.jsx("path", {
        d: "M144 92 l8 6 -8 6",
        fill: "none",
        stroke: "#95a1ac",
        strokeWidth: 3,
        strokeLinejoin: "round",
      }),
      e.jsx("path", { d: "M250 98 H294", stroke: "#7ed99f", strokeWidth: 3 }),
      e.jsx("path", {
        d: "M290 92 l8 6 -8 6",
        fill: "none",
        stroke: "#7ed99f",
        strokeWidth: 3,
        strokeLinejoin: "round",
      }),
      e.jsx("circle", { cx: 200, cy: 98, r: 44, fill: "#242f38" }),
      e.jsx(J, { x: 200, y: 100, s: 2.1, fill: "#5bb57e", shackle: "#a8ffc6" }),
      e.jsxs("g", {
        transform: "translate(176 44) rotate(-30)",
        children: [
          e.jsx("circle", { r: 13, fill: "#e8ba61" }),
          e.jsx("circle", { r: 5, fill: "#242f38" }),
          e.jsx("rect", {
            x: 10,
            y: -4,
            width: 40,
            height: 8,
            rx: 2,
            fill: "#e8ba61",
          }),
          e.jsx("rect", { x: 36, y: 4, width: 5, height: 8, fill: "#e8ba61" }),
          e.jsx("rect", { x: 44, y: 4, width: 5, height: 10, fill: "#e8ba61" }),
        ],
      }),
      e.jsx(lt, {
        x: 300,
        y: 28,
        children: i.map((t, s) =>
          e.jsx(
            r,
            {
              x: 308,
              y: 56 + s * 17,
              size: 12,
              weight: 700,
              fill: "#137a47",
              children: t,
            },
            s,
          ),
        ),
      }),
      e.jsx("path", {
        d: "M342 166 V196 Q342 206 330 206 H262",
        fill: "none",
        stroke: "#7ed99f",
        strokeWidth: 2,
        strokeDasharray: "5 5",
        className: "attack-flow",
      }),
      e.jsx("path", {
        d: "M200 240 C200 206 212 194 236 194 C260 194 272 206 272 240z",
        fill: "#111b23",
      }),
      e.jsx("path", {
        d: "M212 206 C212 176 260 176 260 206 L256 214 H216z",
        fill: "#242f38",
      }),
      e.jsx("ellipse", { cx: 236, cy: 204, rx: 16, ry: 12, fill: "#0d171f" }),
      e.jsx("circle", { cx: 230, cy: 203, r: 2.2, fill: "#ee766f" }),
      e.jsx("circle", { cx: 242, cy: 203, r: 2.2, fill: "#ee766f" }),
      e.jsx("circle", { cx: 162, cy: 196, r: 20, fill: "#e3e9ee" }),
      e.jsx("path", { d: "M176 208 L194 214 L182 198z", fill: "#e3e9ee" }),
      e.jsx(r, {
        x: 162,
        y: 204,
        size: 22,
        anchor: "middle",
        fill: "#cb5651",
        children: "?",
      }),
    ],
  });
}
function Vi() {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#242f38" }),
      Array.from({ length: 6 }, (i, t) =>
        e.jsx(
          "rect",
          { x: 0, y: t * 36, width: 400, height: 1.5, fill: "#333e48" },
          t,
        ),
      ),
      e.jsx("rect", { y: 214, width: 400, height: 26, fill: "#111b23" }),
      e.jsx("path", {
        d: "M78 48 L140 214 L262 214z",
        fill: "#ffe4b4",
        opacity: 0.12,
      }),
      e.jsx("rect", {
        x: 134,
        y: 44,
        width: 132,
        height: 172,
        fill: "#46515b",
      }),
      e.jsx("rect", {
        x: 142,
        y: 52,
        width: 116,
        height: 164,
        fill: "#95a1ac",
      }),
      e.jsx("rect", {
        x: 160,
        y: 66,
        width: 80,
        height: 70,
        rx: 3,
        fill: "#0d171f",
        stroke: "#333e48",
        strokeWidth: 4,
      }),
      e.jsx("rect", { x: 178, y: 74, width: 44, height: 62, fill: "#242f38" }),
      [0, 1, 2, 3].map((i) =>
        e.jsxs(
          "g",
          {
            children: [
              e.jsx("rect", {
                x: 182,
                y: 78 + i * 14,
                width: 36,
                height: 10,
                rx: 1.5,
                fill: "#333e48",
              }),
              e.jsx("circle", {
                cx: 212,
                cy: 83 + i * 14,
                r: 1.8,
                fill: "#7ed99f",
              }),
            ],
          },
          i,
        ),
      ),
      e.jsx(J, { x: 200, y: 118, s: 0.9, fill: "#e8ba61", shackle: "#ffe4b4" }),
      e.jsx("path", {
        d: "M160 92 L192 66 M176 136 L240 84",
        stroke: "#bac3cb",
        strokeWidth: 3,
        opacity: 0.18,
      }),
      e.jsx("rect", {
        x: 232,
        y: 146,
        width: 8,
        height: 30,
        rx: 3,
        fill: "#bac3cb",
      }),
      e.jsx("rect", {
        x: 170,
        y: 186,
        width: 60,
        height: 14,
        rx: 2,
        fill: "#cb5651",
      }),
      e.jsx(r, {
        x: 200,
        y: 196.5,
        size: 7.5,
        anchor: "middle",
        fill: "#e3e9ee",
        children: "SERVER ROOM",
      }),
      e.jsx("rect", {
        x: 278,
        y: 112,
        width: 30,
        height: 46,
        rx: 4,
        fill: "#111b23",
        stroke: "#5c6873",
        strokeWidth: 2,
      }),
      e.jsx("circle", {
        cx: 293,
        cy: 122,
        r: 4.5,
        fill: "#7ed99f",
        className: "attack-flash",
      }),
      e.jsx("path", {
        d: "M286 134 q7 -6 14 0 M289 140 q4 -3 8 0",
        fill: "none",
        stroke: "#5c6873",
        strokeWidth: 2,
        strokeLinecap: "round",
      }),
      e.jsxs("g", {
        transform: "translate(316 132) rotate(-18)",
        children: [
          e.jsx("rect", {
            x: -6,
            y: -6,
            width: 34,
            height: 22,
            rx: 3,
            fill: "#6ca8ca",
          }),
          e.jsx("rect", {
            x: -2,
            y: -2,
            width: 9,
            height: 11,
            rx: 1.5,
            fill: "#bac3cb",
          }),
          e.jsx("rect", {
            x: 10,
            y: 0,
            width: 14,
            height: 3,
            rx: 1.5,
            fill: "#bac3cb",
          }),
          e.jsx("rect", {
            x: 10,
            y: 6,
            width: 10,
            height: 3,
            rx: 1.5,
            fill: "#bac3cb",
          }),
        ],
      }),
      e.jsx("path", {
        d: "M340 140 C352 150 356 170 356 250",
        fill: "none",
        stroke: "#c68a5b",
        strokeWidth: 14,
        strokeLinecap: "round",
      }),
      e.jsx("rect", { x: 10, y: 20, width: 8, height: 30, fill: "#5c6873" }),
      e.jsx("path", { d: "M18 34 H40", stroke: "#5c6873", strokeWidth: 5 }),
      e.jsxs("g", {
        transform: "translate(58 38) rotate(28)",
        children: [
          e.jsx("rect", {
            x: -22,
            y: -11,
            width: 48,
            height: 22,
            rx: 4,
            fill: "#bac3cb",
          }),
          e.jsx("rect", {
            x: 26,
            y: -9,
            width: 8,
            height: 18,
            rx: 2,
            fill: "#95a1ac",
          }),
          e.jsx("circle", { cx: 30, cy: 0, r: 5, fill: "#111b23" }),
          e.jsx("circle", {
            cx: -14,
            cy: -4,
            r: 2.4,
            fill: "#cb5651",
            className: "attack-flash",
          }),
        ],
      }),
      e.jsx("rect", {
        x: 340,
        y: 48,
        width: 44,
        height: 8,
        rx: 2,
        fill: "#5c6873",
      }),
      e.jsx("path", {
        d: "M346 48 V32 a16 16 0 0 1 32 0 V48z",
        fill: "#cb5651",
        className: "attack-flash",
      }),
      e.jsx("path", {
        d: "M354 42 V32 a8 8 0 0 1 8 -8",
        fill: "none",
        stroke: "#d1beaa",
        strokeWidth: 3,
        strokeLinecap: "round",
      }),
      e.jsx("path", {
        d: "M336 20 l-9 -5 M334 34 h-10 M388 20 l9 -5 M390 34 h8",
        stroke: "#ffa79f",
        strokeWidth: 2.5,
        strokeLinecap: "round",
      }),
    ],
  });
}
function ce({ x: i, y: t, hair: s, skin: l }) {
  return e.jsxs("g", {
    children: [
      e.jsx("path", {
        d: `M${i - 28} 240 C${i - 28} ${t + 24} ${i - 14} ${t + 16} ${i} ${t + 16} C${i + 14} ${t + 16} ${i + 28} ${t + 24} ${i + 28} 240z`,
        fill: "#46515b",
      }),
      e.jsx("rect", { x: i - 6, y: t + 8, width: 12, height: 10, fill: l }),
      e.jsx("circle", { cx: i - 17, cy: t + 1, r: 4.5, fill: l }),
      e.jsx("circle", { cx: i + 17, cy: t + 1, r: 4.5, fill: l }),
      e.jsx("circle", { cx: i, cy: t, r: 17, fill: s }),
    ],
  });
}
function Hi() {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#242f38" }),
      e.jsx("rect", {
        x: 104,
        y: 10,
        width: 286,
        height: 164,
        rx: 4,
        fill: "#95a1ac",
      }),
      e.jsx("rect", {
        x: 110,
        y: 16,
        width: 274,
        height: 152,
        fill: "#e3e9ee",
      }),
      e.jsx("rect", {
        x: 180,
        y: 174,
        width: 140,
        height: 6,
        rx: 2,
        fill: "#5c6873",
      }),
      e.jsx("rect", {
        x: 122,
        y: 26,
        width: 250,
        height: 132,
        rx: 4,
        fill: "#e3e9ee",
        stroke: "#bac3cb",
        strokeWidth: 2,
      }),
      e.jsx("rect", {
        x: 122,
        y: 26,
        width: 250,
        height: 14,
        rx: 4,
        fill: "#333e48",
      }),
      e.jsx("circle", { cx: 134, cy: 58, r: 9, fill: "#bac3cb" }),
      e.jsx("rect", {
        x: 150,
        y: 50,
        width: 60,
        height: 5,
        rx: 2.5,
        fill: "#46515b",
      }),
      e.jsx("rect", {
        x: 150,
        y: 60,
        width: 92,
        height: 5,
        rx: 2.5,
        fill: "#ac3a38",
      }),
      e.jsx("ellipse", {
        cx: 196,
        cy: 58,
        rx: 56,
        ry: 15,
        fill: "none",
        stroke: "#cb5651",
        strokeWidth: 3,
      }),
      [0, 1, 2].map((i) =>
        e.jsx(
          "rect",
          {
            x: 134,
            y: 86 + i * 10,
            width: i === 2 ? 110 : 160,
            height: 4,
            rx: 2,
            fill: "#95a1ac",
          },
          i,
        ),
      ),
      e.jsx("rect", {
        x: 134,
        y: 124,
        width: 74,
        height: 18,
        rx: 4,
        fill: "#326e8e",
      }),
      e.jsx("rect", {
        x: 144,
        y: 131,
        width: 54,
        height: 4,
        rx: 2,
        fill: "#cfedff",
      }),
      e.jsx("ellipse", {
        cx: 171,
        cy: 133,
        rx: 48,
        ry: 17,
        fill: "none",
        stroke: "#cb5651",
        strokeWidth: 3,
      }),
      e.jsx(r, {
        x: 330,
        y: 124,
        size: 50,
        anchor: "middle",
        fill: "#cb5651",
        children: "!",
      }),
      e.jsx("path", {
        d: "M14 240 V150 C14 128 30 120 52 120 C74 120 90 128 90 150 V240z",
        fill: "#399661",
      }),
      e.jsx("circle", { cx: 52, cy: 94, r: 22, fill: "#e0ac84" }),
      e.jsx("path", {
        d: "M30 92 C28 64 76 64 74 92 Q70 76 52 76 Q36 78 30 92z",
        fill: "#901e21",
      }),
      e.jsx("circle", { cx: 60, cy: 94, r: 2.4, fill: "#111b23" }),
      e.jsx("circle", { cx: 44, cy: 94, r: 2.4, fill: "#111b23" }),
      e.jsx("path", {
        d: "M46 104 q6 5 12 0",
        fill: "none",
        stroke: "#111b23",
        strokeWidth: 2,
        strokeLinecap: "round",
      }),
      e.jsx("path", {
        d: "M78 140 L108 116",
        stroke: "#399661",
        strokeWidth: 12,
        strokeLinecap: "round",
      }),
      e.jsx("circle", { cx: 110, cy: 114, r: 6, fill: "#e0ac84" }),
      e.jsx("path", {
        d: "M112 112 L140 76",
        stroke: "#e8ba61",
        strokeWidth: 3.5,
        strokeLinecap: "round",
      }),
      e.jsx(ce, { x: 150, y: 206, hair: "#1c1917", skin: "#c68a5b" }),
      e.jsx(ce, { x: 212, y: 210, hair: "#a16207", skin: "#f1c9a5" }),
      e.jsx(ce, { x: 274, y: 206, hair: "#7c2d12", skin: "#e0ac84" }),
      e.jsx(ce, { x: 336, y: 210, hair: "#0f172a", skin: "#8d5524" }),
      e.jsx("path", {
        d: "M354 236 C370 214 376 192 376 172",
        stroke: "#46515b",
        strokeWidth: 9,
        strokeLinecap: "round",
        fill: "none",
      }),
      e.jsx("circle", { cx: 376, cy: 167, r: 7, fill: "#8d5524" }),
    ],
  });
}
function Pi({ x: i, y: t, rotate: s = 0 }) {
  return e.jsxs("g", {
    transform: `translate(${i} ${t}) rotate(${s})`,
    children: [
      e.jsx("path", { d: "M0 -44 V-34", stroke: "#95a1ac", strokeWidth: 3 }),
      e.jsx("circle", {
        cx: 0,
        cy: -46,
        r: 4.5,
        fill: "#cb5651",
        className: "attack-flash",
      }),
      e.jsx("rect", {
        x: -28,
        y: -34,
        width: 56,
        height: 42,
        rx: 8,
        fill: "#95a1ac",
      }),
      e.jsx("rect", {
        x: -21,
        y: -26,
        width: 42,
        height: 22,
        rx: 5,
        fill: "#242f38",
      }),
      e.jsx(q, { x: -10, y: -15, r: 4, stroke: "#e8ba61", width: 2.6 }),
      e.jsx(q, { x: 10, y: -15, r: 4, stroke: "#e8ba61", width: 2.6 }),
      e.jsx("rect", {
        x: -24,
        y: 12,
        width: 48,
        height: 40,
        rx: 6,
        fill: "#5c6873",
      }),
      e.jsx("rect", {
        x: -14,
        y: 20,
        width: 28,
        height: 12,
        rx: 2,
        fill: "#242f38",
      }),
      e.jsx("path", {
        d: "M-24 22 C-40 18 -46 4 -50 -6 M24 22 C40 28 44 44 44 56",
        fill: "none",
        stroke: "#5c6873",
        strokeWidth: 8,
        strokeLinecap: "round",
      }),
    ],
  });
}
function Ei() {
  const i = Array.from({ length: 11 }, (t, s) => s);
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#19232c" }),
      e.jsx("rect", {
        x: 20,
        y: 34,
        width: 196,
        height: 172,
        rx: 12,
        fill: "#bac3cb",
      }),
      e.jsx("path", {
        d: "M20 46 a12 12 0 0 1 12 -12 h172 a12 12 0 0 1 12 12 v16 h-196z",
        fill: "#326e8e",
      }),
      e.jsx("circle", { cx: 66, cy: 104, r: 26, fill: "#95a1ac" }),
      e.jsx("circle", { cx: 66, cy: 96, r: 10, fill: "#46515b" }),
      e.jsx("path", { d: "M48 122 a18 14 0 0 1 36 0z", fill: "#46515b" }),
      e.jsx("rect", {
        x: 104,
        y: 86,
        width: 92,
        height: 9,
        rx: 4.5,
        fill: "#46515b",
      }),
      e.jsx("rect", {
        x: 104,
        y: 104,
        width: 66,
        height: 7,
        rx: 3.5,
        fill: "#95a1ac",
      }),
      e.jsx("rect", {
        x: 104,
        y: 118,
        width: 78,
        height: 7,
        rx: 3.5,
        fill: "#95a1ac",
      }),
      [0, 1, 2].map((t) =>
        e.jsxs(
          "g",
          {
            children: [
              e.jsx("circle", {
                cx: 62 + t * 56,
                cy: 172,
                r: 16,
                fill: "#cb5651",
              }),
              e.jsx(q, {
                x: 62 + t * 56,
                y: 172,
                r: 6,
                stroke: "#e3e9ee",
                width: 3.4,
              }),
            ],
          },
          t,
        ),
      ),
      e.jsx("rect", {
        x: 20,
        y: 34,
        width: 196,
        height: 172,
        rx: 12,
        fill: "#111b23",
        opacity: 0.3,
      }),
      [-26, 26].map((t) =>
        e.jsx(
          "g",
          {
            transform: `rotate(${t} 118 120)`,
            children: i.map((s) =>
              s % 2
                ? e.jsx(
                    "rect",
                    {
                      x: -4 + s * 22,
                      y: 117,
                      width: 26,
                      height: 6,
                      rx: 3,
                      fill: "#bac3cb",
                    },
                    s,
                  )
                : e.jsx(
                    "rect",
                    {
                      x: -6 + s * 22,
                      y: 111,
                      width: 30,
                      height: 18,
                      rx: 9,
                      fill: "none",
                      stroke: "#95a1ac",
                      strokeWidth: 5,
                    },
                    s,
                  ),
            ),
          },
          t,
        ),
      ),
      e.jsx("circle", {
        cx: 118,
        cy: 124,
        r: 40,
        fill: "#19232c",
        opacity: 0.6,
      }),
      e.jsx(J, { x: 118, y: 122, s: 2.6, fill: "#e8ba61", shackle: "#ffe4b4" }),
      e.jsx("rect", {
        x: 240,
        y: 22,
        width: 146,
        height: 104,
        rx: 10,
        fill: "#0d171f",
        stroke: "#cb5651",
        strokeWidth: 3,
      }),
      e.jsx("circle", {
        cx: 264,
        cy: 48,
        r: 13,
        fill: "none",
        stroke: "#ee766f",
        strokeWidth: 3,
      }),
      e.jsx("path", {
        d: "M264 40 V48 L270 52",
        fill: "none",
        stroke: "#ee766f",
        strokeWidth: 2.6,
        strokeLinecap: "round",
        strokeLinejoin: "round",
      }),
      e.jsx(r, {
        x: 284,
        y: 54,
        size: 16,
        fill: "#ee766f",
        children: "LOCKED",
      }),
      e.jsx(r, {
        x: 313,
        y: 100,
        size: 38,
        anchor: "middle",
        fill: "#cb5651",
        children: "30:00",
      }),
      e.jsx("rect", {
        x: 254,
        y: 110,
        width: 118,
        height: 6,
        rx: 3,
        fill: "#392a1a",
      }),
      e.jsx("rect", {
        x: 254,
        y: 110,
        width: 96,
        height: 6,
        rx: 3,
        fill: "#cb5651",
        className: "attack-flash",
      }),
      e.jsx("path", {
        d: "M224 168 l7 4 2 -8 5 7 7 -4 -2 8 8 2 -8 4 4 7 -8 -2 -2 8 -4 -7 -7 4 2 -8 -8 -2 7 -4z",
        fill: "#ffe4b4",
      }),
      e.jsx("path", {
        d: "M262 150 q14 -14 30 -10 M258 192 q16 10 32 4",
        fill: "none",
        stroke: "#5c6873",
        strokeWidth: 3,
        strokeLinecap: "round",
        strokeDasharray: "6 6",
      }),
      e.jsx(Pi, { x: 332, y: 172, rotate: 18 }),
    ],
  });
}
function _i() {
  const i = ["4", "8", "2", "9", "1", "3"];
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#111b23" }),
      e.jsx("rect", { y: 206, width: 400, height: 34, fill: "#242f38" }),
      e.jsx("rect", {
        x: 18,
        y: 22,
        width: 196,
        height: 146,
        rx: 8,
        fill: "#333e48",
      }),
      e.jsx("rect", {
        x: 28,
        y: 32,
        width: 176,
        height: 126,
        rx: 3,
        fill: "#e3e9ee",
      }),
      e.jsx("circle", { cx: 116, cy: 52, r: 11, fill: "#bac3cb" }),
      e.jsx("circle", { cx: 116, cy: 49, r: 4.5, fill: "#5c6873" }),
      e.jsx("path", { d: "M107 61 a9 7 0 0 1 18 0z", fill: "#5c6873" }),
      e.jsx("rect", {
        x: 40,
        y: 72,
        width: 152,
        height: 20,
        rx: 4,
        fill: "#e3e9ee",
        stroke: "#5bb57e",
        strokeWidth: 2,
      }),
      Array.from({ length: 8 }, (t, s) =>
        e.jsx("circle", { cx: 52 + s * 11, cy: 82, r: 3, fill: "#242f38" }, s),
      ),
      e.jsx(Le, { x: 178, y: 81, s: 1 }),
      Array.from({ length: 6 }, (t, s) =>
        e.jsx(
          "rect",
          {
            x: 40 + s * 26,
            y: 104,
            width: 22,
            height: 28,
            rx: 3,
            fill: "#e3e9ee",
            stroke: "#326e8e",
            strokeWidth: 2,
          },
          s,
        ),
      ),
      e.jsx("rect", {
        x: 47,
        y: 112,
        width: 2.5,
        height: 12,
        fill: "#326e8e",
        className: "attack-flash",
      }),
      e.jsx("rect", {
        x: 40,
        y: 140,
        width: 152,
        height: 12,
        rx: 3,
        fill: "#326e8e",
      }),
      e.jsx("path", { d: "M2 168 H230 L220 182 H12z", fill: "#5c6873" }),
      e.jsx("rect", {
        x: 96,
        y: 168,
        width: 40,
        height: 4,
        rx: 2,
        fill: "#46515b",
      }),
      e.jsx("path", {
        d: "M246 96 C232 104 214 112 196 118",
        fill: "none",
        stroke: "#6ca8ca",
        strokeWidth: 2.6,
        strokeDasharray: "6 5",
        className: "attack-flow",
      }),
      e.jsx("rect", {
        x: 250,
        y: 14,
        width: 78,
        height: 150,
        rx: 12,
        fill: "#0d171f",
        stroke: "#46515b",
        strokeWidth: 3,
      }),
      e.jsx("rect", {
        x: 256,
        y: 28,
        width: 66,
        height: 124,
        rx: 4,
        fill: "#00425f",
      }),
      e.jsx("rect", {
        x: 278,
        y: 19,
        width: 22,
        height: 4,
        rx: 2,
        fill: "#333e48",
      }),
      e.jsx("rect", {
        x: 238,
        y: 52,
        width: 102,
        height: 58,
        rx: 8,
        fill: "#e3e9ee",
      }),
      e.jsx(ze, { x: 254, y: 68, s: 0.5 }),
      e.jsx("rect", {
        x: 266,
        y: 62,
        width: 50,
        height: 6,
        rx: 3,
        fill: "#95a1ac",
      }),
      e.jsx(r, {
        x: 289,
        y: 100,
        size: 19,
        anchor: "middle",
        fill: "#326e8e",
        children: i.join(""),
      }),
      e.jsx("rect", {
        x: 270,
        y: 124,
        width: 38,
        height: 14,
        rx: 7,
        fill: "#5bb57e",
      }),
      e.jsx("path", {
        d: "M318 240 C318 200 334 186 360 186 C386 186 400 200 400 240z",
        fill: "#111b23",
      }),
      e.jsx("path", {
        d: "M334 196 C334 158 386 158 386 196 L382 206 H338z",
        fill: "#242f38",
      }),
      e.jsx("ellipse", { cx: 360, cy: 192, rx: 17, ry: 13, fill: "#0d171f" }),
      e.jsx("circle", { cx: 353, cy: 191, r: 2.3, fill: "#ee766f" }),
      e.jsx("circle", { cx: 367, cy: 191, r: 2.3, fill: "#ee766f" }),
      e.jsx("path", {
        d: "M330 214 L300 204",
        stroke: "#242f38",
        strokeWidth: 10,
        strokeLinecap: "round",
      }),
      e.jsxs("g", {
        transform: "translate(276 196) rotate(-8)",
        children: [
          e.jsx("rect", {
            x: -26,
            y: -22,
            width: 52,
            height: 44,
            fill: "#ffe4b4",
          }),
          e.jsx("rect", {
            x: -26,
            y: -22,
            width: 52,
            height: 8,
            fill: "#e8ba61",
          }),
          e.jsx("rect", {
            x: -18,
            y: -6,
            width: 30,
            height: 4,
            rx: 2,
            fill: "#746351",
          }),
          e.jsx("rect", {
            x: -18,
            y: 4,
            width: 22,
            height: 4,
            rx: 2,
            fill: "#746351",
          }),
        ],
      }),
      e.jsx("circle", {
        cx: 276,
        cy: 196,
        r: 30,
        fill: "none",
        stroke: "#cb5651",
        strokeWidth: 5,
      }),
      e.jsx("path", {
        d: "M255 175 L297 217",
        stroke: "#cb5651",
        strokeWidth: 5,
        strokeLinecap: "round",
      }),
    ],
  });
}
function at({ x: i, y: t, ok: s, children: l }) {
  return e.jsxs("g", {
    children: [
      e.jsx("rect", {
        x: i,
        y: t - 16,
        width: 52,
        height: 6,
        rx: 3,
        fill: "#95a1ac",
      }),
      e.jsx("rect", {
        x: i,
        y: t,
        width: 156,
        height: 34,
        rx: 5,
        fill: s ? "#e3e9ee" : "#bac3cb",
        stroke: s ? "#5bb57e" : "#cb5651",
        strokeWidth: 2.5,
      }),
      l,
    ],
  });
}
function Ii() {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#0d171f" }),
      e.jsxs(f, {
        x: 10,
        y: 18,
        w: 180,
        h: 204,
        bar: "#333e48",
        children: [
          e.jsx(at, {
            x: 22,
            y: 60,
            ok: !0,
            children: e.jsx(r, {
              x: 32,
              y: 83,
              size: 17,
              fill: "#111b23",
              children: "Smith",
            }),
          }),
          e.jsx(at, {
            x: 22,
            y: 146,
            children: e.jsx(r, {
              x: 30,
              y: 169,
              size: 15,
              fill: "#ac3a38",
              children: "' OR 1=1; --",
            }),
          }),
        ],
      }),
      e.jsx("path", {
        d: "M180 77 H330",
        fill: "none",
        stroke: "#7ed99f",
        strokeWidth: 3,
        strokeDasharray: "7 6",
        className: "attack-flow",
      }),
      e.jsx("path", {
        d: "M318 69 l10 8 -10 8",
        fill: "none",
        stroke: "#7ed99f",
        strokeWidth: 3,
        strokeLinejoin: "round",
      }),
      e.jsx("path", {
        d: "M180 163 H218",
        fill: "none",
        stroke: "#ee766f",
        strokeWidth: 3,
        strokeDasharray: "7 6",
        className: "attack-flow",
      }),
      e.jsx("rect", {
        x: 222,
        y: 16,
        width: 22,
        height: 204,
        rx: 4,
        fill: "#333e48",
      }),
      e.jsx("rect", {
        x: 222,
        y: 58,
        width: 22,
        height: 38,
        fill: "#5bb57e",
        opacity: 0.35,
      }),
      e.jsx("rect", {
        x: 218,
        y: 56,
        width: 30,
        height: 4,
        rx: 2,
        fill: "#5bb57e",
      }),
      e.jsx("rect", {
        x: 218,
        y: 94,
        width: 30,
        height: 4,
        rx: 2,
        fill: "#5bb57e",
      }),
      e.jsx("rect", {
        x: 216,
        y: 130,
        width: 34,
        height: 66,
        rx: 4,
        fill: "#cb5651",
      }),
      e.jsx(q, { x: 233, y: 163, r: 9, stroke: "#e3e9ee", width: 4.5 }),
      e.jsx("circle", { cx: 258, cy: 36, r: 16, fill: "#5bb57e" }),
      e.jsx(Le, { x: 258, y: 35, s: 1.2, stroke: "#102333" }),
      [
        { x: 196, y: 196, r: 18 },
        { x: 206, y: 214, r: -22 },
        { x: 190, y: 226, r: 30 },
      ].map(({ x: i, y: t, r: s }) =>
        e.jsx(
          "rect",
          {
            x: i - 6,
            y: t - 4,
            width: 12,
            height: 8,
            rx: 1.5,
            fill: "#ee766f",
            transform: `rotate(${s} ${i} ${t})`,
          },
          `${i}-${t}`,
        ),
      ),
      e.jsx("path", {
        d: "M336 48 V176 A28 10 0 0 0 392 176 V48z",
        fill: "#326e8e",
      }),
      e.jsx("ellipse", { cx: 364, cy: 48, rx: 28, ry: 10, fill: "#6ca8ca" }),
      [88, 128].map((i) =>
        e.jsx(
          "path",
          {
            d: `M336 ${i} A28 10 0 0 0 392 ${i}`,
            fill: "none",
            stroke: "#8ecbee",
            strokeWidth: 2.5,
          },
          i,
        ),
      ),
      e.jsx("circle", { cx: 380, cy: 70, r: 3, fill: "#7ed99f" }),
      e.jsx("circle", { cx: 380, cy: 110, r: 3, fill: "#7ed99f" }),
      e.jsx("circle", { cx: 380, cy: 150, r: 3, fill: "#7ed99f" }),
      e.jsx(ze, { x: 364, y: 206, s: 0.85 }),
    ],
  });
}
function k({
  x: i,
  y: t,
  size: s = 8,
  fill: l = "#111b23",
  anchor: a = "start",
  children: c,
}) {
  return e.jsx("text", {
    x: i,
    y: t,
    fontSize: s,
    fill: l,
    fontWeight: 700,
    textAnchor: a,
    fontFamily: "'Courier New', Courier, monospace",
    children: c,
  });
}
function At({ x: i, y: t }) {
  return e.jsx("path", {
    d: `M${i} ${t} l0 18 l5 -5 l4 9 l4 -2 l-4 -9 l7 0z`,
    fill: "#e3e9ee",
    stroke: "#111b23",
    strokeWidth: 1.2,
    strokeLinejoin: "round",
  });
}
function Vt({ x: i, y: t }) {
  return e.jsxs("g", {
    children: [
      e.jsx("rect", {
        x: i,
        y: t,
        width: 32,
        height: 20,
        rx: 2,
        fill: "#242f38",
        stroke: "#46515b",
      }),
      e.jsx("rect", {
        x: i + 3,
        y: t + 3,
        width: 26,
        height: 14,
        fill: "#480004",
      }),
      e.jsx("circle", { cx: i + 16, cy: t + 10, r: 3, fill: "#cb5651" }),
      e.jsx("rect", {
        x: i + 10,
        y: t + 20,
        width: 12,
        height: 3,
        fill: "#46515b",
      }),
    ],
  });
}
function Ht({ x: i, y: t, s = 1 }) {
  return e.jsxs("g", {
    transform: `translate(${i} ${t}) scale(${s})`,
    children: [
      e.jsx("path", {
        d: "M-22 0 q-8 -14 4 -24 q-2 10 8 12 q2 -12 12 -18 q-4 16 8 22 q4 -8 12 -10 q-2 10 4 18z",
        fill: "#ee766f",
      }),
      e.jsx("path", {
        d: "M-12 0 q-2 -8 6 -12 q0 6 6 6 q2 -6 8 -8 q-2 8 4 14z",
        fill: "#e8ba61",
      }),
    ],
  });
}
function Pt({ x: i, y: t, w: s, h: l, units: a }) {
  const c = (l - 12) / a;
  return e.jsxs("g", {
    children: [
      e.jsx("rect", {
        x: i,
        y: t,
        width: s,
        height: l,
        rx: 5,
        fill: "#242f38",
        stroke: "#cb5651",
        strokeWidth: 2,
        className: "attack-flash-stroke",
      }),
      Array.from({ length: a }, (h, o) =>
        e.jsxs(
          "g",
          {
            children: [
              e.jsx("rect", {
                x: i + 7,
                y: t + 7 + o * c,
                width: s - 14,
                height: c - 6,
                rx: 2,
                fill: "#333e48",
              }),
              e.jsx("circle", {
                cx: i + s - 14,
                cy: t + 7 + o * c + (c - 6) / 2,
                r: 3,
                fill: "#cb5651",
              }),
              e.jsx("rect", {
                x: i + 12,
                y: t + 7 + o * c + (c - 6) / 2 - 1.5,
                width: s / 3,
                height: 3,
                rx: 1.5,
                fill: "#242f38",
              }),
            ],
          },
          o,
        ),
      ),
    ],
  });
}
function Et({ x: i, y: t, s }) {
  return e.jsxs("g", {
    transform: `translate(${i} ${t}) scale(${s})`,
    children: [
      e.jsx("path", {
        d: "M-74 156 C-70 102 -42 84 0 84 C42 84 70 102 74 156z",
        fill: "#333e48",
      }),
      e.jsx("path", { d: "M0 84 v72", stroke: "#242f38", strokeWidth: 2 }),
      e.jsx("path", {
        d: "M-46 44 C-46 -14 46 -14 46 44 C46 76 30 92 0 92 C-30 92 -46 76 -46 44z",
        fill: "#46515b",
      }),
      e.jsx("ellipse", { cx: 0, cy: 44, rx: 30, ry: 34, fill: "#111b23" }),
    ],
  });
}
function he({ x: i, y: t, r: s, name: l, num: a, skin: c, hair: h }) {
  return e.jsxs("g", {
    transform: `translate(${i} ${t}) rotate(${s})`,
    children: [
      e.jsx("rect", {
        x: 0,
        y: 0,
        width: 116,
        height: 28,
        rx: 3,
        fill: "#e3e9ee",
        stroke: "#bac3cb",
      }),
      e.jsx("rect", {
        x: 0,
        y: 0,
        width: 10,
        height: 28,
        rx: 2,
        fill: "#901e21",
      }),
      e.jsx("rect", {
        x: 14,
        y: 4,
        width: 20,
        height: 20,
        rx: 1.5,
        fill: "#bac3cb",
      }),
      e.jsx("path", { d: "M16 24 q8 -9 16 0z", fill: "#46515b" }),
      e.jsx("circle", { cx: 24, cy: 12, r: 4.5, fill: c }),
      e.jsx("path", {
        d: "M19.5 11.5 a4.5 4.5 0 0 1 9 0 q-4.5 -3 -9 0z",
        fill: h,
      }),
      e.jsx(r, { x: 40, y: 12, size: 7.5, fill: "#111b23", children: l }),
      e.jsx(k, { x: 40, y: 23, size: 8, fill: "#901e21", children: a }),
    ],
  });
}
function qi() {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#0d171f" }),
      e.jsxs(f, {
        x: 12,
        y: 14,
        w: 222,
        h: 184,
        bar: "#0d171f",
        children: [
          e.jsx("rect", {
            x: 13,
            y: 30,
            width: 220,
            height: 22,
            fill: "#0d171f",
          }),
          e.jsx("rect", {
            x: 13,
            y: 52,
            width: 220,
            height: 4,
            fill: "#326e8e",
          }),
          e.jsx(r, {
            x: 22,
            y: 45,
            size: 10,
            fill: "#e3e9ee",
            children: "Digital Identity Office",
          }),
          e.jsx(r, {
            x: 22,
            y: 76,
            size: 13,
            fill: "#0d171f",
            children: "Apply for a passport",
          }),
          e.jsx(r, {
            x: 22,
            y: 94,
            size: 8,
            fill: "#0d171f",
            children: "First name",
          }),
          e.jsx("rect", {
            x: 22,
            y: 98,
            width: 110,
            height: 18,
            fill: "#e3e9ee",
            stroke: "#0d171f",
            strokeWidth: 1.5,
          }),
          e.jsx(r, {
            x: 27,
            y: 110.5,
            size: 8.5,
            weight: 400,
            fill: "#0d171f",
            children: "Sam",
          }),
          e.jsx(r, {
            x: 22,
            y: 130,
            size: 8,
            fill: "#0d171f",
            children: "Surname",
          }),
          e.jsx("rect", {
            x: 22,
            y: 134,
            width: 200,
            height: 24,
            fill: "#e3e9ee",
            stroke: "#cb5651",
            strokeWidth: 3,
          }),
          e.jsx(k, {
            x: 29,
            y: 150,
            size: 11.5,
            fill: "#ac3a38",
            children: "' OR 1=1; --",
          }),
          e.jsx("path", {
            d: "M116 138 V154",
            stroke: "#0d171f",
            strokeWidth: 1.2,
            className: "attack-flash",
          }),
          e.jsx("rect", {
            x: 22,
            y: 168,
            width: 70,
            height: 20,
            fill: "#137a47",
          }),
          e.jsx("rect", {
            x: 22,
            y: 188,
            width: 70,
            height: 2,
            fill: "#102333",
          }),
          e.jsx(r, {
            x: 57,
            y: 181.5,
            size: 9,
            anchor: "middle",
            fill: "#e3e9ee",
            children: "Continue",
          }),
          e.jsx(At, { x: 78, y: 178 }),
        ],
      }),
      e.jsx("rect", {
        x: 12,
        y: 206,
        width: 222,
        height: 26,
        rx: 4,
        fill: "#480004",
      }),
      e.jsx(k, {
        x: 123,
        y: 223,
        size: 10,
        fill: "#ffa79f",
        anchor: "middle",
        children: "1,204,377 records",
      }),
      e.jsx("path", {
        d: "M234 146 C252 146 248 56 262 56",
        fill: "none",
        stroke: "#cb5651",
        strokeWidth: 2,
        strokeDasharray: "5 4",
        className: "attack-flow",
      }),
      e.jsx("path", { d: "M258 50 l8 6 l-8 6z", fill: "#cb5651" }),
      e.jsx("rect", { x: 272, y: 18, width: 100, height: 62, fill: "#333e48" }),
      e.jsx("ellipse", { cx: 322, cy: 80, rx: 50, ry: 12, fill: "#333e48" }),
      e.jsx("path", {
        d: "M272 46 a50 12 0 0 0 100 0",
        fill: "none",
        stroke: "#242f38",
        strokeWidth: 2,
      }),
      e.jsx("ellipse", {
        cx: 322,
        cy: 18,
        rx: 50,
        ry: 12,
        fill: "#46515b",
        stroke: "#cb5651",
        strokeWidth: 2,
        className: "attack-flash-stroke",
      }),
      e.jsx(r, {
        x: 322,
        y: 70,
        size: 9,
        anchor: "middle",
        fill: "#bac3cb",
        children: "CITIZENS",
      }),
      e.jsx(he, {
        x: 250,
        y: 100,
        r: -3,
        name: "A. Khan",
        num: "P 538214907",
        skin: "#c68642",
        hair: "#1c1917",
      }),
      e.jsx(he, {
        x: 278,
        y: 132,
        r: 3,
        name: "R. Jones",
        num: "P 771045283",
        skin: "#f1c27d",
        hair: "#a16207",
      }),
      e.jsx(he, {
        x: 246,
        y: 164,
        r: -2,
        name: "M. Silva",
        num: "P 402996115",
        skin: "#8d5524",
        hair: "#1c1917",
      }),
      e.jsx(he, {
        x: 276,
        y: 197,
        r: 3,
        name: "L. Okafor",
        num: "P 650318742",
        skin: "#5c3a21",
        hair: "#0c0a09",
      }),
    ],
  });
}
function Di() {
  const i = Array.from({ length: 12 }, (t, s) => (s * Math.PI) / 6);
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#0d171f" }),
      e.jsx("rect", { x: 186, y: 0, width: 214, height: 240, fill: "#19232c" }),
      e.jsx("rect", { x: 196, y: 10, width: 84, height: 88, fill: "#00425f" }),
      e.jsx("circle", {
        cx: 214,
        cy: 26,
        r: 6,
        fill: "#f8e4cf",
        opacity: 0.85,
      }),
      e.jsx("path", {
        d: "M196 98 V80 h8 v-6 h3 v6 h14 v-8 h3 v8 h40 v-6 h3 v6 h13 V98z",
        fill: "#0d171f",
      }),
      e.jsx("path", {
        d: "M242 98 V44 h-3 v-10 h3 l8 -22 l8 22 h3 v10 h-3 V98z",
        fill: "#0d171f",
      }),
      e.jsx("circle", { cx: 250, cy: 48, r: 6, fill: "#ffe4b4" }),
      e.jsx("path", {
        d: "M250 48 V44 M250 48 h3",
        stroke: "#0d171f",
        strokeWidth: 1.2,
      }),
      e.jsx("rect", {
        x: 194,
        y: 8,
        width: 88,
        height: 92,
        fill: "none",
        stroke: "#46515b",
        strokeWidth: 4,
      }),
      e.jsx("circle", {
        cx: 344,
        cy: 38,
        r: 27,
        fill: "#e3e9ee",
        stroke: "#333e48",
        strokeWidth: 4,
      }),
      e.jsx("path", {
        d: "M344 38 L325 27 A22 22 0 0 1 344 16z",
        fill: "#cb5651",
        opacity: 0.75,
        className: "attack-flash",
      }),
      i.map((t) =>
        e.jsx(
          "path",
          {
            d: `M${344 + 19 * Math.sin(t)} ${38 - 19 * Math.cos(t)} L${344 + 23 * Math.sin(t)} ${38 - 23 * Math.cos(t)}`,
            stroke: "#111b23",
            strokeWidth: 2,
          },
          t,
        ),
      ),
      e.jsx("path", {
        d: "M344 38 L343 25 M344 38 L333 20",
        stroke: "#111b23",
        strokeWidth: 2.5,
        strokeLinecap: "round",
      }),
      e.jsx("circle", { cx: 344, cy: 38, r: 2.5, fill: "#ac3a38" }),
      e.jsx("path", {
        d: "M8 240 C12 186 40 168 82 168 C124 168 152 186 156 240z",
        fill: "#333e48",
      }),
      e.jsx("path", { d: "M82 168 v72", stroke: "#242f38", strokeWidth: 2 }),
      e.jsx("path", {
        d: "M36 128 C36 70 128 70 128 128 C128 160 112 176 82 176 C52 176 36 160 36 128z",
        fill: "#46515b",
      }),
      e.jsx("ellipse", { cx: 82, cy: 128, rx: 30, ry: 34, fill: "#111b23" }),
      e.jsx("path", {
        d: "M66 152 q16 10 32 0",
        fill: "none",
        stroke: "#333e48",
        strokeWidth: 2,
      }),
      e.jsx("path", {
        d: "M68 168 L74 192 M96 168 L90 192",
        stroke: "#326e8e",
        strokeWidth: 2.5,
      }),
      e.jsxs("g", {
        transform: "rotate(-6 82 210)",
        children: [
          e.jsx("rect", {
            x: 52,
            y: 190,
            width: 60,
            height: 40,
            rx: 3,
            fill: "#e3e9ee",
            stroke: "#95a1ac",
          }),
          e.jsx("rect", {
            x: 52,
            y: 190,
            width: 60,
            height: 11,
            rx: 2,
            fill: "#326e8e",
          }),
          e.jsx(r, {
            x: 82,
            y: 198.5,
            size: 7,
            anchor: "middle",
            fill: "#e3e9ee",
            children: "MINISTRY",
          }),
          e.jsx("rect", {
            x: 56,
            y: 205,
            width: 14,
            height: 18,
            fill: "#bac3cb",
          }),
          e.jsx("circle", { cx: 63, cy: 211, r: 4, fill: "#46515b" }),
          e.jsx("path", { d: "M57 223 q6 -8 12 0z", fill: "#46515b" }),
          e.jsx("rect", {
            x: 74,
            y: 207,
            width: 32,
            height: 3,
            rx: 1.5,
            fill: "#333e48",
          }),
          e.jsx("rect", {
            x: 74,
            y: 214,
            width: 26,
            height: 3,
            rx: 1.5,
            fill: "#95a1ac",
          }),
          e.jsx("rect", {
            x: 74,
            y: 220,
            width: 30,
            height: 3,
            rx: 1.5,
            fill: "#95a1ac",
          }),
        ],
      }),
      e.jsx("rect", {
        x: 106,
        y: 98,
        width: 16,
        height: 30,
        rx: 3,
        fill: "#111b23",
        stroke: "#5c6873",
        transform: "rotate(14 114 113)",
      }),
      e.jsx("path", {
        d: "M10 12 h166 a8 8 0 0 1 8 8 v36 a8 8 0 0 1 -8 8 h-64 l-10 14 l-2 -14 h-90 a8 8 0 0 1 -8 -8 v-36 a8 8 0 0 1 8 -8z",
        fill: "#e3e9ee",
      }),
      e.jsx(r, {
        x: 93,
        y: 32,
        size: 9.5,
        anchor: "middle",
        children: "I'm the Minister's secretary",
      }),
      e.jsx(r, {
        x: 93,
        y: 51,
        size: 11,
        anchor: "middle",
        fill: "#ac3a38",
        children: "Change it NOW!",
      }),
      e.jsx("path", {
        d: "M126 108 q12 -10 24 0 t24 0 t24 0 t24 0",
        fill: "none",
        stroke: "#cb5651",
        strokeWidth: 2,
        strokeDasharray: "4 4",
        className: "attack-flow",
      }),
      e.jsx("path", {
        d: "M210 240 V170 a28 28 0 0 1 56 0 V240z",
        fill: "#46515b",
      }),
      e.jsx("path", { d: "M232 144 l6 14 l6 -14z", fill: "#bac3cb" }),
      e.jsx("circle", { cx: 238, cy: 128, r: 18, fill: "#e0ac69" }),
      e.jsx("path", {
        d: "M220 126 a18 18 0 0 1 36 -6 q-12 -2 -18 -8 q-8 8 -18 14z",
        fill: "#901e21",
      }),
      e.jsx("path", {
        d: "M220 128 a18 18 0 0 1 36 0",
        fill: "none",
        stroke: "#bac3cb",
        strokeWidth: 3,
      }),
      e.jsx("rect", {
        x: 252,
        y: 124,
        width: 7,
        height: 11,
        rx: 2,
        fill: "#bac3cb",
      }),
      e.jsx("path", {
        d: "M256 134 q2 10 -10 12",
        fill: "none",
        stroke: "#bac3cb",
        strokeWidth: 2,
      }),
      e.jsx("path", {
        d: "M258 186 L294 196",
        stroke: "#46515b",
        strokeWidth: 10,
        strokeLinecap: "round",
      }),
      e.jsx("rect", {
        x: 186,
        y: 198,
        width: 214,
        height: 10,
        fill: "#46515b",
      }),
      e.jsx("rect", {
        x: 282,
        y: 74,
        width: 112,
        height: 90,
        rx: 4,
        fill: "#111b23",
      }),
      e.jsx("rect", { x: 287, y: 79, width: 102, height: 80, fill: "#bac3cb" }),
      e.jsx("rect", { x: 287, y: 79, width: 102, height: 12, fill: "#0d171f" }),
      e.jsx(r, {
        x: 292,
        y: 88,
        size: 6.5,
        fill: "#e3e9ee",
        children: "Passport record",
      }),
      e.jsx(r, { x: 292, y: 102, size: 6, fill: "#46515b", children: "Name" }),
      e.jsx("rect", {
        x: 316,
        y: 95,
        width: 68,
        height: 10,
        rx: 1.5,
        fill: "#e3e9ee",
        stroke: "#95a1ac",
      }),
      e.jsx(r, {
        x: 319,
        y: 102.5,
        size: 6.5,
        weight: 400,
        fill: "#111b23",
        children: "D. Hale",
      }),
      e.jsx(r, { x: 292, y: 116, size: 6, fill: "#46515b", children: "No." }),
      e.jsx("rect", {
        x: 316,
        y: 109,
        width: 68,
        height: 10,
        rx: 1.5,
        fill: "#e3e9ee",
        stroke: "#95a1ac",
      }),
      e.jsx(k, {
        x: 319,
        y: 116.5,
        size: 6.5,
        fill: "#111b23",
        children: "P 913562047",
      }),
      e.jsx("rect", {
        x: 292,
        y: 128,
        width: 92,
        height: 24,
        rx: 3,
        fill: "#cb5651",
        className: "attack-flash",
      }),
      e.jsx(r, {
        x: 338,
        y: 143.5,
        size: 8.5,
        anchor: "middle",
        fill: "#e3e9ee",
        children: "CHANGE RECORD",
      }),
      e.jsx("rect", { x: 331, y: 164, width: 14, height: 26, fill: "#333e48" }),
      e.jsx("rect", {
        x: 315,
        y: 188,
        width: 46,
        height: 10,
        rx: 2,
        fill: "#333e48",
      }),
      e.jsx("rect", {
        x: 278,
        y: 190,
        width: 30,
        height: 8,
        rx: 2,
        fill: "#242f38",
      }),
    ],
  });
}
function Bi({ cx: i, skin: t, hair: s, top: l }) {
  return e.jsxs("g", {
    children: [
      e.jsx("path", {
        d: `M${i - 18} 240 V214 a18 18 0 0 1 36 0 V240z`,
        fill: l,
      }),
      e.jsx("circle", { cx: i, cy: 186, r: 10, fill: t }),
      e.jsx("path", {
        d: `M${i - 10} 185 a10 10 0 0 1 20 0 q-10 -5 -20 0z`,
        fill: s,
      }),
      e.jsx("path", { d: `M${i - 16} 230 l4 -26 h24 l4 26z`, fill: "#95a1ac" }),
      e.jsx("path", { d: `M${i - 13} 228 l3 -21 h20 l3 21z`, fill: "#326e8e" }),
      e.jsx("circle", {
        cx: i,
        cy: 217,
        r: 5,
        fill: "none",
        stroke: "#cfedff",
        strokeWidth: 1.8,
        strokeDasharray: "20 12",
      }),
      e.jsx("rect", {
        x: i - 22,
        y: 230,
        width: 44,
        height: 4,
        rx: 1.5,
        fill: "#bac3cb",
      }),
    ],
  });
}
function Ri() {
  const i = Array.from({ length: 9 }, (s, l) => ({
      x: 14 + (l % 3) * 42,
      y: 64 + Math.floor(l / 3) * 30,
    })),
    t = [
      [32, "#f1c27d", "#a16207", "#137a47"],
      [80, "#8d5524", "#1c1917", "#54697c"],
      [128, "#e0ac69", "#57534e", "#ac3a38"],
      [176, "#5c3a21", "#0c0a09", "#ac3a38"],
      [224, "#ffdbac", "#d97706", "#333e48"],
    ];
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#0d171f" }),
      e.jsx("path", {
        d: "M140 64 L296 112 V180 L140 150z",
        fill: "#cb5651",
        opacity: 0.12,
      }),
      i.map(({ x: s, y: l }, a) =>
        e.jsx(
          "path",
          {
            d: `M${s + 34} ${l + 10} C220 ${l + 10} 230 ${118 + a * 6} 296 ${118 + a * 6}`,
            fill: "none",
            stroke: "#ee766f",
            strokeWidth: 2,
            strokeDasharray: "4 5",
            opacity: 0.85,
            className: "attack-flow",
          },
          `flow-${a}`,
        ),
      ),
      t.map(([s], l) =>
        e.jsx(
          "path",
          {
            d: `M${s} 174 C${s + 10} 160 250 ${176 + l * 6} 296 ${176 + l * 6}`,
            fill: "none",
            stroke: "#6ca8ca",
            strokeWidth: 1.4,
            strokeDasharray: "2 4",
            opacity: 0.8,
          },
          `queue-${s}`,
        ),
      ),
      i.map(({ x: s, y: l }, a) => e.jsx(Vt, { x: s, y: l }, a)),
      e.jsx("rect", {
        x: 14,
        y: 8,
        width: 46,
        height: 48,
        rx: 4,
        fill: "#e3e9ee",
      }),
      e.jsx("path", {
        d: "M14 22 V12 a4 4 0 0 1 4 -4 h38 a4 4 0 0 1 4 4 V22z",
        fill: "#cb5651",
      }),
      e.jsx(r, {
        x: 37,
        y: 19,
        size: 8.5,
        anchor: "middle",
        fill: "#e3e9ee",
        children: "JAN",
      }),
      e.jsx(r, {
        x: 37,
        y: 48,
        size: 22,
        anchor: "middle",
        fill: "#111b23",
        children: "31",
      }),
      e.jsx("rect", {
        x: 68,
        y: 14,
        width: 82,
        height: 34,
        rx: 4,
        fill: "#0d171f",
        stroke: "#cb5651",
        strokeWidth: 2,
        className: "attack-flash-stroke",
      }),
      e.jsx(k, {
        x: 109,
        y: 38,
        size: 20,
        fill: "#ee766f",
        anchor: "middle",
        children: "23:41",
      }),
      e.jsxs(f, {
        x: 226,
        y: 8,
        w: 166,
        h: 54,
        bar: "#0d171f",
        children: [
          e.jsx("rect", {
            x: 227,
            y: 24,
            width: 164,
            height: 3,
            fill: "#326e8e",
          }),
          e.jsx(r, {
            x: 234,
            y: 39,
            size: 8.5,
            fill: "#0d171f",
            children: "File your tax return",
          }),
          e.jsx("rect", {
            x: 232,
            y: 44,
            width: 154,
            height: 13,
            fill: "#bac3cb",
          }),
          e.jsx(r, {
            x: 309,
            y: 53.5,
            size: 7.5,
            anchor: "middle",
            fill: "#ac3a38",
            children: "Service unavailable",
          }),
        ],
      }),
      e.jsx(Ht, { x: 334, y: 96, s: 1.1 }),
      e.jsx(Pt, { x: 296, y: 96, w: 76, h: 126, units: 5 }),
      e.jsx("path", {
        d: "M380 110 q6 8 0 16 q-6 8 0 16 M388 120 q5 7 0 14",
        fill: "none",
        stroke: "#ee766f",
        strokeWidth: 2,
      }),
      t.map(([s, l, a, c]) =>
        e.jsx(Bi, { cx: s, skin: l, hair: a, top: c }, s),
      ),
    ],
  });
}
function Ae({ x: i, y: t, r: s, item: l }) {
  return e.jsxs("g", {
    transform: `translate(${i} ${t}) rotate(${s})`,
    opacity: 0.85,
    children: [
      e.jsx("path", {
        d: "M8 -8 q-4 -12 6 -18 h-2",
        fill: "none",
        stroke: "#95a1ac",
        strokeWidth: 2.5,
      }),
      e.jsx("path", {
        d: "M-8 -14 l8 -10 l6 4 l6 -4 l8 10 l-5 4 v10 h-18 v-10z",
        fill: l,
      }),
      e.jsx("path", {
        d: "M-22 -8 h44 l-6 24 h-32z",
        fill: "#bac3cb",
        stroke: "#5c6873",
        strokeWidth: 1.5,
      }),
      e.jsx("path", {
        d: "M-12 -4 l2 16 M0 -4 v16 M12 -4 l-2 16 M-19 4 h38",
        stroke: "#95a1ac",
        strokeWidth: 1.2,
      }),
    ],
  });
}
function Fi() {
  const i = Array.from({ length: 15 }, (t, s) => ({
    x: 10 + (s % 3) * 40,
    y: 14 + Math.floor(s / 3) * 44,
  }));
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#0d171f" }),
      i.map(({ x: t, y: s }, l) =>
        e.jsx(
          "path",
          {
            d: `M${t + 34} ${s + 10} C150 ${s + 10} 130 ${150 + l * 4} 168 ${150 + l * 4}`,
            fill: "none",
            stroke: "#ee766f",
            strokeWidth: 1.5,
            strokeDasharray: "3 6",
            opacity: 0.8,
            className: "attack-flow",
          },
          `flow-${l}`,
        ),
      ),
      i.map(({ x: t, y: s }, l) => e.jsx(Vt, { x: t, y: s }, l)),
      e.jsx(Ht, { x: 196, y: 136, s: 1 }),
      e.jsx(Pt, { x: 168, y: 136, w: 56, h: 96, units: 4 }),
      e.jsxs(f, {
        x: 234,
        y: 8,
        w: 158,
        h: 160,
        bar: "#0d171f",
        children: [
          e.jsx("rect", {
            x: 235,
            y: 24,
            width: 156,
            height: 20,
            fill: "#e3e9ee",
          }),
          e.jsx(r, {
            x: 242,
            y: 38,
            size: 10,
            fill: "#0d171f",
            children: "THREADLINE",
          }),
          e.jsx("path", {
            d: "M362 30 h14 l-2 9 h-10z",
            fill: "none",
            stroke: "#0d171f",
            strokeWidth: 1.5,
          }),
          e.jsx("circle", { cx: 378, cy: 30, r: 5, fill: "#ee766f" }),
          e.jsx(r, {
            x: 378,
            y: 32.5,
            size: 6.5,
            anchor: "middle",
            fill: "#e3e9ee",
            children: "3",
          }),
          e.jsx("rect", {
            x: 235,
            y: 44,
            width: 156,
            height: 26,
            fill: "#0d171f",
          }),
          e.jsxs(r, {
            x: 313,
            y: 62,
            size: 12,
            anchor: "middle",
            fill: "#e3e9ee",
            children: [
              "BLACK FRIDAY ",
              e.jsx("tspan", { fill: "#ee766f", children: "-70%" }),
            ],
          }),
          e.jsxs("g", {
            opacity: 0.25,
            children: [
              e.jsx("path", {
                d: "M246 84 l10 -6 h12 l10 6 l-4 8 l-4 -2 v24 h-16 v-24 l-4 2z",
                fill: "#ee766f",
              }),
              e.jsx("path", {
                d: "M302 78 h12 l6 14 l-4 1 l6 23 h-28 l6 -23 l-4 -1z",
                fill: "#e8ba61",
              }),
              e.jsx("path", {
                d: "M344 78 h18 l4 40 h-10 l-3 -26 l-3 26 h-10z",
                fill: "#6ca8ca",
              }),
            ],
          }),
          e.jsx("rect", {
            x: 235,
            y: 70,
            width: 156,
            height: 97,
            fill: "#e3e9ee",
            opacity: 0.6,
          }),
          e.jsx("path", {
            d: "M313 92 a5 5 0 1 1 5 5 v4 l26 14 h-62 l26 -14",
            fill: "none",
            stroke: "#0d171f",
            strokeWidth: 2.5,
            strokeLinejoin: "round",
          }),
          e.jsx(r, {
            x: 313,
            y: 140,
            size: 18,
            anchor: "middle",
            fill: "#ac3a38",
            children: "503",
          }),
          e.jsx(r, {
            x: 313,
            y: 155,
            size: 8,
            anchor: "middle",
            weight: 400,
            fill: "#333e48",
            children: "Service unavailable",
          }),
        ],
      }),
      e.jsx(Ae, { x: 266, y: 210, r: -14, item: "#ee766f" }),
      e.jsx(Ae, { x: 318, y: 214, r: 10, item: "#e8ba61" }),
      e.jsx(Ae, { x: 366, y: 208, r: -6, item: "#6ca8ca" }),
      e.jsx("rect", {
        x: 234,
        y: 226,
        width: 158,
        height: 4,
        rx: 2,
        fill: "#333e48",
      }),
    ],
  });
}
function Oi({ cx: i, cy: t }) {
  return e.jsxs("g", {
    children: [
      e.jsx("path", {
        d: `M${i} ${t - 18} V${t - 28}`,
        stroke: "#5c6873",
        strokeWidth: 2,
      }),
      e.jsx("circle", {
        cx: i,
        cy: t - 30,
        r: 3.5,
        fill: "#cb5651",
        className: "attack-flash",
      }),
      e.jsx("rect", {
        x: i - 26,
        y: t - 6,
        width: 5,
        height: 12,
        rx: 1.5,
        fill: "#46515b",
      }),
      e.jsx("rect", {
        x: i + 21,
        y: t - 6,
        width: 5,
        height: 12,
        rx: 1.5,
        fill: "#46515b",
      }),
      e.jsx("rect", {
        x: i - 22,
        y: t - 18,
        width: 44,
        height: 34,
        rx: 8,
        fill: "#333e48",
        stroke: "#5c6873",
        strokeWidth: 1.5,
      }),
      e.jsx("rect", {
        x: i - 17,
        y: t - 12,
        width: 34,
        height: 13,
        rx: 4,
        fill: "#111b23",
      }),
      e.jsx("circle", { cx: i - 8, cy: t - 5.5, r: 3.5, fill: "#cb5651" }),
      e.jsx("circle", { cx: i + 8, cy: t - 5.5, r: 3.5, fill: "#cb5651" }),
      e.jsx("path", {
        d: `M${i - 10} ${t + 8} H${i + 10} M${i - 5} ${t + 5} V${t + 11} M${i} ${t + 5} V${t + 11} M${i + 5} ${t + 5} V${t + 11}`,
        stroke: "#95a1ac",
        strokeWidth: 1.5,
      }),
    ],
  });
}
function ct({ x: i, y: t, text: s, hit: l }) {
  const a = s.length * 4.6 + 14;
  return e.jsxs("g", {
    children: [
      e.jsx("rect", {
        x: i,
        y: t - 8,
        width: a,
        height: 14,
        rx: 7,
        fill: l ? "#006034" : "#242f38",
        stroke: l ? "#7ed99f" : "#ee766f",
        strokeWidth: 1.2,
      }),
      e.jsx(k, {
        x: i + a / 2,
        y: t + 2,
        size: 7.6,
        fill: l ? "#a8ffc6" : "#d1beaa",
        anchor: "middle",
        children: s,
      }),
    ],
  });
}
function Qi() {
  const i = [44, 112, 180],
    t = [
      ["tom88@mail.com:qwerty1", 76, 22],
      ["jo.b@mail.com:Liverpool1", 98, 52],
      ["sara@mail.com:Password!", 76, 82],
      ["ben.t@mail.com:ilovecats", 100, 112],
      ["kim22@mail.com:123456", 78, 142],
    ];
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#0d171f" }),
      i.map((s) =>
        e.jsx(
          "path",
          {
            d: `M66 ${s} C150 ${s} 170 90 236 90`,
            fill: "none",
            stroke: "#cb5651",
            strokeWidth: 1.6,
            strokeDasharray: "4 5",
            opacity: 0.8,
            className: "attack-flow",
          },
          `flow-${s}`,
        ),
      ),
      i.map((s) => e.jsx(Oi, { cx: 34, cy: s }, s)),
      t.map(([s, l, a]) => e.jsx(ct, { x: l, y: a, text: s }, s)),
      e.jsx(ct, { x: 86, y: 172, text: "amy.k@mail.com:Amy2001", hit: !0 }),
      e.jsx("path", {
        d: "M196 178 C214 186 220 190 236 190",
        fill: "none",
        stroke: "#7ed99f",
        strokeWidth: 1.6,
        strokeDasharray: "4 4",
        className: "attack-flow",
      }),
      e.jsx("rect", {
        x: 76,
        y: 196,
        width: 148,
        height: 34,
        rx: 4,
        fill: "#480004",
        stroke: "#cb5651",
        strokeWidth: 2,
        className: "attack-flash-stroke",
      }),
      e.jsx(k, {
        x: 150,
        y: 218,
        size: 12,
        fill: "#ffa79f",
        anchor: "middle",
        children: "2,481,903 tries",
      }),
      e.jsxs(f, {
        x: 236,
        y: 8,
        w: 156,
        h: 128,
        bar: "#0d171f",
        children: [
          e.jsx(r, {
            x: 314,
            y: 42,
            size: 11,
            anchor: "middle",
            fill: "#0d171f",
            children: "THREADLINE",
          }),
          e.jsx(r, {
            x: 314,
            y: 55,
            size: 7.5,
            anchor: "middle",
            weight: 400,
            fill: "#46515b",
            children: "Sign in",
          }),
          e.jsx("rect", {
            x: 248,
            y: 62,
            width: 132,
            height: 16,
            rx: 3,
            fill: "#e3e9ee",
            stroke: "#95a1ac",
          }),
          e.jsx(r, {
            x: 254,
            y: 73.5,
            size: 7.5,
            weight: 400,
            fill: "#333e48",
            children: "amy.k@mail.com",
          }),
          e.jsx("rect", {
            x: 248,
            y: 83,
            width: 132,
            height: 16,
            rx: 3,
            fill: "#e3e9ee",
            stroke: "#cb5651",
            strokeWidth: 1.5,
          }),
          e.jsx(r, {
            x: 254,
            y: 95,
            size: 9,
            fill: "#333e48",
            children: "• • • • • • • •",
          }),
          e.jsx("rect", {
            x: 284,
            y: 106,
            width: 60,
            height: 18,
            rx: 3,
            fill: "#0d171f",
          }),
          e.jsx(r, {
            x: 314,
            y: 118.5,
            size: 8,
            anchor: "middle",
            fill: "#e3e9ee",
            children: "Sign in",
          }),
        ],
      }),
      e.jsx("rect", {
        x: 236,
        y: 144,
        width: 156,
        height: 88,
        rx: 5,
        fill: "#242f38",
        stroke: "#cb5651",
        strokeWidth: 2,
        className: "attack-flash-stroke",
      }),
      e.jsx(r, {
        x: 246,
        y: 161,
        size: 9,
        fill: "#e3e9ee",
        children: "My account",
      }),
      e.jsxs("g", {
        transform: "translate(374 156)",
        children: [
          e.jsx("path", { d: "M-12 8 C-12 -12 12 -12 12 8z", fill: "#46515b" }),
          e.jsx("ellipse", { cx: 0, cy: 2, rx: 7, ry: 7, fill: "#0d171f" }),
          e.jsx("circle", { cx: -3, cy: 1, r: 1.4, fill: "#cb5651" }),
          e.jsx("circle", { cx: 3, cy: 1, r: 1.4, fill: "#cb5651" }),
        ],
      }),
      e.jsx("rect", {
        x: 246,
        y: 170,
        width: 66,
        height: 42,
        rx: 4,
        fill: "#54697c",
      }),
      e.jsx("rect", {
        x: 252,
        y: 177,
        width: 11,
        height: 8,
        rx: 1.5,
        fill: "#e8ba61",
      }),
      e.jsx(r, {
        x: 252,
        y: 201,
        size: 7,
        fill: "#e3e9ee",
        children: "•••• 4417",
      }),
      e.jsx(r, {
        x: 252,
        y: 208,
        size: 5,
        weight: 400,
        fill: "#adc5da",
        children: "A KHAN",
      }),
      e.jsx("path", {
        d: "M322 176 a5 5 0 0 1 10 0 c0 5 -5 9 -5 9 s-5 -4 -5 -9z",
        fill: "#cb5651",
      }),
      e.jsx("circle", { cx: 327, cy: 176, r: 1.8, fill: "#242f38" }),
      e.jsx(r, {
        x: 336,
        y: 181,
        size: 7,
        weight: 400,
        fill: "#bac3cb",
        children: "12 Elm Rd",
      }),
      e.jsx(r, {
        x: 322,
        y: 196,
        size: 7,
        weight: 400,
        fill: "#bac3cb",
        children: "Leeds",
      }),
      e.jsx("rect", {
        x: 322,
        y: 202,
        width: 60,
        height: 12,
        rx: 3,
        fill: "#ee766f",
      }),
      e.jsx(r, {
        x: 352,
        y: 211,
        size: 6.5,
        anchor: "middle",
        fill: "#e3e9ee",
        children: "Buy now",
      }),
    ],
  });
}
function Ve({ x: i, y: t }) {
  return e.jsxs("g", {
    children: [
      e.jsx("rect", {
        x: i - 10,
        y: t - 7,
        width: 20,
        height: 14,
        rx: 2,
        fill: "#e8ba61",
      }),
      e.jsx("rect", {
        x: i - 10,
        y: t - 3,
        width: 20,
        height: 3,
        fill: "#901e21",
      }),
      e.jsx("rect", {
        x: i - 7,
        y: t + 2,
        width: 8,
        height: 2,
        rx: 1,
        fill: "#901e21",
      }),
    ],
  });
}
function Ui() {
  const i = [
    [182, 14],
    [212, 92],
    [300, 100],
    [330, 12],
    [264, 22],
  ];
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#0d171f" }),
      i.map(([t, s]) =>
        e.jsx(
          "circle",
          { cx: t, cy: s, r: 1.2, fill: "#bac3cb", opacity: 0.7 },
          `${t}-${s}`,
        ),
      ),
      e.jsx("path", {
        d: "M0 240 V150 C0 124 22 112 46 112 C66 112 82 124 86 140 L92 240z",
        fill: "#cb5651",
      }),
      e.jsx("circle", { cx: 44, cy: 84, r: 22, fill: "#c68642" }),
      e.jsx("path", {
        d: "M22 84 C18 52 66 50 68 76 C58 70 44 68 30 74 C26 80 24 86 22 92z",
        fill: "#111b23",
      }),
      e.jsx("circle", { cx: 56, cy: 86, r: 2, fill: "#111b23" }),
      e.jsx("path", {
        d: "M50 164 C70 168 84 172 96 176",
        stroke: "#cb5651",
        strokeWidth: 14,
        strokeLinecap: "round",
      }),
      e.jsx("rect", {
        x: 88,
        y: 34,
        width: 76,
        height: 150,
        rx: 10,
        fill: "#111b23",
        stroke: "#46515b",
        strokeWidth: 2,
      }),
      e.jsx("rect", {
        x: 93,
        y: 44,
        width: 66,
        height: 132,
        rx: 3,
        fill: "#e3e9ee",
      }),
      e.jsx("rect", { x: 93, y: 44, width: 66, height: 14, fill: "#bac3cb" }),
      e.jsxs("g", {
        transform: "translate(98 47)",
        children: [
          e.jsx("rect", {
            x: 0,
            y: 4,
            width: 7,
            height: 5,
            rx: 1,
            fill: "#cb5651",
          }),
          e.jsx("path", {
            d: "M1.5 4 v-2 a2.5 2.5 0 0 1 5 -1",
            fill: "none",
            stroke: "#cb5651",
            strokeWidth: 1.2,
          }),
        ],
      }),
      e.jsx(k, {
        x: 108,
        y: 54,
        size: 7,
        fill: "#ac3a38",
        children: "http://",
      }),
      e.jsx(r, {
        x: 126,
        y: 72,
        size: 8,
        anchor: "middle",
        fill: "#0d171f",
        children: "THREADLINE",
      }),
      e.jsx(r, {
        x: 126,
        y: 83,
        size: 6.5,
        anchor: "middle",
        weight: 400,
        fill: "#46515b",
        children: "Checkout",
      }),
      e.jsx("rect", {
        x: 97,
        y: 90,
        width: 58,
        height: 38,
        rx: 4,
        fill: "#242f38",
      }),
      e.jsx("rect", {
        x: 101,
        y: 94,
        width: 9,
        height: 7,
        rx: 1.5,
        fill: "#e8ba61",
      }),
      e.jsx(k, {
        x: 101,
        y: 111,
        size: 7,
        fill: "#e3e9ee",
        children: "4000 1234",
      }),
      e.jsx(k, {
        x: 101,
        y: 120,
        size: 7,
        fill: "#e3e9ee",
        children: "5678 9010",
      }),
      e.jsx(r, {
        x: 151,
        y: 101,
        size: 5.5,
        anchor: "end",
        fill: "#bac3cb",
        children: "09/28",
      }),
      e.jsx("rect", {
        x: 97,
        y: 134,
        width: 58,
        height: 6,
        rx: 2,
        fill: "#bac3cb",
      }),
      e.jsx("rect", {
        x: 97,
        y: 144,
        width: 40,
        height: 6,
        rx: 2,
        fill: "#bac3cb",
      }),
      e.jsx("rect", {
        x: 97,
        y: 156,
        width: 58,
        height: 16,
        rx: 3,
        fill: "#0d171f",
      }),
      e.jsx(r, {
        x: 126,
        y: 167,
        size: 7.5,
        anchor: "middle",
        fill: "#e3e9ee",
        children: "Pay £86",
      }),
      e.jsx("circle", { cx: 94, cy: 176, r: 9, fill: "#c68642" }),
      e.jsx("path", {
        d: "M164 90 C200 90 204 52 236 52 S318 54 348 54",
        fill: "none",
        stroke: "#ee766f",
        strokeWidth: 2.2,
        strokeDasharray: "5 5",
        className: "attack-flow",
      }),
      e.jsx("rect", {
        x: 224,
        y: 44,
        width: 26,
        height: 16,
        rx: 3,
        fill: "#333e48",
        stroke: "#5c6873",
      }),
      e.jsx("path", {
        d: "M230 44 V36 M244 44 V36",
        stroke: "#5c6873",
        strokeWidth: 2,
        strokeLinecap: "round",
      }),
      e.jsx("circle", { cx: 231, cy: 52, r: 1.6, fill: "#5bb57e" }),
      e.jsx("circle", { cx: 237, cy: 52, r: 1.6, fill: "#5bb57e" }),
      e.jsx(Ve, { x: 188, y: 74 }),
      e.jsx(Ve, { x: 276, y: 53 }),
      e.jsx(Ve, { x: 318, y: 54 }),
      e.jsx("rect", {
        x: 348,
        y: 20,
        width: 44,
        height: 74,
        rx: 4,
        fill: "#242f38",
        stroke: "#46515b",
      }),
      e.jsx("rect", {
        x: 348,
        y: 20,
        width: 44,
        height: 8,
        rx: 3,
        fill: "#ee766f",
      }),
      [34, 50, 66].map((t) =>
        e.jsxs(
          "g",
          {
            children: [
              e.jsx("rect", {
                x: 354,
                y: t,
                width: 32,
                height: 11,
                rx: 2,
                fill: "#333e48",
              }),
              e.jsx("circle", { cx: 380, cy: t + 5.5, r: 2, fill: "#5bb57e" }),
            ],
          },
          t,
        ),
      ),
      e.jsx("path", {
        d: "M237 60 V112",
        stroke: "#7ed99f",
        strokeWidth: 1.6,
        strokeDasharray: "3 3",
        className: "attack-flow",
      }),
      e.jsx("circle", {
        cx: 237,
        cy: 60,
        r: 4,
        fill: "none",
        stroke: "#7ed99f",
        strokeWidth: 1.6,
        className: "attack-flash-stroke",
      }),
      e.jsx(Et, { x: 354, y: 120, s: 0.62 }),
      e.jsx("rect", { x: 308, y: 210, width: 92, height: 30, fill: "#333e48" }),
      e.jsx("path", {
        d: "M326 182 L304 200",
        stroke: "#333e48",
        strokeWidth: 9,
        strokeLinecap: "round",
      }),
      e.jsx("path", { d: "M190 112 h138 v86 h-138z", fill: "#242f38" }),
      e.jsx("rect", {
        x: 196,
        y: 118,
        width: 126,
        height: 74,
        fill: "#0d171f",
      }),
      e.jsx("circle", {
        cx: 205,
        cy: 128,
        r: 3,
        fill: "#cb5651",
        className: "attack-flash",
      }),
      e.jsx(k, {
        x: 212,
        y: 131,
        size: 8,
        fill: "#7ed99f",
        children: "CAPTURED",
      }),
      e.jsx("path", { d: "M196 136 H322", stroke: "#006034" }),
      e.jsx(k, { x: 202, y: 149, size: 7, fill: "#a8ffc6", children: "card:" }),
      e.jsx(k, {
        x: 202,
        y: 161,
        size: 9,
        fill: "#ffe4b4",
        children: "4000 1234 5678 9010",
      }),
      e.jsx(k, { x: 202, y: 176, size: 7, fill: "#a8ffc6", children: "exp:" }),
      e.jsx(k, { x: 226, y: 176, size: 9, fill: "#ffe4b4", children: "09/28" }),
      e.jsx("path", { d: "M180 198 h158 l10 12 h-178z", fill: "#333e48" }),
      e.jsx("rect", {
        x: 160,
        y: 212,
        width: 240,
        height: 28,
        fill: "#242f38",
      }),
      e.jsx("rect", { x: 160, y: 210, width: 240, height: 4, fill: "#46515b" }),
    ],
  });
}
function He({ x: i, y: t, k: s }) {
  return e.jsxs("g", {
    children: [
      e.jsx("rect", {
        x: i - 8,
        y: t - 8,
        width: 16,
        height: 16,
        rx: 3,
        fill: "#e3e9ee",
        stroke: "#95a1ac",
        strokeWidth: 1.2,
      }),
      e.jsx("rect", {
        x: i - 8,
        y: t + 5,
        width: 16,
        height: 3,
        rx: 1.5,
        fill: "#bac3cb",
      }),
      e.jsx(k, { x: i, y: t + 3.5, size: 10, anchor: "middle", children: s }),
    ],
  });
}
function ht({ x: i, y: t }) {
  return e.jsxs("g", {
    children: [
      e.jsx("rect", {
        x: i - 12,
        y: t - 9,
        width: 24,
        height: 18,
        rx: 2,
        fill: "#bac3cb",
      }),
      e.jsx("rect", {
        x: i - 12,
        y: t - 9,
        width: 24,
        height: 5,
        rx: 1.5,
        fill: "#0d171f",
      }),
      e.jsx("rect", {
        x: i - 9,
        y: t - 1,
        width: 18,
        height: 2,
        rx: 1,
        fill: "#95a1ac",
      }),
      e.jsx("rect", {
        x: i - 9,
        y: t + 3,
        width: 12,
        height: 2,
        rx: 1,
        fill: "#95a1ac",
      }),
    ],
  });
}
function Zi() {
  const i = [
    [276, 16],
    [300, 104],
    [392, 112],
    [270, 70],
    [394, 18],
  ];
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#0d171f" }),
      i.map(([t, s]) =>
        e.jsx(
          "circle",
          { cx: t, cy: s, r: 1.2, fill: "#bac3cb", opacity: 0.7 },
          `${t}-${s}`,
        ),
      ),
      e.jsx("rect", { x: 0, y: 0, width: 258, height: 240, fill: "#242f38" }),
      e.jsx("circle", {
        cx: 352,
        cy: 66,
        r: 38,
        fill: "#175675",
        stroke: "#6ca8ca",
        strokeWidth: 2,
      }),
      e.jsx("ellipse", {
        cx: 352,
        cy: 66,
        rx: 16,
        ry: 38,
        fill: "none",
        stroke: "#6ca8ca",
        strokeWidth: 1.5,
      }),
      e.jsx("path", {
        d: "M352 28 V104 M314 66 H390 M319 47 H385 M319 85 H385",
        stroke: "#6ca8ca",
        strokeWidth: 1.5,
      }),
      e.jsx("rect", {
        x: 326,
        y: 118,
        width: 56,
        height: 104,
        rx: 4,
        fill: "#242f38",
        stroke: "#cb5651",
        strokeWidth: 2,
        className: "attack-flash-stroke",
      }),
      [128, 150, 172, 194].map((t) =>
        e.jsxs(
          "g",
          {
            children: [
              e.jsx("rect", {
                x: 333,
                y: t,
                width: 42,
                height: 15,
                rx: 2,
                fill: "#333e48",
              }),
              e.jsx("circle", {
                cx: 367,
                cy: t + 7.5,
                r: 2.5,
                fill: "#cb5651",
              }),
              e.jsx("rect", {
                x: 338,
                y: t + 6,
                width: 18,
                height: 3,
                rx: 1.5,
                fill: "#242f38",
              }),
            ],
          },
          t,
        ),
      ),
      e.jsx("path", {
        d: "M234 121 C270 121 280 150 326 150",
        fill: "none",
        stroke: "#cb5651",
        strokeWidth: 2,
        strokeDasharray: "5 4",
        className: "attack-flow",
      }),
      e.jsx("path", {
        d: "M206 200 C250 200 270 180 326 180",
        fill: "none",
        stroke: "#cb5651",
        strokeWidth: 2,
        strokeDasharray: "5 4",
        className: "attack-flow",
      }),
      e.jsx(ht, { x: 276, y: 135 }),
      e.jsx(ht, { x: 306, y: 147 }),
      e.jsx("path", {
        d: "M0 240 V170 C0 148 16 138 36 138 C56 138 66 150 68 168 L72 240z",
        fill: "#137a47",
      }),
      e.jsx("circle", { cx: 34, cy: 110, r: 20, fill: "#e0ac69" }),
      e.jsx("path", {
        d: "M14 112 C10 82 58 80 56 104 C46 98 34 96 22 100 C18 106 16 112 16 120z",
        fill: "#46515b",
      }),
      e.jsx("circle", { cx: 46, cy: 112, r: 2, fill: "#111b23" }),
      e.jsx("rect", {
        x: 70,
        y: 112,
        width: 34,
        height: 84,
        rx: 3,
        fill: "#333e48",
        stroke: "#46515b",
      }),
      e.jsx("path", {
        d: "M76 160 h22 M76 166 h22 M76 172 h22",
        stroke: "#242f38",
        strokeWidth: 2,
      }),
      e.jsx("circle", { cx: 96, cy: 120, r: 2, fill: "#5bb57e" }),
      e.jsx("rect", { x: 76, y: 132, width: 12, height: 4, fill: "#111b23" }),
      e.jsx("path", {
        d: "M82 138 L76 150 M82 138 L96 150",
        stroke: "#ee766f",
        strokeWidth: 1.5,
      }),
      e.jsxs("g", {
        transform: "rotate(-4 86 162)",
        children: [
          e.jsx("rect", {
            x: 68,
            y: 148,
            width: 36,
            height: 26,
            rx: 2,
            fill: "#e3e9ee",
            stroke: "#95a1ac",
          }),
          e.jsx("rect", {
            x: 68,
            y: 148,
            width: 36,
            height: 9,
            rx: 1.5,
            fill: "#ee766f",
          }),
          e.jsx(r, {
            x: 86,
            y: 155,
            size: 6,
            anchor: "middle",
            fill: "#e3e9ee",
            children: "EXPO",
          }),
          e.jsx(r, {
            x: 86,
            y: 168,
            size: 8,
            anchor: "middle",
            fill: "#111b23",
            children: "2026",
          }),
        ],
      }),
      e.jsx("rect", {
        x: 70,
        y: 128,
        width: 14,
        height: 11,
        rx: 2,
        fill: "#326e8e",
      }),
      e.jsx("path", {
        d: "M44 162 L70 138",
        stroke: "#137a47",
        strokeWidth: 10,
        strokeLinecap: "round",
      }),
      e.jsx("circle", { cx: 72, cy: 135, r: 6, fill: "#e0ac69" }),
      e.jsx("rect", {
        x: 108,
        y: 26,
        width: 136,
        height: 118,
        rx: 4,
        fill: "#111b23",
      }),
      e.jsx("rect", {
        x: 113,
        y: 31,
        width: 126,
        height: 104,
        fill: "#bac3cb",
      }),
      e.jsx("rect", { x: 113, y: 31, width: 126, height: 13, fill: "#0d171f" }),
      e.jsx("rect", { x: 113, y: 44, width: 126, height: 2, fill: "#326e8e" }),
      e.jsx(r, {
        x: 118,
        y: 40.5,
        size: 7,
        fill: "#e3e9ee",
        children: "Benefits claim",
      }),
      e.jsx(r, { x: 118, y: 58, size: 6, fill: "#46515b", children: "Name" }),
      e.jsx("rect", {
        x: 146,
        y: 50.5,
        width: 88,
        height: 11,
        rx: 1.5,
        fill: "#e3e9ee",
        stroke: "#95a1ac",
      }),
      e.jsx(r, {
        x: 149,
        y: 58.5,
        size: 6.5,
        weight: 400,
        children: "J. Patel",
      }),
      e.jsx(r, { x: 118, y: 73, size: 6, fill: "#46515b", children: "NI no." }),
      e.jsx("rect", {
        x: 146,
        y: 65.5,
        width: 88,
        height: 11,
        rx: 1.5,
        fill: "#e3e9ee",
        stroke: "#95a1ac",
      }),
      e.jsx(k, { x: 149, y: 73.5, size: 6.5, children: "QQ 12 34 56 C" }),
      e.jsx(r, { x: 118, y: 88, size: 6, fill: "#46515b", children: "Bank" }),
      e.jsx("rect", {
        x: 146,
        y: 80.5,
        width: 88,
        height: 11,
        rx: 1.5,
        fill: "#e3e9ee",
        stroke: "#95a1ac",
      }),
      e.jsx(k, { x: 149, y: 88.5, size: 6.5, children: "40-12-77 81229173" }),
      e.jsx(r, { x: 118, y: 103, size: 6, fill: "#46515b", children: "Notes" }),
      e.jsx("rect", {
        x: 146,
        y: 95.5,
        width: 88,
        height: 11,
        rx: 1.5,
        fill: "#e3e9ee",
        stroke: "#95a1ac",
      }),
      e.jsx(r, {
        x: 149,
        y: 103.5,
        size: 6.5,
        weight: 400,
        children: "GP: asthma, back pain",
      }),
      e.jsx("rect", {
        x: 180,
        y: 113,
        width: 54,
        height: 17,
        rx: 3,
        fill: "#cb5651",
        className: "attack-flash",
      }),
      e.jsx("path", {
        d: "M185 121.5 q8 -7 16 0 q-8 7 -16 0z",
        fill: "#e3e9ee",
      }),
      e.jsx("circle", { cx: 193, cy: 121.5, r: 2.6, fill: "#111b23" }),
      e.jsx(r, {
        x: 218,
        y: 124.5,
        size: 7,
        anchor: "middle",
        fill: "#e3e9ee",
        children: "REC",
      }),
      e.jsx("rect", { x: 168, y: 144, width: 16, height: 42, fill: "#333e48" }),
      e.jsx("rect", {
        x: 150,
        y: 184,
        width: 52,
        height: 12,
        rx: 2,
        fill: "#333e48",
      }),
      e.jsx("rect", { x: 0, y: 196, width: 258, height: 14, fill: "#5c6873" }),
      e.jsx("rect", { x: 0, y: 210, width: 258, height: 30, fill: "#333e48" }),
      e.jsx("rect", {
        x: 102,
        y: 199,
        width: 104,
        height: 9,
        rx: 2,
        fill: "#111b23",
      }),
      e.jsx("path", {
        d: "M106 203.5 h96",
        stroke: "#46515b",
        strokeWidth: 3,
        strokeDasharray: "5 2",
      }),
      e.jsx(He, { x: 236, y: 196, k: "p" }),
      e.jsx(He, { x: 263, y: 188, k: "a" }),
      e.jsx(He, { x: 292, y: 182, k: "s" }),
    ],
  });
}
function ot({ cx: i, skin: t, cap: s }) {
  return e.jsxs("g", {
    children: [
      e.jsx("path", {
        d: `M${i - 30} 240 V172 a30 30 0 0 1 60 0 V240z`,
        fill: "#242f38",
      }),
      e.jsx("path", {
        d: `M${i - 26} 240 V174 a26 24 0 0 1 52 0 V240z`,
        fill: "#a8ffc6",
      }),
      e.jsx("path", { d: `M${i} 152 V240`, stroke: "#399661", strokeWidth: 2 }),
      e.jsx("rect", {
        x: i - 26,
        y: 198,
        width: 52,
        height: 5,
        fill: "#bac3cb",
      }),
      e.jsx("rect", {
        x: i - 26,
        y: 216,
        width: 52,
        height: 5,
        fill: "#bac3cb",
      }),
      e.jsx("circle", { cx: i, cy: 128, r: 17, fill: t }),
      e.jsx("path", { d: `M${i - 18} 126 a18 18 0 0 1 36 0z`, fill: s }),
    ],
  });
}
function ee({ x: i, y: t, w: s, led: l }) {
  return e.jsxs("g", {
    children: [
      e.jsx("rect", {
        x: i,
        y: t,
        width: s,
        height: 16,
        rx: 2,
        fill: "#333e48",
      }),
      e.jsx("rect", {
        x: i + 5,
        y: t + 6.5,
        width: s / 3,
        height: 3,
        rx: 1.5,
        fill: "#242f38",
      }),
      e.jsx("circle", { cx: i + s - 8, cy: t + 8, r: 2.5, fill: l }),
    ],
  });
}
function Yi() {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#0d171f" }),
      e.jsx("rect", { x: 0, y: 192, width: 400, height: 48, fill: "#111b23" }),
      e.jsx("path", {
        d: "M0 210 H400 M80 192 L60 240 M200 192 V240 M320 192 L340 240",
        stroke: "#242f38",
      }),
      [10, 46].map((i) =>
        e.jsxs(
          "g",
          {
            opacity: 0.6,
            children: [
              e.jsx("rect", {
                x: i,
                y: 52,
                width: 32,
                height: 140,
                rx: 2,
                fill: "#111b23",
                stroke: "#242f38",
              }),
              [60, 78, 96, 114, 132, 150, 168].map((t) =>
                e.jsxs(
                  "g",
                  {
                    children: [
                      e.jsx("rect", {
                        x: i + 4,
                        y: t,
                        width: 24,
                        height: 13,
                        rx: 1.5,
                        fill: "#242f38",
                      }),
                      e.jsx("circle", {
                        cx: i + 23,
                        cy: t + 6.5,
                        r: 1.6,
                        fill: "#5bb57e",
                      }),
                    ],
                  },
                  t,
                ),
              ),
            ],
          },
          i,
        ),
      ),
      e.jsx("rect", {
        x: 318,
        y: 14,
        width: 72,
        height: 30,
        rx: 4,
        fill: "#0d171f",
        stroke: "#cb5651",
        strokeWidth: 2,
        className: "attack-flash-stroke",
      }),
      e.jsx(k, {
        x: 354,
        y: 35,
        size: 17,
        fill: "#ee766f",
        anchor: "middle",
        children: "04:00",
      }),
      e.jsx("rect", {
        x: 344,
        y: 98,
        width: 26,
        height: 20,
        rx: 2,
        fill: "#111b23",
        stroke: "#46515b",
      }),
      e.jsx("rect", { x: 346, y: 100, width: 10, height: 7, fill: "#00425f" }),
      e.jsx("rect", { x: 358, y: 100, width: 10, height: 7, fill: "#00425f" }),
      e.jsx("rect", { x: 346, y: 109, width: 10, height: 7, fill: "#00425f" }),
      e.jsx("rect", { x: 358, y: 109, width: 10, height: 7, fill: "#00425f" }),
      e.jsx("path", {
        d: "M368 140 V128 a12 12 0 0 1 24 0 V140z",
        fill: "#00425f",
      }),
      e.jsx("circle", { cx: 380, cy: 112, r: 9, fill: "#8d5524" }),
      e.jsx("path", {
        d: "M371 110 a9 9 0 0 1 18 0 h2 v-2 h-20z",
        fill: "#111b23",
      }),
      e.jsx("rect", { x: 336, y: 130, width: 64, height: 8, fill: "#46515b" }),
      e.jsx("rect", { x: 340, y: 138, width: 60, height: 42, fill: "#333e48" }),
      e.jsx("rect", {
        x: 360,
        y: 146,
        width: 34,
        height: 9,
        rx: 2,
        fill: "#326e8e",
      }),
      e.jsx(r, {
        x: 377,
        y: 153,
        size: 5.5,
        anchor: "middle",
        fill: "#e3e9ee",
        children: "SECURITY",
      }),
      e.jsx("rect", {
        x: 124,
        y: 12,
        width: 124,
        height: 28,
        rx: 3,
        fill: "#bac3cb",
      }),
      e.jsx(r, {
        x: 186,
        y: 24,
        size: 8.5,
        anchor: "middle",
        fill: "#111b23",
        children: "PASSPORT PHOTO",
      }),
      e.jsx(r, {
        x: 186,
        y: 35,
        size: 8.5,
        anchor: "middle",
        fill: "#ac3a38",
        children: "BACKUPS",
      }),
      e.jsx("rect", {
        x: 146,
        y: 44,
        width: 80,
        height: 152,
        rx: 3,
        fill: "#242f38",
        stroke: "#46515b",
        strokeWidth: 2,
      }),
      e.jsx("path", {
        d: "M226 46 L246 54 V186 L226 194z",
        fill: "#333e48",
        stroke: "#46515b",
      }),
      e.jsx("path", {
        d: "M230 60 V180 M236 62 V178 M242 64 V176",
        stroke: "#242f38",
        strokeWidth: 2,
      }),
      e.jsx(ee, { x: 153, y: 52, w: 66, led: "#5bb57e" }),
      e.jsx(ee, { x: 153, y: 72, w: 66, led: "#5bb57e" }),
      e.jsx("rect", { x: 153, y: 92, width: 66, height: 16, fill: "#0d171f" }),
      e.jsx(ee, { x: 153, y: 130, w: 66, led: "#5bb57e" }),
      e.jsx(ee, { x: 153, y: 150, w: 66, led: "#5bb57e" }),
      e.jsx(ee, { x: 153, y: 170, w: 66, led: "#5bb57e" }),
      e.jsxs("g", {
        transform: "rotate(-4 220 102)",
        children: [
          e.jsx("rect", {
            x: 176,
            y: 92,
            width: 92,
            height: 20,
            rx: 2,
            fill: "#46515b",
            stroke: "#cb5651",
            strokeWidth: 2,
            className: "attack-flash-stroke",
          }),
          e.jsx("rect", {
            x: 182,
            y: 99,
            width: 32,
            height: 6,
            rx: 2,
            fill: "#242f38",
          }),
          e.jsx("circle", { cx: 258, cy: 102, r: 2.5, fill: "#e8ba61" }),
          e.jsx("circle", { cx: 250, cy: 102, r: 2.5, fill: "#e8ba61" }),
        ],
      }),
      e.jsx(ot, { cx: 100, skin: "#f1c27d", cap: "#111b23" }),
      e.jsx("path", {
        d: "M118 160 L148 116",
        stroke: "#a8ffc6",
        strokeWidth: 10,
        strokeLinecap: "round",
      }),
      e.jsx("circle", { cx: 150, cy: 113, r: 5.5, fill: "#f1c27d" }),
      e.jsx("path", {
        d: "M150 112 L156 104",
        stroke: "#cb5651",
        strokeWidth: 4,
        strokeLinecap: "round",
      }),
      e.jsx("path", {
        d: "M156 104 L160 99",
        stroke: "#bac3cb",
        strokeWidth: 1.5,
      }),
      e.jsx("circle", { cx: 161, cy: 98, r: 2, fill: "#95a1ac" }),
      e.jsx(ot, { cx: 300, skin: "#c68642", cap: "#901e21" }),
      e.jsx("path", {
        d: "M282 160 L268 110",
        stroke: "#a8ffc6",
        strokeWidth: 10,
        strokeLinecap: "round",
      }),
      e.jsx("circle", { cx: 267, cy: 106, r: 5.5, fill: "#c68642" }),
      e.jsxs("g", {
        transform: "rotate(8 330 168)",
        children: [
          e.jsx("rect", {
            x: 314,
            y: 146,
            width: 32,
            height: 42,
            rx: 2,
            fill: "#ac3a38",
          }),
          e.jsx("rect", {
            x: 318,
            y: 152,
            width: 24,
            height: 32,
            fill: "#e3e9ee",
          }),
          e.jsx("rect", {
            x: 324,
            y: 143,
            width: 12,
            height: 6,
            rx: 1.5,
            fill: "#95a1ac",
          }),
          e.jsx("path", {
            d: "M321 160 h18 M321 167 h18 M321 174 h12",
            stroke: "#95a1ac",
            strokeWidth: 1.5,
          }),
          e.jsx("path", {
            d: "M335 175 l2 3 l5 -7",
            fill: "none",
            stroke: "#399661",
            strokeWidth: 1.8,
          }),
        ],
      }),
      e.jsx("circle", { cx: 318, cy: 170, r: 5.5, fill: "#c68642" }),
    ],
  });
}
function Gi() {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#0d171f" }),
      e.jsxs(f, {
        x: 10,
        y: 10,
        w: 206,
        h: 220,
        bar: "#002538",
        children: [
          e.jsx("rect", {
            x: 11,
            y: 26,
            width: 204,
            height: 14,
            fill: "#bac3cb",
          }),
          e.jsx(r, {
            x: 18,
            y: 36,
            size: 7.5,
            fill: "#002538",
            children: "Finance inbox",
          }),
          e.jsx("rect", {
            x: 11,
            y: 40,
            width: 204,
            height: 18,
            fill: "#d1beaa",
          }),
          e.jsx("circle", { cx: 18, cy: 49, r: 2.5, fill: "#326e8e" }),
          e.jsx(r, {
            x: 25,
            y: 52,
            size: 7,
            fill: "#111b23",
            children: "Bluestitch Denim",
          }),
          e.jsx(r, {
            x: 208,
            y: 52,
            size: 6.5,
            anchor: "end",
            weight: 400,
            fill: "#46515b",
            children: "Bank details changed",
          }),
          e.jsx("rect", {
            x: 18,
            y: 63,
            width: 60,
            height: 4,
            rx: 2,
            fill: "#bac3cb",
          }),
          e.jsx("rect", {
            x: 110,
            y: 63,
            width: 98,
            height: 4,
            rx: 2,
            fill: "#bac3cb",
          }),
          e.jsx("rect", {
            x: 18,
            y: 75,
            width: 52,
            height: 4,
            rx: 2,
            fill: "#bac3cb",
          }),
          e.jsx("rect", {
            x: 110,
            y: 75,
            width: 86,
            height: 4,
            rx: 2,
            fill: "#bac3cb",
          }),
          e.jsx("path", { d: "M11 86 H215", stroke: "#bac3cb" }),
          e.jsx(r, {
            x: 18,
            y: 101,
            size: 6.5,
            weight: 400,
            fill: "#46515b",
            children: "From",
          }),
          e.jsxs(k, {
            x: 40,
            y: 101,
            size: 7,
            children: [
              "accounts@b",
              e.jsx("tspan", { fill: "#cb5651", children: "1" }),
              "uestitch.co.uk",
            ],
          }),
          e.jsx(r, {
            x: 18,
            y: 121,
            size: 9,
            fill: "#111b23",
            children: "Our bank details have changed.",
          }),
          e.jsx(r, {
            x: 18,
            y: 136,
            size: 7.5,
            weight: 400,
            fill: "#333e48",
            children: "Please approve this month’s invoice:",
          }),
          e.jsx("rect", {
            x: 18,
            y: 144,
            width: 190,
            height: 36,
            rx: 3,
            fill: "#e3e9ee",
            stroke: "#ffa79f",
          }),
          e.jsx(r, {
            x: 113,
            y: 169,
            size: 20,
            anchor: "middle",
            fill: "#ac3a38",
            children: "£4,000,000",
          }),
          e.jsx("rect", {
            x: 18,
            y: 190,
            width: 110,
            height: 22,
            rx: 3,
            fill: "#326e8e",
          }),
          e.jsx(r, {
            x: 73,
            y: 204.5,
            size: 8,
            anchor: "middle",
            fill: "#e3e9ee",
            children: "Log in to approve",
          }),
          e.jsx(At, { x: 112, y: 200 }),
        ],
      }),
      e.jsx("path", {
        d: "M130 201 C178 201 196 108 226 108",
        fill: "none",
        stroke: "#cb5651",
        strokeWidth: 2,
        strokeDasharray: "5 4",
        className: "attack-flow",
      }),
      e.jsxs(f, {
        x: 228,
        y: 10,
        w: 164,
        h: 146,
        bar: "#242f38",
        children: [
          e.jsx("rect", {
            x: 234,
            y: 30,
            width: 152,
            height: 15,
            rx: 7.5,
            fill: "#bac3cb",
            stroke: "#cb5651",
            strokeWidth: 1.5,
            className: "attack-flash-stroke",
          }),
          e.jsxs("g", {
            transform: "translate(240 33)",
            children: [
              e.jsx("rect", {
                x: 0,
                y: 4,
                width: 7,
                height: 5,
                rx: 1,
                fill: "#399661",
              }),
              e.jsx("path", {
                d: "M1.5 4 v-2 a2.5 2.5 0 0 1 5 -1",
                fill: "none",
                stroke: "#399661",
                strokeWidth: 1.2,
              }),
            ],
          }),
          e.jsxs(k, {
            x: 252,
            y: 40.5,
            size: 7.5,
            fill: "#333e48",
            children: [
              "b",
              e.jsx("tspan", { fill: "#cb5651", children: "1" }),
              "uestitch.co.uk/pay",
            ],
          }),
          e.jsx(r, {
            x: 310,
            y: 64,
            size: 11,
            anchor: "middle",
            fill: "#00425f",
            children: "BLUESTITCH",
          }),
          e.jsx(r, {
            x: 310,
            y: 75,
            size: 7,
            anchor: "middle",
            weight: 400,
            fill: "#46515b",
            children: "Supplier portal",
          }),
          e.jsx("rect", {
            x: 242,
            y: 82,
            width: 136,
            height: 15,
            rx: 3,
            fill: "#e3e9ee",
            stroke: "#95a1ac",
          }),
          e.jsx(r, {
            x: 248,
            y: 92.5,
            size: 7,
            weight: 400,
            fill: "#333e48",
            children: "finance@threadline.com",
          }),
          e.jsx("rect", {
            x: 242,
            y: 102,
            width: 136,
            height: 15,
            rx: 3,
            fill: "#e3e9ee",
            stroke: "#cb5651",
            strokeWidth: 1.5,
          }),
          e.jsx(r, {
            x: 248,
            y: 113.5,
            size: 9,
            fill: "#333e48",
            children: "• • • • • • • • •",
          }),
          e.jsx("rect", {
            x: 258,
            y: 125,
            width: 104,
            height: 20,
            rx: 3,
            fill: "#00425f",
          }),
          e.jsx(r, {
            x: 310,
            y: 138.5,
            size: 8,
            anchor: "middle",
            fill: "#e3e9ee",
            children: "Approve invoice",
          }),
        ],
      }),
      e.jsx("path", {
        d: "M262 156 C262 186 290 204 316 204",
        fill: "none",
        stroke: "#cb5651",
        strokeWidth: 2,
        strokeDasharray: "5 4",
        className: "attack-flow",
      }),
      e.jsx("rect", {
        x: 226,
        y: 170,
        width: 72,
        height: 16,
        rx: 8,
        fill: "#242f38",
        stroke: "#ee766f",
      }),
      e.jsx(k, {
        x: 262,
        y: 181,
        size: 8,
        fill: "#d1beaa",
        anchor: "middle",
        children: "Denim2026!",
      }),
      e.jsx(Et, { x: 358, y: 164, s: 0.48 }),
      e.jsxs("g", {
        transform: "translate(330 214)",
        children: [
          e.jsx("path", { d: "M-10 -12 h20 l6 22 h-32z", fill: "#746351" }),
          e.jsx("path", { d: "M-6 -12 l-4 -6 h20 l-4 6z", fill: "#746351" }),
          e.jsx(r, {
            x: 0,
            y: 6,
            size: 11,
            anchor: "middle",
            fill: "#ffe4b4",
            children: "£",
          }),
        ],
      }),
    ],
  });
}
function V({ x: i, y: t, w: s, h: l }) {
  return e.jsxs("g", {
    children: [
      e.jsx("rect", {
        x: i,
        y: t,
        width: s,
        height: l,
        rx: 1.5,
        fill: "#ac3a38",
        stroke: "#901e21",
      }),
      e.jsx("rect", {
        x: i + s / 2 - 2.5,
        y: t,
        width: 5,
        height: l,
        fill: "#ae9c88",
      }),
      e.jsx("rect", {
        x: i + 3,
        y: t + l - 10,
        width: s / 2 - 5,
        height: 7,
        fill: "#e3e9ee",
      }),
    ],
  });
}
function nt({ x: i }) {
  return e.jsxs("g", {
    children: [
      e.jsx("rect", {
        x: i + 8,
        y: 172,
        width: 40,
        height: 18,
        fill: "#e3e9ee",
      }),
      e.jsx("rect", {
        x: i,
        y: 182,
        width: 56,
        height: 30,
        rx: 4,
        fill: "#46515b",
        stroke: "#5c6873",
      }),
      e.jsx("rect", {
        x: i + 5,
        y: 188,
        width: 46,
        height: 17,
        rx: 2,
        fill: "#901e21",
        stroke: "#cb5651",
        className: "attack-flash-stroke",
      }),
      e.jsx(k, {
        x: i + 28,
        y: 200,
        size: 9,
        fill: "#d1beaa",
        anchor: "middle",
        children: "£10m",
      }),
    ],
  });
}
function Ki() {
  const i = [30, 100, 170, 240, 310, 370];
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#0d171f" }),
      e.jsx("rect", { x: 0, y: 0, width: 400, height: 156, fill: "#111b23" }),
      e.jsx("rect", { x: 0, y: 156, width: 400, height: 84, fill: "#242f38" }),
      e.jsx("path", {
        d: "M0 6 q20 14 40 0 t40 0 t40 0 t40 0 t40 0 t40 0 t40 0 t40 0 t40 0 t40 0",
        fill: "none",
        stroke: "#399661",
        strokeWidth: 4,
        strokeDasharray: "2 2",
      }),
      i.map((t, s) =>
        e.jsx(
          "circle",
          { cx: t, cy: 14, r: 4, fill: s % 2 ? "#e8ba61" : "#cb5651" },
          t,
        ),
      ),
      [8, 322].map((t) =>
        e.jsxs(
          "g",
          {
            children: [
              e.jsx("rect", {
                x: t,
                y: 28,
                width: 70,
                height: 128,
                fill: "none",
                stroke: "#4e89aa",
                strokeWidth: 3,
              }),
              [66, 106].map((s) =>
                e.jsx(
                  "rect",
                  { x: t, y: s, width: 70, height: 3, fill: "#4e89aa" },
                  s,
                ),
              ),
              [44, 84, 124].map((s) =>
                e.jsxs(
                  "g",
                  {
                    children: [
                      e.jsx(V, { x: t + 6, y: s - 4, w: 26, h: 22 }),
                      e.jsx(V, { x: t + 36, y: s, w: 28, h: 18 }),
                    ],
                  },
                  s,
                ),
              ),
            ],
          },
          t,
        ),
      ),
      e.jsx("rect", {
        x: 278,
        y: 30,
        width: 36,
        height: 40,
        rx: 3,
        fill: "#e3e9ee",
      }),
      e.jsx("path", {
        d: "M278 42 V33 a3 3 0 0 1 3 -3 h30 a3 3 0 0 1 3 3 V42z",
        fill: "#cb5651",
      }),
      e.jsx(r, {
        x: 296,
        y: 39.5,
        size: 7.5,
        anchor: "middle",
        fill: "#e3e9ee",
        children: "DEC",
      }),
      e.jsx(r, {
        x: 296,
        y: 64,
        size: 18,
        anchor: "middle",
        fill: "#111b23",
        children: "4",
      }),
      e.jsx("path", {
        d: "M150 0 V28 M250 0 V28",
        stroke: "#46515b",
        strokeWidth: 2,
      }),
      e.jsx("rect", {
        x: 124,
        y: 28,
        width: 148,
        height: 70,
        rx: 4,
        fill: "#901e21",
        stroke: "#cb5651",
        strokeWidth: 3,
        className: "attack-flash-stroke",
      }),
      e.jsxs("g", {
        transform: "translate(150 50)",
        children: [
          e.jsx("rect", {
            x: -11,
            y: 0,
            width: 22,
            height: 17,
            rx: 2,
            fill: "#d1beaa",
          }),
          e.jsx("path", {
            d: "M-7 0 v-5 a7 7 0 0 1 14 0 v5",
            fill: "none",
            stroke: "#d1beaa",
            strokeWidth: 3,
          }),
          e.jsx("circle", { cx: 0, cy: 8, r: 2.5, fill: "#901e21" }),
        ],
      }),
      e.jsx(r, {
        x: 218,
        y: 64,
        size: 20,
        anchor: "middle",
        fill: "#e3e9ee",
        children: "PAY £10m",
      }),
      e.jsx(r, {
        x: 198,
        y: 86,
        size: 8,
        anchor: "middle",
        fill: "#d1beaa",
        children: "or no parcel leaves",
      }),
      e.jsx("rect", { x: 0, y: 150, width: 400, height: 14, fill: "#333e48" }),
      Array.from({ length: 17 }, (t, s) =>
        e.jsx(
          "circle",
          {
            cx: 12 + s * 24,
            cy: 168,
            r: 4,
            fill: "#242f38",
            stroke: "#46515b",
          },
          s,
        ),
      ),
      [60, 180, 300].map((t) =>
        e.jsx(
          "rect",
          { x: t, y: 172, width: 6, height: 30, fill: "#333e48" },
          t,
        ),
      ),
      e.jsx(V, { x: 118, y: 124, w: 30, h: 26 }),
      e.jsx(V, { x: 156, y: 130, w: 26, h: 20 }),
      e.jsx(V, { x: 194, y: 120, w: 34, h: 30 }),
      e.jsx(V, { x: 240, y: 128, w: 28, h: 22 }),
      e.jsx("rect", { x: 196, y: 112, width: 6, height: 12, fill: "#46515b" }),
      e.jsx("circle", {
        cx: 199,
        cy: 109,
        r: 5,
        fill: "#cb5651",
        className: "attack-flash",
      }),
      e.jsx("rect", { x: 52, y: 210, width: 10, height: 30, fill: "#46515b" }),
      e.jsx("rect", {
        x: 10,
        y: 138,
        width: 94,
        height: 74,
        rx: 4,
        fill: "#111b23",
        stroke: "#46515b",
      }),
      e.jsx("rect", {
        x: 15,
        y: 143,
        width: 84,
        height: 64,
        fill: "#901e21",
        className: "attack-flash",
      }),
      e.jsx("rect", {
        x: 20,
        y: 148,
        width: 18,
        height: 18,
        rx: 4,
        fill: "#399661",
      }),
      e.jsx("path", {
        d: "M24 154 h10 l-3 -3 M34 160 h-10 l3 3",
        fill: "none",
        stroke: "#e3e9ee",
        strokeWidth: 1.6,
      }),
      e.jsx(r, {
        x: 68,
        y: 161,
        size: 7,
        anchor: "middle",
        fill: "#d1beaa",
        children: "LOCKED",
      }),
      e.jsx(r, {
        x: 57,
        y: 190,
        size: 14,
        anchor: "middle",
        fill: "#e3e9ee",
        children: "Pay £10m",
      }),
      e.jsx("rect", {
        x: 226,
        y: 212,
        width: 174,
        height: 28,
        fill: "#46515b",
      }),
      e.jsx(nt, { x: 250 }),
      e.jsx(nt, { x: 326 }),
      e.jsx(V, { x: 124, y: 206, w: 34, h: 28 }),
      e.jsx(V, { x: 162, y: 214, w: 30, h: 20 }),
      e.jsx(V, { x: 140, y: 186, w: 28, h: 20 }),
    ],
  });
}
const Ji = {
  civil_sql_injection: {
    Art: qi,
    bg: "#0d171f",
    alt: "Someone types an SQL command into the Surname box of the Digital Identity Office passport form, and the citizens database spills out passport records with photos, names and passport numbers.",
  },
  civil_blagging: {
    Art: Di,
    bg: "#0d171f",
    alt: "A hooded caller with a fake ministry ID claims to be a minister’s secretary and pressures a help desk officer to change a passport record, as the clock ticks towards the summit and the clock tower glows outside.",
  },
  civil_ddos: {
    Art: Ri,
    bg: "#0d171f",
    alt: "At 23:41 on 31 January, a botnet floods the overheating online tax service while a queue of citizens wait at their laptops, unable to file their tax returns.",
  },
  civil_spyware: {
    Art: Zi,
    bg: "#0d171f",
    alt: "A caseworker plugs a free conference USB stick into their PC, and hidden spyware records every key pressed and every benefits claim on screen, sending them to a server abroad.",
  },
  civil_server_theft: {
    Art: Yi,
    bg: "#0d171f",
    alt: "At 4am in a government data centre, two people in hi-vis jackets, one holding a clipboard, unscrew a server from the open passport photo backups rack while the security desk sits behind them.",
  },
  threadline_ddos: {
    Art: Fi,
    bg: "#0d171f",
    alt: "On Black Friday, hijacked computers flood the Threadline shop servers until the website shows an error and shoppers abandon their baskets.",
  },
  threadline_brute_force: {
    Art: Qi,
    bg: "#0d171f",
    alt: "Bots try millions of leaked email and password pairs on the Threadline sign in page until one works, opening a customer account with a saved card and home address.",
  },
  threadline_interception: {
    Art: Ui,
    bg: "#0d171f",
    alt: "A shopper pays on an unencrypted Threadline checkout page, and a hooded attacker captures the card number and expiry date as the payment travels across the internet.",
  },
  threadline_phishing: {
    Art: Gi,
    bg: "#0d171f",
    alt: "Threadline’s finance inbox shows a lookalike supplier email saying its bank details have changed and asking for a £4,000,000 invoice to be approved, linking to a fake supplier portal on a slightly wrong web address.",
  },
  threadline_ransomware: {
    Art: Ki,
    bg: "#0d171f",
    alt: "In early December, under the warehouse tinsel, the conveyor of parcels has stopped and the picking terminal, label printers and overhead board all show red ransom screens demanding £10m.",
  },
};
function p({
  x: i,
  y: t,
  size: s = 8,
  fill: l = "#111b23",
  anchor: a = "start",
  children: c,
}) {
  return e.jsx("text", {
    x: i,
    y: t,
    fontSize: s,
    fill: l,
    fontWeight: 700,
    textAnchor: a,
    fontFamily: "'Courier New', Courier, monospace",
    children: c,
  });
}
function Ge({ x: i, y: t }) {
  return e.jsx("path", {
    d: `M${i} ${t} l0 18 l5 -5 l4 9 l4 -2 l-4 -9 l7 0z`,
    fill: "#e3e9ee",
    stroke: "#111b23",
    strokeWidth: 1.2,
    strokeLinejoin: "round",
  });
}
function L({ d: i, stroke: t = "#cb5651" }) {
  return e.jsx("path", {
    d: i,
    fill: "none",
    stroke: t,
    strokeWidth: 2,
    strokeDasharray: "5 4",
    className: "attack-flow",
  });
}
function Ke({ x: i, y: t, s }) {
  return e.jsxs("g", {
    transform: `translate(${i} ${t}) scale(${s})`,
    children: [
      e.jsx("path", {
        d: "M-74 156 C-70 102 -42 84 0 84 C42 84 70 102 74 156z",
        fill: "#333e48",
      }),
      e.jsx("path", { d: "M0 84 v72", stroke: "#242f38", strokeWidth: 2 }),
      e.jsx("path", {
        d: "M-46 44 C-46 -14 46 -14 46 44 C46 76 30 92 0 92 C-30 92 -46 76 -46 44z",
        fill: "#46515b",
      }),
      e.jsx("ellipse", { cx: 0, cy: 44, rx: 30, ry: 34, fill: "#111b23" }),
    ],
  });
}
function dt({ x: i, y: t, fill: s = "#e3e9ee" }) {
  return e.jsxs("g", {
    children: [
      e.jsx("path", {
        d: `M${i - 6} ${t + 10} v-4 a6 6 0 0 1 12 0 v4`,
        fill: "none",
        stroke: s,
        strokeWidth: 2.5,
      }),
      e.jsx("rect", {
        x: i - 9,
        y: t + 9,
        width: 18,
        height: 14,
        rx: 2,
        fill: s,
      }),
    ],
  });
}
function Xi({ x: i, y: t }) {
  return e.jsx("path", {
    d: `M${i - 3.5} ${t - 3.5} l7 7 M${i + 3.5} ${t - 3.5} l-7 7`,
    stroke: "#cb5651",
    strokeWidth: 2,
    strokeLinecap: "round",
  });
}
function es({ x: i, y: t }) {
  return e.jsx("path", {
    d: `M${i - 4} ${t} l3 3 l5 -6`,
    fill: "none",
    stroke: "#7ed99f",
    strokeWidth: 2.2,
    strokeLinecap: "round",
    strokeLinejoin: "round",
  });
}
function _t({ x: i, y: t }) {
  return e.jsxs("g", {
    children: [
      e.jsx("circle", {
        cx: i,
        cy: t,
        r: 3.5,
        fill: "#cb5651",
        className: "attack-flash",
      }),
      e.jsx(r, {
        x: i + 6,
        y: t + 3,
        size: 8,
        fill: "#ffa79f",
        children: "REC",
      }),
    ],
  });
}
function xt({ x: i, y: t }) {
  return e.jsxs("g", {
    children: [
      e.jsx("path", {
        d: `M${i} ${t} h14 l4 4 h22 v22 h-40z`,
        fill: "#c4973c",
      }),
      e.jsx("rect", {
        x: i,
        y: t + 6,
        width: 40,
        height: 20,
        rx: 1.5,
        fill: "#e8ba61",
      }),
      e.jsx(r, {
        x: i + 20,
        y: t + 20,
        size: 7.5,
        anchor: "middle",
        fill: "#5c4d3b",
        children: "TAX",
      }),
    ],
  });
}
function ts() {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#0d171f" }),
      e.jsxs(f, {
        x: 10,
        y: 10,
        w: 206,
        h: 220,
        bar: "#0d171f",
        children: [
          e.jsx("rect", {
            x: 11,
            y: 26,
            width: 204,
            height: 14,
            fill: "#bac3cb",
          }),
          e.jsx(r, {
            x: 18,
            y: 36,
            size: 7.5,
            fill: "#0d171f",
            children: "Staff inbox",
          }),
          e.jsx("rect", {
            x: 11,
            y: 40,
            width: 204,
            height: 18,
            fill: "#d1beaa",
          }),
          e.jsx("circle", { cx: 18, cy: 49, r: 2.5, fill: "#326e8e" }),
          e.jsx(r, {
            x: 25,
            y: 52,
            size: 7,
            fill: "#111b23",
            children: "Cabinet Office",
          }),
          e.jsx(r, {
            x: 208,
            y: 52,
            size: 6.5,
            anchor: "end",
            weight: 400,
            fill: "#46515b",
            children: "Your £500 bonus",
          }),
          e.jsx("path", { d: "M11 64 H215", stroke: "#bac3cb" }),
          e.jsx(r, {
            x: 18,
            y: 79,
            size: 6.5,
            weight: 400,
            fill: "#46515b",
            children: "From",
          }),
          e.jsxs(p, {
            x: 40,
            y: 79,
            size: 7.5,
            children: [
              "pay@cabinet-",
              e.jsx("tspan", { fill: "#cb5651", children: "0" }),
              "ffice.uk",
            ],
          }),
          e.jsx("rect", {
            x: 18,
            y: 88,
            width: 190,
            height: 54,
            rx: 4,
            fill: "#f8e4cf",
            stroke: "#e8ba61",
          }),
          e.jsx(r, {
            x: 113,
            y: 104,
            size: 8,
            anchor: "middle",
            fill: "#746351",
            children: "COST OF LIVING BONUS",
          }),
          e.jsx(r, {
            x: 113,
            y: 133,
            size: 24,
            anchor: "middle",
            fill: "#ac3a38",
            children: "£500",
          }),
          e.jsx(r, {
            x: 18,
            y: 158,
            size: 7.5,
            weight: 400,
            fill: "#333e48",
            children: "For all civil servants. Log in to claim.",
          }),
          e.jsx("rect", {
            x: 18,
            y: 168,
            width: 110,
            height: 22,
            rx: 3,
            fill: "#137a47",
          }),
          e.jsx(r, {
            x: 73,
            y: 182.5,
            size: 8,
            anchor: "middle",
            fill: "#e3e9ee",
            children: "Log in to claim",
          }),
          e.jsx("rect", {
            x: 146,
            y: 204,
            width: 62,
            height: 18,
            rx: 9,
            fill: "#bac3cb",
          }),
          e.jsx(r, {
            x: 177,
            y: 216,
            size: 7,
            anchor: "middle",
            fill: "#ac3a38",
            children: "Ends Friday",
          }),
          e.jsx(Ge, { x: 112, y: 178 }),
          e.jsx(r, {
            x: 18,
            y: 216,
            size: 7,
            weight: 400,
            fill: "#5c6873",
            children: "Cabinet Office HR Team",
          }),
        ],
      }),
      e.jsx(L, { d: "M134 186 C184 186 196 96 226 96" }),
      e.jsxs(f, {
        x: 228,
        y: 10,
        w: 164,
        h: 140,
        bar: "#0d171f",
        children: [
          e.jsx("rect", {
            x: 234,
            y: 30,
            width: 152,
            height: 15,
            rx: 7.5,
            fill: "#bac3cb",
            stroke: "#cb5651",
            strokeWidth: 1.5,
            className: "attack-flash-stroke",
          }),
          e.jsx(p, {
            x: 310,
            y: 40.5,
            size: 7.5,
            fill: "#333e48",
            anchor: "middle",
            children: "gov-uk-staff.com/login",
          }),
          e.jsx("rect", {
            x: 229,
            y: 50,
            width: 162,
            height: 18,
            fill: "#0d171f",
          }),
          e.jsx("rect", {
            x: 229,
            y: 68,
            width: 162,
            height: 3,
            fill: "#326e8e",
          }),
          e.jsx(r, {
            x: 236,
            y: 62,
            size: 8,
            fill: "#e3e9ee",
            children: "Civil Service",
          }),
          e.jsx(r, {
            x: 236,
            y: 87,
            size: 10,
            fill: "#0d171f",
            children: "Staff sign in",
          }),
          e.jsx("rect", {
            x: 236,
            y: 93,
            width: 148,
            height: 15,
            rx: 2,
            fill: "#e3e9ee",
            stroke: "#95a1ac",
          }),
          e.jsx(r, {
            x: 241,
            y: 103.5,
            size: 7,
            weight: 400,
            fill: "#333e48",
            children: "j.patel@dio.gov.uk",
          }),
          e.jsx("rect", {
            x: 236,
            y: 112,
            width: 148,
            height: 15,
            rx: 2,
            fill: "#e3e9ee",
            stroke: "#cb5651",
            strokeWidth: 1.5,
          }),
          e.jsx(r, {
            x: 241,
            y: 123.5,
            size: 9,
            fill: "#333e48",
            children: "• • • • • • • • • •",
          }),
          e.jsx("rect", {
            x: 236,
            y: 131,
            width: 56,
            height: 14,
            rx: 2,
            fill: "#137a47",
          }),
          e.jsx(r, {
            x: 264,
            y: 141,
            size: 7,
            anchor: "middle",
            fill: "#e3e9ee",
            children: "Sign in",
          }),
        ],
      }),
      e.jsx(L, { d: "M262 150 C262 196 300 196 318 196" }),
      e.jsx("rect", {
        x: 226,
        y: 160,
        width: 76,
        height: 16,
        rx: 8,
        fill: "#242f38",
        stroke: "#ee766f",
      }),
      e.jsx(p, {
        x: 264,
        y: 171,
        size: 8,
        fill: "#d1beaa",
        anchor: "middle",
        children: "Whitehall9!",
      }),
      e.jsx(xt, { x: 226, y: 202 }),
      e.jsx(xt, { x: 272, y: 208 }),
      e.jsx(Ke, { x: 358, y: 164, s: 0.48 }),
    ],
  });
}
function ft({ y: i, text: t, hit: s }) {
  return e.jsxs("g", {
    children: [
      e.jsx("rect", {
        x: 12,
        y: i,
        width: 108,
        height: 17,
        rx: 8.5,
        fill: s ? "#102333" : "#242f38",
        stroke: s ? "#7ed99f" : "#46515b",
        strokeWidth: s ? 1.5 : 1,
      }),
      e.jsx(p, {
        x: 22,
        y: i + 11.5,
        size: 8,
        fill: s ? "#a8ffc6" : "#bac3cb",
        children: t,
      }),
      s ? e.jsx(es, { x: 108, y: i + 8.5 }) : e.jsx(Xi, { x: 108, y: i + 5 }),
    ],
  });
}
function is() {
  const i = ["password1", "123456", "Summer2026", "qwerty", "biscuit"];
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#0d171f" }),
      e.jsx("path", { d: "M66 6 V14", stroke: "#5c6873", strokeWidth: 2 }),
      e.jsx("circle", {
        cx: 66,
        cy: 6,
        r: 3,
        fill: "#cb5651",
        className: "attack-flash",
      }),
      e.jsx("rect", {
        x: 44,
        y: 14,
        width: 44,
        height: 30,
        rx: 7,
        fill: "#333e48",
        stroke: "#5c6873",
      }),
      e.jsx("rect", {
        x: 50,
        y: 21,
        width: 32,
        height: 12,
        rx: 6,
        fill: "#111b23",
      }),
      e.jsx("circle", { cx: 59, cy: 27, r: 3, fill: "#cb5651" }),
      e.jsx("circle", { cx: 73, cy: 27, r: 3, fill: "#cb5651" }),
      e.jsx(r, {
        x: 66,
        y: 56,
        size: 8,
        anchor: "middle",
        fill: "#95a1ac",
        children: "GUESSING BOT",
      }),
      i.map((t, s) => e.jsx(ft, { y: 64 + s * 21, text: t }, t)),
      e.jsx(ft, { y: 169, text: "Rex2015", hit: !0 }),
      e.jsx("rect", {
        x: 12,
        y: 196,
        width: 108,
        height: 30,
        rx: 4,
        fill: "#480004",
      }),
      e.jsx(p, {
        x: 66,
        y: 215,
        size: 10,
        fill: "#ffa79f",
        anchor: "middle",
        children: "48,211 tries",
      }),
      e.jsx(L, { d: "M120 177 C134 177 128 116 140 116", stroke: "#7ed99f" }),
      e.jsxs(f, {
        x: 140,
        y: 14,
        w: 130,
        h: 212,
        bar: "#0d171f",
        children: [
          e.jsx("rect", {
            x: 141,
            y: 30,
            width: 128,
            height: 18,
            fill: "#0d171f",
          }),
          e.jsx("rect", {
            x: 141,
            y: 48,
            width: 128,
            height: 3,
            fill: "#326e8e",
          }),
          e.jsx(r, {
            x: 147,
            y: 42,
            size: 8,
            fill: "#e3e9ee",
            children: "Your tax account",
          }),
          e.jsx(r, {
            x: 147,
            y: 66,
            size: 7,
            fill: "#0d171f",
            children: "User ID",
          }),
          e.jsx("rect", {
            x: 147,
            y: 70,
            width: 116,
            height: 16,
            fill: "#e3e9ee",
            stroke: "#0d171f",
          }),
          e.jsx(p, {
            x: 152,
            y: 81.5,
            size: 8,
            fill: "#0d171f",
            children: "jsmith1984",
          }),
          e.jsx(r, {
            x: 147,
            y: 100,
            size: 7,
            fill: "#0d171f",
            children: "Password",
          }),
          e.jsx("rect", {
            x: 147,
            y: 104,
            width: 116,
            height: 16,
            fill: "#e3e9ee",
            stroke: "#399661",
            strokeWidth: 2,
            className: "attack-flash-stroke",
          }),
          e.jsx(p, {
            x: 152,
            y: 115.5,
            size: 8,
            fill: "#137a47",
            children: "Rex2015",
          }),
          e.jsx("rect", {
            x: 147,
            y: 126,
            width: 116,
            height: 14,
            rx: 2,
            fill: "#bac3cb",
          }),
          e.jsx(r, {
            x: 205,
            y: 136,
            size: 7,
            anchor: "middle",
            fill: "#137a47",
            children: "Signed in",
          }),
          e.jsx("path", { d: "M141 148 H269", stroke: "#bac3cb" }),
          e.jsx(r, {
            x: 147,
            y: 162,
            size: 7,
            fill: "#0d171f",
            children: "Refund bank account",
          }),
          e.jsx(p, {
            x: 152,
            y: 178,
            size: 9,
            fill: "#95a1ac",
            children: "12-34-56",
          }),
          e.jsx("path", {
            d: "M150 175 H200",
            stroke: "#5c6873",
            strokeWidth: 1.5,
          }),
          e.jsx("rect", {
            x: 147,
            y: 186,
            width: 116,
            height: 20,
            rx: 2,
            fill: "#e3e9ee",
            stroke: "#cb5651",
          }),
          e.jsx(p, {
            x: 152,
            y: 200,
            size: 9,
            fill: "#ac3a38",
            children: "99-01-66",
          }),
          e.jsx(r, {
            x: 258,
            y: 199.5,
            size: 6.5,
            anchor: "end",
            weight: 400,
            fill: "#ac3a38",
            children: "new",
          }),
        ],
      }),
      e.jsx("rect", {
        x: 284,
        y: 14,
        width: 106,
        height: 70,
        rx: 6,
        fill: "#e3e9ee",
      }),
      e.jsx("rect", {
        x: 284,
        y: 14,
        width: 106,
        height: 16,
        rx: 6,
        fill: "#137a47",
      }),
      e.jsx("rect", { x: 284, y: 24, width: 106, height: 6, fill: "#137a47" }),
      e.jsx(r, {
        x: 337,
        y: 26,
        size: 8,
        anchor: "middle",
        fill: "#e3e9ee",
        children: "APRIL",
      }),
      e.jsx(r, {
        x: 337,
        y: 45,
        size: 8,
        anchor: "middle",
        fill: "#111b23",
        children: "Tax refund",
      }),
      e.jsx(r, {
        x: 337,
        y: 72,
        size: 20,
        anchor: "middle",
        fill: "#137a47",
        children: "£1,240",
      }),
      e.jsx(L, { d: "M270 196 C300 196 300 92 330 92" }),
      e.jsx(L, { d: "M337 84 V118" }),
      e.jsx(Ke, { x: 348, y: 118, s: 0.5 }),
      e.jsxs("g", {
        transform: "translate(300 214)",
        children: [
          e.jsx("path", { d: "M-12 -14 h24 l7 24 h-38z", fill: "#746351" }),
          e.jsx("path", { d: "M-7 -14 l-5 -7 h24 l-5 7z", fill: "#746351" }),
          e.jsx(r, {
            x: 0,
            y: 5,
            size: 12,
            anchor: "middle",
            fill: "#ffe4b4",
            children: "£",
          }),
        ],
      }),
    ],
  });
}
function jt({ x: i, y: t, kind: s }) {
  return e.jsxs("g", {
    children: [
      e.jsx("rect", {
        x: i,
        y: t,
        width: 18,
        height: 22,
        rx: 1.5,
        fill: "#e3e9ee",
        stroke: "#95a1ac",
      }),
      s === "photo"
        ? e.jsxs(e.Fragment, {
            children: [
              e.jsx("rect", {
                x: i + 3,
                y: t + 3,
                width: 12,
                height: 12,
                fill: "#bac3cb",
              }),
              e.jsx("circle", { cx: i + 9, cy: t + 8, r: 3, fill: "#c68642" }),
              e.jsx("path", {
                d: `M${i + 4} ${t + 15} q5 -6 10 0z`,
                fill: "#46515b",
              }),
            ],
          })
        : e.jsxs(e.Fragment, {
            children: [
              e.jsx("rect", {
                x: i + 3,
                y: t + 4,
                width: 12,
                height: 2,
                fill: "#ac3a38",
              }),
              e.jsx("rect", {
                x: i + 3,
                y: t + 9,
                width: 12,
                height: 1.5,
                fill: "#95a1ac",
              }),
              e.jsx("rect", {
                x: i + 3,
                y: t + 13,
                width: 10,
                height: 1.5,
                fill: "#95a1ac",
              }),
              e.jsx("circle", {
                cx: i + 12,
                cy: t + 18,
                r: 2.2,
                fill: "#cb5651",
              }),
            ],
          }),
    ],
  });
}
function yt({ x: i, w: t, top: s, label: l }) {
  const a = Math.floor((t - 8) / 16),
    c = Math.floor((172 - s - 26) / 20);
  return e.jsxs("g", {
    children: [
      e.jsx("rect", { x: i, y: s, width: t, height: 178 - s, fill: "#242f38" }),
      e.jsx("rect", { x: i, y: s - 18, width: t, height: 18, fill: "#0d171f" }),
      e.jsx(r, {
        x: i + t / 2,
        y: s - 6,
        size: 8,
        anchor: "middle",
        fill: "#e3e9ee",
        children: l,
      }),
      Array.from({ length: c * a }, (h, o) =>
        e.jsx(
          "rect",
          {
            x: i + 8 + (o % a) * 16,
            y: s + 10 + Math.floor(o / a) * 20,
            width: 9,
            height: 12,
            fill: (o * 7) % 5 === 0 ? "#333e48" : "#ffe4b4",
          },
          o,
        ),
      ),
    ],
  });
}
function ss() {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#0d171f" }),
      e.jsx("circle", {
        cx: 200,
        cy: 26,
        r: 11,
        fill: "#f8e4cf",
        opacity: 0.9,
      }),
      e.jsx("circle", { cx: 205, cy: 22, r: 10, fill: "#0d171f" }),
      e.jsx(yt, { x: 8, w: 88, top: 52, label: "PASSPORT OFFICE" }),
      e.jsx(yt, { x: 304, w: 88, top: 52, label: "PRINT CENTRE" }),
      e.jsx("rect", { x: 0, y: 178, width: 400, height: 62, fill: "#111b23" }),
      e.jsx("rect", { x: 0, y: 178, width: 400, height: 4, fill: "#333e48" }),
      e.jsx("path", {
        d: "M52 178 V214 H348 V178",
        fill: "none",
        stroke: "#333e48",
        strokeWidth: 6,
      }),
      e.jsx(L, { d: "M52 178 V214 H348 V178", stroke: "#6ca8ca" }),
      e.jsx(jt, { x: 78, y: 200, kind: "cert" }),
      e.jsx(jt, { x: 290, y: 200, kind: "photo" }),
      e.jsx(r, {
        x: 200,
        y: 234,
        size: 7.5,
        anchor: "middle",
        fill: "#95a1ac",
        children: "Tonight's scanned applications",
      }),
      e.jsx("rect", {
        x: 112,
        y: 116,
        width: 50,
        height: 62,
        rx: 3,
        fill: "#006034",
      }),
      e.jsx("rect", { x: 116, y: 120, width: 42, height: 54, fill: "#102333" }),
      e.jsx("path", {
        d: "M122 128 h30 M122 138 h30 M122 148 h30",
        stroke: "#95a1ac",
        strokeWidth: 2,
      }),
      e.jsx("path", { d: "M162 116 l14 6 v50 l-14 6z", fill: "#137a47" }),
      e.jsx("path", {
        d: "M137 214 V156 C137 140 168 140 186 140",
        fill: "none",
        stroke: "#cb5651",
        strokeWidth: 2,
        strokeDasharray: "5 4",
        className: "attack-flow",
      }),
      e.jsx("circle", {
        cx: 137,
        cy: 214,
        r: 4,
        fill: "#cb5651",
        className: "attack-flash",
      }),
      e.jsx("rect", {
        x: 186,
        y: 80,
        width: 108,
        height: 74,
        rx: 4,
        fill: "#242f38",
        stroke: "#46515b",
      }),
      e.jsx("rect", { x: 191, y: 85, width: 98, height: 64, fill: "#111b23" }),
      e.jsx(p, {
        x: 196,
        y: 96,
        size: 7.5,
        fill: "#ffa79f",
        children: "CAPTURED 12,004",
      }),
      e.jsx("rect", { x: 196, y: 102, width: 30, height: 40, fill: "#bac3cb" }),
      e.jsx("circle", { cx: 211, cy: 116, r: 7, fill: "#8d5524" }),
      e.jsx("path", { d: "M200 142 q11 -16 22 0z", fill: "#333e48" }),
      e.jsx("rect", { x: 231, y: 102, width: 54, height: 40, fill: "#d1beaa" }),
      e.jsx(r, {
        x: 258,
        y: 113,
        size: 7,
        anchor: "middle",
        fill: "#ac3a38",
        children: "BIRTH",
      }),
      e.jsx(r, {
        x: 258,
        y: 122,
        size: 7,
        anchor: "middle",
        fill: "#ac3a38",
        children: "CERTIFICATE",
      }),
      e.jsx("rect", { x: 236, y: 127, width: 44, height: 2, fill: "#bac3cb" }),
      e.jsx("rect", { x: 236, y: 132, width: 36, height: 2, fill: "#bac3cb" }),
      e.jsx("circle", { cx: 276, cy: 137, r: 3, fill: "#cb5651" }),
      e.jsx("path", { d: "M180 154 h120 l-8 10 h-104z", fill: "#333e48" }),
      e.jsx("rect", { x: 196, y: 164, width: 88, height: 14, fill: "#242f38" }),
    ],
  });
}
function rs() {
  return e.jsxs("g", {
    children: [
      e.jsx("path", {
        d: "M126 82 L146 100",
        stroke: "#111b23",
        strokeWidth: 2,
      }),
      e.jsx("ellipse", { cx: 128, cy: 86, rx: 12, ry: 5, fill: "#5c6873" }),
      e.jsx("path", {
        d: "M54 60 H186 L198 70 Q198 80 188 80 H54 Q36 80 34 70 Q36 60 54 60z",
        fill: "#bac3cb",
      }),
      e.jsx("path", { d: "M168 60 L182 26 H195 L198 60z", fill: "#00425f" }),
      e.jsx("path", { d: "M178 38 H195 V45 H175z", fill: "#cb5651" }),
      e.jsx("rect", { x: 38, y: 72, width: 156, height: 2.5, fill: "#00425f" }),
      e.jsx("path", { d: "M38 66 L46 64 V68 H37z", fill: "#111b23" }),
      [56, 66, 76, 86, 96, 106, 116, 136, 146, 156, 166].map((i) =>
        e.jsx(
          "rect",
          { x: i, y: 64, width: 4, height: 4, rx: 1, fill: "#333e48" },
          i,
        ),
      ),
      e.jsx("path", { d: "M104 74 L140 94 H152 L130 74z", fill: "#95a1ac" }),
      e.jsx("path", {
        d: "M62 80 V92 M156 80 V92",
        stroke: "#46515b",
        strokeWidth: 2,
      }),
      e.jsx("circle", { cx: 62, cy: 94, r: 3, fill: "#111b23" }),
      e.jsx("circle", { cx: 156, cy: 94, r: 3, fill: "#111b23" }),
    ],
  });
}
function Pe({
  y: i,
  time: t,
  place: s,
  gate: l,
  status: a,
  colour: c,
  flash: h,
}) {
  return e.jsxs("g", {
    children: [
      e.jsx(p, { x: 221, y: i, size: 8, fill: "#e8ba61", children: t }),
      e.jsx(r, { x: 250, y: i, size: 8, fill: "#e3e9ee", children: s }),
      e.jsx(p, { x: 300, y: i, size: 8, fill: "#e8ba61", children: l }),
      e.jsx("g", {
        className: h ? "attack-flash" : void 0,
        children: e.jsx(r, {
          x: 386,
          y: i,
          size: 7.5,
          anchor: "end",
          fill: c,
          children: a,
        }),
      }),
    ],
  });
}
function ls() {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#0d171f" }),
      e.jsx("rect", { x: 0, y: 196, width: 400, height: 44, fill: "#19232c" }),
      e.jsx("rect", { x: 8, y: 8, width: 198, height: 80, fill: "#00425f" }),
      e.jsx("rect", {
        x: 8,
        y: 70,
        width: 198,
        height: 18,
        fill: "#ee766f",
        opacity: 0.3,
      }),
      e.jsx("circle", { cx: 24, cy: 88, r: 9, fill: "#d1beaa", opacity: 0.85 }),
      e.jsx("rect", { x: 8, y: 88, width: 198, height: 22, fill: "#333e48" }),
      e.jsx("path", {
        d: "M8 104 H206",
        stroke: "#bac3cb",
        strokeWidth: 1.5,
        strokeDasharray: "10 8",
      }),
      e.jsxs("g", {
        transform: "translate(146 26) rotate(-14)",
        children: [
          e.jsx("rect", {
            x: -14,
            y: -2.5,
            width: 28,
            height: 5,
            rx: 2.5,
            fill: "#bac3cb",
          }),
          e.jsx("path", {
            d: "M-2 0 L-8 9 H-4 L4 0z M10 0 L14 -7 H16 L15 0z",
            fill: "#bac3cb",
          }),
        ],
      }),
      e.jsx(rs, {}),
      e.jsx("rect", {
        x: 8,
        y: 8,
        width: 198,
        height: 102,
        fill: "none",
        stroke: "#46515b",
        strokeWidth: 4,
      }),
      e.jsx("path", {
        d: "M74 8 V110 M140 8 V110",
        stroke: "#46515b",
        strokeWidth: 3,
      }),
      e.jsx("path", {
        d: "M26 0 V14 M70 0 V14",
        stroke: "#5c6873",
        strokeWidth: 2,
      }),
      e.jsx("rect", {
        x: 16,
        y: 14,
        width: 64,
        height: 28,
        rx: 2,
        fill: "#e8ba61",
      }),
      e.jsx(r, {
        x: 48,
        y: 24,
        size: 7,
        anchor: "middle",
        fill: "#111b23",
        children: "Gate",
      }),
      e.jsx(r, {
        x: 48,
        y: 38,
        size: 13,
        anchor: "middle",
        fill: "#111b23",
        children: "B22",
      }),
      e.jsx("rect", {
        x: 214,
        y: 8,
        width: 178,
        height: 74,
        rx: 3,
        fill: "#0d171f",
        stroke: "#333e48",
      }),
      e.jsx("path", {
        d: "M214 11 a3 3 0 0 1 3 -3 h172 a3 3 0 0 1 3 3 v13 h-178z",
        fill: "#e8ba61",
      }),
      e.jsx(r, {
        x: 221,
        y: 20,
        size: 8.5,
        fill: "#111b23",
        children: "Departures",
      }),
      e.jsx("rect", {
        x: 217,
        y: 29,
        width: 172,
        height: 14,
        rx: 2,
        fill: "#480004",
      }),
      e.jsx(Pe, {
        y: 39,
        time: "09:40",
        place: "Geneva",
        gate: "B22",
        status: "FINAL CALL",
        colour: "#ee766f",
        flash: !0,
      }),
      e.jsx(Pe, {
        y: 56,
        time: "10:05",
        place: "Madrid",
        gate: "B14",
        status: "Boarding",
        colour: "#7ed99f",
      }),
      e.jsx(Pe, {
        y: 73,
        time: "10:30",
        place: "Oslo",
        gate: "B09",
        status: "On time",
        colour: "#95a1ac",
      }),
      e.jsx("rect", {
        x: 104,
        y: 96,
        width: 118,
        height: 76,
        rx: 4,
        fill: "#242f38",
      }),
      e.jsx("rect", {
        x: 109,
        y: 100,
        width: 108,
        height: 68,
        fill: "#e3e9ee",
      }),
      e.jsx("rect", {
        x: 109,
        y: 100,
        width: 108,
        height: 14,
        fill: "#0d171f",
      }),
      e.jsx(r, {
        x: 113,
        y: 110,
        size: 7,
        fill: "#e3e9ee",
        children: "Digital Identity Office",
      }),
      e.jsx(r, {
        x: 113,
        y: 126,
        size: 8,
        fill: "#0d171f",
        children: "Passport records",
      }),
      e.jsx("rect", {
        x: 113,
        y: 131,
        width: 100,
        height: 14,
        fill: "#e3e9ee",
        stroke: "#cb5651",
        strokeWidth: 1.5,
        className: "attack-flash-stroke",
      }),
      e.jsx(r, {
        x: 117,
        y: 141.5,
        size: 8,
        fill: "#333e48",
        children: "• • • • • • • • •",
      }),
      e.jsx("rect", { x: 113, y: 150, width: 40, height: 13, fill: "#137a47" }),
      e.jsx(r, {
        x: 133,
        y: 159.5,
        size: 7,
        anchor: "middle",
        fill: "#e3e9ee",
        children: "Sign in",
      }),
      e.jsx("rect", { x: 160, y: 150, width: 53, height: 13, fill: "#bac3cb" }),
      e.jsx(r, {
        x: 186.5,
        y: 159.5,
        size: 7,
        anchor: "middle",
        fill: "#ac3a38",
        children: "SENSITIVE",
      }),
      e.jsx("path", { d: "M98 172 H228 L238 188 H88z", fill: "#46515b" }),
      [176, 180.5].map((i) =>
        e.jsx(
          "rect",
          { x: 102, y: i, width: 122, height: 2.5, rx: 1, fill: "#333e48" },
          i,
        ),
      ),
      e.jsx("rect", {
        x: 176,
        y: 180,
        width: 8,
        height: 3.5,
        rx: 1,
        fill: "#cb5651",
        className: "attack-flash",
      }),
      e.jsx("path", {
        d: "M28 240 C30 206 52 192 86 192 C120 192 142 206 144 240z",
        fill: "#242f38",
      }),
      e.jsx("path", {
        d: "M76 192 l10 9 l10 -9",
        fill: "none",
        stroke: "#bac3cb",
        strokeWidth: 2.5,
      }),
      e.jsx("circle", { cx: 86, cy: 170, r: 19, fill: "#3b2a20" }),
      e.jsx("path", {
        d: "M128 206 q12 -14 44 -24",
        stroke: "#242f38",
        strokeWidth: 9,
        strokeLinecap: "round",
        fill: "none",
      }),
      e.jsx("circle", { cx: 172, cy: 182, r: 4.5, fill: "#c68642" }),
      e.jsx("rect", {
        x: -12,
        y: 210,
        width: 36,
        height: 34,
        rx: 8,
        fill: "#333e48",
      }),
      e.jsx("rect", {
        x: 30,
        y: 210,
        width: 112,
        height: 34,
        rx: 8,
        fill: "#333e48",
      }),
      e.jsx("rect", {
        x: 148,
        y: 210,
        width: 104,
        height: 34,
        rx: 8,
        fill: "#333e48",
      }),
      e.jsx("rect", {
        x: 0,
        y: 206,
        width: 256,
        height: 4,
        rx: 2,
        fill: "#95a1ac",
      }),
      e.jsx("path", {
        d: "M268 178 V160 H284 V178",
        fill: "none",
        stroke: "#95a1ac",
        strokeWidth: 2.5,
      }),
      e.jsx("rect", {
        x: 258,
        y: 178,
        width: 36,
        height: 52,
        rx: 4,
        fill: "#54697c",
      }),
      e.jsx("path", {
        d: "M266 186 V222 M286 186 V222",
        stroke: "#3d5264",
        strokeWidth: 2,
      }),
      e.jsx("circle", { cx: 264, cy: 233, r: 3, fill: "#111b23" }),
      e.jsx("circle", { cx: 288, cy: 233, r: 3, fill: "#111b23" }),
      e.jsx("path", {
        d: "M302 240 C304 172 324 142 352 142 C382 142 396 162 398 240z",
        fill: "#333e48",
      }),
      e.jsx("circle", { cx: 350, cy: 120, r: 17, fill: "#f1c27d" }),
      e.jsx("path", { d: "M333 117 a17 17 0 0 1 34 0z", fill: "#137a47" }),
      e.jsx("rect", {
        x: 331,
        y: 114,
        width: 38,
        height: 5,
        rx: 2,
        fill: "#175675",
      }),
      e.jsx("circle", { cx: 342, cy: 124, r: 2, fill: "#111b23" }),
      e.jsx("path", {
        d: "M336 140 a14 8 0 1 0 28 0",
        fill: "none",
        stroke: "#ee766f",
        strokeWidth: 6,
        strokeLinecap: "round",
      }),
      e.jsx("path", {
        d: "M330 172 C318 160 308 146 302 134",
        stroke: "#333e48",
        strokeWidth: 10,
        strokeLinecap: "round",
        fill: "none",
      }),
      e.jsx("rect", {
        x: 226,
        y: 98,
        width: 74,
        height: 42,
        rx: 5,
        fill: "#111b23",
        stroke: "#5c6873",
      }),
      e.jsx("rect", {
        x: 230,
        y: 102,
        width: 66,
        height: 34,
        rx: 2,
        fill: "#111b23",
        stroke: "#cb5651",
        strokeWidth: 1.5,
      }),
      e.jsx(_t, { x: 236, y: 111 }),
      e.jsx(p, {
        x: 292,
        y: 114,
        size: 7,
        fill: "#95a1ac",
        anchor: "end",
        children: "00:09",
      }),
      e.jsx(p, {
        x: 263,
        y: 130,
        size: 9.5,
        fill: "#d1beaa",
        anchor: "middle",
        children: "Border#26",
      }),
      e.jsx("circle", { cx: 298, cy: 132, r: 6, fill: "#f1c27d" }),
      e.jsx(L, { d: "M236 140 C228 156 214 168 198 178" }),
    ],
  });
}
function Ee({ x: i, y: t, r: s = 0 }) {
  return e.jsxs("g", {
    transform: `translate(${i} ${t}) rotate(${s})`,
    children: [
      e.jsx("rect", {
        x: -10,
        y: -13,
        width: 20,
        height: 26,
        rx: 2,
        fill: "#901e21",
      }),
      e.jsx("circle", {
        cx: 0,
        cy: -2,
        r: 4.5,
        fill: "none",
        stroke: "#e8ba61",
        strokeWidth: 1.2,
      }),
      e.jsx("rect", { x: -6, y: 6, width: 12, height: 2, fill: "#e8ba61" }),
    ],
  });
}
function as() {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#0d171f" }),
      e.jsx("rect", { x: 0, y: 196, width: 400, height: 44, fill: "#111b23" }),
      e.jsx("rect", {
        x: 12,
        y: 14,
        width: 150,
        height: 104,
        rx: 5,
        fill: "#242f38",
      }),
      e.jsx("rect", {
        x: 17,
        y: 19,
        width: 140,
        height: 94,
        fill: "#901e21",
        stroke: "#cb5651",
        strokeWidth: 2,
        className: "attack-flash-stroke",
      }),
      e.jsx(dt, { x: 87, y: 25 }),
      e.jsx(r, {
        x: 87,
        y: 64,
        size: 9,
        anchor: "middle",
        fill: "#d1beaa",
        children: "PRINTING LOCKED",
      }),
      e.jsx(r, {
        x: 87,
        y: 88,
        size: 18,
        anchor: "middle",
        fill: "#e3e9ee",
        children: "Pay £8m",
      }),
      e.jsx(r, {
        x: 87,
        y: 104,
        size: 7,
        anchor: "middle",
        weight: 400,
        fill: "#d1beaa",
        children: "or no passport is printed",
      }),
      e.jsx("rect", { x: 80, y: 118, width: 14, height: 12, fill: "#333e48" }),
      e.jsx("rect", {
        x: 58,
        y: 130,
        width: 58,
        height: 5,
        rx: 2,
        fill: "#333e48",
      }),
      e.jsx("rect", {
        x: 12,
        y: 146,
        width: 150,
        height: 20,
        rx: 4,
        fill: "#242f38",
        stroke: "#cb5651",
      }),
      e.jsx(p, {
        x: 87,
        y: 159.5,
        size: 8,
        fill: "#ffa79f",
        anchor: "middle",
        children: "printer_driver.exe",
      }),
      e.jsx(L, { d: "M162 132 C180 132 178 150 196 150" }),
      e.jsx("rect", {
        x: 190,
        y: 14,
        width: 200,
        height: 62,
        rx: 4,
        fill: "#111b23",
        stroke: "#333e48",
      }),
      e.jsx("rect", {
        x: 350,
        y: 20,
        width: 34,
        height: 22,
        rx: 2,
        fill: "#e3e9ee",
      }),
      e.jsx("rect", {
        x: 350,
        y: 20,
        width: 34,
        height: 8,
        rx: 2,
        fill: "#cb5651",
      }),
      e.jsx(r, {
        x: 367,
        y: 38,
        size: 7.5,
        anchor: "middle",
        fill: "#111b23",
        children: "JUNE",
      }),
      e.jsx(r, {
        x: 200,
        y: 32,
        size: 8,
        fill: "#95a1ac",
        children: "PASSPORTS WAITING",
      }),
      e.jsx(p, {
        x: 200,
        y: 64,
        size: 22,
        fill: "#ee766f",
        children: "500,000",
      }),
      e.jsx("rect", {
        x: 196,
        y: 96,
        width: 124,
        height: 92,
        rx: 6,
        fill: "#46515b",
      }),
      e.jsx("rect", {
        x: 204,
        y: 104,
        width: 108,
        height: 30,
        rx: 3,
        fill: "#333e48",
      }),
      e.jsx("circle", {
        cx: 222,
        cy: 119,
        r: 9,
        fill: "#242f38",
        stroke: "#5c6873",
        strokeWidth: 2,
      }),
      e.jsx("circle", {
        cx: 258,
        cy: 119,
        r: 9,
        fill: "#242f38",
        stroke: "#5c6873",
        strokeWidth: 2,
      }),
      e.jsx("circle", {
        cx: 294,
        cy: 119,
        r: 9,
        fill: "#242f38",
        stroke: "#5c6873",
        strokeWidth: 2,
      }),
      e.jsx("rect", {
        x: 204,
        y: 142,
        width: 56,
        height: 34,
        rx: 2,
        fill: "#901e21",
        stroke: "#cb5651",
      }),
      e.jsx(dt, { x: 232, y: 145, fill: "#d1beaa" }),
      e.jsx("circle", {
        cx: 282,
        cy: 152,
        r: 6,
        fill: "#cb5651",
        className: "attack-flash",
      }),
      e.jsx("circle", {
        cx: 302,
        cy: 152,
        r: 6,
        fill: "#cb5651",
        className: "attack-flash",
      }),
      e.jsx(r, {
        x: 292,
        y: 174,
        size: 7.5,
        anchor: "middle",
        fill: "#d1beaa",
        children: "STOPPED",
      }),
      e.jsx("rect", { x: 320, y: 160, width: 72, height: 28, fill: "#333e48" }),
      e.jsx(Ee, { x: 334, y: 150, r: -6 }),
      e.jsx(Ee, { x: 356, y: 148, r: 4 }),
      e.jsx(Ee, { x: 378, y: 151, r: -3 }),
      e.jsx("rect", { x: 196, y: 188, width: 196, height: 8, fill: "#242f38" }),
      e.jsx("path", {
        d: "M210 196 v22 M378 196 v22",
        stroke: "#242f38",
        strokeWidth: 6,
      }),
    ],
  });
}
function pt({ x: i, y: t, fill: s }) {
  return e.jsx("path", {
    d: `M${i + 6} ${t} l-6 5 l3 4 l3 -2 v13 h14 v-13 l3 2 l3 -4 l-6 -5 q-4 3 -8 0z`,
    fill: s,
  });
}
function oe({ x: i, y: t, r: s, name: l, addr: a }) {
  return e.jsxs("g", {
    transform: `translate(${i} ${t}) rotate(${s})`,
    children: [
      e.jsx("rect", {
        x: 0,
        y: 0,
        width: 142,
        height: 18,
        rx: 2,
        fill: "#e3e9ee",
        stroke: "#bac3cb",
      }),
      e.jsx("rect", {
        x: 0,
        y: 0,
        width: 5,
        height: 18,
        rx: 1,
        fill: "#54697c",
      }),
      e.jsx(p, { x: 10, y: 12, size: 7.5, fill: "#111b23", children: l }),
      e.jsx(p, {
        x: 136,
        y: 12,
        size: 7.5,
        fill: "#901e21",
        anchor: "end",
        children: a,
      }),
    ],
  });
}
function cs() {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#0d171f" }),
      e.jsxs(f, {
        x: 10,
        y: 12,
        w: 216,
        h: 214,
        bar: "#1c2f40",
        children: [
          e.jsx(r, {
            x: 20,
            y: 46,
            size: 13,
            fill: "#1c2f40",
            children: "THREADLINE",
          }),
          e.jsx(r, {
            x: 216,
            y: 46,
            size: 8,
            anchor: "end",
            weight: 400,
            fill: "#46515b",
            children: "Checkout",
          }),
          e.jsx("path", { d: "M11 54 H225", stroke: "#bac3cb" }),
          e.jsx("rect", {
            x: 18,
            y: 60,
            width: 26,
            height: 26,
            rx: 3,
            fill: "#bac3cb",
          }),
          e.jsx(pt, { x: 18, y: 63, fill: "#326e8e" }),
          e.jsx(r, {
            x: 52,
            y: 77,
            size: 8,
            fill: "#111b23",
            children: "Denim jacket",
          }),
          e.jsx(r, {
            x: 216,
            y: 77,
            size: 8,
            anchor: "end",
            fill: "#111b23",
            children: "£65.00",
          }),
          e.jsx("rect", {
            x: 18,
            y: 92,
            width: 26,
            height: 26,
            rx: 3,
            fill: "#bac3cb",
          }),
          e.jsx(pt, { x: 18, y: 95, fill: "#cb5651" }),
          e.jsx(r, {
            x: 52,
            y: 109,
            size: 8,
            fill: "#111b23",
            children: "Silk top",
          }),
          e.jsx(r, {
            x: 216,
            y: 109,
            size: 8,
            anchor: "end",
            fill: "#111b23",
            children: "£24.00",
          }),
          e.jsx("path", { d: "M11 126 H225", stroke: "#bac3cb" }),
          e.jsx(r, {
            x: 18,
            y: 142,
            size: 8,
            fill: "#111b23",
            children: "Promo code",
          }),
          e.jsx("rect", {
            x: 18,
            y: 147,
            width: 198,
            height: 24,
            fill: "#e3e9ee",
            stroke: "#cb5651",
            strokeWidth: 3,
          }),
          e.jsx(p, {
            x: 25,
            y: 163,
            size: 11.5,
            fill: "#ac3a38",
            children: "' OR 1=1; --",
          }),
          e.jsx("path", {
            d: "M112 151 V167",
            stroke: "#111b23",
            strokeWidth: 1.2,
            className: "attack-flash",
          }),
          e.jsx("rect", {
            x: 18,
            y: 180,
            width: 64,
            height: 22,
            rx: 3,
            fill: "#54697c",
          }),
          e.jsx(r, {
            x: 50,
            y: 194.5,
            size: 8.5,
            anchor: "middle",
            fill: "#e3e9ee",
            children: "Apply",
          }),
          e.jsx(Ge, { x: 70, y: 190 }),
          e.jsx(r, {
            x: 216,
            y: 195,
            size: 9,
            anchor: "end",
            fill: "#111b23",
            children: "Total £89.00",
          }),
        ],
      }),
      e.jsx(L, { d: "M226 159 C244 159 240 52 256 52" }),
      e.jsx("path", { d: "M252 46 l8 6 l-8 6z", fill: "#cb5651" }),
      e.jsx("rect", { x: 264, y: 20, width: 110, height: 52, fill: "#333e48" }),
      e.jsx("ellipse", { cx: 319, cy: 72, rx: 55, ry: 12, fill: "#333e48" }),
      e.jsx("path", {
        d: "M264 44 a55 12 0 0 0 110 0",
        fill: "none",
        stroke: "#242f38",
        strokeWidth: 2,
      }),
      e.jsx("ellipse", {
        cx: 319,
        cy: 20,
        rx: 55,
        ry: 12,
        fill: "#46515b",
        stroke: "#cb5651",
        strokeWidth: 2,
        className: "attack-flash-stroke",
      }),
      e.jsx(r, {
        x: 319,
        y: 64,
        size: 9,
        anchor: "middle",
        fill: "#bac3cb",
        children: "CUSTOMERS",
      }),
      e.jsx(oe, {
        x: 244,
        y: 92,
        r: -3,
        name: "A. Lee",
        addr: "4 Elm Rd, Leeds",
      }),
      e.jsx(oe, {
        x: 247,
        y: 116,
        r: 2,
        name: "J. Byrne",
        addr: "17 Kay St, Hull",
      }),
      e.jsx(oe, {
        x: 242,
        y: 140,
        r: -2,
        name: "S. Ali",
        addr: "2 Vale Cl, Derby",
      }),
      e.jsx(oe, {
        x: 245,
        y: 164,
        r: 3,
        name: "M. Chen",
        addr: "9 Oak Way, Bath",
      }),
      e.jsx("rect", {
        x: 240,
        y: 196,
        width: 152,
        height: 30,
        rx: 4,
        fill: "#480004",
      }),
      e.jsx(p, {
        x: 316,
        y: 215,
        size: 10,
        fill: "#ffa79f",
        anchor: "middle",
        children: "25,000,000 rows",
      }),
    ],
  });
}
function hs() {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#0d171f" }),
      e.jsx("path", {
        d: "M8 196 V130 q0 -10 10 -10 h62 l22 30 v46z",
        fill: "#242f38",
      }),
      e.jsx("rect", {
        x: 20,
        y: 128,
        width: 30,
        height: 18,
        rx: 2,
        fill: "#333e48",
      }),
      e.jsx("circle", { cx: 30, cy: 196, r: 10, fill: "#0d171f" }),
      e.jsx("circle", { cx: 86, cy: 196, r: 10, fill: "#0d171f" }),
      e.jsx(Ke, { x: 112, y: 128, s: 0.62 }),
      e.jsx("rect", {
        x: 128,
        y: 146,
        width: 12,
        height: 22,
        rx: 3,
        fill: "#111b23",
        stroke: "#5c6873",
      }),
      e.jsx("rect", {
        x: 12,
        y: 12,
        width: 196,
        height: 72,
        rx: 10,
        fill: "#e3e9ee",
      }),
      e.jsx("path", { d: "M104 84 l14 22 l6 -22z", fill: "#e3e9ee" }),
      e.jsx(r, {
        x: 110,
        y: 32,
        size: 10,
        anchor: "middle",
        fill: "#111b23",
        children: "It's the courier depot.",
      }),
      e.jsx(r, {
        x: 110,
        y: 50,
        size: 10,
        anchor: "middle",
        fill: "#111b23",
        children: "Our system has crashed!",
      }),
      e.jsx(r, {
        x: 110,
        y: 72,
        size: 11,
        anchor: "middle",
        fill: "#ac3a38",
        children: "Email me today's list NOW",
      }),
      e.jsx("rect", { x: 220, y: 0, width: 180, height: 240, fill: "#19232c" }),
      e.jsx("rect", { x: 232, y: 12, width: 40, height: 34, fill: "#e3e9ee" }),
      e.jsx("rect", { x: 232, y: 12, width: 40, height: 11, fill: "#cb5651" }),
      e.jsx(r, {
        x: 252,
        y: 41,
        size: 11,
        anchor: "middle",
        fill: "#111b23",
        children: "20",
      }),
      e.jsx(r, {
        x: 252,
        y: 21,
        size: 7,
        anchor: "middle",
        fill: "#e3e9ee",
        children: "DEC",
      }),
      e.jsxs(f, {
        x: 282,
        y: 10,
        w: 110,
        h: 112,
        bar: "#1c2f40",
        children: [
          e.jsx(r, {
            x: 288,
            y: 38,
            size: 8,
            fill: "#111b23",
            children: "Delivery list",
          }),
          e.jsx(p, {
            x: 288,
            y: 54,
            size: 7.5,
            fill: "#333e48",
            children: "14 Oak St, York",
          }),
          e.jsx(p, {
            x: 288,
            y: 67,
            size: 7.5,
            fill: "#333e48",
            children: "2 Mill Ln, Bath",
          }),
          e.jsx(p, {
            x: 288,
            y: 80,
            size: 7.5,
            fill: "#333e48",
            children: "9 Park Rd, Hull",
          }),
          e.jsx(p, {
            x: 288,
            y: 93,
            size: 7.5,
            fill: "#95a1ac",
            children: "+ 39,997 more",
          }),
          e.jsx("rect", {
            x: 288,
            y: 100,
            width: 64,
            height: 16,
            rx: 3,
            fill: "#cb5651",
          }),
          e.jsx(r, {
            x: 320,
            y: 111.5,
            size: 7.5,
            anchor: "middle",
            fill: "#e3e9ee",
            children: "Send list",
          }),
          e.jsx(Ge, { x: 340, y: 106 }),
        ],
      }),
      e.jsx("path", {
        d: "M244 240 C246 192 274 178 306 178 C338 178 366 192 368 240z",
        fill: "#54697c",
      }),
      e.jsx("circle", { cx: 306, cy: 156, r: 22, fill: "#8d5524" }),
      e.jsx("path", {
        d: "M284 152 a22 22 0 0 1 44 0 q-22 -14 -44 0z",
        fill: "#111b23",
      }),
      e.jsx("path", {
        d: "M282 154 a24 24 0 0 1 48 0",
        fill: "none",
        stroke: "#111b23",
        strokeWidth: 3,
      }),
      e.jsx("rect", {
        x: 278,
        y: 150,
        width: 7,
        height: 14,
        rx: 3,
        fill: "#111b23",
      }),
      e.jsx("path", {
        d: "M282 162 q4 12 16 12",
        fill: "none",
        stroke: "#111b23",
        strokeWidth: 2,
      }),
      e.jsx("circle", { cx: 298, cy: 157, r: 2, fill: "#111b23" }),
      e.jsx("circle", { cx: 314, cy: 157, r: 2, fill: "#111b23" }),
      e.jsx("path", {
        d: "M300 168 q6 -3 12 0",
        fill: "none",
        stroke: "#111b23",
        strokeWidth: 1.5,
      }),
      e.jsx("path", {
        d: "M332 140 q4 6 0 10",
        fill: "none",
        stroke: "#8ecbee",
        strokeWidth: 2,
      }),
      e.jsx("rect", {
        x: 220,
        y: 200,
        width: 180,
        height: 40,
        fill: "#1c2f40",
      }),
      e.jsx("rect", { x: 228, y: 182, width: 26, height: 18, fill: "#746351" }),
      e.jsx("rect", { x: 366, y: 176, width: 26, height: 24, fill: "#746351" }),
      e.jsx("rect", { x: 228, y: 189, width: 26, height: 3, fill: "#746351" }),
      e.jsx("rect", { x: 366, y: 186, width: 26, height: 3, fill: "#746351" }),
      e.jsx(L, { d: "M208 48 C240 48 250 110 282 110" }),
    ],
  });
}
function _e({ cx: i, skin: t }) {
  return e.jsxs("g", {
    children: [
      e.jsx("path", {
        d: `M${i - 15} 214 v-30 a15 15 0 0 1 30 0 v30z`,
        fill: "#e8ba61",
      }),
      e.jsx("path", {
        d: `M${i - 15} 196 h30 M${i - 15} 204 h30`,
        stroke: "#bac3cb",
        strokeWidth: 2,
      }),
      e.jsx("circle", { cx: i, cy: 160, r: 10, fill: t }),
    ],
  });
}
function os() {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#0d171f" }),
      [30, 80, 130].map((i) =>
        e.jsxs(
          "g",
          {
            children: [
              e.jsx("rect", {
                x: 10,
                y: i + 36,
                width: 190,
                height: 5,
                fill: "#cb5651",
              }),
              [18, 54, 92, 130, 166].map((t, s) =>
                e.jsx(
                  "rect",
                  {
                    x: t,
                    y: i + 36 - (s % 2 ? 22 : 28),
                    width: s % 2 ? 26 : 30,
                    height: s % 2 ? 22 : 28,
                    fill: (s % 2, "#746351"),
                  },
                  t,
                ),
              ),
            ],
          },
          i,
        ),
      ),
      e.jsx("path", {
        d: "M12 20 V172 M198 20 V172",
        stroke: "#ac3a38",
        strokeWidth: 4,
      }),
      e.jsx("rect", { x: 0, y: 214, width: 400, height: 26, fill: "#242f38" }),
      e.jsx("circle", {
        cx: 232,
        cy: 36,
        r: 20,
        fill: "#e3e9ee",
        stroke: "#333e48",
        strokeWidth: 3,
      }),
      e.jsx("path", {
        d: "M232 36 V20 M232 36 L222 30",
        stroke: "#111b23",
        strokeWidth: 2.5,
        strokeLinecap: "round",
      }),
      e.jsx(r, {
        x: 232,
        y: 72,
        size: 10,
        anchor: "middle",
        fill: "#bac3cb",
        children: "22:00",
      }),
      e.jsx(_e, { cx: 42, skin: "#c68642" }),
      e.jsx(_e, { cx: 78, skin: "#f1c27d" }),
      e.jsx("rect", { x: 100, y: 174, width: 10, height: 40, fill: "#95a1ac" }),
      e.jsx("path", {
        d: "M110 186 h28 M110 186 l20 12",
        stroke: "#bac3cb",
        strokeWidth: 3,
      }),
      e.jsx("rect", { x: 104, y: 168, width: 6, height: 6, fill: "#7ed99f" }),
      e.jsx(_e, { cx: 146, skin: "#8d5524" }),
      e.jsx(L, { d: "M168 206 C210 206 230 200 296 200" }),
      e.jsx("rect", {
        x: 260,
        y: 20,
        width: 132,
        height: 194,
        fill: "#242f38",
      }),
      e.jsx("rect", {
        x: 266,
        y: 30,
        width: 64,
        height: 18,
        rx: 2,
        fill: "#cb5651",
      }),
      e.jsx(r, {
        x: 298,
        y: 43,
        size: 9,
        anchor: "middle",
        fill: "#e3e9ee",
        children: "IT ROOM",
      }),
      e.jsx("rect", { x: 266, y: 56, width: 64, height: 158, fill: "#0d171f" }),
      e.jsx("rect", {
        x: 276,
        y: 70,
        width: 44,
        height: 86,
        rx: 3,
        fill: "#333e48",
      }),
      e.jsx("rect", { x: 281, y: 77, width: 34, height: 12, fill: "#46515b" }),
      e.jsx("rect", {
        x: 281,
        y: 94,
        width: 34,
        height: 12,
        fill: "#0d171f",
        stroke: "#cb5651",
        className: "attack-flash-stroke",
      }),
      e.jsx("rect", {
        x: 281,
        y: 111,
        width: 34,
        height: 12,
        fill: "#0d171f",
        stroke: "#cb5651",
        className: "attack-flash-stroke",
      }),
      e.jsx("rect", { x: 281, y: 128, width: 34, height: 12, fill: "#46515b" }),
      e.jsx("path", { d: "M330 56 l20 10 v140 l-20 8z", fill: "#46515b" }),
      e.jsx("path", {
        d: "M326 214 C328 176 344 164 364 164 C384 164 398 176 398 214z",
        fill: "#54697c",
      }),
      e.jsx("path", {
        d: "M346 128 C346 104 382 104 382 128 C382 146 374 156 364 156 C354 156 346 146 346 128z",
        fill: "#54697c",
      }),
      e.jsx("ellipse", { cx: 364, cy: 132, rx: 12, ry: 15, fill: "#111b23" }),
      e.jsx(r, {
        x: 364,
        y: 182,
        size: 7,
        anchor: "middle",
        fill: "#bac3cb",
        children: "THREADLINE",
      }),
      e.jsx("rect", { x: 340, y: 192, width: 14, height: 9, fill: "#95a1ac" }),
      e.jsx("rect", { x: 358, y: 190, width: 14, height: 11, fill: "#95a1ac" }),
      e.jsx("rect", {
        x: 334,
        y: 199,
        width: 48,
        height: 15,
        rx: 3,
        fill: "#111b23",
      }),
      e.jsx(r, {
        x: 358,
        y: 210,
        size: 7.5,
        anchor: "middle",
        fill: "#ffa79f",
        children: "BACKUP",
      }),
    ],
  });
}
function ne({ x: i, fill: t, long: s }) {
  return e.jsxs("g", {
    children: [
      e.jsx("path", {
        d: `M${i} 64 v4 l-10 6 h20z`,
        fill: "none",
        stroke: "#95a1ac",
        strokeWidth: 1.5,
      }),
      e.jsx("path", {
        d: `M${i - 10} 74 h20 l4 ${s ? 56 : 34} h-28z`,
        fill: t,
      }),
    ],
  });
}
function ns() {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#0d171f" }),
      e.jsx("rect", { x: 0, y: 0, width: 400, height: 30, fill: "#54697c" }),
      e.jsx(r, {
        x: 200,
        y: 20,
        size: 13,
        anchor: "middle",
        fill: "#e3e9ee",
        children: "THREADLINE POP-UP",
      }),
      e.jsx("path", {
        d: "M156 64 H392 M162 64 V180 M388 64 V180",
        stroke: "#95a1ac",
        strokeWidth: 3,
      }),
      e.jsx(ne, { x: 184, fill: "#cb5651", long: !0 }),
      e.jsx(ne, { x: 214, fill: "#e8ba61" }),
      e.jsx(ne, { x: 244, fill: "#326e8e", long: !0 }),
      e.jsx(ne, { x: 366, fill: "#399661", long: !0 }),
      e.jsx("path", {
        d: "M296 200 C298 160 316 150 340 150 C364 150 380 160 382 200z",
        fill: "#46515b",
      }),
      e.jsx("circle", { cx: 340, cy: 124, r: 16, fill: "#f1c27d" }),
      e.jsx("path", {
        d: "M324 120 a16 16 0 0 1 32 0 q-16 -9 -32 0z",
        fill: "#333e48",
      }),
      e.jsx("circle", { cx: 333, cy: 125, r: 2, fill: "#111b23" }),
      e.jsx("path", {
        d: "M322 168 C310 150 302 128 296 112",
        stroke: "#f1c27d",
        strokeWidth: 7,
        strokeLinecap: "round",
        fill: "none",
      }),
      e.jsx("rect", {
        x: 284,
        y: 84,
        width: 22,
        height: 36,
        rx: 3,
        fill: "#111b23",
        stroke: "#5c6873",
      }),
      e.jsx("circle", {
        cx: 295,
        cy: 92,
        r: 3,
        fill: "#cb5651",
        className: "attack-flash",
      }),
      e.jsx(L, { d: "M284 106 C258 116 240 130 226 148" }),
      e.jsx("path", {
        d: "M160 240 C162 186 184 172 210 172 C236 172 258 186 260 240z",
        fill: "#242f38",
      }),
      e.jsx("path", {
        d: "M198 174 l12 26 l12 -26",
        fill: "none",
        stroke: "#54697c",
        strokeWidth: 3,
      }),
      e.jsx("rect", {
        x: 204,
        y: 198,
        width: 12,
        height: 16,
        rx: 2,
        fill: "#e3e9ee",
      }),
      e.jsx("circle", { cx: 210, cy: 146, r: 20, fill: "#8d5524" }),
      e.jsx("path", {
        d: "M190 142 a20 20 0 0 1 40 0 q-20 -14 -40 0z",
        fill: "#0d171f",
      }),
      e.jsx("circle", { cx: 203, cy: 148, r: 2, fill: "#111b23" }),
      e.jsx("circle", { cx: 217, cy: 148, r: 2, fill: "#111b23" }),
      e.jsx("rect", {
        x: 130,
        y: 206,
        width: 270,
        height: 34,
        fill: "#2b3f50",
      }),
      e.jsx("rect", { x: 130, y: 202, width: 270, height: 6, fill: "#8ba3b7" }),
      e.jsx("path", { d: "M180 202 l8 -40 h44 l8 40z", fill: "#333e48" }),
      e.jsx("rect", {
        x: 190,
        y: 168,
        width: 40,
        height: 30,
        rx: 3,
        fill: "#46515b",
      }),
      e.jsx("rect", {
        x: 14,
        y: 42,
        width: 118,
        height: 186,
        rx: 12,
        fill: "#111b23",
        stroke: "#cb5651",
        strokeWidth: 2,
      }),
      e.jsx("rect", {
        x: 22,
        y: 56,
        width: 102,
        height: 158,
        rx: 4,
        fill: "#242f38",
      }),
      e.jsx(_t, { x: 32, y: 68 }),
      e.jsx("rect", {
        x: 30,
        y: 80,
        width: 86,
        height: 58,
        rx: 3,
        fill: "#e3e9ee",
      }),
      e.jsx("rect", {
        x: 30,
        y: 80,
        width: 86,
        height: 14,
        rx: 3,
        fill: "#2b3f50",
      }),
      e.jsx(r, {
        x: 73,
        y: 90.5,
        size: 7.5,
        anchor: "middle",
        fill: "#e3e9ee",
        children: "Admin login",
      }),
      e.jsx("rect", {
        x: 36,
        y: 102,
        width: 74,
        height: 14,
        rx: 2,
        fill: "#e3e9ee",
        stroke: "#cb5651",
      }),
      e.jsx(p, {
        x: 73,
        y: 112,
        size: 8,
        fill: "#ac3a38",
        anchor: "middle",
        children: "Tl-Admin#24",
      }),
      e.jsx("rect", {
        x: 52,
        y: 122,
        width: 42,
        height: 11,
        rx: 2,
        fill: "#54697c",
      }),
      e.jsx(r, {
        x: 73,
        y: 130.5,
        size: 7,
        anchor: "middle",
        fill: "#e3e9ee",
        children: "Log in",
      }),
      Array.from({ length: 9 }, (i, t) =>
        e.jsx(
          "rect",
          {
            x: 34 + (t % 3) * 27,
            y: 146 + Math.floor(t / 3) * 20,
            width: 22,
            height: 16,
            rx: 3,
            fill: t === 1 || t === 5 || t === 6 ? "#cb5651" : "#46515b",
            className: t === 1 || t === 5 || t === 6 ? "attack-flash" : void 0,
          },
          t,
        ),
      ),
    ],
  });
}
function gt({ x: i, y: t, k: s }) {
  return e.jsxs("g", {
    children: [
      e.jsx("rect", {
        x: i,
        y: t,
        width: 16,
        height: 16,
        rx: 3,
        fill: "#e3e9ee",
        stroke: "#95a1ac",
      }),
      e.jsx(p, {
        x: i + 8,
        y: t + 11.5,
        size: 9,
        anchor: "middle",
        children: s,
      }),
    ],
  });
}
function ds({ x: i, y: t, fill: s }) {
  return e.jsx("path", {
    d: `M${i} ${t + 4} h4 a3 3 0 0 1 6 0 h4 v4 a3 3 0 0 1 0 6 v4 h-14z`,
    fill: s,
  });
}
function xs() {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#0d171f" }),
      e.jsxs(f, {
        x: 10,
        y: 12,
        w: 234,
        h: 168,
        bar: "#1c2f40",
        children: [
          e.jsx("rect", {
            x: 11,
            y: 28,
            width: 232,
            height: 20,
            fill: "#bac3cb",
          }),
          e.jsx("rect", {
            x: 16,
            y: 32,
            width: 174,
            height: 12,
            rx: 6,
            fill: "#e3e9ee",
          }),
          e.jsx(p, {
            x: 22,
            y: 41,
            size: 7,
            fill: "#333e48",
            children: "admin.threadline.com/customer",
          }),
          e.jsx("rect", {
            x: 198,
            y: 30,
            width: 40,
            height: 16,
            rx: 3,
            fill: "#bac3cb",
            stroke: "#cb5651",
            strokeWidth: 1.5,
            className: "attack-flash-stroke",
          }),
          e.jsx(ds, { x: 203, y: 30, fill: "#cb5651" }),
          e.jsx("circle", {
            cx: 229,
            cy: 38,
            r: 4,
            fill: "#e3e9ee",
            stroke: "#111b23",
          }),
          e.jsx("circle", { cx: 229, cy: 38, r: 1.8, fill: "#111b23" }),
          e.jsx("rect", {
            x: 110,
            y: 52,
            width: 128,
            height: 15,
            rx: 3,
            fill: "#111b23",
          }),
          e.jsx(r, {
            x: 174,
            y: 62.5,
            size: 7,
            anchor: "middle",
            fill: "#d1beaa",
            children: "Size Chart Helper added",
          }),
          e.jsx(r, {
            x: 20,
            y: 84,
            size: 9,
            fill: "#111b23",
            children: "Customer #48213",
          }),
          [
            ["Name", "Priya Shah"],
            ["Address", "22 Rose St, Leeds"],
            ["Card", "**** 4417"],
            ["Orders", "12"],
          ].map(([i, t], s) =>
            e.jsxs(
              "g",
              {
                children: [
                  e.jsx(r, {
                    x: 20,
                    y: 104 + s * 18,
                    size: 7,
                    weight: 400,
                    fill: "#5c6873",
                    children: i,
                  }),
                  e.jsx("rect", {
                    x: 64,
                    y: 94 + s * 18,
                    width: 170,
                    height: 14,
                    rx: 2,
                    fill: "#e3e9ee",
                    stroke: s < 3 ? "#cb5651" : "#bac3cb",
                    strokeDasharray: s < 3 ? "3 2" : void 0,
                  }),
                  e.jsx(p, {
                    x: 69,
                    y: 104 + s * 18,
                    size: 7.5,
                    fill: "#111b23",
                    children: t,
                  }),
                ],
              },
              i,
            ),
          ),
        ],
      }),
      e.jsx("rect", {
        x: 60,
        y: 192,
        width: 140,
        height: 20,
        rx: 3,
        fill: "#333e48",
      }),
      Array.from({ length: 10 }, (i, t) =>
        e.jsx(
          "rect",
          {
            x: 65 + t * 13.4,
            y: 196,
            width: 10,
            height: 5,
            rx: 1,
            fill: "#5c6873",
          },
          t,
        ),
      ),
      e.jsx("rect", {
        x: 76,
        y: 204,
        width: 108,
        height: 5,
        rx: 1,
        fill: "#5c6873",
      }),
      e.jsx("circle", { cx: 216, cy: 226, r: 26, fill: "#111b23" }),
      e.jsx("path", {
        d: "M190 226 a26 26 0 0 1 52 0",
        fill: "none",
        stroke: "#111b23",
        strokeWidth: 5,
      }),
      e.jsx("rect", {
        x: 186,
        y: 218,
        width: 8,
        height: 16,
        rx: 3,
        fill: "#54697c",
      }),
      e.jsx(L, { d: "M238 38 C290 38 296 80 318 80" }),
      e.jsx(gt, { x: 258, y: 46, k: "P" }),
      e.jsx(gt, { x: 280, y: 58, k: "w" }),
      e.jsx("circle", { cx: 354, cy: 42, r: 28, fill: "#00425f" }),
      e.jsx("path", {
        d: "M326 42 h56 M354 14 v56 M354 14 c-16 14 -16 42 0 56 M354 14 c16 14 16 42 0 56",
        fill: "none",
        stroke: "#6ca8ca",
        strokeWidth: 1.5,
      }),
      e.jsx("rect", {
        x: 318,
        y: 74,
        width: 72,
        height: 30,
        rx: 3,
        fill: "#242f38",
        stroke: "#cb5651",
        strokeWidth: 2,
      }),
      e.jsx("circle", {
        cx: 328,
        cy: 89,
        r: 3,
        fill: "#cb5651",
        className: "attack-flash",
      }),
      e.jsx(p, {
        x: 338,
        y: 92,
        size: 7.5,
        fill: "#ffa79f",
        children: "ABROAD",
      }),
      e.jsx("rect", {
        x: 258,
        y: 116,
        width: 134,
        height: 94,
        rx: 4,
        fill: "#0d171f",
        stroke: "#333e48",
      }),
      e.jsx(p, {
        x: 266,
        y: 131,
        size: 7.5,
        fill: "#95a1ac",
        children: "SPY LOG",
      }),
      e.jsx(p, {
        x: 266,
        y: 148,
        size: 7.5,
        fill: "#7ed99f",
        children: "user k.wong",
      }),
      e.jsx(p, {
        x: 266,
        y: 163,
        size: 7.5,
        fill: "#7ed99f",
        children: "pass Spr1ng!24",
      }),
      e.jsx(p, {
        x: 266,
        y: 178,
        size: 7.5,
        fill: "#7ed99f",
        children: "Priya Shah",
      }),
      e.jsx(p, {
        x: 266,
        y: 193,
        size: 7.5,
        fill: "#7ed99f",
        children: "22 Rose St, Leeds",
      }),
      e.jsx(L, { d: "M354 104 V116" }),
    ],
  });
}
const fs = {
  civil_phishing: {
    Art: ts,
    bg: "#0d171f",
    alt: "A tax officer’s inbox shows a fake Cabinet Office email offering a £500 bonus from a lookalike address, and clicking Log in to claim opens a fake staff sign in page that sends the password to a hooded attacker with an armful of tax records.",
  },
  civil_brute_force: {
    Art: is,
    bg: "#0d171f",
    alt: "A guessing bot works through password after password on a citizen’s online tax account until Rex2015 works on the 48,211th try, then swaps the refund bank details so a £1,240 April tax refund goes to a hooded criminal.",
  },
  civil_interception: {
    Art: ss,
    bg: "#0d171f",
    alt: "At night, scanned birth certificates and photos travel along a buried line from the passport office to the print centre, while a criminal’s laptop wired into an opened street cabinet captures every one.",
  },
  civil_shouldering: {
    Art: ls,
    bg: "#0d171f",
    alt: "At airport Gate B22, with a plane waiting outside the window and the departures board flashing final call for Geneva, a Digital Identity Office manager signs into the Passport records system on a work laptop while a traveller standing behind the seats films the keyboard on a phone, recording the password Border#26.",
  },
  civil_ransomware: {
    Art: as,
    bg: "#0d171f",
    alt: "In June, with 500,000 passports waiting, a fake printer driver locks the passport printing line, the control screen demands £8m and half-finished passports sit in the stopped machine’s tray.",
  },
  threadline_sql_injection: {
    Art: cs,
    bg: "#0d171f",
    alt: "Someone types an SQL command into the promo code box at the Threadline checkout, and the customer database spills out names and home addresses, 25 million rows in all.",
  },
  threadline_blagging: {
    Art: hs,
    bg: "#0d171f",
    alt: "A hooded caller beside an unmarked van pretends to be the courier depot and demands today’s delivery list, while a worried dispatcher in a headset hovers over the Send list button on 20 December.",
  },
  threadline_warehouse_theft: {
    Art: os,
    bg: "#0d171f",
    alt: "At the 10pm shift change, a stranger in a Threadline hoodie slips through the warehouse turnstile behind the workers and walks out of the open IT room with a bag of backup drives.",
  },
  threadline_shouldering: {
    Art: ns,
    bg: "#0d171f",
    alt: "At the Threadline pop-up shop, a shopper by the clothes rail holds a phone over the store manager’s shoulder and records the admin password being typed into the counter tablet.",
  },
  threadline_spyware: {
    Art: xs,
    bg: "#0d171f",
    alt: "A Size Chart Helper browser add-on secretly records a customer service agent’s keys and the customer record on screen, sending the login, name and address to a server abroad.",
  },
};
function M({
  x: i,
  y: t,
  size: s = 8,
  fill: l = "#111b23",
  anchor: a = "start",
  children: c,
}) {
  return e.jsx("text", {
    x: i,
    y: t,
    fontSize: s,
    fill: l,
    fontWeight: 700,
    textAnchor: a,
    fontFamily: "'Courier New', Courier, monospace",
    children: c,
  });
}
function Je({ x: i, y: t }) {
  return e.jsx("path", {
    d: `M${i} ${t} l0 18 l5 -5 l4 9 l4 -2 l-4 -9 l7 0z`,
    fill: "#e3e9ee",
    stroke: "#111b23",
    strokeWidth: 1.2,
    strokeLinejoin: "round",
  });
}
function js({ x: i, y: t, s = 1, fill: l }) {
  return e.jsxs("g", {
    transform: `translate(${i} ${t}) scale(${s})`,
    children: [
      e.jsx("path", {
        d: "M-6 -2v-4a6 6 0 0 1 12 0v4",
        fill: "none",
        stroke: l,
        strokeWidth: 2.6,
      }),
      e.jsx("rect", { x: -9, y: -3, width: 18, height: 14, rx: 2.5, fill: l }),
    ],
  });
}
function we({ x: i, y: t, s = 1, fill: l }) {
  return e.jsxs("g", {
    transform: `translate(${i} ${t}) scale(${s})`,
    children: [
      e.jsx("circle", { cx: 0, cy: -4, r: 2.6, fill: l }),
      e.jsx("rect", { x: -1.5, y: -2, width: 3, height: 24, fill: l }),
      e.jsx("rect", { x: -9, y: 21, width: 18, height: 4, rx: 1.5, fill: l }),
      e.jsx("rect", {
        x: -16,
        y: -1,
        width: 32,
        height: 2.6,
        rx: 1.3,
        fill: l,
      }),
      e.jsx("path", {
        d: "M-14 1 L-20 13 M-14 1 L-8 13 M14 1 L8 13 M14 1 L20 13",
        stroke: l,
        strokeWidth: 1,
        fill: "none",
      }),
      e.jsx("path", {
        d: "M-22 13 h16 a8 5 0 0 1 -16 0z M6 13 h16 a8 5 0 0 1 -16 0z",
        fill: l,
      }),
    ],
  });
}
function R({ x: i, y: t, s = 1 }) {
  return e.jsxs("g", {
    transform: `translate(${i} ${t}) scale(${s})`,
    children: [
      e.jsx("rect", {
        x: -10,
        y: -10,
        width: 20,
        height: 20,
        rx: 6,
        fill: "#54697c",
      }),
      e.jsx("path", {
        d: "M-3.5 -5.5 L6 0 L-3.5 5.5z",
        fill: "#7ed99f",
        strokeLinejoin: "round",
      }),
    ],
  });
}
function ys() {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#111b23" }),
      e.jsx("rect", { x: 0, y: 132, width: 400, height: 56, fill: "#19232c" }),
      [40, 80, 120, 160].map((i) =>
        e.jsx(
          "path",
          { d: `M${i} 136 V186`, stroke: "#242f38", strokeWidth: 2 },
          i,
        ),
      ),
      e.jsx("rect", { x: 0, y: 130, width: 400, height: 4, fill: "#333e48" }),
      e.jsxs(f, {
        x: 8,
        y: 8,
        w: 152,
        h: 98,
        bar: "#333e48",
        children: [
          e.jsx(r, {
            x: 16,
            y: 36,
            size: 7.5,
            weight: 400,
            fill: "#46515b",
            children: "From: Client Share",
          }),
          e.jsx(r, {
            x: 16,
            y: 46,
            size: 6.5,
            weight: 400,
            fill: "#ac3a38",
            children: "share@hv-clientdocs.net",
          }),
          e.jsx(r, { x: 16, y: 62, size: 9, children: "Confidential" }),
          e.jsx(r, { x: 16, y: 73, size: 9, children: "document shared" }),
          e.jsx("rect", {
            x: 16,
            y: 81,
            width: 78,
            height: 17,
            rx: 3,
            fill: "#326e8e",
          }),
          e.jsx(r, {
            x: 55,
            y: 92.5,
            size: 7.5,
            anchor: "middle",
            fill: "#e3e9ee",
            children: "Log in to view",
          }),
          e.jsx("path", {
            d: "M124 28 h18 l7 7 v32 h-25z",
            fill: "#bac3cb",
            stroke: "#95a1ac",
          }),
          e.jsx("path", {
            d: "M142 28 v7 h7",
            fill: "none",
            stroke: "#95a1ac",
          }),
          [40, 46, 52].map((i) =>
            e.jsx(
              "rect",
              { x: 128, y: i, width: 16, height: 2.5, rx: 1, fill: "#95a1ac" },
              i,
            ),
          ),
          e.jsx("circle", { cx: 136, cy: 60, r: 5.5, fill: "#ac3a38" }),
          e.jsx("circle", {
            cx: 136,
            cy: 60,
            r: 3,
            fill: "none",
            stroke: "#d1beaa",
            strokeWidth: 1,
          }),
          e.jsx(Je, { x: 62, y: 88 }),
        ],
      }),
      e.jsx("rect", {
        x: 168,
        y: 4,
        width: 226,
        height: 154,
        rx: 6,
        fill: "#111b23",
      }),
      e.jsxs(f, {
        x: 174,
        y: 10,
        w: 214,
        h: 142,
        bar: "#5c6873",
        children: [
          e.jsx("rect", {
            x: 175,
            y: 26,
            width: 212,
            height: 15,
            fill: "#bac3cb",
          }),
          e.jsx(r, {
            x: 281,
            y: 36.5,
            size: 7.5,
            weight: 400,
            anchor: "middle",
            fill: "#ac3a38",
            children: "harcourtvale.docs-login.co",
          }),
          e.jsx(we, { x: 281, y: 54, s: 0.8, fill: "#746351" }),
          e.jsx(r, {
            x: 281,
            y: 88,
            size: 11,
            anchor: "middle",
            fill: "#00425f",
            children: "Harcourt & Vale",
          }),
          e.jsx("rect", {
            x: 194,
            y: 95,
            width: 174,
            height: 14,
            rx: 3,
            fill: "#e3e9ee",
            stroke: "#95a1ac",
          }),
          e.jsx(r, {
            x: 199,
            y: 105,
            size: 7,
            weight: 400,
            fill: "#333e48",
            children: "e.marsh@harcourtvale.com",
          }),
          e.jsx("rect", {
            x: 194,
            y: 112,
            width: 174,
            height: 14,
            rx: 3,
            fill: "#e3e9ee",
            stroke: "#cb5651",
            strokeWidth: 1.5,
          }),
          e.jsx(r, {
            x: 199,
            y: 122.5,
            size: 8,
            fill: "#333e48",
            children: "• • • • •",
          }),
          e.jsx("path", {
            d: "M232 115 V123",
            stroke: "#111b23",
            strokeWidth: 1.2,
            className: "attack-flash",
          }),
          e.jsx("rect", {
            x: 243,
            y: 131,
            width: 76,
            height: 15,
            rx: 3,
            fill: "#00425f",
          }),
          e.jsx(r, {
            x: 281,
            y: 141.5,
            size: 7.5,
            anchor: "middle",
            fill: "#e3e9ee",
            children: "Log in to view",
          }),
        ],
      }),
      e.jsx("path", {
        d: "M96 90 C150 90 160 119 194 119",
        fill: "none",
        stroke: "#ee766f",
        strokeWidth: 1.8,
        strokeDasharray: "4 4",
        className: "attack-flow",
      }),
      e.jsx("rect", { x: 272, y: 158, width: 18, height: 22, fill: "#333e48" }),
      e.jsx("rect", {
        x: 256,
        y: 178,
        width: 50,
        height: 7,
        rx: 2,
        fill: "#333e48",
      }),
      e.jsx("rect", { x: 0, y: 185, width: 400, height: 9, fill: "#5c4d3b" }),
      e.jsx("rect", { x: 0, y: 194, width: 400, height: 46, fill: "#242f38" }),
      e.jsx("path", { d: "M0 214 H400", stroke: "#19232c", strokeWidth: 2 }),
      e.jsx("path", { d: "M186 185 L194 177 H262 L268 185z", fill: "#bac3cb" }),
      e.jsx("path", {
        d: "M196 181 H262",
        stroke: "#95a1ac",
        strokeWidth: 1.2,
        strokeDasharray: "3 2",
      }),
      e.jsx(we, { x: 354, y: 162, s: 0.85, fill: "#c4973c" }),
      [
        ["#e8ba61", "#746351"],
        ["#ac3a38", "#901e21"],
        ["#e8ba61", "#746351"],
        ["#00425f", "#003249"],
        ["#e8ba61", "#746351"],
      ].map(([i, t], s) =>
        e.jsxs(
          "g",
          {
            children: [
              e.jsx("rect", {
                x: 8 + (s % 2) * 3,
                y: 177 - s * 8,
                width: 48,
                height: 8,
                rx: 1,
                fill: i,
                stroke: t,
              }),
              e.jsx("rect", {
                x: 14 + (s % 3) * 10,
                y: 175 - s * 8,
                width: 10,
                height: 3,
                rx: 1,
                fill: t,
              }),
            ],
          },
          s,
        ),
      ),
      e.jsx("rect", {
        x: 14,
        y: 140,
        width: 34,
        height: 6,
        fill: "#ac3a38",
        transform: "rotate(-8 30 143)",
      }),
      e.jsx("rect", {
        x: 58,
        y: 110,
        width: 30,
        height: 84,
        rx: 8,
        fill: "#77000e",
      }),
      e.jsx("path", {
        d: "M72 194 L74 152 q2 -14 18 -15 h18 q14 2 16 18 l2 39z",
        fill: "#242f38",
      }),
      e.jsx("path", { d: "M112 137 h9 q4 2 4 8 l-10 14z", fill: "#e3e9ee" }),
      e.jsx("path", {
        d: "M118 140 l3 2 l-1 16 l-3 4 l-2 -4z",
        fill: "#ac3a38",
      }),
      e.jsx("rect", { x: 98, y: 128, width: 11, height: 11, fill: "#d6a77a" }),
      e.jsx("circle", { cx: 104, cy: 118, r: 15, fill: "#d6a77a" }),
      e.jsx("path", {
        d: "M118 118 l3 5 l-3 1",
        fill: "#d6a77a",
        stroke: "#8f7e6b",
        strokeWidth: 1,
      }),
      e.jsx("path", {
        d: "M89 120 a15 15 0 0 1 28 -9 q-10 -2 -16 2 q-3 6 -2 12 l-6 4z",
        fill: "#242f38",
      }),
      e.jsx("circle", { cx: 112, cy: 116, r: 1.6, fill: "#111b23" }),
      e.jsx("path", { d: "M108 112 h7", stroke: "#242f38", strokeWidth: 1.4 }),
      e.jsx("path", {
        d: "M98 150 L130 176 L188 180",
        fill: "none",
        stroke: "#242f38",
        strokeWidth: 10,
        strokeLinecap: "round",
        strokeLinejoin: "round",
      }),
      e.jsx("rect", {
        x: 180,
        y: 175,
        width: 6,
        height: 9,
        rx: 1,
        fill: "#e3e9ee",
      }),
      e.jsx("circle", { cx: 191, cy: 179, r: 5, fill: "#d6a77a" }),
    ],
  });
}
function bt({ x: i }) {
  return e.jsxs("g", {
    children: [
      e.jsx("rect", {
        x: i,
        y: 104,
        width: 20,
        height: 92,
        rx: 9,
        fill: "#326e8e",
      }),
      e.jsx("rect", {
        x: i + 3,
        y: 108,
        width: 14,
        height: 20,
        rx: 5,
        fill: "#bac3cb",
      }),
      [140, 156, 172].map((t) =>
        e.jsx(
          "circle",
          { cx: i + 10, cy: t, r: 2, fill: "#8ecbee", opacity: 0.6 },
          t,
        ),
      ),
    ],
  });
}
function ps() {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#0d171f" }),
      e.jsx("rect", { x: 0, y: 0, width: 400, height: 204, fill: "#242f38" }),
      e.jsx("rect", { x: 0, y: 0, width: 400, height: 8, fill: "#111b23" }),
      e.jsx("rect", {
        x: 30,
        y: 8,
        width: 340,
        height: 4,
        rx: 2,
        fill: "#f8e4cf",
        opacity: 0.8,
      }),
      [12, 142, 272].map((i) =>
        e.jsxs(
          "g",
          {
            children: [
              e.jsx("rect", {
                x: i,
                y: 62,
                width: 116,
                height: 58,
                rx: 10,
                fill: "#46515b",
              }),
              e.jsx("rect", {
                x: i + 4,
                y: 66,
                width: 108,
                height: 50,
                rx: 8,
                fill: "#002538",
              }),
              e.jsx("path", {
                d: `M${i + 4} 116 V100 h14 v-12 h12 v18 h16 v-24 h10 v20 h18 v-10 h14 v14 h10 v-8 h14 v18z`,
                fill: "#111b23",
              }),
              [78, 92, 104].map((t, s) =>
                e.jsx(
                  "path",
                  {
                    d: `M${i + 12 + s * 18} ${t} h${30 - s * 6}`,
                    stroke: "#e8ba61",
                    strokeWidth: 1.6,
                    strokeLinecap: "round",
                    opacity: 0.75,
                  },
                  t,
                ),
              ),
            ],
          },
          i,
        ),
      ),
      e.jsx("path", { d: "M0 50 H400", stroke: "#95a1ac", strokeWidth: 4 }),
      e.jsx("path", { d: "M0 40 H400", stroke: "#5c6873", strokeWidth: 2 }),
      [20, 140, 260, 380].map((i) =>
        e.jsx(
          "path",
          {
            d: `M${i} 36 V56 l8 6`,
            fill: "none",
            stroke: "#5c6873",
            strokeWidth: 2,
          },
          i,
        ),
      ),
      e.jsx("rect", {
        x: 160,
        y: 22,
        width: 58,
        height: 26,
        rx: 4,
        fill: "#006034",
      }),
      e.jsx("rect", {
        x: 180,
        y: 18,
        width: 18,
        height: 5,
        rx: 2,
        fill: "#2b3f50",
      }),
      e.jsx("rect", {
        x: 300,
        y: 26,
        width: 46,
        height: 22,
        rx: 3,
        fill: "#901e21",
      }),
      e.jsx("rect", {
        x: 46,
        y: 20,
        width: 64,
        height: 28,
        rx: 4,
        fill: "none",
        stroke: "#cb5651",
        strokeWidth: 1.8,
        strokeDasharray: "4 3",
        className: "attack-flash-stroke",
      }),
      e.jsx("rect", { x: 0, y: 204, width: 400, height: 36, fill: "#333e48" }),
      e.jsx("path", { d: "M0 212 H400", stroke: "#46515b", strokeWidth: 2 }),
      e.jsx(bt, { x: 6 }),
      e.jsx("rect", {
        x: 60,
        y: 164,
        width: 86,
        height: 16,
        rx: 6,
        fill: "#175675",
      }),
      e.jsx("rect", { x: 70, y: 180, width: 8, height: 24, fill: "#111b23" }),
      e.jsx("rect", { x: 128, y: 180, width: 8, height: 24, fill: "#111b23" }),
      e.jsx("path", {
        d: "M120 164 L74 164 L70 200",
        fill: "none",
        stroke: "#46515b",
        strokeWidth: 13,
      }),
      e.jsx("path", {
        d: "M62 202 h16",
        stroke: "#0d171f",
        strokeWidth: 7,
        strokeLinecap: "round",
      }),
      e.jsx("path", {
        d: "M100 166 L104 128 q2 -12 16 -12 h6 q12 2 12 16 V168z",
        fill: "#46515b",
      }),
      e.jsx("path", { d: "M104 130 q2 -8 8 -10 l4 14z", fill: "#e3e9ee" }),
      e.jsx("path", {
        d: "M109 124 l3 2 l-1 14 l-3 2 l-1 -3z",
        fill: "#54697c",
      }),
      e.jsx("circle", {
        cx: 110,
        cy: 104,
        r: 14,
        fill: "#e0ac69",
        transform: "rotate(-18 110 104)",
      }),
      e.jsx("path", {
        d: "M100 92 a14 14 0 0 1 24 4 q-8 -2 -14 0 q-6 2 -10 -4z",
        fill: "#95a1ac",
      }),
      e.jsx("path", {
        d: "M100 104 q3 2 6 0",
        fill: "none",
        stroke: "#111b23",
        strokeWidth: 1.4,
      }),
      e.jsx("path", {
        d: "M116 150 L84 158",
        stroke: "#46515b",
        strokeWidth: 9,
        strokeLinecap: "round",
      }),
      e.jsx(bt, { x: 136 }),
      e.jsx(r, { x: 78, y: 88, size: 11, fill: "#bac3cb", children: "z" }),
      e.jsx(r, { x: 66, y: 74, size: 14, fill: "#bac3cb", children: "Z" }),
      e.jsx("path", {
        d: "M110 34 C180 60 214 110 238 146",
        fill: "none",
        stroke: "#cb5651",
        strokeWidth: 2,
        strokeDasharray: "5 4",
        className: "attack-flow",
      }),
      e.jsx("path", {
        d: "M228 168 L212 206 M240 168 L262 204",
        stroke: "#111b23",
        strokeWidth: 12,
        strokeLinecap: "round",
      }),
      e.jsx("path", {
        d: "M204 208 h14 M258 206 h14",
        stroke: "#0d171f",
        strokeWidth: 7,
        strokeLinecap: "round",
      }),
      e.jsx("path", {
        d: "M214 172 L218 118 q2 -14 16 -14 h4 q14 2 16 16 l2 52z",
        fill: "#242f38",
      }),
      e.jsx("path", {
        d: "M220 114 C214 90 230 74 244 82 C256 90 254 108 248 116z",
        fill: "#333e48",
      }),
      e.jsx("path", { d: "M238 90 q10 4 8 20 l-8 2z", fill: "#111b23" }),
      e.jsx("circle", { cx: 243, cy: 100, r: 1.6, fill: "#bac3cb" }),
      e.jsx("path", {
        d: "M244 124 L262 150 L270 152",
        fill: "none",
        stroke: "#242f38",
        strokeWidth: 10,
        strokeLinecap: "round",
        strokeLinejoin: "round",
      }),
      e.jsx("path", {
        d: "M222 124 L206 156",
        stroke: "#333e48",
        strokeWidth: 10,
        strokeLinecap: "round",
      }),
      e.jsx("path", {
        d: "M262 152 q10 -12 20 0",
        fill: "none",
        stroke: "#392a1a",
        strokeWidth: 3,
      }),
      e.jsx("rect", {
        x: 250,
        y: 150,
        width: 46,
        height: 32,
        rx: 4,
        fill: "#901e21",
      }),
      e.jsx("path", { d: "M250 158 h46 v10 h-46z", fill: "#ac3a38" }),
      e.jsx("rect", {
        x: 269,
        y: 163,
        width: 8,
        height: 7,
        rx: 1,
        fill: "#e8ba61",
      }),
      e.jsx("circle", { cx: 272, cy: 150, r: 4, fill: "#c68642" }),
      e.jsx("path", {
        d: "M290 154 L304 132",
        stroke: "#ffa79f",
        strokeWidth: 1.4,
        strokeDasharray: "3 3",
      }),
      e.jsx("rect", {
        x: 292,
        y: 60,
        width: 102,
        height: 80,
        rx: 6,
        fill: "#0d171f",
        stroke: "#cb5651",
        strokeWidth: 2,
      }),
      e.jsx("rect", {
        x: 304,
        y: 68,
        width: 78,
        height: 52,
        rx: 3,
        fill: "#333e48",
      }),
      e.jsx("rect", { x: 307, y: 71, width: 72, height: 46, fill: "#e3e9ee" }),
      e.jsx("rect", {
        x: 307,
        y: 71,
        width: 72,
        height: 13,
        fill: "#cb5651",
        className: "attack-flash",
      }),
      e.jsx(r, {
        x: 343,
        y: 80.5,
        size: 7.5,
        anchor: "middle",
        fill: "#e3e9ee",
        children: "CONFIDENTIAL",
      }),
      e.jsx(r, {
        x: 311,
        y: 95,
        size: 7,
        fill: "#111b23",
        children: "Case 3105: Divorce",
      }),
      [101, 106, 111].map((i, t) =>
        e.jsx(
          "rect",
          {
            x: 311,
            y: i,
            width: t === 2 ? 40 : 62,
            height: 2.5,
            rx: 1,
            fill: "#95a1ac",
          },
          i,
        ),
      ),
      e.jsx("path", { d: "M298 120 h90 l6 10 h-102z", fill: "#5c6873" }),
    ],
  });
}
function gs({ x: i, y: t }) {
  return e.jsxs("g", {
    children: [
      e.jsx("path", {
        d: `M${i} ${t + 4} h12 l3 -4 h21 v32 h-36z`,
        fill: "#746351",
      }),
      e.jsx("rect", {
        x: i,
        y: t + 6,
        width: 36,
        height: 30,
        rx: 1.5,
        fill: "#e8ba61",
      }),
      e.jsx("rect", {
        x: i + 4,
        y: t + 10,
        width: 18,
        height: 3,
        rx: 1,
        fill: "#746351",
      }),
      e.jsx(js, { x: i + 18, y: t + 24, s: 0.75, fill: "#ac3a38" }),
    ],
  });
}
function bs() {
  const i = [
    "Case 4471: Merger",
    "Case 2208: Divorce",
    "Case 3915: Libel",
    "Case 1187: Probate",
    "Case 5032: Custody",
  ];
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#0d171f" }),
      e.jsx("rect", {
        x: 12,
        y: 10,
        width: 228,
        height: 160,
        rx: 6,
        fill: "#242f38",
      }),
      e.jsx("rect", {
        x: 20,
        y: 18,
        width: 212,
        height: 144,
        rx: 2,
        fill: "#901e21",
        className: "attack-flash",
      }),
      e.jsxs("g", {
        transform: "translate(126 50)",
        children: [
          e.jsx("path", {
            d: "M-12 -4v-8a12 12 0 0 1 24 0v8",
            fill: "none",
            stroke: "#d1beaa",
            strokeWidth: 5,
          }),
          e.jsx("rect", {
            x: -18,
            y: -6,
            width: 36,
            height: 28,
            rx: 5,
            fill: "#d1beaa",
          }),
          e.jsx("circle", { cx: 0, cy: 6, r: 4, fill: "#901e21" }),
        ],
      }),
      e.jsx(r, {
        x: 126,
        y: 98,
        size: 16,
        anchor: "middle",
        fill: "#e3e9ee",
        children: "PAY OR WE PUBLISH",
      }),
      e.jsx(r, {
        x: 126,
        y: 115,
        size: 8.5,
        anchor: "middle",
        weight: 400,
        fill: "#d1beaa",
        children: "2.1 TB of client files stolen",
      }),
      e.jsx("rect", {
        x: 78,
        y: 124,
        width: 96,
        height: 26,
        rx: 3,
        fill: "#480004",
      }),
      e.jsx(M, {
        x: 126,
        y: 142,
        size: 15,
        anchor: "middle",
        fill: "#ffa79f",
        children: "47:59:12",
      }),
      e.jsx("rect", { x: 116, y: 170, width: 20, height: 10, fill: "#333e48" }),
      e.jsx("rect", {
        x: 96,
        y: 180,
        width: 60,
        height: 5,
        rx: 2,
        fill: "#333e48",
      }),
      e.jsx("path", {
        d: "M126 185 V190 M30 190 H222",
        fill: "none",
        stroke: "#cb5651",
        strokeWidth: 1.6,
        strokeDasharray: "4 4",
        className: "attack-flow",
      }),
      [14, 58, 102, 146, 190].map((t) => e.jsx(gs, { x: t, y: 196 }, t)),
      e.jsx("path", {
        d: "M240 54 H252 M240 130 H252",
        stroke: "#cb5651",
        strokeWidth: 2,
        strokeDasharray: "4 3",
        className: "attack-flow",
      }),
      e.jsx("rect", {
        x: 252,
        y: 10,
        width: 140,
        height: 222,
        rx: 5,
        fill: "#0d171f",
        stroke: "#333e48",
      }),
      e.jsx("path", {
        d: "M252 15 a5 5 0 0 1 5 -5 h130 a5 5 0 0 1 5 5 v19 h-140z",
        fill: "#111b23",
      }),
      e.jsxs("g", {
        transform: "translate(266 22)",
        children: [
          e.jsx("circle", { cx: 0, cy: -1, r: 6.5, fill: "#bac3cb" }),
          e.jsx("rect", {
            x: -4,
            y: 3,
            width: 8,
            height: 5,
            rx: 1,
            fill: "#bac3cb",
          }),
          e.jsx("circle", { cx: -2.4, cy: -1.5, r: 1.8, fill: "#0d171f" }),
          e.jsx("circle", { cx: 2.4, cy: -1.5, r: 1.8, fill: "#0d171f" }),
        ],
      }),
      e.jsx(M, { x: 278, y: 26, size: 10, fill: "#cb5651", children: "LEAKS" }),
      e.jsx(r, {
        x: 262,
        y: 50,
        size: 8.5,
        fill: "#ffa79f",
        children: "Harcourt & Vale LLP",
      }),
      i.map((t, s) =>
        e.jsxs(
          "g",
          {
            children: [
              e.jsx("rect", {
                x: 260,
                y: 58 + s * 34,
                width: 124,
                height: 28,
                rx: 3,
                fill: "#111b23",
              }),
              e.jsx("rect", {
                x: 260,
                y: 58 + s * 34,
                width: 4,
                height: 28,
                rx: 1,
                fill: "#cb5651",
              }),
              e.jsx(r, {
                x: 269,
                y: 70 + s * 34,
                size: 8,
                fill: "#bac3cb",
                children: t,
              }),
              e.jsx("rect", {
                x: 269,
                y: 75 + s * 34,
                width: 108,
                height: 5,
                rx: 2.5,
                fill: "#333e48",
              }),
              e.jsx("rect", {
                x: 269,
                y: 75 + s * 34,
                width: [96, 80, 64, 48, 30][s],
                height: 5,
                rx: 2.5,
                fill: "#cb5651",
              }),
            ],
          },
          t,
        ),
      ),
    ],
  });
}
function It({ cx: i, cy: t }) {
  return e.jsxs("g", {
    children: [
      e.jsx("path", {
        d: `M${i} ${t - 18} V${t - 28}`,
        stroke: "#5c6873",
        strokeWidth: 2,
      }),
      e.jsx("circle", {
        cx: i,
        cy: t - 30,
        r: 3.5,
        fill: "#cb5651",
        className: "attack-flash",
      }),
      e.jsx("rect", {
        x: i - 26,
        y: t - 6,
        width: 5,
        height: 12,
        rx: 1.5,
        fill: "#46515b",
      }),
      e.jsx("rect", {
        x: i + 21,
        y: t - 6,
        width: 5,
        height: 12,
        rx: 1.5,
        fill: "#46515b",
      }),
      e.jsx("rect", {
        x: i - 22,
        y: t - 18,
        width: 44,
        height: 34,
        rx: 8,
        fill: "#333e48",
        stroke: "#5c6873",
        strokeWidth: 1.5,
      }),
      e.jsx("rect", {
        x: i - 17,
        y: t - 12,
        width: 34,
        height: 13,
        rx: 4,
        fill: "#111b23",
      }),
      e.jsx("circle", { cx: i - 8, cy: t - 5.5, r: 3.5, fill: "#cb5651" }),
      e.jsx("circle", { cx: i + 8, cy: t - 5.5, r: 3.5, fill: "#cb5651" }),
      e.jsx("path", {
        d: `M${i - 10} ${t + 8} H${i + 10} M${i - 5} ${t + 5} V${t + 11} M${i} ${t + 5} V${t + 11} M${i + 5} ${t + 5} V${t + 11}`,
        stroke: "#95a1ac",
        strokeWidth: 1.5,
      }),
    ],
  });
}
function ws({ x: i, y: t, text: s }) {
  const l = s.length * 5.4 + 12;
  return e.jsxs("g", {
    children: [
      e.jsx("rect", {
        x: i,
        y: t - 9,
        width: l,
        height: 15,
        rx: 7.5,
        fill: "#002538",
        stroke: "#ee766f",
        strokeWidth: 1.2,
      }),
      e.jsx(M, {
        x: i + l / 2,
        y: t + 1.5,
        size: 9,
        fill: "#d1beaa",
        anchor: "middle",
        children: s,
      }),
    ],
  });
}
function ks() {
  const i = [48, 120, 192],
    t = [
      ["kaizoom1", 86, 22],
      ["password1", 128, 62],
      ["40million", 84, 98],
      ["qwerty123", 140, 136],
      ["Kai2026!", 86, 170],
      ["iloveyou", 130, 214],
    ];
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#0d171f" }),
      i.map((s) =>
        e.jsx(
          "path",
          {
            d: `M70 ${s} C150 ${s} 170 136 222 136`,
            fill: "none",
            stroke: "#cb5651",
            strokeWidth: 1.6,
            strokeDasharray: "4 5",
            opacity: 0.8,
            className: "attack-flow",
          },
          `flow-${s}`,
        ),
      ),
      i.map((s) => e.jsx(It, { cx: 38, cy: s }, s)),
      t.map(([s, l, a]) => e.jsx(ws, { x: l, y: a, text: s }, s)),
      e.jsxs(f, {
        x: 222,
        y: 8,
        w: 170,
        h: 188,
        bar: "#2b3f50",
        children: [
          e.jsx("rect", {
            x: 223,
            y: 24,
            width: 168,
            height: 56,
            fill: "#3d5264",
          }),
          e.jsx("path", {
            d: "M300 24 H391 V80 H262z",
            fill: "#5bb57e",
            opacity: 0.55,
          }),
          e.jsx("path", {
            d: "M340 24 H391 V80 H314z",
            fill: "#7ed99f",
            opacity: 0.4,
          }),
          e.jsx(R, { x: 376, y: 38, s: 0.8 }),
          e.jsx("circle", {
            cx: 246,
            cy: 70,
            r: 17,
            fill: "#ffe4b4",
            stroke: "#e3e9ee",
            strokeWidth: 2.5,
          }),
          e.jsx("path", {
            d: "M232 68 a14 14 0 0 1 28 -2 q-8 -10 -28 2z",
            fill: "#111b23",
          }),
          e.jsx("circle", { cx: 241, cy: 72, r: 1.6, fill: "#111b23" }),
          e.jsx("circle", { cx: 251, cy: 72, r: 1.6, fill: "#111b23" }),
          e.jsx("path", {
            d: "M241 78 q5 4 10 0",
            fill: "none",
            stroke: "#111b23",
            strokeWidth: 1.4,
          }),
          e.jsx(r, {
            x: 268,
            y: 45,
            size: 11,
            fill: "#e3e9ee",
            children: "KAI ZOOM",
          }),
          e.jsx("circle", { cx: 330, cy: 41, r: 5, fill: "#7ed99f" }),
          e.jsx("path", {
            d: "M327.5 41 l2 2 l3.5 -4",
            fill: "none",
            stroke: "#111b23",
            strokeWidth: 1.4,
            strokeLinecap: "round",
          }),
          e.jsx("rect", {
            x: 268,
            y: 52,
            width: 84,
            height: 15,
            rx: 7.5,
            fill: "#111b23",
            opacity: 0.75,
          }),
          e.jsx(r, {
            x: 310,
            y: 62.5,
            size: 8,
            anchor: "middle",
            fill: "#7ed99f",
            children: "40M subscribers",
          }),
          e.jsx("rect", {
            x: 236,
            y: 98,
            width: 142,
            height: 15,
            rx: 3,
            fill: "#e3e9ee",
            stroke: "#95a1ac",
          }),
          e.jsx(r, {
            x: 242,
            y: 108.5,
            size: 8,
            weight: 400,
            fill: "#333e48",
            children: "kaizoom",
          }),
          e.jsx("rect", {
            x: 236,
            y: 118,
            width: 142,
            height: 15,
            rx: 3,
            fill: "#e3e9ee",
            stroke: "#cb5651",
            strokeWidth: 1.5,
          }),
          e.jsx(r, {
            x: 242,
            y: 129.5,
            size: 9,
            fill: "#333e48",
            children: "• • • • • • • •",
          }),
          e.jsx("rect", {
            x: 274,
            y: 140,
            width: 66,
            height: 16,
            rx: 8,
            fill: "#54697c",
          }),
          e.jsx(r, {
            x: 307,
            y: 151.5,
            size: 8,
            anchor: "middle",
            fill: "#e3e9ee",
            children: "Log in",
          }),
          e.jsx("rect", {
            x: 223,
            y: 164,
            width: 168,
            height: 16,
            fill: "#bac3cb",
          }),
          e.jsx(r, {
            x: 307,
            y: 175,
            size: 8,
            anchor: "middle",
            fill: "#ac3a38",
            children: "Incorrect password",
          }),
        ],
      }),
      e.jsx("rect", {
        x: 222,
        y: 202,
        width: 170,
        height: 30,
        rx: 4,
        fill: "#480004",
        stroke: "#cb5651",
        strokeWidth: 2,
        className: "attack-flash-stroke",
      }),
      e.jsx(M, {
        x: 307,
        y: 222,
        size: 13,
        fill: "#ffa79f",
        anchor: "middle",
        children: "1,204,377 tries",
      }),
    ],
  });
}
function de({ x: i, y: t, r: s, name: l, amount: a, face: c }) {
  return e.jsxs("g", {
    transform: `translate(${i} ${t}) rotate(${s})`,
    children: [
      e.jsx("rect", {
        x: 0,
        y: 0,
        width: 122,
        height: 26,
        rx: 3,
        fill: "#e3e9ee",
        stroke: "#bac3cb",
      }),
      e.jsx("rect", {
        x: 0,
        y: 0,
        width: 6,
        height: 26,
        rx: 2,
        fill: "#54697c",
      }),
      e.jsx("circle", { cx: 16, cy: 13, r: 6.5, fill: c }),
      e.jsx(r, { x: 26, y: 10.5, size: 7, fill: "#111b23", children: l }),
      e.jsx(M, {
        x: 26,
        y: 20.5,
        size: 6.5,
        fill: "#46515b",
        children: "00-00-00",
      }),
      e.jsx(r, {
        x: 116,
        y: 17,
        size: 8.5,
        anchor: "end",
        fill: "#137a47",
        children: a,
      }),
    ],
  });
}
function us() {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#051827" }),
      e.jsxs(f, {
        x: 12,
        y: 14,
        w: 216,
        h: 180,
        bar: "#3d5264",
        children: [
          e.jsx("rect", {
            x: 13,
            y: 30,
            width: 214,
            height: 42,
            fill: "#1c2f40",
          }),
          e.jsx(R, { x: 36, y: 51, s: 1.1 }),
          e.jsx(r, {
            x: 54,
            y: 50,
            size: 12,
            fill: "#e3e9ee",
            children: "Vidora",
          }),
          e.jsx(r, {
            x: 54,
            y: 63,
            size: 8,
            fill: "#7ed99f",
            children: "Creator Payouts",
          }),
          [0, 1, 2].map((i) =>
            e.jsx(
              "ellipse",
              {
                cx: 204,
                cy: 60 - i * 6,
                rx: 11,
                ry: 4,
                fill: "#e8ba61",
                stroke: "#ac3a38",
              },
              i,
            ),
          ),
          e.jsx(r, {
            x: 26,
            y: 90,
            size: 8,
            fill: "#333e48",
            children: "Search creators",
          }),
          e.jsx("rect", {
            x: 26,
            y: 96,
            width: 188,
            height: 24,
            rx: 3,
            fill: "#e3e9ee",
            stroke: "#cb5651",
            strokeWidth: 2,
          }),
          e.jsx(M, {
            x: 33,
            y: 112,
            size: 11.5,
            fill: "#ac3a38",
            children: "' OR 1=1; --",
          }),
          e.jsx("path", {
            d: "M128 100 V116",
            stroke: "#111b23",
            strokeWidth: 1.2,
            className: "attack-flash",
          }),
          e.jsx("rect", {
            x: 26,
            y: 128,
            width: 88,
            height: 12,
            rx: 3,
            fill: "#bac3cb",
          }),
          e.jsx("rect", {
            x: 120,
            y: 128,
            width: 94,
            height: 12,
            rx: 3,
            fill: "#bac3cb",
          }),
          e.jsx("rect", {
            x: 26,
            y: 156,
            width: 84,
            height: 22,
            rx: 11,
            fill: "#54697c",
          }),
          e.jsx(r, {
            x: 68,
            y: 170.5,
            size: 9,
            anchor: "middle",
            fill: "#e3e9ee",
            children: "Search",
          }),
          e.jsx(Je, { x: 94, y: 168 }),
        ],
      }),
      e.jsx("rect", {
        x: 12,
        y: 202,
        width: 216,
        height: 28,
        rx: 4,
        fill: "#480004",
      }),
      e.jsx(M, {
        x: 120,
        y: 220,
        size: 10,
        fill: "#ffa79f",
        anchor: "middle",
        children: "52,108 rows returned",
      }),
      e.jsx("path", {
        d: "M228 108 C248 108 250 70 264 70",
        fill: "none",
        stroke: "#cb5651",
        strokeWidth: 2,
        strokeDasharray: "5 4",
        className: "attack-flow",
      }),
      e.jsx("path", { d: "M260 64 l8 6 l-8 6z", fill: "#cb5651" }),
      e.jsx("rect", { x: 276, y: 22, width: 92, height: 74, fill: "#333e48" }),
      e.jsx("ellipse", { cx: 322, cy: 96, rx: 46, ry: 12, fill: "#333e48" }),
      e.jsx("path", {
        d: "M276 60 a46 12 0 0 0 92 0",
        fill: "none",
        stroke: "#242f38",
        strokeWidth: 2,
      }),
      e.jsx("ellipse", {
        cx: 322,
        cy: 22,
        rx: 46,
        ry: 12,
        fill: "#46515b",
        stroke: "#cb5651",
        strokeWidth: 2,
        className: "attack-flash-stroke",
      }),
      e.jsx(r, {
        x: 322,
        y: 52,
        size: 8.5,
        anchor: "middle",
        fill: "#bac3cb",
        children: "PAYOUTS",
      }),
      e.jsx("path", {
        d: "M300 104 l-6 10 M322 108 v10 M344 104 l6 10",
        stroke: "#ee766f",
        strokeWidth: 2,
      }),
      e.jsx(de, {
        x: 250,
        y: 114,
        r: -3,
        name: "@lunabakes",
        amount: "£48,210",
        face: "#ffa79f",
      }),
      e.jsx(de, {
        x: 268,
        y: 143,
        r: 3,
        name: "@kaizoom",
        amount: "£912,400",
        face: "#ffe4b4",
      }),
      e.jsx(de, {
        x: 246,
        y: 172,
        r: -3,
        name: "@gamerjess",
        amount: "£73,950",
        face: "#8ecbee",
      }),
      e.jsx(de, {
        x: 264,
        y: 202,
        r: 2,
        name: "@dr.denz",
        amount: "£130,006",
        face: "#a8ffc6",
      }),
    ],
  });
}
function ms() {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#0d171f" }),
      e.jsx("rect", { x: 186, y: 0, width: 214, height: 240, fill: "#002538" }),
      e.jsx("path", {
        d: "M8 240 C12 190 40 172 82 172 C124 172 152 190 156 240z",
        fill: "#242f38",
      }),
      e.jsx("path", { d: "M70 172 L82 200 L94 172z", fill: "#bac3cb" }),
      e.jsx("path", {
        d: "M70 172 L60 240 M94 172 L104 240",
        stroke: "#111b23",
        strokeWidth: 3,
      }),
      e.jsx("rect", { x: 74, y: 150, width: 16, height: 24, fill: "#c68642" }),
      e.jsx("ellipse", { cx: 82, cy: 126, rx: 28, ry: 32, fill: "#c68642" }),
      e.jsx("path", {
        d: "M54 120 C52 88 112 84 110 118 q-10 -16 -28 -16 q-18 0 -28 18z",
        fill: "#111b23",
      }),
      e.jsx("rect", {
        x: 60,
        y: 118,
        width: 20,
        height: 11,
        rx: 4,
        fill: "#0d171f",
      }),
      e.jsx("rect", {
        x: 84,
        y: 118,
        width: 20,
        height: 11,
        rx: 4,
        fill: "#0d171f",
      }),
      e.jsx("path", { d: "M80 122 h4", stroke: "#0d171f", strokeWidth: 2 }),
      e.jsx("ellipse", { cx: 82, cy: 145, rx: 9, ry: 6, fill: "#480004" }),
      e.jsx("rect", { x: 76, y: 141, width: 12, height: 2.5, fill: "#e3e9ee" }),
      e.jsx("path", {
        d: "M64 176 L74 204 M100 176 L90 204",
        stroke: "#54697c",
        strokeWidth: 2.5,
      }),
      e.jsxs("g", {
        transform: "rotate(-6 82 216)",
        children: [
          e.jsx("rect", {
            x: 56,
            y: 202,
            width: 52,
            height: 30,
            rx: 3,
            fill: "#e8ba61",
            stroke: "#901e21",
          }),
          e.jsx(R, { x: 68, y: 217, s: 0.6 }),
          e.jsx(r, {
            x: 92,
            y: 215,
            size: 8,
            anchor: "middle",
            fill: "#901e21",
            children: "VIP",
          }),
          e.jsx(r, {
            x: 92,
            y: 225,
            size: 5.5,
            anchor: "middle",
            fill: "#901e21",
            children: "MANAGER",
          }),
        ],
      }),
      e.jsx("rect", {
        x: 108,
        y: 102,
        width: 16,
        height: 30,
        rx: 3,
        fill: "#111b23",
        stroke: "#5c6873",
        transform: "rotate(14 116 117)",
      }),
      e.jsx("circle", { cx: 112, cy: 132, r: 6, fill: "#c68642" }),
      e.jsx("path", {
        d: "M10 10 h162 a8 8 0 0 1 8 8 v36 a8 8 0 0 1 -8 8 h-60 l-10 14 l-2 -14 h-90 a8 8 0 0 1 -8 -8 v-36 a8 8 0 0 1 8 -8z",
        fill: "#e3e9ee",
      }),
      e.jsx(r, {
        x: 92,
        y: 31,
        size: 10,
        anchor: "middle",
        children: "I'm Kai's manager!",
      }),
      e.jsx(r, {
        x: 92,
        y: 50,
        size: 11,
        anchor: "middle",
        fill: "#ac3a38",
        children: "Reset it NOW!",
      }),
      e.jsx("path", {
        d: "M128 110 q14 -10 24 0 t24 0 t24 0 t24 0 t24 0",
        fill: "none",
        stroke: "#cb5651",
        strokeWidth: 2,
        strokeDasharray: "4 4",
        className: "attack-flow",
      }),
      e.jsx("rect", {
        x: 198,
        y: 8,
        width: 192,
        height: 58,
        rx: 5,
        fill: "#0d171f",
        stroke: "#cb5651",
        strokeWidth: 2,
        className: "attack-flash-stroke",
      }),
      e.jsx("rect", {
        x: 206,
        y: 15,
        width: 58,
        height: 16,
        rx: 4,
        fill: "#cb5651",
      }),
      e.jsx("circle", {
        cx: 214,
        cy: 23,
        r: 3,
        fill: "#e3e9ee",
        className: "attack-flash",
      }),
      e.jsx(r, {
        x: 243,
        y: 26.5,
        size: 8.5,
        anchor: "middle",
        fill: "#e3e9ee",
        children: "LIVE IN",
      }),
      e.jsx("path", { d: "M272 23 q8 -7 16 0 q-8 7 -16 0z", fill: "#7ed99f" }),
      e.jsx("circle", { cx: 280, cy: 23, r: 2.4, fill: "#0d171f" }),
      e.jsx(r, {
        x: 292,
        y: 26.5,
        size: 8.5,
        fill: "#7ed99f",
        children: "2,000,000 waiting",
      }),
      e.jsx(M, {
        x: 294,
        y: 58,
        size: 22,
        fill: "#ee766f",
        anchor: "middle",
        children: "05:00",
      }),
      e.jsx("path", {
        d: "M210 240 V172 a28 28 0 0 1 56 0 V240z",
        fill: "#54697c",
      }),
      e.jsx("circle", { cx: 238, cy: 130, r: 18, fill: "#8d5524" }),
      e.jsx("path", {
        d: "M220 126 a18 18 0 0 1 36 -4 q-14 -8 -36 4z",
        fill: "#111b23",
      }),
      e.jsx("path", {
        d: "M220 130 a18 18 0 0 1 36 0",
        fill: "none",
        stroke: "#bac3cb",
        strokeWidth: 3,
      }),
      e.jsx("rect", {
        x: 252,
        y: 126,
        width: 7,
        height: 11,
        rx: 2,
        fill: "#bac3cb",
      }),
      e.jsx("path", {
        d: "M256 136 q2 10 -10 12",
        fill: "none",
        stroke: "#bac3cb",
        strokeWidth: 2,
      }),
      e.jsx("path", {
        d: "M232 138 q6 4 12 0",
        fill: "none",
        stroke: "#111b23",
        strokeWidth: 1.4,
      }),
      e.jsx("path", {
        d: "M258 188 L294 196",
        stroke: "#54697c",
        strokeWidth: 10,
        strokeLinecap: "round",
      }),
      e.jsx("rect", {
        x: 186,
        y: 198,
        width: 214,
        height: 10,
        fill: "#46515b",
      }),
      e.jsx("rect", {
        x: 284,
        y: 74,
        width: 108,
        height: 88,
        rx: 4,
        fill: "#111b23",
      }),
      e.jsx("rect", { x: 289, y: 79, width: 98, height: 78, fill: "#bac3cb" }),
      e.jsx("rect", { x: 289, y: 79, width: 98, height: 13, fill: "#2b3f50" }),
      e.jsx(R, { x: 297, y: 85.5, s: 0.42 }),
      e.jsx(r, {
        x: 304,
        y: 88.5,
        size: 6.5,
        fill: "#e3e9ee",
        children: "Support",
      }),
      e.jsx(r, {
        x: 294,
        y: 104,
        size: 7.5,
        fill: "#333e48",
        children: "@kaizoom",
      }),
      e.jsx("rect", {
        x: 294,
        y: 109,
        width: 88,
        height: 12,
        rx: 2,
        fill: "#e3e9ee",
        stroke: "#95a1ac",
      }),
      e.jsx(r, {
        x: 298,
        y: 118,
        size: 7,
        fill: "#5c6873",
        children: "• • • • • •",
      }),
      e.jsx("rect", {
        x: 294,
        y: 128,
        width: 88,
        height: 22,
        rx: 3,
        fill: "#cb5651",
        className: "attack-flash",
      }),
      e.jsx(r, {
        x: 338,
        y: 142.5,
        size: 8,
        anchor: "middle",
        fill: "#e3e9ee",
        children: "RESET PASSWORD",
      }),
      e.jsx("rect", { x: 331, y: 162, width: 14, height: 28, fill: "#333e48" }),
      e.jsx("rect", {
        x: 315,
        y: 188,
        width: 46,
        height: 10,
        rx: 2,
        fill: "#333e48",
      }),
      e.jsx("rect", {
        x: 282,
        y: 190,
        width: 30,
        height: 8,
        rx: 2,
        fill: "#242f38",
      }),
    ],
  });
}
function Ms({ x: i, y: t, s = 4, stroke: l = "#cb5651" }) {
  return e.jsx("path", {
    d: `M${i - s} ${t - s} L${i + s} ${t + s} M${i + s} ${t - s} L${i - s} ${t + s}`,
    stroke: l,
    strokeWidth: 1.8,
    strokeLinecap: "round",
  });
}
function vs() {
  const i = [
    "yacht2024",
    "Monaco!",
    "password123",
    "Thorne1960",
    "billions!",
    "yacht2025",
  ];
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#111b23" }),
      e.jsx(It, { cx: 90, cy: 42 }),
      e.jsx("rect", {
        x: 10,
        y: 66,
        width: 160,
        height: 164,
        rx: 5,
        fill: "#0d171f",
        stroke: "#333e48",
      }),
      e.jsx("path", {
        d: "M10 71 a5 5 0 0 1 5 -5 h150 a5 5 0 0 1 5 5 v10 h-160z",
        fill: "#242f38",
      }),
      e.jsx(M, {
        x: 18,
        y: 78,
        size: 7,
        fill: "#95a1ac",
        children: "guess.bot",
      }),
      i.map((t, s) => {
        const l = 100 + s * 19,
          a = s === i.length - 1;
        return e.jsxs(
          "g",
          {
            className: a ? "attack-flash" : void 0,
            children: [
              e.jsx(M, {
                x: 18,
                y: l,
                size: 10,
                fill: "#5c6873",
                children: ">",
              }),
              e.jsx(M, {
                x: 30,
                y: l,
                size: 10,
                fill: a ? "#d1beaa" : "#bac3cb",
                children: t,
              }),
              e.jsx(Ms, { x: 156, y: l - 3.5 }),
            ],
          },
          t,
        );
      }),
      e.jsx(M, { x: 18, y: 220, size: 10, fill: "#5c6873", children: ">" }),
      e.jsx("rect", {
        x: 30,
        y: 211,
        width: 7,
        height: 11,
        fill: "#7ed99f",
        className: "attack-flash",
      }),
      e.jsxs(f, {
        x: 196,
        y: 8,
        w: 196,
        h: 180,
        bar: "#333e48",
        children: [
          e.jsx("rect", {
            x: 197,
            y: 24,
            width: 194,
            height: 36,
            fill: "#00425f",
          }),
          e.jsx(we, { x: 220, y: 34, s: 0.6, fill: "#e8ba61" }),
          e.jsx(r, {
            x: 238,
            y: 40,
            size: 11,
            fill: "#e3e9ee",
            children: "Harcourt & Vale",
          }),
          e.jsx(r, {
            x: 238,
            y: 53,
            size: 7.5,
            fill: "#ffe4b4",
            children: "Client Portal",
          }),
          e.jsx("circle", {
            cx: 218,
            cy: 78,
            r: 10,
            fill: "#ffe4b4",
            stroke: "#746351",
            strokeWidth: 1.5,
          }),
          e.jsx("path", {
            d: "M209 76 a9 9 0 0 1 18 -1 q-8 -6 -18 1z",
            fill: "#5c6873",
          }),
          e.jsx("circle", { cx: 215, cy: 79, r: 1.3, fill: "#111b23" }),
          e.jsx("circle", { cx: 221, cy: 79, r: 1.3, fill: "#111b23" }),
          e.jsx(r, {
            x: 234,
            y: 76,
            size: 8.5,
            fill: "#111b23",
            children: "Alexander Thorne",
          }),
          e.jsx(r, {
            x: 234,
            y: 87,
            size: 7,
            weight: 400,
            fill: "#746351",
            children: "Private client",
          }),
          e.jsx("path", { d: "M344 86 h38 l-6 7 h-28z", fill: "#00425f" }),
          e.jsx("path", { d: "M352 86 v-8 h18 l4 8z", fill: "#bac3cb" }),
          e.jsx("path", { d: "M358 78 v-6 h8 l2 6z", fill: "#95a1ac" }),
          e.jsx("rect", {
            x: 214,
            y: 100,
            width: 160,
            height: 15,
            rx: 3,
            fill: "#e3e9ee",
            stroke: "#95a1ac",
          }),
          e.jsx(r, {
            x: 220,
            y: 110.5,
            size: 8,
            weight: 400,
            fill: "#333e48",
            children: "a.thorne",
          }),
          e.jsx("rect", {
            x: 214,
            y: 120,
            width: 160,
            height: 15,
            rx: 3,
            fill: "#e3e9ee",
            stroke: "#cb5651",
            strokeWidth: 1.5,
          }),
          e.jsx(r, {
            x: 220,
            y: 131.5,
            size: 9,
            fill: "#333e48",
            children: "• • • • • • • • •",
          }),
          e.jsx("rect", {
            x: 258,
            y: 141,
            width: 72,
            height: 16,
            rx: 3,
            fill: "#00425f",
          }),
          e.jsx(r, {
            x: 294,
            y: 152.5,
            size: 8,
            anchor: "middle",
            fill: "#e3e9ee",
            children: "Sign in",
          }),
          e.jsx("rect", {
            x: 197,
            y: 164,
            width: 194,
            height: 16,
            fill: "#bac3cb",
          }),
          e.jsx(r, {
            x: 294,
            y: 175,
            size: 8,
            anchor: "middle",
            fill: "#ac3a38",
            children: "Incorrect password",
          }),
        ],
      }),
      [100, 138, 176].map((t) =>
        e.jsx(
          "path",
          {
            d: `M170 ${t} C190 ${t} 192 127 214 127`,
            fill: "none",
            stroke: "#cb5651",
            strokeWidth: 1.6,
            strokeDasharray: "4 4",
            opacity: 0.85,
            className: "attack-flow",
          },
          t,
        ),
      ),
      e.jsx("rect", {
        x: 196,
        y: 196,
        width: 196,
        height: 34,
        rx: 4,
        fill: "#480004",
        stroke: "#cb5651",
        strokeWidth: 2,
        className: "attack-flash-stroke",
      }),
      e.jsx("path", {
        d: "M210 220 l6 -8 l6 4 l8 -10",
        fill: "none",
        stroke: "#ffa79f",
        strokeWidth: 2,
      }),
      e.jsx("path", {
        d: "M226 206 h5 v5",
        fill: "none",
        stroke: "#ffa79f",
        strokeWidth: 2,
      }),
      e.jsx(M, {
        x: 384,
        y: 218,
        size: 12,
        fill: "#ffa79f",
        anchor: "end",
        children: "48,213 failed",
      }),
    ],
  });
}
function xe({ x: i, y: t, fill: s = "#e3e9ee", edge: l = "#95a1ac" }) {
  return e.jsxs("g", {
    children: [
      e.jsx("rect", {
        x: i - 7,
        y: t - 5,
        width: 14,
        height: 10,
        rx: 1.5,
        fill: s,
        stroke: l,
      }),
      e.jsx("path", {
        d: `M${i - 7} ${t - 5} l7 5 l7 -5`,
        fill: "none",
        stroke: l,
        strokeWidth: 1,
      }),
    ],
  });
}
function zs() {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#0d171f" }),
      e.jsx("rect", { x: 0, y: 0, width: 400, height: 176, fill: "#19232c" }),
      [40, 80, 120, 280, 320, 360].map((i) =>
        e.jsx(
          "path",
          { d: `M${i} 4 V176`, stroke: "#242f38", strokeWidth: 2 },
          i,
        ),
      ),
      e.jsx(we, { x: 206, y: 104, s: 1.1, fill: "#746351" }),
      e.jsx("rect", {
        x: 140,
        y: 8,
        width: 120,
        height: 22,
        rx: 3,
        fill: "#e3e9ee",
      }),
      e.jsxs("g", {
        transform: "translate(154 25)",
        fill: "none",
        stroke: "#326e8e",
        strokeWidth: 1.6,
        children: [
          e.jsx("path", { d: "M-7 -7 a10 10 0 0 1 14 0" }),
          e.jsx("path", { d: "M-4.5 -4 a6 6 0 0 1 9 0" }),
          e.jsx("circle", {
            cx: 0,
            cy: -1,
            r: 1.3,
            fill: "#326e8e",
            stroke: "none",
          }),
        ],
      }),
      e.jsx(r, {
        x: 208,
        y: 23,
        size: 8.5,
        anchor: "middle",
        fill: "#00425f",
        children: "Court Free Wi-Fi",
      }),
      e.jsx("path", {
        d: "M190 40 V33 M210 40 V33",
        stroke: "#95a1ac",
        strokeWidth: 2,
        strokeLinecap: "round",
      }),
      e.jsx("rect", {
        x: 182,
        y: 40,
        width: 36,
        height: 11,
        rx: 3,
        fill: "#bac3cb",
      }),
      [192, 198, 204].map((i) =>
        e.jsx("circle", { cx: i, cy: 45.5, r: 1.5, fill: "#5bb57e" }, i),
      ),
      e.jsx("path", {
        d: "M14 172 L18 136 q4 -12 24 -12 h16 q18 2 20 16 l2 32z",
        fill: "#0d171f",
      }),
      e.jsx("path", { d: "M42 124 l8 12 l8 -12z", fill: "#e3e9ee" }),
      e.jsx("rect", { x: 46, y: 134, width: 3, height: 10, fill: "#e3e9ee" }),
      e.jsx("rect", { x: 51, y: 134, width: 3, height: 10, fill: "#e3e9ee" }),
      e.jsx("rect", { x: 45, y: 114, width: 10, height: 11, fill: "#d6a77a" }),
      e.jsx("circle", { cx: 52, cy: 104, r: 14, fill: "#d6a77a" }),
      e.jsx("path", {
        d: "M36 104 q-2 -18 16 -18 q18 0 16 16 q-6 -6 -14 -6 q-10 0 -18 8z",
        fill: "#bac3cb",
        stroke: "#95a1ac",
      }),
      [96, 102, 108].map((i) =>
        e.jsx(
          "path",
          { d: `M37 ${i} h6`, stroke: "#95a1ac", strokeWidth: 1.2 },
          i,
        ),
      ),
      e.jsx("rect", {
        x: 34,
        y: 104,
        width: 8,
        height: 12,
        rx: 3,
        fill: "#bac3cb",
        stroke: "#95a1ac",
      }),
      e.jsx("circle", { cx: 60, cy: 103, r: 1.5, fill: "#111b23" }),
      e.jsx("path", {
        d: "M60 140 L80 160 L104 166",
        fill: "none",
        stroke: "#0d171f",
        strokeWidth: 9,
        strokeLinecap: "round",
        strokeLinejoin: "round",
      }),
      e.jsx("circle", { cx: 106, cy: 166, r: 4.5, fill: "#d6a77a" }),
      e.jsx("rect", { x: 0, y: 170, width: 180, height: 9, fill: "#5c4d3b" }),
      e.jsx("rect", { x: 0, y: 179, width: 180, height: 61, fill: "#242f38" }),
      e.jsx("path", { d: "M0 206 H180", stroke: "#19232c", strokeWidth: 2 }),
      e.jsx("rect", {
        x: 84,
        y: 110,
        width: 84,
        height: 56,
        rx: 3,
        fill: "#111b23",
      }),
      e.jsx("rect", { x: 88, y: 114, width: 76, height: 48, fill: "#e3e9ee" }),
      e.jsx("rect", { x: 88, y: 114, width: 76, height: 12, fill: "#00425f" }),
      e.jsx(r, {
        x: 92,
        y: 123,
        size: 7,
        fill: "#e3e9ee",
        children: "Witness statement",
      }),
      [132, 138, 144, 150].map((i, t) =>
        e.jsx(
          "rect",
          {
            x: 92,
            y: i,
            width: t === 3 ? 38 : 66,
            height: 2.5,
            rx: 1,
            fill: "#95a1ac",
          },
          i,
        ),
      ),
      e.jsx("rect", {
        x: 130,
        y: 152,
        width: 30,
        height: 7,
        rx: 2,
        fill: "#399661",
      }),
      e.jsx(r, {
        x: 145,
        y: 157.6,
        size: 5.5,
        anchor: "middle",
        fill: "#e3e9ee",
        children: "Send",
      }),
      e.jsx("path", { d: "M78 166 h96 l-6 4 h-84z", fill: "#5c6873" }),
      e.jsx("path", {
        d: "M166 112 C180 92 170 64 186 54",
        fill: "none",
        stroke: "#e8ba61",
        strokeWidth: 1.6,
        strokeDasharray: "4 4",
        className: "attack-flow",
      }),
      e.jsx(xe, { x: 172, y: 96 }),
      e.jsx(xe, { x: 180, y: 70 }),
      e.jsx("rect", {
        x: 180,
        y: 176,
        width: 220,
        height: 64,
        fill: "#242f38",
      }),
      e.jsx("rect", { x: 180, y: 176, width: 220, height: 6, fill: "#5c4d3b" }),
      e.jsx("path", { d: "M180 206 H400", stroke: "#19232c", strokeWidth: 2 }),
      e.jsx("path", {
        d: "M212 178 V160 a16 16 0 0 1 32 0 V178z",
        fill: "#46515b",
      }),
      e.jsx("circle", { cx: 228, cy: 142, r: 11, fill: "#8d5524" }),
      e.jsx("path", {
        d: "M217 140 a11 11 0 0 1 22 0 q-10 -6 -22 0z",
        fill: "#111b23",
      }),
      e.jsxs("g", {
        transform: "translate(0 14)",
        children: [
          e.jsx("path", {
            d: "M314 178 V150 a26 26 0 0 1 52 0 V178z",
            fill: "#901e21",
          }),
          e.jsx("path", {
            d: "M332 126 l8 12 l8 -12",
            fill: "none",
            stroke: "#326e8e",
            strokeWidth: 2,
          }),
          e.jsx("rect", {
            x: 334,
            y: 138,
            width: 22,
            height: 13,
            rx: 2,
            fill: "#e3e9ee",
            stroke: "#326e8e",
          }),
          e.jsx(r, {
            x: 345,
            y: 147,
            size: 6,
            anchor: "middle",
            fill: "#326e8e",
            children: "PRESS",
          }),
          e.jsx("circle", { cx: 340, cy: 110, r: 14, fill: "#e0ac69" }),
          e.jsx("path", {
            d: "M326 108 a14 14 0 0 1 28 -2 q-6 -8 -16 -6 q-8 2 -12 8z",
            fill: "#ac3a38",
          }),
          e.jsx("rect", {
            x: 326,
            y: 106,
            width: 10,
            height: 7,
            rx: 2,
            fill: "none",
            stroke: "#111b23",
            strokeWidth: 1.4,
          }),
          e.jsx("rect", {
            x: 338,
            y: 106,
            width: 10,
            height: 7,
            rx: 2,
            fill: "none",
            stroke: "#111b23",
            strokeWidth: 1.4,
          }),
          e.jsx("path", {
            d: "M336 109 h2",
            stroke: "#111b23",
            strokeWidth: 1.4,
          }),
          e.jsx("path", {
            d: "M330 152 L314 166",
            stroke: "#901e21",
            strokeWidth: 8,
            strokeLinecap: "round",
          }),
          e.jsx("path", {
            d: "M284 146 L298 170 h26 v4 h-30z",
            fill: "#46515b",
          }),
          e.jsx("path", {
            d: "M284 146 L298 170",
            stroke: "#95a1ac",
            strokeWidth: 2,
          }),
          e.jsx("circle", { cx: 314, cy: 168, r: 4, fill: "#e0ac69" }),
        ],
      }),
      e.jsx("path", {
        d: "M218 48 C252 60 240 150 288 166",
        fill: "none",
        stroke: "#cb5651",
        strokeWidth: 1.8,
        strokeDasharray: "5 4",
        className: "attack-flow",
      }),
      e.jsx(xe, { x: 242, y: 78, fill: "#bac3cb", edge: "#cb5651" }),
      e.jsx(xe, { x: 250, y: 128, fill: "#bac3cb", edge: "#cb5651" }),
      e.jsx("path", {
        d: "M296 158 L304 92",
        stroke: "#ffa79f",
        strokeWidth: 1.4,
        strokeDasharray: "3 3",
      }),
      e.jsxs(f, {
        x: 266,
        y: 6,
        w: 126,
        h: 84,
        bar: "#901e21",
        children: [
          e.jsx(r, {
            x: 296,
            y: 17,
            size: 7,
            fill: "#e3e9ee",
            children: "Packet capture",
          }),
          e.jsx(M, {
            x: 272,
            y: 33,
            size: 7,
            fill: "#5c6873",
            children: "PKT 0412 2.1KB",
          }),
          e.jsx(M, {
            x: 272,
            y: 43,
            size: 7,
            fill: "#5c6873",
            children: "PKT 0413 1.8KB",
          }),
          e.jsx("rect", {
            x: 270,
            y: 49,
            width: 118,
            height: 37,
            rx: 3,
            fill: "#d1beaa",
            stroke: "#e8ba61",
          }),
          e.jsx(r, {
            x: 275,
            y: 60,
            size: 7.5,
            fill: "#ac3a38",
            children: "Witness B statement",
          }),
          e.jsx(r, {
            x: 275,
            y: 71,
            size: 7,
            weight: 400,
            fill: "#111b23",
            children: "“I saw the director",
          }),
          e.jsx(r, {
            x: 275,
            y: 81,
            size: 7,
            weight: 400,
            fill: "#111b23",
            children: "shred the ledgers.”",
          }),
        ],
      }),
    ],
  });
}
function Ls() {
  const i = ["#ee766f", "#6ca8ca", "#e8ba61", "#8ba3b7", "#7ed99f", "#e8ba61"];
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#0d171f" }),
      e.jsx("rect", {
        x: 10,
        y: 8,
        width: 234,
        height: 164,
        rx: 6,
        fill: "#0d171f",
      }),
      e.jsxs(f, {
        x: 16,
        y: 14,
        w: 222,
        h: 152,
        bar: "#2b3f50",
        children: [
          e.jsx("rect", {
            x: 17,
            y: 30,
            width: 220,
            height: 13,
            fill: "#bac3cb",
          }),
          e.jsx(r, {
            x: 127,
            y: 39.5,
            size: 7,
            weight: 400,
            anchor: "middle",
            fill: "#ac3a38",
            children: "free-plugins-dl.net/8k-filter",
          }),
          e.jsx(r, {
            x: 24,
            y: 58,
            size: 11,
            fill: "#111b23",
            children: "Free 8K filter plugin",
          }),
          e.jsx("rect", {
            x: 74,
            y: 118,
            width: 104,
            height: 6,
            rx: 2,
            fill: "#901e21",
          }),
          [84, 112, 140, 168].map((t) =>
            e.jsx(
              "circle",
              { cx: t, cy: 127, r: 4, fill: "#392a1a", stroke: "#746351" },
              t,
            ),
          ),
          [92, 106, 140, 154].map((t) =>
            e.jsx(
              "rect",
              { x: t, y: 100, width: 7, height: 18, fill: "#ac3a38" },
              t,
            ),
          ),
          e.jsx("path", { d: "M150 88 L160 62 h12 l-2 30z", fill: "#ac3a38" }),
          e.jsx("path", {
            d: "M156 66 h22 q6 0 6 6 v4 h-24z",
            fill: "#ac3a38",
          }),
          e.jsx("path", { d: "M158 62 l4 -8 l4 8z", fill: "#ac3a38" }),
          e.jsx("path", {
            d: "M156 64 q-6 10 -4 24",
            fill: "none",
            stroke: "#901e21",
            strokeWidth: 3,
          }),
          e.jsx("circle", { cx: 172, cy: 69, r: 1.6, fill: "#111b23" }),
          e.jsx("rect", {
            x: 86,
            y: 78,
            width: 76,
            height: 26,
            rx: 6,
            fill: "#ac3a38",
          }),
          [86, 94].map((t) =>
            e.jsx(
              "path",
              { d: `M90 ${t} H158`, stroke: "#ac3a38", strokeWidth: 1 },
              t,
            ),
          ),
          e.jsx("rect", {
            x: 116,
            y: 78,
            width: 8,
            height: 26,
            fill: "#ee766f",
          }),
          e.jsx("rect", {
            x: 86,
            y: 88,
            width: 76,
            height: 6,
            fill: "#ee766f",
          }),
          e.jsx("path", {
            d: "M120 78 q-12 -12 -14 -2 q2 6 14 2 q12 -12 14 -2 q-2 6 -14 2z",
            fill: "#ee766f",
            stroke: "#ac3a38",
          }),
          e.jsx("rect", {
            x: 134,
            y: 95,
            width: 18,
            height: 8,
            fill: "#480004",
          }),
          e.jsx("rect", {
            x: 134,
            y: 95,
            width: 18,
            height: 8,
            fill: "#cb5651",
            opacity: 0.7,
            className: "attack-flash",
          }),
          e.jsx("path", { d: "M134 103 l-6 4 v-8 l6 -4z", fill: "#ac3a38" }),
          e.jsx("rect", {
            x: 64,
            y: 70,
            width: 18,
            height: 12,
            rx: 2,
            fill: "#e3e9ee",
            stroke: "#ac3a38",
          }),
          e.jsx(r, {
            x: 73,
            y: 79,
            size: 7,
            anchor: "middle",
            fill: "#ac3a38",
            children: "8K",
          }),
          e.jsx("path", {
            d: "M82 76 L104 80",
            stroke: "#ac3a38",
            strokeWidth: 1,
          }),
          e.jsx(r, {
            x: 24,
            y: 150,
            size: 8,
            fill: "#333e48",
            children: "Installing",
          }),
          e.jsx("rect", {
            x: 74,
            y: 142,
            width: 154,
            height: 10,
            rx: 5,
            fill: "#bac3cb",
          }),
          e.jsx("rect", {
            x: 74,
            y: 142,
            width: 114,
            height: 10,
            rx: 5,
            fill: "#54697c",
          }),
          e.jsx(r, {
            x: 225,
            y: 162,
            size: 7,
            anchor: "end",
            fill: "#54697c",
            children: "74%",
          }),
          e.jsx(Je, { x: 176, y: 146 }),
        ],
      }),
      e.jsx("rect", { x: 118, y: 172, width: 18, height: 14, fill: "#333e48" }),
      e.jsx("rect", {
        x: 98,
        y: 184,
        width: 58,
        height: 6,
        rx: 2,
        fill: "#333e48",
      }),
      e.jsx("rect", { x: 0, y: 190, width: 262, height: 50, fill: "#19232c" }),
      e.jsx("rect", { x: 0, y: 190, width: 262, height: 5, fill: "#2b3f50" }),
      e.jsx("path", {
        d: "M24 240 C26 214 42 204 64 204 C86 204 102 214 104 240z",
        fill: "#137a47",
      }),
      e.jsx("circle", { cx: 64, cy: 188, r: 18, fill: "#111b23" }),
      e.jsx("path", {
        d: "M44 188 a20 20 0 0 1 40 0",
        fill: "none",
        stroke: "#8ba3b7",
        strokeWidth: 4,
      }),
      e.jsx("rect", {
        x: 40,
        y: 184,
        width: 8,
        height: 14,
        rx: 3,
        fill: "#54697c",
      }),
      e.jsx("rect", {
        x: 80,
        y: 184,
        width: 8,
        height: 14,
        rx: 3,
        fill: "#54697c",
      }),
      e.jsx("path", {
        d: "M152 99 C210 99 232 140 282 140",
        fill: "none",
        stroke: "#cb5651",
        strokeWidth: 2,
        strokeDasharray: "5 4",
        className: "attack-flow",
      }),
      e.jsx("rect", {
        x: 282,
        y: 14,
        width: 110,
        height: 212,
        rx: 4,
        fill: "#242f38",
        stroke: "#46515b",
      }),
      e.jsx("rect", {
        x: 282,
        y: 14,
        width: 110,
        height: 20,
        rx: 4,
        fill: "#2b3f50",
      }),
      e.jsx(R, { x: 294, y: 24, s: 0.6 }),
      e.jsx(r, {
        x: 346,
        y: 28,
        size: 8,
        anchor: "middle",
        fill: "#e3e9ee",
        children: "UNRELEASED",
      }),
      [40, 62].map((t) =>
        e.jsxs(
          "g",
          {
            children: [
              e.jsx("rect", {
                x: 290,
                y: t,
                width: 94,
                height: 18,
                rx: 2,
                fill: "#333e48",
              }),
              e.jsx("circle", { cx: 298, cy: t + 9, r: 2.2, fill: "#7ed99f" }),
              e.jsx("circle", { cx: 306, cy: t + 9, r: 2.2, fill: "#7ed99f" }),
              [0, 1, 2, 3, 4].map((s) =>
                e.jsx(
                  "path",
                  {
                    d: `M${330 + s * 10} ${t + 5} v8`,
                    stroke: "#242f38",
                    strokeWidth: 2,
                  },
                  s,
                ),
              ),
            ],
          },
          t,
        ),
      ),
      e.jsx("rect", {
        x: 288,
        y: 88,
        width: 98,
        height: 132,
        rx: 2,
        fill: "#480004",
      }),
      i.map((t, s) => {
        const l = 294 + (s % 2) * 46,
          a = 94 + Math.floor(s / 2) * 42;
        return e.jsxs(
          "g",
          {
            children: [
              e.jsx("rect", {
                x: l,
                y: a,
                width: 40,
                height: 34,
                rx: 3,
                fill: t,
              }),
              e.jsx("circle", {
                cx: l + 20,
                cy: a + 15,
                r: 8,
                fill: "#111b23",
                opacity: 0.55,
              }),
              e.jsx("path", {
                d: `M${l + 17} ${a + 10.5} L${l + 25} ${a + 15} L${l + 17} ${a + 19.5}z`,
                fill: "#e3e9ee",
              }),
              e.jsx("rect", {
                x: l,
                y: a + 27,
                width: 40,
                height: 7,
                fill: "#111b23",
                opacity: 0.6,
              }),
            ],
          },
          t,
        );
      }),
      e.jsx("path", {
        d: "M288 88 L262 98 V210 L288 220z",
        fill: "#333e48",
        stroke: "#5c6873",
      }),
      e.jsx("rect", {
        x: 267,
        y: 148,
        width: 4,
        height: 14,
        rx: 2,
        fill: "#95a1ac",
      }),
      e.jsx("path", {
        d: "M288 88 L262 98 V210 L288 220",
        fill: "none",
        stroke: "#cb5651",
        strokeWidth: 2,
        className: "attack-flash-stroke",
      }),
    ],
  });
}
function Ws({ x: i, y: t }) {
  return e.jsxs("g", {
    children: [
      e.jsx("rect", {
        x: i,
        y: t,
        width: 36,
        height: 24,
        rx: 2,
        fill: "#242f38",
        stroke: "#46515b",
      }),
      e.jsx("rect", {
        x: i + 3,
        y: t + 3,
        width: 30,
        height: 18,
        fill: "#480004",
      }),
      e.jsx("circle", { cx: i + 18, cy: t + 10.5, r: 5, fill: "#ffa79f" }),
      e.jsx("rect", {
        x: i + 15,
        y: t + 13,
        width: 6,
        height: 4,
        rx: 1,
        fill: "#ffa79f",
      }),
      e.jsx("circle", { cx: i + 16, cy: t + 10, r: 1.4, fill: "#480004" }),
      e.jsx("circle", { cx: i + 20, cy: t + 10, r: 1.4, fill: "#480004" }),
      e.jsx("path", {
        d: `M${i - 4} ${t + 24} h44 l-4 4 h-36z`,
        fill: "#46515b",
      }),
    ],
  });
}
function $s() {
  const i = [12, 56, 100, 144, 188],
    t = [56, 94, 132, 170],
    s = [0, 1, 2, 3, 4, 5, 6, 7];
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#0d171f" }),
      e.jsxs(f, {
        x: 8,
        y: 8,
        w: 206,
        h: 178,
        bar: "#2b3f50",
        children: [
          e.jsx("rect", {
            x: 9,
            y: 24,
            width: 204,
            height: 126,
            fill: "#137a47",
          }),
          [0, 2, 4, 6].map((l) =>
            e.jsx(
              "rect",
              {
                x: 9 + l * 25.5,
                y: 24,
                width: 25.5,
                height: 126,
                fill: "#006034",
              },
              l,
            ),
          ),
          e.jsxs("g", {
            fill: "none",
            stroke: "#bac3cb",
            strokeWidth: 1.4,
            opacity: 0.8,
            children: [
              e.jsx("rect", { x: 18, y: 34, width: 186, height: 106 }),
              e.jsx("path", { d: "M111 34 V140" }),
              e.jsx("circle", { cx: 111, cy: 87, r: 18 }),
              e.jsx("rect", { x: 18, y: 64, width: 22, height: 46 }),
              e.jsx("rect", { x: 182, y: 64, width: 22, height: 46 }),
            ],
          }),
          e.jsx("rect", {
            x: 9,
            y: 24,
            width: 204,
            height: 126,
            fill: "#0d171f",
            opacity: 0.6,
          }),
          s.map((l) => {
            const a = (l * Math.PI) / 4;
            return e.jsx(
              "path",
              {
                d: `M${111 + Math.cos(a) * 9} ${87 + Math.sin(a) * 9} L${111 + Math.cos(a) * 17} ${87 + Math.sin(a) * 17}`,
                stroke: "#e3e9ee",
                strokeWidth: 3.5,
                strokeLinecap: "round",
                opacity: 0.25 + l * 0.1,
              },
              l,
            );
          }),
          e.jsx("rect", {
            x: 15,
            y: 30,
            width: 30,
            height: 14,
            rx: 3,
            fill: "#cb5651",
          }),
          e.jsx("circle", {
            cx: 21,
            cy: 37,
            r: 2.4,
            fill: "#e3e9ee",
            className: "attack-flash",
          }),
          e.jsx(r, {
            x: 26,
            y: 40.5,
            size: 7.5,
            fill: "#e3e9ee",
            children: "LIVE",
          }),
          e.jsx("rect", {
            x: 49,
            y: 30,
            width: 80,
            height: 14,
            rx: 3,
            fill: "#111b23",
            opacity: 0.85,
          }),
          e.jsx("path", {
            d: "M54 37 q6 -5 12 0 q-6 5 -12 0z",
            fill: "#7ed99f",
          }),
          e.jsx("circle", { cx: 60, cy: 37, r: 1.8, fill: "#111b23" }),
          e.jsx(r, {
            x: 70,
            y: 40.5,
            size: 7.5,
            fill: "#7ed99f",
            children: "300M watching",
          }),
          e.jsx("rect", {
            x: 160,
            y: 30,
            width: 46,
            height: 14,
            rx: 3,
            fill: "#111b23",
            opacity: 0.85,
          }),
          e.jsx(r, {
            x: 183,
            y: 40.5,
            size: 7.5,
            anchor: "middle",
            fill: "#e8ba61",
            children: "FINAL",
          }),
          e.jsx("rect", {
            x: 9,
            y: 150,
            width: 204,
            height: 35,
            fill: "#111b23",
          }),
          e.jsx("path", { d: "M18 160 l9 6 l-9 6z", fill: "#bac3cb" }),
          e.jsx("rect", {
            x: 36,
            y: 164,
            width: 140,
            height: 4,
            rx: 2,
            fill: "#333e48",
          }),
          e.jsx("rect", {
            x: 36,
            y: 164,
            width: 52,
            height: 4,
            rx: 2,
            fill: "#cb5651",
          }),
          e.jsx("circle", { cx: 88, cy: 166, r: 4, fill: "#cb5651" }),
          e.jsx("circle", { cx: 186, cy: 166, r: 3, fill: "#cb5651" }),
          e.jsx(r, {
            x: 192,
            y: 169,
            size: 7,
            fill: "#bac3cb",
            children: "LIVE",
          }),
        ],
      }),
      e.jsx("rect", {
        x: 8,
        y: 196,
        width: 206,
        height: 34,
        rx: 4,
        fill: "#480004",
        stroke: "#cb5651",
        strokeWidth: 2,
        className: "attack-flash-stroke",
      }),
      e.jsx(M, {
        x: 111,
        y: 218,
        size: 12,
        fill: "#ffa79f",
        anchor: "middle",
        children: "2.4bn requests/s",
      }),
      e.jsx("rect", {
        x: 226,
        y: 36,
        width: 66,
        height: 172,
        rx: 4,
        fill: "#242f38",
        stroke: "#46515b",
      }),
      e.jsx(R, { x: 240, y: 22, s: 0.7 }),
      e.jsx(r, { x: 254, y: 26, size: 8, fill: "#bac3cb", children: "STREAM" }),
      t.map((l) =>
        e.jsxs(
          "g",
          {
            children: [
              e.jsx("rect", {
                x: 232,
                y: l - 15,
                width: 54,
                height: 30,
                rx: 2,
                fill: "#333e48",
              }),
              e.jsx("circle", {
                cx: 240,
                cy: l,
                r: 2.6,
                fill: "#cb5651",
                className: "attack-flash",
              }),
              e.jsx("circle", { cx: 248, cy: l, r: 2.6, fill: "#e8ba61" }),
              [0, 1, 2].map((a) =>
                e.jsx(
                  "path",
                  {
                    d: `M${258 + a * 8} ${l - 7} v14`,
                    stroke: "#242f38",
                    strokeWidth: 2,
                  },
                  a,
                ),
              ),
            ],
          },
          l,
        ),
      ),
      e.jsx("path", { d: "M214 96 H226", stroke: "#46515b", strokeWidth: 4 }),
      i.flatMap((l, a) =>
        t
          .filter((c, h) => Math.abs(h - a * 0.75) <= 1.1)
          .map((c) => {
            const o = l + 12,
              d = 294,
              n = (Math.atan2(c - o, d - 338) * 180) / Math.PI;
            return e.jsxs(
              "g",
              {
                children: [
                  e.jsx("path", {
                    d: `M338 ${o} L${d + 6} ${c}`,
                    stroke: "#cb5651",
                    strokeWidth: 1.6,
                    strokeDasharray: "4 3",
                    opacity: 0.85,
                    className: "attack-flow",
                  }),
                  e.jsx("path", {
                    d: "M0 0 l8 -4 v8z",
                    fill: "#cb5651",
                    transform: `translate(${d} ${c}) rotate(${n + 180})`,
                  }),
                ],
              },
              `${l}-${c}`,
            );
          }),
      ),
      i.map((l) => e.jsx(Ws, { x: 348, y: l }, l)),
    ],
  });
}
const Ts = {
  law_phishing: {
    Art: ys,
    bg: "#111b23",
    alt: "A lawyer at his desk is about to type his password into a fake Harcourt & Vale document login page on a lookalike web address, after an email said a client had shared a confidential document.",
  },
  law_laptop_theft: {
    Art: ps,
    bg: "#0d171f",
    alt: "On a night commuter train a partner sleeps in his seat while a hooded thief walks off with his laptop bag from the luggage rack, and the laptop inside shows a confidential divorce case file.",
  },
  law_ransomware: {
    Art: bs,
    bg: "#0d171f",
    alt: "A red screen with a padlock says pay or we publish with a countdown, the case folders are locked, and a leak site lists client cases such as a merger and a divorce ready to be released.",
  },
  law_brute_force: {
    Art: vs,
    bg: "#111b23",
    alt: "A bot fires password guesses such as yacht2024, Monaco! and password123 at the Harcourt & Vale client portal login of a billionaire private client, and the failed attempt counter keeps climbing.",
  },
  law_court_interception: {
    Art: zs,
    bg: "#0d171f",
    alt: "In a courtroom a barrister sends a witness statement from his laptop over the court’s free Wi-Fi, while a journalist on the public benches captures the packets on his own laptop and reads the statement.",
  },
  vidora_brute_force: {
    Art: ks,
    bg: "#0d171f",
    alt: "Bots fire password guesses such as kaizoom1 and 40million at the Vidora login of a creator with 40 million subscribers, and the failed attempt counter passes a million.",
  },
  vidora_sql_injection: {
    Art: us,
    bg: "#051827",
    alt: "Someone types an SQL command into the search box on the Vidora creator payouts page and the database spills out every creator’s bank details and earnings.",
  },
  vidora_blagging: {
    Art: ms,
    bg: "#0d171f",
    alt: "A caller in sunglasses with a fake VIP manager pass shouts down the phone at a Vidora support agent to reset a star creator’s password, five minutes before a live stream with two million viewers waiting.",
  },
  vidora_trojan: {
    Art: Ls,
    bg: "#0d171f",
    alt: "A Vidora engineer installs a free 8K filter plugin shaped like a gift-wrapped wooden horse, and a hidden door in its side opens a back door into the server rack of unreleased videos.",
  },
  vidora_ddos: {
    Art: $s,
    bg: "#0d171f",
    alt: "The live stream of the football final shows 300 million watching but only a buffering spinner, as a botnet of hijacked computers floods Vidora’s streaming servers with billions of requests.",
  },
};
function C({
  x: i,
  y: t,
  size: s = 8,
  fill: l = "#111b23",
  anchor: a = "start",
  children: c,
}) {
  return e.jsx("text", {
    x: i,
    y: t,
    fontSize: s,
    fill: l,
    fontWeight: 700,
    textAnchor: a,
    fontFamily: "'Courier New', Courier, monospace",
    children: c,
  });
}
function qt({ x: i, y: t }) {
  return e.jsx("path", {
    d: `M${i} ${t} l0 18 l5 -5 l4 9 l4 -2 l-4 -9 l7 0z`,
    fill: "#e3e9ee",
    stroke: "#111b23",
    strokeWidth: 1.2,
    strokeLinejoin: "round",
  });
}
function Dt({ x: i, y: t, s = 1, fill: l }) {
  return e.jsxs("g", {
    transform: `translate(${i} ${t}) scale(${s})`,
    children: [
      e.jsx("circle", { cx: 0, cy: -4, r: 2.6, fill: l }),
      e.jsx("rect", { x: -1.5, y: -2, width: 3, height: 24, fill: l }),
      e.jsx("rect", { x: -9, y: 21, width: 18, height: 4, rx: 1.5, fill: l }),
      e.jsx("rect", {
        x: -16,
        y: -1,
        width: 32,
        height: 2.6,
        rx: 1.3,
        fill: l,
      }),
      e.jsx("path", {
        d: "M-14 1 L-20 13 M-14 1 L-8 13 M14 1 L8 13 M14 1 L20 13",
        stroke: l,
        strokeWidth: 1,
        fill: "none",
      }),
      e.jsx("path", {
        d: "M-22 13 h16 a8 5 0 0 1 -16 0z M6 13 h16 a8 5 0 0 1 -16 0z",
        fill: l,
      }),
    ],
  });
}
function se({ x: i, y: t, s = 1 }) {
  return e.jsxs("g", {
    transform: `translate(${i} ${t}) scale(${s})`,
    children: [
      e.jsx("rect", {
        x: -10,
        y: -10,
        width: 20,
        height: 20,
        rx: 6,
        fill: "#54697c",
      }),
      e.jsx("path", {
        d: "M-3.5 -5.5 L6 0 L-3.5 5.5z",
        fill: "#7ed99f",
        strokeLinejoin: "round",
      }),
    ],
  });
}
function Cs() {
  const i = [
    "OKAFOR 14 Elm Rd 20-45-77",
    "PRICE  9 Mill Ln 40-12-09",
    "HUGHES 2 Bank St 30-98-11",
    "NOVAK  7 Kew Grn 60-55-02",
    "BELLO  3 Ash Ct  11-20-63",
  ];
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#111b23" }),
      e.jsx("rect", { x: 0, y: 204, width: 400, height: 36, fill: "#242f38" }),
      e.jsxs(f, {
        x: 10,
        y: 10,
        w: 232,
        h: 166,
        bar: "#00425f",
        children: [
          e.jsx("rect", {
            x: 11,
            y: 26,
            width: 230,
            height: 14,
            fill: "#bac3cb",
          }),
          e.jsx(r, {
            x: 126,
            y: 36,
            size: 7,
            weight: 400,
            anchor: "middle",
            fill: "#333e48",
            children: "harcourtvale.com/track-my-case",
          }),
          e.jsx(Dt, { x: 32, y: 54, s: 0.55, fill: "#746351" }),
          e.jsx(r, {
            x: 50,
            y: 65,
            size: 12,
            fill: "#00425f",
            children: "Track your case",
          }),
          e.jsx(r, {
            x: 22,
            y: 84,
            size: 7.5,
            fill: "#46515b",
            children: "Case reference",
          }),
          e.jsx("rect", {
            x: 22,
            y: 89,
            width: 208,
            height: 22,
            rx: 3,
            fill: "#e3e9ee",
            stroke: "#cb5651",
            strokeWidth: 1.6,
          }),
          e.jsx(C, {
            x: 29,
            y: 104,
            size: 11,
            fill: "#ac3a38",
            children: "' OR 1=1; --",
          }),
          e.jsx("path", {
            d: "M113 93 V107",
            stroke: "#111b23",
            strokeWidth: 1.2,
            className: "attack-flash",
          }),
          e.jsx("rect", {
            x: 22,
            y: 117,
            width: 62,
            height: 17,
            rx: 3,
            fill: "#00425f",
          }),
          e.jsx(r, {
            x: 53,
            y: 128.5,
            size: 8,
            anchor: "middle",
            fill: "#e3e9ee",
            children: "Track",
          }),
          e.jsx(qt, { x: 76, y: 127 }),
          e.jsx("path", {
            d: "M34 152 H200",
            stroke: "#bac3cb",
            strokeWidth: 2,
          }),
          [
            { x: 34, label: "Offer", fill: "#399661" },
            { x: 89, label: "Searches", fill: "#399661" },
            { x: 145, label: "Exchange", fill: "#bac3cb" },
            { x: 200, label: "Complete", fill: "#bac3cb" },
          ].map(({ x: t, label: s, fill: l }) =>
            e.jsxs(
              "g",
              {
                children: [
                  e.jsx("circle", { cx: t, cy: 152, r: 4.5, fill: l }),
                  e.jsx(r, {
                    x: t,
                    y: 167,
                    size: 7,
                    weight: 400,
                    anchor: "middle",
                    fill: "#46515b",
                    children: s,
                  }),
                ],
              },
              s,
            ),
          ),
        ],
      }),
      e.jsx("path", {
        d: "M231 100 C262 100 266 74 294 74",
        fill: "none",
        stroke: "#cb5651",
        strokeWidth: 2,
        strokeDasharray: "5 4",
        className: "attack-flow",
      }),
      e.jsx("path", {
        d: "M296 40 v62 a34 9 0 0 0 68 0 v-62",
        fill: "#333e48",
      }),
      e.jsx("path", {
        d: "M296 61 a34 9 0 0 0 68 0",
        fill: "none",
        stroke: "#242f38",
        strokeWidth: 2,
      }),
      e.jsx("ellipse", { cx: 330, cy: 40, rx: 34, ry: 9, fill: "#46515b" }),
      e.jsx(r, {
        x: 330,
        y: 83,
        size: 8.5,
        anchor: "middle",
        fill: "#e3e9ee",
        children: "CLIENTS",
      }),
      e.jsx(r, {
        x: 330,
        y: 95,
        size: 7,
        weight: 400,
        anchor: "middle",
        fill: "#bac3cb",
        children: "case files",
      }),
      e.jsx("path", {
        d: "M330 112 V124",
        stroke: "#cb5651",
        strokeWidth: 2,
        strokeDasharray: "3 3",
      }),
      e.jsx("rect", {
        x: 252,
        y: 124,
        width: 140,
        height: 106,
        rx: 4,
        fill: "#111b23",
        stroke: "#cb5651",
        strokeWidth: 1.6,
        className: "attack-flash-stroke",
      }),
      e.jsx(r, {
        x: 322,
        y: 139,
        size: 8,
        anchor: "middle",
        fill: "#ee766f",
        children: "60,412 rows returned",
      }),
      i.map((t, s) =>
        e.jsx(
          C,
          {
            x: 259,
            y: 156 + s * 14,
            size: 7,
            fill: s === 4 ? "#5c6873" : "#bac3cb",
            children: t,
          },
          t,
        ),
      ),
      e.jsx("path", {
        d: "M62 240 C64 214 86 204 116 204 C146 204 168 214 170 240z",
        fill: "#111b23",
      }),
      e.jsx("ellipse", { cx: 116, cy: 199, rx: 20, ry: 22, fill: "#242f38" }),
      e.jsx("path", {
        d: "M100 210 q16 8 32 0",
        fill: "none",
        stroke: "#0d171f",
        strokeWidth: 2,
      }),
    ],
  });
}
function Ns() {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#111b23" }),
      e.jsx("rect", {
        x: 8,
        y: 10,
        width: 180,
        height: 128,
        rx: 6,
        fill: "#111b23",
      }),
      e.jsxs(f, {
        x: 14,
        y: 16,
        w: 168,
        h: 116,
        bar: "#00425f",
        children: [
          e.jsx(r, {
            x: 44,
            y: 27,
            size: 7,
            fill: "#e3e9ee",
            children: "Completion: 14 Elm Road",
          }),
          e.jsx(r, {
            x: 22,
            y: 46,
            size: 7.5,
            fill: "#46515b",
            children: "Sale proceeds",
          }),
          e.jsx(r, {
            x: 174,
            y: 46,
            size: 10,
            anchor: "end",
            fill: "#111b23",
            children: "£640,000",
          }),
          e.jsx("path", {
            d: "M22 52 H174",
            stroke: "#bac3cb",
            strokeWidth: 1.2,
          }),
          e.jsx(r, {
            x: 22,
            y: 63,
            size: 7,
            weight: 400,
            fill: "#46515b",
            children: "Pay to: Mrs A Okafor",
          }),
          e.jsx(C, {
            x: 22,
            y: 76,
            size: 8,
            fill: "#95a1ac",
            children: "20-45-77 31174220",
          }),
          e.jsx("path", {
            d: "M20 73.5 H106",
            stroke: "#cb5651",
            strokeWidth: 1.4,
          }),
          e.jsx("rect", {
            x: 20,
            y: 81,
            width: 154,
            height: 14,
            rx: 2,
            fill: "#bac3cb",
            stroke: "#cb5651",
          }),
          e.jsx(C, {
            x: 24,
            y: 91,
            size: 8,
            fill: "#ac3a38",
            children: "60-11-02 88213409",
          }),
          e.jsx(r, {
            x: 170,
            y: 91,
            size: 7,
            anchor: "end",
            fill: "#ac3a38",
            children: "NEW",
          }),
          e.jsx("rect", {
            x: 22,
            y: 104,
            width: 74,
            height: 18,
            rx: 3,
            fill: "#399661",
          }),
          e.jsx(r, {
            x: 59,
            y: 116,
            size: 8,
            anchor: "middle",
            fill: "#e3e9ee",
            children: "Send funds",
          }),
          e.jsx(qt, { x: 90, y: 113 }),
          e.jsx("rect", {
            x: 128,
            y: 101,
            width: 46,
            height: 26,
            fill: "#ffe4b4",
            transform: "rotate(5 151 114)",
          }),
          e.jsx(r, {
            x: 151,
            y: 112,
            size: 7,
            anchor: "middle",
            fill: "#5c4d3b",
            children: "Done by",
          }),
          e.jsx(r, {
            x: 151,
            y: 123,
            size: 9,
            anchor: "middle",
            fill: "#ac3a38",
            children: "2pm!",
          }),
        ],
      }),
      e.jsx("rect", { x: 88, y: 138, width: 20, height: 34, fill: "#333e48" }),
      e.jsx("rect", {
        x: 72,
        y: 170,
        width: 52,
        height: 7,
        rx: 2,
        fill: "#333e48",
      }),
      e.jsx("circle", {
        cx: 234,
        cy: 40,
        r: 20,
        fill: "#e3e9ee",
        stroke: "#95a1ac",
        strokeWidth: 3,
      }),
      [0, 90, 180, 270].map((i) =>
        e.jsx(
          "rect",
          {
            x: 233,
            y: 23,
            width: 2,
            height: 4,
            fill: "#46515b",
            transform: `rotate(${i} 234 40)`,
          },
          i,
        ),
      ),
      e.jsx("path", {
        d: "M234 40 L244 35",
        stroke: "#111b23",
        strokeWidth: 2.4,
        strokeLinecap: "round",
      }),
      e.jsx("path", {
        d: "M234 40 L220 32",
        stroke: "#111b23",
        strokeWidth: 1.6,
        strokeLinecap: "round",
      }),
      e.jsx("path", {
        d: "M234 40 L234 24",
        stroke: "#cb5651",
        strokeWidth: 1,
        className: "attack-flash",
      }),
      e.jsx("rect", { x: 0, y: 176, width: 400, height: 9, fill: "#5c4d3b" }),
      e.jsx("rect", { x: 0, y: 185, width: 400, height: 55, fill: "#242f38" }),
      e.jsx("path", { d: "M0 210 H400", stroke: "#19232c", strokeWidth: 2 }),
      e.jsx("path", {
        d: "M196 176 L198 136 q2 -14 26 -14 q24 0 26 14 l2 40z",
        fill: "#ac3a38",
      }),
      e.jsx("path", { d: "M216 122 l8 10 l8 -10z", fill: "#e3e9ee" }),
      e.jsx("rect", { x: 218, y: 110, width: 12, height: 13, fill: "#8d5524" }),
      e.jsx("circle", { cx: 224, cy: 100, r: 15, fill: "#8d5524" }),
      e.jsx("path", {
        d: "M208 102 a16 16 0 0 1 32 -4 q-6 -8 -16 -8 q-12 0 -16 12z",
        fill: "#111b23",
      }),
      e.jsx("circle", { cx: 224, cy: 84, r: 7, fill: "#111b23" }),
      e.jsx("circle", { cx: 219, cy: 101, r: 1.5, fill: "#111b23" }),
      e.jsx("circle", { cx: 229, cy: 101, r: 1.5, fill: "#111b23" }),
      e.jsx("path", {
        d: "M215 95 l6 2 M233 95 l-6 2",
        stroke: "#111b23",
        strokeWidth: 1.4,
      }),
      e.jsx("path", {
        d: "M220 109 q4 -3 8 0",
        fill: "none",
        stroke: "#111b23",
        strokeWidth: 1.4,
      }),
      e.jsx("path", {
        d: "M246 140 L252 112",
        stroke: "#ac3a38",
        strokeWidth: 9,
        strokeLinecap: "round",
      }),
      e.jsx("rect", {
        x: 236,
        y: 92,
        width: 10,
        height: 26,
        rx: 4,
        fill: "#242f38",
      }),
      e.jsx("circle", { cx: 250, cy: 110, r: 4.5, fill: "#8d5524" }),
      e.jsx("path", {
        d: "M241 118 q4 10 -2 18 q-6 8 2 16 q6 8 -2 16",
        fill: "none",
        stroke: "#242f38",
        strokeWidth: 1.4,
      }),
      e.jsx("rect", {
        x: 232,
        y: 166,
        width: 30,
        height: 10,
        rx: 3,
        fill: "#242f38",
      }),
      e.jsx("circle", {
        cx: 176,
        cy: 170,
        r: 5,
        fill: "none",
        stroke: "#e8ba61",
        strokeWidth: 2,
      }),
      e.jsx("path", {
        d: "M171 172 L160 170 M163 170 v3",
        stroke: "#e8ba61",
        strokeWidth: 2,
      }),
      e.jsx("rect", {
        x: 136,
        y: 160,
        width: 22,
        height: 11,
        rx: 2,
        fill: "#d1beaa",
        stroke: "#c4973c",
      }),
      e.jsx(r, {
        x: 147,
        y: 168.5,
        size: 7,
        anchor: "middle",
        fill: "#ac3a38",
        children: "Elm",
      }),
      e.jsx("rect", {
        x: 280,
        y: 10,
        width: 112,
        height: 104,
        rx: 8,
        fill: "#081b2b",
        stroke: "#cb5651",
        strokeWidth: 1.8,
        className: "attack-flash-stroke",
      }),
      e.jsx(r, {
        x: 336,
        y: 24,
        size: 7,
        anchor: "middle",
        fill: "#ffa79f",
        children: "Caller ID: Mrs Okafor",
      }),
      e.jsx("path", {
        d: "M296 114 L298 88 q2 -12 22 -12 q20 0 22 12 l2 26z",
        fill: "#333e48",
      }),
      e.jsx("circle", { cx: 320, cy: 60, r: 13, fill: "#e0ac69" }),
      e.jsx("path", { d: "M306 58 a14 14 0 0 1 28 0z", fill: "#111b23" }),
      e.jsx("path", {
        d: "M304 58 h34",
        stroke: "#111b23",
        strokeWidth: 3,
        strokeLinecap: "round",
      }),
      e.jsx("rect", {
        x: 313,
        y: 60,
        width: 7,
        height: 4,
        rx: 1,
        fill: "#111b23",
      }),
      e.jsx("rect", {
        x: 322,
        y: 60,
        width: 7,
        height: 4,
        rx: 1,
        fill: "#111b23",
      }),
      e.jsx("path", {
        d: "M316 69 q4 3 8 0",
        fill: "none",
        stroke: "#901e21",
        strokeWidth: 1.2,
      }),
      e.jsx("rect", {
        x: 302,
        y: 56,
        width: 6,
        height: 14,
        rx: 2,
        fill: "#111b23",
      }),
      e.jsx("path", {
        d: "M306 82 L304 70",
        stroke: "#333e48",
        strokeWidth: 7,
        strokeLinecap: "round",
      }),
      e.jsx("rect", {
        x: 346,
        y: 66,
        width: 34,
        height: 42,
        fill: "#e3e9ee",
        transform: "rotate(6 363 87)",
      }),
      e.jsx(r, {
        x: 363,
        y: 78,
        size: 7,
        anchor: "middle",
        fill: "#ac3a38",
        children: "SCRIPT",
      }),
      [86, 92, 98].map((i) =>
        e.jsx(
          "rect",
          {
            x: 352,
            y: i,
            width: 22,
            height: 2,
            fill: "#95a1ac",
            transform: "rotate(6 363 87)",
          },
          i,
        ),
      ),
      e.jsx("path", {
        d: "M338 92 L350 96",
        stroke: "#333e48",
        strokeWidth: 7,
        strokeLinecap: "round",
      }),
      e.jsx("path", {
        d: "M300 64 C280 80 262 84 246 100",
        fill: "none",
        stroke: "#cb5651",
        strokeWidth: 1.8,
        strokeDasharray: "4 4",
        className: "attack-flow",
      }),
      e.jsx("path", { d: "M318 122 l10 -10 l4 10z", fill: "#e3e9ee" }),
      e.jsx("rect", {
        x: 270,
        y: 120,
        width: 122,
        height: 44,
        rx: 8,
        fill: "#e3e9ee",
      }),
      e.jsx(r, {
        x: 331,
        y: 138,
        size: 8,
        anchor: "middle",
        fill: "#111b23",
        children: "I've changed banks!",
      }),
      e.jsx(r, {
        x: 331,
        y: 154,
        size: 8,
        anchor: "middle",
        fill: "#ac3a38",
        children: "Send it before 2pm!",
      }),
    ],
  });
}
function Ss() {
  const i = [14, 50, 86].flatMap((t) =>
    [40, 96, 152].map((s) => ({ x: t, y: s })),
  );
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#0d171f" }),
      e.jsx("rect", { x: 0, y: 214, width: 400, height: 26, fill: "#111b23" }),
      e.jsx(r, {
        x: 60,
        y: 24,
        size: 9,
        anchor: "middle",
        fill: "#ee766f",
        children: "BOTNET",
      }),
      i.map(({ x: t, y: s }) =>
        e.jsxs(
          "g",
          {
            children: [
              e.jsx("rect", {
                x: t,
                y: s,
                width: 30,
                height: 22,
                rx: 2,
                fill: "#242f38",
              }),
              e.jsx("rect", {
                x: t + 3,
                y: s + 3,
                width: 24,
                height: 16,
                fill: "#901e21",
              }),
              e.jsx("path", {
                d: `M${t + 10} ${s + 8} l3 3 l-3 3 M${t + 16} ${s + 14} h5`,
                fill: "none",
                stroke: "#ffa79f",
                strokeWidth: 1.4,
              }),
              e.jsx("rect", {
                x: t + 12,
                y: s + 22,
                width: 6,
                height: 5,
                fill: "#333e48",
              }),
              e.jsx("rect", {
                x: t + 8,
                y: s + 27,
                width: 14,
                height: 3,
                rx: 1,
                fill: "#333e48",
              }),
            ],
          },
          `${t}-${s}`,
        ),
      ),
      e.jsx(r, {
        x: 60,
        y: 200,
        size: 7,
        weight: 400,
        anchor: "middle",
        fill: "#95a1ac",
        children: "hijacked computers",
      }),
      i.map(({ x: t, y: s }, l) =>
        e.jsx(
          "path",
          {
            d: `M${t + 31} ${s + 11} C${t + 70} ${s + 11} 140 ${60 + l * 14} 170 ${60 + l * 14}`,
            fill: "none",
            stroke: "#cb5651",
            strokeWidth: 1.4,
            strokeDasharray: "4 5",
            className: "attack-flow",
            opacity: 0.85,
          },
          `f${l}`,
        ),
      ),
      e.jsx("rect", {
        x: 170,
        y: 40,
        width: 70,
        height: 158,
        rx: 4,
        fill: "#242f38",
        stroke: "#46515b",
      }),
      e.jsx("rect", {
        x: 170,
        y: 40,
        width: 70,
        height: 18,
        rx: 4,
        fill: "#00425f",
      }),
      e.jsx(r, {
        x: 205,
        y: 53,
        size: 8,
        anchor: "middle",
        fill: "#e3e9ee",
        children: "DATA ROOM",
      }),
      [64, 86, 108, 130].map((t) =>
        e.jsxs(
          "g",
          {
            children: [
              e.jsx("rect", {
                x: 177,
                y: t,
                width: 56,
                height: 16,
                rx: 2,
                fill: "#333e48",
              }),
              e.jsx("circle", {
                cx: 185,
                cy: t + 8,
                r: 2.4,
                fill: "#cb5651",
                className: "attack-flash",
              }),
              e.jsx("circle", {
                cx: 193,
                cy: t + 8,
                r: 2.4,
                fill: "#cb5651",
                className: "attack-flash",
              }),
              [0, 1, 2].map((s) =>
                e.jsx(
                  "path",
                  {
                    d: `M${208 + s * 8} ${t + 4} v8`,
                    stroke: "#242f38",
                    strokeWidth: 2,
                  },
                  s,
                ),
              ),
            ],
          },
          t,
        ),
      ),
      e.jsx(Dt, { x: 205, y: 160, s: 0.62, fill: "#746351" }),
      [188, 205, 222].map((t) =>
        e.jsx(
          "path",
          {
            d: `M${t} 34 q-4 -5 0 -10 q4 -5 0 -10`,
            fill: "none",
            stroke: "#e8ba61",
            strokeWidth: 1.6,
            strokeLinecap: "round",
          },
          t,
        ),
      ),
      e.jsx(r, {
        x: 205,
        y: 212,
        size: 8,
        anchor: "middle",
        fill: "#e8ba61",
        children: "4.2m requests/sec",
      }),
      e.jsx("path", {
        d: "M241 92 H256",
        stroke: "#5c6873",
        strokeWidth: 1.6,
        strokeDasharray: "3 3",
      }),
      e.jsx("path", {
        d: "M244 86 l8 12 M252 86 l-8 12",
        stroke: "#cb5651",
        strokeWidth: 2.2,
      }),
      e.jsxs(f, {
        x: 258,
        y: 20,
        w: 134,
        h: 126,
        bar: "#333e48",
        children: [
          e.jsx(r, {
            x: 288,
            y: 31,
            size: 7,
            fill: "#e3e9ee",
            children: "Falcon data room",
          }),
          e.jsx(r, {
            x: 325,
            y: 70,
            size: 28,
            anchor: "middle",
            fill: "#ac3a38",
            children: "503",
          }),
          e.jsx(r, {
            x: 325,
            y: 86,
            size: 7.5,
            anchor: "middle",
            fill: "#333e48",
            children: "Data room unavailable",
          }),
          e.jsx("path", {
            d: "M268 94 H382",
            stroke: "#bac3cb",
            strokeWidth: 1.2,
          }),
          e.jsx(r, {
            x: 325,
            y: 107,
            size: 7,
            weight: 400,
            anchor: "middle",
            fill: "#46515b",
            children: "Final bids close in",
          }),
          e.jsx("g", {
            className: "attack-flash",
            children: e.jsx(C, {
              x: 325,
              y: 128,
              size: 15,
              anchor: "middle",
              fill: "#ac3a38",
              children: "02:59:41",
            }),
          }),
        ],
      }),
      e.jsx("path", {
        d: "M292 214 L296 186 q4 -14 30 -14 q26 0 30 14 l4 28z",
        fill: "#00425f",
      }),
      e.jsx("path", { d: "M318 172 l8 10 l8 -10z", fill: "#e3e9ee" }),
      e.jsx("circle", { cx: 326, cy: 160, r: 13, fill: "#c68642" }),
      e.jsx("path", {
        d: "M313 158 a13 13 0 0 1 26 0 q-6 -6 -13 -5 q-8 1 -13 5z",
        fill: "#333e48",
      }),
      e.jsx("path", {
        d: "M321 166 q5 -3 10 0",
        fill: "none",
        stroke: "#111b23",
        strokeWidth: 1.4,
      }),
      e.jsx("circle", { cx: 321, cy: 159, r: 1.4, fill: "#111b23" }),
      e.jsx("circle", { cx: 331, cy: 159, r: 1.4, fill: "#111b23" }),
      e.jsx("path", {
        d: "M300 190 L304 156 M352 190 L348 156",
        stroke: "#00425f",
        strokeWidth: 8,
        strokeLinecap: "round",
      }),
      e.jsx("circle", { cx: 306, cy: 152, r: 4.5, fill: "#c68642" }),
      e.jsx("circle", { cx: 346, cy: 152, r: 4.5, fill: "#c68642" }),
    ],
  });
}
function As() {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#111b23" }),
      e.jsx("rect", { x: 0, y: 0, width: 400, height: 170, fill: "#242f38" }),
      e.jsx("rect", {
        x: 10,
        y: 12,
        width: 140,
        height: 90,
        rx: 3,
        fill: "#46515b",
      }),
      e.jsx("rect", { x: 15, y: 17, width: 130, height: 80, fill: "#00425f" }),
      e.jsx("path", {
        d: "M15 97 V66 h14 v-10 l6 -14 l6 14 v10 h14 v-18 l8 -20 l8 20 v18 h18 v-12 l6 -14 l6 14 v12 h14 v-8 l5 -12 l5 12 v8 h10 V97z",
        fill: "#5c6873",
      }),
      [34, 60, 90, 112].map((i) =>
        e.jsx(
          "path",
          { d: `M${i} 97 v-14 a4 4 0 0 1 8 0 v14`, fill: "#242f38" },
          i,
        ),
      ),
      e.jsx("path", {
        d: "M80 17 V97 M15 57 H145",
        stroke: "#46515b",
        strokeWidth: 3,
      }),
      e.jsx("rect", {
        x: 292,
        y: 12,
        width: 98,
        height: 72,
        rx: 3,
        fill: "#901e21",
      }),
      e.jsx("rect", { x: 296, y: 16, width: 90, height: 64, fill: "#242f38" }),
      e.jsx(r, {
        x: 341,
        y: 30,
        size: 9,
        anchor: "middle",
        fill: "#e3e9ee",
        children: "MENU",
      }),
      [
        ["Flat white", "3.40"],
        ["Latte", "3.60"],
        ["Tea", "2.10"],
      ].map(([i, t], s) =>
        e.jsxs(
          "g",
          {
            children: [
              e.jsx(r, {
                x: 302,
                y: 46 + s * 12,
                size: 7,
                weight: 400,
                fill: "#bac3cb",
                children: i,
              }),
              e.jsxs(r, {
                x: 380,
                y: 46 + s * 12,
                size: 7,
                weight: 400,
                anchor: "end",
                fill: "#ffe4b4",
                children: ["£", t],
              }),
            ],
          },
          i,
        ),
      ),
      e.jsx("rect", { x: 0, y: 200, width: 400, height: 40, fill: "#19232c" }),
      [40, 120, 200, 280, 360].map((i) =>
        e.jsx(
          "path",
          { d: `M${i} 200 l-20 40`, stroke: "#242f38", strokeWidth: 2 },
          i,
        ),
      ),
      e.jsx("rect", {
        x: 20,
        y: 164,
        width: 184,
        height: 7,
        rx: 2,
        fill: "#746351",
      }),
      e.jsx("rect", { x: 106, y: 171, width: 10, height: 32, fill: "#5c4d3b" }),
      e.jsx("rect", {
        x: 86,
        y: 200,
        width: 50,
        height: 5,
        rx: 2,
        fill: "#5c4d3b",
      }),
      e.jsx("path", {
        d: "M26 200 L30 150 q2 -26 30 -26 q24 0 28 22 l2 54z",
        fill: "#137a47",
      }),
      e.jsx("rect", { x: 52, y: 110, width: 11, height: 14, fill: "#f1c27d" }),
      e.jsx("circle", { cx: 60, cy: 102, r: 14, fill: "#f1c27d" }),
      e.jsx("path", {
        d: "M46 104 a15 15 0 0 1 26 -12 q-6 2 -12 1 q-4 6 -10 12z",
        fill: "#901e21",
      }),
      e.jsx("circle", { cx: 68, cy: 102, r: 1.5, fill: "#111b23" }),
      e.jsx("path", {
        d: "M70 140 L104 158 L124 158",
        fill: "none",
        stroke: "#137a47",
        strokeWidth: 9,
        strokeLinecap: "round",
        strokeLinejoin: "round",
      }),
      e.jsx("circle", { cx: 127, cy: 158, r: 4.5, fill: "#f1c27d" }),
      e.jsx("rect", {
        x: 96,
        y: 102,
        width: 84,
        height: 58,
        rx: 3,
        fill: "#111b23",
      }),
      e.jsx("rect", { x: 100, y: 106, width: 76, height: 50, fill: "#e3e9ee" }),
      e.jsx("rect", { x: 100, y: 106, width: 76, height: 12, fill: "#00425f" }),
      e.jsx(r, {
        x: 104,
        y: 115,
        size: 7,
        fill: "#e3e9ee",
        children: "H&V cases",
      }),
      e.jsx("rect", {
        x: 104,
        y: 122,
        width: 68,
        height: 11,
        rx: 2,
        fill: "#e3e9ee",
        stroke: "#95a1ac",
      }),
      e.jsx(r, {
        x: 107,
        y: 130,
        size: 7,
        weight: 400,
        fill: "#333e48",
        children: "j.ellis",
      }),
      e.jsx("rect", {
        x: 104,
        y: 138,
        width: 68,
        height: 11,
        rx: 2,
        fill: "#e3e9ee",
        stroke: "#cb5651",
      }),
      e.jsx(r, {
        x: 107,
        y: 146.5,
        size: 7,
        fill: "#333e48",
        children: "• • • • • •",
      }),
      e.jsx("path", { d: "M92 160 h92 l-6 4 h-80z", fill: "#5c6873" }),
      e.jsx("path", {
        d: "M180 148 h14 v14 a4 4 0 0 1 -4 4 h-6 a4 4 0 0 1 -4 -4z",
        fill: "#e3e9ee",
      }),
      e.jsx("path", {
        d: "M194 151 a4 4 0 0 1 0 8",
        fill: "none",
        stroke: "#e3e9ee",
        strokeWidth: 2,
      }),
      e.jsx("rect", {
        x: 262,
        y: 168,
        width: 130,
        height: 7,
        rx: 2,
        fill: "#746351",
      }),
      e.jsx("rect", { x: 322, y: 175, width: 10, height: 28, fill: "#5c4d3b" }),
      e.jsx("path", {
        d: "M318 200 L320 150 q2 -24 28 -24 q26 0 30 24 l4 50z",
        fill: "#333e48",
      }),
      e.jsx("circle", { cx: 346, cy: 108, r: 14, fill: "#c68642" }),
      e.jsx("path", {
        d: "M332 106 a14 14 0 0 1 28 0 q-6 -4 -14 -4 q-8 0 -14 4z",
        fill: "#111b23",
      }),
      e.jsx("path", {
        d: "M330 104 h-6",
        stroke: "#111b23",
        strokeWidth: 3,
        strokeLinecap: "round",
      }),
      e.jsx("circle", { cx: 338, cy: 108, r: 1.5, fill: "#111b23" }),
      e.jsx("path", {
        d: "M336 142 L310 134 L294 130",
        fill: "none",
        stroke: "#333e48",
        strokeWidth: 9,
        strokeLinecap: "round",
        strokeLinejoin: "round",
      }),
      e.jsx("rect", {
        x: 282,
        y: 118,
        width: 10,
        height: 20,
        rx: 2,
        fill: "#111b23",
        stroke: "#95a1ac",
        transform: "rotate(-20 287 128)",
      }),
      e.jsx("circle", { cx: 293, cy: 130, r: 4.5, fill: "#c68642" }),
      e.jsx("path", {
        d: "M282 132 C240 150 200 156 160 162",
        fill: "none",
        stroke: "#cb5651",
        strokeWidth: 1.8,
        strokeDasharray: "4 4",
        className: "attack-flow",
      }),
      e.jsx("rect", {
        x: 268,
        y: 158,
        width: 16,
        height: 10,
        rx: 2,
        fill: "#e3e9ee",
      }),
      e.jsx("path", {
        d: "M286 118 L276 92",
        stroke: "#ffa79f",
        strokeWidth: 1.2,
        strokeDasharray: "3 3",
      }),
      e.jsx("rect", {
        x: 168,
        y: 10,
        width: 112,
        height: 82,
        rx: 10,
        fill: "#111b23",
        stroke: "#cb5651",
        strokeWidth: 1.6,
      }),
      e.jsx("rect", {
        x: 174,
        y: 16,
        width: 100,
        height: 70,
        rx: 4,
        fill: "#242f38",
      }),
      e.jsx("circle", {
        cx: 182,
        cy: 24,
        r: 3,
        fill: "#cb5651",
        className: "attack-flash",
      }),
      e.jsx(r, { x: 188, y: 27, size: 7, fill: "#e3e9ee", children: "REC" }),
      [34, 42, 50].map((i, t) =>
        e.jsx(
          "g",
          {
            children: [0, 1, 2, 3, 4, 5, 6, 7, 8].map((s) =>
              e.jsx(
                "rect",
                {
                  x: 180 + t * 3 + s * 10,
                  y: i,
                  width: 8,
                  height: 6,
                  rx: 1,
                  fill: "#46515b",
                },
                s,
              ),
            ),
          },
          i,
        ),
      ),
      e.jsx("rect", {
        x: 210,
        y: 42,
        width: 8,
        height: 6,
        rx: 1,
        fill: "#e8ba61",
      }),
      e.jsx("rect", {
        x: 180,
        y: 62,
        width: 88,
        height: 18,
        rx: 3,
        fill: "#d1beaa",
      }),
      e.jsx(C, {
        x: 224,
        y: 75,
        size: 10,
        anchor: "middle",
        fill: "#ac3a38",
        children: "Hv!Trial24",
      }),
    ],
  });
}
function Vs() {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#0d171f" }),
      e.jsx("rect", { x: 0, y: 0, width: 400, height: 196, fill: "#19232c" }),
      e.jsx("rect", {
        x: 10,
        y: 14,
        width: 124,
        height: 80,
        rx: 3,
        fill: "#333e48",
      }),
      e.jsx("rect", { x: 14, y: 18, width: 116, height: 72, fill: "#001d2d" }),
      e.jsx("circle", { cx: 110, cy: 34, r: 7, fill: "#f8e4cf" }),
      e.jsx("path", {
        d: "M14 90 V62 h12 v-10 h14 v20 h8 v-28 h10 v28 h6 V60 a14 14 0 0 1 28 0 v30z",
        fill: "#242f38",
      }),
      e.jsx("rect", { x: 75, y: 36, width: 4, height: 10, fill: "#242f38" }),
      e.jsx("path", { d: "M110 90 V58 h20 v32z", fill: "#242f38" }),
      [
        [30, 66],
        [44, 56],
        [52, 66],
        [116, 64],
        [122, 76],
      ].map(([i, t]) =>
        e.jsx(
          "rect",
          { x: i, y: t, width: 3, height: 3, fill: "#e8ba61" },
          `${i}-${t}`,
        ),
      ),
      e.jsx("path", {
        d: "M72 18 V90 M14 54 H130",
        stroke: "#333e48",
        strokeWidth: 3,
      }),
      e.jsx("rect", {
        x: 20,
        y: 110,
        width: 64,
        height: 22,
        rx: 3,
        fill: "#0d171f",
      }),
      e.jsx(C, {
        x: 52,
        y: 126,
        size: 13,
        anchor: "middle",
        fill: "#cb5651",
        children: "23:40",
      }),
      e.jsx(r, {
        x: 52,
        y: 146,
        size: 7,
        weight: 400,
        anchor: "middle",
        fill: "#95a1ac",
        children: "Friday",
      }),
      e.jsx("rect", {
        x: 158,
        y: 44,
        width: 66,
        height: 15,
        rx: 2,
        fill: "#bac3cb",
      }),
      e.jsx(r, {
        x: 191,
        y: 55,
        size: 8,
        anchor: "middle",
        fill: "#111b23",
        children: "ARCHIVE",
      }),
      e.jsx("rect", { x: 150, y: 64, width: 82, height: 132, fill: "#46515b" }),
      e.jsx("rect", { x: 155, y: 68, width: 72, height: 128, fill: "#0d171f" }),
      [96, 126, 156].map((i) =>
        e.jsx(
          "rect",
          { x: 155, y: i, width: 72, height: 3, fill: "#46515b" },
          i,
        ),
      ),
      [159, 175, 191, 207].map((i, t) =>
        e.jsxs(
          "g",
          {
            children: [
              e.jsx("rect", {
                x: i,
                y: 76,
                width: 14,
                height: 20,
                fill: t % 2 ? "#ac3a38" : "#e8ba61",
              }),
              e.jsx("rect", {
                x: i,
                y: 106,
                width: 14,
                height: 20,
                fill: t % 2 ? "#e8ba61" : "#00425f",
              }),
            ],
          },
          i,
        ),
      ),
      e.jsx(r, {
        x: 191,
        y: 142,
        size: 7,
        anchor: "middle",
        fill: "#e8ba61",
        children: "WILLS · DEEDS",
      }),
      e.jsx("rect", {
        x: 160,
        y: 164,
        width: 62,
        height: 26,
        rx: 2,
        fill: "#242f38",
      }),
      e.jsx("rect", {
        x: 164,
        y: 168,
        width: 22,
        height: 18,
        rx: 1,
        fill: "#333e48",
      }),
      e.jsx("circle", { cx: 180, cy: 182, r: 1.6, fill: "#7ed99f" }),
      e.jsx("rect", {
        x: 194,
        y: 168,
        width: 24,
        height: 18,
        rx: 1,
        fill: "none",
        stroke: "#cb5651",
        strokeWidth: 1.6,
        strokeDasharray: "3 2",
        className: "attack-flash-stroke",
      }),
      e.jsx("path", { d: "M150 64 L128 76 V200 L150 196z", fill: "#5c6873" }),
      e.jsx("circle", { cx: 134, cy: 136, r: 2.5, fill: "#bac3cb" }),
      e.jsx("path", {
        d: "M218 170 C250 120 300 112 336 130",
        fill: "none",
        stroke: "#cb5651",
        strokeWidth: 2,
        strokeDasharray: "5 4",
        className: "attack-flow",
      }),
      e.jsx("rect", {
        x: 338,
        y: 14,
        width: 50,
        height: 18,
        rx: 2,
        fill: "#399661",
      }),
      e.jsx(r, {
        x: 363,
        y: 27,
        size: 9,
        anchor: "middle",
        fill: "#e3e9ee",
        children: "EXIT",
      }),
      e.jsx("rect", { x: 0, y: 196, width: 400, height: 44, fill: "#242f38" }),
      e.jsx("path", { d: "M0 202 H400", stroke: "#333e48", strokeWidth: 2 }),
      e.jsx("path", {
        d: "M270 196 L262 232 M286 196 L296 230",
        stroke: "#111b23",
        strokeWidth: 10,
        strokeLinecap: "round",
      }),
      e.jsx("path", {
        d: "M254 234 h12 M292 232 h12",
        stroke: "#0d171f",
        strokeWidth: 6,
        strokeLinecap: "round",
      }),
      e.jsx("path", {
        d: "M262 200 L264 140 q2 -16 16 -16 q16 0 18 16 l2 60z",
        fill: "#111b23",
      }),
      e.jsx("path", {
        d: "M266 198 L268 140 q2 -10 12 -10 q12 0 14 10 l2 58z",
        fill: "#326e8e",
      }),
      e.jsx("rect", {
        x: 272,
        y: 170,
        width: 16,
        height: 12,
        rx: 2,
        fill: "#326e8e",
      }),
      e.jsx("rect", { x: 273, y: 112, width: 11, height: 14, fill: "#e0ac69" }),
      e.jsx("circle", { cx: 280, cy: 104, r: 13, fill: "#e0ac69" }),
      e.jsx("path", { d: "M266 100 a14 14 0 0 1 28 0z", fill: "#175675" }),
      e.jsx("path", {
        d: "M292 100 h10",
        stroke: "#175675",
        strokeWidth: 3,
        strokeLinecap: "round",
      }),
      e.jsx("circle", { cx: 287, cy: 106, r: 1.5, fill: "#111b23" }),
      e.jsx("path", {
        d: "M286 144 L304 160 L316 160",
        fill: "none",
        stroke: "#111b23",
        strokeWidth: 8,
        strokeLinecap: "round",
        strokeLinejoin: "round",
      }),
      e.jsx("path", {
        d: "M316 150 V196 M316 166 H390 V196",
        fill: "none",
        stroke: "#95a1ac",
        strokeWidth: 3,
      }),
      e.jsx("rect", {
        x: 322,
        y: 160,
        width: 30,
        height: 34,
        rx: 4,
        fill: "#111b23",
      }),
      e.jsx("rect", {
        x: 358,
        y: 168,
        width: 30,
        height: 26,
        rx: 3,
        fill: "#e8ba61",
      }),
      e.jsx("path", {
        d: "M376 168 L394 112",
        stroke: "#746351",
        strokeWidth: 3,
      }),
      [324, 384].map((i) =>
        e.jsx(
          "circle",
          { cx: i, cy: 200, r: 5, fill: "#111b23", stroke: "#5c6873" },
          i,
        ),
      ),
      e.jsx("rect", {
        x: 318,
        y: 136,
        width: 50,
        height: 22,
        rx: 3,
        fill: "#333e48",
      }),
      e.jsx("rect", {
        x: 316,
        y: 134,
        width: 54,
        height: 26,
        rx: 4,
        fill: "none",
        stroke: "#cb5651",
        strokeWidth: 1.8,
        className: "attack-flash-stroke",
      }),
      e.jsx(r, {
        x: 343,
        y: 150,
        size: 8,
        anchor: "middle",
        fill: "#e3e9ee",
        children: "BACKUP",
      }),
    ],
  });
}
function Hs() {
  const i = ["#ee766f", "#6ca8ca", "#e8ba61", "#7ed99f", "#e8ba61"];
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#0d171f" }),
      i.map((t, s) =>
        e.jsxs(
          "g",
          {
            children: [
              e.jsx("rect", {
                x: 150 + s * 50,
                y: 194,
                width: 42,
                height: 24,
                rx: 2,
                fill: "#0d171f",
              }),
              e.jsx("rect", {
                x: 153 + s * 50,
                y: 197,
                width: 36,
                height: 18,
                fill: t,
                opacity: 0.75,
              }),
              e.jsx("path", {
                d: `M${165 + s * 50} 201 l9 5 l-9 5z`,
                fill: "#e3e9ee",
              }),
              e.jsx("rect", {
                x: 181 + s * 50,
                y: 198,
                width: 6,
                height: 6,
                rx: 1,
                fill: s % 2 ? "#cb5651" : "#5bb57e",
              }),
            ],
          },
          t,
        ),
      ),
      e.jsx("rect", {
        x: 140,
        y: 218,
        width: 260,
        height: 22,
        fill: "#19232c",
      }),
      e.jsx("rect", { x: 140, y: 218, width: 260, height: 4, fill: "#2b3f50" }),
      e.jsx("rect", {
        x: 22,
        y: 16,
        width: 110,
        height: 212,
        rx: 14,
        fill: "#0d171f",
      }),
      e.jsx("rect", {
        x: 28,
        y: 28,
        width: 98,
        height: 188,
        rx: 4,
        fill: "#e3e9ee",
      }),
      e.jsx("rect", {
        x: 66,
        y: 20,
        width: 22,
        height: 4,
        rx: 2,
        fill: "#333e48",
      }),
      e.jsx("circle", { cx: 77, cy: 46, r: 9, fill: "#54697c" }),
      e.jsx(r, {
        x: 77,
        y: 49,
        size: 8,
        anchor: "middle",
        fill: "#e3e9ee",
        children: "M",
      }),
      e.jsx(r, {
        x: 77,
        y: 66,
        size: 8,
        anchor: "middle",
        fill: "#111b23",
        children: "ModDesk",
      }),
      e.jsx("rect", {
        x: 33,
        y: 74,
        width: 88,
        height: 92,
        rx: 8,
        fill: "#bac3cb",
      }),
      [
        "Your account will",
        "be suspended in",
        "30 minutes.",
        "Verify now:",
      ].map((t, s) =>
        e.jsx(
          r,
          {
            x: 39,
            y: 88 + s * 11,
            size: 7.5,
            weight: s === 2 ? 700 : 400,
            fill: s === 2 ? "#ac3a38" : "#111b23",
            children: t,
          },
          t,
        ),
      ),
      e.jsx(r, {
        x: 39,
        y: 140,
        size: 7,
        weight: 400,
        fill: "#326e8e",
        children: "vidora-moddesk",
      }),
      e.jsx(r, {
        x: 39,
        y: 151,
        size: 7,
        weight: 400,
        fill: "#326e8e",
        children: ".help/login",
      }),
      e.jsx("path", { d: "M39 153 H82", stroke: "#326e8e", strokeWidth: 0.8 }),
      e.jsx("path", {
        d: "M82 150 q6 -6 12 0 l20 34 q4 10 -6 14 q-10 4 -14 -6z",
        fill: "#d6a77a",
        stroke: "#8f7e6b",
      }),
      e.jsx("ellipse", { cx: 16, cy: 110, rx: 8, ry: 12, fill: "#d6a77a" }),
      e.jsx("ellipse", { cx: 16, cy: 140, rx: 8, ry: 12, fill: "#d6a77a" }),
      e.jsx("ellipse", { cx: 16, cy: 170, rx: 8, ry: 12, fill: "#d6a77a" }),
      e.jsx("path", {
        d: "M60 240 L68 220 q20 -10 50 -6 l12 26z",
        fill: "#d6a77a",
      }),
      e.jsx("path", {
        d: "M121 100 C136 90 132 52 150 40",
        fill: "none",
        stroke: "#cb5651",
        strokeWidth: 1.8,
        strokeDasharray: "4 4",
        className: "attack-flow",
      }),
      e.jsxs(f, {
        x: 150,
        y: 14,
        w: 240,
        h: 172,
        bar: "#2b3f50",
        children: [
          e.jsx("rect", {
            x: 151,
            y: 30,
            width: 238,
            height: 13,
            fill: "#bac3cb",
          }),
          e.jsx(r, {
            x: 270,
            y: 39.5,
            size: 7.5,
            weight: 400,
            anchor: "middle",
            fill: "#ac3a38",
            children: "vidora-moddesk.help/login",
          }),
          e.jsx(se, { x: 270, y: 62, s: 0.9 }),
          e.jsx(r, {
            x: 270,
            y: 88,
            size: 11,
            anchor: "middle",
            fill: "#2b3f50",
            children: "Vidora ModDesk",
          }),
          e.jsx("rect", {
            x: 208,
            y: 94,
            width: 124,
            height: 15,
            rx: 3,
            fill: "#e3e9ee",
          }),
          e.jsx("g", {
            className: "attack-flash",
            children: e.jsx(r, {
              x: 270,
              y: 104.5,
              size: 7.5,
              anchor: "middle",
              fill: "#ac3a38",
              children: "Suspended in 29:58",
            }),
          }),
          e.jsx("rect", {
            x: 174,
            y: 114,
            width: 192,
            height: 15,
            rx: 3,
            fill: "#e3e9ee",
            stroke: "#95a1ac",
          }),
          e.jsx(r, {
            x: 179,
            y: 124.5,
            size: 7,
            weight: 400,
            fill: "#333e48",
            children: "aisha.k@vidora.com",
          }),
          e.jsx("rect", {
            x: 174,
            y: 134,
            width: 192,
            height: 15,
            rx: 3,
            fill: "#e3e9ee",
            stroke: "#cb5651",
            strokeWidth: 1.5,
          }),
          e.jsx(r, {
            x: 179,
            y: 145,
            size: 8,
            fill: "#333e48",
            children: "• • • • • • •",
          }),
          e.jsx("path", {
            d: "M232 137 V146",
            stroke: "#111b23",
            strokeWidth: 1.2,
            className: "attack-flash",
          }),
          e.jsx("rect", {
            x: 230,
            y: 156,
            width: 80,
            height: 18,
            rx: 3,
            fill: "#54697c",
          }),
          e.jsx(r, {
            x: 270,
            y: 168,
            size: 8,
            anchor: "middle",
            fill: "#e3e9ee",
            children: "Verify",
          }),
        ],
      }),
    ],
  });
}
function fe({ x: i, y: t, fill: s = "#d1beaa", edge: l = "#c4973c" }) {
  return e.jsxs("g", {
    children: [
      e.jsx("rect", {
        x: i - 7,
        y: t - 5,
        width: 14,
        height: 10,
        rx: 1.5,
        fill: s,
        stroke: l,
      }),
      e.jsx("path", {
        d: `M${i - 7} ${t - 5} l7 5 l7 -5`,
        fill: "none",
        stroke: l,
        strokeWidth: 1,
      }),
    ],
  });
}
function Ps() {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#111b23" }),
      e.jsx("rect", { x: 0, y: 0, width: 400, height: 176, fill: "#19232c" }),
      [116, 252].map((i) =>
        e.jsx(
          "rect",
          {
            x: i,
            y: 60,
            width: i === 116 ? 122 : 134,
            height: 112,
            fill: "none",
            stroke: "#746351",
            strokeWidth: 1.5,
          },
          i,
        ),
      ),
      [112, 248].map((i) =>
        e.jsxs(
          "g",
          {
            children: [
              e.jsx("path", { d: `M${i} 92 l-6 -12 h12z`, fill: "#ffe4b4" }),
              e.jsx("rect", {
                x: i - 1.5,
                y: 92,
                width: 3,
                height: 8,
                fill: "#746351",
              }),
            ],
          },
          i,
        ),
      ),
      e.jsx("rect", { x: 0, y: 176, width: 400, height: 64, fill: "#333e48" }),
      [200, 222].map((i) =>
        e.jsx(
          "path",
          { d: `M0 ${i} H400`, stroke: "#46515b", strokeWidth: 1 },
          i,
        ),
      ),
      e.jsx("rect", {
        x: 12,
        y: 10,
        width: 92,
        height: 78,
        rx: 4,
        fill: "#2b3f50",
        stroke: "#e8ba61",
        strokeWidth: 2,
      }),
      e.jsx(se, { x: 30, y: 24, s: 0.6 }),
      e.jsx(r, { x: 40, y: 27, size: 8, fill: "#e3e9ee", children: "VIDORA" }),
      e.jsx(r, {
        x: 58,
        y: 42,
        size: 7.5,
        anchor: "middle",
        fill: "#ffe4b4",
        children: "CREATOR AWARDS",
      }),
      e.jsx("path", { d: "M50 48 h16 v5 a8 8 0 0 1 -16 0z", fill: "#e8ba61" }),
      e.jsx("path", {
        d: "M50 50 h-4 a4 4 0 0 0 4 5 M66 50 h4 a4 4 0 0 1 -4 5",
        fill: "none",
        stroke: "#e8ba61",
        strokeWidth: 1.4,
      }),
      e.jsx("rect", { x: 56.5, y: 60, width: 3, height: 4, fill: "#e8ba61" }),
      e.jsx("rect", {
        x: 52,
        y: 64,
        width: 12,
        height: 3,
        rx: 1,
        fill: "#e8ba61",
      }),
      e.jsx("rect", {
        x: 20,
        y: 71,
        width: 76,
        height: 12,
        rx: 2,
        fill: "#e8ba61",
      }),
      e.jsx(r, {
        x: 58,
        y: 80,
        size: 7.5,
        anchor: "middle",
        fill: "#1c2f40",
        children: "TOMORROW 8PM",
      }),
      e.jsx("rect", {
        x: 118,
        y: 8,
        width: 130,
        height: 22,
        rx: 3,
        fill: "#e3e9ee",
      }),
      e.jsxs("g", {
        transform: "translate(131 25)",
        fill: "none",
        stroke: "#746351",
        strokeWidth: 1.6,
        children: [
          e.jsx("path", { d: "M-7 -7 a10 10 0 0 1 14 0" }),
          e.jsx("path", { d: "M-4.5 -4 a6 6 0 0 1 9 0" }),
          e.jsx("circle", {
            cx: 0,
            cy: -1,
            r: 1.3,
            fill: "#746351",
            stroke: "none",
          }),
        ],
      }),
      e.jsx(r, {
        x: 190,
        y: 23,
        size: 8,
        anchor: "middle",
        fill: "#392a1a",
        children: "Grand Hotel Guest Wi-Fi",
      }),
      e.jsx("path", {
        d: "M176 42 V35 M196 42 V35",
        stroke: "#95a1ac",
        strokeWidth: 2,
        strokeLinecap: "round",
      }),
      e.jsx("rect", {
        x: 168,
        y: 42,
        width: 36,
        height: 11,
        rx: 3,
        fill: "#bac3cb",
      }),
      [178, 184, 190].map((i) =>
        e.jsx("circle", { cx: i, cy: 47.5, r: 1.5, fill: "#5bb57e" }, i),
      ),
      e.jsx("rect", { x: 168, y: 134, width: 70, height: 42, fill: "#493a28" }),
      e.jsx("rect", {
        x: 164,
        y: 130,
        width: 78,
        height: 6,
        rx: 1,
        fill: "#746351",
      }),
      e.jsx("path", { d: "M196 130 a7 7 0 0 1 14 0z", fill: "#e8ba61" }),
      e.jsx("circle", { cx: 203, cy: 121.5, r: 1.5, fill: "#e8ba61" }),
      e.jsx("rect", {
        x: 176,
        y: 146,
        width: 54,
        height: 12,
        rx: 2,
        fill: "#19232c",
      }),
      e.jsx(r, {
        x: 203,
        y: 155,
        size: 7,
        anchor: "middle",
        fill: "#ffe4b4",
        children: "RECEPTION",
      }),
      e.jsx("rect", {
        x: 8,
        y: 94,
        width: 88,
        height: 84,
        rx: 18,
        fill: "#00425f",
      }),
      e.jsx("rect", {
        x: 4,
        y: 136,
        width: 16,
        height: 40,
        rx: 6,
        fill: "#175675",
      }),
      e.jsx("path", {
        d: "M18 176 L22 140 q4 -12 24 -12 h16 q18 2 20 16 l2 32z",
        fill: "#002538",
      }),
      e.jsx("path", { d: "M46 128 l8 12 l8 -12z", fill: "#e3e9ee" }),
      e.jsx("path", {
        d: "M44 128 L54 156 L64 128",
        fill: "none",
        stroke: "#8ba3b7",
        strokeWidth: 1.5,
      }),
      e.jsx("rect", {
        x: 46,
        y: 154,
        width: 16,
        height: 14,
        rx: 2,
        fill: "#e3e9ee",
        stroke: "#54697c",
      }),
      e.jsx(se, { x: 54, y: 161, s: 0.45 }),
      e.jsx("rect", { x: 49, y: 118, width: 10, height: 11, fill: "#c68642" }),
      e.jsx("circle", { cx: 54, cy: 106, r: 14, fill: "#c68642" }),
      e.jsx("path", {
        d: "M40 104 q-2 -16 14 -17 q16 -1 15 15 q-4 -8 -14 -8 q-10 0 -15 10z",
        fill: "#111b23",
      }),
      e.jsx("circle", { cx: 61, cy: 106, r: 1.5, fill: "#111b23" }),
      e.jsx("path", {
        d: "M58 113 q3 2 6 0",
        fill: "none",
        stroke: "#901e21",
        strokeWidth: 1.2,
      }),
      e.jsx("path", {
        d: "M64 142 L84 160 L104 166",
        fill: "none",
        stroke: "#002538",
        strokeWidth: 9,
        strokeLinecap: "round",
        strokeLinejoin: "round",
      }),
      e.jsx("circle", { cx: 106, cy: 166, r: 4.5, fill: "#c68642" }),
      e.jsx("rect", {
        x: 0,
        y: 170,
        width: 176,
        height: 8,
        rx: 2,
        fill: "#746351",
      }),
      e.jsx("rect", { x: 14, y: 178, width: 6, height: 30, fill: "#493a28" }),
      e.jsx("rect", { x: 156, y: 178, width: 6, height: 30, fill: "#493a28" }),
      e.jsx("rect", {
        x: 82,
        y: 110,
        width: 86,
        height: 56,
        rx: 3,
        fill: "#111b23",
      }),
      e.jsx("rect", { x: 86, y: 114, width: 78, height: 48, fill: "#e3e9ee" }),
      e.jsx("rect", { x: 86, y: 114, width: 78, height: 12, fill: "#54697c" }),
      e.jsx(r, {
        x: 90,
        y: 123,
        size: 7,
        fill: "#e3e9ee",
        children: "Uploading...",
      }),
      e.jsx("rect", {
        x: 90,
        y: 131,
        width: 10,
        height: 13,
        rx: 1,
        fill: "#bac3cb",
        stroke: "#ac3a38",
      }),
      e.jsx(r, {
        x: 104,
        y: 141,
        size: 7.5,
        fill: "#111b23",
        children: "winners.pdf",
      }),
      e.jsx("rect", {
        x: 90,
        y: 150,
        width: 68,
        height: 5,
        rx: 2.5,
        fill: "#bac3cb",
      }),
      e.jsx("rect", {
        x: 90,
        y: 150,
        width: 46,
        height: 5,
        rx: 2.5,
        fill: "#54697c",
      }),
      e.jsx("path", { d: "M76 166 h98 l-6 4 h-86z", fill: "#5c6873" }),
      e.jsx("path", {
        d: "M32 186 V176 h14 v10",
        fill: "none",
        stroke: "#95a1ac",
        strokeWidth: 2,
      }),
      e.jsx("rect", {
        x: 26,
        y: 186,
        width: 26,
        height: 40,
        rx: 4,
        fill: "#ac3a38",
      }),
      [34, 44].map((i) =>
        e.jsx(
          "path",
          { d: `M${i} 190 V222`, stroke: "#901e21", strokeWidth: 1.5 },
          i,
        ),
      ),
      [30, 48].map((i) =>
        e.jsx("circle", { cx: i, cy: 229, r: 3, fill: "#111b23" }, i),
      ),
      e.jsx("path", {
        d: "M164 112 C178 94 166 66 180 56",
        fill: "none",
        stroke: "#e8ba61",
        strokeWidth: 1.6,
        strokeDasharray: "4 4",
        className: "attack-flow",
      }),
      e.jsx(fe, { x: 171, y: 96 }),
      e.jsx(fe, { x: 175, y: 72 }),
      e.jsx("rect", {
        x: 322,
        y: 198,
        width: 52,
        height: 6,
        rx: 2,
        fill: "#111b23",
      }),
      [326, 366].map((i) =>
        e.jsx(
          "rect",
          { x: i, y: 204, width: 4, height: 26, fill: "#111b23" },
          i,
        ),
      ),
      e.jsx("path", {
        d: "M322 198 V168 a26 26 0 0 1 52 0 V198z",
        fill: "#46515b",
      }),
      e.jsx("circle", { cx: 348, cy: 146, r: 17, fill: "#46515b" }),
      e.jsx("circle", { cx: 345, cy: 149, r: 11, fill: "#e0ac69" }),
      e.jsx("path", {
        d: "M334 147 a11 11 0 0 1 22 -2 q-12 -6 -22 2z",
        fill: "#111b23",
      }),
      e.jsx("circle", { cx: 339, cy: 150, r: 1.5, fill: "#111b23" }),
      e.jsx("path", { d: "M336 156 h4", stroke: "#901e21", strokeWidth: 1.2 }),
      e.jsx("path", {
        d: "M340 174 L322 186",
        stroke: "#46515b",
        strokeWidth: 8,
        strokeLinecap: "round",
      }),
      e.jsx("circle", { cx: 318, cy: 187, r: 4, fill: "#e0ac69" }),
      e.jsx("path", { d: "M214 214 h28 l-4 24 h-20z", fill: "#746351" }),
      e.jsx("path", {
        d: "M228 214 C226 196 214 188 202 186 M228 214 C230 194 244 186 256 188 M228 214 C228 196 228 186 230 176",
        fill: "none",
        stroke: "#137a47",
        strokeWidth: 5,
        strokeLinecap: "round",
      }),
      e.jsx("rect", {
        x: 270,
        y: 192,
        width: 70,
        height: 6,
        rx: 2,
        fill: "#746351",
      }),
      e.jsx("rect", { x: 302, y: 198, width: 6, height: 30, fill: "#493a28" }),
      e.jsx("rect", {
        x: 290,
        y: 226,
        width: 30,
        height: 4,
        rx: 1,
        fill: "#493a28",
      }),
      e.jsx("path", { d: "M282 164 L296 188 h26 v4 h-30z", fill: "#46515b" }),
      e.jsx("path", {
        d: "M282 164 L296 188",
        stroke: "#95a1ac",
        strokeWidth: 2,
      }),
      e.jsx("rect", {
        x: 326,
        y: 182,
        width: 9,
        height: 10,
        rx: 1.5,
        fill: "#e3e9ee",
      }),
      e.jsx("path", {
        d: "M335 185 a3 3 0 0 1 0 5",
        fill: "none",
        stroke: "#e3e9ee",
        strokeWidth: 1.2,
      }),
      e.jsx("path", {
        d: "M204 50 C238 62 236 150 284 166",
        fill: "none",
        stroke: "#cb5651",
        strokeWidth: 1.8,
        strokeDasharray: "5 4",
        className: "attack-flow",
      }),
      e.jsx(fe, { x: 229, y: 80, fill: "#bac3cb", edge: "#cb5651" }),
      e.jsx(fe, { x: 246, y: 134, fill: "#bac3cb", edge: "#cb5651" }),
      e.jsx("path", {
        d: "M290 162 L300 126",
        stroke: "#ffa79f",
        strokeWidth: 1.4,
        strokeDasharray: "3 3",
      }),
      e.jsxs(f, {
        x: 258,
        y: 6,
        w: 136,
        h: 118,
        bar: "#901e21",
        children: [
          e.jsx(r, {
            x: 288,
            y: 17,
            size: 7,
            fill: "#e3e9ee",
            children: "Packet sniffer",
          }),
          e.jsx(C, {
            x: 264,
            y: 32,
            size: 7,
            fill: "#5c6873",
            children: "PKT 2207 1.4KB",
          }),
          e.jsx(C, {
            x: 264,
            y: 42,
            size: 7,
            fill: "#5c6873",
            children: "PKT 2208 1.6KB",
          }),
          e.jsx("rect", {
            x: 262,
            y: 48,
            width: 128,
            height: 70,
            rx: 3,
            fill: "#d1beaa",
            stroke: "#e8ba61",
          }),
          e.jsx("g", {
            className: "attack-flash",
            children: e.jsx(r, {
              x: 267,
              y: 59,
              size: 7.5,
              fill: "#ac3a38",
              children: "winners.pdf (SECRET)",
            }),
          }),
          e.jsx(r, {
            x: 267,
            y: 71,
            size: 7,
            weight: 400,
            fill: "#111b23",
            children: "Creator of the Year:",
          }),
          e.jsx(r, {
            x: 267,
            y: 81,
            size: 7.5,
            fill: "#54697c",
            children: "@kaizoom",
          }),
          e.jsx(r, {
            x: 267,
            y: 95,
            size: 7,
            weight: 400,
            fill: "#111b23",
            children: "Best Newcomer:",
          }),
          e.jsx(r, {
            x: 267,
            y: 105,
            size: 7.5,
            fill: "#54697c",
            children: "@luna_draws",
          }),
        ],
      }),
    ],
  });
}
function ie({ x: i, y: t, r: s = 6 }) {
  const l = [0, 45, 90, 135, 180, 225, 270, 315].map((a) => {
    const c = (a * Math.PI) / 180;
    return {
      deg: a,
      x1: i + Math.cos(c) * s,
      y1: t + Math.sin(c) * s,
      x2: i + Math.cos(c) * (s + s * 0.55),
      y2: t + Math.sin(c) * (s + s * 0.55),
    };
  });
  return e.jsxs("g", {
    children: [
      l.map((a) =>
        e.jsxs(
          "g",
          {
            children: [
              e.jsx("path", {
                d: `M${a.x1} ${a.y1} L${a.x2} ${a.y2}`,
                stroke: "#399661",
                strokeWidth: s * 0.3,
              }),
              e.jsx("circle", {
                cx: a.x2,
                cy: a.y2,
                r: s * 0.24,
                fill: "#7ed99f",
              }),
            ],
          },
          a.deg,
        ),
      ),
      e.jsx("circle", {
        cx: i,
        cy: t,
        r: s,
        fill: "#7ed99f",
        stroke: "#006034",
        strokeWidth: s * 0.18,
      }),
      e.jsx("circle", {
        cx: i - s * 0.35,
        cy: t - s * 0.25,
        r: s * 0.22,
        fill: "#006034",
      }),
      e.jsx("circle", {
        cx: i + s * 0.3,
        cy: t + s * 0.35,
        r: s * 0.18,
        fill: "#006034",
      }),
    ],
  });
}
function Ie({ x: i, y: t, label: s }) {
  return e.jsxs("g", {
    children: [
      e.jsx(r, {
        x: i,
        y: t - 5,
        size: 7.5,
        anchor: "middle",
        fill: "#adc5da",
        children: s,
      }),
      e.jsx("path", {
        d: `M${i - 11} ${t} h15 l7 7 v21 h-22z`,
        fill: "#e3e9ee",
      }),
      e.jsx("path", { d: `M${i + 4} ${t} v7 h7z`, fill: "#bac3cb" }),
      e.jsx("path", { d: `M${i - 5} ${t + 10} l8 5 l-8 5z`, fill: "#54697c" }),
      e.jsx(ie, { x: i + 10, y: t + 25, r: 4.5 }),
    ],
  });
}
function wt({ x: i, y: t, w: s, h: l }) {
  return e.jsxs("g", {
    children: [
      e.jsx("rect", { x: i, y: t, width: s, height: l, fill: "#e8ba61" }),
      e.jsx("rect", { x: i, y: t, width: s, height: l * 0.4, fill: "#54697c" }),
      e.jsx("circle", {
        cx: i + s * 0.68,
        cy: t + l * 0.55,
        r: l * 0.18,
        fill: "#ffe4b4",
      }),
      e.jsx("path", {
        d: `M${i} ${t + l} V${t + l * 0.7} Q${i + s * 0.3} ${t + l * 0.5} ${i + s * 0.55} ${t + l * 0.72} T${i + s} ${t + l * 0.66} V${t + l}z`,
        fill: "#002538",
      }),
      e.jsx("circle", {
        cx: i + s * 0.3,
        cy: t + l * 0.5,
        r: l * 0.07,
        fill: "#002538",
      }),
      e.jsx("path", {
        d: `M${i + s * 0.24} ${t + l * 0.8} Q${i + s * 0.3} ${t + l * 0.52} ${i + s * 0.36} ${t + l * 0.8}z`,
        fill: "#002538",
      }),
    ],
  });
}
const Es = [
  [0, 7, "#54697c", -7],
  [7, 5, "#7ed99f", 9],
  [12, 8, "#ee766f", -3],
  [20, 3, "#e3e9ee", 14],
  [23, 9, "#6ca8ca", 6],
  [32, 6, "#e8ba61", -10],
  [38, 4, "#cb5651", 4],
  [42, 7, "#54697c", 11],
  [49, 7, "#7ed99f", -5],
];
function qe({ x: i, y: t, w: s, from: l = 0 }) {
  return e.jsxs("g", {
    children: [
      Es.filter(([a]) => a >= l).map(([a, c, h, o]) =>
        e.jsx(
          "rect",
          {
            x: i + Math.max(o, 0),
            y: t + a,
            width: s - Math.abs(o),
            height: c,
            fill: h,
            opacity: 0.85,
          },
          a,
        ),
      ),
      [
        [0.12, 10],
        [0.58, 26],
        [0.3, 44],
        [0.8, 50],
      ]
        .filter(([, a]) => a >= l)
        .map(([a, c]) =>
          e.jsx(
            "rect",
            { x: i + s * a, y: t + c, width: 10, height: 3, fill: "#0d171f" },
            c,
          ),
        ),
    ],
  });
}
function je({ x: i, label: t, infected: s, children: l }) {
  return e.jsxs("g", {
    children: [
      e.jsx("rect", {
        x: i + 36,
        y: 134,
        width: 12,
        height: 12,
        fill: "#333e48",
      }),
      e.jsx("rect", {
        x: i + 26,
        y: 146,
        width: 32,
        height: 4,
        rx: 2,
        fill: "#333e48",
      }),
      e.jsx("rect", {
        x: i,
        y: 70,
        width: 84,
        height: 64,
        rx: 4,
        fill: "#0d171f",
      }),
      e.jsx("rect", {
        x: i + 4,
        y: 74,
        width: 76,
        height: 56,
        fill: "#111b23",
      }),
      l,
      s
        ? e.jsx("rect", {
            x: i + 4,
            y: 74,
            width: 76,
            height: 56,
            fill: "none",
            stroke: "#cb5651",
            strokeWidth: 2,
            className: "attack-flash-stroke",
          })
        : null,
      e.jsx("rect", {
        x: i + 4,
        y: 74,
        width: 34,
        height: 12,
        fill: "#0d171f",
        opacity: 0.85,
      }),
      e.jsx(r, {
        x: i + 8,
        y: 83,
        size: 7,
        fill: s ? "#ffa79f" : "#bac3cb",
        children: t,
      }),
    ],
  });
}
function _s() {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#0d171f" }),
      e.jsx("rect", { x: 0, y: 0, width: 400, height: 150, fill: "#081b2b" }),
      e.jsx("path", {
        d: "M54 70 C54 30 152 30 152 70 M152 70 C152 30 250 30 250 70 M250 70 C250 30 348 30 348 70",
        fill: "none",
        stroke: "#cb5651",
        strokeWidth: 2,
        strokeDasharray: "5 4",
        className: "attack-flow",
      }),
      e.jsx("path", { d: "M343 62 l5 8 l5 -8z", fill: "#cb5651" }),
      e.jsx(Ie, { x: 103, y: 26, label: "EP1.mov" }),
      e.jsx(Ie, { x: 201, y: 26, label: "EP2.mov" }),
      e.jsx(Ie, { x: 299, y: 26, label: "EP3.mov" }),
      e.jsxs(je, {
        x: 12,
        label: "EDIT 1",
        infected: !0,
        children: [
          e.jsx(qe, { x: 16, y: 74, w: 76 }),
          e.jsx(ie, { x: 54, y: 104, r: 9 }),
        ],
      }),
      e.jsxs(je, {
        x: 110,
        label: "EDIT 2",
        infected: !0,
        children: [
          e.jsx(qe, { x: 114, y: 74, w: 76 }),
          e.jsx(ie, { x: 152, y: 106, r: 7 }),
        ],
      }),
      e.jsxs(je, {
        x: 208,
        label: "EDIT 3",
        infected: !0,
        children: [
          e.jsx(wt, { x: 212, y: 74, w: 76, h: 56 }),
          e.jsx(qe, { x: 212, y: 74, w: 76, from: 32 }),
          e.jsx(ie, { x: 272, y: 112, r: 6 }),
        ],
      }),
      e.jsxs(je, {
        x: 306,
        label: "EDIT 4",
        children: [
          e.jsx(wt, { x: 310, y: 74, w: 76, h: 56 }),
          e.jsx("path", {
            d: "M344 96 l12 7 l-12 7z",
            fill: "#e3e9ee",
            opacity: 0.9,
          }),
        ],
      }),
      e.jsx("rect", { x: 0, y: 150, width: 400, height: 8, fill: "#2b3f50" }),
      e.jsx("rect", { x: 0, y: 158, width: 400, height: 82, fill: "#19232c" }),
      e.jsx("rect", {
        x: 12,
        y: 160,
        width: 22,
        height: 18,
        rx: 2,
        fill: "#333e48",
      }),
      e.jsx("rect", { x: 34, y: 164, width: 8, height: 10, fill: "#95a1ac" }),
      e.jsx("rect", {
        x: 42,
        y: 161,
        width: 56,
        height: 16,
        rx: 3,
        fill: "#bac3cb",
      }),
      e.jsx("rect", {
        x: 46,
        y: 163.5,
        width: 48,
        height: 11,
        rx: 1.5,
        fill: "#ffe4b4",
      }),
      e.jsx(r, {
        x: 70,
        y: 171.5,
        size: 7,
        anchor: "middle",
        fill: "#5c4d3b",
        children: "S2 FINAL CUT",
      }),
      e.jsx("rect", {
        x: 8,
        y: 156,
        width: 94,
        height: 26,
        rx: 4,
        fill: "none",
        stroke: "#cb5651",
        strokeWidth: 1.6,
        className: "attack-flash-stroke",
      }),
      e.jsx(ie, { x: 112, y: 169, r: 5 }),
      e.jsx("path", {
        d: "M30 156 C30 146 32 140 32 134",
        fill: "none",
        stroke: "#cb5651",
        strokeWidth: 2,
        strokeDasharray: "5 4",
        className: "attack-flow",
      }),
      e.jsx("path", {
        d: "M100 240 C102 214 122 204 152 204 C182 204 202 214 204 240z",
        fill: "#137a47",
      }),
      e.jsx("path", {
        d: "M118 214 L128 186 L138 176 M186 214 L176 186 L166 176",
        fill: "none",
        stroke: "#137a47",
        strokeWidth: 10,
        strokeLinecap: "round",
        strokeLinejoin: "round",
      }),
      e.jsx("circle", { cx: 152, cy: 186, r: 18, fill: "#111b23" }),
      e.jsx("circle", { cx: 138, cy: 176, r: 5, fill: "#8d5524" }),
      e.jsx("circle", { cx: 166, cy: 176, r: 5, fill: "#8d5524" }),
      e.jsx("path", {
        d: "M132 206 a20 12 0 0 0 40 0",
        fill: "none",
        stroke: "#8ba3b7",
        strokeWidth: 4,
      }),
      e.jsx("rect", {
        x: 214,
        y: 172,
        width: 52,
        height: 50,
        rx: 3,
        fill: "#e3e9ee",
      }),
      e.jsx("path", {
        d: "M214 175 a3 3 0 0 1 3 -3 h46 a3 3 0 0 1 3 3 v9 h-52z",
        fill: "#54697c",
      }),
      e.jsx(r, {
        x: 240,
        y: 181,
        size: 7,
        anchor: "middle",
        fill: "#e3e9ee",
        children: "PREMIERE",
      }),
      e.jsx(r, {
        x: 240,
        y: 202,
        size: 15,
        anchor: "middle",
        fill: "#002538",
        children: "FRI",
      }),
      e.jsx(r, {
        x: 240,
        y: 216,
        size: 7,
        anchor: "middle",
        fill: "#54697c",
        children: "in 2 days",
      }),
      e.jsx("rect", {
        x: 276,
        y: 172,
        width: 116,
        height: 50,
        rx: 4,
        fill: "#480004",
        stroke: "#cb5651",
        strokeWidth: 1.6,
      }),
      e.jsx(C, {
        x: 334,
        y: 196,
        size: 16,
        anchor: "middle",
        fill: "#d1beaa",
        children: "3,412",
      }),
      e.jsx(r, {
        x: 334,
        y: 212,
        size: 7.5,
        anchor: "middle",
        fill: "#ffa79f",
        children: "clips corrupted",
      }),
    ],
  });
}
function Is() {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#0d171f" }),
      e.jsx("rect", { x: 0, y: 0, width: 400, height: 196, fill: "#111b23" }),
      e.jsx("rect", {
        x: 18,
        y: 6,
        width: 104,
        height: 20,
        rx: 3,
        fill: "#2b3f50",
      }),
      e.jsx(se, { x: 32, y: 16, s: 0.6 }),
      e.jsx(r, {
        x: 78,
        y: 20,
        size: 9,
        anchor: "middle",
        fill: "#e3e9ee",
        children: "STUDIO",
      }),
      e.jsx("path", { d: "M10 32 H130 V196 H10z", fill: "#399661" }),
      e.jsx("path", {
        d: "M10 180 q0 16 16 16 H130",
        fill: "none",
        stroke: "#137a47",
        strokeWidth: 2,
      }),
      e.jsx("circle", {
        cx: 100,
        cy: 80,
        r: 20,
        fill: "none",
        stroke: "#f8e4cf",
        strokeWidth: 5,
      }),
      e.jsx("path", {
        d: "M100 100 V196 M90 196 L100 170 L110 196",
        stroke: "#46515b",
        strokeWidth: 3,
        fill: "none",
      }),
      e.jsx("rect", {
        x: 124,
        y: 112,
        width: 30,
        height: 20,
        rx: 3,
        fill: "#111b23",
      }),
      e.jsx("rect", {
        x: 112,
        y: 116,
        width: 14,
        height: 12,
        rx: 2,
        fill: "#242f38",
      }),
      e.jsx("circle", { cx: 148, cy: 116, r: 2, fill: "#cb5651" }),
      e.jsx("path", {
        d: "M140 132 L132 196 M140 132 L148 196 M140 132 V196",
        stroke: "#46515b",
        strokeWidth: 2.5,
      }),
      e.jsx("rect", {
        x: 170,
        y: 36,
        width: 78,
        height: 15,
        rx: 2,
        fill: "#bac3cb",
      }),
      e.jsx(r, {
        x: 209,
        y: 47,
        size: 8,
        anchor: "middle",
        fill: "#111b23",
        children: "EDIT BAY",
      }),
      e.jsx("rect", {
        x: 166,
        y: 58,
        width: 88,
        height: 60,
        rx: 4,
        fill: "#0d171f",
      }),
      e.jsx("rect", { x: 171, y: 63, width: 78, height: 50, fill: "#002538" }),
      e.jsx("circle", { cx: 196, cy: 84, r: 8, fill: "#ee766f" }),
      e.jsx("path", { d: "M184 108 q12 -18 24 0z", fill: "#ee766f" }),
      e.jsx("circle", { cx: 224, cy: 84, r: 8, fill: "#6ca8ca" }),
      e.jsx("path", { d: "M212 108 q12 -18 24 0z", fill: "#6ca8ca" }),
      e.jsx(r, {
        x: 210,
        y: 74,
        size: 7,
        anchor: "middle",
        fill: "#ffe4b4",
        children: "SECRET COLLAB",
      }),
      e.jsx("rect", { x: 202, y: 118, width: 16, height: 16, fill: "#333e48" }),
      e.jsx("rect", {
        x: 160,
        y: 134,
        width: 100,
        height: 7,
        rx: 2,
        fill: "#2b3f50",
      }),
      e.jsx("rect", { x: 168, y: 141, width: 6, height: 55, fill: "#2b3f50" }),
      e.jsx("rect", { x: 246, y: 141, width: 6, height: 55, fill: "#2b3f50" }),
      e.jsx("rect", {
        x: 168,
        y: 124,
        width: 24,
        height: 10,
        rx: 2,
        fill: "#242f38",
      }),
      e.jsx("rect", {
        x: 224,
        y: 122,
        width: 30,
        height: 12,
        rx: 2,
        fill: "none",
        stroke: "#cb5651",
        strokeWidth: 1.6,
        strokeDasharray: "3 2",
        className: "attack-flash-stroke",
      }),
      e.jsx("rect", { x: 334, y: 40, width: 58, height: 156, fill: "#46515b" }),
      e.jsx("rect", { x: 338, y: 44, width: 50, height: 152, fill: "#0d171f" }),
      e.jsx("path", {
        d: "M368 196 V120 M360 120 h16",
        stroke: "#5c6873",
        strokeWidth: 3,
      }),
      e.jsx("circle", { cx: 368, cy: 116, r: 6, fill: "#ffe4b4" }),
      e.jsx("path", {
        d: "M352 196 L384 196 L392 168 L340 168z",
        fill: "#ffe4b4",
        opacity: 0.15,
      }),
      e.jsx("path", { d: "M338 44 L312 56 V200 L338 196z", fill: "#5c6873" }),
      e.jsx("circle", { cx: 318, cy: 128, r: 2.5, fill: "#bac3cb" }),
      e.jsx("rect", { x: 0, y: 196, width: 400, height: 44, fill: "#102333" }),
      e.jsx("path", {
        d: "M240 122 C262 96 290 94 304 110",
        fill: "none",
        stroke: "#cb5651",
        strokeWidth: 2,
        strokeDasharray: "5 4",
        className: "attack-flow",
      }),
      e.jsx("path", {
        d: "M278 196 L270 232 M292 196 L304 230",
        stroke: "#111b23",
        strokeWidth: 10,
        strokeLinecap: "round",
      }),
      e.jsx("path", {
        d: "M262 234 h12 M300 232 h12",
        stroke: "#0d171f",
        strokeWidth: 6,
        strokeLinecap: "round",
      }),
      e.jsx("path", {
        d: "M268 200 L270 140 q2 -16 16 -16 q16 0 18 16 l2 60z",
        fill: "#333e48",
      }),
      e.jsx("rect", { x: 279, y: 112, width: 11, height: 14, fill: "#c68642" }),
      e.jsx("circle", { cx: 286, cy: 104, r: 13, fill: "#c68642" }),
      e.jsx("path", {
        d: "M272 104 a14 14 0 0 1 28 -2 q-8 -4 -14 -3 q-8 1 -14 5z",
        fill: "#111b23",
      }),
      e.jsx("circle", { cx: 293, cy: 105, r: 1.5, fill: "#111b23" }),
      e.jsx("rect", {
        x: 292,
        y: 126,
        width: 60,
        height: 34,
        rx: 2,
        fill: "#ac3a38",
      }),
      e.jsx("path", {
        d: "M292 134 H352",
        stroke: "#ac3a38",
        strokeWidth: 1.4,
      }),
      e.jsx(r, {
        x: 322,
        y: 152,
        size: 9,
        anchor: "middle",
        fill: "#d1beaa",
        children: "PROPS",
      }),
      e.jsx("rect", {
        x: 306,
        y: 110,
        width: 32,
        height: 16,
        rx: 2,
        fill: "#ee766f",
      }),
      e.jsx(r, {
        x: 322,
        y: 121,
        size: 7,
        anchor: "middle",
        fill: "#e3e9ee",
        children: "RAW",
      }),
      e.jsx("rect", {
        x: 303,
        y: 107,
        width: 38,
        height: 22,
        rx: 3,
        fill: "none",
        stroke: "#cb5651",
        strokeWidth: 1.6,
        className: "attack-flash-stroke",
      }),
      e.jsx("circle", { cx: 292, cy: 150, r: 4.5, fill: "#c68642" }),
      e.jsx("circle", { cx: 352, cy: 150, r: 4.5, fill: "#c68642" }),
    ],
  });
}
function qs() {
  const i = [
    [236, "#003249"],
    [380, "#003249"],
    [270, "#00425f"],
  ];
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#0d171f" }),
      e.jsx("rect", { x: 0, y: 0, width: 400, height: 8, fill: "#002538" }),
      [60, 180].map((t) =>
        e.jsx(
          "path",
          {
            d: `M${t - 6} 8 h12 l30 150 h-72z`,
            fill: "#8ba3b7",
            opacity: 0.07,
          },
          t,
        ),
      ),
      e.jsx("rect", { x: 10, y: 24, width: 240, height: 126, fill: "#1c2f40" }),
      e.jsx(se, { x: 36, y: 46, s: 1.2 }),
      e.jsx(r, { x: 56, y: 52, size: 17, fill: "#e3e9ee", children: "VIDORA" }),
      e.jsx("rect", { x: 10, y: 68, width: 240, height: 4, fill: "#7ed99f" }),
      e.jsx("path", {
        d: "M50 150 L54 120 q4 -14 24 -14 q20 0 24 14 l2 30z",
        fill: "#137a47",
      }),
      e.jsx("path", { d: "M72 106 l6 30", stroke: "#e8ba61", strokeWidth: 2 }),
      e.jsx("rect", {
        x: 72,
        y: 134,
        width: 12,
        height: 9,
        rx: 1,
        fill: "#e3e9ee",
      }),
      e.jsx("rect", { x: 72, y: 92, width: 11, height: 14, fill: "#e0ac69" }),
      e.jsx("circle", { cx: 80, cy: 84, r: 13, fill: "#e0ac69" }),
      e.jsx("path", {
        d: "M66 86 a14 14 0 0 1 26 -10 q-6 0 -12 2 q-4 6 -6 14 q-4 -2 -8 -6z",
        fill: "#901e21",
      }),
      e.jsx("path", { d: "M66 86 q-6 10 -2 20 l6 -6z", fill: "#901e21" }),
      e.jsx("circle", { cx: 88, cy: 84, r: 1.5, fill: "#111b23" }),
      e.jsx("path", {
        d: "M96 122 L116 140 L146 144",
        fill: "none",
        stroke: "#137a47",
        strokeWidth: 8,
        strokeLinecap: "round",
        strokeLinejoin: "round",
      }),
      e.jsx("circle", { cx: 148, cy: 144, r: 4, fill: "#e0ac69" }),
      e.jsx("rect", {
        x: 122,
        y: 92,
        width: 86,
        height: 54,
        rx: 3,
        fill: "#111b23",
      }),
      e.jsx("rect", { x: 126, y: 96, width: 78, height: 46, fill: "#e3e9ee" }),
      e.jsx("rect", { x: 126, y: 96, width: 78, height: 12, fill: "#2b3f50" }),
      e.jsx(r, {
        x: 130,
        y: 105,
        size: 7,
        fill: "#e3e9ee",
        children: "Admin panel",
      }),
      e.jsx("rect", {
        x: 130,
        y: 112,
        width: 70,
        height: 11,
        rx: 2,
        fill: "#e3e9ee",
        stroke: "#95a1ac",
      }),
      e.jsx(r, {
        x: 133,
        y: 120,
        size: 7,
        weight: 400,
        fill: "#333e48",
        children: "maya.r",
      }),
      e.jsx("rect", {
        x: 130,
        y: 127,
        width: 70,
        height: 11,
        rx: 2,
        fill: "#e3e9ee",
        stroke: "#cb5651",
      }),
      e.jsx(r, {
        x: 133,
        y: 135.5,
        size: 7,
        fill: "#333e48",
        children: "• • • • • • •",
      }),
      e.jsx("path", { d: "M118 146 h94 l-6 4 h-82z", fill: "#5c6873" }),
      e.jsx("rect", { x: 10, y: 150, width: 240, height: 50, fill: "#2b3f50" }),
      e.jsx("rect", { x: 10, y: 150, width: 240, height: 5, fill: "#7ed99f" }),
      e.jsx("rect", { x: 0, y: 200, width: 400, height: 40, fill: "#001d2d" }),
      i.map(([t, s]) =>
        e.jsxs(
          "g",
          {
            children: [
              e.jsx("path", {
                d: `M${t - 24} 240 V214 a24 24 0 0 1 48 0 V240z`,
                fill: s,
              }),
              e.jsx("circle", { cx: t, cy: 180, r: 13, fill: s }),
            ],
          },
          t,
        ),
      ),
      e.jsx("path", {
        d: "M302 240 V206 a26 26 0 0 1 52 0 V240z",
        fill: "#ac3a38",
      }),
      e.jsx("circle", { cx: 328, cy: 170, r: 14, fill: "#111b23" }),
      e.jsx("path", {
        d: "M310 200 L300 168 L296 156",
        fill: "none",
        stroke: "#ac3a38",
        strokeWidth: 9,
        strokeLinecap: "round",
        strokeLinejoin: "round",
      }),
      e.jsx("circle", { cx: 296, cy: 154, r: 4.5, fill: "#8d5524" }),
      e.jsx("rect", {
        x: 288,
        y: 136,
        width: 14,
        height: 20,
        rx: 2,
        fill: "#111b23",
        stroke: "#8ba3b7",
      }),
      e.jsx("path", {
        d: "M288 146 C260 150 230 150 206 148",
        fill: "none",
        stroke: "#cb5651",
        strokeWidth: 1.8,
        strokeDasharray: "4 4",
        className: "attack-flow",
      }),
      e.jsx("path", {
        d: "M296 136 L310 128",
        stroke: "#8ba3b7",
        strokeWidth: 1.2,
        strokeDasharray: "3 3",
      }),
      e.jsx("rect", {
        x: 262,
        y: 8,
        width: 130,
        height: 120,
        rx: 10,
        fill: "#0d171f",
        stroke: "#8ba3b7",
        strokeWidth: 1.6,
      }),
      e.jsx("rect", {
        x: 268,
        y: 14,
        width: 118,
        height: 108,
        rx: 4,
        fill: "#002538",
      }),
      e.jsx("rect", {
        x: 274,
        y: 20,
        width: 26,
        height: 11,
        rx: 2,
        fill: "#cb5651",
        className: "attack-flash",
      }),
      e.jsx(r, {
        x: 287,
        y: 28.5,
        size: 7,
        anchor: "middle",
        fill: "#e3e9ee",
        children: "LIVE",
      }),
      e.jsx(r, {
        x: 306,
        y: 28.5,
        size: 7,
        fill: "#bac3cb",
        children: "12.4K watching",
      }),
      [38, 46, 54].map((t, s) =>
        e.jsx(
          "g",
          {
            children: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9].map((l) =>
              e.jsx(
                "rect",
                {
                  x: 274 + s * 3 + l * 10.5,
                  y: t,
                  width: 8.5,
                  height: 6,
                  rx: 1,
                  fill: "#46515b",
                },
                l,
              ),
            ),
          },
          t,
        ),
      ),
      e.jsx("rect", {
        x: 277 + 4 * 10.5,
        y: 46,
        width: 8.5,
        height: 6,
        rx: 1,
        fill: "#e8ba61",
      }),
      e.jsx("rect", {
        x: 278,
        y: 64,
        width: 98,
        height: 17,
        rx: 3,
        fill: "#0d171f",
        stroke: "#ffe4b4",
      }),
      e.jsx(C, {
        x: 327,
        y: 76,
        size: 9.5,
        anchor: "middle",
        fill: "#ffe4b4",
        children: "V1d0ra#Adm1n",
      }),
      e.jsx(r, {
        x: 274,
        y: 98,
        size: 7,
        fill: "#7ed99f",
        children: "@pixelpete",
      }),
      e.jsx(r, {
        x: 274,
        y: 110,
        size: 7,
        weight: 400,
        fill: "#bac3cb",
        children: "is that the admin password??",
      }),
    ],
  });
}
const Ds = {
    law_sql_injection: {
      Art: Cs,
      bg: "#111b23",
      alt: "A hooded attacker types an SQL command instead of a case reference into the Harcourt & Vale Track your case page, and the client database spills out 60,412 rows of names, home addresses and bank sort codes.",
    },
    law_blagging: {
      Art: Ns,
      bg: "#111b23",
      alt: "A conveyancing assistant on the desk phone is about to send £640,000 from a house sale to new bank details, while a caller in a cap reading from a script pretends to be the client and shouts to send it before 2pm.",
    },
    law_ddos: {
      Art: Ss,
      bg: "#0d171f",
      alt: "A botnet of hijacked computers floods the overheating Harcourt & Vale deal data room with 4.2 million requests a second, and a bidder clutches his head at a 503 error with three hours left to submit a final bid.",
    },
    law_shouldering: {
      Art: As,
      bg: "#111b23",
      alt: "In a café opposite the Royal Courts a trainee logs into the firm’s case system on a laptop, while a man at the next table films the keyboard on his phone and the recording shows the password Hv!Trial24.",
    },
    law_office_break_in: {
      Art: Vs,
      bg: "#0d171f",
      alt: "At 23:40 on a Friday a man in a cleaner’s tabard pushes a trolley away from the open archive room of wills and deeds, with the firm’s backup drive sitting on top and an empty slot left on the shelf.",
    },
    vidora_phishing: {
      Art: Hs,
      bg: "#0d171f",
      alt: "A moderator’s thumb taps a link in a text warning that their account will be suspended in 30 minutes, opening a fake Vidora ModDesk login page on a lookalike web address with a countdown.",
    },
    vidora_interception: {
      Art: Ps,
      bg: "#111b23",
      alt: "In a hotel lobby the night before the Vidora Creator Awards, a talent manager uploads winners.pdf over the Grand Hotel Guest Wi-Fi, and a hooded guest at a nearby table captures the packets from the router with packet-sniffing software, which shows Creator of the Year @kaizoom and Best Newcomer @luna_draws in readable text.",
    },
    vidora_virus: {
      Art: _s,
      bg: "#0d171f",
      alt: "A USB stick labelled S2 FINAL CUT is plugged in at the first edit machine, and a virus riding on the episode files copies itself from screen to screen across the edit suite, turning the footage into glitched stripes on three machines as it heads for the fourth, two days before Friday’s premiere with 3,412 clips already corrupted.",
    },
    vidora_studio_break_in: {
      Art: Is,
      bg: "#0d171f",
      alt: "In the Vidora creator studio a man carrying a box of props walks out through a propped-open side door with the raw footage drive of a secret collaboration, leaving an empty slot on the edit bay desk.",
    },
    vidora_shouldering: {
      Art: qs,
      bg: "#0d171f",
      alt: "At a gaming expo a Vidora engineer types into the admin panel on the stand laptop, while a fan in the crowd live-streams it to 12,400 viewers and the stream shows the password V1d0ra#Adm1n.",
    },
  },
  z = "#326e8e";
function u({
  x: i,
  y: t,
  size: s = 8,
  fill: l = "#111b23",
  anchor: a = "start",
  className: c,
  children: h,
}) {
  return e.jsx("text", {
    x: i,
    y: t,
    fontSize: s,
    fill: l,
    fontWeight: 700,
    textAnchor: a,
    fontFamily: "'Courier New', Courier, monospace",
    className: c,
    children: h,
  });
}
function Xe({ cx: i, cy: t, s = 1, fill: l = "#d1beaa", hole: a = "#901e21" }) {
  return e.jsxs("g", {
    transform: `translate(${i} ${t}) scale(${s})`,
    children: [
      e.jsx("path", {
        d: "M-12 -4v-8a12 12 0 0 1 24 0v8",
        fill: "none",
        stroke: l,
        strokeWidth: 5,
      }),
      e.jsx("rect", { x: -18, y: -6, width: 36, height: 28, rx: 5, fill: l }),
      e.jsx("circle", { cx: 0, cy: 6, r: 4, fill: a }),
      e.jsx("rect", { x: -1.5, y: 6, width: 3, height: 8, fill: a }),
    ],
  });
}
function Bt({ x: i, y: t }) {
  return e.jsx("path", {
    d: `M${i} ${t} l0 18 l5 -5 l4 9 l4 -2 l-4 -9 l7 0z`,
    fill: "#e3e9ee",
    stroke: "#111b23",
    strokeWidth: 1.2,
    strokeLinejoin: "round",
  });
}
function Bs({ x: i, y: t }) {
  return e.jsxs("g", {
    children: [
      e.jsx("rect", {
        x: i - 8,
        y: t - 4.5,
        width: 16,
        height: 9,
        rx: 2.5,
        fill: "#5c6873",
      }),
      e.jsx("rect", {
        x: i - 2,
        y: t - 4.5,
        width: 4,
        height: 9,
        fill: "#95a1ac",
      }),
      e.jsx("circle", { cx: i, cy: t - 9, r: 2, fill: "#46515b" }),
    ],
  });
}
function Rs() {
  const i = [
    [228, 48],
    [270, 74],
    [304, 46],
    [344, 92],
    [366, 52],
    [236, 98],
    [300, 100],
  ];
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#0d171f" }),
      e.jsx("rect", {
        x: 196,
        y: 8,
        width: 196,
        height: 106,
        rx: 4,
        fill: "#242f38",
        stroke: "#333e48",
      }),
      e.jsx("rect", { x: 200, y: 12, width: 188, height: 98, fill: "#242f38" }),
      e.jsx("path", {
        d: "M200 88 C240 76 270 106 310 94 S360 72 388 80",
        fill: "none",
        stroke: "#333e48",
        strokeWidth: 7,
      }),
      e.jsx("path", {
        d: "M200 62 H388 M252 26 V110 M322 26 V110 M200 34 L388 106 M360 26 L330 110",
        fill: "none",
        stroke: "#46515b",
        strokeWidth: 3,
      }),
      i.map(([t, s]) => e.jsx(Bs, { x: t, y: s }, `${t}-${s}`)),
      e.jsx("rect", {
        x: 200,
        y: 26,
        width: 188,
        height: 84,
        fill: "#111b23",
        opacity: 0.45,
      }),
      e.jsx("rect", { x: 200, y: 12, width: 188, height: 14, fill: "#111b23" }),
      e.jsx(r, {
        x: 206,
        y: 22.5,
        size: 7.5,
        fill: "#95a1ac",
        children: "LIVE UNITS",
      }),
      e.jsx("rect", {
        x: 330,
        y: 14,
        width: 54,
        height: 10,
        rx: 2,
        fill: "#ac3a38",
        className: "attack-flash",
      }),
      e.jsx(r, {
        x: 357,
        y: 22,
        size: 7,
        anchor: "middle",
        fill: "#e3e9ee",
        children: "OFFLINE",
      }),
      e.jsx("rect", {
        x: 196,
        y: 120,
        width: 196,
        height: 42,
        rx: 4,
        fill: "#111b23",
        stroke: "#cb5651",
        strokeWidth: 2,
        className: "attack-flash-stroke",
      }),
      e.jsx(r, {
        x: 208,
        y: 137,
        size: 9,
        fill: "#ffa79f",
        children: "999 CALLS",
      }),
      e.jsx(r, {
        x: 208,
        y: 151,
        size: 9,
        fill: "#ffa79f",
        children: "WAITING",
      }),
      [0, 1, 2, 3, 4].map((t) =>
        e.jsx(
          "rect",
          {
            x: 278 + t * 8,
            y: 154 - (t + 1) * 5.5,
            width: 5,
            height: (t + 1) * 5.5,
            fill: "#cb5651",
            opacity: 0.4 + t * 0.15,
          },
          t,
        ),
      ),
      e.jsx(u, {
        x: 344,
        y: 153,
        size: 28,
        fill: "#ee766f",
        anchor: "middle",
        children: "47",
      }),
      e.jsx("path", {
        d: "M378 154 V130 M371 137 l7 -7 l7 7",
        fill: "none",
        stroke: "#ee766f",
        strokeWidth: 2.5,
        strokeLinecap: "round",
        strokeLinejoin: "round",
      }),
      e.jsx("rect", { x: 0, y: 196, width: 400, height: 10, fill: "#333e48" }),
      e.jsx("rect", { x: 0, y: 206, width: 400, height: 34, fill: "#111b23" }),
      e.jsx("rect", {
        x: 10,
        y: 12,
        width: 180,
        height: 140,
        rx: 6,
        fill: "#242f38",
      }),
      e.jsx("rect", {
        x: 16,
        y: 18,
        width: 168,
        height: 126,
        rx: 2,
        fill: "#901e21",
        className: "attack-flash",
      }),
      e.jsx("rect", { x: 16, y: 18, width: 168, height: 14, fill: "#480004" }),
      e.jsx(r, {
        x: 22,
        y: 28,
        size: 7,
        fill: "#d1beaa",
        children: "DISPATCH",
      }),
      e.jsx("circle", { cx: 176, cy: 25, r: 2.5, fill: "#cb5651" }),
      e.jsx(Xe, { cx: 100, cy: 60 }),
      e.jsx(r, {
        x: 100,
        y: 104,
        size: 12,
        anchor: "middle",
        fill: "#e3e9ee",
        children: "DISPATCH LOCKED",
      }),
      e.jsx(r, {
        x: 100,
        y: 118,
        size: 8.5,
        anchor: "middle",
        weight: 400,
        fill: "#d1beaa",
        children: "Pay 40 Bitcoin to unlock",
      }),
      e.jsx("rect", {
        x: 56,
        y: 123,
        width: 88,
        height: 17,
        rx: 3,
        fill: "#480004",
      }),
      e.jsx(u, {
        x: 100,
        y: 135.5,
        size: 12,
        fill: "#ffa79f",
        anchor: "middle",
        children: "05:59:42",
      }),
      e.jsx("rect", { x: 92, y: 152, width: 16, height: 38, fill: "#333e48" }),
      e.jsx("rect", {
        x: 64,
        y: 188,
        width: 72,
        height: 8,
        rx: 3,
        fill: "#333e48",
      }),
      e.jsx("path", { d: "M226 198 L236 178 H296 L306 198z", fill: "#242f38" }),
      e.jsx("rect", {
        x: 228,
        y: 168,
        width: 76,
        height: 11,
        rx: 5.5,
        fill: "#46515b",
      }),
      [0, 1, 2].map((t) =>
        [0, 1, 2].map((s) =>
          e.jsx(
            "rect",
            {
              x: 250 + s * 9,
              y: 182 + t * 5,
              width: 6,
              height: 3,
              rx: 1,
              fill: "#5c6873",
            },
            `${t}-${s}`,
          ),
        ),
      ),
      e.jsx("circle", {
        cx: 292,
        cy: 188,
        r: 3.5,
        fill: "#cb5651",
        className: "attack-flash",
      }),
      [8, 16].map((t) =>
        e.jsxs(
          "g",
          {
            className: "attack-flash",
            children: [
              e.jsx("path", {
                d: `M${222 - t} ${166 - t / 2} q${-8 - t / 2} ${14 + t / 2} 0 ${28 + t}`,
                fill: "none",
                stroke: "#ee766f",
                strokeWidth: 2.5,
                strokeLinecap: "round",
              }),
              e.jsx("path", {
                d: `M${310 + t} ${166 - t / 2} q${8 + t / 2} ${14 + t / 2} 0 ${28 + t}`,
                fill: "none",
                stroke: "#ee766f",
                strokeWidth: 2.5,
                strokeLinecap: "round",
              }),
            ],
          },
          t,
        ),
      ),
      e.jsx("path", {
        d: "M346 194 a20 20 0 0 1 40 0",
        fill: "none",
        stroke: "#46515b",
        strokeWidth: 4,
      }),
      e.jsx("rect", {
        x: 340,
        y: 184,
        width: 10,
        height: 12,
        rx: 3,
        fill: "#333e48",
      }),
      e.jsx("rect", {
        x: 382,
        y: 184,
        width: 10,
        height: 12,
        rx: 3,
        fill: "#333e48",
      }),
      e.jsx("path", {
        d: "M345 190 q-12 0 -18 6",
        fill: "none",
        stroke: "#46515b",
        strokeWidth: 2,
      }),
      e.jsx("circle", { cx: 326, cy: 196, r: 2.5, fill: "#46515b" }),
    ],
  });
}
function De({ x: i, y: t }) {
  return e.jsxs("g", {
    children: [
      e.jsx("rect", {
        x: i - 8,
        y: t - 6,
        width: 16,
        height: 12,
        rx: 1.5,
        fill: "#e8ba61",
      }),
      e.jsx("path", {
        d: `M${i - 8} ${t - 6} l8 6 l8 -6`,
        fill: "none",
        stroke: "#901e21",
        strokeWidth: 1.2,
      }),
    ],
  });
}
function Fs() {
  const i = [
      [20, 16],
      [62, 30],
      [96, 12],
      [176, 22],
      [198, 52],
      [30, 58],
    ],
    t = Array.from({ length: 17 }, (s, l) => l);
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#0d171f" }),
      i.map(([s, l]) =>
        e.jsx(
          "circle",
          { cx: s, cy: l, r: 1.2, fill: "#bac3cb", opacity: 0.7 },
          `${s}-${l}`,
        ),
      ),
      e.jsx("path", {
        d: "M116 170 L128 44 L140 170 M119 140 L136 118 M121 118 L135 96 M123 96 L134 76 M125 76 L133 60",
        fill: "none",
        stroke: "#5c6873",
        strokeWidth: 2.5,
      }),
      e.jsx("rect", { x: 118, y: 44, width: 5, height: 16, fill: "#95a1ac" }),
      e.jsx("rect", { x: 133, y: 44, width: 5, height: 16, fill: "#95a1ac" }),
      e.jsx("circle", {
        cx: 128,
        cy: 38,
        r: 2.5,
        fill: "#cb5651",
        className: "attack-flash",
      }),
      [10, 18].map((s) =>
        e.jsx(
          "path",
          {
            d: `M142 ${52 - s} a${s} ${s} 0 0 1 0 ${2 * s}`,
            fill: "none",
            stroke: "#6ca8ca",
            strokeWidth: 2,
            strokeLinecap: "round",
            opacity: 1 - s / 40,
          },
          s,
        ),
      ),
      e.jsx("rect", { x: 212, y: 112, width: 4, height: 90, fill: "#333e48" }),
      e.jsx("path", {
        d: "M214 112 q0 -8 12 -8 h8",
        fill: "none",
        stroke: "#333e48",
        strokeWidth: 4,
      }),
      e.jsx("rect", {
        x: 228,
        y: 102,
        width: 14,
        height: 5,
        rx: 2,
        fill: "#ffe4b4",
      }),
      e.jsx("path", {
        d: "M230 107 L206 200 H264 L240 107z",
        fill: "#ffe4b4",
        opacity: 0.07,
      }),
      e.jsx("rect", { x: 0, y: 200, width: 400, height: 40, fill: "#242f38" }),
      [40, 130, 220, 310].map((s) =>
        e.jsx(
          "rect",
          {
            x: s,
            y: 220,
            width: 44,
            height: 4,
            fill: "#bac3cb",
            opacity: 0.35,
          },
          s,
        ),
      ),
      e.jsx("path", {
        d: "M60 196 V176 q0 -6 6 -8 L92 164 L112 146 H160 L184 164 L198 168 q4 2 4 8 V196z",
        fill: "#e3e9ee",
      }),
      e.jsx("path", {
        d: "M116 150 H136 V164 H100z M140 150 H158 L176 164 H140z",
        fill: "#242f38",
      }),
      t.map((s) =>
        e.jsxs(
          "g",
          {
            children: [
              e.jsx("rect", {
                x: 62 + s * 8,
                y: 172,
                width: 8,
                height: 7,
                fill: s % 2 ? "#e8ba61" : "#326e8e",
              }),
              e.jsx("rect", {
                x: 62 + s * 8,
                y: 179,
                width: 8,
                height: 7,
                fill: s % 2 ? "#326e8e" : "#e8ba61",
              }),
            ],
          },
          s,
        ),
      ),
      e.jsx("rect", {
        x: 122,
        y: 139,
        width: 30,
        height: 7,
        rx: 2,
        fill: "#326e8e",
        className: "attack-flash",
      }),
      e.jsx("rect", {
        x: 196,
        y: 170,
        width: 7,
        height: 6,
        rx: 2,
        fill: "#ffe4b4",
      }),
      e.jsx("rect", {
        x: 58,
        y: 170,
        width: 5,
        height: 6,
        rx: 1.5,
        fill: "#cb5651",
      }),
      [86, 174].map((s) =>
        e.jsxs(
          "g",
          {
            children: [
              e.jsx("circle", { cx: s, cy: 198, r: 12, fill: "#111b23" }),
              e.jsx("circle", { cx: s, cy: 198, r: 4.5, fill: "#95a1ac" }),
            ],
          },
          s,
        ),
      ),
      e.jsx("path", {
        d: "M30 156 L28 200 M42 156 L44 200",
        stroke: "#111b23",
        strokeWidth: 10,
      }),
      e.jsx("path", {
        d: "M22 202 h12 M40 202 h12",
        stroke: "#0d171f",
        strokeWidth: 6,
        strokeLinecap: "round",
      }),
      e.jsx("path", {
        d: "M24 112 L16 154",
        stroke: "#111b23",
        strokeWidth: 8,
        strokeLinecap: "round",
      }),
      e.jsx("path", {
        d: "M48 112 L56 152",
        stroke: "#111b23",
        strokeWidth: 8,
        strokeLinecap: "round",
      }),
      e.jsx("rect", {
        x: 22,
        y: 102,
        width: 28,
        height: 58,
        rx: 8,
        fill: "#111b23",
      }),
      e.jsx("rect", {
        x: 23,
        y: 108,
        width: 26,
        height: 46,
        rx: 4,
        fill: "#e8ba61",
      }),
      e.jsx("path", { d: "M23 142 H49", stroke: "#bac3cb", strokeWidth: 3 }),
      e.jsx("rect", {
        x: 45,
        y: 100,
        width: 6,
        height: 13,
        rx: 1.5,
        fill: "#0d171f",
      }),
      e.jsx("rect", {
        x: 30,
        y: 114,
        width: 13,
        height: 13,
        rx: 2,
        fill: "#0d171f",
        stroke: "#46515b",
      }),
      e.jsx("circle", { cx: 36.5, cy: 121, r: 3, fill: "#00425f" }),
      e.jsx("circle", {
        cx: 41,
        cy: 116.5,
        r: 1.5,
        fill: "#cb5651",
        className: "attack-flash",
      }),
      e.jsx("circle", { cx: 36, cy: 88, r: 12, fill: "#c68642" }),
      e.jsx("path", { d: "M24 82 q12 -14 24 0z", fill: "#111b23" }),
      [0, 1, 2, 3, 4, 5].map((s) =>
        e.jsx(
          "rect",
          {
            x: 24 + s * 4,
            y: 80,
            width: 4,
            height: 4,
            fill: s % 2 ? "#bac3cb" : "#111b23",
          },
          s,
        ),
      ),
      e.jsx("path", { d: "M22 84 H50 l-4 3 H22z", fill: "#0d171f" }),
      [8, 14, 20].map((s) =>
        e.jsx(
          "path",
          {
            d: `M43 ${119 - s} a${s} ${s} 0 0 1 ${s} ${s}`,
            fill: "none",
            stroke: "#6ca8ca",
            strokeWidth: 2,
            strokeLinecap: "round",
            opacity: 1 - s / 34,
          },
          `b${s}`,
        ),
      ),
      e.jsx("path", {
        d: "M58 104 L120 58 M137 136 L130 64",
        fill: "none",
        stroke: "#6ca8ca",
        strokeWidth: 1.6,
        strokeDasharray: "3 4",
        className: "attack-flow",
      }),
      e.jsx("path", {
        d: "M146 52 C200 46 222 126 330 112",
        fill: "none",
        stroke: "#ee766f",
        strokeWidth: 2,
        strokeDasharray: "5 5",
        className: "attack-flow",
      }),
      e.jsx(De, { x: 176, y: 58 }),
      e.jsx(De, { x: 206, y: 88 }),
      e.jsx(De, { x: 268, y: 116 }),
      e.jsx("path", {
        d: "M396 202 V138 q0 -10 -10 -10 H284 q-10 0 -16 8 L250 164 q-8 2 -8 10 V202z",
        fill: "#95a1ac",
      }),
      e.jsx("path", { d: "M280 134 H300 V164 H258z", fill: "#111b23" }),
      e.jsx("path", {
        d: "M284 164 q0 -16 10 -18 q8 2 8 18z",
        fill: "#333e48",
      }),
      e.jsx("rect", {
        x: 286,
        y: 156,
        width: 14,
        height: 8,
        fill: "#7ed99f",
        opacity: 0.5,
      }),
      e.jsx("rect", { x: 312, y: 134, width: 8, height: 64, fill: "#0d171f" }),
      e.jsx("rect", {
        x: 313,
        y: 142,
        width: 6,
        height: 36,
        fill: "#5bb57e",
        opacity: 0.35,
      }),
      e.jsx("rect", { x: 242, y: 182, width: 154, height: 4, fill: "#5c6873" }),
      e.jsx("rect", {
        x: 242,
        y: 170,
        width: 8,
        height: 6,
        rx: 2,
        fill: "#ffe4b4",
      }),
      e.jsx("path", { d: "M340 128 V110", stroke: "#95a1ac", strokeWidth: 2 }),
      e.jsx("path", {
        d: "M330 110 h20 M333 105 v10 M339 105 v10 M345 105 v10",
        stroke: "#bac3cb",
      }),
      [270, 366].map((s) =>
        e.jsxs(
          "g",
          {
            children: [
              e.jsx("circle", { cx: s, cy: 202, r: 13, fill: "#111b23" }),
              e.jsx("circle", { cx: s, cy: 202, r: 5, fill: "#95a1ac" }),
            ],
          },
          s,
        ),
      ),
      e.jsx("path", {
        d: "M316 134 L314 98",
        stroke: "#7ed99f",
        strokeWidth: 1.2,
        strokeDasharray: "2 3",
      }),
      e.jsx("rect", {
        x: 230,
        y: 8,
        width: 162,
        height: 90,
        rx: 5,
        fill: "#0d171f",
        stroke: "#5bb57e",
        strokeWidth: 1.5,
      }),
      e.jsx("circle", {
        cx: 240,
        cy: 20,
        r: 3,
        fill: "#cb5651",
        className: "attack-flash",
      }),
      e.jsx(u, {
        x: 248,
        y: 23,
        size: 8.5,
        fill: "#7ed99f",
        children: "CAPTURING",
      }),
      e.jsx(u, {
        x: 386,
        y: 23,
        size: 7,
        fill: "#a8ffc6",
        anchor: "end",
        children: "2,931 pkts",
      }),
      e.jsx("path", { d: "M230 29 H392", stroke: "#006034" }),
      e.jsx(u, {
        x: 238,
        y: 42,
        size: 7.5,
        fill: "#a8ffc6",
        children: "bodycam_0142.mp4",
      }),
      e.jsx(u, {
        x: 238,
        y: 56,
        size: 8,
        fill: "#ffe4b4",
        children: "SUSPECT: D. CARTER",
      }),
      e.jsx(u, {
        x: 238,
        y: 69,
        size: 8,
        fill: "#ffe4b4",
        children: "ADDR: 14 MILL LANE",
      }),
      e.jsx("rect", { x: 234, y: 76, width: 154, height: 15, fill: "#901e21" }),
      e.jsx(u, {
        x: 238,
        y: 86.5,
        size: 7.5,
        fill: "#d1beaa",
        children: "RADIO: UNIT 7 EN ROUTE",
      }),
    ],
  });
}
function Os({ x: i, y: t, tint: s }) {
  return e.jsxs("g", {
    children: [
      e.jsx("rect", {
        x: i,
        y: t,
        width: 22,
        height: 30,
        rx: 2,
        fill: "#bac3cb",
        opacity: 0.85,
      }),
      e.jsx("rect", { x: i, y: t, width: 22, height: 5, fill: "#cb5651" }),
      e.jsx("rect", {
        x: i + 4,
        y: t + 9,
        width: 14,
        height: 8,
        rx: 1,
        fill: "#e3e9ee",
      }),
      e.jsx("path", {
        d: `M${i + 6} ${t + 12} h10 M${i + 6} ${t + 15} h7`,
        stroke: "#95a1ac",
      }),
      e.jsx("rect", {
        x: i + 5,
        y: t + 20,
        width: 12,
        height: 7,
        rx: 2,
        fill: s,
      }),
    ],
  });
}
function Qs() {
  const i = [86, 130, 174],
    t = ["#5c6873", "#746351", "#00425f", "#901e21", "#006034"];
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#0d171f" }),
      e.jsx("rect", { x: 0, y: 0, width: 400, height: 204, fill: "#111b23" }),
      e.jsx("rect", { x: 0, y: 4, width: 400, height: 4, fill: "#333e48" }),
      [120, 260].map((s) =>
        e.jsx(
          "rect",
          {
            x: s,
            y: 8,
            width: 40,
            height: 4,
            rx: 2,
            fill: "#d1beaa",
            opacity: 0.6,
          },
          s,
        ),
      ),
      [0, 1, 2, 3, 4].map((s) =>
        e.jsx(
          "path",
          {
            d: `M${s * 100} 204 L${s * 100 - 30} 240`,
            stroke: "#242f38",
            strokeWidth: 2,
          },
          s,
        ),
      ),
      e.jsx("rect", {
        x: 20,
        y: 14,
        width: 140,
        height: 20,
        rx: 2,
        fill: "#00425f",
      }),
      e.jsx(r, {
        x: 90,
        y: 28,
        size: 9,
        anchor: "middle",
        fill: "#e3e9ee",
        children: "EVIDENCE STORE",
      }),
      e.jsx("rect", {
        x: 14,
        y: 40,
        width: 150,
        height: 164,
        fill: "#111b23",
        stroke: "#5c6873",
        strokeWidth: 3,
      }),
      i.map((s) =>
        e.jsx(
          "rect",
          { x: 18, y: s, width: 142, height: 5, fill: "#46515b" },
          s,
        ),
      ),
      e.jsx("rect", { x: 18, y: 44, width: 4, height: 160, fill: "#333e48" }),
      e.jsx("rect", { x: 156, y: 44, width: 4, height: 160, fill: "#333e48" }),
      i.map((s, l) =>
        [0, 1, 2, 3, 4].map((a) =>
          l === 1 && a === 2
            ? null
            : e.jsx(
                Os,
                { x: 27 + a * 26, y: s - 31, tint: t[(a + l) % 5] },
                `${l}-${a}`,
              ),
        ),
      ),
      e.jsx("rect", {
        x: 77,
        y: 99,
        width: 26,
        height: 30,
        rx: 2,
        fill: "#480004",
        opacity: 0.6,
        stroke: "#cb5651",
        strokeWidth: 1.5,
        strokeDasharray: "3 2",
        className: "attack-flash-stroke",
      }),
      e.jsx("path", {
        d: "M164 40 L198 30 V216 L164 204z",
        fill: "#242f38",
        opacity: 0.55,
      }),
      e.jsx("path", {
        d: "M164 40 L198 30 V216 L164 204z M172 38 V206 M181 35 V209 M190 33 V212 M164 80 L198 72 M164 120 L198 114 M164 160 L198 156",
        fill: "none",
        stroke: "#95a1ac",
        strokeWidth: 1.5,
      }),
      e.jsx("rect", {
        x: 158,
        y: 112,
        width: 10,
        height: 6,
        rx: 1,
        fill: "#95a1ac",
      }),
      e.jsxs("g", {
        transform: "rotate(-20 166 122)",
        children: [
          e.jsx("path", {
            d: "M160 124 v-6 a5 5 0 0 1 10 0",
            fill: "none",
            stroke: "#bac3cb",
            strokeWidth: 2.5,
          }),
          e.jsx("rect", {
            x: 158,
            y: 123,
            width: 14,
            height: 12,
            rx: 2,
            fill: "#bac3cb",
          }),
          e.jsx("circle", { cx: 165, cy: 129, r: 1.8, fill: "#46515b" }),
        ],
      }),
      e.jsx("rect", {
        x: 324,
        y: 30,
        width: 66,
        height: 16,
        rx: 2,
        fill: "#901e21",
      }),
      e.jsx(r, {
        x: 357,
        y: 41.5,
        size: 8,
        anchor: "middle",
        fill: "#e3e9ee",
        children: "STAFF ONLY",
      }),
      e.jsx("rect", {
        x: 326,
        y: 52,
        width: 64,
        height: 152,
        fill: "#001d2d",
        stroke: "#5c6873",
        strokeWidth: 3,
      }),
      e.jsx("circle", { cx: 344, cy: 74, r: 1.2, fill: "#bac3cb" }),
      e.jsx("circle", { cx: 372, cy: 92, r: 1.2, fill: "#bac3cb" }),
      e.jsx("path", { d: "M326 170 h64 v34 h-64z", fill: "#111b23" }),
      e.jsx("path", { d: "M392 54 L400 50 V212 L392 204z", fill: "#46515b" }),
      e.jsx("path", {
        d: "M326 204 L390 204 L400 240 L300 240z",
        fill: "#ffe4b4",
        opacity: 0.05,
      }),
      e.jsx("rect", {
        x: 308,
        y: 96,
        width: 12,
        height: 18,
        rx: 2,
        fill: "#242f38",
        stroke: "#5c6873",
      }),
      e.jsx("circle", { cx: 314, cy: 109, r: 2, fill: "#5bb57e" }),
      e.jsxs("g", {
        transform: "translate(-12 0)",
        children: [
          e.jsx("path", {
            d: "M262 156 L246 220 M282 156 L300 220",
            stroke: "#242f38",
            strokeWidth: 13,
            strokeLinecap: "round",
          }),
          e.jsx("path", {
            d: "M238 222 h16 M292 222 h16",
            stroke: "#0d171f",
            strokeWidth: 7,
            strokeLinecap: "round",
          }),
          e.jsx("rect", {
            x: 254,
            y: 92,
            width: 38,
            height: 68,
            rx: 10,
            fill: "#ac3a38",
          }),
          e.jsx("rect", {
            x: 254,
            y: 140,
            width: 38,
            height: 6,
            fill: "#e8ba61",
          }),
          e.jsx("path", {
            d: "M266 92 L273 104 L280 92",
            fill: "none",
            stroke: "#e8ba61",
            strokeWidth: 2,
          }),
          e.jsx("rect", {
            x: 278,
            y: 110,
            width: 9,
            height: 8,
            rx: 1,
            fill: "#e3e9ee",
          }),
          e.jsx("path", {
            d: "M278 114 h9 M282.5 110 v8",
            stroke: "#ac3a38",
            strokeWidth: 1,
          }),
          e.jsx("circle", { cx: 273, cy: 76, r: 14, fill: "#d6a77a" }),
          e.jsx("path", { d: "M259 72 a14 14 0 0 1 28 0z", fill: "#ac3a38" }),
          e.jsx("path", { d: "M285 70 h12 q2 3 -2 4 h-10z", fill: "#ac3a38" }),
          e.jsx("circle", { cx: 279, cy: 78, r: 1.6, fill: "#111b23" }),
          e.jsx("path", {
            d: "M222 122 L266 116 L274 146 L230 152z",
            fill: "#bac3cb",
            stroke: "#46515b",
            strokeWidth: 1.5,
          }),
          e.jsx("path", {
            d: "M224 128 L266 122",
            stroke: "#95a1ac",
            strokeWidth: 1.5,
          }),
          e.jsx("path", {
            d: "M232 150 L226 170",
            stroke: "#cb5651",
            strokeWidth: 1.2,
          }),
          e.jsx("rect", {
            x: 198,
            y: 168,
            width: 58,
            height: 13,
            rx: 2,
            fill: "#cb5651",
          }),
          e.jsx(r, {
            x: 227,
            y: 177.5,
            size: 7,
            anchor: "middle",
            fill: "#e3e9ee",
            children: "INFORMANTS",
          }),
          e.jsx("path", {
            d: "M262 100 L252 134 L240 140",
            fill: "none",
            stroke: "#ac3a38",
            strokeWidth: 10,
            strokeLinecap: "round",
            strokeLinejoin: "round",
          }),
          e.jsx("circle", { cx: 238, cy: 141, r: 5, fill: "#d6a77a" }),
          e.jsx("path", {
            d: "M286 100 L306 128",
            stroke: "#ac3a38",
            strokeWidth: 10,
            strokeLinecap: "round",
          }),
          e.jsx("rect", {
            x: 292,
            y: 124,
            width: 30,
            height: 26,
            rx: 1.5,
            fill: "#d6a77a",
            stroke: "#ac3a38",
          }),
          e.jsx("path", {
            d: "M307 124 V150 M292 132 H322",
            stroke: "#746351",
            strokeWidth: 2,
          }),
          e.jsx("circle", { cx: 306, cy: 128, r: 5, fill: "#d6a77a" }),
        ],
      }),
    ],
  });
}
function te({ x: i, y: t, rotate: s = 0 }) {
  return e.jsxs("g", {
    transform: `translate(${i} ${t}) rotate(${s})`,
    children: [
      e.jsx("path", {
        d: "M-14 0 q3.5 -7 7 0 t7 0 t7 0",
        fill: "none",
        stroke: "#cb5651",
        strokeWidth: 5,
        strokeLinecap: "round",
      }),
      e.jsx("circle", { cx: 9, cy: 0, r: 5, fill: "#cb5651" }),
      e.jsx("circle", { cx: 10.5, cy: -1.5, r: 1.6, fill: "#e3e9ee" }),
    ],
  });
}
function Us({ cx: i, label: t, infected: s }) {
  return e.jsxs("g", {
    children: [
      e.jsx(r, {
        x: i,
        y: 34,
        size: 7,
        anchor: "middle",
        fill: s ? "#ffa79f" : "#8ecbee",
        children: t,
      }),
      e.jsx("rect", {
        x: i - 26,
        y: 40,
        width: 52,
        height: 38,
        rx: 3,
        fill: "#242f38",
        stroke: "#46515b",
      }),
      e.jsx("rect", {
        x: i - 22,
        y: 44,
        width: 44,
        height: 30,
        fill: s ? "#901e21" : "#326e8e",
        className: s ? "attack-flash" : void 0,
      }),
      s
        ? e.jsx(Xe, { cx: i, cy: 56, s: 0.42 })
        : e.jsx("path", {
            d: `M${i - 18} 60 h10 l3 -8 l4 14 l3 -6 h16`,
            fill: "none",
            stroke: "#cfedff",
            strokeWidth: 1.8,
            strokeLinejoin: "round",
          }),
      e.jsx("rect", { x: i - 3, y: 78, width: 6, height: 8, fill: "#46515b" }),
      e.jsx("rect", {
        x: i - 12,
        y: 86,
        width: 24,
        height: 4,
        rx: 1,
        fill: "#46515b",
      }),
    ],
  });
}
function Zs() {
  const i = [
      [168, "THEATRE 1", !0],
      [230, "THEATRE 2", !0],
      [292, "WARD 4", !0],
      [354, "PHARMACY", !1],
    ],
    t = Array.from({ length: 15 }, (s, l) => l);
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#0d171f" }),
      e.jsx("rect", { x: 0, y: 0, width: 400, height: 146, fill: "#002538" }),
      e.jsx("rect", { x: 0, y: 0, width: 400, height: 18, fill: z }),
      e.jsx(r, {
        x: 10,
        y: 13,
        size: 9,
        fill: "#e3e9ee",
        children: "St Elm University Hospital",
      }),
      e.jsx("path", {
        d: "M64 116 V130 M64 130 H354 M168 90 V130 M230 90 V130 M292 90 V130 M354 90 V130",
        fill: "none",
        stroke: "#333e48",
        strokeWidth: 4,
      }),
      e.jsx("path", {
        d: "M64 116 V130 H330 M168 90 V130 M230 90 V130 M292 90 V130",
        fill: "none",
        stroke: "#cb5651",
        strokeWidth: 1.6,
        strokeDasharray: "4 6",
        className: "attack-flow",
      }),
      e.jsx("rect", {
        x: 24,
        y: 92,
        width: 80,
        height: 24,
        rx: 3,
        fill: "#bac3cb",
      }),
      e.jsx("circle", { cx: 64, cy: 68, r: 42, fill: "#bac3cb" }),
      e.jsx("circle", { cx: 64, cy: 68, r: 20, fill: "#242f38" }),
      e.jsx("rect", {
        x: 64,
        y: 78,
        width: 74,
        height: 7,
        rx: 2,
        fill: "#95a1ac",
      }),
      e.jsx("rect", { x: 124, y: 85, width: 7, height: 31, fill: "#5c6873" }),
      e.jsx("circle", {
        cx: 64,
        cy: 68,
        r: 42,
        fill: "#cb5651",
        opacity: 0.28,
        className: "attack-flash",
      }),
      e.jsx("circle", {
        cx: 64,
        cy: 68,
        r: 42,
        fill: "none",
        stroke: "#cb5651",
        strokeWidth: 2.5,
      }),
      e.jsx("rect", {
        x: 44,
        y: 98,
        width: 40,
        height: 14,
        rx: 2,
        fill: "#901e21",
      }),
      e.jsx(r, {
        x: 64,
        y: 108.5,
        size: 8,
        anchor: "middle",
        fill: "#e3e9ee",
        children: "MRI",
      }),
      i.map(([s, l, a]) => e.jsx(Us, { cx: s, label: l, infected: a }, l)),
      e.jsx(te, { x: 110, y: 130 }),
      e.jsx(te, { x: 198, y: 130 }),
      e.jsx(te, { x: 262, y: 130 }),
      e.jsx(te, { x: 292, y: 106, rotate: -90 }),
      e.jsx(te, { x: 326, y: 130 }),
      e.jsx("rect", { x: 34, y: 186, width: 6, height: 20, fill: "#46515b" }),
      e.jsx("rect", { x: 124, y: 186, width: 6, height: 20, fill: "#46515b" }),
      e.jsx("rect", {
        x: 14,
        y: 150,
        width: 136,
        height: 38,
        rx: 3,
        fill: "#0d171f",
        stroke: "#46515b",
      }),
      e.jsx("rect", { x: 14, y: 150, width: 46, height: 38, rx: 3, fill: z }),
      e.jsx(r, {
        x: 37,
        y: 174,
        size: 13,
        anchor: "middle",
        fill: "#e3e9ee",
        children: "A&E",
      }),
      e.jsx(u, {
        x: 104,
        y: 174,
        size: 13,
        fill: "#ee766f",
        anchor: "middle",
        className: "attack-flash",
        children: "DIVERTED",
      }),
      e.jsx("rect", { x: 0, y: 204, width: 400, height: 36, fill: "#242f38" }),
      [20, 110, 200, 290, 380].map((s) =>
        e.jsx(
          "rect",
          {
            x: s,
            y: 222,
            width: 44,
            height: 4,
            fill: "#bac3cb",
            opacity: 0.35,
          },
          s,
        ),
      ),
      e.jsx("path", {
        d: "M168 164 h20 M160 176 h26 M170 188 h16",
        stroke: "#5c6873",
        strokeWidth: 2,
        strokeLinecap: "round",
      }),
      e.jsx("rect", {
        x: 196,
        y: 152,
        width: 128,
        height: 50,
        rx: 4,
        fill: "#ffe4b4",
      }),
      e.jsx("path", {
        d: "M324 162 H354 L376 182 V202 H324z",
        fill: "#ffe4b4",
      }),
      e.jsx("path", { d: "M330 166 H352 L368 182 H330z", fill: "#111b23" }),
      t.map((s) =>
        e.jsxs(
          "g",
          {
            children: [
              e.jsx("rect", {
                x: 198 + s * 12,
                y: 184,
                width: 12,
                height: 6,
                fill: s % 2 ? "#ffe4b4" : "#137a47",
              }),
              e.jsx("rect", {
                x: 198 + s * 12,
                y: 190,
                width: 12,
                height: 6,
                fill: s % 2 ? "#137a47" : "#ffe4b4",
              }),
            ],
          },
          s,
        ),
      ),
      e.jsx("rect", { x: 198, y: 176, width: 176, height: 3, fill: "#399661" }),
      e.jsx(r, {
        x: 258,
        y: 170,
        size: 9.5,
        anchor: "middle",
        fill: "#137a47",
        children: "AMBULANCE",
      }),
      e.jsx("rect", {
        x: 204,
        y: 146,
        width: 20,
        height: 6,
        rx: 2,
        fill: "#326e8e",
        className: "attack-flash",
      }),
      e.jsx("rect", {
        x: 300,
        y: 146,
        width: 20,
        height: 6,
        rx: 2,
        fill: "#326e8e",
        className: "attack-flash",
      }),
      e.jsx("rect", {
        x: 370,
        y: 186,
        width: 7,
        height: 6,
        rx: 2,
        fill: "#e3e9ee",
      }),
      e.jsx("rect", { x: 196, y: 160, width: 5, height: 10, fill: "#cb5651" }),
      [226, 346].map((s) =>
        e.jsxs(
          "g",
          {
            children: [
              e.jsx("circle", { cx: s, cy: 204, r: 12, fill: "#111b23" }),
              e.jsx("circle", { cx: s, cy: 204, r: 4.5, fill: "#95a1ac" }),
            ],
          },
          s,
        ),
      ),
    ],
  });
}
function Ys() {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#242f38" }),
      e.jsx("rect", {
        x: 0,
        y: 150,
        width: 400,
        height: 6,
        fill: z,
        opacity: 0.6,
      }),
      e.jsxs(f, {
        x: 244,
        y: 10,
        w: 146,
        h: 124,
        bar: "#5c6873",
        children: [
          e.jsx("rect", {
            x: 250,
            y: 30,
            width: 134,
            height: 13,
            rx: 6.5,
            fill: "#bac3cb",
            stroke: "#ee766f",
          }),
          e.jsx(r, {
            x: 256,
            y: 39.5,
            size: 6.5,
            weight: 400,
            fill: "#ac3a38",
            children: "stelm-nhs.records-verify.co",
          }),
          e.jsx("rect", { x: 245, y: 46, width: 144, height: 18, fill: z }),
          e.jsx(r, {
            x: 317,
            y: 59,
            size: 9.5,
            anchor: "middle",
            fill: "#e3e9ee",
            children: "St Elm Hospital",
          }),
          e.jsx(r, {
            x: 317,
            y: 76,
            size: 8,
            anchor: "middle",
            weight: 400,
            fill: "#333e48",
            children: "Patient Records",
          }),
          e.jsx("rect", {
            x: 256,
            y: 82,
            width: 122,
            height: 13,
            rx: 3,
            fill: "#e3e9ee",
            stroke: "#95a1ac",
          }),
          e.jsx(r, {
            x: 261,
            y: 91.5,
            size: 7.5,
            weight: 400,
            fill: "#333e48",
            children: "dr.osei",
          }),
          e.jsx("rect", {
            x: 256,
            y: 99,
            width: 122,
            height: 13,
            rx: 3,
            fill: "#e3e9ee",
            stroke: "#95a1ac",
          }),
          e.jsx(r, {
            x: 261,
            y: 109,
            size: 8,
            fill: "#333e48",
            children: "• • • • • • •",
          }),
          e.jsx("rect", {
            x: 287,
            y: 116,
            width: 60,
            height: 14,
            rx: 3,
            fill: z,
          }),
          e.jsx(r, {
            x: 317,
            y: 126,
            size: 8,
            anchor: "middle",
            fill: "#e3e9ee",
            children: "Log in",
          }),
        ],
      }),
      e.jsx("rect", {
        x: 8,
        y: 8,
        width: 228,
        height: 156,
        rx: 6,
        fill: "#111b23",
      }),
      e.jsxs(f, {
        x: 14,
        y: 14,
        w: 216,
        h: 144,
        bar: z,
        children: [
          e.jsx("rect", {
            x: 14,
            y: 30,
            width: 52,
            height: 128,
            fill: "#bac3cb",
          }),
          [0, 1, 2, 3].map((i) =>
            e.jsxs(
              "g",
              {
                children: [
                  e.jsx("rect", {
                    x: 18,
                    y: 35 + i * 30,
                    width: 44,
                    height: 25,
                    rx: 3,
                    fill: i === 0 ? "#bac3cb" : "#e3e9ee",
                  }),
                  e.jsx("rect", {
                    x: 22,
                    y: 40 + i * 30,
                    width: 26,
                    height: 4,
                    rx: 2,
                    fill: i === 0 ? "#ac3a38" : "#5c6873",
                  }),
                  e.jsx("rect", {
                    x: 22,
                    y: 49 + i * 30,
                    width: 34,
                    height: 3,
                    rx: 1.5,
                    fill: "#95a1ac",
                  }),
                ],
              },
              i,
            ),
          ),
          e.jsx(r, {
            x: 74,
            y: 44,
            size: 8,
            weight: 400,
            fill: "#46515b",
            children: "From: IT Service Desk",
          }),
          e.jsx(r, {
            x: 74,
            y: 55,
            size: 7,
            weight: 400,
            fill: "#ac3a38",
            children: "itdesk@stelm-nhs.support",
          }),
          e.jsx(r, {
            x: 74,
            y: 74,
            size: 10,
            fill: "#111b23",
            children: "Your patient records",
          }),
          e.jsx(r, {
            x: 74,
            y: 86,
            size: 10,
            fill: "#111b23",
            children: "login expires today",
          }),
          [0, 1, 2].map((i) =>
            e.jsx(
              "rect",
              {
                x: 74,
                y: 95 + i * 8,
                width: i === 2 ? 80 : 146,
                height: 3.5,
                rx: 1.75,
                fill: "#bac3cb",
              },
              i,
            ),
          ),
          e.jsx("rect", {
            x: 74,
            y: 124,
            width: 80,
            height: 22,
            rx: 4,
            fill: "#cb5651",
          }),
          e.jsx(r, {
            x: 114,
            y: 138.5,
            size: 9,
            anchor: "middle",
            fill: "#e3e9ee",
            children: "Verify now",
          }),
          e.jsx(Bt, { x: 140, y: 134 }),
        ],
      }),
      e.jsx("path", {
        d: "M156 140 C196 160 220 120 244 104",
        fill: "none",
        stroke: "#ee766f",
        strokeWidth: 1.8,
        strokeDasharray: "4 4",
        className: "attack-flow",
      }),
      e.jsx("rect", { x: 112, y: 164, width: 20, height: 26, fill: "#333e48" }),
      e.jsx("rect", {
        x: 90,
        y: 188,
        width: 64,
        height: 8,
        rx: 2,
        fill: "#333e48",
      }),
      e.jsx("path", {
        d: "M282 240 V206 a34 34 0 0 1 68 0 V240z",
        fill: "#326e8e",
      }),
      e.jsx("path", { d: "M304 175 L316 200 L328 175", fill: "#175675" }),
      e.jsx("path", {
        d: "M302 178 q-2 14 14 18 M330 178 q2 14 -14 18",
        fill: "none",
        stroke: "#bac3cb",
        strokeWidth: 2.5,
      }),
      e.jsx("circle", { cx: 316, cy: 196, r: 4, fill: "#95a1ac" }),
      e.jsx("rect", {
        x: 333,
        y: 180,
        width: 12,
        height: 15,
        rx: 2,
        fill: "#e3e9ee",
      }),
      e.jsx("rect", { x: 333, y: 180, width: 12, height: 4, fill: z }),
      e.jsx("circle", { cx: 316, cy: 158, r: 17, fill: "#8d5524" }),
      e.jsx("path", {
        d: "M299 156 a17 17 0 0 1 34 0 q-17 -6 -34 0z",
        fill: "#8ecbee",
      }),
      e.jsx("path", {
        d: "M299 156 q17 -6 34 0",
        fill: "none",
        stroke: "#326e8e",
        strokeWidth: 1.5,
      }),
      e.jsx("circle", { cx: 309, cy: 164, r: 1.8, fill: "#111b23" }),
      e.jsx("circle", { cx: 322, cy: 164, r: 1.8, fill: "#111b23" }),
      e.jsx("rect", { x: 0, y: 196, width: 400, height: 10, fill: "#46515b" }),
      e.jsx("rect", { x: 0, y: 206, width: 400, height: 34, fill: "#242f38" }),
      e.jsx("rect", {
        x: 40,
        y: 188,
        width: 44,
        height: 8,
        rx: 2,
        fill: "#242f38",
      }),
      e.jsx("rect", {
        x: 210,
        y: 188,
        width: 12,
        height: 8,
        rx: 4,
        fill: "#bac3cb",
      }),
      e.jsx("path", {
        d: "M292 184 L254 191 L226 191",
        fill: "none",
        stroke: "#326e8e",
        strokeWidth: 10,
        strokeLinecap: "round",
        strokeLinejoin: "round",
      }),
      e.jsx("circle", { cx: 221, cy: 190, r: 5.5, fill: "#8d5524" }),
    ],
  });
}
function Gs({ cx: i, cy: t }) {
  return e.jsxs("g", {
    children: [
      e.jsx("path", {
        d: `M${i} ${t - 18} V${t - 28}`,
        stroke: "#5c6873",
        strokeWidth: 2,
      }),
      e.jsx("circle", {
        cx: i,
        cy: t - 30,
        r: 3.5,
        fill: "#cb5651",
        className: "attack-flash",
      }),
      e.jsx("rect", {
        x: i - 26,
        y: t - 6,
        width: 5,
        height: 12,
        rx: 1.5,
        fill: "#46515b",
      }),
      e.jsx("rect", {
        x: i + 21,
        y: t - 6,
        width: 5,
        height: 12,
        rx: 1.5,
        fill: "#46515b",
      }),
      e.jsx("rect", {
        x: i - 22,
        y: t - 18,
        width: 44,
        height: 34,
        rx: 8,
        fill: "#333e48",
        stroke: "#5c6873",
        strokeWidth: 1.5,
      }),
      e.jsx("rect", {
        x: i - 17,
        y: t - 12,
        width: 34,
        height: 13,
        rx: 4,
        fill: "#111b23",
      }),
      e.jsx("circle", { cx: i - 8, cy: t - 5.5, r: 3.5, fill: "#cb5651" }),
      e.jsx("circle", { cx: i + 8, cy: t - 5.5, r: 3.5, fill: "#cb5651" }),
      e.jsx("path", {
        d: `M${i - 10} ${t + 8} H${i + 10} M${i - 5} ${t + 5} V${t + 11} M${i} ${t + 5} V${t + 11} M${i + 5} ${t + 5} V${t + 11}`,
        stroke: "#95a1ac",
        strokeWidth: 1.5,
      }),
    ],
  });
}
function Ks({ x: i, y: t, text: s }) {
  const l = s.length * 5.4 + 12;
  return e.jsxs("g", {
    children: [
      e.jsx("rect", {
        x: i,
        y: t - 9,
        width: l,
        height: 15,
        rx: 7.5,
        fill: "#242f38",
        stroke: "#ee766f",
        strokeWidth: 1.2,
      }),
      e.jsx(u, {
        x: i + l / 2,
        y: t + 1.5,
        size: 9,
        fill: "#d1beaa",
        anchor: "middle",
        children: s,
      }),
    ],
  });
}
function Js() {
  const i = [44, 120, 196],
    t = [
      ["password1", 82, 20],
      ["nhs2024", 130, 60],
      ["doctor!", 84, 96],
      ["StElm123", 128, 136],
      ["Welcome1", 82, 170],
      ["consultant", 116, 222],
    ];
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#0d171f" }),
      i.map((s) =>
        e.jsx(
          "path",
          {
            d: `M66 ${s} C150 ${s} 170 112 234 112`,
            fill: "none",
            stroke: "#cb5651",
            strokeWidth: 1.6,
            strokeDasharray: "4 5",
            opacity: 0.8,
            className: "attack-flow",
          },
          `flow-${s}`,
        ),
      ),
      i.map((s) => e.jsx(Gs, { cx: 36, cy: s + 4 }, s)),
      t.map(([s, l, a]) => e.jsx(Ks, { x: l, y: a, text: s }, s)),
      e.jsxs(f, {
        x: 234,
        y: 10,
        w: 156,
        h: 184,
        bar: "#333e48",
        children: [
          e.jsx("rect", { x: 235, y: 26, width: 154, height: 22, fill: z }),
          e.jsx(r, {
            x: 312,
            y: 41,
            size: 10,
            anchor: "middle",
            fill: "#e3e9ee",
            children: "St Elm Hospital",
          }),
          e.jsx("rect", {
            x: 298,
            y: 56,
            width: 28,
            height: 20,
            rx: 2,
            fill: "#242f38",
          }),
          e.jsx("rect", {
            x: 301,
            y: 59,
            width: 22,
            height: 14,
            fill: "#6ca8ca",
          }),
          e.jsx("rect", {
            x: 308,
            y: 76,
            width: 8,
            height: 4,
            fill: "#242f38",
          }),
          e.jsx(Xe, {
            cx: 312,
            cy: 65,
            s: 0.25,
            fill: "#111b23",
            hole: "#6ca8ca",
          }),
          e.jsx(r, {
            x: 312,
            y: 92,
            size: 8.5,
            anchor: "middle",
            fill: "#111b23",
            children: "Consultant Remote Access",
          }),
          e.jsx("rect", {
            x: 248,
            y: 100,
            width: 128,
            height: 16,
            rx: 3,
            fill: "#e3e9ee",
            stroke: "#95a1ac",
          }),
          e.jsx(r, {
            x: 254,
            y: 111.5,
            size: 8,
            weight: 400,
            fill: "#333e48",
            children: "dr.ahmed",
          }),
          e.jsx("rect", {
            x: 248,
            y: 122,
            width: 128,
            height: 16,
            rx: 3,
            fill: "#e3e9ee",
            stroke: "#cb5651",
            strokeWidth: 1.5,
          }),
          e.jsx(r, {
            x: 254,
            y: 134,
            size: 9,
            fill: "#333e48",
            children: "• • • • • • • • •",
          }),
          e.jsx("rect", {
            x: 282,
            y: 145,
            width: 60,
            height: 16,
            rx: 3,
            fill: z,
          }),
          e.jsx(r, {
            x: 312,
            y: 156.5,
            size: 8,
            anchor: "middle",
            fill: "#e3e9ee",
            children: "Log in",
          }),
          e.jsx("rect", {
            x: 235,
            y: 170,
            width: 154,
            height: 16,
            fill: "#bac3cb",
          }),
          e.jsx(r, {
            x: 312,
            y: 181,
            size: 8,
            anchor: "middle",
            fill: "#ac3a38",
            children: "Incorrect password",
          }),
        ],
      }),
      e.jsx("rect", {
        x: 234,
        y: 202,
        width: 156,
        height: 30,
        rx: 4,
        fill: "#480004",
        stroke: "#cb5651",
        strokeWidth: 2,
        className: "attack-flash-stroke",
      }),
      e.jsx(u, {
        x: 312,
        y: 222,
        size: 13,
        fill: "#ffa79f",
        anchor: "middle",
        children: "73,904 tries",
      }),
    ],
  });
}
function Xs() {
  const i = Array.from({ length: 24 }, (t, s) => s);
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#0d171f" }),
      e.jsx("rect", { x: 0, y: 0, width: 400, height: 150, fill: "#111b23" }),
      e.jsx("rect", {
        x: 296,
        y: 8,
        width: 94,
        height: 18,
        rx: 2,
        fill: "#00425f",
      }),
      e.jsx(r, {
        x: 343,
        y: 20.5,
        size: 8.5,
        anchor: "middle",
        fill: "#e3e9ee",
        children: "CUSTODY SUITE",
      }),
      e.jsx("rect", {
        x: 10,
        y: 12,
        width: 176,
        height: 116,
        rx: 6,
        fill: "#242f38",
      }),
      e.jsx("rect", {
        x: 16,
        y: 18,
        width: 164,
        height: 104,
        rx: 2,
        fill: "#111b23",
      }),
      e.jsx("rect", { x: 16, y: 18, width: 164, height: 16, fill: "#00425f" }),
      e.jsx(r, {
        x: 22,
        y: 29.5,
        size: 8,
        fill: "#e3e9ee",
        children: "INTELLIGENCE DATABASE",
      }),
      e.jsx(r, {
        x: 26,
        y: 50,
        size: 7.5,
        weight: 400,
        fill: "#95a1ac",
        children: "Officer ID",
      }),
      e.jsx("rect", {
        x: 26,
        y: 54,
        width: 144,
        height: 15,
        rx: 2,
        fill: "#242f38",
        stroke: "#46515b",
      }),
      e.jsx(u, {
        x: 32,
        y: 64.5,
        size: 8.5,
        fill: "#bac3cb",
        children: "PS 2147",
      }),
      e.jsx(r, {
        x: 26,
        y: 83,
        size: 7.5,
        weight: 400,
        fill: "#95a1ac",
        children: "Password",
      }),
      e.jsx("rect", {
        x: 26,
        y: 87,
        width: 144,
        height: 15,
        rx: 2,
        fill: "#242f38",
        stroke: "#cb5651",
        strokeWidth: 1.5,
        className: "attack-flash-stroke",
      }),
      e.jsx(r, {
        x: 32,
        y: 98.5,
        size: 9,
        fill: "#bac3cb",
        children: "• • • • • •",
      }),
      e.jsx("rect", {
        x: 90,
        y: 90,
        width: 1.5,
        height: 9,
        fill: "#bac3cb",
        className: "attack-flash",
      }),
      e.jsx("rect", {
        x: 124,
        y: 106,
        width: 46,
        height: 12,
        rx: 2,
        fill: "#326e8e",
      }),
      e.jsx(r, {
        x: 147,
        y: 114.5,
        size: 7,
        anchor: "middle",
        fill: "#e3e9ee",
        children: "Log in",
      }),
      e.jsx("rect", { x: 90, y: 128, width: 16, height: 24, fill: "#333e48" }),
      e.jsx("rect", {
        x: 70,
        y: 150,
        width: 56,
        height: 6,
        rx: 2,
        fill: "#333e48",
      }),
      e.jsx("rect", { x: 0, y: 156, width: 236, height: 8, fill: "#46515b" }),
      e.jsx("rect", { x: 0, y: 164, width: 236, height: 76, fill: "#242f38" }),
      e.jsx("rect", {
        x: 34,
        y: 146,
        width: 84,
        height: 10,
        rx: 2,
        fill: "#333e48",
      }),
      i.map((t) =>
        e.jsx(
          "rect",
          {
            x: 38 + (t % 12) * 6.6,
            y: 148 + Math.floor(t / 12) * 3.6,
            width: 5,
            height: 2.6,
            rx: 0.6,
            fill: t === 17 ? "#ee766f" : "#5c6873",
          },
          t,
        ),
      ),
      e.jsx("rect", {
        x: 190,
        y: 138,
        width: 44,
        height: 56,
        rx: 4,
        fill: "#333e48",
      }),
      e.jsx("rect", {
        x: 184,
        y: 110,
        width: 50,
        height: 62,
        rx: 12,
        fill: "#e3e9ee",
      }),
      e.jsx("path", { d: "M206 110 L209 140 L212 110z", fill: "#111b23" }),
      e.jsx("rect", {
        x: 218,
        y: 112,
        width: 14,
        height: 6,
        rx: 1.5,
        fill: "#111b23",
      }),
      e.jsx("path", {
        d: "M192 120 L154 148 L120 152",
        fill: "none",
        stroke: "#e3e9ee",
        strokeWidth: 11,
        strokeLinecap: "round",
        strokeLinejoin: "round",
      }),
      e.jsx("path", {
        d: "M170 126 l5 5 l5 -5 M170 132 l5 5 l5 -5 M170 138 l5 5 l5 -5",
        fill: "none",
        stroke: "#111b23",
        strokeWidth: 1.8,
        transform: "rotate(16 175 134)",
      }),
      e.jsx("circle", { cx: 114, cy: 151, r: 5.5, fill: "#d6a77a" }),
      e.jsx("circle", { cx: 209, cy: 94, r: 15, fill: "#d6a77a" }),
      e.jsx("path", {
        d: "M194 92 a15 15 0 0 1 30 -2 q-10 -2 -16 4 q-8 -4 -14 -2z",
        fill: "#333e48",
      }),
      e.jsx("circle", { cx: 200, cy: 96, r: 1.6, fill: "#111b23" }),
      e.jsx("rect", { x: 236, y: 128, width: 164, height: 8, fill: "#95a1ac" }),
      e.jsx("rect", {
        x: 240,
        y: 136,
        width: 160,
        height: 104,
        fill: "#46515b",
      }),
      [0, 1, 2].map((t) =>
        e.jsx(
          "rect",
          {
            x: 250 + t * 50,
            y: 146,
            width: 40,
            height: 84,
            rx: 2,
            fill: "#333e48",
          },
          t,
        ),
      ),
      e.jsx("rect", {
        x: 300,
        y: 84,
        width: 56,
        height: 52,
        rx: 14,
        fill: "#137a47",
      }),
      e.jsx("path", {
        d: "M314 86 q14 12 28 0",
        fill: "none",
        stroke: "#006034",
        strokeWidth: 3,
      }),
      e.jsx("circle", { cx: 328, cy: 64, r: 15, fill: "#8d5524" }),
      e.jsx("path", {
        d: "M313 62 a15 15 0 0 1 30 0 q-15 -7 -30 0z",
        fill: "#111b23",
      }),
      e.jsx("circle", { cx: 320, cy: 64, r: 1.6, fill: "#111b23" }),
      e.jsx("path", {
        d: "M354 104 L362 130 L336 132",
        fill: "none",
        stroke: "#137a47",
        strokeWidth: 10,
        strokeLinecap: "round",
        strokeLinejoin: "round",
      }),
      e.jsx("path", {
        d: "M306 98 L292 72 L278 50",
        fill: "none",
        stroke: "#137a47",
        strokeWidth: 10,
        strokeLinecap: "round",
        strokeLinejoin: "round",
      }),
      e.jsx("path", {
        d: "M252 38 L34 146 M252 38 L118 150",
        fill: "none",
        stroke: "#ee766f",
        strokeWidth: 1.4,
        strokeDasharray: "4 4",
        className: "attack-flow",
      }),
      e.jsx("path", {
        d: "M252 38 L34 146 L118 150z",
        fill: "#cb5651",
        opacity: 0.12,
      }),
      e.jsx("rect", {
        x: 244,
        y: 16,
        width: 34,
        height: 56,
        rx: 5,
        fill: "#0d171f",
        stroke: "#46515b",
      }),
      e.jsx("rect", {
        x: 247,
        y: 24,
        width: 28,
        height: 40,
        rx: 1.5,
        fill: "#242f38",
      }),
      e.jsx("circle", {
        cx: 252,
        cy: 30,
        r: 2.4,
        fill: "#cb5651",
        className: "attack-flash",
      }),
      e.jsx(u, {
        x: 256,
        y: 32.5,
        size: 6.5,
        fill: "#ffa79f",
        children: "REC",
      }),
      [0, 1, 2].map((t) =>
        [0, 1, 2].map((s) =>
          e.jsx(
            "rect",
            {
              x: 251 + s * 7,
              y: 40 + t * 7,
              width: 6,
              height: 5,
              rx: 1,
              fill: t === 1 && s === 2 ? "#ee766f" : "#5c6873",
            },
            `${t}-${s}`,
          ),
        ),
      ),
      e.jsx("circle", { cx: 274, cy: 50, r: 6, fill: "#8d5524" }),
    ],
  });
}
function er({ x: i, y: t }) {
  return e.jsxs("g", {
    children: [
      e.jsx("rect", {
        x: i - 13,
        y: t - 10,
        width: 26,
        height: 18,
        rx: 2,
        fill: "#242f38",
        stroke: "#46515b",
      }),
      e.jsx("rect", {
        x: i - 10,
        y: t - 7,
        width: 20,
        height: 12,
        fill: "#901e21",
      }),
      e.jsx("circle", { cx: i - 4, cy: t - 1, r: 1.8, fill: "#ee766f" }),
      e.jsx("circle", { cx: i + 4, cy: t - 1, r: 1.8, fill: "#ee766f" }),
      e.jsx("rect", {
        x: i - 2,
        y: t + 8,
        width: 4,
        height: 4,
        fill: "#46515b",
      }),
      e.jsx("rect", {
        x: i - 8,
        y: t + 12,
        width: 16,
        height: 2.5,
        rx: 1,
        fill: "#46515b",
      }),
    ],
  });
}
function tr() {
  const i = [24, 62, 100].flatMap((l) =>
      [26, 66, 106, 146, 186, 222].map((a) => [l, a]),
    ),
    t = [70, 90, 110, 130, 150, 170],
    s = [
      [128, 44],
      [150, 72],
      [138, 104],
      [164, 128],
      [126, 150],
      [156, 176],
      [134, 204],
      [176, 96],
      [178, 156],
    ];
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#0d171f" }),
      i.map(([l, a], c) =>
        e.jsx(
          "path",
          {
            d: `M${l + 14} ${a} C150 ${a} 160 ${t[c % 6]} 196 ${t[c % 6]}`,
            fill: "none",
            stroke: "#cb5651",
            strokeWidth: 1.2,
            strokeDasharray: "4 5",
            opacity: 0.7,
            className: "attack-flow",
          },
          `f${l}-${a}`,
        ),
      ),
      i.map(([l, a]) => e.jsx(er, { x: l, y: a }, `${l}-${a}`)),
      s.map(([l, a]) =>
        e.jsxs(
          "g",
          {
            children: [
              e.jsx("rect", {
                x: l - 10,
                y: a - 5,
                width: 20,
                height: 10,
                rx: 2,
                fill: "#ee766f",
              }),
              e.jsx("path", {
                d: `M${l + 10} ${a - 5} l6 5 l-6 5z`,
                fill: "#ee766f",
              }),
              e.jsx(u, {
                x: l,
                y: a + 2.8,
                size: 6.5,
                fill: "#2c1f0e",
                anchor: "middle",
                children: "GET",
              }),
            ],
          },
          `${l}-${a}`,
        ),
      ),
      e.jsxs(f, {
        x: 196,
        y: 10,
        w: 196,
        h: 184,
        bar: "#333e48",
        children: [
          e.jsx("rect", {
            x: 202,
            y: 30,
            width: 184,
            height: 13,
            rx: 6.5,
            fill: "#bac3cb",
          }),
          e.jsx(r, {
            x: 208,
            y: 39.5,
            size: 7,
            weight: 400,
            fill: "#333e48",
            children: "northgate.police.uk/appeal",
          }),
          e.jsx("rect", {
            x: 197,
            y: 48,
            width: 194,
            height: 20,
            fill: "#ac3a38",
          }),
          e.jsx(r, {
            x: 294,
            y: 62,
            size: 11,
            anchor: "middle",
            fill: "#e3e9ee",
            children: "WANTED: ESCAPED PRISONER",
          }),
          e.jsx("rect", {
            x: 206,
            y: 76,
            width: 60,
            height: 70,
            rx: 2,
            fill: "#bac3cb",
          }),
          e.jsx("circle", { cx: 236, cy: 102, r: 14, fill: "#5c6873" }),
          e.jsx("path", {
            d: "M212 146 v-10 a24 18 0 0 1 48 0 v10z",
            fill: "#5c6873",
          }),
          e.jsx(r, {
            x: 276,
            y: 90,
            size: 11,
            fill: "#111b23",
            children: "LEE MARSH",
          }),
          e.jsx(r, {
            x: 276,
            y: 104,
            size: 8,
            weight: 400,
            fill: "#333e48",
            children: "Do not approach.",
          }),
          e.jsx(r, {
            x: 276,
            y: 116,
            size: 8,
            weight: 400,
            fill: "#333e48",
            children: "Seen him? Tell us.",
          }),
          e.jsx("rect", {
            x: 276,
            y: 124,
            width: 74,
            height: 18,
            rx: 3,
            fill: "#95a1ac",
          }),
          e.jsx(r, {
            x: 313,
            y: 136,
            size: 8.5,
            anchor: "middle",
            fill: "#e3e9ee",
            children: "Send a tip",
          }),
          e.jsx("rect", {
            x: 197,
            y: 152,
            width: 194,
            height: 41,
            fill: "#111b23",
            opacity: 0.88,
          }),
          e.jsx("circle", {
            cx: 222,
            cy: 172,
            r: 9,
            fill: "none",
            stroke: "#46515b",
            strokeWidth: 3,
          }),
          e.jsx("path", {
            d: "M222 163 a9 9 0 0 1 9 9",
            fill: "none",
            stroke: "#ee766f",
            strokeWidth: 3,
            strokeLinecap: "round",
          }),
          e.jsx(r, {
            x: 240,
            y: 169,
            size: 9.5,
            fill: "#ffa79f",
            children: "504 Gateway Timeout",
          }),
          e.jsx(r, {
            x: 240,
            y: 182,
            size: 7.5,
            weight: 400,
            fill: "#bac3cb",
            children: "The server is not responding.",
          }),
        ],
      }),
      e.jsx("rect", {
        x: 196,
        y: 202,
        width: 196,
        height: 30,
        rx: 4,
        fill: "#480004",
        stroke: "#cb5651",
        strokeWidth: 2,
        className: "attack-flash-stroke",
      }),
      e.jsx(u, {
        x: 294,
        y: 222,
        size: 13,
        fill: "#ffa79f",
        anchor: "middle",
        children: "2.4M requests/s",
      }),
    ],
  });
}
function ir({ cx: i, top: t, w: s, h: l }) {
  const a = s / 2,
    c = 9;
  return e.jsxs("g", {
    children: [
      e.jsx("path", {
        d: `M${i - a} ${t} V${t + l} a${a} ${c} 0 0 0 ${s} 0 V${t}z`,
        fill: "#333e48",
        stroke: "#5c6873",
        strokeWidth: 1.5,
      }),
      [1, 2].map((h) =>
        e.jsx(
          "path",
          {
            d: `M${i - a} ${t + (l * h) / 3} a${a} ${c} 0 0 0 ${s} 0`,
            fill: "none",
            stroke: "#5c6873",
            strokeWidth: 1.5,
          },
          h,
        ),
      ),
      e.jsx("ellipse", {
        cx: i,
        cy: t,
        rx: a,
        ry: c,
        fill: "#46515b",
        stroke: "#5c6873",
        strokeWidth: 1.5,
      }),
    ],
  });
}
function sr({ x: i, y: t, tilt: s, text: l }) {
  return e.jsxs("g", {
    transform: `rotate(${s} ${i + 80} ${t + 8})`,
    children: [
      e.jsx("rect", {
        x: i,
        y: t,
        width: 160,
        height: 16,
        rx: 2,
        fill: "#e3e9ee",
        stroke: "#ee766f",
      }),
      e.jsx("rect", { x: i, y: t, width: 4, height: 16, fill: z }),
      e.jsx(u, {
        x: i + 9,
        y: t + 11,
        size: 7.5,
        fill: "#111b23",
        children: l,
      }),
    ],
  });
}
function rr() {
  const i = [
    [104, -4, "R. SHAH · INSULIN · 4 ELM RD"],
    [126, 3, "J. COLE · WARFARIN · 9 MILL LN"],
    [148, -2, "A. KHAN · METFORMIN · 2 ASH ST"],
    [170, 4, "P. REID · SERTRALINE · 7 OAK AV"],
    [192, -3, "M. HALE · MORPHINE · 1 KEW PL"],
  ];
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#0d171f" }),
      e.jsxs(f, {
        x: 10,
        y: 10,
        w: 196,
        h: 168,
        bar: "#333e48",
        children: [
          e.jsx("rect", { x: 11, y: 26, width: 194, height: 20, fill: z }),
          e.jsx(r, {
            x: 18,
            y: 40,
            size: 9.5,
            fill: "#e3e9ee",
            children: "St Elm Hospital",
          }),
          e.jsx(r, {
            x: 20,
            y: 62,
            size: 10,
            fill: "#111b23",
            children: "Repeat prescription",
          }),
          e.jsx(r, {
            x: 20,
            y: 78,
            size: 7.5,
            weight: 400,
            fill: "#46515b",
            children: "NHS number",
          }),
          e.jsx("rect", {
            x: 20,
            y: 82,
            width: 176,
            height: 20,
            rx: 3,
            fill: "#e3e9ee",
            stroke: "#cb5651",
            strokeWidth: 2,
            className: "attack-flash-stroke",
          }),
          e.jsx(u, {
            x: 26,
            y: 96,
            size: 11,
            fill: "#ac3a38",
            children: "' OR 1=1; --",
          }),
          e.jsx("rect", {
            x: 112,
            y: 86,
            width: 1.5,
            height: 12,
            fill: "#111b23",
            className: "attack-flash",
          }),
          e.jsx(r, {
            x: 20,
            y: 118,
            size: 7.5,
            weight: 400,
            fill: "#46515b",
            children: "Date of birth",
          }),
          e.jsx("rect", {
            x: 20,
            y: 122,
            width: 86,
            height: 18,
            rx: 3,
            fill: "#e3e9ee",
            stroke: "#95a1ac",
          }),
          e.jsx("rect", {
            x: 20,
            y: 148,
            width: 80,
            height: 20,
            rx: 3,
            fill: z,
          }),
          e.jsx(r, {
            x: 60,
            y: 161.5,
            size: 8.5,
            anchor: "middle",
            fill: "#e3e9ee",
            children: "Submit",
          }),
          e.jsx(Bt, { x: 86, y: 156 }),
        ],
      }),
      e.jsx("path", {
        d: "M196 92 C232 92 236 62 262 56",
        fill: "none",
        stroke: "#ee766f",
        strokeWidth: 1.8,
        strokeDasharray: "4 4",
        className: "attack-flow",
      }),
      e.jsx(ir, { cx: 310, top: 26, w: 96, h: 58 }),
      e.jsx(r, {
        x: 310,
        y: 60,
        size: 8.5,
        anchor: "middle",
        fill: "#bac3cb",
        children: "PATIENTS",
      }),
      e.jsx("path", {
        d: "M268 92 L240 104 M310 96 V104 M352 92 L380 104",
        stroke: "#ee766f",
        strokeWidth: 2,
      }),
      i.map(([t, s, l], a) =>
        e.jsx(sr, { x: 230 - (a % 2) * 6, y: t, tilt: s, text: l }, l),
      ),
      e.jsx("rect", {
        x: 10,
        y: 190,
        width: 196,
        height: 40,
        rx: 4,
        fill: "#480004",
        stroke: "#cb5651",
        strokeWidth: 2,
        className: "attack-flash-stroke",
      }),
      e.jsx(u, {
        x: 108,
        y: 208,
        size: 12,
        fill: "#ffa79f",
        anchor: "middle",
        children: "48,213 rows",
      }),
      e.jsx(r, {
        x: 108,
        y: 222,
        size: 8,
        anchor: "middle",
        weight: 400,
        fill: "#d1beaa",
        children: "medicines and home addresses",
      }),
    ],
  });
}
function lr() {
  const i = [
    [312, 54, "#d1beaa"],
    [326, 54, "#cfedff"],
    [340, 54, "#d1beaa"],
    [362, 54, "#d1beaa"],
    [376, 54, "#a8ffc6"],
    [312, 92, "#cfedff"],
    [330, 92, "#d1beaa"],
    [352, 92, "#d1beaa"],
    [370, 92, "#cfedff"],
  ];
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#0d171f" }),
      e.jsx("rect", { x: 0, y: 0, width: 400, height: 170, fill: "#111b23" }),
      e.jsx("rect", {
        x: 196,
        y: 70,
        width: 80,
        height: 60,
        rx: 2,
        fill: "#0d171f",
        stroke: "#333e48",
        strokeWidth: 3,
      }),
      e.jsx("path", {
        d: "M236 70 V130 M196 100 H276",
        stroke: "#333e48",
        strokeWidth: 3,
      }),
      e.jsx("circle", { cx: 258, cy: 84, r: 7, fill: "#bac3cb" }),
      e.jsx("circle", { cx: 262, cy: 81, r: 6, fill: "#0d171f" }),
      e.jsx("circle", { cx: 212, cy: 116, r: 1.2, fill: "#bac3cb" }),
      e.jsx("circle", {
        cx: 236,
        cy: 32,
        r: 22,
        fill: "#e3e9ee",
        stroke: "#46515b",
        strokeWidth: 3,
      }),
      Array.from({ length: 12 }, (t, s) => s).map((t) =>
        e.jsx(
          "rect",
          {
            x: 235,
            y: 13,
            width: 2,
            height: 4,
            fill: "#333e48",
            transform: `rotate(${t * 30} 236 32)`,
          },
          t,
        ),
      ),
      e.jsx("path", {
        d: "M236 32 L247 30",
        stroke: "#111b23",
        strokeWidth: 3,
        strokeLinecap: "round",
      }),
      e.jsx("path", {
        d: "M236 32 L227 17",
        stroke: "#111b23",
        strokeWidth: 2,
        strokeLinecap: "round",
      }),
      e.jsx("circle", { cx: 236, cy: 32, r: 2, fill: "#cb5651" }),
      e.jsx("rect", {
        x: 300,
        y: 18,
        width: 92,
        height: 134,
        rx: 3,
        fill: "#bac3cb",
        stroke: "#95a1ac",
      }),
      e.jsx("rect", { x: 300, y: 18, width: 92, height: 16, fill: "#ac3a38" }),
      e.jsx(r, {
        x: 346,
        y: 29.5,
        size: 8,
        anchor: "middle",
        fill: "#e3e9ee",
        children: "DRUG CABINET",
      }),
      e.jsx("rect", { x: 306, y: 38, width: 80, height: 108, fill: "#242f38" }),
      [70, 108].map((t) =>
        e.jsx(
          "rect",
          { x: 306, y: t, width: 80, height: 3, fill: "#5c6873" },
          t,
        ),
      ),
      i.map(([t, s, l]) =>
        e.jsxs(
          "g",
          {
            children: [
              e.jsx("rect", {
                x: t - 5,
                y: s,
                width: 10,
                height: 16,
                rx: 2,
                fill: l,
              }),
              e.jsx("rect", {
                x: t - 3,
                y: s - 4,
                width: 6,
                height: 4,
                fill: "#e3e9ee",
              }),
            ],
          },
          `${t}-${s}`,
        ),
      ),
      e.jsx("rect", {
        x: 312,
        y: 118,
        width: 30,
        height: 22,
        rx: 2,
        fill: "#333e48",
      }),
      e.jsx("path", { d: "M346 38 V146", stroke: "#95a1ac", strokeWidth: 1.5 }),
      e.jsx("rect", {
        x: 354,
        y: 116,
        width: 24,
        height: 26,
        rx: 2,
        fill: "#111b23",
        stroke: "#5c6873",
      }),
      [0, 1, 2].map((t) =>
        [0, 1, 2].map((s) =>
          e.jsx(
            "rect",
            {
              x: 358 + s * 6,
              y: 124 + t * 5,
              width: 4,
              height: 3,
              rx: 0.6,
              fill: "#5c6873",
            },
            `${t}-${s}`,
          ),
        ),
      ),
      e.jsx("circle", { cx: 366, cy: 120, r: 1.8, fill: "#5bb57e" }),
      e.jsx("path", {
        d: "M14 10 H178 a6 6 0 0 1 6 6 V78 a6 6 0 0 1 -6 6 H130 L156 112 L112 84 H14 a6 6 0 0 1 -6 -6 V16 a6 6 0 0 1 6 -6z",
        fill: "#e3e9ee",
      }),
      e.jsx(r, {
        x: 18,
        y: 26,
        size: 8,
        fill: "#ac3a38",
        children: "Dan from IT",
      }),
      e.jsx(r, {
        x: 18,
        y: 42,
        size: 9,
        weight: 400,
        fill: "#111b23",
        children: "The drug cabinet system",
      }),
      e.jsx(r, {
        x: 18,
        y: 55,
        size: 9,
        weight: 400,
        fill: "#111b23",
        children: "is about to crash. I just",
      }),
      e.jsx(r, {
        x: 18,
        y: 68,
        size: 9,
        fill: "#111b23",
        children: "need your password.",
      }),
      e.jsx("path", {
        d: "M134 240 V198 a38 38 0 0 1 76 0 V240z",
        fill: "#175675",
      }),
      e.jsx("path", {
        d: "M134 198 a38 38 0 0 1 76 0",
        fill: "none",
        stroke: "#bac3cb",
        strokeWidth: 2,
      }),
      e.jsx("path", { d: "M160 162 L172 178 L184 162", fill: "#e3e9ee" }),
      e.jsx("rect", {
        x: 186,
        y: 176,
        width: 14,
        height: 8,
        rx: 1.5,
        fill: "#e3e9ee",
      }),
      e.jsx("rect", { x: 186, y: 176, width: 14, height: 3, fill: z }),
      e.jsx("circle", { cx: 172, cy: 140, r: 18, fill: "#c68642" }),
      e.jsx("path", {
        d: "M154 138 a18 18 0 0 1 36 0 q-18 -10 -36 0z",
        fill: "#111b23",
      }),
      e.jsx("circle", { cx: 190, cy: 128, r: 7, fill: "#111b23" }),
      e.jsx("circle", { cx: 178, cy: 144, r: 1.8, fill: "#111b23" }),
      e.jsx("path", {
        d: "M174 152 q4 2 8 0",
        fill: "none",
        stroke: "#901e21",
        strokeWidth: 1.2,
      }),
      e.jsx("path", {
        d: "M142 196 L140 166 L152 146",
        fill: "none",
        stroke: "#175675",
        strokeWidth: 11,
        strokeLinecap: "round",
        strokeLinejoin: "round",
      }),
      e.jsx("g", {
        transform: "rotate(-20 156 136)",
        children: e.jsx("rect", {
          x: 150,
          y: 118,
          width: 11,
          height: 38,
          rx: 4,
          fill: "#bac3cb",
          stroke: "#5c6873",
        }),
      }),
      e.jsx("circle", { cx: 154, cy: 146, r: 5.5, fill: "#c68642" }),
      e.jsx("rect", { x: 0, y: 196, width: 400, height: 10, fill: "#46515b" }),
      e.jsx("rect", { x: 0, y: 206, width: 400, height: 34, fill: "#242f38" }),
      e.jsx("rect", { x: 300, y: 212, width: 84, height: 20, rx: 2, fill: z }),
      e.jsx(r, {
        x: 342,
        y: 226,
        size: 10,
        anchor: "middle",
        fill: "#e3e9ee",
        children: "WARD 7",
      }),
      e.jsx("path", { d: "M40 196 L48 178 H104 L112 196z", fill: "#333e48" }),
      e.jsx("rect", {
        x: 54,
        y: 168,
        width: 44,
        height: 14,
        rx: 2,
        fill: "#111b23",
        stroke: "#46515b",
      }),
      e.jsx(u, {
        x: 76,
        y: 178,
        size: 7,
        fill: "#e8ba61",
        anchor: "middle",
        children: "WITHHELD",
      }),
      e.jsx("path", {
        d: "M108 188 q20 10 30 -6 q8 -14 14 -26",
        fill: "none",
        stroke: "#95a1ac",
        strokeWidth: 1.5,
      }),
    ],
  });
}
const ar = {
    police_ransomware: {
      Art: Rs,
      bg: "#0d171f",
      alt: "A 999 call handler’s dispatch screen is locked red with a padlock and a ransom countdown, the patrol car map is frozen and offline, and an unanswered phone rings while 47 emergency calls wait in the queue.",
    },
    police_interception: {
      Art: Fs,
      bg: "#0d171f",
      alt: "An officer’s bodycam and police car send signals to a phone mast, but a van parked nearby captures the packets and its laptop shows a suspect’s name, an address and a radio message.",
    },
    police_evidence_theft: {
      Art: Qs,
      bg: "#0d171f",
      alt: "A stranger in a delivery uniform walks out of the police station’s open evidence store towards the back door, carrying a laptop tagged informants and leaving an empty slot on the shelf.",
    },
    hospital_worm: {
      Art: Zs,
      bg: "#0d171f",
      alt: "Red worms crawl along the St Elm University Hospital network, locking the MRI scanner and theatre and ward computers one by one, while an ambulance drives past an A&E sign that says diverted.",
    },
    hospital_phishing: {
      Art: Ys,
      bg: "#242f38",
      alt: "A doctor in scrubs clicks Verify now on an urgent email saying their patient records login expires today, which opens a fake St Elm Hospital login page on a slightly wrong web address.",
    },
    hospital_brute_force: {
      Art: Js,
      bg: "#0d171f",
      alt: "Bots fire thousands of password guesses such as password1, nhs2024 and doctor! at the St Elm Hospital consultant remote access portal, and the failed attempt counter keeps climbing.",
    },
    police_shouldering: {
      Art: Xs,
      bg: "#0d171f",
      alt: "At the custody desk a man leans over the counter and films on his phone as a sergeant types a password into the intelligence database, his camera aimed past the sergeant’s shoulder at the keyboard.",
    },
    police_ddos: {
      Art: tr,
      bg: "#0d171f",
      alt: "A botnet of hijacked computers fires a flood of requests at Northgate Police’s wanted appeal for an escaped prisoner, and the page times out at 2.4 million requests a second so nobody can send a tip.",
    },
    hospital_sql_injection: {
      Art: rr,
      bg: "#0d171f",
      alt: "An attacker types a scrap of SQL code into the NHS number box on St Elm Hospital’s repeat prescription form, and the patient database spills out record after record of names, medicines and home addresses.",
    },
    hospital_blagging: {
      Art: lr,
      bg: "#0d171f",
      alt: "Just before 3am a night-shift nurse at the ward desk answers a withheld call from Dan from IT, who says the drug cabinet system is about to crash and he just needs her password.",
    },
  },
  P = "#326e8e",
  T = "#00425f";
function j({
  x: i,
  y: t,
  size: s = 8,
  fill: l = "#111b23",
  anchor: a = "start",
  className: c,
  children: h,
}) {
  return e.jsx("text", {
    x: i,
    y: t,
    fontSize: s,
    fill: l,
    fontWeight: 700,
    textAnchor: a,
    fontFamily: "'Courier New', Courier, monospace",
    className: c,
    children: h,
  });
}
function cr({ cx: i, cy: t, s = 1 }) {
  return e.jsxs("g", {
    transform: `translate(${i} ${t}) scale(${s})`,
    children: [
      e.jsx("path", {
        d: "M-12 -4v-8a12 12 0 0 1 24 0v8",
        fill: "none",
        stroke: "#d1beaa",
        strokeWidth: 5,
      }),
      e.jsx("rect", {
        x: -18,
        y: -6,
        width: 36,
        height: 28,
        rx: 5,
        fill: "#d1beaa",
      }),
      e.jsx("circle", { cx: 0, cy: 6, r: 4, fill: "#901e21" }),
      e.jsx("rect", { x: -1.5, y: 6, width: 3, height: 8, fill: "#901e21" }),
    ],
  });
}
function et({ x: i, y: t }) {
  return e.jsx("path", {
    d: `M${i} ${t} l0 18 l5 -5 l4 9 l4 -2 l-4 -9 l7 0z`,
    fill: "#e3e9ee",
    stroke: "#111b23",
    strokeWidth: 1.2,
    strokeLinejoin: "round",
  });
}
function We({ y: i, top: t = "#333e48", front: s = "#111b23" }) {
  return e.jsxs("g", {
    children: [
      e.jsx("rect", { x: 0, y: i, width: 400, height: 10, fill: t }),
      e.jsx("rect", {
        x: 0,
        y: i + 10,
        width: 400,
        height: 240 - i - 10,
        fill: s,
      }),
    ],
  });
}
function Rt({ cx: i, y: t }) {
  return e.jsxs("g", {
    children: [
      e.jsx("rect", {
        x: i - 10,
        y: t,
        width: 20,
        height: 24,
        fill: "#333e48",
      }),
      e.jsx("rect", {
        x: i - 32,
        y: t + 22,
        width: 64,
        height: 8,
        rx: 2,
        fill: "#333e48",
      }),
    ],
  });
}
function tt({ cx: i, cy: t, r: s = 7 }) {
  const l = Array.from({ length: 16 }, (a, c) => {
    const h = (Math.PI / 8) * c - Math.PI / 2,
      o = c % 2 ? s * 0.55 : s;
    return `${(i + o * Math.cos(h)).toFixed(1)},${(t + o * Math.sin(h)).toFixed(1)}`;
  });
  return e.jsx("polygon", { points: l.join(" "), fill: "#bac3cb" });
}
function hr({ cx: i, cy: t }) {
  return e.jsxs("g", {
    children: [
      e.jsx("path", {
        d: `M${i} ${t - 18} V${t - 28}`,
        stroke: "#5c6873",
        strokeWidth: 2,
      }),
      e.jsx("circle", {
        cx: i,
        cy: t - 30,
        r: 3.5,
        fill: "#cb5651",
        className: "attack-flash",
      }),
      e.jsx("rect", {
        x: i - 26,
        y: t - 6,
        width: 5,
        height: 12,
        rx: 1.5,
        fill: "#46515b",
      }),
      e.jsx("rect", {
        x: i + 21,
        y: t - 6,
        width: 5,
        height: 12,
        rx: 1.5,
        fill: "#46515b",
      }),
      e.jsx("rect", {
        x: i - 22,
        y: t - 18,
        width: 44,
        height: 34,
        rx: 8,
        fill: "#333e48",
        stroke: "#5c6873",
        strokeWidth: 1.5,
      }),
      e.jsx("rect", {
        x: i - 17,
        y: t - 12,
        width: 34,
        height: 13,
        rx: 4,
        fill: "#111b23",
      }),
      e.jsx("circle", { cx: i - 8, cy: t - 5.5, r: 3.5, fill: "#cb5651" }),
      e.jsx("circle", { cx: i + 8, cy: t - 5.5, r: 3.5, fill: "#cb5651" }),
      e.jsx("path", {
        d: `M${i - 9} ${t + 8} h18`,
        stroke: "#95a1ac",
        strokeWidth: 2,
        strokeLinecap: "round",
      }),
    ],
  });
}
function Ft({ x: i, y: t }) {
  return e.jsx("path", {
    d: `M${i} ${t} V${t - 22} M${i - 7} ${t - 15} l7 -7 l7 7`,
    fill: "none",
    stroke: "#ee766f",
    strokeWidth: 2.5,
    strokeLinecap: "round",
    strokeLinejoin: "round",
  });
}
function or() {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#0d171f" }),
      e.jsx("rect", {
        x: 0,
        y: 150,
        width: 400,
        height: 6,
        fill: T,
        opacity: 0.7,
      }),
      e.jsxs(f, {
        x: 250,
        y: 10,
        w: 142,
        h: 134,
        bar: "#5c6873",
        children: [
          e.jsx("rect", {
            x: 256,
            y: 31,
            width: 130,
            height: 14,
            rx: 7,
            fill: "#bac3cb",
            stroke: "#ee766f",
          }),
          e.jsx(r, {
            x: 321,
            y: 41,
            size: 7,
            weight: 400,
            anchor: "middle",
            fill: "#ac3a38",
            children: "northgate-police.pay-claims.co",
          }),
          e.jsx("rect", { x: 251, y: 49, width: 140, height: 22, fill: T }),
          e.jsx(tt, { cx: 264, cy: 60 }),
          e.jsx(r, {
            x: 330,
            y: 63.5,
            size: 9.5,
            anchor: "middle",
            fill: "#e3e9ee",
            children: "Northgate Police",
          }),
          e.jsx(r, {
            x: 321,
            y: 85,
            size: 8,
            anchor: "middle",
            weight: 400,
            fill: "#333e48",
            children: "Staff sign in",
          }),
          e.jsx("rect", {
            x: 262,
            y: 90,
            width: 118,
            height: 13,
            rx: 3,
            fill: "#e3e9ee",
            stroke: "#95a1ac",
          }),
          e.jsx(r, {
            x: 267,
            y: 99.5,
            size: 7.5,
            weight: 400,
            fill: "#333e48",
            children: "pc4471.shaw",
          }),
          e.jsx("rect", {
            x: 262,
            y: 107,
            width: 118,
            height: 13,
            rx: 3,
            fill: "#e3e9ee",
            stroke: "#95a1ac",
          }),
          e.jsx(r, {
            x: 267,
            y: 117,
            size: 8,
            fill: "#333e48",
            children: "• • • • • • • •",
          }),
          e.jsx("rect", {
            x: 291,
            y: 125,
            width: 60,
            height: 14,
            rx: 3,
            fill: T,
          }),
          e.jsx(r, {
            x: 321,
            y: 135,
            size: 8,
            anchor: "middle",
            fill: "#e3e9ee",
            children: "Sign in",
          }),
        ],
      }),
      e.jsx("rect", {
        x: 8,
        y: 8,
        width: 232,
        height: 158,
        rx: 6,
        fill: "#0d171f",
      }),
      e.jsxs(f, {
        x: 14,
        y: 14,
        w: 220,
        h: 146,
        bar: T,
        children: [
          e.jsx(r, {
            x: 22,
            y: 42,
            size: 8,
            weight: 400,
            fill: "#46515b",
            children: "From: Northgate Payroll",
          }),
          e.jsx(r, {
            x: 22,
            y: 53,
            size: 7,
            weight: 400,
            fill: "#ac3a38",
            children: "payroll@northgate-police.pay-claims.co",
          }),
          e.jsx("rect", {
            x: 22,
            y: 60,
            width: 204,
            height: 19,
            rx: 2,
            fill: "#bac3cb",
          }),
          e.jsx("rect", {
            x: 22,
            y: 60,
            width: 4,
            height: 19,
            fill: "#cb5651",
          }),
          e.jsx(r, {
            x: 32,
            y: 73.5,
            size: 10,
            fill: "#ac3a38",
            children: "Overtime claim REJECTED",
          }),
          e.jsx(r, {
            x: 22,
            y: 95,
            size: 9,
            fill: "#111b23",
            children: "Resubmit before midnight",
          }),
          e.jsx(r, {
            x: 22,
            y: 107,
            size: 8,
            weight: 400,
            fill: "#333e48",
            children: "or it will not be paid.",
          }),
          e.jsx("rect", {
            x: 22,
            y: 118,
            width: 100,
            height: 22,
            rx: 4,
            fill: "#cb5651",
          }),
          e.jsx(r, {
            x: 72,
            y: 132.5,
            size: 9,
            anchor: "middle",
            fill: "#e3e9ee",
            children: "Resubmit claim",
          }),
          e.jsx(et, { x: 114, y: 132 }),
          e.jsx("circle", {
            cx: 202,
            cy: 102,
            r: 14,
            fill: "#e3e9ee",
            stroke: "#cb5651",
            strokeWidth: 2.5,
          }),
          e.jsx("path", {
            d: "M202 102 V92 M202 102 L209 106",
            stroke: "#111b23",
            strokeWidth: 2,
            strokeLinecap: "round",
          }),
          e.jsx(j, {
            x: 202,
            y: 128,
            size: 8,
            fill: "#cb5651",
            anchor: "middle",
            className: "attack-flash",
            children: "23:59",
          }),
        ],
      }),
      e.jsx("path", {
        d: "M126 134 C170 168 226 156 250 112",
        fill: "none",
        stroke: "#ee766f",
        strokeWidth: 1.8,
        strokeDasharray: "4 4",
        className: "attack-flow",
      }),
      e.jsx(Rt, { cx: 124, y: 166 }),
      e.jsxs("g", {
        transform: "translate(0 5)",
        children: [
          e.jsx("path", {
            d: "M284 240 V208 a36 36 0 0 1 72 0 V240z",
            fill: "#111b23",
          }),
          e.jsx("path", {
            d: "M288 206 a32 32 0 0 1 64 0 V240 H288z",
            fill: "#e8ba61",
          }),
          e.jsx("path", {
            d: "M288 222 H352",
            stroke: "#bac3cb",
            strokeWidth: 4,
          }),
          e.jsx("path", { d: "M309 176 L320 196 L331 176", fill: "#bac3cb" }),
          e.jsx("path", {
            d: "M320 182 V200",
            stroke: "#111b23",
            strokeWidth: 3,
          }),
          e.jsx("rect", {
            x: 334,
            y: 196,
            width: 13,
            height: 16,
            rx: 2,
            fill: "#0d171f",
          }),
          e.jsx("circle", { cx: 340.5, cy: 204, r: 3, fill: "#00425f" }),
          e.jsx("circle", { cx: 320, cy: 160, r: 17, fill: "#c68642" }),
          e.jsx("path", {
            d: "M309 166 q4 -3 8 0 M323 166 q4 -3 8 0",
            fill: "none",
            stroke: "#111b23",
            strokeWidth: 1.6,
          }),
          e.jsx("path", { d: "M300 152 q20 -22 40 0z", fill: "#111b23" }),
          [0, 1, 2, 3, 4, 5, 6, 7, 8, 9].map((i) =>
            e.jsx(
              "rect",
              {
                x: 300 + i * 4,
                y: 149,
                width: 4,
                height: 4,
                fill: i % 2 ? "#bac3cb" : "#111b23",
              },
              i,
            ),
          ),
          e.jsx("path", { d: "M298 153 H342 l-4 4 H298z", fill: "#0d171f" }),
        ],
      }),
      e.jsx(We, { y: 196 }),
      e.jsx("rect", {
        x: 196,
        y: 188,
        width: 12,
        height: 8,
        rx: 4,
        fill: "#bac3cb",
      }),
      e.jsx("path", {
        d: "M292 186 L250 192 L214 191",
        fill: "none",
        stroke: "#111b23",
        strokeWidth: 10,
        strokeLinecap: "round",
        strokeLinejoin: "round",
      }),
      e.jsx("circle", { cx: 210, cy: 190, r: 5.5, fill: "#c68642" }),
      e.jsx("rect", {
        x: 30,
        y: 186,
        width: 16,
        height: 10,
        rx: 2,
        fill: "#901e21",
      }),
      e.jsx("path", {
        d: "M46 189 q6 0 6 4 q0 3 -6 3",
        fill: "none",
        stroke: "#901e21",
        strokeWidth: 2,
      }),
    ],
  });
}
function ye({ x: i, y: t, name: s }) {
  return e.jsxs("g", {
    children: [
      e.jsx("rect", {
        x: i,
        y: t,
        width: 66,
        height: 34,
        rx: 3,
        fill: "#bac3cb",
      }),
      e.jsx("circle", { cx: i + 14, cy: t + 19, r: 8, fill: "#a16207" }),
      e.jsx("path", { d: `M${i + 6} ${t + 14} q8 -10 16 0z`, fill: "#111b23" }),
      e.jsx("rect", {
        x: i + 6,
        y: t + 13,
        width: 16,
        height: 3,
        fill: "#bac3cb",
      }),
      e.jsx(r, {
        x: i + 26,
        y: t + 16,
        size: 7.5,
        fill: "#111b23",
        children: s,
      }),
      e.jsx("rect", {
        x: i + 26,
        y: t + 21,
        width: 34,
        height: 3,
        rx: 1.5,
        fill: "#95a1ac",
      }),
      e.jsx("rect", {
        x: i + 26,
        y: t + 27,
        width: 24,
        height: 3,
        rx: 1.5,
        fill: "#bac3cb",
      }),
    ],
  });
}
function Be({ cx: i, cy: t, text: s }) {
  const l = s.length * 5.2 + 12;
  return e.jsxs("g", {
    children: [
      e.jsx("rect", {
        x: i - l / 2,
        y: t - 8,
        width: l,
        height: 15,
        rx: 3,
        fill: "#901e21",
      }),
      e.jsx(j, {
        x: i,
        y: t + 2.5,
        size: 8.5,
        fill: "#d1beaa",
        anchor: "middle",
        children: s,
      }),
    ],
  });
}
function nr() {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#0d171f" }),
      e.jsxs(f, {
        x: 10,
        y: 10,
        w: 156,
        h: 124,
        bar: T,
        children: [
          e.jsx(r, {
            x: 18,
            y: 41,
            size: 9,
            fill: "#111b23",
            children: "Meet your local team",
          }),
          e.jsx(ye, { x: 16, y: 50, name: "A. Khan" }),
          e.jsx(ye, { x: 88, y: 50, name: "R. Patel" }),
          e.jsx(ye, { x: 16, y: 92, name: "J. Smith" }),
          e.jsx(ye, { x: 88, y: 92, name: "L. Owen" }),
        ],
      }),
      e.jsx("path", {
        d: "M60 134 V166",
        fill: "none",
        stroke: "#6ca8ca",
        strokeWidth: 2,
        strokeDasharray: "4 4",
        className: "attack-flow",
      }),
      e.jsx(j, {
        x: 70,
        y: 154,
        size: 8,
        fill: "#8ecbee",
        children: "200 names copied",
      }),
      e.jsx(hr, { cx: 60, cy: 200 }),
      e.jsx("path", {
        d: "M90 196 C170 196 190 100 236 92",
        fill: "none",
        stroke: "#cb5651",
        strokeWidth: 1.8,
        strokeDasharray: "5 5",
        className: "attack-flow",
      }),
      e.jsx(Be, { cx: 132, cy: 194, text: "Bobby123" }),
      e.jsx(Be, { cx: 194, cy: 154, text: "Northgate1" }),
      e.jsx(Be, { cx: 200, cy: 112, text: "Police2026" }),
      e.jsxs(f, {
        x: 236,
        y: 10,
        w: 156,
        h: 134,
        bar: T,
        children: [
          e.jsx("rect", { x: 237, y: 26, width: 154, height: 22, fill: T }),
          e.jsx(tt, { cx: 250, cy: 37 }),
          e.jsx(r, {
            x: 318,
            y: 40.5,
            size: 9.5,
            anchor: "middle",
            fill: "#e3e9ee",
            children: "Northgate Mail",
          }),
          e.jsx("rect", {
            x: 246,
            y: 56,
            width: 136,
            height: 14,
            rx: 3,
            fill: "#e3e9ee",
            stroke: "#95a1ac",
          }),
          e.jsx(r, {
            x: 251,
            y: 66,
            size: 7.5,
            weight: 400,
            fill: "#333e48",
            children: "a.khan@northgate.police.uk",
          }),
          e.jsx("rect", {
            x: 246,
            y: 75,
            width: 136,
            height: 16,
            rx: 3,
            fill: "#e3e9ee",
            stroke: "#cb5651",
            strokeWidth: 1.5,
          }),
          e.jsx(j, {
            x: 251,
            y: 86.5,
            size: 9,
            fill: "#ac3a38",
            children: "Police2026",
          }),
          e.jsx("rect", {
            x: 286,
            y: 97,
            width: 64,
            height: 15,
            rx: 3,
            fill: T,
          }),
          e.jsx(r, {
            x: 318,
            y: 107.5,
            size: 8,
            anchor: "middle",
            fill: "#e3e9ee",
            children: "Sign in",
          }),
          e.jsx(r, {
            x: 314,
            y: 128,
            size: 8,
            anchor: "middle",
            fill: "#ac3a38",
            children: "Wrong password",
          }),
        ],
      }),
      e.jsx("rect", {
        x: 236,
        y: 156,
        width: 156,
        height: 74,
        rx: 5,
        fill: "#111b23",
        stroke: "#cb5651",
        strokeWidth: 2,
        className: "attack-flash-stroke",
      }),
      e.jsx(r, {
        x: 250,
        y: 176,
        size: 9,
        fill: "#ffa79f",
        children: "FAILED LOGINS",
      }),
      e.jsx(j, {
        x: 250,
        y: 212,
        size: 24,
        fill: "#ee766f",
        children: "18,442",
      }),
      e.jsx(Ft, { x: 374, y: 214 }),
    ],
  });
}
function dr({ x: i, y: t, lines: s }) {
  return e.jsxs("g", {
    children: [
      e.jsx("rect", {
        x: i,
        y: t,
        width: 146,
        height: 26,
        rx: 2,
        fill: "#e3e9ee",
        stroke: "#ee766f",
      }),
      e.jsx("rect", { x: i, y: t, width: 4, height: 26, fill: T }),
      e.jsx(j, {
        x: i + 9,
        y: t + 11,
        size: 7.5,
        fill: "#111b23",
        children: s[0],
      }),
      e.jsx(j, {
        x: i + 9,
        y: t + 21,
        size: 7.5,
        fill: "#ac3a38",
        children: s[1],
      }),
    ],
  });
}
function xr() {
  const i = [
    [238, 106, ["VICTIM: S. AHMED", "22 ELM RD · 07700 900412"]],
    [246, 138, ["WITNESS: T. REID", "5 MILL LN · 07700 900733"]],
    [238, 170, ["VICTIM: K. BRAY", "81 HIGH ST · 07700 900218"]],
  ];
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#0d171f" }),
      e.jsxs(f, {
        x: 10,
        y: 10,
        w: 214,
        h: 150,
        bar: "#333e48",
        children: [
          e.jsx("rect", { x: 11, y: 26, width: 212, height: 20, fill: T }),
          e.jsx(tt, { cx: 24, cy: 36, r: 6 }),
          e.jsx(r, {
            x: 36,
            y: 39.5,
            size: 9,
            fill: "#e3e9ee",
            children: "Northgate Police",
          }),
          e.jsx(r, {
            x: 18,
            y: 64,
            size: 11,
            fill: "#111b23",
            children: "Track my crime report",
          }),
          e.jsx(r, {
            x: 18,
            y: 80,
            size: 7.5,
            weight: 400,
            fill: "#46515b",
            children: "Report reference",
          }),
          e.jsx("rect", {
            x: 18,
            y: 85,
            width: 198,
            height: 22,
            rx: 3,
            fill: "#e3e9ee",
            stroke: "#cb5651",
            strokeWidth: 2,
            className: "attack-flash-stroke",
          }),
          e.jsx(j, {
            x: 26,
            y: 100,
            size: 11,
            fill: "#ac3a38",
            children: "' OR 1=1; --",
          }),
          e.jsx(r, {
            x: 18,
            y: 120,
            size: 7,
            weight: 400,
            fill: "#5c6873",
            children: "e.g. NG12345678",
          }),
          e.jsx("rect", {
            x: 18,
            y: 128,
            width: 72,
            height: 22,
            rx: 4,
            fill: T,
          }),
          e.jsx(r, {
            x: 54,
            y: 142.5,
            size: 9,
            anchor: "middle",
            fill: "#e3e9ee",
            children: "Track",
          }),
          e.jsx(et, { x: 74, y: 137 }),
        ],
      }),
      e.jsx("path", {
        d: "M92 140 C150 168 206 70 262 62",
        fill: "none",
        stroke: "#ee766f",
        strokeWidth: 1.8,
        strokeDasharray: "4 4",
        className: "attack-flow",
      }),
      e.jsx("circle", {
        cx: 318,
        cy: 56,
        r: 58,
        fill: "#cb5651",
        opacity: 0.12,
        className: "attack-flash",
      }),
      e.jsx("path", {
        d: "M268 22 V84 a50 13 0 0 0 100 0 V22z",
        fill: "#333e48",
      }),
      e.jsx("path", {
        d: "M268 43 a50 13 0 0 0 100 0 M268 64 a50 13 0 0 0 100 0",
        fill: "none",
        stroke: "#46515b",
        strokeWidth: 2,
      }),
      e.jsx("ellipse", {
        cx: 318,
        cy: 22,
        rx: 50,
        ry: 13,
        fill: "#46515b",
        stroke: "#5c6873",
        strokeWidth: 1.5,
      }),
      e.jsx(r, {
        x: 318,
        y: 59,
        size: 8.5,
        anchor: "middle",
        fill: "#bac3cb",
        children: "CRIME REPORTS",
      }),
      e.jsx("path", {
        d: "M318 98 V106",
        stroke: "#ee766f",
        strokeWidth: 2,
        strokeDasharray: "3 3",
        className: "attack-flow",
      }),
      i.map(([t, s, l]) => e.jsx(dr, { x: t, y: s, lines: l }, s)),
      e.jsx(j, {
        x: 318,
        y: 222,
        size: 13,
        fill: "#ffa79f",
        anchor: "middle",
        children: "300,000 leaked",
      }),
      e.jsx("path", {
        d: "M40 240 V214 a34 34 0 0 1 68 0 V240z",
        fill: "#242f38",
      }),
      e.jsx("path", {
        d: "M50 196 a24 26 0 0 1 48 0 V214 H50z",
        fill: "#242f38",
      }),
      e.jsx("ellipse", { cx: 74, cy: 200, rx: 14, ry: 16, fill: "#0d171f" }),
      e.jsx("circle", { cx: 68, cy: 202, r: 1.6, fill: "#95a1ac" }),
      e.jsx("circle", { cx: 80, cy: 202, r: 1.6, fill: "#95a1ac" }),
      e.jsx("path", { d: "M118 236 L132 196 H204 L190 236z", fill: "#46515b" }),
      e.jsx("path", {
        d: "M121 230 L133 200 H199 L187 230z",
        fill: "#6ca8ca",
        opacity: 0.25,
      }),
      e.jsx("rect", { x: 110, y: 234, width: 96, height: 6, fill: "#5c6873" }),
    ],
  });
}
function fr() {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#0d171f" }),
      e.jsx("rect", { x: 0, y: 0, width: 232, height: 240, fill: "#111b23" }),
      e.jsx("rect", { x: 0, y: 0, width: 232, height: 16, fill: T }),
      e.jsx(r, {
        x: 10,
        y: 11.5,
        size: 8,
        fill: "#e3e9ee",
        children: "CONTROL ROOM",
      }),
      e.jsx("rect", {
        x: 10,
        y: 24,
        width: 160,
        height: 124,
        rx: 5,
        fill: "#0d171f",
      }),
      e.jsx("rect", {
        x: 15,
        y: 29,
        width: 150,
        height: 114,
        rx: 2,
        fill: "#111b23",
      }),
      e.jsx(j, {
        x: 22,
        y: 44,
        size: 8,
        fill: "#8ecbee",
        children: "PERSON RECORD",
      }),
      e.jsx("path", { d: "M22 50 H158", stroke: "#00425f" }),
      e.jsx(j, {
        x: 22,
        y: 64,
        size: 8,
        fill: "#bac3cb",
        children: "NAME: K. MORGAN",
      }),
      e.jsx(j, {
        x: 22,
        y: 78,
        size: 8,
        fill: "#bac3cb",
        children: "CHILD: ELLA, 7",
      }),
      e.jsx(j, { x: 22, y: 92, size: 8, fill: "#bac3cb", children: "ADDR:" }),
      e.jsx("rect", { x: 52, y: 84, width: 104, height: 10, fill: "#5c6873" }),
      e.jsx("rect", {
        x: 22,
        y: 104,
        width: 136,
        height: 30,
        rx: 3,
        fill: "#ac3a38",
        className: "attack-flash",
      }),
      e.jsx(r, {
        x: 90,
        y: 117,
        size: 8.5,
        anchor: "middle",
        fill: "#e3e9ee",
        children: "PROTECTED ADDRESS",
      }),
      e.jsx(r, {
        x: 90,
        y: 129,
        size: 7,
        anchor: "middle",
        fill: "#d1beaa",
        children: "Do not disclose",
      }),
      e.jsx(Rt, { cx: 90, y: 148 }),
      e.jsx("path", {
        d: "M150 240 V212 a36 36 0 0 1 72 0 V240z",
        fill: "#e3e9ee",
      }),
      e.jsx("path", {
        d: "M150 214 h14 M208 214 h14",
        stroke: "#111b23",
        strokeWidth: 4,
      }),
      e.jsx("path", { d: "M176 182 L186 198 L196 182", fill: "#bac3cb" }),
      e.jsx("path", { d: "M186 188 V220", stroke: "#111b23", strokeWidth: 4 }),
      e.jsx("circle", { cx: 186, cy: 164, r: 18, fill: "#e0ac69" }),
      e.jsx("path", {
        d: "M168 162 a18 18 0 0 1 36 -2 q-18 -10 -36 2z",
        fill: "#901e21",
      }),
      e.jsx("circle", { cx: 180, cy: 168, r: 1.8, fill: "#111b23" }),
      e.jsx("circle", { cx: 192, cy: 168, r: 1.8, fill: "#111b23" }),
      e.jsx("path", {
        d: "M181 177 q5 3 10 0",
        fill: "none",
        stroke: "#901e21",
        strokeWidth: 1.5,
      }),
      e.jsx("path", {
        d: "M166 162 a20 20 0 0 1 40 0",
        fill: "none",
        stroke: "#333e48",
        strokeWidth: 3.5,
      }),
      e.jsx("rect", {
        x: 202,
        y: 156,
        width: 8,
        height: 14,
        rx: 3,
        fill: "#333e48",
      }),
      e.jsx("path", {
        d: "M206 170 q0 12 -12 13",
        fill: "none",
        stroke: "#333e48",
        strokeWidth: 2,
      }),
      e.jsx("circle", { cx: 193, cy: 183, r: 2.5, fill: "#333e48" }),
      e.jsx(We, { y: 212, top: "#333e48", front: "#111b23" }),
      e.jsx("path", {
        d: "M212 160 l12 -10 l8 12 l10 -12 l8 12 l10 -12 l10 10",
        fill: "none",
        stroke: "#ee766f",
        strokeWidth: 2,
        strokeDasharray: "4 3",
        strokeLinejoin: "round",
        className: "attack-flow",
      }),
      e.jsx("rect", { x: 232, y: 0, width: 168, height: 240, fill: "#0d171f" }),
      e.jsx("path", { d: "M232 0 V240", stroke: "#333e48", strokeWidth: 2 }),
      e.jsx("rect", {
        x: 242,
        y: 10,
        width: 150,
        height: 60,
        rx: 8,
        fill: "#e3e9ee",
      }),
      e.jsx("path", { d: "M322 70 L330 84 L338 70z", fill: "#e3e9ee" }),
      e.jsx(r, {
        x: 250,
        y: 26,
        size: 8,
        fill: "#00425f",
        children: "DS Hughes, Westshire",
      }),
      e.jsx(r, {
        x: 250,
        y: 41,
        size: 8.5,
        weight: 400,
        fill: "#111b23",
        children: "A child is missing.",
      }),
      e.jsx(r, {
        x: 250,
        y: 58,
        size: 9,
        fill: "#ac3a38",
        children: "I need the address NOW",
      }),
      e.jsx("path", {
        d: "M240 98 Q240 88 252 88 H372 Q392 88 392 104 V240 H240z",
        fill: "#242f38",
      }),
      e.jsx("path", {
        d: "M248 104 Q248 96 258 96 H368 Q384 96 384 110 V170 H248z",
        fill: "#001d2d",
      }),
      e.jsx("circle", {
        cx: 266,
        cy: 112,
        r: 6,
        fill: "#d1beaa",
        opacity: 0.8,
      }),
      e.jsx("path", {
        d: "M290 170 V160 a30 22 0 0 1 60 0 V170z",
        fill: "#333e48",
      }),
      e.jsx("path", {
        d: "M298 140 a22 24 0 0 1 44 0 V162 H298z",
        fill: "#333e48",
      }),
      e.jsx("ellipse", { cx: 320, cy: 144, rx: 14, ry: 16, fill: "#d6a77a" }),
      e.jsx("path", {
        d: "M312 139 l5 2 M328 139 l-5 2",
        stroke: "#111b23",
        strokeWidth: 1.8,
      }),
      e.jsx("circle", { cx: 314, cy: 145, r: 1.8, fill: "#111b23" }),
      e.jsx("circle", { cx: 326, cy: 145, r: 1.8, fill: "#111b23" }),
      e.jsx("path", {
        d: "M314 154 q7 3 12 -1",
        fill: "none",
        stroke: "#901e21",
        strokeWidth: 1.5,
      }),
      e.jsx("rect", {
        x: 333,
        y: 134,
        width: 9,
        height: 18,
        rx: 2,
        fill: "#0d171f",
      }),
      e.jsx("path", {
        d: "M340 156 L352 170",
        stroke: "#333e48",
        strokeWidth: 9,
        strokeLinecap: "round",
      }),
      e.jsx("rect", { x: 240, y: 168, width: 152, height: 8, fill: "#111b23" }),
      e.jsx("rect", {
        x: 258,
        y: 190,
        width: 64,
        height: 18,
        rx: 3,
        fill: "#480004",
      }),
      e.jsx(r, {
        x: 290,
        y: 202.5,
        size: 8,
        anchor: "middle",
        fill: "#ffa79f",
        children: "WITHHELD",
      }),
    ],
  });
}
function jr({ x: i, ch: t }) {
  return e.jsxs("g", {
    children: [
      e.jsx("rect", {
        x: i,
        y: 200,
        width: 18,
        height: 18,
        rx: 3,
        fill: "#bac3cb",
        stroke: "#95a1ac",
      }),
      e.jsx(j, {
        x: i + 9,
        y: 213,
        size: 10,
        fill: "#111b23",
        anchor: "middle",
        children: t,
      }),
    ],
  });
}
function yr() {
  const i = ["K", "E", "S", "T", "R", "E", "L"];
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#0d171f" }),
      e.jsx("rect", {
        x: 10,
        y: 10,
        width: 232,
        height: 150,
        rx: 6,
        fill: "#242f38",
      }),
      e.jsx("rect", {
        x: 16,
        y: 16,
        width: 220,
        height: 138,
        rx: 2,
        fill: "#111b23",
      }),
      e.jsxs(f, {
        x: 22,
        y: 22,
        w: 152,
        h: 112,
        bar: "#54697c",
        children: [
          e.jsx(r, {
            x: 58,
            y: 32,
            size: 7,
            fill: "#e3e9ee",
            children: "FREE CCTV Player",
          }),
          e.jsx("rect", {
            x: 27,
            y: 42,
            width: 142,
            height: 70,
            fill: "#111b23",
          }),
          e.jsx("rect", {
            x: 27,
            y: 88,
            width: 142,
            height: 24,
            fill: "#242f38",
          }),
          e.jsx("rect", {
            x: 40,
            y: 80,
            width: 60,
            height: 14,
            fill: "#46515b",
          }),
          e.jsx("circle", { cx: 130, cy: 62, r: 7, fill: "#333e48" }),
          e.jsx("path", { d: "M124 70 h12 l4 24 h-20z", fill: "#333e48" }),
          e.jsx("path", {
            d: "M120 74 L104 80",
            stroke: "#333e48",
            strokeWidth: 4,
            strokeLinecap: "round",
          }),
          e.jsx(j, {
            x: 31,
            y: 52,
            size: 7,
            fill: "#bac3cb",
            children: "CAM 2",
          }),
          e.jsx(j, {
            x: 165,
            y: 52,
            size: 7,
            fill: "#bac3cb",
            anchor: "end",
            children: "14:32",
          }),
          e.jsx("circle", { cx: 160, cy: 60, r: 2.5, fill: "#cb5651" }),
          e.jsx("rect", {
            x: 27,
            y: 114,
            width: 142,
            height: 16,
            fill: "#bac3cb",
          }),
          e.jsx("path", { d: "M33 117 v10 l8 -5z", fill: "#333e48" }),
          e.jsx("rect", {
            x: 48,
            y: 121,
            width: 110,
            height: 3,
            rx: 1.5,
            fill: "#95a1ac",
          }),
          e.jsx("rect", {
            x: 48,
            y: 121,
            width: 40,
            height: 3,
            rx: 1.5,
            fill: "#54697c",
          }),
        ],
      }),
      e.jsxs("g", {
        className: "attack-flash",
        children: [
          e.jsx("path", {
            d: "M184 52 q22 -24 44 0 q-22 24 -44 0z",
            fill: "#bac3cb",
            stroke: "#cb5651",
            strokeWidth: 2,
          }),
          e.jsx("circle", { cx: 206, cy: 52, r: 8, fill: "#ac3a38" }),
          e.jsx("circle", { cx: 206, cy: 52, r: 3.5, fill: "#0d171f" }),
        ],
      }),
      e.jsx(r, {
        x: 206,
        y: 82,
        size: 7,
        anchor: "middle",
        fill: "#ffa79f",
        children: "SPYWARE",
      }),
      e.jsx("rect", {
        x: 180,
        y: 96,
        width: 52,
        height: 38,
        rx: 3,
        fill: "#002538",
        stroke: "#4e89aa",
      }),
      e.jsx(j, {
        x: 206,
        y: 110,
        size: 7,
        fill: "#8ecbee",
        anchor: "middle",
        children: "CASE",
      }),
      e.jsx(j, {
        x: 206,
        y: 124,
        size: 7,
        fill: "#8ecbee",
        anchor: "middle",
        children: "FILES",
      }),
      e.jsx("path", { d: "M0 160 H252 L240 176 H12z", fill: "#333e48" }),
      e.jsx(We, { y: 176, top: "#242f38", front: "#0d171f" }),
      e.jsx(r, {
        x: 14,
        y: 194,
        size: 8,
        fill: "#95a1ac",
        children: "Keys recorded",
      }),
      i.map((t, s) => e.jsx(jr, { x: 14 + s * 22, ch: t }, s)),
      e.jsx("path", {
        d: "M170 209 H194",
        stroke: "#cb5651",
        strokeWidth: 2,
        strokeDasharray: "4 3",
        className: "attack-flow",
      }),
      e.jsx("path", {
        d: "M232 60 C270 60 270 30 292 30",
        fill: "none",
        stroke: "#cb5651",
        strokeWidth: 2,
        strokeDasharray: "5 5",
        className: "attack-flow",
      }),
      e.jsx("path", {
        d: "M196 209 C260 209 262 150 292 150",
        fill: "none",
        stroke: "#cb5651",
        strokeWidth: 2,
        strokeDasharray: "5 5",
        className: "attack-flow",
      }),
      e.jsx("rect", {
        x: 292,
        y: 10,
        width: 100,
        height: 76,
        rx: 5,
        fill: "#111b23",
        stroke: "#46515b",
      }),
      [0, 1, 2].map((t) =>
        e.jsxs(
          "g",
          {
            children: [
              e.jsx("rect", {
                x: 300,
                y: 18 + t * 20,
                width: 56,
                height: 14,
                rx: 2,
                fill: "#242f38",
              }),
              e.jsx("circle", {
                cx: 308,
                cy: 25 + t * 20,
                r: 2.5,
                fill: "#cb5651",
                className: "attack-flash",
              }),
              e.jsx("rect", {
                x: 316,
                y: 23 + t * 20,
                width: 34,
                height: 4,
                rx: 2,
                fill: "#333e48",
              }),
            ],
          },
          t,
        ),
      ),
      e.jsx("circle", {
        cx: 374,
        cy: 36,
        r: 12,
        fill: "#111b23",
        stroke: "#95a1ac",
        strokeWidth: 1.5,
      }),
      e.jsx("path", {
        d: "M362 36 h24 M374 24 q-8 12 0 24 M374 24 q8 12 0 24 M364 30 h20 M364 42 h20",
        fill: "none",
        stroke: "#95a1ac",
        strokeWidth: 1.2,
      }),
      e.jsx(r, {
        x: 342,
        y: 78,
        size: 7.5,
        anchor: "middle",
        fill: "#95a1ac",
        children: "GANG SERVER",
      }),
      e.jsx("rect", {
        x: 292,
        y: 100,
        width: 100,
        height: 128,
        rx: 5,
        fill: "#0d171f",
        stroke: "#cb5651",
      }),
      e.jsx(j, {
        x: 300,
        y: 116,
        size: 8,
        fill: "#ee766f",
        children: "STOLEN",
      }),
      e.jsx("path", { d: "M296 122 H388", stroke: "#901e21" }),
      e.jsx(j, {
        x: 300,
        y: 138,
        size: 7.5,
        fill: "#ffe4b4",
        children: "OP KESTREL",
      }),
      e.jsx(j, {
        x: 300,
        y: 150,
        size: 7.5,
        fill: "#ffe4b4",
        children: "RAID: TUE 4AM",
      }),
      e.jsx(j, {
        x: 300,
        y: 170,
        size: 7.5,
        fill: "#ffe4b4",
        children: "UNDERCOVER:",
      }),
      e.jsx(j, {
        x: 300,
        y: 182,
        size: 7.5,
        fill: "#ffe4b4",
        children: "DC M. LEWIS",
      }),
      e.jsx(j, {
        x: 300,
        y: 194,
        size: 7.5,
        fill: "#ffe4b4",
        children: "DC S. GRANT",
      }),
      e.jsx(j, {
        x: 300,
        y: 216,
        size: 7.5,
        fill: "#ffa79f",
        className: "attack-flash",
        children: "SENDING...",
      }),
    ],
  });
}
function Re({ y: i, bed: t, text: s }) {
  return e.jsxs("g", {
    children: [
      e.jsx(j, { x: 258, y: i, size: 7.5, fill: "#a8ffc6", children: t }),
      e.jsx(j, { x: 258, y: i + 10, size: 7.5, fill: "#ffe4b4", children: s }),
    ],
  });
}
function pr() {
  const i = [
    [16, 14],
    [150, 20],
    [196, 10],
    [118, 48],
    [210, 62],
  ];
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#0d171f" }),
      i.map(([t, s]) =>
        e.jsx(
          "circle",
          { cx: t, cy: s, r: 1.2, fill: "#bac3cb", opacity: 0.7 },
          `${t}-${s}`,
        ),
      ),
      e.jsx("rect", { x: 12, y: 92, width: 116, height: 122, fill: "#242f38" }),
      e.jsx("rect", { x: 12, y: 92, width: 116, height: 18, fill: P }),
      e.jsx(r, {
        x: 70,
        y: 105,
        size: 9,
        anchor: "middle",
        fill: "#e3e9ee",
        children: "St Elm Hospital",
      }),
      [0, 1, 2, 3].map((t) =>
        [0, 1, 2, 3].map((s) =>
          e.jsx(
            "rect",
            {
              x: 22 + s * 26,
              y: 118 + t * 22,
              width: 16,
              height: 12,
              fill: "#ffe4b4",
              opacity: (t + s) % 3 ? 0.55 : 0.2,
            },
            `${t}-${s}`,
          ),
        ),
      ),
      e.jsx("path", {
        d: "M62 92 L70 36 L78 92 M64 76 L76 62 M66 62 L75 50",
        fill: "none",
        stroke: "#5c6873",
        strokeWidth: 2.5,
      }),
      e.jsx("circle", {
        cx: 70,
        cy: 32,
        r: 3,
        fill: "#cb5651",
        className: "attack-flash",
      }),
      [10, 18].map((t) =>
        e.jsxs(
          "g",
          {
            opacity: 1 - t / 40,
            children: [
              e.jsx("path", {
                d: `M80 ${40 - t} a${t} ${t} 0 0 1 0 ${2 * t}`,
                fill: "none",
                stroke: "#6ca8ca",
                strokeWidth: 2,
                strokeLinecap: "round",
              }),
              e.jsx("path", {
                d: `M60 ${40 - t} a${t} ${t} 0 0 0 0 ${2 * t}`,
                fill: "none",
                stroke: "#6ca8ca",
                strokeWidth: 2,
                strokeLinecap: "round",
              }),
            ],
          },
          t,
        ),
      ),
      e.jsx("rect", { x: 0, y: 214, width: 400, height: 26, fill: "#111b23" }),
      e.jsx("path", {
        d: "M96 40 C150 50 170 100 182 140",
        fill: "none",
        stroke: "#6ca8ca",
        strokeWidth: 1.8,
        strokeDasharray: "3 4",
        className: "attack-flow",
      }),
      e.jsx("rect", {
        x: 140,
        y: 140,
        width: 92,
        height: 60,
        rx: 10,
        fill: "#242f38",
        stroke: "#46515b",
        strokeWidth: 2,
      }),
      e.jsx("rect", {
        x: 148,
        y: 148,
        width: 76,
        height: 32,
        rx: 3,
        fill: "#7ed99f",
      }),
      e.jsx(j, {
        x: 152,
        y: 160,
        size: 7.5,
        fill: "#1c2f40",
        children: "BED3 J.WILSON",
      }),
      e.jsx(j, {
        x: 152,
        y: 173,
        size: 7.5,
        fill: "#1c2f40",
        children: "CHEST PAIN",
      }),
      [0, 1, 2].map((t) =>
        e.jsx(
          "rect",
          {
            x: 156 + t * 22,
            y: 186,
            width: 16,
            height: 7,
            rx: 3,
            fill: "#46515b",
          },
          t,
        ),
      ),
      e.jsx("circle", {
        cx: 222,
        cy: 146,
        r: 2.5,
        fill: "#cb5651",
        className: "attack-flash",
      }),
      e.jsx("path", {
        d: "M96 30 C150 10 200 30 228 64",
        fill: "none",
        stroke: "#ee766f",
        strokeWidth: 2,
        strokeDasharray: "5 5",
        className: "attack-flow",
      }),
      e.jsx("path", {
        d: "M244 132 L234 70",
        stroke: "#bac3cb",
        strokeWidth: 2,
      }),
      e.jsx("circle", { cx: 234, cy: 68, r: 3, fill: "#bac3cb" }),
      e.jsx("rect", {
        x: 236,
        y: 128,
        width: 18,
        height: 10,
        rx: 2,
        fill: "#0d171f",
        stroke: "#5c6873",
      }),
      e.jsx("path", { d: "M254 133 H266", stroke: "#5c6873", strokeWidth: 2 }),
      e.jsx("rect", {
        x: 250,
        y: 10,
        width: 142,
        height: 116,
        rx: 5,
        fill: "#0d171f",
        stroke: "#5bb57e",
        strokeWidth: 1.5,
      }),
      e.jsx("circle", {
        cx: 260,
        cy: 22,
        r: 3,
        fill: "#cb5651",
        className: "attack-flash",
      }),
      e.jsx(j, {
        x: 268,
        y: 25,
        size: 8,
        fill: "#7ed99f",
        children: "DECODING",
      }),
      e.jsx(j, {
        x: 386,
        y: 25,
        size: 7,
        fill: "#a8ffc6",
        anchor: "end",
        children: "153.3 MHz",
      }),
      e.jsx("path", { d: "M250 31 H392", stroke: "#006034" }),
      e.jsx(Re, { y: 44, bed: "W7 BED3 J.WILSON", text: "CHEST PAIN" }),
      e.jsx(Re, { y: 70, bed: "W2 BED9 A.FINCH", text: "BROKEN HIP" }),
      e.jsx(Re, { y: 96, bed: "W5 BED1 M.ROSE", text: "DIABETIC" }),
      e.jsx("path", { d: "M240 126 H400 L396 136 H244z", fill: "#46515b" }),
      e.jsx("rect", { x: 236, y: 136, width: 164, height: 6, fill: "#333e48" }),
      e.jsx("rect", { x: 250, y: 142, width: 6, height: 72, fill: "#333e48" }),
      e.jsx("rect", { x: 384, y: 142, width: 6, height: 72, fill: "#333e48" }),
      e.jsx("rect", {
        x: 268,
        y: 156,
        width: 110,
        height: 38,
        rx: 4,
        fill: "#111b23",
        stroke: "#ee766f",
      }),
      e.jsx(r, {
        x: 323,
        y: 170,
        size: 7.5,
        anchor: "middle",
        fill: "#d1beaa",
        children: "CAPTURED",
      }),
      e.jsx(j, {
        x: 323,
        y: 187,
        size: 12,
        fill: "#e8ba61",
        anchor: "middle",
        children: "4,812",
      }),
    ],
  });
}
function gr({ x: i, y: t }) {
  return e.jsxs("g", {
    children: [
      e.jsx("rect", {
        x: i,
        y: t,
        width: 30,
        height: 22,
        rx: 2,
        fill: "#242f38",
        stroke: "#46515b",
      }),
      e.jsx("rect", {
        x: i + 3,
        y: t + 3,
        width: 24,
        height: 14,
        fill: "#901e21",
      }),
      e.jsx("circle", {
        cx: i + 15,
        cy: t + 10,
        r: 3,
        fill: "#cb5651",
        className: "attack-flash",
      }),
      e.jsx("rect", {
        x: i + 11,
        y: t + 22,
        width: 8,
        height: 4,
        fill: "#46515b",
      }),
    ],
  });
}
function br({ x: i }) {
  return e.jsxs("g", {
    children: [
      e.jsx("rect", {
        x: i,
        y: 211,
        width: 40,
        height: 17,
        rx: 2,
        fill: "#ffe4b4",
      }),
      e.jsx("path", { d: `M${i + 40} 215 h8 l6 6 v7 h-14z`, fill: "#ffe4b4" }),
      e.jsx("path", { d: `M${i + 42} 217 h5 l4 4 h-9z`, fill: "#111b23" }),
      e.jsx("rect", { x: i, y: 222, width: 54, height: 3, fill: "#137a47" }),
      e.jsx("path", {
        d: `M${i + 17} 216 h8 M${i + 21} 212 v8`,
        stroke: "#cb5651",
        strokeWidth: 2.5,
      }),
      e.jsx("rect", {
        x: i + 4,
        y: 207,
        width: 9,
        height: 4,
        rx: 1,
        fill: "#4e89aa",
        className: "attack-flash",
      }),
      e.jsx("circle", { cx: i + 10, cy: 229, r: 4.5, fill: "#0d171f" }),
      e.jsx("circle", { cx: i + 44, cy: 229, r: 4.5, fill: "#0d171f" }),
    ],
  });
}
function wr() {
  const i = [];
  for (let t = 0; t < 4; t += 1)
    for (let s = 0; s < 3; s += 1)
      i.push([6 + s * 36 + (t % 2) * 6, 34 + t * 38]);
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#0d171f" }),
      e.jsx("rect", { x: 0, y: 0, width: 400, height: 22, fill: "#901e21" }),
      e.jsx("circle", {
        cx: 14,
        cy: 11,
        r: 5,
        fill: "#4e89aa",
        className: "attack-flash",
      }),
      e.jsx(r, {
        x: 26,
        y: 15,
        size: 9,
        fill: "#e3e9ee",
        children: "MAJOR INCIDENT",
      }),
      e.jsx(r, {
        x: 392,
        y: 15,
        size: 8,
        anchor: "end",
        fill: "#d1beaa",
        children: "Motorway pile-up · 38 casualties",
      }),
      i.map(([t, s], l) =>
        e.jsx(
          "path",
          {
            d: `M${t + 30} ${s + 11} C${t + 60} ${s + 11} 116 ${92 + l * 7} 146 ${92 + l * 7}`,
            fill: "none",
            stroke: "#cb5651",
            strokeWidth: 1.4,
            strokeDasharray: "4 5",
            opacity: 0.75,
            className: "attack-flow",
          },
          `flow-${t}-${s}`,
        ),
      ),
      i.map(([t, s]) => e.jsx(gr, { x: t, y: s }, `${t}-${s}`)),
      e.jsx(r, {
        x: 60,
        y: 197,
        size: 8,
        anchor: "middle",
        fill: "#ffa79f",
        children: "BOTNET",
      }),
      e.jsxs(f, {
        x: 146,
        y: 30,
        w: 154,
        h: 170,
        bar: "#333e48",
        children: [
          e.jsx("rect", { x: 147, y: 46, width: 152, height: 16, fill: P }),
          e.jsx(r, {
            x: 154,
            y: 57.5,
            size: 8,
            fill: "#e3e9ee",
            children: "St Elm Hospital",
          }),
          e.jsx("rect", {
            x: 147,
            y: 62,
            width: 152,
            height: 16,
            fill: "#cb5651",
          }),
          e.jsx(r, {
            x: 223,
            y: 73.5,
            size: 8,
            anchor: "middle",
            fill: "#e3e9ee",
            children: "URGENT BLOOD APPEAL",
          }),
          e.jsx(r, {
            x: 155,
            y: 94,
            size: 10.5,
            fill: "#111b23",
            children: "O-negative donors",
          }),
          e.jsx(r, {
            x: 155,
            y: 106,
            size: 7.5,
            weight: 400,
            fill: "#46515b",
            children: "Book an emergency slot today",
          }),
          e.jsx("rect", {
            x: 155,
            y: 113,
            width: 136,
            height: 18,
            rx: 3,
            fill: "#bac3cb",
          }),
          e.jsx(r, {
            x: 223,
            y: 125.5,
            size: 8,
            anchor: "middle",
            fill: "#5c6873",
            children: "Book a slot",
          }),
          e.jsx("circle", {
            cx: 166,
            cy: 150,
            r: 10,
            fill: "none",
            stroke: "#bac3cb",
            strokeWidth: 4,
          }),
          e.jsx("path", {
            d: "M166 140 a10 10 0 0 1 10 10",
            fill: "none",
            stroke: P,
            strokeWidth: 4,
            strokeLinecap: "round",
          }),
          e.jsx(r, {
            x: 182,
            y: 148,
            size: 8.5,
            fill: "#ac3a38",
            children: "Connection timed out",
          }),
          e.jsx(r, {
            x: 182,
            y: 159,
            size: 7,
            weight: 400,
            fill: "#46515b",
            children: "The server is not responding",
          }),
          e.jsx("rect", {
            x: 154,
            y: 172,
            width: 138,
            height: 20,
            rx: 3,
            fill: "#bac3cb",
          }),
          e.jsx(j, {
            x: 223,
            y: 185.5,
            size: 9,
            fill: "#ac3a38",
            anchor: "middle",
            className: "attack-flash",
            children: "2.1M requests/sec",
          }),
        ],
      }),
      e.jsx("path", { d: "M350 26 V36", stroke: "#5c6873", strokeWidth: 2 }),
      e.jsx("path", {
        d: "M342 36 h16",
        stroke: "#5c6873",
        strokeWidth: 3,
        strokeLinecap: "round",
      }),
      e.jsx("rect", {
        x: 322,
        y: 40,
        width: 56,
        height: 82,
        rx: 10,
        fill: "#e3e9ee",
        opacity: 0.92,
      }),
      e.jsx("path", {
        d: "M326 106 H374 V110 a8 8 0 0 1 -8 8 H334 a8 8 0 0 1 -8 -8z",
        fill: "#cb5651",
      }),
      e.jsx("path", {
        d: "M326 106 H374",
        stroke: "#cb5651",
        strokeWidth: 1.5,
        strokeDasharray: "3 2",
        className: "attack-flash-stroke",
      }),
      [86, 96, 106].map((t) =>
        e.jsx(
          "path",
          { d: `M366 ${t} h8`, stroke: "#ffa79f", strokeWidth: 1.5 },
          t,
        ),
      ),
      e.jsx("rect", {
        x: 331,
        y: 50,
        width: 38,
        height: 30,
        rx: 2,
        fill: "#e3e9ee",
        stroke: "#ffa79f",
      }),
      e.jsx(r, {
        x: 350,
        y: 63,
        size: 8,
        anchor: "middle",
        fill: "#ac3a38",
        children: "O NEG",
      }),
      e.jsx(r, {
        x: 350,
        y: 74,
        size: 7,
        anchor: "middle",
        weight: 400,
        fill: "#46515b",
        children: "Blood bank",
      }),
      e.jsx("path", { d: "M350 122 V132", stroke: "#cb5651", strokeWidth: 3 }),
      e.jsx("rect", {
        x: 316,
        y: 134,
        width: 68,
        height: 14,
        rx: 3,
        fill: "#480004",
      }),
      e.jsx(r, {
        x: 350,
        y: 144,
        size: 7.5,
        anchor: "middle",
        fill: "#ffa79f",
        children: "2 units left",
      }),
      e.jsx("rect", {
        x: 308,
        y: 154,
        width: 84,
        height: 48,
        rx: 4,
        fill: "#111b23",
        stroke: "#cb5651",
        strokeWidth: 2,
        className: "attack-flash-stroke",
      }),
      e.jsx(r, {
        x: 350,
        y: 165,
        size: 7,
        anchor: "middle",
        fill: "#ffa79f",
        children: "DONOR SLOTS",
      }),
      [0, 1].map((t) =>
        [0, 1, 2, 3, 4].map((s) =>
          e.jsx(
            "rect",
            {
              x: 316 + s * 14,
              y: 170 + t * 11,
              width: 10,
              height: 8,
              rx: 1.5,
              fill: "none",
              stroke: "#46515b",
              strokeDasharray: "2 1.5",
            },
            `${t}-${s}`,
          ),
        ),
      ),
      e.jsx(j, {
        x: 350,
        y: 198,
        size: 8,
        fill: "#ee766f",
        anchor: "middle",
        children: "0 booked",
      }),
      e.jsx("rect", { x: 0, y: 206, width: 400, height: 34, fill: "#111b23" }),
      e.jsx("path", {
        d: "M0 237 H400",
        stroke: "#333e48",
        strokeWidth: 2,
        strokeDasharray: "14 10",
      }),
      [10, 80, 150].map((t) => e.jsx(br, { x: t }, t)),
      e.jsx("rect", { x: 300, y: 212, width: 92, height: 20, rx: 3, fill: P }),
      e.jsx(r, {
        x: 346,
        y: 225.5,
        size: 8.5,
        anchor: "middle",
        fill: "#e3e9ee",
        children: "A&E",
      }),
    ],
  });
}
function kr() {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#111b23" }),
      e.jsx("rect", { x: 0, y: 0, width: 400, height: 204, fill: "#002538" }),
      e.jsx("rect", {
        x: 0,
        y: 150,
        width: 400,
        height: 6,
        fill: "#8ecbee",
        opacity: 0.25,
      }),
      [30, 170, 310].map((i) =>
        e.jsx(
          "rect",
          {
            x: i,
            y: 4,
            width: 60,
            height: 5,
            rx: 2.5,
            fill: "#bac3cb",
            opacity: 0.6,
          },
          i,
        ),
      ),
      e.jsx("rect", { x: 140, y: 18, width: 146, height: 22, rx: 3, fill: P }),
      e.jsx(r, {
        x: 213,
        y: 33,
        size: 9,
        anchor: "middle",
        fill: "#e3e9ee",
        children: "Children's Ward 9",
      }),
      e.jsx("rect", {
        x: 160,
        y: 46,
        width: 106,
        height: 16,
        rx: 3,
        fill: "#111b23",
        stroke: "#6ca8ca",
      }),
      e.jsx(r, {
        x: 213,
        y: 57.5,
        size: 7.5,
        anchor: "middle",
        fill: "#8ecbee",
        children: "Visiting 2pm to 8pm",
      }),
      [
        [160, 92],
        [200, 80],
        [252, 96],
        [284, 76],
      ].map(([i, t]) =>
        e.jsx(
          "path",
          {
            d: `M${i} ${t - 6} l1.8 4 4.2 0.4 -3.2 2.8 1 4.2 -3.8 -2.2 -3.8 2.2 1 -4.2 -3.2 -2.8 4.2 -0.4z`,
            fill: "#ffe4b4",
            opacity: 0.5,
          },
          `${i}-${t}`,
        ),
      ),
      e.jsx("rect", {
        x: 14,
        y: 22,
        width: 108,
        height: 20,
        rx: 2,
        fill: "#333e48",
      }),
      e.jsx(r, {
        x: 68,
        y: 36,
        size: 8.5,
        anchor: "middle",
        fill: "#e3e9ee",
        children: "STAFF OFFICE",
      }),
      e.jsx("rect", {
        x: 18,
        y: 48,
        width: 100,
        height: 156,
        fill: "#0d171f",
        stroke: "#5c6873",
        strokeWidth: 3,
      }),
      e.jsx("rect", { x: 28, y: 128, width: 80, height: 6, fill: "#46515b" }),
      e.jsx("rect", { x: 34, y: 134, width: 5, height: 70, fill: "#333e48" }),
      e.jsx("rect", { x: 98, y: 134, width: 5, height: 70, fill: "#333e48" }),
      e.jsx("rect", {
        x: 50,
        y: 112,
        width: 40,
        height: 16,
        rx: 2,
        fill: "#480004",
        opacity: 0.6,
        stroke: "#cb5651",
        strokeWidth: 1.5,
        strokeDasharray: "3 2",
        className: "attack-flash-stroke",
      }),
      e.jsx("rect", { x: 34, y: 70, width: 30, height: 22, fill: "#242f38" }),
      e.jsx("path", { d: "M118 48 L146 58 V214 L118 204z", fill: "#95a1ac" }),
      e.jsx("circle", { cx: 140, cy: 130, r: 3, fill: "#333e48" }),
      e.jsx("rect", {
        x: 124,
        y: 98,
        width: 12,
        height: 18,
        rx: 2,
        fill: "#242f38",
        stroke: "#5c6873",
      }),
      e.jsx("circle", { cx: 130, cy: 110, r: 2, fill: "#5bb57e" }),
      e.jsx("rect", {
        x: 330,
        y: 70,
        width: 62,
        height: 22,
        rx: 3,
        fill: "#137a47",
      }),
      e.jsx(r, {
        x: 361,
        y: 85,
        size: 9,
        anchor: "middle",
        fill: "#e3e9ee",
        children: "WAY OUT",
      }),
      e.jsx("path", {
        d: "M352 100 h22 m-7 -6 l7 6 l-7 6",
        fill: "none",
        stroke: "#7ed99f",
        strokeWidth: 3,
        strokeLinecap: "round",
        strokeLinejoin: "round",
      }),
      e.jsx("rect", { x: 0, y: 204, width: 400, height: 36, fill: "#111b23" }),
      e.jsx("path", {
        d: "M244 156 L230 222 M262 156 L280 222",
        stroke: "#242f38",
        strokeWidth: 13,
        strokeLinecap: "round",
      }),
      e.jsx("path", {
        d: "M222 224 h16 M272 224 h16",
        stroke: "#0d171f",
        strokeWidth: 7,
        strokeLinecap: "round",
      }),
      e.jsx("rect", {
        x: 234,
        y: 94,
        width: 38,
        height: 68,
        rx: 10,
        fill: "#137a47",
      }),
      e.jsx("path", { d: "M253 94 V162", stroke: "#006034", strokeWidth: 2 }),
      e.jsx("circle", { cx: 253, cy: 78, r: 14, fill: "#e0ac69" }),
      e.jsx("path", { d: "M239 74 a14 14 0 0 1 28 0z", fill: "#111b23" }),
      e.jsx("path", { d: "M265 72 h10 q2 3 -2 4 h-8z", fill: "#111b23" }),
      e.jsx("circle", { cx: 259, cy: 80, r: 1.6, fill: "#111b23" }),
      e.jsx("path", {
        d: "M268 104 L292 122",
        stroke: "#137a47",
        strokeWidth: 10,
        strokeLinecap: "round",
      }),
      e.jsx("path", {
        d: "M288 124 L306 100 M294 126 L316 108 M290 126 L298 96",
        stroke: "#399661",
        strokeWidth: 2,
      }),
      e.jsx("path", { d: "M284 122 L300 138 L310 114z", fill: "#d1beaa" }),
      [
        [306, 98, "#ee766f"],
        [316, 106, "#e8ba61"],
        [298, 94, "#ee766f"],
        [310, 90, "#8ba3b7"],
      ].map(([i, t, s]) =>
        e.jsx(
          "circle",
          { cx: Number(i), cy: Number(t), r: 5, fill: String(s) },
          `${i}-${t}`,
        ),
      ),
      e.jsx("circle", { cx: 292, cy: 124, r: 5, fill: "#e0ac69" }),
      e.jsx("path", {
        d: "M196 124 L240 118 L248 146 L204 152z",
        fill: "#bac3cb",
        stroke: "#46515b",
        strokeWidth: 1.5,
      }),
      e.jsx("path", {
        d: "M198 130 L240 124",
        stroke: "#95a1ac",
        strokeWidth: 1.5,
      }),
      e.jsx("path", {
        d: "M240 100 L228 136 L216 142",
        fill: "none",
        stroke: "#137a47",
        strokeWidth: 10,
        strokeLinecap: "round",
        strokeLinejoin: "round",
      }),
      e.jsx("circle", { cx: 214, cy: 143, r: 5, fill: "#e0ac69" }),
      e.jsx("path", {
        d: "M206 150 L196 170",
        stroke: "#cb5651",
        strokeWidth: 1.2,
      }),
      e.jsx("rect", {
        x: 156,
        y: 168,
        width: 74,
        height: 24,
        rx: 2,
        fill: "#cb5651",
      }),
      e.jsx(r, {
        x: 193,
        y: 178,
        size: 7,
        anchor: "middle",
        fill: "#e3e9ee",
        children: "WARD 9",
      }),
      e.jsx(r, {
        x: 193,
        y: 188,
        size: 7,
        anchor: "middle",
        fill: "#e3e9ee",
        children: "PATIENT LIST",
      }),
    ],
  });
}
function ur() {
  const i = [];
  for (let t = 0; t < 2; t += 1)
    for (let s = 0; s < 8; s += 1) i.push([180 + s * 9, 142 + t * 5]);
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#0d171f" }),
      e.jsx("rect", { x: 0, y: 0, width: 400, height: 204, fill: "#002538" }),
      [60, 210, 350].map((t) =>
        e.jsx(
          "rect",
          {
            x: t - 26,
            y: 2,
            width: 52,
            height: 4,
            rx: 2,
            fill: "#8ecbee",
            opacity: 0.3,
          },
          t,
        ),
      ),
      e.jsx("rect", {
        x: 40,
        y: 10,
        width: 60,
        height: 24,
        rx: 2,
        fill: "#0d171f",
        stroke: "#333e48",
        strokeWidth: 2,
      }),
      e.jsx("path", { d: "M70 10 V34", stroke: "#333e48", strokeWidth: 2 }),
      e.jsx("circle", { cx: 88, cy: 21, r: 6, fill: "#d1beaa" }),
      e.jsx("circle", { cx: 91, cy: 19, r: 5.5, fill: "#0d171f" }),
      e.jsx("circle", { cx: 52, cy: 18, r: 1, fill: "#bac3cb" }),
      e.jsx("circle", { cx: 60, cy: 27, r: 1, fill: "#bac3cb" }),
      e.jsx("rect", { x: 156, y: 12, width: 120, height: 22, rx: 3, fill: P }),
      e.jsx(r, {
        x: 216,
        y: 27,
        size: 9,
        anchor: "middle",
        fill: "#e3e9ee",
        children: "A&E Majors",
      }),
      e.jsx("rect", {
        x: 310,
        y: 12,
        width: 60,
        height: 22,
        rx: 3,
        fill: "#0d171f",
        stroke: "#333e48",
      }),
      e.jsx(j, {
        x: 340,
        y: 27.5,
        size: 11,
        fill: "#7ed99f",
        anchor: "middle",
        children: "03:12",
      }),
      e.jsx("path", { d: "M0 40 H146", stroke: "#5c6873", strokeWidth: 3 }),
      e.jsx("path", {
        d: "M0 42 H30 V196 H0z M6 42 V196 M14 42 V196 M22 42 V196",
        fill: "#6ca8ca",
        fillOpacity: 0.18,
        stroke: "#6ca8ca",
        strokeOpacity: 0.35,
      }),
      e.jsx("path", {
        d: "M118 42 H146 V196 H118z M124 42 V196 M132 42 V196 M140 42 V196",
        fill: "#6ca8ca",
        fillOpacity: 0.18,
        stroke: "#6ca8ca",
        strokeOpacity: 0.35,
      }),
      e.jsx("path", { d: "M44 58 V200", stroke: "#95a1ac", strokeWidth: 2 }),
      e.jsx("rect", {
        x: 38,
        y: 58,
        width: 12,
        height: 18,
        rx: 3,
        fill: "#bac3cb",
        opacity: 0.8,
      }),
      e.jsx("path", {
        d: "M44 76 Q40 110 54 138",
        fill: "none",
        stroke: "#bac3cb",
        strokeWidth: 1,
        opacity: 0.6,
      }),
      e.jsx("rect", {
        x: 66,
        y: 62,
        width: 48,
        height: 34,
        rx: 3,
        fill: "#0d171f",
        stroke: "#333e48",
      }),
      e.jsx("path", {
        d: "M70 84 h8 l3 -10 l4 18 l3 -8 h6 l3 -10 l4 18 l3 -8 h6",
        fill: "none",
        stroke: "#7ed99f",
        strokeWidth: 1.5,
        strokeLinejoin: "round",
      }),
      e.jsx(j, { x: 70, y: 73, size: 7, fill: "#7ed99f", children: "HR 128" }),
      e.jsx("rect", {
        x: 34,
        y: 128,
        width: 6,
        height: 44,
        rx: 2,
        fill: "#5c6873",
      }),
      e.jsx("rect", {
        x: 36,
        y: 150,
        width: 80,
        height: 10,
        rx: 3,
        fill: "#bac3cb",
      }),
      e.jsx("ellipse", { cx: 52, cy: 146, rx: 12, ry: 5, fill: "#e3e9ee" }),
      e.jsx("circle", { cx: 56, cy: 138, r: 8, fill: "#8d5524" }),
      e.jsx("path", {
        d: "M48 136 a8 8 0 0 1 15 -3 q-8 -2 -15 3z",
        fill: "#111b23",
      }),
      e.jsx("rect", {
        x: 60,
        y: 140,
        width: 56,
        height: 14,
        rx: 6,
        fill: "#137a47",
      }),
      e.jsx("path", {
        d: "M44 160 V194 M108 160 V194",
        stroke: "#5c6873",
        strokeWidth: 3,
      }),
      e.jsx("circle", { cx: 44, cy: 198, r: 4, fill: "#333e48" }),
      e.jsx("circle", { cx: 108, cy: 198, r: 4, fill: "#333e48" }),
      e.jsx("rect", { x: 0, y: 204, width: 146, height: 36, fill: "#111b23" }),
      e.jsx("rect", {
        x: 156,
        y: 46,
        width: 120,
        height: 88,
        rx: 5,
        fill: "#242f38",
      }),
      e.jsx("rect", {
        x: 161,
        y: 51,
        width: 110,
        height: 78,
        rx: 2,
        fill: "#e3e9ee",
      }),
      e.jsx("rect", { x: 161, y: 51, width: 110, height: 16, fill: P }),
      e.jsx(r, {
        x: 216,
        y: 62,
        size: 7.5,
        anchor: "middle",
        fill: "#e3e9ee",
        children: "Patient Records",
      }),
      e.jsx("rect", {
        x: 168,
        y: 73,
        width: 96,
        height: 13,
        rx: 3,
        fill: "#e3e9ee",
        stroke: "#95a1ac",
      }),
      e.jsx(r, {
        x: 173,
        y: 82.5,
        size: 7.5,
        weight: 400,
        fill: "#333e48",
        children: "n.okafor",
      }),
      e.jsx("rect", {
        x: 168,
        y: 90,
        width: 96,
        height: 14,
        rx: 3,
        fill: "#e3e9ee",
        stroke: "#cb5651",
        strokeWidth: 1.5,
      }),
      e.jsx(r, {
        x: 173,
        y: 100.5,
        size: 8.5,
        fill: "#333e48",
        children: "• • • • • •",
      }),
      e.jsx("rect", {
        x: 213,
        y: 92,
        width: 1.5,
        height: 10,
        fill: "#111b23",
        className: "attack-flash",
      }),
      e.jsx("rect", { x: 190, y: 109, width: 52, height: 14, rx: 3, fill: P }),
      e.jsx(r, {
        x: 216,
        y: 119,
        size: 7.5,
        anchor: "middle",
        fill: "#e3e9ee",
        children: "Log in",
      }),
      e.jsx("rect", { x: 210, y: 134, width: 12, height: 90, fill: "#46515b" }),
      e.jsx("rect", {
        x: 172,
        y: 138,
        width: 88,
        height: 16,
        rx: 2,
        fill: "#333e48",
      }),
      i.map(([t, s], l) =>
        e.jsx(
          "rect",
          {
            x: t,
            y: s,
            width: 7,
            height: 3.5,
            rx: 0.8,
            fill: l === 11 ? "#cb5651" : "#bac3cb",
            className: l === 11 ? "attack-flash" : void 0,
          },
          `${t}-${s}`,
        ),
      ),
      e.jsx("path", {
        d: "M164 228 H268",
        stroke: "#46515b",
        strokeWidth: 5,
        strokeLinecap: "round",
      }),
      e.jsx("circle", {
        cx: 166,
        cy: 233,
        r: 5,
        fill: "#242f38",
        stroke: "#5c6873",
      }),
      e.jsx("circle", {
        cx: 266,
        cy: 233,
        r: 5,
        fill: "#242f38",
        stroke: "#5c6873",
      }),
      e.jsx("path", {
        d: "M174 240 V214 a42 32 0 0 1 84 0 V240z",
        fill: "#00425f",
      }),
      e.jsx("path", {
        d: "M182 214 L176 186 L186 156",
        fill: "none",
        stroke: "#00425f",
        strokeWidth: 11,
        strokeLinecap: "round",
        strokeLinejoin: "round",
      }),
      e.jsx("path", {
        d: "M250 214 L256 186 L246 156",
        fill: "none",
        stroke: "#00425f",
        strokeWidth: 11,
        strokeLinecap: "round",
        strokeLinejoin: "round",
      }),
      e.jsx("circle", { cx: 186, cy: 152, r: 5, fill: "#c68642" }),
      e.jsx("circle", { cx: 246, cy: 152, r: 5, fill: "#c68642" }),
      e.jsx("circle", { cx: 216, cy: 182, r: 18, fill: "#111b23" }),
      e.jsx("circle", { cx: 216, cy: 164, r: 7, fill: "#111b23" }),
      e.jsx("path", {
        d: "M200 200 q16 8 32 0",
        fill: "none",
        stroke: "#6ca8ca",
        strokeWidth: 2.5,
      }),
      e.jsx("rect", { x: 282, y: 148, width: 118, height: 8, fill: "#5c6873" }),
      e.jsx("rect", {
        x: 286,
        y: 156,
        width: 114,
        height: 84,
        fill: "#242f38",
      }),
      e.jsx("rect", { x: 300, y: 176, width: 88, height: 20, rx: 3, fill: P }),
      e.jsx(r, {
        x: 344,
        y: 189.5,
        size: 8,
        anchor: "middle",
        fill: "#e3e9ee",
        children: "Nurses' Station",
      }),
      e.jsx("path", {
        d: "M312 148 V122 a32 26 0 0 1 64 0 V148z",
        fill: "#746351",
      }),
      e.jsx("path", { d: "M344 100 V148", stroke: "#746351", strokeWidth: 2 }),
      e.jsx("path", {
        d: "M372 126 L352 145",
        stroke: "#746351",
        strokeWidth: 10,
        strokeLinecap: "round",
      }),
      e.jsx("circle", { cx: 349, cy: 147, r: 4.5, fill: "#e0ac69" }),
      e.jsx("rect", {
        x: 350,
        y: 120,
        width: 34,
        height: 11,
        rx: 2,
        fill: "#ffe4b4",
      }),
      e.jsx(r, {
        x: 367,
        y: 128.5,
        size: 7,
        anchor: "middle",
        fill: "#5c4d3b",
        children: "VISITOR",
      }),
      e.jsx("circle", { cx: 340, cy: 82, r: 17, fill: "#e0ac69" }),
      e.jsx("path", {
        d: "M323 80 a17 17 0 0 1 34 -4 q-18 -8 -34 4z",
        fill: "#46515b",
      }),
      e.jsx("circle", { cx: 331, cy: 84, r: 1.8, fill: "#111b23" }),
      e.jsx("path", { d: "M326 77 l8 2", stroke: "#111b23", strokeWidth: 1.6 }),
      e.jsx("path", { d: "M332 93 h7", stroke: "#901e21", strokeWidth: 1.5 }),
      e.jsx("path", {
        d: "M318 126 L302 144",
        stroke: "#746351",
        strokeWidth: 10,
        strokeLinecap: "round",
      }),
      e.jsx("rect", {
        x: 284,
        y: 116,
        width: 22,
        height: 34,
        rx: 3,
        fill: "#0d171f",
        stroke: "#46515b",
      }),
      e.jsx("rect", { x: 287, y: 121, width: 16, height: 24, fill: "#242f38" }),
      e.jsx("circle", {
        cx: 291,
        cy: 125,
        r: 1.8,
        fill: "#cb5651",
        className: "attack-flash",
      }),
      [0, 1, 2].map((t) =>
        [0, 1, 2].map((s) =>
          e.jsx(
            "rect",
            {
              x: 289 + s * 4.5,
              y: 130 + t * 4.5,
              width: 3.5,
              height: 3.5,
              fill: t === 1 && s === 2 ? "#cb5651" : "#95a1ac",
            },
            `${t}-${s}`,
          ),
        ),
      ),
      e.jsx("circle", { cx: 302, cy: 146, r: 4.5, fill: "#e0ac69" }),
      e.jsx("path", {
        d: "M284 132 L216 147",
        fill: "none",
        stroke: "#cb5651",
        strokeWidth: 1.8,
        strokeDasharray: "4 3",
        className: "attack-flow",
      }),
    ],
  });
}
function mr({ x: i, cap: t }) {
  return e.jsxs("g", {
    children: [
      e.jsx("rect", {
        x: i,
        y: 190,
        width: 8,
        height: 26,
        rx: 4,
        fill: "#d1beaa",
        opacity: 0.85,
      }),
      e.jsx("rect", {
        x: i,
        y: 194,
        width: 8,
        height: 18,
        rx: 2,
        fill: "#ac3a38",
        opacity: 0.7,
      }),
      e.jsx("rect", {
        x: i - 1,
        y: 184,
        width: 10,
        height: 7,
        rx: 1.5,
        fill: t,
      }),
    ],
  });
}
function Mr() {
  const i = ["#6e8498", "#e8ba61", "#cb5651", "#6ca8ca", "#6e8498", "#5bb57e"],
    t = Array.from({ length: 16 }, (s, l) => l);
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#0d171f" }),
      e.jsx("rect", { x: 0, y: 0, width: 400, height: 176, fill: "#0d171f" }),
      e.jsx("rect", {
        x: 10,
        y: 10,
        width: 196,
        height: 142,
        rx: 6,
        fill: "#242f38",
      }),
      e.jsx("rect", {
        x: 16,
        y: 16,
        width: 184,
        height: 130,
        rx: 2,
        fill: "#901e21",
        className: "attack-flash",
      }),
      e.jsx("rect", { x: 16, y: 16, width: 184, height: 14, fill: "#480004" }),
      e.jsx(r, {
        x: 22,
        y: 26,
        size: 7,
        fill: "#d1beaa",
        children: "LAB RESULTS SYSTEM",
      }),
      e.jsx(cr, { cx: 108, cy: 58 }),
      e.jsx(r, {
        x: 108,
        y: 102,
        size: 12,
        anchor: "middle",
        fill: "#e3e9ee",
        children: "RESULTS ENCRYPTED",
      }),
      e.jsx(r, {
        x: 108,
        y: 116,
        size: 8.5,
        anchor: "middle",
        weight: 400,
        fill: "#d1beaa",
        children: "Pay £4 million to unlock",
      }),
      e.jsx("rect", {
        x: 64,
        y: 122,
        width: 88,
        height: 17,
        rx: 3,
        fill: "#480004",
      }),
      e.jsx(j, {
        x: 108,
        y: 134.5,
        size: 12,
        fill: "#ffa79f",
        anchor: "middle",
        children: "71:59:08",
      }),
      e.jsxs(f, {
        x: 160,
        y: 124,
        w: 122,
        h: 50,
        bar: "#5c6873",
        children: [
          e.jsx(r, {
            x: 167,
            y: 153,
            size: 8,
            fill: "#111b23",
            children: "Browser out of date",
          }),
          e.jsx("rect", {
            x: 167,
            y: 157,
            width: 64,
            height: 14,
            rx: 3,
            fill: "#326e8e",
          }),
          e.jsx(r, {
            x: 199,
            y: 167,
            size: 7.5,
            anchor: "middle",
            fill: "#e3e9ee",
            children: "Update now",
          }),
          e.jsx(et, { x: 226, y: 156 }),
        ],
      }),
      e.jsx("rect", {
        x: 290,
        y: 30,
        width: 102,
        height: 140,
        rx: 6,
        fill: "#bac3cb",
      }),
      e.jsx("rect", {
        x: 290,
        y: 30,
        width: 102,
        height: 18,
        rx: 6,
        fill: "#95a1ac",
      }),
      e.jsx(r, {
        x: 341,
        y: 43,
        size: 8,
        anchor: "middle",
        fill: "#242f38",
        children: "ANALYSER 1",
      }),
      e.jsx("rect", {
        x: 300,
        y: 56,
        width: 82,
        height: 36,
        rx: 3,
        fill: "#0d171f",
      }),
      e.jsx(j, {
        x: 341,
        y: 79,
        size: 11,
        fill: "#ee766f",
        anchor: "middle",
        className: "attack-flash",
        children: "OFFLINE",
      }),
      e.jsx("rect", {
        x: 300,
        y: 104,
        width: 82,
        height: 44,
        rx: 3,
        fill: "#95a1ac",
      }),
      [0, 1, 2, 3, 4, 5].map((s) =>
        e.jsxs(
          "g",
          {
            children: [
              e.jsx("rect", {
                x: 306 + s * 12,
                y: 108,
                width: 7,
                height: 30,
                rx: 3.5,
                fill: "#e3e9ee",
              }),
              e.jsx("rect", {
                x: 305 + s * 12,
                y: 104,
                width: 9,
                height: 6,
                rx: 1.5,
                fill: i[s],
              }),
            ],
          },
          s,
        ),
      ),
      e.jsx("rect", {
        x: 300,
        y: 154,
        width: 82,
        height: 8,
        rx: 2,
        fill: "#5c6873",
      }),
      e.jsx("path", {
        d: "M206 60 C240 60 256 90 290 90",
        fill: "none",
        stroke: "#cb5651",
        strokeWidth: 2,
        strokeDasharray: "5 5",
        className: "attack-flow",
      }),
      e.jsx(We, { y: 176, top: "#333e48", front: "#111b23" }),
      e.jsx("rect", {
        x: 14,
        y: 208,
        width: 196,
        height: 10,
        rx: 2,
        fill: "#46515b",
      }),
      t.map((s) => e.jsx(mr, { x: 20 + s * 12, cap: i[s % i.length] }, s)),
      e.jsx("rect", {
        x: 226,
        y: 186,
        width: 166,
        height: 46,
        rx: 4,
        fill: "#111b23",
        stroke: "#cb5651",
        strokeWidth: 2,
        className: "attack-flash-stroke",
      }),
      e.jsx(r, {
        x: 238,
        y: 202,
        size: 8,
        fill: "#ffa79f",
        children: "SAMPLES WAITING",
      }),
      e.jsx(j, {
        x: 238,
        y: 225,
        size: 16,
        fill: "#ee766f",
        children: "3,412",
      }),
      e.jsx(Ft, { x: 372, y: 226 }),
    ],
  });
}
const vr = {
    police_phishing: {
      Art: or,
      bg: "#0d171f",
      alt: "A tired officer in a hi-vis vest clicks Resubmit claim on an email saying their overtime claim was rejected and must be resubmitted by 23:59, which opens a fake Northgate Police sign-in page on a lookalike web address.",
    },
    police_brute_force: {
      Art: nr,
      bg: "#0d171f",
      alt: "A bot copies 200 officer names from the force’s Meet your local team page and fires guesses such as Bobby123, Northgate1 and Police2026 at the Northgate Mail login, while the failed login counter climbs past 18,000.",
    },
    police_sql_injection: {
      Art: xr,
      bg: "#0d171f",
      alt: "A hooded attacker types a scrap of SQL code into the report reference box on Northgate Police’s Track my crime report page, and the crime reports database spills out victims’ and witnesses’ names, addresses and phone numbers.",
    },
    police_blagging: {
      Art: fr,
      bg: "#0d171f",
      alt: "A control room call handler in a headset looks at a record flashing Protected address while a man calling from a dark car on a withheld number claims to be DS Hughes from Westshire and demands the address now.",
    },
    police_spyware: {
      Art: yr,
      bg: "#0d171f",
      alt: "A detective’s laptop plays robbery CCTV in a free CCTV player while a red spyware eye watches the case files, recording keys that spell KESTREL and sending undercover officers’ names and raid plans to a gang server abroad.",
    },
    hospital_interception: {
      Art: pr,
      bg: "#0d171f",
      alt: "The St Elm Hospital mast broadcasts a pager message about a patient’s chest pain, and a man’s aerial and laptop nearby decode every message, listing patients’ names, beds and conditions.",
    },
    hospital_ddos: {
      Art: wr,
      bg: "#0d171f",
      alt: "Under a Major incident banner for a motorway pile-up with 38 casualties, a botnet of hijacked computers floods St Elm Hospital’s urgent O-negative blood appeal with 2.1 million requests a second, so the Book a slot page times out, the donor slots board shows 0 booked and the blood bag is down to 2 units as ambulances arrive at A&E.",
    },
    hospital_laptop_theft: {
      Art: kr,
      bg: "#111b23",
      alt: "During visiting hours a man holding a bunch of flowers walks out of the open staff office on Children’s Ward 9 towards the way out, carrying a laptop tagged patient list and leaving an empty space on the desk.",
    },
    hospital_shouldering: {
      Art: ur,
      bg: "#0d171f",
      alt: "At 03:12 on the dimly lit A&E Majors ward, beside a curtained bed with a heart monitor, a nurse types her password into Patient Records on a computer on wheels while a man wearing a visitor sticker leans on the nurses’ station counter and films her keyboard on his phone.",
    },
    hospital_ransomware: {
      Art: Mr,
      bg: "#0d171f",
      alt: "A fake Browser out of date pop-up sits on a pathology lab computer whose screen is locked red with a padlock and a £4 million ransom countdown, the blood analyser shows offline and 3,412 samples wait untested.",
    },
  },
  Ot = { ...ar, ...Ji, ...Ts, ...vr, ...fs, ...Ds },
  Qt = {
    pen_testers: {
      Art: Li,
      bg: "#111b23",
      alt: "A tester in a white hat uses a laptop to probe a server rack, a magnifying glass shows a crack in one server, and a report lists the weaknesses found.",
    },
    anti_malware: {
      Art: Ti,
      bg: "#111b23",
      alt: "A green scan line sweeps across files on a screen, spots an infected one, and moves the red bug into a locked quarantine cage.",
    },
    firewall: {
      Art: Ci,
      bg: "#111b23",
      alt: "A flaming brick wall stands between the internet and a server, letting green packets through its gate while red packets bounce off.",
    },
    user_access: {
      Art: Ni,
      bg: "#242f38",
      alt: "A staff member with a green ID badge can open only the green door, while the other doors stay padlocked.",
    },
    password_policy: {
      Art: Si,
      bg: "#111b23",
      alt: "A login box shows a long hidden password with a full green strength meter, and a guessing robot is locked out after three wrong attempts.",
    },
    encryption: {
      Art: Ai,
      bg: "#111b23",
      alt: "A readable message passes through a key and padlock and comes out as scrambled symbols that an eavesdropper cannot understand.",
    },
    physical_security: {
      Art: Vi,
      bg: "#242f38",
      alt: "A locked server room door opens only with a keycard, while a CCTV camera watches the door and an alarm sits on the wall.",
    },
    staff_training: {
      Art: Hi,
      bg: "#242f38",
      alt: "A trainer points at a phishing email on a whiteboard, with the fake sender and link circled in red, while staff watch.",
    },
    account_lockout: {
      Art: Ei,
      bg: "#19232c",
      alt: "An account card is chained shut with a big padlock after three failed login attempts, a red timer reads LOCKED 30:00, and a guessing robot bounces off dazed.",
    },
    two_factor: {
      Art: _i,
      bg: "#111b23",
      alt: "A laptop login accepts the password but still asks for a six-digit code sent to the owner's phone, so a hooded thief holding only a stolen password note is stopped.",
    },
    input_validation: {
      Art: Ii,
      bg: "#0d171f",
      alt: "A form's validation gate lets the name Smith through to the database but blocks the SQL injection text ' OR 1=1; -- with a red cross.",
    },
  },
  zr = {
    protected: {
      fill: "#5bb57e",
      mark: e.jsx("path", {
        d: "M-9 1l6 6 12-13",
        fill: "none",
        stroke: "#102333",
        strokeWidth: 5,
        strokeLinecap: "round",
        strokeLinejoin: "round",
      }),
    },
    partial: {
      fill: "#e8ba61",
      mark: e.jsxs(e.Fragment, {
        children: [
          e.jsx("path", {
            d: "M0 -12v12",
            stroke: "#392a1a",
            strokeWidth: 5,
            strokeLinecap: "round",
          }),
          e.jsx("circle", { cx: 0, cy: 11, r: 3, fill: "#392a1a" }),
        ],
      }),
    },
    vulnerable: {
      fill: "#cb5651",
      mark: e.jsx("path", {
        d: "M-2 -18l6 12-8 6 6 14",
        fill: "none",
        stroke: "#5c0008",
        strokeWidth: 4,
        strokeLinecap: "round",
        strokeLinejoin: "round",
      }),
    },
  };
function Lr({ attackId: i, className: t }) {
  const s = Ot[i];
  return s
    ? e.jsx("div", {
        className: `flex items-center ${t ?? ""}`,
        style: { background: s.bg },
        children: e.jsx("svg", {
          viewBox: "0 0 400 240",
          className: "attack-scene block h-auto w-full",
          role: "img",
          "aria-label": s.alt,
          fontFamily: "Arial, Helvetica, sans-serif",
          "data-attack-scene": i,
          children: e.jsx(s.Art, {}),
        }),
      })
    : null;
}
function ke({ itemId: i, className: t, layout: s = "wide" }) {
  const l = Qt[i];
  return l
    ? s === "tall"
      ? e.jsxs("svg", {
          viewBox: "0 0 200 480",
          className: `attack-scene block h-full w-full ${t ?? ""}`,
          "aria-hidden": "true",
          focusable: "false",
          fontFamily: "Arial, Helvetica, sans-serif",
          "data-defence-art": i,
          "data-layout": "tall",
          children: [
            e.jsx("svg", {
              width: 200,
              height: 240,
              viewBox: "0 0 200 240",
              children: e.jsx(l.Art, {}),
            }),
            e.jsx("svg", {
              y: 240,
              width: 200,
              height: 240,
              viewBox: "200 0 200 240",
              children: e.jsx(l.Art, {}),
            }),
          ],
        })
      : e.jsx("svg", {
          viewBox: "0 0 400 240",
          className: `attack-scene block h-auto w-full ${t ?? ""}`,
          "aria-hidden": "true",
          focusable: "false",
          fontFamily: "Arial, Helvetica, sans-serif",
          "data-defence-art": i,
          children: e.jsx(l.Art, {}),
        })
    : null;
}
const N = { w: 360, h: 216 },
  Wr = {
    landscape: {
      w: 800,
      h: 290,
      attack: { x: 20, y: 18 },
      defence: { x: 420, y: 18 },
      bands: [{ y: 244, h: 46 }],
      attackLabel: { x: 200, y: 273 },
      defenceLabel: { x: 600, y: 273 },
      badge: { x: 400, y: 126 },
    },
    portrait: {
      w: 400,
      h: 590,
      attack: { x: 20, y: 46 },
      defence: { x: 20, y: 318 },
      bands: [
        { y: 0, h: 40 },
        { y: 540, h: 50 },
      ],
      attackLabel: { x: 200, y: 27 },
      defenceLabel: { x: 200, y: 571 },
      badge: { x: 200, y: 290 },
    },
  };
function $r({
  attackId: i,
  outcome: t,
  defenceId: s,
  defenceName: l,
  missingId: a,
  missingName: c,
  attackName: h,
  layout: o = "landscape",
}) {
  const d = Ot[i];
  if (!d) return null;
  const n = zr[t],
    x = s ?? a,
    g = x ? Qt[x] : void 0,
    w = l ?? (c ? `Missing: ${c}` : "No defence"),
    y = Wr[o],
    $ =
      t === "protected"
        ? `${l ?? "Your defence"} stopped the ${h.toLowerCase()}.`
        : t === "partial"
          ? `${l ?? "Your defence"} limited the damage from the ${h.toLowerCase()}.`
          : `Nothing stopped the ${h.toLowerCase()}.${c ? ` ${c} would have.` : ""}`;
  return e.jsxs("svg", {
    viewBox: `0 0 ${y.w} ${y.h}`,
    className: "attack-scene block h-auto w-full",
    role: "img",
    "aria-label": $,
    fontFamily: "Arial, Helvetica, sans-serif",
    "data-attack-scene": i,
    "data-attack-outcome": t,
    "data-defence": s,
    "data-layout": o,
    children: [
      e.jsx("rect", { width: y.w, height: y.h, fill: "#0d171f" }),
      e.jsxs("svg", {
        x: y.attack.x,
        y: y.attack.y,
        width: N.w,
        height: N.h,
        viewBox: "0 0 400 240",
        children: [
          e.jsx(d.Art, {}),
          t === "vulnerable"
            ? null
            : e.jsx("rect", {
                width: 400,
                height: 240,
                fill: "#0d171f",
                opacity: 0.35,
              }),
        ],
      }),
      e.jsx("rect", {
        x: y.attack.x,
        y: y.attack.y,
        width: N.w,
        height: N.h,
        rx: 10,
        fill: "none",
        stroke: "#cb5651",
        strokeOpacity: 0.6,
        strokeWidth: 2,
      }),
      g
        ? e.jsxs("svg", {
            x: y.defence.x,
            y: y.defence.y,
            width: N.w,
            height: N.h,
            viewBox: "0 0 400 240",
            children: [
              e.jsx("g", {
                opacity: t === "vulnerable" ? 0.28 : 1,
                children: e.jsx(g.Art, {}),
              }),
              t === "vulnerable"
                ? e.jsx("path", {
                    d: "M120 40 L280 200 M280 40 L120 200",
                    stroke: "#cb5651",
                    strokeWidth: 14,
                    strokeLinecap: "round",
                  })
                : null,
            ],
          })
        : e.jsx("rect", {
            x: y.defence.x,
            y: y.defence.y,
            width: N.w,
            height: N.h,
            fill: "#111b23",
          }),
      e.jsx("rect", {
        x: y.defence.x,
        y: y.defence.y,
        width: N.w,
        height: N.h,
        rx: 10,
        fill: "none",
        stroke: n.fill,
        strokeWidth: t === "vulnerable" ? 2 : 4,
        strokeDasharray: t === "vulnerable" ? "10 8" : void 0,
      }),
      y.bands.map((_) =>
        e.jsx(
          "rect",
          { x: 0, y: _.y, width: y.w, height: _.h, fill: "#0d171f" },
          _.y,
        ),
      ),
      e.jsx(r, {
        x: y.attackLabel.x,
        y: y.attackLabel.y,
        size: 17,
        anchor: "middle",
        fill: "#ffa79f",
        children: h,
      }),
      e.jsx(r, {
        x: y.defenceLabel.x,
        y: y.defenceLabel.y,
        size: 17,
        anchor: "middle",
        fill: t === "vulnerable" ? "#95a1ac" : n.fill,
        children: w,
      }),
      e.jsxs("g", {
        transform: `translate(${y.badge.x} ${y.badge.y})`,
        children: [
          e.jsx("circle", {
            r: 50,
            fill: "#0d171f",
            stroke: n.fill,
            strokeWidth: 3,
          }),
          e.jsxs("g", {
            transform: "scale(1.1)",
            children: [
              e.jsx("path", {
                d: "M0 -38 L30 -26 V0 C30 20 16 32 0 40 C-16 32 -30 20 -30 0 V-26z",
                fill: n.fill,
              }),
              n.mark,
            ],
          }),
        ],
      }),
    ],
  });
}
const Tr = B.map((i) => {
    const [t, s] = pi[i.id];
    return ri(t, s, {
      id: i.id,
      term: i.name,
      art: e.jsx(ke, { itemId: i.id }),
      tallArt: e.jsx(ke, { itemId: i.id, layout: "tall" }),
    });
  }),
  F = {
    alarm: { bg: "#480004", fg: "#cb5651", wash: "#cb5651" },
    protected: { bg: "#102333", fg: "#5bb57e", wash: "#5bb57e" },
    partial: { bg: "#392a1a", fg: "#e8ba61", wash: "#e8ba61" },
    vulnerable: { bg: "#0d171f", fg: "#cb5651", wash: "#901e21" },
  },
  kt = "M0 -20 L16 -14 V0 C16 11 8 17 0 21 C-8 17 -16 11 -16 0 V-14z";
function Ut({ mood: i, x: t, y: s, s: l = 1 }) {
  const { fg: a, bg: c } = F[i];
  return e.jsx("g", {
    transform: `translate(${t} ${s}) scale(${l})`,
    children:
      i === "alarm"
        ? e.jsxs("g", {
            className: "ma-flash",
            children: [
              e.jsx("path", {
                d: "M0 -16 L17 13 H-17Z",
                fill: a,
                stroke: a,
                strokeWidth: 3,
                strokeLinejoin: "round",
              }),
              e.jsx("rect", {
                x: -1.8,
                y: -7,
                width: 3.6,
                height: 11,
                rx: 1.8,
                fill: c,
              }),
              e.jsx("circle", { cx: 0, cy: 8, r: 2, fill: c }),
            ],
          })
        : i === "protected"
          ? e.jsxs("g", {
              children: [
                e.jsx("path", { d: kt, fill: a }),
                e.jsx("path", {
                  d: "M-7 0l5 5 9 -10",
                  fill: "none",
                  stroke: c,
                  strokeWidth: 3.4,
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                }),
              ],
            })
          : i === "partial"
            ? e.jsxs("g", {
                children: [
                  e.jsx("path", { d: kt, fill: a }),
                  e.jsx("path", {
                    d: "M0 -20 L16 -14 V0 C16 11 8 17 0 21z",
                    fill: "#0d171f",
                    opacity: 0.28,
                  }),
                  e.jsx("path", {
                    d: "M1 -20 l-4 8 5 5 -4 7",
                    fill: "none",
                    stroke: c,
                    strokeWidth: 2.4,
                    strokeLinejoin: "round",
                  }),
                ],
              })
            : e.jsxs("g", {
                children: [
                  e.jsx("path", {
                    d: "M-1 -20 L-16 -14 V0 C-16 11 -8 17 -1 21 L-4 9 L1 1 L-3 -8Z",
                    fill: a,
                  }),
                  e.jsx("g", {
                    transform: "translate(5 4) rotate(14)",
                    children: e.jsx("path", {
                      d: "M1 -20 L16 -14 V0 C16 11 8 17 1 21 L-2 9 L3 1 L-1 -8Z",
                      fill: a,
                    }),
                  }),
                  e.jsx("path", {
                    d: "M-8 26 l3 -2 2 3z M12 27 l3 -3 1 4z",
                    fill: a,
                    opacity: 0.8,
                  }),
                ],
              }),
  });
}
function Zt({ x: i, y: t, w: s, h: l }) {
  const a = i + s * 0.68,
    c = t + l * 0.32;
  return e.jsx("path", {
    d: `M${a} ${c}L${i + s * 0.98} ${t + l * 0.1}M${a} ${c}L${i + s * 0.9} ${t + l * 0.95}M${a} ${c}L${i + s * 0.35} ${t + l * 0.02}M${a} ${c}L${i + s * 0.2} ${t + l * 0.7}L${i + s * 0.04} ${t + l * 0.82}M${a} ${c}L${i + s * 0.55} ${t + l * 0.98}`,
    fill: "none",
    stroke: "#d1beaa",
    strokeWidth: 0.9,
    opacity: 0.7,
  });
}
function S({
  x: i,
  y: t,
  w: s,
  h: l,
  mood: a,
  bg: c = "#111b23",
  frame: h = "#0d171f",
  glyph: o = !0,
  children: d,
}) {
  const n = a === "calm" ? null : F[a];
  return e.jsxs("g", {
    children: [
      e.jsx("rect", {
        x: i - 2.5,
        y: t - 2.5,
        width: s + 5,
        height: l + 5,
        rx: 3,
        fill: h,
      }),
      e.jsx("rect", {
        x: i,
        y: t,
        width: s,
        height: l,
        rx: 1.5,
        fill: n ? n.bg : c,
      }),
      a === "calm" || !n
        ? d
        : e.jsxs("g", {
            children: [
              Array.from({ length: Math.floor(l / 6) }, (x, g) =>
                e.jsx(
                  "rect",
                  {
                    x: i,
                    y: t + 2 + g * 6,
                    width: s,
                    height: 1.2,
                    fill: n.fg,
                    opacity: 0.12,
                  },
                  g,
                ),
              ),
              o
                ? e.jsx(Ut, {
                    mood: a,
                    x: i + s / 2,
                    y: t + l / 2,
                    s: Math.min(s, l) / 58,
                  })
                : e.jsxs("g", {
                    fill: n.fg,
                    children: [
                      e.jsx("rect", {
                        x: i + 3,
                        y: t + l * 0.3,
                        width: s * 0.5,
                        height: 2.4,
                        rx: 1.2,
                      }),
                      e.jsx("rect", {
                        x: i + 3,
                        y: t + l * 0.55,
                        width: s * 0.7,
                        height: 2.4,
                        rx: 1.2,
                      }),
                    ],
                  }),
              a === "vulnerable" ? e.jsx(Zt, { x: i, y: t, w: s, h: l }) : null,
            ],
          }),
    ],
  });
}
function Oe({ mood: i }) {
  if (i === "calm") return null;
  const { wash: t } = F[i];
  if (i === "alarm")
    return e.jsx("g", {
      className: "ma-wash",
      children: e.jsx("rect", {
        width: 400,
        height: 240,
        fill: t,
        opacity: 0.12,
      }),
    });
  const s = i === "vulnerable" ? 0.34 : i === "partial" ? 0.12 : 0.09;
  return e.jsx("rect", { width: 400, height: 240, fill: t, opacity: s });
}
function D({ x: i, y: t, fill: s, slow: l }) {
  return e.jsx("g", {
    className: l ? "ma-blink ma-blink-slow" : "ma-blink",
    children: e.jsx("circle", { cx: i, cy: t, r: 1.8, fill: s }),
  });
}
const Cr = [-21, -150],
  Nr = [21, -150],
  ut = { elbow: [-31, -112], hand: [-8, -106], hold: !0 },
  mt = { elbow: [29, -111], hand: [31, -72] },
  Mt = { elbow: [46, -119], hand: [22, -101] };
function Sr(i, t, s) {
  switch (i) {
    case "alarm":
      return {
        l: { elbow: [-30, -122], hand: [-6, -166] },
        r: s.hipHand ? Mt : mt,
        rLayer: "front",
      };
    case "protected":
      return {
        l: { elbow: [-37, -116], hand: [-27, -141], fist: !0 },
        r: t
          ? { elbow: [38, -136], hand: [30, -172], fist: !0 }
          : { elbow: [41, -182], hand: [44, -218], fist: !0 },
        rLayer: "front",
      };
    case "partial":
      return {
        l: ut,
        r: { elbow: [47, -184], hand: [13, -171] },
        rLayer: "behind",
      };
    case "vulnerable":
      return {
        l: { elbow: [-29, -110], hand: [-27, -70] },
        r: { elbow: [44, -160], hand: [6, -184] },
        rLayer: "over",
      };
    default:
      return { l: ut, r: s.hipHand ? Mt : mt, rLayer: "front" };
  }
}
function Ar({ at: i, toward: t, skin: s, fist: l }) {
  const a = (Math.atan2(i[1] - t[1], i[0] - t[0]) * 180) / Math.PI - 90;
  return l
    ? e.jsxs("g", {
        transform: `translate(${i[0]} ${i[1]}) rotate(${a})`,
        children: [
          e.jsx("rect", {
            x: -5.6,
            y: -3.5,
            width: 11.2,
            height: 10,
            rx: 3.6,
            fill: s,
          }),
          e.jsx("path", {
            d: "M-3.5 5.2 v-2.4 M0 5.6 v-2.6 M3.5 5.2 v-2.4",
            stroke: "#0d171f",
            strokeOpacity: 0.22,
            strokeWidth: 0.9,
            strokeLinecap: "round",
          }),
        ],
      })
    : e.jsxs("g", {
        transform: `translate(${i[0]} ${i[1]}) rotate(${a})`,
        children: [
          e.jsx("ellipse", { cx: 0, cy: 2, rx: 4.4, ry: 5.8, fill: s }),
          e.jsx("g", {
            transform: "translate(3.6 -0.2) rotate(-28)",
            children: e.jsx("ellipse", {
              cx: 0,
              cy: 0,
              rx: 1.8,
              ry: 3.4,
              fill: s,
            }),
          }),
        ],
      });
}
function vt({ from: i, pose: t, look: s, holding: l }) {
  const [a, c] = t.elbow,
    [h, o] = t.hand,
    d = h - a,
    n = o - c,
    x = Math.hypot(d, n) || 1,
    g = h - (d / x) * 6,
    w = o - (n / x) * 6,
    y = i[0] + (a - i[0]) * 0.5,
    $ = i[1] + (c - i[1]) * 0.5;
  return e.jsxs("g", {
    children: [
      e.jsx("path", {
        d: `M${g} ${w}L${h} ${o}`,
        stroke: s.skin,
        strokeWidth: 7,
        strokeLinecap: "round",
      }),
      s.shortSleeves
        ? e.jsxs("g", {
            children: [
              e.jsx("path", {
                d: `M${i[0]} ${i[1]}L${a} ${c}L${g} ${w}`,
                fill: "none",
                stroke: s.skin,
                strokeWidth: 8.5,
                strokeLinecap: "round",
                strokeLinejoin: "round",
              }),
              e.jsx("path", {
                d: `M${i[0]} ${i[1]}L${y} ${$}`,
                stroke: s.sleeve,
                strokeWidth: 12.5,
                strokeLinecap: "round",
              }),
            ],
          })
        : e.jsx("path", {
            d: `M${i[0]} ${i[1]}L${a} ${c}L${g} ${w}`,
            fill: "none",
            stroke: s.sleeve,
            strokeWidth: 10.5,
            strokeLinecap: "round",
            strokeLinejoin: "round",
          }),
      l,
      e.jsx(Ar, { at: t.hand, toward: t.elbow, skin: s.skin, fist: t.fist }),
    ],
  });
}
function pe({
  cx: i,
  open: t = 1,
  iris: s = 1.25,
  dx: l = 0,
  dy: a = 0,
  color: c,
  ink: h,
}) {
  return e.jsxs("g", {
    children: [
      e.jsx("path", {
        d: `M${i - 3} 0Q${i} ${-2.7 * t} ${i + 3} 0Q${i} ${2.2 * t} ${i - 3} 0Z`,
        fill: "#e3e9ee",
      }),
      e.jsx("circle", { cx: i + l, cy: a, r: s, fill: c }),
      e.jsx("path", {
        d: `M${i - 3.4} 0.3Q${i} ${-3 * t} ${i + 3.4} 0.3`,
        fill: "none",
        stroke: h,
        strokeWidth: 1.05,
        strokeLinecap: "round",
      }),
    ],
  });
}
const zt = {
  calm: "M-8.6 -5.4 Q-5.6 -7.2 -2.6 -6",
  alarm: "M-8.6 -6.4 Q-5.6 -8.4 -2.6 -7",
  protected: "M-8.6 -7 Q-5.6 -9.4 -2.6 -7.8",
  partial: "M-8.6 -5.4 Q-5.2 -6.6 -2.6 -8.2",
  vulnerable: "M-8.6 -4.6 Q-5.2 -5.4 -2.6 -8",
};
function Vr({ look: i, mood: t }) {
  const s = "#111b23",
    l = [-5, 5].map((c) => {
      switch (t) {
        case "alarm":
          return e.jsx(
            pe,
            { cx: c, open: 1.15, dx: 1, dy: -0.3, color: i.eye, ink: s },
            c,
          );
        case "protected":
          return e.jsx(
            "path",
            {
              d: `M${c - 3.2} 0.8Q${c} -2.6 ${c + 3.2} 0.8`,
              fill: "none",
              stroke: s,
              strokeWidth: 1.5,
              strokeLinecap: "round",
            },
            c,
          );
        case "partial":
          return e.jsx(
            pe,
            { cx: c, open: 0.75, dx: (c < 0, 1), color: i.eye, ink: s },
            c,
          );
        case "vulnerable":
          return e.jsxs(
            "g",
            {
              children: [
                e.jsx(pe, { cx: c, open: 0.9, dy: 0.5, color: i.eye, ink: s }),
                e.jsx("path", {
                  d: `M${c - 3.5} 0.2Q${c} -3.2 ${c + 3.5} 0.2 Q${c} -0.6 ${c - 3.5} 0.2Z`,
                  fill: i.skin,
                }),
                e.jsx("path", {
                  d: `M${c - 3.4} 0.2Q${c} -0.5 ${c + 3.4} 0.2`,
                  fill: "none",
                  stroke: s,
                  strokeWidth: 1.1,
                  strokeLinecap: "round",
                }),
              ],
            },
            c,
          );
        default:
          return e.jsx(pe, { cx: c, color: i.eye, ink: s }, c);
      }
    });
  let a;
  switch (t) {
    case "alarm":
      a = e.jsx("ellipse", {
        cx: 0.6,
        cy: 10.6,
        rx: 1.8,
        ry: 2,
        fill: "#5c0008",
      });
      break;
    case "protected":
      a = e.jsxs("g", {
        children: [
          e.jsx("path", {
            d: "M-5.8 8 Q0 9.2 5.8 8 Q5.2 14.8 0 14.8 Q-5.2 14.8 -5.8 8Z",
            fill: "#5c0008",
          }),
          e.jsx("path", {
            d: "M-5 8.4 Q0 9.4 5 8.4 L4.5 10.1 Q0 10.8 -4.5 10.1Z",
            fill: "#e3e9ee",
          }),
          e.jsx("ellipse", {
            cx: 0,
            cy: 13,
            rx: 2.6,
            ry: 1.2,
            fill: "#ee766f",
          }),
        ],
      });
      break;
    case "partial":
      a = e.jsxs("g", {
        children: [
          e.jsx("path", {
            d: "M-5.2 9.4 Q0 8.2 5.2 9.4 Q5.4 12.4 0 12.6 Q-5.4 12.4 -5.2 9.4Z",
            fill: "#e3e9ee",
            stroke: i.mouth,
            strokeWidth: 0.9,
          }),
          e.jsx("path", {
            d: "M-5 10.9 Q0 10.4 5 10.9 M-2.4 9 V12.4 M1 8.8 V12.5",
            fill: "none",
            stroke: i.mouth,
            strokeWidth: 0.6,
            opacity: 0.6,
          }),
        ],
      });
      break;
    case "vulnerable":
      a = e.jsx("path", {
        d: "M-4.2 12.2 Q0 8.6 4.2 12.2",
        fill: "none",
        stroke: i.mouth,
        strokeWidth: 1.5,
        strokeLinecap: "round",
      });
      break;
    default:
      a = e.jsx("path", {
        d: "M-4.3 8.8 Q0 12.2 4.3 8.8",
        fill: "none",
        stroke: i.mouth,
        strokeWidth: 1.4,
        strokeLinecap: "round",
      });
  }
  return e.jsxs("g", {
    children: [
      e.jsx("g", { className: "ma-eyes", children: l }),
      e.jsxs("g", {
        fill: "none",
        stroke: i.brow,
        strokeWidth: 1.9,
        strokeLinecap: "round",
        children: [
          e.jsx("path", { d: zt[t] }),
          e.jsx("g", {
            transform:
              t === "alarm" ? "translate(0 -1.8) scale(-1 1)" : "scale(-1 1)",
            children: e.jsx("path", { d: zt[t] }),
          }),
        ],
      }),
      e.jsx("path", {
        d: "M0.4 1 Q2 5.4 -0.6 6.4",
        fill: "none",
        stroke: i.shade,
        strokeWidth: 1.2,
        strokeLinecap: "round",
      }),
      a,
      t === "partial"
        ? e.jsx("path", {
            d: "M15.5 -9 Q18.5 -4.6 15.5 -2.6 Q12.5 -4.6 15.5 -9Z",
            fill: "#8ecbee",
          })
        : null,
    ],
  });
}
const Hr =
  "M-13.5 -2 C-13.5 -14 -8 -16.5 0 -16.5 C8 -16.5 13.5 -14 13.5 -2 C13.5 9 7 16.5 0 16.5 C-7 16.5 -13.5 9 -13.5 -2Z";
function Pr({ look: i }) {
  return e.jsxs("g", {
    children: [
      e.jsx("rect", { x: -5.5, y: -172, width: 11, height: 22, fill: i.skin }),
      e.jsx("path", {
        d: "M-5.5 -166 Q0 -161 5.5 -166 V-160 Q0 -157 -5.5 -160Z",
        fill: i.shade,
      }),
      e.jsx("path", {
        d: "M-7 -158 L-19 -155 Q-25.5 -153 -25 -145 L-20.5 -100 H20.5 L25 -145 Q25.5 -153 19 -155 L7 -158 Q0 -154 -7 -158Z",
        fill: i.top,
      }),
      i.torso,
    ],
  });
}
function Qe({ look: i, mood: t, badge: s }) {
  const l = Sr(t, s, i),
    a = t === "vulnerable",
    c = a
      ? "translate(1.5 -177) rotate(9)"
      : t === "alarm"
        ? "translate(0 -182) rotate(-6)"
        : "translate(0 -182)",
    h = { transformOrigin: "0px -166px" },
    o = e.jsx(vt, { from: Nr, pose: l.r, look: i }),
    d = e.jsx(vt, {
      from: Cr,
      pose: l.l,
      look: i,
      holding: l.l.hold
        ? e.jsx("g", {
            transform: `translate(${l.l.hand[0]} ${l.l.hand[1]})`,
            children: i.prop,
          })
        : null,
    });
  return e.jsxs("g", {
    className: "ma-figure",
    style: { transformOrigin: "0px 0px" },
    children: [
      e.jsx("ellipse", {
        cx: 0,
        cy: 0,
        rx: 34,
        ry: 4,
        fill: "#0d171f",
        opacity: 0.22,
      }),
      i.legs,
      e.jsxs("g", {
        transform: a ? "translate(0 6)" : void 0,
        children: [
          i.hairBack
            ? e.jsx("g", {
                className: "ma-head",
                style: h,
                children: e.jsx("g", { transform: c, children: i.hairBack }),
              })
            : null,
          l.rLayer === "behind" ? o : null,
          e.jsx(Pr, { look: i }),
          l.rLayer === "front" ? o : null,
          e.jsx("g", {
            className: "ma-head",
            style: h,
            children: e.jsxs("g", {
              transform: c,
              children: [
                e.jsx("ellipse", {
                  cx: -13.4,
                  cy: 1,
                  rx: 2.6,
                  ry: 4,
                  fill: i.skin,
                }),
                e.jsx("ellipse", {
                  cx: 13.4,
                  cy: 1,
                  rx: 2.6,
                  ry: 4,
                  fill: i.skin,
                }),
                e.jsx("ellipse", {
                  cx: -13.6,
                  cy: 1.2,
                  rx: 1.2,
                  ry: 2.2,
                  fill: i.shade,
                }),
                e.jsx("ellipse", {
                  cx: 13.6,
                  cy: 1.2,
                  rx: 1.2,
                  ry: 2.2,
                  fill: i.shade,
                }),
                e.jsx("path", { d: Hr, fill: i.skin }),
                i.faceUnder,
                e.jsx(Vr, { look: i, mood: t }),
                i.faceOver,
                i.hairFront,
              ],
            }),
          }),
          d,
          l.rLayer === "over" ? o : null,
        ],
      }),
    ],
  });
}
function re({ fill: i, shoe: t, wide: s }) {
  const l = s ? 3 : 0;
  return e.jsxs("g", {
    children: [
      e.jsx("path", {
        d: `M-20.5 -102 H20.5 L21.5 -84 L${17 + l} -5 H${4 - l * 0.3} L1.4 -90 H-1.4 L${-4 + l * 0.3} -5 H${-17 - l} L-21.5 -84Z`,
        fill: i,
      }),
      e.jsx("path", {
        d: "M0 -100 V-90",
        stroke: "#0d171f",
        strokeOpacity: 0.2,
        strokeWidth: 1,
      }),
      e.jsx("path", {
        d: "M-21 -1 Q-21 -8 -15 -8 H-5 Q-3 -8 -3 -4 V0.5 H-20Q-21 0.5 -21 -1Z",
        fill: t,
      }),
      e.jsx("path", {
        d: "M21 -1 Q21 -8 15 -8 H5 Q3 -8 3 -4 V0.5 H20Q21 0.5 21 -1Z",
        fill: t,
      }),
    ],
  });
}
const Er = {
    skin: "#b07a52",
    shade: "#8f5d3b",
    brow: "#1c1210",
    eye: "#2b1a12",
    mouth: "#3b1d14",
    hairBack: e.jsx("path", {
      d: "M-15 -4 C-17 -21 17 -21 15 -4 L14.6 8 Q0 12 -14.6 8Z",
      fill: "#0d171f",
    }),
    hairFront: e.jsxs("g", {
      children: [
        e.jsx("path", {
          d: "M-14.6 7 C-16.4 -12 -9 -19.8 0 -19.8 C9 -19.8 16.4 -12 14.6 7 C13.2 0 12.8 -6 9.2 -9.6 C6.4 -12.2 2.4 -12.8 0.6 -13.4 L0 -11.2 C-2 -12.8 -7 -12.2 -10 -8.8 C-12.6 -5.6 -13.2 0 -14.6 7Z",
          fill: "#17110e",
        }),
        [0, 1, 2, 3, 4].map((i) =>
          e.jsx(
            "ellipse",
            {
              cx: -13.5 - i * 0.6,
              cy: 13 + i * 6.2,
              rx: 4.2 - i * 0.25,
              ry: 3.8,
              fill: "#17110e",
              stroke: "#2c2018",
              strokeWidth: 0.7,
            },
            i,
          ),
        ),
        e.jsx("rect", {
          x: -18.4,
          y: 42,
          width: 6,
          height: 2.6,
          rx: 1.3,
          fill: "#326e8e",
        }),
        e.jsx("path", { d: "M-15.6 44 l-1.6 6 h3.4z", fill: "#17110e" }),
        e.jsx("circle", { cx: 13.7, cy: 6.4, r: 1.1, fill: "#e8ba61" }),
      ],
    }),
    top: "#00425f",
    sleeve: "#00425f",
    torso: e.jsxs("g", {
      children: [
        e.jsx("path", {
          d: "M-8 -159 L0 -151 L8 -159 L8 -165 Q0 -160 -8 -165Z",
          fill: "#175675",
        }),
        e.jsx("path", {
          d: "M0 -151 V-132",
          stroke: "#8ecbee",
          strokeWidth: 1.2,
        }),
        e.jsx("rect", {
          x: -1.2,
          y: -136,
          width: 2.4,
          height: 4,
          rx: 1,
          fill: "#bac3cb",
        }),
        e.jsx("path", {
          d: "M-20.5 -104 H20.5 V-100 H-20.5Z",
          fill: "#003249",
        }),
        e.jsx("path", {
          d: "M-6 -158 L-4 -126 M6 -158 L4 -126",
          stroke: "#4e89aa",
          strokeWidth: 1.8,
          fill: "none",
        }),
        e.jsx("rect", {
          x: -7,
          y: -127,
          width: 14,
          height: 18,
          rx: 1.6,
          fill: "#e3e9ee",
        }),
        e.jsx("rect", { x: -5, y: -124, width: 5, height: 6, fill: "#95a1ac" }),
        e.jsx("rect", {
          x: 1,
          y: -124,
          width: 4,
          height: 1.6,
          fill: "#00425f",
        }),
        e.jsx("rect", {
          x: 1,
          y: -121,
          width: 3.4,
          height: 1.2,
          fill: "#95a1ac",
        }),
        e.jsx("rect", {
          x: -5,
          y: -115,
          width: 10,
          height: 2.4,
          fill: "#326e8e",
        }),
      ],
    }),
    legs: e.jsx(re, { fill: "#111b23", shoe: "#0d171f" }),
    prop: e.jsxs("g", {
      transform: "translate(5 -6) rotate(-8)",
      children: [
        e.jsx("rect", {
          x: -11,
          y: -8,
          width: 22,
          height: 15,
          rx: 2,
          fill: "#111b23",
        }),
        e.jsx("rect", {
          x: -9,
          y: -6,
          width: 18,
          height: 11,
          rx: 1,
          fill: "#326e8e",
        }),
        e.jsx("circle", { cx: -3, cy: -1, r: 1.4, fill: "#8ecbee" }),
        e.jsx("circle", { cx: 3, cy: 2, r: 1.4, fill: "#ee766f" }),
      ],
    }),
  },
  _r = {
    skin: "#6b4128",
    shade: "#4e2d1b",
    brow: "#0d0806",
    eye: "#140b07",
    mouth: "#2a140b",
    hairFront: e.jsx("path", {
      d: "M-13.8 -3 C-14.6 -15 -7 -18.8 0 -18.8 C7 -18.8 14.6 -15 13.8 -3 C12.6 -9.4 8.4 -11.6 0 -11.6 C-8.4 -11.6 -12.6 -9.4 -13.8 -3Z",
      fill: "#120c09",
    }),
    faceUnder: e.jsxs("g", {
      fill: "#160e0a",
      children: [
        e.jsx("path", {
          d: "M-13.3 1 C-12.8 11 -7 16.8 0 16.8 C7 16.8 12.8 11 13.3 1 L11.4 1.6 C10.8 9 6.6 13.4 0 13.6 C-6.6 13.4 -10.8 9 -11.4 1.6Z",
        }),
        e.jsx("path", { d: "M-5.6 7.4 Q0 4.6 5.6 7.4 Q0 6.6 -5.6 7.4Z" }),
        e.jsx("path", { d: "M-2.6 13.6 Q0 15 2.6 13.6 L2 16.6 H-2Z" }),
      ],
    }),
    top: "#4e89aa",
    sleeve: "#4e89aa",
    shortSleeves: !0,
    torso: e.jsxs("g", {
      children: [
        e.jsx("path", {
          d: "M-8 -159 L-1 -149 L-3 -146 L-11 -155Z M8 -159 L1 -149 L3 -146 L11 -155Z",
          fill: "#326e8e",
        }),
        e.jsx("path", {
          d: "M0 -150 V-136",
          stroke: "#326e8e",
          strokeWidth: 2.4,
        }),
        e.jsx("circle", { cx: 0, cy: -145, r: 0.9, fill: "#bac3cb" }),
        e.jsx("circle", { cx: 0, cy: -139, r: 0.9, fill: "#bac3cb" }),
        e.jsx("path", {
          d: "M-20.5 -104 H20.5 V-100 H-20.5Z",
          fill: "#326e8e",
        }),
        e.jsx("rect", {
          x: -17,
          y: -140,
          width: 10,
          height: 1.4,
          fill: "#326e8e",
        }),
        e.jsx("rect", {
          x: -15,
          y: -142,
          width: 4,
          height: 4,
          rx: 0.8,
          fill: "#95a1ac",
        }),
        e.jsx("rect", {
          x: -18,
          y: -138,
          width: 10,
          height: 14,
          rx: 1.4,
          fill: "#e3e9ee",
        }),
        e.jsx("rect", {
          x: -16.4,
          y: -136,
          width: 4,
          height: 5,
          fill: "#5c6873",
        }),
        e.jsx("rect", {
          x: -18,
          y: -128,
          width: 10,
          height: 2.4,
          fill: "#6ca8ca",
        }),
      ],
    }),
    legs: e.jsx(re, { fill: "#00425f", shoe: "#493a28" }),
    prop: e.jsxs("g", {
      transform: "translate(5 -7)",
      children: [
        e.jsx("path", { d: "M-5 -6 H5 L4 7 H-4Z", fill: "#e3e9ee" }),
        e.jsx("rect", {
          x: -5.4,
          y: -1,
          width: 10.6,
          height: 4,
          fill: "#6ca8ca",
        }),
        e.jsx("rect", {
          x: -5.6,
          y: -8,
          width: 11.2,
          height: 2.6,
          rx: 1,
          fill: "#bac3cb",
        }),
      ],
    }),
  },
  Ir = {
    skin: "#f1cfb4",
    shade: "#d9a98a",
    brow: "#8a8f98",
    eye: "#3f5a73",
    mouth: "#7a3b33",
    hairBack: e.jsx("path", {
      d: "M-16.4 -4 C-17.4 -21 17.4 -21 16.4 -4 L17.2 13 Q12 15.6 9 13 L-9 13 Q-12 15.6 -17.2 13Z",
      fill: "#b8bfc8",
    }),
    hairFront: e.jsxs("g", {
      children: [
        e.jsx("path", {
          d: "M-15.8 11 C-17.6 -10 -9.4 -20.4 1 -20 C10.6 -19.6 17 -11 15.8 11 C14.2 4 14.2 -3 11.2 -7 C7.4 -11.2 0 -10 -6.4 -12 C-10 -9.4 -12.2 -4.4 -13.2 1.8 C-13.8 5.2 -14.6 8.4 -15.8 11Z",
          fill: "#c9cfd6",
        }),
        e.jsx("path", {
          d: "M-6.4 -12 C-2 -16 6 -17 11 -13 M-11 -6 C-12.6 -1 -13.4 5 -14.6 9",
          fill: "none",
          stroke: "#9aa3ad",
          strokeWidth: 1,
        }),
      ],
    }),
    faceUnder: e.jsx("path", {
      d: "M-7.6 8.4 q-1 2.4 0.4 4.2 M7.6 8.4 q1 2.4 -0.4 4.2 M-9.8 -1.6 l-1.8 -0.8 M9.8 -1.6 l1.8 -0.8",
      fill: "none",
      stroke: "#d4a08a",
      strokeWidth: 0.8,
      strokeLinecap: "round",
    }),
    faceOver: e.jsxs("g", {
      fill: "none",
      stroke: "#901e21",
      strokeWidth: 1,
      children: [
        e.jsx("rect", {
          x: -9.4,
          y: -3,
          width: 8.6,
          height: 5.8,
          rx: 2.4,
          fill: "#e3e9ee",
          fillOpacity: 0.12,
        }),
        e.jsx("rect", {
          x: 0.8,
          y: -3,
          width: 8.6,
          height: 5.8,
          rx: 2.4,
          fill: "#e3e9ee",
          fillOpacity: 0.12,
        }),
        e.jsx("path", {
          d: "M-0.8 -0.6 Q0 -1.6 0.8 -0.6 M-9.4 -1 L-13 -2 M9.4 -1 L13 -2",
        }),
      ],
    }),
    top: "#00425f",
    sleeve: "#00425f",
    torso: e.jsxs("g", {
      children: [
        e.jsx("path", {
          d: "M-7 -158 L0 -146 L7 -158 Q0 -154 -7 -158Z",
          fill: "#e3e9ee",
        }),
        e.jsx("path", {
          d: "M-7.6 -158 L-1.5 -123 L-13 -140 L-10 -146 L-14 -148Z",
          fill: "#242f38",
        }),
        e.jsx("path", {
          d: "M7.6 -158 L1.5 -123 L13 -140 L10 -146 L14 -148Z",
          fill: "#242f38",
        }),
        e.jsx("path", { d: "M-2 -146 L0 -123 L2 -146 Z", fill: "#e3e9ee" }),
        e.jsx("path", {
          d: "M-5.4 -156 Q0 -148 5.4 -156",
          fill: "none",
          stroke: "#e3e9ee",
          strokeWidth: 1.6,
          strokeDasharray: "0.1 2.4",
          strokeLinecap: "round",
        }),
        e.jsx("circle", { cx: -12, cy: -138, r: 2, fill: "#c4973c" }),
        e.jsx("circle", { cx: 0, cy: -116, r: 1, fill: "#242f38" }),
        e.jsx("circle", { cx: 0, cy: -108, r: 1, fill: "#242f38" }),
      ],
    }),
    legs: e.jsxs("g", {
      children: [
        e.jsx("path", {
          d: "M-14 -50 L-12 -6 H-5 L-4 -50Z M14 -50 L12 -6 H5 L4 -50Z",
          fill: "#ae9c88",
        }),
        e.jsx("path", {
          d: "M-21 -102 H21 L23 -46 Q0 -42 -23 -46Z",
          fill: "#00425f",
        }),
        e.jsx("path", {
          d: "M0 -60 V-44",
          stroke: "#242f38",
          strokeWidth: 1.2,
        }),
        e.jsx("path", {
          d: "M-17 -1 Q-17 -8 -11 -8 H-5 Q-3 -8 -3 -4 V0.5 H-16Z",
          fill: "#901e21",
        }),
        e.jsx("path", {
          d: "M17 -1 Q17 -8 11 -8 H5 Q3 -8 3 -4 V0.5 H16Z",
          fill: "#901e21",
        }),
        e.jsx("path", {
          d: "M-5 0.5 V-3 M5 0.5 V-3",
          stroke: "#5c0008",
          strokeWidth: 2,
        }),
      ],
    }),
    prop: e.jsxs("g", {
      transform: "translate(6 -7) rotate(-6)",
      children: [
        e.jsx("rect", {
          x: -12,
          y: -10,
          width: 22,
          height: 17,
          rx: 1.4,
          fill: "#901e21",
        }),
        e.jsx("rect", {
          x: -10,
          y: -12,
          width: 20,
          height: 17,
          rx: 1,
          fill: "#e3e9ee",
        }),
        e.jsx("path", {
          d: "M-7 -7 h12 M-7 -4 h14 M-7 -1 h9",
          stroke: "#95a1ac",
          strokeWidth: 1,
        }),
      ],
    }),
  },
  qr = {
    skin: "#f0c8a0",
    shade: "#d4a37a",
    brow: "#111111",
    eye: "#1f140e",
    mouth: "#6b2a2a",
    hairBack: e.jsx("path", {
      d: "M-16.4 -6 C-16.4 -22 16.4 -22 16.4 -6 L17.4 13.6 L-17.4 13.6Z",
      fill: "#0f0f12",
    }),
    hairFront: e.jsxs("g", {
      children: [
        e.jsx("path", {
          d: "M-16 13.6 L-16 -4 C-16 -16.6 -8 -20.6 0 -20.6 C8 -20.6 16 -16.6 16 -4 L16 13.6 L12.6 13.6 L12.2 -1 L11.6 -6.4 L-11.6 -6.4 L-12.2 -1 L-12.6 13.6Z",
          fill: "#0f0f12",
        }),
        e.jsx("path", {
          d: "M14.2 13.4 L14.2 -4 C14.2 -10 12.4 -14.6 8.6 -17.6",
          fill: "none",
          stroke: "#ee766f",
          strokeWidth: 3,
          strokeLinecap: "round",
        }),
        e.jsx("path", {
          d: "M-11.6 -6.4 C-6 -8 6 -8 11.6 -6.4",
          fill: "none",
          stroke: "#2a2a30",
          strokeWidth: 0.8,
        }),
      ],
    }),
    faceOver: e.jsx("path", {
      d: "M-8 -0.4 l-2.4 -1.4 M8 -0.4 l2.4 -1.4",
      stroke: "#0d171f",
      strokeWidth: 1.1,
      strokeLinecap: "round",
    }),
    top: "#7ed99f",
    sleeve: "#7ed99f",
    hipHand: !0,
    torso: e.jsxs("g", {
      children: [
        e.jsx("path", {
          d: "M-8 -158 L-8 -100 H8 L8 -158 Q0 -154 -8 -158Z",
          fill: "#e3e9ee",
        }),
        e.jsx("circle", { cx: 0, cy: -134, r: 5, fill: "#ee766f" }),
        e.jsx("circle", { cx: 0, cy: -134, r: 2.2, fill: "#e3e9ee" }),
        e.jsx("path", {
          d: "M-4 -124 h8",
          stroke: "#0d171f",
          strokeWidth: 1.4,
        }),
        e.jsx("path", {
          d: "M-8 -158 L-10 -100 M8 -158 L10 -100",
          stroke: "#5bb57e",
          strokeWidth: 3,
        }),
        e.jsx("path", {
          d: "M-21 -105 H21 L20.6 -99 H-20.6Z",
          fill: "#137a47",
        }),
        e.jsx("path", {
          d: "M-9 -160 Q0 -153 9 -160 L9 -156 Q0 -150 -9 -156Z",
          fill: "#137a47",
        }),
        e.jsx("rect", {
          x: -19,
          y: -128,
          width: 7,
          height: 8,
          rx: 1.4,
          fill: "#5bb57e",
        }),
      ],
    }),
    legs: e.jsxs("g", {
      children: [
        e.jsx(re, { fill: "#46515b", shoe: "#e3e9ee", wide: !0 }),
        e.jsx("rect", {
          x: -21.5,
          y: -60,
          width: 9,
          height: 11,
          rx: 1.6,
          fill: "#333e48",
        }),
        e.jsx("rect", {
          x: 12.5,
          y: -60,
          width: 9,
          height: 11,
          rx: 1.6,
          fill: "#333e48",
        }),
        e.jsx("path", {
          d: "M-24 -2.6 H-1 M24 -2.6 H1",
          stroke: "#ee766f",
          strokeWidth: 1.6,
        }),
      ],
    }),
    prop: e.jsxs("g", {
      transform: "translate(4 -9) rotate(-10)",
      children: [
        e.jsx("rect", {
          x: -4.8,
          y: -9,
          width: 9.6,
          height: 17,
          rx: 2,
          fill: "#ee766f",
        }),
        e.jsx("rect", {
          x: -3.6,
          y: -7.4,
          width: 7.2,
          height: 13.4,
          rx: 1,
          fill: "#111b23",
        }),
        e.jsx("rect", {
          x: -2.4,
          y: -5,
          width: 4.8,
          height: 2.4,
          fill: "#7ed99f",
        }),
      ],
    }),
  },
  Dr = {
    skin: "#a86d43",
    shade: "#87522f",
    brow: "#120c0a",
    eye: "#24150d",
    mouth: "#3a1a10",
    hairFront: e.jsxs("g", {
      children: [
        e.jsx("path", {
          d: "M-14 -2 C-15.2 -16 -7 -21.4 2 -21 C10.6 -20.6 15.6 -15 14 -2 C13 -9 11 -12.4 6 -13.4 C1.6 -14 -4 -14.6 -8.2 -11.4 C-11.6 -9 -13 -5.6 -14 -2Z",
          fill: "#16100d",
        }),
        e.jsx("path", {
          d: "M-6 -14.2 C-4 -17.4 1 -19 6 -18.4",
          fill: "none",
          stroke: "#3b2a20",
          strokeWidth: 0.9,
        }),
      ],
    }),
    faceUnder: e.jsx("path", {
      d: "M-13 3 C-12.4 11.6 -7 16.4 0 16.4 C7 16.4 12.4 11.6 13 3 C11 10 7 12 0 12.4 C-7 12 -11 10 -13 3Z",
      fill: "#3b2418",
      opacity: 0.35,
    }),
    top: "#003249",
    sleeve: "#003249",
    hipHand: !0,
    torso: e.jsxs("g", {
      children: [
        e.jsx("path", {
          d: "M-7.4 -158 L0 -141 L7.4 -158 Q0 -154 -7.4 -158Z",
          fill: "#e3e9ee",
        }),
        e.jsx("path", {
          d: "M-7.4 -160 L-3 -149 L-9 -150Z M7.4 -160 L3 -149 L9 -150Z",
          fill: "#bac3cb",
        }),
        e.jsx("path", {
          d: "M-8 -159 L-1.4 -116 L-14 -136 L-10.6 -143 L-15.4 -146Z",
          fill: "#002538",
        }),
        e.jsx("path", {
          d: "M8 -159 L1.4 -116 L14 -136 L10.6 -143 L15.4 -146Z",
          fill: "#002538",
        }),
        e.jsx("path", {
          d: "M-2.6 -141 L0 -116 L2.6 -141 L0 -141Z",
          fill: "#e3e9ee",
        }),
        e.jsx("path", { d: "M10 -138 l6 -1 -1.4 3z", fill: "#e8ba61" }),
        e.jsx("circle", { cx: 0, cy: -110, r: 1.1, fill: "#0d171f" }),
      ],
    }),
    legs: e.jsx(re, { fill: "#003249", shoe: "#493a28" }),
    prop: e.jsxs("g", {
      transform: "translate(5 -8)",
      children: [
        e.jsx("path", { d: "M-4.6 -7 H4.6 L3.6 7 H-3.6Z", fill: "#d1beaa" }),
        e.jsx("rect", {
          x: -5,
          y: -9.4,
          width: 10,
          height: 3,
          rx: 1,
          fill: "#242f38",
        }),
        e.jsx("rect", {
          x: -4.4,
          y: -1.4,
          width: 8.8,
          height: 4.4,
          fill: "#901e21",
        }),
      ],
    }),
  },
  Br = {
    skin: "#c08a5c",
    shade: "#9c6a42",
    brow: "#1d120b",
    eye: "#2a1a0f",
    mouth: "#4a2414",
    hairBack: e.jsx("path", {
      d: "M-17 -10 C-18 4 -14 16 -10 18 L10 18 C14 16 18 4 17 -10 Z",
      fill: "#ac3a38",
    }),
    hairFront: e.jsxs("g", {
      fill: "#24170e",
      children: [
        e.jsx("path", {
          d: "M-13.8 -3 C-14.6 -10 -13 -14 -11 -15 L11 -15 C13 -14 14.6 -10 13.8 -3 C12.8 -8 11 -10 9 -10.6 L-9 -10.6 C-11 -10 -12.8 -8 -13.8 -3Z",
        }),
        [
          [-10, -16, 4.4],
          [-4.6, -18.6, 4.8],
          [1.4, -19.2, 4.8],
          [7, -17.8, 4.6],
          [11, -14.6, 3.6],
          [-12.4, -12, 3.4],
          [-7.4, -14.6, 4],
          [4, -14.8, 4],
          [-1.6, -15.2, 4],
        ].map(([i, t, s]) =>
          e.jsx("circle", { cx: i, cy: t, r: s }, `${i}-${t}`),
        ),
      ],
    }),
    top: "#ee766f",
    sleeve: "#ee766f",
    torso: e.jsxs("g", {
      children: [
        e.jsx("path", {
          d: "M-14 -157 Q-15 -168 -10 -168 Q0 -160 10 -168 Q15 -168 14 -157 Q0 -150 -14 -157Z",
          fill: "#cb5651",
        }),
        e.jsx("path", {
          d: "M-4 -156 V-138 M4 -156 V-138",
          stroke: "#e3e9ee",
          strokeWidth: 1.4,
          strokeLinecap: "round",
        }),
        e.jsx("path", { d: "M-13 -116 H13 L10 -104 H-10Z", fill: "#cb5651" }),
        e.jsx("path", {
          d: "M-20.5 -104 H20.5 V-100 H-20.5Z",
          fill: "#ac3a38",
        }),
        e.jsx("path", {
          d: "M-12 -158 Q0 -150 12 -158",
          fill: "none",
          stroke: "#111b23",
          strokeWidth: 2.4,
        }),
        e.jsx("rect", {
          x: -17,
          y: -164,
          width: 8,
          height: 11,
          rx: 3.6,
          fill: "#111b23",
        }),
        e.jsx("rect", {
          x: 9,
          y: -164,
          width: 8,
          height: 11,
          rx: 3.6,
          fill: "#111b23",
        }),
        e.jsx("rect", {
          x: -15.6,
          y: -162,
          width: 3,
          height: 7,
          rx: 1.5,
          fill: "#8ecbee",
        }),
        e.jsx("rect", {
          x: 12.6,
          y: -162,
          width: 3,
          height: 7,
          rx: 1.5,
          fill: "#8ecbee",
        }),
      ],
    }),
    legs: e.jsxs("g", {
      children: [
        e.jsx(re, { fill: "#242f38", shoe: "#e3e9ee" }),
        e.jsx("path", {
          d: "M-19 -12 H-3 M3 -12 H19",
          stroke: "#111b23",
          strokeWidth: 3,
        }),
        e.jsx("path", {
          d: "M-22 -3 H-2 M2 -3 H22",
          stroke: "#8ecbee",
          strokeWidth: 1.6,
        }),
      ],
    }),
    prop: e.jsxs("g", {
      transform: "translate(4 -9) rotate(-10)",
      children: [
        e.jsx("rect", {
          x: -5,
          y: -9,
          width: 10,
          height: 18,
          rx: 2,
          fill: "#111b23",
        }),
        e.jsx("rect", {
          x: -4,
          y: -7.6,
          width: 8,
          height: 14.6,
          rx: 1,
          fill: "#6e8498",
        }),
        e.jsx("path", { d: "M-1.4 -2.4 L2.4 0 L-1.4 2.4Z", fill: "#e3e9ee" }),
      ],
    }),
  },
  Yt = {
    police: Er,
    hospital: _r,
    civil: Ir,
    threadline: qr,
    law: Dr,
    vidora: Br,
  };
function Rr({ mood: i }) {
  const t = [
    [214, 70],
    [252, 116],
    [300, 62],
    [338, 104],
    [370, 74],
    [280, 92],
  ];
  return e.jsxs("g", {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#002538" }),
      e.jsx("rect", { width: 400, height: 14, fill: "#001d2d" }),
      [30, 140, 250, 350].map((s) =>
        e.jsx(
          "rect",
          {
            x: s,
            y: 5,
            width: 44,
            height: 3,
            rx: 1.5,
            fill: "#bac3cb",
            opacity: 0.5,
          },
          s,
        ),
      ),
      Array.from({ length: 50 }, (s, l) =>
        e.jsxs(
          "g",
          {
            children: [
              e.jsx("rect", {
                x: l * 8,
                y: 18,
                width: 8,
                height: 8,
                fill: l % 2 ? "#bac3cb" : "#326e8e",
              }),
              e.jsx("rect", {
                x: l * 8,
                y: 26,
                width: 8,
                height: 8,
                fill: l % 2 ? "#326e8e" : "#bac3cb",
              }),
            ],
          },
          l,
        ),
      ),
      e.jsx("rect", { y: 198, width: 400, height: 42, fill: "#0d171f" }),
      e.jsx("path", {
        d: "M0 212 H400 M0 228 H400",
        stroke: "#002538",
        strokeWidth: 1.4,
      }),
      e.jsx("rect", {
        x: 8,
        y: 50,
        width: 66,
        height: 150,
        rx: 2,
        fill: "#46515b",
      }),
      e.jsx("rect", {
        x: 13,
        y: 56,
        width: 56,
        height: 138,
        rx: 2,
        fill: "#5c6873",
      }),
      e.jsx("rect", { x: 13, y: 70, width: 56, height: 6, fill: "#e8ba61" }),
      Array.from({ length: 7 }, (s, l) =>
        e.jsx(
          "path",
          { d: `M${15 + l * 8} 76 l5 -6`, stroke: "#111b23", strokeWidth: 2.4 },
          l,
        ),
      ),
      e.jsx("rect", {
        x: 20,
        y: 84,
        width: 42,
        height: 12,
        rx: 1.4,
        fill: "#242f38",
      }),
      e.jsx("text", {
        x: 41,
        y: 92.6,
        fontSize: 6.4,
        fontWeight: 700,
        fill: "#bac3cb",
        textAnchor: "middle",
        children: "EVIDENCE",
      }),
      e.jsx("rect", {
        x: 52,
        y: 112,
        width: 12,
        height: 20,
        rx: 2,
        fill: "#242f38",
      }),
      [0, 1, 2].map((s) =>
        [0, 1].map((l) =>
          e.jsx(
            "rect",
            {
              x: 54 + l * 5,
              y: 117 + s * 4.6,
              width: 3.4,
              height: 3,
              rx: 0.6,
              fill: "#95a1ac",
            },
            `${s}${l}`,
          ),
        ),
      ),
      e.jsx(D, { x: 58, y: 114.6, fill: i === "calm" ? "#7ed99f" : "#cb5651" }),
      e.jsx("rect", {
        x: 52,
        y: 140,
        width: 4,
        height: 26,
        rx: 2,
        fill: "#bac3cb",
      }),
      e.jsx("path", {
        d: "M20 110 h22 M20 170 h22",
        stroke: "#46515b",
        strokeWidth: 3,
      }),
      e.jsxs(S, {
        x: 186,
        y: 46,
        w: 206,
        h: 92,
        mood: i,
        bg: "#003249",
        frame: "#0d171f",
        children: [
          e.jsx("path", {
            d: "M186 120 C220 110 240 128 274 112 C300 100 330 120 392 98",
            fill: "none",
            stroke: "#175675",
            strokeWidth: 7,
          }),
          e.jsx("path", {
            d: "M300 52 h36 v24 h-36z M206 92 h26 v20 h-26z",
            fill: "#006034",
            opacity: 0.7,
          }),
          e.jsx("path", {
            d: "M186 72 H392 M186 96 H392 M222 46 V138 M262 46 V138 M318 46 V138 M356 46 V138 M190 130 L250 50 M300 138 L390 58",
            stroke: "#175675",
            strokeWidth: 1.6,
          }),
          t.map(([s, l], a) =>
            e.jsxs(
              "g",
              {
                children: [
                  e.jsx("circle", {
                    cx: s,
                    cy: l,
                    r: 4.2,
                    fill: "#003249",
                    stroke: "#8ecbee",
                    strokeWidth: 1,
                  }),
                  e.jsx(D, { x: s, y: l, fill: "#6ca8ca", slow: a % 2 === 0 }),
                ],
              },
              a,
            ),
          ),
          e.jsx("circle", { cx: 326, cy: 82, r: 5, fill: "#cb5651" }),
          e.jsx("g", {
            className: "ma-ping",
            style: { transformOrigin: "326px 82px" },
            children: e.jsx("circle", {
              cx: 326,
              cy: 82,
              r: 8,
              fill: "none",
              stroke: "#cb5651",
              strokeWidth: 1.4,
            }),
          }),
        ],
      }),
      e.jsx("rect", { x: 186, y: 150, width: 214, height: 8, fill: "#333e48" }),
      e.jsx("rect", {
        x: 186,
        y: 158,
        width: 214,
        height: 18,
        fill: "#242f38",
      }),
      [198, 262, 326].map((s, l) =>
        e.jsxs(
          "g",
          {
            children: [
              e.jsx("rect", {
                x: s + 22,
                y: 140,
                width: 6,
                height: 12,
                fill: "#111b23",
              }),
              e.jsxs(S, {
                x: s,
                y: 120,
                w: 50,
                h: 22,
                mood: i,
                glyph: !1,
                bg: "#002538",
                children: [
                  e.jsx("text", {
                    x: s + 4,
                    y: 128,
                    fontSize: 6,
                    fontWeight: 700,
                    fill: "#e8ba61",
                    children: "999",
                  }),
                  e.jsx("rect", {
                    x: s + 22,
                    y: 124,
                    width: 24,
                    height: 2,
                    rx: 1,
                    fill: "#6ca8ca",
                  }),
                  e.jsx("rect", {
                    x: s + 4,
                    y: 132,
                    width: 40,
                    height: 2,
                    rx: 1,
                    fill: "#95a1ac",
                  }),
                  e.jsx("rect", {
                    x: s + 4,
                    y: 136,
                    width: 28,
                    height: 2,
                    rx: 1,
                    fill: "#95a1ac",
                  }),
                  e.jsx(D, {
                    x: s + 46,
                    y: 138,
                    fill: "#7ed99f",
                    slow: l === 1,
                  }),
                ],
              }),
            ],
          },
          s,
        ),
      ),
      [
        { x: 234, hair: "#3b2416", top: "#bac3cb" },
        { x: 336, hair: "#c9a26b", top: "#00425f" },
      ].map(({ x: s, hair: l, top: a }) =>
        e.jsxs(
          "g",
          {
            children: [
              e.jsx("rect", {
                x: s - 17,
                y: 168,
                width: 34,
                height: 44,
                rx: 8,
                fill: "#0d171f",
              }),
              e.jsx("path", {
                d: `M${s - 20} 206 C${s - 20} 182 ${s - 12} 174 ${s} 174 C${s + 12} 174 ${s + 20} 182 ${s + 20} 206Z`,
                fill: a,
              }),
              e.jsx("circle", { cx: s, cy: 160, r: 11, fill: l }),
              e.jsx("path", {
                d: `M${s - 12} 160 A12 12 0 0 1 ${s + 12} 160`,
                fill: "none",
                stroke: "#111b23",
                strokeWidth: 2.4,
              }),
              e.jsx("rect", {
                x: s - 14,
                y: 157,
                width: 5,
                height: 9,
                rx: 2,
                fill: "#111b23",
              }),
              e.jsx("path", {
                d: `M${s - 12} 165 q4 6 12 6`,
                fill: "none",
                stroke: "#111b23",
                strokeWidth: 1.4,
              }),
              e.jsx("rect", {
                x: s - 22,
                y: 210,
                width: 44,
                height: 6,
                rx: 2,
                fill: "#242f38",
              }),
            ],
          },
          s,
        ),
      ),
    ],
  });
}
function Fr({ mood: i }) {
  return e.jsxs("g", {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#bac3cb" }),
      e.jsx("rect", { width: 400, height: 10, fill: "#bac3cb" }),
      e.jsx("rect", { y: 200, width: 400, height: 40, fill: "#bac3cb" }),
      e.jsx("path", {
        d: "M0 214 H400",
        stroke: "#bac3cb",
        strokeWidth: 6,
        opacity: 0.6,
      }),
      e.jsx("rect", { y: 146, width: 400, height: 5, fill: "#95a1ac" }),
      e.jsx("rect", {
        y: 151,
        width: 400,
        height: 2,
        fill: "#5c6873",
        opacity: 0.4,
      }),
      e.jsx("rect", {
        x: 92,
        y: 6,
        width: 64,
        height: 16,
        rx: 2,
        fill: "#326e8e",
      }),
      e.jsx("text", {
        x: 124,
        y: 17.4,
        fontSize: 8,
        fontWeight: 700,
        fill: "#e3e9ee",
        textAnchor: "middle",
        children: "WARD 7",
      }),
      e.jsx("rect", {
        x: 2,
        y: 118,
        width: 6,
        height: 86,
        rx: 2,
        fill: "#95a1ac",
      }),
      e.jsx("rect", {
        x: 0,
        y: 158,
        width: 82,
        height: 14,
        rx: 4,
        fill: "#e3e9ee",
      }),
      e.jsx("path", { d: "M14 152 h66 q4 0 4 6 v8 h-70z", fill: "#8ecbee" }),
      e.jsx("ellipse", { cx: 14, cy: 152, rx: 10, ry: 6, fill: "#e3e9ee" }),
      e.jsx("rect", { x: 2, y: 172, width: 82, height: 6, fill: "#5c6873" }),
      e.jsx("path", {
        d: "M10 178 V204 M76 178 V204",
        stroke: "#5c6873",
        strokeWidth: 3,
      }),
      e.jsx("circle", { cx: 10, cy: 206, r: 4, fill: "#333e48" }),
      e.jsx("circle", { cx: 76, cy: 206, r: 4, fill: "#333e48" }),
      e.jsx("path", {
        d: "M68 74 V204 M58 210 L68 204 L78 210",
        stroke: "#95a1ac",
        strokeWidth: 2.4,
        fill: "none",
      }),
      e.jsx("path", { d: "M60 74 H76", stroke: "#95a1ac", strokeWidth: 2 }),
      e.jsx("rect", {
        x: 60,
        y: 76,
        width: 14,
        height: 22,
        rx: 4,
        fill: "#bac3cb",
        stroke: "#8ecbee",
      }),
      e.jsx("rect", {
        x: 60,
        y: 86,
        width: 14,
        height: 12,
        rx: 4,
        fill: "#cfedff",
      }),
      e.jsx("path", {
        d: "M67 98 V108 C67 130 50 140 40 154",
        fill: "none",
        stroke: "#bac3cb",
        strokeWidth: 1.2,
      }),
      e.jsx("rect", {
        x: 190,
        y: 22,
        width: 112,
        height: 78,
        rx: 3,
        fill: "#bac3cb",
      }),
      e.jsx("rect", { x: 195, y: 27, width: 102, height: 68, fill: "#bac3cb" }),
      e.jsx("rect", {
        x: 222,
        y: 36,
        width: 66,
        height: 56,
        rx: 10,
        fill: "#e3e9ee",
      }),
      e.jsx("circle", { cx: 255, cy: 64, r: 18, fill: "#bac3cb" }),
      e.jsx("circle", { cx: 255, cy: 64, r: 12, fill: "#00425f" }),
      e.jsx("rect", {
        x: 198,
        y: 70,
        width: 58,
        height: 6,
        rx: 2,
        fill: "#bac3cb",
      }),
      e.jsx("rect", { x: 210, y: 76, width: 6, height: 19, fill: "#95a1ac" }),
      e.jsx("path", {
        d: "M200 92 L230 30 M230 92 L258 34",
        stroke: "#e3e9ee",
        strokeWidth: 3,
        opacity: 0.4,
      }),
      e.jsx("rect", {
        x: 196,
        y: 28,
        width: 22,
        height: 9,
        rx: 1.4,
        fill: "#e8ba61",
      }),
      e.jsx("text", {
        x: 207,
        y: 35,
        fontSize: 6.4,
        fontWeight: 700,
        fill: "#242f38",
        textAnchor: "middle",
        children: "MRI",
      }),
      e.jsx("path", { d: "M352 10 V24", stroke: "#95a1ac", strokeWidth: 4 }),
      e.jsxs(S, {
        x: 314,
        y: 24,
        w: 78,
        h: 56,
        mood: i,
        bg: "#111b23",
        children: [
          e.jsx("path", {
            className: "ma-trace",
            d: "M314 50 h12 l4 -4 4 4 h6 l3 8 4 -26 4 26 3 -8 h12 l4 -4 4 4 h6 l3 8 4 -26 4 26",
            fill: "none",
            stroke: "#7ed99f",
            strokeWidth: 1.8,
            strokeLinejoin: "round",
          }),
          e.jsx("path", {
            d: "M318 72 q6 -6 12 0 t12 0 t12 0 t12 0",
            fill: "none",
            stroke: "#6ca8ca",
            strokeWidth: 1.4,
          }),
          e.jsx("text", {
            x: 388,
            y: 76,
            fontSize: 9,
            fontWeight: 700,
            fill: "#7ed99f",
            textAnchor: "end",
            children: "72",
          }),
          e.jsx(D, { x: 318, y: 29, fill: "#7ed99f" }),
        ],
      }),
      e.jsx("rect", { x: 196, y: 170, width: 204, height: 8, fill: "#95a1ac" }),
      e.jsx("rect", {
        x: 204,
        y: 178,
        width: 190,
        height: 30,
        fill: "#bac3cb",
      }),
      e.jsx("path", {
        d: "M204 192 H394 M300 178 V208",
        stroke: "#95a1ac",
        strokeWidth: 1.2,
      }),
      e.jsx("rect", { x: 244, y: 164, width: 10, height: 8, fill: "#333e48" }),
      e.jsxs(S, {
        x: 204,
        y: 110,
        w: 90,
        h: 56,
        mood: i,
        bg: "#111b23",
        children: [
          e.jsx("text", {
            x: 208,
            y: 120,
            fontSize: 6.4,
            fontWeight: 700,
            fill: "#8ecbee",
            children: "THEATRES",
          }),
          [0, 1, 2, 3].map((t) =>
            e.jsxs(
              "g",
              {
                children: [
                  e.jsx("rect", {
                    x: 208,
                    y: 126 + t * 9.4,
                    width: 12,
                    height: 6,
                    rx: 1,
                    fill: "#333e48",
                  }),
                  e.jsx("rect", {
                    x: 224,
                    y: 126 + t * 9.4,
                    width: [48, 30, 60, 40][t],
                    height: 6,
                    rx: 1.4,
                    fill: ["#5bb57e", "#6ca8ca", "#5bb57e", "#8ba3b7"][t],
                  }),
                ],
              },
              t,
            ),
          ),
        ],
      }),
      e.jsx("rect", { x: 342, y: 162, width: 10, height: 10, fill: "#333e48" }),
      e.jsxs(S, {
        x: 304,
        y: 98,
        w: 88,
        h: 64,
        mood: i,
        bg: "#00425f",
        children: [
          e.jsx("ellipse", {
            cx: 348,
            cy: 142,
            rx: 30,
            ry: 8,
            fill: "#7ed99f",
            opacity: 0.5,
          }),
          e.jsx("rect", {
            x: 322,
            y: 136,
            width: 52,
            height: 8,
            rx: 2,
            fill: "#a8ffc6",
          }),
          e.jsx("circle", {
            cx: 348,
            cy: 112,
            r: 9,
            fill: "#e3e9ee",
            opacity: 0.9,
          }),
          e.jsx("circle", { cx: 342, cy: 110, r: 2.4, fill: "#ffe4b4" }),
          e.jsx("circle", { cx: 350, cy: 108, r: 2.4, fill: "#ffe4b4" }),
          e.jsx("circle", { cx: 352, cy: 115, r: 2.4, fill: "#ffe4b4" }),
          e.jsx("path", {
            d: "M348 98 V103",
            stroke: "#bac3cb",
            strokeWidth: 2,
          }),
          e.jsx("circle", {
            cx: 384,
            cy: 105,
            r: 2.4,
            fill: "#cb5651",
            className: "ma-blink",
          }),
        ],
      }),
      e.jsx("rect", {
        x: 210,
        y: 196,
        width: 14,
        height: 4,
        rx: 1,
        fill: "#5c6873",
      }),
    ],
  });
}
function Or({ mood: i }) {
  return e.jsxs("g", {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#bac3cb" }),
      e.jsx("rect", { width: 400, height: 12, fill: "#d1beaa" }),
      e.jsx("rect", { y: 12, width: 400, height: 3, fill: "#ae9c88" }),
      e.jsx("rect", { y: 118, width: 400, height: 86, fill: "#5c4d3b" }),
      e.jsx("rect", { y: 114, width: 400, height: 6, fill: "#392a1a" }),
      Array.from({ length: 8 }, (t, s) =>
        e.jsx(
          "rect",
          {
            x: 8 + s * 50,
            y: 128,
            width: 40,
            height: 64,
            rx: 2,
            fill: "#5c4d3b",
            stroke: "#493a28",
            strokeWidth: 1.6,
          },
          s,
        ),
      ),
      e.jsx("rect", { y: 204, width: 400, height: 36, fill: "#77000e" }),
      e.jsx("path", { d: "M0 212 H400", stroke: "#77000e", strokeWidth: 2 }),
      e.jsx("rect", { x: 12, y: 30, width: 58, height: 46, fill: "#c4973c" }),
      e.jsx("rect", { x: 17, y: 35, width: 48, height: 36, fill: "#8ecbee" }),
      e.jsx("path", {
        d: "M17 71 L32 52 L42 62 L52 48 L65 71Z",
        fill: "#137a47",
      }),
      e.jsx("circle", { cx: 56, cy: 42, r: 4, fill: "#d1beaa" }),
      e.jsx("path", { d: "M26 204 L22 178 H52 L48 204Z", fill: "#746351" }),
      [
        "M37 178 C20 160 18 140 24 128 C32 142 36 160 37 178",
        "M37 178 C50 156 60 146 70 142 C64 158 52 170 37 178",
        "M37 178 C34 152 40 132 48 120 C50 140 44 160 37 178",
        "M37 178 C26 168 12 166 6 168 C14 176 26 180 37 178",
      ].map((t) => e.jsx("path", { d: t, fill: "#137a47" }, t)),
      e.jsx("path", {
        d: "M182 14 Q178 90 186 168 H200 Q194 90 198 14Z",
        fill: "#901e21",
      }),
      e.jsx("path", {
        d: "M296 14 Q300 90 292 168 H278 Q284 90 280 14Z",
        fill: "#901e21",
      }),
      e.jsx("rect", { x: 196, y: 16, width: 86, height: 150, fill: "#bac3cb" }),
      e.jsx("rect", { x: 201, y: 21, width: 76, height: 140, fill: "#00425f" }),
      [
        [214, 34],
        [268, 30],
        [258, 52],
        [208, 60],
      ].map(([t, s]) =>
        e.jsx("circle", { cx: t, cy: s, r: 0.9, fill: "#f8e4cf" }, `${t}-${s}`),
      ),
      e.jsxs("g", {
        fill: "#111b23",
        children: [
          e.jsx("path", { d: "M201 128 h76 v33 h-76z" }),
          [206, 220, 252, 266].map((t) =>
            e.jsx("path", { d: `M${t} 128 v-10 l2 -6 2 6 v10z` }, t),
          ),
          e.jsx("rect", { x: 226, y: 66, width: 20, height: 64 }),
          e.jsx("rect", { x: 223, y: 44, width: 26, height: 24 }),
          e.jsx("path", { d: "M223 44 L236 18 L249 44Z" }),
          e.jsx("path", {
            d: "M236 18 V10",
            stroke: "#111b23",
            strokeWidth: 1.4,
          }),
        ],
      }),
      e.jsx("circle", { cx: 236, cy: 56, r: 8.4, fill: "#ffe4b4" }),
      e.jsx("circle", {
        cx: 236,
        cy: 56,
        r: 8.4,
        fill: "none",
        stroke: "#ac3a38",
        strokeWidth: 1,
      }),
      e.jsx("path", {
        d: "M236 56 V50 M236 56 L240 58",
        stroke: "#242f38",
        strokeWidth: 1.2,
        strokeLinecap: "round",
      }),
      e.jsx("path", {
        d: "M201 90 H277 M239 21 V161 M201 55 H277 M201 125 H277",
        stroke: "#bac3cb",
        strokeWidth: 3,
      }),
      e.jsx("rect", { x: 196, y: 88, width: 86, height: 5, fill: "#bac3cb" }),
      e.jsx("rect", { x: 190, y: 164, width: 98, height: 6, fill: "#bac3cb" }),
      e.jsx("rect", { x: 346, y: 140, width: 8, height: 30, fill: "#242f38" }),
      e.jsx("rect", {
        x: 334,
        y: 166,
        width: 32,
        height: 4,
        rx: 1,
        fill: "#242f38",
      }),
      e.jsxs(S, {
        x: 300,
        y: 70,
        w: 92,
        h: 68,
        mood: i,
        bg: "#e3e9ee",
        frame: "#242f38",
        children: [
          e.jsx("rect", {
            x: 300,
            y: 70,
            width: 92,
            height: 10,
            fill: "#1c2f40",
          }),
          e.jsx("rect", {
            x: 304,
            y: 73.5,
            width: 18,
            height: 3,
            rx: 1.5,
            fill: "#e3e9ee",
          }),
          e.jsx("rect", {
            x: 306,
            y: 86,
            width: 28,
            height: 40,
            rx: 2,
            fill: "#901e21",
          }),
          e.jsx("circle", {
            cx: 320,
            cy: 100,
            r: 6,
            fill: "none",
            stroke: "#e8ba61",
            strokeWidth: 1.2,
          }),
          e.jsx("path", {
            d: "M314 100 h12 M320 94 v12",
            stroke: "#e8ba61",
            strokeWidth: 0.8,
          }),
          e.jsx("text", {
            x: 320,
            y: 118,
            fontSize: 4,
            fontWeight: 700,
            fill: "#e8ba61",
            textAnchor: "middle",
            children: "PASSPORT",
          }),
          e.jsx("rect", {
            x: 340,
            y: 86,
            width: 46,
            height: 16,
            rx: 2,
            fill: "#bac3cb",
          }),
          e.jsx("text", {
            x: 344,
            y: 97.4,
            fontSize: 8,
            fontWeight: 700,
            fill: "#1c2f40",
            children: "67M",
          }),
          e.jsx("circle", {
            cx: 377,
            cy: 94,
            r: 5,
            fill: "none",
            stroke: "#399661",
            strokeWidth: 2.6,
          }),
          e.jsx("path", {
            d: "M377 89 a5 5 0 0 1 4.6 7",
            fill: "none",
            stroke: "#6ca8ca",
            strokeWidth: 2.6,
          }),
          [0, 1, 2, 3, 4].map((t) =>
            e.jsx(
              "rect",
              {
                x: 342 + t * 9,
                y: 128 - [10, 16, 12, 20, 15][t],
                width: 6,
                height: [10, 16, 12, 20, 15][t],
                fill: t === 3 ? "#399661" : "#1c2f40",
                opacity: 0.85,
              },
              t,
            ),
          ),
        ],
      }),
      e.jsx("rect", { x: 290, y: 170, width: 110, height: 8, fill: "#392a1a" }),
      e.jsx("rect", {
        x: 296,
        y: 178,
        width: 104,
        height: 62,
        fill: "#493a28",
      }),
      e.jsx("rect", {
        x: 304,
        y: 186,
        width: 40,
        height: 18,
        rx: 2,
        fill: "none",
        stroke: "#392a1a",
        strokeWidth: 1.6,
      }),
      e.jsx("circle", { cx: 324, cy: 195, r: 2, fill: "#c4973c" }),
      e.jsxs("g", {
        children: [
          e.jsx("rect", {
            x: 298,
            y: 148,
            width: 58,
            height: 24,
            rx: 2,
            fill: "#ac3a38",
          }),
          e.jsx("rect", {
            x: 298,
            y: 148,
            width: 58,
            height: 6,
            rx: 2,
            fill: "#901e21",
          }),
          e.jsx("path", {
            d: "M314 148 v-6 h26 v6",
            fill: "none",
            stroke: "#c4973c",
            strokeWidth: 2.4,
          }),
          e.jsx("rect", {
            x: 322,
            y: 158,
            width: 10,
            height: 7,
            rx: 1,
            fill: "#c4973c",
          }),
          e.jsx("path", {
            d: "M300 168 h54",
            stroke: "#901e21",
            strokeWidth: 1,
          }),
        ],
      }),
    ],
  });
}
function Qr({ x: i, y: t, fill: s, kind: l }) {
  return e.jsxs("g", {
    children: [
      e.jsx("path", {
        d: `M${i} ${t - 6} q0 -4 3 -4 M${i - 10} ${t + 2} L${i} ${t - 4} L${i + 10} ${t + 2}`,
        fill: "none",
        stroke: "#46515b",
        strokeWidth: 1.2,
      }),
      l === 0
        ? e.jsx("path", {
            d: `M${i - 8} ${t + 1} L${i - 14} ${t + 12} L${i - 10} ${t + 15} L${i - 8} ${t + 12} V${t + 44} H${i + 8} V${t + 12} L${i + 10} ${t + 15} L${i + 14} ${t + 12} L${i + 8} ${t + 1} Q${i} ${t + 6} ${i - 8} ${t + 1}Z`,
            fill: s,
          })
        : e.jsx("path", {
            d: `M${i - 6} ${t + 1} L${i - 7} ${t + 16} L${i - 15} ${t + 60} H${i + 15} L${i + 7} ${t + 16} L${i + 6} ${t + 1} Q${i} ${t + 5} ${i - 6} ${t + 1}Z`,
            fill: s,
          }),
    ],
  });
}
function Ur({ mood: i }) {
  return e.jsxs("g", {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#bac3cb" }),
      e.jsx("rect", { width: 400, height: 20, fill: "#46515b" }),
      e.jsx("path", {
        d: "M0 20 L25 4 L50 20 L75 4 L100 20 L125 4 L150 20 L175 4 L200 20 L225 4 L250 20 L275 4 L300 20 L325 4 L350 20 L375 4 L400 20",
        fill: "none",
        stroke: "#242f38",
        strokeWidth: 2,
      }),
      [60, 220, 330].map((t) =>
        e.jsx(
          "rect",
          { x: t, y: 6, width: 40, height: 6, fill: "#f8e4cf", opacity: 0.7 },
          t,
        ),
      ),
      [0, 1, 2].map((t) =>
        e.jsxs(
          "g",
          {
            children: [
              e.jsx("rect", {
                x: 96,
                y: 58 + t * 40,
                width: 304,
                height: 4,
                fill: "#cb5651",
              }),
              Array.from({ length: 14 }, (s, l) => {
                const a = 14 + ((l * 7 + t * 5) % 9),
                  c = 18 + ((l * 5 + t * 3) % 14);
                return e.jsx(
                  "rect",
                  {
                    x: 100 + l * 22,
                    y: 58 + t * 40 - c,
                    width: a,
                    height: c,
                    fill: (l + t) % 3 === 0 ? "#8f7e6b" : "#ae9c88",
                    stroke: "#8f7e6b",
                    strokeWidth: 0.8,
                  },
                  l,
                );
              }),
            ],
          },
          t,
        ),
      ),
      [96, 196, 296, 396].map((t) =>
        e.jsx(
          "rect",
          { x: t, y: 24, width: 4, height: 178, fill: "#326e8e" },
          t,
        ),
      ),
      e.jsx("rect", { y: 200, width: 400, height: 40, fill: "#bac3cb" }),
      e.jsx("path", {
        d: "M0 214 H180 M0 232 H400",
        stroke: "#e8ba61",
        strokeWidth: 3,
      }),
      e.jsx("path", {
        d: "M4 92 H84 M8 92 V204 M80 92 V204",
        stroke: "#95a1ac",
        strokeWidth: 3,
      }),
      e.jsx("path", {
        d: "M2 204 H14 M74 204 H86",
        stroke: "#5c6873",
        strokeWidth: 3,
      }),
      [
        ["#ee766f", 0],
        ["#e8ba61", 1],
        ["#5bb57e", 0],
        ["#8ba3b7", 1],
        ["#4e89aa", 0],
        ["#111b23", 1],
      ].map(([t, s], l) =>
        e.jsx(Qr, { x: 16 + l * 11.4, y: 100, fill: t, kind: s }, l),
      ),
      e.jsx("path", {
        d: "M216 20 V32 M310 20 V32",
        stroke: "#242f38",
        strokeWidth: 1.4,
      }),
      e.jsxs(S, {
        x: 200,
        y: 32,
        w: 128,
        h: 70,
        mood: i,
        bg: "#111b23",
        children: [
          e.jsx("text", {
            x: 206,
            y: 44,
            fontSize: 6.4,
            fontWeight: 700,
            fill: "#95a1ac",
            children: "ORDERS / SEC",
          }),
          e.jsx("text", {
            x: 206,
            y: 70,
            fontSize: 22,
            fontWeight: 800,
            fill: "#e3e9ee",
            children: "4,812",
          }),
          e.jsx("path", {
            d: "M206 96 L226 92 L242 94 L258 86 L276 88 L292 78 L306 74 L322 60",
            fill: "none",
            stroke: "#ee766f",
            strokeWidth: 2,
            strokeLinejoin: "round",
          }),
          e.jsx("circle", { cx: 322, cy: 60, r: 2.4, fill: "#ee766f" }),
          e.jsx(D, { x: 318, y: 40, fill: "#7ed99f" }),
        ],
      }),
      e.jsx("path", {
        d: "M362 20 L364 34",
        stroke: "#242f38",
        strokeWidth: 1,
      }),
      e.jsxs("g", {
        transform: "rotate(8 364 36)",
        children: [
          e.jsx("path", {
            d: "M352 36 L376 36 L376 92 L364 102 L352 92Z",
            fill: "#ee766f",
          }),
          e.jsx("circle", { cx: 364, cy: 42, r: 2.4, fill: "#bac3cb" }),
          e.jsx("text", {
            x: 364,
            y: 62,
            fontSize: 8.4,
            fontWeight: 800,
            fill: "#e3e9ee",
            textAnchor: "middle",
            children: "SALE",
          }),
          e.jsx("text", {
            x: 364,
            y: 80,
            fontSize: 9,
            fontWeight: 800,
            fill: "#e3e9ee",
            textAnchor: "middle",
            children: "-50%",
          }),
        ],
      }),
      e.jsx("rect", {
        x: 184,
        y: 170,
        width: 216,
        height: 10,
        fill: "#333e48",
      }),
      e.jsx("path", {
        className: "ma-belt",
        d: "M184 175 H400",
        stroke: "#5c6873",
        strokeWidth: 4,
        strokeDasharray: "6 8",
      }),
      e.jsx("rect", { x: 184, y: 180, width: 216, height: 6, fill: "#242f38" }),
      [196, 250, 304, 358].map((t) =>
        e.jsx(
          "path",
          {
            d: `M${t} 186 V206 M${t + 8} 186 V206`,
            stroke: "#46515b",
            strokeWidth: 3,
          },
          t,
        ),
      ),
      [
        { x: 192, w: 30, h: 22, f: "#ae9c88" },
        { x: 230, w: 24, h: 14, f: "#6e8498" },
        { x: 262, w: 34, h: 26, f: "#ae9c88" },
        { x: 306, w: 22, h: 14, f: "#ee766f" },
        { x: 336, w: 28, h: 20, f: "#ae9c88" },
        { x: 372, w: 24, h: 14, f: "#6e8498" },
      ].map(({ x: t, w: s, h: l, f: a }) =>
        e.jsxs(
          "g",
          {
            children: [
              e.jsx("rect", {
                x: t,
                y: 170 - l,
                width: s,
                height: l,
                rx: a === "#ae9c88" ? 1 : 4,
                fill: a,
              }),
              a === "#ae9c88"
                ? e.jsx("rect", {
                    x: t + s / 2 - 2,
                    y: 170 - l,
                    width: 4,
                    height: l,
                    fill: "#d1beaa",
                  })
                : e.jsx("rect", {
                    x: t + 5,
                    y: 170 - l + 3,
                    width: 10,
                    height: 6,
                    rx: 1,
                    fill: "#e3e9ee",
                  }),
            ],
          },
          t,
        ),
      ),
    ],
  });
}
function Zr({ mood: i }) {
  const t = ["#901e21", "#00425f", "#bac3cb", "#006034", "#746351", "#333e48"];
  return e.jsxs("g", {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#493a28" }),
      Array.from({ length: 9 }, (s, l) =>
        e.jsx(
          "rect",
          {
            x: 4 + l * 46,
            y: 16,
            width: 38,
            height: 180,
            rx: 2,
            fill: "#493a28",
            stroke: "#392a1a",
            strokeWidth: 1.4,
          },
          l,
        ),
      ),
      e.jsx("rect", { y: 196, width: 400, height: 44, fill: "#003249" }),
      e.jsx("path", { d: "M0 206 H400", stroke: "#00425f", strokeWidth: 2 }),
      e.jsx("rect", { x: 0, y: 6, width: 86, height: 194, fill: "#19232c" }),
      [0, 1, 2, 3, 4].map((s) =>
        e.jsxs(
          "g",
          {
            children: [
              e.jsx("rect", {
                x: 0,
                y: 44 + s * 38,
                width: 86,
                height: 4,
                fill: "#493a28",
              }),
              s === 2
                ? [0, 1, 2].map((l) =>
                    e.jsxs(
                      "g",
                      {
                        children: [
                          e.jsx("rect", {
                            x: 6,
                            y: 30 + s * 38 - l * 5,
                            width: 38,
                            height: 5,
                            fill: "#bac3cb",
                            stroke: "#bac3cb",
                            strokeWidth: 0.6,
                          }),
                          e.jsx("path", {
                            d: `M25 ${30 + s * 38 - l * 5} v5`,
                            stroke: "#ee766f",
                            strokeWidth: 1.6,
                          }),
                        ],
                      },
                      l,
                    ),
                  )
                : null,
              Array.from({ length: s === 2 ? 4 : 8 }, (l, a) => {
                const c = 26 + ((a * 3 + s) % 7),
                  h = (s === 2 ? 48 : 4) + a * 9.6;
                return e.jsxs(
                  "g",
                  {
                    children: [
                      e.jsx("rect", {
                        x: h,
                        y: 44 + s * 38 - c,
                        width: 8.6,
                        height: c,
                        fill: t[(a + s * 2) % t.length],
                      }),
                      e.jsx("rect", {
                        x: h + 2,
                        y: 44 + s * 38 - c + 5,
                        width: 4.6,
                        height: 3,
                        fill: "#e3e9ee",
                        opacity: 0.7,
                      }),
                    ],
                  },
                  a,
                );
              }),
            ],
          },
          s,
        ),
      ),
      e.jsx("rect", {
        x: 160,
        y: 40,
        width: 96,
        height: 152,
        fill: "#cfedff",
        opacity: 0.16,
      }),
      e.jsx("rect", {
        x: 160,
        y: 110,
        width: 96,
        height: 10,
        fill: "#e3e9ee",
        opacity: 0.3,
      }),
      e.jsx("ellipse", {
        cx: 210,
        cy: 170,
        rx: 34,
        ry: 6,
        fill: "#0d171f",
        opacity: 0.7,
      }),
      [186, 210, 234].map((s) =>
        e.jsx(
          "rect",
          {
            x: s - 5,
            y: 150,
            width: 10,
            height: 14,
            rx: 3,
            fill: "#111b23",
            opacity: 0.6,
          },
          s,
        ),
      ),
      e.jsxs(S, {
        x: 186,
        y: 58,
        w: 48,
        h: 30,
        mood: i,
        bg: "#111b23",
        frame: "#111b23",
        children: [
          e.jsx("rect", {
            x: 190,
            y: 64,
            width: 22,
            height: 3,
            rx: 1.5,
            fill: "#bac3cb",
          }),
          e.jsx("rect", {
            x: 190,
            y: 70,
            width: 36,
            height: 2,
            rx: 1,
            fill: "#5c6873",
          }),
          e.jsx("rect", {
            x: 190,
            y: 75,
            width: 30,
            height: 2,
            rx: 1,
            fill: "#5c6873",
          }),
          e.jsx("rect", {
            x: 190,
            y: 80,
            width: 20,
            height: 2,
            rx: 1,
            fill: "#c4973c",
          }),
        ],
      }),
      e.jsx("rect", {
        x: 158,
        y: 38,
        width: 100,
        height: 156,
        fill: "none",
        stroke: "#95a1ac",
        strokeWidth: 2.4,
      }),
      e.jsx("path", { d: "M208 38 V194", stroke: "#95a1ac", strokeWidth: 1.4 }),
      e.jsx("path", {
        d: "M170 48 L190 70 M222 48 L250 82",
        stroke: "#e3e9ee",
        strokeWidth: 2,
        opacity: 0.3,
      }),
      e.jsx("rect", {
        x: 266,
        y: 16,
        width: 128,
        height: 136,
        fill: "#19232c",
      }),
      e.jsx("rect", {
        x: 271,
        y: 21,
        width: 118,
        height: 126,
        fill: "#00425f",
      }),
      e.jsx("rect", { x: 271, y: 70, width: 118, height: 30, fill: "#3d5264" }),
      e.jsx("rect", {
        x: 271,
        y: 100,
        width: 118,
        height: 47,
        fill: "#ae9c88",
      }),
      e.jsxs("g", {
        fill: "#002538",
        children: [
          e.jsx("rect", { x: 274, y: 96, width: 16, height: 51 }),
          e.jsx("path", { d: "M294 147 V86 Q302 60 310 86 V147Z" }),
          e.jsx("path", { d: "M316 147 L332 40 L346 147Z" }),
          e.jsx("rect", { x: 348, y: 78, width: 20, height: 69 }),
          e.jsx("rect", { x: 354, y: 66, width: 8, height: 12 }),
          e.jsx("rect", { x: 370, y: 104, width: 19, height: 43 }),
        ],
      }),
      [
        [278, 104],
        [284, 116],
        [300, 98],
        [304, 120],
        [330, 90],
        [334, 112],
        [352, 92],
        [362, 108],
        [374, 116],
        [380, 128],
      ].map(([s, l], a) =>
        e.jsx(
          "g",
          {
            className: a % 3 === 0 ? "ma-blink ma-blink-slow" : void 0,
            children: e.jsx("rect", {
              x: s,
              y: l,
              width: 2.6,
              height: 2.6,
              fill: "#ffe4b4",
            }),
          },
          a,
        ),
      ),
      e.jsx("path", {
        d: "M330 21 V147 M271 84 H389",
        stroke: "#19232c",
        strokeWidth: 3,
      }),
      e.jsx("rect", { x: 262, y: 168, width: 138, height: 8, fill: "#19232c" }),
      e.jsx("rect", {
        x: 268,
        y: 176,
        width: 132,
        height: 64,
        fill: "#392a1a",
      }),
      e.jsx("rect", {
        x: 278,
        y: 188,
        width: 50,
        height: 22,
        rx: 2,
        fill: "none",
        stroke: "#19232c",
        strokeWidth: 1.6,
      }),
      e.jsx("path", {
        d: "M286 168 V150 L296 140",
        fill: "none",
        stroke: "#746351",
        strokeWidth: 2,
      }),
      e.jsx("path", { d: "M280 168 h16", stroke: "#746351", strokeWidth: 3 }),
      e.jsx("path", { d: "M284 142 Q296 128 310 140Z", fill: "#137a47" }),
      e.jsx("ellipse", {
        cx: 297,
        cy: 150,
        rx: 16,
        ry: 6,
        fill: "#ffe4b4",
        opacity: 0.25,
      }),
      e.jsx("path", { d: "M318 168 L322 146 H362 L366 168Z", fill: "#333e48" }),
      e.jsxs(S, {
        x: 324,
        y: 140,
        w: 36,
        h: 22,
        mood: i,
        glyph: !1,
        bg: "#242f38",
        frame: "#333e48",
        children: [
          e.jsx("rect", {
            x: 328,
            y: 145,
            width: 22,
            height: 2.4,
            rx: 1.2,
            fill: "#bac3cb",
          }),
          e.jsx("rect", {
            x: 328,
            y: 150,
            width: 28,
            height: 2,
            rx: 1,
            fill: "#5c6873",
          }),
          e.jsx("rect", {
            x: 328,
            y: 154,
            width: 18,
            height: 2,
            rx: 1,
            fill: "#5c6873",
          }),
        ],
      }),
      e.jsxs("g", {
        stroke: "#c4973c",
        strokeWidth: 1.6,
        fill: "none",
        children: [
          e.jsx("path", { d: "M384 168 V128 M370 134 H398 M384 124 v-3" }),
          e.jsx("path", {
            d: "M372 134 L366 150 M372 134 L378 150 M396 134 L390 150 M396 134 L398 150",
            strokeWidth: 0.8,
          }),
        ],
      }),
      e.jsx("path", {
        d: "M364 150 Q372 158 380 150Z M388 150 Q394 156 400 150Z",
        fill: "#c4973c",
      }),
      e.jsx("path", { d: "M376 168 h16 l-3 -5 h-10z", fill: "#c4973c" }),
      e.jsx("circle", { cx: 384, cy: 121, r: 2.4, fill: "#c4973c" }),
    ],
  });
}
function I({ x: i, y: t, s = 1, fill: l, broken: a }) {
  return e.jsx("g", {
    transform: `translate(${i} ${t}) scale(${s})`,
    children: a
      ? e.jsxs("g", {
          fill: l,
          children: [
            e.jsx("path", {
              d: "M-0.6 6 C-6 2 -8 -1 -8 -3.6 C-8 -6.6 -5 -8 -2.8 -6.6 C-1.8 -6 -1 -5 -0.6 -4.4 L-2 -1.6 L0 0.6 L-1.6 3Z",
            }),
            e.jsx("g", {
              transform: "translate(1.6 0.8) rotate(10)",
              children: e.jsx("path", {
                d: "M0.6 6 C6 2 8 -1 8 -3.6 C8 -6.6 5 -8 2.8 -6.6 C1.8 -6 1 -5 0.6 -4.4 L-0.6 -1.6 L1.4 0.6 L0 3Z",
              }),
            }),
          ],
        })
      : e.jsx("path", {
          d: "M0 6 C-6 2 -8 -1 -8 -3.6 C-8 -6.6 -5 -8 -2.8 -6.6 C-1.6 -6 -0.6 -5 0 -4 C0.6 -5 1.6 -6 2.8 -6.6 C5 -8 8 -6.6 8 -3.6 C8 -1 6 2 0 6Z",
          fill: l,
        }),
  });
}
function Lt({ x: i, y: t, fill: s, line: l }) {
  return e.jsxs("g", {
    children: [
      e.jsx("rect", { x: i, y: t, width: 30, height: 16, rx: 6, fill: s }),
      e.jsx("path", { d: `M${i + 6} ${t + 15} l-2 6 7 -6z`, fill: s }),
      e.jsx("rect", {
        x: i + 5,
        y: t + 4.4,
        width: 20,
        height: 2.2,
        rx: 1.1,
        fill: l,
      }),
      e.jsx("rect", {
        x: i + 5,
        y: t + 9.2,
        width: 13,
        height: 2.2,
        rx: 1.1,
        fill: l,
      }),
    ],
  });
}
function Yr({ mood: i }) {
  const t = i === "calm",
    s = t || i === "protected",
    l = s ? "#cb5651" : i === "partial" ? "#e8ba61" : "#cb5651",
    a = [
      "#6ca8ca",
      "#ee766f",
      "#e8ba61",
      "#7ed99f",
      "#8ba3b7",
      "#e8ba61",
      "#6ca8ca",
      "#ee766f",
      "#7ed99f",
      "#8ba3b7",
      "#e8ba61",
      "#8ecbee",
    ];
  return e.jsxs("g", {
    children: [
      e.jsx("rect", { width: 400, height: 240, fill: "#051827" }),
      e.jsx("rect", { y: 202, width: 400, height: 38, fill: "#0d171f" }),
      e.jsx("rect", {
        y: 201,
        width: 400,
        height: 2,
        fill: "#6e8498",
        opacity: 0.8,
      }),
      [0, 1, 2, 3, 4, 5].map((c) =>
        e.jsx(
          "path",
          {
            d: `M${200 + (c - 2.5) * 30} 203 L${200 + (c - 2.5) * 90} 240`,
            stroke: "#1c2f40",
            strokeWidth: 1,
          },
          c,
        ),
      ),
      e.jsx("rect", {
        x: 172,
        y: 14,
        width: 222,
        height: 138,
        rx: 6,
        fill: "#0d171f",
      }),
      a.map((c, h) => {
        const o = h % 4,
          d = Math.floor(h / 4),
          n = 178 + o * 53.5,
          x = 20 + d * 43.5;
        return e.jsxs(
          "g",
          {
            children: [
              e.jsx("rect", {
                x: n,
                y: x,
                width: 49,
                height: 39,
                rx: 3,
                fill: c,
              }),
              h % 3 === 0
                ? e.jsx("path", {
                    d: `M${n} ${x + 39} L${n + 16} ${x + 20} L${n + 26} ${x + 30} L${n + 36} ${x + 16} L${n + 49} ${x + 39}Z`,
                    fill: "#0d171f",
                    opacity: 0.25,
                  })
                : h % 3 === 1
                  ? e.jsxs("g", {
                      fill: "#0d171f",
                      opacity: 0.25,
                      children: [
                        e.jsx("circle", { cx: n + 24.5, cy: x + 16, r: 7 }),
                        e.jsx("path", {
                          d: `M${n + 12} ${x + 39} Q${n + 24.5} ${x + 20} ${n + 37} ${x + 39}Z`,
                        }),
                      ],
                    })
                  : e.jsxs("g", {
                      fill: "#e3e9ee",
                      opacity: 0.45,
                      children: [
                        e.jsx("rect", {
                          x: n + 8,
                          y: x + 10,
                          width: 14,
                          height: 14,
                          rx: 2,
                        }),
                        e.jsx("rect", {
                          x: n + 26,
                          y: x + 16,
                          width: 14,
                          height: 14,
                          rx: 7,
                        }),
                      ],
                    }),
              e.jsx("rect", {
                x: n,
                y: x + 36,
                width: 49 * (0.3 + ((h * 37) % 60) / 100),
                height: 3,
                fill: "#cb5651",
              }),
              e.jsx("rect", {
                x: n + 34,
                y: x + 28,
                width: 12,
                height: 6,
                rx: 1.4,
                fill: "#0d171f",
                opacity: 0.6,
              }),
            ],
          },
          h,
        );
      }),
      t
        ? e.jsxs("g", {
            children: [
              e.jsx("circle", { cx: 284, cy: 84, r: 21, fill: "#6e8498" }),
              e.jsx("circle", {
                cx: 284,
                cy: 84,
                r: 21,
                fill: "none",
                stroke: "#e3e9ee",
                strokeWidth: 2,
                opacity: 0.6,
              }),
              e.jsx("path", {
                d: "M277 73 L297 84 L277 95Z",
                fill: "#e3e9ee",
                strokeLinejoin: "round",
              }),
            ],
          })
        : e.jsxs("g", {
            children: [
              e.jsx("rect", {
                x: 172,
                y: 14,
                width: 222,
                height: 138,
                rx: 6,
                fill: F[i].bg,
                opacity: 0.82,
              }),
              e.jsx(Ut, { mood: i, x: 284, y: 84, s: 1.5 }),
              i === "vulnerable"
                ? e.jsx(Zt, { x: 172, y: 14, w: 222, h: 138 })
                : null,
            ],
          }),
      e.jsx("rect", {
        x: 292,
        y: 158,
        width: 102,
        height: 22,
        rx: 11,
        fill: "#0d171f",
        stroke: "#1c2f40",
      }),
      e.jsx("rect", {
        x: 296,
        y: 162,
        width: 36,
        height: 14,
        rx: 7,
        fill: t ? "#cb5651" : F[i].fg,
      }),
      e.jsx(D, { x: 302, y: 169, fill: "#e3e9ee" }),
      e.jsx("text", {
        x: 306,
        y: 172.4,
        fontSize: 8,
        fontWeight: 800,
        fill: "#e3e9ee",
        children: "LIVE",
      }),
      e.jsx("path", {
        d: "M338 169 q6 -6 12 0 q-6 6 -12 0z",
        fill: "none",
        stroke: "#adc5da",
        strokeWidth: 1.2,
      }),
      e.jsx("circle", { cx: 344, cy: 169, r: 1.8, fill: "#adc5da" }),
      e.jsx("text", {
        x: 388,
        y: 173,
        fontSize: 10,
        fontWeight: 800,
        fill: "#e3e9ee",
        textAnchor: "end",
        children: "2.1B",
      }),
      [
        { x: 8, y: 52, c: "#ee766f" },
        { x: 46, y: 70, c: "#8ecbee" },
      ].map(({ x: c, y: h, c: o }, d) =>
        e.jsxs(
          "g",
          {
            children: [
              e.jsx("rect", {
                x: c,
                y: h,
                width: 32,
                height: 60,
                rx: 5,
                fill: "#0d171f",
              }),
              e.jsxs(S, {
                x: c + 3,
                y: h + 4,
                w: 26,
                h: 50,
                mood: i,
                bg: o,
                frame: "#0d171f",
                children: [
                  e.jsx("circle", {
                    cx: c + 16,
                    cy: h + 22,
                    r: 5,
                    fill: "#0d171f",
                    opacity: 0.5,
                  }),
                  e.jsx("path", {
                    d: `M${c + 8} ${h + 50} Q${c + 16} ${h + 26} ${c + 24} ${h + 50}Z`,
                    fill: "#0d171f",
                    opacity: 0.5,
                  }),
                  e.jsx(I, { x: c + 25, y: h + 30, s: 0.35, fill: "#e3e9ee" }),
                  e.jsx("circle", {
                    cx: c + 25,
                    cy: h + 37,
                    r: 1.4,
                    fill: "#e3e9ee",
                  }),
                ],
              }),
              e.jsx("path", {
                d: `M${c + 16} ${h + 60} V${h + 72 + (1 - d) * 18} M${c + 6} ${h + 74 + (1 - d) * 18} H${c + 26}`,
                stroke: "#1c2f40",
                strokeWidth: 3,
              }),
            ],
          },
          c,
        ),
      ),
      e.jsx("rect", { x: 0, y: 160, width: 86, height: 8, fill: "#1c2f40" }),
      e.jsx("rect", { x: 4, y: 168, width: 78, height: 34, fill: "#081b2b" }),
      e.jsxs("g", {
        className: "ma-float",
        children: [
          e.jsx(I, { x: 166, y: 44, s: 1.1, fill: l, broken: !s }),
          e.jsx(I, { x: 86, y: 34, s: 0.8, fill: l, broken: !s }),
        ],
      }),
      e.jsxs("g", {
        className: "ma-float ma-float-late",
        children: [
          e.jsx(I, { x: 20, y: 140, s: 0.9, fill: l, broken: !s }),
          e.jsx(I, { x: 258, y: 178, s: 1.2, fill: l, broken: !s }),
        ],
      }),
      e.jsx(Lt, {
        x: 148,
        y: 8,
        fill: s ? "#e3e9ee" : "#d1beaa",
        line: s ? "#8ba3b7" : "#ac3a38",
      }),
      e.jsx(Lt, {
        x: 190,
        y: 160,
        fill: s ? "#e3e9ee" : "#d1beaa",
        line: s ? "#8ba3b7" : "#ac3a38",
      }),
    ],
  });
}
const Gt = {
    police: Rr,
    hospital: Fr,
    civil: Or,
    threadline: Ur,
    law: Zr,
    vidora: Yr,
  },
  Ue = {
    police: 122,
    hospital: 128,
    civil: 124,
    threadline: 124,
    law: 120,
    vidora: 122,
  },
  v = { w: 240, h: 474, top: 180, gap: 6 },
  Gr = {
    police: { x: 180, y: 40 },
    hospital: { x: 180, y: 14 },
    civil: { x: 180, y: 34 },
    threadline: { x: 176, y: 14 },
    law: { x: 180, y: 30 },
    vidora: { x: 178, y: 14 },
  },
  Kr = 220,
  Wt = 200;
function Jr({ scenario: i, mood: t }) {
  const s = W.useId(),
    l = Gt[i],
    a = Yt[i],
    c = Gr[i],
    h = v.w / Kr,
    o = v.w / Wt,
    d = v.top + v.gap,
    n = Ue[i] - Wt / 2;
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("clipPath", {
        id: `${s}-top`,
        children: e.jsx("rect", { width: v.w, height: v.top }),
      }),
      e.jsx("clipPath", {
        id: `${s}-figure`,
        children: e.jsx("rect", { y: d, width: v.w, height: v.h - d }),
      }),
      e.jsx("rect", { width: v.w, height: v.h, fill: "#0d171f" }),
      e.jsx("g", {
        clipPath: `url(#${s}-top)`,
        children: e.jsxs("g", {
          transform: `scale(${h}) translate(${-c.x} ${-c.y})`,
          children: [e.jsx(l, { mood: t }), e.jsx(Oe, { mood: t })],
        }),
      }),
      e.jsx("g", {
        clipPath: `url(#${s}-figure)`,
        children: e.jsxs("g", {
          transform: `translate(0 ${d}) scale(${o}) translate(${-n} 0)`,
          children: [
            e.jsx(l, { mood: t }),
            e.jsx(Oe, { mood: t }),
            e.jsx("g", {
              transform: `translate(${Ue[i]} 234)`,
              children: e.jsx(Qe, { look: a, mood: t, badge: !1 }),
            }),
          ],
        }),
      }),
    ],
  });
}
const Xr = {
    police: "#8ecbee",
    hospital: "#399661",
    civil: "#c4973c",
    threadline: "#ee766f",
    law: "#c4973c",
    vidora: "#6e8498",
  },
  el = {
    alarm: "#cb5651",
    protected: "#5bb57e",
    partial: "#e8ba61",
    vulnerable: "#901e21",
  };
function tl({ scenario: i, mood: t }) {
  const s = t === "calm" ? null : F[t].fg;
  switch (i) {
    case "police":
      return e.jsxs("g", {
        children: [
          e.jsx("rect", { width: 120, height: 120, fill: "#00425f" }),
          Array.from({ length: 16 }, (l, a) =>
            e.jsxs(
              "g",
              {
                children: [
                  e.jsx("rect", {
                    x: a * 8,
                    y: 20,
                    width: 8,
                    height: 8,
                    fill: a % 2 ? "#bac3cb" : "#326e8e",
                  }),
                  e.jsx("rect", {
                    x: a * 8,
                    y: 28,
                    width: 8,
                    height: 8,
                    fill: a % 2 ? "#326e8e" : "#bac3cb",
                  }),
                ],
              },
              a,
            ),
          ),
          e.jsx("circle", { cx: 98, cy: 70, r: 4, fill: s ?? "#6ca8ca" }),
          e.jsx("circle", { cx: 20, cy: 78, r: 3, fill: s ?? "#6ca8ca" }),
        ],
      });
    case "hospital":
      return e.jsxs("g", {
        children: [
          e.jsx("rect", { width: 120, height: 120, fill: "#bac3cb" }),
          e.jsx("path", {
            d: "M0 44 H22 l5 -6 5 6 h6 l4 12 6 -36 6 36 4 -12 M80 44 h40",
            fill: "none",
            stroke: s ?? "#399661",
            strokeWidth: 3,
            strokeLinejoin: "round",
          }),
        ],
      });
    case "civil":
      return e.jsxs("g", {
        children: [
          e.jsx("rect", { width: 120, height: 120, fill: "#bac3cb" }),
          e.jsxs("g", {
            fill: s ?? "#77838e",
            children: [
              e.jsx("rect", { x: 10, y: 40, width: 12, height: 70 }),
              e.jsx("rect", { x: 8, y: 28, width: 16, height: 14 }),
              e.jsx("path", { d: "M8 28 L16 10 L24 28Z" }),
            ],
          }),
          e.jsx("circle", { cx: 16, cy: 35, r: 4, fill: "#ffe4b4" }),
          e.jsx("rect", {
            x: 96,
            y: 80,
            width: 24,
            height: 14,
            rx: 2,
            fill: "#ac3a38",
          }),
        ],
      });
    case "threadline":
      return e.jsxs("g", {
        children: [
          e.jsx("rect", { width: 120, height: 120, fill: "#bac3cb" }),
          e.jsx("path", {
            d: "M8 32 L22 22 L36 32 M22 22 v-4 q0 -3 3 -3",
            fill: "none",
            stroke: "#901e21",
            strokeWidth: 2,
          }),
          e.jsxs("g", {
            transform: "rotate(14 98 30)",
            children: [
              e.jsx("path", {
                d: "M88 18 H108 V44 L98 52 L88 44Z",
                fill: s ?? "#ee766f",
              }),
              e.jsx("circle", { cx: 98, cy: 23, r: 2, fill: "#bac3cb" }),
            ],
          }),
        ],
      });
    case "law":
      return e.jsxs("g", {
        children: [
          e.jsx("rect", { width: 120, height: 120, fill: "#493a28" }),
          e.jsxs("g", {
            fill: "#00425f",
            children: [
              e.jsx("rect", { x: 0, y: 78, width: 18, height: 42 }),
              e.jsx("path", { d: "M92 120 L104 52 L116 120Z" }),
            ],
          }),
          e.jsx("g", {
            stroke: s ?? "#c4973c",
            strokeWidth: 2,
            fill: "none",
            children: e.jsx("path", {
              d: "M22 50 V20 M10 26 H34 M10 26 l-4 12 M10 26 l4 12 M34 26 l-4 12 M34 26 l4 12",
            }),
          }),
          e.jsx("path", {
            d: "M5 38 Q10 43 15 38Z M29 38 Q34 43 39 38Z",
            fill: s ?? "#c4973c",
          }),
        ],
      });
    default:
      return e.jsxs("g", {
        children: [
          e.jsx("rect", { width: 120, height: 120, fill: "#1c2f40" }),
          e.jsx("circle", { cx: 98, cy: 28, r: 12, fill: s ?? "#6e8498" }),
          e.jsx("path", { d: "M94 21 L105 28 L94 35Z", fill: "#e3e9ee" }),
          e.jsx(I, {
            x: 20,
            y: 34,
            s: 0.9,
            fill: s ?? "#cb5651",
            broken: t === "vulnerable",
          }),
          e.jsx(I, {
            x: 104,
            y: 62,
            s: 0.6,
            fill: s ?? "#cb5651",
            broken: t === "vulnerable",
          }),
        ],
      });
  }
}
function E({
  scenario: i,
  mood: t = "calm",
  variant: s = "scene",
  className: l,
}) {
  const a = Yt[i],
    c = l ? `ma-art ${l}` : "ma-art";
  if (s === "badge")
    return e.jsxs("svg", {
      viewBox: "0 0 120 120",
      className: c,
      style: { clipPath: "circle(50% at 50% 50%)" },
      "aria-hidden": "true",
      focusable: "false",
      "data-manager": i,
      "data-mood": t,
      "data-variant": s,
      children: [
        e.jsx(tl, { scenario: i, mood: t }),
        t === "alarm"
          ? e.jsx("g", {
              className: "ma-wash",
              children: e.jsx("rect", {
                width: 120,
                height: 120,
                fill: "#cb5651",
                opacity: 0.12,
              }),
            })
          : null,
        e.jsx("g", {
          transform: "translate(60 365) scale(1.76)",
          children: e.jsx(Qe, { look: a, mood: t, badge: !0 }),
        }),
        e.jsx("circle", {
          cx: 60,
          cy: 60,
          r: 57.5,
          fill: "none",
          stroke: t === "calm" ? Xr[i] : el[t],
          strokeWidth: 4,
        }),
      ],
    });
  if (s === "portrait")
    return e.jsx("svg", {
      viewBox: `0 0 ${v.w} ${v.h}`,
      className: c,
      "aria-hidden": "true",
      focusable: "false",
      "data-manager": i,
      "data-mood": t,
      "data-variant": s,
      children: e.jsx(Jr, { scenario: i, mood: t }),
    });
  const h = Gt[i];
  return e.jsxs("svg", {
    viewBox: "0 0 400 240",
    className: c,
    "aria-hidden": "true",
    focusable: "false",
    "data-manager": i,
    "data-mood": t,
    "data-variant": s,
    children: [
      e.jsx(h, { mood: t }),
      e.jsx(Oe, { mood: t }),
      e.jsx("g", {
        transform: `translate(${Ue[i]} 234)`,
        children: e.jsx(Qe, { look: a, mood: t, badge: !1 }),
      }),
    ],
  });
}
const Kt = 2600,
  il = 1600,
  sl = Kt + il,
  rl = 1800;
function ll({ scenario: i, onDone: t }) {
  const [s, l] = W.useState(!1),
    a = ue();
  W.useEffect(() => {
    const n = window.setTimeout(() => l(!0), Kt),
      x = window.setTimeout(t, sl);
    return () => {
      (window.clearTimeout(n), window.clearTimeout(x));
    };
  }, [t]);
  const c = s ? "#cb5651" : "#5bb57e",
    h = a ? v.w : 400,
    o = a ? v.h : 240,
    d = a ? 80 : 150;
  return e.jsxs("div", {
    className: `ua-interlude relative mx-auto max-w-5xl overflow-hidden rounded-2xl border border-slate-700 bg-[#0d171f] ${s ? "ua-alarm" : "ua-calm"}`,
    "data-under-attack-stage": "interlude",
    "data-interlude-phase": s ? "alarm" : "calm",
    "data-layout": a ? "portrait" : "landscape",
    children: [
      e.jsx("p", {
        className: "sr-only",
        "aria-live": "assertive",
        children: s
          ? "Alert: an attack is hitting the network."
          : "All quiet on the network.",
      }),
      e.jsx(E, {
        scenario: i,
        mood: s ? "alarm" : "calm",
        variant: a ? "portrait" : "scene",
        className: "block h-auto w-full",
      }),
      e.jsxs("svg", {
        viewBox: `0 0 ${h} ${o}`,
        className: "pointer-events-none absolute inset-0 h-full w-full",
        "aria-hidden": "true",
        children: [
          e.jsx("rect", {
            x: 0,
            y: o - 26,
            width: h,
            height: 26,
            fill: "#0d171f",
            opacity: 0.75,
          }),
          e.jsx("path", {
            d: `M0 ${o - 12} H${d} l6 -10 7 20 6 -14 4 4 H${h}`,
            fill: "none",
            stroke: c,
            strokeWidth: 2,
            strokeLinejoin: "round",
            className: "ua-heartbeat",
          }),
          s
            ? e.jsxs("g", {
                children: [
                  e.jsx("rect", {
                    width: h,
                    height: o,
                    fill: "#cb5651",
                    className: "ua-flash",
                  }),
                  e.jsx("g", {
                    transform: a ? "translate(200 226)" : "translate(352 44)",
                    children: e.jsxs("g", {
                      className: "ua-warning",
                      children: [
                        e.jsx("path", {
                          d: "M0 -30 L28 20 H-28 Z",
                          fill: "#e8ba61",
                          stroke: "#0d171f",
                          strokeWidth: 3.5,
                          strokeLinejoin: "round",
                        }),
                        e.jsx("rect", {
                          x: -3.5,
                          y: -12,
                          width: 7,
                          height: 20,
                          rx: 3,
                          fill: "#0d171f",
                        }),
                        e.jsx("circle", {
                          cx: 0,
                          cy: 13.5,
                          r: 3.8,
                          fill: "#0d171f",
                        }),
                      ],
                    }),
                  }),
                ],
              })
            : null,
        ],
      }),
    ],
  });
}
function al({ onDone: i }) {
  const t = ue();
  return (
    W.useEffect(() => {
      const s = window.setTimeout(i, rl);
      return () => window.clearTimeout(s);
    }, [i]),
    e.jsxs("div", {
      className:
        "ua-verdict-frame flex items-center justify-center rounded-2xl border border-slate-700 bg-[#0d171f] py-10",
      "data-under-attack-stage": "verdict",
      "data-layout": t ? "portrait" : "landscape",
      children: [
        e.jsx("p", {
          className: "sr-only",
          "aria-live": "polite",
          children: "Checking your defences.",
        }),
        e.jsxs("svg", {
          viewBox: "0 0 200 200",
          className: "ua-verdict h-48 w-48",
          "aria-hidden": "true",
          children: [
            [0, 1, 2].map((s) =>
              e.jsx(
                "circle",
                {
                  cx: 100,
                  cy: 100,
                  r: 40,
                  fill: "none",
                  stroke: "#6ca8ca",
                  strokeWidth: 3,
                  className: "ua-ring",
                  style: { animationDelay: `${s * 0.5}s` },
                },
                s,
              ),
            ),
            e.jsxs("g", {
              className: "ua-shield",
              children: [
                e.jsx("path", {
                  d: "M100 52 L136 66 V98 C136 124 120 140 100 150 C80 140 64 124 64 98 V66z",
                  fill: "#242f38",
                  stroke: "#6ca8ca",
                  strokeWidth: 4,
                }),
                e.jsx("path", {
                  d: "M100 74 V128",
                  stroke: "#6ca8ca",
                  strokeWidth: 3,
                  strokeDasharray: "4 6",
                  className: "ua-scan",
                }),
              ],
            }),
          ],
        }),
      ],
    })
  );
}
const Jt = {
    protected: {
      label: "Network protected",
      Icon: hi,
      text: "text-emerald-300",
      panel: "border-emerald-500/40 bg-emerald-500/10",
    },
    partial: {
      label: "Partially protected",
      Icon: ci,
      text: "text-amber-300",
      panel: "border-amber-500/40 bg-amber-500/10",
    },
    vulnerable: {
      label: "Breach successful",
      Icon: ai,
      text: "text-rose-300",
      panel: "border-rose-500/40 bg-rose-500/10",
    },
  },
  Ze =
    "inline-flex items-center gap-2 rounded-lg border border-slate-600 px-4 py-2 text-sm font-semibold text-slate-100 transition hover:bg-slate-800",
  $e = `inline-flex items-center gap-2 rounded-lg px-5 py-2.5 text-sm font-semibold transition disabled:cursor-not-allowed disabled:opacity-40 ${Ct}`;
function cl({ onPick: i }) {
  return ue()
    ? e.jsx(si, {
        label: "Pick an organisation",
        primaryClass: $e,
        picks: be.map((s) => ({
          id: s.id,
          name: s.organisation,
          aside: H(s.budget),
          line: s.briefing,
          art: e.jsx(E, { scenario: s.id, variant: "portrait" }),
          data: { "data-scenario": s.id },
        })),
        onPick: (s) => i(s),
      })
    : e.jsx("div", {
        className: "grid gap-4 md:grid-cols-3",
        children: be.map((s, l) =>
          e.jsxs(
            me.button,
            {
              type: "button",
              initial: { opacity: 0, y: 12 },
              animate: { opacity: 1, y: 0 },
              transition: { delay: l * 0.08 },
              onClick: () => i(s.id),
              "data-scenario": s.id,
              className:
                "group flex flex-col overflow-hidden rounded-2xl border border-slate-700 bg-slate-900/80 text-left transition hover:border-primary/60 focus:outline-none focus-visible:ring-2 focus-visible:ring-primary",
              children: [
                e.jsx(E, { scenario: s.id, className: "block h-auto w-full" }),
                e.jsxs("span", {
                  className: "flex flex-1 flex-col gap-2 p-4",
                  children: [
                    e.jsxs("span", {
                      className: "flex items-baseline justify-between gap-3",
                      children: [
                        e.jsx("span", {
                          className: "text-lg font-semibold text-slate-50",
                          children: s.organisation,
                        }),
                        e.jsx("span", {
                          className:
                            "shrink-0 font-mono text-sm font-bold text-primary",
                          children: H(s.budget),
                        }),
                      ],
                    }),
                    e.jsx("span", {
                      className: "text-sm leading-6 text-slate-300",
                      children: s.briefing,
                    }),
                  ],
                }),
              ],
            },
            s.id,
          ),
        ),
      });
}
function $t({
  scenario: i,
  purchased: t,
  locked: s = [],
  budget: l = i.budget,
  onToggle: a,
  onConfirm: c,
}) {
  const h = s.length > 0,
    o = Ye(t, i),
    d = Math.min(100, (o / l) * 100);
  return e.jsxs("div", {
    className: "space-y-5",
    "data-under-attack-stage": h ? "topup" : "shop",
    children: [
      h
        ? e.jsxs(me.div, {
            initial: { opacity: 0, y: 12 },
            animate: { opacity: 1, y: 0 },
            className:
              "flex items-center gap-3 rounded-2xl border border-emerald-500/40 bg-emerald-500/10 p-3 sm:gap-4 sm:p-4",
            "data-under-attack-topup": i.topUp,
            children: [
              e.jsx(E, {
                scenario: i.id,
                mood: "protected",
                variant: "badge",
                className: "h-14 w-14 shrink-0 sm:h-20 sm:w-20",
              }),
              e.jsxs("div", {
                className:
                  "flex min-w-0 flex-1 flex-col sm:flex-row sm:items-center sm:gap-4",
                children: [
                  e.jsx("h2", {
                    className:
                      "whitespace-nowrap text-lg font-semibold text-slate-50 sm:flex-1 sm:text-xl",
                    children: "Budget topped up",
                  }),
                  e.jsxs("div", {
                    className:
                      "flex shrink-0 items-center gap-2 whitespace-nowrap font-mono text-xl font-bold text-emerald-300 sm:text-2xl",
                    children: [
                      e.jsx(fi, {
                        "aria-hidden": "true",
                        className: "h-5 w-5 sm:h-6 sm:w-6",
                      }),
                      "+",
                      H(i.topUp),
                    ],
                  }),
                ],
              }),
            ],
          })
        : e.jsxs("div", {
            className: "flex items-center gap-4",
            children: [
              e.jsx(E, {
                scenario: i.id,
                variant: "badge",
                className: "h-20 w-20 shrink-0",
              }),
              e.jsxs("div", {
                children: [
                  e.jsx("h2", {
                    className: "text-xl font-semibold text-slate-50",
                    children: i.organisation,
                  }),
                  e.jsx("p", {
                    className: "text-sm leading-6 text-slate-300",
                    children: i.briefing,
                  }),
                ],
              }),
            ],
          }),
      e.jsxs("div", {
        className:
          "sticky top-2 z-10 flex flex-col gap-3 rounded-2xl border border-slate-700 bg-slate-900/95 p-4 backdrop-blur sm:flex-row sm:items-center",
        children: [
          e.jsxs("div", {
            className: "flex-1",
            children: [
              e.jsxs("div", {
                className: "mb-1.5 flex justify-between text-sm",
                children: [
                  e.jsx("span", {
                    className: "text-slate-400",
                    children: "Budget used",
                  }),
                  e.jsxs("span", {
                    className: "font-semibold text-slate-50",
                    children: [H(o), " / ", H(l)],
                  }),
                ],
              }),
              e.jsx("div", {
                className: "h-2.5 overflow-hidden rounded-full bg-slate-700",
                children: e.jsx("div", {
                  className: `h-full rounded-full transition-all duration-300 ${d > 95 ? "bg-rose-500" : d > 75 ? "bg-amber-400" : "bg-primary"}`,
                  style: { width: `${d}%` },
                }),
              }),
            ],
          }),
          e.jsx("button", {
            type: "button",
            onClick: c,
            disabled: t.length === 0,
            className: $e,
            children: "Confirm choices",
          }),
        ],
      }),
      e.jsx("div", {
        className: "grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-4",
        role: "group",
        "aria-label": "Security shopping list",
        children: B.map((n) => {
          const x = t.includes(n.id),
            g = s.includes(n.id),
            w = vi(n, t, i, l);
          return e.jsxs(
            "button",
            {
              type: "button",
              "aria-pressed": x,
              disabled: !w || g,
              onClick: () => a(n.id),
              "data-shop-item": n.id,
              "data-shop-locked": g || void 0,
              className: `group flex flex-col overflow-hidden rounded-xl border text-left transition focus:outline-none focus-visible:ring-2 focus-visible:ring-primary ${g ? "cursor-default border-emerald-500/50 bg-emerald-500/10" : x ? "border-primary bg-primary/10 ring-2 ring-primary/60" : w ? "border-slate-700 bg-slate-900/80 hover:border-slate-500" : "cursor-not-allowed border-slate-800 bg-slate-950/50 opacity-40 grayscale"}`,
              children: [
                e.jsxs("span", {
                  className: "relative block",
                  children: [
                    e.jsx("span", {
                      className: `block transition-[filter] duration-500 ${x ? "grayscale-0" : "grayscale group-hover:grayscale-0 group-focus-visible:grayscale-0"}`,
                      children: e.jsx(ke, { itemId: n.id }),
                    }),
                    x
                      ? e.jsx("span", {
                          className: `absolute right-2 top-2 flex h-8 w-8 items-center justify-center rounded-full shadow-lg ${g ? "bg-emerald-400 text-emerald-950" : "bg-primary text-slate-950"}`,
                          children: g
                            ? e.jsx(ji, {
                                "aria-hidden": "true",
                                className: "h-4 w-4",
                              })
                            : e.jsx(yi, {
                                "aria-hidden": "true",
                                className: "h-5 w-5",
                              }),
                        })
                      : null,
                  ],
                }),
                e.jsx("span", {
                  className: "flex flex-1 flex-col gap-1 p-3",
                  children: e.jsxs("span", {
                    className: "flex flex-col gap-0.5",
                    children: [
                      e.jsx("span", {
                        className: `text-sm font-bold ${g ? "text-emerald-300" : x ? "text-primary" : "text-slate-50"}`,
                        children: n.name,
                      }),
                      e.jsx("span", {
                        className: `shrink-0 font-mono text-sm font-bold ${g ? "text-slate-500 line-through" : "text-slate-50"}`,
                        children: H(ve(n, i)),
                      }),
                    ],
                  }),
                }),
              ],
            },
            n.id,
          );
        }),
      }),
    ],
  });
}
function hl({ scenario: i, attack: t, round: s, onReveal: l }) {
  return e.jsxs(
    me.div,
    {
      initial: { opacity: 0, scale: 0.97 },
      animate: { opacity: 1, scale: 1 },
      className: "space-y-5",
      "data-under-attack-stage": "attack",
      children: [
        e.jsxs("div", {
          className: "flex items-center gap-4",
          children: [
            e.jsx(E, {
              scenario: i.id,
              mood: "alarm",
              variant: "badge",
              className: "h-16 w-16 shrink-0 sm:h-20 sm:w-20",
            }),
            e.jsxs("div", {
              className: "min-w-0",
              children: [
                e.jsxs("p", {
                  className: "sr-only",
                  children: ["Round ", s + 1, " of ", Me],
                }),
                e.jsx("h2", {
                  className: "text-2xl font-semibold text-slate-50 sm:text-3xl",
                  children: t.name,
                }),
                e.jsxs("p", {
                  className: "text-sm text-slate-400",
                  children: ["Attack type: ", t.attackType],
                }),
              ],
            }),
          ],
        }),
        e.jsxs("div", {
          className:
            "relative grid overflow-hidden rounded-2xl border border-rose-500/30 bg-slate-900/80 lg:grid-cols-[minmax(0,1.15fr)_minmax(0,1fr)]",
          children: [
            e.jsx("div", {
              className:
                "absolute inset-x-0 top-0 z-10 h-1 bg-gradient-to-r from-rose-500 to-orange-500",
              "aria-hidden": "true",
            }),
            e.jsx(Lr, { attackId: t.id }),
            e.jsx("p", {
              className: "self-center p-5 text-lg leading-8 text-slate-200",
              children: t.scenario,
            }),
          ],
        }),
        e.jsx("button", {
          type: "button",
          onClick: l,
          className: $e,
          children: "Reveal outcome",
        }),
      ],
    },
    t.id,
  );
}
const Fe =
    "M12 1.5 21.5 5v8c0 6.5-4.2 10.9-9.5 13.5C6.7 23.9 2.5 19.5 2.5 13V5Z",
  ol = {
    protected: "protected",
    partial: "partially protected",
    vulnerable: "breached",
    unplayed: "not played yet",
  };
function nl({ results: i, current: t }) {
  const s = W.useId();
  return e.jsx("ol", {
    className: "flex shrink-0 items-center gap-1.5",
    "aria-label": "Rounds",
    "data-shield-progress": !0,
    children: Array.from({ length: Me }, (l, a) => {
      const c = i[a],
        h = c ?? "unplayed",
        o = a === t,
        d =
          c === "protected"
            ? "text-emerald-400"
            : c === "partial"
              ? "text-amber-400"
              : "";
      return e.jsxs(
        "li",
        {
          "data-round-shield": h,
          "data-active": o || void 0,
          "aria-current": o ? "step" : void 0,
          className: `p-1 transition-transform ${o ? "scale-[1.12]" : ""}`,
          children: [
            e.jsxs("svg", {
              viewBox: "0 0 24 28",
              "aria-hidden": "true",
              className: `h-8 w-7 ${d}`,
              children: [
                c === "partial"
                  ? e.jsxs(e.Fragment, {
                      children: [
                        e.jsx("clipPath", {
                          id: `${s}-${a}`,
                          children: e.jsx("rect", {
                            x: "0",
                            y: "14",
                            width: "24",
                            height: "14",
                          }),
                        }),
                        e.jsx("path", {
                          d: Fe,
                          fill: "currentColor",
                          clipPath: `url(#${s}-${a})`,
                        }),
                      ],
                    })
                  : c === "protected"
                    ? e.jsx("path", { d: Fe, fill: "currentColor" })
                    : null,
                e.jsx("path", {
                  d: Fe,
                  fill: "none",
                  strokeWidth: "1.75",
                  strokeLinejoin: "round",
                  className:
                    c === "protected"
                      ? "stroke-emerald-300"
                      : c === "partial"
                        ? "stroke-amber-300"
                        : c === "vulnerable"
                          ? "stroke-slate-400"
                          : "stroke-slate-600",
                }),
              ],
            }),
            e.jsxs("span", {
              className: "sr-only",
              children: ["Round ", a + 1, ": ", ol[h]],
            }),
          ],
        },
        a,
      );
    }),
  });
}
function dl({
  scenario: i,
  attack: t,
  level: s,
  results: l,
  round: a,
  purchased: c,
  isLast: h,
  beforeTopUp: o,
  onNext: d,
}) {
  const n = Jt[s],
    x =
      s === "protected"
        ? t.outcomeProtected
        : s === "partial"
          ? t.outcomePartial
          : t.outcomeVulnerable,
    g = B.filter((m) => t.protectedBy.includes(m.id)),
    w = B.filter((m) => t.alsoHelpedBy.includes(m.id)),
    y = g.filter((m) => c.includes(m.id)),
    $ = w.filter((m) => c.includes(m.id)),
    _ = g.filter((m) => !c.includes(m.id)),
    le = s === "protected" ? y[0] : s === "partial" ? $[0] : void 0,
    X = s === "vulnerable" ? g[0] : void 0,
    Te = ue();
  return e.jsxs(
    me.div,
    {
      initial: { opacity: 0, y: 12 },
      animate: { opacity: 1, y: 0 },
      className: "space-y-4",
      "data-under-attack-stage": "result",
      "data-protection": s,
      children: [
        e.jsxs("div", {
          className: `flex flex-wrap items-center gap-x-4 gap-y-3 rounded-2xl border p-4 sm:flex-nowrap sm:p-5 ${n.panel}`,
          children: [
            e.jsx(E, {
              scenario: i.id,
              mood: s,
              variant: "badge",
              className: "h-16 w-16 shrink-0 sm:h-20 sm:w-20",
            }),
            e.jsx("div", {
              className: "min-w-0 flex-1",
              children: e.jsx("h2", {
                className: `text-2xl font-semibold ${n.text}`,
                children: n.label,
              }),
            }),
            e.jsx("div", {
              className: "flex w-full justify-center sm:w-auto",
              children: e.jsx(nl, { results: l, current: a }),
            }),
          ],
        }),
        e.jsxs("div", {
          className:
            "overflow-hidden rounded-2xl border border-slate-700 bg-slate-900/80",
          children: [
            e.jsx($r, {
              attackId: t.id,
              attackName: t.name,
              outcome: s,
              defenceId: le?.id,
              defenceName: le?.name,
              missingId: X?.id,
              missingName: X?.name,
              layout: Te ? "portrait" : "landscape",
            }),
            e.jsxs("div", {
              className: "p-5",
              children: [
                e.jsx("h3", {
                  className:
                    "mb-2 text-sm font-semibold uppercase tracking-[0.14em] text-slate-300",
                  children: "What happened",
                }),
                e.jsx("p", {
                  className: "text-sm leading-7 text-slate-300",
                  children: x,
                }),
                s === "partial"
                  ? null
                  : e.jsx("div", {
                      className:
                        "mt-3 flex items-start gap-2 border-t border-slate-700 pt-3",
                      children:
                        s === "protected"
                          ? e.jsxs(e.Fragment, {
                              children: [
                                e.jsx(di, {
                                  "aria-hidden": "true",
                                  className:
                                    "mt-0.5 h-4 w-4 shrink-0 text-emerald-300",
                                }),
                                e.jsx("p", {
                                  className:
                                    "text-sm font-medium text-emerald-300",
                                  children: "No damage to the network or data.",
                                }),
                              ],
                            })
                          : e.jsxs(e.Fragment, {
                              children: [
                                e.jsx(xi, {
                                  "aria-hidden": "true",
                                  className:
                                    "mt-0.5 h-4 w-4 shrink-0 text-rose-300",
                                }),
                                e.jsx("p", {
                                  className:
                                    "text-sm font-medium text-rose-300",
                                  children: t.consequence,
                                }),
                              ],
                            }),
                    }),
              ],
            }),
          ],
        }),
        e.jsxs("div", {
          className: "grid items-start gap-3 sm:grid-cols-2",
          "data-under-attack-defences": !0,
          children: [
            e.jsx(Tt, {
              title: "Relevant items you had",
              tone: "text-emerald-300",
              border: "border-emerald-500/20",
              empty: "None of the relevant defences",
              group: "had",
              cards: [
                ...y.map((m) => ({ item: m, tag: "full" })),
                ...$.map((m) => ({ item: m, tag: "partial" })),
              ],
            }),
            e.jsx(Tt, {
              title: "Would have fully protected",
              tone: "text-rose-300",
              border: "border-rose-500/20",
              empty: "You had full coverage.",
              group: "needed",
              cards: _.map((m) => ({ item: m, caption: H(ve(m, i)) })),
            }),
          ],
        }),
        e.jsxs("div", {
          className: "rounded-2xl border border-primary/30 bg-primary/10 p-5",
          children: [
            e.jsx("h3", {
              className:
                "mb-2 text-sm font-semibold uppercase tracking-[0.14em] text-primary",
              children: "What you learned",
            }),
            e.jsx("p", {
              className: "text-sm leading-7 text-slate-300",
              children: t.learning,
            }),
          ],
        }),
        e.jsx("button", {
          type: "button",
          onClick: d,
          className: $e,
          children: h
            ? "See final results"
            : o
              ? "Budget review"
              : "Next round",
        }),
      ],
    },
    `${t.id}-result`,
  );
}
const xl = { full: "text-emerald-300", partial: "text-amber-300" };
function Tt({ title: i, tone: t, border: s, empty: l, group: a, cards: c }) {
  return e.jsxs("div", {
    className: `rounded-xl border bg-slate-900/80 p-4 ${s}`,
    "data-defence-group": a,
    children: [
      e.jsx("h3", {
        className: `mb-3 text-xs font-semibold uppercase tracking-[0.14em] ${t}`,
        children: i,
      }),
      c.length === 0
        ? e.jsx("p", {
            className: "text-xs italic text-slate-500",
            children: l,
          })
        : e.jsx("ul", {
            className: "grid grid-cols-2 gap-3 lg:grid-cols-3",
            children: c.map(({ item: h, tag: o, caption: d }) =>
              e.jsx(
                "li",
                {
                  "data-defence-card": h.id,
                  className: "flex",
                  children: e.jsxs("figure", {
                    className:
                      "flex w-full flex-col overflow-hidden rounded-lg border border-slate-700 bg-slate-950/60",
                    children: [
                      e.jsx(ke, { itemId: h.id, className: "grayscale" }),
                      e.jsxs("figcaption", {
                        className:
                          "flex flex-1 flex-col px-2 py-1.5 text-xs leading-5",
                        children: [
                          e.jsx("span", {
                            className: "font-semibold text-slate-200",
                            children: h.name,
                          }),
                          o
                            ? e.jsx("span", {
                                className: `font-mono ${xl[o]}`,
                                children: o,
                              })
                            : null,
                          d
                            ? e.jsx("span", {
                                className: "font-mono text-slate-500",
                                children: d,
                              })
                            : null,
                        ],
                      }),
                    ],
                  }),
                },
                h.id,
              ),
            ),
          }),
    ],
  });
}
function fl({
  scenario: i,
  attacks: t,
  results: s,
  purchased: l,
  onRestart: a,
  onPickAnother: c,
}) {
  const h = s.reduce((g, w) => g + Ne[w], 0),
    o = t.length * Ne.protected,
    d = zi(h, o),
    n =
      d.tone === "good"
        ? "text-emerald-300"
        : d.tone === "mixed"
          ? "text-amber-300"
          : "text-rose-300",
    x = Ye(l, i);
  return e.jsxs(e.Fragment, {
    children: [
      e.jsxs("div", {
        className: "space-y-5",
        "aria-live": "polite",
        "data-game-finished": d.tone,
        children: [
          e.jsxs("div", {
            className:
              "flex flex-col gap-5 rounded-2xl border border-slate-700 bg-slate-900/80 p-5 sm:flex-row sm:p-7",
            children: [
              e.jsx(E, {
                variant: "badge",
                scenario: i.id,
                mood:
                  d.tone === "good"
                    ? "protected"
                    : d.tone === "mixed"
                      ? "partial"
                      : "vulnerable",
                className: "h-40 w-40 shrink-0 self-center",
              }),
              e.jsxs("div", {
                className: "flex-1",
                children: [
                  e.jsx("h2", {
                    className: `text-3xl font-semibold ${n}`,
                    children: d.label,
                  }),
                  e.jsxs("p", {
                    className: "mt-1 text-lg text-slate-200",
                    children: [h, " / ", o, " points"],
                  }),
                  e.jsx("p", {
                    className: "mt-3 leading-7 text-slate-300",
                    children: d.message,
                  }),
                  e.jsx("ul", {
                    className: "mt-5 space-y-2 border-t border-slate-700 pt-4",
                    children: t.map((g, w) => {
                      const y = s[w] ?? "vulnerable",
                        $ = Jt[y];
                      return e.jsxs(
                        "li",
                        {
                          className:
                            "flex items-center justify-between gap-3 text-sm",
                          children: [
                            e.jsxs("span", {
                              className:
                                "flex items-center gap-2 text-slate-200",
                              children: [
                                e.jsx($.Icon, {
                                  "aria-hidden": "true",
                                  className: `h-4 w-4 ${$.text}`,
                                }),
                                g.name,
                              ],
                            }),
                            e.jsxs("span", {
                              className: `font-mono text-xs ${$.text}`,
                              children: ["+", Ne[y]],
                            }),
                          ],
                        },
                        g.id,
                      );
                    }),
                  }),
                  e.jsxs("p", {
                    className: "mt-4 text-sm text-slate-400",
                    children: [
                      "You spent ",
                      H(x),
                      " of ",
                      H(Nt(i)),
                      " on",
                      " ",
                      B.filter((g) => l.includes(g.id))
                        .map((g) => g.name)
                        .join(", "),
                      ".",
                    ],
                  }),
                ],
              }),
            ],
          }),
          e.jsxs("div", {
            className: "flex flex-wrap gap-3",
            children: [
              e.jsxs("button", {
                type: "button",
                onClick: a,
                className: Ze,
                children: [
                  e.jsx(oi, { "aria-hidden": "true", className: "h-4 w-4" }),
                  "Play again",
                ],
              }),
              e.jsxs("button", {
                type: "button",
                onClick: c,
                className: Ze,
                children: [
                  e.jsx(ni, { "aria-hidden": "true", className: "h-4 w-4" }),
                  "Choose another organisation",
                ],
              }),
            ],
          }),
        ],
      }),
      e.jsx(ii, { game: "under-attack" }),
    ],
  });
}
function vl() {
  const [i, t] = W.useState({ type: "pick" }),
    [s, l] = W.useState("police"),
    [a, c] = W.useState([]),
    [h, o] = W.useState([]),
    [d, n] = W.useState([]),
    [x, g] = W.useState([]),
    w = st(s);
  ti(
    d.filter((b) => b !== void 0).length,
    Me,
    d.filter((b) => b === "protected").length,
  );
  const y = "round" in i ? i.round : 0,
    $ = W.useCallback(() => t({ type: "attack", round: y }), [y]),
    _ = W.useCallback(() => t({ type: "result", round: y }), [y]);
  function le(b) {
    (l(b), g(rt(st(b))), c([]), o([]), n([]), t({ type: "cards" }));
  }
  function X(b) {
    h.includes(b) ||
      c((A) => (A.includes(b) ? A.filter((Ce) => Ce !== b) : [...A, b]));
  }
  function Te(b) {
    const A = x[b];
    if (!A) return;
    const Ce = Mi(A, a);
    (n((ei) => {
      const it = [...ei];
      return ((it[b] = Ce), it);
    }),
      t({ type: "verdict", round: b }));
  }
  function m(b) {
    b + 1 >= x.length
      ? t({ type: "final" })
      : b + 1 === ge
        ? (o(a), t({ type: "topup" }))
        : t({ type: "interlude", round: b + 1 });
  }
  function Xt() {
    (g(rt(w)), c([]), o([]), n([]), t({ type: "shop" }));
  }
  switch (i.type) {
    case "pick":
      return e.jsx(cl, { onPick: le });
    case "cards":
      return e.jsx("div", {
        className: "ua-cards",
        "data-under-attack-stage": "cards",
        children: e.jsx(li, {
          title: "Know your defences",
          cards: Tr,
          skipLabel: "Skip to the budget",
          doneLabel: "Spend the budget",
          buttonClass: Ze,
          primaryClass: Ct,
          titleClass: "text-xl font-semibold text-slate-50",
          onDone: () => t({ type: "shop" }),
        }),
      });
    case "shop":
      return e.jsx($t, {
        scenario: w,
        purchased: a,
        onToggle: X,
        onConfirm: () => t({ type: "interlude", round: 0 }),
      });
    case "topup":
      return e.jsx($t, {
        scenario: w,
        purchased: a,
        locked: h,
        budget: Nt(w),
        onToggle: X,
        onConfirm: () => t({ type: "interlude", round: ge }),
      });
    case "interlude":
      return e.jsx(ll, { scenario: w.id, onDone: $ }, i.round);
    case "attack": {
      const b = x[i.round];
      return b
        ? e.jsx(hl, {
            scenario: w,
            attack: b,
            round: i.round,
            onReveal: () => Te(i.round),
          })
        : null;
    }
    case "verdict":
      return e.jsx(al, { onDone: _ }, i.round);
    case "result": {
      const b = x[i.round],
        A = d[i.round];
      return b && A
        ? e.jsx(dl, {
            scenario: w,
            attack: b,
            level: A,
            results: d,
            round: i.round,
            purchased: a,
            isLast: i.round === x.length - 1,
            beforeTopUp: i.round === ge - 1,
            onNext: () => m(i.round),
          })
        : null;
    }
    case "final":
      return e.jsx(fl, {
        scenario: w,
        attacks: x,
        results: d,
        purchased: a,
        onRestart: Xt,
        onPickAnother: () => t({ type: "pick" }),
      });
  }
}
export { vl as default };
